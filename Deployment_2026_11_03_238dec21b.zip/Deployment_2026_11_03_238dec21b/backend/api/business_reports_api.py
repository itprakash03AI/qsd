"""Phase 56+58+62 — Business Report Builder, Report Catalog & Export API.

Provides CRUD for BusinessReport + ReportParameter, report execution via
FederationEngine, cascading parameter LOV resolution, certification,
clone from template, share tokens, embed tokens, PDF/Excel export,
and admin config.
"""
from __future__ import annotations

import asyncio
import csv as _csv_mod
import html as _html_mod
import io
import json
from core import download_retention as _dl_retention
import logging
import math as _math_mod
import re as _re_mod
import threading
import time
import uuid
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Optional, List, Any, Dict, Tuple

if TYPE_CHECKING:  # annotation-only — pandas stays a lazy in-function import
    import pandas as pd

from api.strict_request import StrictRequestModel
from api.models.query_models import CLIENT_REQUEST_ID_PATTERN
from api.connector_errors import (
    raise_if_self_clearing, refusal_status, source_unavailable_503,
)
from core.connectors.base import SourceUnavailableError
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, field_validator

from api.deps import get_current_user, get_current_user_or_service_key, require_admin, require_role

# 2026-09-24: AUTHORING a report is an analyst/admin act, like every other
# authoring surface (datasets, saved queries, connections, the SQL editor and
# query builder are all require_role("admin", "analyst")).  Create, duplicate
# and clone took get_current_user, so a VIEWER -- who cannot open the
# datasets page -- could still author a report on any dataset through the
# API.  Found signed in as a real viewer on the login rig.
_REPORT_AUTHOR = require_role("admin", "analyst")
from core.json_utils import sanitize_for_json
from core.reports.instances import (
    record_report_instance,
    truncation_facts,
    try_serve_instance,
)
from core.roles import ADMIN_TIER_ROLES
from core.reports.param_model import normalize_value as _normalize_param_value  # noqa: E402
from core.reports import diagnostics as _run_diagnostics  # noqa: E402  (2026-10-30 Diagnostics panel)
from core.reports.admission import (  # noqa: E402
    CapacityWaitCancelled as _CapacityWaitCancelled,
    ReportAdmissionRefused as _ReportAdmissionRefused,
)
from core.reports.pdf_engine import (  # noqa: E402
    PdfRendererUnavailable, PdfRenderRefused,
    load_weasyprint as _load_weasyprint,
)

logger = logging.getLogger(__name__)
router = APIRouter()

#: A PDF too large for its render budget (core.reports.pdf_engine): the
#: request is well-formed, the document it asks for cannot be produced here.
#: Same status the scan refusals use (api/connector_errors.py).
PDF_REFUSAL_STATUS = 422


def _render_pdf_document(html: str, css: str) -> bytes:
    """Every business-report PDF goes through ``pdf_engine.render_pdf`` --
    rendered in a budgeted child process, never in the API's own heap.
    Called through the module so a test can stand in for it."""
    from core.reports import pdf_engine as _pe
    return _pe.render_pdf(html, css)


def _pdf_refusal(exc: PdfRenderRefused) -> HTTPException:
    """The 422 a refused render answers with: the sentence names the limit
    and the way out (the CSV export)."""
    return HTTPException(status_code=PDF_REFUSAL_STATUS, detail={
        "error": "pdf_too_large", "message": str(exc), "limit": exc.limit,
        "kind": exc.kind, "continue_with": "csv"})


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# ── Dependency injection (set from main.py startup) ─────────────────────────
_db_manager = None
_federation_engine = None
_ws_manager = None


def set_business_reports_dependencies(db_manager, federation_engine, ws_manager=None):
    """Called once from main.py _startup()."""
    global _db_manager, _federation_engine, _ws_manager
    _db_manager = db_manager
    _federation_engine = federation_engine
    _ws_manager = ws_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _require_federation():
    if _federation_engine is None:
        raise RuntimeError("Federation engine not available for business reports")
    return _federation_engine


def _br_can_view(report: dict, user: dict) -> bool:
    """Phase 131 deep-dive #10 — DRY access-check for business reports.

    Phase 157 (2026-06-26) -- ADDITIONALLY consults the new
    ``core.business_report_permissions`` chokepoint so explicit grants
    (per-user or per-group) granted via the Permissions tab are
    honoured.  Legacy entitlements check stays as the FIRST source so
    nothing regresses; chokepoint is purely additive.

    Wraps core.entitlements.can_view (shared utility used by Report /
    FeedConfig / PublishedView).  Adapts BR's field names (is_published /
    owner) to the normalised shape can_view expects (is_public /
    created_by).  Honors owner_group_id for group-based access.

    Three sites previously inlined the same check with the legacy
    is_published/owner/role pattern — group membership was silently
    ignored on BR.  This helper closes that gap.

    2026-08-04 strategic redesign: the decision now lives in ONE chokepoint
    (``core.reports.authorization.can_view_business_report``) shared with
    subscription creation and delivery-time re-checks — no drifting copies.
    """
    from core.reports.authorization import can_view_business_report
    return can_view_business_report(report, user, _db_manager)


def _br_can_edit(report: dict, user: dict) -> bool:
    """Phase 157 -- editor-level check.  Owner / admin / explicit
    editor-or-higher grant."""
    try:
        from core import business_report_permissions as _perm
        return _perm.can_edit(report, user, _db_manager)
    except Exception:
        # Legacy fallback -- owner OR admin.
        username = (user or {}).get("username", "")
        role = (user or {}).get("role", "viewer")
        return (report.get("owner") == username
                or role in ADMIN_TIER_ROLES)


def _resolve_execution_report(db, report: dict, user: dict | None,
                              consumer: bool = False) -> tuple:
    """Publish lifecycle (2026-08-17) — which definition does this run use?

    Delegates to the ONE chokepoint (``core.reports.versions.
    resolve_execution_report``): editors run the DRAFT; ``consumer=True``
    (share / embed tokens, published views — callers with NO session) run
    the CURRENT PUBLISHED VERSION's snapshot or are REFUSED (2026-09-15:
    unpublished / never-published / no version row ⇒ 410, version store
    unreadable ⇒ 503 — the draft is never served to a token).  An
    authenticated grantee keeps the documented fail-open to the draft when
    no version exists, so nothing goes dark pre-backfill.  Archived +
    non-editor ⇒ HTTP 410 (metadata endpoints stay readable for audit).

    Returns ``(effective_report, served_version_meta | None)``.  Call AFTER
    the ``_br_can_view`` gate — authorization is always evaluated against
    the LIVE row.
    """
    from core.reports.versions import (
        ReportNotServableError, resolve_execution_report as _resolve,
    )
    try:
        return _resolve(db, report, user, consumer=consumer)
    except ReportNotServableError as exc:
        raise HTTPException(status_code=int(getattr(exc, "status_code", 410)),
                            detail=str(exc))


# ── Phase 81+83A+113: Async execution state — DB-backed + bounded in-memory cache ────────────
# Status/metadata is persisted to DB; result rows stay in memory with bounded LRU eviction.
from core.cache_layer import create_cache  # noqa: E402
_br_results_cache = create_cache("br_results", ttl=0, max_entries=50)


def _br_cache_set(execution_id: str, value: dict) -> None:
    """Store result in bounded cache with LRU eviction."""
    _br_results_cache.set(execution_id, value)


def _br_cache_get(execution_id: str) -> dict:
    """Get from cache."""
    return _br_results_cache.get(execution_id, {})


def _br_cache_pop(execution_id: str) -> None:
    """Remove from cache."""
    _br_results_cache.delete(execution_id)


def _track_sync_execution(db, report_id: int, username: str,
                          total_rows: int = 0, output_path: str = "", *,
                          status: str = "completed",
                          error: Optional[str] = None,
                          execution_id: Optional[str] = None) -> None:
    """Record a sync execution in BR async jobs table for unified history.

    2026-09-15: also records a REFUSED run (``status="failed"`` + the
    admission reason) so a 503 at the gate is visible in the execution
    history, not only in the caller's response.
    """
    try:
        eid = execution_id or str(uuid.uuid4())
        db.create_br_async_job(eid, report_id, created_by=username)
        fields: Dict[str, Any] = {"status": status}
        if status == "completed":
            fields.update(progress_pct=100, total_rows=total_rows,
                          output_path=output_path)
        if error:
            fields["error"] = error
        db.update_br_async_job(eid, **fields)
    except Exception as exc:
        logger.warning("Failed to track sync execution for report %d: %s", report_id, exc)


async def _admit_report_run(fn, *args, execution_id: str, username: str,
                            report_id: int, db, **kwargs):
    """Sync-route seam onto the REPORT admission gate (2026-09-15).

    Runs ``fn`` through ``core.reports.admission.run_admitted`` as
    ``WorkType.REPORT`` — load-shed, bounded typed queue, pool thread —
    instead of the default executor every ``adb()`` call shares.  A refusal
    is recorded as a FAILED execution carrying the reason, then raised as
    the same 503 + Retry-After that ``/api/execute`` returns.

    H1 (2026-10-07): ``client_request_id`` (in ``kwargs``) reaches the
    gate, so the run's queued events carry it and a cancel can name it; a
    wait the caller cancelled is recorded CANCELLED and answered 409
    ``cancelled_while_queued`` (``ReportAdmissionRefused.as_http``).
    """
    from core.reports.admission import ReportAdmissionRefused, run_admitted
    from core.worker_pool import WorkType
    try:
        # 2026-10-07: the interactive report run waits, fairly and bounded,
        # in the pod-wide queue at the global cap (was an immediate 503).
        from core.reports.admission import interactive_global_wait
        kwargs.setdefault("global_wait", interactive_global_wait())
        return await run_admitted(WorkType.REPORT, fn, *args,
                                  execution_id=execution_id,
                                  username=username, **kwargs)
    except ReportAdmissionRefused as ref:
        await _adb(_track_sync_execution, db, report_id, username,
                   status=("cancelled" if ref.kind == "cancelled" else "failed"),
                   error=ref.reason, execution_id=execution_id)
        raise ref.as_http()


def _public_view_result(result):
    """Drop ``_execute_view``'s INTERNAL keys before the result leaves.

    2026-09-21 -- ``_execute_view_federation`` (and the two executors
    beside it) return their working state alongside the page:
    ``_page_table`` is a live ``pyarrow.Table``, ``_manifest`` an object,
    ``_parquet_path`` a server path.  The published-view HTTP routes
    never ship those -- they build a JSON envelope
    (``published_views.helpers._send_response``).  The business-report
    branches returned the raw dict straight to FastAPI, which tried to
    encode the Arrow table and died:

        ValueError: dictionary update sequence element #0 has length 5
        TypeError:  vars() argument must have __dict__ attribute

    So a ``data_source_type='published_view'`` report COMPUTED its rows
    (the [br-serve] line logs rows=5 total_rows=5) and then 500'd on the
    way out -- every time, since the source type shipped.  Found the
    first time such a report was ever executed.  ``_parquet_path`` would
    also have been a server-path disclosure had the encode succeeded.

    Underscore-prefixed by CONVENTION at every producer, so the rule is
    the convention rather than a list that drifts from it.
    """
    if not isinstance(result, dict):
        return result
    return {k: v for k, v in result.items() if not str(k).startswith("_")}


def _persist_inline_result_artifact(db, report: dict, result: dict,
                                    executed_by: str,
                                    execution_id: Optional[str] = None) -> Optional[str]:
    """Phase 0 reports rewire (2026-08-08) — PV/FV artifact parity.

    published_view / federation_view executions return inline ``{data:[...]}``
    and were the ONLY report sources with no queryable parquet artifact
    (consumed inline at _execute_report_internal), which blocks the microcube
    and instance layers for them.  This helper ADDITIVELY writes
    ``{execution_id}.parquet`` through the same streaming chokepoint every
    other source uses (``core.connector_to_parquet.df_to_parquet_streaming``
    — see the agg-cache serve in federation_engine.py) and registers the
    execution in federation_executions (mirroring the raw_sql tracking block
    in _execute_raw_sql_report) so the paged results endpoint can find it.

    The inline ``data`` keeps flowing exactly as before — the ONLY response
    mutation is ``result.setdefault("execution_id", ...)``.  Memory note: the
    inline rows are ALREADY a fully-materialised list of dicts upstream
    (published_views_api rows_from_table / federation_views_api per-row dict
    loop), so the DataFrame built here is one bounded extra copy of that
    page (bounded by the execution's row_limit), released on return — there
    is no upstream streaming form to consume instead.

    Single chokepoint for all four PV/FV call sites (sync FV, sync PV,
    async PV, share/embed/export dispatch).  Blocking (parquet + DB writes)
    — call via ``asyncio.to_thread`` from async handlers.  Fail-open by
    design: the artifact is additive, so ANY failure logs a warning and
    returns None without touching the inline flow.  Returns the artifact
    path on success.
    """
    try:
        if not isinstance(result, dict):
            return None
        data = result.get("data")
        if not isinstance(data, list):
            return None
        if result.get("_stream_df") is not None:
            # Streaming PV page — ``data`` is intentionally empty; an
            # artifact written from it would LIE about the result.
            return None

        exec_id = execution_id or result.get("execution_id") or str(uuid.uuid4())

        import pandas as _pd
        col_names = [c.get("name") for c in (result.get("columns") or [])
                     if isinstance(c, dict) and c.get("name")]
        df = _pd.DataFrame(data, columns=col_names) if col_names else _pd.DataFrame(data)

        from core.config import paths as _paths
        output_dir = Path(str(_paths.downloads_dir))
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / f"{exec_id}.parquet")

        from core.connector_to_parquet import df_to_parquet_streaming
        stats = df_to_parquet_streaming(df, output_path)

        db.create_federation_execution(
            execution_id=exec_id,
            dataset_id=(report or {}).get("dataset_id") or 0,
            report_id=(report or {}).get("id"),
            sql_generated="",
            column_ids=[],
            executed_by=executed_by,
        )
        db.update_federation_execution(
            exec_id,
            status="completed",
            output_path=output_path,
            total_rows=int(stats.get("total_rows", len(df))),
            duration_seconds=result.get("duration_seconds") or 0,
        )
        result.setdefault("execution_id", exec_id)
        return output_path
    except Exception as exc:
        logger.warning("PV/FV artifact parity write failed (report_id=%s): %s",
                       (report or {}).get("id"), exc)
        return None


def _br_cleanup_stale() -> None:
    """Remove stale async execution entries from DB (called by APScheduler hourly)."""
    try:
        db = _require_db()
        from core import config as _cfg
        ttl = _cfg.business_reports.async_execution_ttl_seconds
        deleted = db.delete_stale_br_async_jobs(ttl)
        if deleted:
            logger.info("Cleaned up %d stale async business-report jobs from DB", deleted)
        # Snapshot keys — cache_layer.keys() is already thread-safe
        candidate_keys = list(_br_results_cache.keys())
        stale_keys = [k for k in candidate_keys if not db.get_br_async_job(k)]
        for k in stale_keys:
            _br_cache_pop(k)
    except Exception as exc:
        logger.debug("_br_cleanup_stale failed: %s", exc)


# ── Phase 81: Relative date resolution ───────────────────────────────────────

def _month_end() -> str:
    today = date.today()
    next_month_first = (today.replace(day=1) + timedelta(days=32)).replace(day=1)
    return (next_month_first - timedelta(days=1)).isoformat()


def _quarter_start() -> str:
    """Phase 83F: First day of current quarter."""
    today = date.today()
    q_month = ((today.month - 1) // 3) * 3 + 1
    return today.replace(month=q_month, day=1).isoformat()


def _quarter_end() -> str:
    """Phase 83F: Last day of current quarter."""
    today = date.today()
    q_month = ((today.month - 1) // 3) * 3 + 3
    next_q = (today.replace(month=q_month, day=1) + timedelta(days=32)).replace(day=1)
    return (next_q - timedelta(days=1)).isoformat()


_RELATIVE_DATE_MAP: Dict[str, Any] = {
    "@TODAY":           lambda: date.today().isoformat(),
    "@YESTERDAY":       lambda: (date.today() - timedelta(days=1)).isoformat(),
    "@MONTH_START":     lambda: date.today().replace(day=1).isoformat(),
    "@MONTH_END":       _month_end,
    "@YEAR_START":      lambda: date.today().replace(month=1, day=1).isoformat(),
    "@YEAR_END":        lambda: date.today().replace(month=12, day=31).isoformat(),
    "@LAST_7_DAYS":     lambda: (date.today() - timedelta(days=7)).isoformat(),
    "@LAST_30_DAYS":    lambda: (date.today() - timedelta(days=30)).isoformat(),
    "@LAST_90_DAYS":    lambda: (date.today() - timedelta(days=90)).isoformat(),
    # Phase 83F — additional macros
    "@QUARTER_START":   _quarter_start,
    "@QUARTER_END":     _quarter_end,
    "@LAST_WEEK_START": lambda: (date.today() - timedelta(days=date.today().weekday() + 7)).isoformat(),
    "@LAST_WEEK_END":   lambda: (date.today() - timedelta(days=date.today().weekday() + 1)).isoformat(),
    "@THIS_WEEK_START": lambda: (date.today() - timedelta(days=date.today().weekday())).isoformat(),
    "@THIS_MONTH_END":  _month_end,  # alias
}


def _resolve_param_value(val: Any) -> Any:
    """Resolve relative date macros (e.g. @TODAY) to concrete date strings."""
    if isinstance(val, str) and val.startswith("@"):
        fn = _RELATIVE_DATE_MAP.get(val.upper())
        if fn:
            return fn()
        # 2026-09-28 -- @PREV_BUSINESS_DAY[:CAL] and friends, through THE
        # shared business-calendar resolver (core.business_calendar_tokens);
        # refuses (400) when the token cannot be rendered, never falls back
        # to plain days.  None = not a calendar token: the literal stays.
        from core.business_calendar_tokens import resolve_if_calendar_token
        calendar_iso = resolve_if_calendar_token(val, today=date.today())
        return calendar_iso if calendar_iso is not None else val
    if isinstance(val, dict):
        # date_range: resolve from/to individually
        return {k: _resolve_param_value(v) for k, v in val.items()}
    if isinstance(val, list):
        return [_resolve_param_value(item) for item in val]
    return val


# ── Phase 81: URL query-string parameter parsing (p_ prefix) ─────────────────

def _parse_url_params(request: Request, report_params: list) -> dict:
    """Parse ?p_<name>=<value> query-string params, validated against report parameters.

    Returns a dict of {param_name: value}. Only known param names (from report_params)
    are accepted. Unknown p_* keys are silently ignored (security: no injection).
    """
    known_names = {p["name"] for p in report_params}
    result: dict = {}
    for key, value in request.query_params.multi_items():
        if key.startswith("p_"):
            param_name = key[2:]  # strip "p_" prefix
            if param_name in known_names:
                result[param_name] = value
    return result


# ── Pydantic models ─────────────────────────────────────────────────────────


def _validate_filter_operators(specs):
    """Refuse a filter the query engine cannot run — AT SAVE TIME.

    2026-08-31.  The report builder offered "Starts With" and "Ends With";
    core.federation_engine implemented neither.  Saving such a report
    returned 200 and produced a report that could NEVER run: 400 on every
    execute, 500 on every export, and nothing at save time to tell the
    author which of their choices was the problem.  The engine's refusal is
    right — silently dropping a filter would return more rows than the
    report asked for — but it happens far too late to act on.

    Both operators are implemented now.  This guard is for the NEXT
    divergence: it reads the engine's own vocabulary, so a filter the engine
    cannot honour is rejected where the author can still change it, and a
    new operator added to the UI alone fails loudly instead of shipping a
    report that saves and never runs.
    """
    if not specs:
        return specs
    from core.federation_engine import SUPPORTED_FILTER_OPERATORS
    bad = sorted({str((s or {}).get("operator") or "")
                  for s in specs
                  if isinstance(s, dict)
                  and str(s.get("operator") or "") not in
                  SUPPORTED_FILTER_OPERATORS})
    if bad:
        raise ValueError(
            f"Unsupported filter operator(s): {bad}. Supported: "
            f"{sorted(SUPPORTED_FILTER_OPERATORS)}. A report saved with an "
            f"operator the query engine cannot run would fail every "
            f"execution and every export, so it is refused here instead.")
    return specs


def _canonical_data_source_type(value):
    """The stored spelling of a data_source_type (None stays None so an
    UPDATE that did not send the field leaves it alone)."""
    if value is None:
        return None
    from core.reports.sources import canonical_source_type
    return canonical_source_type(value)


class ReportCreate(StrictRequestModel):
    # FB-27 (2026-09-19): ONE vocabulary.  ``schedule_config``,
    # ``sql_saved_query_id``, ``cache_ttl_minutes`` are column names on the
    # PARAMETRIC reports table for the same concepts this model spells
    # ``raw_schedule_config`` / ``raw_sql_saved_query_id``; a caller who had
    # read that half of the product sent the obvious spelling and got a 200
    # that stored nothing (pydantic's default extra="ignore").  Measured:
    # PUT {"schedule_config": {...}} -> 200, raw_schedule_config stayed
    # null.  Unknown keys are now a 422 that NAMES the field, the posture
    # the execute bodies took for FB-22 -- not aliases, which would make the
    # second vocabulary official.
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    dataset_id: Optional[int] = None               # Required for saved_query/federation_view; unused for raw_sql
    merged_dataset_id: Optional[int] = None
    merge_config: Optional[dict] = None
    merged_dataset_column_ids: Optional[List[int]] = None  # Phase 81: secondary dataset columns
    column_ids: List[int] = []
    # GAP-1 (2026-08-30): CalculatedMetric.id selection — DECLARED here (an
    # undeclared field is silently dropped by pydantic, the F-009 class).
    # Persisted inside ``layout_config["metric_ids"]``: business_reports has
    # no metric_ids column and layout_config is the report's existing JSON
    # definition store — already snapshotted by publish versions
    # (versions.DEFINITION_FIELDS), copied by duplicate/template clone,
    # hashed by instance serving (_SEMANTIC_FIELDS) and change-logged
    # (TRACKED_FIELDS), so the selection rides every lifecycle path
    # column_ids rides, with no parallel store.
    metric_ids: List[int] = []
    filter_specs: List[dict] = []

    _chk_ops = field_validator("filter_specs")(
        classmethod(lambda cls, v: _validate_filter_operators(v)))
    # FB-46 (2026-09-20): ``dataset`` is the API contract's spelling of a
    # dataset-backed report and ``saved_query`` the backend's; one vocabulary
    # is stored.  Existing rows and version snapshots that already carry the
    # alias are read through core.reports.sources.canonical_source_type.
    _chk_dst = field_validator("data_source_type")(
        classmethod(lambda cls, v: _canonical_data_source_type(v)))
    condition_ids: List[int] = []
    order_by: List[dict] = []
    # 2026-10-24 (the owner: "why does a report have row limits?") -- a new
    # report has NO limit of its own: null = the deployment's ceiling
    # (business_reports.default_row_limit), the viewer pages the result and
    # CSV export streams every row.  An author may still set "at most N".
    row_limit: Optional[int] = None
    section_definitions: List[dict] = []
    running_calculations: List[dict] = []
    slicer_column_ids: List[int] = []
    drill_hierarchy_id: Optional[int] = None
    layout_config: Optional[dict] = None
    role_whitelist: Optional[List[str]] = None
    data_source_type: str = "saved_query"          # "saved_query" | "federation_view" | "published_view" | "raw_sql"
    federation_view_id: Optional[int] = None       # Phase 93
    published_view_id: Optional[int] = None        # Phase 100
    # Phase 111: raw_sql source type (parametric report unification)
    raw_saved_query_id: Optional[int] = None
    raw_sql_saved_query_id: Optional[int] = None
    # Phase 131 deep-dive #13: published .sql file as report source
    raw_sql_file_id: Optional[int] = None
    raw_sql_override: Optional[str] = None
    raw_parameters_schema: Optional[List[dict]] = None
    raw_schedule_config: Optional[dict] = None
    raw_connection_override_id: Optional[int] = None
    legacy_report_id: Optional[int] = None
    # Phase 131 deep-dive #10: entitlement parity with Report/FeedConfig/PV
    owner_group_id: Optional[int] = None
    # Phase 2 report-instance layer (2026-08-09) — BO "Refresh When Open"
    # parity.  False (default) = an open may serve the latest matching
    # instance once business_reports.instance_serving_enabled is flipped;
    # True = always execute on open.
    refresh_on_open: Optional[bool] = None


class ReportUpdate(StrictRequestModel):
    # FB-27 (2026-09-19): extra="forbid" -- see ReportCreate.  A wrong
    # spelling on an UPDATE is the accepted-then-ignored class at its worst:
    # a 200 that changes nothing on a resource the caller believes changed.
    # 2026-08-25 — DECLARED so it stops being dropped. ReportCreate has always
    # had dataset_id; this model did not, and pydantic's default
    # extra='ignore' discarded it silently while APPLYING the column_ids sent
    # in the same request. A report therefore kept its OLD dataset while
    # holding the NEW dataset's column ids — the next run 400s blaming columns
    # the user had just picked, or the edit is a silent no-op behind a 200.
    #
    # Not nullable on the model, so it is listed in _NON_CLEARABLE below: an
    # explicit null is refused with a 400 instead of reaching flush() as a 500.
    dataset_id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[str] = None
    #: 2026-09-18 -- mark/unmark a report as a SAMPLE.  Samples are hidden
    #: from the list unless the caller asks for them (?include_samples=true,
    #: the UI's "Show samples" toggle), so seeded demos and probe reports do
    #: not bury the real ones.
    is_sample: Optional[bool] = None
    column_ids: Optional[List[int]] = None
    # GAP-1 (2026-08-30): see ReportCreate.metric_ids.  Clearable: explicit
    # null or [] removes the selection (unlike column_ids, an empty metric
    # selection is a fully valid report).
    metric_ids: Optional[List[int]] = None
    filter_specs: Optional[List[dict]] = None

    _chk_ops = field_validator("filter_specs")(
        classmethod(lambda cls, v: _validate_filter_operators(v)))
    # FB-46 (2026-09-20): ``dataset`` is the API contract's spelling of a
    # dataset-backed report and ``saved_query`` the backend's; one vocabulary
    # is stored.  Existing rows and version snapshots that already carry the
    # alias are read through core.reports.sources.canonical_source_type.
    _chk_dst = field_validator("data_source_type")(
        classmethod(lambda cls, v: _canonical_data_source_type(v)))
    condition_ids: Optional[List[int]] = None
    order_by: Optional[List[dict]] = None
    row_limit: Optional[int] = None
    section_definitions: Optional[List[dict]] = None
    running_calculations: Optional[List[dict]] = None
    slicer_column_ids: Optional[List[int]] = None
    drill_hierarchy_id: Optional[int] = None
    layout_config: Optional[dict] = None
    # 2026-10-26 (the report canvas): the ``updated_at`` the editor loaded.
    # Sent = "save only if nobody saved since"; a different stored value is a
    # 409 naming who saved when -- never last-writer-wins over a colleague.
    expected_updated_at: Optional[str] = None
    merged_dataset_id: Optional[int] = None
    merge_config: Optional[dict] = None
    merged_dataset_column_ids: Optional[List[int]] = None  # Phase 81: secondary dataset columns
    role_whitelist: Optional[List[str]] = None
    data_source_type: Optional[str] = None                 # Phase 93
    federation_view_id: Optional[int] = None               # Phase 93
    published_view_id: Optional[int] = None                # Phase 100
    # Phase 111: raw_sql source type
    raw_saved_query_id: Optional[int] = None
    raw_sql_saved_query_id: Optional[int] = None
    # Phase 131 deep-dive #13: published .sql file as report source
    raw_sql_file_id: Optional[int] = None
    raw_sql_override: Optional[str] = None
    raw_parameters_schema: Optional[List[dict]] = None
    raw_schedule_config: Optional[dict] = None
    raw_connection_override_id: Optional[int] = None
    legacy_report_id: Optional[int] = None
    owner_group_id: Optional[int] = None  # Phase 131 deep-dive #10
    refresh_on_open: Optional[bool] = None  # Phase 2 instance layer (2026-08-09)


class ReportExecuteRequest(StrictRequestModel):
    parameter_values: dict = {}  # {param_name: value}
    extra_filters: List[dict] = []
    # Edge-case sweep 2026-09-24: -1 was normalised to 0 == UNLIMITED -- a
    # negative (a client bug, or "no limit" in another convention) removed the
    # cap instead of refusing.  0 stays the one spelling of unlimited.
    limit_override: Optional[int] = Field(default=None, ge=0)
    override_column_ids: Optional[List[int]] = None  # Phase 112: drill-down level columns
    #: H1 (2026-10-07): the client's correlation id for this run -- carried by
    #: every execution_queued event while the request waits for a slot in the
    #: pod-wide fair queue, and the handle POST /api/execute/queued/cancel
    #: ends that wait by.
    client_request_id: Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)
    # Phase 2 UX (2026-08-09) — the viewer's "Refresh" affordance (BO
    # View-on-Demand parity): a caller-requested one-off LIVE run.  Bypasses
    # instance SERVING only; the fresh execution still write-throughs a new
    # instance so the next open is fresh.  See _wants_instance_serve().
    force_refresh: bool = False
    #: 2026-11-01 -- the "Data version" run control (core/iceberg_versions.py):
    #: ``{<iceberg table>: {"snapshot_id": "..."} | {"as_of": "<ISO time>"} |
    #: "latest"}``, one entry per Iceberg table of the dataset's storage
    #: connection; a missing table reads the version the dataset's SQL pins,
    #: else latest.  THE precedence is ``decide_pin``; the run record and the
    #: instance name every table's version; the override is audited.
    data_version: Optional[Dict[str, Any]] = None


def _param_values_source(v: Any) -> str:
    from core.reports.param_values import normalise_source
    return normalise_source(v)


class ReportParameterCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    label: str = Field(..., min_length=1, max_length=200)
    parameter_type: str = "dropdown"
    lov_column_id: Optional[int] = None
    # 2026-08-31 — the author's curated choices.  Answers "what may the
    # viewer pick?"; lov_column_id still answers "which column does the
    # pick filter?".  Two questions, two fields — a static list with no
    # column bound offers choices that filter nothing.
    static_values: Optional[List[str]] = None
    # 2026-10-23 -- where the choices come from: auto (default) | data |
    # metadata | static (core/reports/param_values.py, the one rule).
    values_source: Optional[str] = None
    # 2026-10-24 -- values_source "table": the other table's column
    lov_source_connection_id: Optional[int] = None
    lov_source_table: Optional[str] = Field(default=None, max_length=500)
    lov_source_column: Optional[str] = Field(default=None, max_length=255)
    # 2026-10-24 -- values_source "list": a named value list (core/value_lists.py)
    value_list_id: Optional[int] = None
    # 2026-10-29 -- FILTER AT THE SOURCE: the key of a predicate in the
    # dataset's own SQL WHERE (core/source_filters.py); the value goes INTO
    # that predicate and the query runs on the source.  Checked against the
    # dataset's SQL on save (_refuse_unbound_source_columns).
    source_column: Optional[str] = Field(default=None, max_length=200)
    depends_on_param_id: Optional[int] = None
    cascade_filter_column_id: Optional[int] = None
    default_value: Optional[str] = None
    description: Optional[str] = Field(default=None, max_length=500)  # tooltip help text
    is_required: bool = True
    sort_order: int = 0
    # 2026-11-01 -- the general parameter model (core/reports/param_contract.py)
    applies: Optional[List[Dict[str, Any]]] = None
    default_rule: Optional[str] = None
    visible: Optional[bool] = None
    group_label: Optional[str] = Field(default=None, max_length=100)
    show_when: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    template_id: Optional[int] = None

    _chk_values_source = field_validator("values_source")(
        lambda v: None if v is None else _param_values_source(v))


class ReportParameterUpdate(BaseModel):
    name: Optional[str] = None
    label: Optional[str] = None
    parameter_type: Optional[str] = None
    lov_column_id: Optional[int] = None
    static_values: Optional[List[str]] = None
    values_source: Optional[str] = None
    # 2026-10-24 -- values_source "table": the other table's column
    lov_source_connection_id: Optional[int] = None
    lov_source_table: Optional[str] = Field(default=None, max_length=500)
    lov_source_column: Optional[str] = Field(default=None, max_length=255)
    # 2026-10-24 -- values_source "list": a named value list (core/value_lists.py)
    value_list_id: Optional[int] = None
    # 2026-10-29 -- filter at the source (core/source_filters.py)
    source_column: Optional[str] = Field(default=None, max_length=200)
    depends_on_param_id: Optional[int] = None
    cascade_filter_column_id: Optional[int] = None
    default_value: Optional[str] = None
    description: Optional[str] = Field(default=None, max_length=500)
    is_required: Optional[bool] = None
    sort_order: Optional[int] = None
    applies: Optional[List[Dict[str, Any]]] = None
    default_rule: Optional[str] = None
    visible: Optional[bool] = None
    group_label: Optional[str] = Field(default=None, max_length=100)
    show_when: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    template_id: Optional[int] = None

    _chk_values_source = field_validator("values_source")(
        lambda v: None if v is None else _param_values_source(v))


class ParameterValuesRequest(BaseModel):
    parameter_id: int
    parent_values: dict = {}  # {parent_param_name: selected_value}
    # 2026-10-23 -- the editor's "show the values from ..." (to capture them
    # as a saved list); a viewer sends none.  Same rules as a stored source.
    source: Optional[str] = None
    # 2026-10-24 -- type to search: a case-insensitive "contains" on the
    # server, so a value past the list's cap can still be found.
    search: Optional[str] = Field(default=None, max_length=200)

    _chk_source = field_validator("source")(
        lambda v: None if v is None else _param_values_source(v))


class CertifyRequest(BaseModel):
    template_category: str = Field(..., min_length=1, max_length=100)


class ShareCreateRequest(BaseModel):
    expires_hours: Optional[int] = None  # None = use config default


class EmbedTokenCreateRequest(BaseModel):
    expires_in_days: Optional[int] = None  # None = use config default
    # 2026-08-29 — optional per-group scope for the embed (see
    # ``ReportEmbedToken``).  Either list, both, or neither: an AD directory is
    # NOT a precondition, and a deployment with only QueryStudio-native groups
    # is a first-class case.  Omitting both keeps today's behaviour.
    allowed_ad_groups: Optional[List[str]] = None
    allowed_user_groups: Optional[List[str]] = None


class EmbedExecuteRequest(StrictRequestModel):
    # AQD-12 (2026-09-23): strict like its sibling below.  An anonymous
    # surface that silently ignores a field it was sent is a contract that
    # says one thing and does another.
    parameter_values: dict = {}
    limit: Optional[int] = 1000


class SharedExecuteRequest(StrictRequestModel):
    """What an ANONYMOUS share-link caller may ask for -- and nothing else.

    AQD-12 (2026-09-23).  The share route reused the full authenticated
    ReportExecuteRequest, so its published contract offered
    ``override_column_ids`` and ``force_refresh`` to anyone holding a link.
    The route silently dropped both: the SAFE behaviour (an anonymous caller
    must not pull columns the author did not publish, nor bypass the cache),
    held up by an undocumented omission instead of a stated refusal.  This
    model carries exactly the three fields the route honours, so asking for
    another column is now a 422 that names the field, and the contract and
    the behaviour agree.  The embed model above was already narrow in shape.
    """
    parameter_values: dict = {}
    extra_filters: List[dict] = []
    # Narrow-only: _resolve_token_row_limit bounds it by the author's limit.
    limit_override: Optional[int] = None


class AsyncExecuteRequest(StrictRequestModel):
    parameter_values: dict = {}
    extra_filters: List[dict] = []
    limit_override: Optional[int] = None
    override_column_ids: Optional[List[int]] = None  # Phase 112: drill-down level columns
    # Phase 2 UX (2026-08-09) — one-off live refresh; see ReportExecuteRequest.
    force_refresh: bool = False
    #: 2026-11-01 -- see ReportExecuteRequest.data_version
    data_version: Optional[Dict[str, Any]] = None


def _with_data_version(report: dict, data_version: Optional[Dict[str, Any]], user: Optional[dict],
                       db, report_id: int) -> dict:
    """Stamp the run's Data version override on the report dict the query
    runners read (``_run_report_query`` -> ``execute_dataset_query(
    version_overrides=)``), checked by THE parser (422 in words), and
    AUDITED with who asked for what (``report.data_version_override``).
    No override = the dict unchanged."""
    if not data_version:
        return report
    from core import iceberg_versions as _iv
    try:
        parsed = _iv.parse_body_overrides(data_version)
    except _iv.IcebergVersionRefusal as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    if not parsed:
        return report
    try:
        from core.audit import audit_event
        audit_event(db, user or {}, None, action="report.data_version_override",
                    resource_type="business_report", resource_id=str(report_id),
                    details={"data_version": _iv.serialize_overrides(parsed),
                             "by": (user or {}).get("username")})
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("data_version audit skipped: %s", exc)
    return {**report, "_data_version": dict(data_version)}


class BusinessReportsConfigUpdate(BaseModel):
    """Phase 81 — admin-writable business reports config fields."""
    enabled: Optional[bool] = None
    max_reports_per_user: Optional[int] = None
    max_sections_per_report: Optional[int] = None
    max_parameters_per_report: Optional[int] = None
    max_running_calcs_per_report: Optional[int] = None
    default_row_limit: Optional[int] = None
    pdf_row_limit: Optional[int] = None
    pdf_max_rows: Optional[int] = None       # 2026-10-04 PDF memory ceiling
    excel_row_limit: Optional[int] = None
    csv_row_limit: Optional[int] = None      # 2026-10-04 0 = every row
    embed_row_limit: Optional[int] = None
    cascade_lov_limit: Optional[int] = None
    page_size: Optional[int] = None
    max_page_size: Optional[int] = None
    auto_save_interval_seconds: Optional[int] = None
    export_formats: Optional[List[str]] = None
    async_execution_ttl_seconds: Optional[int] = None
    pdf_page_size: Optional[str] = None
    pdf_primary_color: Optional[str] = None


VALID_PIVOT_AGGREGATIONS = {"sum", "avg", "count", "min", "max", "count_distinct"}


def _instance_cacheable_for(body) -> bool:
    """May this request serve from / write to the SHARED report instance?

    An instance is the report's STORED shape at the data's CURRENT version.
    Extra filters, drill column overrides and limit overrides change the bytes;
    a ``data_version`` (a run pinned to an older Iceberg snapshot, or "as of a
    time") changes the DATA -- served from the instance it would show today's
    numbers as the pinned ones, and written to it every later reader (and a
    sign-off) would see the old version as the current instance (security
    review of 5f04142e9).  Any of them disables BOTH serve and record.
    """
    return not (getattr(body, "extra_filters", None)
                or getattr(body, "override_column_ids", None)
                or getattr(body, "limit_override", None)
                or getattr(body, "data_version", None))


def _wants_instance_serve(body) -> bool:
    """Phase 2 UX (2026-08-09): may this execute request be answered from a
    stored instance?

    ``force_refresh=True`` (the viewer's "Refresh" button — BO
    View-on-Demand parity) bypasses instance SERVING only.  It deliberately
    does NOT make the request non-cacheable: the forced live execution
    still write-throughs a fresh instance, so the user who clicked Refresh
    is the one who pre-warms the next open for everyone in their scope.
    Shape-changing overrides (extra_filters / override_column_ids /
    limit_override) are handled separately by ``_instance_cacheable``,
    which disables BOTH serve and record.
    """
    return not bool(getattr(body, "force_refresh", False))


class PivotValueField(BaseModel):
    """A measure field in the pivot Values zone with its aggregation function."""
    column_id: int
    aggregation: str = "sum"  # sum|avg|count|min|max|count_distinct


class PivotConfig(BaseModel):
    """Pivot layout configuration stored inside layout_config.pivot_config."""
    row_field_ids: List[int]                 # dimension column IDs for row headers
    col_field_ids: List[int] = []            # dimension column IDs for column headers
    value_fields: List[PivotValueField]      # measures with per-field aggregation
    show_row_totals: bool = True
    show_col_totals: bool = True
    show_grand_total: bool = True


class PivotReportsConfigUpdate(BaseModel):
    """Phase 106 — admin-writable pivot reports config fields."""
    enabled: Optional[bool] = None
    max_row_dimensions: Optional[int] = None
    max_col_dimensions: Optional[int] = None
    max_measures: Optional[int] = None
    max_row_groups: Optional[int] = None
    max_col_groups: Optional[int] = None
    default_aggregation: Optional[str] = None


def _validate_pivot_config(layout_config: dict, dataset_id: int, db) -> None:
    """Validate pivot_config within layout_config. Raises HTTPException on error."""
    if not layout_config or layout_config.get("report_type") != "pivot":
        return

    raw = layout_config.get("pivot_config")
    if not raw:
        raise HTTPException(400, "Pivot report requires pivot_config in layout_config")

    try:
        pc = PivotConfig(**raw)
    except Exception as exc:
        raise HTTPException(400, f"Invalid pivot_config: {exc}")

    from core.config import pivot_reports as _pv_cfg

    # ── Limit checks ──
    if len(pc.row_field_ids) > _pv_cfg.max_row_dimensions:
        raise HTTPException(400, f"Max {_pv_cfg.max_row_dimensions} row dimensions allowed")
    if len(pc.col_field_ids) > _pv_cfg.max_col_dimensions:
        raise HTTPException(400, f"Max {_pv_cfg.max_col_dimensions} column dimensions allowed")
    if len(pc.value_fields) > _pv_cfg.max_measures:
        raise HTTPException(400, f"Max {_pv_cfg.max_measures} measure fields allowed")
    if not pc.row_field_ids:
        raise HTTPException(400, "At least one row dimension is required")
    if not pc.value_fields:
        raise HTTPException(400, "At least one measure field is required")

    # ── Aggregation validation ──
    for vf in pc.value_fields:
        vf.aggregation = vf.aggregation.lower()
        if vf.aggregation not in VALID_PIVOT_AGGREGATIONS:
            raise HTTPException(400, f"Invalid aggregation '{vf.aggregation}'. "
                                f"Must be one of: {', '.join(sorted(VALID_PIVOT_AGGREGATIONS))}")

    # ── Column existence + type checks ──
    ds = db.get_dataset_full(dataset_id)
    if not ds:
        raise HTTPException(404, f"Dataset {dataset_id} not found")
    col_map = {c["id"]: c for c in ds.get("columns", [])}

    for cid in pc.row_field_ids + pc.col_field_ids:
        col = col_map.get(cid)
        if not col:
            raise HTTPException(400, f"Column ID {cid} not found in dataset {dataset_id}")
        if col.get("column_type") not in ("dimension", "detail"):
            raise HTTPException(400, f"Column '{col.get('physical_name')}' is a {col.get('column_type')}, "
                                "not a dimension — cannot use as row/column field")

    for vf in pc.value_fields:
        col = col_map.get(vf.column_id)
        if not col:
            raise HTTPException(400, f"Column ID {vf.column_id} not found in dataset {dataset_id}")
        if col.get("column_type") not in ("measure", "kpi"):
            raise HTTPException(400, f"Column '{col.get('physical_name')}' is a {col.get('column_type')}, "
                                "not a measure — cannot use as value field")


# ── Chart view (2026-08-09): saved visualisation config ──────────────────────
#
# A business report can carry ONE saved chart definition in
# layout_config.chart_config — the same JSON home as pivot_config /
# style_config / column_order, so NO schema migration.  The chart is a
# RENDERER over the microcube: the viewer answers it with the same
# POST .../results/{exec_id}/cube drill query the table uses, which means
# every correctness gate (non-additive 422, identifier validation,
# truncation disclosure) applies to charts with zero extra code here.
# This validator gates the SHAPE at save time — presentation config, but a
# wrong chart_type or a dimension plotted as a measure should fail loudly
# at authoring, not render nonsense in the viewer.

VALID_CHART_TYPES = frozenset({
    "bar", "bar_horizontal", "bar_grouped", "bar_stacked",
    "line", "combo", "donut", "kpi",
})


class ChartViewConfig(BaseModel):
    """Saved chart view stored inside layout_config.chart_config."""
    enabled: bool = True
    chart_type: str
    dimension_col_id: Optional[int] = None       # category axis (dataset column id)
    split_col_id: Optional[int] = None           # series-split dimension
    measure_col_ids: List[int] = []              # plotted measures
    line_measure_col_ids: List[int] = []         # combo: drawn as line
    secondary_axis: bool = False                 # combo: opt-in right-hand axis
    kpi_comparison_col_id: Optional[int] = None  # kpi: e.g. target measure
    top_n: Optional[int] = Field(default=None, ge=1, le=500)   # category CAP
    default_view: Optional[str] = None           # 'table' | 'chart' | 'both'


def _validate_report_selections(dataset_id: Optional[int],
                                condition_ids: Optional[list],
                                layout_config: Optional[dict], db) -> None:
    """Refuse selections that point at things this dataset does not have.

    2026-09-01 — completing the save-time gate.  column_ids, metric_ids, the
    pivot config, the chart config and (as of today) the drill hierarchy are
    all checked at authoring time; ``condition_ids`` and the conditional
    FORMAT rules were not.  Both saved with 200 and then did nothing:

      * a condition id that does not exist was accepted, and the execute
        returned every row — the filter the author thought they had applied
        simply was not there;
      * a format rule with an unknown ``condition_type``, or on a column
        this report cannot see, was accepted and then ignored downstream.

    In every case the author gets a success, a report that runs, and a
    feature that is quietly absent.  That is the failure mode this codebase
    keeps producing, and the fix is always the same: refuse where the person
    can still act on it.

    Fails OPEN on an unreadable lookup — a dataset that cannot be read must
    not block saving.
    """
    if not dataset_id:
        return
    try:
        known_conditions = {int(c["id"]) for c in
                            (db.list_predefined_conditions(dataset_id) or [])
                            if c.get("id") is not None}
        known_columns = {int(c["id"]) for c in
                         (db.list_dataset_columns(dataset_id) or [])
                         if c.get("id") is not None}
    except Exception as exc:
        logger.debug("report selections not validated (dataset %s unreadable): %s",
                     dataset_id, exc)
        return

    bad = sorted({int(c) for c in (condition_ids or [])} - known_conditions)
    if bad:
        raise HTTPException(
            status_code=400,
            detail=f"Condition(s) {bad} are not defined on dataset "
                   f"{dataset_id}. The report would save and run with the "
                   f"condition silently absent, returning more rows than "
                   f"you asked for.")

    for rule in ((layout_config or {}).get("conditional_formats") or []):
        if not isinstance(rule, dict):
            continue
        ctype = rule.get("condition_type")
        if ctype and ctype not in _FMT_CONDITION_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown conditional-format condition type "
                       f"{ctype!r}. Supported: "
                       f"{', '.join(sorted(_FMT_CONDITION_TYPES))}. A rule "
                       f"with an unrecognised type never fires.")
        cid = rule.get("column_id")
        if cid is not None and int(cid) not in known_columns:
            raise HTTPException(
                status_code=400,
                detail=f"Conditional-format rule targets column {cid}, which "
                       f"is not on dataset {dataset_id}. The rule would be "
                       f"saved and never applied.")


#: data_source_type values whose ``column_ids`` / ``filter_specs`` are ids of
#: the report's DATASET columns (canonical spelling -- see
#: core.reports.sources.canonical_source_type).
_DATASET_COLUMN_SOURCES = frozenset({"saved_query"})


def _dataset_column_index(dataset_ids: List[int], db) -> Optional[Dict[int, dict]]:
    """id -> column row over the given datasets, or None when unreadable."""
    out: Dict[int, dict] = {}
    try:
        for ds_id in dataset_ids:
            for c in (db.list_dataset_columns(ds_id) or []):
                if c.get("id") is not None:
                    out[int(c["id"])] = c
    except Exception as exc:                              # noqa: BLE001
        logger.debug("report column refs not validated (datasets %s "
                     "unreadable): %s", dataset_ids, exc)
        return None
    return out


def _column_label(cid: Any, index: Optional[Dict[int, dict]]) -> str:
    try:
        c = (index or {}).get(int(cid))
    except (TypeError, ValueError):
        c = None
    if not c:
        return f"column {cid!r}"
    name = c.get("friendly_name") or c.get("physical_name") or ""
    phys = c.get("physical_name") or ""
    shown = f"'{name}'" + (f" ({phys})" if phys and phys != name else "")
    return f"{shown}, column id {cid}"


def _refuse_unfilled_filters(filter_specs: Optional[list],
                             index: Optional[Dict[int, dict]]) -> None:
    """422 for a filter row that was never given its value -- AT SAVE TIME.

    2026-10-03 (owner, real Snowflake).  The builder's "Add Filter" seeds a
    row ``{column: first column, operator: eq, value: ""}``; left untouched
    it was SAVED, and the report rendered ``WHERE "REGION" = ''`` -- 0 rows
    behind a 200 while the dataset returned 4.  An unfilled row is not a
    filter.  The engine refuses to RUN one (``_filter_to_sql``); this
    refuses to SAVE one, naming the column, where the author can still act.
    The decision is ``core.federation_engine.is_unfilled_filter`` -- one
    answer for both ends.
    """
    from core.federation_engine import is_unfilled_filter
    for i, spec in enumerate(filter_specs or []):
        if not isinstance(spec, dict):
            continue
        if is_unfilled_filter(spec.get("operator"), spec.get("value"),
                              spec.get("value2")):
            raise HTTPException(
                status_code=422,
                detail=(f"Filter {i + 1} on {_column_label(spec.get('column_id'), index)} "
                        f"has no value (operator '{spec.get('operator') or 'eq'}'). "
                        f"An unfilled filter row is not a filter: pick a value "
                        f"for it or remove it. To test for a missing value use "
                        f"'is_null' / 'is_not_null'. Saving it would run "
                        f"\"= ''\" and return no rows."))


def _refuse_invisible_datasets(db, user: dict, *dataset_ids) -> None:
    """A report is built only on datasets its author may VIEW (2026-10-24,
    security review: create / update checked neither the dataset nor the
    second dataset of a merge, so an author could name a dataset they cannot
    see -- read its column names from a refusal, or its rows through the
    report).  THE dataset rule, ``core.entitlements.dataset_can_view``
    (published, or owner / group / admin); 404 for none, 403 for not
    visible -- before any other gate reads the dataset."""
    from core.entitlements import dataset_can_view
    for did in dataset_ids:
        if not did:
            continue
        ds = db.get_dataset(int(did))
        if not ds:
            raise HTTPException(status_code=404, detail=f"Dataset {did} not found")
        if not dataset_can_view(ds, user, db=db):
            raise HTTPException(
                status_code=403,
                detail=f"Not authorized to build a report on dataset {did} (it is not "
                       f"published and you are not its owner)")


def _refuse_unrunnable_union(db, **report_fields) -> None:
    """Save-time gate of a UNION ALL report (2026-10-24): the run's own
    checks (core/reports/union_of_datasets.py), as a 422 naming the cause,
    while the author is here."""
    from core.reports.union_of_datasets import UnionReportRefused, refuse_if_unrunnable
    try:
        refuse_if_unrunnable(db, **report_fields)
    except UnionReportRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))


def _validate_report_column_refs(*, dataset_id: Optional[int],
                                 merged_dataset_id: Optional[int],
                                 data_source_type: Optional[str],
                                 column_ids: Optional[list],
                                 filter_specs: Optional[list],
                                 section_definitions: Optional[list],
                                 slicer_column_ids: Optional[list],
                                 order_by: Optional[list], db) -> None:
    """Refuse column ids that are not the report's dataset's -- AT SAVE TIME.

    2026-10-03.  The docstring of ``_validate_report_selections`` has long
    said column_ids are checked at authoring time; they were not.  The
    builder kept the previous dataset's column ids when the author switched
    datasets, and a draft could carry ids from another dataset, so a report
    could be saved selecting, filtering, breaking and slicing on columns
    its dataset does not have.  A selection of a foreign column fails at
    run (filters refuse) or silently shows nothing (sections, slicers).

    Unfilled filter rows are refused for EVERY source type; column
    membership only for dataset-backed reports (primary + merged dataset).
    Fails OPEN on an unreadable dataset, like the sibling gates -- the
    engine still refuses an unresolvable filter at run.
    """
    index: Optional[Dict[int, dict]] = None
    from core.reports.sources import canonical_source_type
    dataset_backed = (canonical_source_type(data_source_type)
                      in _DATASET_COLUMN_SOURCES and bool(dataset_id))
    if dataset_backed:
        ids = [int(dataset_id)] + ([int(merged_dataset_id)]
                                   if merged_dataset_id else [])
        index = _dataset_column_index(ids, db)
    _refuse_unfilled_filters(filter_specs, index)
    if not dataset_backed or index is None:
        return
    # 2026-10-25 (the owner: "we should have all validation rather than just
    # allowing to create a report blindly") -- a value its column cannot hold
    # (a word for a number, 25/10/2026 for a date) is refused HERE, by name,
    # judged on the column's type in the SOURCE: the run would refuse it too.
    from core.federation_engine import FederationEngine
    _typed = FederationEngine(db).filter_spec_problems(ids, filter_specs or [])
    if _typed:
        raise HTTPException(status_code=422, detail=" ".join(_typed))

    def _ids(values) -> List[Any]:
        return [v for v in (values or []) if v is not None]

    refs: List[Tuple[str, Any]] = []
    refs += [("column_ids", c) for c in _ids(column_ids)]
    refs += [("slicer_column_ids", c) for c in _ids(slicer_column_ids)]
    for spec in filter_specs or []:
        if isinstance(spec, dict):
            refs.append(("filter_specs", spec.get("column_id")))
    for ob in order_by or []:
        if isinstance(ob, dict) and ob.get("column_id") is not None:
            refs.append(("order_by", ob.get("column_id")))
    for s in section_definitions or []:
        if not isinstance(s, dict):
            continue
        if s.get("break_column_id") is not None:
            refs.append(("section_definitions", s.get("break_column_id")))
        refs += [("section_definitions", m)
                 for m in _ids(s.get("subtotal_measure_ids"))]

    bad: Dict[str, List[Any]] = {}
    for field, cid in refs:
        try:
            known = int(cid) in index
        except (TypeError, ValueError):
            known = False
        if not known:
            bad.setdefault(field, []).append(cid)
    if bad:
        where = "; ".join(f"{f}: {sorted(set(map(str, v)))}"
                          for f, v in sorted(bad.items()))
        raise HTTPException(
            status_code=422,
            detail=(f"Column id(s) that are not columns of dataset {dataset_id}"
                    f"{f' (or merged dataset {merged_dataset_id})' if merged_dataset_id else ''}"
                    f" -- {where}. A report cannot select, filter, sort, "
                    f"break or slice on another dataset's columns; re-pick "
                    f"them on this dataset."))


def _validate_drill_hierarchy(hierarchy_id: Optional[int],
                              dataset_id: Optional[int], db) -> None:
    """Refuse a drill hierarchy that is not this dataset's.

    2026-09-01 — column_ids, metric_ids, the pivot config and the chart
    config are all validated at authoring time, on the stated principle two
    lines above the call site: "fail loudly at authoring, not in the
    viewer".  ``drill_hierarchy_id`` was the one that was not, so a report
    could be saved pointing at a hierarchy that does not exist — or, more
    likely, one that was DELETED after the report was written — and the
    drill simply did nothing.  No error at save, none at execute: the rows
    come back and the feature is silently absent, which is the hardest kind
    of broken to notice.

    Fails OPEN on an unreadable lookup: a hierarchy that cannot be checked
    must not block saving an otherwise valid report.
    """
    if not hierarchy_id:
        return
    try:
        h = db.get_drill_hierarchy(int(hierarchy_id))
    except Exception as exc:
        logger.debug("drill hierarchy %s unreadable, not validated: %s",
                     hierarchy_id, exc)
        return
    if not h:
        raise HTTPException(
            status_code=400,
            detail=f"Drill hierarchy {hierarchy_id} does not exist. The "
                   f"report would save and its drill-down would silently do "
                   f"nothing.")
    h_ds = h.get("dataset_id")
    if dataset_id and h_ds and int(h_ds) != int(dataset_id):
        raise HTTPException(
            status_code=400,
            detail=f"Drill hierarchy {hierarchy_id} belongs to dataset "
                   f"{h_ds}, not {dataset_id}. Its levels are columns this "
                   f"report cannot see.")


def _norm_ts(v: str) -> str:
    """One spelling of a stored timestamp for the save precondition: ISO with
    'T', no timezone suffix, microseconds kept (the API returns what it
    stored; a client echoes it)."""
    t = (v or "").strip().replace(" ", "T")
    for suffix in ("+00:00", "Z"):
        if t.endswith(suffix):
            t = t[: -len(suffix)]
    return t


def _validate_canvas(layout_config: Optional[dict], dataset_id: Optional[int],
                     column_ids: Optional[List[int]], db, user: Optional[dict] = None) -> None:
    """The report canvas (2026-10-26): ``layout_config.canvas`` is checked on
    save by ``core.reports.canvas.canvas_problems`` -- every problem named on
    the tile it concerns, one 422 listing them all."""
    # 2026-11-01 -- the LOOK (layout_config.theme) is checked first: a bad colour,
    # an unknown theme name or an unreadable contrast refuses the save in words
    if isinstance(layout_config, dict) and layout_config.get("theme") is not None:
        from core.reports.themes import theme_problems
        _tp, _tw = theme_problems(layout_config.get("theme"), db)
        if _tp:
            raise HTTPException(status_code=422, detail={
                "error": "theme_problems", "problems": _tp, "warnings": _tw,
                "message": "The report's look cannot be saved: " + " ".join(_tp)})
    if isinstance(layout_config, dict) and layout_config.get("insights") is not None:
        from core.reports.insight_story import settings_problems
        _ip = settings_problems(layout_config.get("insights"))
        if _ip:
            raise HTTPException(status_code=422, detail={"error": "insight_settings_problems", "problems": _ip,
                                                         "message": "The insight settings cannot be saved: " + " ".join(_ip)})
    canvas = (layout_config or {}).get("canvas") if isinstance(layout_config, dict) else None
    if canvas is None:
        return
    from core.reports.canvas import canvas_problems
    columns: List[dict] = []
    has_metrics = False
    if dataset_id:
        ds = db.get_dataset_full(dataset_id) or {}
        columns = ds.get("columns", []) or []
        try:
            _m = db.list_calculated_metrics(dataset_id, active_only=False)
            has_metrics = bool(_m) if isinstance(_m, (list, tuple)) else False
        except Exception:                                    # noqa: BLE001
            has_metrics = True        # unknown = the stricter (grouped) rule
    # 2026-10-31 the detail popup: every action's targets must be names its SOURCE
    # takes (an API's parameters / filter.<col>; a dataset's columns / where.<key>) --
    # listed only from a source the SAVING user may call / read (else one plain problem)
    from api.canvas_actions_api import action_targets_resolver
    problems = canvas_problems(canvas, dataset_columns=columns,
                               report_column_ids=list(column_ids or []),
                               has_metrics=has_metrics, has_dataset=bool(dataset_id),
                               action_targets=action_targets_resolver(db, user))
    if problems:
        raise HTTPException(status_code=422, detail={
            "error": "canvas_problems",
            "message": "The report cannot be saved: " + " ".join(p["message"] for p in problems),
            "problems": problems,
        })


def _validate_chart_config(layout_config: Optional[dict], dataset_id: Optional[int],
                           db, *, has_drill_hierarchy: bool = False) -> None:
    """Validate chart_config within layout_config.  Raises HTTPException(400).

    Column existence/type checks run only when the report has a resolvable
    dataset (raw_sql / PV / FV reports have no semantic columns — the viewer
    resolves ids defensively and simply shows no chart when they miss).
    """
    if not layout_config:
        return
    raw = layout_config.get("chart_config")
    if raw is None:
        return
    if not isinstance(raw, dict):
        raise HTTPException(400, "chart_config must be an object")

    try:
        cc = ChartViewConfig(**raw)
    except Exception as exc:
        raise HTTPException(400, f"Invalid chart_config: {exc}")

    if cc.chart_type not in VALID_CHART_TYPES:
        raise HTTPException(400, f"Invalid chart_type '{cc.chart_type}'. "
                            f"Must be one of: {', '.join(sorted(VALID_CHART_TYPES))}")
    # 'both' (2026-09-25): the report opens dashboard-style, chart above table
    if cc.default_view not in (None, "table", "chart", "both"):
        raise HTTPException(400, "chart_config.default_view must be 'table', 'chart' or 'both'")
    if not cc.measure_col_ids:
        raise HTTPException(400, "chart_config requires at least one measure_col_id")
    if cc.chart_type != "kpi" and cc.dimension_col_id is None \
            and not has_drill_hierarchy:
        raise HTTPException(400, "chart_config requires dimension_col_id "
                            "(or a drill hierarchy to follow)")
    unknown_lines = set(cc.line_measure_col_ids) - set(cc.measure_col_ids)
    if unknown_lines:
        raise HTTPException(400, f"line_measure_col_ids must be a subset of "
                            f"measure_col_ids (unknown: {sorted(unknown_lines)})")

    if not dataset_id:
        return   # no semantic columns to check against (raw_sql / PV / FV)
    ds = db.get_dataset_full(dataset_id)
    if not ds:
        return   # dataset unresolvable — viewer resolution fails safe
    col_map = {c["id"]: c for c in ds.get("columns", [])}

    for cid in [c for c in (cc.dimension_col_id, cc.split_col_id) if c is not None]:
        col = col_map.get(cid)
        if not col:
            raise HTTPException(400, f"chart_config column ID {cid} not found in dataset {dataset_id}")
        if col.get("column_type") not in ("dimension", "detail"):
            raise HTTPException(400, f"Column '{col.get('physical_name')}' is a "
                                f"{col.get('column_type')}, not a dimension — "
                                "cannot use as a chart category/split")
    for cid in cc.measure_col_ids + (
            [cc.kpi_comparison_col_id] if cc.kpi_comparison_col_id is not None else []):
        col = col_map.get(cid)
        if not col:
            raise HTTPException(400, f"chart_config column ID {cid} not found in dataset {dataset_id}")
        if col.get("column_type") not in ("measure", "kpi"):
            raise HTTPException(400, f"Column '{col.get('physical_name')}' is a "
                                f"{col.get('column_type')}, not a measure — "
                                "cannot plot it as a chart measure")


# ── Report CRUD ──────────────────────────────────────────────────────────────

@router.get("/api/business-reports/limits")
async def report_limits(user: dict = Depends(require_capability("reports.view"))):
    """The row limits a person meets in a report, in one place (2026-10-24):
    the builder says "All rows (this server shows at most N)" and the viewer
    says how to get every row.  Read-only, any signed-in user -- these are
    the deployment's numbers, no data.  0 = every row."""
    from core import config as _c
    br = _c.business_reports
    return {"default_row_limit": br.default_row_limit, "csv_row_limit": br.csv_row_limit,
            "excel_row_limit": br.excel_row_limit, "pdf_row_limit": br.pdf_row_limit,
            "page_size": br.page_size, "max_page_size": br.max_page_size}


@router.get("/api/business-reports")
async def list_reports(
    owner: Optional[str] = Query(None),
    dataset_id: Optional[int] = Query(None),
    published_only: bool = Query(False),
    limit: Optional[int] = Query(None, description=(
        "Page size (1-500, clamped). Providing it switches the response to "
        "the paginated envelope {items, next_cursor, has_more, limit} with "
        "SLIM list-projection items. Omit for the legacy full array.")),
    cursor: Optional[str] = Query(None, description=(
        "Opaque keyset cursor from a previous page's next_cursor.")),
    q: Optional[str] = Query(None, description=(
        "Server-side search over name/description/owner (paginated mode).")),
    include_samples: bool = Query(False, description=(
        "Include reports flagged is_sample. Default FALSE: seeded demos and "
        "probe reports are hidden so they do not bury the real ones. The "
        "list UI's 'Show samples' toggle sets this.")),
    user: dict = Depends(require_capability("reports.view")),
):
    """List business reports. Non-admins see own + published reports.

    2026-08-09 (metadata-scale audit finding 1) — PAGINATION.  Two modes:

    * ``limit``/``cursor``/``q`` provided → keyset-paginated envelope with
      slim ``to_summary_dict()`` items, visibility applied INSIDE the SQL
      query via the ``list_visible_business_reports_page`` chokepoint (page
      honesty: a run of role_whitelist-hidden rows can never silently
      shrink a page).  This is what the reports list UI uses.

    * BACKWARDS-COMPATIBILITY CONTRACT (stated loudly): an unparameterised
      call keeps returning the FULL array with full ``to_dict()`` payloads,
      exactly as before.  Existing consumers (reports_compat layer, scripts,
      pre-upgrade UI bundles) pass no pagination params; silently truncating
      their result would be a silent data change — the house rule says a cap
      must throttle, never silently drop.  Every row in that array is one
      the caller is entitled to open, so it is a payload-SIZE concern, not a
      disclosure; the shipped UI now always paginates, and remaining legacy
      callers migrate by adding ``limit``.
    """
    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    # Tests (and any internal caller) invoke this route FUNCTION directly,
    # where unpassed params keep their ``Query(...)`` sentinel defaults
    # instead of the declared values — normalise them so "param not given"
    # means the same thing via HTTP and via direct call.
    from fastapi.params import Query as _QP
    limit = limit.default if isinstance(limit, _QP) else limit
    cursor = cursor.default if isinstance(cursor, _QP) else cursor
    q = q.default if isinstance(q, _QP) else q
    owner = owner.default if isinstance(owner, _QP) else owner
    dataset_id = dataset_id.default if isinstance(dataset_id, _QP) else dataset_id
    published_only = (published_only.default
                      if isinstance(published_only, _QP) else published_only)

    # ── Paginated mode ──────────────────────────────────────────────────
    if limit is not None or cursor is not None or q is not None:
        from core.reports.authorization import list_visible_business_reports_page
        try:
            return await _adb(
                list_visible_business_reports_page, db, user,
                limit=int(limit) if limit is not None else 100,
                cursor=cursor, owner=owner, dataset_id=dataset_id,
                published_only=published_only, q=q,
                include_samples=include_samples)
        except ValueError as exc:
            # Malformed cursor — client error, never a 500.
            raise HTTPException(400, str(exc))

    # ── Legacy mode (no pagination params) — unchanged behaviour ───────
    if published_only:
        # 2026-08-09: this branch used to return EVERY published report with
        # no gate at all — the same disclosure as catalog finding 7, reached
        # through a different query param, and it short-circuited BEFORE the
        # admin check so non-admins hit it too.  A published report with a
        # non-empty role_whitelist is NOT visible to everyone; route
        # non-admins through the same chokepoint and keep only published rows
        # (grants can surface an UNpublished report, which this param excludes
        # by contract).
        if role in ADMIN_TIER_ROLES:
            return await _adb(db.list_business_reports, is_published=True,
                              dataset_id=dataset_id)
        from core.reports.authorization import list_visible_business_reports
        _visible = await _adb(list_visible_business_reports, db, user, dataset_id)
        return [r for r in _visible if r.get("is_published")]

    if role in ADMIN_TIER_ROLES:
        return await _adb(db.list_business_reports, owner=owner, dataset_id=dataset_id)

    # Non-admin: own reports + published (role_whitelist-gated, 2026-08-05
    # audit fix) + Phase 157 explicit grants.  2026-08-09: extracted to ONE
    # chokepoint (core.reports.authorization.list_visible_business_reports)
    # shared with GET /api/report-catalog — the catalog had its own drifted
    # copy that skipped the whitelist gate (audit finding 7).  The caller's
    # groups + grants are now resolved once per REQUEST instead of once per
    # report row.
    from core.reports.authorization import list_visible_business_reports
    return await _adb(list_visible_business_reports, db, user, dataset_id)


def _grants_for_user(db, username: str):
    """Phase 157 helper -- cheap lookup of every grant where
    ``username`` matches.  Scans the table; bounded by grant count
    which is small in practice."""
    from core.db.models import BusinessReportGrant as _G
    try:
        with db.get_session(read_only=True) as session:
            rows = session.query(_G).filter(_G.username == username).all()
            return [r.to_dict() for r in rows]
    except Exception:
        return []


def _grants_for_group(db, group_id: int):
    from core.db.models import BusinessReportGrant as _G
    try:
        with db.get_session(read_only=True) as session:
            rows = session.query(_G).filter(_G.group_id == int(group_id)).all()
            return [r.to_dict() for r in rows]
    except Exception:
        return []


def _refuse_cross_source_raw_sql_at_save(raw_saved_query_id, raw_sql_file_id, db) -> None:
    """Save-time gate (2026-08-05 BR cross-source audit) — refuse a raw_sql
    BR whose referenced source carries a cross-source shape the report
    engines cannot execute, so the user learns at SAVE time, not from a
    half-empty overnight file.

    * ``raw_saved_query_id`` (parquet/data-grid saved query): the parquet
      report engine executes the primary side only.  A saved query with a
      secondary connection / secondary SQL shape is refused — the SAME
      detection ``core.feed.cross_source_preflight`` uses, so feeds and
      reports can never disagree on what "cross-source" means.
    * ``raw_sql_file_id``: a '-- ===SECONDARY===' section is refused (the
      run-time resolver refuses too; this surfaces it at save).  Any OTHER
      probe failure (file missing on NFS from this pod, etc.) is fail-OPEN
      here — the run-time chokepoint still refuses — so a save that would
      work is never blocked by a probe hiccup.

    Raises HTTPException(400) on a definite cross-source shape.
    """
    if raw_saved_query_id:
        try:
            sq = db.get_query(int(raw_saved_query_id))
        except Exception:
            sq = None
        if sq:
            # 2026-09-01 — the parquet report engine reads
            # ``config.files[0]``.  A saved query with NO files is a
            # SQL-mode query pointed at the wrong field, and it saved
            # happily and then died at execute with "list index out of
            # range" — a sanitised 500 with nothing the author could act
            # on, from a report that had reported success. Refuse here,
            # and name the field that does work.
            _qc = sq.get("query_config") or {}
            from core.feed.cross_source_preflight import saved_query_cross_shape
            shape = saved_query_cross_shape(_qc)
            if shape is not None:
                raise HTTPException(400, (
                    f"Saved query {raw_saved_query_id} is cross-source "
                    f"({shape} shape) — the parquet report engine executes "
                    f"the primary side only, so this report would silently "
                    f"emit half the data. Back the report with a "
                    f"cross-source SQL saved query instead, or re-save the "
                    f"query without its secondary side."))
            # 2026-09-01 — checked AFTER the cross-source shape, deliberately.
            # A cross-source saved query also has no files, so testing this
            # first SHADOWED the more specific diagnosis and told the author
            # about the wrong problem. The specific refusal wins; this is the
            # fallback for a plain SQL-mode query in the parquet field, which
            # used to save and then die at execute with "list index out of
            # range" because the engine reads ``config.files[0]``.
            if not (_qc.get("files") or []):
                raise HTTPException(400, (
                    f"Saved query {raw_saved_query_id} has no files — it is "
                    f"a SQL-mode query, and ``raw_saved_query_id`` is the "
                    f"parquet/data-grid field. The report would save and "
                    f"then fail on every run. Use "
                    f"``raw_sql_saved_query_id`` for a SQL saved query, or "
                    f"``raw_sql_file_id`` for a .sql file."))
    if raw_sql_file_id:
        # 2026-08-11 — this used to refuse ANY ``.sql`` file with a
        # ``-- ===SECONDARY===`` section, because business reports had no
        # cross-connection executor.  They have one now
        # (since 2026-10-04 THE cross-source capability,
        # ``core.executors.cross_source_combine``), so a complete cross-connection
        # file SAVES and RUNS.
        #
        # What is still refused is a HALF-configured one: a secondary section
        # with no ``secondary_connection_id`` (nothing to run it against), or a
        # secondary connection with no section (nothing to run).  Either would
        # execute as a primary-side-only report that looks complete — the
        # original defect.  Catching it at save time turns a silent wrong
        # answer into a form error; the run-time resolver enforces the same
        # rule, so this probe stays fail-open on infrastructure trouble (an
        # unmounted NFS share must not block saving an unrelated field).
        try:
            from api.sql_files_api import _split_cross_sql, _get_storage_dir
            rec = db.get_sql_file(int(raw_sql_file_id))
            if rec and rec.get("file_path"):
                nfs_path = _get_storage_dir() / rec["file_path"]
                if nfs_path.exists():
                    _, _sec = _split_cross_sql(nfs_path.read_text(encoding="utf-8"))
                    _sec_conn = rec.get("secondary_connection_id")
                    if _sec is not None and not _sec_conn:
                        raise HTTPException(400, (
                            f"SQL file {raw_sql_file_id} has a "
                            f"'-- ===SECONDARY===' cross-connection section "
                            f"but no secondary connection, so the report "
                            f"would emit only the primary side's rows. Set "
                            f"the file's secondary connection, or remove the "
                            f"secondary section."))
                    if _sec is None and _sec_conn:
                        raise HTTPException(400, (
                            f"SQL file {raw_sql_file_id} names a secondary "
                            f"connection ({_sec_conn}) but has no "
                            f"'-- ===SECONDARY===' section — the report would "
                            f"run the primary side alone while looking "
                            f"cross-connection."))
        except HTTPException:
            raise
        except Exception as _probe_exc:
            logger.debug("[br-save] sql_file cross probe skipped (fail-open, "
                         "run-time gate still applies): %s", _probe_exc)


@router.post("/api/business-reports")
async def create_report(body: ReportCreate, user: dict = Depends(require_capability("reports.create"))):
    """Create a new business report."""
    db = _require_db()
    from core import config
    username = (user or {}).get("username", "admin")

    # Quota check
    existing = await _adb(db.list_business_reports, owner=username)
    max_reports = config.business_reports.max_reports_per_user
    if len(existing) >= max_reports:
        raise HTTPException(status_code=400,
                            detail=f"Report quota exceeded ({max_reports} max per user)")

    # F-P3A-15 (2026-08-23): a non-admin may only assign the report to a
    # group THEY belong to — the R6 rule the reports and datasets siblings
    # already enforce (one implementation, reused).
    if body.owner_group_id:
        from api.reports_api import _assert_owner_group_membership_rpt
        await _adb(_assert_owner_group_membership_rpt, user, body.owner_group_id)

    # Phase 111: raw_sql reports don't require a dataset — default to 0 sentinel
    if body.data_source_type == "raw_sql":
        # Phase 131 deep-dive #13: accept raw_sql_file_id as a third source.
        if not (body.raw_saved_query_id or body.raw_sql_saved_query_id or body.raw_sql_file_id):
            raise HTTPException(400, "raw_sql report must specify raw_saved_query_id, raw_sql_saved_query_id, or raw_sql_file_id")
        # 2026-08-05 BR cross-source audit — refuse unexecutable cross shapes
        # at save time (run-time chokepoints refuse too; this is the red
        # message at config time, same posture as the feed preflight).
        await _adb(_refuse_cross_source_raw_sql_at_save,
                   body.raw_saved_query_id, body.raw_sql_file_id, db)
        if not body.dataset_id:
            body.dataset_id = 0  # sentinel — raw_sql reports use saved queries, not datasets
    elif body.data_source_type in ("published_view", "federation_view"):
        # PV/FV reports don't require a dataset — default to 0 sentinel
        if not body.dataset_id:
            body.dataset_id = 0
    else:
        # Validate dataset exists (only for standard dataset types)
        if not body.dataset_id:
            raise HTTPException(status_code=400, detail="dataset_id is required for dataset-based reports")
        ds = await _adb(db.get_dataset, body.dataset_id)
        if not ds:
            raise HTTPException(status_code=404, detail=f"Dataset {body.dataset_id} not found")

    # Validate section/calc limits
    _cfg = config.business_reports
    if len(body.section_definitions) > _cfg.max_sections_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_sections_per_report} sections per report")
    if len(body.running_calculations) > _cfg.max_running_calcs_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_running_calcs_per_report} running calculations per report")

    # Phase 106: validate pivot config if present
    if body.layout_config and body.layout_config.get("report_type") == "pivot":
        await _adb(_validate_pivot_config, body.layout_config, body.dataset_id, db)

    # Chart view (2026-08-09): fail loudly at authoring, not in the viewer
    await _adb(_validate_chart_config, body.layout_config, body.dataset_id, db,
                           has_drill_hierarchy=bool(body.drill_hierarchy_id))
    await _adb(_validate_drill_hierarchy, body.drill_hierarchy_id, body.dataset_id, db)
    await _adb(_validate_report_selections, body.dataset_id, body.condition_ids,
                                body.layout_config, db)
    # 2026-10-03: every column id names a column of THIS dataset, and no
    # filter row is saved without its value (422 naming the column).
    await _adb(_refuse_invisible_datasets, db, user, body.dataset_id, body.merged_dataset_id)
    await _adb(_validate_report_column_refs,
        dataset_id=body.dataset_id, merged_dataset_id=body.merged_dataset_id,
        data_source_type=body.data_source_type, column_ids=body.column_ids,
        filter_specs=body.filter_specs,
        section_definitions=body.section_definitions,
        slicer_column_ids=body.slicer_column_ids, order_by=body.order_by,
        db=db)
    # The report canvas (2026-10-26): every tile checked on save -- AFTER the
    # dataset visibility gate and the column-reference check, so its messages
    # (which name columns) are only ever about a dataset the caller may see
    await _adb(_validate_canvas, body.layout_config, body.dataset_id, body.column_ids, db, user=user)
    await _adb(_refuse_unrunnable_union, db,
               dataset_id=body.dataset_id, merged_dataset_id=body.merged_dataset_id,
               merge_config=body.merge_config, column_ids=body.column_ids,
               filter_specs=body.filter_specs, condition_ids=body.condition_ids,
               layout_config=body.layout_config, metric_ids=body.metric_ids)

    # GAP-1 (2026-08-30): validate + fold the calculated-metric selection
    # into layout_config (the column_ids-equivalent store — see
    # ReportCreate.metric_ids).  business_reports has no metric_ids column,
    # so the plain kwarg would TypeError inside create_business_report.
    _metric_sel = list(body.metric_ids or [])
    if _metric_sel:
        _metric_sel = await _adb(
            _validate_metric_selection, db, _metric_sel,
            dataset_id=body.dataset_id,
            data_source_type=body.data_source_type,
            layout_config=body.layout_config,
            merged_dataset_id=body.merged_dataset_id,
            merge_config=body.merge_config)

    data = body.model_dump(exclude_none=True)
    data.pop("metric_ids", None)
    if _metric_sel:
        _lc = dict(data.get("layout_config") or {})
        _lc["metric_ids"] = _metric_sel
        data["layout_config"] = _lc
    data["owner"] = username
    report = await _adb(db.create_business_report, **data)
    logger.info("Created business report '%s' (id=%s) by user '%s'", body.name, report["id"], username)

    # Phase 114-K: log creation
    try:
        await _adb(db.create_report_change_log, 
            report_id=report["id"], username=username,
            action="created", changes=[{"field": "name", "old": None, "new": body.name}],
        )
    except Exception as e:
        logger.warning("Failed to log report creation for report %s: %s", report.get("id"), e)

    return report


# ── What is running right now (static path — before {report_id}) ─────────────

@router.get("/api/business-reports/running")
async def list_my_running_reports(
    limit: int = Query(20, ge=1, le=100),
    user: dict = Depends(require_capability("reports.view")),
):
    """The caller's in-flight report runs.

    2026-08-31.  A notification says a report FINISHED; nothing said what was
    still going.  After a long run is detached (the viewer stops watching
    after ten minutes and leaves the job alone), the user had no way to see
    that it was still alive — only silence until the notification arrived.

    SCOPED TO THE CALLER, always.  A job row carries the report id, its name
    and who started it, so an unscoped list would tell anyone what everyone
    else is running.  There is no ``?all=true`` escape hatch here even for
    admins: a system-wide view is a different, admin-gated feature, and
    building the hatch first is how these lists come to leak.  The DB filter
    is the same ``created_by`` parameter ``list_br_execution_history``
    already uses, so the two agree on what scoping means.

    Names are resolved best-effort — a job whose report was deleted mid-run
    still appears, because "something of yours is running" is the fact the
    caller needs, and dropping the row would make it vanish silently.
    """
    db = _require_db()
    username = (user or {}).get("username") or ""
    if not username:
        # No principal, no jobs — never fall back to "everyone's".
        return {"items": [], "count": 0}

    rows = await _adb(db.list_br_async_jobs, None, "running", limit, username)
    items = []
    for r in (rows or []):
        rid = r.get("report_id")
        name = ""
        try:
            rep = await _adb(db.get_business_report, rid) if rid else None
            name = (rep or {}).get("name") or ""
        except Exception:
            name = ""
        items.append({
            "execution_id": r.get("id") or r.get("execution_id"),
            "report_id": rid,
            "report_name": name or f"Report {rid}",
            "progress_pct": r.get("progress_pct") or 0,
            "started_at": r.get("created_at"),
        })
    return {"items": items, "count": len(items)}


# ── Templates (static paths — must be before {report_id}) ────────────────────

@router.get("/api/business-reports/templates")
async def list_templates(
    category: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(require_capability("reports.view")),
):
    """List certified business report templates, optionally filtered by category."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.template_gallery_enabled:
        raise HTTPException(status_code=400, detail="Template gallery is disabled")
    return await _adb(db.list_certified_templates, category=category, limit=limit)


@router.get("/api/business-reports/template-categories")
async def list_categories(user: dict = Depends(require_capability("reports.view"))):
    """List all template categories that have at least one certified report."""
    db = _require_db()
    return {"categories": await _adb(db.list_template_categories)}


@router.get("/api/business-reports/by-slug/{slug}")
async def get_report_by_slug(slug: str, user: dict = Depends(require_capability("reports.view"))):
    """The report behind a browser URL (/finance-reports/<slug>) -- the ONE
    way the UI resolves a slug; the payload is exactly GET /{id}'s.

    2026-09-20.  The REST API keeps numeric ids everywhere else (embed
    tokens, share links, published views and external consumers hold them).
    A purely numeric token is the documented fallback for a legacy row the
    backfill could not slug.
    """
    db = _require_db()
    report = await _adb(db.get_business_report_by_slug, slug)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return await get_report(report["id"], user)


@router.get("/api/business-reports/by-legacy-id/{legacy_id}")
async def get_report_by_legacy_id(legacy_id: int, user: dict = Depends(require_capability("reports.view"))):
    """The finance report a retired parametric report was migrated into
    (FB-60, 2026-09-26) -- so an old ``/reports/<id>`` bookmark opens the
    report it names instead of dropping the user on a list.  The payload is
    exactly GET /{id}'s, with the same view gate; 404 when that parametric
    report was never migrated (``migrate_reports.py --execute`` not yet run).
    """
    db = _require_db()
    report = await _adb(db.get_business_report_by_legacy_id, legacy_id)
    if not report:
        raise HTTPException(
            status_code=404,
            detail=f"No finance report was migrated from report {legacy_id}")
    return await get_report(report["id"], user)


@router.get("/api/business-reports/{report_id}")
async def get_report(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """Get report definition with its parameters."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    # Phase 131 deep-dive #10: replaced 3 duplicated access checks with
    # the shared core.entitlements.can_view helper (DRY).  Now honors
    # owner_group_id (group-based access) in addition to is_published /
    # owner / admin-tier semantic.
    if not _br_can_view(report, user):
        raise HTTPException(status_code=403, detail="Access denied")

    report["parameters"] = await _adb(_enrich_source_parameters,
                                      await _adb(db.list_report_parameters, report_id), db, report,
                                      with_sql=bool(_br_can_edit(report, user)))
    # 2026-11-01 -- an older report's dropdowns get their lists on an AUTHOR's
    # action (opening it in the editor), never on a viewer's read (security review)
    if _br_can_edit(report, user):
        _schedule_param_lists(report, report["parameters"], user)
    # 2026-11-01 -- default RULES resolved for THIS viewer (core/reports/param_defaults.py):
    # the latest value with data, the viewer's entitled value, the viewer's last pick
    try:
        _eff = await _rule_defaults(db, report, report["parameters"], user)
        for _p in report["parameters"]:
            if isinstance(_p, dict) and _p.get("name") in _eff:
                _p["effective_default"] = _eff[_p["name"]].get("value")
                _p["default_words"] = _eff[_p["name"]].get("words")
    except Exception as _exc:                                 # noqa: BLE001
        logger.info("Report %s: default rules not resolved: %s", report_id, _exc)

    # Publish lifecycle (2026-08-17) — ADDITIVE metadata: the current
    # published version (what consumers execute) and whether the draft has
    # drifted from it.  Fail-open: metadata decoration must never break the
    # detail read.  Computed from the DRAFT deliberately — the flag tells an
    # editor (and honestly, a consumer) that draft ≠ published.
    try:
        from core.reports.versions import (
            definitions_equal, snapshot_definition, version_meta,
        )
        cur = await _adb(db.get_current_business_report_version, report_id)
        if cur:
            report["current_version"] = version_meta(cur)
            report["current_version"]["notes"] = cur.get("notes")
            report["has_unpublished_changes"] = not definitions_equal(
                cur, snapshot_definition(report), report["parameters"])
    except Exception as _ver_exc:
        logger.debug("version metadata decoration skipped (fail-open): %s",
                     _ver_exc)

    # F-P3A-08 (2026-08-23): a CONSUMER's detail read must describe the
    # definition their /execute will RUN — the published snapshot — or the
    # viewer prompts for draft parameters and executes published ones (a
    # published-required param deleted in the draft became an unfillable
    # 400).  Same fork, same chokepoint as /execute; editors keep the draft
    # (their edits are what they need to see).  Archived reports stay
    # readable — metadata is an audit surface, only execution 410s.
    eff, _served = report, None
    try:
        from core.reports.versions import (
            ReportArchivedError, resolve_execution_report as _resolve_v,
        )
        try:
            eff, _served = await _adb(_resolve_v, db, report, user)
        except ReportArchivedError:
            eff, _served = report, None
    except Exception as _fork_exc:
        # Fail-open is confined to RESOLUTION (the versions chokepoint's own
        # documented posture) — the overlay below runs OUTSIDE this handler
        # so a programming error there raises instead of silently serving
        # drafts to consumers forever.
        logger.debug("consumer version fork skipped (draft served, "
                     "fail-open): %s", _fork_exc)
        eff, _served = report, None
    if _served is not None:
        eff["parameters"] = await _adb(
            _report_parameters_for_execution, eff, db, report_id)
        eff.pop("_version_parameters", None)
        eff.pop("_served_version_no", None)
        report = eff
    # GAP-1 (2026-08-30): surface the calculated-metric selection top-level
    # (mirror of column_ids) — AFTER the consumer/version fork so a consumer
    # sees the selection of the definition their /execute will run.
    report["metric_ids"] = _report_metric_ids(report)
    return report


@router.put("/api/business-reports/{report_id}")
async def update_report(report_id: int, body: ReportUpdate, user: dict = Depends(require_capability("reports.edit"))):
    """Update report definition. Only owner or admin can update."""
    db = _require_db()
    # 2026-08-05: this assignment had been dropped in a refactor —
    # _track_report_change below referenced an undefined ``username``
    # (NameError → 500 AFTER the update was persisted).
    username = (user or {}).get("username", "")
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    # Phase 157 -- editor-level check (owner / admin / explicit editor
    # grant).  Replaces the legacy owner-or-admin gate with the
    # chokepoint so explicit editor grants take effect.
    if not _br_can_edit(existing, user):
        raise HTTPException(
            status_code=403,
            detail="Only the report owner, admin, or a user with editor "
                   "grant can update this report",
        )

    from core import config
    _cfg = config.business_reports
    # F-P3A-07 (2026-08-23): ``exclude_none=True`` silently DISCARDED every
    # explicit-null clear — the F-009/F-031/F-P2A-03 undeclared/dropped-field
    # class.  Live consequences: the builder's source-type switch left the
    # old ``raw_saved_query_id`` set (and the parquet id has execution
    # PRECEDENCE, so the report kept running the OLD source while the toast
    # claimed success); ``owner_group_id: null`` — documented in the builder
    # as "null clears it" — was a silent no-op, i.e. group-ownership
    # REVOCATION did nothing.  ``exclude_unset`` applies exactly the fields
    # the caller sent: explicit null CLEARS a clearable field, an omitted
    # field stays.  Fields that cannot be null (DB non-nullable / semantic
    # core) are refused loudly, never dropped.
    updates = body.model_dump(exclude_unset=True)
    _expected = updates.pop("expected_updated_at", None)
    if _expected is not None:
        _stored = existing.get("updated_at")
        _stored_s = _stored.isoformat() if hasattr(_stored, "isoformat") else (str(_stored) if _stored else "")
        if _norm_ts(_stored_s) != _norm_ts(str(_expected)):
            raise HTTPException(status_code=409, detail={
                "error": "report_changed_since_loaded",
                "message": ("Someone saved this report after you opened it"
                            + (f" (saved {_stored_s})" if _stored_s else "")
                            + ". Your changes were not saved. Reload the report to see "
                              "theirs, then make your changes again."),
                "updated_at": _stored_s,
            })
    _NON_CLEARABLE = ("name", "description", "column_ids", "filter_specs",
                      "condition_ids", "order_by",
                      "section_definitions", "running_calculations",
                      "slicer_column_ids", "data_source_type",
                      # NOT NULLable on the model; update_business_report
                      # setattr's whatever it receives, so a null here would
                      # surface as an IntegrityError 500 at flush().
                      "dataset_id")
    _nulled = sorted(k for k in _NON_CLEARABLE
                     if k in updates and updates[k] is None)
    if _nulled:
        raise HTTPException(
            status_code=400,
            detail=f"Field(s) cannot be cleared to null: {', '.join(_nulled)}")
    if "section_definitions" in updates and len(updates["section_definitions"]) > _cfg.max_sections_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_sections_per_report} sections per report")
    if "running_calculations" in updates and len(updates["running_calculations"]) > _cfg.max_running_calcs_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_running_calcs_per_report} running calculations per report")

    # 2026-08-25 — a CHANGED dataset must exist, the same check create makes.
    # Without it a typo'd id is written to a NOT NULL foreign-ish column and
    # every subsequent open of the report fails somewhere further downstream,
    # far from the edit that caused it.
    if ("dataset_id" in updates
            and updates["dataset_id"] != existing.get("dataset_id")):
        # ``db`` (from _require_db() above), not the module-level _db_manager:
        # that global can be None before init, while _require_db has already
        # raised if the database is unavailable.
        _new_ds = await _adb(db.get_dataset, int(updates["dataset_id"]))
        if not _new_ds:
            raise HTTPException(
                status_code=400,
                detail=f"Dataset {updates['dataset_id']} not found — the "
                       f"report's dataset was not changed.")

    # GAP-1 (2026-08-30): calculated-metric selection.  Folded into
    # layout_config BEFORE the pivot/chart validations below so they judge
    # the layout_config that will actually be stored.
    if "metric_ids" in updates:
        _metric_sel = updates.pop("metric_ids") or []   # null and [] both clear
        _eff_lc = dict(updates.get("layout_config")
                       or existing.get("layout_config") or {})
        if _metric_sel:
            _metric_sel = await _adb(
                _validate_metric_selection, db, _metric_sel,
                dataset_id=updates.get("dataset_id", existing.get("dataset_id")),
                data_source_type=updates.get(
                    "data_source_type", existing.get("data_source_type")),
                layout_config=_eff_lc,
                merged_dataset_id=updates.get(
                    "merged_dataset_id", existing.get("merged_dataset_id")),
                merge_config=updates.get(
                    "merge_config", existing.get("merge_config")))
            _eff_lc["metric_ids"] = _metric_sel
        else:
            _eff_lc.pop("metric_ids", None)
        updates["layout_config"] = _eff_lc
    elif (isinstance(updates.get("layout_config"), dict)
          and "metric_ids" not in updates["layout_config"]):
        # A layout-only update (style edit, column widths) must not silently
        # clear a stored metric selection — layout_config is replaced
        # WHOLESALE by the ORM, so carry the selection forward unless the
        # caller cleared it explicitly (metric_ids field) or the update
        # turns the report into a pivot (where metrics do not apply).
        _prev_sel = _report_metric_ids(existing)
        if _prev_sel and updates["layout_config"].get("report_type") != "pivot":
            updates["layout_config"] = {**updates["layout_config"],
                                        "metric_ids": _prev_sel}

    # F-P3A-15: assigning the report to a group requires MEMBERSHIP for
    # non-admins — the same R6 rule the reports and datasets siblings
    # enforce (reused, never re-implemented).
    if updates.get("owner_group_id") and updates["owner_group_id"] != existing.get("owner_group_id"):
        from api.reports_api import _assert_owner_group_membership_rpt
        await _adb(_assert_owner_group_membership_rpt, user, updates["owner_group_id"])

    # Phase 106: validate pivot config on update
    lc = updates.get("layout_config")
    if lc and lc.get("report_type") == "pivot":
        ds_id = existing.get("dataset_id")
        await _adb(_validate_pivot_config, lc, ds_id, db)

    # Chart view (2026-08-09): same save-time gate as create.  The drill
    # hierarchy may arrive in this update or already live on the report.
    if lc:
        _has_dh = bool(updates.get("drill_hierarchy_id",
                                   existing.get("drill_hierarchy_id")))
        await _adb(_validate_chart_config, lc, existing.get("dataset_id"), db,
                               has_drill_hierarchy=_has_dh)

    # 2026-09-01 — the SAME gate as create.  Validating on create and not on
    # update is the sibling divergence this codebase produces over and over:
    # the author saves a valid report, later repoints the drill at a
    # hierarchy that has since been deleted, and the drill silently stops
    # working with no error at either end.  Checked whenever the update
    # touches it, whether or not layout_config came along.
    if "drill_hierarchy_id" in updates:
        await _adb(_validate_drill_hierarchy, updates.get("drill_hierarchy_id"),
                                  existing.get("dataset_id"), db)
    if "condition_ids" in updates or lc:
        await _adb(_validate_report_selections, existing.get("dataset_id"),
            updates.get("condition_ids", existing.get("condition_ids")),
            lc if lc else existing.get("layout_config"), db)

    # 2026-10-03: the SAME column-reference + unfilled-filter gate as create,
    # judged on the report as it will be STORED (an update that changes the
    # dataset is checked against the NEW dataset), whenever the update
    # touches any field the gate reads.
    _ref_fields = ("dataset_id", "merged_dataset_id", "data_source_type",
                   "column_ids", "filter_specs", "section_definitions",
                   "slicer_column_ids", "order_by")
    if "dataset_id" in updates or "merged_dataset_id" in updates:
        await _adb(_refuse_invisible_datasets, db, user,
                   updates.get("dataset_id") if "dataset_id" in updates else None,
                   updates.get("merged_dataset_id") if "merged_dataset_id" in updates else None)
    if any(f in updates for f in _ref_fields):
        _eff = {f: updates.get(f, existing.get(f)) for f in _ref_fields}
        await _adb(_validate_report_column_refs, db=db, **_eff)
    # The report canvas (2026-10-26): checked against the columns the report
    # will have AFTER this update -- after the visibility gate above, so its
    # messages only ever name columns of a dataset the caller may see
    if lc or "column_ids" in updates or "dataset_id" in updates:
        _lc_eff = lc if lc is not None else (existing.get("layout_config") or {})
        await _adb(_validate_canvas, _lc_eff,
                   updates.get("dataset_id", existing.get("dataset_id")),
                   updates.get("column_ids", existing.get("column_ids")), db, user=user)
    _union_fields = ("dataset_id", "merged_dataset_id", "merge_config", "column_ids",
                     "filter_specs", "condition_ids", "layout_config")
    if any(f in updates for f in _union_fields):
        _u = {f: updates.get(f, existing.get(f)) for f in _union_fields}
        await _adb(_refuse_unrunnable_union, db, **_u)

    # 2026-08-05 BR cross-source audit — same save-time gate as create when
    # the update repoints the raw_sql source at a cross-source object.
    if updates.get("raw_saved_query_id") or updates.get("raw_sql_file_id"):
        await _adb(_refuse_cross_source_raw_sql_at_save,
                   updates.get("raw_saved_query_id"),
                   updates.get("raw_sql_file_id"), db)

    updated = await _adb(db.update_business_report, report_id, **updates)

    # Phase 114-K: track field-level changes
    await _adb(_track_report_change, db, report_id, username, "updated", existing, updates)

    return updated


def _track_report_change(db, report_id: int, username: str, action: str,
                         old_report: dict, updates: dict):
    """Record field-level diffs for auditable change history."""
    try:
        TRACKED_FIELDS = {"name", "description", "column_ids", "filter_specs",
                          "layout_config", "is_published", "section_definitions",
                          "running_calculations", "data_source_type"}
        changes = []
        for field in TRACKED_FIELDS:
            if field not in updates:
                continue
            old_val = old_report.get(field)
            new_val = updates[field]
            # Skip if unchanged
            if old_val == new_val:
                continue
            # Truncate large values for readability
            old_str = str(old_val)[:200] if old_val is not None else None
            new_str = str(new_val)[:200] if new_val is not None else None
            changes.append({"field": field, "old": old_str, "new": new_str})
        if changes:
            db.create_report_change_log(
                report_id=report_id, username=username,
                action=action, changes=changes,
            )
    except Exception as e:
        logger.warning("Failed to log report changes (action=%s, report_id=%s): %s", action, report_id, e)


class ViewerPrefsUpdate(BaseModel):
    """Lightweight viewer preferences (column order, chart view) stored in
    layout_config without a full report update.

    ``chart_config`` (2026-08-09): pass an object to set/replace the saved
    chart view (validated exactly like the create/update path), or
    ``clear_chart_config=true`` to remove it.  Omitting both leaves the
    stored chart untouched.
    """
    column_order: Optional[List[str]] = None
    chart_config: Optional[Dict[str, Any]] = None
    clear_chart_config: Optional[bool] = None


@router.patch("/api/business-reports/{report_id}/viewer-prefs")
async def update_viewer_prefs(report_id: int, body: ViewerPrefsUpdate,
                               user: dict = Depends(require_capability("reports.edit"))):
    """Save lightweight viewer preferences into layout_config without full report update."""
    db = _require_db()
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if existing["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Only the report owner or admin can update preferences")
    lc = dict(existing.get("layout_config") or {})
    if body.column_order is not None:
        lc["column_order"] = body.column_order
    if body.chart_config is not None:
        # Same save-time gate as create/update — a wrong chart_type or a
        # dimension plotted as a measure fails loudly here, not in the viewer.
        await _adb(_validate_chart_config, {"chart_config": body.chart_config}, existing.get("dataset_id"),
            db, has_drill_hierarchy=bool(existing.get("drill_hierarchy_id")))
        lc["chart_config"] = body.chart_config
    if body.clear_chart_config:
        lc.pop("chart_config", None)
    await _adb(db.update_business_report, report_id, layout_config=lc)
    return {"ok": True}


# ── a VIEWER's own layout (2026-11-01; FD-03 / FD-10; core/reports/viewer_layout.py) ──

class ViewerLayoutBody(BaseModel):
    layout: Dict[str, Any]


@router.get("/api/business-reports/{report_id}/my-layout")
async def get_my_layout(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """This person's saved layout of the report's tiles, and whether the report lets viewers rearrange."""
    from core.reports import viewer_layout as vl
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report or not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=404, detail="Report not found")
    lay = await _adb(vl.get_layout, db, report_id, str(user.get("username") or ""))
    return {"allowed": vl.allowed(report), "layout": lay}


@router.put("/api/business-reports/{report_id}/my-layout")
async def put_my_layout(report_id: int, body: ViewerLayoutBody, user: dict = Depends(require_capability("reports.view"))):
    """Keep this person's arrangement (tiles moved / resized, fields picked from the approved
    columns).  Refused in words when the report does not allow it or a field is not approved."""
    from core.reports import viewer_layout as vl
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report or not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=404, detail="Report not found")
    if not vl.allowed(report):
        raise HTTPException(status_code=403, detail="This report's author has not allowed viewers to rearrange it "
                                                    "(Edit report -> Design -> Viewers may rearrange).")
    canvas = (report.get("layout_config") or {}).get("canvas") or {}
    problems = vl.layout_problems(body.layout, canvas)
    if problems:
        raise HTTPException(status_code=422, detail={"error": "layout_problems", "problems": problems,
                                                     "message": "Your layout cannot be kept: " + " ".join(problems)})
    await _adb(vl.save_layout, db, report_id, str(user.get("username") or ""), body.layout)
    return {"ok": True, "layout": body.layout}


@router.delete("/api/business-reports/{report_id}/my-layout")
async def reset_my_layout(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    from core.reports import viewer_layout as vl
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report or not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=404, detail="Report not found")
    gone = await _adb(vl.reset_layout, db, report_id, str(user.get("username") or ""))
    return {"reset": bool(gone)}


@router.delete("/api/business-reports/{report_id}")
async def delete_report(report_id: int,
                        acknowledge_dependents: bool = Query(default=False),
                        user: dict = Depends(require_capability("reports.edit"))):
    """Delete report. Only owner or admin.

    2026-09-27 -- refused (409, naming them) while ACTIVE published views
    are sourced from the report, unless ``acknowledge_dependents=true``
    (audited).  Found on the Docker rig: 90 views pointed at deleted
    reports, 4 of them still ACTIVE -- their API consumers broken and
    nothing on any screen saying so.  An inactive view does not block.
    "Could not check" refuses too (503) -- it is the
    opposite finding from "has none".
    """
    db = _require_db()
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if existing["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Only the report owner or admin can delete")

    # 2026-09-27: "could not check" REFUSES (503) -- the views-over-this-report
    # reader is probed first; a table that cannot be read is the opposite
    # finding from "has none", and the one rule below must never run on a
    # half-readable estate.  2026-10-17 -- then ONE rule for every delete that
    # a published API may rest on (core/published_api/impact.py): the views
    # over this report AND the report's own token API are named with their
    # ids and consumers; acknowledge_dependents=true proceeds and audits
    # (business_report_deleted_with_dependents, each API's id / name / key).
    try:
        await _adb(db.list_published_views_for_report, report_id)
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Could not check which published views serve this report "
                   f"({type(exc).__name__}) -- refusing rather than breaking "
                   f"their API consumers.  Retry.")
    from api.published_api_api import refuse_if_apis_depend_async
    dependents = await refuse_if_apis_depend_async(
        db, "business_report", report_id, acknowledged=acknowledge_dependents, actor=user or {},
        action="business_report_deleted_with_dependents")

    # 2026-10-30 (owner) -- SWITCHED OFF, not erased: parameters and versions
    # stay, share/embed links are revoked; Admin -> Switched off brings it back
    await _adb(db.delete_business_report, report_id)
    logger.info("Switched off business report id=%d by user '%s'", report_id, username)
    return {"detail": "deleted", "switched_off": True}


# what a report needs when it is switched back on (core/reports/switch_on.py)
from core.reports.switch_on import register as _register_switch_on  # noqa: E402
_register_switch_on()


# ── Report Execution ─────────────────────────────────────────────────────────

def _reject_unknown_parameters(params: list, param_values: dict | None,
                               report_id) -> None:
    """400 when ``param_values`` names a parameter the report does not declare.

    2026-09-15 -- LIVE: ``{"parameter_values": {"nosuchparam": "2"}}`` ran
    the report with EVERY row and no warning.  Both parameter consumers
    iterated the DECLARED parameters and read values by name, so a value
    under an undeclared name was never looked at: a typo in a parameter
    name returned the whole table as a 200.  A filter that cannot be
    rendered must refuse, never silently drop -- dropping returns MORE rows.
    The message names the unknown key(s) and lists the valid ones, so the
    caller can fix the request without reading the report definition.
    """
    if not param_values:
        return
    known = [p.get("name") for p in (params or []) if p.get("name")]
    unknown = [k for k in param_values if k not in known]
    if not unknown:
        return
    shown = ", ".join(sorted(str(u)[:60] for u in unknown[:10]))
    valid = ", ".join(known) if known else "(this report declares no parameters)"
    logger.warning("Report %s: refused unknown parameter name(s) %s; valid: %s",
                   report_id, shown, valid)
    raise HTTPException(
        status_code=400,
        detail=f"Unknown parameter(s): {shown}. Valid parameters for this "
               f"report: {valid}.")


def _map_report_params_to_pv(report: dict, param_values: dict, db, report_id: int,
                             strict_parameter_names: bool = True) -> dict:
    """Map resolved report parameter values to Published View {{param}} placeholders.

    Phase 100: PV params use {{name}} substitution. Report params are resolved
    (including @TODAY macros) and mapped by name.

    ``strict_parameter_names`` (2026-09-15): refuse names the report does not
    declare -- see ``_reject_unknown_parameters``.
    """
    from core.reports.param_contract import run_value
    pv_params: dict = {}
    params = _report_parameters_for_execution(report, db, report_id)
    if strict_parameter_names:
        _reject_unknown_parameters(params, param_values, report_id)
    for param in params:
        pname = param["name"]
        raw_val = run_value(param, param_values, params)     # SECURITY 2026-11-01: a hidden one runs with its default
        if raw_val is None:
            continue
        pv_params[pname] = _resolve_param_value(raw_val)
    return pv_params


async def _rule_defaults(db, report: dict, params: list, user: Optional[dict]) -> dict:
    """``{name: {value, words}}`` -- the default RULES (latest value with data, the
    viewer's entitled value, the viewer's last pick) resolved for THIS viewer
    (core/reports/param_defaults.py).  ONE answer for the screen (the detail read)
    and for a run (``_fill_rule_defaults``)."""
    from core.reports.param_defaults import effective_defaults
    _cols_by_id = {}
    try:
        _ds_id = await _adb(_resolve_lov_dataset_id, report, db)
        if _ds_id:
            _cols_by_id = {int(c["id"]): c for c in ((await _adb(db.get_dataset_full, int(_ds_id)) or {}).get("columns") or [])
                           if c.get("id") is not None}
    except Exception:                                     # noqa: BLE001
        _cols_by_id = {}
    # SECURITY (review 2026-11-01): a 'latest with data' list is read for a viewer who may
    # see its connection (param_lists.stored_list_for), under their own entitlement
    from core.reports import param_lists as _pl0
    from core.reports.param_choices import _may_see_connection as _msc0
    _lists = {}
    for _p in params or []:
        if isinstance(_p, dict) and _p.get("default_rule") == "latest_with_data":
            _vl0 = await _pl0.stored_list_for(db, report, _p, user, _msc0)
            if _vl0:
                _lists[str(_p["name"])] = _vl0
    return await _adb(effective_defaults, db, report, params or [], user, _cols_by_id, _lists)


async def _fill_rule_defaults(db, report: dict, param_values: Optional[dict], user: Optional[dict],
                              strict: bool = False, only_rules: Optional[set] = None,
                              _first_fill_deadline: Optional[float] = None) -> dict:
    """The values a RUN uses when the caller sent none for a parameter whose default
    is a RULE (2026-11-02).  The rules were resolved only for the screen (the detail
    read hands ``effective_default`` to the browser, which sends it back), so a run
    with no values -- the API, a schedule, a subscription, a proof -- ran a 'latest
    date with data' report with NO date filter (every date: 1,073,797 rows on the
    rig, a PDF too large to render) and a period anchored on it fell back to TODAY
    (no data: an empty dashboard).  A value the caller sent always wins; a parameter
    not shown keeps its stored default (param_contract.run_value)."""
    from core.reports.param_defaults import DefaultUnresolved
    values = dict(param_values or {})
    unresolved, filling = [], False
    try:
        params = await _adb(_report_parameters_for_execution, report, db, int(report["id"]))
        wanted = [p for p in params if isinstance(p, dict) and str(p.get("default_rule") or "value") != "value"
                  and (only_rules is None or str(p.get("default_rule")) in only_rules)
                  and values.get(str(p["name"])) in (None, "", [], {}) and p.get("default_value") in (None, "")]
        if not wanted:
            return values
        eff = await _rule_defaults(db, report, [p for p in params if only_rules is None or p in wanted
                                                or str(p.get("default_rule") or "value") == "value"], user)
        for p in wanted:
            got = eff.get(str(p["name"])) or {}
            v = got.get("value")
            if v not in (None, "", [], {}):
                values[str(p["name"])] = v
            elif p.get("default_rule") == "latest_with_data" and (strict or await _adb(_has_own_list, db, report, p)):
                # a list EXISTS for it (still being built, or not one this viewer may read):
                # refused.  A parameter that can have no list (its column cannot be traced to
                # one source table) keeps running without the default, as it always did.
                filling = filling or await _adb(_list_first_fill_pending, db, report, p)
                unresolved.append(f"'{p.get('label') or p['name']}' starts at the latest value with data, which could not "
                                  f"be worked out: {got.get('words') or 'no value was found.'}")
    except Exception as exc:                              # noqa: BLE001
        logger.warning("Report %s: default rules not applied to the run: %s", report.get("id"), exc)
        return values
    if unresolved and filling:
        # (release-check 2026-11-02) a report run the moment it was saved: its list is being
        # filled for the FIRST time (about a second) -- wait for it, bounded, never refuse yet
        now = time.monotonic()
        deadline = _first_fill_deadline or now + FIRST_FILL_WAIT_S
        if now < deadline:
            await asyncio.sleep(0.5)
            return await _fill_rule_defaults(db, report, param_values, user, strict=strict,
                                             only_rules=only_rules, _first_fill_deadline=deadline)
    if unresolved:
        # (rig 2026-11-02) a CORRECTNESS gate: run with no value it filtered nothing -- a
        # 'latest business date' report read every date.  Refused, in words.
        raise DefaultUnresolved(" ".join(unresolved) + " Pick a value, or run again in a moment.")
    return values


#: how long a run waits for a parameter list's FIRST fill before it refuses
FIRST_FILL_WAIT_S = 20.0


def _list_first_fill_pending(db, report: dict, param: dict) -> bool:
    """Is the parameter's own list still waiting for its FIRST fill (``never``)?"""
    try:
        from core.reports import param_lists as _pl
        vl = _pl.find(db, int(report["id"]), str(param["name"]))
        return bool(vl) and vl.get("last_status") == "never"
    except Exception:                                     # noqa: BLE001
        return False


def _has_own_list(db, report: dict, param: dict) -> bool:
    """Does the parameter have its own stored list (param_lists.find)?"""
    try:
        from core.reports import param_lists as _pl
        return bool(_pl.find(db, int(report["id"]), str(param["name"])))
    except Exception:                                     # noqa: BLE001
        return True                                       # unknown = refuse (never "no filter" by accident)


#: the default rules a SHARE / EMBED reader is given: the one about the DATA (security review
#: 2026-11-02) -- 'last_picked' / 'entitlement' are a person's own and stay off token surfaces
TOKEN_SAFE_RULES = frozenset({"latest_with_data"})


async def _token_rule_defaults(db, report: dict, param_values: Optional[dict]) -> dict:
    """A SHARE / EMBED / shared-dashboard / token-download run (2026-11-02, the owner: "no
    full reports should be shared, or embedded"): a default RULE applies exactly as on the
    signed-in road, resolved for the report OWNER (the person who chose to share it -- the
    scheduled road resolves the same way), and the viewer's own picks win.  STRICT: a
    'latest with data' default that cannot be worked out is REFUSED in words (pick a date)
    -- a link never runs the report with no date filter."""
    from core.reports.param_defaults import DefaultUnresolved
    from core.scheduler import _resolve_owner_user_ctx
    owner = report.get("owner")
    ctx = {**(await asyncio.to_thread(_resolve_owner_user_ctx, owner) or {}), "username": owner} if owner else None
    try:
        # SECURITY (review 2026-11-02): ONLY the rule about the DATA -- 'last pick' and
        # 'entitlement' are the OWNER's own and are never resolved for a token reader
        return await _fill_rule_defaults(db, report, param_values, ctx, strict=True, only_rules=TOKEN_SAFE_RULES)
    except DefaultUnresolved as exc:
        raise HTTPException(status_code=409, detail=str(exc))


async def _token_effective_defaults(db, report: dict, params: list) -> list:
    """The parameter rows a token page renders, each with its ``effective_default`` (the
    owner-resolved rule value) so the band PRE-SELECTS it -- the latest date with data --
    and the viewer may pick another.  Never fails the page."""
    try:
        from core.scheduler import _resolve_owner_user_ctx
        owner = report.get("owner")
        safe = [p for p in params if isinstance(p, dict) and str(p.get("default_rule") or "value") in TOKEN_SAFE_RULES]
        if not owner or not safe:
            return params
        ctx = {**(await asyncio.to_thread(_resolve_owner_user_ctx, owner) or {}), "username": owner}
        # SECURITY (review 2026-11-02): only 'latest with data' -- never the owner's last pick
        # or entitled value on a page an anonymous reader opens.  The latest date is a fact
        # about the data; the rows a token run reads stay under the token's own row policy.
        eff = await _rule_defaults(db, report, [p for p in params if not isinstance(p, dict)
                                                or str(p.get("default_rule") or "value") in TOKEN_SAFE_RULES | {"value"}], ctx)
        return [{**p, "effective_default": (eff.get(str(p.get("name"))) or {}).get("value")}
                if isinstance(p, dict) and str(p.get("name")) in eff
                and str(p.get("default_rule") or "value") in TOKEN_SAFE_RULES else p for p in params]
    except Exception as exc:                              # noqa: BLE001
        logger.info("Report %s: token page defaults not resolved: %s", report.get("id"), exc)
        return params


async def _fill_rule_defaults_or_409(db, report: dict, param_values: Optional[dict], user: Optional[dict]) -> dict:
    """``_fill_rule_defaults`` for a route: an unresolved default is a 409 with its words."""
    from core.reports.param_defaults import DefaultUnresolved
    try:
        return await _fill_rule_defaults(db, report, param_values, user)
    except DefaultUnresolved as exc:
        raise HTTPException(status_code=409, detail=str(exc))


def _report_parameters_for_execution(report: dict, db, report_id: int) -> list:
    """The parameter definitions THIS execution runs under — one rule.

    Publish lifecycle (2026-08-17): a report dict resolved to a published
    version (core/reports/versions.apply_version) carries the SNAPSHOTTED
    parameter rows in ``_version_parameters`` — a consumer run must use the
    published defaults/LOV bindings, not the author's draft edits.  Draft
    executions (key absent) read the live table exactly as before.
    """
    rows = report.get("_version_parameters") or [] if "_version_parameters" in report else db.list_report_parameters(report_id)
    # 2026-11-01 -- a parameter attached to a TEMPLATE reads its definition from the
    # library (a change there applies to every report on its next read)
    tids = [int(p["template_id"]) for p in rows if isinstance(p, dict) and p.get("template_id")]
    if tids:
        from core.reports.param_contract import apply_template
        try:
            tpl = db.templates_by_id(tids)
        except Exception as exc:                              # noqa: BLE001
            logger.info("templates not read for report %s: %s", report_id, exc)
            tpl = {}
        rows = [apply_template(p, tpl.get(int(p["template_id"]))) if isinstance(p, dict) and p.get("template_id") else p
                for p in rows]
    return rows


def _source_binding(param: dict, pval: Any) -> dict:
    """A parameter's resolved value as the filter dict the engine reads as a
    SOURCE binding (2026-10-29).  A date_range travels as ``between`` with
    ``value`` / ``value2`` (one side may be empty: the query's own bound
    stands); a list as it is (one value renders ``=``, several ``IN``)."""
    from core.source_filters import SOURCE_KEY
    key = str(param["source_column"]).strip().lower()
    if param.get("parameter_type") == "date_range" and isinstance(pval, dict):
        return {SOURCE_KEY: key, "operator": "between",
                "value": pval.get("from") or None, "value2": pval.get("to") or None}
    return {SOURCE_KEY: key, "value": pval}


def _build_source_bindings(report: dict, param_values: dict, db, report_id: int) -> list:
    """The SOURCE bindings of this run (2026-10-29): one per declared parameter
    that carries ``source_column`` AND was given a value (or has a default),
    resolved like every other parameter (macros, defaults).  No value = no
    binding = the query's own literal.  Handed to the engine as its own
    argument (``execute_dataset_query(source_bindings=)``) by every road that
    runs a dataset report: the sync and async routes, the share / embed /
    export / dashboard dispatcher, the headless runner, a published view over
    a report.  Names are validated by ``_build_report_filters`` beside it."""
    from core.reports.param_contract import run_value, targets_of
    out: list = []
    params = _report_parameters_for_execution(report, db, report_id)
    for param in params:
        keys = [str(t.get("source_column") or "").strip().lower() for t in targets_of(param) if t.get("to") == "source"]
        keys = [k for k in keys if k]
        if not keys:
            continue
        # SECURITY (review 2026-11-01): a hidden parameter (or one whose control is not shown)
        # ALWAYS runs with its default and a sent value is ignored -- core/reports/param_contract.run_value
        raw_val = run_value(param, param_values or {}, params)
        if raw_val is None or raw_val == "" or (isinstance(raw_val, list) and not raw_val):
            continue
        pval = _resolve_param_value(_normalize_param_value(param, raw_val))
        for key in keys:
            out.append(_source_binding({**param, "source_column": key}, pval))
    return out


def _build_report_filters(report: dict, param_values: dict, db, report_id: int,
                          extra_filters: list | None = None,
                          strict_parameter_names: bool = True) -> list:
    """Build combined filter list from report default filters + resolved parameter values.

    Phase 81: applies _resolve_param_value() to all parameter values (relative date support).
    Also applies default_value resolution when no value supplied by caller.

    ``strict_parameter_names`` (2026-09-15): a value under a name the report
    does not declare is REFUSED (400), never ignored -- see
    ``_reject_unknown_parameters``.  The one caller that legitimately passes
    another vocabulary (a Published View's own parameters, mapped onto the
    report by other means in api/published_views_api.py) opts out
    explicitly.
    """
    combined_filters = list(report.get("filter_specs") or [])
    # 2026-10-29 (security review of 3a799c243) -- a filter on the dataset's
    # OWN query (``source_column``) is set only through the report's declared
    # parameters (_build_source_bindings).  One arriving in a filter list --
    # extra_filters, an export's ?filters=, a share body, a stored row -- is
    # refused HERE, at the door of every HTTP road, in words; the engine
    # refuses it again as the last layer.
    from core.source_filters import SOURCE_KEY, is_source_binding
    _forged = [f for f in list(combined_filters) + list(extra_filters or []) if is_source_binding(f)]
    if _forged:
        raise HTTPException(
            status_code=422,
            detail=("A filter on the dataset's own query (source_column "
                    f"{', '.join(repr(str(f.get(SOURCE_KEY))) for f in _forged)}) can only be set through "
                    "the report's own parameters -- never through a filter list. Remove it from the "
                    "filters; the report is not run with it."))
    params = _report_parameters_for_execution(report, db, report_id)
    if strict_parameter_names:
        _reject_unknown_parameters(params, param_values, report_id)
    # Validate required parameters before building filters
    missing = []
    for param in params:
        if not param.get("is_required"):
            continue
        pname = param["name"]
        raw_val = param_values.get(pname)
        if raw_val is None and param.get("default_value") not in (None, ""):
            raw_val = param["default_value"]
        if raw_val is None or raw_val == '' or (isinstance(raw_val, list) and not raw_val):
            missing.append(param)
    if missing:
        # AQD-05: name each parameter by the NAME the API accepts (label
        # alongside), and say where the value goes -- the old message named
        # the label, which the unknown-parameter check then refused.
        from core.parameters import describe_parameter
        _named = ", ".join(describe_parameter(p) for p in missing)
        _eg = missing[0].get("name") or "name"
        raise HTTPException(
            status_code=400,
            detail=(f"Required parameter(s) missing: {_named}. Supply them in "
                    f"parameter_values keyed by name, e.g. "
                    f"{{\"parameter_values\": {{\"{_eg}\": ...}}}}."))
    # 2026-11-01 -- the general parameter model: a value that breaks a validation
    # rule is refused in words; one value may reach several result columns.
    # SECURITY (review 2026-11-01): a parameter not shown (hidden, or its 'show
    # when' not met) ALWAYS runs with its default and a sent value is IGNORED --
    # it used to be skipped BEFORE its default was read, so an author's hidden
    # "region = EU" filtered nothing on every road (param_contract.run_value).
    from core.reports.param_contract import result_columns, run_value, shown, validation_problems
    _vproblems: list = []
    for param in params:
        _rv = param_values.get(param["name"])
        if _rv not in (None, "", [], {}) and shown(param, param_values, params):
            _vproblems += validation_problems(param, _normalize_param_value(param, _rv), param_values)
    if _vproblems:
        raise HTTPException(status_code=400, detail=" ".join(_vproblems))
    # (rig 2026-11-01) a business date with a PERIOD anchored on it: the period's date set
    # replaces the anchor's own filter (``= as-of AND IN (month-ends)`` was always empty)
    from core.reports.period import anchors_replaced, compare_widens
    _replaced = anchors_replaced(params, param_values)
    _widening = set(compare_widens(params, param_values).values())
    for param in params:
        pname = param["name"]
        raw_val = run_value(param, param_values, params)
        if pname in _replaced and not param.get("source_column"):
            continue                                 # the anchor only says "as of"; the period filters
        # Skip unset / empty parameters — don't generate a filter for them
        if raw_val is None or raw_val == '' or (isinstance(raw_val, list) and not raw_val):
            continue
        # Resolve relative date macros
        pval = _resolve_param_value(_normalize_param_value(param, raw_val))   # 2026-10-30 one shape per kind
        _rcols = result_columns(param)
        if param["parameter_type"] == "hierarchy" and isinstance(pval, dict):
            # one value per level, top first: a level with a value filters its column
            for _cid in _rcols:
                _lv = pval.get(str(_cid), pval.get(_cid))
                if _lv not in (None, ""):
                    combined_filters.append({"column_id": _cid, "operator": "eq", "value": _lv})
            continue
        if param["parameter_type"] == "number_range" and isinstance(pval, dict) and _rcols:
            for _cid in _rcols:
                if pval.get("from") not in (None, ""):
                    combined_filters.append({"column_id": _cid, "operator": "gte", "value": pval["from"]})
                if pval.get("to") not in (None, ""):
                    combined_filters.append({"column_id": _cid, "operator": "lte", "value": pval["to"]})
            continue
        if param["parameter_type"] == "boolean" and _rcols:
            _bv = pval if isinstance(pval, bool) else str(pval).strip().lower() in ("true", "1", "yes", "y", "on")
            for _cid in _rcols:
                combined_filters.append({"column_id": _cid, "operator": "eq", "value": _bv})
            continue
        if len(_rcols) > 1 and param["parameter_type"] in ("dropdown", "multi_select", "date", "date_range", "text", "numeric"):
            # the same value on every result target
            for _cid in _rcols:
                if isinstance(pval, list):
                    combined_filters.append({"column_id": _cid, "operator": "in", "value": pval})
                elif isinstance(pval, dict):
                    if pval.get("from"):
                        combined_filters.append({"column_id": _cid, "operator": "gte", "value": pval["from"]})
                    if pval.get("to"):
                        combined_filters.append({"column_id": _cid, "operator": "lte", "value": pval["to"]})
                else:
                    combined_filters.append({"column_id": _cid, "operator": "eq", "value": pval})
            continue
        if param.get("source_column") or (not param.get("lov_column_id") and _rcols):
            if not param.get("lov_column_id") and _rcols and not param.get("source_column"):
                param = {**param, "lov_column_id": _rcols[0]}
        if param.get("source_column"):
            # 2026-10-29 -- FILTER AT THE SOURCE: this parameter's value goes
            # INTO the dataset's own WHERE, through _build_source_bindings and
            # the engine's OWN argument -- never through this filter list
            # (security review of 3a799c243: a binding in a filter list is a
            # binding anyone with a link could forge).
            continue
        if not param.get("lov_column_id"):
            # 2026-08-31 -- SAY that this was skipped.  A parameter with no
            # column bound cannot become a filter, so the viewer is prompted
            # for a value (required by default) that then changes nothing.
            # This used to be a bare `continue`: the system logged what it
            # did and never what it declined to do, so an inert parameter
            # was indistinguishable from a working one at every level.
            # The builder now warns the author at authoring time; this line
            # is how an ALREADY-SAVED inert parameter becomes findable.
            logger.warning(
                "Report %s: parameter %r was given a value but is bound to "
                "no column, so it filtered NOTHING. Set its Filter Column in "
                "the report builder.", report_id, pname)
            continue
        if param["parameter_type"] == "multi_select" and isinstance(pval, list):
            combined_filters.append({"column_id": param["lov_column_id"], "operator": "in", "value": pval})
        elif param["parameter_type"] == "cob_compare":
            # (rig 2026-11-01) the comparison never NARROWS the run: under a date range
            # or no date the stored result already holds A and B.  (rig 2026-11-02) with
            # a single business DATE on the same column (``= B``: A read nothing) that
            # date steps aside and the run binds the column IN (A, B)
            # (period.compare_widens); the canvas reads each side through a slicer and a
            # tile that does not compare reads B, the as-of date.
            if pname in _widening:
                from core.reports.period import PeriodRefused, compare_filters
                try:
                    combined_filters.extend(compare_filters(param, pval))
                except PeriodRefused as exc:
                    raise HTTPException(status_code=400, detail=str(exc))
        elif param["parameter_type"] == "period":
            # 2026-11-01 -- core/reports/period.py: a period anchored on the business
            # date it depends on -> gte / lte (or IN for a set of month-ends).
            from core.reports.period import PeriodRefused, period_filters
            try:
                if True:
                    anchor_p = next((x for x in params if x.get("id") == param.get("depends_on_param_id")), None)
                    anchor_raw = run_value(anchor_p, param_values, params) if anchor_p else None
                    anchor_val = _resolve_param_value(_normalize_param_value(anchor_p, anchor_raw)) if anchor_p and anchor_raw not in (None, "") else None
                    combined_filters.extend(period_filters(param, pval, anchor_val, anchor_p, db, report))
            except PeriodRefused as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        elif param["parameter_type"] == "date_range" and isinstance(pval, dict):
            if pval.get("from"):
                combined_filters.append({"column_id": param["lov_column_id"], "operator": "gte", "value": pval["from"]})
            if pval.get("to"):
                combined_filters.append({"column_id": param["lov_column_id"], "operator": "lte", "value": pval["to"]})
        else:
            combined_filters.append({"column_id": param["lov_column_id"], "operator": "eq", "value": pval})
    if extra_filters:
        combined_filters.extend(extra_filters)
    return combined_filters


# ── GAP-1 (2026-08-30): calculated metrics on business reports ──────────────
# CalculatedMetric (core/db/models.py) is a complete semantic-layer feature —
# an aggregate SQL expression with its own format_pattern — and the federation
# engine has resolved ``metric_ids`` since Phase 101, but no BR path ever
# passed them.  The selection is persisted in ``layout_config["metric_ids"]``
# (see ReportCreate.metric_ids for why that is the column_ids-equivalent
# store, not a parallel one) and flows through _run_report_query into
# execute_dataset_query, so metrics run inside the SAME generated SQL as the
# report's columns: the row-security rewrite (_apply_rls_all_connections)
# wraps the whole statement, so a metric aggregates only rows the caller may
# see, and the artifact/limit/truncation contract is untouched because the
# metric is just another SELECT item of the same execution.

def _metric_alias(name: str) -> str:
    """The federation engine's Phase-101 output alias for a calculated
    metric: ``m["name"].lower().replace(" ", "_")`` (federation_engine
    execute_dataset_query step 3b).  Pinned by an end-to-end test that
    EXECUTES the engine and asserts this alias appears in the artifact, so
    drift between the two spellings fails a test rather than silently
    unmapping formats."""
    return str(name or "").lower().replace(" ", "_")


def _report_metric_ids(report: dict) -> list:
    """The stored calculated-metric selection of a report (possibly [])."""
    lc = (report or {}).get("layout_config") or {}
    raw = lc.get("metric_ids")
    if not isinstance(raw, list):
        return []
    out: list = []
    for v in raw:
        try:
            out.append(int(v))
        except (TypeError, ValueError):
            logger.warning("[metrics] ignoring non-integer metric id %r on "
                           "report %s", v, (report or {}).get("id"))
    return out


def _validate_metric_selection(db, metric_ids: list, *, dataset_id,
                               data_source_type, layout_config,
                               merged_dataset_id, merge_config) -> list:
    """Save-time gate for a report's calculated-metric selection.

    Refuses loudly (400) at CONFIG time — the same posture as
    _refuse_cross_source_raw_sql_at_save — instead of letting the engine
    silently drop an unusable id at run time (``if m["id"] in metric_ids``
    matches nothing for a wrong-dataset/inactive/deleted metric, which
    would be a dark no-op behind a 200).  Returns the normalised int list.
    """
    try:
        ids = [int(m) for m in (metric_ids or [])]
    except (TypeError, ValueError):
        raise HTTPException(status_code=400,
                            detail="metric_ids must be a list of integers")
    if not ids:
        return []
    from core.reports.sources import canonical_source_type as _canon_dst
    if _canon_dst(data_source_type) != "saved_query":
        raise HTTPException(
            status_code=400,
            detail="Calculated metrics require a dataset-backed report "
                   "(data_source_type='saved_query') — they are defined on "
                   "a semantic-layer dataset.")
    if not dataset_id:
        raise HTTPException(status_code=400,
                            detail="Calculated metrics require a dataset_id")
    if merged_dataset_id and merge_config:
        raise HTTPException(
            status_code=400,
            detail="Calculated metrics are not supported on merged "
                   "(two-dataset) reports — the merged execution path has "
                   "no metric resolution.")
    if ((layout_config or {}).get("report_type")) == "pivot":
        raise HTTPException(
            status_code=400,
            detail="Calculated metrics are not supported on pivot reports — "
                   "the pivot path builds its own aggregated selection "
                   "(value_fields).")
    # LIFTED 2026-09-03.  This refusal named its own release condition:
    # "the engine's custom-SQL path (_build_from_base_query) has NO
    # is_metric branch — it selects the metric's ALIAS as a bare column
    # and every run dies with a DuckDB binder error".  True when written,
    # and the refusal was the right call then — but it guarded ONE caller
    # while datasets_api hit the same engine gap unguarded, so the
    # capability stayed broken for every custom-SQL dataset rather than
    # merely refused.
    #
    # Both builders now share ONE column->SELECT vocabulary
    # (FederationEngine._column_select_terms), so a metric resolves to its
    # EXPRESSION on the custom-SQL path exactly as it always did on the
    # table path.  Verified by execution, both paths, in
    # tests/test_metric_on_custom_sql_2026_09_03.py.
    seen_aliases: dict = {}
    col_names = {c.get("physical_name")
                 for c in (db.list_dataset_columns(dataset_id) or [])}
    for mid in ids:
        m = db.get_calculated_metric(mid)
        if not m:
            raise HTTPException(status_code=400,
                                detail=f"Calculated metric {mid} not found")
        if int(m.get("dataset_id") or 0) != int(dataset_id):
            raise HTTPException(
                status_code=400,
                detail=f"Calculated metric {mid} ('{m.get('name')}') belongs "
                       f"to dataset {m.get('dataset_id')}, not dataset "
                       f"{dataset_id}")
        if not m.get("is_active", True):
            raise HTTPException(
                status_code=400,
                detail=f"Calculated metric {mid} ('{m.get('name')}') is "
                       f"inactive — the engine would silently skip it")
        alias = _metric_alias(m.get("name", ""))
        if alias in seen_aliases:
            raise HTTPException(
                status_code=400,
                detail=f"Metrics {seen_aliases[alias]} and {mid} both emit "
                       f"output column '{alias}' — pick one")
        if alias in col_names:
            raise HTTPException(
                status_code=400,
                detail=f"Calculated metric '{m.get('name')}' would emit "
                       f"output column '{alias}', which collides with a "
                       f"dataset column of the same name — rename the metric")
        seen_aliases[alias] = mid
    return ids


def _parse_column_names(raw: "str | None") -> "list | None":
    """Parse ``?columns=region,amount`` into column NAMES.

    Names, not ids: a viewer picks the columns they can SEE, and a
    shared link should not carry internal dataset ids that mean
    nothing to the person reading it and change if the dataset is
    rebuilt.  Ids remain the internal vocabulary
    (``override_column_ids`` on the execute API, used by drill-down).

    ``None`` for absent or empty -- an export must never fail because
    a column hint was malformed; it runs the report's stored columns,
    exactly as before the parameter existed.  Direct invocation of a
    route function (tests, tools) passes FastAPI's Query default
    object here, which is also "absent".
    """
    if not raw or not isinstance(raw, str):
        return None
    names = [p.strip() for p in raw.split(",") if p.strip()]
    return names or None


def _validated_column_subset(report: dict, requested,
                             ds_cols: list | None = None) -> "list | None":
    """A runtime column choice, narrowed to what the author published.

    2026-08-31.  A dataset can carry 200+ columns and a report author
    curates a subset into the report; a VIEWER then wants to narrow
    that further for the screen and the file they download.

    The selection may only ever be a SUBSET of ``report["column_ids"]``.
    Accepting arbitrary dataset column ids here would let a viewer pull
    columns the author deliberately left out -- a curation boundary, and
    on a wide dataset frequently a sensitivity one.  Narrowing is a view
    preference; widening is an authorization decision, and this is not
    where authorization decisions are made.

    Returns ``None`` for "no runtime choice" (the stored columns run,
    exactly as before).  Unknown ids are dropped WITH A LOG rather than
    failing the report: a stale bookmark or a column removed from the
    report since the link was shared should still render the columns
    that do exist.  An empty intersection also returns None -- a report
    with no columns is not a narrower report, it is a broken one.
    """
    if not requested:
        return None
    authored = [c for c in (report.get("column_ids") or [])]
    if not authored:
        return None
    allowed = set(authored)
    # A selection may arrive as NAMES (the ?columns= query parameter a
    # viewer's picker sends) or as IDS (override_column_ids, the
    # internal drill-down vocabulary).  Names are resolved against the
    # dataset's columns, case-insensitively, because that is how the
    # person choosing them sees the report.
    by_name = {}
    for c in (ds_cols or []):
        pn = str(c.get("physical_name") or "").strip().lower()
        if pn and c.get("id") is not None:
            by_name[pn] = c["id"]
    asked, unknown = [], []
    for item in requested:
        if isinstance(item, int):
            asked.append(item)
            continue
        key = str(item).strip().lower()
        if key in by_name:
            asked.append(by_name[key])
        else:
            unknown.append(item)
    if unknown:
        # Truncate what is echoed: these names come from a query string,
        # so an oversized or careless value must not flood the log.
        _shown = [str(u)[:60] for u in unknown[:10]]
        logger.warning("[report-columns] report %s: no column named "
                       "%s in this report — ignored%s",
                       report.get("id"), _shown,
                       f" (+{len(unknown) - 10} more)"
                       if len(unknown) > 10 else "")
    if not asked:
        logger.warning("[report-columns] report %s: the column "
                       "selection named nothing this report has — "
                       "running the full report instead",
                       report.get("id"))
        return None
    kept = [c for c in authored if c in set(asked)]   # author order
    dropped = [c for c in asked if c not in allowed]
    if dropped:
        logger.warning("[report-columns] report %s: column(s) %s are "
                       "not part of this report and were ignored",
                       report.get("id"), dropped)
    if not kept:
        logger.warning("[report-columns] report %s: the column "
                       "selection matched none of the report's "
                       "columns — running the full report instead",
                       report.get("id"))
        return None
    return kept


def _run_report_query(fed, report: dict, combined_filters: list, row_limit: int,
                      execution_id: str, role: str,
                      override_column_ids: list | None = None,
                      user_ctx: Optional[Dict[str, Any]] = None,
                      force_refresh: bool = False,
                      source_bindings: list | None = None):
    """Execute federation query for a report (merged or single dataset).

    Phase 81: uses stored merged_dataset_column_ids (not hardcoded []).
    Phase 112: override_column_ids for drill-down level queries.
    Phase 131 deep-dive #13: user_ctx forwarded to FederationEngine so
    row + column policies are enforced.  Was the last engine path where
    secure_sql was silently bypassed.
    """
    col_ids = override_column_ids or report["column_ids"]
    # GAP-1 (2026-08-30): the STORED metric selection rides every execution
    # of this report — the plain run and Phase-112 drill overrides alike (a
    # drill level re-aggregates the metric at that level, which is the
    # metric's meaning).  _derive_artifact_grain's DETAIL proof has been
    # amended to match: it now fails closed whenever the dataset defines any
    # calculated metric, because a metric forces has_aggregation=True.
    metric_ids = _report_metric_ids(report)
    # 2026-08-31: say when a selected metric no longer resolves.  The engine
    # matches ``if m["id"] in metric_ids`` against the dataset's CURRENT
    # metrics, so an id that was valid at save time and has since been
    # deleted, deactivated or moved to another dataset matches nothing and
    # the column simply is not there -- the dark no-op _validate_metric_
    # selection's own docstring warns about, which save-time validation
    # cannot prevent because the deletion happens afterwards.
    #
    # Advisory only: the report still runs (it has every OTHER column the
    # author asked for, and refusing would take a working report away over a
    # column its owner may have deleted deliberately).  The log is what turns
    # a missing column from unexplainable into explainable.
    if metric_ids:
        try:
            # The module-level manager, NOT _require_db(): that delegates to
            # api.deps, whose own manager is wired separately and raises 503
            # when it is not — a raise this diagnostic's own except would then
            # swallow, leaving the check permanently silent and looking fine.
            _mdb = _db_manager
            _missing = []
            for _mid in (metric_ids if _mdb is not None else []):
                _m = _mdb.get_calculated_metric(_mid)
                if not _m:
                    _missing.append(_mid)
                elif (report.get("dataset_id")
                      and _m.get("dataset_id") not in (None, report["dataset_id"])):
                    _missing.append(_mid)
            if _missing:
                logger.warning(
                    "[report-metrics] report %s selects calculated metric(s) "
                    "%s that no longer resolve on dataset %s — those columns "
                    "will be ABSENT from the result",
                    report.get("id"), _missing, report.get("dataset_id"))
        except Exception as _mx:      # never break a run over a diagnostic
            logger.debug("[report-metrics] resolution check skipped: %s", _mx)
    if report.get("merged_dataset_id") and report.get("merge_config"):
        if metric_ids:
            # Save-time validation refuses this combination; this guard
            # covers a definition written before validation existed.  A
            # silent drop here would export a report missing a column the
            # author selected — fail loud instead.
            raise ValueError(
                "This report merges two datasets; calculated metrics are "
                "not supported on merged reports. Remove the metric "
                "selection or the merge.")
        if source_bindings:
            # 2026-10-29 -- a source parameter has no road into a merged or
            # UNION report yet: refuse, never run with the value dropped
            raise ValueError(
                "This report merges two datasets; a parameter that filters at the "
                "source is not supported on merged reports. Remove the parameter or "
                "the merge.")
        mc = report["merge_config"]
        # 2026-10-24 -- a UNION ALL of two datasets (each its own connection),
        # lined up BY NAME, the report's filters pushed into EACH side:
        # core/reports/union_of_datasets.py is the mapping, the engine's ONE
        # union runs it.
        from core.reports.union_of_datasets import is_union, regroup_plan, union_specs
        if is_union(report.get("merged_dataset_id"), mc):
            return fed.execute_union_query(
                datasets=union_specs(fed._db, report, list(col_ids), combined_filters),
                limit=row_limit, on_mismatch="fail", execution_id=execution_id,
                user_role=role, user_ctx=user_ctx,
                reaggregate=regroup_plan(fed._db, int(report["dataset_id"]), list(col_ids)))
        # Phase 81 FIX 1: use actual secondary column IDs instead of []
        secondary_col_ids = report.get("merged_dataset_column_ids") or []
        return fed.execute_merged_query(
            primary_dataset_id=report["dataset_id"],
            secondary_dataset_id=report["merged_dataset_id"],
            primary_column_ids=col_ids,
            secondary_column_ids=secondary_col_ids,
            merge_keys=mc.get("merge_keys", []),
            merge_type=mc.get("merge_type", "inner"),
            primary_filters=combined_filters,
            limit=row_limit,
            primary_condition_ids=report.get("condition_ids"),
            execution_id=execution_id,
            user_role=role,
            user_ctx=user_ctx,
        )
    else:
        return fed.execute_dataset_query(
            dataset_id=report["dataset_id"],
            column_ids=col_ids,
            metric_ids=metric_ids or None,
            filters=combined_filters if combined_filters else None,
            condition_ids=report.get("condition_ids") or None,
            order_by=report.get("order_by") or None,
            limit=row_limit,
            execution_id=execution_id,
            user_role=role,
            user_ctx=user_ctx,
            force_refresh=bool(force_refresh),            # FB-36
            source_bindings=source_bindings or None,      # 2026-10-29
            version_overrides=report.get("_data_version") or None,   # 2026-11-01
        )


def _run_pivot_report_query(fed, report: dict, combined_filters: list, row_limit: int,
                            execution_id: str, role: str,
                            user_ctx: Optional[Dict[str, Any]] = None,
                            force_refresh: bool = False,
                            source_bindings: list | None = None):
    """Execute a pivot report query with per-measure aggregation overrides.

    Builds column_ids from pivot_config (row_field_ids + col_field_ids + value column IDs)
    and passes aggregation overrides so the federation engine generates correct GROUP BY SQL.
    Returns flat grouped result — frontend transforms into crosstab matrix.

    Phase 131 deep-dive #13: threads user_ctx into FederationEngine so pivot
    reports enforce row + column policies too (otherwise pivot was a silent
    RLS bypass).
    """
    pc_raw = (report.get("layout_config") or {}).get("pivot_config", {})
    try:
        pc = PivotConfig(**pc_raw)
    except Exception as exc:
        raise ValueError(f"Invalid pivot_config: {exc}")

    # Build column IDs: row dims + col dims + value measures
    column_ids = list(pc.row_field_ids) + list(pc.col_field_ids) + [vf.column_id for vf in pc.value_fields]

    # Build aggregation overrides: {column_id: "sum"/"avg"/etc.}
    agg_overrides = {vf.column_id: vf.aggregation for vf in pc.value_fields}

    # Order by row dimensions for consistent grouping
    order_by = [{"column_id": cid, "direction": "asc"} for cid in pc.row_field_ids]

    result = fed.execute_dataset_query(
        dataset_id=report["dataset_id"],
        column_ids=column_ids,
        filters=combined_filters if combined_filters else None,
        condition_ids=report.get("condition_ids") or None,
        order_by=order_by,
        limit=row_limit,
        execution_id=execution_id,
        user_role=role,
        agg_overrides=agg_overrides,
        user_ctx=user_ctx,
        force_refresh=bool(force_refresh),                # FB-36
        source_bindings=source_bindings or None,          # 2026-10-29
        version_overrides=report.get("_data_version") or None,       # 2026-11-01
    )
    return result


# ── Phase 111: raw_sql adapter + execution ───────────────────────────────────

def _resolve_sql_file_to_override(sql_file_id: int) -> tuple:
    """Phase 131 deep-dive #13 — read a published .sql file's content
    from NFS and return ``(sql_text, connection_id)``.

    Used when a Business Report is configured with ``raw_sql_file_id``:
    we resolve it at execution time to an inline ``sql_override`` so the
    existing _run_sql_report path executes the file content against the
    SqlFile's bound connection (or the BR's connection_override).

    Raises ValueError on missing file / missing content / unreadable
    NFS path so the report's error UI shows a real cause instead of an
    empty result set.
    """
    rec = _db_manager.get_sql_file(int(sql_file_id))
    if not rec:
        raise ValueError(f"SQL file id={sql_file_id} not found")
    if not rec.get("is_active"):
        raise ValueError(f"SQL file id={sql_file_id} is inactive")

    # Resolve content from NFS path (same logic as sql_files_api.get_sql_file)
    from api.sql_files_api import _get_storage_dir as _sf_storage_dir
    from api.sql_files_api import _split_cross_sql as _sf_split
    storage = _sf_storage_dir()
    nfs_path = storage / rec["file_path"]
    if not nfs_path.exists():
        raise ValueError(
            f"SQL file id={sql_file_id} content missing on NFS: {nfs_path}"
        )
    content = nfs_path.read_text(encoding="utf-8")
    if not content.strip():
        raise ValueError(f"SQL file id={sql_file_id} is empty")

    # Cross-connection SqlFiles split with the ===SECONDARY=== marker.
    #
    # 2026-08-05 -> 2026-08-11.  This branch used to REFUSE: the pre-2026-08-05
    # code silently DROPPED the secondary section and ran the primary side
    # only, so the audit replaced that with a loud error (UNKNOWN = UNSAFE)
    # because no cross-connection executor existed for SqlFile sources.
    #
    # One now exists — THE cross-source capability
    # (``core.executors.cross_source_combine``, 2026-10-04) — built on the SAME
    # pieces the feed path uses (streaming side -> parquet, then
    # ``cross_source_combine`` UNION/JOIN in DuckDB).  So the refusal is
    # retired in favour of EXECUTING the thing, and the invariant the gate
    # protected is enforced where it belongs instead: that module raises
    # rather than ever returning one side, and
    # ``_resolve_sql_file_cross_spec`` below refuses a file whose secondary
    # section has no ``secondary_connection_id`` to run it on.
    #
    # This function keeps returning the PRIMARY side only, because that is its
    # contract and several callers (published views, share tokens) legitimately
    # want just that. Callers that can execute both sides ask for the spec.
    primary_sql, _secondary_sql = _sf_split(content)
    if _secondary_sql is not None and not rec.get("secondary_connection_id"):
        raise ValueError(
            f"SQL file id={sql_file_id} contains a '-- ===SECONDARY===' "
            f"cross-connection section but no secondary_connection_id, so "
            f"there is nothing to run the secondary side against — executing "
            f"it would emit only the primary side's rows. Fix: set the file's "
            f"secondary connection, or remove the secondary section."
        )
    return primary_sql, rec.get("connection_id")


def _resolve_sql_file_cross_spec(sql_file_id: int) -> Optional[dict]:
    """The cross-connection shape of a ``.sql`` file, or ``None``.

    Returns ``{"secondary_connection_id", "secondary_sql", "combine_mode",
    "join_config"}`` when the file has BOTH a ``-- ===SECONDARY===`` section
    and a secondary connection to run it against; ``None`` for an ordinary
    single-connection file.

    Deliberately mirrors the ``feed_configs`` / ``sql_files`` field names so
    the two features read the same way.

    FAIL-CLOSED on a half-configured file: a secondary SECTION with no
    secondary CONNECTION, or a secondary CONNECTION with no section, raises.
    Either shape would otherwise run as a single-side report that looks
    complete — which is the original defect.
    """
    rec = _db_manager.get_sql_file(int(sql_file_id))
    if not rec:
        raise ValueError(f"SQL file id={sql_file_id} not found")

    from api.sql_files_api import _get_storage_dir as _sf_storage_dir
    from api.sql_files_api import _split_cross_sql as _sf_split
    nfs_path = _sf_storage_dir() / rec["file_path"]
    if not nfs_path.exists():
        raise ValueError(
            f"SQL file id={sql_file_id} content missing on NFS: {nfs_path}")
    _primary, secondary_sql = _sf_split(nfs_path.read_text(encoding="utf-8"))
    sec_conn_id = rec.get("secondary_connection_id")

    if secondary_sql is None and not sec_conn_id:
        return None
    if secondary_sql is None:
        raise ValueError(
            f"SQL file id={sql_file_id} names a secondary connection "
            f"({sec_conn_id}) but has no '-- ===SECONDARY===' section — the "
            f"report would run the primary side alone while looking "
            f"cross-connection.")
    if not sec_conn_id:
        raise ValueError(
            f"SQL file id={sql_file_id} has a '-- ===SECONDARY===' section "
            f"but no secondary_connection_id — there is nothing to execute "
            f"the secondary side against.")
    return {
        "secondary_connection_id": int(sec_conn_id),
        "secondary_sql": secondary_sql,
        "combine_mode": (rec.get("combine_mode") or "union"),
        "join_config": rec.get("join_config") or {},
    }


def _resolve_report_row_limit(limit_override, report: dict, _cfg) -> int:
    """Row bound for ONE report execution.  ``0`` means UNLIMITED.

    2026-08-13.  Both call sites did::

        row_limit = limit_override or report.get("row_limit") or default

    and ``a or b or c`` FOLDS 0 INTO THE DEFAULT.  A report whose row_limit
    is 0 -- the spelling that means unlimited everywhere else in this
    product -- is falsy, so it fell through to
    ``business_reports.default_row_limit`` (500,000) and the report was
    silently clipped while reporting success.  56dd9fff recorded exactly
    this trap on the federation side ("``limit or default`` would have
    folded 0 into semantic_layer.default_row_limit=10k -- A CUBE SILENTLY
    REBUILT FROM 10K ROWS AND SERVED AS COMPLETE"); these two call sites
    never got the same treatment, and having the rule in TWO places is why.

    Resolves by PRESENCE, not truthiness, so an explicit 0 survives and only
    a genuinely absent value falls back to the configured default.
    """
    if limit_override is not None:
        val = int(limit_override)
    elif report.get("row_limit") is not None:
        val = int(report.get("row_limit") or 0)
    else:
        val = int(_cfg.business_reports.default_row_limit)
    return max(0, val)          # negatives normalise to 0 == unlimited


def _as_legacy_report(br: dict) -> dict:
    """Convert a raw_sql BusinessReport dict to the shape expected by
    _run_parquet_report() / _run_sql_report() from reports_api.py.

    Phase 131 deep-dive #13: when the BR points at a SqlFile via
    ``raw_sql_file_id``, resolve the .sql content into ``sql_override``
    and the bound connection_id into ``connection_override_id`` (unless
    the BR already specified its own connection override, which wins).
    """
    legacy = {
        # Ownership must survive the adapter: the execution paths fall
        # back to the owner when there is no caller (scheduled runs,
        # deliveries), and without it they resolve nobody, render an
        # empty scope, and deliver ZERO ROWS marked completed.
        "owner": br.get("owner") or br.get("created_by"),
        "id": br["id"],
        "name": br.get("name", ""),
        "saved_query_id": br.get("raw_saved_query_id"),
        "sql_saved_query_id": br.get("raw_sql_saved_query_id"),
        "sql_override": br.get("raw_sql_override"),
        "parameters": br.get("raw_parameters_schema") or [],
        "connection_override_id": br.get("raw_connection_override_id"),
    }
    sql_file_id = br.get("raw_sql_file_id")
    if sql_file_id and not legacy["sql_override"]:
        sql_text, sf_conn_id = _resolve_sql_file_to_override(int(sql_file_id))
        legacy["sql_override"] = sql_text
        if not legacy["connection_override_id"] and sf_conn_id:
            legacy["connection_override_id"] = sf_conn_id
        # No sql_saved_query_id is needed — reports_api._run_sql_report
        # tolerates a missing sql_q when sql_override + connection_
        # override_id are both set (deep-dive #13 hardening).  Audit
        # trail in run logs shows raw_sql_file_id=<n> on the BR row.

        # 2026-08-11 — cross-connection ``.sql`` files EXECUTE now.  The file
        # is the source of truth (it owns the ``-- ===SECONDARY===`` section);
        # the BR's own mirror columns are an OVERRIDE, exactly as
        # ``raw_connection_override_id`` overrides the file's primary
        # connection.  Names mirror ``sql_files`` / ``feed_configs``.
        cross = _resolve_sql_file_cross_spec(int(sql_file_id))
        if cross:
            legacy["secondary_connection_id"] = (
                br.get("secondary_connection_id")
                or cross["secondary_connection_id"])
            legacy["secondary_sql"] = cross["secondary_sql"]
            legacy["combine_mode"] = (
                br.get("combine_mode") or cross["combine_mode"])
            legacy["join_config"] = (
                br.get("join_config") or cross["join_config"])
    return legacy


def _read_columns_from_file(path: str) -> list:
    """Read column names from a parquet or CSV result file."""
    try:
        p = Path(path)
        if not p.exists():
            return []
        if p.suffix.lower() in (".parquet", ".pq"):
            import pyarrow.parquet as pq
            schema = pq.read_schema(path)
            return [f.name for f in schema]
        # CSV fallback
        import csv
        with open(path, "r", encoding="utf-8") as f:
            return next(csv.reader(f), [])
    except Exception:
        return []


# ── Shared owner-scoped Business-Report executor (single chokepoint) ──────────
#
# One execution function reused by EVERY headless business-report path:
#   * core/scheduler.py::_exec_business_report (scheduled runs, Phase 111-F)
#   * core/delivery_engine.py deliver_subscription (subscription delivery)
#   * any future background caller
#
# It preserves the SAME data-source dispatch the interactive report path uses
# (_run_report_query / _run_parquet_report / _run_sql_report) and the SAME
# owner-scoped RLS the F1 fix introduced (commit bc5a639).  Never role="admin".
def _dispatch_business_report_execution(br: dict, param_values: dict,
                                        execution_id: str, output_dir: Path,
                                        owner_ctx: Dict[str, Any], db) -> tuple:
    """Execute a business report to an output file at the OWNER's RLS scope.

    Thin shim over :func:`core.reports.sources.execute_headless` — the
    registry-dispatched single chokepoint every headless caller (scheduler,
    subscription delivery, future automation) shares, so they can never
    diverge on data-source dispatch or RLS scope.

    Returns ``(output_path, total_rows)`` where ``output_path`` is a
    **VERIFIED** artifact path — it is guaranteed to exist for EVERY source
    type (the raw-SQL cross-source branch is resolved through the result
    store).  If no retrievable artifact was produced this RAISES
    (``core.reports.contract.ReportArtifactError``): a run can no longer
    claim success without the artifact it names.
    """
    from core.reports.sources import execute_headless
    return execute_headless(br, param_values, execution_id, output_dir,
                            owner_ctx, db)


def _read_result_file_head(p: Path, limit: Optional[int]) -> "pd.DataFrame":
    """The first ``limit`` rows of a result file (all when ``limit`` is
    falsy), with the file's TRUE row count in ``df.attrs["qs_source_rows"]``.

    2026-10-04: a subscription delivers at most ``delivery.max_pdf_rows``
    rows, but the whole artifact was read into pandas first and cut after --
    a 5M-row report's subscription materialised all 5M rows on the scheduler
    pod to mail 10,000.  Parquet is read batch by batch up to the bound and
    counted from its footer; a CSV is counted in chunks.
    """
    import pandas as pd
    bound = int(limit) if limit else 0
    if p.suffix.lower() in (".parquet", ".pq"):
        if bound <= 0:
            df = pd.read_parquet(p)
            df.attrs["qs_source_rows"] = len(df)
            return df
        import pyarrow as pa
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(str(p))
        total = int(pf.metadata.num_rows)
        batches, got = [], 0
        for batch in pf.iter_batches(batch_size=min(65_536, max(1, bound))):
            batches.append(batch)
            got += batch.num_rows
            if got >= bound:
                break
        table = (pa.Table.from_batches(batches, schema=pf.schema_arrow)
                 if batches else pf.schema_arrow.empty_table())
        df = table.slice(0, bound).to_pandas()
        df.attrs["qs_source_rows"] = total
        return df
    if bound <= 0:
        df = pd.read_csv(p)
        df.attrs["qs_source_rows"] = len(df)
        return df
    df = pd.read_csv(p, nrows=bound)
    df.attrs["qs_source_rows"] = sum(len(c) for c in pd.read_csv(p, chunksize=100_000))
    return df


def _read_business_report_result_to_df(output_path: str, execution_id: str,
                                       limit: Optional[int] = None) -> "pd.DataFrame":
    """Read a business-report execution result file into a DataFrame.

    Handles both output shapes produced by
    :func:`_dispatch_business_report_execution`:
      * ``output_path`` written directly (parquet / federation / raw-parquet)
      * cross-source raw-SQL results discoverable via ``find_csv_file``
    Raises RuntimeError when no result file can be located (fail-closed — we
    never deliver an empty/wrong report silently).

    ``limit`` (2026-10-04): read at most that many rows; the true count
    rides ``df.attrs["qs_source_rows"]`` (see :func:`_read_result_file_head`).
    """
    p = Path(output_path) if output_path else None
    if p and p.exists():
        return _read_result_file_head(p, limit)
    # Raw-SQL cross-source branch writes under execution_id — locate it.
    from api.data_grid_api import find_csv_file
    result_file = find_csv_file(execution_id)
    if result_file and result_file.exists():
        return _read_result_file_head(Path(result_file), limit)
    raise RuntimeError(
        f"Business report execution produced no readable output "
        f"(exec {execution_id}, path {output_path})"
    )


def run_business_report_to_df(report_id: int, param_values: dict,
                              username: str, limit: int = 10000) -> "pd.DataFrame":
    """Run a Business Report to a DataFrame at the report OWNER's RLS scope.

    This is the reusable owner-scoped executor for headless/background callers
    (subscription delivery, PDF/burst of business reports, future automation).
    It resolves the report against the ``business_reports`` table — NOT the
    legacy ``reports`` table — so ``report_type="business_report"`` deliveries
    stop colliding with legacy report IDs.

    SECURITY (RLS): the principal is the REPORT OWNER (``br["owner"]``),
    resolved through the SAME F1 helper the scheduler uses
    (``core.scheduler._resolve_owner_user_ctx`` → ``core.ad_auth.lookup_ad_user``).
    It is NEVER role="admin"; on any resolution failure it fails CLOSED to a
    least-privilege ``{role:"viewer", groups:[]}`` principal.  A scheduled /
    delivered run therefore reproduces exactly the rows the owner sees running
    the report interactively — never an unfiltered admin view.  ``username``
    (the subscription's created_by / triggering identity) is accepted for
    signature parity with the legacy executor and audit context; the RLS scope
    deliberately follows the report owner, matching F1.

    Raises on any failure (report not found, execution error, no output) so the
    caller records a delivery FAILURE and never sends a partial/wrong report.
    """
    import shutil
    import tempfile

    db = _require_db()
    br = db.get_business_report(report_id)
    if not br:
        raise ValueError(f"Business report {report_id} not found")

    # Reuse the F1 owner-scoped principal resolver (single chokepoint).
    from core.scheduler import _resolve_owner_user_ctx
    owner_ctx = _resolve_owner_user_ctx(br.get("owner"))

    execution_id = str(uuid.uuid4())
    tmp_dir = Path(tempfile.mkdtemp(prefix="br_deliver_"))
    try:
        output_path, _total = _dispatch_business_report_execution(
            br, param_values or {}, execution_id, tmp_dir, owner_ctx, db,
        )
        # 2026-10-04: read only the rows that will be delivered (+ the true
        # count from the footer) -- never the whole artifact to cut after.
        df = _read_business_report_result_to_df(output_path, execution_id,
                                                limit=limit)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    # 2026-08-05 audit fix (silent truncation): the head() cut below used to
    # be invisible — a subscribed CSV/Excel/PDF was mailed cut at ``limit``
    # (delivery.max_pdf_rows for subscriptions) with no indication anywhere.
    # The cut still happens (bounded delivery is deliberate) but it is now
    # DECLARED via DataFrame.attrs so the delivery engine can disclose it in
    # the e-mail body and the structured log.  attrs are set on the FINAL
    # frame (never relied on to propagate through pandas ops).
    total_before = int(df.attrs.get("qs_source_rows", len(df)))
    truncated = bool(limit) and total_before > int(limit)
    if truncated:
        df = df.head(int(limit)).copy()
    df.attrs["qs_total_rows"] = total_before
    df.attrs["qs_row_limit"] = int(limit) if limit else None
    df.attrs["qs_truncated"] = truncated
    return df


def _execute_raw_sql_report(report: dict, param_values: dict,
                            limit_override: int | None,
                            report_id: int, db, role: str,
                            user_ctx: Optional[Dict[str, Any]] = None) -> dict:
    """Execute a raw_sql business report via the parametric report engines.

    Adapts fields to the legacy report shape, resolves business dates,
    dispatches to OptimizedParquetEngine or CrossSourceEngine, and returns
    a FederationEngine-compatible result dict.

    Phase 131 deep-dive #10: accepts user_ctx for row-security
    enforcement.  Forwarded to _run_sql_report (which calls secure_sql).
    """
    import time as _time
    from core.parameters import (resolve_business_dates, seed_parameter_defaults,
                                 validate_param_values)
    from core import config as _cfg

    legacy = _as_legacy_report(report)
    # Defaults first, supplied values win -- the SAME rule the save-time
    # preflight applies (core.parameters.seed_parameter_defaults).
    resolved = resolve_business_dates(
        seed_parameter_defaults(legacy["parameters"], param_values))

    errors = validate_param_values(legacy["parameters"], resolved)
    if errors:
        raise HTTPException(400, detail={"errors": errors})

    row_limit = _resolve_report_row_limit(limit_override, report, _cfg)
    execution_id = str(uuid.uuid4())
    t0 = _time.time()
    # AQD-01 (2026-09-23): a raw-SQL report does not pass through the
    # semantic-layer wrapper that records the others, so it records itself --
    # otherwise the admin "last N queries" list is blind to it.
    try:
        from core.brain.scan_plan import record_execution_path_if_absent
        record_execution_path_if_absent(
            execution_id, "business_report_raw_sql", raw_sql=True,
            notes=f"report_id={report_id}")
    except Exception:  # pragma: no cover - diagnostics never break a run
        logger.debug("could not record execution path", exc_info=True)

    from core.config import paths as _br_paths
    output_dir = Path(str(_br_paths.downloads_dir))
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / f"{execution_id}.parquet")

    noop = lambda _: None  # noqa: E731 — no WebSocket emit for sync path

    try:
        if legacy["saved_query_id"]:
            from api.reports_api import _run_parquet_report
            total_rows = _run_parquet_report(legacy, resolved, row_limit, output_path, noop)
            columns = _read_columns_from_file(output_path)
        elif legacy["sql_saved_query_id"] or legacy.get("sql_override"):
            from api.reports_api import _run_sql_report
            # Phase 131 deep-dive #10: forward user_ctx for RLS.
            # deep-dive #13: SqlFile-backed BR — sql_override set inline.
            total_rows = _run_sql_report(legacy, resolved, row_limit, execution_id, noop,
                                          user_ctx=user_ctx)
            # SQL engine writes {execution_id}.parquet via cross_source_engine
            result_path = str(output_dir / f"{execution_id}.parquet")
            columns = _read_columns_from_file(result_path)
            output_path = result_path
        else:
            raise HTTPException(400, "raw_sql report has no source configured")
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(400, detail=str(exc))
    except Exception as exc:
        from core.error_sanitizer import sanitize_error as _se
        logger.error("raw_sql report execution failed (report_id=%d): %s", report_id, _se(str(exc)))
        raise HTTPException(500, detail=f"raw_sql report execution failed: {_se(str(exc))}")

    duration = round(_time.time() - t0, 2)

    # Phase 0 reports rewire (2026-08-08): record the REAL executor.
    # executed_by="" made the paged-results gate's executor check
    # (get_report_results_paginated: executed_by == username) False for
    # EVERYONE, so a non-owner/non-admin executor got 403 paging their OWN
    # sync raw_sql result (fail-closed availability defect).  Key mirrors
    # the callers' (user or {}).get("username", "") convention; user_ctx is
    # None on the legacy compat path → "" exactly as before.
    executed_by = (user_ctx or {}).get("username") or ""

    # Track execution in federation_executions so the paged results endpoint
    # (get_report_results_paginated) can find the output_path via
    # get_federation_execution(exec_id).  Without this, paged results returns 404.
    try:
        db.create_federation_execution(
            execution_id=execution_id,
            dataset_id=report.get("dataset_id") or 0,
            report_id=report_id,
            sql_generated="",
            column_ids=[],
            executed_by=executed_by,
        )
        db.update_federation_execution(
            execution_id,
            status="completed",
            output_path=output_path,
            total_rows=total_rows,
            duration_seconds=duration,
        )
    except Exception as exc:
        logger.warning("Failed to track raw_sql federation execution: %s", exc)

    db.increment_business_report_execution(report_id)
    _track_sync_execution(db, report_id, executed_by, total_rows=total_rows, output_path=output_path)

    return {
        "execution_id": execution_id,
        "dataset_id": report.get("dataset_id"),
        "output_path": output_path,
        "total_rows": total_rows,
        "columns": columns,
        "duration_seconds": duration,
        "sql_generated": "",
        "sources_used": [],
        "data_source_type": "raw_sql",
    }


def _with_contract_keys(resp: Any, source_type: str, row_limit: Optional[int],
                        log_ctx: Optional[dict] = None) -> Any:
    """ADDITIVELY stamp the unified-contract metadata onto a legacy response.

    The interactive ``/execute`` endpoint keeps its historical per-source
    payloads (existing UI consumers read ``data`` / ``output_path`` /
    ``execution_id`` in source-specific ways) but every response now ALSO
    carries ``source_type`` / ``row_limit`` / ``truncated`` so new consumers
    can read one contract.  ``truncated`` is tri-state: True (limit reached,
    may be cut), False (under the limit), None (row count unknown — UNKNOWN
    is surfaced, never coerced to a claim of completeness).  Existing keys
    are never overwritten.

    ``log_ctx`` (2026-08-05 audit, optional + additive): when provided —
    ``{"report_id":…, "user":…, "surface":…}`` — the ONE greppable
    ``[br-serve]`` line is emitted here, so every interactive/async response
    is logged from the same chokepoint that stamps its contract.
    """
    if not isinstance(resp, dict):
        return resp
    resp.setdefault("source_type", source_type)
    # D1 silent-truncation fix (2026-08-09, drilldown + source-agnostic
    # audits): the federation engine stamps the EFFECTIVE limit it actually
    # applied (post federation.max_result_rows clamp) into the response.
    # When present, THAT limit — not the (possibly larger) BR-configured
    # limit — is what the truncation verdict must compare against.
    # Pre-fix: report.row_limit=500K, federation clamp=100K → artifact cut
    # at 100K but verdict computed 100000 >= 500000 → truncated=False: a
    # silently-incomplete result under a green light.  The engine-stamped
    # value wins; paths that don't stamp one keep the caller's limit
    # exactly as before.
    if resp.get("row_limit") is None:
        resp["row_limit"] = row_limit
    if "truncated" not in resp:
        # CORR-2 (2026-08-22): the ONE truncation chokepoint — an explicit
        # row_limit of 0 (unlimited) reads COMPLETE (False), never UNKNOWN.
        from core.reports.contract import truncation_verdict
        resp["truncated"] = truncation_verdict(
            resp.get("total_rows"), resp.get("row_limit"))
    if log_ctx:
        from core.reports.serve_log import log_report_serve
        _data = resp.get("data")
        log_report_serve(
            report_id=log_ctx.get("report_id"),
            execution_id=str(resp.get("execution_id") or ""),
            user=log_ctx.get("user", ""),
            rls=log_ctx.get("rls", "caller"),
            surface=log_ctx.get("surface", "interactive"),
            fmt="json",
            rows=(len(_data) if isinstance(_data, list) else None),
            total_rows=resp.get("total_rows"),
            row_limit=resp.get("row_limit"),
            truncated=resp.get("truncated"),
        )
    return resp


def _stamp_served_version(resp: Any, served_version: Optional[dict]) -> Any:
    """ADDITIVE disclosure: which published version this response executed.
    Absent for draft runs (editors / never-published reports) — existing
    consumers that don't read the key are unaffected.

    2026-09-28 -- ALSO the one door every execute response leaves through,
    so the business-date READINESS verdict (core/reports/readiness.py) is
    stamped here from the request's context (``_readiness_ctx``, set once
    by each execute route after the effective report is resolved) instead
    of at nine separate return sites.  A response that IS a completed run
    (an execution id, not a "running" hand-off, not a served instance)
    also records the verdict it was served under -- the SLO's evidence."""
    if isinstance(resp, dict) and served_version:
        resp.setdefault("served_version", served_version)
    return _stamp_readiness(resp)


# ── 2026-09-28: business-date readiness on the run envelope ─────────────────
#
# (readiness, db, username, surface) for the request in flight.  Each HTTP
# request runs in its own asyncio task with a COPIED context, so a value set
# by one execute route is invisible to every other request and dies with the
# task; nothing needs resetting.  None outside an execute route.
import contextvars as _contextvars
_readiness_ctx: "_contextvars.ContextVar[Optional[tuple]]" = _contextvars.ContextVar(
    "br_readiness", default=None)

#: execution_id -> Readiness for ASYNC runs, read back by the terminal write
#: (to record the run) and by the status poll (to show it).  Bounded: the
#: oldest entry goes when the map passes _ASYNC_READINESS_CAP.
_async_readiness: "Dict[str, Any]" = {}
_ASYNC_READINESS_CAP = 2000


def _readiness_for_execute(db, report: dict, param_values: dict, report_id: int):
    """The readiness of the business date this run asks about -- through the
    one resolver (``readiness_for_run``) with THIS module's shortcut
    resolver, and the parameter rows THIS execution runs under (a consumer
    runs the published snapshot's).  Never raises: readiness must not fail a
    run.  A date token the resolver refuses lands as ``unknown`` naming the
    refusal here, and the run itself still refuses with 400 further down
    (the same token reaches ``_build_report_filters``)."""
    from core.reports import readiness as _rd
    try:
        params = _report_parameters_for_execution(report, db, report_id)
        return _rd.readiness_for_run(db, report, param_values or {},
                                     resolve=_resolve_param_value, params=params)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[readiness] report %s: readiness could not be evaluated "
                       "for this run (%s) -- stamped as unknown", report_id, exc)
        return _rd.Readiness(
            report_id=int(report_id), business_date=date.today(),
            business_date_source=_rd.SOURCE_TODAY, business_date_param=None,
            state=_rd.STATE_UNKNOWN,
            summary=f"Could not tell -- readiness could not be evaluated for "
                    f"this run ({type(exc).__name__}: {exc})")


def _arm_readiness(readiness, db, username: str, surface: str):
    """Put the verdict in the REQUEST's context.  Called on the event loop
    by the route itself -- ``asyncio.to_thread`` runs in a COPY of the
    context, so a set made inside the worker thread never reaches the
    request (the first cut did exactly that and stamped nothing)."""
    _readiness_ctx.set((readiness, db, username, surface))
    return readiness


def _remember_async_readiness(execution_id: str, readiness) -> None:
    if readiness is None:
        return
    if len(_async_readiness) >= _ASYNC_READINESS_CAP:
        try:
            del _async_readiness[next(iter(_async_readiness))]
        except (StopIteration, KeyError):
            pass
    _async_readiness[str(execution_id)] = readiness


def _stamp_readiness(resp: Any) -> Any:
    ctx = _readiness_ctx.get()
    if ctx is None or not isinstance(resp, dict):
        return resp
    readiness, db, username, surface = ctx
    if readiness is None:
        return resp
    resp.setdefault("readiness", readiness.to_dict())
    completed_run = (bool(resp.get("execution_id"))
                     and str(resp.get("status") or "completed") == "completed"
                     and not resp.get("served_from_instance")
                     and not resp.get("instance"))
    if completed_run and db is not None:
        import functools
        from core.reports.readiness import record_readiness_run
        _write = functools.partial(
            record_readiness_run, db, readiness,
            execution_id=str(resp.get("execution_id")),
            executed_by=username, surface=surface)
        _sink = _readiness_write_sink.get()
        if _sink is not None:
            _sink.append(_write)        # _astamp_served_version runs it off the loop
        else:
            _write()
    return resp


#: 2026-10-07 -- the readiness-run INSERT used to run inline on the event loop
#: from every execute route's return (measured in-process: the top stall
#: source of the sync report lane, beside ``_track_sync_execution``).  Inside
#: :func:`_astamp_served_version` this collects the write instead, which is
#: then AWAITED on a worker thread -- still written before the response
#: leaves, never on the loop.
_readiness_write_sink: "_contextvars.ContextVar[Optional[list]]" = _contextvars.ContextVar(
    "br_readiness_write_sink", default=None)


async def _astamp_served_version(resp: Any, served_version: Optional[dict]) -> Any:
    """:func:`_stamp_served_version` for an ``async def`` route: identical
    stamping, with the readiness-run DB write awaited off the event loop."""
    pending: list = []
    token = _readiness_write_sink.set(pending)
    try:
        resp = _stamp_served_version(resp, served_version)
    finally:
        _readiness_write_sink.reset(token)
    for _write in pending:
        await _adb(_write)
    return resp


def _record_async_readiness(db, execution_id: str, username: Optional[str]) -> None:
    """The async terminal write's half: the verdict remembered at submit is
    recorded once the run actually COMPLETED (a failed or cancelled job
    served nothing and records nothing)."""
    readiness = _async_readiness.get(str(execution_id))
    if readiness is None:
        return
    from core.reports.readiness import record_readiness_run
    record_readiness_run(db, readiness, execution_id=str(execution_id),
                         executed_by=username, surface="interactive-async")


@router.post("/api/business-reports/{report_id}/execute")
async def execute_report(report_id: int, body: ReportExecuteRequest,
                         user: dict = Depends(require_capability("reports.view"))):
    """Execute a business report via the Federation Engine.

    Phase 81: resolves relative date parameters, uses correct secondary column IDs.
    Phase 111: raw_sql source type dispatches to parametric report engines.
    """
    db = _require_db()
    fed = _require_federation()
    from core import config as _cfg

    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    # Phase 131 deep-dive #10: replaced 3 duplicated access checks with
    # the shared core.entitlements.can_view helper (DRY).  Now honors
    # owner_group_id (group-based access) in addition to is_published /
    # owner / admin-tier semantic.
    if not _br_can_view(report, user):
        raise HTTPException(status_code=403, detail="Access denied")

    # ── Publish lifecycle (2026-08-17) — draft vs published fork ─────────
    # Editors execute the DRAFT (live row); consumers execute the CURRENT
    # PUBLISHED VERSION's snapshot, so an author's in-progress edit never
    # reaches them.  Every use of ``report`` below (filters, source ids,
    # row_limit, layout, instance keying) reads the EFFECTIVE dict.
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, user)
    # 2026-11-02 -- a default RULE (latest with data, ...) applies to a run that sent no value
    body.parameter_values = await _fill_rule_defaults_or_409(db, report, body.parameter_values, user)
    # 2026-09-28 -- the business-date READINESS this run is served under,
    # evaluated ONCE here (off the loop) and stamped on whichever envelope
    # this route returns (see _stamp_served_version / _stamp_readiness).
    _arm_readiness(await asyncio.to_thread(_readiness_for_execute, db, report,
                                           body.parameter_values, report_id),
                   db, username, "interactive")

    # ── Phase 2 report-instance layer (2026-08-09) ───────────────────────
    # An instance is a lawful stand-in ONLY for the report's STORED shape:
    # extra filters, drill column overrides and limit overrides all change
    # the bytes, so such requests neither serve nor record instances.
    # try_serve_instance is fail-closed (any uncertainty → None → run live)
    # and flag-gated; with instance_serving_enabled OFF this block is inert.
    # Version coherence: the effective dict above is what keys the instance
    # (semantic_version hashes the SNAPSHOT for consumers, the draft for
    # editors) — an instance belongs to the definition that produced it.
    _instance_cacheable = _instance_cacheable_for(body)
    if (_instance_cacheable and _wants_instance_serve(body)
            and _cfg.business_reports.instance_serving_enabled):
        _inst_wire = await asyncio.to_thread(
            try_serve_instance, db, report, user, body.parameter_values,
            row_limit=_resolve_report_row_limit(None, report, _cfg),
            surface="interactive")
        if _inst_wire is not None:
            return await _astamp_served_version(_inst_wire, _served_version)

    # Phase 93: federation_view data source — bypass FederationEngine, use federation views API
    if (report.get("data_source_type") or "saved_query") == "federation_view":
        fv_id = report.get("federation_view_id")
        if not fv_id:
            raise HTTPException(400, "Report has data_source_type='federation_view' but no federation_view_id")
        fv = await _adb(db.get_federation_view, fv_id)
        if not fv:
            raise HTTPException(404, f"Federation view {fv_id} not found")
        try:
            from api.federation_views_api import execute_federation_view
            row_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)
            # 2026-08-30 — pass the CALLER, not just their name.  Without
            # user_ctx, _fv_principal fabricates an ``rls_unresolved``
            # principal; the rewriter then REFUSES every governed table,
            # so an authenticated user with full legitimate access got
            # "Row-security policy enforcement failed" on every FV-backed
            # report.  Fail-closed was correct; being unrunnable for
            # everyone was the defect.  Two independent audits flagged it.
            result = await execute_federation_view(
                fv, limit=row_limit, username=username, user_ctx=user)
            await _adb(db.increment_business_report_execution, report_id)
            # Phase 0 reports rewire (2026-08-08): PV/FV artifact parity —
            # additive artifact + execution registration; inline data
            # untouched.  Blocking write → off the event loop.
            _artifact_path = await asyncio.to_thread(
                _persist_inline_result_artifact, db, report, result, username)
            await _adb(_track_sync_execution, db, report_id, username,
                                  total_rows=(result or {}).get("total_rows", 0) if isinstance(result, dict) else 0,
                                  output_path=_artifact_path or "")
            # Phase 2 (2026-08-09): instance write-through — fail-open +
            # flag-gated inside the chokepoint; one line per site.
            # D1/D2: persist the RUN's truncation facts (one extraction
            # chokepoint, mirrors _with_contract_keys) so serves disclose
            # the run's verdict instead of recomputing one.
            if _instance_cacheable and _artifact_path and isinstance(result, dict) and result.get("execution_id"):
                await asyncio.to_thread(
                    record_report_instance, db, report, user,
                    body.parameter_values,
                    execution_id=result.get("execution_id"),
                    artifact_path=_artifact_path,
                    row_count=result.get("total_rows"),
                    **truncation_facts(result, row_limit))
            return await _astamp_served_version(
                _with_contract_keys(result, "federation_view", row_limit,
                                    log_ctx={"report_id": report_id,
                                             "user": username,
                                             "surface": "interactive"}),
                _served_version)
        except HTTPException:
            raise
        except Exception as exc:
            from core.error_sanitizer import sanitize_error as _se
            logger.error("Federation view report execution failed (report_id=%d, fv_id=%d): %s",
                         report_id, fv_id, _se(str(exc)))
            raise HTTPException(500, f"Federation view execution failed: {_se(str(exc))}")

    # Phase 100: published_view data source — leverage cached Published View
    if (report.get("data_source_type") or "saved_query") == "published_view":
        pv_id = report.get("published_view_id")
        if not pv_id:
            raise HTTPException(400, "Report has data_source_type='published_view' but no published_view_id")
        if not _cfg.business_reports.enable_published_view_source:
            raise HTTPException(400, "Published View data source is disabled by configuration")
        pv = await _adb(db.get_published_view, pv_id)
        if not pv:
            raise HTTPException(404, f"Published view {pv_id} not found")
        if not pv.get("is_active"):
            raise HTTPException(400, "Published view is inactive")
        try:
            pv_params = await _adb(_map_report_params_to_pv, report, body.parameter_values, db, report_id)
            row_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)
            from api.published_views_api import _execute_view
            # 2026-08-05 BR cross-source audit: pass the REAL viewer as the
            # RLS principal.  Without consumer_user the PV handler falls
            # back to a synthetic "pv:<slug>" principal, so row policies
            # bound to the actual user/groups were not applied on the
            # BR-over-PV path (every other BR source type uses the caller).
            result = _public_view_result(await _execute_view(
                pv=pv, filters=[], columns=None,
                sort_column=None, sort_dir="asc",
                limit=row_limit, offset=0, params=pv_params,
                consumer_user=user,
            ))
            await _adb(db.increment_business_report_execution, report_id)
            # Phase 0 reports rewire (2026-08-08): PV/FV artifact parity —
            # additive artifact + execution registration; inline data
            # untouched.  Blocking write → off the event loop.
            _artifact_path = await asyncio.to_thread(
                _persist_inline_result_artifact, db, report, result, username)
            await _adb(_track_sync_execution, db, report_id, username,
                                  total_rows=(result or {}).get("total_rows", 0) if isinstance(result, dict) else 0,
                                  output_path=_artifact_path or "")
            # Phase 2 (2026-08-09): instance write-through (see FV branch).
            if _instance_cacheable and _artifact_path and isinstance(result, dict) and result.get("execution_id"):
                await asyncio.to_thread(
                    record_report_instance, db, report, user,
                    body.parameter_values,
                    execution_id=result.get("execution_id"),
                    artifact_path=_artifact_path,
                    row_count=result.get("total_rows"),
                    **truncation_facts(result, row_limit))
            return await _astamp_served_version(
                _with_contract_keys(result, "published_view", row_limit,
                                    log_ctx={"report_id": report_id,
                                             "user": username,
                                             "surface": "interactive"}),
                _served_version)
        except HTTPException:
            raise
        except Exception as exc:
            from core.error_sanitizer import sanitize_error as _se
            logger.error("Published view report execution failed (report_id=%d, pv_id=%d): %s",
                         report_id, pv_id, _se(str(exc)))
            raise HTTPException(500, f"Published view execution failed: {_se(str(exc))}")

    # Phase 111: raw_sql source type — dispatch to parametric report engines.
    # Phase 131 deep-dive #10: forward user for RLS enforcement.
    if (report.get("data_source_type") or "saved_query") == "raw_sql":
        # 2026-09-15: through the REPORT admission gate (typed pool slot +
        # load-shed), not the default executor — see _admit_report_run.
        _raw_resp = await _admit_report_run(
            _execute_raw_sql_report, report, body.parameter_values,
            body.limit_override, report_id, db, role, user,
            execution_id=f"br_raw_{uuid.uuid4().hex[:12]}", username=username,
            report_id=report_id, db=db, client_request_id=body.client_request_id)
        # Phase 2 (2026-08-09): instance write-through (see FV branch).
        # D1/D2: same fallback limit expression as _with_contract_keys below.
        _raw_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)
        if _instance_cacheable and isinstance(_raw_resp, dict) and _raw_resp.get("execution_id"):
            await asyncio.to_thread(
                record_report_instance, db, report, user,
                body.parameter_values,
                execution_id=_raw_resp.get("execution_id"),
                artifact_path=(_raw_resp.get("output_path") or None),
                row_count=_raw_resp.get("total_rows"),
                **truncation_facts(_raw_resp, _raw_limit))
        return await _astamp_served_version(
            _with_contract_keys(
                _raw_resp, "raw_sql",
                _raw_limit,
                log_ctx={"report_id": report_id, "user": username,
                         "surface": "interactive"}),
            _served_version)

    combined_filters = await _adb(_build_report_filters, report, body.parameter_values, db,
                                              report_id, body.extra_filters)
    _src_bindings = await _adb(_build_source_bindings, report, body.parameter_values, db, report_id)
    row_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)
    execution_id = str(uuid.uuid4())
    # 2026-11-01 -- the Data version run control (core/iceberg_versions.py):
    # stamped on the report dict the query runner reads, audited.
    report = _with_data_version(report, getattr(body, "data_version", None), user, db, report_id)

    # Phase 106: pivot report execution — uses agg_overrides for GROUP BY
    lc = report.get("layout_config") or {}
    is_pivot = lc.get("report_type") == "pivot"

    try:
        # 2026-09-15: federation execution is blocking (duckdb / IO) and it
        # now runs through the REPORT admission gate (_admit_report_run):
        # a typed, bounded pool slot on a wp- thread — never the default
        # executor every adb() call shares (the /health-green-API-stalled
        # defect class), and never inline on the loop.
        # FB-36: the viewer's Refresh reaches the CUBE route too, not only
        # instance serving (see _wants_instance_serve).
        _force_live = bool(getattr(body, "force_refresh", False))
        if is_pivot:
            result = await _admit_report_run(
                _run_pivot_report_query, fed, report, combined_filters,
                row_limit, execution_id, role, user_ctx=user,
                force_refresh=_force_live, source_bindings=_src_bindings,
                execution_id=execution_id, username=username,
                report_id=report_id, db=db,
                client_request_id=body.client_request_id)
        else:
            result = await _admit_report_run(
                _run_report_query, fed, report, combined_filters,
                row_limit, execution_id, role,
                override_column_ids=_validated_column_subset(
                    report, body.override_column_ids),
                user_ctx=user,
                force_refresh=_force_live, source_bindings=_src_bindings,
                execution_id=execution_id, username=username,
                report_id=report_id, db=db,
                client_request_id=body.client_request_id)
        await _adb(db.increment_business_report_execution, report_id)
        resp = result.to_dict() if hasattr(result, "to_dict") else result
        # Store federation execution so paged results endpoint can find the output_path
        _resp_d = resp if isinstance(resp, dict) else {}
        try:
            await _adb(db.create_federation_execution, 
                execution_id=execution_id,
                dataset_id=report.get("dataset_id") or 0,
                report_id=report_id,
                sql_generated=_resp_d.get("sql_generated", ""),
                column_ids=report.get("column_ids", []),
                executed_by=username,
            )
            await _adb(db.update_federation_execution, 
                execution_id,
                status="completed",
                output_path=_resp_d.get("output_path", ""),
                total_rows=_resp_d.get("total_rows", 0),
                duration_seconds=_resp_d.get("duration_seconds", 0),
            )
        except Exception as _fe_exc:
            logger.debug("Failed to track sync federation execution: %s", _fe_exc)
        # Also store in BR async jobs table for unified execution history
        await _adb(_track_sync_execution, db, report_id, username,
                              total_rows=_resp_d.get("total_rows", 0),
                              output_path=_resp_d.get("output_path", ""))
        await asyncio.to_thread(_run_diagnostics.record_report_run, db, report=report, report_id=report_id, execution_id=execution_id, param_values=body.parameter_values, combined_filters=combined_filters, source_bindings=_src_bindings, result=_resp_d, username=username)  # 2026-10-30 Diagnostics panel
        # Phase 2 (2026-08-09): instance write-through (see FV branch).
        # D1/D2: the engine-stamped effective row_limit/truncated in
        # _resp_d (FederationResult.to_dict) win; the caller's limit is
        # only the fallback — exactly _with_contract_keys precedence.
        if _instance_cacheable and _resp_d.get("output_path"):
            await asyncio.to_thread(
                record_report_instance, db, report, user,
                body.parameter_values,
                execution_id=execution_id,
                artifact_path=_resp_d.get("output_path"),
                row_count=_resp_d.get("total_rows"),
                iceberg_versions=_resp_d.get("iceberg_versions"),      # 2026-11-01
                **truncation_facts(_resp_d, row_limit))
        # Phase 106: include pivot_config in response so frontend knows how to render
        if is_pivot and isinstance(resp, dict):
            resp["pivot_config"] = lc.get("pivot_config")
        # 2026-07-18 Completeness Certificate — surface the reader-built
        # fail-closed trust verdict on the response envelope so the UI can
        # show a Complete / Incomplete / Unverified badge.  Observational +
        # fail-open: the certificate was pushed to the per-execution
        # diagnostic store under this execution_id by the iceberg reader;
        # absence simply omits the field (never breaks the response).
        if isinstance(resp, dict):
            try:
                from core.query_diagnostic_store import get_pruning as _get_pruning
                _cert_d = (_get_pruning(execution_id) or {}).get("completeness_certificate")
                if _cert_d:
                    resp["certificate"] = _cert_d
            except Exception as _cert_exc:
                logger.debug("certificate surface skipped (fail-open): %s", _cert_exc)
            # 2026-09-05 progressive partition loading -- the planner's own
            # answer to "I declared a partition column and the query ran
            # WHOLE".  Same store, same lift, same fail-open terms as the
            # certificate above, through ONE shared function so surfacing a
            # diagnostic does not become a fifth hand-rolled way of doing it.
            # The access gate this handler already ran is unchanged: nothing
            # here widens who may read a report.  A dataset that declares no
            # partition config stamps nothing and therefore produces NO KEY --
            # an empty object would read as "the planner ran and said nothing".
            try:
                from core.reports.scan_verdict import scan_verdict_keys
                resp.update(scan_verdict_keys(execution_id))
            except Exception as _scan_exc:
                logger.debug("scan verdict surface skipped (fail-open): %s",
                             _scan_exc)
        return await _astamp_served_version(
            _with_contract_keys(resp, "saved_query", row_limit,
                                log_ctx={"report_id": report_id,
                                         "user": username,
                                         "surface": "interactive"}),
            _served_version)

    except HTTPException:
        # 2026-09-15: an admission refusal (503 + Retry-After) -- or any
        # other precise status raised inside -- must reach the caller as
        # itself.  The generic handler below flattened it into
        # "500: Report execution failed: 503: ...", which hid exactly the
        # status a client's retry logic keys on.
        raise
    except SourceUnavailableError as exc:
        # FB-39 (2026-09-19): with the source STOPPED this answered 400 with
        # the breaker's "clears ITSELF ... in 59s" sentence and no header --
        # the status said the request was bad; the request was fine.  503 +
        # Retry-After.
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        # 2026-10-10: the source's verdict on the caller's RIGHT (a hidden
        # column, a role it may not set) is 403 with the cluster's sentence
        # -- api.connector_errors.refusal_status, the ONE status rule;
        # every other refusal keeps this route's 400.
        raise HTTPException(status_code=refusal_status(exc, 400), detail=str(exc))
    except Exception as exc:
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        from core.error_sanitizer import sanitize_error as _se
        logger.error("Report execution failed (report_id=%d): %s", report_id, _se(str(exc)))
        raise HTTPException(status_code=500, detail=f"Report execution failed: {_se(str(exc))}")


# ── 2026-08-30 hardening — orphaned / cancelled async jobs (D3 + D4) ────────
#
# D3.  Async runs execute IN-PROCESS.  A pod restart mid-run left the
# ``br_async_jobs`` row at status="running" FOREVER: the hourly
# ``delete_stale_br_async_jobs`` deletes only completed/failed/cancelled
# rows, so after every deploy the status endpoint answered 200/"running"
# indefinitely for the orphans.  ``QS_POD_ROLE=api`` runs no daemons, so the
# sweep is OPPORTUNISTIC — piggybacked on the status/list reads, bounded
# (one LIMITed query), stampede-guarded (at most once per
# ``_ORPHAN_SWEEP_MIN_INTERVAL_SECONDS`` per process) and fail-safe (any
# error is swallowed — the read it rides on is never broken).
#
# D4.  ``DELETE .../execution/{exec_id}`` sets status="cancelled", but the
# background task had no cancellation check and its terminal write
# unconditionally flipped the row back to "completed" when it finished.
# ``_finalize_br_async_job_guarded`` is now the ONE terminal-write door for
# the three runners: an atomic ``UPDATE ... WHERE status != 'cancelled'``, so
# a cancelled job can never be resurrected — by "completed" OR by "failed".
# The runners also OBSERVE cancellation at their await boundaries (before
# the engine starts, and again at the terminal write).  Honesty note: an
# engine/DuckDB call already in flight CANNOT be interrupted from here —
# cancellation takes effect at the next boundary; work already running is
# discarded, not aborted.

_ORPHAN_SWEEP_MIN_INTERVAL_SECONDS = 60   # per-process stampede guard
_ORPHAN_SWEEP_BATCH_LIMIT = 100           # rows examined per sweep — bounded
_orphan_sweep_lock = threading.Lock()
_orphan_sweep_last_monotonic = 0.0


def _br_running_stale_after_seconds() -> int:
    """TTL after which a status="running" row with no live executor is
    treated as ORPHANED by a process restart.

    Config: ``business_reports.async_running_stale_after_seconds``
    (default 3600 s — comfortably above any sane async report run).
    Explicit ``int()`` parse — NEVER an ``x or default`` fold.  ``<= 0``
    DISABLES the sweep (the conservative direction: nothing gets marked
    failed); it must never mean "everything is instantly stale", which
    would kill live cross-pod runs.
    """
    from core import config as _cfg_mod
    try:
        return int(_cfg_mod.get("business_reports",
                                "async_running_stale_after_seconds", 3600))
    except (TypeError, ValueError):
        return 3600


def _job_created_at_utc(row: dict):
    """Parse a job row's ``created_at`` (isoformat string or datetime) to an
    aware UTC datetime; None when absent/unparseable (such a row is never
    swept — fail-safe)."""
    raw = (row or {}).get("created_at")
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
        if getattr(dt, "tzinfo", None) is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (TypeError, ValueError):
        return None


_ORPHANED_JOB_ERROR = (
    "Orphaned by a process restart: the executing pod stopped before this "
    "job finished (row stayed 'running' past the {ttl}s staleness bound).")


def _mark_job_orphaned(db, row: dict, ttl: int) -> bool:
    """Mark ONE stale running row failed IF it qualifies; True when flipped.

    A run still alive in THIS pod keeps its process-local result-cache entry
    (set at job creation) — those are skipped.  For a run on ANOTHER pod the
    TTL is the only available signal: a genuine cross-pod run longer than
    the TTL would be marked failed — that is the documented bound, and the
    TTL is configurable for installations with longer reports.
    """
    if (row or {}).get("status") != "running":
        return False
    if ttl <= 0:
        return False
    created = _job_created_at_utc(row)
    if created is None:
        return False
    if datetime.now(timezone.utc) - created < timedelta(seconds=ttl):
        return False
    exec_id = row.get("execution_id") or ""
    if _br_cache_get(exec_id):
        return False        # live in THIS pod — never orphan a running run
    # Guarded terminal write — never resurrects a concurrently-cancelled job.
    return _finalize_br_async_job_guarded(
        db, exec_id, status="failed",
        error=_ORPHANED_JOB_ERROR.format(ttl=ttl))


def _sweep_orphaned_br_async_jobs(db) -> int:
    """Opportunistic, bounded, fail-safe sweep of orphaned running rows (D3).

    Rides the status/list reads (no daemon on an API pod).  The per-process
    monotonic gate makes back-to-back polls free; any failure returns 0 and
    never breaks the read it rides on.  Returns the number of rows flipped.
    """
    global _orphan_sweep_last_monotonic
    try:
        ttl = _br_running_stale_after_seconds()
        if ttl <= 0:
            return 0
        now = time.monotonic()
        with _orphan_sweep_lock:
            if (now - _orphan_sweep_last_monotonic
                    < _ORPHAN_SWEEP_MIN_INTERVAL_SECONDS):
                return 0
            _orphan_sweep_last_monotonic = now
        rows = db.list_br_async_jobs(status="running",
                                     limit=_ORPHAN_SWEEP_BATCH_LIMIT)
        swept = 0
        for row in rows or []:
            try:
                if _mark_job_orphaned(db, row, ttl):
                    swept += 1
            except Exception as row_exc:  # one bad row never stops the rest
                logger.debug("[br-async] orphan sweep skipped row %s: %s",
                             (row or {}).get("execution_id"), row_exc)
        if swept:
            logger.info("[br-async] marked %d orphaned running job(s) failed "
                        "(stale > %ds — process restart)", swept, ttl)
        return swept
    except Exception as exc:
        logger.debug("[br-async] orphan sweep failed (fail-safe): %s", exc)
        return 0


def _br_job_cancelled(db, execution_id: str) -> bool:
    """Cancellation checkpoint for the in-process runners (D4), observed at
    the runners' await boundaries.  Fail-open: an unreadable row must not
    kill a healthy run."""
    try:
        row = db.get_br_async_job(execution_id)
        return bool(row and row.get("status") == "cancelled")
    except Exception:
        return False


def _suppressed_terminal_write(execution_id: str, fields: dict) -> bool:
    logger.info("[br-async] %s finished after cancellation — terminal "
                "write '%s' suppressed", execution_id, fields.get("status"))
    return False


def _finalize_br_async_job_write(db, execution_id: str, **fields) -> bool:
    """The terminal write itself.  Wrapped by
    :func:`_finalize_br_async_job_guarded`, which is what callers use — the
    split exists so the completion NOTIFICATION hangs off ONE place rather
    than off each of this function's three success returns.

    Writes ``fields`` onto the job row ATOMICALLY guarded by
    ``status != 'cancelled'`` — a job the user cancelled can never be
    flipped back to "completed" (or overwritten with "failed") by the
    background task finishing later.  Returns True when the write landed,
    False when it was suppressed because the job is cancelled.

    Falls back to read-check-write for DB objects without a SQLAlchemy
    session layer (a residual read→write race, milliseconds wide — strictly
    narrower than the unconditional overwrite it replaces).
    """
    try:
        from core.db.models import BusinessReportAsyncJob as _Job
        with db.get_session() as session:
            values = {k: v for k, v in fields.items() if hasattr(_Job, k)}
            if fields.get("status") in ("completed", "failed", "cancelled"):
                values["completed_at"] = datetime.now(timezone.utc)
                # 2026-09-28: a terminal state waits for nothing.
                values.setdefault("waiting_for", None)
                values.setdefault("status_detail", None)
            updated = session.query(_Job).filter(
                _Job.id == execution_id,
                _Job.status != "cancelled",
            ).update(values, synchronize_session=False)
        if updated:
            return True
        row = db.get_br_async_job(execution_id)
        if row and row.get("status") == "cancelled":
            return _suppressed_terminal_write(execution_id, fields)
        return True   # row gone (TTL-deleted mid-run): nothing to resurrect
    except Exception:
        try:
            row = db.get_br_async_job(execution_id)
        except Exception:
            row = None
        if row and row.get("status") == "cancelled":
            return _suppressed_terminal_write(execution_id, fields)
        if fields.get("status") in ("completed", "failed", "cancelled"):
            fields = {"waiting_for": None, "status_detail": None, **fields}
        db.update_br_async_job(execution_id, **fields)
        return True


def _async_capacity_wait(db, execution_id: str):
    """The capacity wait of an ALREADY-ADMITTED async run (2026-09-28).

    ``None`` when ``business_reports.async_capacity_wait_seconds`` is 0
    (fail at once, the old behaviour).  Otherwise a ``CapacityWait`` whose
    callbacks keep the JOB ROW truthful: every poll that finds the pod at
    capacity writes ``waiting_for="capacity"`` and a ``status_detail``
    sentence (the status route surfaces both), obtaining capacity clears
    them, and the wait stops as soon as the row says ``cancelled`` (the
    cancel route's write) -- the same predicate the runners observe at
    their other boundaries.  The sync route never builds one.
    """
    from core import config as _cfg_mod
    from core.reports.admission import CapacityWait
    try:
        budget = float(_cfg_mod.business_reports.async_capacity_wait_seconds)
    except (TypeError, ValueError):
        budget = 0.0
    if budget <= 0:
        return None

    async def _keep_waiting() -> bool:
        return not await _adb(_br_job_cancelled, db, execution_id)

    async def _on_waiting(waited: float, reason: str) -> None:
        await _adb(db.update_br_async_job, execution_id,
                   waiting_for="capacity",
                   status_detail=(f"Waiting for server capacity "
                                  f"({waited:.0f}s of up to {budget:.0f}s): {reason}"))

    async def _on_admitted(waited: float) -> None:
        await _adb(db.update_br_async_job, execution_id,
                   waiting_for=None, status_detail=None)

    return CapacityWait(budget, keep_waiting=_keep_waiting,
                        on_waiting=_on_waiting, on_admitted=_on_admitted)


def _notify_br_async_terminal(db, execution_id: str, status: str) -> None:
    """Tell the user their report finished — durably, not just on the wire.

    2026-08-31.  Completion only ever broadcast over the WebSocket, and the
    viewer's listener requires ``msg.report_id === reportId`` — so the news
    reached exactly one place: the report page you were already looking at.
    Open a different report, switch tabs, or simply walk away, and a run
    that took twelve minutes finished in silence.  "Start it, go and do
    something else, get told when it is ready" was not implemented at all.

    This writes a NotificationLog row on the ``websocket`` channel, which is
    what ``GET /api/notifications`` and the bell in Layout read, so the news
    survives navigation, a reload and a closed tab.  The WS broadcast stays:
    it is the instant path for someone who IS watching, and this is the
    durable one for everyone else.

    FAIL-OPEN and quiet: a notification is a courtesy, and losing one must
    never fail the job write it rides on.
    """
    if status not in ("completed", "failed"):
        # "cancelled" is excluded deliberately: the user pressed the button,
        # so telling them what they just did is noise, not news.
        return
    try:
        row = db.get_br_async_job(execution_id) or {}
        username = row.get("username") or row.get("created_by")
        report_id = row.get("report_id")
        if not username:
            # A notification with no recipient is a wiring bug, not a quiet
            # no-op — say so once rather than returning in silence.
            logger.info("[br-async] %s finished (%s) but the job row records "
                        "no user, so nobody was notified",
                        execution_id, status)
            return
        name = ""
        try:
            rep = db.get_business_report(report_id) if report_id else None
            name = (rep or {}).get("name") or ""
        except Exception:
            name = ""
        label = name or f"Report {report_id}"
        if status == "completed":
            title = f"{label} is ready"
            message = (f"{label} finished running. Open it to view the "
                       f"results and drill down.")
        else:
            title = f"{label} failed"
            message = (f"{label} did not finish. Open it to see the error "
                       f"and try again.")
        db.log_notification(
            event_type=f"report_execution_{status}",
            channel="websocket",
            recipient=username,
            status="sent",
            title=title,
            message=message,
            execution_id=execution_id,
            payload={"report_id": report_id, "execution_id": execution_id,
                     "status": status},
        )
    except Exception as exc:
        logger.debug("[br-async] could not record the completion "
                     "notification for %s (the job write is unaffected): %s",
                     execution_id, exc)


def _finalize_br_async_job_guarded(db, execution_id: str, **fields) -> bool:
    """The ONE terminal-write door for the async runners (D4).

    Writes the terminal state, and — when that write actually LANDED — raises
    the user's completion notification.  Both live here so that every path
    which can finish a job notifies: the three runners, and the orphan sweep.
    A notification wired into two of three runners is precisely the
    divergence this codebase keeps producing.

    The order matters.  The notification is raised only on a True return, so
    a job the user cancelled (suppressed write, False) never announces a
    completion the user already stopped.
    """
    landed = _finalize_br_async_job_write(db, execution_id, **fields)
    if landed:
        _notify_br_async_terminal(db, execution_id, fields.get("status") or "")
        # 2026-09-28 -- a COMPLETED async run records the readiness it was
        # served under (the SLO's evidence); failed / cancelled record nothing.
        if (fields.get("status") or "") == "completed":
            try:
                _job = db.get_br_async_job(execution_id) or {}
                _record_async_readiness(db, execution_id, _job.get("created_by"))
            except Exception as _rd_exc:              # noqa: BLE001
                logger.warning("[readiness] async run %s: verdict not recorded: %s",
                               execution_id, _rd_exc)
    return landed


# ── Phase 81: Async Execution ─────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/execute-async")
async def execute_report_async(report_id: int, body: AsyncExecuteRequest,
                                user: dict = Depends(require_capability("reports.view", identity=get_current_user_or_service_key))):
    """Start async report execution. Returns execution_id + status='running'.

    Phase 81: Client polls GET /execution/{exec_id}/status and fetches results when completed.

    2026-09-10: the ONE route Clockwork's ``qs_api`` task calls for a
    report, so it takes ``get_current_user_or_service_key`` -- an
    ``X-API-Key`` principal ONLY while ``auth.reports_service_api_key``
    is on (default off); the ``can_view`` gate below applies to it
    unchanged.  Every other report route keeps ``get_current_user``.
    """
    db = _require_db()
    fed = _require_federation()
    from core import config as _cfg

    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    # Phase 131 deep-dive #10: replaced 3 duplicated access checks with
    # the shared core.entitlements.can_view helper (DRY).  Now honors
    # owner_group_id (group-based access) in addition to is_published /
    # owner / admin-tier semantic.
    if not _br_can_view(report, user):
        raise HTTPException(status_code=403, detail="Access denied")

    # ── Publish lifecycle (2026-08-17) — same fork as the sync path ──────
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, user)
    # 2026-11-02 -- a default RULE (latest with data, ...) applies to a run that sent no value
    body.parameter_values = await _fill_rule_defaults_or_409(db, report, body.parameter_values, user)
    # 2026-09-28 -- readiness at SUBMIT (it is about the data, not the run):
    # stamped on the hand-off and on an instance serve, remembered by
    # execution id so the terminal write records it once the run completes.
    _async_rd = _arm_readiness(
        await asyncio.to_thread(_readiness_for_execute, db, report,
                                body.parameter_values, report_id),
        db, username, "interactive-async")

    # ── Phase 2 report-instance layer (2026-08-09) ───────────────────────
    # Same preconditions + fail-closed serve as the sync path.  A hit
    # returns status="completed" immediately: try_serve_instance registered
    # a completed job row under the returned execution_id, so the standard
    # status-poll / paged-results flow works unchanged for the caller.
    _instance_cacheable = _instance_cacheable_for(body)
    if (_instance_cacheable and _wants_instance_serve(body)
            and _cfg.business_reports.instance_serving_enabled):
        _inst_wire = await asyncio.to_thread(
            try_serve_instance, db, report, user, body.parameter_values,
            row_limit=_resolve_report_row_limit(None, report, _cfg),
            surface="interactive-async")
        if _inst_wire is not None:
            return await _astamp_served_version(
                {"execution_id": _inst_wire.get("execution_id"),
                 "status": "completed",
                 "served_from_instance": True,
                 "instance": _inst_wire.get("instance"),
                 "as_of": _inst_wire.get("as_of"),
                 "freshness": _inst_wire.get("freshness"),
                 "stale": _inst_wire.get("stale"),
                 "refresh_queued": _inst_wire.get("refresh_queued")},
                _served_version)

    execution_id = "br_" + str(uuid.uuid4()).replace("-", "")[:24]
    _remember_async_readiness(execution_id, _async_rd)

    # Phase 100: published_view async — PV results are already cached, run inline
    if (report.get("data_source_type") or "saved_query") == "published_view":
        pv_id = report.get("published_view_id")
        if not pv_id:
            raise HTTPException(400, "Report has data_source_type='published_view' but no published_view_id")
        if not _cfg.business_reports.enable_published_view_source:
            raise HTTPException(400, "Published View data source is disabled by configuration")
        pv = await _adb(db.get_published_view, pv_id)
        if not pv:
            raise HTTPException(404, f"Published view {pv_id} not found")
        if not pv.get("is_active"):
            raise HTTPException(400, "Published view is inactive")

        await _adb(db.create_br_async_job, execution_id, report_id, username)
        _br_cache_set(execution_id, {"report_id": report_id, "result": None})
        pv_params = await _adb(_map_report_params_to_pv, report, body.parameter_values, db, report_id)
        pv_row_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)

        async def _run_pv():
            try:
                await _adb(db.update_br_async_job, execution_id, progress_pct=10)
                # D4 (2026-08-30): observe cancellation before the engine
                # starts — a job cancelled between submit and this boundary
                # never runs.
                if await _adb(_br_job_cancelled, db, execution_id):
                    logger.info("[br-async] %s cancelled before PV execution — run skipped", execution_id)
                    _br_cache_pop(execution_id)
                    return
                from api.published_views_api import _execute_view
                from core.reports.admission import capacity_wait_scope
                # 2026-08-05: same RLS-principal threading as the sync path.
                # 2026-09-28: a view over a business report reaches the
                # REPORT gate inside _execute_view's plugin registry, which
                # carries no argument for it -- the wait is armed by scope
                # (task-local), so this admitted async run waits for
                # capacity like the other two runners.
                with capacity_wait_scope(_async_capacity_wait(db, execution_id)):
                    res_dict = _public_view_result(await _execute_view(
                        pv=pv, filters=[], columns=None,
                        sort_column=None, sort_dir="asc",
                        limit=pv_row_limit, offset=0, params=pv_params,
                        consumer_user=user,
                    ))
                # Phase 0 reports rewire (2026-08-08): PV/FV artifact parity —
                # additive artifact + execution registration, and the job row
                # now carries output_path (raw_sql async parity) so paged
                # retrieval survives cache eviction / restart.
                _artifact_path = await asyncio.to_thread(
                    _persist_inline_result_artifact, db, report, res_dict,
                    username, execution_id)
                # 2026-08-05: stamp contract keys (row_limit/truncated) into the
                # cached result so the paged-results endpoint can disclose
                # truncation to the viewer; also emits the [br-serve] line.
                _with_contract_keys(res_dict, "published_view", pv_row_limit,
                                    log_ctx={"report_id": report_id,
                                             "user": username,
                                             "surface": "interactive-async"})
                _br_cache_set(execution_id, {"report_id": report_id, "result": res_dict})
                # D4: guarded terminal write — never resurrects a
                # cancelled job (and skips the side effects when suppressed).
                if not await _adb(_finalize_br_async_job_guarded, db,
                                  execution_id, status="completed",
                                  progress_pct=100,
                                  total_rows=res_dict.get("total_rows", 0),
                                  output_path=_artifact_path):
                    _br_cache_pop(execution_id)
                    return
                await _adb(db.increment_business_report_execution, report_id)
                # Phase 2 (2026-08-09): instance write-through — fail-open +
                # flag-gated inside the chokepoint.  D1/D2: res_dict was
                # already stamped by _with_contract_keys above, so the
                # facts recorded are the facts the live response wired.
                if _instance_cacheable and _artifact_path and isinstance(res_dict, dict):
                    await asyncio.to_thread(
                        record_report_instance, db, report, user,
                        body.parameter_values,
                        execution_id=execution_id,
                        artifact_path=_artifact_path,
                        row_count=res_dict.get("total_rows"),
                        **truncation_facts(res_dict, pv_row_limit))
                logger.info("Async PV report execution completed (exec_id=%s, report_id=%d)", execution_id, report_id)
            except _CapacityWaitCancelled:
                # 2026-09-28: cancelled while waiting for capacity -- the
                # row already says so; nothing terminal to write.
                logger.info("[br-async] %s cancelled while waiting for capacity (PV)", execution_id)
                _br_cache_pop(execution_id)
            except Exception as exc:
                from core.error_sanitizer import sanitize_error as _se
                logger.error("Async PV report execution failed (exec_id=%s): %s", execution_id, _se(str(exc)))
                # D4: "failed" must not overwrite a user's cancel either.
                await _adb(_finalize_br_async_job_guarded, db, execution_id,
                           status="failed", error=_se(str(exc)))

        # BF-594: strong-ref track (Python issue #88831).
        from core.bg_tasks import track_bg_task as _track_bg_task_br
        _track_bg_task_br(_run_pv())
        return await _astamp_served_version(
            {"execution_id": execution_id, "status": "running"},
            _served_version)

    # Phase 111: raw_sql async — run parametric engine in background thread
    if (report.get("data_source_type") or "saved_query") == "raw_sql":
        await _adb(db.create_br_async_job, execution_id, report_id, username)
        _br_cache_set(execution_id, {"report_id": report_id, "result": None})

        async def _run_raw():
            try:
                await _adb(db.update_br_async_job, execution_id, progress_pct=10)
                # D4 (2026-08-30): observe cancellation before the engine
                # starts.  A call already inside the engine cannot be
                # interrupted — cancellation lands at the next boundary.
                if await _adb(_br_job_cancelled, db, execution_id):
                    logger.info("[br-async] %s cancelled before raw_sql execution — run skipped", execution_id)
                    _br_cache_pop(execution_id)
                    return
                # 2026-09-15: REPORT admission gate (typed pool slot), not
                # the default executor.  A refusal lands in the except
                # below as a failed job carrying the reason.
                from core.reports.admission import run_admitted as _run_admitted_raw
                from core.worker_pool import WorkType as _WT_raw
                res_dict = await _run_admitted_raw(
                    _WT_raw.REPORT, _execute_raw_sql_report,
                    report, body.parameter_values, body.limit_override,
                    report_id, db, role, user_ctx=user,
                    execution_id=execution_id, username=username,
                    capacity_wait=_async_capacity_wait(db, execution_id))
                # 2026-08-05: stamp contract keys into the cached result
                # (truncation disclosure via paged results) + [br-serve] line.
                _with_contract_keys(
                    res_dict, "raw_sql",
                    _resolve_report_row_limit(body.limit_override, report, _cfg),
                    log_ctx={"report_id": report_id, "user": username,
                             "surface": "interactive-async"})
                _br_cache_set(execution_id, {"report_id": report_id, "result": res_dict})
                # D4: guarded terminal write — never resurrects a
                # cancelled job (and skips the side effects when suppressed).
                if not await _adb(_finalize_br_async_job_guarded, db,
                                  execution_id, status="completed",
                                  progress_pct=100,
                                  total_rows=res_dict.get("total_rows", 0),
                                  output_path=res_dict.get("output_path")):
                    _br_cache_pop(execution_id)
                    return
                # Phase 2 (2026-08-09): instance write-through (see PV runner).
                # D1/D2: res_dict already carries the stamped contract keys.
                if _instance_cacheable and isinstance(res_dict, dict) and res_dict.get("execution_id"):
                    await asyncio.to_thread(
                        record_report_instance, db, report, user,
                        body.parameter_values,
                        execution_id=res_dict.get("execution_id"),
                        artifact_path=(res_dict.get("output_path") or None),
                        row_count=res_dict.get("total_rows"),
                        **truncation_facts(
                            res_dict,
                            _resolve_report_row_limit(
                                body.limit_override, report, _cfg)))
                logger.info("Async raw_sql report completed (exec_id=%s, report_id=%d)", execution_id, report_id)
            except _CapacityWaitCancelled:
                # 2026-09-28: cancelled while waiting for capacity -- the
                # row already says so; nothing terminal to write.
                logger.info("[br-async] %s cancelled while waiting for capacity (raw_sql)", execution_id)
                _br_cache_pop(execution_id)
            except _ReportAdmissionRefused as _ref:
                # 2026-09-15: refused at the gate — the reason is caller-safe
                # by construction (it names a cap) and is recorded VERBATIM
                # on the job so the poller sees why, not a generic failure.
                logger.warning("[br-admission] async raw_sql execution %s refused: %s",
                               execution_id, _ref.reason)
                await _adb(_finalize_br_async_job_guarded, db, execution_id,
                           status="failed", error=_ref.reason)
            except Exception as exc:
                from core.error_sanitizer import sanitize_error as _se
                logger.error("Async raw_sql report failed (exec_id=%s): %s", execution_id, _se(str(exc)))
                # D4: "failed" must not overwrite a user's cancel either.
                await _adb(_finalize_br_async_job_guarded, db, execution_id,
                           status="failed", error=_se(str(exc)))

        from core.bg_tasks import track_bg_task as _track_bg_task_br_raw
        _track_bg_task_br_raw(_run_raw())
        return await _astamp_served_version(
            {"execution_id": execution_id, "status": "running"},
            _served_version)

    # Phase 83A: persist to DB instead of in-memory dict
    await _adb(db.create_br_async_job, execution_id, report_id, username)
    _br_cache_set(execution_id, {"report_id": report_id, "result": None})

    combined_filters = await _adb(_build_report_filters, report, body.parameter_values, db,
                                              report_id, body.extra_filters)
    _async_src_bindings = await _adb(_build_source_bindings, report, body.parameter_values, db, report_id)
    row_limit = _resolve_report_row_limit(body.limit_override, report, _cfg)

    # Phase 106: detect pivot report for async path
    _async_lc = report.get("layout_config") or {}
    _async_is_pivot = _async_lc.get("report_type") == "pivot"
    _async_override_cols = body.override_column_ids
    _async_force_live = bool(getattr(body, "force_refresh", False))   # FB-36
    report = _with_data_version(report, getattr(body, "data_version", None), user, db, report_id)  # 2026-11-01

    async def _ws_broadcast(msg: dict):
        """Best-effort user-scoped WS broadcast for report execution progress."""
        try:
            if _ws_manager:
                await _ws_manager.broadcast_to_user(username, msg)
        except Exception:
            pass  # WS is best-effort; never block execution

    async def _run():
        try:
            await _adb(db.update_br_async_job, execution_id, progress_pct=10)
            # D4 (2026-08-30): observe cancellation before the engine starts.
            if await _adb(_br_job_cancelled, db, execution_id):
                logger.info("[br-async] %s cancelled before execution — run skipped", execution_id)
                _br_cache_pop(execution_id)
                return
            await _ws_broadcast({"type": "report_execution_started", "execution_id": execution_id,
                                 "report_id": report_id, "username": username})
            # 2026-09-15: REPORT admission gate — a typed, bounded pool
            # slot on a wp- thread instead of the default executor every
            # adb() call shares.  A refusal is handled below as a failed
            # job carrying the reason (never a silent hang).
            from core.reports.admission import run_admitted as _run_admitted
            from core.worker_pool import WorkType as _WT
            # 2026-09-28: an admitted async run WAITS for global capacity
            # (bounded) instead of failing the moment the SQL editor is busy.
            _cap_wait = _async_capacity_wait(db, execution_id)
            if _async_is_pivot:
                result = await _run_admitted(
                    _WT.REPORT, _run_pivot_report_query,
                    fed, report, combined_filters, row_limit, execution_id, role,
                    user_ctx=user, force_refresh=_async_force_live,   # FB-36
                    source_bindings=_async_src_bindings,
                    execution_id=execution_id, username=username,
                    capacity_wait=_cap_wait)
            else:
                result = await _run_admitted(
                    _WT.REPORT, _run_report_query,
                    fed, report, combined_filters, row_limit, execution_id, role,
                    override_column_ids=_async_override_cols, user_ctx=user,
                    force_refresh=_async_force_live,                  # FB-36
                    source_bindings=_async_src_bindings,
                    execution_id=execution_id, username=username,
                    capacity_wait=_cap_wait)
            res_dict = result.to_dict() if hasattr(result, "to_dict") else result
            # Phase 106: include pivot_config in async result so frontend knows how to render
            if _async_is_pivot and isinstance(res_dict, dict):
                res_dict["pivot_config"] = _async_lc.get("pivot_config")
            # 2026-08-05: stamp contract keys into the cached result
            # (truncation disclosure via paged results) + [br-serve] line.
            _with_contract_keys(res_dict, "saved_query", row_limit,
                                log_ctx={"report_id": report_id,
                                         "user": username,
                                         "surface": "interactive-async"})
            existing = _br_results_cache.get(execution_id)
            if existing:
                existing["result"] = res_dict
                _br_results_cache.set(execution_id, existing)
            total = res_dict.get("total_rows", 0)
            # D4: guarded terminal write — never resurrects a cancelled job
            # (and skips the side effects + WS broadcast when suppressed).
            if not await _adb(_finalize_br_async_job_guarded, db,
                              execution_id, status="completed",
                              progress_pct=100, total_rows=total,
                              output_path=res_dict.get("output_path")):
                _br_cache_pop(execution_id)
                return
            await _adb(db.increment_business_report_execution, report_id)
            await asyncio.to_thread(_run_diagnostics.record_report_run, db, report=report, report_id=report_id, execution_id=execution_id, param_values=body.parameter_values, combined_filters=combined_filters, source_bindings=_async_src_bindings, result=res_dict, username=username, surface="interactive-async")  # 2026-10-30 Diagnostics panel
            # Phase 2 (2026-08-09): instance write-through (see PV runner).
            # D1/D2: res_dict already carries the stamped contract keys.
            if _instance_cacheable and isinstance(res_dict, dict) and res_dict.get("output_path"):
                await asyncio.to_thread(
                    record_report_instance, db, report, user,
                    body.parameter_values,
                    execution_id=execution_id,
                    artifact_path=res_dict.get("output_path"),
                    row_count=res_dict.get("total_rows"),
                    iceberg_versions=res_dict.get("iceberg_versions"),      # 2026-11-01
                    **truncation_facts(res_dict, row_limit))
            logger.info("Async report execution completed (exec_id=%s, report_id=%d)", execution_id, report_id)
            await _ws_broadcast({"type": "report_execution_completed", "execution_id": execution_id,
                                 "report_id": report_id, "total_rows": total, "username": username})
        except _CapacityWaitCancelled:
            # 2026-09-28: cancelled while waiting for capacity -- the row
            # already says so; nothing terminal to write, nothing to announce.
            logger.info("[br-async] %s cancelled while waiting for capacity", execution_id)
            _br_cache_pop(execution_id)
        except _ReportAdmissionRefused as _ref:
            # 2026-09-15: refused at the gate.  The reason names a cap (no
            # secret, no path) and is recorded VERBATIM so the poller and
            # the WS listener see WHY — a queue-full is not an engine error.
            logger.warning("[br-admission] async execution %s refused: %s",
                           execution_id, _ref.reason)
            if await _adb(_finalize_br_async_job_guarded, db, execution_id,
                          status="failed", error=_ref.reason):
                await _ws_broadcast({"type": "report_execution_failed", "execution_id": execution_id,
                                     "report_id": report_id, "error": _ref.reason, "username": username})
        except Exception as exc:
            from core.error_sanitizer import sanitize_error as _se
            _safe_err = _se(str(exc))
            logger.error("Async report execution failed (exec_id=%s): %s", execution_id, _safe_err)
            # D4: "failed" must not overwrite a user's cancel either — and a
            # cancelled job broadcasts nothing (the user already ended it).
            if await _adb(_finalize_br_async_job_guarded, db, execution_id,
                          status="failed", error=_safe_err):
                await _ws_broadcast({"type": "report_execution_failed", "execution_id": execution_id,
                                     "report_id": report_id, "error": _safe_err, "username": username})

    from core.bg_tasks import track_bg_task as _track_bg_task_br_main
    _track_bg_task_br_main(_run())
    return await _astamp_served_version(
        {"execution_id": execution_id, "status": "running"}, _served_version)


def _check_async_exec_access(db, entry: dict, user: dict):
    """Verify current user can access this async execution.

    Allowed: execution creator (``created_by == username``), report owner, or
    admin — and NOTHING else.

    SECURITY (RLS result-retrieval leak, 2026-07-17): a completed execution
    serves CACHED PARQUET computed at the ORIGINAL executor's row-security
    scope.  Publishing a report must let a user RUN it (creating their OWN
    execution) and read THEIR OWN result — it must NOT grant any authenticated
    viewer the right to read ANOTHER user's cached rows.  The old
    ``is_published`` allow-any branch let a low-privilege viewer read a
    high-privilege user's execution result and bypass their own row-security
    (same class as the F1 scheduler bypass, commit bc5a639).  Fail CLOSED:
    ambiguity → 403.
    """
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if username and role in ADMIN_TIER_ROLES:
        return
    # The user who created this execution may read it back.
    if username and entry.get("created_by") == username:
        return
    # The report owner may read any execution of their report.
    report = db.get_business_report(entry.get("report_id"))
    if report and username and report.get("owner") == username:
        return
    # Published no longer grants cross-user READ access to a foreign
    # execution's cached rows — publishing only lets a user RUN the report
    # and read the execution THEY created (handled above).
    raise HTTPException(status_code=403, detail="Access denied to this execution")


@router.get("/api/business-reports/{report_id}/execution/{exec_id}/status")
async def get_async_execution_status(report_id: int, exec_id: str,
                                      user: dict = Depends(require_capability("reports.view"))):
    """Poll async execution status. Phase 81+83A."""
    db = _require_db()
    # D3 (2026-08-30): opportunistic orphan sweep — bounded, stampede-guarded
    # (per-process interval gate), fail-safe.  No daemon on an API pod.
    await _adb(_sweep_orphaned_br_async_jobs, db)
    entry = await _adb(db.get_br_async_job, exec_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Execution not found or expired")
    if entry.get("report_id") != report_id:
        raise HTTPException(status_code=404, detail="Execution not found for this report")
    # Ownership check: only the creator, report owner, or admin can poll.
    # 2026-10-07: off the loop -- a non-creator's check reads the report row,
    # and this route is POLLED (every 0.3-2 s per open viewer).
    await _adb(_check_async_exec_access, db, entry, user)
    # D3 targeted check: the POLLED row itself, independent of the batch
    # sweep's interval gate — the "running forever" symptom dies on the
    # first poll past the staleness bound.
    if entry.get("status") == "running":
        if await _adb(_mark_job_orphaned, db, entry,
                      _br_running_stale_after_seconds()):
            entry = await _adb(db.get_br_async_job, exec_id) or entry
    total = entry.get("total_rows")
    resp = {
        "execution_id": exec_id,
        "status": entry["status"],
        "progress_pct": entry.get("progress_pct", 0),
        "rows_ready": total or 0,
        "total_rows": total,
        "error": entry.get("error"),
        # 2026-09-28: a running job that is admitted and waiting for the
        # pod's global query capacity says so (see _async_capacity_wait);
        # status_detail is the sentence, cleared once it runs.
        "waiting_for_capacity": entry.get("waiting_for") == "capacity",
        "status_detail": entry.get("status_detail"),
    }
    # 2026-09-05 PROGRESSIVE — how a client learns it can start paging, and
    # when it can stop.  A running partitioned scan has durable parts long
    # before it finishes; nothing in this payload could say so, and
    # ``rows_ready: 0`` on a running job reads as "ran and found nothing"
    # rather than "not counted yet".  Manifest-only (no part is opened), so
    # polling it costs one small JSON read.  Additive and fail-open: absent
    # keys mean there is no parts dataset, which is every report that does
    # not declare a partition column.
    try:
        from core.reports.pagination import (expected_report_artifact,
                                             parts_progress)
        _apath = expected_report_artifact(exec_id)
        # 2026-10-07: a stat + a dir probe (+ a manifest read) on the shared
        # downloads dir -- NFS in production -- ran INLINE on the event loop
        # on every poll: the largest stall source measured in-process for
        # the business-report lane.  Off the loop now.
        _pprog = (await _adb(parts_progress, _apath)) if _apath is not None else None
        if _pprog:
            resp.update(_pprog)
    except Exception as _pg_exc:
        logger.debug("progressive status disclosure skipped (fail-open): %s",
                     _pg_exc)
    # 2026-08-09 reports rewire Phase 3 — the presentation-engine verdict.
    # The viewer reads statusRes.engine to decide whether to drive /cube or
    # keep using the browser engine.  The sync path gets this via
    # ReportEnvelope; the ASYNC path builds its own dict, so without this the
    # verdict never reaches the client and every async execution silently
    # stays on the browser engine (its ~250-300K row ceiling included).
    # Same chokepoint as the envelope property — never a second copy of the
    # rule.  Fail-open: any hiccup simply omits the key, and the viewer
    # degrades to client mode when it is absent.
    try:
        from core.reports.contract import engine_for_rows as _engine_for_rows
        resp["engine"] = _engine_for_rows(total)
    except Exception as _eng_exc:
        logger.debug("async status engine verdict skipped (fail-open): %s", _eng_exc)
    # Completeness Certificate (Phase 4) — best-effort, fail-open, omitted when absent.
    try:
        from core.query_diagnostic_store import get_pruning as _get_pruning
        _cert_d = (_get_pruning(exec_id) or {}).get("completeness_certificate")
        if _cert_d:
            resp["certificate"] = _cert_d
    except Exception as _cert_exc:
        logger.debug("async status certificate surface skipped (fail-open): %s", _cert_exc)
    # Progressive-scan verdict (2026-09-05) -- the SAME lift, on the same
    # terms, at every place the certificate is lifted.  The async lane is
    # where a long partitioned build is actually watched, so leaving it to
    # the sync envelope alone would be the one-of-two-twins shape.
    try:
        from core.reports.scan_verdict import scan_verdict_keys
        resp.update(scan_verdict_keys(exec_id))
    except Exception as _scan_exc:
        logger.debug("async status scan verdict skipped (fail-open): %s",
                     _scan_exc)
    # 2026-09-28 -- the readiness verdict remembered at submit, so the
    # viewer's poll result carries the same key the sync envelope does.
    _rd = _async_readiness.get(str(exec_id))
    if _rd is not None:
        resp["readiness"] = _rd.to_dict()
    # 2026-11-01 -- the versions the run READ (core/iceberg_versions.py:
    # table, version, commit time, which rule decided), the key the sync
    # envelope carries, so the viewer's header names them after an async run
    # too.  The finished result is held by the process that ran it; a poll
    # answered elsewhere omits the key (the header then says nothing).
    try:
        _done = (_br_results_cache.get(str(exec_id)) or {}).get("result") or {}
        if isinstance(_done, dict) and _done.get("iceberg_versions") is not None:
            resp["iceberg_versions"] = list(_done["iceberg_versions"])
    except Exception as _iv_exc:                              # noqa: BLE001
        logger.debug("async status iceberg_versions skipped (fail-open): %s", _iv_exc)
    return resp


@router.get("/api/business-reports/{report_id}/execution/{exec_id}/result")
async def get_async_execution_result(
    report_id: int,
    exec_id: str,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=0, ge=0),
    sort_column: Optional[str] = Query(default=None),
    sort_direction: Optional[str] = Query(default=None, pattern="^(asc|desc)$"),
    dataset_version: Optional[str] = Query(
        default=None,
        description="Echo the dataset_version a previous page returned to keep "
                    "paging the SAME snapshot of a still-building result. A "
                    "snapshot that no longer exists is a 409, never a silent "
                    "splice."),
    user: dict = Depends(require_capability("reports.view")),
):
    """Fetch result rows for a completed async execution (with pagination + sorting). Phase 81+83A."""
    from core import config as _cfg
    db = _require_db()
    entry = await _adb(db.get_br_async_job, exec_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Execution not found or expired")
    if entry.get("report_id") != report_id:
        raise HTTPException(status_code=404, detail="Execution not found for this report")
    await _adb(_check_async_exec_access, db, entry, user)
    if entry["status"] != "completed":
        # 2026-09-05 PROGRESSIVE — an execution that is STILL RUNNING can have
        # durable parts.  Only reachable when they exist; otherwise the 409
        # below is unchanged, so "not yet complete" keeps meaning exactly what
        # it means today for every report that produces no parts.
        #
        # A FAILED or CANCELLED run is deliberately excluded even when parts
        # survive it (the engine removes them, but a pod that died mid-build
        # leaves them behind).  Those parts are the evidence of an incomplete
        # run; serving them as a result would present the fragment a crash
        # left as the report's answer.
        _prog = None
        if entry["status"] in ("running", "pending"):
            _prog = await asyncio.to_thread(
                _progressive_page_for_execution, exec_id, page, page_size,
                sort_column, sort_direction, _cfg, dataset_version)
        if _prog is not None:
            return _prog
        raise HTTPException(status_code=409, detail=f"Execution not yet complete (status={entry['status']})")

    # Get result from in-memory cache first, or rebuild from output_path
    cache_entry = _br_cache_get(exec_id)
    result = cache_entry.get("result")
    if not result and entry.get("output_path"):
        result = {"output_path": entry["output_path"], "total_rows": entry.get("total_rows", 0)}
    if not result:
        raise HTTPException(status_code=404, detail="Result data no longer available (process restarted)")
    # 2026-08-09 — carry an INSTANCE's stored truncation facts onto its pages.
    #
    # paginate_result passes `row_limit`/`truncated` through when the source
    # result carries them, and never fabricates them.  But the rebuild above
    # (the only path once the process-local cache is gone — i.e. always, on
    # another pod) yields ONLY output_path + total_rows, so both keys are
    # ABSENT and the viewer renders no truncation banner.  To a user, no
    # banner reads as "this is the whole result" — the same silent-truncation
    # failure D1 fixed, arriving by omission instead of by assertion.
    #
    # A served instance persists the engine's verdict (row_limit / truncated /
    # unstable_truncation) on its ReportInstance row, so read it back rather
    # than recomputing: recomputation against the report's own limit is
    # exactly what resurrected D1 through the serve.  Absent stays absent —
    # UNKNOWN is disclosed as unknown, never coerced to complete.
    try:
        if result.get("row_limit") is None and "truncated" not in result:
            # Keyed on the ARTIFACT: a serve registers its job row under a
            # fresh ri_ id owned by the caller, so the execution ids differ by
            # design and the artifact path is what they share.
            _inst = await _adb(db.find_report_instance_by_artifact,
                               result.get("output_path") or "")
            if _inst:
                if _inst.get("row_limit") is not None:
                    result["row_limit"] = _inst["row_limit"]
                if _inst.get("truncated") is not None:
                    result["truncated"] = _inst["truncated"]
                if _inst.get("unstable_truncation") is not None:
                    result["unstable_truncation"] = _inst["unstable_truncation"]
    except Exception as _tf_exc:
        logger.debug("instance truncation facts unavailable for %s (fail-open): %s",
                     exec_id, _tf_exc)
    # Engine-pushed pagination off the event loop (never a full-result sort inline).
    paginated = await asyncio.to_thread(
        _paginate_result, result, page, page_size, sort_column, sort_direction,
        _cfg, dataset_version)
    # 2026-08-29 — carry ``unstable_truncation`` onto the page.  The core
    # paginator passes ``row_limit``/``truncated`` through but not this key,
    # so the backfill above read it off the stored instance and then LOST it
    # before the wire — the viewer (BusinessReportViewer reads
    # ``pageRes.unstable_truncation``) never saw the "kept rows are not
    # stable" disclosure on the async result route.  Same convention as the
    # other contract keys: present only when known, never fabricated.
    if (isinstance(paginated, dict) and "unstable_truncation" not in paginated
            and isinstance(result, dict)
            and result.get("unstable_truncation") is not None):
        paginated["unstable_truncation"] = result.get("unstable_truncation")
    # Completeness Certificate (Phase 4) — best-effort, fail-open, omitted when absent.
    try:
        if isinstance(paginated, dict):
            from core.query_diagnostic_store import get_pruning as _get_pruning
            _cert_d = (_get_pruning(exec_id) or {}).get("completeness_certificate")
            if _cert_d:
                paginated["certificate"] = _cert_d
    except Exception as _cert_exc:
        logger.debug("async result certificate surface skipped (fail-open): %s", _cert_exc)
    # Progressive-scan verdict (2026-09-05) -- see the status route above.
    # A viewer that goes straight to the rows must be able to read why the
    # run it is looking at was built the way it was.
    try:
        if isinstance(paginated, dict):
            from core.reports.scan_verdict import scan_verdict_keys
            paginated.update(scan_verdict_keys(exec_id))
    except Exception as _scan_exc:
        logger.debug("async result scan verdict skipped (fail-open): %s",
                     _scan_exc)
    return paginated


@router.delete("/api/business-reports/{report_id}/execution/{exec_id}")
async def cancel_async_execution(report_id: int, exec_id: str,
                                  user: dict = Depends(require_capability("reports.edit"))):
    """Cancel/discard an async execution entry. Phase 81+83A."""
    db = _require_db()
    entry = await _adb(db.get_br_async_job, exec_id)
    if not entry or entry.get("report_id") != report_id:
        raise HTTPException(status_code=404, detail="Execution not found")
    await _adb(_check_async_exec_access, db, entry, user)
    await _adb(db.update_br_async_job, exec_id, status="cancelled")
    _br_cache_pop(exec_id)
    # 2026-10-30: stop the WORK, not only the row -- the run's cancel event
    # reaches the connector's watchdog (Trino: cancelled at the coordinator)
    # and frees its slot.  Another replica's run is reached by the cancel
    # watcher's sweep of cancelled report runs (get_cancel_requested_executions).
    from core.cancel_router import signal_local_cancel
    signal_local_cancel(exec_id)
    return {"detail": "cancelled"}


@router.get("/api/business-reports/{report_id}/execution-history")
async def get_execution_history(
    report_id: int,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    user: dict = Depends(require_capability("reports.view")),
):
    """Paginated execution history for a business report."""
    db = _require_db()
    # D3 (2026-08-30): opportunistic orphan sweep on the list path too.
    await _adb(_sweep_orphaned_br_async_jobs, db)
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    is_owner_or_admin = (username and report.get("owner") == username) or \
        (username and role in ADMIN_TIER_ROLES)
    # SECURITY (RLS enumeration guard, 2026-07-17): only owner/admin may see
    # the FULL history.  A viewer of a PUBLISHED report may see only THEIR OWN
    # executions (created_by == username) so they can't enumerate another
    # user's execution_id and then fetch that user's RLS-scoped cached rows.
    # Anyone else (non-owner on a non-published report) is denied.  Fail-closed.
    if is_owner_or_admin:
        scope_created_by = None          # full history
    elif username and report.get("is_published"):
        scope_created_by = username      # own executions only
    else:
        raise HTTPException(status_code=403, detail="Access denied")
    return await _adb(db.list_br_execution_history, report_id, page=page,
                      page_size=page_size, created_by=scope_created_by)


# ── Phase 81: Paginated results endpoint for synchronous executions ───────────

def _paginate_result(result: dict, page: int, page_size: int,
                     sort_column: Optional[str], sort_direction: Optional[str],
                     cfg, dataset_version: Optional[str] = None) -> dict:
    """Apply server-side pagination and optional column sorting to a result dict.

    Phase 81 FIX 2+3: supports ?page=N&page_size=M&sort_column=X&sort_direction=asc|desc.

    2026-08-04 strategic redesign: delegates to the engine-pushed paginator
    (``core.reports.pagination.paginate_result``) — sort/limit/offset run
    inside DuckDB and only the requested PAGE is materialised in Python.
    The previous body read + fully sorted the ENTIRE parquet in pandas per
    page request, on the event loop — the same class that starved /health.
    Sync by design; async endpoints call it via ``asyncio.to_thread``.

    ``dataset_version`` (2026-09-05) is the progressive-serving pin — the
    value a previous page of the same paging session returned.  It only means
    anything while the result is still a growing parts dataset; a pin that no
    longer names a servable snapshot becomes a 409 here rather than a page of
    somebody else's snapshot.
    """
    from core.reports.pagination import paginate_result as _core_paginate
    _page = _core_paginate(result, page, page_size, sort_column, sort_direction,
                           cfg, dataset_version=dataset_version)
    # 2026-09-05 progressive serving — the pin named a snapshot this result no
    # longer is.  409 rather than "here are some rows": page N and page N+1 of
    # one paging session must come from ONE prefix, and answering a question
    # asked about snapshot A with snapshot B's rows is exactly the silent
    # splice this contract exists to make impossible.  The REASON travels,
    # because the two cases lead to opposite actions.
    if isinstance(_page, dict) and _page.get("pin_stale"):
        _reason = str(_page.get("pin_stale_reason") or "rebuilt")
        _msg = ("Every chunk of this result has been merged into the single "
                "result file, so the partial snapshot your page was reading no "
                "longer exists. Re-request this page without dataset_version to "
                "read the merged result."
                if _reason == "consolidated" else
                "This result was rebuilt since your page cursor was issued — "
                "continuing would splice rows from two different runs. "
                "Re-request this page without dataset_version.")
        raise HTTPException(
            status_code=409,
            detail={"error": "result_snapshot_moved",
                    "reason": _reason,
                    "message": _msg,
                    "consolidated": bool(_page.get("consolidated")),
                    "requested_dataset_version":
                        _page.get("requested_dataset_version")},
        )
    # 2026-08-09 reports rewire Phase 3 — carry the presentation-engine verdict
    # on every page.  The viewer reads it as `statusRes.engine ?? pageRes.engine`,
    # so stamping it at this ONE wrapper covers every paged endpoint at once
    # (async result, federation-backed paged results) rather than each of them
    # growing its own copy.  Uses the same chokepoint as the envelope property.
    # Additive + fail-open: absent means "client", which is today's behaviour.
    try:
        if isinstance(_page, dict) and "engine" not in _page:
            from core.reports.contract import engine_for_rows as _engine_for_rows
            _page["engine"] = _engine_for_rows(_page.get("total_rows"))
    except Exception as _eng_exc:
        logger.debug("paged-result engine verdict skipped (fail-open): %s", _eng_exc)
    # 2026-08-25 — a result whose artifact has VANISHED is not a zero-row
    # result. The paginator used to fall through to the in-memory branch and
    # return rows:[] / total_rows:0 behind a 200, which the viewer renders as
    # "The report ran successfully but returned no rows. Adjust the parameters
    # above..." — asserting success over a result the system knows it lost, and
    # blaming the user's parameters for it.
    #
    # 410 Gone is the honest status: the resource existed and no longer does,
    # and re-running is a thing the user can actually do. Raised HERE rather
    # than in core.pagination so the sync paginator keeps its plain-dict
    # contract for non-HTTP callers.
    if isinstance(_page, dict) and _page.get("artifact_missing"):
        raise HTTPException(
            status_code=410,
            detail="This execution's result file is no longer available "
                   "(it was cleared, or the pod that produced it restarted). "
                   "Re-run the report to regenerate it.",
        )
    return _page


def _progressive_page_for_execution(exec_id: str, page: int, page_size: int,
                                    sort_column: Optional[str],
                                    sort_direction: Optional[str], cfg,
                                    dataset_version: Optional[str] = None):
    """A page from the parts an IN-FLIGHT execution has already made durable.

    ``core/scan_partitions`` lands each bucket as an immutable part beside the
    artifact and rewrites the partial manifest after every one, so rows are
    readable long before the last bucket finishes.  The artifact path is not
    recorded anywhere until the run completes, so it is derived from the
    execution id (:func:`expected_report_artifact`, which refuses any id that
    is not the server-minted shape rather than joining it onto a directory).

    Returns ``None`` — never an empty page — when there is nothing
    progressive to serve, so every caller falls through to exactly the
    behaviour it has today.  Two producers write parts: the partitioned
    build (a dataset that declares a partition column) and, since
    2026-09-27 behind ``business_reports.progressive_stream_parts``, the
    pure-SQL-connector drain of a report with NO partition plan
    (``FederationEngine._stream_connector_to_parts``).  A report on neither
    path writes no parts and never reaches this.  Synchronous: call it
    through ``asyncio.to_thread``.
    """
    from core.reports.pagination import (expected_report_artifact,
                                         resolve_result_source)
    path = expected_report_artifact(exec_id)
    if path is None:
        return None
    kind, _found = resolve_result_source(path)
    if kind != "parts":
        return None
    return _paginate_result({"output_path": str(path)}, page, page_size,
                            sort_column, sort_direction, cfg, dataset_version)


def _check_result_access(report: Optional[dict], fed_result: Optional[dict],
                         user: dict) -> None:
    """Fail-closed access gate for a federation execution's result artifact.

    SECURITY (RLS result-retrieval leak, 2026-07-17): the federation output
    was computed at the ORIGINAL executor's row-security scope.  Publishing
    no longer grants cross-user READ of a foreign execution's cached rows.
    Allow ONLY: the execution's executor (``executed_by``), the report owner,
    or admin — 403 on anything else (ambiguity included).

    2026-08-09 reports rewire Phase 1: extracted VERBATIM from
    ``get_report_results_paginated`` so the paged endpoint and the ``/cube``
    endpoint share ONE gate that cannot drift (single-chokepoint rule,
    docs/reports_target_architecture_2026_08_08.md §2.3).  Any change here
    changes BOTH endpoints — that is the point.
    """
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    _is_admin = bool(username) and role in ADMIN_TIER_ROLES
    _is_owner = bool(report) and bool(username) and report.get("owner") == username
    _is_executor = bool(username) and (fed_result or {}).get("executed_by") == username
    if not (_is_admin or _is_owner or _is_executor):
        raise HTTPException(status_code=403, detail="Access denied")


def _require_execution_belongs_to_report(report_id: int, report: Optional[dict],
                                          fed_result: dict) -> None:
    """404 unless federation execution ``fed_result`` was produced BY the
    report named in the URL.

    2026-09-15 -- LIVE: ``GET /api/business-reports/999/results/{exec}``
    served rows although report 999 does not exist.  The fallback below
    authorised on executor/owner/admin and never looked at ``report_id``:
    the report was in the path and not in the authorization.  The async-job
    branch above already binds (``db_entry["report_id"] == report_id``);
    this makes the federation branch do the same.

    ``federation_executions.report_id`` is stamped by every business-report
    writer from today.  Rows written before that column existed (and
    dataset-level runs from /api/datasets/{id}/execute, which belong to no
    report) carry only a dataset: for those the binding is the dataset the
    report reads.  Called by the paged-results AND the /cube endpoint --
    one rule, two consumers.
    """
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    bound = fed_result.get("report_id")
    if bound is not None:
        if int(bound) != int(report_id):
            raise HTTPException(status_code=404,
                                detail="Execution result not found for this report")
        return
    if int(fed_result.get("dataset_id") or 0) != int(report.get("dataset_id") or 0):
        raise HTTPException(status_code=404,
                            detail="Execution result not found for this report")


async def _with_format_cutoffs(db, report_id: int, report: Optional[dict], answer: Any,
                               output_path: Optional[str]) -> Any:
    """2026-10-24 -- a page carries the cut-off of each top / bottom N rule,
    computed over the WHOLE stored result (core/reports/format_rules.py),
    so the viewer ranks the column and not the 100 rows it shows.  A report
    without such a rule answers exactly as before."""
    if not isinstance(answer, dict):
        return answer
    try:
        if report is None:
            report = await _adb(db.get_business_report, report_id)
        from core.reports.format_rules import RANKING, attach_cutoffs, wire_cutoffs
        rules = _extract_fmt_rules(report or {})
        if not any(r.get("condition_type") in RANKING for r in rules):
            return answer
        if output_path and Path(str(output_path)).exists():
            rules = await asyncio.to_thread(attach_cutoffs, rules, artifact=str(output_path))
            answer["format_cutoffs"] = wire_cutoffs(rules)
        else:
            answer["format_cutoffs"] = {}
            answer["format_cutoffs_note"] = ("The result file is not available, so top / bottom N "
                                             "formats are not applied.")
    except Exception as exc:                                    # noqa: BLE001
        logger.warning("[fmt-rules] cut-offs for report %s failed: %s", report_id, exc)
    return answer


@router.get("/api/business-reports/{report_id}/results/{exec_id}")
async def get_report_results_paginated(
    report_id: int,
    exec_id: str,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=0, ge=0),
    sort_column: Optional[str] = Query(default=None),
    sort_direction: Optional[str] = Query(default=None),
    dataset_version: Optional[str] = Query(
        default=None,
        description="Echo the dataset_version a previous page returned to keep "
                    "paging the SAME snapshot of a still-building result. A "
                    "snapshot that no longer exists is a 409, never a silent "
                    "splice."),
    # 2026-10-30 (every report a canvas): the clicked values of the canvas's
    # other tiles ([{column_id, value, tile_id, path?}], core.reports.
    # canvas_links) -- the page is then the MATCHING rows of the stored
    # result (core/reports/report_table_links.py).  Absent = as before.
    links: Optional[str] = Query(default=None),
    request: Request = None,
    user: dict = Depends(require_capability("reports.view")),
):
    """Phase 81 FIX 2+3: Paginated + sortable results for a completed report execution.

    Returns {rows, columns, total_rows, page, page_size, total_pages}.
    Also checks async execution state dict for in-memory results.

    2026-10-30: ``?links=`` -> the rows that match the canvas's clicked
    values (``linked: {applied, words}`` says so); ``Accept:
    application/vnd.apache.arrow.stream`` -> the same page as Arrow, unless a
    column is an exact DECIMAL (then JSON, and ``X-Page-Format-Reason`` says
    which).  Without either, the answer is the JSON it always was.
    """
    from core import config as _cfg

    link_entries = _parse_canvas_links(links)
    # Check async executions cache first (Phase 83A: check DB then in-memory result)
    db = _require_db()
    db_entry = await _adb(db.get_br_async_job, exec_id)
    if db_entry and db_entry.get("report_id") == report_id and db_entry.get("status") == "completed":
        await _adb(_check_async_exec_access, db, db_entry, user)
        cache_entry = _br_cache_get(exec_id)
        result = cache_entry.get("result")
        if not result and db_entry.get("output_path"):
            result = {"output_path": db_entry["output_path"], "total_rows": db_entry.get("total_rows", 0)}
        if result:
            if link_entries:
                return await _linked_results_page(db, report_id, None, result, link_entries, page, page_size,
                                                  sort_column, sort_direction, _cfg, request)
            return _page_answer(await _with_format_cutoffs(db, report_id, None, await asyncio.to_thread(
                _paginate_result, result, page, page_size, sort_column,
                sort_direction, _cfg, dataset_version), result.get("output_path")),
                request, result.get("output_path"))

    # 2026-09-05 PROGRESSIVE — a run that is STILL EXECUTING may already have
    # durable parts beside its (not yet written) artifact.  Serving them is
    # the whole point of the partitioned scan: rows appear as each bucket
    # lands instead of only when the last one does.  Entered only when a
    # parts dataset actually exists, so a report with no partition plan takes
    # byte-identically the path it takes today.
    if (db_entry and db_entry.get("report_id") == report_id
            and db_entry.get("status") in ("running", "pending")):
        await _adb(_check_async_exec_access, db, db_entry, user)
        if link_entries:
            # the matching rows of a result still being built would look like all of them
            raise HTTPException(status_code=409, detail={
                "error": "links_need_finished_result",
                "message": "This run is still being built, so the report's table cannot follow the clicked "
                           "values yet. Wait for it to finish, then click again."})
        _prog = await asyncio.to_thread(
            _progressive_page_for_execution, exec_id, page, page_size,
            sort_column, sort_direction, _cfg, dataset_version)
        if _prog is not None:
            return _page_answer(_prog, request, None)

    # Fall back to federation execution history.
    report = await _adb(db.get_business_report, report_id)
    try:
        fed_result = await _adb(db.get_federation_execution, exec_id)
    except Exception:
        fed_result = None
    if not fed_result:
        raise HTTPException(status_code=404, detail="Execution result not found")
    # The execution must BELONG to the report in the path (404 otherwise) --
    # then the executor / owner / admin gate.
    _require_execution_belongs_to_report(report_id, report, fed_result)
    # SECURITY: executor / owner / admin only, fail-closed — the shared
    # single-chokepoint gate (also used by the /cube endpoint below).
    _check_result_access(report, fed_result, user)

    output_path = fed_result.get("output_path", "")
    result_dict = {"output_path": output_path, "columns": fed_result.get("columns", [])}
    if link_entries:
        return await _linked_results_page(db, report_id, report, result_dict, link_entries, page, page_size,
                                          sort_column, sort_direction, _cfg, request)
    return _page_answer(await _with_format_cutoffs(db, report_id, report, await asyncio.to_thread(
        _paginate_result, result_dict, page, page_size, sort_column,
        sort_direction, _cfg, dataset_version), output_path), request, output_path)


def _page_answer(answer: Any, request: Optional[Request], artifact: Optional[str]) -> Any:
    """A page as the caller asked for it (2026-10-30).  ``Accept: ...arrow.stream``
    -> the page as Arrow (``core.reports.cube_arrow.page_arrow``); a page that
    must stay JSON (an exact DECIMAL column, types unknown, mixed values) is the
    JSON with ``X-Page-Format: json`` and ``X-Page-Format-Reason`` in words.
    Everyone else: the dict, i.e. the JSON they have always had, byte for byte."""
    from core.arrow_ipc import ARROW_STREAM_MEDIA_TYPE, accepts_arrow
    if request is None or not isinstance(answer, dict) or not accepts_arrow(request.headers.get("accept")):
        return answer
    from fastapi.encoders import jsonable_encoder
    from fastapi.responses import JSONResponse, Response as _Resp
    from core.reports.cube_arrow import page_arrow
    data, why = page_arrow(answer, artifact)
    if data is not None:
        return _Resp(content=data, media_type=ARROW_STREAM_MEDIA_TYPE,
                     headers={"X-Page-Format": "arrow", "Vary": "Accept"})
    return JSONResponse(content=jsonable_encoder(answer),
                        headers={"X-Page-Format": "json", "X-Page-Format-Reason": why[:300], "Vary": "Accept"})


async def _linked_results_page(db, report_id: int, report: Optional[dict], result: dict, link_entries: list,
                               page: int, page_size: int, sort_column: Optional[str],
                               sort_direction: Optional[str], cfg, request: Optional[Request]) -> Any:
    """A page of the report's OWN table under the canvas's clicked values
    (2026-10-30, every report a canvas; core/reports/report_table_links.py):
    the matching rows of the SAME stored result, through the tiles' rule --
    never a new query.  When the table does not follow (switched off) the
    page is every row and ``linked.applied`` is false with the reason; a
    filter that cannot be applied is a 422 / 409 in words, never every row."""
    from core.reports import report_table_links as _rtl
    if report is None:
        report = await _adb(db.get_business_report, report_id)
    ds = await _adb(db.get_dataset_full, (report or {}).get("dataset_id")) if (report or {}).get("dataset_id") else None
    try:
        flt, words = _rtl.report_table_filter(report or {}, link_entries, (ds or {}).get("columns", []) or [])
    except _rtl.TableLinkRefused as exc:
        raise HTTPException(status_code=422, detail={"error": "links_not_applicable", "message": str(exc)})
    output_path = result.get("output_path") or ""
    if flt is None:
        answer = await asyncio.to_thread(_paginate_result, result, page, page_size, sort_column,
                                         sort_direction, cfg, None)
        if isinstance(answer, dict):
            answer["linked"] = {"applied": False, "words": _rtl.why_not_followed(report or {}, link_entries)}
        return _page_answer(await _with_format_cutoffs(db, report_id, report, answer, output_path),
                            request, output_path)
    if not output_path or (not Path(output_path).exists() and not _parts_result_exists(Path(output_path))):
        raise HTTPException(status_code=409, detail={
            "error": "links_need_stored_result",
            "message": "This run has no stored result to filter, so the report's table cannot follow the "
                       "clicked values. Run the report again, or clear the clicked values."})
    try:
        answer = await asyncio.to_thread(_rtl.linked_page, output_path, flt, words, page, page_size,
                                         sort_column, sort_direction, cfg)
    except _rtl.TableLinkRefused as exc:
        raise HTTPException(status_code=422, detail={"error": "links_not_applicable", "message": str(exc)})
    for k in ("row_limit", "truncated"):
        if k in result and (k != "row_limit" or result.get(k) is not None):
            answer[k] = result.get(k)
    return _page_answer(await _with_format_cutoffs(db, report_id, report, answer, output_path),
                        request, output_path)


# ── Phase 2 report-instance layer (2026-08-09): instance retrieval ────────────
#
# Metadata list/fetch endpoints, access-gated with the SAME
# `_check_result_access` chokepoint as the other retrieval endpoints —
# applied per row (admin / report owner see every instance; anyone else
# sees only instances they executed).  The lawful cross-scope SERVE — user
# B reading A's bytes — happens ONLY in the execute read-through
# (`try_serve_instance`: byte-identical rls_signature AND a passing view
# check, both fail-closed), never here.

@router.get("/api/business-reports/{report_id}/instances/latest")
async def get_latest_report_instance_endpoint(
    report_id: int,
    params_fingerprint: Optional[str] = Query(default=None),
    params: Optional[str] = Query(default=None),
    user: dict = Depends(require_capability("reports.view")),
):
    """Newest instance THIS caller would actually be served (404 if none).

    A PROBE for the viewer: "is opening this report free, or will it cost a
    live query?".  It must therefore answer the same question the serve path
    answers, or it is worse than useless — a probe that says yes where the
    serve says no makes the viewer auto-run a LIVE query, which is precisely
    the cost instances exist to remove.

    2026-08-09: originally matched on ``params_fingerprint`` + access only,
    which ignored the caller's RLS SCOPE.  It now resolves the caller's real
    serve key and delegates to the same ``find_latest_report_instance`` the
    serve path uses, so probe and serve cannot disagree.  Any uncertainty
    (unsignable scope, serving disabled, report forces refresh-on-open) is a
    404 = "not free", never a false yes.

    Parameter keying, in precedence order: ``params_fingerprint`` (a
    pre-computed key) wins; else ``params`` — RAW parameter values as a JSON
    object, fingerprinted HERE through ``canonical_params_fingerprint`` (the
    one canonicalisation the serve path uses — clients must never replicate
    it, replication = drift = probe/serve disagreement); else the report's
    stored parameter defaults.  Unparseable/non-object ``params`` ⇒ 404.
    """
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")

    # Publish lifecycle (2026-08-17): the probe must key on the SAME
    # definition the serve/execute path will run — the published snapshot
    # for consumers, the draft for editors — or probe and serve disagree
    # (the exact defect class this endpoint documents below).  An archived
    # report is a 404 here: opening it is never "free" for a consumer.
    try:
        report, _probe_version = await _adb(
            _resolve_execution_report, db, report, user)
    except HTTPException as exc:
        if exc.status_code == 410:
            raise HTTPException(status_code=404,
                                detail="No accessible instance found")
        raise

    # Direct-call safety: tests invoke this function without FastAPI's
    # dependency resolution, so unsupplied Query params arrive as Query
    # sentinel objects — anything non-str means "not provided".
    _pf_arg = params_fingerprint if isinstance(params_fingerprint, str) else None
    _params_arg = params if isinstance(params, str) else None

    def _probe():
        from core.reports import instances as _ri
        if not _ri.instance_serving_enabled():
            return None
        if report.get("refresh_on_open"):
            return None          # author asked for live — opening is never free
        try:
            if _pf_arg:
                pf = _pf_arg
            elif _params_arg is not None:
                _pv = json.loads(_params_arg)
                if not isinstance(_pv, dict):
                    return None  # fail-closed: not a parameter mapping
                pf = _ri.canonical_params_fingerprint(_pv)
            else:
                pf = _ri.canonical_params_fingerprint(
                    {p.get("name"): p.get("default_value")
                     for p in (report.get("parameters") or [])
                     if isinstance(p, dict) and p.get("name")})
            sig = _ri.compute_caller_signature(db, report, user)
            sv = _ri.compute_semantic_version(db, report)
        except Exception:
            return None          # fail-closed: cannot key ⇒ "not free"
        inst = db.find_latest_report_instance(
            report_id=int(report_id), params_fingerprint=pf,
            rls_signature=sig, semantic_version=sv)
        if not inst:
            return None
        # D3 (2026-08-09 adversarial cross-feature review): the serve's
        # artifact GATE, applied to the probe.  The artifact cleaner stops
        # exempting an instance's bytes after its age window and deletes
        # them while the row stays `ready` and keeps matching — a probe
        # that answers on the ROW alone then reports "free" for an open
        # the serve will MISS on require_artifact, and the viewer
        # auto-fires the LIVE query the probe exists to avoid.  Same
        # chokepoint as the serve (core.reports.contract.require_artifact),
        # so probe and serve cannot disagree on existence either.
        try:
            from core.reports.contract import require_artifact as _req_art
            _req_art(str(inst["execution_id"]), inst.get("artifact_path"))
        except Exception:
            return None          # bytes unverifiable ⇒ opening is NOT free
        return inst

    inst = await asyncio.to_thread(_probe)
    if not inst:
        raise HTTPException(status_code=404, detail="No accessible instance found")
    return inst


@router.get("/api/business-reports/{report_id}/instances")
async def list_report_instances_endpoint(
    report_id: int,
    limit: int = Query(default=50, ge=1, le=200),
    user: dict = Depends(require_capability("reports.view")),
):
    """List this report's instances the caller may access (see gate note
    above — one chokepoint, applied per row)."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    rows = await _adb(db.list_report_instances, report_id, limit)
    out = []
    for inst in rows:
        try:
            _check_result_access(report, {"executed_by": inst.get("created_by")}, user)
        except HTTPException:
            continue
        out.append(inst)
    return {"instances": out, "total": len(out)}


# ── Reports rewire Phase 1 (2026-08-09): microcube /cube endpoint ─────────────
#
# One bounded DuckDB query per drill / banding / running-calc / slicer gesture
# over the already-materialised result artifact — never "ship every detail row
# to the browser" (docs/reports_target_architecture_2026_08_08.md §2).  The
# client sends STATE only; column semantics come from the stored report +
# dataset rows (single semantic source).

class CubeMeasure(BaseModel):
    """One requested measure.  Blank/None aggregation defaults to ``sum``
    (client ``getAggType`` parity — see microcube._gate_measures)."""
    column: str
    aggregation: Optional[str] = None
    # 2026-10-26 (the report canvas): the measure's OUTPUT name, so one
    # column can be shown two ways in one tile (sum AND largest of Amount)
    alias: Optional[str] = None


class CubePathStep(BaseModel):
    """One clicked drill-path step.  ``value=None`` filters ``IS NULL``
    (audit D5 NULL discipline — never ``= 'null'``)."""
    column: str
    value: Optional[Any] = None


class CubeRunningCalc(BaseModel):
    """Mirrors the client ``RunningCalcDef``; both field spellings accepted
    (microcube normalises ``measure``/``measure_col_name`` etc.)."""
    name: str
    calc_type: str
    measure: Optional[str] = None
    partition: Optional[str] = None
    measure_col_name: Optional[str] = None
    partition_col_name: Optional[str] = None


class CubeDerived(BaseModel):
    """A value worked out from two of the drill's measure aliases (2026-11-03)."""
    alias: str = Field(max_length=64)
    op: str = Field(pattern="^(difference|ratio)$")
    a: str = Field(max_length=200)
    b: str = Field(max_length=200)
    nonzero: bool = False

class CubeQueryRequest(BaseModel):
    """The ``state`` body of POST .../results/{exec_id}/cube (target arch §2.3).

    ``operation`` selects the microcube capability; the remaining fields are
    that operation's arguments.  Unknown identifiers are rejected against the
    artifact schema inside the microcube (400), filter/slicer VALUES bind as
    prepared-statement parameters.
    """
    operation: str                       # 'drill' | 'bands' | 'running_calcs' | 'slicer_options'
    # drill / running_calcs level definition
    dimensions: List[str] = []
    measures: List[CubeMeasure] = []
    # bands
    section_columns: List[str] = []
    group_columns: List[str] = []
    # running_calcs
    calcs: List[CubeRunningCalc] = []
    # slicer_options
    column: Optional[str] = None
    options_limit: Optional[int] = Field(default=None, ge=1)
    options_offset: int = Field(default=0, ge=0)
    # shared state
    path_filters: List[CubePathStep] = []
    slicers: Dict[str, List[Any]] = {}
    sort_column: Optional[str] = None
    sort_direction: Optional[str] = Field(default=None, pattern="^(asc|desc)$")
    page: int = Field(default=1, ge=1)
    page_size: Optional[int] = Field(default=None, ge=0)  # None = operation default; 0 = full grouped result
    # insight (2026-10-30): a canvas insight tile's settings -- api/report_insights.py
    insight: Optional[Dict[str, Any]] = None
    # 2026-11-01 -- the canvas tile asking (the stored story's key beside the run); the
    # execution id itself is the ROUTE's path value, never a body field (api/report_insights.py)
    tile_id: Optional[str] = Field(default=None, max_length=64)
    # 2026-10-30 (the canvas drawing fast): a 'drill' over ONE category may ask
    # for at most this many rows back, chosen by LTTB over its first measure
    # in the page's order (core/reports/lttb.py) -- about one point per pixel
    # of a line tile, the peaks and dips kept.  None = every row (as before).
    max_points: Optional[int] = Field(default=None, ge=4, le=100_000)
    # 2026-10-30 (linked canvas tiles, core/reports/canvas_links.py): each
    # entry is ONE alternative clause -- "this clicked path OR that one", a
    # path being ALL of its steps; the clauses must all hold.  Sent to the
    # microcube as path_filters steps {"any_of": ...} (_cube_path_filters).
    link_paths: List[List[List[CubePathStep]]] = Field(default_factory=list, max_length=50)
    # 2026-11-03 -- a 'drill' may ask for values DERIVED from two of its measures
    # (core/reports/microcube.py DERIVED_OPS: a difference, a ratio as %), optionally
    # only the rows where one is not zero; sort_abs orders by size whatever the sign
    derived: List[CubeDerived] = Field(default_factory=list, max_length=4)
    sort_abs: bool = False


def _cube_path_filters(body: Any) -> List[Dict[str, Any]]:
    """The cube request's drill path AND its linked path alternatives, as the
    microcube's ``path_filters`` (``microcube._build_where`` renders an
    ``any_of`` step as one OR of ANDs)."""
    out = [s.model_dump() for s in (getattr(body, "path_filters", None) or [])]
    for clause in getattr(body, "link_paths", None) or []:
        out.append({"any_of": [[s.model_dump() for s in path] for path in clause]})
    return out


_CUBE_OPERATIONS = ("drill", "bands", "running_calcs", "slicer_options", "insight")


def _finish_drill(result: dict, body: "CubeQueryRequest", request: Optional[Request]):
    """The drill answer as the caller asked for it (2026-10-30).

    ``max_points`` -> the rows LTTB keeps, and ``downsampled`` says from how
    many (``total_rows`` stays the true count).  ``Accept: ...arrow.stream``
    -> the same envelope as Arrow (core/reports/cube_arrow.py), else -- and
    whenever Arrow cannot carry the values exactly -- the dict, i.e. the JSON
    every other caller has always had."""
    from core.arrow_ipc import ARROW_STREAM_MEDIA_TYPE, accepts_arrow
    if body.max_points is not None and len(body.dimensions) == 1 and body.measures:
        from core.reports.lttb import downsample_rows, drill_y_key
        rows = result.get("rows") or []
        y_key = drill_y_key([m.model_dump() for m in body.measures])
        if y_key and len(rows) > body.max_points:
            kept = downsample_rows(rows, y_key, body.max_points)
            result = {**result, "rows": kept,
                      "downsampled": {"from": len(rows), "to": len(kept), "method": "lttb", "by": y_key}}
    if request is not None and accepts_arrow(request.headers.get("accept")):
        from fastapi.responses import Response as _Resp
        from core.reports.cube_arrow import cube_arrow_bytes
        data = cube_arrow_bytes(result)
        if data is not None:
            return _Resp(content=data, media_type=ARROW_STREAM_MEDIA_TYPE,
                         headers={"X-Cube-Format": "arrow", "Vary": "Accept"})
    return result


def _derive_artifact_grain(db, report: Optional[dict]) -> tuple:
    """Derive whether a report's result artifact holds DETAIL or GROUPED rows.

    Returns ``(artifact_grain, artifact_group_columns)`` for the microcube.

    The artifact's grain is a property of the SQL the federation engine
    EMITTED, so the rule encoded here is ``federation_engine._build_query``'s
    rule (federation_engine.py:1302-1361; base-query variant :1380-1395,
    identical guard), verified 2026-08-09: a selected column contributes an
    aggregate iff ``column_type in ('measure','kpi') AND aggregation`` is
    non-blank AND ``aggregation.upper() in VALID_AGGREGATIONS``.  Every other
    column is selected as-is and becomes a GROUP BY column — including a
    measure with a BLANK aggregation (drill audit D8: the FRONTEND displays
    blank as 'sum', but the frontend never emits SQL, so the backend
    blank-means-dimension treatment is what physically shaped the artifact)
    and a measure with an INVALID aggregation (the :1315-1319 warning branch
    demotes it to a dimension).

    Fail-closed direction: GROUPED refuses more (COUNT/AVG/COUNT DISTINCT are
    gated), so GROUPED is the default and DETAIL is claimed only when PROVABLE
    for ANY selection the execution could have used:

    * dataset-source ('saved_query'), non-pivot, non-merged report, AND
    * NO column of the DATASET can emit an aggregate under the rule above.

    Why dataset-wide rather than ``report['column_ids']``: Phase-112 drill
    executions run with ``override_column_ids`` that the execution row does
    NOT record (the sync tracker stores the report's STORED ids, :1629), so
    stored ids are not evidence about THIS artifact — but every possible
    selection (stored or override) resolves against the same dataset column
    definitions, so "no dataset column can aggregate" proves
    ``has_aggregation=False`` → plain SELECT → detail rows for all of them.
    Only the pivot path passes ``agg_overrides`` (_run_report_query /
    _run_pivot_report_query), so overrides cannot inject an aggregate into
    a non-pivot artifact.

    GAP-1 amendment (2026-08-30): BR dataset paths NOW pass ``metric_ids``
    (_run_report_query forwards the stored selection), and a calculated
    metric sets ``has_aggregation=True`` unconditionally (_build_query's
    ``is_metric`` branch), so a metric-bearing selection produces GROUPED
    rows even when no dataset COLUMN can aggregate.  The execution row
    records the metric selection no more than it records column overrides,
    and the report's CURRENT selection is not evidence about an artifact
    written under an earlier edit — so the same dataset-wide standard
    applies: DETAIL is provable only when the dataset ALSO defines no
    calculated metric at all (``active_only=False``: a metric deactivated
    since the artifact was written could still have shaped it).  Metric
    output aliases are likewise excluded from the GROUPED admission set —
    an artifact column bearing a metric's alias may BE the aggregated
    metric, not a grain column.

    Every non-provable branch stays GROUPED (UNKNOWN = UNSAFE):

    * raw_sql / published_view / federation_view — no semantic columns shaped
      the artifact (raw SQL groups however it likes; PV/FV artifacts are
      written from inline view output by the Phase-0 parity helper);
    * pivot — ``agg_overrides`` force aggregation;
    * merged — two composed queries + a pandas merge, not proven here;
    * dataset unresolvable / empty columns / any error.

    ``artifact_group_columns`` (GROUPED only): physical names that can NEVER
    emit an aggregate for this dataset.  This is a safe admission set for the
    microcube's COUNT-DISTINCT-on-grain-column rule: if such a name exists in
    the artifact it was necessarily selected un-aggregated, hence was a GROUP
    BY column of the grouped SQL.  Names that are aggregated under ANY column
    definition are excluded (ambiguity → fail closed); the microcube still
    validates every name against the artifact schema before use.
    """
    from core.reports.microcube import GRAIN_DETAIL, GRAIN_GROUPED
    fail_closed = (GRAIN_GROUPED, None)
    try:
        if not report:
            return fail_closed
        from core.reports.sources import canonical_source_type as _canon_dst
        if _canon_dst(report.get("data_source_type")) != "saved_query":
            return fail_closed          # raw_sql / PV / FV — see docstring
        if ((report.get("layout_config") or {}).get("report_type")) == "pivot":
            return fail_closed          # pivot: agg_overrides force GROUP BY
        if report.get("merged_dataset_id") and report.get("merge_config"):
            return fail_closed          # merged: composed path, not proven
        dataset_id = report.get("dataset_id")
        if not dataset_id:
            return fail_closed
        columns = db.list_dataset_columns(dataset_id) or []
        if not columns:
            return fail_closed
        from core.federation_engine import VALID_AGGREGATIONS

        def _emits_aggregate(col: dict) -> bool:
            agg = str(col.get("aggregation") or "").strip()
            return (col.get("column_type") in ("measure", "kpi")
                    and bool(agg) and agg.upper() in VALID_AGGREGATIONS)

        agg_names = {c.get("physical_name") for c in columns if _emits_aggregate(c)}
        # GAP-1 (2026-08-30): any calculated metric of the dataset (active or
        # not — see docstring) could have been selected by an execution and
        # forces GROUPED output, so its existence breaks the DETAIL proof.
        # Contract note: the real DatabaseManager returns a LIST or RAISES
        # (a raise lands in the outer handler → fail_closed).  A db object
        # without a usable metric catalog (duck-typed managers and the
        # metric-blind MagicMock doubles in the 2026-08-09 cube tests) has
        # no metrics to inject, so a non-list answer means "none" — it must
        # NOT flip every such report to GROUPED.
        _metrics_raw = db.list_calculated_metrics(dataset_id, active_only=False)
        metric_rows = _metrics_raw if isinstance(_metrics_raw, (list, tuple)) else []
        metric_aliases = {_metric_alias(m.get("name", ""))
                          for m in metric_rows} - {""}
        if not agg_names and not metric_rows:
            # PROOF of detail: no dataset column can emit an aggregate and no
            # calculated metric exists to be injected, so ANY selection
            # (stored column_ids, override_column_ids, metric_ids) built SQL
            # with has_aggregation=False → plain SELECT → detail rows.
            return GRAIN_DETAIL, None
        group_cols = sorted(
            ({c.get("physical_name") for c in columns
              if c.get("physical_name") and not _emits_aggregate(c)}
             - agg_names) - metric_aliases)
        return GRAIN_GROUPED, (group_cols or None)
    except Exception as exc:
        logger.debug("artifact-grain derivation fell back to grouped: %s", exc)
        return fail_closed


@router.post("/api/business-reports/{report_id}/results/{exec_id}/cube")
async def query_report_cube(report_id: int, exec_id: str, body: CubeQueryRequest,
                            request: Request = None,
                            user: dict = Depends(require_capability("reports.view"))):
    """One microcube gesture over a completed execution's result artifact.

    Auth + dispatch mirror ``get_report_results_paginated`` exactly: the
    async-job row is consulted first (creator/owner/admin gate), then the
    federation execution fallback (executor/owner/admin via the SHARED
    ``_check_result_access`` chokepoint — the two endpoints cannot drift),
    and the blocking DuckDB work runs via ``asyncio.to_thread`` (the
    starved-/health event-loop rule).

    Requires a file artifact — in-memory-only results have no artifact and
    404 here; those are exactly the small results the client engine serves.
    Response = the pagination page contract plus each operation's additive
    keys (never a second envelope shape); ``slicer_options`` returns the
    microcube's options contract.  Non-additive measures surface as a
    structured 422 naming each refused measure and its reason (audit D2 —
    never a silent wrong number, never a 500).
    """
    from core import config as _cfg
    from core.reports import microcube as _mc

    if body.operation not in _CUBE_OPERATIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown operation {body.operation!r} — expected one of "
                   f"{list(_CUBE_OPERATIONS)}")

    db = _require_db()
    report = await _adb(db.get_business_report, report_id)

    # Artifact resolution + access — same order as the paged endpoint:
    # async-job row first, then federation execution (finds PV/FV artifacts
    # written by the Phase-0 parity helper too).
    artifact_path = ""
    db_entry = await _adb(db.get_br_async_job, exec_id)
    if db_entry and db_entry.get("report_id") == report_id \
            and db_entry.get("status") == "completed":
        await _adb(_check_async_exec_access, db, db_entry, user)
        artifact_path = db_entry.get("output_path") or ""
    if not artifact_path:
        try:
            fed_result = await _adb(db.get_federation_execution, exec_id)
        except Exception:
            fed_result = None
        if not fed_result:
            raise HTTPException(status_code=404, detail="Execution result not found")
        _require_execution_belongs_to_report(report_id, report, fed_result)
        _check_result_access(report, fed_result, user)
        artifact_path = fed_result.get("output_path") or ""
    artifact = Path(artifact_path) if artifact_path else None
    # 2026-10-26: a result still held as its finished PARTS answers too (the
    # microcube reads their union); only "no result at all" is a 404
    if artifact is None or (not artifact.exists() and not _parts_result_exists(artifact)):
        raise HTTPException(status_code=404,
                            detail="Result artifact not available for cube queries")

    # Grain is derived server-side from the stored semantics — never trusted
    # from the client (blocking DB read → off the event loop).
    grain, group_cols = await asyncio.to_thread(_derive_artifact_grain, db, report)

    threads = _cfg.business_reports.microcube_threads
    memory_limit = _cfg.business_reports.microcube_memory_limit
    measures = [m.model_dump() for m in body.measures]
    path_filters = _cube_path_filters(body)
    if body.operation == "insight":     # a canvas insight tile (api/report_insights.py)
        from api.report_insights import answer_insight
        from core.reports.canvas_insights import previous_run_of
        return await answer_insight(db, report, artifact, body, grain=grain, group_cols=group_cols,
                                    allow_assistant=True, principal=str((user or {}).get("username") or "") or None,
                                    execution_id=str(exec_id),
                                    previous=lambda: previous_run_of(db, report, execution_id=exec_id,
                                                                     user_ctx=user))

    try:
        if body.operation == "slicer_options":
            if not body.column:
                raise HTTPException(status_code=400,
                                    detail="slicer_options requires 'column'")
            kwargs = dict(offset=body.options_offset, path_filters=path_filters,
                          threads=threads, memory_limit=memory_limit)
            if body.options_limit is not None:
                kwargs["limit"] = body.options_limit
            return await asyncio.to_thread(
                _mc.read_artifact_slicer_options, artifact, body.column, **kwargs)

        kwargs = dict(measures=measures, path_filters=path_filters,
                      slicers=body.slicers or None, page=body.page,
                      artifact_grain=grain, artifact_group_columns=group_cols,
                      threads=threads, memory_limit=memory_limit)
        if body.page_size is not None:
            kwargs["page_size"] = body.page_size
        if body.operation == "drill":
            drilled = await asyncio.to_thread(
                _mc.read_artifact_drill, artifact, dimensions=body.dimensions,
                sort_column=body.sort_column, sort_direction=body.sort_direction,
                derived=[d.model_dump() for d in body.derived], sort_abs=body.sort_abs,
                **kwargs)
            from core.arrow_ipc import accepts_arrow as _wants_arrow
            if body.max_points is None and not (
                    request is not None and _wants_arrow(request.headers.get("accept"))):
                return drilled          # the JSON every caller has always had
            return await asyncio.to_thread(_finish_drill, drilled, body, request)
        if body.operation == "bands":
            return await asyncio.to_thread(
                _mc.read_artifact_bands, artifact,
                section_columns=body.section_columns,
                group_columns=body.group_columns, **kwargs)
        # running_calcs
        return await asyncio.to_thread(
            _mc.read_artifact_running_calcs, artifact, dimensions=body.dimensions,
            calcs=[c.model_dump() for c in body.calcs],
            sort_column=body.sort_column, sort_direction=body.sort_direction,
            **kwargs)
    except _mc.NonAdditiveMeasureError as exc:
        # Correctness GATE (audit D2): refuse loudly and STRUCTURALLY — the
        # caller can render "this measure can't be shown at this level, and
        # here's why" per measure.  Never a 500, never a silent fallback.
        raise HTTPException(status_code=422, detail={
            "error": "non_additive_measures",
            "message": str(exc),
            "artifact_grain": grain,
            "refused": [{"column": col, "reason": reason}
                        for col, reason in exc.refused.items()],
        })
    except _mc.ArtifactNotReady as exc:
        # still building / gone / parts this pod cannot read: a plain
        # sentence, never a total over part of the rows
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        # Identifier/shape validation from the microcube (unknown column,
        # duplicate dims, bad calc definitions, ...) — caller error, 400.
        raise HTTPException(status_code=400, detail=str(exc))


def _parts_result_exists(artifact: Path) -> bool:
    """Is this result held as a parts directory (finished or not)?  The
    microcube decides whether it may be READ (complete manifest, local parts)."""
    try:
        from core.reports.pagination import parts_dir_for
        from core.feed.parts_manifest import is_parts_dir
        return is_parts_dir(parts_dir_for(artifact))
    except Exception:                                        # noqa: BLE001
        return False


# ── Export (PDF / Excel) — Phase 62 ──────────────────────────────────────────

def _parse_export_params(params_json: str) -> dict:
    """Parse and validate the ?params= query string for export endpoints."""
    if not params_json:
        return {}
    try:
        parsed = json.loads(params_json)
    except (json.JSONDecodeError, TypeError):
        raise HTTPException(status_code=400, detail="Invalid params JSON")
    if not isinstance(parsed, dict):
        raise HTTPException(status_code=400, detail="params must be a JSON object")
    return parsed


def _parse_export_filters(filters_json: str) -> list:
    """Parse the ``?filters=`` query string for export endpoints.

    2026-09-17 -- exports could not carry the ad-hoc filters the run used, so
    a report executed with ``extra_filters`` showed 109,687,297,970.94 on the
    surface and exported 226,691,273,337.83 -- the whole table, twice the
    value, with nothing to say so.

    The neighbouring ``columns`` parameter already carries the viewer's
    runtime choice "so the file matches the screen"; this is the other half of
    that sentence.  The asymmetry mattered: a column subset can only NARROW an
    export, while a missing filter WIDENS it.
    """
    # Not a string means "not supplied".  These route functions are also
    # called DIRECTLY by tests and by the share/embed paths, where an unfilled
    # parameter arrives as the FastAPI ``Query`` default object rather than
    # None -- and a Query object is truthy, so a bare falsy check would hand
    # it to json.loads.  Caught by 53 existing tests on the first cut.
    if not isinstance(filters_json, str) or not filters_json:
        return []
    try:
        parsed = json.loads(filters_json)
    except (json.JSONDecodeError, TypeError):
        raise HTTPException(status_code=400, detail="Invalid filters JSON")
    if not isinstance(parsed, list):
        raise HTTPException(
            status_code=400,
            detail="filters must be a JSON array of "
                   "{column_id, operator, value} objects")
    return parsed


def _sanitize_export_filename(name: str) -> str:
    """Sanitize report name for use in Content-Disposition filename."""
    safe = _re_mod.sub(r'[^\w\s\-.]', '', name)
    return safe.replace(' ', '_').strip('_') or 'report'


def _export_response_headers(filename: str, rows_served: int,
                             row_limit: int,
                             total_rows: Optional[int] = None,
                             *, truncated: Optional[bool] = None,
                             disclose_total: bool = False,
                             continue_with: Optional[str] = None) -> dict:
    """Download headers + truncation disclosure — 2026-08-05 audit.

    Every export download now carries machine-readable truncation metadata
    (the CSV path used to cut at the row cap with NO indication anywhere):

      X-QS-Rows       — rows actually in the file
      X-QS-Row-Limit  — the cap the execution ran under
      X-QS-Truncated  — "true" when the file MAY be an incomplete cut of the
                        full result (row-limit reached OR SCALE-1 memory cap),
                        else "false"
      X-QS-Total-Rows — (SCALE-1, only when known) the artifact's true row
                        count when the memory cap cut it below that total

    Additive only — Content-Disposition is unchanged, so existing download
    flows keep working; API consumers and tests can now detect a cut file.

    2026-10-04 (streamed exports), keyword-only and additive:
    ``truncated`` -- the caller KNOWS the verdict (a PDF that executed for
    ceiling+1 rows), overriding the rows-vs-limit inference;
    ``disclose_total`` -- send ``X-QS-Total-Rows`` whenever the total is
    known, so a complete file says ``X-QS-Rows == X-QS-Total-Rows``;
    ``continue_with`` -- on a cut file, ``X-QS-Continue-With`` names the
    route that serves every row (the CSV export).
    """
    limit_hit = bool(row_limit) and int(rows_served) >= int(row_limit)
    mem_cut = total_rows is not None and int(total_rows) > int(rows_served)
    cut = (limit_hit or mem_cut) if truncated is None else bool(truncated)
    headers = {
        "Content-Disposition": f'attachment; filename="{filename}"',
        "X-QS-Rows": str(int(rows_served)),
        "X-QS-Row-Limit": str(int(row_limit or 0)),
        "X-QS-Truncated": "true" if cut else "false",
    }
    if mem_cut or (disclose_total and total_rows is not None):
        headers["X-QS-Total-Rows"] = str(int(total_rows))
    if cut and continue_with:
        headers["X-QS-Continue-With"] = continue_with
    return headers


_HEX_RE = _re_mod.compile(r'^[0-9a-fA-F]{3,8}$')

_KNOWN_EXCEL_FORMATS = frozenset({
    "$#,##0.00", "$#,##0", "#,##0", "#,##0.00", "#,##0.0",
    "0.00%", "0%", "0.00",
})
_ACCOUNTING_EXCEL = '#,##0.00_);(#,##0.00)'
_ACCOUNTING_CURRENCY_EXCEL = '$#,##0.00_);($#,##0.00)'


# GAP-1 (2026-08-30): currency symbols other than "$" used to be DROPPED —
# the value formatter special-cased startswith("$") and every other pattern
# ("€#,##0.00", "£#,##0", "#,##0.00 €") fell into the plain-number branch,
# so the number survived and the currency vanished.  The symbol now comes
# from the AUTHOR'S pattern.  Placement is honoured: a prefix symbol abuts
# the number (exactly like today's "$"); a suffix symbol keeps the spacing
# the pattern expresses ("#,##0.00 €" → "1,234.50 €", "#,##0.00€" →
# "1,234.50€").  Deliberately NOT done: locale separator swapping — a
# decimal-comma pattern ("#.##0,00 €") gets its symbol suffixed correctly
# but separators render US-style, same as every other numeric branch here.
_CURRENCY_BODY_RE = _re_mod.compile(r'[#0][#0,.]*')


def _split_currency_pattern(fp: str):
    """Split a numeric format pattern into (prefix_symbol, suffix_text).

    Returns None when the pattern carries no currency affix — pure numeric,
    percent, or no numeric body.  Precedence mirrors the historical branch
    order: a clean PREFIX symbol wins even on a pattern that ends with "%"
    (old code: startswith("$") was checked before endswith("%")); a
    suffix-only symbol is taken only when it contains no percent/placeholder
    machinery, so "0.00%" stays a percent pattern and an accounting tail
    like "_);($#,##0.00)" is never mistaken for a symbol.
    """
    if not fp:
        return None
    m = _CURRENCY_BODY_RE.search(fp)
    if not m:
        return None
    prefix = fp[:m.start()]
    suffix = fp[m.end():]

    def _clean(text: str) -> bool:
        return bool(text.strip()) and not any(c in '#0%"' for c in text)

    if _clean(prefix):
        return prefix.strip(), (suffix if _clean(suffix) else "")
    if _clean(suffix):
        return "", suffix
    return None


def _resolve_xl_format(fp: str, neg_fmt: str) -> str:
    """Resolve a format pattern to an Excel number format string."""
    if not fp:
        return ""
    if fp in _KNOWN_EXCEL_FORMATS:
        xl = fp
        if neg_fmt == "brackets" and xl:
            if xl.startswith("$"):
                xl = _ACCOUNTING_CURRENCY_EXCEL
            elif any(c.isdigit() for c in xl):
                xl = _ACCOUNTING_EXCEL
        return xl
    # GAP-1: unknown pattern carrying a currency affix — build the Excel
    # format from the author's symbol (quoted literal, so "CHF"/"€"/"kr"
    # are all safe) instead of returning "" (which left the cell with NO
    # number format at all).  Two decimals, mirroring the "$" semantics
    # the render side has always used.  Known "$" formats above are
    # untouched — their output is byte-identical.
    cur = _split_currency_pattern(fp)
    if cur is None:
        return ""
    sym_prefix, sym_suffix = cur
    pos = ((f'"{sym_prefix}"' if sym_prefix else "")
           + "#,##0.00"
           + (f'"{sym_suffix}"' if sym_suffix else ""))
    if neg_fmt == "brackets":
        return f"{pos}_);({pos})"
    return pos


def _extract_style_and_formats(report: dict, db) -> tuple:
    """Extract validated style_config + col_fmt_map from a report.

    Returns (header_bg, header_text, neg_fmt, stripe_rows, col_fmt_map, ds_cols).
    ds_cols is the raw list of dataset column dicts (reusable for pivot metadata).
    """
    sc = dict((report.get("layout_config") or {}).get("style_config", {}) or {})
    # 2026-11-01 -- a report with a THEME (layout_config.theme) prints its grid
    # in the theme's colours and negative style (core/reports/themes.py), so Excel
    # and PDF look like the screen; a report without one keeps its style_config
    if isinstance(report.get("layout_config"), dict) and report["layout_config"].get("theme") is not None:
        from core.reports.themes import grid_style, theme_of
        _gs = grid_style(theme_of(report["layout_config"], db))
        sc.update({"header_bg": "#" + _gs["header_bg"], "header_text": "#" + _gs["header_text"],
                   "negative_format": _gs["negative_format"], "stripe_rows": _gs["stripe_rows"]})
    header_bg = sc.get("header_bg", "#1976D2").lstrip("#")
    header_text = sc.get("header_text", "#FFFFFF").lstrip("#")
    if not _HEX_RE.match(header_bg):
        header_bg = "1976D2"
    if not _HEX_RE.match(header_text):
        header_text = "FFFFFF"
    neg_fmt = sc.get("negative_format", "brackets")
    stripe_rows = sc.get("stripe_rows", True)

    resolved_ds_id = _resolve_lov_dataset_id(report, db)
    ds_cols = db.list_dataset_columns(resolved_ds_id) if resolved_ds_id else []
    col_fmt_map: dict = {}
    for c in ds_cols:
        pn = c.get("physical_name", "")
        fp = c.get("format_pattern", "")
        if pn and fp:
            col_fmt_map[pn] = fp

    # GAP-1/GAP-2 (2026-08-30): metric and running-calc output columns carry
    # their AUTHOR's format_pattern into every renderer that reads this map
    # (interactive + token exports AND core/delivery_engine, which imports
    # this helper — so delivered documents format them identically).
    # setdefault: a dataset column's own pattern always wins, so a report
    # WITHOUT metrics/calcs — or a legacy name collision — renders exactly
    # as before.  Fail-open: format enrichment must never break a render
    # (the delivery engine falls back to blank styles on any raise here).
    try:
        for _mid in _report_metric_ids(report):
            _m = db.get_calculated_metric(_mid)
            if _m and _m.get("format_pattern"):
                col_fmt_map.setdefault(_metric_alias(_m.get("name", "")),
                                       _m["format_pattern"])
        for _rc in (report.get("running_calculations") or []):
            if (isinstance(_rc, dict) and _rc.get("name")
                    and _rc.get("format_pattern")):
                col_fmt_map.setdefault(str(_rc["name"]), _rc["format_pattern"])
    except Exception as _fmt_exc:
        logger.debug("metric/calc format enrichment skipped (fail-open): %s",
                     _fmt_exc)

    return header_bg, header_text, neg_fmt, stripe_rows, col_fmt_map, ds_cols


# ── GAP-2 (2026-08-30): value-based (conditional) formatting ─────────────────
# Conditional formatting existed only on the LEGACY PDF path
# (enterprise_reports_api stores rules, pdf_export_api applies them); the
# business-report renderers had no way to receive rules at all.  The rules now
# ride where business reports already carry every other style decision —
# layout_config.style_config, under "conditional_formats" — using the SAME
# rule shape the legacy path stores (column_name / condition_type /
# condition_value / bg_color / text_color / bold / is_enabled / rule_order)
# and the SAME evaluator, REUSED BY IMPORT so the two paths cannot drift on
# what a rule means.
#
# NOTE this stays a separate helper rather than a 7th element on
# _extract_style_and_formats: core/delivery_engine.py unpacks that tuple into
# exactly 6 names INSIDE a try/except that falls back to defaults — widening
# the tuple would not crash delivery, it would silently blank every style on
# every delivered PDF.
from api.pdf_export_api import (  # noqa: E402  (deliberate placement)
    _apply_conditional_formats as _legacy_apply_conditional_formats,
)

# Colors are interpolated into an inline style="" attribute and into openpyxl
# fills — only simple tokens (hex with optional '#', or a bare color name)
# are accepted; anything else is dropped from the rule, with a log line.
_SAFE_RULE_COLOR_RE = _re_mod.compile(r'^#?[0-9a-zA-Z]{2,20}$')


#: The conditions api/pdf_export_api._apply_conditional_formats actually
#: implements.  Kept beside the reader so the two cannot drift: the
#: authoring UI offers exactly these (CONDITION_TYPES in
#: frontend/src/components/reports/reportAuthoringModel.ts).
_FMT_CONDITION_TYPES = frozenset({
    "value_range", "equals", "contains", "not_null", "is_null",
    "top_n", "bottom_n",
})


def _extract_fmt_rules(report: dict) -> list:
    """Read value-based formatting rules off the report's style config.

    Malformed entries are skipped WITH A LOG LINE (the system must say what
    it declined to do); unsafe color tokens are dropped from the rule.
    """
    sc = (report.get("layout_config") or {}).get("style_config") or {}
    raw = sc.get("conditional_formats") or []
    if not isinstance(raw, list):
        logger.warning("[fmt-rules] style_config.conditional_formats is %s, "
                       "expected list — ignoring", type(raw).__name__)
        return []
    rules: list = []
    for r in raw:
        if not (isinstance(r, dict) and r.get("column_name")
                and r.get("condition_type")):
            logger.warning("[fmt-rules] skipping malformed rule (needs "
                           "column_name + condition_type): %r", r)
            continue
        cv = r.get("condition_value")
        if cv is not None and not isinstance(cv, dict):
            logger.warning("[fmt-rules] skipping rule on column %s: "
                           "condition_value must be an object, got %s",
                           r["column_name"], type(cv).__name__)
            continue
        # 2026-08-31: a condition the evaluator does not implement matched
        # NOTHING and said nothing.  The authoring UI can only emit the seven
        # below (CONDITION_TYPES in reportAuthoringModel.ts), but these rules
        # ride in layout_config and have no CRUD endpoint of their own, so an
        # API caller or a hand-edited report can carry any spelling at all --
        # e.g. "greater_than", which reads like it should work.  Skipping is
        # behaviour-neutral (it never matched) and the log is the difference
        # between a rule that does nothing and a rule that does nothing
        # VISIBLY.
        if r["condition_type"] not in _FMT_CONDITION_TYPES:
            logger.warning(
                "[fmt-rules] skipping rule on column %s: condition_type %r is "
                "not one of %s — it would never match anything",
                r["column_name"], r["condition_type"],
                ", ".join(sorted(_FMT_CONDITION_TYPES)))
            continue
        r = dict(r)
        for key in ("bg_color", "text_color"):
            c = r.get(key)
            if c and not _SAFE_RULE_COLOR_RE.match(str(c)):
                logger.warning("[fmt-rules] dropping unsafe %s %r on column %s",
                               key, c, r["column_name"])
                r[key] = None
        rules.append(r)
    return rules


def _rules_by_column(fmt_rules) -> dict:
    """Index rules per column once per render — the evaluator then only ever
    sees the handful of rules for THAT column (a per-cell sort over the whole
    rule list on a million-row export is exactly the latency class we ban)."""
    by_col: dict = {}
    for r in (fmt_rules or []):
        by_col.setdefault(r.get("column_name"), []).append(r)
    return by_col


def _cell_rule_style(col_name: str, raw_val, rules_by_col: dict) -> str:
    """CSS style string for a cell, via the LEGACY evaluator (shared import)."""
    col_rules = rules_by_col.get(col_name)
    if not col_rules:
        return ""
    try:
        return _legacy_apply_conditional_formats(raw_val, col_name, col_rules)
    except Exception as exc:  # a broken rule must not kill an export
        logger.warning("[fmt-rules] rule evaluation failed on column %s: %s",
                       col_name, exc)
        return ""


def _xl_rule_color(css_color: str):
    """Normalise a CSS color token to openpyxl aRGB hex, or None."""
    c = str(css_color or "").lstrip("#")
    if _re_mod.fullmatch(r"[0-9a-fA-F]{3}", c):
        c = "".join(ch * 2 for ch in c)
    if _re_mod.fullmatch(r"[0-9a-fA-F]{6}|[0-9a-fA-F]{8}", c):
        return c.upper()
    return None  # named colors reach HTML but Excel fills need hex


def _xl_conditional_style(col_name: str, raw_val, rules_by_col: dict):
    """(bg_hex, text_hex, bold) for a matched rule, or None.

    Parses the CSS string the shared evaluator emits rather than re-deciding
    which rule matches — one matcher, two output media.
    """
    style = _cell_rule_style(col_name, raw_val, rules_by_col)
    if not style:
        return None
    bg = text = None
    bold = False
    for part in style.split(";"):
        k, _, v = part.partition(":")
        k, v = k.strip(), v.strip()
        if k == "background-color":
            bg = _xl_rule_color(v)
        elif k == "color":
            text = _xl_rule_color(v)
        elif k == "font-weight" and v == "bold":
            bold = True
    if bg is None and text is None and not bold:
        return None
    return bg, text, bold


def _fmt_pdf_val(col_name: str, raw, col_fmt_map: dict, neg_fmt: str) -> str:
    """Format a cell value for PDF — applies format patterns + accounting brackets."""
    if raw is None:
        return ""
    if isinstance(raw, (int, float)):
        if _math_mod.isnan(raw) or _math_mod.isinf(raw):
            return _html_mod.escape(str(raw))
        fmt_pattern = col_fmt_map.get(col_name, "")
        if fmt_pattern:
            try:
                # GAP-1 (2026-08-30): the currency symbol comes from the
                # AUTHOR'S pattern — "€#,##0.00" → "€1,234.50", "#,##0.00 €"
                # → "1,234.50 €".  A "$" pattern takes this same branch and
                # renders byte-identically to the old startswith("$")
                # special case (prefix abuts the number, always 2 decimals,
                # same bracket/red negative treatment).
                _cur = _split_currency_pattern(fmt_pattern)
                if _cur is not None:
                    sym_prefix, sym_suffix = _cur
                    abs_v = abs(raw)
                    formatted = (f"{_html_mod.escape(sym_prefix)}{abs_v:,.2f}"
                                 f"{_html_mod.escape(sym_suffix)}")
                    if raw < 0 and neg_fmt == "brackets":
                        return f'<span style="color:#d32f2f">({formatted})</span>'
                    elif raw < 0:
                        return f'<span style="color:#d32f2f">-{formatted}</span>'
                    return formatted
                elif fmt_pattern.endswith("%"):
                    pct_val = raw * 100
                    dec = 2 if ".00" in fmt_pattern else 0
                    formatted = f"{abs(pct_val):,.{dec}f}%"
                    if pct_val < 0 and neg_fmt == "brackets":
                        return f'<span style="color:#d32f2f">({formatted})</span>'
                    elif pct_val < 0:
                        return f'<span style="color:#d32f2f">-{formatted}</span>'
                    return formatted
                elif "#" in fmt_pattern or "0" in fmt_pattern:
                    dec = len(fmt_pattern.split(".")[-1]) if "." in fmt_pattern else 0
                    formatted = f"{abs(raw):,.{dec}f}"
                    if raw < 0 and neg_fmt == "brackets":
                        return f'<span style="color:#d32f2f">({formatted})</span>'
                    elif raw < 0:
                        return f'<span style="color:#d32f2f">-{formatted}</span>'
                    return formatted
            except (ValueError, TypeError):
                pass
        if raw < 0 and neg_fmt == "brackets":
            abs_v = abs(raw)
            fmt_str = f"{abs_v:,.2f}" if isinstance(raw, float) else f"{abs_v:,}"
            return f'<span style="color:#d32f2f">({fmt_str})</span>'
        elif raw < 0:
            return f'<span style="color:#d32f2f">{raw:,.2f}</span>' if isinstance(raw, float) else f'<span style="color:#d32f2f">{raw:,}</span>'
        return f"{raw:,.2f}" if isinstance(raw, float) else f"{raw:,}"
    return _html_mod.escape(str(raw))


def _pdf_data_tr(row, columns: list, col_fmt_map: dict, neg_fmt: str,
                 rules_bc: dict, col_css: dict) -> str:
    """One <tr> for one data row — the SINGLE cell emitter shared by the flat
    and the banded PDF paths (one formatter, one rule evaluator, one style
    merge).  With no rules and no column styles it emits exactly the
    historical markup — no style attribute at all."""
    cells_parts = []
    for c in columns:
        _v = row.get(c) if isinstance(row, dict) else row
        _ccss = col_css.get(c, "") if col_css else ""
        _style = _cell_rule_style(c, _v, rules_bc) if rules_bc else ""
        _full = _ccss + (";" if _ccss and _style else "") + _style
        _attr = f' style="{_full}"' if _full else ""
        cells_parts.append(f"<td{_attr}>{_fmt_pdf_val(c, _v, col_fmt_map, neg_fmt)}</td>")
    return f"<tr>{''.join(cells_parts)}</tr>"


def _banded_tbody_html(events: list, columns: list, col_fmt_map: dict,
                       neg_fmt: str, rules_bc: dict, col_css: dict,
                       page_break_between: bool) -> tuple:
    """Banded events → table body HTML.  Returns (html, n_data_rows).

    Structure: one <tbody class="band-group"> per TOP-LEVEL group (so
    ``break-inside: avoid`` keeps a group on one page when it fits, and the
    optional between-group page break has an element to land on); the grand
    total rides its own plain <tbody> so a page-break rule never applies to
    it.  Subtotal/grand values go through the SAME _fmt_pdf_val as data
    cells — a subtotal of a currency column carries the author's symbol.
    """
    ncols = len(columns)
    parts: list = []
    state = {"open": False, "first": True}
    n_data = 0

    def _close():
        if state["open"]:
            parts.append("</tbody>")
        state["open"] = False

    for ev in events:
        kind = ev["kind"]
        if kind == "group_header":
            if ev["level"] == 0:
                _close()
                cls = "band-group"
                if page_break_between and not state["first"]:
                    cls += " band-break"
                parts.append(f'<tbody class="{cls}">')
                state["open"] = True
                state["first"] = False
            indent = 4 + ev["level"] * 12
            parts.append(
                f'<tr class="band-header"><td colspan="{ncols}" '
                f'style="padding-left:{indent}pt">'
                f'{_html_mod.escape(str(ev["value"]))} '
                f'<span class="band-count">({ev["count"]:,} '
                f'row{"s" if ev["count"] != 1 else ""})</span>'
                f'</td></tr>')
        elif kind == "data":
            n_data += 1
            parts.append(_pdf_data_tr(ev["row"], columns, col_fmt_map,
                                      neg_fmt, rules_bc, col_css))
        elif kind in ("subtotal", "grand_total"):
            totals = ev["totals"]
            if kind == "subtotal":
                label = f"Subtotal: {ev['value']}"
                if ev.get("count") is not None:
                    label += (f" ({ev['count']:,} "
                              f"row{'s' if ev['count'] != 1 else ''})")
                cls = "band-subtotal"
            else:
                _close()
                parts.append("<tbody>")
                state["open"] = True
                label = "Grand Total"
                cls = "grand-total"
            # The label goes in the first column that carries no total (the
            # break column is always total-free); if every column somehow
            # carries a total, the values win and the label is dropped.
            label_col = next((c for c in columns if c not in totals), None)
            cells = []
            for c in columns:
                _ccss = col_css.get(c, "") if col_css else ""
                _attr = f' style="{_ccss}"' if _ccss else ""
                if c in totals:
                    cells.append(f"<td{_attr}>"
                                 f"{_fmt_pdf_val(c, totals[c], col_fmt_map, neg_fmt)}"
                                 f"</td>")
                elif c == label_col:
                    cells.append(f"<td{_attr}>{_html_mod.escape(label)}</td>")
                else:
                    cells.append(f"<td{_attr}></td>")
            parts.append(f'<tr class="{cls}">{"".join(cells)}</tr>')
    _close()
    return "".join(parts), n_data


def _render_pdf_bytes(rows: list, columns: list, report_name: str,
                      header_bg: str, header_text: str, neg_fmt: str,
                      col_fmt_map: dict, page_size: str = "A4 landscape",
                      footer_text: str = "",
                      disclosure_text: str = "",
                      fmt_rules: list | None = None,
                      sections: dict | None = None,
                      column_styles: dict | None = None,
                      pdf_layout: dict | None = None,
                      canvas: dict | None = None) -> bytes:
    """Render rows/columns to PDF bytes via WeasyPrint. Reusable across endpoints.

    ``canvas`` (2026-10-26, the report canvas): ``{"above", "below", "css"}``
    from ``core.reports.canvas_pdf.canvas_pdf_parts`` -- the tiles laid out
    as the viewer places them, the bands above the report tile before the
    report's own table and the bands below it after; None = unchanged output.

    ``footer_text`` (optional): a one-line Completeness Certificate footer.  When
    non-empty it is rendered as a muted line beneath the row count; empty ⇒ no
    footer (unchanged output).

    ``disclosure_text`` (optional, 2026-08-09 caps-throttle-not-refuse): when
    non-empty it is rendered as a PROMINENT banner ABOVE the table.  A cap may
    bound how many rows a document carries, but the fact "this PDF contains N
    rows and the result may be larger" belongs ON THE DOCUMENT itself, not
    only in an API header — a printed/forwarded PDF must carry its own truth.
    Empty ⇒ no banner (unchanged output).

    2026-08-30 banded documents — three optional layers, each inert when None
    (a report using none of them renders BYTE-IDENTICALLY to the historical
    output; pinned by hash in tests):

    * ``sections`` — a _banding_spec dict.  Rows (already section-sorted by
      the caller) render as a banded document: group header rows, detail
      rows, group subtotal rows, a grand-total report footer.  CSS keeps a
      group header glued to its first rows (page-break-after: avoid), keeps
      a whole group together when it fits (break-inside: avoid on the
      group's own <tbody>), and honours the optional page break between
      top-level groups.  The <thead> column header repeats on every page —
      WeasyPrint table-header behaviour, verified by a page-count test.
    * ``column_styles`` — _extract_column_styles output; per-column width /
      alignment / font riding inline th/td styles.
    * ``pdf_layout`` — _extract_pdf_layout output (legacy ReportPDFConfig
      vocabulary): optional cover page, report header on/off, author
      subtitle (header_text), author page footer (footer_text with
      {page}/{total}), body font size.  Page SIZE from pdf_layout is
      resolved by the CALLER into the existing ``page_size`` argument.
    """
    # 2026-09-15: ONE capability probe (core.reports.pdf_engine).  The old
    # ``except ImportError`` missed the common failure -- package installed,
    # native Pango/GObject missing -> OSError -> an opaque 500.
    _load_weasyprint()

    # 2026-10-04: the PDF MEMORY CEILING, enforced where every flat PDF is
    # built (routes, token links, subscription delivery).  The routes cut
    # BEFORE calling (they execute for ceiling+1 rows and disclose it), so
    # this is the backstop for any caller that hands over more -- delivery
    # sends up to delivery.max_pdf_rows (10,000 = ~1 GB of WeasyPrint).
    _ceiling = _pdf_max_rows()
    if _ceiling > 0 and len(rows) > _ceiling:
        rows = rows[:_ceiling]
        _cut = _pdf_ceiling_disclosure(_ceiling, _ceiling)
        disclosure_text = f"{_cut} {disclosure_text}" if disclosure_text else _cut

    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    _col_css = _column_css_map(column_styles, columns) if column_styles else {}

    def _th_attr(c):
        _ccss = _col_css.get(c, "")
        return f' style="{_ccss}"' if _ccss else ""

    thead = "".join(f"<th{_th_attr(c)}>{_html_mod.escape(str(c))}</th>"
                    for c in columns)
    # GAP-2: value-based rules land on the <td> (the cell's own red-negative
    # span stays INSIDE the cell content, unchanged).  With no rules the
    # loop emits exactly the historical markup — no style attribute at all.
    _rules_bc = _rules_by_column(fmt_rules)
    if sections:
        table_body, _n_data_rows = _banded_tbody_html(
            _banded_layout(rows, sections), columns, col_fmt_map, neg_fmt,
            _rules_bc, _col_css, bool(sections.get("page_break_between")))
    else:
        tbody_rows = [_pdf_data_tr(row, columns, col_fmt_map, neg_fmt,
                                   _rules_bc, _col_css) for row in rows]
        table_body = f"<tbody>{''.join(tbody_rows)}</tbody>"
        _n_data_rows = len(tbody_rows)

    cert_html = (f'<p class="cert-footer">{_html_mod.escape(footer_text)}</p>'
                 if footer_text else "")
    disclosure_html = (f'<div class="truncation-note">{_html_mod.escape(disclosure_text)}</div>'
                       if disclosure_text else "")

    # Report/page header + footer text (legacy ReportPDFConfig vocabulary).
    # Every default below reproduces the historical bytes exactly.
    _layout = pdf_layout or {}
    _subtitle = _layout.get("header_text") or ""
    _cover_html = ""
    if _layout.get("include_cover"):
        _cover_html = (
            f'<div class="cover-page">'
            f'<div class="cover-title">{_html_mod.escape(report_name)}</div>'
            + (f'<div class="cover-subtitle">{_html_mod.escape(_subtitle)}</div>'
               if _subtitle else "")
            + f'<div class="cover-date">Generated {now_str}</div></div>')
    if _layout.get("include_header", True):
        _hdr_html = (f'<div class="page-header"><span class="header-title">'
                     f'{_html_mod.escape(report_name)}</span>\n'
                     f'<span class="run-date">{now_str}</span></div>')
    else:
        _hdr_html = ""
    _sub_html = (f'<div class="doc-subtitle">{_html_mod.escape(_subtitle)}</div>'
                 if _subtitle else "")

    _cv_above = (canvas.get("above") + "\n") if canvas and canvas.get("above") else ""
    _cv_below = ("\n" + canvas.get("below")) if canvas and canvas.get("below") else ""
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{_html_mod.escape(report_name)}</title></head>
<body>
{_cover_html}{_hdr_html}{_sub_html}
{disclosure_html}
{_cv_above}<table><thead><tr>{thead}</tr></thead>{table_body}</table>
<p class="row-count">{_n_data_rows:,} row(s)</p>
{cert_html}{_cv_below}
</body></html>"""

    _body_fs = f"{_layout['font_size']:g}" if _layout.get("font_size") else "10"
    if not _layout.get("include_footer", True):
        _footer_block = ""
    elif _layout.get("footer_text"):
        _footer_block = (f"@bottom-center {{ content: "
                         f"{_css_footer_content(_layout['footer_text'])};\n"
                         f"                   font-size: 8pt; color: #888; }} ")
    else:
        _footer_block = ('@bottom-center { content: "Generated by QueryStudio '
                         '| Page " counter(page) " of " counter(pages);'
                         f'\n'
                         '                   font-size: 8pt; color: #888; } ')

    css = f"""@page {{ size: {page_size}; margin: 15mm 12mm 18mm 12mm;
  {_footer_block}}}
body {{ font-family: Arial, sans-serif; font-size: {_body_fs}pt; color: #222; }}
table {{ border-collapse: collapse; width: 100%; font-size: 9pt; }}
thead tr {{ background: #{header_bg}; color: #{header_text}; }}
th {{ padding: 5pt 6pt; text-align: left; font-weight: bold; white-space: nowrap; }}
td {{ padding: 3pt 6pt; border-bottom: 1px solid #e0e0e0; }}
tr:nth-child(even) {{ background: #f5f7fa; }}
.page-header {{ display: flex; justify-content: space-between; margin-bottom: 6pt;
               font-size: 9pt; color: #555; border-bottom: 1px solid #ccc; padding-bottom: 3pt; }}
.header-title {{ font-weight: bold; }}
.row-count {{ font-size: 8pt; color: #999; margin-top: 6pt; }}
.cert-footer {{ font-size: 8pt; color: #777; margin-top: 2pt; font-style: italic; }}
.truncation-note {{ background: #FFF3E0; border: 1pt solid #E65100; color: #7A3E00;
                   padding: 5pt 8pt; margin: 4pt 0 6pt 0; font-size: 9pt;
                   font-weight: bold; }}"""

    if _sub_html or _cover_html:
        css += """
.doc-subtitle { font-size: 10pt; color: #333; margin: 0 0 6pt 0; }
.cover-page { page-break-after: always; text-align: center; padding-top: 80mm; }
.cover-title { font-size: 24pt; font-weight: bold; }
.cover-subtitle { font-size: 14pt; color: #555; margin-top: 8pt; }
.cover-date { font-size: 10pt; color: #888; margin-top: 16pt; }"""
    if sections:
        css += f"""
tbody.band-group {{ break-inside: avoid; }}
tbody.band-break {{ page-break-before: always; }}
tr.band-header {{ page-break-after: avoid; }}
tr.band-header td {{ background: #{sections["subtotal_bg"]}; font-weight: bold;
                    border-top: 1pt solid #bbb; }}
.band-count {{ font-weight: normal; color: #777; font-size: 8pt; }}
tr.band-subtotal {{ page-break-before: avoid; }}
tr.band-subtotal td {{ background: #{sections["subtotal_bg"]}; font-weight: bold;
                      border-top: 1pt solid #999; }}
tr.grand-total {{ page-break-before: avoid; }}
tr.grand-total td {{ background: #{sections["grand_total_bg"]}; font-weight: bold;
                    border-top: 2pt solid #444; }}"""

    if canvas and canvas.get("css"):
        css += canvas["css"]
    # THE door (core.reports.pdf_engine.render_pdf): isolated, budgeted.
    return _render_pdf_document(html, css)


# The xlsx FORMAT holds at most 1,048,576 rows per worksheet — a format
# limit, not a policy.  One header row per sheet ⇒ this many DATA rows fit.
# Exports larger than this continue onto additional sheets (never a refusal).
_XLSX_MAX_DATA_ROWS_PER_SHEET = 1_048_576 - 1


def _render_excel_bytes(rows: list, columns: list, report_name: str,
                        header_bg: str, header_text: str, neg_fmt: str,
                        stripe_rows: bool, col_fmt_map: dict,
                        footer_text: str = "",
                        disclosure_text: str = "",
                        max_rows_per_sheet: int | None = None,
                        fmt_rules: list | None = None,
                        sections: dict | None = None,
                        column_styles: dict | None = None) -> bytes:
    """Render rows/columns to Excel (.xlsx) bytes via openpyxl. Reusable across endpoints.

    2026-08-09 caps-throttle-not-refuse:

    * ``disclosure_text`` (optional): a truncation disclosure written INTO the
      workbook (bold, beneath the data) — the file must carry its own truth,
      not only the X-QS-* response headers.  Empty ⇒ no line (unchanged output).
    * Results that exceed the xlsx sheet FORMAT limit (1,048,576 rows) no
      longer 413: they continue across additional sheets via a streaming
      (write-only) workbook, plus a final "Export Info" sheet stating exactly
      which rows live on which sheet.  Results that fit one sheet keep the
      original single-sheet path byte-for-byte (styling, stripes, widths).
    * ``max_rows_per_sheet`` exists for tests to exercise the multi-sheet
      logic without building a million-row fixture; production callers leave
      it None (= the real format limit).
    """
    per_sheet = int(max_rows_per_sheet or _XLSX_MAX_DATA_ROWS_PER_SHEET)
    # 2026-10-04: ALSO above excel_styled_max_rows -- the styled object model
    # costs ~2 KB of heap per row (measured; 1M rows ~2 GB, the live 309 s
    # near-OOM export).  Every caller of this renderer (report routes, token
    # links, dashboards, delivery) gets the bounded path past it.
    _styled_max = _excel_styled_max_rows()
    if len(rows) > per_sheet or (_styled_max > 0 and len(rows) > _styled_max):
        return _render_excel_multisheet_bytes(
            rows, columns, report_name, header_bg, header_text, neg_fmt,
            col_fmt_map, footer_text=footer_text,
            disclosure_text=disclosure_text, per_sheet=per_sheet,
            fmt_rules=fmt_rules, banded_omitted=bool(sections),
            column_styles=column_styles)

    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = report_name[:31]

    header_font = Font(bold=True, color=header_text, size=10)
    header_fill = PatternFill(start_color=header_bg, end_color=header_bg, fill_type="solid")
    stripe_fill = PatternFill(start_color="F9F9F9", end_color="F9F9F9", fill_type="solid")
    for col_idx, col_name in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=_xl_safe(col_name))
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="left")

    # Resolve Excel number formats per column
    col_xl_fmt: dict = {}
    for col_name in columns:
        xl = _resolve_xl_format(col_fmt_map.get(col_name, ""), neg_fmt)
        if xl:
            col_xl_fmt[col_name] = xl

    # GAP-2: value-based rules — the matched rule's fill/font is applied
    # AFTER the cosmetic stripe so the flag always wins.  Empty rules ⇒ the
    # per-cell branch is never entered (zero-cost, unchanged workbook).
    _rules_bc = _rules_by_column(fmt_rules)

    def _write_data_row(row_idx: int, row) -> None:
        # THE one data-cell emitter — shared by the flat and banded paths
        # (number format, stripe, per-column style, then value-based rule,
        # which always wins).  With no column styles/rules the emitted
        # workbook is exactly the historical one.
        for col_idx, col_name in enumerate(columns, 1):
            val = row.get(col_name) if isinstance(row, dict) else row
            cell = ws.cell(row=row_idx, column=col_idx, value=_xl_safe(val))
            if isinstance(val, (int, float)) and col_name in col_xl_fmt and col_xl_fmt[col_name]:
                cell.number_format = col_xl_fmt[col_name]
            if stripe_rows and row_idx % 2 == 1:
                cell.fill = stripe_fill
            if column_styles:
                _st = column_styles.get(col_name)
                if _st:
                    if _st.get("align"):
                        cell.alignment = Alignment(horizontal=_st["align"])
                    if _st.get("font_size") or _st.get("bold"):
                        cell.font = Font(size=_st.get("font_size") or 11,
                                         bold=bool(_st.get("bold")))
            if _rules_bc:
                _cf = _xl_conditional_style(col_name, val, _rules_bc)
                if _cf:
                    _bg, _txt, _bold = _cf
                    if _bg:
                        cell.fill = PatternFill(start_color=_bg, end_color=_bg,
                                                fill_type="solid")
                    if _txt or _bold:
                        cell.font = Font(color=_txt or None, bold=bool(_bold))

    if sections:
        # BANDED path (2026-08-30): group header rows, detail rows, group
        # subtotal rows, grand total — the same _banded_layout events the
        # PDF consumes, so the two documents cannot disagree on grouping or
        # totals.  Subtotal/total cells keep the column's number format.
        from openpyxl.worksheet.pagebreak import Break
        _sub_fill = PatternFill(start_color=sections["subtotal_bg"],
                                end_color=sections["subtotal_bg"],
                                fill_type="solid")
        _gt_fill = PatternFill(start_color=sections["grand_total_bg"],
                               end_color=sections["grand_total_bg"],
                               fill_type="solid")
        _band_font = Font(bold=True)
        _r = 1
        for ev in _banded_layout(rows, sections):
            _r += 1
            kind = ev["kind"]
            if kind == "group_header":
                if (sections.get("page_break_between") and ev["level"] == 0
                        and _r > 2):
                    # Print-layout page break between top-level groups.
                    ws.row_breaks.append(Break(id=_r - 1))
                for col_idx in range(1, len(columns) + 1):
                    ws.cell(row=_r, column=col_idx).fill = _sub_fill
                _hc = ws.cell(
                    row=_r, column=1,
                    value=(f"{ev['value']} ({ev['count']:,} "
                           f"row{'s' if ev['count'] != 1 else ''})"))
                _hc.font = _band_font
                _hc.fill = _sub_fill
                if ev["level"]:
                    _hc.alignment = Alignment(indent=ev["level"])
            elif kind == "data":
                _write_data_row(_r, ev["row"])
            else:   # subtotal / grand_total
                totals = ev["totals"]
                _fill = _sub_fill if kind == "subtotal" else _gt_fill
                if kind == "subtotal":
                    label = f"Subtotal: {ev['value']}"
                    if ev.get("count") is not None:
                        label += (f" ({ev['count']:,} "
                                  f"row{'s' if ev['count'] != 1 else ''})")
                else:
                    label = "Grand Total"
                # Label lands in the first column carrying no total (the
                # break column never carries one) — same rule as the PDF.
                _label_col = next((c for c in columns if c not in totals),
                                  None)
                for col_idx, col_name in enumerate(columns, 1):
                    val = totals.get(col_name)
                    if col_name == _label_col:
                        val = label
                    cell = ws.cell(row=_r, column=col_idx, value=_xl_safe(val))
                    cell.fill = _fill
                    cell.font = _band_font
                    if (isinstance(val, (int, float))
                            and col_xl_fmt.get(col_name)):
                        cell.number_format = col_xl_fmt[col_name]
        _last_row = _r
    else:
        for row_idx, row in enumerate(rows, 2):
            _write_data_row(row_idx, row)
        _last_row = len(rows) + 1

    for col_idx, col_name in enumerate(columns, 1):
        max_len = len(str(col_name))
        for row in rows[:100]:
            val = str(row.get(col_name, "") if isinstance(row, dict) else "")
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = min(max_len + 2, 40)

    # Per-column presentation: an author width overrides the sampled one
    # (validated 1..120 in _extract_column_styles; Excel width units are
    # character-ish, the same unit the author's number expresses).
    if column_styles:
        for col_idx, col_name in enumerate(columns, 1):
            _w = (column_styles.get(col_name) or {}).get("width")
            if _w:
                ws.column_dimensions[
                    openpyxl.utils.get_column_letter(col_idx)].width = _w

    ws.freeze_panes = "A2"

    # Truncation disclosure — bold line two rows below data (before the cert
    # footer).  Written only when the caller detected a limit hit, so output
    # is unchanged for complete results.
    _next_footer_row = _last_row + 2
    if disclosure_text:
        dcell = ws.cell(row=_next_footer_row, column=1, value=disclosure_text)
        dcell.font = Font(bold=True, color="B45309", size=9)
        _next_footer_row += 1

    # Completeness Certificate footer — muted italic line below data.
    if footer_text:
        fcell = ws.cell(row=_next_footer_row, column=1, value=footer_text)
        fcell.font = Font(italic=True, color="777777", size=9)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _render_excel_multisheet_bytes(rows: list, columns: list, report_name: str,
                                   header_bg: str, header_text: str,
                                   neg_fmt: str, col_fmt_map: dict,
                                   *, footer_text: str = "",
                                   disclosure_text: str = "",
                                   per_sheet: int = _XLSX_MAX_DATA_ROWS_PER_SHEET,
                                   fmt_rules: list | None = None,
                                   banded_omitted: bool = False,
                                   column_styles: dict | None = None,
                                   ) -> bytes:
    """Streaming multi-sheet Excel render for results beyond the sheet limit.

    2026-08-09 caps-throttle-not-refuse: the 1,048,576-row bound is an xlsx
    FORMAT limit, not a policy — so the export spills onto additional sheets
    instead of refusing (the old HTTP 413 fired AFTER the report had already
    executed: work done, data withheld — exactly backwards).

    Engineering choices, on the record:
    * openpyxl write-only mode — cells are serialized and discarded as rows
      are appended, so the render adds O(1 row) overhead on top of the rows
      list the caller already holds (the regular object model would build
      10M+ styled cell objects for a 1M-row export).
    * Header styling + per-column number formats are kept (WriteOnlyCell);
      row striping is dropped on this path — it is cosmetic, and a per-cell
      fill on millions of cells is exactly the kind of resource waste the
      streaming path exists to avoid.  Nothing about the DATA differs.
    * Data sheets come FIRST (sheet 0 = first rows — anything reading "the
      first sheet" still sees data); a final "Export Info" sheet discloses
      exactly which rows live on which sheet, the total, and any truncation
      disclosure — the workbook carries its own truth.
    """
    from core.reports.export_stream import iter_record_rows

    buf = io.BytesIO()
    _write_excel_streaming(
        buf, columns, iter_record_rows(rows, columns), report_name,
        header_bg, header_text, neg_fmt, col_fmt_map,
        footer_text=footer_text, disclosure_text=disclosure_text,
        per_sheet=per_sheet, fmt_rules=fmt_rules,
        banded_omitted=banded_omitted, column_styles=column_styles)
    return buf.getvalue()


class _StreamedSheets:
    """The data sheets of a write-only workbook, opened as rows arrive: a new
    sheet (header, widths, frozen pane) every ``per_sheet`` data rows."""

    def __init__(self, wb, columns: list, report_name: str, widths: list,
                 header_bg: str, header_text: str, per_sheet: int,
                 sheet_base: str | None = None):
        from openpyxl.styles import Alignment, Font, PatternFill
        self._wb = wb
        self._columns = columns
        self._widths = widths
        self._per_sheet = per_sheet
        self._font = Font(bold=True, color=header_text, size=10)
        self._fill = PatternFill(start_color=header_bg, end_color=header_bg,
                                 fill_type="solid")
        self._align = Alignment(horizontal="left")
        # Leave room in the 31-char sheet-title limit for the " (NN)" suffix.
        self._base = (sheet_base or _sanitize_export_filename(report_name)[:24] or "Data")
        self.titles: list = []
        self.ws = None
        self._in_sheet = 0

    def open_next(self):
        from openpyxl.cell import WriteOnlyCell
        from openpyxl.utils import get_column_letter
        i = len(self.titles)
        title = (self._base if i == 0 else f"{self._base} ({i + 1})")[:31]
        self.titles.append(title)
        ws = self._wb.create_sheet(title=title)
        for idx, w in enumerate(self._widths, 1):
            ws.column_dimensions[get_column_letter(idx)].width = w
        ws.freeze_panes = "A2"
        header = []
        for col_name in self._columns:
            c = WriteOnlyCell(ws, value=_xl_safe(col_name))
            c.font = self._font
            c.fill = self._fill
            c.alignment = self._align
            header.append(c)
        ws.append(header)
        self.ws = ws
        self._in_sheet = 0
        return ws

    def sheet_for_next_row(self):
        if self.ws is None or self._in_sheet >= self._per_sheet:
            self.open_next()
        self._in_sheet += 1
        return self.ws


def _excel_widths(columns: list, sample: list, column_styles: Optional[dict]) -> list:
    """Column widths from the first 100 rows (tuples in ``columns`` order) --
    the single-sheet path's rule -- with an author width winning."""
    widths: list = []
    for i, col_name in enumerate(columns):
        max_len = len(str(col_name))
        for row in sample[:100]:
            val = str(row[i] if i < len(row) else "")
            if len(val) > max_len:
                max_len = len(val)
        widths.append(min(max_len + 2, 40))
    if column_styles:
        # Author widths survive the spill; per-cell alignment/font do not —
        # same posture as row striping on this path (cosmetics dropped at
        # streaming scale, DATA identical).
        for _i, _cn in enumerate(columns):
            _w = (column_styles.get(_cn) or {}).get("width")
            if _w:
                widths[_i] = _w
    return widths


_XL_FORMULA_LEADS = ("=", "+", "-", "@", "\t", "\r")


def _xl_safe(v):
    """A cell value that a spreadsheet will SHOW, never RUN (2026-10-26).

    openpyxl stores any text starting with "=" as a formula, and Excel also
    evaluates text led by + - @ tab CR: a source value such as
    ``=HYPERLINK("http://...")`` in a counterparty name became a live formula
    in every Excel export.  Text with such a lead is written with a leading
    apostrophe (the OWASP spreadsheet-injection rule); numbers, dates and
    NULLs are untouched.  CSV exports stay raw -- they are the data contract
    machines read (the published API's bulk.csv among them)."""
    if isinstance(v, str) and v.startswith(_XL_FORMULA_LEADS):
        return "'" + v
    return v


def _excel_out_row(ws, row: tuple, columns: list, col_xl_fmt: dict,
                   rules_bc: dict) -> list:
    """One data row for a write-only sheet: number formats, and the
    value-based rules (GAP-2: unlike row striping, a value-based flag
    carries MEANING and must not vanish past the spill)."""
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font, PatternFill
    out = []
    for i, col_name in enumerate(columns):
        val = row[i]
        fmt = col_xl_fmt.get(col_name)
        _cf = (_xl_conditional_style(col_name, val, rules_bc)
               if rules_bc else None)
        if _cf or (fmt and isinstance(val, (int, float))):
            c = WriteOnlyCell(ws, value=_xl_safe(val))
            if fmt and isinstance(val, (int, float)):
                c.number_format = fmt
            if _cf:
                _bg, _txt, _bold = _cf
                if _bg:
                    c.fill = PatternFill(start_color=_bg, end_color=_bg,
                                         fill_type="solid")
                if _txt or _bold:
                    c.font = Font(color=_txt or None, bold=bool(_bold))
            out.append(c)
        else:
            out.append(_xl_safe(val))
    return out


def _write_excel_info_sheet(wb, report_name: str, total: int, titles: list,
                            per_sheet: int, banded_omitted: bool,
                            disclosure_text: str, footer_text: str) -> None:
    """The "Export Info" sheet, LAST: the workbook states exactly what it
    contains.  When it carries a disclosure it is also the sheet the
    workbook OPENS on (2026-10-04) -- a cut workbook says so before anyone
    reads a row, while sheet 0 stays the first data sheet."""
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font
    info = wb.create_sheet(title="Export Info")
    info.column_dimensions["A"].width = 100
    bold = Font(bold=True, size=10)
    title_cell = WriteOnlyCell(info, value=f"Report: {report_name}")
    title_cell.font = bold
    info.append([title_cell])
    if disclosure_text:
        d_top = WriteOnlyCell(info, value=disclosure_text)
        d_top.font = Font(bold=True, color="B45309", size=11)
        info.append([d_top])
    summary = WriteOnlyCell(
        info,
        value=(f"This workbook contains {total:,} data rows across "
               f"{max(1, len(titles))} sheet(s) — Excel holds at most "
               f"{per_sheet:,} data rows per sheet."))
    summary.font = bold
    info.append([summary])
    if banded_omitted:
        # A band that cannot be rendered is never silently dropped: at this
        # scale the banded layout (group headers / subtotals / grand total)
        # is not applied, and the workbook says so.
        _bnote = WriteOnlyCell(
            info,
            value=("This report defines a banded layout (group headers and "
                   "subtotals). It is not applied at this scale — the "
                   "export is streamed, so data is flat; use the "
                   "PDF export or a smaller result for the banded "
                   "document."))
        _bnote.font = Font(bold=True, color="B45309", size=9)
        info.append([_bnote])
    for i, title in enumerate(titles):
        start = i * per_sheet
        end = min(start + per_sheet, total)
        info.append([f"Sheet '{title}': rows {start + 1:,} to {end:,}"])
    if disclosure_text:
        d = WriteOnlyCell(info, value=disclosure_text)
        d.font = Font(bold=True, color="B45309", size=9)
        info.append([d])
    if footer_text:
        f = WriteOnlyCell(info, value=footer_text)
        f.font = Font(italic=True, color="777777", size=9)
        info.append([f])
    if disclosure_text:
        wb.active = len(wb.worksheets) - 1


def _write_excel_streaming(sink, columns: list, row_batches, report_name: str,
                           header_bg: str, header_text: str, neg_fmt: str,
                           col_fmt_map: dict, *, footer_text: str = "",
                           disclosure_text: str = "",
                           disclosure_for=None,
                           per_sheet: Optional[int] = None,
                           fmt_rules: list | None = None,
                           banded_omitted: bool = False,
                           column_styles: dict | None = None,
                           wb=None, sheet_base: str | None = None) -> int:
    """THE streaming Excel writer (2026-10-04): a write-only workbook fed
    batch by batch (lists of tuples in ``columns`` order -- see
    ``core.reports.export_stream``), a new sheet every ``per_sheet`` data
    rows, the "Export Info" sheet last.  Memory is one batch plus openpyxl's
    per-sheet temp file -- measured flat (~65 MB) at 1M rows.  Writes to
    ``sink`` (a path or a binary file object) and returns the data rows
    written.  ``disclosure_for(rows_written)`` (optional) supplies the
    disclosure once the count is known.

    ``wb`` / ``sheet_base`` (2026-10-26, the report canvas): a write-only
    workbook that already holds the canvas sheet, and the data sheets'
    name ("Rows") -- the rows then follow the canvas, same writer.
    """
    import itertools

    import openpyxl

    # Resolved at CALL time (the module constant is the xlsx format limit).
    per_sheet = max(1, int(per_sheet or _XLSX_MAX_DATA_ROWS_PER_SHEET))
    if wb is None:
        wb = openpyxl.Workbook(write_only=True)
    col_xl_fmt: dict = {}
    for col_name in columns:
        xl = _resolve_xl_format((col_fmt_map or {}).get(col_name, ""), neg_fmt)
        if xl:
            col_xl_fmt[col_name] = xl
    rules_bc = _rules_by_column(fmt_rules)

    batches = iter(row_batches)
    first = next(batches, [])
    sheets = _StreamedSheets(
        wb, list(columns), report_name,
        _excel_widths(list(columns), first, column_styles),
        header_bg, header_text, per_sheet, sheet_base=sheet_base)
    total = 0
    for chunk in itertools.chain([first], batches):
        for row in chunk:
            ws = sheets.sheet_for_next_row()
            ws.append(_excel_out_row(ws, row, columns, col_xl_fmt, rules_bc))
        total += len(chunk)
    if not sheets.titles:
        sheets.open_next()              # an empty result still has its header
    if disclosure_for is not None:
        disclosure_text = disclosure_for(total) or ""
    _write_excel_info_sheet(wb, report_name, total, sheets.titles, per_sheet,
                            banded_omitted, disclosure_text, footer_text)
    wb.save(sink)
    return total


def _export_truncation_disclosure(fmt: str, rows_served: int,
                                  effective_limit: int,
                                  total_rows: Optional[int] = None) -> str:
    """The one wording chokepoint for export truncation disclosure.

    Returns "" when the export is complete; otherwise the exact sentence that
    goes ON the document (PDF banner / Excel line).

    Two independent reasons a file can be short, in priority order:

    * MEMORY GATE (SCALE-1) — ``total_rows`` is known and exceeds
      ``rows_served``: the result was cut so a single synchronous request
      would not OOM the pod.  Here the true total IS known, so we state it and
      point at the background download (Download Centre) for everything.
    * ROW-LIMIT throttle — the caller's ``effective_limit`` was reached.  The
      true total is unknown by construction (execution itself stopped at the
      limit), so we state only what IS known: rows held + limit reached.
    """
    if total_rows is not None and total_rows > rows_served:
        return (f"This export contains the first {rows_served:,} of "
                f"{total_rows:,} rows — a large result is capped for memory "
                f"safety on this request. Use the background download "
                f"(Download Centre) for the complete data.")
    if not effective_limit or rows_served < effective_limit:
        return ""
    return (f"This export contains the first {rows_served:,} rows — the row "
            f"limit of {effective_limit:,} was reached, so the full result "
            f"may be larger. Re-run with a higher limit, or use the CSV "
            f"export, for the complete data.")


def _render_csv_bytes(rows: list, columns: list) -> bytes:
    """Render rows/columns to CSV bytes (UTF-8 with BOM). Reusable across endpoints."""
    buf = io.StringIO()
    writer = _csv_mod.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(row if isinstance(row, dict) else {})
    return buf.getvalue().encode("utf-8-sig")


# ── GAP-2 (2026-08-30): running calculations in exports ──────────────────────
# The UI computes running_sum / rank / percent_of_total / previous_value over
# the report's display order (useReportEngine.applyRunningCalculations), and
# core/reports/microcube.read_artifact_running_calcs reproduces those
# semantics EXACTLY server-side — but no export renderer ever received them,
# so the figure on screen was absent from the document.  The helpers below
# compute the calc columns over EXACTLY the rows an export is about to render
# (post row-limit slice, in display order) by writing those rows to a
# temporary parquet with a synthetic row index and calling the microcube
# function BY IMPORT — the window logic lives in one place and cannot drift.
#
# Grouping cannot change the data: the unique row index is a dimension, so
# every "group" is one input row, and sort_column=<index> pins __row_idx (the
# window order) to the export's display order.
#
# TRUNCATION DECISION (deliberate): a running calculation in an export is
# computed over the rows IN THE DOCUMENT, not the full result.  Rationale:
# (a) the screen computes over the rows the client loaded, so over-the-cut
# values are what the user saw for those rows (a running sum's prefix is
# stable under truncation; rank/percent over a hidden remainder would be
# numbers no surface ever showed); (b) computing over the full artifact and
# then cutting would make the visible percent_of_total column not sum to 100
# with no visible explanation.  When the export IS truncated, the existing
# disclosure banner (the document's own truth) gains one sentence saying the
# calc columns cover only the included rows — see
# _running_calc_disclosure_suffix.  CSV keeps the house posture: the format
# cannot carry an in-file note (it would corrupt parsers), so its disclosure
# stays the X-QS-* headers + [br-serve] log line.

def _running_calc_defs_for_export(report: dict, ds_cols: list,
                                  columns: list,
                                  notes_sink: Optional[list] = None) -> list:
    """Normalise a report's stored running_calculations for export rendering.

    Stored shape (core/db/models.py BusinessReport): ``{name, calc_type,
    measure_col_id, partition_col_id, format_pattern}``; name-based spellings
    (``measure`` / ``measure_col_name``) are accepted too, mirroring the
    microcube.  A definition that cannot be rendered against THESE result
    columns (measure not exported, unknown type, name collision) is skipped
    WITH A LOG LINE — the screen cannot render such a calc either, so
    skipping keeps export == screen; silently guessing would not.
    """
    rcs = report.get("running_calculations") or []
    if not rcs:
        return []
    if ((report.get("layout_config") or {}).get("report_type")) == "pivot":
        return []   # calcs are a flat-report feature; pivot renders a matrix
    id_to_name = {c.get("id"): c.get("physical_name")
                  for c in (ds_cols or []) if c.get("id") is not None}
    col_set = set(columns or [])
    defs: list = []
    taken = set(col_set)
    for rc in rcs:
        if not isinstance(rc, dict):
            logger.warning("[export-calcs] skipping non-object running calc %r", rc)
            continue
        name = str(rc.get("name") or "").strip()
        ctype = rc.get("calc_type")
        mname = rc.get("measure") or rc.get("measure_col_name")
        if not mname and rc.get("measure_col_id") is not None:
            mname = id_to_name.get(rc.get("measure_col_id"))
        pname = rc.get("partition") or rc.get("partition_col_name")
        # 2026-08-30: remember that a partition was ASKED FOR, separately
        # from whether it resolved.  An id that maps to no column left
        # pname None, which is indistinguishable from "no partition
        # requested", so the calc rendered UNPARTITIONED -- a different
        # number under the author's own column name, with no log line.
        # Measured on region/amt = E:10, E:20, W:5 --
        #   partition by region : RT = [10, 30,  5]   (what was asked)
        #   partition id missing: RT = [10, 30, 35]   (what was sent)
        # The measure branch below already distinguishes these two
        # ("not mname or ..."); the partition branch did not.
        _part_requested = bool(pname) or rc.get("partition_col_id") is not None
        if not pname and rc.get("partition_col_id") is not None:
            pname = id_to_name.get(rc.get("partition_col_id"))
        problem = None
        if not name:
            problem = "empty name"
        elif name in taken:
            problem = f"name {name!r} collides with a result column"
        elif ctype not in ("running_sum", "rank", "percent_of_total",
                          "previous_value"):
            problem = f"unknown calc_type {ctype!r}"
        elif not mname or mname not in col_set:
            problem = f"measure column {mname!r} is not in the exported columns"
        elif _part_requested and (not pname or pname not in col_set):
            _asked = pname or rc.get("partition_col_id")
            problem = (f"partition column {_asked!r} was requested but "
                       "is not in the exported columns")
        if problem:
            logger.warning("[export-calcs] skipping running calc %r on report "
                           "%s: %s", rc.get("name"), report.get("id"), problem)
            # 2026-08-30: say it ON THE DOCUMENT too, the way a skipped
            # BAND already does.  A log line reaches the operator; the
            # person holding a report missing a column the author
            # designed sees nothing and cannot tell it from a report
            # that never had one.
            if notes_sink is not None:
                _who = name or rc.get("name") or "a running calculation"
                notes_sink.append(
                    f"Running calculation {_who!r} is not shown: {problem}.")
            continue
        taken.add(name)
        defs.append({"name": name, "calc_type": ctype,
                     "measure": mname, "partition": pname})
    return defs


def _augment_rows_with_running_calcs(rows: list, columns: list, report: dict,
                                     ds_cols: list,
                                     notes_sink: Optional[list] = None) -> tuple:
    """Append the report's running-calculation columns to export rows.

    Returns ``(rows, columns)``.  When the report declares no applicable
    calcs the VERY SAME input objects are returned — a report without
    running calculations renders byte-identically to today (asserted by
    identity in tests, not just equality).

    Correctness GATES (fail loud, never a divergent document): the computed
    page must come back with one row per input row, in input order — both
    are asserted against the synthetic index.  Synchronous (DuckDB work) —
    callers use ``asyncio.to_thread``.
    """
    defs = _running_calc_defs_for_export(report, ds_cols, columns, notes_sink)
    if not defs:
        return rows, columns
    calc_names = [d["name"] for d in defs]
    out_columns = list(columns) + calc_names
    if not rows:
        return rows, out_columns   # headers still declare the columns

    import tempfile

    import pandas as pd

    from core.reports import microcube as _mc

    needed: list = []
    for d in defs:
        for c in (d["measure"], d["partition"]):
            if c and c not in needed:
                needed.append(c)
    idx_col = "__qs_export_row"
    while idx_col in columns or idx_col in calc_names:
        idx_col += "_"

    frame = {idx_col: list(range(len(rows)))}
    for c in needed:
        frame[c] = [(r.get(c) if isinstance(r, dict) else None) for r in rows]
    df = pd.DataFrame(frame)

    tmp = tempfile.NamedTemporaryFile(suffix=".parquet", delete=False)
    tmp.close()
    tmp_path = Path(tmp.name)
    try:
        try:
            df.to_parquet(tmp_path)
        except Exception:
            # Mixed-type object columns (inline PV/FV rows) — stringify,
            # preserving None/NULL.  The microcube TRY_CASTs measures to
            # DOUBLE, so numeric strings compute identically (Number(v)||0
            # semantics), and partition equality is preserved.
            for c in needed:
                df[c] = df[c].map(lambda v: None if v is None else str(v))
            df.to_parquet(tmp_path)
        out = _mc.read_artifact_running_calcs(
            tmp_path,
            dimensions=[idx_col] + needed,
            measures=[],
            calcs=defs,
            sort_column=idx_col, sort_direction="asc",
            page=1, page_size=0,          # 0 = the full result, no paging
            artifact_grain=_mc.GRAIN_DETAIL)
    finally:
        try:
            tmp_path.unlink()
        except OSError:
            pass

    recs = out.get("rows") or []
    if len(recs) != len(rows):
        raise RuntimeError(
            f"running-calc computation returned {len(recs)} rows for "
            f"{len(rows)} input rows — refusing to render a document that "
            f"diverges from the screen")
    out_rows: list = []
    for i, (row, rec) in enumerate(zip(rows, recs)):
        if int(rec.get(idx_col, -1)) != i:
            raise RuntimeError(
                "running-calc rows came back out of display order — refusing "
                "to render a document that diverges from the screen")
        nr = dict(row) if isinstance(row, dict) else {}
        for name in calc_names:
            nr[name] = rec.get(name)
        out_rows.append(nr)
    return out_rows, out_columns


def _running_calc_disclosure_suffix(augmented: bool, truncated: bool) -> str:
    """One sentence appended to the truncation banner when calc columns ride
    a CUT export — the document must carry its own truth about what the
    running numbers cover.  Empty when not augmented or not truncated."""
    if not (augmented and truncated):
        return ""
    return (" Running calculation columns are computed over the rows in "
            "this document only, not the full result.")


# ── BANDED LAYOUT (2026-08-30): section_definitions finally reach the document
# ─────────────────────────────────────────────────────────────────────────────
# ``section_definitions`` has existed on the report model since day one
# ({name, break_column_id, subtotal_measure_ids, show_count} — see
# core/db/models.py BusinessReport) and the SCREEN has always rendered it
# (useReportEngine.buildBandedRows: sort by break column, group header row,
# detail rows, subtotal row per group, grand total at the end) — but no
# export renderer ever received it, so the printed document was a flat table
# of a report the author designed as a BANDED one.  The helpers below are the
# server-side mirror of the screen's banding engine, consumed by BOTH the PDF
# and the single-sheet Excel renderer — one "what is a group"
# (_banded_layout), one total implementation (_section_aggregate) for
# subtotals AND grand totals.
#
# TRUNCATION DECISION (deliberate, same posture as running calcs above):
# subtotals and grand totals are computed over the rows IN THE DOCUMENT
# (post row-limit slice).  A total over a truncated set is a different number
# — so when the export is truncated the existing disclosure banner (the
# document's own truth) gains one sentence saying exactly that
# (_banded_disclosure_suffix).  Totals that silently covered rows the
# document does not show would be unverifiable against the document itself.
#
# A band that cannot be rendered is NEVER silently dropped: every skip
# produces a sentence that rides the on-document disclosure banner (plus a
# log line) — see _banding_spec's ``notes`` return.

_SECTION_AGG_TYPES = frozenset({"sum", "avg", "count", "min", "max",
                                "count_distinct"})


def _section_aggregate(rows: list, column: str, agg_type: str = "sum"):
    """THE one total implementation for banded documents (subtotals + grand).

    Mirrors the screen's aggregateValues (useReportEngine): count_distinct
    counts raw non-empty values; every other aggregation coerces numerics
    (numbers and numeric strings; None and non-numeric text are skipped) and
    returns 0 over an empty set — so a subtotal over a text column shows 0,
    exactly as the screen does, never a crash.
    """
    if agg_type == "count_distinct":
        return len({r.get(column) for r in rows
                    if isinstance(r, dict) and r.get(column) not in (None, "")})
    nums = []
    for r in rows:
        v = r.get(column) if isinstance(r, dict) else None
        if isinstance(v, bool):
            v = int(v)
        elif isinstance(v, str):
            try:
                v = float(v)
            except ValueError:
                continue
        if isinstance(v, (int, float)) and not (
                _math_mod.isnan(v) or _math_mod.isinf(v)):
            nums.append(v)
    if not nums:
        return 0
    if agg_type == "avg":
        return sum(nums) / len(nums)
    if agg_type == "count":
        return len(nums)
    if agg_type == "min":
        return min(nums)
    if agg_type == "max":
        return max(nums)
    return sum(nums)


def _banding_spec(report: dict, ds_cols: list, columns: list) -> tuple:
    """Normalise a report's section_definitions into a render-ready spec.

    Returns ``(spec_or_None, notes)``.  ``spec`` is
    ``{"defs": [{name, break_column, measures: [(col, agg)], show_count,
    page_break}], "subtotal_bg", "grand_total_bg", "page_break_between"}``;
    ``notes`` is a list of DISCLOSURE SENTENCES for every band or subtotal
    column that could not be rendered — callers append them to the
    on-document disclosure banner (a dropped band must never be silent).

    Semantics mirror the screen: ids resolve through the dataset columns
    (name spellings ``break_column``/``break_column_name`` and
    ``subtotal_measures``/``subtotal_measure_names`` are accepted too,
    matching the running-calc normaliser above); the aggregation for each
    subtotal measure is the dataset column's declared ``aggregation``
    (default sum), the same source the viewer's measureAggConfigs uses.
    Pivot reports return no spec — the matrix carries its own totals.
    """
    secs = report.get("section_definitions") or []
    if not secs:
        return None, []
    if ((report.get("layout_config") or {}).get("report_type")) == "pivot":
        return None, []
    id_to_col = {c.get("id"): c for c in (ds_cols or [])
                 if isinstance(c, dict) and c.get("id") is not None}
    agg_by_name = {c.get("physical_name"): (c.get("aggregation") or "sum")
                   for c in (ds_cols or []) if isinstance(c, dict)}
    col_set = set(columns or [])
    defs: list = []
    notes: list = []
    for sec in secs:
        if not isinstance(sec, dict):
            notes.append("A section definition on this report is malformed "
                         "and was not rendered.")
            logger.warning("[banded] report %s: non-object section %r skipped",
                           report.get("id"), sec)
            continue
        name = str(sec.get("name") or "Section")
        bname = sec.get("break_column") or sec.get("break_column_name")
        if not bname and sec.get("break_column_id") is not None:
            bname = (id_to_col.get(sec.get("break_column_id")) or {}).get(
                "physical_name")
        if not bname or bname not in col_set:
            notes.append(f"Section '{name}' is not rendered: its break "
                         f"column is not part of this export.")
            logger.warning("[banded] report %s: section %r skipped — break "
                           "column %r not in exported columns",
                           report.get("id"), name, bname)
            continue
        m_names = sec.get("subtotal_measures") or sec.get(
            "subtotal_measure_names")
        if m_names is None:
            m_names = []
            for mid in (sec.get("subtotal_measure_ids") or []):
                mn = (id_to_col.get(mid) or {}).get("physical_name")
                m_names.append(mn if mn else f"column id {mid}")
        measures: list = []
        for mn in (m_names or []):
            if not mn or mn not in col_set:
                notes.append(f"Section '{name}': subtotal column '{mn}' is "
                             f"not part of this export and was omitted.")
                logger.warning("[banded] report %s: section %r subtotal "
                               "column %r not in exported columns — omitted",
                               report.get("id"), name, mn)
                continue
            agg = agg_by_name.get(mn) or "sum"
            if agg not in _SECTION_AGG_TYPES:
                agg = "sum"
            measures.append((mn, agg))
        defs.append({"name": name, "break_column": bname,
                     "measures": measures,
                     "show_count": bool(sec.get("show_count")),
                     "page_break": bool(sec.get("page_break")
                                        or sec.get("page_break_between_groups"))})
    if not defs:
        return None, notes
    sc = (report.get("layout_config") or {}).get("style_config") or {}

    def _band_color(key: str, default: str) -> str:
        v = str(sc.get(key) or "").lstrip("#")
        return v if v and _HEX_RE.match(v) else default

    spec = {
        "defs": defs,
        # The builder's EXISTING style store already carries banding colors
        # (style_config.subtotal_bg / grand_total_bg) — reused, not invented.
        "subtotal_bg": _band_color("subtotal_bg", "F5F5F5"),
        "grand_total_bg": _band_color("grand_total_bg", "E8EAF6"),
        # Page break between top-level groups is the classic banded-report
        # knob (Jasper's isStartNewPage); it rides the outermost section def.
        "page_break_between": bool(defs[0]["page_break"]),
        # 2026-08-30 — the authoring UI emits style_config.show_grand_total and
        # _banded_layout emitted the grand total unconditionally, so the toggle
        # was SAVED AND IGNORED: a control that does nothing. Two parallel
        # workstreams agreed a contract without a shared reader; this is the
        # reader. Default True preserves the behaviour of every report authored
        # before the toggle existed.
        "show_grand_total": bool(sc.get("show_grand_total", True)),
    }
    return spec, notes


def _section_sort_rows(rows: list, defs: list) -> list:
    """Stable sort by the break columns, outermost first — the screen's
    per-level string sort produces this same grouping order."""
    keys = [d["break_column"] for d in defs]

    def _k(r):
        return tuple(
            "" if (not isinstance(r, dict) or r.get(c) is None) else str(r.get(c))
            for c in keys)

    return sorted(rows, key=_k)


def _banded_layout(rows: list, spec: dict) -> list:
    """Group sorted rows into banded events — the ONE "what is a group".

    Returns a flat event list both document renderers consume:
      {"kind": "group_header", level, section, value, count}
      {"kind": "data", row}
      {"kind": "subtotal", level, section, value, totals, count|None}
      {"kind": "grand_total", totals}          (only when measures exist)

    Grouping is by the stringified break value on CONSECUTIVE rows — callers
    pass rows through _section_sort_rows first, mirroring the screen's
    buildSectionLevel (sort → group → header/detail/subtotal, grand total at
    the outermost level over the union of subtotal measures).
    """
    defs = spec["defs"]
    events: list = []

    def _walk(sub_rows: list, level: int) -> None:
        d = defs[level]
        bc = d["break_column"]
        last = level == len(defs) - 1
        groups: list = []
        for r in sub_rows:
            v = r.get(bc) if isinstance(r, dict) else None
            k = "" if v is None else str(v)
            if not groups or groups[-1][0] != k:
                groups.append((k, []))
            groups[-1][1].append(r)
        for k, grows in groups:
            events.append({"kind": "group_header", "level": level,
                           "section": d["name"], "value": k,
                           "count": len(grows)})
            if last:
                for r in grows:
                    events.append({"kind": "data", "row": r})
            else:
                _walk(grows, level + 1)
            totals = {mn: _section_aggregate(grows, mn, agg)
                      for mn, agg in d["measures"]}
            events.append({"kind": "subtotal", "level": level,
                           "section": d["name"], "value": k, "totals": totals,
                           "count": len(grows) if d["show_count"] else None})

    _walk(rows, 0)
    measure_aggs: dict = {}
    for d in defs:
        for mn, agg in d["measures"]:
            measure_aggs.setdefault(mn, agg)
    if measure_aggs and spec.get("show_grand_total", True):
        events.append({"kind": "grand_total",
                       "totals": {mn: _section_aggregate(rows, mn, agg)
                                  for mn, agg in measure_aggs.items()}})
    return events


def _banded_disclosure_suffix(banded: bool, truncated: bool) -> str:
    """One sentence on the banner when subtotals/grand totals ride a CUT
    export — a total over a truncated set is a different number, and the
    document must say whose rows its totals cover."""
    if not (banded and truncated):
        return ""
    return (" Group subtotals and grand totals are computed over the rows "
            "in this document only, not the full result.")


# ── Per-column presentation (width / alignment / font), 2026-08-30 ──────────
# Driven from the EXISTING style store — layout_config.style_config, under
# "column_styles" (the same home conditional_formats took above; never a
# parallel store).  Shape: {physical_name: {width, align, font_size,
# font_weight}}.  Width is a character-ish width (rendered as CSS ``ch`` on
# PDF and as the column width on Excel — the closest unit both media share).
# Every value is whitelist-validated because these land in an inline style=""
# attribute; an invalid value is dropped WITH a log line, never interpolated.

def _extract_column_styles(report: dict, columns: list) -> dict:
    sc = (report.get("layout_config") or {}).get("style_config") or {}
    raw = sc.get("column_styles") or {}
    if not isinstance(raw, dict):
        logger.warning("[col-styles] style_config.column_styles is %s, "
                       "expected object — ignoring", type(raw).__name__)
        return {}
    col_set = set(columns or [])
    out: dict = {}
    for col, st in raw.items():
        if col not in col_set:
            # Nothing to style — but say so.  Everything else in this file
            # that declines to render an author's configuration announces it
            # (a skipped band, a skipped running calc, a dropped colour); a
            # style that silently does nothing leaves the author retrying a
            # setting that was never going to apply.  DEBUG rather than
            # WARNING: a column dropped from an export legitimately leaves
            # its style behind, so this is common and not a fault.
            logger.debug("[col-styles] column %r has a style but is not in "
                         "this export — not applied", col)
            continue
        if not isinstance(st, dict):
            logger.warning("[col-styles] style for column %r is %s, expected "
                           "object — ignoring", col, type(st).__name__)
            continue
        entry: dict = {}
        w = st.get("width")
        if isinstance(w, (int, float)) and not isinstance(w, bool) and 1 <= w <= 120:
            entry["width"] = float(w)
        elif w is not None:
            logger.warning("[col-styles] dropping invalid width %r on %r "
                           "(number 1..120 expected)", w, col)
        a = st.get("align")
        if a in ("left", "center", "right"):
            entry["align"] = a
        elif a is not None:
            logger.warning("[col-styles] dropping invalid align %r on %r",
                           a, col)
        fs = st.get("font_size")
        if isinstance(fs, (int, float)) and not isinstance(fs, bool) and 5 <= fs <= 36:
            entry["font_size"] = float(fs)
        elif fs is not None:
            logger.warning("[col-styles] dropping invalid font_size %r on %r",
                           fs, col)
        fw = st.get("font_weight", st.get("bold"))
        if fw in ("bold", True):
            entry["bold"] = True
        elif fw not in (None, "normal", False):
            logger.warning("[col-styles] dropping invalid font_weight %r on "
                           "%r", fw, col)
        if entry:
            out[col] = entry
    return out


def _column_css_map(column_styles: dict, columns: list) -> dict:
    """Validated column styles → per-column CSS declaration strings.  Every
    token is generated from whitelisted values (see _extract_column_styles),
    so the output is safe for an inline style attribute."""
    css: dict = {}
    for c in columns:
        st = (column_styles or {}).get(c)
        if not st:
            continue
        parts = []
        if st.get("width"):
            parts.append(f"width:{st['width']:g}ch")
        if st.get("align"):
            parts.append(f"text-align:{st['align']}")
        if st.get("font_size"):
            parts.append(f"font-size:{st['font_size']:g}pt")
        if st.get("bold"):
            parts.append("font-weight:bold")
        if parts:
            css[c] = ";".join(parts)
    return css


# ── Report/page header & footer text (PDF), 2026-08-30 ──────────────────────
# The LEGACY family already has a vocabulary for this — ReportPDFConfig
# (core/db/models.py: orientation, paper_size, include_cover, include_header,
# include_footer, logo_url, header_text, footer_text with {page}/{total}
# placeholders, font_size).  Business reports REUSE that field vocabulary,
# carried where they carry every other layout decision:
# ``layout_config.pdf_config``.  DELIBERATE DIVERGENCES from the legacy row:
#   * storage — a report_pdf_configs row is keyed to the LEGACY report id
#     space; business reports keep layout in layout_config (no new table).
#   * logo_url is NOT rendered — a server-side PDF renderer fetching an
#     author-supplied URL is an SSRF vector; declared with a log line.
#   * max_rows is not read — business reports already have pdf_row_limit.

_PDF_PAPER_SIZES = {"a4": "A4", "a3": "A3", "letter": "Letter",
                    "legal": "Legal"}


def _extract_pdf_layout(report: dict, default_page_size: str):
    """Read layout_config.pdf_config (legacy ReportPDFConfig vocabulary).

    Returns a validated layout dict or None (None ⇒ the renderer emits its
    historical output byte-for-byte).  Invalid values fall back to the
    default WITH a log line — a bad knob must not kill an export.
    """
    pc = (report.get("layout_config") or {}).get("pdf_config")
    if not isinstance(pc, dict) or not pc:
        if pc not in (None, {}):
            logger.warning("[pdf-layout] layout_config.pdf_config is %s, "
                           "expected object — ignored", type(pc).__name__)
        return None
    base = str(default_page_size or "A4 landscape").split()
    paper = _PDF_PAPER_SIZES.get(str(pc.get("paper_size") or "").strip().lower())
    if pc.get("paper_size") and not paper:
        logger.warning("[pdf-layout] unknown paper_size %r — using default",
                       pc.get("paper_size"))
    orient = str(pc.get("orientation") or "").strip().lower()
    if orient not in ("landscape", "portrait"):
        if pc.get("orientation"):
            logger.warning("[pdf-layout] unknown orientation %r — using "
                           "default", pc.get("orientation"))
        orient = ""
    page_size = (f"{paper or base[0]} "
                 f"{orient or (base[1] if len(base) > 1 else 'landscape')}")
    fs = pc.get("font_size")
    if not (isinstance(fs, (int, float)) and not isinstance(fs, bool)
            and 6 <= fs <= 24):
        if fs is not None:
            logger.warning("[pdf-layout] dropping invalid font_size %r "
                           "(6..24 expected)", fs)
        fs = None
    if pc.get("logo_url"):
        logger.warning("[pdf-layout] logo_url is not rendered on "
                       "business-report PDFs (a renderer-side fetch of an "
                       "author URL is an SSRF vector) — ignored")
    return {
        "page_size": page_size,
        "include_cover": bool(pc.get("include_cover")),
        "include_header": bool(pc.get("include_header", True)),
        "include_footer": bool(pc.get("include_footer", True)),
        "header_text": str(pc.get("header_text") or "")[:500],
        "footer_text": str(pc.get("footer_text") or "")[:500],
        "font_size": fs,
    }


def _css_footer_content(template: str) -> str:
    """Author footer text → CSS ``content`` expression.  ``{page}``/``{total}``
    become the CSS page counters; literal chunks are CSS-string-escaped."""
    parts = []
    for chunk in _re_mod.split(r"(\{page\}|\{total\})", template):
        if chunk == "{page}":
            parts.append("counter(page)")
        elif chunk == "{total}":
            parts.append("counter(pages)")
        elif chunk:
            esc = (chunk.replace("\\", "\\\\").replace('"', '\\"')
                   .replace("\n", " ").replace("\r", " "))
            parts.append(f'"{esc}"')
    return " ".join(parts) or '""'




def _resolve_pivot_result_keys(names: list, result_columns: list | None,
                               rows: list) -> list:
    """Map each AUTHORED pivot column name (the dataset's ``physical_name``)
    to the key the RESULT rows actually carry.

    2026-09-15 -- LIVE: a pivot over Oracle exported a header-only workbook
    (200, ``x-qs-rows: 97``, cells A1/B1 only).  The dataset stores the
    column as ``BUCKET``; the engine returns the row keyed ``bucket`` --
    the engine adopts the SOURCE's spelling on case-only differences
    (CLAUDE.md §3), and every other renderer keys rows by the result's own
    ``columns`` list.  The matrix builder alone looked up the authored name
    verbatim, so every lookup missed and every cell was empty: a 200 with
    a valid-looking file and no data.

    Resolution, in order: an exact match; else a UNIQUE case-insensitive
    match (the engine's identity rule for case-only differences -- the same
    rule ``_validated_column_subset`` applies to viewer-chosen names); else,
    with rows present, REFUSE.  A dimension or measure that cannot be found
    in the result cannot be rendered, and an export that silently loses
    every row is worse than one that fails.  With no rows there is nothing
    to render and nothing to refuse -- the names pass through unchanged so
    an empty result still produces its header row.

    ``result_columns`` is the engine's column list (strings, or
    ``{"name": ...}`` dicts on the inline PV/FV path); callers without one
    (delivery, token exports) fall back to the first row's keys -- the same
    identity, read from the rows themselves.
    """
    cols: list = []
    for c in (result_columns or []):
        n = c.get("name") if isinstance(c, dict) else c
        if n is not None and n not in cols:
            cols.append(n)
    if rows and isinstance(rows[0], dict):
        for k in rows[0].keys():
            if k not in cols:
                cols.append(k)
    exact = set(cols)
    folded: dict = {}
    for c in cols:
        folded.setdefault(str(c).casefold(), []).append(c)
    out: list = []
    missing: list = []
    for n in names:
        if n in exact:
            out.append(n)
            continue
        cands = folded.get(str(n).casefold(), [])
        if len(cands) == 1:
            out.append(cands[0])
            continue
        missing.append(n)
        out.append(n)
    if missing and rows:
        raise ValueError(
            f"Pivot column(s) {missing} are not present in the result "
            f"(result columns: {cols}); refusing to render an empty pivot.")
    return out


def _build_pivot_matrix(rows: list, pivot_config: dict, columns_meta: list,
                        result_columns: list | None = None) -> dict:
    """Build a server-side crosstab matrix from flat GROUP BY rows.

    Replicates the frontend PivotReportViewer.pivotMatrix logic.
    Returns {row_dim_names, col_dim_names, value_names, row_keys, col_keys,
             row_key_values, col_key_values, cells, row_totals, col_totals, grand_totals}.

    ``*_names`` stay the AUTHORED names (headers, ``col_fmt_map`` keys, the
    cell dict's keys -- every renderer reads those); the row LOOKUP goes
    through the resolved result keys (see ``_resolve_pivot_result_keys``).
    """
    # Map column_id → physical_name
    id_to_name = {c.get("id"): c.get("physical_name", "") for c in columns_meta}

    row_field_ids = pivot_config.get("row_field_ids", [])
    col_field_ids = pivot_config.get("col_field_ids", [])
    value_fields = pivot_config.get("value_fields", [])

    row_dim_names = [id_to_name.get(cid, f"col_{cid}") for cid in row_field_ids]
    col_dim_names = [id_to_name.get(cid, f"col_{cid}") for cid in col_field_ids]
    value_names = [id_to_name.get(vf.get("column_id"), "") for vf in value_fields]
    value_aggs = [vf.get("aggregation", "sum") for vf in value_fields]

    # The keys the rows ACTUALLY carry, one resolution for all three lists.
    _resolved = _resolve_pivot_result_keys(
        row_dim_names + col_dim_names + value_names, result_columns, rows)
    row_dim_keys = _resolved[:len(row_dim_names)]
    col_dim_keys = _resolved[len(row_dim_names):len(row_dim_names) + len(col_dim_names)]
    value_keys = _resolved[len(row_dim_names) + len(col_dim_names):]

    def _key(row, keys):
        return "||".join(str(row.get(k, "")) for k in keys)

    seen_rk, seen_ck = set(), set()
    row_keys, col_keys = [], []
    rk_vals, ck_vals = {}, {}
    cells = {}  # rk -> ck -> {name: value}

    for row in rows:
        rk = _key(row, row_dim_keys)
        ck = _key(row, col_dim_keys) if col_dim_names else "__total__"
        if rk not in seen_rk:
            seen_rk.add(rk)
            row_keys.append(rk)
            rk_vals[rk] = [row.get(k) for k in row_dim_keys]
        if ck not in seen_ck:
            seen_ck.add(ck)
            col_keys.append(ck)
            ck_vals[ck] = [row.get(k) for k in col_dim_keys]
        if rk not in cells:
            cells[rk] = {}
        if ck not in cells[rk]:
            cells[rk][ck] = {}
        for vn, vk in zip(value_names, value_keys):
            v = row.get(vk)
            if vn not in cells[rk][ck]:
                cells[rk][ck][vn] = v
            elif isinstance(cells[rk][ck][vn], (int, float)) and isinstance(v, (int, float)):
                cells[rk][ck][vn] += v

    # Sort keys naturally
    row_keys.sort(key=lambda k: rk_vals.get(k, []))
    col_keys.sort(key=lambda k: ck_vals.get(k, []))

    # ── Result-size caps (2026-09-15) ────────────────────────────────────
    # pivot_reports.max_row_groups (500) and max_col_groups (50) shipped,
    # were rendered in the admin screen, and were enforced NOWHERE.  Their
    # three siblings -- max_row_dimensions, max_col_dimensions, max_measures
    # -- are all checked in _validate_pivot_config; these two are not, and
    # could not be: they bound the RESULT, not the authored shape, so
    # authoring time is too early to know.  A 40k-distinct-key dimension
    # therefore built a 40,000-row matrix in the API pod's heap and shipped
    # it to a browser.
    #
    # THROTTLE AND DISCLOSE, never silently drop.  Cutting groups out of a
    # crosstab changes every total computed from them; a truncated matrix
    # that presents itself as complete is the defect this product has
    # already paid for (a feed that hit its cap and certified VERIFIED).
    # The cut happens HERE, before the totals below, so the totals describe
    # exactly the cells the reader can see -- and ``truncation`` says so.
    # 0 = unlimited, the product-wide rule.
    _trunc: dict = {}
    try:
        from core.config import pivot_reports as _pv_lim
        _max_rg = int(_pv_lim.max_row_groups)
        _max_cg = int(_pv_lim.max_col_groups)
    except Exception:                                   # pragma: no cover
        _max_rg, _max_cg = 500, 50
    if _max_rg > 0 and len(row_keys) > _max_rg:
        _trunc["row_groups"] = {"shown": _max_rg, "total": len(row_keys),
                                "cap": _max_rg, "key": "pivot_reports.max_row_groups"}
        row_keys = row_keys[:_max_rg]
    if _max_cg > 0 and len(col_keys) > _max_cg:
        _trunc["col_groups"] = {"shown": _max_cg, "total": len(col_keys),
                                "cap": _max_cg, "key": "pivot_reports.max_col_groups"}
        col_keys = col_keys[:_max_cg]
    if _trunc:
        # Drop the cells nobody can reach.  Without this the cap throttles
        # the HEADERS and leaves the payload -- the memory cost the cap
        # exists to bound -- exactly as large as before.
        _rk_keep, _ck_keep = set(row_keys), set(col_keys)
        cells = {rk: {ck: v for ck, v in cks.items() if ck in _ck_keep}
                 for rk, cks in cells.items() if rk in _rk_keep}
        rk_vals = {k: v for k, v in rk_vals.items() if k in _rk_keep}
        ck_vals = {k: v for k, v in ck_vals.items() if k in _ck_keep}

    def _agg(vals, agg_type):
        nums = [v for v in vals if isinstance(v, (int, float))]
        if not nums:
            return None
        if agg_type == "sum":
            return sum(nums)
        if agg_type == "avg":
            return sum(nums) / len(nums)
        if agg_type == "min":
            return min(nums)
        if agg_type == "max":
            return max(nums)
        if agg_type == "count_distinct":
            return len(set(nums))
        if agg_type == "count":
            return len(nums)
        return sum(nums)

    # Row totals
    row_totals = {}
    if pivot_config.get("show_row_totals") and col_dim_names:
        for rk in row_keys:
            totals = {}
            for i, vn in enumerate(value_names):
                vals = [cells.get(rk, {}).get(ck, {}).get(vn) for ck in col_keys]
                t = _agg(vals, value_aggs[i])
                if t is not None:
                    totals[vn] = t
            row_totals[rk] = totals

    # Col totals
    col_totals = {}
    if pivot_config.get("show_col_totals"):
        for ck in col_keys:
            totals = {}
            for i, vn in enumerate(value_names):
                vals = [cells.get(rk, {}).get(ck, {}).get(vn) for rk in row_keys]
                t = _agg(vals, value_aggs[i])
                if t is not None:
                    totals[vn] = t
            col_totals[ck] = totals

    # Grand totals
    grand_totals = {}
    if pivot_config.get("show_grand_total"):
        for i, vn in enumerate(value_names):
            all_vals = []
            for rk in row_keys:
                for ck in col_keys:
                    v = cells.get(rk, {}).get(ck, {}).get(vn)
                    if v is not None:
                        all_vals.append(v)
            t = _agg(all_vals, value_aggs[i])
            if t is not None:
                grand_totals[vn] = t

    out = {
        "row_dim_names": row_dim_names, "col_dim_names": col_dim_names,
        "value_names": value_names, "value_aggs": value_aggs,
        "row_keys": row_keys, "col_keys": col_keys,
        "row_key_values": rk_vals, "col_key_values": ck_vals,
        "cells": cells, "row_totals": row_totals,
        "col_totals": col_totals, "grand_totals": grand_totals,
    }
    # Present ONLY when a cap bit, so a matrix that was not truncated is
    # byte-identical to the historical shape for every existing consumer.
    if _trunc:
        out["truncation"] = _trunc
    return out


#: The formats these routes actually serve.  There are nine download
#: endpoints (pdf / excel / csv, each for owner, shared token and embedded
#: token) and no json one.
_SERVED_EXPORT_FORMATS = ("pdf", "excel", "csv")


def _enforce_export_format(fmt: str) -> None:
    """Refuse a format ``business_reports.export_formats`` does not allow.

    2026-09-15.  The key shipped, was rendered in the admin screen, and was
    read by NOTHING -- removing "csv" from it did not stop a single CSV
    download.  Worse than unenforced, it had DRIFTED from the surface it
    names: the declared default was ["csv", "json"], and these routes serve
    pdf / excel / csv and no json at all.  So the value an operator read as
    "this deployment allows csv and json" described a deployment that
    allowed pdf, excel and csv, and enforcing the old declaration verbatim
    would have broken PDF and Excel everywhere while permitting a format
    that does not exist.  The declaration now names what is served; the
    effective set is unchanged (everything was allowed and everything still
    is) until an operator narrows it, which is the whole point.

    This is NOT the per-role gate.  ``admin_governance.export_formats_*``
    answers "may THIS ROLE export xlsx", is enforced in data_grid_api, and
    is a different question from "does this deployment serve the format at
    all" -- one is authorisation, one is provisioning.  Both may refuse.
    """
    # The config read is the ONLY thing allowed to fail open, and it is
    # scoped to exactly that statement.  A wider `try` here silently ate an
    # AttributeError (there is no module-level ``_cfg`` in this file) and the
    # gate permitted every format while looking correct -- the fail-open
    # handler hiding a name error, which this repo has now paid for three
    # times.  Everything after the read raises normally.
    try:
        from core import config as _brcfg
        raw_formats = list(_brcfg.business_reports.export_formats)
    except Exception as exc:                            # pragma: no cover
        logger.error("business_reports.export_formats unreadable (%s) — "
                     "export format NOT enforced for this request", exc)
        return
    allowed = {str(f).strip().lower() for f in raw_formats if str(f).strip()}
    if not allowed:
        # An EMPTY allowlist is ambiguous -- "nothing is allowed" and "the
        # key was cleared by accident" look identical, and reading it as
        # "refuse everything" turns a typo into a total export outage.  Fail
        # open, loudly: the same posture the row-security engine takes for an
        # unresolvable scope.
        logger.error(
            "business_reports.export_formats is EMPTY — every export format "
            "is being allowed. Set it to a subset of %s to restrict, or "
            "leave it at the default.", list(_SERVED_EXPORT_FORMATS))
        return
    if fmt.lower() not in allowed:
        raise HTTPException(
            status_code=403,
            detail=(f"Export format '{fmt}' is not enabled on this "
                    f"deployment. Allowed: {sorted(allowed)} "
                    f"(business_reports.export_formats)."))


def _pivot_truncation_suffix(matrix: dict) -> str:
    """One sentence on the banner when a pivot CAP cut the crosstab, "" when
    it did not — same contract as ``_banded_disclosure_suffix`` above.

    The pivot PDF renderer already carries a ``disclosure_text`` whose whole
    reason for existing is that "totals computed over a truncated input must
    never present themselves as complete".  A cap applied to the matrix is
    that same statement one level up, so it joins the SAME banner rather
    than inventing a second channel a reader might not be shown.
    """
    t = (matrix or {}).get("truncation") or {}
    if not t:
        return ""
    parts = []
    for axis, label in (("row_groups", "row groups"), ("col_groups", "column groups")):
        d = t.get(axis)
        if d:
            parts.append(f"{d['shown']} of {d['total']} {label} "
                         f"(cap {d['cap']}, {d['key']})")
    return (" TRUNCATED: this crosstab shows " + "; ".join(parts)
            + ". Every total shown is computed over the displayed cells only.")


def _pivot_rules_by_column(matrix: dict, fmt_rules) -> dict:
    """2026-10-24 -- a pivot's conditional formats colour its VALUE cells;
    top / bottom N rank every cell of that value in the MATRIX (not the flat
    input rows -- any cut-off attached for those is recomputed here)."""
    if not fmt_rules:
        return {}
    from core.reports.format_rules import attach_cutoffs
    cells = [c for by_col in (matrix.get("cells") or {}).values() for c in by_col.values()]
    plain = [{k: v for k, v in r.items() if k != "_cutoff"} for r in fmt_rules]
    return _rules_by_column(attach_cutoffs(plain, rows=cells))


def _render_pivot_pdf_bytes(matrix: dict, report_name: str,
                             header_bg: str, header_text: str,
                             page_size: str = "A4 landscape",
                             neg_fmt: str = "",
                             col_fmt_map: dict | None = None,
                             footer_text: str = "",
                             disclosure_text: str = "",
                             fmt_rules: list | None = None) -> bytes:
    """Render a pivot crosstab matrix to PDF bytes.

    ``footer_text`` (optional): a one-line Completeness Certificate footer,
    rendered muted beneath the table when non-empty.

    ``disclosure_text`` (optional, 2026-08-09): prominent banner ABOVE the
    table.  For a pivot this matters MORE than for a flat export — the matrix
    was aggregated from the (possibly cut) input rows, so totals computed
    over a truncated input must never present themselves as complete.
    """
    # 2026-09-15: ONE capability probe (core.reports.pdf_engine).  The old
    # ``except ImportError`` missed the common failure -- package installed,
    # native Pango/GObject missing -> OSError -> an opaque 500.
    _load_weasyprint()

    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    vn = matrix["value_names"]
    has_cols = len(matrix["col_dim_names"]) > 0
    _cfm = col_fmt_map or {}

    # Build header rows
    # Row 1: row dim headers + col dim group headers (spanning N value fields each) + optional "Total"
    # Row 2: row dim headers (empty) + value field names under each col group
    h1_cells = "".join(f"<th rowspan='2'>{_html_mod.escape(str(n))}</th>" for n in matrix["row_dim_names"])
    if has_cols:
        for ck in matrix["col_keys"]:
            cv = matrix["col_key_values"].get(ck, [])
            label = " / ".join(str(v) for v in cv)
            h1_cells += f"<th colspan='{len(vn)}'>{_html_mod.escape(label)}</th>"
        if matrix.get("row_totals"):
            h1_cells += f"<th colspan='{len(vn)}'>Total</th>"
    else:
        for name in vn:
            h1_cells += f"<th rowspan='2'>{_html_mod.escape(str(name))}</th>"

    h2_cells = ""
    if has_cols:
        for _ck in matrix["col_keys"]:
            for name in vn:
                h2_cells += f"<th>{_html_mod.escape(str(name))}</th>"
        if matrix.get("row_totals"):
            for name in vn:
                h2_cells += f"<th>{_html_mod.escape(str(name))}</th>"

    # Data rows
    _prb = _pivot_rules_by_column(matrix, fmt_rules)
    body_rows = []
    for rk in matrix["row_keys"]:
        rv = matrix["row_key_values"].get(rk, [])
        cells_html = "".join(f"<td class='rh'>{_html_mod.escape(str(v or ''))}</td>" for v in rv)
        for ck in (matrix["col_keys"] if has_cols else ["__total__"]):
            cell = matrix["cells"].get(rk, {}).get(ck, {})
            for name in vn:
                val = cell.get(name, "")
                _st = _cell_rule_style(name, val, _prb) if _prb else ""
                _sa = f' style="{_html_mod.escape(_st, quote=True)}"' if _st else ""
                cells_html += f"<td{_sa}>{_fmt_pdf_val(name, val, _cfm, neg_fmt)}</td>"
        if has_cols and matrix.get("row_totals"):
            rt = matrix["row_totals"].get(rk, {})
            for name in vn:
                cells_html += f"<td class='total'>{_fmt_pdf_val(name, rt.get(name, ''), _cfm, neg_fmt)}</td>"
        body_rows.append(f"<tr>{cells_html}</tr>")

    # Col totals row
    if matrix.get("col_totals"):
        ct_cells = f"<td class='total' colspan='{len(matrix['row_dim_names'])}'>Total</td>"
        for ck in matrix["col_keys"]:
            ct = matrix["col_totals"].get(ck, {})
            for name in vn:
                ct_cells += f"<td class='total'>{_fmt_pdf_val(name, ct.get(name, ''), _cfm, neg_fmt)}</td>"
        if matrix.get("row_totals") and matrix.get("grand_totals"):
            gt = matrix["grand_totals"]
            for name in vn:
                ct_cells += f"<td class='grand'>{_fmt_pdf_val(name, gt.get(name, ''), _cfm, neg_fmt)}</td>"
        body_rows.append(f"<tr class='total-row'>{ct_cells}</tr>")

    thead = f"<tr>{h1_cells}</tr>"
    if h2_cells:
        thead += f"<tr>{h2_cells}</tr>"

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{_html_mod.escape(report_name)}</title></head>
<body>
<div class="page-header"><span class="header-title">{_html_mod.escape(report_name)} (Pivot)</span>
<span class="run-date">{now_str}</span></div>
{f'<div class="truncation-note">{_html_mod.escape(disclosure_text)}</div>' if disclosure_text else ''}
<table><thead>{thead}</thead><tbody>{''.join(body_rows)}</tbody></table>
{f'<p class="cert-footer">{_html_mod.escape(footer_text)}</p>' if footer_text else ''}
</body></html>"""

    css = f"""@page {{ size: {page_size}; margin: 12mm 10mm 15mm 10mm;
  @bottom-center {{ content: "Page " counter(page) " of " counter(pages); font-size: 8pt; color: #888; }} }}
body {{ font-family: Arial, sans-serif; font-size: 9pt; color: #222; }}
table {{ border-collapse: collapse; width: 100%; font-size: 8pt; }}
thead tr {{ background: #{header_bg}; color: #{header_text}; }}
th {{ padding: 4pt 5pt; text-align: center; font-weight: bold; border: 1px solid #ddd; white-space: nowrap; }}
td {{ padding: 3pt 5pt; border: 1px solid #eee; text-align: right; }}
td.rh {{ text-align: left; font-weight: 600; }}
td.total {{ font-weight: bold; background: #f5f5f5; }}
td.grand {{ font-weight: bold; background: #e8e8e8; }}
tr.total-row {{ background: #f0f0f0; }}
.page-header {{ display: flex; justify-content: space-between; margin-bottom: 4pt;
               font-size: 9pt; color: #555; border-bottom: 1px solid #ccc; padding-bottom: 2pt; }}
.header-title {{ font-weight: bold; }}
.cert-footer {{ font-size: 8pt; color: #777; margin-top: 4pt; font-style: italic; }}
.truncation-note {{ background: #FFF3E0; border: 1pt solid #E65100; color: #7A3E00;
                   padding: 5pt 8pt; margin: 4pt 0 6pt 0; font-size: 9pt;
                   font-weight: bold; }}"""

    return _render_pdf_document(html, css)


def _fmt_number(val) -> str:
    """Format a number for pivot export display."""
    if val is None or val == "":
        return ""
    if isinstance(val, float):
        return f"{val:,.2f}"
    if isinstance(val, int):
        return f"{val:,}"
    return _html_mod.escape(str(val))


def _render_pivot_excel_bytes(matrix: dict, report_name: str,
                               header_bg: str, header_text: str,
                               neg_fmt: str = "", stripe_rows: bool = False,
                               col_fmt_map: dict | None = None,
                               footer_text: str = "",
                               disclosure_text: str = "",
                               fmt_rules: list | None = None) -> bytes:
    """Render a pivot crosstab matrix to Excel bytes with merged headers.

    ``footer_text`` (optional): a one-line Completeness Certificate footer,
    written muted+italic two rows below the last data/total row when non-empty.

    ``disclosure_text`` (optional, 2026-08-09): truncation disclosure written
    bold beneath the data — pivot aggregates computed over a cut input must
    never present themselves as complete.
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    _prb = _pivot_rules_by_column(matrix, fmt_rules)
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = report_name[:31]

    hdr_font = Font(bold=True, color=header_text, size=9)
    hdr_fill = PatternFill(start_color=header_bg, end_color=header_bg, fill_type="solid")
    total_fill = PatternFill(start_color="F0F0F0", end_color="F0F0F0", fill_type="solid")
    stripe_fill = PatternFill(start_color="F9F9F9", end_color="F9F9F9", fill_type="solid")

    # Build Excel number format map for value columns
    _cfm = col_fmt_map or {}
    val_xl_fmt: dict = {}
    for vname in matrix["value_names"]:
        xl = _resolve_xl_format(_cfm.get(vname, ""), neg_fmt)
        if xl:
            val_xl_fmt[vname] = xl

    vn = matrix["value_names"]
    n_rd = len(matrix["row_dim_names"])
    n_vf = len(vn)
    has_cols = len(matrix["col_dim_names"]) > 0
    show_rt = bool(matrix.get("row_totals")) and has_cols

    # Row 1: Row dim names + col group headers
    for i, name in enumerate(matrix["row_dim_names"], 1):
        c = ws.cell(row=1, column=i, value=_xl_safe(name))
        c.font = hdr_font
        c.fill = hdr_fill
        if has_cols:
            ws.merge_cells(start_row=1, start_column=i, end_row=2, end_column=i)

    col_offset = n_rd + 1
    if has_cols:
        for ck in matrix["col_keys"]:
            cv = matrix["col_key_values"].get(ck, [])
            label = " / ".join(str(v) for v in cv)
            c = ws.cell(row=1, column=col_offset, value=_xl_safe(label))
            c.font = hdr_font
            c.fill = hdr_fill
            c.alignment = Alignment(horizontal="center")
            if n_vf > 1:
                ws.merge_cells(start_row=1, start_column=col_offset,
                               end_row=1, end_column=col_offset + n_vf - 1)
            # Row 2: value field names
            for vi, name in enumerate(vn):
                c2 = ws.cell(row=2, column=col_offset + vi, value=_xl_safe(name))
                c2.font = hdr_font
                c2.fill = hdr_fill
            col_offset += n_vf
        if show_rt:
            c = ws.cell(row=1, column=col_offset, value="Total")
            c.font = hdr_font
            c.fill = hdr_fill
            if n_vf > 1:
                ws.merge_cells(start_row=1, start_column=col_offset,
                               end_row=1, end_column=col_offset + n_vf - 1)
            for vi, name in enumerate(vn):
                c2 = ws.cell(row=2, column=col_offset + vi, value=_xl_safe(name))
                c2.font = hdr_font
                c2.fill = hdr_fill
        data_start_row = 3
    else:
        for i, name in enumerate(vn, n_rd + 1):
            c = ws.cell(row=1, column=i, value=_xl_safe(name))
            c.font = hdr_font
            c.fill = hdr_fill
        data_start_row = 2

    # Data rows
    for ri, rk in enumerate(matrix["row_keys"]):
        row_num = data_start_row + ri
        rv = matrix["row_key_values"].get(rk, [])
        for ci, v in enumerate(rv, 1):
            c = ws.cell(row=row_num, column=ci, value=_xl_safe(v))
            if stripe_rows and ri % 2 == 1:
                c.fill = stripe_fill

        col_offset = n_rd + 1
        col_list = matrix["col_keys"] if has_cols else ["__total__"]
        for ck in col_list:
            cell = matrix["cells"].get(rk, {}).get(ck, {})
            for vi, name in enumerate(vn):
                val = cell.get(name)
                c = ws.cell(row=row_num, column=col_offset + vi, value=_xl_safe(val))
                if isinstance(val, (int, float)) and name in val_xl_fmt and val_xl_fmt[name]:
                    c.number_format = val_xl_fmt[name]
                if stripe_rows and ri % 2 == 1:
                    c.fill = stripe_fill
                _xs = _xl_conditional_style(name, val, _prb) if _prb else None
                if _xs:     # 2026-10-24 -- the author's rule wins over the stripe
                    _bg, _tx, _bold = _xs
                    if _bg:
                        c.fill = PatternFill(start_color=_bg, end_color=_bg, fill_type="solid")
                    if _tx or _bold:
                        c.font = Font(color=_tx or None, bold=_bold)
            col_offset += n_vf
        if show_rt:
            rt = matrix["row_totals"].get(rk, {})
            for vi, name in enumerate(vn):
                val = rt.get(name)
                c = ws.cell(row=row_num, column=col_offset + vi, value=_xl_safe(val))
                c.font = Font(bold=True)
                c.fill = total_fill
                if isinstance(val, (int, float)) and name in val_xl_fmt and val_xl_fmt[name]:
                    c.number_format = val_xl_fmt[name]

    # Col totals row
    if matrix.get("col_totals"):
        row_num = data_start_row + len(matrix["row_keys"])
        ws.cell(row=row_num, column=1, value="Total").font = Font(bold=True)
        col_offset = n_rd + 1
        for ck in matrix["col_keys"]:
            ct = matrix["col_totals"].get(ck, {})
            for vi, name in enumerate(vn):
                val = ct.get(name)
                c = ws.cell(row=row_num, column=col_offset + vi, value=_xl_safe(val))
                c.font = Font(bold=True)
                c.fill = total_fill
                if isinstance(val, (int, float)) and name in val_xl_fmt and val_xl_fmt[name]:
                    c.number_format = val_xl_fmt[name]
            col_offset += n_vf
        if show_rt and matrix.get("grand_totals"):
            gt = matrix["grand_totals"]
            for vi, name in enumerate(vn):
                val = gt.get(name)
                c = ws.cell(row=row_num, column=col_offset + vi, value=_xl_safe(val))
                c.font = Font(bold=True, color="FF0000")
                c.fill = total_fill
                if isinstance(val, (int, float)) and name in val_xl_fmt and val_xl_fmt[name]:
                    c.number_format = val_xl_fmt[name]

    # Auto-fit widths
    for col_idx in range(1, ws.max_column + 1):
        max_len = 8
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 50), min_col=col_idx, max_col=col_idx):
            for cell in row:
                if cell.value:
                    max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 2, 30)

    ws.freeze_panes = f"A{data_start_row}"

    # Truncation disclosure — bold line two rows below data (before the cert
    # footer); written only on a detected limit hit.
    if disclosure_text:
        dcell = ws.cell(row=ws.max_row + 2, column=1, value=disclosure_text)
        dcell.font = Font(bold=True, color="B45309", size=9)

    # Completeness Certificate footer — muted italic line two rows below data.
    if footer_text:
        fcell = ws.cell(row=ws.max_row + 2, column=1, value=footer_text)
        fcell.font = Font(italic=True, color="777777", size=9)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _export_materialize_cap() -> int:
    """SCALE-1 (2026-08-22): the HARD row ceiling a single synchronous export
    request may pull into the API pod's Python heap.

    This is a MEMORY / OOM GATE, distinct from the row-limit THROTTLE: the
    caller's ``?limit=`` is still honoured at any size (caps throttle, not
    refuse), and the engine writes those rows to a parquet artifact — but
    reading ALL of them back into a Python list-of-dicts OOM-kills the
    single-replica pod.  Beyond this ceiling the export delivers the first N
    and discloses the cut, pointing at the background download (Download
    Centre) for the full result.  ``<= 0`` disables the guard.
    """
    from core import config as _cfg
    try:
        return int(_cfg.business_reports.export_materialize_cap)
    except Exception:
        return 1_000_000


#: Sources whose engine hands back an INLINE list of rows (not an artifact):
#: their result is in the Python heap whatever an export does with it.
_INLINE_RESULT_SOURCES = ("published_view", "federation_view")


def _pdf_max_rows() -> int:
    """The PDF MEMORY CEILING (``business_reports.pdf_max_rows``): the most
    rows any PDF document carries, an explicit ``?limit=`` included.
    ``<= 0`` disables the cut (the render budget still refuses)."""
    from core import config as _cfg
    try:
        return int(_cfg.business_reports.pdf_max_rows)
    except Exception:
        return 5000


def _excel_styled_max_rows() -> int:
    """Largest result Excel renders through openpyxl's object model; above it
    the workbook is written in streaming (write-only) mode."""
    from core import config as _cfg
    try:
        return int(_cfg.business_reports.excel_styled_max_rows)
    except Exception:
        return 50000


def _pdf_ceiling_disclosure(rows_in_doc: int, ceiling: int) -> str:
    """The sentence a PDF carries when the memory ceiling cut it."""
    return (f"This PDF contains the first {rows_in_doc:,} rows of a larger "
            f"result — a PDF holds at most {ceiling:,} rows "
            f"(business_reports.pdf_max_rows) because rendering one is "
            f"memory-bound. Use the CSV export for every row.")


def _pdf_row_plan(limit: int) -> dict:
    """How many rows a PDF export EXECUTES for, and whether the ceiling
    governs it -- decided once per request (2026-10-04).

    ``requested`` is the caller's ``?limit=`` or ``pdf_row_limit``.  When it
    is within the ceiling it runs as asked.  Otherwise the execution asks
    for ``ceiling + 1`` rows: the extra row is how the export KNOWS the
    result is larger (and says so) without counting the whole result.
    """
    from core import config as _cfg
    requested = limit if limit > 0 else int(_cfg.business_reports.pdf_row_limit)
    ceiling = _pdf_max_rows()
    over = ceiling > 0 and (requested <= 0 or requested > ceiling)
    return {"requested": requested, "ceiling": ceiling, "over": over,
            "exec_limit": (ceiling + 1) if over else requested}


def _apply_pdf_plan(rows: list, plan: dict) -> tuple:
    """``(rows_for_the_document, cut_by_ceiling)``."""
    if plan["over"] and len(rows) > plan["ceiling"]:
        return rows[:plan["ceiling"]], True
    return rows, False


# ── Download Centre registration for report exports (2026-08-30) ─────────────
# Report exports were the ONE surface producing large documents that never
# touched the centralised Download Centre: every PDF/Excel/CSV was built in
# memory and streamed inline — never listed, never re-downloadable.  The
# three AUTHENTICATED download routes now also write the rendered artifact
# into ``paths.downloads_dir`` and register it via the SAME
# ``create_download_file`` + ``DownloadFile`` semantics execute_api uses
# (uuid4 file_id, id-named file in the downloads dir, verified size,
# ``core.download_retention`` expiry).  Re-download authorization is the
# EXISTING Download Centre gate (`api.data_grid_api._enforce_download_
# ownership`: creator / admin / support) — no second rule here; we register
# ``created_by`` so that gate binds.
#
# TOKEN (share/embed) exports are DELIBERATELY NOT registered:
#   * they carry an ANONYMOUS principal — a DownloadFile row with no
#     ``created_by`` and no ``execution_id`` FAILS OPEN in
#     ``_enforce_download_ownership`` (legacy-row concession), i.e. the
#     artifact would be readable by EVERY authenticated user;
#   * a registered row outlives token revocation/expiry, while the token IS
#     the whole authorization for that data (embed group scope included) —
#     revoking the token must kill access, and a Download Centre row would
#     survive it;
#   * the anonymous viewer cannot browse the authenticated Download Centre
#     anyway, so registration buys them nothing and exposes something.

#: Fallback operator ceiling for requester-chosen retention when
#: ``storage.downloads_retain_max_days`` is not configured.
#: 2026-08-30 — the RULE moved to ``core.download_retention`` so the
#: Download Centre's retention-edit endpoint shares it instead of
#: restating it.  These names stay as the module's local vocabulary.
_RETAIN_MAX_FALLBACK_DAYS = _dl_retention.RETAIN_MAX_FALLBACK_DAYS


def _export_retain_max_days() -> int:
    """Operator ceiling (days) for a requester-chosen ``?retain_days=``.

    Delegates to the retention chokepoint — see
    ``core.download_retention.retention_max_days``.
    """
    return _dl_retention.retention_max_days()


def _export_expires_at(retain_days: Optional[int]) -> datetime:
    """Expiry timestamp for a registered export artifact.

    ``None`` (parameter not supplied) → the ONE existing retention
    chokepoint, ``core.download_retention.download_expires_at()`` — nothing
    changes for callers who don't ask.  An explicit value must be
    ``1..operator-max`` and is refused LOUDLY otherwise: in particular an
    explicit ``0`` must never silently mean "keep forever" (the
    ``x or default`` fold is this product's signature defect class, and a
    never-expiring download under a disk quota destroys data via eviction).
    """
    try:
        return _dl_retention.expires_at_for(retain_days)
    except _dl_retention.RetentionRefused as exc:
        raise HTTPException(status_code=400, detail=str(exc))


def _export_inline_max_bytes() -> int:
    """Rendered-artifact size at/above which the response is served FROM THE
    REGISTERED FILE (FileResponse — chunked from disk) instead of a second
    in-memory buffer.  Body bytes are identical either way, so ordinary
    (small) exports keep today's inline behaviour byte-for-byte.
    ``<= 0`` disables the offload (always inline).  Config:
    ``business_reports.export_inline_max_bytes``.
    """
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get("business_reports", "export_inline_max_bytes",
                            10 * 1024 * 1024))
    except Exception:
        return 10 * 1024 * 1024


def _share_stamp(report: Optional[dict], user: Optional[dict]) -> dict:
    """Entitlement-sharing stamp for an export, or {} if unprovable.

    Delegates to the ONE chokepoint so the rule that decides sharing
    and the rule that records it cannot drift.  Never raises: an
    unsignable scope means the download stays creator-only.
    """
    try:
        from core.download_sharing import stamp_for_business_report
        return stamp_for_business_report(report, user, _db_manager)
    except Exception:
        return {}


def _register_export_artifact(out_bytes: bytes, filename: str,
                              username: str, expires_at: datetime,
                              share: Optional[dict] = None):
    """Write the rendered export into the downloads dir, VERIFY it, then
    register it in the Download Centre.  Returns ``(file_id, Path)`` or
    ``None``.

    Ordering is the artifact-required rule: the row is created only AFTER
    the file is on disk with the expected byte count, and a registration
    failure after the write unlinks the file — never a row without its
    verified file, never an orphan file without its row.

    Fail-open FOR THE RESPONSE only: any failure here is logged and the
    export is still served inline from the bytes already in hand (the
    export itself succeeded; only the re-download convenience is lost).
    """
    db = _db_manager
    if db is None or not callable(getattr(db, "create_download_file", None)):
        return None
    if not username:
        # No principal → no ownership signal.  _enforce_download_ownership
        # FAILS OPEN on rows carrying neither created_by nor execution_id,
        # so registering here would mint an artifact readable by every
        # authenticated user.  Refuse to register instead (the inline
        # response is unaffected).
        logger.info("export not registered in Download Centre: no "
                    "authenticated principal to own it")
        return None
    out_path: Optional[Path] = None
    try:
        from core.config import paths as _cfg_paths
        downloads_dir = Path(str(_cfg_paths.downloads_dir))
        downloads_dir.mkdir(parents=True, exist_ok=True)
        file_id = str(uuid.uuid4())
        suffix = Path(filename).suffix or ".bin"
        # Same layout as execute_api: id-named file directly under the
        # downloads dir (execution-id there, file-id here — reports have no
        # QueryExecution row to name it after).
        out_path = downloads_dir / f"{file_id}{suffix}"
        out_path.write_bytes(out_bytes)
        written = int(out_path.stat().st_size)
        if written != len(out_bytes):
            raise IOError(f"short write: {written} of {len(out_bytes)} bytes")
        _row_kwargs = dict(
            file_id=file_id,
            filename=filename,
            file_path=str(out_path),
            file_size_bytes=written,
            expires_at=expires_at,
            created_by=username,
        )
        try:
            # Entitlement-sharing stamp (core.download_sharing).  Empty when
            # the scope could not be signed — the row is then creator-only.
            db.create_download_file(**_row_kwargs, **(share or {}))
        except TypeError as _stamp_exc:
            # A store that does not know the stamp columns must cost us the
            # SHARING, not the DOWNLOAD: without this, one signature drift
            # turns into "registration skipped" and the user silently loses
            # the file from the Download Centre altogether.
            if not share:
                raise
            logger.warning("download store rejected the sharing stamp (%s) "
                           "— registering %s creator-only",
                           _stamp_exc, filename)
            db.create_download_file(**_row_kwargs)
        return file_id, out_path
    except Exception as exc:
        if out_path is not None:
            try:
                out_path.unlink(missing_ok=True)
            except OSError:
                pass
        logger.warning("Download Centre registration skipped for %s: %s",
                       filename, exc)
        return None


async def _serve_export(out_bytes: bytes, filename: str, media_type: str,
                        headers: dict, username: str, expires_at: datetime,
                        share: Optional[dict] = None):
    """Serve a rendered export, registering it in the Download Centre.

    * Registration success is disclosed via the ADDITIVE
      ``X-QS-Download-Id`` header — the reference a client can later fetch
      through the existing ``/api/downloads/{file_id}`` routes.  The body
      and every pre-existing header are unchanged (the frontend's
      ``openDownload`` blobs whatever body arrives, so the response SHAPE
      cannot change without breaking it — see the module comment above).
    * At/above ``_export_inline_max_bytes`` the registered on-disk file
      itself is served (FileResponse, chunked) instead of buffering a
      second in-memory copy; identical bytes.
    * Registration failure → today's inline StreamingResponse exactly.
    """
    reg = await asyncio.to_thread(_register_export_artifact, out_bytes,
                                  filename, username, expires_at, share)
    if reg is not None:
        file_id, out_path = reg
        headers = dict(headers)
        headers["X-QS-Download-Id"] = file_id
        inline_max = _export_inline_max_bytes()
        if inline_max > 0 and len(out_bytes) >= inline_max:
            from fastapi.responses import FileResponse
            return FileResponse(path=str(out_path), media_type=media_type,
                                headers=headers)
    return StreamingResponse(_byte_chunks(out_bytes), media_type=media_type,
                             headers=headers)


#: Body chunk for an in-memory export.  ``StreamingResponse(io.BytesIO(b))``
#: iterates a BytesIO BY LINE: a 500k-row CSV became 500k body messages, each
#: a thread-pool hop and a socket write, and a binary PDF was split at every
#: 0x0A byte.  Same bytes, sent in 64 KiB slices.
_BODY_CHUNK = 64 * 1024


def _byte_chunks(data: bytes):
    view = memoryview(data)
    for i in range(0, len(view), _BODY_CHUNK):
        yield bytes(view[i:i + _BODY_CHUNK])


# ── Streamed exports: written to a FILE, then served from it (2026-10-04) ────
#
# A streamed CSV / Excel is written by a worker into the downloads dir under
# a fresh id, verified, registered in the Download Centre (the same row
# _register_export_artifact writes for an in-memory export), and served from
# disk.  Nothing holds the whole document in memory, and the response starts
# only once the file is COMPLETE -- so X-QS-Rows is the number of rows in it,
# not a promise, and a writer that fails mid-way is a clean error, never a
# 200 that ends early.

def _new_export_target(suffix: str) -> tuple:
    """``(file_id, Path)`` for a new export file in the downloads dir.

    Fail-open FOR THE RESPONSE, as registration always was: when the
    downloads dir cannot be used the file goes to a private temp dir, is
    served, and is never registered (``_register_export_file`` refuses a
    path outside the downloads dir) -- the export still works, only the
    re-download convenience is lost."""
    file_id = str(uuid.uuid4())
    try:
        from core.config import paths as _cfg_paths
        downloads_dir = Path(str(_cfg_paths.downloads_dir))
        downloads_dir.mkdir(parents=True, exist_ok=True)
        return file_id, downloads_dir / f"{file_id}{suffix}"
    except Exception as exc:
        import tempfile
        logger.warning("export: downloads dir unusable (%s) -- writing to a "
                       "private temp file; it will not be registered", exc)
        return file_id, Path(tempfile.mkdtemp(prefix="qs_export_")) / f"{file_id}{suffix}"


def _in_downloads_dir(path: Path) -> bool:
    try:
        from core.config import paths as _cfg_paths
        return Path(path).resolve().parent == Path(str(_cfg_paths.downloads_dir)).resolve()
    except Exception:
        return False


def _register_export_file(file_id: str, path: Path, filename: str,
                          username: str, expires_at: datetime,
                          share: Optional[dict] = None) -> bool:
    """Register an export file ALREADY WRITTEN at ``path`` (its verified
    size is what is recorded).  The same rules as
    :func:`_register_export_artifact`: no principal = not registered (an
    owner-less row fails open), a store that rejects the sharing stamp
    costs the sharing, not the download.  Returns True when registered."""
    db = _db_manager
    if db is None or not callable(getattr(db, "create_download_file", None)):
        return False
    if not username:
        logger.info("export not registered in Download Centre: no "
                    "authenticated principal to own it")
        return False
    if not _in_downloads_dir(path):
        return False
    try:
        row = dict(file_id=file_id, filename=filename, file_path=str(path),
                   file_size_bytes=int(path.stat().st_size),
                   expires_at=expires_at, created_by=username)
        try:
            db.create_download_file(**row, **(share or {}))
        except TypeError as _stamp_exc:
            if not share:
                raise
            logger.warning("download store rejected the sharing stamp (%s) "
                           "— registering %s creator-only", _stamp_exc, filename)
            db.create_download_file(**row)
        return True
    except Exception as exc:
        logger.warning("Download Centre registration skipped for %s: %s",
                       filename, exc)
        return False


def _discard_file(path: Path) -> None:
    try:
        Path(path).unlink(missing_ok=True)
    except OSError:
        pass
    try:
        parent = Path(path).parent
        if parent.name.startswith("qs_export_") and not any(parent.iterdir()):
            parent.rmdir()           # the private fallback dir of _new_export_target
    except OSError:
        pass


def _verify_export_file(path: Path, expected_size: Optional[int]) -> None:
    """The verified-artifact rule for a STREAMED export: the file on disk is
    the file the writer wrote (its own byte count), or the export FAILS --
    the file is the response, so a short one must never be served as the
    data (nor registered)."""
    actual = path.stat().st_size if path.exists() else -1
    if expected_size is not None and actual != int(expected_size):
        _discard_file(path)
        raise HTTPException(
            status_code=500,
            detail=(f"The export file was not fully written ({actual} of "
                    f"{expected_size} bytes on disk) -- refusing to serve a "
                    f"partial file. Retry the export."))


async def _serve_export_file(file_id: str, path: Path, filename: str,
                             media_type: str, headers: dict, username: str,
                             expires_at: Optional[datetime],
                             share: Optional[dict] = None,
                             expected_size: Optional[int] = None):
    """Serve a COMPLETE export file.  Registered -> it stays for the Download
    Centre (``X-QS-Download-Id``); not registered (no principal, a store
    failure) -> deleted once sent.  The SAME transport rule as
    :func:`_serve_export`: below ``export_inline_max_bytes`` the body is
    sent inline (identical bytes, the small-export behaviour pinned since
    2026-08-30), at or above it the file is streamed from disk."""
    from fastapi.responses import FileResponse
    from starlette.background import BackgroundTask

    await asyncio.to_thread(_verify_export_file, path, expected_size)
    registered = False
    if expires_at is not None:
        registered = await asyncio.to_thread(
            _register_export_file, file_id, path, filename, username,
            expires_at, share)
    headers = dict(headers)
    if registered:
        headers["X-QS-Download-Id"] = file_id
    size = path.stat().st_size
    inline_max = _export_inline_max_bytes()
    if inline_max <= 0 or size < inline_max:
        body = await asyncio.to_thread(path.read_bytes)
        if not registered:
            _discard_file(path)
        return StreamingResponse(_byte_chunks(body), media_type=media_type,
                                 headers=headers)
    if registered:
        return FileResponse(path=str(path), media_type=media_type,
                            headers=headers)
    return FileResponse(path=str(path), media_type=media_type, headers=headers,
                        background=BackgroundTask(_discard_file, path))


async def _run_export_work(fn, *args, username: str = "export"):
    """Run an export's heavy, blocking work on the worker pool's EXPORT slot
    (bounded concurrency, its own queue) -- never on the event loop, and not
    on asyncio's default executor, which every ``adb()`` call shares (a few
    long exports there starve the API's database calls).

    A full EXPORT queue is a 503 + Retry-After (a cap that throttles); a
    pool that is shutting down falls back to a thread.
    """
    try:
        from core.worker_pool import QueueFullError, WorkType, get_pool
    except Exception:                                  # pragma: no cover
        return await asyncio.to_thread(fn, *args)
    try:
        record = await get_pool().submit(WorkType.EXPORT, fn, *args,
                                         username=username or "export")
    except QueueFullError:
        raise HTTPException(
            status_code=503,
            detail="The export queue is full -- too many exports are running "
                   "on this server right now. Retry in a minute.",
            headers={"Retry-After": "30"}) from None
    except RuntimeError:
        return await asyncio.to_thread(fn, *args)
    return await asyncio.wrap_future(record.future)


async def _execute_report_internal(report_id: int, username: str, role: str,
                                    param_values: dict | None = None,
                                    limit_override: int | None = None,
                                    user: dict | None = None,
                                    cert_sink: dict | None = None,
                                    meta_sink: dict | None = None,
                                    override_column_ids: list | None = None,
                                    extra_filters: list | None = None,
                                    materialize: bool = True) -> tuple:
    """Execute a business report and return (rows: list[dict], columns: list[str], report_meta: dict).

    ``materialize=False`` (2026-10-04, the streamed CSV / Excel exports):
    nothing is read into Python.  ``rows`` is an inline (published /
    federation view) result when there is one, else ``[]``, and
    ``meta_sink`` receives ``artifact_path`` (the verified parquet the caller
    streams from), ``total_rows`` (its exact footer count) and ``row_limit``
    (the bound the execution actually ran under).  An inline source asked
    for every row (``limit_override=0``) runs under
    ``export_materialize_cap`` instead: its engine materialises the result
    as a Python list whatever the export does next, so the memory gate is
    the honest bound there -- and the cut is disclosed by the caller.

    ``meta_sink`` (optional, additive — same out-parameter idiom as
    ``cert_sink``): when provided, receives ``meta_sink["total_rows"]`` = the
    TRUE row count of the produced result (the artifact's COUNT(*) or the
    inline length).  This can exceed ``len(rows)`` when the SCALE-1 memory cap
    bounded what was materialised, so the export routes can disclose the cut
    honestly.  Kept out of the return tuple so the 3-value contract is
    unchanged for existing callers.

    Shared helper for PDF/Excel/CSV export endpoints.
    Delegates dispatch to ``_dispatch_report_execution``, then materializes rows from the result.

    ``user`` (optional): the FULL authenticated caller dict (incl. ``groups``).
    It is threaded into the dispatcher as the RLS principal so an EXPORT applies
    the SAME group-scoped grants as the on-screen/interactive report.  Omitting
    it degrades to a groups-less ``{username, role}`` principal (fail-safe
    under-fetch, never a broaden).
    """
    db = _require_db()
    fed = _require_federation()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # 2026-08-05 audit fix (scheduled/interactive parity): exports now use the
    # SAME view chokepoint as /execute (_br_can_view → core.reports.
    # authorization.can_view_business_report).  The old inline
    # is_published/owner/admin check (a) DENIED users who could legitimately
    # run the report interactively — explicit Phase-157 grant holders,
    # owner_group members, the support role — and (b) ignored role_whitelist
    # on published reports.  One chokepoint, no drifting copies.
    principal = user or {"username": username, "role": role}
    if not await _adb(_br_can_view, report, principal):
        raise HTTPException(
            status_code=403,
            detail="You do not have view access to this report, so it cannot "
                   "be exported. Ask the report owner for access (Share > "
                   "Request access) — export uses the same permission as "
                   "viewing.")

    # Publish lifecycle (2026-08-17): an EXPORT follows the same fork as
    # /execute — editors export the draft, consumers export the current
    # published version (410 for archived consumers).
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, principal)

    # 2026-08-31: the viewer's runtime column choice reaches the EXPORT
    # too.  Without this a user could narrow 200 columns to 8 on screen,
    # click Export, and receive all 200 — the screen/file divergence this
    # area keeps producing.  Validated to a SUBSET of the report's own
    # columns, so it can narrow and never widen.
    _sel_ds_cols = []
    if override_column_ids:
        # Only pay for the dataset-column read when a selection was
        # actually made — the overwhelming majority of exports make none.
        try:
            _sel_ds_cols = await _adb(db.list_dataset_columns,
                                      report.get("dataset_id")) or []
        except Exception as _dsx:
            logger.warning("[report-columns] could not read dataset "
                           "columns for report %s (%s) — running the full "
                           "report", report_id, _dsx)
    if (not materialize and limit_override is not None and int(limit_override) <= 0
            and report.get("data_source_type") in _INLINE_RESULT_SOURCES):
        _inline_cap = _export_materialize_cap()
        if _inline_cap > 0:
            limit_override = _inline_cap
    if meta_sink is not None:
        meta_sink["row_limit"] = limit_override
    # 2026-09-17 -- was a hard-coded None into a dispatcher parameter named
    # extra_filters that has always existed.  That is why an export could not
    # reproduce the run it was exporting.
    # 2026-11-02 -- the export reproduces the run: a default RULE applies for this
    # signed-in viewer (a 'latest date with data' export carried EVERY date, 100 MB).
    # The token roads (share / embed) are not filled: a token is never served a
    # source-table list (param_lists.stored_list_for).
    param_values = await _fill_rule_defaults_or_409(db, report, param_values, user)
    _dispatch_on("export")
    result = await _dispatch_report_execution(
        report, report_id, param_values or {}, extra_filters or None,
        limit_override,
        db, fed, role, username, user_ctx=user,
        override_column_ids=_validated_column_subset(
            report, override_column_ids, _sel_ds_cols),
        # kwarg only when the streamed road is asked for: the historical
        # call shape (and every dispatcher double with a closed signature)
        # stays as it was.
        **({"materialize": False} if not materialize else {}))
    # 2026-09-28 -- an export is a run: record the readiness it was served
    # under (fail-open inside; never changes the export).
    if isinstance(result, dict) and result.get("execution_id"):
        try:
            from core.reports.readiness import record_readiness_run as _rec_rd
            _rd_exp = await asyncio.to_thread(
                _readiness_for_execute, db, report, param_values or {}, report_id)
            await asyncio.to_thread(_rec_rd, db, _rd_exp,
                                    execution_id=str(result.get("execution_id")),
                                    executed_by=username, surface="export")
        except Exception as _rd_exc:                  # noqa: BLE001
            logger.warning("[readiness] export of report %s: verdict not "
                           "recorded: %s", report_id, _rd_exc)

    # 2026-07-18 Completeness Certificate (Phase 4) — best-effort, fail-open.
    # The iceberg reader pushed the fail-closed cert into the per-execution
    # diagnostic store keyed by this run's execution_id.  Surface it via the
    # caller-supplied sink so export endpoints can render a footer.  Absence /
    # any error simply leaves the sink untouched (footer becomes "").
    if cert_sink is not None and isinstance(result, dict):
        try:
            _exec_id = result.get("execution_id")
            if _exec_id:
                from core.query_diagnostic_store import get_pruning as _get_pruning
                _cert_d = (_get_pruning(_exec_id) or {}).get("completeness_certificate")
                if _cert_d:
                    cert_sink["certificate"] = _cert_d
        except Exception as _cert_exc:
            logger.debug("cert capture skipped (fail-open): %s", _cert_exc)

    # 2026-10-30 -- a canvas band tile shows the values this export ran with;
    # an insight tile compares with an earlier run only under THIS caller's
    # live row access (canvas_insights.previous_run_of)
    report = {**report, "_canvas_param_values": dict(param_values or {}), "_canvas_viewer": principal}

    # Materialize rows: PV/FV return inline {data:[...]}, raw_sql/dataset/pivot return {output_path:...}
    mem_cap = _export_materialize_cap()
    rows: list[dict] = result.get("data", []) if isinstance(result, dict) else []
    columns: list[str] = result.get("columns", []) if isinstance(result, dict) else []
    total_rows: int | None = None

    if not materialize:
        # The streamed road: hand over WHERE the rows are, read none of them.
        if meta_sink is not None:
            _res = result if isinstance(result, dict) else {}
            if rows:
                meta_sink["total_rows"] = len(rows)
                meta_sink["artifact_path"] = ""
            else:
                meta_sink["total_rows"] = _res.get("total_rows")
                meta_sink["artifact_path"] = _res.get("output_path") or ""
        return rows, columns, report

    if rows:
        # Inline result (PV/FV): the engine already materialised it.  Record
        # the true total and bound the list we carry forward so downstream
        # to_dict / to_wire copies cannot explode past the memory ceiling.
        total_rows = len(rows)
        if mem_cap > 0 and total_rows > mem_cap:
            rows = rows[:mem_cap]
    else:
        output_path = result.get("output_path", "") if isinstance(result, dict) else ""
        if output_path and Path(output_path).exists():
            # SCALE-1: read a BOUNDED page through DuckDB (COUNT + LIMIT) rather
            # than pd.read_parquet(whole file).to_dict(records) — the old path
            # pulled the entire (possibly tens-of-millions-row) artifact into a
            # Python list-of-dicts and OOM-killed the single-replica API pod
            # (?limit=50000000 was honoured verbatim).  ``total`` is the true
            # COUNT(*); only ``mem_cap`` rows are materialised.
            from core.reports.pagination import read_artifact_page
            read_limit = mem_cap if mem_cap > 0 else None
            recs, cols, total = await asyncio.to_thread(
                read_artifact_page, Path(output_path), offset=0, limit=read_limit)
            columns = cols or columns
            # Off the loop: a full walk of every value (2026-10-04).
            rows = await asyncio.to_thread(sanitize_for_json, recs)
            total_rows = total

    if meta_sink is not None:
        meta_sink["total_rows"] = total_rows
    return rows, columns, report


def _read_bounded_rows(artifact: str, cap: int) -> tuple:
    """``(records, columns, true_total)`` -- at most ``cap`` rows of an
    artifact (``<= 0`` = all), as the in-memory export path always read them
    (DuckDB page -> ``sanitize_for_json``).  Synchronous."""
    from core.reports.pagination import read_artifact_page
    recs, cols, total = read_artifact_page(Path(artifact), offset=0,
                                           limit=cap if cap > 0 else None)
    return sanitize_for_json(recs), cols, total


def _export_continue_with(report_id: int) -> str:
    """The route that serves every row of a report: the streamed CSV."""
    return f"/api/business-reports/{report_id}/download-csv"


def _build_report_pdf_bytes(report: dict, rows: list, columns: list,
                            disclosure: str, truncated: bool,
                            footer_text: str, canvas: dict | None = None) -> bytes:
    """Everything a report PDF costs after the rows are in hand -- styles,
    sections, running calculations, the pivot matrix, the render -- on ONE
    worker thread (2026-10-04: these ran on the event loop around a
    to_thread'ed render).  ``rows`` is already cut to the document."""
    from core import config as _cfg
    db = _require_db()
    report_name = report.get("name", f"Report {report.get('id')}")
    header_bg, header_text, neg_fmt, _, col_fmt_map, ds_cols = _extract_style_and_formats(report, db)
    # 2026-10-24 -- a top / bottom N rule ranks the column (format_rules)
    from core.reports.format_rules import attach_cutoffs
    fmt_rules = attach_cutoffs(_extract_fmt_rules(report), rows=rows, columns=columns)
    lc = report.get("layout_config") or {}

    # BANDED DOCUMENT (2026-08-30): section definitions, per-column styles
    # and the author's page layout reach the export.  Every helper returns
    # None/{} for a report that declares nothing, and every render kwarg
    # below is passed only when non-empty — such a report renders
    # BYTE-IDENTICALLY to the historical output (pinned by hash in tests).
    _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)
    _rc_notes: list = []
    _col_styles = _extract_column_styles(report, columns)
    _pdf_layout = _extract_pdf_layout(report, _cfg.business_reports.pdf_page_size)
    _page_size = ((_pdf_layout or {}).get("page_size")
                  or _cfg.business_reports.pdf_page_size)

    if lc.get("report_type") == "pivot" and lc.get("pivot_config"):
        if _band_notes:
            disclosure += " " + " ".join(_band_notes)
        matrix = _build_pivot_matrix(rows, lc["pivot_config"], ds_cols,
                                     result_columns=columns)
        # A crosstab cut by pivot_reports.max_*_groups says so in the SAME
        # banner the row cut already uses -- one disclosure channel.
        disclosure += _pivot_truncation_suffix(matrix)
        return _render_pivot_pdf_bytes(
            matrix, report_name, header_bg, header_text,
            _cfg.business_reports.pdf_page_size, neg_fmt, col_fmt_map,
            footer_text=footer_text, disclosure_text=disclosure, fmt_rules=fmt_rules)

    # GAP-2 (2026-08-30): running-calculation columns over the exact rows
    # this document carries (section sort FIRST, so calcs follow the banded
    # display order — export == screen).  Inert for reports without calcs.
    _exp_rows = rows
    if _band_spec:
        _exp_rows = _section_sort_rows(_exp_rows, _band_spec["defs"])
    _exp_rows, _exp_cols = _augment_rows_with_running_calcs(
        _exp_rows, columns, report, ds_cols, _rc_notes)
    disclosure += _running_calc_disclosure_suffix(_exp_cols is not columns,
                                                  truncated)
    disclosure += _banded_disclosure_suffix(bool(_band_spec), truncated)
    if _band_notes:
        # A band that cannot be rendered is never silently dropped.
        disclosure += " " + " ".join(_band_notes)
    if _rc_notes:
        # Nor a running calculation that could not render.
        disclosure += " " + " ".join(_rc_notes)
    return _render_pdf_bytes(
        _exp_rows, _exp_cols, report_name,
        header_bg, header_text, neg_fmt, col_fmt_map,
        _page_size, footer_text=footer_text,
        disclosure_text=disclosure,
        # kwargs only when the feature is in play: a report using none of
        # them keeps the HISTORICAL call shape.
        **({"fmt_rules": fmt_rules} if fmt_rules else {}),
        **({"sections": _band_spec} if _band_spec else {}),
        **({"column_styles": _col_styles} if _col_styles else {}),
        **({"pdf_layout": _pdf_layout} if _pdf_layout else {}),
        **({"canvas": canvas} if canvas else {}))


def _canvas_pages(report: dict) -> list:
    """The report's pages for a document (2026-11-02; ``canvas.export_pages``): a sheet /
    a PDF page per tab; one page = the document as before."""
    from core.reports.canvas import effective_canvas, export_pages
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else {}
    return export_pages(effective_canvas(lc or {}))


def _canvas_look(report: dict, db=None) -> Optional[dict]:
    """Theme v2 (2026-11-02): the page / card / KPI colours a document prints
    (``themes.card_look`` of the report's resolved theme); None for a report
    with no theme, so its document is byte for byte what it was."""
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else None
    if not lc or lc.get("theme") is None:
        return None
    from core.reports.themes import card_look, theme_of
    return card_look(theme_of(lc, db))


def _report_in_view_theme(report: dict, theme: Optional[str], db=None) -> dict:
    """The report as THIS export prints it when the viewer looks at it in another
    theme (2026-11-03, ``?theme=<name>``): a copy whose ``layout_config`` is
    ``themes.layout_in_theme`` -- the named theme through THE resolver (library,
    then shipped; the sanitiser still runs inside ``theme_of`` on every read).
    No name, or a name the resolver does not know = the report itself (its own
    theme; the file is made as before and nothing is refused).  The returned
    dict is a copy: the report's stored layout is never changed."""
    if not theme:
        return report
    from core.reports.themes import layout_in_theme
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else None
    viewed = layout_in_theme(lc, theme, db)
    if viewed is None:
        logger.info("[export] report %s: the theme %r is not known; the report's own theme is used",
                    report.get("id"), str(theme)[:100])
        return report
    return {**report, "layout_config": viewed}


def _canvas_pdf_parts(report: dict, tables: list, db) -> dict:
    """The canvas for a PDF (2026-10-26): the tiles laid out as the viewer
    places them (``core.reports.canvas_pdf``), charts as inline SVG, each
    table cell formatted by the report's own cell formatter (format
    patterns, bracket negatives), text escaped."""
    from core import config as _cfg
    from core.reports.canvas_export import report_tile_layout
    from core.reports.canvas_pdf import canvas_pdf_parts
    header_bg, header_text, neg_fmt, _, _, _ = _extract_style_and_formats(report, db)
    page_size = ((_extract_pdf_layout(report, _cfg.business_reports.pdf_page_size) or {}).get("page_size")
                 or _cfg.business_reports.pdf_page_size)
    parts = canvas_pdf_parts(
        tables, report_tile_layout(report), page_size=page_size, header_bg=header_bg, header_text=header_text,
        fmt_value=lambda name, v, fmt_map: _fmt_pdf_val(name, v, fmt_map, neg_fmt), look=_canvas_look(report, db),
        pages=_canvas_pages(report))
    line = _canvas_links_line(tables)
    if line:                                   # 2026-10-30 -- linked tiles: said once above the canvas
        import html as _html
        parts = {**parts, "above": f'<div class="cv-note">{_html.escape(line)}</div>' + parts.get("above", ""),
                 "css": parts.get("css", "") + "\n.cv-note { font-size: 8pt; color: #7A3E00; }"}
    return parts


def _pdf_table_under_links(report: dict, links: list, artifact: str, rows: list, plan: dict) -> tuple:
    """``(rows, note, matching_rows | None)`` -- the PDF's own table under the
    canvas's clicked values (2026-10-30, every report a canvas): the matching
    rows of the tiles' stored result, at most the PDF's own execution limit.
    ``None`` = no link applies to the table (the rows are unchanged).  A filter
    that cannot be applied gives NO rows and says why -- never every row."""
    from core.reports import report_table_links as _rtl
    db = _require_db()
    ds = db.get_dataset_full(report.get("dataset_id")) if report.get("dataset_id") else None
    try:
        flt, words = _rtl.report_table_filter(report, links, (ds or {}).get("columns", []) or [])
        if flt is None:
            return rows, "", None
        if not artifact:
            raise _rtl.TableLinkRefused(
                "it cannot follow the clicked values in this export (there is no stored result to filter). "
                "Clear the clicked values to export every row.")
        tmp, n = _rtl.filtered_artifact(artifact, flt)
    except _rtl.TableLinkRefused as exc:
        return [], str(exc), 0
    try:
        recs, _cols, _total = _read_bounded_rows(tmp, int(plan.get("exec_limit") or 0))
    finally:
        _rtl.discard(tmp)
    return recs, _rtl.table_note(words), n


def _footer_from_cert(cert_sink: dict) -> str:
    """Completeness Certificate footer (best-effort, fail-open -> "")."""
    try:
        from core.completeness_certificate import footer_text_from_dict as _ftfd
        return _ftfd(cert_sink.get("certificate"))
    except Exception:
        return ""


def _raise_execution_failure(exc: Exception) -> None:
    """The export routes' one mapping of an execution failure."""
    raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After
    from core.error_sanitizer import sanitize_error as _se
    raise HTTPException(status_code=500, detail=f"Report execution failed: {_se(str(exc))}")


@router.get("/api/business-reports/{report_id}/download-pdf")
async def download_business_report_pdf(
    report_id: int,
    user: dict = Depends(require_capability("reports.view")),
    # 2026-08-09 caps-throttle-not-refuse: an explicit caller limit is a
    # THROTTLE.  2026-10-04: bounded by the PDF memory ceiling
    # (business_reports.pdf_max_rows) -- past it the document carries the
    # first rows and SAYS so, pointing at the CSV export.  Default (limit=0)
    # is business_reports.pdf_row_limit.
    limit: int = Query(default=0, ge=0),
    params_json: str = Query(default="", alias="params"),
    retain_days: Optional[int] = Query(default=None),
    # 2026-08-31 — the viewer's runtime column choice, so the file matches
    # the screen.  Comma-separated column NAMES as shown in the report
    # (?columns=region,amount); narrowed to a SUBSET of the report's own
    # columns server-side, so it can never widen what the author published.
    columns: Optional[str] = Query(default=None),
    # 2026-09-17 -- the other half of the ``columns`` sentence above: the
    # viewer's runtime FILTERS, so the file matches the screen.  Without it an
    # export re-ran the saved definition and silently WIDENED the result.
    filters: Optional[str] = Query(default=None),
    # 2026-10-30 -- the canvas's LINKED tiles: the values the viewer clicked
    # ([{column_id, value, tile_id}], core.reports.canvas_links), so the
    # tiles in the file are filtered as on the screen.  Absent = as before.
    links: Optional[str] = Query(default=None),
    # 2026-11-03 -- the viewer's "View in another theme": a theme NAME only (never
    # colours), resolved by _report_in_view_theme through themes.theme_of; an
    # unknown name prints the report's own theme.  Absent = as before.
    theme: Optional[str] = Query(default=None, max_length=100),
):
    """Execute business report and return PDF download.

    2026-10-04 (live: a 5M-row report's PDF OOM-KILLED the API container):
    the document carries at most ``pdf_max_rows`` rows (the execution asks
    for one more, so a cut is KNOWN and disclosed on the document and in
    X-QS-*), it is built on a worker thread, and it is rendered in a
    budgeted child process -- a document too large for its budget is a 422
    naming the limit, never a dead pod.
    """
    _enforce_export_format("pdf")
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    plan = _pdf_row_plan(limit)
    param_values = _parse_export_params(params_json)
    canvas_links = _parse_canvas_links(links)
    # Validate the requested retention BEFORE paying execution cost.
    _dl_expires = _export_expires_at(retain_days)

    _cert_sink: dict = {}
    _meta_sink: dict = {}
    try:
        rows, columns, report = await _execute_report_internal(
            report_id, username, role, param_values=param_values,
            limit_override=plan["exec_limit"], user=user, cert_sink=_cert_sink,
            meta_sink=_meta_sink, override_column_ids=_parse_column_names(columns),
            extra_filters=_parse_export_filters(filters))
    except HTTPException:
        raise
    except Exception as exc:
        _raise_execution_failure(exc)
    report = _report_in_view_theme(report, theme, _require_db())

    # 2026-10-26 -- the report canvas: the tiles add up the report's rows as
    # the viewer does, NOT the PDF's page-ceiling cut of them -- so they come
    # from their own run with the report's own limits (the result cache makes
    # it the viewer's run when the parameters match)
    _tile_sink: dict = {}
    _tile_run_error: Optional[Exception] = None
    _table_note = ""
    if _has_canvas_tiles(report):
        try:
            await _execute_report_internal(
                report_id, username, role, param_values=param_values,
                limit_override=None, user=user, meta_sink=_tile_sink,
                extra_filters=_parse_export_filters(filters), materialize=False)
        except HTTPException:
            raise
        except Exception as exc:                              # noqa: BLE001
            _tile_run_error = exc
        # 2026-10-30 (every report a canvas): the report's OWN table follows the
        # clicked values -- the PDF's rows are the matching rows of the tiles' run
        if canvas_links and _tile_run_error is None:
            rows, _table_note, _matched = await _run_export_work(
                _pdf_table_under_links, report, canvas_links, _tile_sink.get("artifact_path") or "",
                rows, plan, username=username)
            if _matched is not None:
                _meta_sink["total_rows"] = _matched

    total_rows = _meta_sink.get("total_rows")
    rows, cut_by_ceiling = _apply_pdf_plan(rows, plan)
    effective_limit = plan["ceiling"] if plan["over"] else plan["requested"]
    footer_text = _footer_from_cert(_cert_sink)

    # 2026-08-09 caps-throttle-not-refuse: a row limit is a CAP — the export
    # delivers the rows it fetched and states any cut ON the document
    # (banner) and in the X-QS-* headers.
    if plan["over"]:
        # Executed for ceiling+1 rows: the extra row is the PROOF of a larger
        # result; its absence is the proof of a complete one.
        total_rows = None
        _truncated_flag = cut_by_ceiling
        disclosure = (_pdf_ceiling_disclosure(len(rows), plan["ceiling"])
                      if cut_by_ceiling else "")
    else:
        disclosure = _export_truncation_disclosure("pdf", len(rows), effective_limit, total_rows)
        _truncated_flag = (bool(effective_limit) and len(rows) >= effective_limit) or (
            total_rows is not None and total_rows > len(rows))

    canvas = None
    if _has_canvas_tiles(report):
        try:
            if _tile_run_error is not None:
                raise _tile_run_error
            canvas = await _run_export_work(
                lambda: _canvas_pdf_parts(report, _canvas_export_tables(
                    report, _tile_sink.get("artifact_path") or "", _require_db(),
                    truncated=bool(_tile_sink.get("truncated")),
                    row_limit=_tile_sink.get("row_limit"), links=canvas_links), _require_db()), username=username)
        except HTTPException:
            raise
        except Exception as exc:                              # noqa: BLE001
            logger.warning("[canvas-export] PDF tiles for report %s: %s", report_id, exc, exc_info=True)
            canvas = {"above": '<div class="cv-note">The canvas tiles could not be added to this PDF. '
                               'The report\'s own rows are complete.</div>', "below": "",
                      "css": "\n.cv-note { font-size: 8pt; color: #7A3E00; }"}
        if _table_note and isinstance(canvas, dict):
            import html as _html
            canvas = {**canvas, "above": f'<div class="cv-note">The report\'s table: {_html.escape(_table_note)}</div>'
                      + canvas.get("above", "")}
    try:
        pdf_bytes = await _run_export_work(
            _build_report_pdf_bytes, report, rows, columns, disclosure,
            _truncated_flag, footer_text, canvas, username=username)
    except HTTPException:
        raise
    except PdfRendererUnavailable as exc:
        # 501 is a CAPABILITY statement; its detail is the pdf_engine
        # constant, never exception text (main.py lets a 501 through).
        raise HTTPException(status_code=501, detail=str(exc))
    except PdfRenderRefused as exc:
        raise _pdf_refusal(exc)
    except Exception as exc:
        from core.error_sanitizer import sanitize_error as _se
        logger.error("PDF render failed: %s", _se(str(exc)), exc_info=True)
        raise HTTPException(status_code=500, detail=f"PDF render failed: {_se(str(exc))}")

    report_name = report.get("name", f"Report {report_id}")
    filename = f"{_sanitize_export_filename(report_name)}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
    try:
        await _adb(_db_manager.audit, username, "export_report_pdf", resource_type="business_report",
                   resource_id=str(report_id), detail=f"rows={len(rows)}")
    except Exception as e:
        logger.warning("Failed to audit PDF export (report_id=%s, user=%s): %s", report_id, username, e)
    from core.reports.serve_log import log_report_serve
    log_report_serve(report_id=report_id, user=username, rls="caller",
                     surface="export", fmt="pdf", rows=len(rows),
                     total_rows=total_rows,
                     row_limit=effective_limit,
                     truncated=_truncated_flag)
    # Download Centre registration + serve.  Truncation disclosure travels
    # IN the stored bytes — the banner is rendered into the document.
    return await _serve_export(
        pdf_bytes, filename, "application/pdf",
        _export_response_headers(filename, len(rows), effective_limit, total_rows,
                                 truncated=_truncated_flag,
                                 continue_with=_export_continue_with(report_id)),
        username, _dl_expires,
        share=_share_stamp(report, user),
    )


def _write_report_excel_file(out_path: Path, report: dict, rows: list,
                             columns: list, artifact: str, row_limit: int,
                             total_rows: Optional[int],
                             footer_text: str, links: Optional[list] = None) -> dict:
    """Write a report's Excel export to ``out_path`` -- on a worker thread.

    Two roads, decided by what the document needs (2026-10-04):

    * IN MEMORY (the styled object model: stripes, banded sections, running
      calculations, the pivot crosstab) -- a pivot, a report with running
      calculations, or a result of at most ``excel_styled_max_rows`` rows.
      Rows come from the artifact through the old bounded read
      (``export_materialize_cap``) and the existing renderers.
    * STREAMED -- every other result: the artifact is read in record batches
      straight into a write-only workbook (``_write_excel_streaming``),
      spilling to a new sheet every 1,048,575 data rows.  Memory is one
      batch; a banded layout is not applied at this scale and the workbook
      says so.

    Returns ``{"rows", "total_rows", "truncated"}`` for the headers.
    """
    from core.reports.export_stream import artifact_columns, iter_artifact_rows

    db = _require_db()
    report_name = report.get("name", f"Report {report.get('id')}")
    header_bg, header_text, neg_fmt, stripe_rows, col_fmt_map, ds_cols = _extract_style_and_formats(report, db)
    # 2026-10-24 -- a top / bottom N rule ranks the WHOLE stored result
    from core.reports.format_rules import attach_cutoffs
    fmt_rules = attach_cutoffs(_extract_fmt_rules(report), artifact=artifact or None)
    lc = report.get("layout_config") or {}
    is_pivot = bool(lc.get("report_type") == "pivot" and lc.get("pivot_config"))
    has_calcs = bool(report.get("running_calculations")) and not is_pivot
    if not columns and artifact:
        columns = artifact_columns(artifact)
    known_total = total_rows if total_rows is not None else (len(rows) if rows else None)
    if _has_canvas_tiles(report):
        # 2026-10-26 -- the report canvas: ONE sheet laid out as the viewer,
        # every tile from THIS export's own stored result (the caller's run)
        return _write_canvas_excel_file(
            out_path, report, rows, columns, artifact, row_limit, known_total, footer_text,
            db=db, report_name=report_name, header_bg=header_bg, header_text=header_text,
            neg_fmt=neg_fmt, stripe_rows=stripe_rows, col_fmt_map=col_fmt_map, ds_cols=ds_cols,
            fmt_rules=fmt_rules, is_pivot=is_pivot, has_calcs=has_calcs, links=links)
    styled_max = _excel_styled_max_rows()
    small = known_total is not None and (styled_max <= 0 or known_total <= styled_max)

    if artifact and not rows and (is_pivot or has_calcs or small):
        rows, _cols, known_total = _read_bounded_rows(artifact, _export_materialize_cap())
        columns = columns or _cols
        artifact = ""
    if not artifact:
        disclosure = _export_truncation_disclosure("excel", len(rows), row_limit, known_total)
        truncated = (bool(row_limit) and len(rows) >= row_limit) or (
            known_total is not None and known_total > len(rows))
        excel_bytes = _render_report_excel_in_memory(
            report, rows, columns, report_name, header_bg, header_text, neg_fmt,
            stripe_rows, col_fmt_map, ds_cols, fmt_rules, disclosure, truncated,
            footer_text)
        out_path.write_bytes(excel_bytes)
        return {"rows": len(rows), "total_rows": known_total, "truncated": truncated,
                "bytes": len(excel_bytes)}

    _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)

    def _disclosure_for(n: int) -> str:
        text = _export_truncation_disclosure("excel", n, row_limit, known_total)
        if _band_notes:
            text = (text + " " + " ".join(_band_notes)).strip()
        return text

    n = _write_excel_streaming(
        str(out_path), list(columns),
        iter_artifact_rows(artifact, columns, limit=row_limit or None),
        report_name, header_bg, header_text, neg_fmt, col_fmt_map,
        footer_text=footer_text, disclosure_for=_disclosure_for,
        fmt_rules=fmt_rules, banded_omitted=bool(_band_spec),
        column_styles=_extract_column_styles(report, columns))
    truncated = (bool(row_limit) and n >= row_limit) or (
        known_total is not None and known_total > n)
    import zipfile
    with zipfile.ZipFile(str(out_path)) as _zf:      # a cut file has no central directory
        _zf.namelist()
    return {"rows": n, "total_rows": known_total, "truncated": truncated,
            "bytes": None}


#: the report tile's rows written INSIDE its block on the canvas sheet (the
#: styled road); past it the block says so and the rows go to the sheet
#: "Rows" through the streamed writer (never cut silently)
_CANVAS_REPORT_BLOCK_ROWS = 5_000


def _write_canvas_excel_file(out_path: Path, report: dict, rows: list, columns: list,
                             artifact: str, row_limit: int, known_total: Optional[int],
                             footer_text: str, *, db, report_name: str, header_bg: str,
                             header_text: str, neg_fmt: str, stripe_rows: bool,
                             col_fmt_map: dict, ds_cols: list, fmt_rules: list,
                             is_pivot: bool, has_calcs: bool, links: Optional[list] = None) -> dict:
    """A canvas report's Excel (2026-10-26): the canvas laid out on ONE
    visible sheet named after the report (``core.reports.canvas_xlsx``),
    its tiles from this export's own stored result; the report tile holds
    its rows when they fit (``_CANVAS_REPORT_BLOCK_ROWS``, and the block's
    width), otherwise the block says "N rows -- see the sheet 'Rows'" and
    the rows follow on a visible "Rows" sheet through the streamed writer
    (the per-sheet spill rule unchanged).  Returns the same dict as
    ``_write_report_excel_file``."""
    from core.reports.canvas_export import report_tile_layout

    tile_tables = _canvas_export_tables(
        report, artifact, db,
        truncated=bool(row_limit) and known_total is not None and known_total >= row_limit,
        row_limit=row_limit or None, links=links)
    layout = report_tile_layout(report)
    notes: list = []
    # 2026-10-30 (every report a canvas): the report's OWN table follows the
    # clicked values too -- its rows are the matching rows of this export's
    # stored result, written to a file of their own and read exactly as the
    # whole result is (core/reports/report_table_links.py)
    table_tmp = None
    table_refused = ""
    if layout is not None and links:
        from core.reports import report_table_links as _rtl
        try:
            t_flt, t_words = _rtl.report_table_filter(report, links, ds_cols)
            if t_flt is not None:
                if not artifact:
                    raise _rtl.TableLinkRefused(
                        "The report's table cannot follow the clicked values in this export: it has no stored "
                        "result to filter. Clear the clicked values to export every row.")
                table_tmp, known_total = _rtl.filtered_artifact(artifact, t_flt)
                artifact, rows = table_tmp, []
                notes.append(_rtl.table_note(t_words))
        except _rtl.TableLinkRefused as exc:
            table_refused = str(exc)
    try:
        return _write_canvas_excel_body(
            out_path, report, rows, columns, artifact, row_limit, known_total, footer_text,
            report_name=report_name, header_bg=header_bg, header_text=header_text, neg_fmt=neg_fmt,
            stripe_rows=stripe_rows, col_fmt_map=col_fmt_map, ds_cols=ds_cols, fmt_rules=fmt_rules,
            is_pivot=is_pivot, has_calcs=has_calcs, tile_tables=tile_tables, layout=layout,
            notes=notes, table_refused=table_refused)
    finally:
        if table_tmp:
            from core.reports.report_table_links import discard
            discard(table_tmp)


def _write_canvas_excel_body(out_path: Path, report: dict, rows: list, columns: list,
                             artifact: str, row_limit: int, known_total: Optional[int],
                             footer_text: str, *, report_name: str, header_bg: str,
                             header_text: str, neg_fmt: str, stripe_rows: bool,
                             col_fmt_map: dict, ds_cols: list, fmt_rules: list,
                             is_pivot: bool, has_calcs: bool, tile_tables: list, layout,
                             notes: list, table_refused: str = "") -> dict:
    """The canvas workbook once the tiles and the report table's rows are
    decided (split from ``_write_canvas_excel_file`` 2026-10-30, unchanged)."""
    import openpyxl
    from core.reports.canvas_xlsx import COLS_PER_GRID, write_canvas_workbook
    from core.reports.export_stream import iter_artifact_rows, iter_record_rows
    report_block = None
    batches = None
    n_written = 0
    truncated = False
    if layout is not None and table_refused:
        # a filter that cannot be applied is never "every row": the block says why
        report_block = {"layout": layout, "columns": list(columns), "rows": [],
                        "formats": dict(col_fmt_map), "note": table_refused, "in_block": True}
    elif layout is not None:
        fits_width = len(columns) <= int(layout.get("w", 12)) * COLS_PER_GRID
        block_rows: Optional[list] = None
        if rows:                                            # an inline result (published / federation views)
            if len(rows) <= _CANVAS_REPORT_BLOCK_ROWS and fits_width:
                block_rows = rows
            else:
                batches = iter_record_rows(rows, columns)
        elif artifact:
            if fits_width and (known_total is None or known_total <= _CANVAS_REPORT_BLOCK_ROWS):
                recs, _cols, known_total = _read_bounded_rows(artifact, _CANVAS_REPORT_BLOCK_ROWS + 1)
                columns = columns or _cols
                if len(recs) <= _CANVAS_REPORT_BLOCK_ROWS:
                    block_rows = recs
            if block_rows is None:
                batches = iter_artifact_rows(artifact, columns, limit=row_limit or None)
        else:
            block_rows = []
        if block_rows is not None:
            if has_calcs:                                   # running calculations ride the block too
                block_rows, columns = _augment_rows_with_running_calcs(block_rows, columns, report, ds_cols, notes)
            n_written = len(block_rows)
            truncated = (bool(row_limit) and n_written >= row_limit) or (
                known_total is not None and known_total > n_written)
            why = ""
        else:
            why = (f"{known_total:,} rows" if known_total is not None else "The rows") if fits_width else \
                f"{len(columns):,} columns"
            why += " -- see the sheet 'Rows'."
        if is_pivot:
            notes.append("This report's pivot layout is on its own Excel export; the canvas lists its rows.")
        if _banding_spec(report, ds_cols, columns)[0]:
            notes.append("The banded layout (group headers and subtotals) is not applied on the canvas sheet.")
        report_block = {"layout": layout, "columns": list(columns), "rows": block_rows or [],
                        "formats": dict(col_fmt_map), "note": " ".join([why] + notes).strip(),
                        "in_block": block_rows is not None}
    sheet_title = _sanitize_export_filename(report_name).replace("_", " ")[:31] or "Report"
    if sheet_title.lower() in ("rows", "export info", "_chart_data"):
        sheet_title = f"{sheet_title} (report)"[:31]
    footer_lines: list = []
    if batches is None:
        disclosure = _export_truncation_disclosure("excel", n_written, row_limit, known_total)
        footer_lines = [("disclosure", disclosure), ("footer", footer_text)]
    if _canvas_links_line(tile_tables):          # 2026-10-30 -- linked tiles: said under the canvas
        footer_lines.append(("note", _canvas_links_line(tile_tables)))
    wb = openpyxl.Workbook(write_only=True)
    write_canvas_workbook(
        wb, sheet_title=sheet_title, report_name=report_name, tiles=tile_tables, report_block=report_block,
        style={"header_bg": header_bg, "header_text": header_text, "stripe_rows": stripe_rows},
        resolve_fmt=lambda fp: _resolve_xl_format(fp, neg_fmt), safe=_xl_safe, footer_lines=footer_lines,
        look=_canvas_look(report, _require_db()), pages=_canvas_pages(report))
    if batches is not None:
        _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)

        def _disclosure_for(n: int) -> str:
            text = _export_truncation_disclosure("excel", n, row_limit, known_total)
            if _band_notes:
                text = (text + " " + " ".join(_band_notes)).strip()
            return text

        n_written = _write_excel_streaming(
            str(out_path), list(columns), batches, report_name, header_bg, header_text, neg_fmt,
            col_fmt_map, footer_text=footer_text, disclosure_for=_disclosure_for, fmt_rules=fmt_rules,
            banded_omitted=bool(_band_spec), column_styles=_extract_column_styles(report, columns),
            wb=wb, sheet_base="Rows")
        truncated = (bool(row_limit) and n_written >= row_limit) or (
            known_total is not None and known_total > n_written)
    else:
        wb.save(str(out_path))
    import zipfile
    with zipfile.ZipFile(str(out_path)) as _zf:      # a cut file has no central directory
        _zf.namelist()
    return {"rows": n_written, "total_rows": known_total, "truncated": truncated, "bytes": None}


def _has_canvas_tiles(report: dict) -> bool:
    """Does this report's canvas hold a tile beside its own table?  Every
    report IS a canvas (``canvas.effective_canvas``: a report with none
    stored is ONE report tile, derived) -- a canvas of the table alone takes
    the export road a report always took, byte for byte."""
    from core.reports.canvas import effective_canvas, has_tiles_beside_report
    return has_tiles_beside_report(effective_canvas(report.get("layout_config") or {}))


def _parse_canvas_links(raw) -> list:
    """The ``?links=`` of a canvas export (2026-10-30, linked tiles) -> entries.
    Not a string = not supplied (a route called directly gets the Query
    default object -- see ``_parse_export_filters``).  Unreadable = 400: a
    filter that cannot be read is never dropped (the file would show more
    than the screen)."""
    if not isinstance(raw, str) or not raw:
        return []
    from core.reports.canvas_links import LinkError, parse_links
    try:
        return parse_links(raw)
    except LinkError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


def _canvas_links_line(tables: list) -> str:
    """The one line an export prints when its tiles follow clicked values."""
    seen: list = []
    for t in tables or []:
        w = t.get("filtered_by") if isinstance(t, dict) else None
        if w and w not in seen:
            seen.append(w)
    if not seen:
        return ""
    return ("Filtered by " + " | ".join(seen) + " -- the values clicked on the report's tiles; "
            "a tile's note says when it is filtered.")


def _canvas_export_tables(report: dict, artifact: str, db, *, truncated: bool = False,
                          row_limit: Optional[int] = None, links: Optional[list] = None) -> list:
    """The report canvas's tiles for an export (2026-10-26): computed from the
    export's own stored result through the microcube, at the grain the cube
    route uses (``_derive_artifact_grain``).  [] when the report has no canvas
    tile beside its table, or the export has no stored result to read."""
    lc = report.get("layout_config") or {}
    canvas = lc.get("canvas") if isinstance(lc, dict) else None
    if not canvas or not any(
            isinstance(t, dict) and t.get("kind") != "report" for t in canvas.get("tiles") or []):
        return []
    # 2026-11-01 (FD-10) -- the EXPORTING person's own layout, when the report allows one
    try:
        from core.reports import viewer_layout as _vlay
        _who = (report.get("_canvas_viewer") or {}).get("username") if isinstance(report.get("_canvas_viewer"), dict) else None
        _mine = _vlay.canvas_for_viewer(db, report, _who)
        if _mine is not canvas and _mine:
            report = {**report, "layout_config": {**lc, "canvas": _mine}}
            canvas = _mine
    except Exception as _lexc:                                # noqa: BLE001
        logger.info("viewer layout not applied to the export: %s", _lexc)
    try:
        from core.reports.canvas_export import canvas_tile_tables, tile_placeholders
        ds = db.get_dataset_full(report.get("dataset_id")) if report.get("dataset_id") else None
        if not artifact:
            # a source that hands rows back in memory stores no result the
            # tiles could be read from: every tile keeps its place and says so
            return tile_placeholders(report, (ds or {}).get("columns", []) or [],
                                     "This export has no stored result to read this tile from. "
                                     "Run the report on screen to see it.")
        grain, group_cols = _derive_artifact_grain(db, report)
        from core.reports.canvas_outline import run_parameters
        from core.reports.canvas_insights import previous_run_of
        # 2026-11-02 (the KPI card): the export's report carries its PARAMETER ROWS and the run's
        # values ALWAYS -- the two-dates comparison (canvas_compare.compare_setting) reads the
        # cob_compare row and the run's A / B from them; before, the rows were never attached and
        # the values only travelled with a band tile, so a comparison printed its plain value
        if not isinstance(report.get("parameters"), list):
            try:
                report = {**report, "parameters": db.list_report_parameters(report.get("id")) or []}
            except Exception as _pexc:                          # noqa: BLE001
                logger.info("parameter rows not attached to the export: %s", _pexc)
        tables = canvas_tile_tables(artifact, report, (ds or {}).get("columns", []) or [],
                                    grain=grain, group_columns=group_cols,
                                    parameters=run_parameters(db, report, report.get("_canvas_param_values")),
                                    previous_run=lambda: previous_run_of(
                                        db, report, artifact=artifact, user_ctx=report.get("_canvas_viewer")),
                                    db=db, **({"links": links} if links else {}))
        if truncated:
            # the same words the viewer's tiles carry
            cut = (f"These numbers add up the first {int(row_limit):,} rows only -- the report's row limit cut the "
                   f"result." if row_limit else "These numbers add up only the rows the report's row limit kept.")
            for t in tables:
                t["note"] = (cut + " " + t["note"]).strip() if t.get("note") else cut
        return tables
    except Exception as exc:                                  # noqa: BLE001
        # the detail stays in the server log; the workbook says it plainly
        logger.warning("[canvas-export] tiles could not be computed for report %s: %s",
                       report.get("id"), exc, exc_info=True)
        return [{"tile_id": None, "title": "Tiles", "kind": "note", "header": [], "rows": [], "formats": [],
                 "layout": {"x": 0, "y": 0, "w": 12, "h": 2}, "labels": {}, "cut": None,
                 "note": "The canvas tiles could not be added to this export. The report's own rows are complete; "
                         "ask support to look at the server log for this export."}]


def _render_report_excel_in_memory(report: dict, rows: list, columns: list,
                                   report_name: str, header_bg: str,
                                   header_text: str, neg_fmt: str,
                                   stripe_rows: bool, col_fmt_map: dict,
                                   ds_cols: list, fmt_rules: list,
                                   disclosure: str, truncated: bool,
                                   footer_text: str) -> bytes:
    """The styled Excel document over rows already in memory (the pivot
    crosstab, banded sections, running calculations)."""
    lc = report.get("layout_config") or {}
    if lc.get("report_type") == "pivot" and lc.get("pivot_config"):
        try:
            matrix = _build_pivot_matrix(rows, lc["pivot_config"], ds_cols,
                                         result_columns=columns)
        except ValueError as exc:
            # A pivot column absent from the result: refuse (logged with the
            # column names under this rid) rather than ship a header-only file.
            raise HTTPException(status_code=500, detail=f"Excel render failed: {exc}")
        disclosure += _pivot_truncation_suffix(matrix)
        return _render_pivot_excel_bytes(matrix, report_name, header_bg, header_text,
                                         neg_fmt, stripe_rows, col_fmt_map,
                                         footer_text=footer_text,
                                         disclosure_text=disclosure, fmt_rules=fmt_rules)
    # BANDED DOCUMENT (2026-08-30) — see the PDF sibling.  Inert for reports
    # declaring no sections/column styles (byte-identical).
    _rc_notes: list = []
    _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)
    _col_styles = _extract_column_styles(report, columns)
    _exp_rows = rows
    if _band_spec:
        _exp_rows = _section_sort_rows(_exp_rows, _band_spec["defs"])
    _exp_rows, _exp_cols = _augment_rows_with_running_calcs(
        _exp_rows, columns, report, ds_cols, _rc_notes)
    disclosure += _running_calc_disclosure_suffix(_exp_cols is not columns, truncated)
    disclosure += _banded_disclosure_suffix(bool(_band_spec), truncated)
    if _band_notes:
        disclosure += " " + " ".join(_band_notes)
    if _rc_notes:
        disclosure += " " + " ".join(_rc_notes)
    return _render_excel_bytes(
        _exp_rows, _exp_cols, report_name,
        header_bg, header_text, neg_fmt, stripe_rows, col_fmt_map,
        footer_text=footer_text, disclosure_text=disclosure,
        # kwargs only when the feature is in play — see the PDF sibling.
        **({"fmt_rules": fmt_rules} if fmt_rules else {}),
        **({"sections": _band_spec} if _band_spec else {}),
        **({"column_styles": _col_styles} if _col_styles else {}))


@router.get("/api/business-reports/{report_id}/download-excel")
async def download_business_report_excel(
    report_id: int,
    user: dict = Depends(require_capability("reports.view")),
    # 2026-08-09 caps-throttle-not-refuse: le= bound removed — an explicit
    # caller limit is honoured at any size; results beyond the 1,048,576-row
    # xlsx sheet FORMAT limit continue across additional sheets.
    limit: int = Query(default=0, ge=0),
    params_json: str = Query(default="", alias="params"),
    retain_days: Optional[int] = Query(default=None),
    # 2026-08-31 — the viewer's runtime column choice, so the file matches
    # the screen.  Comma-separated column NAMES as shown in the report
    # (?columns=region,amount); narrowed to a SUBSET of the report's own
    # columns server-side, so it can never widen what the author published.
    columns: Optional[str] = Query(default=None),
    # 2026-09-17 -- the other half of the ``columns`` sentence above: the
    # viewer's runtime FILTERS, so the file matches the screen.  Without it an
    # export re-ran the saved definition and silently WIDENED the result.
    filters: Optional[str] = Query(default=None),
    # 2026-10-30 -- the canvas's LINKED tiles: the values the viewer clicked
    # ([{column_id, value, tile_id}], core.reports.canvas_links), so the
    # tiles in the file are filtered as on the screen.  Absent = as before.
    links: Optional[str] = Query(default=None),
    # 2026-11-03 -- the viewer's "View in another theme": a theme NAME only (never
    # colours), resolved by _report_in_view_theme through themes.theme_of; an
    # unknown name prints the report's own theme.  Absent = as before.
    theme: Optional[str] = Query(default=None, max_length=100),
):
    """Execute business report and return Excel (.xlsx) download with formatting.

    2026-10-04: the workbook is STREAMED from the result artifact into a
    write-only workbook (bounded memory at any size, a new sheet every
    1,048,575 rows) unless the document needs the styled object model --
    see ``_write_report_excel_file``.  The DEFAULT bound stays
    ``business_reports.excel_row_limit`` (1,000,000): MEASURED ~25k rows/s
    for a write-only workbook on the dev box (1M rows 40 s; 5M would be
    ~3.5 min here and several on a pod) and a 5M-row xlsx is ~155 MB that
    Excel opens slowly, while the streamed CSV writes 5M rows in ~30 s.  A
    cut workbook says so on the "Export Info" sheet it OPENS on and in
    X-QS-Truncated / X-QS-Continue-With (the CSV route); ``?limit=`` asks
    for more and gets it.
    """
    _enforce_export_format("excel")
    from core import config as _cfg

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    effective_limit = limit if limit > 0 else _cfg.business_reports.excel_row_limit
    param_values = _parse_export_params(params_json)
    canvas_links = _parse_canvas_links(links)
    # Validate the requested retention BEFORE paying execution cost.
    _dl_expires = _export_expires_at(retain_days)

    _cert_sink: dict = {}
    _meta_sink: dict = {}
    try:
        rows, columns, report = await _execute_report_internal(
            report_id, username, role, param_values=param_values,
            limit_override=effective_limit, user=user, cert_sink=_cert_sink,
            meta_sink=_meta_sink, override_column_ids=_parse_column_names(columns),
            extra_filters=_parse_export_filters(filters), materialize=False)
    except HTTPException:
        raise
    except Exception as exc:
        _raise_execution_failure(exc)
    report = _report_in_view_theme(report, theme, _require_db())

    applied_limit = int(_meta_sink.get("row_limit") or effective_limit or 0)
    footer_text = _footer_from_cert(_cert_sink)
    file_id, out_path = _new_export_target(".xlsx")
    try:
        info = await _run_export_work(
            _write_report_excel_file, out_path, report, rows, columns,
            _meta_sink.get("artifact_path") or "", applied_limit,
            _meta_sink.get("total_rows"), footer_text, canvas_links, username=username)
    except HTTPException:
        _discard_file(out_path)
        raise
    except Exception as exc:
        _discard_file(out_path)
        from core.error_sanitizer import sanitize_error as _se
        logger.error("Excel export failed: %s", _se(str(exc)), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Excel render failed: {_se(str(exc))}")

    report_name = report.get("name", f"Report {report_id}")
    filename = f"{_sanitize_export_filename(report_name)}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.xlsx"
    try:
        await _adb(_db_manager.audit, username, "export_report_excel", resource_type="business_report",
                   resource_id=str(report_id), detail=f"rows={info['rows']}")
    except Exception as e:
        logger.warning("Failed to audit Excel export (report_id=%s, user=%s): %s", report_id, username, e)
    from core.reports.serve_log import log_report_serve
    log_report_serve(report_id=report_id, user=username, rls="caller",
                     surface="export", fmt="excel", rows=info["rows"],
                     total_rows=info["total_rows"],
                     row_limit=applied_limit,
                     truncated=info["truncated"])
    return await _serve_export_file(
        file_id, out_path, filename,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        _export_response_headers(filename, info["rows"], applied_limit,
                                 info["total_rows"], truncated=info["truncated"],
                                 disclose_total=True,
                                 continue_with=_export_continue_with(report_id)),
        username, _dl_expires, share=_share_stamp(report, user),
        expected_size=info.get("bytes"))


def _write_report_csv_file(out_path: Path, report: dict, rows: list,
                           columns: list, artifact: str, row_limit: int,
                           total_rows: Optional[int]) -> dict:
    """Write a report's CSV export to ``out_path`` -- on a worker thread.

    STREAMED from the artifact in record batches (``core.reports.
    export_stream``): every row, constant memory, the in-memory path's exact
    bytes for the same rows.  A report with running calculations is the one
    exception -- the calc columns are computed over rows in memory, so it
    reads at most ``export_materialize_cap`` rows and the headers disclose
    any cut, as before.  Returns ``{"rows", "total_rows"}``.
    """
    from core.reports.export_stream import (artifact_columns, iter_artifact_rows,
                                            iter_record_rows, write_csv)
    if not columns and artifact:
        columns = artifact_columns(artifact)
    is_pivot = ((report.get("layout_config") or {}).get("report_type")) == "pivot"
    if report.get("running_calculations") and not is_pivot:
        # GAP-2 (2026-08-30): running-calculation columns ride the CSV too.
        if artifact and not rows:
            rows, _cols, total_rows = _read_bounded_rows(artifact, _export_materialize_cap())
            columns = columns or _cols
        _ds_cols = _extract_style_and_formats(report, _require_db())[5]
        _exp_rows, _exp_cols = _augment_rows_with_running_calcs(
            rows, columns, report, _ds_cols)
        n, nbytes = write_csv(out_path, _exp_cols, iter_record_rows(_exp_rows, _exp_cols))
        return {"rows": n, "total_rows": total_rows if total_rows is not None else n,
                "bytes": nbytes}
    if artifact and not rows:
        batches = iter_artifact_rows(artifact, columns, limit=row_limit or None)
    else:
        batches = iter_record_rows(rows, columns)
    n, nbytes = write_csv(out_path, columns, batches)
    return {"rows": n, "total_rows": total_rows if total_rows is not None else n,
            "bytes": nbytes}


@router.get("/api/business-reports/{report_id}/download-csv")
async def download_business_report_csv(
    report_id: int,
    user: dict = Depends(require_capability("reports.view")),
    # 2026-08-09 caps-throttle-not-refuse: le= bound removed — CSV is the
    # documented escape hatch for large results; capping the escape hatch's
    # explicit limit was self-defeating.
    limit: int = Query(default=0, ge=0),
    params_json: str = Query(default="", alias="params"),
    retain_days: Optional[int] = Query(default=None),
    # 2026-08-31 — the viewer's runtime column choice, so the file matches
    # the screen.  Comma-separated column NAMES as shown in the report
    # (?columns=region,amount); narrowed to a SUBSET of the report's own
    # columns server-side, so it can never widen what the author published.
    columns: Optional[str] = Query(default=None),
    # 2026-09-17 -- the other half of the ``columns`` sentence above: the
    # viewer's runtime FILTERS, so the file matches the screen.  Without it an
    # export re-ran the saved definition and silently WIDENED the result.
    filters: Optional[str] = Query(default=None),
):
    """Export business report as raw CSV (no formatting — underlying data).

    2026-10-04 (live: a 4,988,801-row report exported 1,000,000 rows in
    226 s, cut by export_materialize_cap): the CSV is STREAMED from the
    result artifact in record batches -- EVERY row by default
    (``business_reports.csv_row_limit``, 0), constant memory, written on the
    worker pool's EXPORT slot, then served from the registered file.
    X-QS-Rows / X-QS-Total-Rows say how many rows the file holds and
    X-QS-Truncated says whether that is all of them.
    """
    _enforce_export_format("csv")
    from core import config as _cfg

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    effective_limit = limit if limit > 0 else max(0, int(_cfg.business_reports.csv_row_limit))
    param_values = _parse_export_params(params_json)
    # Validate the requested retention BEFORE paying execution cost.
    _dl_expires = _export_expires_at(retain_days)

    _meta_sink: dict = {}
    try:
        rows, columns, report = await _execute_report_internal(
            report_id, username, role, param_values=param_values,
            limit_override=effective_limit, user=user, meta_sink=_meta_sink,
            override_column_ids=_parse_column_names(columns),
            extra_filters=_parse_export_filters(filters), materialize=False)
    except HTTPException:
        raise
    except Exception as exc:
        _raise_execution_failure(exc)

    applied_limit = int(_meta_sink.get("row_limit") or 0)
    file_id, out_path = _new_export_target(".csv")
    try:
        info = await _run_export_work(
            _write_report_csv_file, out_path, report, rows, columns,
            _meta_sink.get("artifact_path") or "", applied_limit,
            _meta_sink.get("total_rows"), username=username)
    except HTTPException:
        _discard_file(out_path)
        raise
    except Exception as exc:
        _discard_file(out_path)
        from core.error_sanitizer import sanitize_error as _se
        logger.error("CSV export failed: %s", _se(str(exc)), exc_info=True)
        raise HTTPException(status_code=500, detail=f"CSV export failed: {_se(str(exc))}")

    report_name = report.get("name", f"Report {report_id}")
    _truncated_flag = (bool(applied_limit) and info["rows"] >= applied_limit) or (
        info["total_rows"] is not None and info["total_rows"] > info["rows"])
    filename = f"{_sanitize_export_filename(report_name)}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
    try:
        await _adb(_db_manager.audit, username, "export_report_csv", resource_type="business_report",
                   resource_id=str(report_id), detail=f"rows={info['rows']}")
    except Exception as e:
        logger.warning("Failed to audit CSV export (report_id=%s, user=%s): %s", report_id, username, e)
    # 2026-08-05 audit (silent truncation): CSV is pure data — an in-file
    # note would corrupt every parser — so a cut is DISCLOSED where the
    # format allows: X-QS-* response headers + the [br-serve] log line.
    from core.reports.serve_log import log_report_serve
    log_report_serve(report_id=report_id, user=username, rls="caller",
                     surface="export", fmt="csv", rows=info["rows"],
                     total_rows=info["total_rows"],
                     row_limit=applied_limit,
                     truncated=_truncated_flag)
    return await _serve_export_file(
        file_id, out_path, filename, "text/csv; charset=utf-8",
        _export_response_headers(filename, info["rows"], applied_limit,
                                 info["total_rows"], truncated=_truncated_flag,
                                 disclose_total=True),
        username, _dl_expires, share=_share_stamp(report, user),
        expected_size=info.get("bytes"))


# ── Duplicate & Publish ──────────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/duplicate")
async def duplicate_report(report_id: int, user: dict = Depends(require_capability("reports.create"))):
    """Clone a report (including parameters) for the current user."""
    db = _require_db()
    source = await _adb(db.get_business_report, report_id)
    if not source:
        raise HTTPException(status_code=404, detail="Report not found")
    # 2026-08-05 audit fix: duplicate uses the SAME view chokepoint as
    # GET /{id} (which already returns the full definition to any viewer).
    # The old inline check ignored role_whitelist on published reports and
    # denied grant-holders / owner-group members who can read the definition
    # anyway.  The copy is owned by the caller and executes at THEIR RLS
    # scope — no data-scope broadening.
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if not await _adb(_br_can_view, source, user):
        raise HTTPException(
            status_code=403,
            detail="You do not have view access to this report, so it cannot "
                   "be duplicated. Ask the report owner for access first.")
    # Build new report data from source
    clone_data = {
        "name": f"{source['name']} (Copy)",
        "owner": username,
        "dataset_id": source["dataset_id"],
        "description": source.get("description", ""),
        "merged_dataset_id": source.get("merged_dataset_id"),
        "merge_config": source.get("merge_config"),
        "column_ids": source.get("column_ids", []),
        "filter_specs": source.get("filter_specs", []),
        "condition_ids": source.get("condition_ids", []),
        "order_by": source.get("order_by", []),
        "row_limit": source.get("row_limit", 50000),
        "section_definitions": source.get("section_definitions", []),
        "running_calculations": source.get("running_calculations", []),
        "slicer_column_ids": source.get("slicer_column_ids", []),
        "drill_hierarchy_id": source.get("drill_hierarchy_id"),
        "layout_config": source.get("layout_config"),
        "role_whitelist": source.get("role_whitelist"),
    }
    # SECURITY (review 2026-11-01): the copied parameters take THE gate every writer
    # takes, as the person copying (a value table / list / template they may not use
    # is refused in words), BEFORE the copy is made
    source_params = await _adb(db.list_report_parameters, report_id)
    _copies = [dict(_copyable_parameter_fields(p)) for p in source_params]
    await _check_parameter_write(db, source, _copies, _copies, user)
    new_report = await _adb(db.create_business_report, **clone_data)

    # Clone parameters
    param_id_map = {}  # old_id → new_id (for remapping depends_on)
    for p in source_params:
        new_p = await _adb(db.create_report_parameter,
                           report_id=new_report["id"],
                           **_copyable_parameter_fields(p))
        param_id_map[p["id"]] = new_p["id"]

    # Remap depends_on_param_id
    for old_p in source_params:
        if old_p.get("depends_on_param_id") and old_p["depends_on_param_id"] in param_id_map:
            new_pid = param_id_map[old_p["id"]]
            await _adb(db.update_report_parameter, new_pid,
                                        depends_on_param_id=param_id_map[old_p["depends_on_param_id"]])

    new_report["parameters"] = await _adb(db.list_report_parameters, new_report["id"])
    logger.info("Duplicated report %d → %d by user '%s'", report_id, new_report["id"], username)
    return new_report


class PublishRequest(BaseModel):
    """Optional body for POST /publish.  Omitting it (or ``action``) =
    publish (idempotent: an already-published report is republished,
    never flipped off -- 2026-10-24); ``action: unpublish`` unpublishes."""
    action: Optional[str] = None      # "publish" | "unpublish" | None = toggle
    notes: Optional[str] = None       # release notes stored on the version


@router.post("/api/business-reports/{report_id}/publish")
async def toggle_publish(report_id: int, body: Optional[PublishRequest] = None,
                         user: dict = Depends(require_capability("reports.publish"))):
    """Publish / unpublish a report.  Owner, explicit editor, or admin.

    2026-08-17 AUTHZ FIX: this was ``require_admin``, which made the whole
    lifecycle unusable by the people who actually author reports -- an analyst
    who OWNS a report got 403 clicking Publish, so nothing could ever be
    published by its author.  Publishing now follows EDIT rights
    (``_br_can_edit`` -- the same gate PUT /api/business-reports/{id} uses):
    if you may change the definition, you may publish it.  Certification stays
    admin-only, which is where the governance boundary belongs -- publish says
    "this is ready", certify says "the organisation vouches for it".

    2026-08-17 publish lifecycle: publishing is no longer a boolean flip —
    it SNAPSHOTS the draft definition (query config, source binding,
    parameters + defaults, columns, formatting, pivot config, row_limit) as
    an immutable ``BusinessReportVersion``.  Consumers execute the CURRENT
    version; the author's draft edits stay invisible until republish, which
    mints the next version (idempotent when nothing changed).  Unpublishing
    is explicit and reversible: versions are retained.

    No body / no ``action`` = PUBLISH (or republish) -- never an unpublish
    (2026-10-24, rig).  It used to be a toggle: the UI's "Republish" on a
    published report posts with no body, and it UNPUBLISHED the report for
    every viewer while the screen said "a new version is now live".
    Unpublishing is only ever explicit (``action: unpublish`` or
    ``POST .../unpublish``).  The response stays the updated report dict,
    with additive ``published_version`` / ``version_minted`` keys on publish.
    """
    db = _require_db()
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")
    if not _br_can_edit(existing, user):
        raise HTTPException(status_code=403,
                            detail="Only the owner, an editor or an admin "
                                   "may publish this report")

    from core.reports import versions as _brv
    action = (body.action or None) if body else None
    if action not in (None, "publish", "unpublish"):
        raise HTTPException(400, "action must be 'publish' or 'unpublish'")
    action = action or "publish"     # never a toggle (see the docstring)

    username = (user or {}).get("username", "")
    if action == "publish":
        updated, version, minted = await _adb(
            _brv.publish_report, db, existing, username,
            (body.notes if body else None))
        updated["published_version"] = _brv.version_meta(version)
        updated["version_minted"] = bool(minted)
        logger.info("Report %d published as v%s by %s (minted=%s)",
                    report_id, version.get("version_no"), username, minted)
        return updated
    updated = await _adb(_brv.unpublish_report, db, report_id)
    logger.info("Report %d unpublished by %s (versions retained)",
                report_id, username)
    return updated


@router.post("/api/business-reports/{report_id}/unpublish")
async def unpublish_report_endpoint(report_id: int,
                                    user: dict = Depends(require_capability("reports.publish"))):
    """EXPLICIT unpublish (2026-08-17).  Owner, editor or admin -- the same
    gate as publish; pulling your own report back must not need an admin.
    Reversible: version history is retained, and republishing an unchanged
    draft restores the same version instead of minting a duplicate."""
    db = _require_db()
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")
    if not _br_can_edit(existing, user):
        raise HTTPException(status_code=403,
                            detail="Only the owner, an editor or an admin "
                                   "may unpublish this report")
    from core.reports.versions import unpublish_report as _unpub
    updated = await _adb(_unpub, db, report_id)
    logger.info("Report %d unpublished by %s", report_id,
                (user or {}).get("username", ""))
    return updated


class LifecycleRequest(BaseModel):
    status: str                       # draft | published | archived | deprecated
    notes: Optional[str] = None       # forwarded to the version on 'published'


@router.post("/api/business-reports/{report_id}/lifecycle")
async def set_report_lifecycle(report_id: int, body: LifecycleRequest,
                               user: dict = Depends(require_capability("reports.edit"))):
    """Move a report through its lifecycle (2026-08-17).

    AUTHZ (2026-08-17): owner / explicit editor / admin, via ``_br_can_edit``
    -- the same gate as publish and as PUT.  Was admin-only, which meant an
    author could neither publish nor retire their own report; archiving your
    own draft should not require an administrator.  Certification remains
    admin-only: publish says "ready", certify says "the organisation vouches
    for it", and only the second is a governance act.

    ``published`` IS a publish (snapshot + version — never a flag flip);
    ``draft`` is an unpublish.  ``archived`` / ``deprecated`` leave
    ``is_published`` untouched so the report stays resolvable by direct id
    for audit, while the listing chokepoints hide it from consumer listings;
    archived additionally refuses consumer execution (410).
    """
    db = _require_db()
    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")
    if not _br_can_edit(existing, user):
        raise HTTPException(status_code=403,
                            detail="Only the owner, an editor or an admin "
                                   "may change this report's lifecycle")
    from core.reports import versions as _brv
    username = (user or {}).get("username", "")
    try:
        if body.status == "published":
            updated, version, minted = await _adb(
                _brv.publish_report, db, existing, username, body.notes)
            updated["published_version"] = _brv.version_meta(version)
            updated["version_minted"] = bool(minted)
        else:
            updated = await _adb(
                _brv.set_lifecycle_status, db, existing, body.status, username)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    logger.info("Report %d lifecycle -> %s by %s", report_id, body.status,
                username)
    return updated


@router.get("/api/business-reports/{report_id}/versions")
async def list_report_versions(report_id: int,
                               user: dict = Depends(require_capability("reports.view"))):
    """Published-version HISTORY metadata, newest first (2026-08-17).

    View-gated through the SAME chokepoint as GET /{id} — anyone who may
    read the report may read which versions of it were published (audit).
    Definitions are not inlined (list projection); fetch one via
    ``GET .../versions/{version_no}``.
    """
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not _br_can_view(report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    from core.reports.versions import effective_lifecycle_status
    return {
        "report_id": report_id,
        "lifecycle_status": effective_lifecycle_status(report),
        "is_published": bool(report.get("is_published")),
        "versions": await _adb(db.list_business_report_versions, report_id),
    }


@router.get("/api/business-reports/{report_id}/versions/{version_no}")
async def get_report_version(report_id: int, version_no: int,
                             user: dict = Depends(require_capability("reports.view"))):
    """One published version — metadata + the frozen definition snapshot
    (2026-08-17).  Same view gate as GET /{id}: the detail endpoint already
    exposes the full live definition to any viewer, so a frozen copy of a
    definition that WAS served to consumers is not a new disclosure."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not _br_can_view(report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    version = await _adb(db.get_business_report_version, report_id, version_no)
    if not version:
        raise HTTPException(status_code=404, detail="Version not found")
    return version


# ── Report Parameters CRUD ───────────────────────────────────────────────────

# The column fields a report VIEWER renders with -- presentation only.
_REPORT_COLUMN_META_FIELDS = (
    "id", "physical_name", "friendly_name", "data_type", "column_type",
    "aggregation", "format_pattern", "description", "is_hidden", "sort_order",
)


@router.get("/api/business-reports/{report_id}/dataset-meta")
async def get_report_dataset_meta(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """The report's dataset COLUMNS and drill HIERARCHIES, as its viewer needs
    them -- authorised by the REPORT's view rule, not the dataset's.

    2026-09-25 (click crawl, as an analyst): the viewer read them through
    ``GET /api/datasets/{id}``, which refuses anyone who is neither the
    dataset's owner nor looking at a published dataset.  A published report
    over an unpublished dataset -- the normal case -- therefore showed
    "Failed to load report" to every consumer of it.  This returns
    presentation metadata only (names, labels, types, formats) and the
    hierarchies; never the base query, source tables or connections.  A
    column the caller's role may not see (``role_whitelist``) is left out by
    THE column predicate (``datasets_api._filter_columns_by_role``).
    """
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    ds_id = report.get("dataset_id")
    if not ds_id:
        # raw_sql / published_view / federation_view reports: no dataset,
        # by definition no dataset columns -- empty, not an error
        return {"dataset_id": None, "columns": [], "hierarchies": []}
    ds = await _adb(db.get_dataset_full, ds_id)
    if not ds:
        raise HTTPException(status_code=404,
                            detail=f"The report's dataset ({ds_id}) no longer exists")
    from api.datasets_api import _filter_columns_by_role
    cols = _filter_columns_by_role(ds.get("columns") or [],
                                   (user or {}).get("role", "viewer"), user)
    return {
        "dataset_id": ds_id,
        "columns": [{k: c.get(k) for k in _REPORT_COLUMN_META_FIELDS} for c in cols],
        "hierarchies": [{"id": h.get("id"), "name": h.get("name"),
                         "levels": h.get("levels") or []}
                        for h in (ds.get("hierarchies") or [])],
    }


def _execution_belongs_to_report(db, report_id: int, exec_id: str) -> bool:
    """Does ``exec_id`` name a run OF ``report_id``?  Both execution
    records are consulted -- the async job row (async runs, and the sync
    lane's mirror row) and the federation execution (the sync lane's real
    id) -- because the two lanes record under different ids and a viewer
    holds whichever one its envelope gave it."""
    try:
        job = db.get_br_async_job(exec_id)
        if job and int(job.get("report_id") or -1) == int(report_id):
            return True
    except Exception:                                        # noqa: BLE001
        logger.debug("async job lookup failed for %s", exec_id, exc_info=True)
    try:
        fed = db.get_federation_execution(exec_id)
        if fed and fed.get("report_id") is not None and int(fed["report_id"]) == int(report_id):
            return True
    except Exception:                                        # noqa: BLE001
        logger.debug("federation execution lookup failed for %s", exec_id, exc_info=True)
    return False


@router.get("/api/business-reports/{report_id}/execution/{exec_id}/scan-disclosure")
async def get_report_scan_disclosure(report_id: int, exec_id: str,
                                     user: dict = Depends(require_capability("reports.view"))):
    """The scan/engine disclosure for ONE run of this report, as its viewer
    may read it: files read of files listed, manifests read of manifests
    listed, and the engine -- each ``null`` when not recorded, never 0.

    2026-09-27.  The same facts have been on
    ``GET /api/admin/queries/diagnose/{execution_id}`` since June, admin
    only and beside the bucket, prefix, snapshot id and config snapshot.
    This route runs the REPORT's view rule (the ``dataset-meta`` shape),
    binds the execution to the report in the path (404 otherwise -- an
    execution id is not a capability to read any run's diagnostics), and
    returns ``core.reports.scan_disclosure.DISCLOSURE_KEYS`` only.
    """
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    if not await _adb(_execution_belongs_to_report, db, report_id, exec_id):
        raise HTTPException(status_code=404,
                            detail="Execution not found for this report")
    from core.reports.scan_disclosure import scan_disclosure
    return await asyncio.to_thread(scan_disclosure, exec_id)


@router.get("/api/business-reports/{report_id}/parameters")
async def list_parameters(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """List parameters for a report."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # Access control: owner, admin, or published reports
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if not report.get("is_published") and report["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Access denied")
    return await _adb(_enrich_source_parameters,
                      await _adb(db.list_report_parameters, report_id), db, report,
                      with_sql=bool(_br_can_edit(report, user)))


async def _refuse_duplicate_param_name(db, report_id: int, name: str,
                                       *, exclude_param_id: int = None) -> None:
    """A parameter NAME is the substitution key, so it must identify ONE thing.

    2026-09-17 -- measured live: three parameters named ``p_region`` were
    accepted on one report and the missing-value refusal read "Required
    parameter(s) missing: Region, Region, Third".  One placeholder, three
    prompts, three labels.  Worse than the noise: ``{p_region}`` binds to
    whichever row is reached first, so which TYPE, which REQUIRED flag and
    which list-of-values apply is decided by ordering rather than by the
    author -- and an author who "edits" a parameter by adding it again gets a
    second one instead of a change, with no sign anything is wrong.

    Same family as the 2026-09-04 cascade defect, where one integer meant two
    different things.  A name that identifies two things identifies neither.
    """
    if not name:
        return
    existing = await _adb(db.list_report_parameters, report_id)
    clash = [p for p in (existing or [])
             if str(p.get("name") or "") == str(name)
             and p.get("id") != exclude_param_id]
    if clash:
        raise HTTPException(
            status_code=409,
            detail=(f"This report already has a parameter named "
                    f"{name!r} (id={clash[0].get('id')}, label="
                    f"{clash[0].get('label')!r}). Parameter names are the "
                    f"substitution key for {{{name}}}, so two would make the "
                    f"placeholder ambiguous. Rename this one, or edit the "
                    f"existing parameter instead of adding a second."))


@router.post("/api/business-reports/{report_id}/parameters")
async def create_parameter(report_id: int, body: ReportParameterCreate,
                           user: dict = Depends(require_capability("reports.edit"))):
    """Add a parameter to a report. Only owner or admin."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # 2026-08-25 — the SAME predicate PUT /api/business-reports/{id} uses.
    # This was the pre-Phase-157 compare, so a user with an editor grant or
    # owner-group membership could change the report but not its parameters —
    # and the builder saves both, unconditionally, in that order. The PUT
    # landed, this 403'd, and the save could never complete.
    if not _br_can_edit(report, user):
        raise HTTPException(
            status_code=403,
            detail="Only the report owner, an editor, or an admin can add "
                   "parameters")

    from core import config
    existing = await _adb(db.list_report_parameters, report_id)
    if len(existing) >= config.business_reports.max_parameters_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {config.business_reports.max_parameters_per_report} parameters per report")

    await _refuse_duplicate_param_name(db, report_id, body.name)

    data = body.model_dump(exclude_none=True)
    await _check_parameter_write(db, report, [*await _adb(db.list_report_parameters, report_id), data], [data], user)
    data["report_id"] = report_id
    made = await _adb(db.create_report_parameter, **data)
    _schedule_param_lists(report, [made], user)
    return made


def _schedule_param_lists(report: dict, params: list, user: dict) -> None:
    """2026-11-01 -- after a parameter save, every dropdown / multi-select bound
    to a column gets its OWN list in PostgreSQL (core/reports/param_lists.py),
    made and synced in the background so the save answers at once; a failure
    is the list's status, never the save's."""
    try:
        db, fed = _require_db(), _require_federation()
    except Exception:                                         # noqa: BLE001
        return
    from core.reports import param_lists as _pl

    async def _run():
        try:
            await _pl.after_save(fed, db, report, list(params or []), user or {})
        except Exception as exc:                              # noqa: BLE001
            logger.info("[param-lists] after-save pass skipped: %s", exc)
    try:
        asyncio.get_running_loop().create_task(_run())
    except RuntimeError:
        pass


@router.post("/api/business-reports/parameters/{param_id}/choices/refresh")
async def refresh_parameter_choices(param_id: int, user: dict = Depends(require_capability("reports.edit"))):
    """Refresh a parameter's own list NOW (2026-11-01): makes it when missing,
    syncs it in the request, answers the list's status in words."""
    db = _require_db()
    fed = _require_federation()
    await _adb(_check_param_ownership, db, param_id, user)
    from core.db.models import ReportParameter as _RP3
    from core.reports import param_lists as _pl
    from core import value_lists as _vlm2

    def _row():
        with db.get_session(read_only=True) as _s:
            r = _s.query(_RP3).filter(_RP3.id == param_id).first()
            return r.to_dict() if r else None
    param = await _adb(_row)
    if not param:
        raise HTTPException(status_code=404, detail="Parameter not found")
    report = await _adb(db.get_business_report, int(param["report_id"]))
    params = await _adb(db.list_report_parameters, int(param["report_id"]))
    ens = await _pl.ensure(fed, db, report, params, param, user, sync_now=False)
    if not ens.get("list"):
        raise HTTPException(status_code=422, detail=ens.get("reason") or "This parameter has no list of its own.")
    # (rig 2026-11-01) a build the save kicked off may still be running: said, never a 500
    return await asyncio.to_thread(_pl.refresh_now, db, ens["list"], by=user.get("username", ""))


async def _check_parameter_write(db, report: dict, all_params: list, changed: list, user: dict) -> None:
    """THE ONE GATE of every route that WRITES ``report_parameters`` (create,
    the single PUT, the batch; SECURITY review 2026-11-01 -- the single PUT
    used to skip it, so a template, an ``applies`` or a list could be attached
    past every check).  ``all_params`` = the report's parameters as they will
    be after the write (the contract reads the whole set: 'show when' names,
    cascades, templates); ``changed`` = the rows this write adds or changes
    (their value tables / lists / source conditions are checked AS THE CALLER;
    the untouched rows of a co-editor are not re-checked against this caller).
    The guard test enumerates every writer and fails when one skips this."""
    await _refuse_parameter_contract(db, report, all_params, user, changed=changed)
    await _refuse_unreadable_value_tables(db, changed, user)
    await _refuse_unbound_source_columns(db, report, changed)


async def _refuse_parameter_contract(db, report: dict, params: list, user: Optional[dict] = None, *,
                                     changed: Optional[list] = None, templates: Optional[dict] = None) -> None:
    """2026-11-01 -- every rule of the general parameter model the system cannot
    honour is refused on save in plain words (core/reports/param_contract.py):
    kinds, targets (result columns of the dataset, source conditions of its
    query, tokens of a raw-SQL report, actions of the canvas), default rules,
    'show when', validation, templates.  One 422 lists them all.

    SECURITY (review 2026-11-01): the rules run on the rows AS SERVED -- a
    template's definition MERGED under the row (``apply_template``), never the
    bare row (a bare row with only a ``template_id`` passed every check while
    the template brought the targets).  ``changed`` = the rows whose merged
    value tables / lists / source conditions are checked as the caller (None =
    all of them); ``templates`` = the library rows to use instead of the stored
    ones (a template UPDATE checks its new definition against every attached
    report before it is written)."""
    from core.reports.param_contract import apply_template, parameter_problems
    columns = None
    source_keys = None
    try:
        ds_id = await _adb(_resolve_lov_dataset_id, report, db)
        if ds_id:
            ds = await _adb(db.get_dataset_full, int(ds_id)) or {}
            columns = {int(c["id"]): c for c in (ds.get("columns") or []) if c.get("id") is not None}
            try:
                source_keys = set((await _adb(_dataset_source_filters, db, report)).by_key().keys())
            except Exception:                                 # noqa: BLE001
                source_keys = None
    except Exception:                                         # noqa: BLE001
        columns = None
    tokens = None
    try:
        import re as _re
        _sql = str(((report.get("query_config") or {}).get("raw_sql")) or report.get("raw_sql") or "")
        if _sql:
            tokens = set(_re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", _sql))
    except Exception:                                         # noqa: BLE001
        tokens = None
    canvas = (report.get("layout_config") or {}).get("canvas") if isinstance(report.get("layout_config"), dict) else None
    action_ids = {str(a.get("id")) for a in ((canvas or {}).get("actions") or []) if isinstance(a, dict)} if isinstance(canvas, dict) else None
    tids = [int(p["template_id"]) for p in params if isinstance(p, dict) and p.get("template_id")]
    if templates is None:
        templates = await _adb(db.templates_by_id, tids) if tids else {}
    else:
        stored = await _adb(db.templates_by_id, [t for t in tids if t not in templates]) if tids else {}
        templates = {**stored, **templates}
    merged = [apply_template(p, templates.get(int(p["template_id"])))
              if isinstance(p, dict) and p.get("template_id") and int(p["template_id"]) in templates else p
              for p in params]
    problems = parameter_problems(merged, columns=columns, source_keys=source_keys, action_ids=action_ids,
                                  tokens=tokens, templates=templates)
    if problems:
        raise HTTPException(status_code=422, detail={"error": "parameter_problems", "problems": problems,
                                                     "message": "The parameters cannot be saved: " + " ".join(problems)})
    # SECURITY (review 2026-11-01): a template's definition is checked again on the MERGED
    # parameter as the person attaching it (a value table / list they may not see is refused),
    # and the merged row takes the same table / source-condition checks a plain row takes
    if templates:
        from core.reports.param_contract import definition_checks
        touched = params if changed is None else list(changed)
        for p, m in zip(params, merged):
            if not (isinstance(p, dict) and p.get("template_id") in templates):
                continue
            await definition_checks(db, m, user or {}, name=str(p.get("name") or ""))
            if any(p is c for c in touched):
                copy = dict(m)
                await _refuse_unreadable_value_tables(db, [copy], user or {})
                await _refuse_unbound_source_columns(db, report, [copy])


def _check_param_ownership(db, param_id: int, user: dict):
    """Verify the caller owns the report that owns this parameter (or is admin)."""
    # Fetch all params for the report containing this param_id
    # We need to find the param's report_id first via the DB
    from core.db.models import ReportParameter
    with db.get_session() as session:
        p = session.query(ReportParameter).filter(ReportParameter.id == param_id).first()
        if not p:
            raise HTTPException(status_code=404, detail="Parameter not found")
        report = db.get_business_report(p.report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # 2026-08-25 — same predicate as PUT on the report itself; see the note on
    # add_parameter above. Editors can already change columns, filters and the
    # SQL, so blocking them from the parameters of the same report was
    # incoherent rather than protective.
    if not _br_can_edit(report, user):
        raise HTTPException(
            status_code=403,
            detail="Only the report owner, an editor, or an admin can modify "
                   "parameters")


@router.put("/api/business-reports/parameters/{param_id}")
async def update_parameter(param_id: int, body: ReportParameterUpdate,
                           user: dict = Depends(require_capability("reports.edit"))):
    """Update a report parameter."""
    db = _require_db()
    await _adb(_check_param_ownership, db, param_id, user)
    # 2026-09-03 — was exclude_none, which made every optional field
    # UNSETTABLE-BACK-TO-NULL: an author who removed a parameter's cascade
    # parent, its filter column, its static list or its default sent the
    # null, the null was dropped as "not supplied", and the API answered
    # 200 with the old value still in place.  exclude_unset keeps the
    # partial-update semantics (absent field = leave alone) while letting
    # an explicit null mean what it says.
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    # SECURITY (review 2026-11-01): the SAME gate the create and batch routes run,
    # on the report's parameters as they will be -- the stored row merged with this
    # update, beside the others -- as the caller.  This route used to run two partial
    # checks and skip the contract, so a template / applies / list could be attached here.
    from core.db.models import ReportParameter as _RP

    def _stored():
        with db.get_session(read_only=True) as _s:
            _row = _s.query(_RP).filter(_RP.id == param_id).first()
            return _row.to_dict() if _row else None
    _cur = await _adb(_stored)
    if not _cur:
        raise HTTPException(status_code=404, detail="Parameter not found")
    _rep_of = await _adb(db.get_business_report, int(_cur["report_id"]))
    if not _rep_of:
        raise HTTPException(status_code=404, detail="Report not found")
    _merged_row = {**_cur, **updates}
    _others = [p for p in await _adb(db.list_report_parameters, int(_cur["report_id"])) if p.get("id") != param_id]
    await _check_parameter_write(db, _rep_of, [*_others, _merged_row], [_merged_row], user)
    if "source_column" in updates and _merged_row.get("source_column"):
        updates["source_column"] = _merged_row["source_column"]      # the check's spelling (lower-cased key)
    # 2026-09-17 -- a RENAME collides exactly as a create does, and guarding
    # only the create would leave the same ambiguity one PUT away.
    if updates.get("name"):
        from core.db.models import ReportParameter
        with db.get_session() as _s:
            _p = _s.query(ReportParameter).filter(
                ReportParameter.id == param_id).first()
            _rid = _p.report_id if _p else None
        if _rid is not None:
            await _refuse_duplicate_param_name(
                db, _rid, updates["name"], exclude_param_id=param_id)
    result = await _adb(db.update_report_parameter, param_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Parameter not found")
    _rep_for_list = await _adb(db.get_business_report, int(result.get("report_id") or 0)) if result.get("report_id") else None
    if _rep_for_list:
        _schedule_param_lists(_rep_for_list, [result], user)
    return result


@router.delete("/api/business-reports/parameters/{param_id}")
async def delete_parameter(param_id: int, user: dict = Depends(require_capability("reports.edit"))):
    """Delete a report parameter."""
    db = _require_db()
    await _adb(_check_param_ownership, db, param_id, user)
    if not await _adb(db.delete_report_parameter, param_id):
        raise HTTPException(status_code=404, detail="Parameter not found")
    return {"detail": "deleted"}


def _dataset_source_filters(db, report: dict):
    """The source filters the report's DATASET offers (2026-10-29): the
    predicates of its SQL, discovered by ``core.source_filters`` in the
    dialect the engine resolves for it.  Raises ValueError for a report
    with no dataset."""
    from core import source_filters as _sf
    ds_id = int(report.get("dataset_id") or 0)
    if ds_id <= 0:
        raise ValueError("Only a report on a dataset can filter at the source; this report "
                         "has no dataset.")
    ds = db.get_dataset_full(ds_id)
    if not ds:
        raise ValueError(f"Dataset {ds_id} was not found.")
    fed = _require_federation()
    return _sf.discover_cached(ds.get("base_query") or "", fed.dataset_sql_dialect(ds))


async def _refuse_unbound_source_columns(db, report: dict, items: List[dict]) -> None:
    """2026-10-29 -- a parameter that filters AT THE SOURCE names a predicate
    of the dataset's SQL; the key must be one the SQL has today, else the
    save is refused naming the keys that exist.  A parameter saved against a
    condition the query does not have would refuse every run."""
    keyed = [it for it in items if it.get("source_column")]
    if not keyed:
        return
    try:
        disc = await _adb(_dataset_source_filters, db, report)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    if disc.reason:
        raise HTTPException(status_code=422, detail=f"This dataset's query offers no condition to filter "
                                                    f"at the source: {disc.reason}")
    offered = {p.key for p in disc.predicates if p.parameter_type}
    problems = []
    for it in keyed:
        key = str(it["source_column"]).strip().lower()
        if key not in offered:
            problems.append(f"{it.get('name') or 'a parameter'}: '{key}' is not a condition of the "
                            f"dataset's query")
        else:
            it["source_column"] = key
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems) + ". Conditions the query "
                            f"offers: {', '.join(sorted(offered)) or '(none)'}.")


def _enrich_source_parameters(params: list, db, report: dict, *, with_sql: bool = False) -> list:
    """Each parameter that filters at the source learns what the query says
    without a value (``source_default``, ``source_words``), or that its
    condition is gone (``source_missing``) -- the plain words the viewer's
    prompt needs.  ``with_sql`` (an EDITOR of the report, never a token
    projection) adds ``source_sql``, the condition as the query spells it;
    a share / embed caller is told the default in words and nothing of the
    SQL or the tables behind it (security review of 3a799c243).  Fail-open: a
    dataset that cannot be read leaves the rows as stored."""
    if with_sql:
        # 2026-11-01 -- the EDITOR sees each parameter's own list (its query,
        # status, count, why it is read live): core/reports/param_lists.py
        from core.reports import param_lists as _pl
        from core import value_lists as _vlm1
        for p in params or []:
            if not isinstance(p, dict) or not _pl.eligible(p):
                continue
            try:
                vl = _pl.find(db, int(report.get("id") or 0), str(p.get("name") or ""))
                p["choices_list"] = _pl.describe(vl, None, live_reason=_vlm1.needs_live(db, vl) if vl else None)
            except Exception as exc:                           # noqa: BLE001
                p["choices_list"] = _pl.describe(None, f"The list could not be read: {exc}")
    keyed = [p for p in (params or []) if isinstance(p, dict) and p.get("source_column")]
    if not keyed:
        return params
    try:
        by_key = _dataset_source_filters(db, report).by_key()
    except Exception as exc:                                   # noqa: BLE001
        logger.info("Report %s: source filters not read for its parameters: %s", report.get("id"), exc)
        return params
    for p in keyed:
        pred = by_key.get(str(p["source_column"]).strip().lower())
        if pred is None:
            p["source_missing"] = ("This condition is no longer in the dataset's query, so the report "
                                   "cannot run until the parameter is changed or removed.")
            continue
        p["source_default"] = list(pred.values)
        p["source_words"] = f"Without a value the report uses what the query says: {pred.default_words}"
        if with_sql:
            p["source_sql"] = pred.sql
    return params


async def _refuse_unreadable_value_tables(db, items: List[dict], user: dict) -> None:
    """2026-10-24 -- a parameter whose choices come from ANOTHER table
    (``values_source = table``) names a connection, a table and a column, and
    the author must be able to SEE that connection (the connections' own
    visibility rule): otherwise a report would be a way to read a source the
    author cannot.  A viewer later reads it under the REPORT's view rule and
    their own row security, like every other parameter.  One 422 naming
    every problem; 404 for a connection that is not there or not visible."""
    from api.connections_api import _connection_visible_to
    problems: List[str] = []
    for it in items:
        if str(it.get("values_source") or "").lower() == "list":
            # 2026-10-24 -- a named value list must exist (core/value_lists.py)
            if not it.get("value_list_id"):
                problems.append(f"{it.get('name') or 'a parameter'}: its choices come from a value "
                                f"list, so it needs the list")
            else:
                _vl = await _adb(db.get_value_list, int(it["value_list_id"]))
                if _vl is None:
                    raise HTTPException(status_code=404, detail=f"{it.get('name') or 'a parameter'}: value "
                                                                f"list {it['value_list_id']} not found")
                # SECURITY (review): the author may only offer a QUERY list
                # whose connection they may see -- like a value table
                if _vl["source_type"] == "query":
                    _c = await _adb(db.get_connection, int(_vl["connection_id"])) if _vl.get("connection_id") else None
                    if not _c or not await _connection_visible_to(_c, user):
                        raise HTTPException(status_code=404, detail=f"{it.get('name') or 'a parameter'}: value "
                                                                    f"list {it['value_list_id']} not found")
            continue
        if str(it.get("values_source") or "").lower() != "table":
            continue
        name = it.get("name") or "a parameter"
        missing = [f for f in ("lov_source_connection_id", "lov_source_table", "lov_source_column")
                   if not it.get(f)]
        if missing:
            problems.append(f"{name}: its choices come from another table, so it needs "
                            f"{', '.join(m.replace('lov_source_', '') for m in missing)}")
            continue
        import re as _re_vt
        _plain = _re_vt.compile(r'^("?[A-Za-z_][A-Za-z0-9_$]*"?)(\.("?[A-Za-z_][A-Za-z0-9_$]*"?)){0,2}$')
        _plain_col = r'^"?[A-Za-z_][A-Za-z0-9_$]*"?$'
        if (not _plain.match(str(it["lov_source_table"]))
                or not _re_vt.match(_plain_col, str(it["lov_source_column"]))):
            problems.append(f"{name}: the value table and column must be plain names "
                            f"(schema.table and a column), not an expression or a path")
            continue
        conn = await _adb(db.get_connection, int(it["lov_source_connection_id"]))
        if not conn or not await _connection_visible_to(conn, user):
            raise HTTPException(status_code=404,
                                detail=f"{name}: connection {it['lov_source_connection_id']} not found")
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems))


class BatchParameterItem(ReportParameterCreate):
    """The batch-save shape — ``ReportParameterCreate`` plus a positional
    parent reference.

    2026-08-31 noted this was "the THIRD model describing a parameter, and
    the one the builder actually saves through", where a field added to the
    other two and not to this one is silently dropped on every save from the
    UI.  2026-09-01: it now INHERITS rather than repeating the list, so the
    divergence it warned about cannot happen.

    Kept as a distinct name because the batch endpoint's request model
    references it and the two may legitimately diverge later — at which
    point the difference will be visible as an override instead of hiding
    in two identical lists.  ``depends_on_index`` is the first such
    divergence, and it is deliberate.
    """

    #: WHICH parameter in THIS request is the cascade parent, by position.
    #:
    #: 2026-09-03.  A batch save REPLACES every parameter, so at the moment
    #: the client builds the request none of the rows have ids yet — the
    #: ones being replaced are about to be deleted and the new ones are not
    #: created.  ``depends_on_param_id`` therefore cannot be expressed here,
    #: and the report builder worked around that with a second pass: batch
    #: -create, then PUT each child with its parent's freshly-minted id,
    #: looked up through a map keyed by BOTH old ids and array indices.
    #:
    #: Those are two different namespaces in one dict, and they collide
    #: constantly — a report whose parameters have ids 1..N (i.e. any report
    #: whose parameters were created together, which is all of them) has
    #: every index key overwritten by an id key of the same integer, so the
    #: third parameter resolved its parent to ITSELF.  A parameter that
    #: depends on itself filters its own dropdown by its own unset value,
    #: which is why cascading prompts did not work.
    #:
    #: A position is unambiguous, needs no map, and is resolved where the
    #: ids actually exist: inside the one transaction that creates them.
    #: The second pass is gone with it, so a batch save is atomic again —
    #: it used to be able to land the parameters and then fail to link
    #: them, leaving a half-built cascade behind.
    depends_on_index: Optional[int] = None


class BatchParameterRequest(BaseModel):
    parameters: List[BatchParameterItem]


def validate_positional_dependencies(indices: List[Optional[int]]) -> None:
    """Refuse a cascade graph that cannot be evaluated.  Pure; raises
    ``ValueError`` with a message meant for the author.

    Three ways a positional reference is unusable, and the LOV route
    behaves badly on each rather than reporting anything:

    * out of range — the parent does not exist, and the child's dropdown
      would silently fall back to unfiltered values;
    * self-reference — ``parent_param`` resolves to the parameter itself,
      so its dropdown filters on its own unset value and comes back empty;
    * a cycle — the viewer's cascade loop re-fires forever as each member
      invalidates the next.

    None of the three is expressible through the UI once the identity bug
    is fixed, so this guards the API against a client that gets it wrong
    rather than the UI against itself.  Validating positions (not ids)
    means it runs BEFORE anything is written.
    """
    n = len(indices)
    for i, parent in enumerate(indices):
        if parent is None:
            continue
        if not isinstance(parent, int) or parent < 0 or parent >= n:
            raise ValueError(
                f"Parameter {i + 1} depends on parameter position {parent}, "
                f"which is not in this request (it has {n}).")
        if parent == i:
            raise ValueError(
                f"Parameter {i + 1} cannot depend on itself.")

    # Walk each chain to its end; a repeat means a cycle.
    for start in range(n):
        seen = {start}
        cur = indices[start]
        while cur is not None:
            if cur in seen:
                raise ValueError(
                    "Parameters form a dependency cycle "
                    f"(parameter {start + 1} eventually depends on itself).")
            seen.add(cur)
            cur = indices[cur]


@router.put("/api/business-reports/{report_id}/parameters/batch")
async def batch_save_parameters(report_id: int, body: BatchParameterRequest,
                                user: dict = Depends(require_capability("reports.edit"))):
    """Atomic batch replacement of all parameters for a report (single transaction)."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # 2026-08-25 — same predicate as PUT on the report itself; see the note on
    # add_parameter above. Editors can already change columns, filters and the
    # SQL, so blocking them from the parameters of the same report was
    # incoherent rather than protective.
    if not _br_can_edit(report, user):
        raise HTTPException(
            status_code=403,
            detail="Only the report owner, an editor, or an admin can modify "
                   "parameters")

    from core import config
    max_params = config.business_reports.max_parameters_per_report
    if len(body.parameters) > max_params:
        raise HTTPException(status_code=400, detail=f"Maximum {max_params} parameters allowed")

    # 2026-09-03 — refuse an unevaluable cascade BEFORE writing anything.
    # Positions, not ids, so the refusal lands before the transaction
    # opens and a rejected save leaves the report exactly as it was.
    try:
        validate_positional_dependencies(
            [item.depends_on_index for item in body.parameters])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # 2026-09-01 — was a hand-written field list, the FOURTH copy of the
    # parameter shape and the last one a new field had to be remembered in.
    # model_dump() produces exactly the model's fields, so the mapping can no
    # longer fall behind the model it is mapping.
    params_list = [item.model_dump() for item in body.parameters]
    await _check_parameter_write(db, report, params_list, params_list, user)
    # 2026-09-17 -- this REPLACES every parameter, so the collision to catch
    # is inside the payload rather than against what is stored.  Checked
    # before the transaction opens, like the cascade check above, so a
    # rejected save leaves the report exactly as it was.
    _names = [str(p.get("name") or "") for p in params_list if p.get("name")]
    _dupes = sorted({n for n in _names if _names.count(n) > 1})
    if _dupes:
        raise HTTPException(
            status_code=409,
            detail=(f"Duplicate parameter name(s) {_dupes} in this batch. A "
                    f"name is the substitution key for its placeholder, so "
                    f"two of the same name would make it ambiguous -- the "
                    f"viewer is prompted twice and the binding is decided by "
                    f"ordering. Give each parameter a distinct name."))
    created = await _adb(db.replace_report_parameters, report_id, params_list)
    _schedule_param_lists(report, created, user)
    return {"parameters": created, "count": len(created)}


#: Parameter columns a duplicate must NOT copy, with the reason.  Declared so
#: the completeness test can tell "excluded on purpose" from "forgotten".
_PARAM_COPY_EXCLUDED = {
    "id": "the copy gets its own",
    "report_id": "set to the new report",
    "created_at": "the copy is new",
    "depends_on_param_id": "remapped after all copies exist, since ids change",
}


def _copyable_parameter_fields(p: dict) -> dict:
    """Every field a duplicated parameter must carry, DERIVED FROM THE MODEL.

    2026-08-31.  Both duplicate paths listed these fields by hand and both
    had fallen behind: ``description`` (the author's tooltip text) was
    silently dropped on every duplicate, and ``static_values`` would have
    been the next.  That made FIVE hand-written enumerations of a
    parameter's fields — two request models, the batch handler, the DB
    insert, and these two copies — which had already drifted apart.

    Reading the columns off ``ReportParameter`` means a field added to the
    model is copied by default.  Anything that must NOT be copied is named
    in ``_PARAM_COPY_EXCLUDED`` with its reason, so the omission is a
    decision on the record rather than an oversight.
    """
    from core.db.models import ReportParameter
    return {c.name: p.get(c.name)
            for c in ReportParameter.__table__.columns
            if c.name not in _PARAM_COPY_EXCLUDED}


def _resolve_lov_dataset_id(report: dict, db) -> int:
    """Resolve effective dataset_id for LOV queries.

    For published_view / federation_view reports where dataset_id may be 0,
    look up the actual dataset_id from the underlying view config.
    """
    ds_id = report.get("dataset_id", 0) or 0
    if ds_id > 0:
        return ds_id
    # Try published_view source — dataset_id lives inside query_config JSON
    pv_id = report.get("published_view_id")
    if pv_id:
        pv = db.get_published_view(pv_id)
        if pv:
            qc = pv.get("query_config") or {}
            pv_ds = qc.get("dataset_id")
            if pv_ds:
                return int(pv_ds)
    # Try federation_view source — dataset_id lives inside primary_query JSON
    fv_id = report.get("federation_view_id")
    if fv_id:
        fv = db.get_federation_view(fv_id)
        if fv:
            pq = fv.get("primary_query") or {}
            fv_ds = pq.get("dataset_id")
            if fv_ds:
                return int(fv_ds)
    return ds_id


# ── Parameter LOV (Cascading Prompts) ────────────────────────────────────────


def _lov_short_circuit(param: dict, report_id: Any,
                       override: Optional[str] = None) -> Optional[dict]:
    """The answer when the values do not come from the data, or None.

    2026-08-31.  Two cases, and BOTH LOV routes (the app's and the
    shared/embedded twin) must agree on them — a dropdown that works in the
    app and is empty on a shared link is the divergence this codebase keeps
    producing, so the decision lives here once.

    * A static list: the author curated the choices.  Answer without
      touching the data, which also means the dropdown keeps working while
      the source is unreachable.
    * Neither a filter column nor a static list: there is nothing to offer.
      Say WHY — a bare [] reads as "this column has no values" when it
      means "nothing was configured to supply any", and the viewer renders
      an empty dropdown either way.
    """
    # 2026-10-23 -- WHICH source is ONE decision (core/reports/param_values.
    # plan): a saved list when the parameter says so or (auto) has one.
    from core.reports.param_values import plan as _values_plan
    _plan = _values_plan(param, override=override)
    if _plan.read == "nothing":
        logger.info("Report %s parameter %r: %s", report_id, param.get("name"), _plan.reason)
        return {"values": [], "reason": _plan.reason}
    static = param.get("static_values") if _plan.read == "static" else None
    if static:
        seen, ordered = set(), []
        for v in static:
            if v is None:
                continue
            sv = str(v)
            # Keep the author's ORDER: a curated list is a sequence, and
            # sorting it would discard a deliberate choice.
            if sv != "" and sv not in seen:
                seen.add(sv)
                ordered.append(sv)
        return {"values": ordered, "source": "static"}

    return None

@router.post("/api/business-reports/{report_id}/parameter-values")
async def get_parameter_values(report_id: int, body: ParameterValuesRequest,
                               user: dict = Depends(require_capability("reports.view"))):
    """Get distinct values for a parameter's LOV column.

    Supports cascading: if the parameter depends on a parent, the parent's
    selected value is used as a filter on the LOV query.
    """
    db = _require_db()
    fed = _require_federation()

    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # 2026-08-05 audit fix: LOV values are DATA (distinct column values), so
    # this uses the SAME view chokepoint as /execute — the old inline check
    # denied Phase-157 grant holders / owner-group members (who can run the
    # report but got 403 on its parameter dropdowns) and ignored
    # role_whitelist on published reports.  Row-security still applies to
    # the values themselves via user_ctx below.
    if not await _adb(_br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")

    # F-P3A-03 self-audit completion (2026-08-23): with the detail GET now
    # serving consumers the PUBLISHED parameter rows (F-P3A-08), this route
    # must resolve the SAME set — the draft-table lookup 404'd on any
    # published id the author had since deleted/recreated.  Editors still
    # resolve the draft (same fork as GET and /execute).
    report, _lov_version = await _adb(
        _resolve_execution_report, db, report, user)
    params = await _adb(_report_parameters_for_execution,
                        report, db, report_id)
    param = next((p for p in params if p["id"] == body.parameter_id), None)
    if not param:
        raise HTTPException(status_code=404, detail="Parameter not found")

    _short = _lov_short_circuit(param, report_id, override=body.source)
    if _short is not None:
        return _short

    try:
        return await _param_lov_from_column(
            report, params, param, body, fed, db,
            user_ctx=user, reader=user)  # Phase 131 deep-dive #13: RLS on LOV
    except Exception as exc:
        logger.warning("LOV fetch failed for param %d: %s", param["id"], exc)
        return {"values": [], "error": str(exc)}


def _hierarchy_level_filters(param: dict, parent_values: dict) -> Optional[Tuple[int, List[dict]]]:
    """2026-11-01 -- a HIERARCHY parameter asks one level at a time: the level's
    column and the levels above it as filters (``parent_values.__hierarchy__ =
    {column_id, path: {column_id: value}}``).  None = not a hierarchy ask."""
    h = (parent_values or {}).get("__hierarchy__")
    if not isinstance(h, dict) or not h.get("column_id"):
        return None
    from core.reports.param_contract import result_columns
    levels = result_columns(param)
    try:
        cid = int(h["column_id"])
    except (TypeError, ValueError):
        return None
    if cid not in levels:
        return None
    filters = []
    path = h.get("path") if isinstance(h.get("path"), dict) else {}
    for k, v in path.items():
        try:
            k_id = int(k)
        except (TypeError, ValueError):
            continue                               # (review 2026-11-01) a key that is not a column id is skipped, never a 500
        if v not in (None, "") and k_id in levels:
            filters.append({"column_id": k_id, "operator": "eq", "value": v})
    return cid, filters


def _cascade_parent_filters(param: dict, params: list,
                            parent_values: dict) -> List[dict]:
    """The parent selection as a filter on this parameter's value list.

    ONE answer for both LOV routes (the app's and the token twin).
    2026-10-03 -- a parent with NO selection (None, "", [] -- a cleared
    dropdown sends "") filters nothing: the child offers every value.  It
    used to become ``{"operator": "eq", "value": ""}``, a filter on the
    empty string, i.e. an empty child list that looked like "no data".
    """
    if not (param.get("depends_on_param_id")
            and param.get("cascade_filter_column_id")):
        return []
    parent = next((p for p in params
                   if p["id"] == param["depends_on_param_id"]), None)
    if not parent:
        return []
    val = (parent_values or {}).get(parent["name"])
    if isinstance(val, (list, tuple)):
        val = [v for v in val if v is not None and v != ""]
        if not val:
            return []
        return [{"column_id": param["cascade_filter_column_id"],
                 "operator": "in", "value": list(val)}]
    if val is None or val == "":
        return []
    return [{"column_id": param["cascade_filter_column_id"],
             "operator": "eq", "value": val}]


async def _source_param_values(report: dict, param: dict, body: "ParameterValuesRequest",
                               fed, db, dataset_id: int, src: str, cap: int, *,
                               user_ctx, reader: Optional[dict] = None) -> dict:
    """The choices of a parameter that filters AT THE SOURCE (2026-10-29):
    the predicate's own table column.  ``auto`` / ``metadata`` = the table's
    PARTITION values from metadata when the column partitions THAT table and
    the metadata may be shown (core/reports/param_values.py, the same
    row-security gate); else -- or ``data`` -- the column's distinct values
    read off the SOURCE TABLE through THE value cache, under row security,
    for a reader who may see the connection.  Never an empty list in place
    of a reason."""
    from core import source_filters as _sf
    from core.reports import param_values as _pv
    from core.reports import param_choices as _pc
    from core import column_value_cache as _cvc
    ds = await asyncio.to_thread(db.get_dataset_full, int(dataset_id))
    if not ds:
        return {"values": [], "reason": f"Dataset {dataset_id} was not found."}
    disc = _sf.discover_cached(ds.get("base_query") or "", await asyncio.to_thread(fed.dataset_sql_dialect, ds))
    pred = disc.by_key().get(str(param["source_column"]).strip().lower())
    if pred is None:
        return {"values": [], "reason": ("This condition is no longer in the dataset's query, so there "
                                         "is nothing to choose from.")}
    temporal = param.get("parameter_type") in ("date", "date_range") or pred.is_date

    def _querys_own(why: Optional[str]) -> dict:
        # the condition's own literals: what the query runs with; no table
        # name, no metadata -- the answer for a caller who may not see the
        # source (security review of 3a799c243)
        out = {"values": sanitize_for_json(list(pred.values)), "truncated": False, "limit": cap,
               "source": "query"}
        if why:
            out["source_note"] = why
        return out

    if reader is None:
        # a share / embed token: anonymous -- never the source table's
        # metadata, its values or its name
        return _querys_own("The choices are the values the query names; a shared link cannot "
                           "read the table behind it.")
    connections = await asyncio.to_thread(fed._resolve_connections, ds)
    if not connections:
        return _querys_own("The dataset's connection could not be read.")
    cid, conn = next(iter(connections.items()))
    if not await _pc._may_see_connection(conn, reader):
        return _querys_own("You cannot read this report's connection directly, so the choices "
                           "are the values the query names; type another.")
    note = None
    if src in ("auto", "metadata"):
        allowed, why = _pv.metadata_allowed(db, user_ctx)
        if allowed:
            lk = await _pv.partition_values(db, dataset_id=int(dataset_id), user=user_ctx or {},
                                            temporal=temporal, column_name=pred.column,
                                            table_name=pred.table)
            if lk.is_partition:
                vals = list(lk.values or [])
                if body.search:
                    q = body.search.strip().lower()
                    vals = [v for v in vals if q in str(v).lower()]
                return {"values": sanitize_for_json(vals[:cap]), "truncated": lk.truncated or len(vals) > cap,
                        "limit": cap, "source": "metadata", "table": lk.table}
            if src == "metadata":
                return {"values": [], "source": "metadata",
                        "reason": lk.reason or "No partition values could be read."}
            note = None if lk.is_partition is False else lk.reason
        else:
            note = why
    try:
        values, cached = await _pc._cached_table_read(
            fed, connections, ds.get("source_tables") or [], cid, pred.table_ref or pred.table, pred.column,
            (body.search or "").strip() or None, cap + 1, user_ctx, temporal, _cvc.scope_for(user_ctx or {}))
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Report %s: source parameter %r values of %s.%s could not be read: %s",
                       report.get("id"), param.get("name"), pred.table_ref, pred.column, exc)
        return {"values": [], "source": "data",
                "reason": f"The values of {pred.table_ref}.{pred.column} could not be read: "
                          f"{str(exc).splitlines()[0][:200]}"}
    values = list(values or [])
    out = {"values": sanitize_for_json(values[:cap]), "truncated": len(values) > cap, "limit": cap,
           "source": "table", "table": f"{pred.table_ref}.{pred.column}", "cached": bool(cached)}
    if note:
        out["source_note"] = note
    return out


async def _param_lov_from_column(report: dict, params: list, param: dict,
                                 body: "ParameterValuesRequest", fed, db, *,
                                 user_ctx, reader: Optional[dict] = None) -> dict:
    """A parameter's values from its COLUMN: distinct values over the
    report's dataset, narrowed by the cascade parent, under row security.

    2026-10-03 -- the same answer shape as ``/api/datasets/{id}/column-
    values``: ``truncated`` / ``limit`` (one value more than the cap is
    asked for, so a cut list SAYS it was cut), and for a date parameter the
    column's ``range`` (the dates the data covers when the list is cut) --
    through the dataset route's own ``column_value_range``.  Off the event
    loop (FB-24).  Raises on failure; each route words the error itself.
    """
    from core import config
    from api.datasets_api import column_value_range
    lov_dataset_id = await _adb(_resolve_lov_dataset_id, report, db)
    from core.reports import param_values as _pv0
    _src0 = _pv0.normalise_source(body.source or param.get("values_source"))
    if _src0 == "list" and param.get("value_list_id"):
        # 2026-10-24 -- a NAMED value list synced into our database
        # (core/value_lists.py::serve): never wider than this viewer may query
        from core import value_lists as _vl
        from core import config as _cfg_vl
        _cap = int(_cfg_vl.business_reports.cascade_lov_limit)
        _ans = await asyncio.to_thread(_vl.serve, db, int(param["value_list_id"]),
                                       reader if reader is not None else user_ctx,
                                       search=body.search, limit=_cap)
        _vals = _ans.pop("values")
        return {**sanitize_for_json(_ans), "values": [v["key"] for v in _vals],
                "labels": {v["key"]: v.get("label") for v in _vals if v.get("label")},
                "limit": _cap}
    if not lov_dataset_id and _src0 != "table":
        # (a value table the author named needs no dataset)
        return {"values": [], "error": "Could not resolve dataset for LOV query"}
    parent_filters = _cascade_parent_filters(param, params, body.parent_values)
    _hl = _hierarchy_level_filters(param, body.parent_values)
    if _hl is not None:        # a hierarchy level: the level's column, narrowed by the levels above
        param = {**param, "lov_column_id": _hl[0]}
        parent_filters = list(parent_filters or []) + _hl[1]
    cap = int(config.business_reports.cascade_lov_limit)
    if param.get("source_column") and not param.get("lov_column_id") and _src0 != "table":
        # 2026-10-29 -- a parameter that filters AT THE SOURCE: its choices
        # are the SOURCE table's column (the predicate's), by the same rule
        return await _source_param_values(report, param, body, fed, db, lov_dataset_id,
                                          _src0, cap, user_ctx=user_ctx, reader=reader)
    # 2026-11-01 -- EVERY dropdown's list lives in PostgreSQL (the owner: "not in
    # pod memory"; core/reports/param_lists.py): the parameter's OWN list, made on
    # save (or on first use for an older report), served under the viewer's
    # entitlement; a cascade reads attrs.parents.  None = the list cannot answer
    # here (not traceable, a cascade it does not carry, a row policy) -> the roads below.
    # SECURITY (review 2026-11-01): the stored list is every distinct value of the
    # SOURCE table -- served ONLY to an app reader who may see its connection
    # (`stored_list_for`: a share / embed token has no reader and never takes
    # this branch), filtered by THAT reader's entitlement; nothing is created on
    # a viewer read (an author's save / Refresh now makes the list)
    if body.source is None:
        from core.reports import param_lists as _pl
        from core.reports.param_choices import _may_see_connection as _see
        _vl = await _pl.stored_list_for(db, report, param, reader, _see)
        if _vl is not None:
            from core import value_lists as _vlm0
            from core.roles import is_admin_like as _is_admin_like
            _is_admin_reader = _is_admin_like(reader)
            if _vlm0.needs_live(db, _vl) is None or _is_admin_reader:
                _pg = await _pl.choices(db, _vl, param, params, reader,
                                        search=body.search, parent_values=body.parent_values or {}, limit=cap)
                if _pg is not None:
                    return sanitize_for_json(_pg)
    # 2026-10-23 -- a PARTITION column's values from the table's METADATA (no
    # data scan) when the rule allows it (core/reports/param_values.py:
    # never past row security, never for a cascade).  Otherwise -- or when
    # it cannot tell -- the data, as before, and the answer says why.
    from core.reports import param_values as _pv
    _src = _pv.normalise_source(body.source or param.get("values_source"))
    _note = None
    if _src in ("auto", "metadata"):
        _allowed, _why = _pv.metadata_allowed(db, user_ctx)
        if parent_filters:
            _note = "Narrowed by the parameter it depends on, so the choices are read from the data."
        elif not _allowed:
            _note = _why
        else:
            _lk = await _pv.partition_values(
                db, dataset_id=lov_dataset_id, column_id=param["lov_column_id"],
                user=user_ctx or {},
                temporal=param.get("parameter_type") in ("date", "date_range"))
            if _lk.is_partition:
                vals = list(_lk.values or [])
                if body.search:     # the same "contains" the data read runs
                    _q = body.search.strip().lower()
                    vals = [v for v in vals if _q in str(v).lower()]
                return {"values": sanitize_for_json(vals[:cap]),
                        "truncated": _lk.truncated or len(vals) > cap, "limit": cap,
                        "source": "metadata", "table": _lk.table}
            if _src == "metadata":
                return {"values": [], "source": "metadata",
                        "reason": _lk.reason or "No partition values could be read."}
            _note = None if _lk.is_partition is False else _lk.reason
    elif _src == "data":
        _note = None
    # 2026-10-24 -- the DATA read is ONE rule (core/reports/param_choices.py):
    # another table the author named; else the column traced through the
    # report's SQL to its source table (fact_tetb.region); else the report's
    # own DISTINCT -- every answer through THE value cache the query builder
    # fills, under row security, searchable on the server.
    from core.reports import param_choices as _pc
    _read = await _pc.read(
        fed, db, dataset_id=lov_dataset_id, param=param,
        parent_filters=parent_filters or None, search=body.search,
        limit=cap + 1, user_ctx=user_ctx,
        temporal=param.get("parameter_type") in ("date", "date_range"),
        source="table" if _src == "table" else "data",
        # the reader may see the source connection (traced read); the OWNER
        # still sees a value table's connection (checked at read)
        reader=reader, report_owner=report.get("owner") or report.get("created_by"))
    values = list(_read.get("values") or [])
    truncated = len(values) > cap
    values = values[:cap]
    # BF-263: sanitize — federation engine returns raw DB types (Decimal,
    # datetime, etc.) that crash json encode without conversion.
    out = {"values": sanitize_for_json(values), "truncated": truncated,
           "limit": cap, "source": _read.get("source", "data"),
           "cached": bool(_read.get("cached"))}
    if _read.get("table"):
        out["table"] = _read["table"]
    if body.search:
        out["search"] = body.search
    # why the metadata was not used comes first; a failed table read after it
    _note = " ".join(n for n in (_note, _read.get("source_note")) if n) or None
    if _note:
        out["source_note"] = _note
    if _read.get("trace_note"):
        out["trace_note"] = _read["trace_note"]
    # the covered date range is the report query's (a value table names none)
    if param.get("parameter_type") in ("date", "date_range") and out["source"] == "data":
        out.update(sanitize_for_json(await column_value_range(
            fed, dataset_id=lov_dataset_id, column_id=param["lov_column_id"],
            parent_filters=parent_filters or None, values=values,
            truncated=truncated, user=user_ctx)))
    return out


# ── Admin Config ─────────────────────────────────────────────────────────────

def _build_reports_config_response(cfg) -> dict:
    """Build the full business_reports config dict for admin endpoints."""
    br = cfg.business_reports
    return {
        "enabled":                      br.enabled,
        "max_reports_per_user":         br.max_reports_per_user,
        "max_sections_per_report":      br.max_sections_per_report,
        "max_parameters_per_report":    br.max_parameters_per_report,
        "max_running_calcs_per_report": br.max_running_calcs_per_report,
        "default_row_limit":            br.default_row_limit,
        "pdf_row_limit":                br.pdf_row_limit,
        "pdf_max_rows":                 br.pdf_max_rows,
        "excel_row_limit":              br.excel_row_limit,
        "csv_row_limit":                br.csv_row_limit,
        "embed_row_limit":              br.embed_row_limit,
        "cascade_lov_limit":            br.cascade_lov_limit,
        "page_size":                    br.page_size,
        "max_page_size":                br.max_page_size,
        "auto_save_interval_seconds":   br.auto_save_interval_seconds,
        "export_formats":               br.export_formats,
        "async_execution_ttl_seconds":  br.async_execution_ttl_seconds,
        "pdf_page_size":                br.pdf_page_size,
        "pdf_primary_color":            br.pdf_primary_color,
    }


@router.get("/api/admin/reports/config")
async def get_reports_config(user: dict = Depends(require_capability("reports.manage"))):
    """Return current business reports configuration. Phase 81: extended config."""
    from core import config as _cfg
    return _build_reports_config_response(_cfg)


@router.put("/api/admin/reports/config")
async def set_reports_config(body: BusinessReportsConfigUpdate, user: dict = Depends(require_capability("reports.manage"))):
    """Update business reports configuration. Phase 81: typed model."""
    from core import config as _cfg
    updates = body.model_dump(exclude_none=True)
    for k, v in updates.items():
        _cfg.set("business_reports", k, v)
    username = (user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_reports_config", resource_type="config",
                      resource_id="business_reports")
    logger.info("Business reports config updated by '%s': %s", username, list(updates.keys()))
    return _build_reports_config_response(_cfg)


@router.get("/api/admin/business-reports/config")
async def get_business_reports_config_v2(user: dict = Depends(require_capability("reports.manage"))):
    """Phase 81: canonical admin config endpoint for business reports."""
    from core import config as _cfg
    return _build_reports_config_response(_cfg)


@router.put("/api/admin/business-reports/config")
async def set_business_reports_config_v2(body: BusinessReportsConfigUpdate,
                                          user: dict = Depends(require_capability("reports.manage"))):
    """Phase 81: canonical admin config endpoint for business reports."""
    from core import config as _cfg
    updates = body.model_dump(exclude_none=True)
    for k, v in updates.items():
        _cfg.set("business_reports", k, v)
    username = (user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_business_reports_config", resource_type="config",
                      resource_id="business_reports")
    logger.info("Business reports config updated by '%s': %s", username, list(updates.keys()))
    return _build_reports_config_response(_cfg)


# ── Phase 106: Pivot Report Admin Config ──────────────────────────────────────

@router.get("/api/admin/pivot/config")
async def get_pivot_reports_config(user: dict = Depends(require_capability("reports.manage"))):
    """Phase 106: admin config for pivot reports."""
    from core.config import pivot_reports as _pv
    return {
        "enabled": _pv.enabled,
        "max_row_dimensions": _pv.max_row_dimensions,
        "max_col_dimensions": _pv.max_col_dimensions,
        "max_measures": _pv.max_measures,
        "max_row_groups": _pv.max_row_groups,
        "max_col_groups": _pv.max_col_groups,
        "default_aggregation": _pv.default_aggregation,
    }


@router.put("/api/admin/pivot/config")
async def set_pivot_reports_config(body: PivotReportsConfigUpdate,
                                    user: dict = Depends(require_capability("reports.manage"))):
    """Phase 106: update pivot reports config."""
    from core import config as _cfg
    updates = body.model_dump(exclude_none=True)
    for k, v in updates.items():
        _cfg.set("pivot_reports", k, v)
    username = (user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_pivot_reports_config", resource_type="config",
                      resource_id="pivot_reports")
    logger.info("Pivot reports config updated by '%s': %s", username, list(updates.keys()))
    return await get_pivot_reports_config(user)


# ── Certification (Phase 58) ─────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/certify")
async def certify_report(report_id: int, body: CertifyRequest,
                         user: dict = Depends(require_capability("reports.manage"))):
    """Certify a business report as an official template. Admin only."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.certification_enabled:
        raise HTTPException(status_code=400, detail="Certification is disabled")

    existing = await _adb(db.get_business_report, report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    # Validate category against configured list
    allowed_cats = _cfg.report_catalog.template_categories
    if allowed_cats and body.template_category not in allowed_cats:
        raise HTTPException(status_code=400,
                            detail=f"Invalid category. Allowed: {allowed_cats}")

    username = (user or {}).get("username", "admin")
    updated = await _adb(db.certify_business_report, report_id, username, body.template_category)
    if not updated:
        raise HTTPException(status_code=404, detail="Report not found")

    logger.info("Report %d certified by '%s' in category '%s'",
                report_id, username, body.template_category)
    return updated


@router.delete("/api/business-reports/{report_id}/certify")
async def uncertify_report(report_id: int, user: dict = Depends(require_capability("reports.manage"))):
    """Remove certification from a business report. Admin only."""
    db = _require_db()
    updated = await _adb(db.uncertify_business_report, report_id)
    if not updated:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "admin")
    logger.info("Report %d uncertified by '%s'", report_id, username)
    return updated


# ── Clone from Template (Phase 58) ───────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/clone")
async def clone_template(report_id: int, user: dict = Depends(require_capability("reports.create"))):
    """Clone a certified template to the current user's workspace.

    Similar to duplicate, but only works on certified reports and tracks
    ``cloned_from_id`` for lineage.
    """
    db = _require_db()
    source = await _adb(db.get_business_report, report_id)
    if not source:
        raise HTTPException(status_code=404, detail="Report not found")
    if not source.get("is_certified"):
        raise HTTPException(status_code=400, detail="Only certified templates can be cloned")

    username = (user or {}).get("username", "admin")

    # Quota check
    from core import config
    existing = await _adb(db.list_business_reports, owner=username)
    max_reports = config.business_reports.max_reports_per_user
    if len(existing) >= max_reports:
        raise HTTPException(status_code=400,
                            detail=f"Report quota exceeded ({max_reports} max per user)")

    clone_data = {
        "name": f"{source['name']} (My Copy)",
        "owner": username,
        "dataset_id": source["dataset_id"],
        "description": source.get("description", ""),
        "merged_dataset_id": source.get("merged_dataset_id"),
        "merge_config": source.get("merge_config"),
        "column_ids": source.get("column_ids", []),
        "filter_specs": source.get("filter_specs", []),
        "condition_ids": source.get("condition_ids", []),
        "order_by": source.get("order_by", []),
        "row_limit": source.get("row_limit", 50000),
        "section_definitions": source.get("section_definitions", []),
        "running_calculations": source.get("running_calculations", []),
        "slicer_column_ids": source.get("slicer_column_ids", []),
        "drill_hierarchy_id": source.get("drill_hierarchy_id"),
        "layout_config": source.get("layout_config"),
        "role_whitelist": source.get("role_whitelist"),
    }
    # SECURITY (review 2026-11-01): the copied parameters take THE gate, as the copier, first
    source_params = await _adb(db.list_report_parameters, report_id)
    _copies = [dict(_copyable_parameter_fields(p)) for p in source_params]
    await _check_parameter_write(db, source, _copies, _copies, user)
    new_report = await _adb(db.create_business_report, **clone_data)

    # Set cloned_from_id
    await _adb(db.update_business_report, new_report["id"], cloned_from_id=report_id)
    new_report["cloned_from_id"] = report_id

    # Clone parameters
    param_id_map = {}
    for p in source_params:
        new_p = await _adb(db.create_report_parameter,
                           report_id=new_report["id"],
                           **_copyable_parameter_fields(p))
        param_id_map[p["id"]] = new_p["id"]

    for old_p in source_params:
        if old_p.get("depends_on_param_id") and old_p["depends_on_param_id"] in param_id_map:
            new_pid = param_id_map[old_p["id"]]
            await _adb(db.update_report_parameter, new_pid,
                                       depends_on_param_id=param_id_map[old_p["depends_on_param_id"]])

    new_report["parameters"] = await _adb(db.list_report_parameters, new_report["id"])
    logger.info("Cloned certified template %d → %d by user '%s'",
                report_id, new_report["id"], username)
    return new_report


# ── Share Tokens (Phase 58) ──────────────────────────────────────────────────

# ── Token-surface chokepoints (2026-08-23, p3a journey audit) ────────────────
#
# The share/embed token routes are AUTHORIZATION BOUNDARIES serving anonymous
# callers.  Every decision they share is made in exactly ONE place here:
#
#   * `_token_expired`               — the expiry rule (was inlined 5×)
#   * `_validate_business_share_token` — share-token validity, mirroring
#     `_validate_business_embed_token`; BOTH consult their operator kill
#     switch at CONSUMPTION (`report_catalog.sharing_enabled` /
#     `embed_enabled`) — minting was gated but existing links outlived the
#     switch, the opposite of revocation-first-class (F-P3A-04)
#   * `_token_report_projection`     — the ONLY report fields a token page
#     may see.  The shared GET used to ship the FULL row (raw_sql_override,
#     raw_schedule_config recipients, owner, role_whitelist…) while the
#     embed GET whitelisted — the same fact projected two ways (F-P3A-01)
#   * `_resolve_token_row_limit`     — a token caller may only NARROW the
#     author's stored row bound; 0/negative/absent from an anonymous caller
#     NEVER mean unlimited (F-P3A-02; `0 == unlimited` is an AUTHOR spelling)
#   * `_redact_token_result`         — strips server-internal keys
#     (output_path, sql_generated with its RLS predicates, sources_used) and
#     the `served_version.published_by` username from anonymous responses
#     (F-P3A-05)


def _token_expired(raw) -> bool:
    """ONE expiry rule for share + embed tokens.  Naive timestamps are UTC."""
    if not raw:
        return False
    expires = raw
    if isinstance(expires, str):
        expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
    if getattr(expires, "tzinfo", None) is None:
        expires = expires.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) > expires


def _validate_business_share_token(db, token: str) -> dict:
    """Validate a share token: feature enabled, active, unexpired.

    403 when the operator disabled sharing (kill switch governs CONSUMPTION,
    not only minting); 404 unknown/revoked; 410 expired.
    """
    from core import config as _cfg
    if not _cfg.report_catalog.sharing_enabled:
        raise HTTPException(status_code=403, detail="Report sharing is disabled")
    share = db.get_business_report_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    if _token_expired(share.get("expires_at")):
        raise HTTPException(status_code=410, detail="Share link has expired")
    return share


_TOKEN_REPORT_FIELDS = ("id", "name", "description", "layout_config")


def _token_report_projection(report: dict, parameters: list) -> dict:
    """The report fields a token (anonymous) page renders — nothing else.

    Matches what the embed GET always whitelisted and what both token pages
    read.  Server-side definition internals (raw_sql_override, schedule
    recipients, owner, role_whitelist, source ids) never ride this wire.
    """
    out = {f: report.get(f) for f in _TOKEN_REPORT_FIELDS}
    out["section_definitions"] = report.get("section_definitions") or []
    out["running_calculations"] = report.get("running_calculations") or []
    out["parameters"] = parameters
    return out


def _resolve_token_row_limit(requested, report: dict, _cfg,
                             extra_cap: Optional[int] = None) -> int:
    """Row bound for a TOKEN (share/embed/export) execution — narrow-only.

    Base = the AUTHOR's stored bound (`report.row_limit`, else the config
    default; 0 = unlimited only when the author chose that spelling).  A
    token caller's request may narrow the base, never widen it; 0/negative/
    absent from the anonymous side fall back to the base.  ``extra_cap``
    (embed_row_limit / share_export_row_limit) caps again when given.
    """
    base = _resolve_report_row_limit(None, report, _cfg)
    try:
        req = int(requested) if requested is not None else None
    except (TypeError, ValueError):
        req = None
    val = base
    if req is not None and req > 0:
        val = min(req, base) if base > 0 else req
    try:
        cap = int(extra_cap) if extra_cap is not None else None
    except (TypeError, ValueError):
        cap = None
    if cap is not None and cap > 0:
        val = min(val, cap) if val > 0 else cap
    return max(0, val)


_TOKEN_INTERNAL_RESULT_KEYS = ("output_path", "sql_generated", "sources_used",
                               "dataset_id")


def _redact_token_result(result):
    """Strip server-internal keys from a response bound for an anonymous
    token caller.  The wire contract the token pages read (rows / data /
    columns / total_rows / truncated / row_limit / engine) is untouched."""
    if isinstance(result, dict):
        for k in _TOKEN_INTERNAL_RESULT_KEYS:
            result.pop(k, None)
        sv = result.get("served_version")
        if isinstance(sv, dict):
            sv.pop("published_by", None)
    return result


# ── Empty-scope disclosure (2026-08-29) ──────────────────────────────────────
#
# A report whose OWN SQL references ``${user.*}`` varies by who runs it, and
# an empty group scope renders ``${user.groups}`` as the never-match sentinel
# ``(NULL)`` — deliberately fail-closed, zero rows, no leak (see
# core.reports.user_sql_vars).  The renderer already computes that exact cause
# and logs it, but the token caller received a plain successful 0-row result:
# a 200 carrying nothing useful, whose cause is already known, is a defect of
# disclosure in this codebase.  Two chokepoints close it:
#
#   * ``_disclose_empty_principal_scope`` — stamps the EXECUTION envelope
#     (additively: ``data_status`` + ``warnings[]``; no existing key is
#     renamed, removed or overwritten — existing UI consumers read this
#     shape untouched);
#   * ``_token_mint_scope_warning``       — warns at MINT time, which is
#     where the mistake (a share link, or an embed token minted without
#     groups, for a principal-varying report) is actually made.
#
# Both ask ``report_references_user_vars`` — the existing shared rule the
# cache layers use — never a re-implementation of it.

#: Additive envelope marker: the result is empty BECAUSE the executing
#: principal has no group scope, not because the data matched nothing.
_EMPTY_SCOPE_DATA_STATUS = "empty_no_principal_scope"


def _empty_scope_cause(username: str) -> str:
    """The one wording for "empty because the principal has no group scope"."""
    return ("This report's SQL references ${user.*} and it executed with no "
            "principal group scope (principal '" + (username or "anonymous")
            + "'): a ${user.groups} filter renders as the never-match "
              "sentinel and matches nothing, so the empty result reflects "
              "the caller's scope, not the data. Grant the caller a group, "
              "or mint the embed token with allowed_ad_groups / "
              "allowed_user_groups.")


def _disclose_empty_principal_scope(result, report: Optional[dict], db,
                                    principal: Optional[Dict[str, Any]]):
    """ADDITIVELY name the cause when a token execution is empty by scope.

    Fires only when ALL THREE are true — the report's own SQL references
    ``${user.*}`` (decided by ``report_references_user_vars``, the shared
    rule), the executing principal carries NO groups, and the result holds
    no rows.  Everything else passes through byte-identical, so a report
    that does not use the feature cannot be affected by it.

    Best-effort by design: this is disclosure, never a gate — any failure
    returns the result unannotated rather than failing the execution.
    """
    if not isinstance(result, dict):
        return result
    if result.get("data") or result.get("rows"):
        return result                      # rows present — not empty
    if (result.get("total_rows") or 0) > 0:
        return result                      # rows exist, just not materialised
    if (principal or {}).get("groups"):
        return result                      # scoped principal: a genuine no-match
    try:
        from core.reports.user_sql_vars import report_references_user_vars
        if not report_references_user_vars(report, db):
            return result                  # SQL does not vary by principal
    except Exception:
        return result
    who = (principal or {}).get("username") or "anonymous"
    cause = _empty_scope_cause(who)
    result.setdefault("data_status", _EMPTY_SCOPE_DATA_STATUS)
    warnings = result.get("warnings")
    if not isinstance(warnings, list):
        warnings = []
        result["warnings"] = warnings
    if cause not in warnings:
        warnings.append(cause)
    logger.info("[empty-scope] report %s: 0-row result disclosed as %s "
                "(principal '%s')", (report or {}).get("id"),
                _EMPTY_SCOPE_DATA_STATUS, who)
    return result


def _token_mint_scope_warning(report: Optional[dict], db, groups,
                              kind: str) -> Optional[str]:
    """Warn AT MINT TIME when a token cannot satisfy a ``${user.*}`` report.

    ``groups`` is the scope the token will carry (always empty for a share
    link).  Returns the human-readable warning to include in the mint
    response, or ``None`` when the report's SQL does not vary by principal
    or the token already carries a scope.  Best-effort: a failure here must
    never block minting.
    """
    if groups:
        return None
    try:
        from core.reports.user_sql_vars import report_references_user_vars
        if not report_references_user_vars(report, db):
            return None
    except Exception:
        return None
    if kind == "embed":
        msg = ("This report's SQL references ${user.*} and this embed token "
               "carries no groups: any ${user.groups} filter will match "
               "nothing and every viewer of this embed will get ZERO rows. "
               "Mint the token with allowed_ad_groups / allowed_user_groups "
               "to give its viewers a group scope.")
    else:
        msg = ("This report's SQL references ${user.*} and a share link "
               "always runs it with no group scope: any ${user.groups} "
               "filter will match nothing and every viewer of this link "
               "will get ZERO rows. Use an embed token minted with "
               "allowed_ad_groups / allowed_user_groups instead.")
    logger.warning("[token-mint] %s token for report %s ('%s'): %s",
                   kind, (report or {}).get("id"), (report or {}).get("name"),
                   msg)
    return msg


def _append_mint_warning(response, warning: Optional[str]):
    """Attach a mint-time warning to the token row ADDITIVELY (never touches
    an existing key's meaning; absent when there is nothing to say)."""
    if warning and isinstance(response, dict):
        warnings = response.get("warnings")
        if not isinstance(warnings, list):
            warnings = []
            response["warnings"] = warnings
        warnings.append(warning)
    return response


def _may_mint_report_share(report: dict, user: Optional[dict]) -> bool:
    """THE rule for who may expose a report through a public share link: its
    owner, or an admin-tier role.  Used at mint time by the report share
    route and at REQUEST time by the shared-dashboard tile routes (the
    dashboard share's creator, resolved headless -- 2026-10-26 security
    review: anyone who could share a DASHBOARD could expose a report they
    could not share themselves by putting it on the dashboard)."""
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    return bool(username) and (report.get("owner") == username or role in ADMIN_TIER_ROLES)


@router.post("/api/business-reports/{report_id}/share")
async def create_share_token(report_id: int, body: ShareCreateRequest,
                             user: dict = Depends(require_capability("reports.edit"))):
    """Create a public share link for a business report."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.sharing_enabled:
        raise HTTPException(status_code=400, detail="Report sharing is disabled")

    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    if not _may_mint_report_share(report, user):
        raise HTTPException(status_code=403, detail="Only report owner or admin can share")
    from api.published_views.management import _refuse_unpublished_report
    _refuse_unpublished_report(report, "a share link")

    # Enforce max shares per report
    existing_shares = await _adb(db.list_business_report_shares, report_id)
    max_shares = _cfg.report_catalog.max_shares_per_report
    if len(existing_shares) >= max_shares:
        raise HTTPException(status_code=400,
                            detail=f"Max {max_shares} share links per report")

    hours = body.expires_hours or _cfg.report_catalog.share_default_expiry_hours
    expires_at = datetime.now(timezone.utc) + timedelta(hours=hours)

    share = await _adb(db.create_business_report_share, report_id, username, expires_at)
    logger.info("Created share token for report %d by '%s'", report_id, username)
    # 2026-08-29 mint-time disclosure — this is where the mistake is made: a
    # share link ALWAYS executes with no group scope, so a ${user.*} report
    # will return zero rows to every viewer of this link.
    return _append_mint_warning(
        share, await _adb(_token_mint_scope_warning, report, db, [], "share"))


@router.get("/api/business-reports/{report_id}/shares")
async def list_share_tokens(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """List active share tokens for a business report."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Access denied")

    return {"shares": await _adb(db.list_business_report_shares, report_id)}


@router.delete("/api/business-reports/{report_id}/shares/{token}")
async def revoke_share_token(report_id: int, token: str,
                             user: dict = Depends(require_capability("reports.edit"))):
    """Revoke a share token."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Access denied")

    # 2026-09-15: authorisation above is decided on the CALLER-SUPPLIED
    # report_id; the deactivation below is keyed on the token alone.  Without
    # binding the two, the owner of report B could revoke any of report A's
    # links he had seen (proved live: a token minted on C, revoked via D's
    # id -> 200).  The token must belong to the report in the path, or the
    # request is answered as if the token did not exist (404 — a foreign
    # token's existence is not disclosed to a caller who cannot revoke it).
    share = await _adb(db.get_business_report_share_by_token, token)
    if not share or int(share.get("report_id") or 0) != int(report_id):
        raise HTTPException(status_code=404, detail="Share token not found")

    if not await _adb(db.deactivate_business_report_share, token):
        raise HTTPException(status_code=404, detail="Share token not found")

    logger.info("Revoked share token for report %d by '%s'", report_id, username)
    return {"detail": "revoked"}


# ── 2026-08-30 hardening — the PUBLIC token surface (D1 + D2) ────────────────
#
# D1.  main.py builds a slowapi Limiter but never adds SlowAPIMiddleware and
# no route uses @limiter.limit — its default limit is INERT.  The
# unauthenticated share/embed execute, parameter-values and download routes
# run live engine work per call, so one leaked URL was an unauthenticated
# CPU-burn primitive.  The budget below is PER TOKEN — never per IP: IP
# rotation must not buy more budget, and many portal users legitimately
# share one egress NAT — and is enforced AFTER token validation, so garbage
# tokens stay cheap 404s and cannot burn a real link's budget (per-token
# keying would hand a rotating attacker a fresh window per guess anyway).
# Uses the in-house cross-process limiter (core.rate_limiter): Redis sliding
# window when queue.backend=redis, in-process fallback otherwise.  Exceed →
# 429 with Retry-After.
#
# D2.  Every OTHER data-serving surface emits the one greppable [br-serve]
# line (log_report_serve) — interactive, async, exports, token DOWNLOADS,
# headless, delivery — but the share/embed EXECUTE endpoints did not, so
# "who read what" was unanswerable exactly for external-portal traffic.
# ``_log_token_serve`` closes it: report id, TRUNCATED token (never the
# full credential), the group scope used, row count, and the truncation
# verdict the envelope already computed (passed through, never recomputed).

_TOKEN_BUDGET_DEFAULT_LIMIT = 30            # requests per token per window
_TOKEN_BUDGET_DEFAULT_WINDOW_SECONDS = 60


def _token_budget_limit() -> int:
    """Config: ``business_reports.token_requests_per_window`` (default 30).

    Explicit ``int()`` parse — NEVER an ``x or default`` fold.  ``0`` (or
    negative) is the operator's KILL SWITCH for the public token surface:
    ``core.rate_limiter`` treats ``limit <= 0`` as block-all, and it must
    never read as unlimited (the product's signature bug class).
    """
    from core import config as _cfg_mod
    try:
        return int(_cfg_mod.get("business_reports",
                                "token_requests_per_window",
                                _TOKEN_BUDGET_DEFAULT_LIMIT))
    except (TypeError, ValueError):
        return _TOKEN_BUDGET_DEFAULT_LIMIT


def _token_budget_window_seconds() -> int:
    """Config: ``business_reports.token_request_window_seconds`` (default 60).

    A window ``<= 0`` would make every limiter entry instantly expired —
    the 0-means-unlimited fold arriving through the WINDOW instead of the
    limit — so non-positive values fall back to the default window.
    """
    from core import config as _cfg_mod
    try:
        val = int(_cfg_mod.get("business_reports",
                               "token_request_window_seconds",
                               _TOKEN_BUDGET_DEFAULT_WINDOW_SECONDS))
    except (TypeError, ValueError):
        return _TOKEN_BUDGET_DEFAULT_WINDOW_SECONDS
    return val if val > 0 else _TOKEN_BUDGET_DEFAULT_WINDOW_SECONDS


def _enforce_token_budget(action: str, token: str) -> None:
    """Per-TOKEN budget on the public token routes (D1): 429 + Retry-After
    on exceed.  The limiter key is a sha256 prefix of the token — the raw
    credential never lands in Redis keyspace or limiter internals."""
    import hashlib
    from core.rate_limiter import RateLimitExceededError, check_rate_limit
    limit = _token_budget_limit()
    window = _token_budget_window_seconds()
    key = hashlib.sha256(token.encode("utf-8", "surrogatepass")).hexdigest()[:24]
    try:
        check_rate_limit(f"br-token-{action}", key, limit, window)
    except RateLimitExceededError as exc:
        raise HTTPException(
            status_code=429,
            detail=(f"Rate limit exceeded for this report link: "
                    f"{limit} {action} request(s) per {window}s. "
                    f"Retry after {exc.retry_after}s."),
            headers={"Retry-After": str(max(1, int(exc.retry_after)))},
        )


def _record_token_call(request, *, token: str, token_type: str, report: Optional[dict], report_id,
                       endpoint: str, fmt: Optional[str], status: int, rows: Optional[int],
                       ms: Optional[int], response_bytes: Optional[int] = None) -> None:
    """THE call record for a report served by a token (2026-10-17,
    core/published_api/calls.py): ``api_kind`` published_report, the report's
    slug, the token's first 8 characters as the consumer.  Readership stays
    in ``br_serve_log`` (``_log_token_serve``); this is the CALL.  Fail-open.
    No request (a direct, in-process call) = no HTTP call to record."""
    if request is None:
        return
    try:
        from core.published_api import calls as _calls
        _calls.record(_db_manager, request=request, api_kind=_calls.KIND_REPORT,
                      api_id=int(report_id) if report_id is not None else None,
                      api_slug=(report or {}).get("slug"), consumer=_calls.token_consumer(token),
                      auth_method="token", endpoint=endpoint, fmt=fmt, status_code=int(status),
                      response_ms=ms, response_rows=rows, cache_status=None,
                      response_bytes=response_bytes)
    except Exception as exc:                            # noqa: BLE001 -- a record never fails a serve
        logger.debug("[published-api] token call not recorded: %s", exc)


def _log_token_serve(result: Any, *, report_id, token: str, surface: str,
                     scope: Optional[Dict[str, Any]] = None) -> None:
    """Emit the [br-serve] record for an anonymous token EXECUTE (D2).

    Fail-open — audit must never break the serve.  The truncation verdict
    and row counts are READ off the envelope this execution already
    computed, never recomputed here.
    """
    try:
        from core.reports.serve_log import log_report_serve
        rows = None
        total_rows = row_limit = truncated = None
        execution_id = ""
        if isinstance(result, dict):
            data = result.get("data")
            if isinstance(data, list):
                rows = len(data)
            elif isinstance(result.get("rows"), list):
                rows = len(result["rows"])
            total_rows = result.get("total_rows")
            row_limit = result.get("row_limit")
            truncated = result.get("truncated")
            execution_id = str(result.get("execution_id") or "")
        groups = list((scope or {}).get("groups") or [])
        log_report_serve(
            report_id=report_id,
            execution_id=execution_id,
            user=f"token:{token[:8]}",     # truncated — never the credential
            rls=("token-groups" if groups else "token"),
            surface=surface,
            fmt="json",
            rows=rows,
            total_rows=total_rows,
            row_limit=row_limit,
            truncated=truncated,
            detail=("groups=" + ",".join(groups)) if groups else "groups=none",
        )
    except Exception as exc:
        logger.debug("[br-serve] token serve record emit failed (fail-open): %s",
                     exc)


# ── Public Share Endpoint (NO AUTH) ──────────────────────────────────────────

@router.get("/api/shared-business-report/{token}")
async def get_shared_report(token: str):
    """PUBLIC — Return report metadata for a share token (no auth required).

    Phase 81 FIX 4: includes 'parameter_definitions' so frontend knows URL-passable params.

    F-P3A-01 (2026-08-23): the response used to ship the FULL BusinessReport
    row to the anonymous caller — raw_sql_override, raw_schedule_config
    (recipient e-mails), owner, role_whitelist, source/connection ids.  It
    now serves the SAME whitelist projection the embed GET always did
    (`_token_report_projection` — one rule, two doors).
    """
    db = _require_db()
    share = await _adb(_validate_business_share_token, db, token)

    report = await _adb(db.get_business_report, share["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Publish lifecycle (2026-08-17): the metadata a token page renders must
    # describe the SAME definition its /execute will run — the current
    # published version.  Unpublished, never published or archived => 410
    # (2026-09-15: the draft is NEVER served to a token -- see
    # _resolve_execution_report; a share link to an archived report is a
    # dead link, not an audit surface).
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, None, True)

    await _adb(db.increment_business_report_share_access, token)

    parameters = await _adb(_enrich_source_parameters,
                            await _adb(_report_parameters_for_execution, report, db, share["report_id"]),
                            db, report)
    parameters = await _token_effective_defaults(db, report, parameters)   # the band pre-selects the default (2026-11-02)
    return _redact_token_result(await _astamp_served_version({
        "token": token,
        "report": _token_report_projection(report, parameters),
        # Phase 81 FIX 4: explicit param definitions for URL pre-fill
        "parameter_definitions": [
            {"name": p["name"], "label": p["label"], "parameter_type": p["parameter_type"]}
            for p in parameters
        ],
    }, _served_version))


def execution_principal(user_ctx: Optional[Dict[str, Any]] = None,
                        username: Optional[str] = None,
                        role: Optional[str] = None) -> dict:
    """The principal a report execution enforces row-security with.

    A real caller — an interactive user, or an embed token that names groups —
    is used as-is. When there is NO caller (public share link, or an embed
    token minted without groups) the principal is fabricated, and a fabricated
    principal MUST be marked ``rls_unresolved``.

    2026-08-30 — it was not, and the comment here claimed "missing groups →
    fewer grants, never more". That is false in this GRANT-shaped engine: the
    rewriter refuses a governed table only for an UNRESOLVED principal, while
    a *resolved* principal matching no binding is skipped — and its own
    comment records that the skip "ships it UNFILTERED". So every scopeless
    share link and every groupless embed token served governed tables in full
    to an anonymous caller, while the parameter-dropdown sibling set the flag
    and refused the SAME caller. Denied the dropdown, handed the grid.

    The 2026-08-19 escalation fix marked six such sites; this one was missed.

    Module-level and named so it can be tested directly — the first version of
    its test scraped this function out of the source with a regex, which broke
    on the indentation and made a mutation look killed when the tests were
    simply failing.
    """
    if user_ctx:
        return {**user_ctx,
                "username": user_ctx.get("username") or username or "shared",
                "role": user_ctx.get("role") or role or "viewer"}
    return {"username": username or "shared", "role": role or "viewer",
            "rls_unresolved": True}


#: which road is running a report through ``_dispatch_report_execution`` --
#: recorded with the run for its Diagnostics panel (2026-10-30)
from contextvars import ContextVar as _ContextVar
_DISPATCH_SURFACE: "_ContextVar[str]" = _ContextVar("qs_report_dispatch_surface", default="dispatch")


def _dispatch_on(surface: str) -> None:
    """Name the road the CURRENT request runs a report on (a route's task:
    each request is its own task, so the value never leaks to another)."""
    _DISPATCH_SURFACE.set(surface)


async def _dispatch_report_execution(report: dict, report_id: int, param_values: dict,
                                      extra_filters: list | None, limit_override: int | None,
                                      db, fed, role: str = "viewer",
                                      username: str = "shared",
                                      user_ctx: dict | None = None,
                                      override_column_ids: list | None = None,
                                      materialize: bool = True) -> dict:
    """Execute a report dispatching by data_source_type.

    2026-10-30: every run this dispatcher serves is recorded for its
    Diagnostics panel (``core.reports.diagnostics.record_report_run``, the
    SAME recorder the interactive /execute uses), so a share, embed,
    shared-dashboard or export run answers "how was each value applied" too.
    WHICH road ran it is ``_DISPATCH_SURFACE`` (a context variable each route
    sets -- ``_dispatch_on``), not a parameter: the routes' call shape, and
    every dispatcher double with a closed signature, stay as they were.

    ``materialize=False`` (2026-10-04, the streamed exports): the envelope is
    LOCATED -- its artifact proven, its count read from the parquet footer --
    and no row is read into Python; ``data`` / ``rows`` are present only for
    an inline (published / federation view) result.  The caller reads the
    artifact itself in record batches (``core.reports.export_stream``).

    Shared single dispatch for share/embed/export endpoints.

    2026-08-04 strategic redesign: returns the UNIFIED wire envelope
    (``core.reports.contract.ReportEnvelope``) for EVERY source type —
    ``rows`` (positional), ``data`` (records), ``columns``, ``total_rows``,
    ``truncated`` are always present and materialised (bounded by the row
    limit, read off the event loop).  Consumers no longer need to know the
    source type: the shared/embedded token pages that read ``result.rows``
    — which NO branch previously produced — now render data on every path.

    ``user_ctx`` (optional): the FULL authenticated principal dict (incl.
    ``groups``).  When provided it is used verbatim as the RLS context so the
    row scope of an EXPORT matches the on-screen/interactive report — the
    ``build_user_ctx`` rewriter reads ``groups`` to match group-scoped grants.
    When None (public share/embed token paths) we fall back to a minimal
    ``{username, role}`` principal with NO groups — fail-safe, never broadens.
    """
    from core import config as _cfg
    # RLS context for this execution.  A real caller (interactive user, or an
    # embed token that names groups) is used as-is.
    #
    # 2026-08-30 — THE ANONYMOUS FALLBACK USED TO BE MARKED **RESOLVED**, and
    # the comment here claimed "missing groups → fewer grants, never more".
    # That is false in this GRANT-shaped engine: a resolved principal matching
    # no binding is SKIPPED by the rewriter, and a skipped governed table is
    # shipped UNFILTERED (row_security/rewriter.py says so in its own comment).
    # So every scopeless share link and every embed token minted without
    # groups served governed tables IN FULL to an anonymous caller — while the
    # parameter-dropdown sibling a few hundred lines below set
    # ``rls_unresolved`` and correctly refused the SAME caller. One anonymous
    # viewer: denied the dropdown, handed the whole grid.
    #
    # The 2026-08-19 escalation fix marked six such sites; this one was missed.
    def _rls_ctx() -> dict:
        return execution_principal(user_ctx, username, role)
    ds_type = report.get("data_source_type") or "saved_query"
    row_limit = _resolve_report_row_limit(limit_override, report, _cfg)
    execution_id = str(uuid.uuid4())
    # the lists the run USED, for its Diagnostics record (dataset / pivot
    # reports build them below; the view and raw-SQL roads apply their values
    # inside their own engines -- the record then says the filter list was
    # not recorded, never a guess)
    _diag_filters: list | None = None
    _diag_bindings: list | None = None

    if ds_type == "published_view":
        pv_id = report.get("published_view_id")
        if not pv_id:
            raise HTTPException(400, "Report has data_source_type='published_view' but no published_view_id")
        pv = await _adb(db.get_published_view, pv_id)
        if not pv or not pv.get("is_active"):
            raise HTTPException(400, "Published view not found or inactive")
        pv_params = await _adb(_map_report_params_to_pv, report, param_values, db, report_id)
        from api.published_views_api import _execute_view
        # 2026-08-05: thread the caller's principal for RLS on the PV path.
        # user_ctx is None on public share/embed tokens — the PV handler
        # then uses its synthetic low-privilege pv:<slug> principal, which
        # is the correct scope for anonymous consumers.
        raw = _public_view_result(
            await _execute_view(pv=pv, filters=[], columns=None,
                                sort_column=None, sort_dir="asc",
                                limit=row_limit, offset=0, params=pv_params,
                                consumer_user=(user_ctx or None)))

    elif ds_type == "federation_view":
        fv_id = report.get("federation_view_id")
        if not fv_id:
            raise HTTPException(400, "Report has data_source_type='federation_view' but no federation_view_id")
        fv = await _adb(db.get_federation_view, fv_id)
        if not fv:
            raise HTTPException(404, f"Federation view {fv_id} not found")
        from api.federation_views_api import execute_federation_view
        # Same fix on the share/embed/export path: _rls_ctx() is the
        # principal every other source type here already enforces with,
        # and for a scopeless token it carries rls_unresolved so governed
        # tables stay REFUSED rather than read unfiltered.
        raw = await execute_federation_view(
            fv, limit=row_limit, username=username, user_ctx=_rls_ctx())

    elif ds_type == "raw_sql":
        # Phase 131 deep-dive #10: build a minimal user_ctx for RLS from
        # the dispatcher's username/role so shared+embedded reports also
        # enforce policies.  Hardcoded "shared" username when not passed
        # is acceptable — RLS policies should treat "shared" as a low-
        # privilege principal.
        _share_ctx = _rls_ctx()
        # to_thread: the parametric engines are blocking (DB/duckdb work) —
        # they must never run inline on the event loop.
        raw = await asyncio.to_thread(
            _execute_raw_sql_report, report, param_values, limit_override,
            report_id, db, role, _share_ctx)

    else:
        # Standard dataset + pivot
        combined_filters = await _adb(_build_report_filters, report, param_values, db, report_id, extra_filters)
        _src_bindings = await _adb(_build_source_bindings, report, param_values, db, report_id)
        _diag_filters, _diag_bindings = combined_filters, _src_bindings
        lc = report.get("layout_config") or {}
        # Phase 131 deep-dive #13: shared+embedded paths also enforce RLS.
        _share_user_ctx = _rls_ctx()
        if lc.get("report_type") == "pivot":
            result = await asyncio.to_thread(
                _run_pivot_report_query, fed, report, combined_filters,
                row_limit, execution_id, role, user_ctx=_share_user_ctx,
                source_bindings=_src_bindings)
        else:
            result = await asyncio.to_thread(
                _run_report_query, fed, report, combined_filters,
                row_limit, execution_id, role,
                override_column_ids=override_column_ids,
                user_ctx=_share_user_ctx, source_bindings=_src_bindings)
        raw = result.to_dict() if hasattr(result, "to_dict") else result

    # Phase 0 reports rewire (2026-08-08): PV/FV artifact parity — every other
    # branch already produces {execution_id}.parquet; write one for PV/FV too
    # (additive; inline data unchanged).  Uses THIS dispatch's execution_id so
    # the envelope id and the artifact name agree.
    if ds_type in ("published_view", "federation_view"):
        await asyncio.to_thread(
            _persist_inline_result_artifact, db, report, raw,
            _rls_ctx().get("username") or "", execution_id)

    # ── ONE result contract for every source type ────────────────────────────
    # Normalise + materialise (bounded by row_limit) off the event loop.  If a
    # branch claims rows but produced no retrievable artifact, this RAISES
    # instead of silently rendering an empty page (fail-closed).
    from core.reports.contract import ReportEnvelope
    env = ReportEnvelope.from_raw(raw, source_type=ds_type,
                                  row_limit=row_limit, execution_id=execution_id)
    if materialize:
        await asyncio.to_thread(env.materialize, row_limit)
    else:
        await asyncio.to_thread(env.locate)
    # 2026-10-04: to_wire() copies every record through sanitize_for_json and
    # builds a positional ``rows`` list beside it -- seconds of pure Python
    # per million rows, and it used to run ON THE EVENT LOOP (an argument
    # evaluated before _adb's hop), freezing every other request on the pod
    # while one export ran (the loop watchdog's stack dumps, live 2026-10-04).
    wire = await asyncio.to_thread(env.to_wire)
    # 2026-10-30 -- the run's Diagnostics record, on every road this
    # dispatcher serves (never raises; a diagnostic is never why a run fails)
    from core.reports import diagnostics as _run_diag
    await asyncio.to_thread(
        _run_diag.record_report_run, db, report=report, report_id=report_id,
        execution_id=execution_id, param_values=param_values or {},
        combined_filters=_diag_filters, source_bindings=_diag_bindings,
        result=raw if isinstance(raw, dict) else wire, username=username,
        surface=_DISPATCH_SURFACE.get())
    # 2026-08-29: when the result is empty BECAUSE the executing principal has
    # no group scope on a ${user.*} report, say so — additively — instead of
    # returning a plain successful 0-row envelope.  Off the event loop because
    # report_references_user_vars may touch the DB or a SQL file.
    return await _adb(_disclose_empty_principal_scope,
                      wire, report, db, _rls_ctx())


@router.post("/api/shared-business-report/{token}/execute")
async def execute_shared_report(token: str, body: SharedExecuteRequest, request: Request):
    """PUBLIC — Execute a shared business report (no auth required).

    Phase 81 FIX 4+5+7: URL param parsing, relative date resolution, config row limits.
    """
    db = _require_db()
    fed = _require_federation()
    from core import config as _cfg

    share = await _adb(_validate_business_share_token, db, token)
    # D1: per-token budget — after validation (garbage tokens stay cheap
    # 404s), before any engine work.
    await _adb(_enforce_token_budget, "execute", token)

    report = await _adb(db.get_business_report, share["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Publish lifecycle (2026-08-17): a share-token caller is a CONSUMER by
    # definition — they execute the current published version; unpublished,
    # never published or archived => 410 (2026-09-15: the draft is NEVER
    # served to a token -- see _resolve_execution_report).
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, None, True)

    report_params = await _adb(_report_parameters_for_execution,
                               report, db, share["report_id"])

    # Phase 81 FIX 4: merge URL p_* params with body (body takes precedence)
    url_param_values = _parse_url_params(request, report_params)
    merged_param_values = {**url_param_values, **body.parameter_values}

    # F-P3A-02: an anonymous caller's limit_override may only NARROW the
    # author's stored bound — it used to pass through verbatim, where 0
    # means UNLIMITED (the author-only spelling).
    limit_override = _resolve_token_row_limit(body.limit_override, report, _cfg)

    try:
        merged_param_values = await _token_rule_defaults(db, report, merged_param_values)   # never the whole report
        _dispatch_on("shared")
        result = await _dispatch_report_execution(
            report, share["report_id"], merged_param_values,
            body.extra_filters, limit_override, db, fed)
        await _adb(db.increment_business_report_execution, share["report_id"])
        # D2: the one [br-serve] record for an anonymous share execute.
        _log_token_serve(result, report_id=share["report_id"], token=token,
                         surface="shared")
        await _adb(_stamp_token_canvas, result, report, token, share["report_id"], db)
        return _redact_token_result(
            await _astamp_served_version(result, _served_version))

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        logger.error("Shared report execution failed (token=%s): %s", token[:8], exc)
        raise HTTPException(status_code=500, detail="Report execution failed")


# ── Shared/Embedded Parameter LOV (no auth, token-validated) ─────────────────

async def _resolve_token_report_and_params(db, report_id: int) -> tuple:
    """(effective_report, parameters) for a TOKEN caller — the published
    snapshot's definition + parameter rows, exactly what the same token's
    GET and /execute serve (F-P3A-03: the LOV route used the DRAFT rows, so
    a post-publish draft edit made the published param ids unresolvable)."""
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    report, _v = await _adb(_resolve_execution_report, db, report, None, True)
    params = await _adb(_report_parameters_for_execution, report, db, report_id)
    return report, params


async def _get_token_param_values(report: dict, params: list,
                                  body: ParameterValuesRequest,
                                  user_ctx: Optional[Dict[str, Any]] = None) -> dict:
    """Shared logic for token-based parameter LOV fetching.

    ``report`` is the EFFECTIVE (published-resolved) dict and ``params`` its
    execution parameter rows — the same pair /execute runs with.

    2026-08-29 — ``user_ctx`` is the embed token's group scope when it has one.
    The dropdown MUST be filtered by the same principal as the grid: a prompt
    that lists regions the report will then refuse to show is both a leak (the
    distinct values ARE data) and a broken UX — the user picks a value and
    gets an empty report.
    """
    fed = _require_federation()
    db = _require_db()
    param = next((p for p in params if p["id"] == body.parameter_id), None)
    if not param:
        raise HTTPException(status_code=404, detail="Parameter not found")
    _short = _lov_short_circuit(param, (report or {}).get("id"), override=body.source)
    if _short is not None:
        return _short

    try:
        # Phase 131 deep-dive #13: shared-token LOV applies RLS against
        # the holder of the token (synthetic principal — same as exec).
        # 2026-08-29: when the token names groups, THAT is the principal —
        # same one /execute uses, so prompt and grid agree.
        _token_user_ctx = user_ctx or {"username": "shared-token",
                                       "role": "viewer",
                                       "rls_unresolved": True}
        return await _param_lov_from_column(
            report, params, param, body, fed, db, user_ctx=_token_user_ctx)
    except Exception as exc:
        # F-P3A-06: the raw exception text is server-internal — log it here,
        # hand the anonymous caller a generic reason.
        logger.warning("Token LOV fetch failed for param %d: %s", param["id"], exc)
        return {"values": [],
                "error": "List of values is unavailable for this parameter"}


@router.post("/api/shared-business-report/{token}/parameter-values")
async def get_shared_parameter_values(token: str, body: ParameterValuesRequest):
    """PUBLIC — Get LOV values for a shared report parameter (no auth)."""
    db = _require_db()
    share = await _adb(_validate_business_share_token, db, token)
    # D1: per-token budget on the public LOV surface too.
    await _adb(_enforce_token_budget, "parameter-values", token)
    report, params = await _resolve_token_report_and_params(db, share["report_id"])
    return await _get_token_param_values(report, params, body)


@router.post("/api/embedded-business-report/{token}/parameter-values")
async def get_embedded_parameter_values(token: str, body: ParameterValuesRequest):
    """PUBLIC — Get LOV values for an embedded report parameter (no auth)."""
    db = _require_db()
    t = await _adb(_validate_business_embed_token, db, token)
    # D1: per-token budget on the public LOV surface too.
    await _adb(_enforce_token_budget, "parameter-values", token)
    report, params = await _resolve_token_report_and_params(db, t["report_id"])
    return await _get_token_param_values(report, params, body,
                                         user_ctx=_embed_token_group_scope(t))


# ── Embed Tokens for Business Reports (Phase 58) ────────────────────────────

@router.post("/api/business-reports/{report_id}/embed-tokens")
async def create_embed_token(report_id: int, body: EmbedTokenCreateRequest,
                             user: dict = Depends(require_capability("reports.edit"))):
    """Create an embed token for a business report."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.embed_enabled:
        raise HTTPException(status_code=400, detail="Report embedding is disabled")

    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Only report owner or admin can create embed tokens")
    from api.published_views.management import _refuse_unpublished_report
    _refuse_unpublished_report(report, "an embed token")

    existing_tokens = await _adb(db.list_embed_tokens, report_id, report_type="business")
    max_tokens = _cfg.report_catalog.max_embed_tokens_per_report
    if len(existing_tokens) >= max_tokens:
        raise HTTPException(status_code=400,
                            detail=f"Max {max_tokens} embed tokens per report")

    days = body.expires_in_days or _cfg.report_catalog.embed_default_expiry_days
    expires_at = datetime.now(timezone.utc) + timedelta(days=days) if days else None

    # 2026-08-29 — optional per-group scope.  Validated HERE, at mint time,
    # because this is the only moment a human is present to fix a typo: a
    # mis-spelled group name is not an error later, it is a token whose
    # policies never match, which in a grant-shaped engine means the embed
    # quietly serves the UNFILTERED table.
    ad_groups = _normalise_group_names(body.allowed_ad_groups)
    user_groups = _normalise_group_names(body.allowed_user_groups)
    if user_groups:
        # A QueryStudio-native group MUST exist and be active — unlike an AD
        # group, whose directory we cannot interrogate from here.
        unknown: List[str] = []
        for name in user_groups:
            row = await _adb(db.get_user_group_by_name, name)
            if not row or not row.get("is_active"):
                unknown.append(name)
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=("Unknown or inactive user group(s): "
                        f"{', '.join(unknown)}"))

    token = await _adb(db.create_report_embed_token,
        report_id=report_id,
        created_by=username,
        expires_at=expires_at,
        report_type="business",
        allowed_ad_groups=ad_groups,
        allowed_user_groups=user_groups,
    )
    if ad_groups or user_groups:
        logger.info(
            "Embed token for business report %d scoped to groups ad=%s user=%s",
            report_id, ad_groups, user_groups)
    logger.info("Created embed token for business report %d by '%s'", report_id, username)
    # 2026-08-29 mint-time disclosure — an embed token minted WITHOUT groups
    # for a ${user.*} report executes with no group scope and returns zero
    # rows; this is the moment a human is present to add the scope.
    return _append_mint_warning(
        token, await _adb(_token_mint_scope_warning, report, db,
                          ad_groups + user_groups, "embed"))


@router.get("/api/business-reports/{report_id}/embed-tokens")
async def list_embed_tokens(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """List embed tokens for a business report."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Access denied")

    return {"tokens": await _adb(db.list_embed_tokens, report_id, report_type="business")}


@router.delete("/api/business-reports/embed-tokens/{token}")
async def revoke_embed_token(token: str, user: dict = Depends(require_capability("reports.edit"))):
    """Revoke an embed token for a business report."""
    db = _require_db()
    # Verify it's a business report embed token
    tok = await _adb(db.get_embed_token, token)
    if not tok or tok.get("report_type") != "business":
        raise HTTPException(status_code=404, detail="Token not found")

    # Ownership check: only report owner or admin can revoke
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    report = await _adb(db.get_business_report, tok.get("report_id"))
    if not report:
        # 2026-09-15: the token's report is gone, so there is no owner to
        # authorise against — before, ``if report and ...`` let ANY
        # authenticated caller revoke here.  Only an admin may clean up.
        if role not in ADMIN_TIER_ROLES:
            raise HTTPException(status_code=404, detail="Token not found")
    elif report.get("owner") != username and role not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Access denied")

    if not await _adb(db.revoke_embed_token, token):
        raise HTTPException(status_code=404, detail="Token not found")

    logger.info("Revoked embed token for business report by '%s'", username)
    return {"detail": "revoked"}


# ── Public Embed Endpoints (NO AUTH) ─────────────────────────────────────────

def _normalise_group_names(raw) -> List[str]:
    """Trim, drop blanks, de-duplicate case-insensitively, keep input order.

    Order is kept because the list is operator-authored and shown back in the
    admin UI; the case-insensitive de-dupe is what stops ``["Finance",
    "finance"]`` becoming two principal ids for one group.  The FIRST spelling
    wins — row-security matches ``group:<name>`` on the stored spelling, so
    silently re-casing an operator's entry could stop a policy matching.
    """
    out: List[str] = []
    seen: set = set()
    for item in (raw or []):
        name = str(item).strip()
        if not name:
            continue
        key = name.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(name)
    return out


def _embed_token_group_scope(token_row: Optional[dict]) -> Optional[Dict[str, Any]]:
    """The RLS principal an embed token grants, or ``None`` for no scope.

    2026-08-29.  An embed token used to carry NO identity at all, so every
    viewer of an embed saw the same rows and row-security ran with an
    unresolved low-privilege principal.  A token may now name the groups its
    viewers belong to — AD groups, QueryStudio-native user groups, or both —
    and those names become the principal's ``groups``.

    Both sources land in ONE list because ``UserContext.principal_ids`` emits
    ``group:<name>`` and does not care where the name came from; a policy bound
    to ``group:finance`` matches whether ``finance`` is an AD group or a
    ``user_groups`` row.

    Returns ``None`` when the token names no groups, and the caller then keeps
    its existing behaviour EXACTLY -- this is the fail-closed direction.  It
    must never return a principal with an EMPTY ``groups`` list: in this
    grant-shaped engine an unmatched policy leaves its table unfiltered, so a
    groupless-but-resolved principal drops the very bindings that were doing
    the restricting and SHIPS MORE ROWS than the unresolved one would.
    """
    if not token_row:
        return None
    groups = _normalise_group_names(
        list(token_row.get("allowed_ad_groups") or [])
        + list(token_row.get("allowed_user_groups") or []))
    if not groups:
        return None
    token = str(token_row.get("token") or "")
    return {
        "username": f"embed-token:{token[:8]}" if token else "embed-token",
        "role": "viewer",
        "groups": groups,
        "is_admin": False,
        # Resolved on purpose: the operator STATED this scope at mint time, so
        # the group bindings must apply rather than be refused as unknowable.
        "rls_unresolved": False,
    }


def _validate_business_embed_token(db, token: str) -> dict:
    """Validate an embed token: feature enabled, active, unexpired, business.

    F-P3A-04: the `report_catalog.embed_enabled` kill switch used to gate
    MINTING only — an operator flipping it off left every existing embed
    live.  It now governs consumption too (403), same as the share sibling.
    """
    from core import config as _cfg
    if not _cfg.report_catalog.embed_enabled:
        raise HTTPException(status_code=403, detail="Report embedding is disabled")
    t = db.get_embed_token(token)
    if not t or not t.get("is_active"):
        raise HTTPException(status_code=404, detail="Embed token not found or revoked")
    if t.get("report_type") != "business":
        raise HTTPException(status_code=404, detail="Embed token not found or revoked")
    if _token_expired(t.get("expires_at")):
        raise HTTPException(status_code=410, detail="Embed token has expired")
    return t


@router.get("/api/embedded-business-report/{token}")
async def get_embedded_report(token: str, request: Request = None):  # type: ignore[assignment]  -- FastAPI injects it; a direct caller may omit it
    """PUBLIC — Return business report metadata for an embed token (no auth)."""
    db = _require_db()
    _t0 = time.time()
    t = await _adb(_validate_business_embed_token, db, token)
    report = await _adb(db.get_business_report, t["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Publish lifecycle (2026-08-17): same consumer resolution as the
    # execute path — the embed page renders what it will run.
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, None, True)

    await _adb(db.increment_embed_token_access, token)

    parameters = await _adb(_enrich_source_parameters,
                            await _adb(_report_parameters_for_execution, report, db, t["report_id"]),
                            db, report)
    parameters = await _token_effective_defaults(db, report, parameters)   # the band pre-selects the default (2026-11-02)
    _record_token_call(request, token=token, token_type="embedded", report=report,
                       report_id=t["report_id"], endpoint="embed.meta", fmt="json", status=200,
                       rows=None, ms=int((time.time() - _t0) * 1000))
    # Same whitelist projection as the share GET — one rule, two doors
    # (F-P3A-01).
    return {
        "token": token,
        "report": _token_report_projection(report, parameters),
    }


@router.post("/api/embedded-business-report/{token}/execute")
async def execute_embedded_report(token: str, body: EmbedExecuteRequest, request: Request):
    """PUBLIC — Execute a business report via embed token (no auth).

    Phase 81 FIX 4+5+7: URL param parsing (p_ prefix), relative date resolution, config limits.
    """
    db = _require_db()
    fed = _require_federation()
    from core import config as _cfg

    _t0 = time.time()
    t = await _adb(_validate_business_embed_token, db, token)
    # D1: per-token budget — after validation, before any engine work.
    await _adb(_enforce_token_budget, "execute", token)
    report = await _adb(db.get_business_report, t["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Publish lifecycle (2026-08-17): embed-token callers are CONSUMERS —
    # current published version; unpublished, never published or archived
    # => 410 (2026-09-15: the draft is NEVER served to a token).
    report, _served_version = await _adb(
        _resolve_execution_report, db, report, None, True)

    report_params = await _adb(_report_parameters_for_execution,
                               report, db, t["report_id"])

    # Phase 81 FIX 4: merge URL p_* params with body (body takes precedence)
    url_param_values = _parse_url_params(request, report_params)
    merged_param_values = {**url_param_values, **body.parameter_values}

    # Phase 81 FIX 7 + F-P3A-02: the ONE token bound — narrow-only against
    # the author's stored row_limit, then capped by the embed config limit.
    limit_override = _resolve_token_row_limit(
        body.limit, report, _cfg,
        extra_cap=_cfg.business_reports.embed_row_limit)

    try:
        merged_param_values = await _token_rule_defaults(db, report, merged_param_values)   # never the whole report
        _dispatch_on("embed")
        result = await _dispatch_report_execution(
            report, t["report_id"], merged_param_values,
            None, limit_override, db, fed,
            user_ctx=_embed_token_group_scope(t))
        # D2: the one [br-serve] record for an anonymous embed execute —
        # carries the token's group scope so "who read what" names the
        # scope the rows were filtered with.
        _log_token_serve(result, report_id=t["report_id"], token=token,
                         surface="embedded", scope=_embed_token_group_scope(t))
        _rows = (result.get("total_rows") if isinstance(result, dict)
                 else getattr(result, "total_rows", None))
        _record_token_call(request, token=token, token_type="embedded", report=report,
                           report_id=t["report_id"], endpoint="embed.execute", fmt="json",
                           status=200, rows=_rows if isinstance(_rows, int) else None,
                           ms=int((time.time() - _t0) * 1000))
        await _adb(_stamp_token_canvas, result, report, token, t["report_id"], db)
        return _redact_token_result(
            await _astamp_served_version(result, _served_version))

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        logger.error("Embedded business report execution failed (token=%s): %s",
                     token[:8], exc)
        raise HTTPException(status_code=500, detail="Report execution failed")


# ── The report canvas on a share link / embed (2026-10-26) ───────────────────
#
# A canvas tile reads the run's STORED result through the microcube.  A
# token caller has no session, so the token run hands back an opaque HANDLE
# to its own result: the (token, result path, report, expiry) sealed with the
# platform's authenticated encryption (core.crypto -- the key every pod
# shares).  The token cube routes answer ONLY for a handle sealed for that
# very token and report, before it expires: a link can aggregate exactly the
# rows that same link was already served (same principal, same row security,
# same limits) and nothing else -- never another link's run, never a path a
# caller names.  Only 'drill' is offered (what tiles use).

_CANVAS_HANDLE_TTL_S = 2 * 3600


def _token_digest(token: str) -> str:
    import hashlib
    return hashlib.sha256((token or "").encode("utf-8")).hexdigest()


def _stamp_token_canvas(result: dict, report: dict, token: str, report_id: int, db) -> None:
    """Add ``canvas_handle`` + ``canvas_columns`` to a token run's answer when
    the (published) report has canvas tiles and the run left a stored result."""
    try:
        if not isinstance(result, dict) or not _has_canvas_tiles(report):
            return
        path = result.get("output_path") or ""
        if not path:
            return
        import json as _json
        from core.crypto import _ENC_PREFIX, encrypt_value
        if not _artifact_inside_results(path):
            logger.warning("[canvas] report %s result outside the results directory; no handle", report_id)
            return
        sealed = encrypt_value(_json.dumps({
            "t": _token_digest(token), "r": int(report_id), "p": str(path),
            "exp": int(time.time()) + _CANVAS_HANDLE_TTL_S}))
        # encrypt_value hands PLAINTEXT back when the crypto library is
        # missing: never issue an unsealed handle (it would be forgeable)
        if not isinstance(sealed, str) or not sealed.startswith(_ENC_PREFIX):
            logger.warning("[canvas] no sealed handle for report %s: encryption unavailable", report_id)
            return
        result["canvas_handle"] = sealed
        used = set()
        for tile in ((report.get("layout_config") or {}).get("canvas") or {}).get("tiles") or []:
            if isinstance(tile, dict):
                used.update(int(x) for x in tile.get("dimensions") or [] if str(x).lstrip("-").isdigit())
                used.update(int(m.get("column_id")) for m in tile.get("measures") or []
                            if isinstance(m, dict) and str(m.get("column_id")).lstrip("-").isdigit())
                if tile.get("series") is not None:
                    used.add(int(tile["series"]))
                if tile.get("kind") == "insight":
                    from core.reports.canvas_insights import insight_column_ids
                    used.update(insight_column_ids(tile))
        ds = db.get_dataset_full(report.get("dataset_id")) if report.get("dataset_id") else None
        result["canvas_columns"] = [
            {"id": c["id"], "physical_name": c.get("physical_name"),
             "label": c.get("friendly_name") or c.get("physical_name"),
             "data_type": c.get("data_type"), "column_type": c.get("column_type"),
             "aggregation": c.get("aggregation"), "format_pattern": c.get("format_pattern")}
            for c in (ds or {}).get("columns", []) or [] if int(c.get("id")) in used]
    except Exception as exc:                                  # noqa: BLE001
        # the rows are served regardless; the page says the tiles are unavailable
        logger.warning("[canvas] token handle for report %s not stamped: %s", report_id, exc)


def _open_canvas_handle(handle: str, token: str, report_id: int) -> str:
    """The stored-result path a handle names -- only for THIS token and
    report, before it expires.  Anything else is a 403 in words."""
    import json as _json
    from core.crypto import _ENC_PREFIX, decrypt_value
    refused = HTTPException(status_code=403, detail="This tile's run is not one this link made. Run the report again.")
    # decrypt_value PASSES THROUGH anything unencrypted (legacy plaintext
    # settings): a handle must be the sealed form, and must open
    if not isinstance(handle, str) or not handle.startswith(_ENC_PREFIX):
        raise refused
    try:
        opened = decrypt_value(handle)
        data = _json.loads(opened) if opened else None
    except Exception:                                         # noqa: BLE001
        raise refused
    if not isinstance(data, dict) or data.get("t") != _token_digest(token) or int(data.get("r", -1)) != int(report_id):
        raise HTTPException(status_code=403, detail="This tile's run is not one this link made. Run the report again.")
    if int(data.get("exp", 0)) < int(time.time()):
        raise HTTPException(status_code=409, detail="This run is too old to read its tiles. Run the report again.")
    path = str(data.get("p") or "")
    if not _artifact_inside_results(path):
        raise refused
    return path


def _artifact_inside_results(path: str) -> bool:
    """Is ``path`` a report result inside the results (downloads) directory?
    A handle can only ever name a report's own stored result -- never any
    other file on the pod, even sealed."""
    try:
        from core.config import paths as _paths
        base = Path(str(_paths.downloads_dir)).resolve()
        target = Path(path).resolve()
        return target != base and (base in target.parents)
    except Exception:                                         # noqa: BLE001
        return False


class TokenCubeRequest(CubeQueryRequest):
    handle: str


async def _token_cube(token: str, body: TokenCubeRequest, *, embed: bool) -> dict:
    db = _require_db()
    row = await _adb(_validate_business_embed_token if embed else _validate_business_share_token, db, token)
    await _adb(_enforce_token_budget, "cube", token)
    return await _cube_of_handle(token, int(row["report_id"]), body)


async def _cube_of_handle(handle_key: str, report_id: int, body: TokenCubeRequest) -> dict:
    """One tile of a token run: the handle must have been sealed under
    ``handle_key`` for ``report_id`` (``_open_canvas_handle``), the report
    must still have tiles, and only 'drill' is answered.  Shared by the
    report share / embed routes (key = the token) and the shared-dashboard
    tile route (key = the dashboard token's own namespace)."""
    from core import config as _cfg
    from core.reports import microcube as _mc
    db = _require_db()
    if body.operation not in ("drill", "insight"):
        raise HTTPException(status_code=400, detail="A link can only read its tiles.")
    report, _v = await _resolve_token_report_and_params(db, report_id)
    if not _has_canvas_tiles(report):
        raise HTTPException(status_code=404, detail="This report has no tiles.")
    artifact = Path(_open_canvas_handle(body.handle, handle_key, report_id))
    if not artifact.exists() and not _parts_result_exists(artifact):
        raise HTTPException(status_code=404, detail="This run's result is no longer available. Run the report again.")
    grain, group_cols = await asyncio.to_thread(_derive_artifact_grain, db, report)
    if body.operation == "insight":     # its own run only: a link never reads an earlier one
        from api.report_insights import answer_insight
        return await answer_insight(db, report, artifact, body, grain=grain, group_cols=group_cols, previous=None)
    kwargs = dict(measures=[m.model_dump() for m in body.measures],
                  path_filters=_cube_path_filters(body),
                  slicers=body.slicers or None, page=body.page,
                  artifact_grain=grain, artifact_group_columns=group_cols,
                  threads=_cfg.business_reports.microcube_threads,
                  memory_limit=_cfg.business_reports.microcube_memory_limit)
    if body.page_size is not None:
        kwargs["page_size"] = body.page_size
    try:
        drilled = await asyncio.to_thread(_mc.read_artifact_drill, artifact, dimensions=body.dimensions,
                                          sort_column=body.sort_column, sort_direction=body.sort_direction,
                                          derived=[d.model_dump() for d in body.derived], sort_abs=body.sort_abs,
                                          **kwargs)
        if body.max_points is None:
            return drilled
        # a link's long line is down-sampled like the signed-in one (JSON only)
        return await asyncio.to_thread(_finish_drill, drilled, body, None)
    except _mc.NonAdditiveMeasureError as exc:
        raise HTTPException(status_code=422, detail={
            "error": "non_additive_measures", "message": str(exc), "artifact_grain": grain,
            "refused": [{"column": c, "reason": r} for c, r in exc.refused.items()]})
    except _mc.ArtifactNotReady as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/api/shared-business-report/{token}/cube")
async def shared_report_cube(token: str, body: TokenCubeRequest):
    """PUBLIC -- a canvas tile of a share link's own run (the handle it was given)."""
    return await _token_cube(token, body, embed=False)


@router.post("/api/embedded-business-report/{token}/cube")
async def embedded_report_cube(token: str, body: TokenCubeRequest):
    """PUBLIC -- a canvas tile of an embed's own run (the handle it was given)."""
    return await _token_cube(token, body, embed=True)


# ── A finance report on a SHARED DASHBOARD (2026-10-26) ──────────────────────
#
# A dashboard share link (queries_api: GET /api/shared-dashboard/{token})
# used to render only its saved-query tiles; a finance-report tile said "not
# available in a shared view".  It now runs through the SAME road a report
# share link takes, decided once there: the published version (never the
# draft), the share link's principal (``execution_principal`` with NO caller
# -- row security stays REFUSED on a governed table, never served
# unfiltered), the narrow-only row bound, the redacted envelope, and the
# sealed canvas handle + cube for the report's tiles.
#
# What a dashboard link may reach is exactly the finance reports that are
# TILES OF THAT DASHBOARD: the tile is looked up by id and then BOUND to the
# token's dashboard (a tile of another dashboard is "not on this dashboard",
# a 404, never a hint).  The tile runs with ITS stored values, then the
# dashboard's filters by parameter NAME (core/dashboard_params.py, THE
# binding rule -- the signed-in page and the export apply the same one); a
# required value nobody set is refused in a sentence, never run unfiltered.
# A canvas handle is sealed under the dashboard token's OWN namespace, so a
# report share link's handle never opens here and this one never opens there.

def _dashboard_handle_key(token: str) -> str:
    """The key a dashboard link's canvas handles are sealed under."""
    return "dashboard:" + (token or "")


def _widget_of_shared_dashboard(db, share: dict, widget_id: int) -> dict:
    """The finance-report tile ``widget_id`` ON the dashboard ``share`` was
    minted for -- the scope check of every shared-dashboard tile route."""
    widget = db.get_widget(int(widget_id))
    if not widget or int(widget.get("dashboard_id") or -1) != int(share["dashboard_id"]):
        raise HTTPException(status_code=404, detail="This tile is not on the shared dashboard.")
    if widget.get("widget_type") != "business_report":
        raise HTTPException(status_code=400, detail=(
            "A shared dashboard link can show its finance report tiles and saved query tiles. "
            "This tile is a different kind and needs a signed-in user."))
    return widget


def _created_after(report_created, widget_created) -> bool:
    """Was the report row created AFTER the tile that names it?  Then it is
    not the report the tile was made for: that one was deleted and its id
    reused (2026-10-26 security review, "dangling source binding")."""
    def _dt(v):
        if isinstance(v, datetime):
            d = v
        elif isinstance(v, str) and v:
            d = datetime.fromisoformat(v.replace("Z", "+00:00"))
        else:
            return None
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    r, w = _dt(report_created), _dt(widget_created)
    if r is None or w is None:
        return False
    return r > w


def _report_tile_for_link(db, share: dict, widget: dict) -> dict:
    """The report a shared-dashboard tile may serve RIGHT NOW -- the gates a
    report share link passes, applied at request time (2026-10-26 security
    review).  In order: the sharing kill switch (the one
    ``_validate_business_share_token`` enforces); the report still exists;
    it is the report the tile was made for (not a reused id); it is
    published; and the dashboard share's CREATOR may share it by THE report
    share rule (``_may_mint_report_share``, the creator resolved headless
    through ``core.reports.authorization.build_principal`` -- least privilege
    on failure, so a creator whose rights went away is refused)."""
    from core import config as _cfg
    from core.reports import authorization as _authz
    if not _cfg.report_catalog.sharing_enabled:
        raise HTTPException(status_code=403, detail="Report sharing is disabled")
    report = db.get_business_report(int(widget["source_id"]))
    if not report:
        raise HTTPException(status_code=404, detail="This tile's report no longer exists.")
    if _created_after(report.get("created_at"), widget.get("created_at")):
        raise HTTPException(status_code=409, detail=(
            "This tile points at a report that was created after the tile was. "
            "Remove the tile and add the report again."))
    if not report.get("is_published"):
        raise HTTPException(status_code=403, detail=(
            "This report is not published, so a shared link cannot show it. Ask its owner to publish it."))
    creator = _authz.build_principal((share.get("created_by") or "").strip())
    if not _may_mint_report_share(report, creator):
        raise HTTPException(status_code=403, detail=(
            "This report cannot be shown on a shared link -- ask its owner to share it."))
    return report


def _link_filter_values(dashboard: Optional[dict], caller_values: Optional[dict]) -> dict:
    """The dashboard filter values a LINK caller may set: only filters the
    dashboard declares, and -- when a filter lists its allowed values --
    only one of them.  Over the filters' defaults."""
    from core.dashboard_params import default_filter_values
    declared = {f.get("name"): f for f in ((dashboard or {}).get("filters") or []) if isinstance(f, dict)}
    out = default_filter_values((dashboard or {}).get("filters"))
    for name, value in (caller_values or {}).items():
        f = declared.get(name)
        if f is None:
            raise HTTPException(status_code=400, detail=f"This dashboard has no filter named {name}.")
        options = [str(o) for o in (f.get("options") or [])]
        if options:
            given = value if isinstance(value, (list, tuple)) else [value]
            bad = [str(v) for v in given if str(v) not in options]
            if bad:
                raise HTTPException(status_code=400, detail=(
                    f"{f.get('label') or name} must be one of {', '.join(options)}."))
        out[name] = value
    return out


def _link_tile_values(widget: dict, declared: list, filter_values: dict) -> dict:
    """The values a tile runs with for a LINK caller: the dashboard's
    filters by NAME (``core.dashboard_params`` -- only declared names pass),
    and then the values the owner PINNED on the tile, which a link caller
    can never change (on the signed-in page the person's own filter bar
    wins; a link viewer is not that person)."""
    from core.dashboard_params import effective_widget_params
    out = effective_widget_params({"param_values": {}}, declared, filter_values)
    for k, v in (widget.get("param_values") or {}).items():
        if not (v is None or v == "" or (isinstance(v, (list, tuple)) and not v)):
            out[k] = v
    return out


def _declared_from_parameters(params: list) -> list:
    """The published parameter rows in the shape ``core.dashboard_params``
    binds by (name / label / required / default) -- the PUBLISHED rows, which
    is what the token run uses, not the author's draft."""
    return [{"name": p.get("name"), "label": p.get("label") or p.get("name"),
             "required": bool(p.get("is_required")), "default": p.get("default_value")}
            for p in params or [] if p.get("name")]


def _tile_values_missing(declared: list, values: dict) -> list:
    """Required parameters the tile still has no value for (same emptiness
    rule as ``_build_report_filters``: no value, '' or [] and no default)."""
    def _empty(v):
        return v is None or v == "" or (isinstance(v, (list, tuple)) and not v)
    return [p for p in declared if p.get("required") and _empty(values.get(p["name"]))
            and p.get("default") in (None, "")]


class SharedDashboardTileRequest(StrictRequestModel):
    """What an anonymous dashboard-link caller may send a tile: the
    dashboard's filter values by parameter NAME (only names the tile declares
    are passed on -- the binding rule) and nothing else."""
    filter_values: dict = {}


@router.post("/api/shared-dashboard/{token}/widgets/{widget_id}/execute")
async def execute_shared_dashboard_report(token: str, widget_id: int, body: SharedDashboardTileRequest,
                                          request: Request):
    """PUBLIC -- run a finance-report tile of a shared dashboard (no auth)."""
    from core import config as _cfg
    from core.dashboard_shares import validate_dashboard_share_token
    db = _require_db()
    fed = _require_federation()
    share = await _adb(validate_dashboard_share_token, db, token)
    widget = await _adb(_widget_of_shared_dashboard, db, share, widget_id)
    await _adb(_enforce_token_budget, "execute", token)
    report_id = int(widget["source_id"])
    report = await _adb(_report_tile_for_link, db, share, widget)
    # a dashboard-link caller is a CONSUMER: the current published version, or refused
    report, _served_version = await _adb(_resolve_execution_report, db, report, None, True)
    params = await _adb(_report_parameters_for_execution, report, db, report_id)

    dashboard = await _adb(db.get_dashboard, share["dashboard_id"])
    filter_values = _link_filter_values(dashboard, body.filter_values)
    declared = _declared_from_parameters(params)
    effective = _link_tile_values(widget, declared, filter_values)
    missing = _tile_values_missing(declared, effective)
    if missing:
        raise HTTPException(status_code=400, detail=(
            "This tile needs a value for " + ", ".join(p["label"] for p in missing)
            + ". Ask the dashboard owner to set it in the tile's settings or in the dashboard filters."))

    limit_override = _resolve_token_row_limit(None, report, _cfg)
    try:
        # the SAME call the report share link makes: no caller -> the share
        # link's principal (execution_principal: 'shared', unresolved)
        effective = await _token_rule_defaults(db, report, effective)                     # never the whole report
        _dispatch_on("dashboard_share")
        result = await _dispatch_report_execution(
            report, report_id, effective, None, limit_override, db, fed)
        await _adb(db.increment_business_report_execution, report_id)
        _log_token_serve(result, report_id=report_id, token=token, surface="shared-dashboard")
        await _adb(_stamp_token_canvas, result, report, _dashboard_handle_key(token), report_id, db)
        result = _redact_token_result(await _astamp_served_version(result, _served_version))
        if isinstance(result, dict):
            result["report"] = _token_report_projection(report, params)
            result["widget_id"] = int(widget["id"])
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After
        logger.error("Shared dashboard report tile failed (token=%s widget=%s): %s", token[:8], widget_id, exc)
        raise HTTPException(status_code=500, detail="Report execution failed")


@router.post("/api/shared-dashboard/{token}/widgets/{widget_id}/cube")
async def shared_dashboard_report_cube(token: str, widget_id: int, body: TokenCubeRequest):
    """PUBLIC -- a canvas tile of a shared dashboard's finance-report tile,
    from the run THIS dashboard link made (the handle it was given)."""
    from core.dashboard_shares import validate_dashboard_share_token
    db = _require_db()
    share = await _adb(validate_dashboard_share_token, db, token)
    widget = await _adb(_widget_of_shared_dashboard, db, share, widget_id)
    await _adb(_enforce_token_budget, "cube", token)
    report = await _adb(_report_tile_for_link, db, share, widget)
    return await _cube_of_handle(_dashboard_handle_key(token), int(report["id"]), body)


# ── Phase 113-B: Shared / Embedded Export Endpoints (PUBLIC, token-validated) ──

def _validate_share_for_export(db, token: str) -> tuple:
    """Validate a share token for export. Returns (share_dict, report_dict)."""
    share = _validate_business_share_token(db, token)
    report = db.get_business_report(share["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # Publish lifecycle (2026-08-17): token exports are consumer reads —
    # current published version (410 for archived).
    report, _ = _resolve_execution_report(db, report, None, True)
    return share, report


def _validate_embed_for_export(db, token: str) -> tuple:
    """Validate an embed token for export. Returns (embed_dict, report_dict)."""
    t = _validate_business_embed_token(db, token)
    report = db.get_business_report(t["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    # Publish lifecycle (2026-08-17): same consumer fork as the share path.
    report, _ = _resolve_execution_report(db, report, None, True)
    return t, report


async def _execute_for_token_export(report: dict, report_id: int, params_json: str,
                                     limit: int, db, fed,
                                     user_ctx: Optional[Dict[str, Any]] = None) -> tuple:
    """Execute a report for token-based export. Returns (rows, columns).

    The dispatcher returns the unified envelope with ``data`` (records)
    already materialised — bounded by the row limit and read off the event
    loop — so no per-source shape handling and no full-table Python loops
    survive here.

    2026-08-29 — ``user_ctx`` carries the embed token's group scope when it has
    one.  An export that ignored it would hand the viewer a FILE containing
    rows the same token's on-screen view filters out, which is the worse half
    of the leak: the file outlives the session and gets forwarded.
    """
    from core import config as _cfg
    if not _cfg.business_reports.share_export_enabled:
        raise HTTPException(status_code=403, detail="Export is disabled for shared/embedded reports")
    # F-P3A-02: same narrow-only token bound as the interactive routes —
    # the caller can shrink the export, never grow it past the author's
    # stored row_limit; share_export_row_limit caps again.
    row_limit = _resolve_token_row_limit(
        limit if limit and limit > 0 else None, report, _cfg,
        extra_cap=_cfg.business_reports.share_export_row_limit)
    param_values = _parse_export_params(params_json)
    param_values = await _token_rule_defaults(db, report, param_values)                   # never the whole report
    _dispatch_on("token_export")
    result = await _dispatch_report_execution(
        report, report_id, param_values, None, row_limit, db, fed,
        user_ctx=user_ctx)
    rows: list = result.get("data", []) if isinstance(result, dict) else []
    columns: list = result.get("columns", []) if isinstance(result, dict) else []
    # row_limit returned so the download handler can DISCLOSE truncation
    # (X-QS-Truncated header + [br-serve] line) — 2026-08-05 audit.
    # row_limit == 0 is the author-sanctioned UNLIMITED spelling — never a
    # `[:0]` slice (that fold is the product's signature bug class).
    return (rows[:row_limit] if row_limit > 0 else rows), columns, row_limit


def _export_filename(name: str, ext: str) -> str:
    """Build a timestamped export filename."""
    return f"{_sanitize_export_filename(name)}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.{ext}"


_EXPORT_MEDIA_TYPES = {
    "pdf": "application/pdf",
    "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "csv": "text/csv; charset=utf-8",
}
_EXPORT_EXTENSIONS = {"pdf": "pdf", "excel": "xlsx", "csv": "csv"}


def _build_token_export_bytes(fmt: str, report: dict, rows: list, columns: list,
                              effective_limit: int, disclosure: str,
                              truncated: bool) -> bytes:
    """A share/embed export document, built on a worker thread (2026-10-04:
    the CSV writer, the pivot workbook and the style read ran on the event
    loop).  ``rows`` is already cut to the document."""
    from core import config as _cfg
    db = _require_db()
    report_name = report.get("name", "Report")
    _rc_notes: list = []
    if fmt == "csv":
        # GAP-2 (2026-08-30): running-calculation columns — parity with the
        # authenticated CSV export (an embedded viewer sees the calcs on
        # screen; the file it downloads must carry the same figures).
        _exp_rows, _exp_cols = rows, columns
        if (report.get("running_calculations")
                and ((report.get("layout_config") or {}).get("report_type")) != "pivot"):
            _tk_ds_cols = _extract_style_and_formats(report, db)[5]
            _exp_rows, _exp_cols = _augment_rows_with_running_calcs(
                rows, columns, report, _tk_ds_cols, _rc_notes)
        return _render_csv_bytes(_exp_rows, _exp_cols)

    header_bg, header_text, neg_fmt, stripe_rows, col_fmt_map, ds_cols = _extract_style_and_formats(report, db)
    from core.reports.format_rules import attach_cutoffs
    fmt_rules = attach_cutoffs(_extract_fmt_rules(report), rows=rows, columns=columns)
    lc = report.get("layout_config") or {}
    is_pivot = lc.get("report_type") == "pivot" and lc.get("pivot_config")

    # BANDED DOCUMENT (2026-08-30): a shared/embedded viewer sees the
    # banded report on screen — the file it downloads must carry the
    # same bands.  Inert for reports declaring nothing.
    _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)
    _col_styles = _extract_column_styles(report, columns)
    _pdf_layout = _extract_pdf_layout(report, _cfg.business_reports.pdf_page_size)
    # GAP-2 (2026-08-30): running-calculation columns — see the
    # authenticated PDF/Excel exports.  Inert without declared calcs.
    _exp_rows, _exp_cols = rows, columns
    if not is_pivot:
        if _band_spec:
            _exp_rows = _section_sort_rows(_exp_rows, _band_spec["defs"])
        _exp_rows, _exp_cols = _augment_rows_with_running_calcs(
            _exp_rows, columns, report, ds_cols)
        disclosure += _running_calc_disclosure_suffix(_exp_cols is not columns, truncated)
        disclosure += _banded_disclosure_suffix(bool(_band_spec), truncated)
    if _band_notes:
        disclosure += " " + " ".join(_band_notes)
    if _rc_notes:
        # Same rule for a running calculation that could not render:
        # a recipient holding a report missing a designed column must
        # be told, not left to compare it against the author's intent.
        disclosure += " " + " ".join(_rc_notes)

    if is_pivot:
        matrix = _build_pivot_matrix(rows, lc["pivot_config"], ds_cols)
        disclosure += _pivot_truncation_suffix(matrix)
        if fmt == "pdf":
            return _render_pivot_pdf_bytes(
                matrix, report_name, header_bg, header_text,
                _cfg.business_reports.pdf_page_size,
                neg_fmt, col_fmt_map, disclosure_text=disclosure, fmt_rules=fmt_rules)
        return _render_pivot_excel_bytes(matrix, report_name, header_bg, header_text,
                                         neg_fmt, stripe_rows, col_fmt_map,
                                         disclosure_text=disclosure, fmt_rules=fmt_rules)
    if fmt == "pdf":
        return _render_pdf_bytes(
            _exp_rows, _exp_cols, report_name, header_bg, header_text,
            neg_fmt, col_fmt_map,
            ((_pdf_layout or {}).get("page_size")
             or _cfg.business_reports.pdf_page_size),
            disclosure_text=disclosure,
            **({"fmt_rules": fmt_rules} if fmt_rules else {}),
            **({"sections": _band_spec} if _band_spec else {}),
            **({"column_styles": _col_styles} if _col_styles else {}),
            **({"pdf_layout": _pdf_layout} if _pdf_layout else {}))
    return _render_excel_bytes(
        _exp_rows, _exp_cols, report_name, header_bg, header_text,
        neg_fmt, stripe_rows, col_fmt_map, disclosure_text=disclosure,
        **({"fmt_rules": fmt_rules} if fmt_rules else {}),
        **({"sections": _band_spec} if _band_spec else {}),
        **({"column_styles": _col_styles} if _col_styles else {}))


async def _download_token_export(
    token_type: str, token: str, fmt: str,
    params_json: str, limit: int, request: Optional[Request] = None,
) -> StreamingResponse:
    """Unified handler for all 6 shared/embedded export endpoints.

    token_type: "shared" | "embedded"
    fmt: "pdf" | "excel" | "csv"
    request: the HTTP request (the call record reads the client); the six
    routes pass it by NAME.  Direct callers (tests, internal) may omit it --
    the positional contract (token_type, token, fmt, params_json, limit) is
    the one every caller before 2026-10-17 used and it stays.

    2026-10-04: a PDF carries at most ``pdf_max_rows`` rows (the token's own
    narrow-only bound applies first; the execution asks for one row past
    the ceiling so a cut is KNOWN and disclosed), and the document is built
    on a worker thread and rendered in a budgeted child process.  Token
    exports stay bounded by ``share_export_row_limit`` and in memory --
    they are never registered (see the decision block above
    _export_retain_max_days).
    """
    # The deployment's format allowlist applies to a public token download
    # exactly as it does to an authenticated one -- a format switched off
    # must not stay reachable through a share link, which is the wider
    # surface of the two.
    _enforce_export_format(fmt)
    db = _require_db()
    fed = _require_federation()
    _t0 = time.time()

    if token_type == "shared":
        token_info, report = await _adb(_validate_share_for_export, db, token)
    else:
        token_info, report = await _adb(_validate_embed_for_export, db, token)
    # D1: per-token budget on all 6 public download routes (one chokepoint).
    await _adb(_enforce_token_budget, "download", token)

    report_id = token_info.get("report_id") or report.get("id")
    # An embed token's group scope must reach the EXPORT too — see
    # _execute_for_token_export.  Share tokens carry no scope, so this is
    # None for them and their behaviour is unchanged.
    _export_ctx = (_embed_token_group_scope(token_info)
                   if token_type == "embedded" else None)
    # The PDF ceiling: ask (narrow-only) for one row past it.
    _ceiling = _pdf_max_rows() if fmt == "pdf" else 0
    _ask = limit
    if _ceiling > 0 and (limit <= 0 or limit > _ceiling):
        _ask = _ceiling + 1
    rows, columns, effective_limit = await _execute_for_token_export(
        report, report_id, params_json, _ask, db, fed,
        user_ctx=_export_ctx)

    # 2026-08-09 caps-throttle-not-refuse: token exports cut at
    # share_export_row_limit — that cut is stated ON the document too
    # (PDF banner / Excel line), not only in the X-QS-* headers, so a
    # forwarded file carries its own truth.  CSV stays pure data (an in-file
    # note would corrupt parsers); its disclosure is the header + log line.
    _over = _ceiling > 0 and effective_limit == _ceiling + 1
    if _over:
        _cut = len(rows) > _ceiling
        rows = rows[:_ceiling]
        effective_limit = _ceiling
        _truncated = _cut
        disclosure = _pdf_ceiling_disclosure(len(rows), _ceiling) if _cut else ""
    else:
        _truncated = bool(effective_limit) and len(rows) >= effective_limit
        disclosure = _export_truncation_disclosure(fmt, len(rows), effective_limit)

    try:
        out_bytes = await _run_export_work(
            _build_token_export_bytes, fmt, report, rows, columns,
            effective_limit, disclosure, _truncated, username=f"token:{token[:8]}")
    except HTTPException:
        raise
    except PdfRendererUnavailable as exc:
        raise HTTPException(status_code=501, detail=str(exc))
    except PdfRenderRefused as exc:
        raise _pdf_refusal(exc)

    report_name = report.get("name", "Report")
    filename = _export_filename(report_name, _EXPORT_EXTENSIONS[fmt])
    try:
        await _adb(_db_manager.audit, token_type, f"export_{token_type}_{fmt}", resource_type="business_report",
                   resource_id=str(report_id), detail=f"token={token[:8]}")
    except Exception as e:
        logger.warning("Failed to audit public export (report_id=%s, format=%s): %s", report_id, fmt, e)
    # 2026-08-05 audit: token exports disclose truncation like every other
    # export path (X-QS-* headers) and emit the one [br-serve] line.
    from core.reports.serve_log import log_report_serve
    log_report_serve(report_id=report_id, user=f"token:{token[:8]}",
                     rls="token", surface=token_type, fmt=fmt, rows=len(rows),
                     row_limit=effective_limit,
                     truncated=_truncated)
    # DELIBERATELY NOT registered in the Download Centre: token exports run
    # under an ANONYMOUS principal — see the decision block above
    # _export_retain_max_days (an owner-less DownloadFile row fails OPEN in
    # _enforce_download_ownership, and a registered row would outlive token
    # revocation).  Inline streaming stays the whole contract here.
    _record_token_call(request, token=token, token_type=token_type, report=report,
                       report_id=report_id, endpoint=f"{'share' if token_type == 'shared' else 'embed'}.download",
                       fmt=fmt, status=200, rows=len(rows), ms=int((time.time() - _t0) * 1000),
                       response_bytes=len(out_bytes))
    return StreamingResponse(_byte_chunks(out_bytes), media_type=_EXPORT_MEDIA_TYPES[fmt],
                             headers=_export_response_headers(
                                 filename, len(rows), effective_limit,
                                 truncated=_truncated))


@router.get("/api/business-reports/shared/{token}/download-pdf")
async def download_shared_report_pdf(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=200000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download shared report as PDF (token-validated, no auth)."""
    return await _download_token_export("shared", token, "pdf", params_json, limit, request=request)


@router.get("/api/business-reports/shared/{token}/download-excel")
async def download_shared_report_excel(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=500000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download shared report as Excel (token-validated, no auth)."""
    return await _download_token_export("shared", token, "excel", params_json, limit, request=request)


@router.get("/api/business-reports/shared/{token}/download-csv")
async def download_shared_report_csv(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=500000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download shared report as CSV (token-validated, no auth)."""
    return await _download_token_export("shared", token, "csv", params_json, limit, request=request)


@router.get("/api/business-reports/embedded/{token}/download-pdf")
async def download_embedded_report_pdf(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=200000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download embedded report as PDF (token-validated, no auth)."""
    return await _download_token_export("embedded", token, "pdf", params_json, limit, request=request)


@router.get("/api/business-reports/embedded/{token}/download-excel")
async def download_embedded_report_excel(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=500000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download embedded report as Excel (token-validated, no auth)."""
    return await _download_token_export("embedded", token, "excel", params_json, limit, request=request)


@router.get("/api/business-reports/embedded/{token}/download-csv")
async def download_embedded_report_csv(
    token: str, params_json: str = Query(default="", alias="params"),
    limit: int = Query(default=0, ge=0, le=500000),
    request: Request = None,  # type: ignore[assignment]  -- FastAPI injects it; a direct caller (fn(tok, "", 0)) may omit it
):
    """PUBLIC — Download embedded report as CSV (token-validated, no auth)."""
    return await _download_token_export("embedded", token, "csv", params_json, limit, request=request)


# 2026-10-27 -- the seeded IB P&L demo (POST /api/admin/seed-sample-reports: a
# dataset of 30 made-up rows in a VALUES query + six reports) is REMOVED (the
# owner: "sample reports should be based on real tables and queries, not seeded
# anymore").  A sample is now any real report its owner marks ``is_sample``
# (PUT /api/business-reports/{id}); "Show samples" lists them.


# ════════════════════════════════════════════════════════════════════
# Phase 157 (2026-06-26) -- Report Permissions API surface
# ════════════════════════════════════════════════════════════════════
#
# Single chokepoint for grants, access requests, certification, audit
# log, and "who has access" panel.  All endpoints route through
# ``core.business_report_permissions`` so a future security audit
# touches ONE file, not five.


from pydantic import BaseModel as _PermBaseModel, Field as _PermField  # noqa: E402


class _GrantBody(_PermBaseModel):
    username:    Optional[str] = None
    group_id:    Optional[int] = None
    level:       str = _PermField("view")
    grant_until: Optional[datetime] = None
    reason:      Optional[str] = None


class _AccessRequestBody(_PermBaseModel):
    requested_level: str = _PermField("view")
    reason:          Optional[str] = None


class _AccessDecisionBody(_PermBaseModel):
    decision_note: Optional[str] = None
    # Optional grant_until on approval -- contractor / time-bound access.
    grant_until:   Optional[datetime] = None


class _CertRequestBody(_PermBaseModel):
    rationale: Optional[str] = None


class _CertDecisionBody(_PermBaseModel):
    review_note: Optional[str] = None


def _br_or_404(report_id: int) -> dict:
    report = _db_manager.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404,
                             detail=f"Business report {report_id} not found")
    return report


def _require_share_level(report: dict, user: dict) -> None:
    """Phase 157 -- only owner/admin can grant access or modify
    permissions on a report.  Hides the report when the user can't even
    view it (404 instead of 403) so we don't leak existence."""
    from core import business_report_permissions as _perm
    if not _perm.can_view(report, user, _db_manager):
        raise HTTPException(status_code=404, detail="report not found")
    if not _perm.can_share(report, user, _db_manager):
        raise HTTPException(
            status_code=403,
            detail="permission management requires owner / admin role",
        )


# ── Effective access panel ──────────────────────────────────────────


@router.get("/api/business-reports/{report_id}/permissions")
async def br_permissions_get(report_id: int,
                              user: dict = Depends(require_capability("reports.view"))):
    """Return the effective access surface for the report's
    Permissions tab in the editor.  Visible to anyone who can view
    the report; only owner sees grant + token detail."""
    from core import business_report_permissions as _perm
    report = await _adb(_br_or_404, report_id)
    if not _perm.can_view(report, user, _db_manager):
        raise HTTPException(status_code=404, detail="report not found")
    snapshot = _perm.effective_access(report, _db_manager)
    snapshot["my_level"] = _perm.effective_level(
        report, user, _db_manager,
    )
    snapshot["can_share"] = _perm.can_share(report, user, _db_manager)
    if not snapshot["can_share"]:
        # Hide grant + token detail from non-share-permitted viewers.
        snapshot.pop("grants", None)
        snapshot.pop("share_tokens", None)
        snapshot.pop("embed_tokens", None)
    return snapshot


# ── Grant CRUD ──────────────────────────────────────────────────────


@router.post("/api/business-reports/{report_id}/permissions/grants")
async def br_grant_add(report_id: int, body: _GrantBody,
                        user: dict = Depends(require_capability("reports.edit"))):
    from core import business_report_permissions as _perm
    report = await _adb(_br_or_404, report_id)
    _require_share_level(report, user)
    try:
        return _perm.add_grant(
            report_id=report_id,
            username=body.username, group_id=body.group_id,
            level=body.level, granted_by=user.get("username", "system"),
            grant_until=body.grant_until, reason=body.reason,
            db_manager=_db_manager,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.delete("/api/business-reports/permissions/grants/{grant_id}")
async def br_grant_remove(grant_id: int,
                           user: dict = Depends(require_capability("reports.edit"))):
    from core import business_report_permissions as _perm
    grant = await _adb(_db_manager.get_br_grant, grant_id)
    if not grant:
        raise HTTPException(status_code=404, detail="grant not found")
    report = await _adb(_br_or_404, int(grant["report_id"]))
    _require_share_level(report, user)
    ok = _perm.remove_grant(
        grant_id=grant_id, actor=user.get("username", "system"),
        db_manager=_db_manager,
    )
    if not ok:
        raise HTTPException(status_code=500, detail="remove failed")
    return {"ok": True}


# ── Access requests ─────────────────────────────────────────────────


@router.post("/api/business-reports/{report_id}/permissions/access-request")
async def br_access_request(report_id: int, body: _AccessRequestBody,
                             user: dict = Depends(require_capability("reports.edit"))):
    """Any logged-in user can request access (even if they can't see
    the report yet) -- but they have to know the id.  Owner sees the
    request via the queue endpoint below."""
    from core import business_report_permissions as _perm
    # Use get_business_report directly; we don't gate on can_view here.
    report = await _adb(_db_manager.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404,
                             detail=f"Business report {report_id} not found")
    try:
        return _perm.request_access(
            report_id=report_id,
            requester=user.get("username", "system"),
            requested_level=body.requested_level, reason=body.reason,
            db_manager=_db_manager,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/api/business-reports/{report_id}/permissions/access-requests")
async def br_access_requests_list(report_id: int,
                                    status: Optional[str] = None,
                                    user: dict = Depends(require_capability("reports.view"))):
    report = await _adb(_br_or_404, report_id)
    _require_share_level(report, user)
    return {"entries": await _adb(_db_manager.list_br_access_requests, report_id=report_id, status=status, limit=200)}


@router.post("/api/business-reports/permissions/access-requests/{request_id}/approve")
async def br_access_request_approve(request_id: int,
                                      body: _AccessDecisionBody,
                                      user: dict = Depends(require_capability("reports.edit"))):
    from core import business_report_permissions as _perm
    req = await _adb(_db_manager.get_br_access_request, request_id)
    if not req:
        raise HTTPException(status_code=404, detail="request not found")
    report = await _adb(_br_or_404, int(req["report_id"]))
    _require_share_level(report, user)
    try:
        grant = _perm.approve_access(
            request_id=request_id,
            decided_by=user.get("username", "system"),
            decision_note=body.decision_note,
            grant_until=body.grant_until,
            db_manager=_db_manager,
        )
        return {"ok": True, "grant": grant}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/api/business-reports/permissions/access-requests/{request_id}/deny")
async def br_access_request_deny(request_id: int,
                                   body: _AccessDecisionBody,
                                   user: dict = Depends(require_capability("reports.edit"))):
    from core import business_report_permissions as _perm
    req = await _adb(_db_manager.get_br_access_request, request_id)
    if not req:
        raise HTTPException(status_code=404, detail="request not found")
    report = await _adb(_br_or_404, int(req["report_id"]))
    _require_share_level(report, user)
    try:
        _perm.deny_access(
            request_id=request_id,
            decided_by=user.get("username", "system"),
            decision_note=body.decision_note,
            db_manager=_db_manager,
        )
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ── Certification workflow ──────────────────────────────────────────


@router.post("/api/business-reports/{report_id}/permissions/certification-request")
async def br_cert_request(report_id: int, body: _CertRequestBody,
                            user: dict = Depends(require_capability("reports.edit"))):
    from core import business_report_permissions as _perm
    report = await _adb(_br_or_404, report_id)
    if not _perm.can_view(report, user, _db_manager):
        raise HTTPException(status_code=404, detail="report not found")
    return _perm.request_certification(
        report_id=report_id,
        requested_by=user.get("username", "system"),
        rationale=body.rationale,
        db_manager=_db_manager,
    )


@router.get("/api/admin/business-reports/certification-queue")
async def br_cert_queue(status: Optional[str] = "pending",
                         user: dict = Depends(require_capability("reports.manage"))):
    return {"entries": await _adb(_db_manager.list_br_cert_requests, status=status, limit=200)}


@router.post("/api/admin/business-reports/certification-requests/{request_id}/approve")
async def br_cert_approve(request_id: int, body: _CertDecisionBody,
                            user: dict = Depends(require_capability("reports.manage"))):
    from core import business_report_permissions as _perm
    try:
        _perm.approve_certification(
            request_id=request_id,
            reviewed_by=user.get("username", "admin"),
            review_note=body.review_note,
            db_manager=_db_manager,
        )
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/api/admin/business-reports/certification-requests/{request_id}/deny")
async def br_cert_deny(request_id: int, body: _CertDecisionBody,
                         user: dict = Depends(require_capability("reports.manage"))):
    from core import business_report_permissions as _perm
    try:
        _perm.deny_certification(
            request_id=request_id,
            reviewed_by=user.get("username", "admin"),
            review_note=body.review_note,
            db_manager=_db_manager,
        )
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ── Audit log + admin queue ─────────────────────────────────────────


@router.get("/api/business-reports/{report_id}/permissions/audit")
async def br_perm_audit(report_id: int, limit: int = 200,
                          user: dict = Depends(require_capability("reports.view"))):
    report = await _adb(_br_or_404, report_id)
    _require_share_level(report, user)
    return {"entries": await _adb(_db_manager.list_br_permission_events, report_id=report_id, limit=limit)}


@router.get("/api/admin/business-reports/access-request-queue")
async def br_access_queue(status: Optional[str] = "pending",
                            user: dict = Depends(require_capability("reports.manage"))):
    """Admin-wide queue of pending access requests across ALL reports.
    Owners can see per-report via the non-admin endpoint; admins get
    the full firehose for review."""
    return {"entries": await _adb(_db_manager.list_br_access_requests, report_id=None, status=status, limit=500)}

