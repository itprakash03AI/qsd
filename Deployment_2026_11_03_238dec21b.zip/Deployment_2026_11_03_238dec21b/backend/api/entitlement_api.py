"""Data entitlement admin API (2026-10-24, docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html).

The engine is ``core/row_security/entitlement.py``; these routes only author
its rows.  Every write invalidates the row-security caches (the resolver's
and the entitlement memo) and is audited.

  GET    /api/admin/row-security/entitlements/dimensions
  POST   /api/admin/row-security/entitlements/dimensions
  PUT    /api/admin/row-security/entitlements/dimensions/{id}
  DELETE /api/admin/row-security/entitlements/dimensions/{id}
  GET    /api/admin/row-security/entitlements/dimensions/{id}/tables
  GET    /api/admin/row-security/entitlements/values
  POST   /api/admin/row-security/entitlements/values
  DELETE /api/admin/row-security/entitlements/values/{id}
  POST   /api/admin/row-security/entitlements/values/upload?dimension_id=&mode=merge|replace&dry_run=
  GET    /api/me/entitlements                       what the caller holds
"""
from __future__ import annotations

import asyncio
import csv
import io
import logging
from datetime import date
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from pydantic import BaseModel

from api.deps import get_current_user, require_admin, require_capability
from core.audit import audit_event
from core.row_security import entitlement as ent

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin/row-security/entitlements", tags=["row-security"])
me_router = APIRouter(prefix="/api/me", tags=["row-security"])

_db_manager = None


def set_entitlement_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _invalidate() -> None:
    try:
        from core.row_security.api import invalidate_cache
        invalidate_cache()          # also clears the entitlement memo
    except Exception as exc:
        logger.warning("entitlement: cache invalidate failed: %s", exc)
        ent.invalidate()


# ── schemas ─────────────────────────────────────────────────────────────────

class DimensionColumn(BaseModel):
    column_name: str
    connection_id: Optional[int] = None
    value_type: str = "text"


class DimensionCreate(BaseModel):
    name: str
    description: Optional[str] = None
    no_value_behaviour: str = ent.SEE_NOTHING
    is_active: bool = True
    columns: List[DimensionColumn]


class DimensionUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    no_value_behaviour: Optional[str] = None
    is_active: Optional[bool] = None
    columns: Optional[List[DimensionColumn]] = None


class ValueRow(BaseModel):
    dimension_id: int
    principal_type: str
    principal_id: str
    value: Optional[str] = None
    is_all: bool = False
    valid_from: Optional[date] = None
    valid_to: Optional[date] = None


class ValuesAdd(BaseModel):
    values: List[ValueRow]


# ── validation: every refusal named in ONE 422 ─────────────────────────────

def _check_dimension(name: Optional[str], rule: Optional[str],
                     columns: Optional[List[DimensionColumn]], creating: bool) -> None:
    problems: List[str] = []
    if creating or name is not None:
        if not (name or "").strip():
            problems.append("name is required")
    if rule is not None and rule not in ent.NO_VALUE_RULES:
        problems.append(f"no_value_behaviour must be one of {', '.join(ent.NO_VALUE_RULES)}")
    if columns is not None:
        if creating and not columns:
            problems.append("a dimension needs at least one column name")
        seen = set()
        for c in columns:
            n = (c.column_name or "").strip()
            if not n:
                problems.append("a column name is empty")
                continue
            key = (n.lower(), c.connection_id)
            if key in seen:
                problems.append(f"column {n!r} is listed twice")
            seen.add(key)
            if c.value_type not in ent.VALUE_TYPES:
                problems.append(f"column {n!r}: value_type must be one of {', '.join(ent.VALUE_TYPES)}")
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems))


def _check_value(r: Dict[str, Any], dims: Dict[int, Dict[str, Any]], where: str = "") -> Optional[str]:
    """None when the row is valid, else the sentence naming why not."""
    d = dims.get(int(r.get("dimension_id") or 0))
    if d is None:
        return f"{where}dimension {r.get('dimension_id')} does not exist"
    if r.get("principal_type") not in ent.PRINCIPAL_TYPES:
        return f"{where}principal_type must be one of {', '.join(ent.PRINCIPAL_TYPES)}"
    if not str(r.get("principal_id") or "").strip():
        return f"{where}principal_id is required"
    if not r.get("is_all") and (r.get("value") is None or str(r.get("value")).strip() == ""):
        return f"{where}a value is required (or is_all)"
    if r.get("is_all"):
        r["value"] = None
    elif any(c.get("value_type") == "integer" for c in d["columns"]):
        try:
            ent.render_value(r["value"], "integer")
        except Exception:
            return f"{where}{r['value']!r} is not a whole number (dimension {d['name']} has an integer column)"
    vf, vt = r.get("valid_from"), r.get("valid_to")
    if vf and vt and vt < vf:
        return f"{where}valid_to is before valid_from"
    return None


def _dims_by_id() -> Dict[int, Dict[str, Any]]:
    return {int(d["id"]): d for d in _db().list_entitlement_dimensions()}


# ── dimensions ──────────────────────────────────────────────────────────────

@router.get("/dimensions")
async def list_dimensions(user: dict = Depends(require_capability("row_security.manage"))) -> Dict[str, Any]:
    dims = await _adb(_db().list_entitlement_dimensions)
    return {"items": dims, "enabled": ent.enabled(),
            "inline_max_values": ent.inline_max_values()}


@router.post("/dimensions")
async def create_dimension(body: DimensionCreate, request: Request,
                           user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    _check_dimension(body.name, body.no_value_behaviour, body.columns, creating=True)
    existing = await _adb(_db().list_entitlement_dimensions, include_inactive=True)
    for d in existing:
        if d["name"].lower() == body.name.strip().lower():
            if d.get("is_active") is False:     # a switched-off dimension keeps its name
                from core.config_active import name_held_message
                raise HTTPException(status_code=409, detail=name_held_message(
                    "entitlement dimension", d["name"]))
            raise HTTPException(status_code=409, detail=f"A dimension named {body.name!r} already exists")
    data = body.model_dump(exclude={"columns"})
    data["name"] = body.name.strip()
    created = await _adb(_db().create_entitlement_dimension, data,
                         [c.model_dump() for c in body.columns], user.get("username") or "")
    _invalidate()
    audit_event(_db(), user, request, "entitlement_dimension_created",
                resource_type="row_security", resource_id=created["id"],
                details={"name": created["name"], "columns": [c["column_name"] for c in created["columns"]],
                         "no_value_behaviour": created.get("no_value_behaviour")})
    return created


@router.put("/dimensions/{dimension_id}")
async def update_dimension(dimension_id: int, body: DimensionUpdate, request: Request,
                           user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    _check_dimension(body.name, body.no_value_behaviour, body.columns, creating=False)
    if body.columns is not None and not body.columns:
        raise HTTPException(status_code=422, detail="a dimension needs at least one column name")
    data = body.model_dump(exclude={"columns"}, exclude_none=True)
    if data.get("name"):
        for d in await _adb(_db().list_entitlement_dimensions, include_inactive=True):
            if d["name"].lower() == str(data["name"]).strip().lower() and int(d["id"]) != int(dimension_id):
                from core.config_active import name_held_message
                raise HTTPException(status_code=409, detail=(
                    name_held_message("entitlement dimension", d["name"])
                    if d.get("is_active") is False
                    else f"A dimension named {data['name']!r} already exists"))
    cols = [c.model_dump() for c in body.columns] if body.columns is not None else None
    updated = await _adb(_db().update_entitlement_dimension, dimension_id, data, cols,
                         user.get("username") or "")
    if updated is None:
        raise HTTPException(status_code=404, detail="Dimension not found")
    _invalidate()
    audit_event(_db(), user, request, "entitlement_dimension_updated",
                resource_type="row_security", resource_id=dimension_id,
                details={"changed": sorted(data) + (["columns"] if cols is not None else [])})
    return updated


@router.delete("/dimensions/{dimension_id}")
async def delete_dimension(dimension_id: int, request: Request,
                           user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    ok = await _adb(_db().delete_entitlement_dimension, dimension_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Dimension not found")
    _invalidate()
    audit_event(_db(), user, request, "entitlement_dimension_deleted",
                resource_type="row_security", resource_id=dimension_id)
    from core.config_active import switched_off_message
    return {"deleted": True, "detail": switched_off_message("entitlement dimension")}


def _on_dimension_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    """Switched back on, the dimension filters again from the next query:
    drop the compiled entitlement memo, exactly as the delete did."""
    _invalidate()
    return None


def _register_switch_on() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["entitlement_dimensions"] = _on_dimension_switched_on


_register_switch_on()


@router.get("/dimensions/{dimension_id}/tables")
async def dimension_tables(dimension_id: int, user: dict = Depends(require_capability("row_security.manage"))) -> Dict[str, Any]:
    """The catalogued tables carrying one of the dimension's columns -- what
    the filter will land on.  From the column catalog, never the source."""
    d = await _adb(_db().get_entitlement_dimension, dimension_id)
    if d is None:
        raise HTTPException(status_code=404, detail="Dimension not found")

    try:
        found = await _adb(ent.tables_carrying, _db(), d)
    except Exception:
        # Unknown != empty: say it could not be read (the cause in the log only).
        logger.exception("entitlement: tables of dimension %s could not be read", dimension_id)
        raise HTTPException(status_code=503, detail="could not read the column catalog -- see the server log") from None
    return {"dimension": d["name"], **found}


# ── values ──────────────────────────────────────────────────────────────────

@router.get("/values")
async def list_values(dimension_id: Optional[int] = None, principal_type: Optional[str] = None,
                      principal_id: Optional[str] = None,
                      limit: int = Query(500, ge=1, le=5000), offset: int = Query(0, ge=0),
                      user: dict = Depends(require_capability("row_security.manage"))) -> Dict[str, Any]:
    return await _adb(_db().list_entitlement_values, dimension_id, principal_type,
                      principal_id, limit, offset)


@router.post("/values")
async def add_values(body: ValuesAdd, request: Request,
                     user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    dims = await _adb(_dims_by_id)
    rows = [v.model_dump() for v in body.values]
    problems = [p for i, r in enumerate(rows) if (p := _check_value(r, dims, f"row {i + 1}: "))]
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems[:20]) +
                            (f"; and {len(problems) - 20} more" if len(problems) > 20 else ""))
    added = await _adb(_db().add_entitlement_values, rows, user.get("username") or "")
    _invalidate()
    audit_event(_db(), user, request, "entitlement_values_added",
                resource_type="row_security", resource_id=None,
                details={"rows": len(rows), "added": added,
                         "dimensions": sorted({r["dimension_id"] for r in rows})})
    return {"added": added, "already_held": len(rows) - added}


@router.delete("/values/{value_id}")
async def delete_value(value_id: int, request: Request,
                       user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    ok = await _adb(_db().delete_entitlement_value, value_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Value not found")
    _invalidate()
    audit_event(_db(), user, request, "entitlement_value_deleted",
                resource_type="row_security", resource_id=value_id)
    return {"deleted": True}


_UPLOAD_HEADER = ("principal_type", "principal_id", "value")


def parse_upload(text: str, dimension_id: int, dims: Dict[int, Dict[str, Any]],
                 max_rows: int) -> Dict[str, Any]:
    """CSV ``principal_type,principal_id,value[,valid_from,valid_to]``; a value
    of ``*`` = every value.  Pure: rows accepted + rows rejected, each with the
    line and the reason (a rejected row never silently disappears)."""
    reader = csv.DictReader(io.StringIO(text))
    header = [h.strip().lower() for h in (reader.fieldnames or [])]
    missing = [h for h in _UPLOAD_HEADER if h not in header]
    if missing:
        raise HTTPException(status_code=422,
                            detail=f"the file's header must carry {', '.join(_UPLOAD_HEADER)} "
                                   f"(missing {', '.join(missing)})")
    accepted: List[Dict[str, Any]] = []
    rejected: List[Dict[str, Any]] = []
    for n, raw in enumerate(reader, start=2):
        if len(accepted) + len(rejected) >= max_rows:
            raise HTTPException(status_code=413,
                                detail=f"the file has more than {max_rows} rows "
                                       f"(row_security.entitlement_upload_max_rows)")
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
        r: Dict[str, Any] = {"dimension_id": dimension_id,
                             "principal_type": row.get("principal_type", "").lower(),
                             "principal_id": row.get("principal_id", ""),
                             "value": row.get("value") or None,
                             "is_all": row.get("value") == "*"}
        try:
            for k in ("valid_from", "valid_to"):
                r[k] = date.fromisoformat(row[k]) if row.get(k) else None
        except ValueError:
            rejected.append({"line": n, "row": row, "reason": "a date is not YYYY-MM-DD"})
            continue
        why = _check_value(r, dims)
        if why:
            rejected.append({"line": n, "row": row, "reason": why})
        else:
            accepted.append(r)
    return {"accepted": accepted, "rejected": rejected}


@router.post("/values/upload")
async def upload_values(request: Request, dimension_id: int = Query(...),
                        mode: str = Query("merge"), dry_run: bool = Query(False),
                        file: UploadFile = File(...),
                        user: dict = Depends(require_capability("row_security.manage", rate_limited=True))) -> Dict[str, Any]:
    if mode not in ("merge", "replace"):
        raise HTTPException(status_code=422, detail="mode must be merge or replace")
    dims = await _adb(_dims_by_id)
    if dimension_id not in dims:
        raise HTTPException(status_code=404, detail="Dimension not found")
    try:
        text = (await file.read()).decode("utf-8-sig")
    except UnicodeDecodeError:
        raise HTTPException(status_code=422, detail="the file is not UTF-8 text")
    from core.config import row_security as _rs_cfg
    parsed = parse_upload(text, dimension_id, dims, _rs_cfg.entitlement_upload_max_rows)
    acc, rej = parsed["accepted"], parsed["rejected"]
    current = await _adb(_db().list_entitlement_values, dimension_id, None, None, 1, 0)
    preview = {"dimension": dims[dimension_id]["name"], "mode": mode, "rows_accepted": len(acc),
               "rows_rejected": len(rej), "rejected": rej[:200],
               "current_rows": current["total"],
               "would_remove": current["total"] if mode == "replace" else 0}
    if dry_run:
        return {**preview, "dry_run": True}
    if mode == "replace" and not acc:
        raise HTTPException(status_code=422,
                            detail="a replace with no valid row would remove every value of the "
                                   "dimension -- refused (delete the values explicitly instead)")
    result = await _adb(_db().apply_entitlement_upload, dimension_id, acc, user.get("username") or "",
                        {"mode": mode, "filename": file.filename, "rows_rejected": len(rej),
                         "rejected": rej[:200]})
    _invalidate()
    audit_event(_db(), user, request, "entitlement_values_uploaded",
                resource_type="row_security", resource_id=dimension_id,
                details={"filename": file.filename, "mode": mode, **result, "rows_rejected": len(rej)})
    return {**preview, **result, "dry_run": False}


# ── the caller's own entitlements ──────────────────────────────────────────

@me_router.get("/entitlements")
async def my_entitlements(user: dict = Depends(get_current_user)) -> Dict[str, Any]:
    from core.row_security.api import build_user_ctx
    ctx = build_user_ctx(user)
    try:
        items = await _adb(ent.explain_for, ctx, _db())
    except Exception:
        # Unknown != empty: say it could not be read, never "you hold none"
        # (the cause in the server log only -- not to the caller).
        logger.exception("entitlement: /api/me/entitlements failed for %s", ctx.username)
        raise HTTPException(status_code=503, detail="could not read your entitlements -- see the server log") from None
    return {"username": ctx.username, "is_admin": ctx.is_admin,
            "admin_note": ("an administrator's queries are not filtered by entitlement "
                           "(each bypass is audited)") if ctx.is_admin else None,
            "enabled": ent.enabled(), "dimensions": items}
