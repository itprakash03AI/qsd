"""
Report Connectors API (2026-09-26, FB-60 / F7)

Endpoints:
  GET    /api/report-connectors/matrix             -- finance reports that read
                                                      a SQL source, with their
                                                      assigned / override /
                                                      effective connection
  POST   /api/report-connectors/bulk-set-override  -- set or clear the
                                                      connection override on
                                                      many reports (admin)

  GET    /api/reports/connector-matrix               -- 308 -> matrix
  POST   /api/reports/bulk-set-connection-override   -- 308 -> bulk-set-override
                                                      (kept ONE release for a
                                                      UI built before this
                                                      commit; remove after)

WHY THIS MODULE EXISTS.  The two routes were ``/api/reports/connector-matrix``
and ``/api/reports/bulk-set-connection-override`` in ``api/reports_api.py`` --
the legacy PARAMETRIC report surface, decommissioned by FB-60.  They were the
only two routes of that surface a live page (Report Connectors) still called,
so the brief's order of operations was: move them first, then delete the
router.  Deleting the router first would have broken the page.

WHAT THEY ANSWER NOW.  The parametric ``reports`` table is no longer read.
The successor of a parametric report is a finance (business) report with
``data_source_type = 'raw_sql'``: its SQL source is ``raw_sql_saved_query_id``
(a SqlSavedQuery, whose ``primary_connection_id`` is the ASSIGNED connection)
or a ``raw_sql_file_id``; ``raw_connection_override_id`` is the OVERRIDE, and
the engine reads it through ``business_reports_api._as_legacy_report``.  A
parquet-sourced raw_sql report (``raw_saved_query_id``) is file-based and has
no connection to assign, exactly as the old matrix said of parquet rows.

WRITES GO THROUGH THE ONE UPDATE PATH.  ``bulk-set-override`` calls
``business_reports_api.update_report`` per row -- the same handler the
builder's PUT uses -- so the editor gate (owner / admin / editor grant), the
change history and the ``exclude_unset`` clear semantics are not
re-implemented here.  ``raw_connection_override_id`` is a versioned
DEFINITION field (``core.reports.versions.DEFINITION_FIELDS``): the update
changes the live row, i.e. the author's draft; a PUBLISHED report keeps
serving its published snapshot until it is republished.  The matrix reports
the live row, and says so in ``override_scope``.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse

from api.deps import get_current_user, require_capability
from api.strict_request import StrictRequestModel
from core.roles import ADMIN_TIER_ROLES, is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()

#: The matrix covers finance reports whose source is a SQL object.  Kept as a
#: module constant so the test that pins the vocabulary and the filter below
#: read one definition.
MATRIX_SOURCE_TYPE = "raw_sql"

#: Old path -> new path.  The redirect handlers below are generated from this
#: table, and the decommission guard allows exactly these legacy paths.
LEGACY_REDIRECTS: Dict[str, str] = {
    "/api/reports/connector-matrix": "/api/report-connectors/matrix",
    "/api/reports/bulk-set-connection-override": "/api/report-connectors/bulk-set-override",
}


async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _source_type(br: Dict[str, Any]) -> Optional[str]:
    """``sql`` / ``parquet`` for a raw_sql finance report; None otherwise."""
    if (br.get("data_source_type") or "dataset") != MATRIX_SOURCE_TYPE:
        return None
    if br.get("raw_saved_query_id"):
        return "parquet"
    if br.get("raw_sql_saved_query_id") or br.get("raw_sql_file_id") or br.get("raw_sql_override"):
        return "sql"
    return None


def _visible_raw_sql_reports(db, user: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Finance reports the caller may see, restricted to SQL/parquet sources.

    Admin tier lists everything; everyone else goes through the ONE
    visibility chokepoint ``list_visible_business_reports`` (own / published
    within role_whitelist / owner-group / grants) -- never a local copy.
    """
    if is_admin_like(user):
        rows = db.list_business_reports()
    else:
        from core.reports.authorization import list_visible_business_reports
        rows = list_visible_business_reports(db, user)
    return [r for r in rows if _source_type(r)]


def build_matrix(db, user: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The rows the Report Connectors page renders.

    Row contract (unchanged from the legacy matrix, plus ``override_scope``):
    ``id, name, description, source_type, connection_override_id,
    assigned_connection, override_connection, effective_connection,
    profile_mapped_connection``.  Each connection is ``{id, name,
    connection_type}`` or None.
    """
    conn_cache: Dict[int, Optional[dict]] = {}

    def _conn_summary(conn_id: Optional[int]) -> Optional[dict]:
        if not conn_id:
            return None
        if conn_id not in conn_cache:
            c = db.get_connection_raw(conn_id)
            conn_cache[conn_id] = ({"id": c["id"], "name": c["name"],
                                    "connection_type": c["connection_type"]}
                                   if c else None)
        return conn_cache[conn_id]

    result: List[Dict[str, Any]] = []
    for r in _visible_raw_sql_reports(db, user):
        st = _source_type(r)
        entry: Dict[str, Any] = {
            "id":                        r["id"],
            "name":                      r.get("name"),
            "description":               r.get("description"),
            "slug":                      r.get("slug"),
            "source_type":               st,
            "is_published":              bool(r.get("is_published")),
            "connection_override_id":    r.get("raw_connection_override_id"),
            "assigned_connection":       None,
            "override_connection":       None,
            "effective_connection":      None,
            "profile_mapped_connection": None,
            # The live row is the author's draft; a published report serves
            # its snapshot until republished (core.reports.versions).
            "override_scope":            "draft" if r.get("is_published") else "live",
        }
        if st == "sql":
            if r.get("raw_sql_saved_query_id"):
                sq = db.get_sql_query(r["raw_sql_saved_query_id"])
                if sq:
                    entry["assigned_connection"] = _conn_summary(sq.get("primary_connection_id"))
            elif r.get("raw_sql_file_id"):
                try:
                    from api.business_reports_api import _resolve_sql_file_to_override
                    _sql, sf_conn_id = _resolve_sql_file_to_override(int(r["raw_sql_file_id"]))
                    entry["assigned_connection"] = _conn_summary(sf_conn_id)
                except Exception as exc:   # a missing file is a row fact, not a 500
                    logger.debug("connector matrix: sql file %s unresolved: %s",
                                 r.get("raw_sql_file_id"), exc)
            if r.get("raw_connection_override_id"):
                entry["override_connection"] = _conn_summary(r["raw_connection_override_id"])
            eff = entry["override_connection"] or entry["assigned_connection"]
            entry["effective_connection"] = eff
            if eff:
                mapped_id = db.resolve_connection_via_profile(eff["id"])
                if mapped_id != eff["id"]:
                    entry["profile_mapped_connection"] = _conn_summary(mapped_id)
        result.append(entry)
    return result


@router.get("/api/report-connectors/matrix")
async def get_report_connector_matrix(user: dict = Depends(require_capability("reports.view"))):
    """Finance reports with a SQL/parquet source and their connections."""
    db = _require_db()
    rows = await _adb(build_matrix, db, user)
    return {"reports": rows, "source_type": MATRIX_SOURCE_TYPE}


class BulkConnectionOverrideRequest(StrictRequestModel):
    report_ids:             List[int]
    connection_override_id: Optional[int] = None   # None clears the override


@router.post("/api/report-connectors/bulk-set-override")
async def bulk_set_connection_override(body: BulkConnectionOverrideRequest,
                                       user: dict = Depends(require_capability("reports.edit"))):
    """Set or clear ``raw_connection_override_id`` on many finance reports.

    Admin only (as the legacy route was).  Each row is written through
    ``business_reports_api.update_report`` -- the ONE update path -- so an
    id the caller may not edit, or that is not a raw_sql report, is reported
    per id rather than silently skipped.
    """
    if (user or {}).get("role") not in ADMIN_TIER_ROLES:
        raise HTTPException(403, "Bulk connection override requires admin role")
    db = _require_db()
    if body.connection_override_id is not None:
        conn = await _adb(db.get_connection_raw, int(body.connection_override_id))
        if not conn:
            raise HTTPException(404, f"Connection {body.connection_override_id} not found")

    from api.business_reports_api import ReportUpdate, update_report

    updated: List[int] = []
    refused: List[Dict[str, Any]] = []
    for rid in body.report_ids:
        br = await _adb(db.get_business_report, int(rid))
        if not br:
            refused.append({"id": rid, "reason": "not found"})
            continue
        if not _source_type(br):
            refused.append({"id": rid, "reason": "not a raw_sql finance report"})
            continue
        try:
            await update_report(
                int(rid),
                ReportUpdate(raw_connection_override_id=body.connection_override_id),
                user=user,
            )
            updated.append(int(rid))
        except HTTPException as exc:
            refused.append({"id": rid, "reason": str(exc.detail)})
    return {"updated": len(updated), "updated_ids": updated,
            "requested": len(body.report_ids), "refused": refused}


# ── Legacy paths: one release of explicit redirects ─────────────────────────

def _redirect_to(new_path: str):
    async def _handler(request: Request):
        qs = request.url.query
        return RedirectResponse(url=new_path + (f"?{qs}" if qs else ""),
                                status_code=308)
    return _handler


router.add_api_route(
    "/api/reports/connector-matrix",
    _redirect_to(LEGACY_REDIRECTS["/api/reports/connector-matrix"]),
    methods=["GET"], name="legacy_connector_matrix_redirect",
    summary="308 -> /api/report-connectors/matrix (one release)")
router.add_api_route(
    "/api/reports/bulk-set-connection-override",
    _redirect_to(LEGACY_REDIRECTS["/api/reports/bulk-set-connection-override"]),
    methods=["POST"], name="legacy_bulk_override_redirect",
    summary="308 -> /api/report-connectors/bulk-set-override (one release)")
