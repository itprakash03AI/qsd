"""SFTP destination authoring helpers (2026-09-24): fetch a server's host key,
and test a destination through the SAME code path delivery uses.

Why these exist.  The feed form offered host / port / username / password /
remote dir and nothing else, while delivery REFUSES a server whose host key is
not pinned (BF-415 -- the MITM guard) -- so an SFTP feed authored in the UI
could never deliver, and there was no way to author key auth or a vault
account at all.  A person configuring SFTP needs two answers the product can
give: "what is this server's key?" (so they can pin it, confirming the
fingerprint), and "will this configuration deliver?" (before a run finds out).

* ``POST /api/feed-destinations/sftp/host-key`` -- connects WITHOUT
  authenticating, reads the key the server presents, returns its type, the
  base64 blob to pin, and the SHA-256 fingerprint in OpenSSH's own spelling so
  it can be compared with what the server's owner publishes.  Nothing is
  stored: pinning is the person's decision (trust on first use, made visible).
* ``POST /api/feed-destinations/sftp/test`` -- ``core.feed_engine._sftp_connect``
  (host-key verification, THE auth rule in core.feed.sftp_auth, the vault
  account) then a stat of the remote directory.  Answers ok / the stage that
  failed and its reason, and which auth method was used.  A masked
  ``password: "***"`` is restored from the stored feed (by ``feed_id``, and
  ``hop_label`` for a delivery-chain hop), exactly as a save would.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field

from api.deps import get_current_user, require_capability
from api.strict_request import StrictRequestModel

logger = logging.getLogger(__name__)
router = APIRouter()

_TIMEOUT_SECONDS = 10


class HostKeyRequest(StrictRequestModel):
    host: str = Field(..., min_length=1, max_length=255)
    port: int = Field(default=22, ge=1, le=65535)


class SftpTestRequest(StrictRequestModel):
    destination_config: Dict[str, Any]
    #: restore a masked password from this stored feed (optional)
    feed_id: Optional[int] = None
    #: ... from this delivery-chain hop of it (optional)
    hop_label: Optional[str] = None


def _fingerprint(blob: bytes) -> str:
    """OpenSSH's spelling: ``SHA256:<base64, no padding>``."""
    return "SHA256:" + base64.b64encode(hashlib.sha256(blob).digest()).decode().rstrip("=")


def _read_host_key(host: str, port: int) -> Dict[str, Any]:
    import socket
    import paramiko
    sock = socket.create_connection((host, port), timeout=_TIMEOUT_SECONDS)
    transport = paramiko.Transport(sock)
    try:
        transport.start_client(timeout=_TIMEOUT_SECONDS)
        key = transport.get_remote_server_key()
        blob = key.asbytes()
        return {"host": host, "port": port, "key_type": key.get_name(),
                "host_key_b64": base64.b64encode(blob).decode(),
                "fingerprint_sha256": _fingerprint(blob)}
    finally:
        transport.close()


@router.post("/api/feed-destinations/sftp/host-key")
async def fetch_sftp_host_key(body: HostKeyRequest, user: dict = Depends(require_capability("feeds.author"))):
    try:
        out = await asyncio.to_thread(_read_host_key, body.host.strip(), body.port)
    except Exception as exc:
        raise HTTPException(
            400, f"Could not read a host key from {body.host}:{body.port}: "
                 f"{type(exc).__name__}: {exc}. Check the host and port, and that "
                 f"this server can reach it.") from None
    logger.info("[sftp-authoring] host key read from %s:%d by %s: %s %s",
                body.host, body.port, (user or {}).get("username"),
                out["key_type"], out["fingerprint_sha256"])
    out["note"] = ("Compare this fingerprint with the one the server's owner "
                   "publishes before pinning it: pinning an attacker's key "
                   "is exactly what the check exists to prevent.")
    return out


def _test_connection(dest: Dict[str, Any]) -> Dict[str, Any]:
    from core.feed_engine import _sftp_connect
    try:
        transport, sftp, host, port = _sftp_connect(dest)
    except Exception as exc:
        stage = ("authentication" if "auth" in str(exc).lower()
                 or type(exc).__name__ == "SftpAuthRefused"
                 else "host key" if "host key" in str(exc).lower()
                 else "connection")
        return {"ok": False, "stage": stage,
                "reason": f"{type(exc).__name__}: {exc}"}
    try:
        auth = dict(getattr(sftp, "qs_auth", None) or {})
        remote_dir = str(dest.get("remote_dir") or "/")
        try:
            sftp.stat(remote_dir)
            listing = sftp.listdir(remote_dir)
        except (IOError, OSError) as exc:
            return {"ok": False, "stage": "remote directory", "auth": auth,
                    "reason": f"remote_dir {remote_dir!r} is not readable: {exc}"}
        return {"ok": True, "auth": auth, "remote_dir": remote_dir,
                "entries": len(listing),
                "message": f"Connected to {host}:{port} with {auth.get('method')} "
                           f"auth; {remote_dir} is readable ({len(listing)} entries)."}
    finally:
        try:
            sftp.close()
        finally:
            transport.close()


@router.post("/api/feed-destinations/sftp/test")
async def test_sftp_destination(body: SftpTestRequest, user: dict = Depends(require_capability("feeds.author"))):
    dest = dict(body.destination_config or {})
    stored = None
    if body.feed_id is not None:
        from api.feed_api import _chain_hop_label, _require_feed, _unmask_secret_tree
        stored = await _require_feed(int(body.feed_id), user, write=True)
        stored_dest = stored.get("destination_config") or {}
        if body.hop_label:
            for hop in stored.get("delivery_chain") or []:
                if _chain_hop_label(hop) == body.hop_label:
                    stored_dest = hop.get("config") or hop
                    break
        dest = _unmask_secret_tree(dest, stored_dest)
    # 2026-10-29 -- the Test sends the account's login exactly as delivery
    # would, so it asks the same question a save does: only an admin may send
    # a System Account to a host the account does not allow
    # (core/feed/system_account_use.py).  It used to accept any host from the
    # request body, from any signed-in user, without saving anything.
    from core.database import get_db_manager
    from core.feed.system_account_use import authoring_refusal, sftp_destinations
    why = await asyncio.to_thread(authoring_refusal, get_db_manager(), user, dest,
                                  sftp_destinations(stored) if stored else [])
    if why:
        raise HTTPException(status_code=403, detail=why)
    if dest.get("password") == "***":
        dest.pop("password")      # never try a literal mask as a credential
    result = await asyncio.to_thread(_test_connection, dest)
    logger.info("[sftp-authoring] test %s:%s by %s -> ok=%s stage=%s",
                dest.get("host"), dest.get("port"), (user or {}).get("username"),
                result.get("ok"), result.get("stage"))
    return result


@router.get("/api/feed-destinations/sftp/accounts")
async def list_sftp_accounts(user: dict = Depends(require_capability("feeds.view"))):
    """The SFTP system accounts a feed author may pick -- id, name and
    environment only, never a credential.  Listing system accounts is an
    admin route (it shows every account type and its vault wiring); a feed
    author only needs to NAME the account an admin set up."""
    from core.database import get_db_manager
    db = get_db_manager()
    if db is None:
        raise HTTPException(503, "Database not ready")
    rows = await asyncio.to_thread(db.list_system_accounts)
    return [{"id": r.get("id"), "name": r.get("name"),
             "environment": r.get("environment"), "use_vault": bool(r.get("use_vault"))}
            for r in (rows or [])
            if r.get("account_type") == "sftp_account" and r.get("is_active", True)]
