"""
Phase 114-J/K — Report Comments & Change History API.

Threaded comments, @mention extraction, resolve/unresolve,
plus field-level change history for business reports.
"""
import asyncio
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from pydantic import BaseModel, Field

from api.deps import require_role
from core.roles import is_admin_like

logger = logging.getLogger(__name__)
router = APIRouter(tags=["report-comments"])


# BF-NONBLOCK-AUDIT-5
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

_ws_manager = None


def set_comments_dependencies(ws_manager=None):
    global _ws_manager
    if ws_manager:
        _ws_manager = ws_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


async def _require_report_view(report_id: int, user: dict) -> dict:
    """AUTHZ-1 (2026-08-22): object-level view gate for every comment route.

    Before this, all six routes were ``require_role("admin","analyst")`` ONLY
    — presence of a role, never access to the SPECIFIC report — so any analyst
    could read/post comments and change-history on a report they cannot view
    (and, with the DB owner-check missing, edit/delete anyone's comment).

    The rule is the ONE shared chokepoint the rest of the subsystem uses
    (``core.reports.authorization.can_view_business_report`` — the same gate
    ``business_reports_api._br_can_view`` and subscription creation call).
    404 both for a missing report and a denied one (no existence oracle).
    """
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")
    from core.reports.authorization import can_view_business_report
    if not can_view_business_report(report, user, db):
        raise HTTPException(404, f"Report {report_id} not found")
    return report


# ── Pydantic models ──────────────────────────────────────────────────────

class CommentCreate(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000)
    parent_id: Optional[int] = None


class CommentUpdate(BaseModel):
    text: Optional[str] = Field(default=None, max_length=2000)
    is_resolved: Optional[bool] = None


# ── Comments CRUD ─────────────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/comments")
async def list_comments(
    report_id: int,
    limit: int = Query(default=200, ge=1, le=1000),
    user: dict = Depends(require_capability("reports.create")),
):
    await _require_report_view(report_id, user)
    db = _require_db()
    return await _adb(db.list_report_comments, report_id, limit=limit)


@router.post("/api/business-reports/{report_id}/comments", status_code=201)
async def create_comment(
    report_id: int,
    body: CommentCreate,
    user: dict = Depends(require_capability("reports.create")),
):
    db = _require_db()
    # AUTHZ-1: object-level view gate (was: role-only — any analyst could post
    # to a report they cannot view).  Also validates the report exists (404).
    await _require_report_view(report_id, user)

    # Check max comments per report
    from core.config import get as cfg_get
    max_comments = cfg_get("collaboration", "max_comments_per_report") or 500
    count = await _adb(db.count_report_comments, report_id)
    if count >= max_comments:
        raise HTTPException(400, f"Maximum {max_comments} comments per report reached")

    comment = await _adb(db.create_report_comment,
        report_id=report_id,
        username=user.get("username", "system"),
        text=body.text,
        parent_id=body.parent_id,
    )

    # Broadcast to WebSocket clients
    try:
        if _ws_manager:
            _ws_manager.broadcast_sync({
                "type": "report_comment",
                "report_id": report_id,
                "username": user.get("username"),
                "preview": body.text[:100],
            })
    except Exception:
        pass

    return comment


@router.put("/api/business-reports/{report_id}/comments/{comment_id}")
async def update_comment(
    report_id: int,
    comment_id: int,
    body: CommentUpdate,
    user: dict = Depends(require_capability("reports.create")),
):
    # AUTHZ-1: gate on view access to the REPORT, then let the DB enforce
    # comment OWNERSHIP (owner-or-admin) where the row is mutated.
    await _require_report_view(report_id, user)
    db = _require_db()
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No updates provided")

    try:
        result = await _adb(db.update_report_comment,
            comment_id, report_id,
            username=user.get("username", "system"),
            is_admin=is_admin_like(user),
            **updates,
        )
    except PermissionError:
        raise HTTPException(403, "You may only edit your own comments")
    if not result:
        raise HTTPException(404, f"Comment {comment_id} not found")
    return result


@router.delete("/api/business-reports/{report_id}/comments/{comment_id}")
async def delete_comment(
    report_id: int,
    comment_id: int,
    user: dict = Depends(require_capability("reports.create")),
):
    # AUTHZ-1: view-gate the report, then enforce comment OWNERSHIP in the DB
    # (the route previously passed NO identity — any analyst could erase
    # anyone's thread).
    await _require_report_view(report_id, user)
    db = _require_db()
    try:
        deleted = await _adb(db.delete_report_comment, comment_id, report_id,
                             username=user.get("username", "system"),
                             is_admin=is_admin_like(user))
    except PermissionError:
        raise HTTPException(403, "You may only delete your own comments")
    if not deleted:
        raise HTTPException(404, f"Comment {comment_id} not found")
    return {"detail": "Deleted"}


@router.get("/api/business-reports/{report_id}/comments/count")
async def count_comments(
    report_id: int,
    user: dict = Depends(require_capability("reports.create")),
):
    await _require_report_view(report_id, user)
    db = _require_db()
    return {"count": await _adb(db.count_report_comments, report_id)}


# ── Change History (Phase 114-K) ─────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/change-history")
async def get_change_history(
    report_id: int,
    limit: int = Query(default=50, ge=1, le=500),
    user: dict = Depends(require_capability("reports.create")),
):
    await _require_report_view(report_id, user)
    db = _require_db()
    return await _adb(db.list_report_change_log, report_id, limit=limit)
