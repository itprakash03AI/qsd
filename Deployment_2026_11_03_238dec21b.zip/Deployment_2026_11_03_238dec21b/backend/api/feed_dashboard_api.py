"""The feed DASHBOARD routes (2026-10-12, owner request R1; core/feed/dashboard.py).

``GET /api/feed-dashboard`` -- the business date's tasks grouped by the
defined Feed Groups, with the OTG's status chips; ``GET /api/feed-dashboard/
task`` -- one task's dependency cards (gate verdict + the upstream messages
that arrived).  Both scoped by THE feed view rule: a feed the caller may not
view is not on the dashboard, and its task detail is the feed route's 404/403.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user, require_admin_read, require_capability
from core.db_async import adb
from core.feed import dashboard

router = APIRouter(tags=["feed-dashboard"])


def _fa():
    import api.feed_api as fa
    if fa._db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503, detail="The feed dashboard is not wired")
    return fa


@router.get("/api/feed-dashboard")
async def feed_dashboard(business_date: Optional[date] = None, run_date: Optional[date] = None,
                         search: str = "", status: str = Query("", pattern="^[a-z_]*$"),
                         page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                         group_by: str = Query("feed_group", pattern="^(feed_group|template|status|none)$"),
                         user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    allowed = list(dashboard.STATUSES) + ["sla_breached", "sla_at_risk"]
    if status and status not in allowed:
        raise HTTPException(status_code=422, detail=f"status must be one of {allowed}")
    if business_date and run_date:
        raise HTTPException(status_code=422, detail="Give a business date or a run date, not both")
    # 2026-10-13 -- ``run_date``: every task worked on that day, whatever its
    # business date (a September month end delivered on 13 October)
    bd = None if run_date else (business_date or datetime.now(timezone.utc).date())
    # 2026-10-12 -- admin / support / no-auth see every feed: no list to build.
    visible = None if fa._sees_every_feed(user) else await adb(fa._visible_feed_ids, user)
    # 2026-10-17 -- may THIS caller act on a task (re-run / skip / decide)?
    # The same gate every action route applies (``_can_rerun_feed``); with
    # auth off everyone may, as every feed route already allows.
    act_fn = (lambda fc: fa._can_rerun_feed(fc, user)) if fa._auth_on() else None
    return await adb(dashboard.build, fa._db_manager, bd, visible_feed_ids=visible,
                     search=search, status=status, page=page, page_size=page_size,
                     group_by=group_by, run_date=run_date, act_fn=act_fn)


@router.get("/api/feed-dashboard/task")
async def feed_dashboard_task(feed_id: int, business_date: date,
                              user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    feed = await fa._require_feed(feed_id, user, write=False)
    return await adb(dashboard.task_detail, fa._db_manager, feed, business_date)


@router.get("/api/feed-sla-board")
async def feed_sla_board(business_date: Optional[date] = None,
                         user: dict = Depends(require_capability("feeds.view"))):
    """2026-10-12 (owner R5) -- every visible feed's SLA verdict for the date
    (core/feed/sla_board.py), worst first."""
    from core.feed import sla_board
    fa = _fa()
    bd = business_date or datetime.now(timezone.utc).date()
    # 2026-10-12 -- admin / support / no-auth see every feed: no list to build.
    visible = None if fa._sees_every_feed(user) else await adb(fa._visible_feed_ids, user)
    return await adb(sla_board.build, fa._db_manager, bd, visible_feed_ids=visible)


@router.get("/api/feed-dependency-tracker")
async def feed_dependency_tracker(business_date: Optional[date] = None, search: str = "",
                                  user: dict = Depends(require_capability("feeds.view"))):
    """2026-10-25 (owner) -- the date's dependencies arrived / waiting, where
    each one is, the feeds waiting on it and their SLA (core/feed/
    dependency_tracker.py); scoped by THE feed view rule like the board."""
    from core.feed import dependency_tracker
    fa = _fa()
    bd = business_date or datetime.now(timezone.utc).date()
    visible = None if fa._sees_every_feed(user) else await adb(fa._visible_feed_ids, user)
    return await adb(dependency_tracker.build, fa._db_manager, bd, visible_feed_ids=visible,
                     search=search)


@router.get("/api/admin/feeds/iceberg-commits")
async def iceberg_commits(days: int = Query(7, ge=0, le=90),
                          page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                          user: dict = Depends(require_capability("feeds.monitor"))):
    """2026-10-12 (owner R4) -- the Iceberg monitor: watched tables, each new
    commit's inspection, and the feeds it released (core/feed/iceberg_monitor.py).
    The inspections are PAGED (core/feed/paging.py)."""
    from core.feed import iceberg_monitor
    fa = _fa()
    return await adb(iceberg_monitor.build, fa._db_manager, days=days, page=page, page_size=page_size)


# ── the UPSTREAM CONTRACT's vocabulary: DATA, edited here (2026-10-12) ─────
# The owner: "all db driven ... no hardcoded in code".  Environments (which
# side, its label, how a dependency name and a message say it) and message
# tokens ({version} -> VERSION_NUMBER) are rows; admins edit them, everyone
# reads them (the board needs the labels).

from pydantic import BaseModel, Field  # noqa: E402

from api.deps import require_admin  # noqa: E402


class EnvironmentBody(BaseModel):
    side: str = Field(pattern="^(primary|secondary)$")
    label: str = Field(min_length=1, max_length=60)
    dependency_suffixes: list[str] = Field(default_factory=list)
    message_field: Optional[str] = Field(default=None, max_length=120)
    message_values: list[str] = Field(default_factory=list)
    sort_order: int = 0
    is_active: bool = True


class MessageTokenBody(BaseModel):
    token: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,59}$")
    message_field: str = Field(min_length=1, max_length=120)
    description: Optional[str] = Field(default=None, max_length=500)
    is_active: bool = True


@router.get("/api/admin/feed-environments")
async def list_environments(user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    return {"environments": await adb(fa._db_manager.list_feed_environments, False)}


@router.put("/api/admin/feed-environments")
async def put_environment(body: EnvironmentBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.feed import environments
    fa = _fa()
    if body.message_field and not body.message_values:
        raise HTTPException(status_code=422, detail="message_values are required with a message_field "
                                                    "(the values that mean THIS environment)")
    row = await adb(fa._db_manager.upsert_feed_environment, body.model_dump(), user.get("username"))
    environments.invalidate()
    return row


@router.get("/api/admin/feed-message-tokens")
async def list_message_tokens(user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    return {"tokens": await adb(fa._db_manager.list_feed_message_tokens, False)}


@router.put("/api/admin/feed-message-tokens")
async def put_message_token(body: MessageTokenBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.feed import upstream_contract
    fa = _fa()
    row = await adb(fa._db_manager.upsert_feed_message_token, body.model_dump(), user.get("username"))
    upstream_contract.invalidate_tokens()
    return row


class MessageFieldBody(BaseModel):
    field: str = Field(min_length=1, max_length=120)
    label: str = Field(min_length=1, max_length=60)
    sort_order: int = 0
    on_tile: bool = True
    on_monitor: bool = True
    identifies: bool = False
    is_active: bool = True


@router.get("/api/admin/feed-message-fields")
async def list_message_fields(user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    return {"fields": await adb(fa._db_manager.list_feed_message_fields, False)}


@router.put("/api/admin/feed-message-fields")
async def put_message_field(body: MessageFieldBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.feed import message_fields
    fa = _fa()
    row = await adb(fa._db_manager.upsert_feed_message_field, body.model_dump(), user.get("username"))
    message_fields.invalidate()
    return row


# ── restatement + alerts (2026-10-12): every behaviour is a row ──────────

class RestatementPolicyBody(BaseModel):
    scope: str = Field(pattern="^(global|feed_group|template|feed)$")
    scope_id: Optional[int] = None
    name: Optional[str] = Field(default=None, max_length=80)
    on_new_message: str = "decide"
    same_run_date: str = "decide"
    window: str = "next_business_date"
    window_days: Optional[int] = None
    # 2026-10-15 -- WD1..WDn on the feed's calendar
    window_workdays: Optional[int] = None
    is_active: bool = True


@router.get("/api/admin/feed-restatement-policies")
async def list_restatement_policies(user: dict = Depends(require_capability("feeds.view"))):
    from core.feed.restatement import POLICY_ACTIONS, WINDOWS
    fa = _fa()
    return {"policies": await adb(fa._db_manager.list_restatement_policies, False),
            "actions": list(POLICY_ACTIONS), "windows": list(WINDOWS)}


@router.put("/api/admin/feed-restatement-policies")
async def put_restatement_policy(body: RestatementPolicyBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.feed.restatement import validate_policy
    fa = _fa()
    data = body.model_dump()
    why = validate_policy(data)
    if why:
        raise HTTPException(status_code=422, detail=why)
    return await adb(fa._db_manager.upsert_restatement_policy, data, user.get("username"))


@router.delete("/api/admin/feed-restatement-policies/{policy_id}")
async def delete_restatement_policy(policy_id: int, user: dict = Depends(require_capability("feeds.manage"))):
    fa = _fa()
    if not await adb(fa._db_manager.delete_restatement_policy, policy_id):
        raise HTTPException(status_code=404, detail=f"policy {policy_id} not found")
    return {"deleted": policy_id}


class AlertKindBody(BaseModel):
    kind: str = Field(pattern=r"^[a-z][a-z0-9_]{0,59}$")
    title: str = Field(min_length=1, max_length=120)
    severity: int = Field(ge=0, le=5)
    alert_group: str
    to_bell: bool = True
    to_email: bool = False
    to_netcool: bool = False
    to_jira: bool = False
    clears_when: str = Field(min_length=1, max_length=255)
    is_active: bool = True


@router.get("/api/admin/feed-alert-kinds")
async def list_alert_kinds(user: dict = Depends(require_capability("feeds.view"))):
    from core.feed.netcool import ALERT_GROUPS
    fa = _fa()
    return {"kinds": await adb(fa._db_manager.list_feed_alert_kinds, False),
            "alert_groups": sorted(ALERT_GROUPS)}


@router.put("/api/admin/feed-alert-kinds")
async def put_alert_kind(body: AlertKindBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.feed import feed_alerts
    from core.feed.netcool import ALERT_GROUPS
    fa = _fa()
    if body.alert_group not in ALERT_GROUPS:
        raise HTTPException(status_code=422, detail=f"alert_group must be one of {sorted(ALERT_GROUPS)} "
                                                    f"-- the console routes by group")
    row = await adb(fa._db_manager.upsert_feed_alert_kind, body.model_dump(), user.get("username"))
    feed_alerts.invalidate()
    return row


class AlertRouteBody(BaseModel):
    """A feed scope (``global`` / ``feed_group`` / ``template`` / ``feed`` with
    ``scope_id``) or, since 2026-10-17, an alert SUBJECT kind
    (``published_api``, ``component``, ... -- core/feed/alert_subject.py) with
    ``scope_key`` = one subject's key or empty = every subject of that kind."""
    scope: str = Field(pattern="^[a-z][a-z_]{1,19}$")
    scope_id: Optional[int] = None
    scope_key: Optional[str] = Field(default=None, max_length=220)
    kind: Optional[str] = None
    channel: str = Field(pattern="^(bell|email)$")
    target: str = Field(min_length=1, max_length=255)


_FEED_ROUTE_SCOPES = ("feed_group", "template", "feed")


@router.get("/api/admin/feed-alert-routes")
async def list_alert_routes(user: dict = Depends(require_capability("feeds.view"))):
    fa = _fa()
    return {"routes": await adb(fa._db_manager.list_feed_alert_routes)}


@router.post("/api/admin/feed-alert-routes", status_code=201)
async def create_alert_route(body: AlertRouteBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.email_service import _valid_recipients
    fa = _fa()
    if body.scope in _FEED_ROUTE_SCOPES and body.scope_id is None:
        raise HTTPException(status_code=422, detail=f"scope {body.scope!r} needs a scope_id")
    if body.scope not in _FEED_ROUTE_SCOPES and body.scope_id is not None:
        raise HTTPException(status_code=422, detail=f"scope {body.scope!r} takes a scope_key, not a scope_id")
    if body.scope == "global" and body.scope_key:
        raise HTTPException(status_code=422, detail="a global route takes no scope_key")
    if body.channel == "email" and not _valid_recipients([body.target]):
        raise HTTPException(status_code=422, detail=f"{body.target!r} is not an e-mail address")
    return await adb(fa._db_manager.create_feed_alert_route, body.model_dump(), user.get("username"))


@router.delete("/api/admin/feed-alert-routes/{route_id}")
async def delete_alert_route(route_id: int, user: dict = Depends(require_capability("feeds.manage"))):
    fa = _fa()
    if not await adb(fa._db_manager.delete_feed_alert_route, route_id):
        raise HTTPException(status_code=404, detail=f"route {route_id} not found")
    return {"deleted": route_id}


@router.get("/api/feed-alerts")
async def list_feed_alerts(feed_id: Optional[int] = None, business_date: Optional[date] = None,
                           status: Optional[str] = Query(None, pattern="^(open|cleared)$"),
                           subject_kind: str = Query("feed", pattern="^[a-z*][a-z_]{0,19}$"),
                           subject_key: Optional[str] = Query(None, max_length=220),
                           page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                           user: dict = Depends(require_capability("feeds.monitor"))):
    """The alert rows.  ``subject_kind`` defaults to ``feed`` (this is the
    feeds' list); a subject kind lists that kind's alerts, ``*`` every alert."""
    from core.feed.feed_alerts import public
    from core.feed.paging import block, paging
    fa = _fa()
    p = paging(page, page_size)
    # ``*`` or ``all`` = every subject (the Component Health page sends ``all``;
    # a kind literally named "all" would otherwise read as a silent empty list)
    sk = None if subject_kind in ("*", "all") else subject_kind
    rows = await adb(fa._db_manager.list_feed_alerts, feed_config_id=feed_id,
                     business_date=business_date, status=status, limit=p.page_size, offset=p.offset,
                     subject_kind=sk, subject_key=subject_key)
    total = await adb(fa._db_manager.count_feed_alerts, feed_config_id=feed_id,
                      business_date=business_date, status=status,
                      subject_kind=sk, subject_key=subject_key)
    return {"alerts": [public(r) for r in rows], "count": len(rows), "paging": block(total, p, len(rows))}


class DecisionAnswerBody(BaseModel):
    action: str = Field(pattern="^(rerun|keep)$")
    reason: str = Field(default="", max_length=2000)


@router.post("/api/feed-regeneration-decisions/{decision_id}/answer")
async def answer_decision(decision_id: int, body: DecisionAnswerBody,
                          user: dict = Depends(require_capability("feeds.author"))):
    """Re-run or keep: a re-run hold, a restatement after close or a
    superseded delivery -- ONE action (core/feed/restatement.py::answer)."""
    from core.feed.restatement import AnswerRefused, answer
    fa = _fa()
    try:
        return await adb(answer, fa._db_manager, decision_id, user=user,
                         action=body.action, reason=body.reason)
    except AnswerRefused as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))


@router.get("/api/feeds/{feed_id}/definition-timeline")
async def definition_timeline(feed_id: int, user: dict = Depends(require_capability("feeds.view"))):
    """WHEN each saved definition change applies, newest first
    (core/feed/definition_timeline.py)."""
    from core.feed.definition_timeline import describe
    fa = _fa()
    await fa._require_feed(feed_id, user, write=False)
    return {"feed_id": feed_id, "timeline": await adb(describe, fa._db_manager, feed_id)}


# ── Netcool rules: WHEN an event goes to Netcool and WHAT it says (2026-10-25) ──
# The owner: "config based netcool -- when to send and what events".  Rows of
# netcool_rules decided at the one chokepoint (core/feed/netcool_rules.py).

class NetcoolRuleBody(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    priority: int = 100
    is_active: bool = True
    match_alert_group: Optional[str] = None
    match_alert_type: Optional[str] = Field(default=None, max_length=60)
    match_object: Optional[str] = Field(default=None, max_length=255)
    match_min_severity: Optional[int] = None
    match_max_severity: Optional[int] = None
    days: Optional[list[int]] = None
    business_days_calendar: Optional[str] = Field(default=None, max_length=120)
    window_from: Optional[str] = None
    window_to: Optional[str] = None
    timezone: Optional[str] = Field(default=None, max_length=60)
    action: str = "send"
    severity_override: Optional[int] = None
    alert_group_override: Optional[str] = None
    note: Optional[str] = Field(default=None, max_length=2000)


def _rule_fields(body: "NetcoolRuleBody") -> dict:
    d = body.model_dump()
    for f in ("match_alert_group", "alert_group_override", "match_alert_type"):
        if d.get(f):
            d[f] = str(d[f]).strip().upper()
    for f in ("match_alert_group", "match_alert_type", "match_object", "business_days_calendar",
              "window_from", "window_to", "timezone", "alert_group_override", "note"):
        if d.get(f) is not None and not str(d[f]).strip():
            d[f] = None
    d["action"] = str(d["action"]).lower()
    return d


def _refuse_bad_rule(d: dict) -> None:
    from core.feed.netcool_rules import validate
    problems = validate(d)
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems))


def _rules_session():
    fa = _fa()
    return fa._db_manager


@router.get("/api/admin/netcool-rules")
async def list_netcool_rules(user: dict = Depends(require_capability("feeds.monitor"))):
    from core.db.models import NetcoolRule
    from core.feed.netcool import ALERT_GROUPS
    from core.feed.netcool_rules import ACTIONS, _default_action

    def _read():
        with _rules_session().get_session(read_only=True) as s:
            return [r.to_dict() for r in s.query(NetcoolRule)
                    .order_by(NetcoolRule.priority.asc(), NetcoolRule.id.asc()).all()]
    return {"rules": await adb(_read), "alert_groups": sorted(ALERT_GROUPS), "actions": list(ACTIONS),
            "default_action": _default_action()}


@router.post("/api/admin/netcool-rules")
async def create_netcool_rule(body: NetcoolRuleBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.db.models import NetcoolRule
    from core.feed import netcool_rules
    d = _rule_fields(body)
    _refuse_bad_rule(d)

    def _write():
        with _rules_session().get_session() as s:
            if s.query(NetcoolRule).filter(NetcoolRule.name == d["name"]).first():
                raise HTTPException(status_code=409, detail=f"a rule named '{d['name']}' exists")
            r = NetcoolRule(**d, updated_by=user.get("username"), updated_at=datetime.now(timezone.utc))
            s.add(r)
            s.flush()
            return r.to_dict()
    row = await adb(_write)
    netcool_rules.invalidate()
    _audit_rule("netcool_rule.created", row, user)
    return row


@router.put("/api/admin/netcool-rules/{rule_id}")
async def update_netcool_rule(rule_id: int, body: NetcoolRuleBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.db.models import NetcoolRule
    from core.feed import netcool_rules
    d = _rule_fields(body)
    _refuse_bad_rule(d)

    def _write():
        with _rules_session().get_session() as s:
            r = s.query(NetcoolRule).filter(NetcoolRule.id == rule_id).first()
            if r is None:
                raise HTTPException(status_code=404, detail="Netcool rule not found")
            clash = s.query(NetcoolRule).filter(NetcoolRule.name == d["name"], NetcoolRule.id != rule_id).first()
            if clash:
                raise HTTPException(status_code=409, detail=f"a rule named '{d['name']}' exists")
            for k, v in d.items():
                setattr(r, k, v)
            r.updated_by, r.updated_at = user.get("username"), datetime.now(timezone.utc)
            s.flush()
            return r.to_dict()
    row = await adb(_write)
    netcool_rules.invalidate()
    _audit_rule("netcool_rule.updated", row, user)
    return row


@router.delete("/api/admin/netcool-rules/{rule_id}")
async def delete_netcool_rule(rule_id: int, user: dict = Depends(require_capability("feeds.manage"))):
    from core.db.models import NetcoolRule
    from core.feed import netcool_rules

    def _write():
        with _rules_session().get_session() as s:
            r = s.query(NetcoolRule).filter(NetcoolRule.id == rule_id).first()
            if r is None:
                raise HTTPException(status_code=404, detail="Netcool rule not found")
            row = r.to_dict()
            s.delete(r)
            return row
    row = await adb(_write)
    netcool_rules.invalidate()
    _audit_rule("netcool_rule.deleted", row, user)
    return {"deleted": rule_id}


class NetcoolTestBody(BaseModel):
    alert_group: str
    alert_type: str = Field(min_length=1, max_length=60)
    object: str = Field(default="SOME_OBJECT", max_length=255)
    severity: int = 4
    resolution: bool = False
    at: Optional[datetime] = None


@router.post("/api/admin/netcool-rules/test")
async def test_netcool_rules(body: NetcoolTestBody, user: dict = Depends(require_capability("feeds.monitor"))):
    """A DRY RUN: which rule would decide an event like this, at this moment
    (or ``at``) -- nothing is queued, no counter moves."""
    from core.config import deploy_environment
    from core.feed import netcool as nc
    from core.feed.netcool_rules import decide
    at = body.at or datetime.now(timezone.utc)
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    ev = nc.NetcoolEvent(
        identifier=nc.build_identifier(deploy_environment() or "TEST", body.alert_type.upper(), body.object,
                                       at.date()),
        node="querystudio", alert_group=body.alert_group.upper(), alert_key=body.object,
        severity=int(body.severity), summary=f"test {body.alert_type}",
        type=nc.TYPE_RESOLUTION if body.resolution else nc.TYPE_PROBLEM)
    d = await adb(lambda: decide(ev, at, record=False))
    return {"action": d.action, "rule_id": d.rule_id, "rule_name": d.rule_name, "reason": d.reason,
            "would_send": d.event.to_dict() if d.send else None, "at": at.isoformat()}


def _audit_rule(action: str, row: dict, user: dict) -> None:
    from core.audit import audit_event
    audit_event(_rules_session(), user, action=action, resource_type="netcool_rule",
                resource_id=row.get("id"), details={"name": row.get("name"), "action": row.get("action"),
                                                    "priority": row.get("priority")})
