"""Canvas ACTIONS -- the routes (2026-10-30, "Download detail").

Every rule is in ``core/reports/canvas_actions.py``; these routes resolve the
report, the run, the clicked row and the caller, and run the job.

    GET  /api/business-reports/{id}/actions/apis
         the Published APIs the caller may call, each with its REAL names
         (its parameters and the columns it allows a filter on) -- the
         builder offers only these, never free typing.
    POST /api/business-reports/{id}/actions/{action_id}/run
         {execution_id, tile_id?, row_key: {column_id: value}, links?:
         [{column_id, value}], parameter_values?: {}}  -> 202 {run}
    GET  /api/business-reports/{id}/actions/runs/{run_id}   -> {run}
    GET  /api/business-reports/{id}/actions/runs            -> {items}
         (the audit: every run for the report's owner / an admin, your own
         runs for anyone else)

THE DETAIL POPUP (2026-10-31; docs/CANVAS_DETAIL_POPUP_2026_10_31.html) --
the same click, two roads (``source``: a Published API, or a query on a
dataset through the normal dataset execution, its stored connections, the
caller's dataset access and row security), shown in a popup with every
download:

    GET  /api/business-reports/{id}/actions/datasets              the datasets
         the caller may read (the builder's list)
    GET  /api/business-reports/{id}/actions/datasets/{dataset_id} its columns
         and the conditions of its own query (``where.<key>``) -- the targets
    POST /api/business-reports/{id}/actions/{action_id}/view   (the run body)
         -> {run, view}: the detail read ONCE into a stored parquet, its first
         page, the total and the cap in words, what was sent and from where
    GET  /api/business-reports/{id}/actions/runs/{run_id}/rows?page=&page_size=
         -> one page of the view (only within the first
         ``business_reports.detail_popup_max_rows`` rows); only the person
         whose view it is may read it
    POST /api/business-reports/{id}/actions/runs/{run_id}/file
         {format: csv | xlsx | parquet, deliver: now | download_centre}
         -> the SAME stored rows (all of them) in that format, registered in
         the Download Centre; ``download_centre`` builds it in the background
         with the tile note and the bell (a view too big to show builds from
         the source there)

THE SAFETY RULES.  The clicked row's values are READ from the run's STORED,
row-secured result (``read_clicked_values``): the browser's ``row_key`` only
names the row, a key that is not in the caller's result is refused, and
nothing else in the body is a value that is sent.  The run must be one the
caller may read (THE gates the result / cube routes use).  The Published API
is called IN THIS PROCESS AS THE CLICKING USER (a session principal through
``_check_view_access`` and the bulk CSV road, so the API's access rule, its
entitlements and row security apply to them); a caller who may not call the
API is refused with a plain sentence and no file.  The CSV is written into
the Download Centre under the caller (the registration the report CSV
exports use), a big one through the API's own background build
(``bulk/prepare``).  Every click is a row of ``report_canvas_action_runs``
(who, the action, the values sent, the rows, the time) -- a refusal too.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from api.deps import require_capability
from core.reports import canvas_actions as _ca
from core.reports.canvas_actions import ActionRefused

logger = logging.getLogger(__name__)
router = APIRouter(tags=["report-canvas-actions"])

#: how often a background API build is polled, and the most it is waited for
_PREPARE_POLL_SECONDS = 3.0


async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


class _Link(BaseModel):
    column_id: int
    value: Any = None


class RunActionRequest(BaseModel):
    execution_id: str = Field(..., min_length=1, max_length=100)
    tile_id: Optional[str] = Field(None, max_length=64)
    #: the clicked cell's dimension values, by column id -- they NAME the row
    row_key: Dict[str, Any] = Field(default_factory=dict)
    #: the linked-tile chips in force (column id + value)
    links: List[_Link] = Field(default_factory=list)
    #: the report's chosen parameters for this run
    parameter_values: Dict[str, Any] = Field(default_factory=dict)


# ── who the API is called as ──────────────────────────────────────────────

def consumer_principal(user: dict) -> dict:
    """The clicking user as a published-API consumer: the SAME shape the
    published routes mint for a Bearer session (``api/deps.py::
    _resolve_api_key_or_ad_user``), so ``_check_view_access`` applies the
    view's group rule to this human and the handlers' row security binds
    to them."""
    groups = list((user or {}).get("groups") or (user or {}).get("ad_groups") or [])
    return {
        "username": (user or {}).get("username", ""),
        "display_name": (user or {}).get("display_name") or (user or {}).get("username", ""),
        "role": (user or {}).get("role", "viewer"),
        "is_admin": bool((user or {}).get("is_admin", False)),
        "groups": groups,
        "ad_groups": groups,
        "scoped_view_ids": None,
        "api_key_id": None,
        "auth_method": "session",
    }


def _may_call(pv: dict, principal: dict) -> Optional[str]:
    """``None`` when the principal may call the view, else the sentence."""
    from api.published_views.helpers import _check_view_access
    try:
        _check_view_access(pv, principal)
        return None
    except HTTPException as exc:
        return _ca.refusal_words(exc.status_code, exc.detail, pv.get("name") or pv.get("slug") or "")


# ── the report, the run, the stored result ────────────────────────────────

async def _require_report_view(report_id: int, user: dict) -> dict:
    """404 for a missing report and for a denied one (no oracle)."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")
    from core.reports.authorization import can_view_business_report
    if not await _adb(can_view_business_report, report, user, db):
        raise HTTPException(404, f"Report {report_id} not found")
    return report


async def _stored_result(db, report_id: int, report: dict, exec_id: str, user: dict) -> Path:
    """The run's stored result, through THE gates the result and cube routes
    use (``business_reports_api``): the async-job row first (its creator /
    the owner / an admin), then the federation execution (it must belong to
    this report; its executor / the owner / an admin)."""
    from api import business_reports_api as _br
    artifact_path = ""
    entry = await _adb(db.get_br_async_job, exec_id)
    if entry and entry.get("report_id") == report_id and entry.get("status") == "completed":
        await _adb(_br._check_async_exec_access, db, entry, user)
        artifact_path = entry.get("output_path") or ""
    if not artifact_path:
        try:
            fed = await _adb(db.get_federation_execution, exec_id)
        except Exception:                                    # noqa: BLE001 -- unreadable = not found
            fed = None
        if not fed:
            raise HTTPException(404, "This run's result is no longer available. Run the report again.")
        _br._require_execution_belongs_to_report(report_id, report, fed)
        _br._check_result_access(report, fed, user)
        artifact_path = fed.get("output_path") or ""
    artifact = Path(artifact_path) if artifact_path else None
    if artifact is None or (not artifact.exists() and not _br._parts_result_exists(artifact)):
        raise HTTPException(404, "This run's result is no longer available. Run the report again.")
    return artifact


def _params_changed(db, exec_id: str, parameter_values: Dict[str, Any]) -> bool:
    """True when the run is recorded as an instance whose parameters are NOT
    the ones the browser sends (the page changed them after the run).  No
    instance = cannot tell = not refused (the API is still called as the
    user, so a parameter can never widen what they may read)."""
    try:
        from core.db.models import ReportInstance
        from core.reports.instances import canonical_params_fingerprint
        with db.get_session(read_only=True) as s:
            row = s.query(ReportInstance).filter(ReportInstance.execution_id == exec_id).first()
            if row is None:
                return False
            return row.params_fingerprint != canonical_params_fingerprint(parameter_values or {})
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("[canvas-action] instance params unreadable for %s: %s", exec_id, exc)
        return False


def _dataset_columns(db, report: dict) -> Dict[int, dict]:
    ds_id = report.get("dataset_id")
    if not ds_id:
        return {}
    ds = db.get_dataset_full(ds_id) or {}
    out: Dict[int, dict] = {}
    for c in ds.get("columns") or []:
        try:
            out[int(c["id"])] = c
        except (KeyError, TypeError, ValueError):
            continue
    return out


def _col_label(c: Optional[dict]) -> str:
    return str((c or {}).get("friendly_name") or (c or {}).get("physical_name") or "value")


# ── routes ────────────────────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/actions/apis")
async def list_action_apis(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """The Published APIs this caller may call, each with the names it
    takes: ``params`` (its declared parameters: name, type, required) and
    ``filters`` (``filter.<column>`` for each column it allows a filter
    on).  What the builder offers -- never a typed name."""
    await _require_report_view(report_id, user)
    db = _require_db()
    principal = consumer_principal(user)
    views = await _adb(db.list_published_views, active_only=True)
    out = []
    for v in views or []:
        if _may_call(v, principal) is not None:
            continue
        params = [{"name": p.get("name"), "type": p.get("type") or p.get("param_type") or "string",
                   "required": bool(p.get("required")), "label": p.get("label") or p.get("name")}
                  for p in (v.get("param_definitions") or []) if isinstance(p, dict) and p.get("name")]
        filters = []
        for f in v.get("allowed_filters") or []:
            col = f.get("column") if isinstance(f, dict) else f
            if col:
                filters.append({"name": f"filter.{col}", "column": col})
        out.append({"slug": v.get("slug"), "name": v.get("name"), "description": v.get("description") or "",
                    "params": params, "filters": filters})
    out.sort(key=lambda x: str(x.get("name") or "").lower())
    return {"items": out}


class _Click:
    """One click, checked: everything both roads and both shows need."""

    def __init__(self, **kw):
        self.__dict__.update(kw)


async def _resolve_click(report_id: int, action_id: str, body: RunActionRequest, user: dict, *,
                         run_kind: Optional[str] = None) -> _Click:
    """THE checks of a click, in the order they always ran (a refusal is
    audited and raised as an HTTPException with its sentence): the action is
    on the report and offered on the tile, the run is one the caller may
    read, its parameters did not change, the clicked key names a row of the
    caller's STORED result (every value sent is READ from it), each linked
    chip is a value of that result, only the report's declared parameters
    are sent; then the SOURCE -- the API exists and the caller may call it,
    or the dataset exists, the caller may read it and every value has a
    place in its query.  ``run_kind`` = ``view`` for the popup (its rows are
    stamped so); ``None`` = the file click exactly as before."""
    db = _require_db()
    report = await _require_report_view(report_id, user)
    username = (user or {}).get("username") or ""
    if not username:
        raise HTTPException(401, "Sign in to download the detail.")
    canvas = ((report.get("layout_config") or {}) if isinstance(report.get("layout_config"), dict) else {}).get("canvas")
    action = _ca.find_action(canvas, action_id)
    if action is None or action.get("kind") not in _ca.ACTION_KINDS:
        raise HTTPException(404, "This report has no such action. Open the report again.")
    source = _ca.source_of(action)
    on_query = source == _ca.SOURCE_QUERY
    slug = "" if on_query else str(action.get("view_slug") or "")
    dataset_id = _ca._int(action.get("dataset_id")) if on_query else None
    label_base = str(action.get("label") or "Detail")
    audit = dict(report_id=report_id, action_id=action_id, execution_id=body.execution_id,
                 tile_id=body.tile_id, username=username, view_slug=slug)
    if on_query:
        audit.update(source=_ca.SOURCE_QUERY, dataset_id=dataset_id)
    if run_kind:
        audit.update(run_kind=run_kind)

    async def refuse(status: int, words: str, **extra) -> None:
        # a refusal is audited too (no file was made)
        await _adb(_ca.record_run, db, **audit, status=_ca.STATUS_REFUSED, message=words,
                   finished_at=_ca._now(), **extra)
        raise HTTPException(status, words)

    # the link is offered only where the action is placed
    places = [p for p in (action.get("on") or []) if isinstance(p, dict)]
    if body.tile_id is not None and places and not any(str(p.get("tile_id")) == body.tile_id for p in places):
        await refuse(400, f'"{label_base}" is not offered on this tile.')

    # the run: one the caller may read, and its stored result
    try:
        artifact = await _stored_result(db, report_id, report, body.execution_id, user)
    except HTTPException as exc:
        await refuse(exc.status_code, "You cannot use this run's result. Run the report yourself, then click."
                     if exc.status_code == 403 else str(exc.detail))
    if await _adb(_params_changed, db, body.execution_id, body.parameter_values):
        await refuse(409, "The parameters changed after this run. Run the report again, then click.")

    cols = await _adb(_dataset_columns, db, report)

    def phys(cid: Any) -> Optional[str]:
        c = cols.get(_ca._int(cid))
        return str(c.get("physical_name")) if c and c.get("physical_name") else None

    # the clicked row: the key names it; the values are READ from the result
    key: Dict[str, Any] = {}
    for cid, v in (body.row_key or {}).items():
        name = phys(cid)
        if name is None:
            await refuse(400, "The click names a column that is not in this report. Run the report again.")
        key[name] = v
    row_params = [p for p in action.get("params") or [] if isinstance(p, dict) and p.get("from") == "row"]
    wanted = [n for n in (phys(p.get("column_id")) for p in row_params) if n]
    try:
        stored = await asyncio.to_thread(_ca.read_clicked_values, artifact, key=key, wanted=wanted)
    except ActionRefused as exc:
        await refuse(exc.status, str(exc))
    row_values = {_ca._int(p.get("column_id")): stored.get(phys(p.get("column_id"))) for p in row_params}

    # linked-tile chips: each must be a value this user's result holds
    link_values: Dict[int, Any] = {}
    link_cols = {_ca._int(p.get("column_id")) for p in action.get("params") or []
                 if isinstance(p, dict) and p.get("from") == "link"}
    for ln in body.links:
        if ln.column_id not in link_cols:
            continue
        name = phys(ln.column_id)
        if not name or not await asyncio.to_thread(_ca.link_value_seen, artifact, name, ln.value):
            await refuse(400, "A linked filter names a value that is not in your result. Clear it and click again.")
        link_values[ln.column_id] = ln.value

    # the report's chosen parameters: only names the report declares
    declared = {p.get("name") for p in (await _adb(db.list_report_parameters, report_id) or [])
                if isinstance(p, dict)}
    params = {k: v for k, v in (body.parameter_values or {}).items() if k in declared}

    sent = _ca.build_sent(action, row_values=row_values, parameter_values=params, link_values=link_values)
    first_row = row_params[0] if row_params else {}
    value = row_values.get(_ca._int(first_row.get("column_id")))
    label = f"{_col_label(cols.get(_ca._int(first_row.get('column_id'))))} {_ca._plain(value)}".strip()

    click = _Click(db=db, report=report, action=action, source=source, slug=slug, dataset_id=dataset_id,
                   audit=audit, refuse=refuse, sent=sent, label=label, value=value, params=params,
                   cols=cols, username=username, user=user, pv=None, ds=None, principal=None,
                   filters=[], bindings=[], column_ids=[], qs="")
    if on_query:
        await _resolve_query_source(click)
    else:
        click.qs = _ca.query_string(sent)
        audit.update(values_sent=sent, query_string=click.qs, label=label)
        # the API, and whether THIS user may call it
        pv = await _adb(db.get_published_view_by_slug, slug) if slug else None
        if not pv or not pv.get("is_active"):
            await refuse(404, f"The API \"{slug}\" this action calls is no longer available, so no file was made. "
                              "Ask the report's owner to pick another.")
        principal = consumer_principal(user)
        why = _may_call(pv, principal)
        if why:
            await refuse(403, why)
        click.pv, click.principal = pv, principal
    return click


async def _file_name(click: _Click, ext: str = ".csv") -> str:
    subject = None
    try:
        subject = (await _adb(click.db.get_report_readiness_subject, click.report["id"]) or {}).get("business_date_param")
    except Exception:                                        # noqa: BLE001 -- no readiness = no subject
        subject = None
    report = click.report
    return _ca.file_name_for(
        click.action.get("file_name"), report_code=_ca.report_code_of(report),
        report_name=str(report.get("name") or ""), value=_ca._plain(click.value),
        business_date=_ca.business_date_of(click.params, subject), label=click.label, sent=click.sent, ext=ext)


@router.post("/api/business-reports/{report_id}/actions/{action_id}/run", status_code=202)
async def run_action(report_id: int, action_id: str, body: RunActionRequest,
                     background: BackgroundTasks, user: dict = Depends(require_capability("reports.view"))):
    click = await _resolve_click(report_id, action_id, body, user)
    db, report, audit = click.db, click.report, click.audit
    username, label = click.username, click.label
    if click.source == _ca.SOURCE_QUERY:
        # the query road as a file: the dataset's query, then the CSV
        file_name = await _file_name(click)
        run = await _adb(_ca.record_run, db, **audit, run_kind=_ca.RUN_FILE, file_format="csv",
                         file_name=file_name, message=f"Preparing {label} detail…")
        background.add_task(_produce_detail_file, run["run_id"], _spec_of(click), "csv", user, username,
                            file_name, label, report_id, report.get("name") or f"Report {report_id}", None)
        return {"run": _ca.public_run(run), "joined": False}

    joined = await _adb(_ca.find_preparing, db, report_id=report_id, action_id=action_id,
                        username=username, query=click.qs)
    if joined:
        return {"run": _ca.public_run(joined), "joined": True}

    file_name = await _file_name(click)
    run = await _adb(_ca.record_run, db, **audit, file_name=file_name,
                     message=f"Preparing {label} detail…")
    background.add_task(_produce_file, run["run_id"], click.pv, click.qs, click.principal, username, file_name, label,
                        report_id, report.get("name") or f"Report {report_id}")
    return {"run": _ca.public_run(run), "joined": False}


@router.get("/api/business-reports/{report_id}/actions/runs/{run_id}")
async def get_action_run(report_id: int, run_id: str, user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    report = await _require_report_view(report_id, user)
    run = await _adb(_ca.get_run, db, run_id)
    if not run or int(run.get("report_id") or 0) != int(report_id):
        raise HTTPException(404, "This download is not known. Click the link again.")
    if run.get("username") != user.get("username") and not _may_audit(report, user):
        raise HTTPException(404, "This download is not known. Click the link again.")
    return {"run": _ca.public_run(run)}


@router.get("/api/business-reports/{report_id}/actions/runs")
async def list_action_runs(report_id: int, limit: int = 50, user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    report = await _require_report_view(report_id, user)
    who = None if _may_audit(report, user) else user.get("username") or ""
    rows = await _adb(_ca.list_runs, db, report_id, username=who, limit=limit)
    return {"items": [_ca.public_run(r) for r in rows], "scope": "all" if who is None else "mine"}


def _may_audit(report: dict, user: dict) -> bool:
    from core.roles import ADMIN_TIER_ROLES
    username = (user or {}).get("username") or ""
    return bool(username) and ((user or {}).get("role") in ADMIN_TIER_ROLES or report.get("owner") == username)


# ── the job ───────────────────────────────────────────────────────────────

def _request_for(slug: str, path_suffix: str, qs: str):
    """The in-process call's request: the query string the API reads its
    parameters and filters from, and a request id that names the run."""
    from starlette.requests import Request
    scope = {
        "type": "http", "http_version": "1.1", "method": "GET" if path_suffix != "/bulk/prepare" else "POST",
        "scheme": "http", "path": f"/api/v1/views/{slug}{path_suffix}", "raw_path": f"/api/v1/views/{slug}{path_suffix}".encode(),
        "root_path": "", "query_string": qs.encode("ascii"),
        "headers": [(b"x-request-id", uuid.uuid4().hex[:16].encode()),
                    (b"user-agent", b"QueryStudio canvas action")],
        "client": ("canvas-action", 0), "server": ("querystudio", 80),
    }
    return Request(scope)


async def _bulk_csv(slug: str, qs: str, principal: dict):
    from fastapi import Response
    from api import published_views_api as _pva
    return await _pva.ext_bulk_csv(
        request=_request_for(slug, "/bulk.csv", qs), slug=slug, response=Response(), columns=None,
        max_rows=None, offset=0, cursor=None, received=None, dataset_version=None, batch_rows=None,
        cache="auto", snapshot_id=None, as_of_timestamp=None, api_user=principal)


async def _prepare_in_background(slug: str, qs: str, principal: dict) -> None:
    """The API's own background build (``bulk/prepare``), waited for; the
    stream that follows reads the built dataset."""
    from api import published_views_api as _pva
    from api.published_views import bulk as _bulk
    started = await _pva.ext_bulk_prepare(
        request=_request_for(slug, "/bulk/prepare", qs), slug=slug, cache="auto",
        snapshot_id=None, as_of_timestamp=None, api_user=principal)
    job = json.loads(bytes(started.body).decode("utf-8")) if hasattr(started, "body") else dict(started)
    deadline = time.monotonic() + float(_bulk.bulk_prepare_timeout_seconds()) + 60.0
    while job.get("status") not in ("ready", "failed"):
        if time.monotonic() > deadline:
            raise HTTPException(504, "The API's background build did not finish in time.")
        await asyncio.sleep(_PREPARE_POLL_SECONDS)
        job = await _pva.ext_bulk_prepare_status(slug=slug, job_id=job["job_id"], api_user=principal)
    if job.get("status") == "failed":
        raise HTTPException(500, str(job.get("error") or "The API's background build failed."))


async def _produce_file(run_id: str, pv: dict, qs: str, principal: dict, username: str,
                        file_name: str, label: str, report_id: int, report_name: str) -> None:
    """Call the API as the user, write the CSV, register it, say so."""
    from api import business_reports_api as _br
    db = _require_db()
    slug = pv.get("slug") or ""
    api_name = pv.get("name") or slug
    path: Optional[Path] = None
    try:
        try:
            resp = await _bulk_csv(slug, qs, principal)
        except HTTPException as exc:
            if exc.status_code != 504:
                raise
            # too big for one request: the API's background road, then the file
            await _prepare_in_background(slug, qs, principal)
            resp = await _bulk_csv(slug, qs, principal)
        headers = {k.lower(): v for k, v in resp.headers.items()}
        file_id, path = _br._new_export_target(".csv")
        with open(path, "wb") as fh:
            async for chunk in resp.body_iterator:
                await asyncio.to_thread(fh.write, chunk if isinstance(chunk, (bytes, bytearray)) else chunk.encode("utf-8"))
        rows = int(headers.get("x-qs-expected-rows") or 0)
        total = int(headers.get("x-qs-total-rows") or rows)
        size = path.stat().st_size
        if rows <= 0:
            _br._discard_file(path)
            path = None
            await _adb(_ca.finish_run, db, run_id, status=_ca.STATUS_EMPTY, row_count=0, total_rows=total,
                       message=f"The API \"{api_name}\" has no rows for {label}, so no file was made.")
            _notify(db, username, report_id, report_name, run_id, ok=False,
                    title=f"{label}: no detail rows", text=f"The API \"{api_name}\" has no rows for {label}.")
            return
        kept = await _adb(_br._register_export_file, file_id, path, file_name, username,
                          _br._export_expires_at(None))
        if not kept:
            raise RuntimeError("the file could not be registered in the Download Centre")
        path = None                                          # it belongs to the Download Centre now
        words = _ca.ready_words(label, file_name, rows, size, total if total > rows else None)
        await _adb(_ca.finish_run, db, run_id, status=_ca.STATUS_READY, row_count=rows, total_rows=total,
                   file_size_bytes=size, download_id=file_id, message=words)
        _notify(db, username, report_id, report_name, run_id, ok=True, title=f"{label} detail is ready",
                text=words, file_name=file_name, rows=rows, size=size, download_id=file_id)
    except HTTPException as exc:
        words = _ca.refusal_words(exc.status_code, exc.detail, api_name)
        await _fail(db, run_id, words, username, report_id, report_name, label, path)
    except Exception as exc:                                 # noqa: BLE001 -- said in words, logged in full
        from core.error_sanitizer import sanitize_error
        logger.error("[canvas-action] run %s (%s) failed: %s", run_id, slug, sanitize_error(str(exc)), exc_info=True)
        await _fail(db, run_id, f"The detail file for {label} could not be made. Click the link to try again; "
                                "if it fails again, tell the report's owner.",
                    username, report_id, report_name, label, path)


async def _fail(db, run_id, words, username, report_id, report_name, label, path) -> None:
    if path is not None:
        from api import business_reports_api as _br
        _br._discard_file(path)
    await _adb(_ca.finish_run, db, run_id, status=_ca.STATUS_FAILED, message=words)
    _notify(db, username, report_id, report_name, run_id, ok=False, title=f"{label} detail failed", text=words)


def _notify(db, username: str, report_id: int, report_name: str, run_id: str, *, ok: bool,
            title: str, text: str, **facts) -> None:
    """The bell: the same sentence the report shows."""
    try:
        db.log_notification(
            event_type="report_detail_download_" + ("ready" if ok else "failed"),
            channel="websocket", recipient=username, status="sent", title=title,
            message=f"{report_name}: {text}",
            payload={"report_id": report_id, "run_id": run_id, **facts})
    except Exception as exc:                                 # noqa: BLE001 -- the file stands; the bell is extra
        logger.warning("[canvas-action] the notification for run %s was not recorded: %s", run_id, exc)


# ══ THE DETAIL POPUP (2026-10-31) ═════════════════════════════════════════
#
# Both roads read the detail ONCE into a parquet (the view's stored result):
# the popup pages it (within the cap), and every download writes THOSE rows
# -- all of them -- in the asked format through the report export writers
# (``export_stream.write_csv``, ``business_reports_api._write_excel_streaming``,
# a parquet writer), so the popup and its files can never disagree.

class FileRequest(BaseModel):
    format: str = Field("csv", pattern="^(csv|xlsx|parquet)$")
    deliver: str = Field("now", pattern="^(now|download_centre)$")


def _visible_columns(ds: dict, user: dict) -> List[dict]:
    """The dataset's columns this caller's role may read (hidden ones out) --
    the columns the detail selects and the only ones a filter may name."""
    role = (user or {}).get("role") or "viewer"
    out = []
    for c in ds.get("columns") or []:
        if c.get("is_hidden") or not c.get("physical_name") or _ca._int(c.get("id")) is None:
            continue
        wl = c.get("role_whitelist") or []
        if wl and role not in wl:
            continue
        out.append(c)
    return out


def _dataset_conditions(ds: dict) -> Tuple[List[dict], Optional[str]]:
    """The conditions of the dataset's own query (``core/source_filters``):
    ``([predicate dicts], reason when none can be read)``."""
    from core import source_filters as _sf
    try:
        from api.datasets_api import _require_federation
        dialect = _require_federation().dataset_sql_dialect(ds)
    except Exception:                                        # noqa: BLE001 -- the generic grammar reads it
        dialect = None
    disc = _sf.discover_cached(ds.get("base_query") or "", dialect)
    return [p.to_dict() for p in disc.predicates], disc.reason


#: the one sentence a saver gets for a source they may not use -- no names of it
NOT_AVAILABLE_DATASET = "the dataset it runs is not available to you, so it cannot be used here."
NOT_AVAILABLE_API = "the Published API it calls is not available to you, so it cannot be used here."


def action_targets_resolver(db, user: Optional[dict]):
    """For the save check (``canvas_actions.actions_problems(targets_for=)``):
    the names each action's SOURCE takes -- an API's declared parameters and
    ``filter.<col>`` for each allowed filter; a dataset's columns and
    ``where.<key>`` for each condition of its own query.

    SECURITY (review 2026-10-31): the names are listed ONLY from a source the
    SAVING user may use -- the dataset through ``dataset_can_view`` (the
    dataset routes' check) and only the columns their role may see
    (``_visible_columns``); the API through ``_may_call``.  A source they may
    not use answers ONE plain problem and no name of it (else the 422 would
    list another team's columns, conditions and parameters).  No user =
    nothing is listed."""
    def targets_for(action: dict):
        if _ca.source_of(action) == _ca.SOURCE_QUERY:
            ds_id = _ca._int(action.get("dataset_id"))
            if ds_id is None:
                return None, None                            # "pick the dataset" is said already
            ds = db.get_dataset_full(ds_id)
            if not ds:
                return None, "the dataset it runs is not there any more; pick another."
            from core.entitlements import dataset_can_view
            if not user or not dataset_can_view(ds, user, db=db):
                return None, NOT_AVAILABLE_DATASET
            names = {str(c["physical_name"]) for c in _visible_columns(ds, user)}
            names |= {_ca.WHERE_PREFIX + p["key"] for p in _dataset_conditions(ds)[0]}
            return names, None
        slug = str(action.get("view_slug") or "").strip()
        if not slug:
            return None, None                                # "pick the Published API" is said already
        pv = db.get_published_view_by_slug(slug)
        if not pv or not pv.get("is_active"):
            return None, f'the Published API "{slug}" is not there any more; pick another.'
        if not user or _may_call(pv, consumer_principal(user)) is not None:
            return None, NOT_AVAILABLE_API
        names = {str(p.get("name")) for p in pv.get("param_definitions") or [] if isinstance(p, dict) and p.get("name")}
        for f in pv.get("allowed_filters") or []:
            col = f.get("column") if isinstance(f, dict) else f
            if col:
                names.add(f"filter.{col}")
        return names, None
    return targets_for


async def _resolve_query_source(click: _Click) -> None:
    """The query road's checks: the dataset exists, THIS caller may read it,
    a dataset query may run here, and every value sent has a place in it
    (a typed filter on a column the caller may see, or a condition of the
    query) -- else refused in words, nothing run."""
    db, refuse, user = click.db, click.refuse, click.user
    click.audit.update(values_sent=click.sent, label=click.label)
    ds = await _adb(db.get_dataset_full, click.dataset_id) if click.dataset_id else None
    if not ds:
        await refuse(404, "The dataset this action runs is no longer available, so nothing was run. "
                          "Ask the report's owner to pick another.")
    from core.entitlements import dataset_can_view
    if not await _adb(dataset_can_view, ds, user, db=db):
        await refuse(403, f"You do not have access to the dataset \"{ds.get('name') or click.dataset_id}\", so "
                          "nothing was run. Ask its owner for access.")
    from core import config as _cfg
    if not bool(getattr(_cfg.federation, "enabled", True)):
        await refuse(503, "Running a dataset's query is switched off on this server. Ask an administrator.")
    visible = _visible_columns(ds, user)
    if not visible:
        await refuse(403, f"You cannot see any column of the dataset \"{ds.get('name')}\", so nothing was run.")
    conditions, _why = await asyncio.to_thread(_dataset_conditions, ds)
    try:
        filters, bindings = _ca.query_filters(
            click.sent, columns={str(c["physical_name"]): c for c in visible},
            conditions=[p["key"] for p in conditions])
    except ActionRefused as exc:
        await refuse(exc.status, str(exc))
    click.ds, click.filters, click.bindings = ds, filters, bindings
    click.column_ids = [int(c["id"]) for c in visible]
    if _ca.pass_parameters_of(click.action, click.report):
        await _apply_report_scope(click, visible, [p["key"] for p in conditions])
    click.qs = json.dumps({"dataset_id": click.dataset_id, "filters": click.filters, "source_bindings": click.bindings},
                          sort_keys=True, default=str)
    click.audit.update(query_string=click.qs, values_sent=click.sent)


def _skip(click: _Click, target: str, words: str) -> None:
    click.sent.append({"target": target, "from": _ca.FROM_REPORT, "skipped": True, "value": None, "words": words})


async def _apply_report_scope(click: _Click, visible: List[dict], condition_keys: List[str]) -> None:
    """(rig 2026-11-01) The report's OWN parameters and filters narrow the detail
    too, when the action says so (``pass_parameters``; on by default for a query
    on the report's own dataset).  SECURITY: the values are the RUN's -- read
    from the run's own record (core/reports/diagnostics.get_run_record), never
    the browser's -- and become exactly the filters the run used
    (``_build_report_filters`` / ``_build_source_bindings``: hidden defaults,
    periods, ranges, hierarchies, the report's fixed filters), each mapped onto
    the detail dataset by column NAME (a column the detail does not have is
    said, never dropped silently).  Everything applied or skipped is written
    into ``values_sent`` so the popup says which filters applied."""
    from api import business_reports_api as _br
    from core.reports.diagnostics import get_run_record
    from core.reports.param_model import is_empty
    exec_id = str(click.audit.get("execution_id") or "")
    rec = await _adb(get_run_record, click.db, exec_id) if exec_id else None
    recorded = ((rec or {}).get("facts") or {}).get("parameters") if rec else None
    if recorded is None:
        _skip(click, "report", "The report's parameters were not applied: this run's values were not recorded. "
                               "Run the report again, then click.")
        return
    values = {str(p.get("name")): p.get("value") for p in recorded
              if isinstance(p, dict) and p.get("name") and not is_empty(p.get("value"))}
    rid = int(click.report.get("id") or 0)
    try:
        filters = await _adb(_br._build_report_filters, click.report, values, click.db, rid, strict_parameter_names=False)
        bindings = await _adb(_br._build_source_bindings, click.report, values, click.db, rid)
    except HTTPException as exc:
        d = exc.detail
        _skip(click, "report", "The report's parameters were not applied: " + str(d.get("message") if isinstance(d, dict) else d))
        return
    by_lower = {str(c.get("physical_name") or "").lower(): c for c in visible}
    for f in filters:
        rc = click.cols.get(_ca._int(f.get("column_id"))) or {}
        name = str(rc.get("physical_name") or "")
        label = _col_label(rc) if rc else f"column {f.get('column_id')}"
        words = _ca.report_filter_words(f, label)
        dc = by_lower.get(name.lower()) if name else None
        if not dc or _ca._int(dc.get("id")) is None:
            _skip(click, name or label, f"{words}: not applied -- the detail has no column {name or label}.")
            continue
        click.filters.append({"column_id": _ca._int(dc["id"]), "operator": f.get("operator") or "eq", "value": f.get("value")})
        click.sent.append({"target": name, "from": _ca.FROM_REPORT, "value": f.get("value"),
                           "words": f"{words} (from the report's own parameters)"})
    have = {str(b.get("source_column") or "").lower() for b in click.bindings}
    for b in bindings:
        key = str(b.get("source_column") or "").lower()
        words = _ca.report_filter_words({"operator": b.get("operator") or "eq", "value": b.get("value")}, key)
        if key in have:
            continue                                   # the click's own value on that condition wins
        if key not in {str(k).lower() for k in condition_keys}:
            _skip(click, _ca.WHERE_PREFIX + key, f"{words}: not applied -- the detail's query has no condition '{key}'.")
            continue
        click.bindings.append(b)
        click.sent.append({"target": _ca.WHERE_PREFIX + key, "from": _ca.FROM_REPORT, "value": b.get("value"),
                           "words": f"{words} (from the report's own parameters)"})


def _spec_of(click: _Click) -> dict:
    """What is needed to read the detail again (a background file)."""
    if click.source == _ca.SOURCE_QUERY:
        return {"source": _ca.SOURCE_QUERY, "dataset_id": click.dataset_id, "filters": click.filters,
                "bindings": click.bindings, "column_ids": click.column_ids,
                "name": (click.ds or {}).get("name") or f"dataset {click.dataset_id}"}
    return {"source": _ca.SOURCE_API, "slug": click.slug, "qs": click.qs,
            "name": (click.pv or {}).get("name") or click.slug}


def _spec_of_run(run: dict) -> dict:
    """The same, from a recorded run (its query string is the record)."""
    if run.get("source") == _ca.SOURCE_QUERY:
        rec = json.loads(run.get("query_string") or "{}")
        return {"source": _ca.SOURCE_QUERY, "dataset_id": rec.get("dataset_id") or run.get("dataset_id"),
                "filters": rec.get("filters") or [], "bindings": rec.get("source_bindings") or [],
                "column_ids": None, "name": f"dataset {run.get('dataset_id')}"}
    return {"source": _ca.SOURCE_API, "slug": run.get("view_slug") or "", "qs": run.get("query_string") or "",
            "name": run.get("view_slug") or ""}


class _TooBig(Exception):
    """The source is too big to read on the request path (the API's 504)."""


def _views_dir() -> Path:
    from core.config import paths as _paths
    d = Path(str(_paths.parquet_dir)) / "canvas_action_views"
    d.mkdir(parents=True, exist_ok=True)
    return d


#: a popup's stored detail is kept this long (a download after that reads the source again)
_VIEW_KEEP_SECONDS = 24 * 3600


def _sweep_views(d: Path) -> None:
    cutoff = time.time() - _VIEW_KEEP_SECONDS
    try:
        for f in d.glob("*.parquet"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except OSError:
                continue
    except OSError:
        pass


async def _api_detail(slug: str, qs: str, principal: dict, out: Path,
                      max_rows: Optional[int] = None) -> Dict[str, int]:
    """The API road: the view's bulk PARQUET, called in process as the
    person (the same road and checks as ``bulk.csv``), written to ``out``.
    ``max_rows`` bounds what is read (the popup: cap + 1; a download: None =
    the API's own rule).  ``{rows, total}``: the rows in the file and the
    API's own total (read from its materialization, so exact)."""
    from fastapi import Response
    from api import published_views_api as _pva
    try:
        resp = await _pva.ext_bulk_stream(
            request=_request_for(slug, "/bulk", qs), slug=slug, response=Response(), format="parquet",
            columns=None, max_rows=max_rows, offset=0, cursor=None, received=None, dataset_version=None,
            batch_rows=None, cache="auto", snapshot_id=None, as_of_timestamp=None, sort=None,
            allow_partial=False, api_user=principal)
    except HTTPException as exc:
        if exc.status_code == 504:
            raise _TooBig() from None
        raise
    headers = {k.lower(): v for k, v in resp.headers.items()}
    with open(out, "wb") as fh:
        async for chunk in resp.body_iterator:
            await asyncio.to_thread(fh.write, chunk if isinstance(chunk, (bytes, bytearray)) else chunk.encode("utf-8"))
    rows = await asyncio.to_thread(_count_rows, out)
    total = int(headers.get("x-qs-total-rows") or rows)
    return {"rows": rows, "total": total}


async def _query_detail(spec: dict, user: dict, limit: int = 0) -> Dict[str, Any]:
    """The query road: the dataset's query through THE dataset execution
    path (``execute_dataset_query`` on the interactive admission gate) --
    its stored connections, THIS caller's role and row security
    (``user_ctx``), the typed filters and source bindings.  ``limit``: the
    popup reads cap + 1 (so it knows "more than the cap" without a full
    read); a download reads every row (``0``).  ``{path, rows}``."""
    from api.datasets_api import _require_federation, _run_engine_off_loop
    from core.entitlements import dataset_can_view
    db = _require_db()
    ds = await _adb(db.get_dataset_full, int(spec["dataset_id"]))
    if not ds or not await _adb(dataset_can_view, ds, user, db=db):
        raise HTTPException(403, "You do not have access to the dataset any more, so nothing was run.")
    column_ids = spec.get("column_ids") or [int(c["id"]) for c in _visible_columns(ds, user)]
    username = (user or {}).get("username") or ""
    exec_id = str(uuid.uuid4())
    await _adb(db.create_federation_execution, execution_id=exec_id, dataset_id=int(spec["dataset_id"]),
               sql_generated="", column_ids=column_ids, filters=spec.get("filters") or [], condition_ids=[],
               executed_by=username)
    try:
        result = await _run_engine_off_loop(
            _require_federation().execute_dataset_query, db=db, execution_id=exec_id, username=username,
            dataset_id=int(spec["dataset_id"]), column_ids=column_ids,
            filters=spec.get("filters") or None, source_bindings=spec.get("bindings") or None,
            limit=int(limit), user_role=(user or {}).get("role") or "viewer", user_ctx=user)
    except Exception as exc:
        await _adb(db.update_federation_execution, exec_id, status="failed", error_message=str(exc)[:2000])
        raise
    await _adb(db.update_federation_execution, exec_id, status="completed", output_path=result.output_path,
               total_rows=result.total_rows, duration_seconds=result.duration_seconds,
               sql_generated=result.sql_generated, sources_used=result.sources_used)
    path = Path(result.output_path)
    rows = await asyncio.to_thread(_count_rows, path)
    return {"path": path, "rows": rows}


def _dataset_of(path: Path):
    import pyarrow.dataset as pads
    return pads.dataset(str(path), format="parquet")


def _count_rows(path: Path) -> int:
    return int(_dataset_of(path).count_rows())


def _row_batches(path: Path, *, native: bool):
    """The stored detail as lists of tuples, batch by batch, in the export
    value convention (``native``: typed cells for a spreadsheet)."""
    import pyarrow.types as pat
    from core.reports.export_stream import export_cell_values, native_cell_values
    d = _dataset_of(path)
    # Text cells as the popup SHOWS them (``_cell_text``: a date as the date,
    # a timestamp without the 'T'), so the CSV and the screen say one thing;
    # a spreadsheet keeps typed dates (Excel shows a date cell as the date).
    kinds = ["date" if pat.is_date(f.type) else "timestamp" if pat.is_timestamp(f.type) else ""
             for f in d.schema]
    for b in d.to_batches():
        if b.num_rows:
            if native:
                cols = [native_cell_values(b.column(i)) for i in range(b.num_columns)]
            else:
                cols = [[_cell_text(v, k) for v in c] if k else c
                        for c, k in zip((export_cell_values(b.column(i)) for i in range(b.num_columns)), kinds)]
            yield list(zip(*cols))


def write_detail_file(src: Path, out: Path, fmt: str, title: str) -> int:
    """ALL the stored detail's rows into ``out`` in ``fmt``, through the
    report export writers; returns the rows written."""
    cols = list(_dataset_of(src).schema.names)
    if fmt == "csv":
        from core.reports.export_stream import write_csv
        n, _bytes = write_csv(out, cols, _row_batches(src, native=False))
        return n
    if fmt == "xlsx":
        from api.business_reports_api import _write_excel_streaming
        return _write_excel_streaming(str(out), cols, _row_batches(src, native=True),
                                      (title or "Detail")[:120], "1976D2", "FFFFFF", "", {})
    if fmt == "parquet":
        import pyarrow.parquet as pq
        d = _dataset_of(src)
        n = 0
        with pq.ParquetWriter(str(out), d.schema) as w:
            for b in d.to_batches():
                if b.num_rows:
                    w.write_batch(b)
                    n += b.num_rows
        return n
    raise ValueError(f"unknown format {fmt}")


def _detail_labels(db, spec: dict, report: dict) -> Dict[str, str]:
    """(rig 2026-11-01) The popup's headers in the dataset's DISPLAY names, by
    physical name (lower-cased): the query road's dataset; the API road falls
    back to the report's own dataset (a Published API over the same table)."""
    ds = None
    try:
        if spec.get("source") == _ca.SOURCE_QUERY and spec.get("dataset_id"):
            ds = db.get_dataset_full(int(spec["dataset_id"]))
        elif report.get("dataset_id"):
            ds = db.get_dataset_full(int(report["dataset_id"]))
    except Exception as exc:                                 # noqa: BLE001 -- names are a courtesy, never a failure
        logger.info("[canvas-action] display names not read: %s", exc)
    out: Dict[str, str] = {}
    for c in (ds or {}).get("columns") or []:
        if c.get("physical_name") and c.get("friendly_name"):
            out[str(c["physical_name"]).lower()] = str(c["friendly_name"])
    return out


def _cell_text(v: Any, kind: str) -> Any:
    """A date as ``YYYY-MM-DD``, a timestamp without the 'T' (rig 2026-11-01:
    'dt' showed 1997-01-21T00:00:00 for a DATE); anything else as it is."""
    if v is None or not isinstance(v, str):
        return v
    if kind == "date":
        return v[:10]
    if kind == "timestamp":
        return v.replace("T", " ")
    return v


def read_view_page(path: Path, *, page: int, page_size: int, cap: int,
                   known_total: Optional[int] = None, labels: Optional[Dict[str, str]] = None) -> dict:
    """One page of the stored detail, never past the first ``cap`` rows.
    The stored detail holds at most cap + 1 rows (the popup's bounded read):
    more than ``cap`` = capped; ``known_total`` = the source's own count
    when it gave one cheaply (the API), else ``None`` when capped."""
    import pyarrow.types as pat
    from core.json_utils import sanitize_for_json
    from core.reports.export_stream import export_cell_values
    d = _dataset_of(path)
    kinds = ["date" if pat.is_date(f.type) else "timestamp" if pat.is_timestamp(f.type) else "" for f in d.schema]
    stored = int(d.count_rows())
    shown = min(stored, cap)
    capped = stored > cap or (known_total is not None and known_total > shown)
    total = known_total if known_total is not None else (None if capped else stored)
    page = max(1, int(page))
    page_size = max(1, min(500, int(page_size)))
    start, end = (page - 1) * page_size, min(page * page_size, shown)
    rows: List[list] = []
    seen = 0
    if start < end:
        for b in d.to_batches():
            n = b.num_rows
            lo, hi = max(start - seen, 0), min(end - seen, n)
            if lo < hi:
                sl = b.slice(lo, hi - lo)
                cols = [export_cell_values(sl.column(i)) for i in range(sl.num_columns)]
                cols = [[_cell_text(v, k) for v in c] if k else c for c, k in zip(cols, kinds)]
                rows.extend([list(r) for r in zip(*cols)])
            seen += n
            if seen >= end:
                break
    lab = labels or {}
    return {"columns": [{"name": f.name, "type": str(f.type), "label": lab.get(str(f.name).lower()) or f.name} for f in d.schema],
            "rows": sanitize_for_json(rows), "page": page, "page_size": page_size,
            "total_rows": total, "shown_rows": shown, "capped": capped,
            "pages": max(1, -(-shown // page_size))}


async def _read_detail(spec: dict, run_id: str, user: dict, principal: Optional[dict],
                       cap: int) -> Dict[str, Any]:
    """The popup's BOUNDED read (review 2026-10-31: the cap must bound the
    read, not only the page): at most cap + 1 rows from either road, so a
    click never pulls the whole detail into the request.  ``{path, rows,
    total}`` -- ``total`` exact when the source counts cheaply (the API's
    materialization), else the rows read when they fit, else ``None``."""
    if spec["source"] == _ca.SOURCE_QUERY:
        got = await _query_detail(spec, user, limit=cap + 1)
        return {**got, "total": got["rows"] if got["rows"] <= cap else None}
    d = _views_dir()
    await asyncio.to_thread(_sweep_views, d)
    out = d / f"{run_id}.parquet"
    try:
        got = await _api_detail(spec["slug"], spec["qs"], principal or consumer_principal(user), out,
                                max_rows=cap + 1)
    except BaseException:
        out.unlink(missing_ok=True)
        raise
    return {"path": out, **got}


def _view_complete(view: dict) -> bool:
    """Does the popup's stored detail hold EVERY row (then a download writes
    it straight away)?  Only when the true total is known and equals it."""
    total, rows = view.get("total_rows"), view.get("row_count")
    return total is not None and rows is not None and int(total) == int(rows)


def _why_failed(exc: BaseException, spec: dict) -> Tuple[int, str]:
    """A failed read in words (never the raw error text)."""
    if isinstance(exc, _TooBig):
        return 413, ("This detail is too big to show here. Send it to the Download Centre: "
                     "you will be told when the file is ready.")
    if isinstance(exc, HTTPException):
        if spec["source"] == _ca.SOURCE_API:
            return exc.status_code, _ca.refusal_words(exc.status_code, exc.detail, spec.get("name") or "")
        return exc.status_code, str(exc.detail)
    if isinstance(exc, ValueError):
        # the engine's refusals are sentences (a value a column cannot hold,
        # a condition that cannot take the value, row security that cannot apply)
        from core.error_sanitizer import sanitize_error
        return 422, f"The dataset's query refused the values sent: {sanitize_error(str(exc))[:400]}"
    return 500, "The detail could not be read. Click again; if it fails again, tell the report's owner."


def _view_payload(run: dict, page: dict, action: dict, sent: list, cols: Dict[int, dict]) -> dict:
    words = _ca.view_words(shown=page["shown_rows"], total=page["total_rows"], capped=page["capped"])
    return {**page, "complete": _view_complete(run), "title": f"{run.get('label') or 'Row'} detail", "words": words,
            "sent": _ca.sent_words(action, sent, cols), "source": run.get("source") or _ca.SOURCE_API}


@router.post("/api/business-reports/{report_id}/actions/{action_id}/view")
async def view_action(report_id: int, action_id: str, body: RunActionRequest,
                      page_size: int = 50, user: dict = Depends(require_capability("reports.view"))):
    """The popup: the click checked exactly as a file click, the detail read
    ONCE (as the person, on the action's road), its first page."""
    click = await _resolve_click(report_id, action_id, body, user, run_kind=_ca.RUN_VIEW)
    db = click.db
    file_name = await _file_name(click)
    run = await _adb(_ca.record_run, db, **click.audit, file_name=file_name,
                     message=f"Reading {click.label} detail…")
    spec = _spec_of(click)
    cap = _ca.popup_max_rows()
    try:
        got = await _read_detail(spec, run["run_id"], user, click.principal, cap)
    except Exception as exc:                                 # noqa: BLE001 -- said in words, logged
        status, words = _why_failed(exc, spec)
        if status >= 500:
            from core.error_sanitizer import sanitize_error
            logger.error("[canvas-action] view %s failed: %s", run["run_id"], sanitize_error(str(exc)), exc_info=True)
        await _adb(_ca.finish_run, db, run["run_id"], status=_ca.STATUS_FAILED, message=words)
        raise HTTPException(status, {"message": words, "run_id": run["run_id"], "too_big": status == 413})
    page = await asyncio.to_thread(read_view_page, got["path"], page=1, page_size=page_size, cap=cap,
                                   known_total=got["total"], labels=await _adb(_detail_labels, db, spec, click.report))
    words = _ca.view_words(shown=page["shown_rows"], total=page["total_rows"], capped=page["capped"])
    done = await _adb(_ca.finish_run, db, run["run_id"], status=_ca.STATUS_SHOWN, row_count=got["rows"],
                      total_rows=got["total"], result_path=str(got["path"]), message=words)
    return {"run": _ca.public_run(done), "view": _view_payload(done, page, click.action, click.sent, click.cols)}


async def _own_view(report_id: int, run_id: str, user: dict) -> Tuple[dict, dict]:
    """The caller's OWN popup view on this report -- its rows were read as
    them, so nobody else (not the owner, not an admin) reads them."""
    db = _require_db()
    report = await _require_report_view(report_id, user)
    run = await _adb(_ca.get_run, db, run_id)
    if (not run or int(run.get("report_id") or 0) != int(report_id) or run.get("run_kind") != _ca.RUN_VIEW
            or not user.get("username") or run.get("username") != user.get("username")):
        raise HTTPException(404, "This detail is not known. Click the link again.")
    run["result_path"] = await _adb(_ca.view_result_path, db, run_id)      # server side only
    return report, run


@router.get("/api/business-reports/{report_id}/actions/runs/{run_id}/rows")
async def view_rows(report_id: int, run_id: str, page: int = 1, page_size: int = 50,
                    user: dict = Depends(require_capability("reports.view"))):
    report, run = await _own_view(report_id, run_id, user)
    path = Path(run.get("result_path") or "")
    if run.get("status") != _ca.STATUS_SHOWN or not run.get("result_path") or not path.exists():
        raise HTTPException(410, "This detail is no longer kept. Click the link again.")
    pg = await asyncio.to_thread(read_view_page, path, page=page, page_size=page_size, cap=_ca.popup_max_rows(),
                                 known_total=run.get("total_rows"),
                                 labels=await _adb(_detail_labels, _require_db(), _spec_of_run(run), report))
    canvas = ((report.get("layout_config") or {}) if isinstance(report.get("layout_config"), dict) else {}).get("canvas")
    action = _ca.find_action(canvas, run.get("action_id")) or {}
    cols = await _adb(_dataset_columns, _require_db(), report)
    return {"run": _ca.public_run(run), "view": _view_payload(run, pg, action, run.get("values_sent") or [], cols)}


@router.post("/api/business-reports/{report_id}/actions/runs/{run_id}/file")
async def view_file(report_id: int, run_id: str, body: FileRequest, background: BackgroundTasks,
                    user: dict = Depends(require_capability("reports.view"))):
    """A download from the popup: ALL the detail's rows in ``format``,
    registered in the Download Centre under the caller.  ``now`` on a view
    whose stored detail holds every row (``_view_complete``) answers with the
    ready file (200).  Anything bigger -- a capped view, a view too big to
    show, ``download_centre`` -- is a FULL read, and a full read happens only
    on the background Download Centre road (202, ``background: true``), never
    inside the request."""
    from api import business_reports_api as _br
    report, view = await _own_view(report_id, run_id, user)
    db = _require_db()
    fmt, ext = body.format, _ca.FILE_FORMATS[body.format]
    base = view.get("file_name") or "detail.csv"
    file_name = (base[:-4] if base.lower().endswith(".csv") else base) + ext
    src = Path(view.get("result_path") or "")
    have = (view.get("status") == _ca.STATUS_SHOWN and bool(view.get("result_path")) and src.exists()
            and _view_complete(view))
    fields = dict(report_id=report_id, action_id=view["action_id"], execution_id=view["execution_id"],
                  tile_id=view.get("tile_id"), username=view["username"], view_slug=view.get("view_slug") or "",
                  label=view.get("label"), values_sent=view.get("values_sent"), query_string=view.get("query_string"),
                  run_kind=_ca.RUN_FILE, source=view.get("source"), dataset_id=view.get("dataset_id"),
                  file_format=fmt, parent_run_id=view["run_id"], file_name=file_name)
    label = view.get("label") or "Detail"
    report_name = report.get("name") or f"Report {report_id}"
    if body.deliver == "download_centre" or not have:
        run = await _adb(_ca.record_run, db, **fields, message=f"Preparing {label} detail ({_ca.FORMAT_WORDS[fmt]})…")
        background.add_task(_produce_detail_file, run["run_id"], _spec_of_run(view), fmt, user, view["username"],
                            file_name, label, report_id, report_name, str(src) if have else None)
        words = None if body.deliver == "download_centre" else (
            "This detail has more rows than the popup reads, so the whole file is made in the Download Centre. "
            "You will be told when it is ready.")
        return JSONResponse(status_code=202, content={"run": _ca.public_run(run), "background": True,
                                                      "message": words})
    run = await _adb(_ca.record_run, db, **fields, message=f"Writing {file_name}…")
    file_id, path = _br._new_export_target(ext)
    try:
        rows = await _br._run_export_work(write_detail_file, src, path, fmt, label, username=view["username"])
        kept = await _adb(_br._register_export_file, file_id, path, file_name, view["username"],
                          _br._export_expires_at(None))
        if not kept:
            raise RuntimeError("the file could not be registered in the Download Centre")
    except Exception as exc:                                 # noqa: BLE001 -- said in words, logged
        from core.error_sanitizer import sanitize_error
        logger.error("[canvas-action] file %s failed: %s", run["run_id"], sanitize_error(str(exc)), exc_info=True)
        _br._discard_file(path)
        words = f"The {_ca.FORMAT_WORDS[fmt]} file for {label} could not be made. Try again."
        await _adb(_ca.finish_run, db, run["run_id"], status=_ca.STATUS_FAILED, message=words)
        raise HTTPException(500, words) from None
    size = path.stat().st_size
    done = await _adb(_ca.finish_run, db, run["run_id"], status=_ca.STATUS_READY, row_count=rows,
                      total_rows=view.get("total_rows") or rows, file_size_bytes=size, download_id=file_id,
                      message=_ca.ready_words(label, file_name, rows, size, None))
    return {"run": _ca.public_run(done)}


async def _produce_detail_file(run_id: str, spec: dict, fmt: str, user: dict, username: str, file_name: str,
                               label: str, report_id: int, report_name: str, src: Optional[str]) -> None:
    """A detail FILE in the background (the query road's click, a popup's
    "Send to Download Centre"): the stored detail when there is one, else
    the source read again as the person (a big API through its own
    background build), then the format, the Download Centre and the bell."""
    from api import business_reports_api as _br
    db = _require_db()
    path: Optional[Path] = None
    tmp: Optional[Path] = None
    try:
        source_path = Path(src) if src and Path(src).exists() else None
        total: Optional[int] = None
        if source_path is None:
            if spec["source"] == _ca.SOURCE_QUERY:
                got = await _query_detail(spec, user)
            else:
                principal = consumer_principal(user)
                tmp = _views_dir() / f"{run_id}.parquet"
                try:
                    got = await _api_detail(spec["slug"], spec["qs"], principal, tmp)
                except _TooBig:
                    await _prepare_in_background(spec["slug"], spec["qs"], principal)
                    got = await _api_detail(spec["slug"], spec["qs"], principal, tmp)
                got["path"] = tmp
            source_path, total = got["path"], got.get("total")
        ext = _ca.FILE_FORMATS[fmt]
        file_id, path = _br._new_export_target(ext)
        rows = await _br._run_export_work(write_detail_file, source_path, path, fmt, label, username=username)
        size = path.stat().st_size
        if rows <= 0:
            _br._discard_file(path)
            path = None
            words = f"There are no detail rows for {label}, so no file was made."
            await _adb(_ca.finish_run, db, run_id, status=_ca.STATUS_EMPTY, row_count=0, total_rows=total or 0,
                       message=words)
            _notify(db, username, report_id, report_name, run_id, ok=False, title=f"{label}: no detail rows", text=words)
            return
        kept = await _adb(_br._register_export_file, file_id, path, file_name, username, _br._export_expires_at(None))
        if not kept:
            raise RuntimeError("the file could not be registered in the Download Centre")
        path = None
        total = total if total is not None else rows
        words = _ca.ready_words(label, file_name, rows, size, total if total > rows else None)
        await _adb(_ca.finish_run, db, run_id, status=_ca.STATUS_READY, row_count=rows, total_rows=total,
                   file_size_bytes=size, download_id=file_id, message=words)
        _notify(db, username, report_id, report_name, run_id, ok=True, title=f"{label} detail is ready",
                text=words, file_name=file_name, rows=rows, size=size, download_id=file_id)
    except Exception as exc:                                 # noqa: BLE001 -- said in words, logged in full
        status, words = _why_failed(exc, spec)
        if status >= 500:
            from core.error_sanitizer import sanitize_error
            logger.error("[canvas-action] file run %s failed: %s", run_id, sanitize_error(str(exc)), exc_info=True)
            words = (f"The detail file for {label} could not be made. Click the link to try again; "
                     "if it fails again, tell the report's owner.")
        await _fail(db, run_id, words, username, report_id, report_name, label, path)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


# ── the builder's lists for the query road ──────────────────────────────

@router.get("/api/business-reports/{report_id}/actions/datasets")
async def list_action_datasets(report_id: int, user: dict = Depends(require_capability("reports.view"))):
    """The datasets this caller may read -- the builder offers only these."""
    await _require_report_view(report_id, user)
    db = _require_db()
    from core.entitlements import dataset_can_view
    out = []
    for d in await _adb(db.list_datasets) or []:
        if await _adb(dataset_can_view, d, user, db=db):
            out.append({"id": d.get("id"), "name": d.get("name"), "description": d.get("description") or ""})
    out.sort(key=lambda x: str(x.get("name") or "").lower())
    return {"items": out}


@router.get("/api/business-reports/{report_id}/actions/datasets/{dataset_id}")
async def get_action_dataset(report_id: int, dataset_id: int, user: dict = Depends(require_capability("reports.view"))):
    """What a value can be given to on the query road: the dataset's columns
    the caller may see (``=`` one value, ``IN`` several) and the conditions
    of its own query (``where.<key>``; ``conditions_reason`` says why there
    are none -- never an empty list that reads as "has none")."""
    await _require_report_view(report_id, user)
    db = _require_db()
    from core.entitlements import dataset_can_view
    ds = await _adb(db.get_dataset_full, dataset_id)
    if not ds or not await _adb(dataset_can_view, ds, user, db=db):
        raise HTTPException(404, "This dataset is not one you may read.")
    conds, why = await asyncio.to_thread(_dataset_conditions, ds)
    return {
        "id": ds.get("id"), "name": ds.get("name"),
        "columns": [{"name": c["physical_name"], "label": c.get("friendly_name") or c["physical_name"],
                     "data_type": c.get("data_type") or "string", "column_type": c.get("column_type") or "dimension"}
                    for c in _visible_columns(ds, user)],
        "conditions": [{"name": _ca.WHERE_PREFIX + p["key"], "column": p.get("column"), "op": p.get("op"),
                        "words": f"Condition in the query on {p.get('column')} (now: {', '.join(p.get('values') or [])})"}
                       for p in conds],
        "conditions_reason": why if not conds else None,
    }
