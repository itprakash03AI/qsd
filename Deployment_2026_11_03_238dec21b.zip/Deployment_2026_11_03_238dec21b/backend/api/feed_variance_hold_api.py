"""Variance holds -- the queue of files the row-count check HELD, and the
release group's two decisions (2026-10-12, owner R2; core/feed/variance_hold.py).

Who sees a hold: admin / support, anyone who may VIEW the feed (its owner,
its group) and anyone who may DECIDE it.  Who decides (2026-10-12): an admin,
the feed's owner, or a member of a user group MAPPED as an approver for it
(global / feed group / template / feed -- ``/api/feed-hold-approvers``, admin)
-- ``variance_hold.decision_authority``; every hold row carries
``can_decide`` + ``decision_authority`` for the caller.
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import date
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user, require_admin, require_capability
from core.db.models import HOLD_APPROVER_SCOPES
from api.strict_request import StrictRequestModel
from core.feed import variance_hold as vh

logger = logging.getLogger(__name__)
router = APIRouter(tags=["feed-variance-holds"])

_db_manager: Any = None


def set_feed_variance_hold_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="Variance holds are not wired to a database")
    return _db_manager


class HoldDecisionBody(StrictRequestModel):
    reason: str


def _sees_all(db, user: dict) -> bool:
    from core.entitlements import is_admin_like, is_support
    return bool(is_admin_like(user) or is_support(user))


def _visible(db, user: dict, holds: list) -> list:
    if _sees_all(db, user):
        return holds
    from core.feed.permissions import can_view_feed
    feeds: dict = {}
    out = []
    for h in holds:
        fid = int(h["feed_config_id"])
        if fid not in feeds:
            feeds[fid] = db.get_feed_config(fid)
        try:
            if (feeds[fid] and can_view_feed(feeds[fid], user, db))                     or vh.decision_authority(db, user, h)[0]:
                out.append(h)
        except Exception:                               # noqa: BLE001 -- fail closed
            continue
    return out


def _one(db, user: dict, hold_id: int) -> dict:
    h = db.get_variance_hold(hold_id)
    if not h or not _visible(db, user, [h]):
        # the same answer for "absent" and "not yours"
        raise HTTPException(status_code=404, detail=f"variance hold {hold_id} not found")
    return h


@router.get("/api/feed-variance-holds")
async def list_holds(status: Optional[str] = Query(None, description="held,release_failed,..."),
                     business_date: Optional[date] = None,
                     feed_config_id: Optional[int] = None,
                     limit: int = Query(5000, ge=1, le=5000),
                     page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                     user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    holds = await asyncio.to_thread(db.list_variance_holds, status=status,
                                    business_date=business_date,
                                    feed_config_id=feed_config_id, limit=limit)
    holds = await asyncio.to_thread(_visible, db, user, holds)
    # the counts are over every hold this user may see; the page is cut
    # after the visibility rule (it is not SQL) -- core/feed/paging.py
    counts: dict = {}
    for h in holds:
        counts[h["status"]] = counts.get(h["status"], 0) + 1
    from core.feed.paging import block, paging, slice_rows
    _p = paging(page, page_size)
    holds, _total = slice_rows(holds, _p)
    may, why = await asyncio.to_thread(vh.decision_authority, db, user)

    def _per_hold():
        for h in holds:
            h["can_decide"], h["decision_authority"] = vh.decision_authority(db, user, h)
    await asyncio.to_thread(_per_hold)
    may = may or any(h["can_decide"] for h in holds)
    return {"holds": holds, "counts": counts, "release_group": vh.release_group_name(),
            "can_decide": may, "decision_authority": why,
            "paging": block(_total, _p, len(holds))}


@router.get("/api/feed-variance-holds/{hold_id}")
async def get_hold(hold_id: int, user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    h = await asyncio.to_thread(_one, db, user, hold_id)
    h["file_present"] = bool(h.get("artifact_path") and os.path.exists(h["artifact_path"]))
    h["can_decide"], h["decision_authority"] = await asyncio.to_thread(vh.decision_authority, db, user, h)
    return h


@router.get("/api/feed-variance-holds/{hold_id}/preview")
async def preview_hold(hold_id: int, lines: int = Query(20, ge=1, le=500),
                       user: dict = Depends(require_capability("feeds.view"))):
    """The first lines of the HELD file -- what the verifier inspects
    before deciding.  Text formats only; a binary file says so."""
    db = _db()
    h = await asyncio.to_thread(_one, db, user, hold_id)
    path = str(h.get("artifact_path") or "")
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=410,
                            detail=f"the held file is no longer on the output volume ({path})")
    def _read():
        out = []
        with open(path, "rb") as fh:
            head = fh.read(4)
            if head[:2] == b"\x1f\x8b" or head == b"PAR1" or head[:2] == b"PK":
                return None
            fh.seek(0)
            for _ in range(lines):
                raw = fh.readline()
                if not raw:
                    break
                out.append(raw.decode("utf-8", errors="replace").rstrip("\r\n"))
        return out
    got = await asyncio.to_thread(_read)
    if got is None:
        return {"hold_id": hold_id, "lines": [], "binary": True,
                "detail": "the file is compressed or binary; download it from the "
                          "execution to inspect it"}
    return {"hold_id": hold_id, "lines": got, "binary": False}


async def _decide(fn, hold_id: int, body: HoldDecisionBody, user: dict) -> dict:
    db = _db()
    await asyncio.to_thread(_one, db, user, hold_id)
    try:
        row = await asyncio.to_thread(fn, db, hold_id, user, body.reason)
    except vh.HoldRefused as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))
    try:
        from core.audit import audit_event
        audit_event(db, user or {}, action=f"feed_variance_hold_{row.get('status')}",
                    details={"hold_id": hold_id, "feed_config_id": row.get("feed_config_id"),
                             "business_date": row.get("business_date"),
                             "reason": body.reason,
                             "delivery_verdict": row.get("delivery_verdict")})
    except Exception:                                   # pragma: no cover - audit is soft
        pass
    return row


@router.post("/api/feed-variance-holds/{hold_id}/release")
async def release_hold(hold_id: int, body: HoldDecisionBody,
                       user: dict = Depends(require_capability("feeds.release_hold"))):
    """Send the HELD file (the same bytes) through the feed's delivery chain."""
    return await _decide(vh.release, hold_id, body, user)


@router.post("/api/feed-variance-holds/{hold_id}/reject")
async def reject_hold(hold_id: int, body: HoldDecisionBody,
                      user: dict = Depends(require_capability("feeds.release_hold"))):
    """Never send this file.  A corrected file comes from a rerun, which is
    checked again."""
    return await _decide(vh.reject, hold_id, body, user)


# ── approver mappings (2026-10-12): a user group at a scope ──────────────

class ApproverBody(StrictRequestModel):
    scope: str
    scope_id: Optional[int] = None
    user_group_id: int


def _named_approver(db, a: dict) -> dict:
    g = db.get_user_group(int(a["user_group_id"])) or {}
    label = "every feed"
    try:
        if a["scope"] == "feed_group":
            fg = next((x for x in db.list_feed_groups() or [] if x.get("id") == a["scope_id"]), None)
            label = f"feed group {(fg or {}).get('name', a['scope_id'])}"
        elif a["scope"] == "template":
            t = db.get_feed_template(int(a["scope_id"])) or {}
            label = f"template {t.get('name', a['scope_id'])}"
        elif a["scope"] == "feed":
            f = db.get_feed_config(int(a["scope_id"])) or {}
            label = f"feed {f.get('name', a['scope_id'])}"
    except Exception:                                   # noqa: BLE001 -- the id is still shown
        label = f"{a['scope']} {a['scope_id']}"
    return {**a, "user_group_name": g.get("name"), "applies_to": label}


@router.get("/api/feed-hold-approvers")
async def list_approvers(user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    rows = await asyncio.to_thread(db.list_hold_approvers)
    return {"approvers": await asyncio.to_thread(lambda: [_named_approver(db, a) for a in rows]),
            "scopes": list(HOLD_APPROVER_SCOPES), "deployment_group": vh.release_group_name() or None}


@router.post("/api/feed-hold-approvers", status_code=201)
async def add_approver(body: ApproverBody, user: dict = Depends(require_capability("feeds.manage"))):
    db = _db()
    if body.scope not in HOLD_APPROVER_SCOPES:
        raise HTTPException(status_code=422, detail=f"scope must be one of {list(HOLD_APPROVER_SCOPES)}")
    if (body.scope == "global") != (body.scope_id is None):
        raise HTTPException(status_code=422, detail="scope_id is required for feed_group / template / "
                                                    "feed, and must be absent for global")

    def _check():
        if not db.get_user_group(int(body.user_group_id)):
            return f"user group {body.user_group_id} does not exist"
        if body.scope == "feed_group" and not any(g.get("id") == body.scope_id for g in db.list_feed_groups() or []):
            return f"feed group {body.scope_id} does not exist"
        if body.scope == "template" and not db.get_feed_template(int(body.scope_id)):
            return f"template {body.scope_id} does not exist"
        if body.scope == "feed" and not db.get_feed_config(int(body.scope_id)):
            return f"feed {body.scope_id} does not exist"
        return None
    problem = await asyncio.to_thread(_check)
    if problem:
        raise HTTPException(status_code=422, detail=problem)
    row = await asyncio.to_thread(db.create_hold_approver, body.scope, body.scope_id,
                                  body.user_group_id, user.get("username"))
    logger.info("[variance_hold] approver %s mapped at %s %s by %s", body.user_group_id,
                body.scope, body.scope_id, user.get("username"))
    return await asyncio.to_thread(_named_approver, db, row)


@router.delete("/api/feed-hold-approvers/{approver_id}")
async def remove_approver(approver_id: int, user: dict = Depends(require_capability("feeds.manage"))):
    db = _db()
    if not await asyncio.to_thread(db.delete_hold_approver, approver_id):
        raise HTTPException(status_code=404, detail=f"approver mapping {approver_id} not found")
    return {"deleted": approver_id}
