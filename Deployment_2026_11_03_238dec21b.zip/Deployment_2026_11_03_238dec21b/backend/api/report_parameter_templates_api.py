"""Report parameter TEMPLATES -- routes (2026-11-01; the rules are core/reports/param_contract.py).

A template ("Business date (LDN calendar)", "Legal entity", "Currency") is a
parameter's definition kept ONCE in ``report_parameter_templates`` and
attached to many reports by ``report_parameters.template_id``; a change here
applies to every report on its next read.  RELEASE by name, ``is_active``.

  GET    /api/report-parameter-templates          authors (reports.create) -- a definition names connections, tables, lists
  GET    /api/report-parameter-templates/kinds    the vocabularies (kinds, targets, default rules)
  POST   /api/report-parameter-templates          authors (reports.create)
  PUT    /api/report-parameter-templates/{id}     authors
  DELETE /api/report-parameter-templates/{id}     switch off (authors); reports keep their own row
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.deps import require_capability
from core.audit import audit_event
from core.reports import param_contract as pc

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/report-parameter-templates", tags=["report-parameter-templates"])
_db_manager = None


def set_report_parameter_templates_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


class TemplateBody(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    definition: Optional[Dict[str, Any]] = None


def _require_owner(tpl: Dict[str, Any], user: dict) -> None:
    if not pc.may_change_template(tpl, user):
        raise HTTPException(status_code=403, detail="Only the template's author or an admin can change it: a change "
                                                    "applies to every report attached to it.")


async def _check(name: Any, definition: Any, db=None, user: Optional[dict] = None) -> None:
    problems = []
    if not isinstance(name, str) or not name.strip():
        problems.append("a template needs a name.")
    elif len(name) > 100:
        problems.append("the name is at most 100 characters.")
    if not isinstance(definition, dict):
        problems.append("a template needs its definition (the parameter's settings).")
    else:
        unknown = [k for k in definition if k not in pc.TEMPLATE_FIELDS and k != "name"]
        if unknown:
            problems.append(f"these are not settings of a parameter: {', '.join(sorted(unknown))}.")
        problems += pc.parameter_problems([{**definition, "name": name}])
    if problems:
        raise HTTPException(status_code=422, detail={"error": "template_problems", "problems": problems,
                                                     "message": "The template cannot be saved: " + " ".join(problems)})
    # SECURITY (review 2026-11-01): the SAME save checks a parameter gets, as the caller
    if db is not None and user is not None and isinstance(definition, dict):
        await pc.definition_checks(db, definition, user, name=str(name))


@router.get("")
async def list_templates(user: dict = Depends(require_capability("reports.create"))):
    """SECURITY (review 2026-11-01): a definition carries connection, table and
    list ids -- authors only; an error is said in plain words, never its text."""
    db = _db()
    try:
        rows = await asyncio.to_thread(db.list_report_parameter_templates)
    except Exception as exc:                                  # noqa: BLE001
        logger.warning("[param-templates] library not read: %s", exc)
        raise HTTPException(status_code=503, detail="The template library could not be read just now. Try again in a "
                                                    "moment; if it keeps failing, tell an administrator.") from None
    return {"templates": rows}


async def _refuse_breaking_attached_reports(db, template_id: int, name: str, definition: Dict[str, Any], user: dict) -> None:
    """SECURITY (review 2026-11-01): a template's change flows into every
    attached report -- so the NEW definition is checked against each of them
    (the merged parameter under that report's dataset, as the caller) and the
    change is refused in words, before anything is written.  Only a report the
    caller may VIEW is named with its problem (commit review 2026-11-01); the
    others are a COUNT -- no name, no problem text."""
    from api.business_reports_api import _br_can_view, _refuse_parameter_contract
    broken, unseen = [], 0
    for rid in await asyncio.to_thread(db.reports_using_template, int(template_id)):
        report = await asyncio.to_thread(db.get_business_report, int(rid))
        if not report:
            continue
        params = await asyncio.to_thread(db.list_report_parameters, int(rid))
        try:
            await _refuse_parameter_contract(db, report, params, user, changed=[],
                                             templates={int(template_id): {"id": int(template_id), "name": name,
                                                                           "definition": definition}})
        except HTTPException as exc:
            if not await asyncio.to_thread(_br_can_view, report, user):
                unseen += 1
                continue
            d = exc.detail
            words = d.get("message") if isinstance(d, dict) else str(d)
            broken.append(f'report "{report.get("name") or rid}": {words}')
    if broken or unseen:
        parts = list(broken)
        if unseen:
            parts.append(f"{unseen} other report{'s' if unseen != 1 else ''} you cannot see would break")
        raise HTTPException(status_code=422, detail={
            "error": "template_breaks_reports", "problems": parts, "unseen_reports": unseen,
            "message": "The change was not saved because it would break " + "; ".join(parts)
                       + ". Fix those reports first, or detach them from the template."})


@router.get("/kinds")
async def kinds(user: dict = Depends(require_capability("reports.view"))):
    """What a parameter can be -- read by the editor, never re-spelled there."""
    return {"kinds": pc.KINDS, "targets": pc.TARGETS, "default_rules": pc.DEFAULT_RULES,
            "template_fields": pc.TEMPLATE_FIELDS, "overridable": pc.TEMPLATE_OVERRIDABLE}


@router.post("")
async def create_template(body: TemplateBody, user: dict = Depends(require_capability("reports.create"))):
    db = _db()
    await _check(body.name, body.definition, db, user)
    if await asyncio.to_thread(db.get_report_parameter_template_by_name, str(body.name).strip()):
        raise HTTPException(status_code=409, detail=f'A template named "{body.name}" already exists.')
    row = await asyncio.to_thread(db.create_report_parameter_template, body.model_dump(), user.get("username", ""))
    audit_event("report_parameter_template.created", user=user.get("username"), details={"id": row["id"], "name": row["name"]})
    return row


@router.put("/{template_id}")
async def update_template(template_id: int, body: TemplateBody, user: dict = Depends(require_capability("reports.create"))):
    db = _db()
    cur = await asyncio.to_thread(db.get_report_parameter_template, template_id)
    if not cur:
        raise HTTPException(status_code=404, detail="Template not found")
    _require_owner(cur, user)
    name = body.name if body.name is not None else cur["name"]
    definition = body.definition if body.definition is not None else cur["definition"]
    await _check(name, definition, db, user)
    if name != cur["name"] and await asyncio.to_thread(db.get_report_parameter_template_by_name, name):
        raise HTTPException(status_code=409, detail=f'A template named "{name}" already exists.')
    await _refuse_breaking_attached_reports(db, template_id, str(name), definition, user)
    row = await asyncio.to_thread(db.update_report_parameter_template, template_id, body.model_dump(exclude_none=True),
                                  user.get("username", ""))
    audit_event("report_parameter_template.updated", user=user.get("username"), details={"id": template_id, "name": name})
    return row


@router.delete("/{template_id}")
async def delete_template(template_id: int, user: dict = Depends(require_capability("reports.create"))):
    db = _db()
    cur = await asyncio.to_thread(db.get_report_parameter_template, template_id)
    if not cur:
        raise HTTPException(status_code=404, detail="Template not found")
    _require_owner(cur, user)
    ok = await asyncio.to_thread(db.delete_report_parameter_template, template_id, user.get("username", ""))
    if not ok:
        raise HTTPException(status_code=404, detail="Template not found")
    audit_event("report_parameter_template.switched_off", user=user.get("username"), details={"id": template_id})
    return {"switched_off": True, "message": "The template is switched off, not erased -- an admin can switch it back "
                                              "on under Admin -> Switched off. Reports attached to it keep their own settings."}
