"""
Phase 122C: SQL File Management API — save/load/edit .sql files on NFS.

Endpoints:
    POST   /api/sql-files           — save SQL to NFS + DB record
    GET    /api/sql-files           — list (pagination, connection_id filter)
    GET    /api/sql-files/{id}      — metadata + content
    PUT    /api/sql-files/{id}      — update content (version++)
    DELETE /api/sql-files/{id}      — soft-delete
    POST   /api/sql-files/{id}/validate — parse + check registered tables
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from pydantic import BaseModel, Field

# SECURITY 2026-08-17 (BF-352 class, second occurrence).  Every route in this
# module carried `Depends(lambda: _get_current_user)`.  FastAPI calls the
# lambda, which returns the FUNCTION OBJECT -- `get_current_user` never runs,
# no Authorization header is ever read, and no 401 is ever raised.  All six
# routes were anonymous read/write/DELETE of any user's saved SQL, and the
# handlers' `user.get("username", "unknown") if isinstance(user, dict)` guard
# silently degraded every record's ownership to the string "unknown" because
# the injected value is a function, not a dict.
#
# api/agents_api.py:13-16 documents this exact defect and its fix for
# `require_admin`; the same indirection here was never corrected.  Import the
# dependency directly so FastAPI invokes it.
from api.deps import get_current_user as _user_dep

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/sql-files", tags=["sql-files"])

# ── Dependencies (injected from main.py startup) ───────────────────────────
_db_manager = None
_get_current_user = None


def set_sql_files_dependencies(db_manager, get_current_user_dep):
    global _db_manager, _get_current_user
    _db_manager = db_manager
    _get_current_user = get_current_user_dep
    # BF-107: Log storage dir on init for debugging
    try:
        _dir = _get_storage_dir()
        logger.info("SQL files storage dir: %s (exists=%s)", _dir, _dir.exists())
    except Exception as exc:
        logger.error("SQL files storage dir init failed: %s", exc, exc_info=True)


# ── Pydantic models ────────────────────────────────────────────────────────

class SqlFileCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    sql: str = Field(..., min_length=1)
    description: Optional[str] = None
    connection_id: Optional[int] = None
    # Phase 124-B: Cross-connection
    secondary_connection_id: Optional[int] = None
    secondary_sql: Optional[str] = None
    combine_mode: Optional[str] = Field(None, pattern=r"^(union|join)$")
    join_config: Optional[dict] = None       # {"how": "inner", "left_on": [...], "right_on": [...]}
    is_shared: bool = False
    tags: Optional[list] = None


class SqlFileUpdate(BaseModel):
    sql: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    # Phase 124-B: Cross-connection
    secondary_sql: Optional[str] = None
    secondary_connection_id: Optional[int] = None
    combine_mode: Optional[str] = Field(None, pattern=r"^(union|join)$")
    join_config: Optional[dict] = None
    clear_secondary: bool = False  # BF-103: set True to remove cross-connection
    is_shared: Optional[bool] = None
    tags: Optional[list] = None


# ── Helpers ─────────────────────────────────────────────────────────────────

def _get_storage_dir() -> Path:
    """Get the NFS storage directory for SQL files."""
    from core.config import get as cfg
    raw = cfg("sql_files", "storage_dir", "")
    # Windows dev: use local fallback
    if not raw or (os.name == "nt" and raw.startswith("/")):
        raw = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "sql_files")
    p = Path(raw)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _safe_filename(name: str) -> str:
    """Sanitize a filename — reject path traversal."""
    base = Path(name).name  # strip any directory components
    if not base or base.startswith(".") or ".." in base:
        raise HTTPException(400, "Invalid file name")
    # Ensure .sql extension
    if not base.lower().endswith(".sql"):
        base = base + ".sql"
    return base


def _content_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _get_max_file_size() -> int:
    from core.config import get as cfg
    return int(cfg("sql_files", "max_file_size", 1048576))


def _enforce_max_files_per_user(username: str) -> None:
    """FB-48 (2026-09-20) -- ``sql_files.max_files_per_user`` had no reader.

    ``max_file_size`` right beside it in the same config section IS
    enforced, at the route below, so an operator who set a per-user file cap
    had every reason to believe it applied to the same screen.  It did not.

    This is a CAP, so it throttles: a 409 naming the number, the shape the
    per-user connection / schedule / published-view quotas already use.  0
    is unlimited, and the shipped default is 500, so this changes nothing
    for anyone under 500 files.  Admins bypass, as they do for every other
    per-user quota.  Fail-OPEN on an internal error -- a governance helper
    must never be the reason a working route 500s.
    """
    from core.config import get as cfg
    try:
        cap = int(cfg("sql_files", "max_files_per_user", 500))
    except Exception:
        return
    if cap <= 0:                       # 0 = unlimited (NOT "block everything")
        return
    if not username or username == "guest":
        return
    counter = getattr(_db_manager, "count_user_sql_files", None)
    if counter is None:
        return
    try:
        current = int(counter(username))
    except Exception:
        return
    if current >= cap:
        raise HTTPException(
            409,
            f"Quota exceeded: you already own {current}/{cap} SQL files. "
            f"Delete one, or ask an admin to raise sql_files."
            f"max_files_per_user.")


# ── Phase 124-B: Cross-connection SQL file separator ───────────────────────

_CROSS_SEPARATOR = "\n-- ===SECONDARY===\n"


def _split_cross_sql(content: str) -> tuple:
    """Split cross-connection SQL file into (primary_sql, secondary_sql).
    Returns (content, None) for single-connection files."""
    if _CROSS_SEPARATOR in content:
        parts = content.split(_CROSS_SEPARATOR, 1)
        return parts[0].strip(), parts[1].strip()
    return content, None


def _join_cross_sql(primary_sql: str, secondary_sql: Optional[str]) -> str:
    """Join primary and secondary SQL into a single file content."""
    if secondary_sql:
        return primary_sql + _CROSS_SEPARATOR + secondary_sql
    return primary_sql


# ── Ownership gates ─────────────────────────────────────────────────────────
# SECURITY 2026-08-17: with the dependency repaired above, `user` is finally a
# real principal -- but the by-id routes still fetched by id and acted, with no
# owner comparison at all (DELETE did not even load the record first).  A saved
# .sql file holds the query text, so a read is a disclosure and a write is
# tampering with what someone else will execute.

def _username(user) -> str:
    return (user or {}).get("username") or ""


def _is_admin(user) -> bool:
    from core.roles import is_admin_like
    return bool(user) and is_admin_like(user)


def _require_sql_file_view(record: dict, user) -> None:
    """Owner, an explicitly shared file, or an admin."""
    if _is_admin(user):
        return
    if record.get("created_by") == _username(user):
        return
    if record.get("is_shared"):
        return
    # 404 rather than 403 -- do not confirm the id exists to a stranger.
    raise HTTPException(404, "SQL file not found")


def _require_sql_file_edit(record: dict, user) -> None:
    """Only the owner or an admin may mutate.  `is_shared` grants READ, never
    write -- otherwise sharing a file would hand over the right to rewrite it.
    """
    if _is_admin(user):
        return
    if record.get("created_by") == _username(user):
        return
    raise HTTPException(403, "You do not own this SQL file")


# ── Endpoints ───────────────────────────────────────────────────────────────

@router.post("", status_code=201)
async def create_sql_file(body: SqlFileCreate, user=Depends(require_capability("sql.view"))):
    """Save a .sql file to NFS and create a DB record."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")

    # BF-NONBLOCK-AUDIT-5: file IO (write_text) + DB write are sync.
    def _inner():
        file_content = _join_cross_sql(body.sql, body.secondary_sql)
        if len(file_content.encode("utf-8")) > _get_max_file_size():
            raise HTTPException(400, f"SQL content exceeds max size ({_get_max_file_size()} bytes)")

        # No "unknown" fallback: the dependency now guarantees a real
        # principal, and silently stamping "unknown" as the owner is what made
        # every record created under the broken dependency unattributable.
        username = _username(user)
        # FB-48: the per-user cap, enforced rather than declared and
        # discarded.  Checked BEFORE anything is written, so a refused save
        # leaves no orphan .sql on NFS -- the size gate above is ordered the
        # same way for the same reason.
        if not _is_admin(user):
            _enforce_max_files_per_user(username)

        storage = _get_storage_dir()
        safe_name = _safe_filename(body.name)
        file_path = storage / safe_name

        counter = 1
        while file_path.exists():
            stem = Path(safe_name).stem
            file_path = storage / f"{stem}_{counter}.sql"
            counter += 1

        # 2026-10-30 -- a deleted file is SWITCHED OFF, never erased
        # (core/config_active.py): its row keeps the path (the unique key).
        # Asked BEFORE the write, so a held path whose .sql went missing on
        # disk is refused instead of having another file's content written
        # under it (and the insert then failing as a raw IntegrityError).
        _rel = str(file_path.relative_to(storage))
        _holder = _db_manager.sql_file_path_held(_rel)
        if _holder:
            from core.config_active import name_held_message
            if _holder.get("is_active") is False:
                raise HTTPException(409, name_held_message("SQL file", _rel))
            raise HTTPException(409, f"Another SQL file already uses {_rel!r} "
                                     f"(its .sql is missing on disk). Pick another name.")

        file_path.write_text(file_content, encoding="utf-8")
        chash = _content_hash(file_content)

        try:
            record = _db_manager.create_sql_file(
                name=body.name,
                description=body.description,
                file_path=str(file_path.relative_to(storage)),
                connection_id=body.connection_id,
                secondary_connection_id=body.secondary_connection_id,
                combine_mode=body.combine_mode,
                join_config=body.join_config,
                content_hash=chash,
                file_size=len(file_content.encode("utf-8")),
                is_shared=body.is_shared,
                tags=body.tags,
                created_by=username,
            )
        except HTTPException:
            # refused (a switched-off file holds the name): no orphan .sql
            file_path.unlink(missing_ok=True)
            raise
        logger.info("SQL file created: id=%s name='%s' cross=%s by=%s",
                    record["id"], body.name, bool(body.secondary_connection_id), username)
        return record
    try:
        return await asyncio.to_thread(_inner)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to save SQL file '%s': %s", body.name, exc, exc_info=True)
        raise HTTPException(500, f"Failed to save SQL file: {exc}")


@router.get("")
async def list_sql_files(
    connection_id: Optional[int] = Query(None),
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    user=Depends(require_capability("sql.view")),
):
    """List SQL files — own + shared."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")
    try:
        # No "unknown" fallback: the dependency now guarantees a real
        # principal, and silently stamping "unknown" as the owner is what made
        # every record created under the broken dependency unattributable.
        username = _username(user)
        # BF-NONBLOCK-AUDIT-5
        return await asyncio.to_thread(
            _db_manager.list_sql_files,
            connection_id=connection_id,
            created_by=username,
            include_shared=True,
            limit=limit,
            offset=offset,
        )
    except Exception as exc:
        logger.error("Failed to list SQL files: %s", exc, exc_info=True)
        raise HTTPException(500, f"Failed to list SQL files: {exc}")


@router.get("/{file_id}")
async def get_sql_file(file_id: int, user=Depends(require_capability("sql.view"))):
    """Get SQL file metadata + content."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")
    # BF-NONBLOCK-AUDIT-5: DB read + file IO.
    def _inner():
        record = _db_manager.get_sql_file(file_id)
        if not record:
            raise HTTPException(404, "SQL file not found")
        _require_sql_file_view(record, user)  # SECURITY

        storage = _get_storage_dir()
        nfs_path = storage / record["file_path"]
        content = ""
        if nfs_path.exists():
            content = nfs_path.read_text(encoding="utf-8")
        else:
            logger.warning("SQL file %d: NFS path not found: %s", file_id, nfs_path)
        primary_sql, secondary_sql = _split_cross_sql(content)
        record["content"] = primary_sql
        if secondary_sql is not None:
            record["secondary_content"] = secondary_sql
        return record
    try:
        return await asyncio.to_thread(_inner)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to get SQL file %d: %s", file_id, exc, exc_info=True)
        raise HTTPException(500, f"Failed to load SQL file: {exc}")


@router.put("/{file_id}")
async def update_sql_file(file_id: int, body: SqlFileUpdate,
                           user=Depends(require_capability("sql.view"))):
    """Update SQL file content (increments version)."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")
    # BF-NONBLOCK-AUDIT-5: DB reads + file reads/writes + DB write.
    def _inner():
        record = _db_manager.get_sql_file(file_id)
        if not record:
            raise HTTPException(404, "SQL file not found")
        _require_sql_file_edit(record, user)  # SECURITY

        updates = {}
        if body.sql is not None:
            secondary_sql = body.secondary_sql
            if secondary_sql is None and record.get("secondary_connection_id"):
                storage = _get_storage_dir()
                existing_path = storage / record["file_path"]
                if existing_path.exists():
                    _, secondary_sql = _split_cross_sql(
                        existing_path.read_text(encoding="utf-8"))
            file_content = _join_cross_sql(body.sql, secondary_sql)
            if len(file_content.encode("utf-8")) > _get_max_file_size():
                raise HTTPException(400, "SQL content exceeds max size")

            storage = _get_storage_dir()
            nfs_path = storage / record["file_path"]

            from core.config import get as cfg
            if cfg("sql_files", "versioning", True) and nfs_path.exists():
                ver = record.get("version", 1)
                backup = nfs_path.with_suffix(f".sql.v{ver}")
                try:
                    backup.write_text(nfs_path.read_text(encoding="utf-8"), encoding="utf-8")
                except Exception as exc:
                    logger.warning("Version backup failed: %s", exc)

            nfs_path.write_text(file_content, encoding="utf-8")
            updates["content_hash"] = _content_hash(file_content)
            updates["file_size"] = len(file_content.encode("utf-8"))
            updates["version"] = (record.get("version", 1) or 1) + 1

        if body.name is not None:
            updates["name"] = body.name
        if body.description is not None:
            updates["description"] = body.description
        if body.clear_secondary:
            updates["secondary_connection_id"] = None
            updates["combine_mode"] = None
            updates["join_config"] = None
        else:
            if body.secondary_connection_id is not None:
                updates["secondary_connection_id"] = body.secondary_connection_id
            if body.combine_mode is not None:
                updates["combine_mode"] = body.combine_mode
            if body.join_config is not None:
                updates["join_config"] = body.join_config
        if body.is_shared is not None:
            updates["is_shared"] = body.is_shared
        if body.tags is not None:
            updates["tags"] = body.tags

        updated = _db_manager.update_sql_file(file_id, **updates)
        if not updated:
            raise HTTPException(500, "Update failed")
        return updated
    return await asyncio.to_thread(_inner)


@router.delete("/{file_id}")
async def delete_sql_file(file_id: int, acknowledge_dependents: bool = False, user=Depends(require_capability("sql.view"))):
    """Soft-delete a SQL file.

    2026-10-17 -- refused (409) while a PUBLISHED API serves this file
    (core/published_api/impact.py); ``acknowledge_dependents=true`` deletes
    anyway and audits the APIs."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")

    # SECURITY: this route used to delete by id without ever loading the
    # record, so there was nothing to compare an owner against.  Load first.
    def _check():
        record = _db_manager.get_sql_file(file_id)
        if not record:
            raise HTTPException(404, "SQL file not found")
        _require_sql_file_edit(record, user)
        return record

    await asyncio.to_thread(_check)
    from api.published_api_api import refuse_if_apis_depend_async
    await refuse_if_apis_depend_async(_db_manager, "sql_file", file_id,
                                      acknowledged=acknowledge_dependents, actor=user)

    def _inner():
        return _db_manager.delete_sql_file(file_id, soft_delete=True)

    ok = await asyncio.to_thread(_inner)
    if not ok:
        raise HTTPException(404, "SQL file not found")
    return {"status": "deleted", "id": file_id}


@router.post("/{file_id}/validate")
async def validate_sql_file(file_id: int, user=Depends(require_capability("sql.view"))):
    """Validate a SQL file — parse with sqlglot + check table references."""
    if not _db_manager:
        raise HTTPException(500, "Service not initialized")

    # BF-NONBLOCK-AUDIT-5: full validate body wraps in to_thread —
    # mixes 3 sync DB reads + 1 file read + sqlglot parse.
    def _inner():
        record = _db_manager.get_sql_file(file_id)
        if not record:
            raise HTTPException(404, "SQL file not found")
        _require_sql_file_view(record, user)  # SECURITY

        storage = _get_storage_dir()
        nfs_path = storage / record["file_path"]
        if not nfs_path.exists():
            raise HTTPException(404, "SQL file not found on disk")

        raw_content = nfs_path.read_text(encoding="utf-8")
        primary_sql, secondary_sql = _split_cross_sql(raw_content)
        result = {"valid": True, "tables": [], "errors": [], "secondary_tables": []}

        try:
            from core.sql_table_extractor import extract_table_names
            tables = extract_table_names(primary_sql)
            result["tables"] = sorted(tables)
        except Exception as exc:
            result["valid"] = False
            result["errors"].append(f"Parse error (primary): {exc}")

        if secondary_sql:
            try:
                from core.sql_table_extractor import extract_table_names as _ext
                sec_tables = _ext(secondary_sql)
                result["secondary_tables"] = sorted(sec_tables)
            except Exception as exc:
                result["valid"] = False
                result["errors"].append(f"Parse error (secondary): {exc}")

        if record.get("connection_id") and result["tables"]:
            try:
                conn = _db_manager.get_connection(record["connection_id"])
                if conn:
                    reg_tables = conn.get("config", {}).get("registered_tables", [])
                    if reg_tables:
                        from core.sql_table_extractor import validate_registered_tables
                        ok, missing = validate_registered_tables(set(result["tables"]), reg_tables)
                        if not ok:
                            result["warnings"] = [f"Unregistered tables (primary): {', '.join(missing)}"]
            except Exception:
                pass

        if record.get("secondary_connection_id") and result["secondary_tables"]:
            try:
                sec_conn = _db_manager.get_connection(record["secondary_connection_id"])
                if sec_conn:
                    sec_reg = sec_conn.get("config", {}).get("registered_tables", [])
                    if sec_reg:
                        from core.sql_table_extractor import validate_registered_tables as _val
                        ok, missing = _val(set(result["secondary_tables"]), sec_reg)
                        if not ok:
                            result.setdefault("warnings", []).append(
                                f"Unregistered tables (secondary): {', '.join(missing)}"
                            )
            except Exception:
                pass

        return result
    return await asyncio.to_thread(_inner)
