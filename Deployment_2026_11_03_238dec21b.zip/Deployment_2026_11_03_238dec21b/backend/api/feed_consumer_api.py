"""My Feeds -- delivery receipts and self-subscription for feed CONSUMERS
(2026-09-28, docs/FEATURE_STRATEGY_2026_09_28.html #3).

Routes (every one for ANY signed-in role, the viewer included):

* ``GET  /api/my-feeds``                          the feeds the caller consumes,
                                                  each with the caller's subscription
* ``GET  /api/my-feeds/receipts?days=&business_date=``
                                                  one receipt per run per business date
* ``GET  /api/my-feeds/{feed_id}``                one feed + its receipts
* ``GET  /api/my-feeds/receipts/{run_id}``        the receipt (JSON)
* ``GET  /api/my-feeds/receipts/{run_id}/html``   the printable receipt
* ``GET|PUT|DELETE /api/my-feeds/{feed_id}/subscription``
* ``GET  /api/admin/feeds/consumer-notices/status`` (admin / support)

The gate is ``core/feed/consumer_receipts.can_read_receipts``: admin /
support, the feed's own view gate, or a member of a declared consumer
group.  A caller who fails it is told the feed / receipt does not exist
(404) -- the same answer as for a feed that really does not, so a refusal
never confirms a feed id.  No route here writes anything but the caller's
own subscription; a consumer can never rerun, skip or redeliver.

Every receipt served passes ``assert_no_secrets`` first: a receipt that
somehow carried a destination config or a query is refused with a 500
naming the key, never served.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import Field

from api.deps import get_current_user, require_admin_read, require_capability
from api.strict_request import StrictRequestModel
from core.db.models import FEED_CONSUMER_EVENTS
from core.db_async import adb
from core.feed import consumer_notices, consumer_receipts as cr

logger = logging.getLogger(__name__)
router = APIRouter(tags=["my-feeds"])

_db_manager: Any = None


def set_feed_consumer_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="My Feeds is not wired to a database")
    return _db_manager


def _not_found(what: str) -> HTTPException:
    return HTTPException(status_code=404, detail=f"{what} not found")


def _parse_date(raw: Optional[str]) -> Optional[date]:
    if not raw:
        return None
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"business_date {raw!r} is not an ISO date (YYYY-MM-DD)")


def _default_days() -> int:
    from core.config import get as _get
    try:
        return int(_get("feed_generation", "consumer_receipt_window_days", 7) or 7)
    except (TypeError, ValueError):
        return 7


def _feed_row(db, feed: dict, user: dict) -> dict:
    """What the page shows per feed: identity, SLA, the consumer groups
    (by name), the caller's subscription.  Never the config."""
    groups = []
    for gid in cr.consumer_group_ids(feed):
        try:
            g = db.get_user_group(gid)
        except Exception:  # noqa: BLE001
            g = None
        groups.append({"id": gid, "name": (g or {}).get("name") or f"group {gid}"})
    sub = db.get_feed_consumer_subscription(int(feed["id"]),
                                            str(user.get("username") or ""))
    return {
        "id": int(feed["id"]),
        "name": feed.get("name"),
        "display_name": feed.get("display_name"),
        "description": feed.get("description"),
        "is_active": bool(feed.get("is_active", True)),
        "output_format": feed.get("output_format"),
        "sla_to": feed.get("sla_to"),
        "sla_timezone": feed.get("sla_timezone") or "UTC",
        "consumer_groups": groups,
        "subscription": sub,
    }


async def _gated_feed(feed_id: int, user: dict) -> dict:
    db = _db()
    feed = await adb(db.get_feed_config, int(feed_id))
    if not feed or not await adb(cr.can_read_receipts, db, feed, user):
        raise _not_found(f"feed {feed_id}")
    return feed


def _serve(receipt: dict) -> dict:
    try:
        cr.assert_no_secrets(receipt)
    except ValueError as exc:
        logger.error("[my-feeds] REFUSED to serve receipt %s: %s",
                     receipt.get("receipt_id"), exc)
        raise HTTPException(
            status_code=500,
            detail=f"receipt refused: {exc} -- this is a platform defect, "
                   f"not a missing receipt")
    return receipt


# ── the feeds ────────────────────────────────────────────────────────────

@router.get("/api/my-feeds")
async def list_my_feeds(user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    feeds = await adb(cr.consumable_feeds, db, user)
    rows = [await adb(_feed_row, db, f, user) for f in feeds]
    return {"feeds": rows, "count": len(rows),
            "events": list(FEED_CONSUMER_EVENTS),
            "default_days": _default_days()}


@router.get("/api/my-feeds/receipts")
async def list_my_receipts(days: Optional[int] = Query(default=None, ge=1, le=62),
                           business_date: Optional[str] = Query(default=None),
                           feed_id: Optional[int] = Query(default=None),
                           user: dict = Depends(require_capability("feeds.view"))):
    """One receipt per run per business date over the window (default
    ``feed_generation.consumer_receipt_window_days``), or one date."""
    db = _db()
    feeds = await adb(cr.consumable_feeds, db, user)
    if feed_id is not None:
        feeds = [f for f in feeds if int(f["id"]) == int(feed_id)]
        if not feeds:
            # a feed the caller may read (owner) but is not a consumer of
            # is still answerable here through the gate.
            feed = await _gated_feed(int(feed_id), user)
            feeds = [feed]
    bd = _parse_date(business_date)
    if bd is not None:
        date_from, date_to = bd, bd
    else:
        date_from, date_to = cr.window(days or _default_days())
    built = await adb(cr.receipts_for_feeds, db, feeds,
                      date_from=date_from, date_to=date_to)
    return {"business_date_from": date_from.isoformat(),
            "business_date_to": date_to.isoformat(),
            "receipts": [_serve(r) for r in built["receipts"]],
            "count": len(built["receipts"]),
            "unavailable": built["unavailable"],
            "feed_count": len(feeds)}


# NOTE: the static /receipts/{run_id} routes are declared BEFORE the
# parameterised /{feed_id} so "receipts" is never read as a feed id.

@router.get("/api/my-feeds/receipts/{run_id}")
async def get_my_receipt(run_id: str, user: dict = Depends(require_capability("feeds.view"))):
    return _serve(await _receipt(run_id, user))


@router.get("/api/my-feeds/receipts/{run_id}/html", response_class=HTMLResponse)
async def get_my_receipt_html(run_id: str, user: dict = Depends(require_capability("feeds.view"))):
    receipt = _serve(await _receipt(run_id, user))
    return HTMLResponse(content=cr.render_receipt_html(receipt))


async def _receipt(run_id: str, user: dict) -> dict:
    """The receipt of one run, by run id or receipt id (``qsr-<id>``).
    404 for a run that does not exist AND for one the caller may not
    read: the two are indistinguishable on purpose."""
    db = _db()
    rid = cr.run_id_from_receipt_id(run_id)
    if rid is None:
        raise _not_found(f"receipt {run_id}")
    run = await adb(db.get_feed_run, rid)
    if not run:
        raise _not_found(f"receipt {run_id}")
    feed = await adb(db.get_feed_config, int(run["feed_config_id"]))
    if not feed or not await adb(cr.can_read_receipts, db, feed, user):
        raise _not_found(f"receipt {run_id}")
    return await adb(cr.build_receipt, db, feed, run)


@router.get("/api/my-feeds/{feed_id}")
async def get_my_feed(feed_id: int,
                      days: Optional[int] = Query(default=None, ge=1, le=62),
                      user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    feed = await _gated_feed(feed_id, user)
    date_from, date_to = cr.window(days or _default_days())
    built = await adb(cr.receipts_for_feeds, db, [feed],
                      date_from=date_from, date_to=date_to)
    return {"feed": await adb(_feed_row, db, feed, user),
            "business_date_from": date_from.isoformat(),
            "business_date_to": date_to.isoformat(),
            "receipts": [_serve(r) for r in built["receipts"]],
            "unavailable": built["unavailable"]}


# ── the subscription ─────────────────────────────────────────────────────

class SubscriptionBody(StrictRequestModel):
    """``events`` over FEED_CONSUMER_EVENTS (an empty list is a DELETE
    spelled as a PUT); ``email`` optional -- the bell and the socket are
    always on, the mail needs an address."""
    events: List[str] = Field(default_factory=list)
    email: Optional[str] = Field(default=None, max_length=255)


def _clean_events(events: List[str]) -> List[str]:
    out: List[str] = []
    for e in events or []:
        s = str(e or "").strip().lower()
        if s not in FEED_CONSUMER_EVENTS:
            raise HTTPException(
                status_code=422,
                detail=f"unknown event {e!r}; one of {list(FEED_CONSUMER_EVENTS)}")
        if s not in out:
            out.append(s)
    return out


def _clean_email(email: Optional[str]) -> Optional[str]:
    if email is None or not str(email).strip():
        return None
    from core.email_service import _valid_recipients
    s = str(email).strip()
    if not _valid_recipients([s]):
        raise HTTPException(status_code=422,
                            detail=f"{s!r} is not a valid e-mail address")
    return s


@router.get("/api/my-feeds/{feed_id}/subscription")
async def get_my_subscription(feed_id: int, user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    feed = await _gated_feed(feed_id, user)
    sub = await adb(db.get_feed_consumer_subscription, int(feed["id"]),
                    str(user.get("username") or ""))
    return {"feed_id": int(feed["id"]), "subscription": sub,
            "events": list(FEED_CONSUMER_EVENTS)}


@router.put("/api/my-feeds/{feed_id}/subscription")
async def put_my_subscription(feed_id: int, body: SubscriptionBody,
                              user: dict = Depends(require_capability("feeds.author"))):
    db = _db()
    feed = await _gated_feed(feed_id, user)
    username = str(user.get("username") or "")
    if not username:
        raise HTTPException(status_code=401, detail="a subscription needs a signed-in user")
    events = _clean_events(body.events)
    email = _clean_email(body.email)
    if not events:
        removed = await adb(db.delete_feed_consumer_subscription, int(feed["id"]), username)
        return {"feed_id": int(feed["id"]), "subscription": None,
                "removed": bool(removed)}
    sub = await adb(db.upsert_feed_consumer_subscription, int(feed["id"]),
                    username, events, email)
    from core.email_service import is_email_enabled
    mail_note = None
    if email and not is_email_enabled():
        from core.email_service import NOT_CONFIGURED_REASON
        mail_note = NOT_CONFIGURED_REASON
    logger.info("[my-feeds] %s subscribed to %s on feed %s (email=%s)",
                username, events, feed["id"], "yes" if email else "no")
    return {"feed_id": int(feed["id"]), "subscription": sub,
            "email_note": mail_note}


@router.delete("/api/my-feeds/{feed_id}/subscription")
async def delete_my_subscription(feed_id: int, user: dict = Depends(require_capability("feeds.author"))):
    db = _db()
    feed = await _gated_feed(feed_id, user)
    removed = await adb(db.delete_feed_consumer_subscription, int(feed["id"]),
                        str(user.get("username") or ""))
    return {"feed_id": int(feed["id"]), "removed": bool(removed)}


# ── admin status ─────────────────────────────────────────────────────────

@router.get("/api/admin/feeds/consumer-notices/status")
async def consumer_notices_status(user: dict = Depends(require_capability("feeds.monitor"))):
    out = await adb(consumer_notices.status, _db())
    out["generated_at"] = datetime.now(timezone.utc).isoformat()
    return out
