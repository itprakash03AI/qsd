"""
Unified FastAPI auth dependencies — used by ALL routers.

Every router imports from here instead of duplicating auth logic.
Replaces the per-router _get_user() copies spread across 5+ files.

Initialization:
    Call ``init_deps(auth_cfg, db_manager)`` once at application startup
    (in main.py after db_manager is created).

Usage in routers:
    from api.deps import get_current_user, require_admin, require_role, require_execute_access

    @router.get("/api/something")
    async def my_endpoint(user: dict = Depends(get_current_user)):
        ...

    @router.delete("/api/admin/something")
    async def admin_only(user: dict = Depends(require_admin)):
        ...
"""
from __future__ import annotations

import inspect
import hashlib
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Optional
from fastapi import Depends, Header, HTTPException, Request

from core.roles import is_admin_like
from core.sessions import get_session

logger = logging.getLogger(__name__)

# ── Module-level singletons — populated by init_deps() at startup ─────────────
_auth_cfg   = None   # core.config.auth singleton
_db_manager = None   # DatabaseManager singleton


# ── E-M4 — API-key auth hot-path cache + fire-and-forget usage touch ──────────
# Audit finding: get_api_key_user() ran TWO synchronous DB round-trips on
# EVERY external call — a SELECT (get_api_key_by_hash) plus an UPDATE
# (touch_api_key_usage).  Both sat on the request-latency path.  We add:
#   1. A short-TTL in-memory cache of the key-row lookup, keyed by the same
#      sha256(key) hash, so repeated calls with the same key skip the SELECT.
#   2. A throttled, fire-and-forget usage-touch so the UPDATE never blocks the
#      request (and collapses to at most one write per throttle window per key).
# Both are FAIL-SAFE: any cache/executor error falls back to the original
# direct lookup / synchronous touch.  Config-overridable so a deployment can
# restore the exact prior behaviour:
#   published_views.api_key_cache_enabled        (bool, default True)
#   published_views.api_key_cache_ttl_seconds    (int,  default 30)
#   published_views.api_key_touch_throttle_seconds (int, default 30)
# REVOCATION BOUND: a key revoked/deactivated in the DB continues to
# authenticate from cache until its cached entry expires — i.e. at most
# api_key_cache_ttl_seconds (default 30s).  invalidate_api_key_cache() is
# exposed so a revoke hook can evict immediately; absent that hook the TTL is
# the documented upper bound.  Set api_key_cache_ttl_seconds<=0 (or
# api_key_cache_enabled=false) to disable caching entirely.
_API_KEY_CACHE: dict[str, tuple[float, dict]] = {}   # key_hash -> (expiry_epoch, api_key_row)
_API_KEY_CACHE_LOCK = threading.Lock()
_API_KEY_LAST_TOUCH: dict = {}                        # api_key_id -> last touch epoch
_API_KEY_TOUCH_LOCK = threading.Lock()
_api_key_touch_executor = None                        # lazily-created single-thread pool


def _pv_cfg_get(key: str, fallback):
    """Read a ``published_views`` config value, fail-safe to ``fallback``."""
    try:
        from core.config import get as _get
        v = _get("published_views", key, fallback)
        return fallback if v is None else v
    except Exception:
        return fallback


def invalidate_api_key_cache(key_hash: Optional[str] = None) -> None:
    """Evict a single key (by sha256 hash) or the whole API-key lookup cache.

    Call from a revoke/rotate path to drop the revocation window to zero.
    Fail-safe: never raises.
    """
    try:
        with _API_KEY_CACHE_LOCK:
            if key_hash is None:
                _API_KEY_CACHE.clear()
            else:
                _API_KEY_CACHE.pop(key_hash, None)
    except Exception:
        pass


def _api_key_cache_get(key_hash: str):
    """Return a cached, non-expired api_key row for ``key_hash`` or None."""
    try:
        ttl = int(_pv_cfg_get("api_key_cache_ttl_seconds", 30))
        if ttl <= 0 or not bool(_pv_cfg_get("api_key_cache_enabled", True)):
            return None
        with _API_KEY_CACHE_LOCK:
            entry = _API_KEY_CACHE.get(key_hash)
            if not entry:
                return None
            expiry, row = entry
            if time.time() >= expiry:
                _API_KEY_CACHE.pop(key_hash, None)
                return None
            return row
    except Exception:
        return None


def _api_key_cache_put(key_hash: str, row: dict) -> None:
    """Cache a successful active-key lookup for the configured TTL."""
    try:
        ttl = int(_pv_cfg_get("api_key_cache_ttl_seconds", 30))
        if ttl <= 0 or not bool(_pv_cfg_get("api_key_cache_enabled", True)):
            return
        with _API_KEY_CACHE_LOCK:
            # Bound cache size defensively so a spray of distinct keys can't
            # grow it without limit; evict oldest-expiring on overflow.
            if len(_API_KEY_CACHE) > 10000:
                try:
                    _oldest = min(_API_KEY_CACHE.items(), key=lambda kv: kv[1][0])[0]
                    _API_KEY_CACHE.pop(_oldest, None)
                except Exception:
                    _API_KEY_CACHE.clear()
            _API_KEY_CACHE[key_hash] = (time.time() + ttl, row)
    except Exception:
        pass


def _touch_api_key_usage_async(api_key_id) -> None:
    """Fire-and-forget, throttled usage-touch — kept off the request path.

    At most one UPDATE per ``api_key_touch_throttle_seconds`` window per key.
    Fail-safe: on any executor error, best-effort synchronous touch so usage
    stats don't silently stop (matches the pre-change guarantee).  When
    caching is disabled (ttl<=0) callers do the original synchronous touch
    directly instead of calling this.
    """
    global _api_key_touch_executor
    try:
        throttle = int(_pv_cfg_get("api_key_touch_throttle_seconds", 30))
    except Exception:
        throttle = 30
    now = time.time()
    if throttle > 0:
        with _API_KEY_TOUCH_LOCK:
            last = _API_KEY_LAST_TOUCH.get(api_key_id, 0)
            if now - last < throttle:
                return  # touched recently — skip this write entirely
            _API_KEY_LAST_TOUCH[api_key_id] = now
    db = _db_manager

    def _do_touch():
        try:
            if db is not None:
                db.touch_api_key_usage(api_key_id)
        except Exception as exc:
            logger.debug("api-key usage touch failed (async): %s", exc)

    try:
        if _api_key_touch_executor is None:
            from concurrent.futures import ThreadPoolExecutor
            _api_key_touch_executor = ThreadPoolExecutor(
                max_workers=1, thread_name_prefix="apikey-touch")
        _api_key_touch_executor.submit(_do_touch)
    except Exception as exc:
        # Executor unavailable/shut down — best-effort synchronous fallback so
        # we never silently drop usage tracking.
        logger.debug("api-key touch executor unavailable, sync fallback: %s", exc)
        _do_touch()


def init_deps(auth_cfg, db_manager) -> None:
    """Called once from main.py startup after components are created."""
    global _auth_cfg, _db_manager
    _auth_cfg   = auth_cfg
    _db_manager = db_manager


def require_db():
    """
    FastAPI dependency — returns the DatabaseManager singleton.

    Raises HTTP 503 if ``init_deps()`` was not called at startup (i.e. the DB
    manager is not initialized). Replaces the 13 duplicate ``_require_db()``
    helpers that used to be scattered across individual router modules.

    Usage:
        from api.deps import require_db

        @router.get("/api/something")
        async def endpoint(db = Depends(require_db)):
            ...
    """
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not initialized")
    return _db_manager


def enforce_user_resource_quota(user: dict, resource: str) -> None:
    """Phase 102-F — enforce per-user resource quotas.

    ``resource`` must be one of: ``"connections"`` | ``"schedules"`` |
    ``"published_views"`` | ``"saved_queries"``. Raises HTTP 409 when the
    user already owns the configured cap for that resource. Admin users
    bypass all quotas.  No-op when ``admin_governance.enabled`` is false.

    FB-48 (2026-09-20): ``saved_queries`` joined the table so that
    ``max_saved_queries_per_user`` -- declared, admin-settable, and read by
    nothing -- is actually a cap.  This is a CAP, so it throttles with a
    409 naming the number; it is not a correctness gate.
    """
    try:
        from core.config import admin_governance as _gov
        if not _gov.enabled:
            return
    except Exception:
        return
    if not user or is_admin_like(user):
        return
    username = user.get("username", "")
    if not username or username == "guest":
        return
    if _db_manager is None:
        return  # fail-open
    limits = {
        "connections":     (_gov.max_connections_per_user,     "count_user_connections"),
        "schedules":       (_gov.max_schedules_per_user,       "count_user_schedules"),
        "published_views": (_gov.max_published_views_per_user, "count_user_published_views"),
        "saved_queries":   (_gov.max_saved_queries_per_user,   "count_user_saved_queries"),
    }
    if resource not in limits:
        # FB-48: this used to return in silence, so a typo'd resource name
        # disabled a quota and nothing anywhere said so -- a guard that
        # cannot fail.  Still fail-open (a governance helper must never 500
        # a working route), but no longer silent.
        logging.getLogger(__name__).error(
            "enforce_user_resource_quota: unknown resource %r -- no cap was "
            "applied. Known: %s", resource, sorted(limits))
        return
    cap, counter_name = limits[resource]
    if cap <= 0:  # 0 = unlimited
        return
    counter = getattr(_db_manager, counter_name, None)
    if counter is None:
        return
    try:
        current = counter(username)
    except Exception:
        return
    if current >= cap:
        raise HTTPException(
            status_code=409,
            detail=(f"Quota exceeded: you already own {current}/{cap} {resource}. "
                    f"Contact an admin to raise this limit."),
        )


# ── Core dependency ────────────────────────────────────────────────────────────

def _stash_resolved_user(request, user) -> None:
    """Remember the resolved principal on the request (``request.state`` is
    shared by every middleware and the route through the ASGI scope), so no
    later layer authenticates the same request again."""
    try:
        if isinstance(user, dict) and user.get("username"):
            request.state.qs_resolved_user = user
    except Exception:                                   # noqa: BLE001
        pass


async def aresolve_user(request: Request) -> dict:
    """:func:`_resolve_user` for a caller ON THE EVENT LOOP (2026-10-07).

    The request middleware resolved every ``/api`` caller inline on the loop:
    a session-store DB read every 60 s per token (L1 revalidation), a DB
    WRITE on every sliding extend, and for an ``Authorization: Basic``
    caller a full password check -- an LDAP bind against AD, or a pbkdf2
    hash -- for EVERY request.  Each one stalled every request on the pod.

    Here only work that cannot block runs on the loop: a principal already
    stashed on the request, the no-auth guest, an absent header (a 401), and
    a Bearer token whose L1 entry ``get_session`` would serve from memory
    (:func:`core.sessions.peek_session`).  Everything else runs on the
    dedicated ``auth`` lane (core/interactive_lanes.py), never on asyncio's
    default executor, whose queue under load is the query traffic.  The
    result is stashed so the route's own dependency does not authenticate
    the request a second time.  Raises exactly what :func:`_resolve_user`
    raises.
    """
    try:
        _stashed = getattr(request.state, "qs_resolved_user", None)
    except Exception:                                   # noqa: BLE001
        _stashed = None
    if isinstance(_stashed, dict) and _stashed.get("username"):
        return _stashed
    auth_header = request.headers.get("Authorization", "")
    needs_io = bool(auth_header) and not _auth_genuinely_disabled()
    peeked = None
    if needs_io and auth_header.startswith("Bearer "):
        from core.sessions import peek_session
        peeked = peek_session(auth_header[7:])
        if peeked is not None:
            needs_io = False
    if needs_io:
        from core.interactive_lanes import run_in_lane
        user = await run_in_lane("auth", _resolve_user, request)
    elif peeked is not None:
        # Serve the entry peek_session READ.  Re-reading it through
        # _resolve_user -> get_session was a check-then-act race: an entry
        # fresh at the peek can pass its revalidation deadline a moment
        # later, and get_session then revalidates against the DB -- ON THE
        # LOOP (2026-10-07; seen as test_event_loop_never_waits_on_the_db
        # failing only under a loaded full suite: 507 samples in
        # _resolve_user -> get_session).
        user = peeked
    else:
        user = _resolve_user(request)
    _stash_resolved_user(request, user)
    return user


async def aget_current_user(request: Request) -> dict:
    """:func:`get_current_user` as an ``async`` dependency (2026-10-07).

    A sync dependency is run by FastAPI on anyio's worker threads (40 tokens,
    shared by every sync dependency and every sync route on the pod), so
    even a principal the middleware already resolved costs a thread hop that
    queues behind whatever holds those threads under load.  This one resolves
    through :func:`aresolve_user` -- the stash, or memory, on the loop; real
    I/O on the ``auth`` lane -- and publishes the username to the request's
    context exactly as :func:`get_current_user` does.  For a route that must
    stay fast while the pod is busy (``api/user_drafts_api.py``).
    """
    user = await aresolve_user(request)
    try:
        from core.user_context import set_current_username
        set_current_username(user.get("username", ""))
    except Exception:
        pass
    return user


def get_current_user(request: Request) -> dict:
    """
    FastAPI dependency — resolves the caller's identity.

    Priority:
      1. auth.type == "none"  →  guest admin (dev/testing mode)
      2. Bearer <token>       →  server-side session lookup
      3. Basic <base64>       →  direct AD/local authentication (fallback)

    Raises HTTP 401 if credentials are missing or invalid.

    Phase 139 (Tier 2.3): also publishes the resolved username into the
    request-scoped contextvar so cache_layer can attribute hit/miss per user.
    """
    user = _resolve_user(request)
    # 2026-10-07: stash it -- the access log reads the principal from the
    # request instead of authenticating it again on the event loop.
    _stash_resolved_user(request, user)
    # Publish to context so downstream code (cache_layer telemetry, etc.)
    # can read the username without taking it as a parameter. Fail-OPEN.
    try:
        from core.user_context import set_current_username
        set_current_username(user.get("username", ""))
    except Exception:
        pass
    return user


#: The roles a no-auth guest may act as -- strictly below admin.
ACT_AS_ROLES = frozenset({"viewer", "analyst"})
ACT_AS_HEADER = "X-QS-Act-As-Role"


def acting_role(request) -> Optional[str]:
    """The lesser role a no-auth guest asked to act as, or None.

    Honoured ONLY when auth is genuinely disabled (the config loaded and
    chose 'none'); anything outside ACT_AS_ROLES is ignored, so the header
    can never elevate.  See ``_resolve_user``.
    """
    if not _auth_genuinely_disabled():
        return None
    try:
        value = str(request.headers.get(ACT_AS_HEADER, "") or "").strip().lower()
    except Exception:                                    # noqa: BLE001
        return None
    return value if value in ACT_AS_ROLES else None


def _gates_apply(user) -> bool:
    """Do the role gates apply to this principal?  Yes when auth is on;
    and yes for a no-auth guest ACTING AS a lesser role -- otherwise the
    act-as seam would gate the UI while the API let the same principal
    through, two answers to one question."""
    if not _auth_genuinely_disabled():
        return True
    return bool(isinstance(user, dict) and user.get("acting_as"))


def _auth_genuinely_disabled() -> bool:
    """True only when the config LOADED and deliberately chose auth.type='none'.

    2026-08-20 -- THE 2026-07-15 FAIL-CLOSED GUARD WAS NEVER PROPAGATED.

    ``_resolve_user`` was hardened on 2026-07-15 to consult
    ``config.config_load_failed()`` before handing out the no-auth
    guest-admin, because a missing or corrupt config falls back to the
    built-in DEFAULTS -- where ``auth.type`` is ``'none'``.  Its own comment
    calls the unguarded version "a silent admin bypass".

    Every ROLE GATE in this module kept the unguarded test
    (``_auth_cfg.type == "none"``), so on a config-load failure they all read
    "auth is disabled, let everyone through".  ``_resolve_user`` still denies
    ANONYMOUS callers, but a non-admin holding a valid DB-backed session --
    and sessions survive a pod restart, which is exactly when a ConfigMap
    goes missing -- passed ``get_current_user`` and was then ELEVATED TO
    ADMIN by ``require_admin``, reaching every ``Depends(require_admin)``
    route in admin_api.

    Verified: the same non-admin principal is 403'd under a loaded config and
    granted admin under failed-config defaults.

    One helper, five call sites, so the next gate added here cannot miss it.
    """
    if not _auth_cfg or _auth_cfg.type != "none":
        return False
    try:
        from core.config import config_load_failed as _cfg_failed
        if _cfg_failed():
            return False        # 'none' is an ACCIDENT -- do not disable auth
    except Exception:
        pass
    return True


def _resolve_user(request: Request) -> dict:
    # 2026-09-10 — the scheduler-scope middleware (main.py) resolves the
    # principal through THIS function first and stashes the result on the
    # request so the route does not pay a second Basic/pbkdf2 or session
    # lookup.  The stash is only ever written by that middleware from this
    # function's own return value; it is never trusted from the wire.
    try:
        _stashed = getattr(request.state, "qs_resolved_user", None)
    except Exception:                                   # noqa: BLE001
        _stashed = None
    if isinstance(_stashed, dict) and _stashed.get("username"):
        return _stashed
    # 2026-07-15 FAIL-CLOSED: only hand out the no-auth guest-admin when the
    # config ACTUALLY loaded and genuinely selected auth.type='none'.  When
    # 'none' is an ACCIDENT of a missing/corrupt config (config_load_failed),
    # do NOT grant guest — that's a silent admin bypass.  Fall through to the
    # session-required path below instead: the super_admin break-glass session
    # (DB-backed, checked before AD — no LDAP/config needed) still validates
    # there, so an operator can always get in, while anonymous callers get 401
    # → the SPA shows the login page.  Genuine no-auth dev (config loaded, type
    # explicitly 'none') is unaffected.
    _load_failed = False
    try:
        from core.config import config_load_failed as _cfg_failed
        _load_failed = _cfg_failed()
    except Exception:
        _load_failed = False
    if (not _auth_cfg or _auth_cfg.type == "none") and not _load_failed:
        _acting = acting_role(request)
        if _acting:
            # 2026-09-20 -- a NON-ADMIN principal on a no-auth rig.  Every
            # consumer-role check in the product (the viewer allowlist, the
            # author-free action bar, admin bypass of row security) was
            # unprovable because auth.type='none' has exactly one user and
            # it is an admin.  The header can only NARROW: 'viewer' or
            # 'analyst', never admin/super_admin, and only where everyone
            # is already admin -- so it widens nothing on any deployment.
            return {
                "username": f"guest-{_acting}",
                "display_name": f"Guest ({_acting})",
                "email": "",
                "groups": [],
                "is_admin": False,
                "role": _acting,
                "acting_as": _acting,
            }
        return {
            "username": "guest",
            "display_name": "Guest",
            "is_admin": True,
            "groups": [],
            "role": "admin",
        }

    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Bearer → session lookup (preferred — no password ever re-transmitted)
    if auth_header.startswith("Bearer "):
        user = get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Basic → direct authentication (legacy clients / API testing)
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        user = authenticate_user(username, password)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        return user
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))


# ── Verified user for legacy report routers (Phase 1 SECURITY) ────────────────
#
# burst_api / enterprise_reports_api / pdf_export_api each carried a local
# ``_get_user()`` that base64-decoded ``Authorization: Basic`` and TRUSTED the
# username with no password/session check, falling back to "anonymous".
# Forgeable admin — the parked burst-auth finding, Part 1.  These two helpers
# are THE single replacement: identity comes only from the verified boundary.

def _reports_service_api_key_enabled() -> bool:
    """Explicit opt-in gate for X-API-Key service auth on report endpoints.

    SECURITY: default OFF, and any config failure keeps the gate CLOSED
    (this is an *access widener*, so its fail mode is the opposite of the
    usual fail-open probes)."""
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("auth", "reports_service_api_key", False))
    except Exception:
        return False


def get_verified_user(request: Request) -> dict:
    """Verified replacement for the forgeable per-router ``_get_user()``.

    Identity is derived ONLY through ``core.identity.effective.
    derive_from_request`` → the real :func:`get_current_user` (Bearer →
    server-side session lookup; Basic → ACTUAL AD/local password check;
    ``auth.type='none'`` dev mode → explicit guest, unchanged).

    FAIL-CLOSED: no verifiable identity → HTTP 401.  Never an "anonymous"
    fallback, never the header-spelled username.

    Service-auth escape hatch (machine callers, explicit opt-in):  when
    ``auth.reports_service_api_key`` is true, an ``X-API-Key`` header
    authenticates through the EXISTING hashed-key path
    (:func:`get_api_key_user` — DB-backed, active+expiry checked).  The
    principal keeps role ``api_consumer`` (never admin-tier), so a service
    key can trigger report work but can never reach admin-gated surfaces.
    The forgeable Basic path exists in NO mode.

    Returns the dict shape the legacy call sites already consume
    (``username`` / ``role`` / ``groups`` / ``is_admin``).
    """
    # Explicit, config-gated machine path first (mirrors the API-key
    # precedence of get_api_key_or_ad_user).  Gate OFF → the header is
    # ignored and the caller must hold a real session/password like anyone.
    if request.headers.get("X-API-Key", "").strip() and _reports_service_api_key_enabled():
        return get_api_key_user(request)   # raises 401 on bad/inactive/expired key

    from core.identity.effective import IdentityError, derive_from_request
    try:
        ident = derive_from_request(request)
    except IdentityError as exc:
        # Deny with the codebase-wide 401 shape.  Detail stays generic on
        # purpose (no auth-backend oracle for unauthenticated callers).
        logger.info("verified-user boundary refused request: %s", exc)
        raise HTTPException(status_code=401, detail="Authentication required") from exc
    user = {
        "username": ident.username,
        "role": ident.role or "viewer",
        "groups": list(ident.groups),
        "is_admin": bool(ident.is_admin),
        "auth_source": ident.source.value,
        # This boundary only ever returns a VERIFIED identity, so there is
        # always a caller.  Stamped explicitly rather than left to the
        # ``auth_source`` tell so the fact is stated, not inferred.
        LIVE_CALLER_KEY: True,
    }
    display_name = ident.attrs.get("display_name")
    if display_name:
        user["display_name"] = display_name
    return user


async def aget_verified_user(request: Request) -> dict:
    """Async form of :func:`get_verified_user` for ``async def`` routes.

    Real authentication does blocking I/O (LDAP bind / session-store read).
    Calling it inline on the event loop is the exact /health-starvation
    failure mode behind the 2026-07-21 pod-restart incident — so offload to
    a worker thread.  Same fail-closed contract."""
    import asyncio
    return await asyncio.to_thread(get_verified_user, request)


# ── Workspace helper ───────────────────────────────────────────────────────────

def get_workspace_id(request: Request) -> Optional[int]:
    """Read X-Workspace-ID header and return as int, or None if not set/invalid.

    Round 10 deep-dive (2026-06-30): NOW validates that the
    authenticated user is actually a MEMBER of the named workspace.
    Pre-fix the header was trusted as a scoping filter -- but the
    workspace_id was applied as a SQL filter on tables like
    ``materialized_views``, ``saved_queries``, ``dashboards`` etc
    with NO user-level RLS on top.  Result: any authenticated user
    could spoof ``X-Workspace-ID: <some_other_id>`` and see
    every workspace member's data within that workspace, even
    workspaces they did not belong to.

    Validation rules:
      * Empty / missing / unparseable header -> None (back-compat).
      * Admin / super_admin user -> trust header (admin can cross
        workspaces by design, matches the existing admin RLS bypass).
      * Non-admin user MUST be in workspace_members for the requested
        workspace_id; if not, returns None (treat as "no workspace
        specified" -- callers fall back to their default-scope rule,
        typically "own + shared + ACL-granted only").

    Auth-disabled (auth.type='none') -> trust header (dev mode).
    """
    raw = request.headers.get("X-Workspace-ID", "").strip()
    if not raw:
        return None
    try:
        wsid = int(raw)
    except ValueError:
        return None

    # Skip validation when auth is disabled (dev) -- matches the
    # rest of the codebase's pattern of NOT enforcing access checks
    # when there is no real user identity to check.
    if _auth_genuinely_disabled():
        return wsid

    # Resolve current user.  get_current_user raises HTTPException
    # on unauthenticated requests but we don't want this helper to
    # change the request's auth outcome -- swallow.
    try:
        user = get_current_user(request)
    except Exception:
        return None    # unauthenticated -> no workspace
    if not user:
        return None

    # Admin / super_admin can scope to any workspace (matches the
    # admin RLS bypass elsewhere).
    if is_admin_like(user):
        return wsid

    # Non-admin: must be a workspace member.
    if _db_manager is None:
        return None
    # Deep-dive #9 (2026-06-30): NFC-normalize before case-fold so
    # combining-character variants (e.g. "josé" as NFD [e + combining
    # acute] vs NFC [precomposed é]) compare equal.  str.lower() alone
    # doesn't normalize; two visually identical usernames could
    # silently fail the membership check.
    import unicodedata as _ud
    def _norm(s: str) -> str:
        return _ud.normalize("NFC", str(s or "")).casefold()
    try:
        members = _db_manager.list_workspace_members(wsid) or []
        username = _norm(user.get("username"))
        for m in members:
            if _norm(m.get("username")) == username:
                return wsid
    except Exception:
        # DB error -- fail CLOSED for safety (treat as not-a-member).
        return None
    # Not a member -> ignore the spoofed header.
    return None


def get_current_user_or_service_key(request: Request) -> dict:
    """``get_current_user``, plus the ONE machine path a route may opt into.

    2026-09-10 (Clockwork completion round).  The Clockwork ``qs_api`` task
    type calls ``/api/business-reports/{id}/execute-async`` as this pod
    with ``X-API-Key``; its docstring, and :func:`get_verified_user`'s,
    both said the report route accepts a service key when
    ``auth.reports_service_api_key`` is on.  The route's dependency was
    :func:`get_current_user`, whose :func:`_resolve_user` reads only
    ``Authorization`` -- so every service call answered 401 "Authorization
    header required" REGARDLESS of the gate.  A surface that could be
    authored (a scheduled report run) and could not work.

    This dependency makes the declared gate true and widens nothing else:
    with the gate OFF the header is ignored and the caller must hold a
    session or password like anyone; with it ON the principal is the
    hashed-key ``api_consumer`` :func:`get_api_key_user` mints -- never
    admin-tier, the resolved principal ``api_key:<id>`` with no groups -- and every
    entitlement the route applies (``can_view``: a published report, or
    one the key's name owns) applies to it unchanged.
    """
    if request.headers.get("X-API-Key", "").strip() and _reports_service_api_key_enabled():
        return get_api_key_user(request)   # raises 401 on bad/inactive/expired key
    return get_current_user(request)


# ── Role-based dependencies ────────────────────────────────────────────────────

def require_admin(user: dict = Depends(get_current_user)) -> dict:
    """Dependency that enforces admin-only access."""
    if _gates_apply(user) and not is_admin_like(user):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def require_admin_read(user: dict = Depends(get_current_user)) -> dict:
    """Phase 130 hotfix-13: read-only admin gate that ALSO accepts the
    'support' role.  Use on GET endpoints where L1/L2 support staff
    need to investigate (health probes, failover state, audit views)
    without granting them mutate permissions.

    Wraps :func:`require_admin` plus :func:`core.roles.is_support`.
    The support-role name is DB-tunable via ``roles.support_role_name``,
    so this honours the operator's renaming choice (no hardcoded
    'support' string).
    """
    if not _gates_apply(user):
        return user
    if is_admin_like(user):
        return user
    try:
        from core.roles import is_support
        if is_support(user):
            return user
    except Exception:
        pass
    raise HTTPException(status_code=403, detail="Admin or support access required")


def require_role(*allowed_roles: str):
    """
    Factory — returns a dependency that allows only the specified roles.

    Phase 107-F: ``super_admin`` is implicitly allowed by every ``require_role``
    check — it's a break-glass role that must work in every protected endpoint.

    Example:
        @router.post("/api/reports")
        async def create_report(user: dict = Depends(require_role("admin", "analyst"))):
    """
    def _dep(user: dict = Depends(get_current_user)) -> dict:
        if _gates_apply(user):
            role = (user or {}).get("role", "viewer")
            if role != "super_admin" and role not in allowed_roles:
                raise HTTPException(
                    status_code=403,
                    detail=f"Requires role: {', '.join(allowed_roles)}",
                )
        return user
    return _dep


# ── Capability-based dependency (tool entitlement, 2026-10-31) ─────────────────
#
# Every route declares ONE capability from core/tool_entitlement/vocabulary.py
# and the decision is core.tool_entitlement.can() -- grants to the caller's
# role (the bundle), AD groups, QueryStudio user groups or the user itself.
# ``require_admin`` / ``require_admin_read`` / ``require_role`` above are kept
# for the few non-route callers that still spell a role check; no ROUTE uses
# them (tests/test_tool_entitlement_route_guard_2026_10_31.py).

def _capability_refusal(capability: str) -> HTTPException:
    from core.tool_entitlement.vocabulary import refusal_text
    return HTTPException(status_code=403, detail=refusal_text(capability),
                         headers={"X-QS-Missing-Capability": capability})


def check_capability(user: dict, capability: str, scope=None) -> dict:
    """The decision for a user dict already in hand (route bodies, the
    clockwork author check).  Raises the plain 403; a store that cannot be
    read is a 503 that says the check could not be made."""
    if not _gates_apply(user):
        return user
    from core.tool_entitlement import engine as _te
    try:
        allowed = _te.can(user, capability, scope)
    except _te.PermissionCheckUnavailable as exc:
        logger.error("tool_entitlement: permission check unavailable for %r: %s", capability, exc)
        raise HTTPException(status_code=503,
                            detail="Your permissions could not be checked right now. Try again shortly.") from None
    if not allowed:
        raise _capability_refusal(capability)
    return user


def require_capability(capability: str, *, identity=None, rate_limited: bool = False):
    """Factory -- a dependency that lets the caller through when they hold
    ``capability`` (``core.tool_entitlement.can``).

    ``identity`` is the dependency that resolves WHO is calling (default
    :func:`get_current_user`); a route whose callers may be an API key or a
    share token passes its own (``get_api_key_or_ad_user``,
    ``require_execute_access`` ...).  ``rate_limited`` keeps the 30/min
    sensitive-operation limit (30/min per user) applied.

    The returned dependency carries ``qs_capability`` so the route guard can
    read every route's declaration off the live app, never from a grep.

    Example:
        @router.post("/api/business-reports")
        async def create_report(user: dict = Depends(require_capability("reports.create"))):
    """
    from core.tool_entitlement.vocabulary import is_capability
    if not is_capability(capability):
        # a typo here would deny everyone at run time; refuse at import instead
        raise ValueError(f"require_capability: unknown capability {capability!r} "
                         f"-- declare it in core/tool_entitlement/vocabulary.py")
    _identity = identity if identity is not None else get_current_user

    def _decide(request: Request, user: dict) -> dict:
        check_capability(user, capability)
        if rate_limited:
            try:
                from core.rate_limiter import check_rate_limit, RateLimitExceededError
                username = user.get("username", request.client.host if request.client else "unknown")
                check_rate_limit("admin_sensitive", username, limit=30, window_seconds=60)
            except RateLimitExceededError:
                raise HTTPException(status_code=429, detail="Admin rate limit exceeded (30/min)")
            except Exception:
                pass  # rate limiter failure should not block admin operations
        return user

    # 2026-11-01: the gate runs where its IDENTITY runs.  A route that chose an
    # ASYNC identity (aget_current_user: the drafts, kept off the shared pools on
    # purpose -- test_draft_save_isolated_from_query_load) got a SYNC gate, which
    # FastAPI runs on anyio's shared worker threads: under load the draft queued
    # behind every sync dependency again.  The decision reads the grants and the
    # principals from their in-process memo (core/tool_entitlement/engine.py),
    # so on the loop it is a dict lookup; a sync identity keeps the sync gate.
    if inspect.iscoroutinefunction(_identity):
        async def _dep(request: Request, user: dict = Depends(_identity)) -> dict:
            return _decide(request, user)
    else:
        def _dep(request: Request, user: dict = Depends(_identity)) -> dict:
            return _decide(request, user)

    _dep.qs_capability = capability
    _dep.qs_identity = _identity
    _dep.__name__ = f"require_capability[{capability}]"
    _dep.__qualname__ = _dep.__name__
    return _dep


def require_execute_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    x_embed_token: Optional[str] = Header(None),
) -> dict:
    """
    Dependency for execution endpoints.
    Grants access via normal auth OR a valid share/embed token —
    enabling SharedQueryPage, SharedDashboardPage, and EmbeddedReportPage
    to execute queries without requiring the viewer to be logged in.
    """
    if _auth_genuinely_disabled():
        return {"username": "guest", "role": "admin", "is_admin": True}

    # 2026-08-23 -- the identity was resolved via ``Depends(get_current_user)``,
    # which RAISES 401 for a credential-less request BEFORE this function's body
    # runs.  So every share/embed-token branch below was DEAD CODE for the one
    # audience it exists to serve: the anonymous SharedDashboardPage /
    # SharedQueryPage / EmbeddedReportPage viewer.  ``executeSharedQuery`` sends
    # ``X-Share-Token`` and NO ``Authorization`` header, so under real auth
    # (type != none) every shared widget got 401 "Authorization header required"
    # and rendered nothing -- invisible under the auth.type=none test fixture,
    # where the anonymous caller is a guest ADMIN and the token path is never
    # taken.  Resolve identity HERE instead: a request that carries credentials
    # is still fully validated (bad creds → 401 as before); a credential-LESS
    # request is not an error -- it falls through to the token layer this
    # function was built for.
    _user = None
    if request.headers.get("Authorization"):
        _user = get_current_user(request)

    # Authenticated analyst/admin/super_admin
    if _user and _user.get("role") in ("admin", "analyst", "super_admin"):
        return _user

    # ── SECURITY AUDIT 2026-08-03 (S5) ────────────────────────────────────
    # Share/embed tokens mint a SCOPED viewer principal carrying the object
    # the token was created for; enforce_token_execute_scope() (below)
    # restricts execution to exactly that object.  Expiry is enforced by the
    # shared resolver -- previously only checked on the metadata GET route,
    # never on execute.
    principal = _share_or_embed_principal(x_share_token, x_embed_token)
    if principal:
        return principal

    raise HTTPException(status_code=403, detail="Authorization required")


def _share_or_embed_principal(
    x_share_token: Optional[str],
    x_embed_token: Optional[str],
) -> Optional[dict]:
    """Resolve an anonymous share/embed token to a SCOPED viewer principal.

    ONE resolver shared by ``require_execute_access`` (the execute gate) and
    ``require_execution_read_access`` (the result/status read gate), so the
    token → principal fact is never modelled two ways.  Returns ``None`` when
    no valid token is present; raises 410 when a token is present but expired
    (a revoked/``is_active=False`` token resolves to ``None`` -> denied by the
    caller).  Never raises on a lookup error -- fail closed to ``None``.
    """
    # Share-token path
    if x_share_token and _db_manager:
        try:
            from datetime import datetime as _dt, timezone as _tz2
            share = _db_manager.get_share_by_token(x_share_token)
            _share_kind = "query" if share else None
            if not share:
                share = _db_manager.get_dashboard_share_by_token(x_share_token)
                _share_kind = "dashboard" if share else None
            if share and share.get("is_active"):
                _s_exp = share.get("expires_at")
                if _s_exp:
                    if isinstance(_s_exp, str):
                        _s_exp = _dt.fromisoformat(_s_exp.replace("Z", "+00:00"))
                    if _s_exp.tzinfo is None:
                        _s_exp = _s_exp.replace(tzinfo=_tz2.utc)
                    if _dt.now(_tz2.utc) > _s_exp:
                        raise HTTPException(status_code=410, detail="Share link has expired")
                principal = {
                    "username": f"shared:{x_share_token[:8]}",
                    "role": "share_viewer",
                    "is_admin": False,
                    "auth_via": "share_token",
                }
                if _share_kind == "query":
                    principal["share_query_id"] = share.get("query_id")
                else:
                    principal["share_dashboard_id"] = share.get("dashboard_id")
                return principal
        except HTTPException:
            raise
        except Exception as _share_exc:
            logger.debug("share-token lookup failed: %s", _share_exc)

    # Embed-token path (Phase 27)
    if x_embed_token and _db_manager:
        try:
            from datetime import datetime, timezone as _tz
            tok = _db_manager.get_embed_token(x_embed_token)
            if tok and tok.get("is_active"):
                expires = tok.get("expires_at")
                if expires:
                    if isinstance(expires, str):
                        expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    if expires.tzinfo is None:
                        expires = expires.replace(tzinfo=_tz.utc)
                    if datetime.now(_tz.utc) > expires:
                        raise HTTPException(status_code=410, detail="Embed token expired")
                return {
                    "username": f"embed:{x_embed_token[:8]}",
                    "role": "embed_viewer",
                    "is_admin": False,
                    "auth_via": "embed_token",
                    "embed_report_id": tok.get("report_id"),
                }
        except HTTPException:
            raise
        except Exception as _embed_exc:
            logger.debug("embed-token lookup failed: %s", _embed_exc)

    return None


def require_execution_read_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    x_embed_token: Optional[str] = Header(None),
) -> dict:
    """Identity for execution RESULT / STATUS reads (GET only).

    2026-08-23 -- the shared/embedded viewer executes a widget via
    ``/api/execute`` (X-Share-Token) and then reads the rows via
    ``/api/executions/{id}/status`` + ``/results``.  Those two routes gated on
    ``get_current_user``, which 401s the anonymous viewer -- so a shared
    dashboard executed its widgets and could NEVER read the result, a dead end
    the auth.type=none fixture (guest = admin) hid.

    Resolution mirrors ``require_execute_access``: a credentialled request is
    fully validated (bad creds -> 401); a credential-less request is allowed
    ONLY as a valid share/embed-token viewer.  The caller MUST additionally
    bind the token viewer to the execution it launched via
    :func:`assert_execution_visible_to_token` -- this dependency proves
    identity, not per-execution scope.
    """
    if _auth_genuinely_disabled():
        return {"username": "guest", "role": "admin", "is_admin": True}
    if request.headers.get("Authorization"):
        return get_current_user(request)          # bad creds -> 401
    principal = _share_or_embed_principal(x_share_token, x_embed_token)
    if principal:
        return principal
    raise HTTPException(status_code=401, detail="Authorization header required")


def assert_execution_visible_to_token(user: Optional[dict], execution: Optional[dict]) -> None:
    """Bind a share/embed-token viewer to the execution it launched.

    A token viewer's ``username`` is ``shared:<t8>`` / ``embed:<t8>`` and the
    execution it launches is stamped with that same ``executed_by`` (execute
    path sets executed_by = principal username).  Restrict a token viewer to
    reading EXACTLY its own executions -- not the broad service-prefix grant
    ``_enforce_execution_ownership`` extends to authenticated users -- so one
    share link cannot read another share's (or a published-view's) result by
    guessing an execution id.  No-op for real authenticated principals; those
    keep the existing ownership rule the route already applies.
    """
    if not is_token_principal(user):
        return
    owner = ((execution or {}).get("executed_by") or "")
    if owner != (user or {}).get("username", ""):
        raise HTTPException(status_code=404, detail="Execution not found")


# ── Share/embed-token scope enforcement (SECURITY AUDIT 2026-08-03, S5) ──────

def is_token_principal(user: Optional[dict]) -> bool:
    """True when the principal was minted from a share/embed token."""
    return bool(user) and user.get("auth_via") in ("share_token", "embed_token")


def reject_token_principals(user: Optional[dict]) -> None:
    """Guard for endpoints that must never be reachable with a share/embed
    token (batch submit, admin cache invalidation, …)."""
    if is_token_principal(user):
        raise HTTPException(
            status_code=403,
            detail="Share/embed tokens cannot access this endpoint",
        )


def enforce_token_execute_scope(user: dict, request) -> None:
    """Restrict a share-token execution request to the object the token was
    minted for.  Mutates ``request`` (an ExecuteQueryRequest) so the server
    executes the STORED saved query rather than trusting a caller-supplied
    config.  No-op for real (non-token) principals.

    Rules:
      * embed tokens never reach /api/execute — they have their own scoped
        endpoint (/api/embedded-report/{token}/execute);
      * raw SQL / cross-connection fields are always refused;
      * a query-share token may execute ONLY its shared saved query — a
        submitted query_config is replaced by the saved query id;
      * a dashboard-share token may execute only saved queries that are
        widgets of the shared dashboard.
    """
    if not is_token_principal(user):
        return
    if user.get("auth_via") == "embed_token":
        raise HTTPException(
            status_code=403,
            detail="Embed tokens cannot execute queries here — use "
                   "/api/embedded-report/{token}/execute",
        )
    if getattr(request, "raw_sql", None) or getattr(request, "secondary_raw_sql", None):
        raise HTTPException(
            status_code=403,
            detail="Share links cannot execute arbitrary SQL",
        )
    if (getattr(request, "secondary_connection_id", None)
            or getattr(request, "secondary_query_config", None)):
        raise HTTPException(
            status_code=403,
            detail="Share links cannot execute cross-connection queries",
        )

    req_qid = getattr(request, "query_id", None)
    scope_qid = user.get("share_query_id")
    scope_did = user.get("share_dashboard_id")

    if scope_qid is not None:
        if req_qid is not None and int(req_qid) != int(scope_qid):
            raise HTTPException(
                status_code=403,
                detail="This share link only permits its own shared query",
            )
        # SharedQueryPage submits the query_config it received from
        # GET /api/shared/{token}.  Never trust a caller-supplied config —
        # execute the stored saved query the token was minted for.
        request.query_id = int(scope_qid)
        request.query_config = None
        return

    if scope_did is not None:
        if req_qid is None:
            raise HTTPException(
                status_code=403,
                detail="This dashboard share link requires a query_id of one "
                       "of the dashboard's widgets",
            )
        allowed: set = set()
        try:
            widgets = (_db_manager.list_widgets(int(scope_did))
                       if _db_manager else []) or []
            # 2026-10-26: ONLY saved-query tiles.  /api/execute runs a SAVED
            # QUERY by id; a sql_query tile's source_id names a row of a
            # DIFFERENT table (sql_queries), so admitting it here let a
            # dashboard link run whichever saved query happened to share
            # that number.  A finance-report tile has its own scoped routes
            # (/api/shared-dashboard/{token}/widgets/{id}/execute).
            allowed = {
                int(w.get("source_id")) for w in widgets
                if w.get("widget_type") == "saved_query"
                and w.get("source_id") is not None
            }
        except Exception as _w_exc:
            logger.warning("dashboard-share widget lookup failed: %s", _w_exc)
            allowed = set()   # fail CLOSED
        if int(req_qid) not in allowed:
            raise HTTPException(
                status_code=403,
                detail="This share link only permits the shared dashboard's queries",
            )
        # Widget flow only ever sends query_id; drop any smuggled config.
        request.query_config = None
        return

    # Token principal with no recorded scope — refuse rather than guess.
    raise HTTPException(status_code=403, detail="Share token has no execution scope")


# ── Ownership helper ───────────────────────────────────────────────────────────

def is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if user owns item, it's shared, or user is admin."""
    if not user or is_admin_like(user):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )


# ── API Key authentication (Phase 75 — Published Views) ──────────────────────

#: 2026-09-05 -- "there is a caller" is a DIFFERENT proposition from
#: "this principal's groups are unresolved", and this module is the only one
#: that can answer the first: it is where a PRESENTED CREDENTIAL becomes a
#: principal.  Imported at module scope so a mint site cannot silently skip
#: it behind a lazy import.
from core.row_security.principal import LIVE_CALLER_KEY  # noqa: E402


def api_key_refusal(api_key: Optional[dict]) -> Optional[str]:
    """Why this key row may NOT call (inactive / missing / expired), or None.
    ONE rule for the X-API-Key door and the try-as door (2026-10-24)."""
    if not api_key or not api_key.get("is_active"):
        return "Invalid or inactive API key"
    expires = api_key.get("expires_at")
    if expires:
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            return "API key expired"
    return None


def api_key_principal(api_key: dict) -> dict:
    """THE principal an API key calls as (2026-10-24: moved out of
    ``get_api_key_user`` so a try-as -- core/published_api/try_as.py -- is
    exactly the consumer, never a second construction)."""
    return {
        "username": f"apikey:{api_key.get('key_prefix', 'unknown')}",
        "display_name": api_key.get("name", "API Consumer"),
        "role": "api_consumer",
        "is_admin": False,
        "groups": [],
        "api_key_id": api_key["id"],
        "scoped_view_ids": api_key.get("scoped_view_ids") or [],
        "rate_limit": api_key.get("rate_limit"),
        "auth_method": "api_key",
        # 2026-10-25 -- AN API KEY IS A RESOLVED PRINCIPAL: ``api_key:<id>``
        # (core/row_security/principal.py).  Its ``groups: []`` is the truth
        # -- a key has no directory identity -- and a row policy reaches it
        # by a binding to ``api_key:<id>`` (or ``all:*`` / its role), never
        # by a group.  From 2026-09-05 to today this dict carried
        # ``rls_unresolved: True`` ("nobody looked its groups up"), and the
        # rewriter refused every governed table for every key: measured on
        # the rig, a table carrying ONE policy bound to some other group
        # made every API key a 403.  Whether an API applies any data policy
        # to its keys is the API's own switch (published_views.
        # entitlement_mode, api/published_views/helpers.py::
        # with_entitlement_scope); what a key holds nothing of is FB-45's
        # composition (no grant held = no rows), never a refusal.
        #
        # ...AND THERE IS A CALLER (2026-09-05).  core/reports/user_sql_vars.py
        # renders ${user.*} against the report OWNER when there is none; a
        # service key renders its OWN (empty) scope.  Two propositions, two
        # fields; see core/row_security/principal.py.
        LIVE_CALLER_KEY: True,
    }


def get_api_key_user(request: Request) -> dict:
    """
    FastAPI dependency — authenticate via X-API-Key header.

    Returns a synthetic user dict with role='api_consumer' and the key's
    scoped view IDs so the endpoint can enforce access control.
    """
    key = request.headers.get("X-API-Key", "").strip()
    if not key:
        raise HTTPException(status_code=401, detail="X-API-Key header required")

    key_hash = hashlib.sha256(key.encode()).hexdigest()
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Service not ready")

    # E-M4 — short-TTL cache avoids the SELECT on the hot path.  Fail-safe:
    # a cache miss (or caching disabled/errored) falls back to the direct
    # lookup below.  Only ACTIVE keys are cached; is_active/expiry are still
    # re-validated on every request from the (cached) row, so a key that is
    # already inactive is never served from cache.
    _cache_hit = True
    api_key = _api_key_cache_get(key_hash)
    if api_key is None:
        _cache_hit = False
        api_key = _db_manager.get_api_key_by_hash(key_hash)

    why = api_key_refusal(api_key)
    if why:
        # Never cache an inactive/missing/expired key; drop any stale entry too.
        invalidate_api_key_cache(key_hash)
        raise HTTPException(status_code=401, detail=why)

    # Populate the cache only after the key passed active+expiry checks.
    if not _cache_hit:
        _api_key_cache_put(key_hash, api_key)

    # Update usage stats — fire-and-forget + throttled so the UPDATE is off
    # the request-latency path (E-M4).  When caching/throttle is disabled
    # (ttl<=0) fall back to the original synchronous touch for exact parity.
    if int(_pv_cfg_get("api_key_cache_ttl_seconds", 30)) <= 0:
        try:
            _db_manager.touch_api_key_usage(api_key["id"])
        except Exception as exc:
            logger.debug("api-key usage touch failed (sync): %s", exc)
    else:
        _touch_api_key_usage_async(api_key["id"])

    return api_key_principal(api_key)


def get_api_key_or_ad_user(request: Request) -> dict:
    """The published-API principal, STASHED on the request (2026-10-17,
    core/published_api/calls.py): a resolved consumer rides ``request.state``
    so a refusal raised later in the route (the rate limit, access denied, a
    retired API) is recorded against it; a failed authentication leaves its
    CLAIM -- a key's first 8 characters, a Basic username -- labelled
    unverified, never the credential.  The resolution itself is
    :func:`_resolve_api_key_or_ad_user`, unchanged."""
    from core.published_api import calls as _calls
    try:
        user = _resolve_api_key_or_ad_user(request)
    except HTTPException:
        _key = request.headers.get("X-API-Key", "").strip()
        if _key:
            _calls.stash_auth_failure(request, auth_method="api_key", claim=_key[:8])
        else:
            _auth = request.headers.get("Authorization", "")
            if _auth.lower().startswith("basic "):
                try:
                    from base64 import b64decode as _b64
                    _claim = _b64(_auth[6:]).decode("utf-8", "replace").partition(":")[0]
                except Exception:
                    _claim = ""
                _calls.stash_auth_failure(request, auth_method="ad_basic", claim=_claim)
            elif _auth.startswith("Bearer "):
                _calls.stash_auth_failure(request, auth_method="session", claim="")
        raise
    _calls.stash_api_user(request, user)
    return user


def _resolve_api_key_or_ad_user(request: Request) -> dict:
    """
    Phase 82 — Dual-auth dependency for Published View external endpoints.

    Accepts:
      - X-API-Key header  → delegates to get_api_key_user() (existing API key path)
      - Bearer session    → the product's own session token (2026-08-23, P6 D8)
      - HTTP Basic auth   → authenticates via AD/LDAP and fetches group memberships

    The returned dict always includes ``auth_method`` so callers can apply
    the correct access-control check (api_key vs session vs ad_basic vs
    basic_noauth).

    2026-08-23 (P6 audit D8) — WHY the Bearer branch exists.  Both internal
    testers of this surface — the API Explorer's "test with your session"
    fallback and PublishedViewsPage's Test dialog — call these /api/v1
    routes through safeFetch, which authenticates the way every internal
    route does: ``Authorization: Bearer <session>``.  This dependency
    accepted only X-API-Key/Basic, so BOTH testers 401'd unconditionally —
    a dead journey the auth.type=none fixtures could never see.  A session
    is the SAME identity class as Basic (the same human, resolved through
    core.sessions instead of a fresh AD bind), so accepting it widens
    nothing: the principal still passes _check_view_access under the
    identical group rules.  An invalid/expired session is a 401, never a
    fall-through.

    Raises HTTP 401 if no credential is present (and auth is genuinely
    enabled) or if any presented credential is invalid.
    """
    import binascii
    from base64 import b64decode

    # 2026-10-24 -- an admin TRYING the API as one of its consumers
    # (core/published_api/try_as.py): the token names the key; the principal
    # is that key's own (api_key_principal), plus who is trying.
    try_as = request.headers.get("X-QS-Try-As", "").strip()
    if try_as:
        from core.published_api.try_as import TryAsRefused, read as _try_read
        try:
            claims = _try_read(try_as)
        except TryAsRefused as exc:
            raise HTTPException(status_code=401, detail=f"Try-as refused: {exc}")
        if not _db_manager:
            raise HTTPException(status_code=503, detail="Service not ready")
        row = _db_manager.get_api_key(int(claims["api_key_id"]))
        why = api_key_refusal(row)
        if why:
            raise HTTPException(status_code=401, detail=f"Try-as refused: {why}")
        principal = dict(api_key_principal(row))
        principal["tried_by"] = claims["tried_by"]
        return principal

    # Try API key first — existing behaviour is preserved exactly
    api_key_header = request.headers.get("X-API-Key", "").strip()
    if api_key_header:
        return get_api_key_user(request)

    auth_header = request.headers.get("Authorization", "")

    # Try the product's own session token (Bearer) — P6 D8, see docstring.
    if auth_header.startswith("Bearer "):
        _sess_tok = auth_header[7:].strip()
        _sess_user = None
        try:
            from core.sessions import get_session as _sess_get
            _sess_user = _sess_get(_sess_tok)
        except Exception as _sess_exc:
            # Session store unavailable — fail CLOSED (401), never open.
            logger.warning("PV session lookup failed: %s", _sess_exc)
            _sess_user = None
        if not _sess_user:
            raise HTTPException(status_code=401,
                                detail="Session invalid or expired")
        _sess_groups = list(_sess_user.get("groups") or [])
        return {
            "username": _sess_user.get("username", ""),
            "display_name": _sess_user.get("display_name",
                                           _sess_user.get("username", "")),
            "role": _sess_user.get("role", "viewer"),
            "is_admin": bool(_sess_user.get("is_admin", False)),
            "groups": _sess_groups,
            "ad_groups": _sess_groups,
            "scoped_view_ids": None,   # governed by the view's allowed_ad_groups
            "api_key_id": None,
            "auth_method": "session",
        }

    # Try HTTP Basic auth (AD credentials)
    if auth_header.lower().startswith("basic "):
        try:
            decoded = b64decode(auth_header[6:]).decode("utf-8")
        except (binascii.Error, UnicodeDecodeError):
            raise HTTPException(status_code=401, detail="Invalid Authorization header encoding")

        username, _, password = decoded.partition(":")
        if not username:
            raise HTTPException(status_code=401, detail="Username missing in Authorization header")

        from core.config import auth as _auth_cfg_local
        # 2026-08-17 FAIL-CLOSED, matching _resolve_user above: only mint the
        # no-auth consumer when the config ACTUALLY loaded and deliberately
        # selected auth.type='none'.  When 'none' is an ACCIDENT of a
        # missing/corrupt config, accepting ANY Basic credentials here handed
        # out a principal that then flowed into the published-view access check
        # -- a silent bypass on the paid data surface.  _resolve_user was
        # hardened for exactly this on 2026-07-15; this second minting site was
        # missed.
        _pv_load_failed = False
        try:
            from core.config import config_load_failed as _cfg_failed
            _pv_load_failed = _cfg_failed()
        except Exception:
            _pv_load_failed = False
        if _auth_cfg_local.type == "none" and not _pv_load_failed:
            # Dev/test mode — accept any Basic credentials as a guest consumer
            return {
                "username": username,
                "display_name": username,
                "role": "api_consumer",
                "is_admin": False,
                "groups": [],
                "ad_groups": [],
                "scoped_view_ids": None,
                "api_key_id": None,
                "auth_method": "basic_noauth",
                # 2026-10-25 -- auth is OFF on purpose (auth.type=none), so
                # this guest IS the deployment's resolved principal: a
                # person with no groups, served by the policies that bind
                # it (user / role / all:*) and FB-45's composition for the
                # rest.  It was marked ``rls_unresolved`` from 2026-09-05 --
                # a 403 on every governed table in dev mode, the "no one
                # should get 403" the owner closed.
                # A dev-mode guest IS a caller: ${user.*} renders against
                # THIS principal's (empty) scope, never the report owner's.
                LIVE_CALLER_KEY: True,
            }

        from core.ad_auth import authenticate_user as _ad_auth
        user = _ad_auth(username, password)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid AD credentials")

        # Retrieve group memberships — fail mode is configurable (Phase 83H)
        ad_groups: list = user.get("groups", [])
        import logging as _deps_log
        _deps_logger = _deps_log.getLogger(__name__)
        # 2026-09-01 -- ``core.ad_auth`` HAS NO ``get_user_groups``.  It never
        # has: the module exposes ``authenticate_user`` / ``lookup_ad_user``
        # and nothing else that returns memberships.  So this import raised
        # ImportError on EVERY AD login, the handler below ran every time,
        # and the ``else`` that cleared ``_rls_unresolved`` was unreachable
        # by construction.
        #
        # The consequence was not cosmetic.  Every authenticated AD caller
        # was marked ``rls_unresolved=True``, which ``build_user_ctx`` reads
        # and which makes ``secure_sql`` REFUSE a governed table -- so row
        # security behaved as though group resolution had failed, for
        # everyone, permanently, while a warning was logged on every request.
        #
        # There was never anything to fetch: ``authenticate_user`` resolves
        # the memberships during the SAME LDAP bind that authenticates the
        # user, and ``_resolve_role`` already derives the user's ROLE from
        # exactly this list.  A list trusted to decide whether someone is an
        # admin is resolved enough to decide which rows they see.
        #
        # 2026-10-25 -- EMPTY IS RESOLVED.  The bind that authenticated this
        # person returned their memberships; "no groups" is the directory's
        # answer, not a failed lookup.  From 2026-08-20 to today an empty
        # list was marked ``rls_unresolved`` ("resolved to nothing and could
        # not tell are indistinguishable here") and the rewriter refused
        # every governed table for a person their directory places in no
        # group -- the owner: "if no AD groups it should work ... no one
        # should get 403".  The hole the marker guarded (a groupless
        # principal matching no binding is SKIPPED, i.e. served unfiltered)
        # is closed by FB-45's composition: no grant held = no rows.  A
        # person with no groups is served by the policies that bind them
        # (user:<name>, role, all:*).  The refusal stays where a lookup
        # genuinely FAILED: ``_ad_auth`` raising lands in the caller's 401 /
        # 5xx, and the fabricated background principals keep their marker.
        _rls_unresolved = False
        if ad_groups or is_admin_like(user):
            _ad_fetch_failed_open = False
        else:
            _deps_logger.info(
                "No AD groups for %s -- a resolved principal with no groups: "
                "served by the policies that bind it", username)
            # Phase 83H: the VIEW-ACL fail mode.  ``ad_group_fetch_fail_mode``
            # steers ``_ad_fetch_failed_open``, consumed by exactly one thing:
            # the view ACL intersection in
            # published_views/helpers.py::_check_view_access ("allow" lets a
            # groupless consumer open a group-restricted VIEW).  It never
            # decided ROW security and does not now.
            try:
                from core.config import published_views as _pv_cfg
                fail_mode = _pv_cfg.ad_group_fetch_fail_mode
            except Exception:
                fail_mode = "deny"
            if fail_mode == "allow":
                # BF-415 — previously stored the literal string "__ALL__" inside
                # the groups list as a sentinel.  But that namespace is shared
                # with real AD groups: any corp directory with a group literally
                # named "__ALL__" (test/admin prefixes are common) granted that
                # user master-key access to every PV.  Track the bypass
                # out-of-band on the user record instead, then have
                # _check_view_access read the flag rather than scan groups.
                ad_groups = user.get("groups", [])
                _ad_fetch_failed_open = True
            else:
                ad_groups = user.get("groups", [])  # fall back to authenticate_user groups
                _ad_fetch_failed_open = False

        return {
            "username": username,
            "display_name": user.get("display_name", username),
            "role": user.get("role", "viewer"),
            "is_admin": user.get("is_admin", False),
            "groups": ad_groups,
            "ad_groups": ad_groups,
            # BF-415 — explicit, out-of-band marker; consumed by
            # api/published_views/helpers.py::_check_view_access.
            "_ad_fetch_failed_open": _ad_fetch_failed_open,
            # 2026-10-25 -- always False on this path: the bind RESOLVED this
            # person (see above).  Kept as an explicit field so the chokepoint
            # (core.row_security build_user_ctx) reads one spelling.
            "rls_unresolved": _rls_unresolved,
            # 2026-09-05 -- an AD caller is a CALLER.  Without this, a
            # groupless AD login rendered ${user.groups} as the report
            # OWNER's groups.
            LIVE_CALLER_KEY: True,
            "scoped_view_ids": None,  # AD users access is governed by view's allowed_ad_groups
            "api_key_id": None,
            "auth_method": "ad_basic",
        }

    # 2026-08-23 (P6 D8) — credential-less caller while auth is GENUINELY
    # disabled (deliberate auth.type='none', config loaded): mint the same
    # guest consumer the Basic-under-none branch mints, so dev-mode journeys
    # (PV Test dialog, API Explorer) work without fabricating credentials.
    # _check_view_access re-verifies basic_noauth against live config, so a
    # forged/stale principal cannot ride this label when auth is on.
    # 2026-09-17 -- and ONLY when the deployment has said so.
    #
    # Measured live: no credential at all -> 200 with 3,000 real rows from
    # the paid data surface, on BOTH the main API and the dedicated published
    # tier.  (An earlier note in the Fable brief called this a difference
    # BETWEEN the tiers; that was wrong -- the published pod was running a
    # five-week-old image.  Once both ran the same code they agreed, and what
    # they agreed on is this branch.)
    #
    # The two journeys this branch was added for do not need it: the API
    # Explorer sends a pasted X-API-Key or a Bearer session through
    # safeFetch, and both are handled above.  An API key here is not only
    # identity -- it carries the per-view SCOPE -- so skipping it skips
    # AUTHORIZATION, not just login.  See the config property's docstring for
    # why the default is now False.
    if not auth_header and _auth_genuinely_disabled()             and _pv_allows_anonymous():
        return {
            "username": "guest",
            "display_name": "Guest",
            "role": "api_consumer",
            "is_admin": False,
            "groups": [],
            "ad_groups": [],
            "scoped_view_ids": None,
            "api_key_id": None,
            "auth_method": "basic_noauth",
            # 2026-10-25 -- a resolved principal with no groups; see the
            # Basic-under-none branch above.
            LIVE_CALLER_KEY: True,
        }

    raise HTTPException(
        status_code=401,
        detail="X-API-Key header, Bearer session, or HTTP Basic Authorization required",
    )


def _pv_allows_anonymous() -> bool:
    """Whether a credential-less /api/v1 caller is served under auth.type=none.

    Fails CLOSED on any error reading the config: this gate stands in front
    of the paid data surface, and "we could not read the setting" must not
    read as "the setting was permissive".
    """
    try:
        from core.config import published_views as _pv_cfg
        return bool(_pv_cfg.allow_anonymous_when_auth_disabled)
    except Exception as _pv_exc:            # noqa: BLE001
        logger.warning(
            "published_views.allow_anonymous_when_auth_disabled unreadable "
            "(%s) -- requiring a credential", _pv_exc)
        return False
