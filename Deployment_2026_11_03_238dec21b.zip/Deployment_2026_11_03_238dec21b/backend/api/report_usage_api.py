"""Report readership analytics API — governance layer (2026-08-17).

Data source: ``core.reports.usage_store`` (one ``br_serve_log`` row per
business-report serve, fed by the ``log_report_serve`` chokepoint).

PRIVACY POSTURE — readership is per-user data; this module ENFORCES it:

* **Admins** (and read-only **support** staff via the ``sees_all`` tier of
  ``core.reports.authorization.resolve_viewer_context``) may see all
  readership and any user's activity.
* **Report owners** (including owner-group members) may see who read THEIR
  reports — and only theirs.  Most-read / never-read are silently scoped to
  the caller's own reports for non-admins.
* **Every user** may see their OWN activity (``/me`` or their username);
  requesting another user's activity is 403 for non-admins.
* Ordinary viewers of a report learn nothing about who else reads it —
  being able to VIEW a report does NOT grant its readership analytics.

Authorization reuses the existing chokepoint primitives
(``resolve_viewer_context`` — admin/support tier, owner-group membership)
rather than inventing a new rule; the OWNER gate here is deliberately
STRICTER than ``can_view_business_report`` because readership is more
sensitive than the report itself.

Authentication is applied at the ROUTER (the lineage_api lesson: a newly
added route must inherit auth rather than default open).

Router registration (main.py — applied by the main agent):
    from api.report_usage_api import router as report_usage_router
    app.include_router(report_usage_router, tags=["report-usage"])
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as FastQuery

from api.deps import (require_capability, 
    get_current_user as _user_dep,
    require_admin as _admin_dep,
    require_db as _require_db,
)

logger = logging.getLogger(__name__)

router = APIRouter()


# ── Access gate ──────────────────────────────────────────────────────────────

def _sees_all(user: Optional[dict], db) -> bool:
    """Admin / support tier — the same resolution the BR view chokepoint uses."""
    try:
        from core.reports.authorization import resolve_viewer_context
        return bool(resolve_viewer_context(user, db).get("sees_all"))
    except Exception as exc:
        logger.debug("[br-usage-api] sees_all resolution failed "
                     "(fail-closed): %s", exc)
        return False


def _owns_report(report: dict, user: Optional[dict], db) -> bool:
    """Owner or owner-group member.  Fail-closed."""
    username = str((user or {}).get("username") or "").strip()
    if not username:
        return False
    owner = str(report.get("owner") or "")
    if owner and owner.lower() == username.lower():
        return True
    og = report.get("owner_group_id")
    if og is None:
        return False
    try:
        from core.reports.authorization import resolve_viewer_context
        ctx = resolve_viewer_context(user, db)
        return int(og) in ctx.get("group_ids", frozenset())
    except Exception as exc:
        logger.debug("[br-usage-api] owner-group resolution failed "
                     "(fail-closed): %s", exc)
        return False


def _require_readership_access(report_id: int, user: dict, db) -> dict:
    """404 unknown id; 403 known-but-not-owner-or-admin; report dict on allow.

    404-before-403 ordering deliberately mirrors the sql_files authz fix:
    a stranger who cannot view the report gets 404 (no existence oracle);
    a VIEWER who can see the report but doesn't own it gets an explicit 403
    (readership is more sensitive than the report itself).
    """
    report = db.get_business_report(int(report_id))
    if _sees_all(user, db):
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")
        return report
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if _owns_report(report, user, db):
        return report
    # Not the owner.  Distinguish viewer (403) from stranger (404).
    try:
        from core.reports.authorization import can_view_business_report
        can_view = can_view_business_report(report, user, db)
    except Exception:
        can_view = False
    if can_view:
        raise HTTPException(
            status_code=403,
            detail="Readership analytics are visible to the report owner "
                   "and admins only")
    raise HTTPException(status_code=404, detail="Report not found")


# ── Per-report readership ────────────────────────────────────────────────────

@router.get("/api/report-usage/reports/{report_id}")
def get_report_readership(
        report_id: int,
        days: int = FastQuery(0, ge=0, description="Window in days; 0 = all time"),
        recent_limit: int = FastQuery(50, ge=1, le=500),
        user: dict = Depends(require_capability("reports.view"))):
    """Who read this report, when, how often.  Owner/admin only."""
    db = _require_db()
    report = _require_readership_access(report_id, user, db)
    from core.reports import usage_store
    out = usage_store.report_readership(db, report_id, days=days or None,
                                        recent_limit=recent_limit)
    out["report_name"] = report.get("name")
    out["owner"] = report.get("owner")
    return out


# ── Most-read / never-read (the retirement drivers) ──────────────────────────

@router.get("/api/report-usage/most-read")
def get_most_read(
        days: int = FastQuery(30, ge=0, description="Window in days; 0 = all time"),
        limit: int = FastQuery(20, ge=0, description="0 = unlimited"),
        user: dict = Depends(require_capability("reports.view"))):
    """Reports ranked by serves.  Admins: all reports; others: own reports."""
    db = _require_db()
    from core.reports import usage_store
    owner = None if _sees_all(user, db) else str(user.get("username") or "")
    rows = usage_store.most_read(db, days=days or None, limit=limit, owner=owner)
    return {"window_days": days or None, "scope": ("all" if owner is None else "own"),
            "reports": rows, "count": len(rows)}


@router.get("/api/report-usage/never-read")
def get_never_read(
        days: int = FastQuery(90, ge=0, description="Window in days; 0 = all time"),
        user: dict = Depends(require_capability("reports.view"))):
    """Reports with ZERO serves in the window — candidates for retirement.

    ``last_served_at_ever`` = null means never opened since readership
    recording began (2026-08-17); an old timestamp means it went quiet.
    """
    db = _require_db()
    from core.reports import usage_store
    owner = None if _sees_all(user, db) else str(user.get("username") or "")
    rows = usage_store.never_read(db, days=days or None, owner=owner)
    return {"window_days": days or None, "scope": ("all" if owner is None else "own"),
            "reports": rows, "count": len(rows)}


# ── Per-user activity ────────────────────────────────────────────────────────

@router.get("/api/report-usage/me")
def get_my_activity(
        days: int = FastQuery(30, ge=0),
        limit: int = FastQuery(100, ge=1, le=1000),
        user: dict = Depends(require_capability("reports.view"))):
    """The caller's own reading activity — always permitted."""
    db = _require_db()
    from core.reports import usage_store
    return usage_store.user_activity(db, str(user.get("username") or ""),
                                     days=days or None, limit=limit)


@router.get("/api/report-usage/users/{username}")
def get_user_activity(
        username: str,
        days: int = FastQuery(30, ge=0),
        limit: int = FastQuery(100, ge=1, le=1000),
        user: dict = Depends(require_capability("reports.view"))):
    """A user's reading activity.  Self or admin/support only (privacy
    posture: readership is per-user data)."""
    db = _require_db()
    caller = str(user.get("username") or "")
    if caller.lower() != str(username or "").lower() and not _sees_all(user, db):
        raise HTTPException(
            status_code=403,
            detail="You may only view your own activity")
    from core.reports import usage_store
    return usage_store.user_activity(db, username, days=days or None, limit=limit)


# ── Retention (admin) ────────────────────────────────────────────────────────

@router.post("/api/report-usage/cleanup")
def run_retention_cleanup(
        body: Optional[Dict[str, Any]] = None,
        _admin: dict = Depends(require_capability("reports.manage"))):
    """Force the readership retention sweep now (admin).

    Body (optional): ``{"days": N}`` overrides ``report_usage.retention_days``
    for this run only.  Config default: 180 days; 0 = keep forever (the
    scheduled/opportunistic sweep then never deletes).
    """
    db = _require_db()
    from core.reports import usage_store
    days = None
    if body and body.get("days") is not None:
        days = int(body["days"])
        if days <= 0:
            raise HTTPException(
                status_code=400,
                detail="days must be positive for a forced sweep "
                       "(0 = keep forever is a config choice, not a sweep)")
    deleted = usage_store.cleanup_old_serves(db, days=days)
    return {"deleted": deleted,
            "retention_days": (days if days is not None
                               else usage_store.retention_days())}
