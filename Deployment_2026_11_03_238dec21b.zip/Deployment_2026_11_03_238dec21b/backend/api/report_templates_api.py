"""Report templates -- routes (2026-11-02; the rules are core/reports/templates.py).

  GET  /api/report-templates                       the designs: name, what it shows, slots, a wireframe (reports.view)
  GET  /api/report-templates/{id}/suggest?dataset_id=  which columns fill each slot, from the column types (reports.view;
                                                   the dataset must be one the caller may view)
  POST /api/report-templates/{id}/build            {dataset_id, slots, name, theme?} -> the SAME payloads the editor saves
                                                   by hand: the report body and the parameter rows (reports.create).
                                                   Nothing is written here: the browser creates the report through
                                                   POST /api/business-reports and PUT .../parameters/batch, so a
                                                   template can never save what the product refuses.
"""
from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from api.deps import require_capability
from core.reports import templates as tp

router = APIRouter(prefix="/api/report-templates", tags=["report-templates"])

_db_manager = None


def set_report_templates_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


def _dataset_for(db, user: dict, dataset_id: int) -> dict:
    """The dataset with its columns, only when the caller may VIEW it (the report rule)."""
    from api.business_reports_api import _refuse_invisible_datasets
    _refuse_invisible_datasets(db, user, dataset_id)
    ds = db.get_dataset_full(int(dataset_id))
    if not ds:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_id} not found")
    return ds


def _grouped(db, dataset_id: int, columns) -> bool:
    from core.reports.canvas import dataset_rows_are_grouped
    try:
        metrics = db.list_calculated_metrics(int(dataset_id), active_only=False)
        has_metrics = bool(metrics) if isinstance(metrics, (list, tuple)) else False
    except Exception:                                    # noqa: BLE001
        has_metrics = True                               # unknown = the stricter (grouped) rule
    return dataset_rows_are_grouped(columns or [], has_metrics)


class BuildBody(BaseModel):
    dataset_id: int
    slots: Dict[str, Any]
    name: str
    theme: Optional[str] = None


@router.get("")
async def list_templates(user: dict = Depends(require_capability("reports.view"))):
    return {"templates": tp.catalogue()}


@router.get("/{template_id}/suggest")
async def suggest(template_id: str, dataset_id: int = Query(...), user: dict = Depends(require_capability("reports.view"))):
    t = tp.BY_ID.get(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail=f"There is no design named '{template_id}'.")
    db = _db()
    ds = await asyncio.to_thread(_dataset_for, db, user, dataset_id)
    cols = ds.get("columns") or []
    return {"template": template_id, "dataset_id": int(dataset_id), "slots": tp.suggest_slots(t, cols),
            "words": tp.slot_words(t, cols),
            "columns": [{"id": int(c["id"]), "label": str(c.get("friendly_name") or c.get("physical_name") or c["id"]),
                         "physical_name": c.get("physical_name"), "kind": tp.column_kind(c), "hidden": bool(c.get("is_hidden"))}
                        for c in cols if isinstance(c, dict) and c.get("id") is not None]}


@router.post("/{template_id}/build")
async def build(template_id: str, body: BuildBody, user: dict = Depends(require_capability("reports.create"))):
    db = _db()
    ds = await asyncio.to_thread(_dataset_for, db, user, body.dataset_id)
    grouped = await asyncio.to_thread(_grouped, db, body.dataset_id, ds.get("columns") or [])
    from core.business_calendar_tokens import default_calendar_name
    try:
        out = tp.build_report(template_id, ds, body.slots, body.name, body.theme, grouped=grouped, calendar=default_calendar_name())
    except tp.TemplateRefused as exc:
        raise HTTPException(status_code=422, detail={"error": "template_refused", "message": str(exc)})
    # the theme must be one the save would accept (the save checks it again)
    from core.reports.themes import theme_problems
    problems, _ = theme_problems({"name": out["theme"]}, db)
    if problems:
        raise HTTPException(status_code=422, detail={"error": "template_refused", "message": " ".join(problems)})
    return out
