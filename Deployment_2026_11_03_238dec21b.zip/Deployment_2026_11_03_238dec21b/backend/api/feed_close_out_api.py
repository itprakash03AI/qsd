"""Admin routes for the daily close-out digest (2026-09-27).

* ``GET /api/admin/feeds/close-out-digest/preview`` — the digest for a
  business date (default today UTC), per group or for every active group,
  WITHOUT sending it: subject, recipients, the five sections, the HTML,
  and whether the sender would send it (and if not, why).
* ``GET /api/admin/feeds/close-out-digest/status`` — the declared config
  and the "sent" marker (which groups got which date's digest).

Read-only admin surface (``require_admin_read``: admin or support).
The sender is the daemon; there is deliberately no "send now" button
here -- a digest mailed twice reads as two close-outs.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import require_admin_read, require_capability
from core.db_async import adb
from core.feed import close_out_digest

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/admin/feeds/close-out-digest",
                   tags=["feed-close-out"])

_db_manager: Any = None


def set_feed_close_out_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="close-out digest not wired to a database")
    return _db_manager


def _parse_date(raw: Optional[str]) -> date:
    if not raw:
        return datetime.now(timezone.utc).date()
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"business_date {raw!r} is not an ISO date (YYYY-MM-DD)")


@router.get("/preview")
async def preview_close_out_digest(
        business_date: Optional[str] = Query(default=None),
        group_id: Optional[int] = Query(default=None),
        user: dict = Depends(require_capability("feeds.monitor"))):
    bd = _parse_date(business_date)
    built = await adb(close_out_digest.build_digests, _db(), bd,
                      group_id=group_id)
    if group_id is not None and not built["groups"]:
        raise HTTPException(
            status_code=404,
            detail=f"No active feed group with id {group_id}")
    return built


@router.get("/status")
async def close_out_digest_status(user: dict = Depends(require_capability("feeds.monitor"))):
    return await adb(close_out_digest.status, _db())
