"""Report themes -- routes (2026-11-01; the rules are core/reports/themes.py).

  GET    /api/report-themes            the shipped themes + the library (anyone who may view reports)
  POST   /api/report-themes/check      a theme body -> its problems and its plain-words warnings (nothing saved)
  POST   /api/report-themes            a new library theme (admin: reports.manage)
  PUT    /api/report-themes/{id}       edit (admin)
  DELETE /api/report-themes/{id}       switch off (admin)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.deps import require_capability
from core.audit import audit_event
from core.reports import themes as th

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/report-themes", tags=["report-themes"])

_db_manager = None


def set_report_themes_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


class ThemeBody(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    theme: Optional[Dict[str, Any]] = None


class ThemeCheck(BaseModel):
    """``theme`` = a report's layout_config.theme (a name and overrides) or a library body."""
    theme: Optional[Dict[str, Any]] = None


def _refuse(problems, warnings=None):
    raise HTTPException(status_code=422, detail={
        "error": "theme_problems", "problems": problems, "warnings": warnings or [],
        "message": "The look cannot be saved: " + " ".join(problems)})


@router.get("")
async def list_themes(user: dict = Depends(require_capability("reports.view"))):
    db = _db()
    try:
        library = await asyncio.to_thread(db.list_report_themes)
    except Exception as exc:                                  # noqa: BLE001
        logger.warning("[report-themes] library unreadable: %s", exc)
        library, note = [], "The theme library could not be read; the shipped themes are listed."
    else:
        note = None
    return {"default": th.DEFAULT_THEME_NAME,
            "shipped": [{"name": n, "theme": t, "shipped": True} for n, t in th.SHIPPED.items()],
            "library": library, "choices": {"negative": th.NEGATIVE_STYLES, "code_position": th.CODE_POSITIONS,
                                            "density": th.DENSITIES, "scale": th.SCALES},
            **({"note": note} if note else {})}


@router.post("/check")
async def check_theme(body: ThemeCheck, user: dict = Depends(require_capability("reports.view"))):
    db = _db()
    problems, warnings = await asyncio.to_thread(th.theme_problems, body.theme, db)
    return {"ok": not problems, "problems": problems, "warnings": warnings,
            "resolved": th.theme_of({"theme": body.theme}, db) if not problems else None}


@router.post("")
async def create_theme(body: ThemeBody, user: dict = Depends(require_capability("reports.manage"))):
    db = _db()
    problems, warnings = await asyncio.to_thread(th.library_problems, body.name, body.theme, db)
    if problems:
        _refuse(problems, warnings)
    if await asyncio.to_thread(db.get_report_theme_by_name, str(body.name).strip()):
        raise HTTPException(status_code=409, detail=f'A theme named "{body.name}" already exists.')
    row = await asyncio.to_thread(db.create_report_theme, body.model_dump(), user.get("username", ""))
    audit_event("report_theme.created", user=user.get("username"), details={"id": row["id"], "name": row["name"]})
    return {**row, "warnings": warnings}


@router.put("/{theme_id}")
async def update_theme(theme_id: int, body: ThemeBody, user: dict = Depends(require_capability("reports.manage"))):
    db = _db()
    cur = await asyncio.to_thread(db.get_report_theme, theme_id)
    if not cur:
        raise HTTPException(status_code=404, detail="Theme not found")
    name = body.name if body.name is not None else cur["name"]
    theme = body.theme if body.theme is not None else cur["theme"]
    problems, warnings = await asyncio.to_thread(th.library_problems, name, theme, db)
    if problems:
        _refuse(problems, warnings)
    if name != cur["name"] and await asyncio.to_thread(db.get_report_theme_by_name, name):
        raise HTTPException(status_code=409, detail=f'A theme named "{name}" already exists.')
    row = await asyncio.to_thread(db.update_report_theme, theme_id, body.model_dump(exclude_none=True),
                                  user.get("username", ""))
    audit_event("report_theme.updated", user=user.get("username"), details={"id": theme_id, "name": name})
    return {**row, "warnings": warnings}


@router.delete("/{theme_id}")
async def delete_theme(theme_id: int, user: dict = Depends(require_capability("reports.manage"))):
    db = _db()
    ok = await asyncio.to_thread(db.delete_report_theme, theme_id, user.get("username", ""))
    if not ok:
        raise HTTPException(status_code=404, detail="Theme not found")
    audit_event("report_theme.switched_off", user=user.get("username"), details={"id": theme_id})
    return {"switched_off": True, "message": "The theme is switched off, not erased -- an admin can switch it "
                                              "back on under Admin -> Switched off. Reports that named it use the default look."}
