"""
Report Catalog API (Phase 23A + Phase 58 unified catalog)

Endpoints:
  GET    /api/report-catalog            — catalog (finance reports; FB-60 removed the parametric half)
  GET    /api/report-folders            — list folders (optionally by parent)
  POST   /api/report-folders            — create folder
  PUT    /api/report-folders/{id}       — rename / recolor
  DELETE /api/report-folders/{id}       — delete (re-parents children)

  POST   /api/reports/{id}/folder       — assign report to folder (or None to un-assign)
  GET    /api/report-tags               — list all tags
  POST   /api/report-tags               — create tag
  DELETE /api/report-tags/{id}          — delete tag + remove assignments
  POST   /api/reports/{id}/tags         — replace tag assignments for a report
  GET    /api/reports/{id}/tags         — get tags for a report

  POST   /api/reports/{id}/favorite     — toggle user favorite
  GET    /api/reports/favorites         — user's favorited report ids
  POST   /api/reports/{id}/view         — record a report view (recently viewed)
  GET    /api/reports/recent            — recently viewed report ids
  GET    /api/reports/search            — search (finance reports)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as QParam
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from api.strict_request import StrictRequestModel  # AQD-03: unknown keys are refused, not ignored

from api.deps import get_current_user
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

router = APIRouter()


# BF-NONBLOCK-AUDIT-5: catalog page calls /api/report-catalog which
# fires 6+ DB queries serially.  All routes now offload to threads.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

_db_manager = None
_auth_cfg   = None


def set_catalog_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Pydantic models ───────────────────────────────────────────────────────────

class FolderCreate(StrictRequestModel):
    name:        str
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        str = "folder"
    color:       str = "#1976d2"


class FolderUpdate(StrictRequestModel):
    name:        Optional[str] = None
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        Optional[str] = None
    color:       Optional[str] = None


class TagCreate(StrictRequestModel):
    name:  str
    color: str = "#666666"


class TagAssignRequest(StrictRequestModel):
    tag_ids: List[int]


class FolderAssignRequest(StrictRequestModel):
    folder_id: Optional[int] = None   # None = remove from folder
    report_type: str = "business"      # FB-60: 'parametric' rows are legacy data only


# ── Main catalog endpoint ────────────────────────────────────────────────────

@router.get("/api/report-catalog")
async def get_report_catalog(user: dict = Depends(require_capability("reports.view"))):
    """Return unified catalog: folder tree + tags + favorites + recent for both report types."""
    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    # BF-NONBLOCK-AUDIT-5: this endpoint fires 6 sync DB scans
    # serially.  Wrap the whole body in a single to_thread so the
    # event loop stays free for /health + WS during the ~200-1000ms it
    # takes on cold caches.
    def _inner() -> Dict[str, Any]:
        folders_all = db.list_folders(all_folders=True)
        tags_all    = db.list_tags()

        favorites   = db.get_user_favorites(username, report_type=None)
        recent_ids  = db.get_recently_viewed(username, limit=10, report_type=None)

        try:
            if role in ADMIN_TIER_ROLES:
                business = db.list_business_reports()
            else:
                # 2026-08-09 audit fix (finding 7): this endpoint used its
                # own own+published copy of the visibility rule, which
                # skipped the 2026-08-05 role_whitelist gate — published
                # but role-restricted reports were listed (with full
                # definitions) to everyone.  Now the SAME chokepoint as
                # GET /api/business-reports decides visibility (whitelist
                # gate + Phase-157 grants included).
                from core.reports.authorization import (
                    list_visible_business_reports)
                business = list_visible_business_reports(db, user)
        except Exception:
            business = []

        for r in business:
            r["report_type"] = "business"

        def _build_tree(parent_id):
            children = [f for f in folders_all if f["parent_id"] == parent_id]
            for c in children:
                c["children"] = _build_tree(c["id"])
            return children

        return {
            "folders":   _build_tree(None),
            "tags":      tags_all,
            "favorites": favorites,
            "recent":    recent_ids,
            # FB-60 (2026-09-26): no ``parametric_reports`` key -- an
            # always-empty list would read as "there are none" when the
            # truth is "there is no such surface".
            "business_reports":   business,
        }

    return await asyncio.to_thread(_inner)


# ── Folder endpoints ──────────────────────────────────────────────────────────

@router.get("/api/report-folders")
async def list_folders(parent_id: Optional[int] = None,
                       user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    return {"folders": await _adb(db.list_folders, parent_id=parent_id)}


@router.post("/api/report-folders", status_code=201)
async def create_folder(body: FolderCreate, user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    folder = await _adb(db.create_folder,
        name=body.name, description=body.description,
        parent_id=body.parent_id, created_by=username,
        icon=body.icon, color=body.color,
    )
    return folder


@router.put("/api/report-folders/{folder_id}")
async def update_folder(folder_id: int, body: FolderUpdate,
                        user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(db.update_folder, folder_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Folder not found")
    return result


@router.delete("/api/report-folders/{folder_id}")
async def delete_folder(folder_id: int, user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    ok = await _adb(db.delete_folder, folder_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Folder not found")
    return {"deleted": True, "folder_id": folder_id}


@router.post("/api/reports/{report_id}/folder")
async def assign_report_folder(report_id: int, body: FolderAssignRequest,
                               user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    await _adb(db.set_report_folder, report_id, body.folder_id, report_type=body.report_type)
    return {"report_id": report_id, "folder_id": body.folder_id,
            "report_type": body.report_type}


# ── Tag endpoints ─────────────────────────────────────────────────────────────

@router.get("/api/report-tags")
async def list_tags(user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    return {"tags": await _adb(db.list_tags)}


@router.post("/api/report-tags", status_code=201)
async def create_tag(body: TagCreate, user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    tag = await _adb(db.create_tag, name=body.name, color=body.color,
                     created_by=username)
    return tag


@router.delete("/api/report-tags/{tag_id}")
async def delete_tag(tag_id: int, user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    ok = await _adb(db.delete_tag, tag_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Tag not found")
    return {"deleted": True, "tag_id": tag_id}


@router.post("/api/reports/{report_id}/tags")
async def assign_tags(report_id: int, body: TagAssignRequest,
                      report_type: str = QParam(default="business"),
                      user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    await _adb(db.assign_report_tags, report_id, body.tag_ids, report_type=report_type)
    return {"report_id": report_id, "tag_ids": body.tag_ids,
            "report_type": report_type}


@router.get("/api/reports/{report_id}/tags")
async def get_report_tags(report_id: int,
                          report_type: str = QParam(default="business"),
                          user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    return {"tags": await _adb(db.get_report_tags, report_id, report_type=report_type)}


# ── Favorites & Recently Viewed ───────────────────────────────────────────────

@router.post("/api/reports/{report_id}/favorite")
async def toggle_favorite(report_id: int,
                          report_type: str = QParam(default="business"),
                          user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    added = await _adb(db.toggle_report_favorite, report_id, username, report_type=report_type)
    return {"report_id": report_id, "favorited": added, "report_type": report_type}


@router.get("/api/reports/favorites")
async def get_favorites(report_type: Optional[str] = QParam(default=None),
                        user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    return {"favorites": await _adb(db.get_user_favorites, username, report_type=report_type)}


@router.post("/api/reports/{report_id}/view")
async def record_view(report_id: int,
                      report_type: str = QParam(default="business"),
                      user: dict = Depends(require_capability("reports.edit"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    await _adb(db.record_report_view, report_id, username, report_type=report_type)
    return {"recorded": True}


@router.get("/api/reports/recent")
async def get_recent(report_type: Optional[str] = QParam(default=None),
                     limit: int = QParam(default=10, ge=1, le=50),
                     user: dict = Depends(require_capability("reports.view"))):
    db = _require_db()
    username = (user or {}).get("username", "")
    return {"recent": await _adb(db.get_recently_viewed, username, limit, report_type=report_type)}


# ── Search (unified) ────────────────────────────────────────────────────────

@router.get("/api/reports/search")
async def search_reports(q: str = QParam(min_length=1),
                         limit: int = QParam(default=30, ge=1, le=100),
                         user: dict = Depends(require_capability("reports.view"))):
    """Search finance reports (FB-60 removed the parametric half).

    2026-08-09 audit fix (finding 6): business-report results are now
    filtered to the caller's visibility (the DB comment claimed "access
    control handled at API layer" — no layer applied any).  Any
    authenticated user's search returned other users' UNPUBLISHED report
    definitions including the full ``raw_sql_override`` SQL text.
    """
    db = _require_db()
    results = await _adb(db.search_reports_unified, q, limit=limit, viewer=user)
    return {"results": results, "count": len(results)}
