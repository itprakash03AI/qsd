"""
Data Grid API — DuckDB-Powered
Key changes:
  1. DuckDB replaces pandas for all data reads — handles 5-10 GB files without loading into RAM
  2. Advanced AND/OR filter via adv_filters parameter (JSON: {conjunction, conditions})
  3. Legacy per-column filters still supported for backwards compat
  4. All chart-data endpoints use DuckDB aggregation
  5. /export and /stats retain pandas (they process full dataset intentionally)
"""

from fastapi import APIRouter, HTTPException, Query, BackgroundTasks, Depends
from fastapi.responses import FileResponse, StreamingResponse
from api.deps import (require_capability, get_current_user, require_execution_read_access,
                      is_token_principal, assert_execution_visible_to_token)
try:
    from fastapi.responses import ORJSONResponse as _JSONResp
    _USE_ORJSON = True
except ImportError:
    from fastapi.responses import JSONResponse as _JSONResp
    _USE_ORJSON = False
import pandas as pd
from pathlib import Path
import json
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:  # annotation-only — duckdb stays a lazy in-function import
    import duckdb
import io
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor as _TPE
from datetime import datetime, timedelta, timezone
from core.s3_utilities import get_s3_access_mode

try:
    import duckdb as _duckdb
    _DUCKDB_AVAILABLE = True
except ImportError:
    _DUCKDB_AVAILABLE = False

router = APIRouter()

# Dedicated thread pool for blocking DuckDB / pandas calls so they never
# stall the asyncio event loop.  DuckDB in-memory connections are per-call
# (_duckdb_con() creates a new one each time), so this is thread-safe.
_duckdb_executor = _TPE(max_workers=8, thread_name_prefix="duckdb")  # legacy, phasing out


def _get_executor():
    """Return pool executor if available, else fall back to legacy."""
    try:
        from core.worker_pool import get_pool
        return get_pool().executor
    except RuntimeError:
        return _duckdb_executor

# ── Schema + row-count cache ─────────────────────────────────────────────────
# Keyed by resolved file path string.
# Avoids running `SELECT COUNT(*)` and schema-detection queries on every page.
# Entries are invalidated when the file's mtime changes or after 2 hours.
import sys as _sys  # noqa: E402
import time as _time  # noqa: E402
import threading as _threading  # noqa: E402
import hashlib as _hashlib  # noqa: E402
import logging as _logging  # noqa: E402
from queue import Queue as _Queue, Empty as _QueueEmpty  # noqa: E402
import math as _math  # noqa: E402
from decimal import Decimal as _Decimal  # noqa: E402
from core.download_retention import (
    download_expires_at as _download_expires_at, download_refusal)

_logger = _logging.getLogger(__name__)

_meta_cache: dict = {}          # path_str → {columns, total_rows, mtime, ts}
_meta_cache_lock = _threading.Lock()
_META_MAX_ENTRIES = 2000        # prevent unbounded growth


def _meta_ttl() -> int:
    """Metadata cache TTL from config (Phase 102-H, default 7200s)."""
    try:
        from core.config import limits as _lim
        return int(_lim.metadata_cache_ttl)
    except Exception:
        return 7200

# ── Snappy DataFrame cache ─────────────────────────────────────────
# When a parquet file uses snappy compression we fall back to pandas
# (DuckDB can segfault on some platforms).  Reading the full file via
# pd.read_parquet on every page request is very slow for large files.
# Cache the DataFrame in memory (up to 5 files, 5-min TTL).
_snappy_df_cache: dict = {}     # path_str → {"df": DataFrame, "mtime": float, "ts": float}
_snappy_df_lock = _threading.Lock()
_SNAPPY_DF_TTL = 300            # 5 minutes
_SNAPPY_DF_MAX = 5              # max cached DataFrames (memory guard)

# 2026-07-31 memory bound: pd.read_parquet(whole file) + the RAM cache above
# is only safe for SMALL files.  Above this UNCOMPRESSED-size estimate (sum of
# row-group total_byte_size from the parquet footer — O(1), no row data read)
# the snappy fallback must not materialise the file; it pages via a bounded
# Arrow batch reader instead (see _snappy_bounded_paginate).  128 MB keeps the
# worst case of the cache (5 entries) near ~640 MB — the pre-existing ceiling
# this cache was sized for — while 10-20M-row results route to bounded paging.
_SNAPPY_PANDAS_MAX_BYTES = 128 * 1024 * 1024


def _get_cached_snappy_df(path: Path):
    """Return cached DataFrame for snappy parquet, or None."""
    key = str(path)
    with _snappy_df_lock:
        entry = _snappy_df_cache.get(key)
        if not entry:
            return None
        try:
            if path.stat().st_mtime != entry["mtime"]:
                del _snappy_df_cache[key]
                return None
        except OSError:
            del _snappy_df_cache[key]
            return None
        if _time.monotonic() - entry["ts"] > _SNAPPY_DF_TTL:
            del _snappy_df_cache[key]
            return None
        return entry["df"]


def _set_cached_snappy_df(path: Path, df):
    """Cache a DataFrame for snappy parquet file."""
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return
    with _snappy_df_lock:
        if len(_snappy_df_cache) >= _SNAPPY_DF_MAX:
            oldest = min(_snappy_df_cache, key=lambda k: _snappy_df_cache[k]["ts"])
            del _snappy_df_cache[oldest]
        _snappy_df_cache[str(path)] = {"df": df, "mtime": mtime, "ts": _time.monotonic()}


def _get_cached_meta(path: Path) -> dict | None:
    key = str(path)
    with _meta_cache_lock:
        entry = _meta_cache.get(key)
        if not entry:
            return None
        try:
            if path.stat().st_mtime != entry["mtime"]:
                del _meta_cache[key]
                return None
        except OSError:
            del _meta_cache[key]
            return None
        if _time.monotonic() - entry["ts"] > _meta_ttl():
            del _meta_cache[key]
            return None
        return entry


def _set_cached_meta(path: Path, columns: list, total_rows: int) -> None:
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return
    with _meta_cache_lock:
        # Evict expired + enforce max size
        if len(_meta_cache) >= _META_MAX_ENTRIES:
            now = _time.monotonic()
            expired = [k for k, v in _meta_cache.items() if now - v["ts"] > _meta_ttl()]
            for k in expired:
                del _meta_cache[k]
            if len(_meta_cache) >= _META_MAX_ENTRIES:
                oldest = min(_meta_cache, key=lambda k: _meta_cache[k]["ts"])
                del _meta_cache[oldest]
        _meta_cache[str(path)] = {
            "columns":    columns,
            "total_rows": total_rows,
            "mtime":      mtime,
            "ts":         _time.monotonic(),
        }


def _evict_cached_meta(path: Path) -> None:
    """Call when a file is deleted so the cache doesn't serve stale entries."""
    with _meta_cache_lock:
        _meta_cache.pop(str(path), None)
        # Also evict any filter-count entries for this file
        prefix = str(path) + "|"
        stale = [k for k in _meta_cache if k.startswith(prefix)]
        for k in stale:
            del _meta_cache[k]


def _get_filtered_count_cache(path: Path, filter_key: str) -> int | None:
    key = str(path) + "|" + filter_key
    with _meta_cache_lock:
        entry = _meta_cache.get(key)
        if not entry:
            return None
        if _time.monotonic() - entry["ts"] > _meta_ttl():
            del _meta_cache[key]
            return None
        return entry["count"]


def _set_filtered_count_cache(path: Path, filter_key: str, count: int) -> None:
    key = str(path) + "|" + filter_key
    with _meta_cache_lock:
        _meta_cache[key] = {"count": count, "ts": _time.monotonic()}


# ── S3 DuckDB Connection Pool ─────────────────────────────────────────────────
# Keeps warm DuckDB connections per connection_id so parquet footer reads and
# HTTP handshakes are not repeated on every query.  Cold-start can be 3-5x
# slower than a warm hit; pooling eliminates that gap for repeat queries.
#
# Thread safety: Queue.get/put are atomic; _s3_pool_lock guards the dict.
# DuckDB connections are NOT shared across threads — only one thread owns a
# connection at a time (checked out from queue → used → returned).

_s3_pool: dict = {}          # conn_id (int) → {"queue": Queue, "cred_hash": str}
_s3_pool_lock = _threading.Lock()
_S3_POOL_MAX = 3             # max idle connections per connection_id (was 6)
_S3_POOL_TTL = 300           # seconds idle before TTL eviction (was 600)


def _s3_cred_hash(conn_config: dict) -> str:
    """Fingerprint of S3 credentials — pool is invalidated when this changes."""
    keys = (
        "aws_access_key_id", "aws_secret_access_key", "aws_session_token",
        "region_name", "region", "endpoint_url", "endpoint",
        "auth_mode", "aws_profile", "role_arn", "ssl_verify",
    )
    sig = {k: conn_config.get(k, "") for k in keys}
    # usedforsecurity=False — FIPS-strict OS images (UBI8 FIPS, RHEL FIPS)
    # disable MD5 at the OpenSSL layer; without this flag the call raises
    # ValueError: [digital envelope routines: EVP_DigestInit_ex] disabled for FIPS.
    # MD5 here is a cache-key fingerprint, not a security hash.
    # 2026-09-13 security-hotspot triage: the `except TypeError` <3.9
    # fallback that used to sit here was DEAD (usedforsecurity has existed
    # since 3.9; this repo runs 3.13/3.14) and it was the only unguarded
    # md5() in this file.  Worse, had it ever run it would have called
    # plain md5() on exactly the FIPS-strict image the flag exists for --
    # a fallback that defeats its own guard.  Removed, not suppressed.
    return _hashlib.md5(
        json.dumps(sig, sort_keys=True).encode(), usedforsecurity=False,
    ).hexdigest()


# BF-484 (2026-05-27) — auth modes whose resolved AWS creds rotate at runtime
# (STS session tokens expire ~1h, portal creds depend on system_account state).
# Pooled DuckDB connections SET creds at creation time and keep them until the
# pool evicts the connection (TTL=300s).  When a query lands on a pooled
# connection whose token has expired, CREATE VIEW fails with HTTP 403 and
# register_s3_views silently returns empty rows.  Fix: re-resolve + re-apply
# AWS keys on EVERY pool checkout for these auth modes.
_DYNAMIC_AUTH_MODES = ("portal", "assume_role", "iam_role")


def _resolve_aws_keys_for_duckdb(
    conn_config: dict, connection_id: Optional[int]
) -> tuple:
    """Resolve (access_key, secret_key, session_token) for the configured
    auth_mode.  Pure resolution — no DuckDB SET statements.  Used both at
    fresh-connection creation and on every pool checkout (BF-484) so the
    pooled connection always uses live credentials.

    Returns ``("", "", "")`` when resolution fails — the caller is expected
    to log/stamp via the BF-476 ``_qs_duckdb_no_creds_reason`` mechanism.

    2026-09-12 — ONE resolver.  This and the fresh-connection path inside
    ``_duckdb_con_with_s3`` were two byte-identical copies of the same
    portal / static-keys / boto3 chain.  Two engines is fine; two answers
    to the same question is not, so both now go through
    :func:`_resolve_s3_creds_for_con`.  This wrapper drops the resolved
    ``auth_mode`` on purpose: its callers apply keys, they do not stamp.
    """
    from core.s3_storage import resolve_s3_region as _qs_region
    region = _qs_region(conn_config)
    key, secret, token, _auth_mode = _resolve_s3_creds_for_con(
        conn_config, connection_id, region)
    return key, secret, token


def _set_s3_session_token(con, token: str, _esc) -> None:
    """Set, or actively RESET, the connection's S3 session token.

    IMPORTANT: always RESET the session token even when token=="" — a
    previous (now-expired) STS token must not stick around on a
    connection that's been re-credentialed with static keys.
    """
    if token:
        con.execute(f"SET s3_session_token='{_esc(token)}';")
        return
    try:
        con.execute("RESET s3_session_token;")
    except Exception:
        # DuckDB versions that don't support RESET — overwrite with empty.
        con.execute("SET s3_session_token='';")


def _apply_s3_keys_to_con(con, key: str, secret: str, token: str) -> None:
    """Run SET s3_* on the DuckDB connection.  Used both at creation and on
    every pool checkout (BF-484).  Empty strings clear the corresponding
    setting so an expired token doesn't linger on the connection."""
    _esc = lambda v: v.replace("'", "''")
    try:
        if key:
            con.execute(f"SET s3_access_key_id='{_esc(key)}';")
        if secret:
            con.execute(f"SET s3_secret_access_key='{_esc(secret)}';")
        _set_s3_session_token(con, token, _esc)
    except Exception as _set_exc:
        _logger.warning("DuckDB: failed to apply S3 keys: %s", _set_exc, exc_info=True)


def _pooled_con_was_signing_reset(con) -> bool:
    """Decide whether register_s3_views had to RESET this connection's S3
    settings, which makes it unfit for the pool.

    2026-06-23 round-7 -- check the side-channel registry instead
    of the getattr.  setattr on raw DuckDBPyConnection silently fails
    (no __dict__), so the prior getattr-based check always returned
    False -- pool would keep RESET connections, breaking the next
    query on the same pool.  ``is_connection_reset`` consults both
    the WeakSet registry AND the legacy attribute (back-compat).
    """
    try:
        from core.duckdb_s3_plan import is_connection_reset
        return is_connection_reset(con)
    except Exception:
        return False


def _return_to_s3_pool(conn_id: int, con, cred_hash: str) -> None:
    """Return a warm connection to the pool (or close it if pool is full/stale).

    2026-06-23 -- additionally close (not pool) any connection that
    ``register_s3_views`` flagged with
    ``_qs_s3_signing_reset_for_presigned_views``.  Such connections had
    their ``s3_endpoint`` + credentials RESET to prevent httpfs from
    double-signing presigned URLs embedded in view DDLs.  Pooling them
    would mean a future query checking out the same connection finds
    a half-configured S3 client and either fails on credential-less
    ``s3://`` URIs or, worse, gets confusing 403s.  Recycling is
    cheap; risk of stale state isn't.
    """
    if _pooled_con_was_signing_reset(con):
        _close_duckdb_quietly(con)
        _logger.info(
            "S3 pool: dropped connection %s on release because "
            "register_s3_views had to RESET its S3 settings to avoid "
            "double-signing presigned URLs in views.",
            conn_id,
        )
        return
    with _s3_pool_lock:
        entry = _s3_pool.get(conn_id)
        if entry is None:
            entry = {"queue": _Queue(maxsize=_S3_POOL_MAX), "cred_hash": cred_hash}
            _s3_pool[conn_id] = entry
        if entry["cred_hash"] == cred_hash and not entry["queue"].full():
            entry["queue"].put_nowait((con, _time.monotonic()))
        else:
            _close_duckdb_quietly(con)


def _drain_and_close_pool_entry(entry) -> None:
    """Close every connection queued in one pool entry."""
    while not entry["queue"].empty():
        try:
            con, _ = entry["queue"].get_nowait()
            con.close()
        except Exception as exc:
            _logger.warning("data_grid_api error: %s", exc, exc_info=True)


def evict_s3_pool(conn_id: Optional[int] = None) -> None:
    """Close and evict pooled connections for one connection_id or all."""
    with _s3_pool_lock:
        targets = [conn_id] if conn_id is not None else list(_s3_pool.keys())
        for cid in targets:
            entry = _s3_pool.pop(cid, None)
            if entry:
                _drain_and_close_pool_entry(entry)


class _PooledS3Con:
    """Wraps a DuckDB connection; .close() returns it to the pool.

    2026-10-06 -- a checkout's ``threads`` is a PER-QUERY decision
    (``core.s3_http_transport.apply_remote_io_for_views`` raises it to the
    query's remote file count), so the wrapper remembers the value the
    connection was handed out with and puts it back on release.  A
    connection that cannot be put back is closed, not pooled: the next
    query must not inherit another query's I/O answer.
    """

    __slots__ = ("_con", "_conn_id", "_cred_hash", "_returned",
                 "_base_threads")

    def __init__(self, con, conn_id: int, cred_hash: str) -> None:
        object.__setattr__(self, "_con",       con)
        object.__setattr__(self, "_conn_id",   conn_id)
        object.__setattr__(self, "_cred_hash", cred_hash)
        object.__setattr__(self, "_returned",  False)
        try:
            from core.s3_http_transport import current_threads
            _base = current_threads(con)
        except Exception:
            _base = None
        object.__setattr__(self, "_base_threads", _base)

    def close(self) -> None:
        if object.__getattribute__(self, "_returned"):
            return
        object.__setattr__(self, "_returned", True)
        _con = object.__getattribute__(self, "_con")
        try:
            from core.s3_http_transport import restore_threads
            _restored = restore_threads(
                _con, object.__getattribute__(self, "_base_threads"))
        except Exception:
            _restored = False
        if not _restored:
            _logger.info(
                "S3 pool: dropped connection %s on release -- its per-query "
                "threads could not be put back to %s",
                object.__getattribute__(self, "_conn_id"),
                object.__getattribute__(self, "_base_threads"))
            _close_duckdb_quietly(_con)
            return
        _return_to_s3_pool(
            object.__getattribute__(self, "_conn_id"),
            object.__getattribute__(self, "_con"),
            object.__getattribute__(self, "_cred_hash"),
        )

    def __getattr__(self, name: str):
        return getattr(object.__getattribute__(self, "_con"), name)

    def __setattr__(self, name: str, value) -> None:
        if name in _PooledS3Con.__slots__:
            object.__setattr__(self, name, value)
        else:
            setattr(object.__getattribute__(self, "_con"), name, value)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def _serialize_df(df: pd.DataFrame) -> pd.DataFrame:
    """Convert non-JSON-serializable pandas/numpy types to plain Python types.

    Handles: Timestamp → ISO string, NaT → None, numpy scalars → int/float.
    Called before to_dict('records') so orjson / JSONResponse never sees
    pandas internals.
    Uses vectorized operations instead of row-by-row .apply() for performance.
    """
    df = df.copy()
    for col in df.columns:
        dtype = df[col].dtype
        if pd.api.types.is_datetime64_any_dtype(dtype) or (hasattr(dtype, "tz") and dtype.tz is not None):
            # Vectorized: format non-NaT as ISO strings, NaT → None
            mask = df[col].notna()
            df[col] = df[col].astype(object)
            if mask.any():
                df.loc[mask, col] = pd.to_datetime(df.loc[mask, col]).dt.strftime("%Y-%m-%dT%H:%M:%S")
            df.loc[~mask, col] = None
        elif pd.api.types.is_integer_dtype(dtype):
            df[col] = df[col].where(df[col].notna(), None).astype(object)
        elif pd.api.types.is_float_dtype(dtype):
            mask = df[col].isna()
            df[col] = df[col].astype(object)
            df.loc[mask, col] = None
    return df


async def _aduckdb(fn):
    """Run a blocking DuckDB or pandas function off the event loop."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_get_executor(), fn)


# Injected from main.py at startup
_db_manager    = None
_ws_manager    = None
_main_loop     = None
_downloads_dir: Optional[Path] = None   # config-driven, set via set_paths()
_parquet_dir:   Optional[Path] = None   # config-driven, set via set_paths()

# ── Eager own-instance init ─────────────────────────────────────────
# Uses core.config so the BYOS/network-drive paths are respected even
# before main.py calls set_db_manager() / set_paths().
try:
    from core.config import paths as _cfg_paths, database as _cfg_db
    from core.database import DatabaseManager as _OwnDBManager
    _cfg_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _cfg_paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _db_manager = _OwnDBManager(db_url=_cfg_db.db_url)
    _logger.info(
        "data_grid_api: eager init OK — db=%s  downloads=%s",
        _cfg_db.db_url, _cfg_paths.downloads_dir)
except Exception as _init_exc:
    _logger.warning(
        "data_grid_api: eager init failed (%s) — will rely on main.py injection", _init_exc, exc_info=True)
    _db_manager = None

# ── Eager DuckDB extension pre-init (background, subprocess-isolated) ─────
# DuckDB's INSTALL/LOAD can crash at C level (access violation on Windows).
# Running in a subprocess ensures a crash doesn't kill the backend.
# Running in a background thread ensures startup isn't blocked.
def _record_preinit_extension_verdicts(out: str) -> None:
    """Read the pre-init subprocess's verdicts into the process-wide caches.

    ``iceberg:no`` is a DIFFERENT answer from no line at all: the first
    says the subprocess asked and the extension is unavailable (optional,
    so only logged), the second says the subprocess never got that far.
    """
    global _DUCKDB_HTTPFS_OK, _DUCKDB_ICEBERG_OK
    if "httpfs:ok" in out:
        _DUCKDB_HTTPFS_OK = True
        _logger.info("DuckDB httpfs extension pre-installed OK")
    if "iceberg:ok" in out:
        _DUCKDB_ICEBERG_OK = True
        _logger.info("DuckDB iceberg extension pre-installed OK")
    elif "iceberg:no" in out:
        _logger.info("DuckDB iceberg extension not available (optional)")


def _preinit_duckdb_extensions():
    """Pre-install DuckDB extensions in a subprocess (background thread)."""
    import subprocess as _sp
    _script = "\n".join([
        "import os, duckdb",
        "c = duckdb.connect(':memory:')",
        # Disable auto-install to avoid ~120s timeout in air-gapped containers
        "try:",
        "    c.execute('SET autoinstall_known_extensions=false')",
        "except Exception:",
        "    pass",
        # Set extension_directory to a writable path (container HOME may be / read-only)
        "_ext_dir = os.environ.get('DUCKDB_EXTENSION_DIR', '').strip()",
        "if not _ext_dir:",
        "    _ext_dir = os.environ.get('DUCKDB_TEMP_DIR', '').strip()",
        "    if _ext_dir:",
        "        _ext_dir = os.path.join(os.path.dirname(os.path.dirname(_ext_dir.rstrip('/\\\\'))), 'duckdb_extensions')",
        "if not _ext_dir and os.name != 'nt':",
        "    _ext_dir = '/usr/local/querystudioapi/nfs/data/duckdb_extensions'",
        "try:",
        "    os.makedirs(_ext_dir, exist_ok=True)",
        "    c.execute(f\"SET extension_directory='{_ext_dir}'\")",
        "except Exception:",
        "    pass",
        "try:",
        "    c.execute(\"LOAD 'httpfs'\")",
        "except Exception:",
        "    c.execute(\"INSTALL 'httpfs'\")",
        "    c.execute(\"LOAD 'httpfs'\")",
        "print('httpfs:ok')",
        "try:",
        "    try:",
        "        c.execute(\"LOAD 'iceberg'\")",
        "    except Exception:",
        "        c.execute(\"INSTALL 'iceberg'\")",
        "        c.execute(\"LOAD 'iceberg'\")",
        "    print('iceberg:ok')",
        "except Exception:",
        "    print('iceberg:no')",
        "c.close()",
    ])
    try:
        _result = _sp.run(
            [_sys.executable, "-c", _script],
            capture_output=True, text=True, timeout=30,
            encoding="utf-8", errors="replace",
        )
        if _result.returncode == 0:
            _record_preinit_extension_verdicts(_result.stdout)
        else:
            _logger.warning(
                "DuckDB extension pre-init subprocess exited %d — extensions will install on first use",
                _result.returncode)
    except Exception as _exc:
        _logger.warning(
            "DuckDB extension pre-init skipped: %s — will install on first use", _exc, exc_info=True)

# Run in background thread so startup isn't blocked or crashed
_threading.Thread(target=_preinit_duckdb_extensions, daemon=True, name="duckdb-preinit").start()


def set_db_manager(db):
    global _db_manager
    _db_manager = db


def set_paths(downloads_dir: Path, parquet_dir: Path) -> None:
    """Called by main.py at startup to inject config-driven paths."""
    global _downloads_dir, _parquet_dir
    _downloads_dir = downloads_dir
    _parquet_dir   = parquet_dir


def _get_downloads_dir() -> Path:
    if _downloads_dir is not None:
        return _downloads_dir
    try:
        from core.config import paths as _p
        return _p.downloads_dir
    except Exception:
        return Path(__file__).resolve().parent.parent / "data" / "downloads"


def _get_parquet_dir() -> Path:
    if _parquet_dir is not None:
        return _parquet_dir
    try:
        from core.config import paths as _p
        return _p.parquet_dir
    except Exception:
        return Path(__file__).resolve().parent.parent / "data" / "parquet"


def set_ws_manager(ws_mgr, loop):
    global _ws_manager, _main_loop
    _ws_manager = ws_mgr
    _main_loop  = loop


# Phase 131 deep-dive #13 (round 3): which executed_by prefixes are
# "service" identities that any authenticated user is allowed to read
# from.  PVs serve API consumers; embed/shared tokens validate at the
# token layer; system/scheduled run pre-published reports.
_SERVICE_EXECUTOR_PREFIXES = (
    "published_view:", "embed:", "shared:", "system", "scheduled",
)


def _execution_record_or_none(execution_id: str) -> Optional[dict]:
    """Read the execution record; None when the DB is not ready or errors.

    None is deliberately indistinguishable here from "no such execution":
    the caller's existing 404 path gives a clearer error than a 403 about
    a record nobody can see.
    """
    try:
        db = _get_db()
        if db is None:
            return None  # DB not ready — caller will handle the 503/404
        return db.get_execution(execution_id)
    except Exception:
        return None


def _has_single_flight_grant(execution_id: str, username: str) -> bool:
    """Decide whether a verified single-flight FOLLOWER may read the
    leader's results.

    Industrialization Phase 5 — single-flight shared-result grant.  A
    follower attached to a SHARE-VERIFIED leader may read the leader's
    execution results: verified means the executor PROVED the rls_key
    (identical rendered RLS predicates ⇒ identical result bytes for
    every participant) held through enforcement.  Flag OFF → this block
    is one flag read on the would-403 path only; any error → deny
    (fail closed — the 403 stands).
    """
    try:
        from core.industrialization import is_enabled as _ind_enabled
        if not _ind_enabled("single_flight"):
            return False
        from core.jobqueue import get_job_queue as _get_jq
        return bool(_get_jq().has_shared_result_grant(execution_id, username))
    except Exception:
        return False  # fail CLOSED — fall through to the 403


#: Pivot functions whose answer changes meaning over a PRE-AGGREGATED grid.
#: SUM of sums is still the sum; COUNT of groups is not the count of rows.
#: Measured on this stack 2026-09-17 against a report grouped by five
#: dimensions: COUNT 1,439 vs 257,170 rows (179x), AVG 30,612,699 vs 171,294
#: (179x), MAX 142,173,344 vs 508,048 (280x) — each a plausible-looking
#: currency figure, none of them the answer to the question asked.
_NON_ADDITIVE_PIVOT_FUNCS = frozenset({"avg", "count", "count_distinct",
                                       "min", "max", "median", "stddev"})


def _execution_grain(execution_id: str) -> dict:
    """Is this execution's result file one row per SOURCE ROW, or per GROUP?

    Returns ``{"pre_aggregated": True|False|None, "reason": str}``.  ``None``
    means UNDETERMINED and is never treated as safe — "could not tell" and
    "is fine" lead to opposite decisions, which is the rule this codebase
    keeps relearning.

    The signal is the execution's own stored SQL.  A GROUP BY (or an
    aggregate in the projection with no GROUP BY, i.e. a single-row rollup)
    means every measure column in the file is ALREADY aggregated, so a pivot
    over it aggregates groups, not rows.
    """
    import re as _re_grain

    # TWO record stores, and only one of them carries the SQL.
    # ``get_execution`` serves ad-hoc/grid executions; a dataset or business
    # report execution lives in ``federation_executions`` and
    # ``get_execution`` returns {} for it.  Checking only the first made this
    # guard silently inert on exactly the executions that ARE pre-aggregated
    # -- caught live, where a GROUP BY report pivoted with avg/count/max and
    # was not refused.
    rec = _execution_record_or_none(execution_id) or {}
    sql = str(rec.get("sql_generated") or rec.get("sql") or "")
    if not sql.strip():
        try:
            db = _get_db()
            fed = db.get_federation_execution(execution_id) if db else None
            sql = str((fed or {}).get("sql_generated") or "")
            rec = rec or fed or {}
        except Exception:                                    # noqa: BLE001
            pass
    if not rec and not sql.strip():
        return {"pre_aggregated": None, "reason": "execution record unavailable"}
    if not sql.strip():
        return {"pre_aggregated": None,
                "reason": "execution stored no SQL, so its grain is unknown"}
    upper = " ".join(sql.upper().split())
    if " GROUP BY " in upper:
        return {"pre_aggregated": True, "reason": "the query carries a GROUP BY"}
    if _re_grain.search(r"\b(SUM|AVG|COUNT|MIN|MAX)\s*\(", upper):
        return {"pre_aggregated": True,
                "reason": "the query projects aggregates (single-row rollup)"}
    return {"pre_aggregated": False, "reason": "the query returns source rows"}


def _guard_pivot_functions(execution_id: str, values: list) -> dict:
    """Refuse a pivot whose functions would describe GROUPS, not rows.

    A REFUSAL, not a downgrade.  The alternative is what shipped before:
    a well-formed grid, a 200, and a number nobody can spot as wrong without
    recomputing it from source.  Only refuses when the grain is KNOWN to be
    pre-aggregated; an undetermined grain is labelled, not blocked, because
    blocking on "we could not tell" would break every legitimate pivot whose
    execution predates this field.
    """
    grain = _execution_grain(execution_id)
    if grain["pre_aggregated"] is not True:
        return grain
    offenders = sorted({
        str(v.get("function", "")).lower()
        for v in values
        if isinstance(v, dict)
        and str(v.get("function", "")).lower() in _NON_ADDITIVE_PIVOT_FUNCS
    })
    if offenders:
        raise HTTPException(
            status_code=409,
            detail=(
                f"This result is already aggregated ({grain['reason']}), so "
                f"{offenders} would describe the GROUPS in it, not the "
                f"underlying rows — on a five-dimension report that is wrong "
                f"by two orders of magnitude. Use SUM, which stays correct "
                f"over sums, or pivot an un-aggregated execution."
            ),
        )
    return grain


def _enforce_execution_ownership(execution_id: str, user: dict,
                                   *, allow_service: bool = True,
                                   record: Optional[dict] = None) -> None:
    """Reject the request if ``user`` is neither the executor nor an admin.

    Service-account executions (PV API consumers, embed/shared-token
    runs, scheduled jobs) are readable by any authenticated user
    because the auth boundary lives at the token/key layer above.

    Pass ``allow_service=False`` for write/delete endpoints — service
    executions are managed by their own cleanup mechanisms and should
    not be mutated by arbitrary authenticated users.

    Raises HTTPException 403 on mismatch.  No-op when the execution
    record isn't found (the existing 404 path in the caller handles
    that case with a clearer error).

    ``record``: the row the caller ALREADY read (2026-09-24).  Judge that
    row, not a second read through this module's own handle -- a caller
    whose handle differs (another pod's view, a test double) got a None
    here and the no-op above, i.e. the read was allowed on the strength
    of the row NOT being found.
    """
    rec = record if record is not None else _execution_record_or_none(execution_id)
    if not rec:
        return
    owner = (rec.get("executed_by") or "")
    if allow_service and owner and any(owner.startswith(pfx) for pfx in _SERVICE_EXECUTOR_PREFIXES):
        return  # service execution — allow read
    username = (user or {}).get("username", "")
    if owner == username:
        return  # owner match
    # Phase 115 hardening regression — use the canonical role helper instead
    # of the inline is_admin tuple.  Support role is admin-like for read.
    #
    # 2026-09-16: the second half was `role == "support"`, a HARDCODED name
    # for a role whose name is CONFIGURABLE (roles.support_role_name).
    # Rename the role and this gate silently stopped admitting support,
    # while core/clockwork/scope.py -- which asks is_support() -- kept
    # admitting them: one role, two answers.  is_read_like IS this
    # expression (is_admin_like or is_support), so this is the same
    # decision, spelled once, honouring the configured name.
    from core.roles import is_read_like as _is_read_like
    if _is_read_like(user):
        return  # admin / support bypass
    if _has_single_flight_grant(execution_id, username):
        return  # verified single-flight follower — allow read
    raise HTTPException(status_code=403, detail="Execution belongs to another user")


def _enforce_download_ownership(record: Optional[dict], user: dict,
                                *, allow_service: bool = True,
                                share_memo: Optional[dict] = None) -> None:
    """Reject the request if ``user`` may not read this DownloadFile.

    Wiz-scan #1 (2026-07-14, CWE-306 + CWE-639/IDOR): the three
    ``/api/downloads/{file_id}/*`` endpoints previously served any
    user's exported result set to anyone who knew (or guessed) the
    file_id — no authentication, no ownership check.  A DownloadFile
    is readable by:

      * its creator (``created_by``),
      * the owner of the originating execution (delegated to
        ``_enforce_execution_ownership`` — which also allows
        service-account executions and admin/support to read), or
      * any admin / support user.

    ``allow_service=False`` withdraws the service-execution allowance for
    callers where it is not the right boundary.  It IS right for the
    in-grid ``/api/downloads/{file_id}/preview|chart-data|pivot-data``
    routes this rule was written for (2026-07-14): a published-view or
    embed consumer viewing the result their own token produced, with the
    auth boundary at the token layer above.  It is NOT right for the
    DOWNLOAD CENTRE (``/api/downloads`` and ``/api/downloads/{id}``),
    where the caller is an ordinary QueryStudio user and the file was
    materialised under a DIFFERENT principal's row-security scope --
    reusing the permissive rule there (2026-08-22) listed and served
    every published_view:/embed:/shared:/system/scheduled result file to
    every authenticated user.  Two boundaries, one rule; they disagree,
    so each caller states which it is (2026-08-30).

    Fails OPEN (no-op) only when the record carries NO ownership signal
    at all — legacy rows written before ``created_by`` was populated and
    with no ``execution_id``.  The ``Depends(get_current_user)`` boundary
    still guarantees an authenticated caller, and rejecting these would
    break downloads of pre-existing files.  Raises HTTPException 403
    otherwise.
    """
    if not record:
        return  # 404 handled by the caller's existing not-found path
    # 2026-09-16 — see the sibling gate above: hardcoded "support" against
    # a configurable role name.
    from core.roles import is_read_like as _is_read_like
    if _is_read_like(user):
        return  # admin / support bypass
    username = (user or {}).get("username", "")
    created_by = (record.get("created_by") or "")
    if created_by and created_by == username:
        return  # creator match
    # Entitlement share (2026-08-30): the reader passes the SOURCE's own
    # read check (group grants included) AND their resolved row-security
    # scope equals the scope the file was generated under.  Both, because
    # entitlement to a definition is not entitlement to another
    # principal's rows.  Returns False for every unstamped row without
    # touching the database, so this costs nothing on the common path.
    try:
        from core.download_sharing import may_share as _may_share
        if _may_share(record, user, db=_get_db(), memo=share_memo):
            return
    except Exception:
        pass  # fail closed — fall through to the ownership chain
    exec_id = (record.get("execution_id") or "")
    if exec_id:
        # Delegate to the execution owner check — same gate the sibling
        # export_results_direct endpoint uses (owner / service / admin allow,
        # otherwise 403).
        _enforce_execution_ownership(exec_id, user,
                                     allow_service=allow_service)
        return
    if created_by:
        # Owner recorded, differs, and no execution to appeal to.
        raise HTTPException(status_code=403, detail="Download belongs to another user")
    # No ownership signal on a legacy record -> fail open.
    return


def _get_db():
    """Return the DatabaseManager.

    Tier 1: module-level global (set eagerly at import time OR via set_db_manager).
    Tier 2: sys.modules lookup — final safety net for unusual import scenarios.
    """
    global _db_manager
    if _db_manager is not None:
        return _db_manager

    # Tier 2: look inside sys.modules for main.db_manager
    import sys
    for mod_name in ("main", "__main__"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            dm = getattr(mod, "db_manager", None)
            if dm is not None:
                _db_manager = dm
                return _db_manager

    _logger.error("_get_db: all tiers failed — DatabaseManager unavailable")
    return None


def _is_safe_id(val: str) -> bool:
    """Validate that an ID looks like a UUID or safe alphanumeric string (no path traversal)."""
    import re
    return bool(re.match(r'^[a-zA-Z0-9_-]+$', val))


def _result_file_in_downloads_dir(execution_id: str, dl) -> Optional[Path]:
    """Look for {execution_id}.parquet then .csv in the downloads dir.

    Parquet first: it is the current format and the faster reader.
    """
    for ext in (".parquet", ".csv"):
        for base in [dl, Path(str(_get_downloads_dir()))]:
            try:
                candidate = base / f"{execution_id}{ext}"
                if candidate.exists():
                    return candidate
            except (OSError, ValueError):
                pass
    return None


def _result_file_from_db_record(execution_id: str) -> Optional[Path]:
    """Look up the execution record's stored output_file path.

    Needed for cache-hit executions stored outside downloads_dir.
    """
    try:
        db = _get_db()
        rec = db.get_execution(execution_id)
        if rec:
            p = rec.get("output_file")
            if p:
                fp = Path(p)
                if fp.exists():
                    return fp
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)
    return None


def _result_file_from_s3(execution_id: str, dl) -> Optional[Path]:
    """Download the result from S3 result storage (Phase 19F)."""
    try:
        from core.s3_storage import download_result_from_s3
        from main import s3_config as _main_s3_cfg
        s3_path = download_result_from_s3(execution_id, dl, _main_s3_cfg)
        if s3_path and s3_path.exists():
            return s3_path
    except Exception as exc:
        _logger.debug("S3 result fallback failed for %s: %s", execution_id, exc)
    return None


def _result_file_from_artifact(execution_id: str, dl) -> Optional[Path]:
    """Materialize a published result artifact locally.

    Industrialization Phase 6 — result-artifact hydration fallback.
    When queue-mode executors publish results as Arrow artifacts (local
    FS / S3), ANY API pod can materialize the result locally and serve
    every existing surface (pagination, charts, pivot, export) from it —
    pods are stateless, results never ride through pod RAM.  Flag OFF →
    one flag read, None.  Any error → None (today's behavior).  AUTHZ:
    like the S3 fallback, callers enforce execution ownership /
    the single-flight result grant BEFORE resolving the file.
    """
    try:
        from core.artifacts import maybe_hydrate_execution_result
        art_path = maybe_hydrate_execution_result(execution_id, dl)
        if art_path and art_path.exists():
            return art_path
    except Exception as exc:
        _logger.debug("artifact result fallback failed for %s: %s",
                      execution_id, exc)
    return None


def find_csv_file(execution_id: str, *,
                  hydrate_artifact: bool = True) -> Optional[Path]:
    """
    Find the result file for an execution.
    Prefers .parquet (new format, faster) but falls back to .csv for legacy files.
    Searches the config-driven downloads_dir first, then legacy fallbacks.
    Falls back to the DB-recorded output_file path (handles cache-hit executions
    whose result lives in data/cache/ rather than data/downloads/).

    ``hydrate_artifact=False`` skips the Phase-6 result-artifact
    materialization fallback — used by cleanup paths (release) that must
    not download an artifact just to delete the local copy.

    The four lookups are ORDERED cheapest-first and each is a fallback for
    the one before it; reordering them changes which copy of a result the
    grid serves.
    """
    # Prevent path traversal via execution_id
    if not _is_safe_id(execution_id):
        _logger.warning("Invalid execution_id rejected: %s", execution_id[:80])
        return None

    dl = _get_downloads_dir()

    found = _result_file_in_downloads_dir(execution_id, dl)
    if found is not None:
        return found

    found = _result_file_from_db_record(execution_id)
    if found is not None:
        return found

    found = _result_file_from_s3(execution_id, dl)
    if found is not None:
        return found

    if hydrate_artifact:
        found = _result_file_from_artifact(execution_id, dl)
        if found is not None:
            return found

    return None


# ═══════════════════════════════════════════════════════════════════
# DuckDB helpers
# ═══════════════════════════════════════════════════════════════════

def _set_duckdb_extension_dir(con, _lim_os) -> None:
    """Point DuckDB's extension directory at a WRITABLE path.

    Extension directory — must be writable for INSTALL/LOAD.
    In containers running as non-root, HOME may be "/" (read-only) causing
    DuckDB's default ~/.duckdb/extensions/ to fail with "Permission denied".
    """
    try:
        _ext_dir = _lim_os.environ.get("DUCKDB_EXTENSION_DIR", "").strip()
        if not _ext_dir:
            _td = _lim_os.environ.get("DUCKDB_TEMP_DIR", "").strip()
            if _td:
                # temp_dir is typically .../data/tmp/duckdb — need 2 levels up to reach .../data/
                _ext_dir = _lim_os.path.join(_lim_os.path.dirname(_lim_os.path.dirname(_td.rstrip("/\\"))), "duckdb_extensions")
        if _ext_dir:
            _lim_os.makedirs(_ext_dir, exist_ok=True)
            con.execute(f"SET extension_directory='{_ext_dir}';")
    except Exception:
        pass  # best-effort — fall back to DuckDB default


def _set_duckdb_temp_dir(con, _lim_os) -> None:
    """Point DuckDB's spill directory at the first WRITABLE candidate.

    2026-07-16: temp_directory MUST be a WRITABLE dir.  This path
    (_duckdb_con_with_s3 → data grid + feed query_native capture) previously
    NEVER set temp_directory — DUCKDB_TEMP_DIR was read only to derive the
    extension dir above.  With it unset, DuckDB spills to ``.tmp`` in the
    read-only container CWD → "failed to create directory .tmp: Permission
    denied" on the first COPY TO / spill (the reported query_native crash).
    Try DUCKDB_TEMP_DIR (exported from config at startup in main.py), then a
    guaranteed-writable local OS-temp dir.
    """
    try:
        import tempfile as _lim_tf
        _td_cfg = _lim_os.environ.get("DUCKDB_TEMP_DIR", "").strip()
        _local_spill = _lim_os.path.join(_lim_tf.gettempdir(), "qs_duckdb_spill")
        for _cand in ([_td_cfg] if _td_cfg else []) + [_local_spill]:
            try:
                _lim_os.makedirs(_cand, exist_ok=True)
                con.execute(f"SET temp_directory='{_cand}';")
                break
            except Exception:
                continue  # try the local fallback
    except Exception:
        pass  # best-effort — never block connection setup on temp-dir config


def _set_duckdb_resource_limits(con) -> None:
    """Apply the admin-configured thread and memory caps.

    A cap of 0 or less means "unset" and leaves DuckDB's own default in
    place -- it must never be pushed down as a literal 0.
    """
    try:
        from core.config import query_engine as _qe
        threads = _qe.duckdb_threads_per_query
        if threads > 0:
            con.execute(f"SET threads = {threads}")
        mem_mb = _qe.duckdb_memory_limit_mb
        if mem_mb > 0:
            con.execute(f"SET memory_limit = '{mem_mb}MB'")
    except Exception:
        pass  # config not loaded yet (startup) — use DuckDB defaults


def _duckdb_apply_limits(con):
    """Apply per-connection thread and memory limits from admin config."""
    import os as _lim_os
    _set_duckdb_extension_dir(con, _lim_os)
    _set_duckdb_temp_dir(con, _lim_os)
    _set_duckdb_resource_limits(con)
    return con


def _duckdb_con():
    """New in-memory DuckDB connection (each request gets its own)."""
    return _duckdb_apply_limits(_duckdb.connect(database=":memory:"))


# ── DuckDB S3 / Iceberg helpers ───────────────────────────────────────────────

_DUCKDB_HTTPFS_OK   = None   # None = not yet tested
_DUCKDB_ICEBERG_OK  = None
_ext_load_lock = _threading.Lock()  # serialise first-time extension install/load


def _try_load_extension(con, ext: str) -> bool:
    """Attempt to LOAD a DuckDB extension (INSTALL as fallback).

    LOAD-first order supports air-gapped environments where extensions
    are pre-downloaded to the extension_directory (no internet needed).
    """
    # Ensure extension_directory is writable (non-root containers).
    # Callers via _duckdb_apply_limits() already set this, but be defensive
    # in case _try_load_extension is called from other paths.
    try:
        from core.file_formats import ensure_extension_directory
        ensure_extension_directory(con)
    except Exception:
        pass
    try:
        con.execute(f"LOAD '{ext}';")  # works with pre-downloaded extensions
        return True
    except Exception:
        try:
            con.execute(f"INSTALL '{ext}';")  # needs internet
            con.execute(f"LOAD '{ext}';")
            return True
        except Exception:
            return False


def _drain_fresh_pooled_con(queue):
    """Pop the first non-expired connection off a pool queue.

    Returns ``(candidate_or_None, expired_cons)``.  Expired connections are
    handed BACK to the caller rather than closed here, because a close can
    block and this runs under the global pool lock.
    """
    expired: list = []
    # Drain until first non-expired connection; expired ones
    # are collected and closed outside the lock.
    while not queue.empty():
        try:
            cached_con, ts = queue.get_nowait()
        except _QueueEmpty:
            break
        if _time.monotonic() - ts < _S3_POOL_TTL:
            return cached_con, expired
        expired.append(cached_con)
    return None, expired


def _drain_all_pooled_cons(queue):
    """Pop EVERY connection off a pool queue, for closing outside the lock."""
    drained: list = []
    while not queue.empty():
        try:
            stale_con, _ = queue.get_nowait()
        except _QueueEmpty:
            break
        drained.append(stale_con)
    return drained


def _take_pooled_s3_con(connection_id, cred_hash):
    """Dequeue a candidate pooled connection, and whatever must be closed.

    2026-08-20 — _s3_pool_lock is the single global lock guarding EVERY
    connection's pool.  The BF-484 credential re-resolution used to run
    INSIDE it: for _DYNAMIC_AUTH_MODES the checkout performs an STS
    assume_role / portal-token HTTP exchange (documented at 5-15s through a
    corporate proxy), so one slow portal call blocked every other thread
    checking out ANY pooled S3 connection for the whole window.  Now the
    lock is held only to DEQUEUE a candidate (pure dict/queue ops); the
    dequeued connection is exclusively ours, so resolving + applying keys
    and closing expired connections all happen safely OUTSIDE the lock.
    """
    with _s3_pool_lock:
        entry = _s3_pool.get(connection_id)
        if not entry:
            return None, []
        if entry["cred_hash"] == cred_hash:
            return _drain_fresh_pooled_con(entry["queue"])
        # Credentials rotated — evict stale pool entries
        old = _s3_pool.pop(connection_id)
        return None, _drain_all_pooled_cons(old["queue"])


def _restamp_no_creds_marker(cached_con, _k, _auth_mode, connection_id):
    """Clear, or re-stamp, the "DuckDB has no S3 credentials" marker after a
    credential refresh on pool checkout.

    Stamping is what makes the eventual HTTP 403 attributable, so a STALE
    stamp is worse than none: it names a cause that has since been fixed.
    """
    # Clear any stale BF-476 stamp from a prior
    # empty-creds resolution — we just re-resolved.
    try:
        if hasattr(cached_con, "_qs_duckdb_no_creds_reason"):
            delattr(cached_con, "_qs_duckdb_no_creds_reason")
    except Exception as _clr_exc:
        # 2026-09-01 -- was ``logger``; this module defines
        # ``_logger``.  A NameError raised INSIDE an except block
        # escapes it, so a failure to clear the marker took the
        # whole pooled-connection path down with it.
        _logger.debug("could not clear the no-creds marker: %s",
                      _clr_exc)
    if not _k:
        # Stamp so register_s3_views' failure hint
        # points at the right cause.
        try:
            setattr(
                cached_con,
                "_qs_duckdb_no_creds_reason",
                f"DuckDB S3 secret EMPTY after refresh "
                f"(auth_mode={_auth_mode}, conn={connection_id})",
            )
        except Exception as _mark_exc:
            _logger.debug(
                "could not stamp the no-creds marker: %s",
                _mark_exc)


def _close_pooled_s3_cons(cons):
    """Close connections evicted from the pool, OUTSIDE the pool lock.

    A close can block; holding the one global pool lock across it is what
    the 2026-08-20 change removed.
    """
    for _stale in cons:
        try:
            _stale.close()
        except Exception as exc:
            _logger.warning("data_grid_api error: %s", exc, exc_info=True)


def _apply_native_s3_ssl(con, conn_config):
    """Route SSL verification for the NATIVE S3 path through the shared helper.

    2026-06-24 -- SSL verification: route through shared helper.
    Prior inline logic FORCED ssl_verify=True (boolean default) into
    the DISABLE branch because it only honored string-path values.
    Operators who set ssl_verify=True and entered a .pem file via
    the UI saw cert verification silently turned OFF.
    """
    try:
        from core.ssl_config import apply_ssl_to_duckdb_con
        apply_ssl_to_duckdb_con(
            con, conn_config,
            log_prefix="DuckDB native SSL",
        )
    except Exception as _e:
        _logger.warning("DuckDB SSL helper failed (%s) -- leaving "
                        "defaults in place.", _e)


def _load_httpfs_into(con) -> bool:
    """Load the httpfs extension into ``con``; False means no S3 for it.

    Thread-safe extension loading — DuckDB INSTALL/LOAD is NOT thread-safe;
    concurrent calls from worker-pool threads cause access violations on Windows.
    The INSTALL verdict is cached process-wide in ``_DUCKDB_HTTPFS_OK``, so a
    box without the extension pays the failure once.
    """
    global _DUCKDB_HTTPFS_OK
    _logger.info("STREAM-DIAG: acquiring _ext_load_lock (httpfs_ok=%s)", _DUCKDB_HTTPFS_OK)
    with _ext_load_lock:
        _logger.info("STREAM-DIAG: _ext_load_lock acquired")
        if _DUCKDB_HTTPFS_OK is False:
            return False

        if _DUCKDB_HTTPFS_OK is None:
            ok = _try_load_extension(con, "httpfs")
            _DUCKDB_HTTPFS_OK = ok
            if not ok:
                _logger.warning(
                    "DuckDB httpfs extension unavailable — S3 direct queries disabled"
                )
                return False
            _logger.info("STREAM-DIAG: httpfs extension installed and loaded (first time)")
            return True

        # Already installed globally — just LOAD into this connection
        try:
            con.execute("LOAD 'httpfs';")
            _logger.info("STREAM-DIAG: httpfs LOAD OK")
        except Exception as _load_exc:
            _logger.warning("DuckDB: httpfs LOAD failed: %s", _load_exc, exc_info=True)
            return False
    return True


def _configure_presigned_s3_con(con, conn_config, ep):
    """Configure a connection for on-prem PRE-SIGNED S3 mode.

    When access mode is "presigned", all S3 reads use pre-signed HTTP URLs
    (boto3 handles auth).  If we set s3_endpoint + s3_access_key_id, DuckDB
    httpfs recognizes the endpoint host and adds S3 auth headers ON TOP of
    the pre-signed URL, corrupting the signature.  So this path sets NO S3
    credentials at all -- only SSL, HTTP tuning and the proxy.
    """
    _logger.info("DuckDB: S3 access_mode=presigned — skipping S3 credential setup (pre-signed URLs handle auth)")
    # Prevent DuckDB from auto-fetching AWS creds from env vars / ~/.aws
    # which would cause httpfs to add S3 auth headers to pre-signed URLs
    try:
        con.execute("SET enable_global_s3_configuration=false;")
    except Exception:
        pass
    # 2026-06-24 -- route through shared SSL helper.  Previously
    # this forced ssl_verify=True (boolean default!) into the
    # FORCE-OFF branch because it only honored string paths.
    # Operators who entered a .pem file but left the toggle at
    # True got SSL DISABLED.
    try:
        from core.ssl_config import apply_ssl_to_duckdb_con
        apply_ssl_to_duckdb_con(
            con, conn_config,
            log_prefix="DuckDB on-prem SSL (presigned mode)",
        )
    except Exception as _ssl_exc:
        _logger.warning(
            "DuckDB on-prem presigned SSL helper failed (%s) -- "
            "leaving DuckDB defaults in place.", _ssl_exc,
        )
    # HTTP tuning + the shared S3 transport for httpfs HTTPS fetches --
    # the same function as the native path (2026-10-06).
    _apply_s3_http_tuning(con, presigned=True)
    from core.proxy_utils import apply_duckdb_proxy
    apply_duckdb_proxy(con, endpoint_url=ep)


def _portal_s3_creds(conn_config, connection_id):
    """Resolve S3 keys through the CredentialManager (system account +
    auto-fallback), or None when portal resolution did not answer.

    None is NOT "no credentials": it means the portal was unavailable or
    errored, and the caller keeps ``auth_mode`` as it was rather than
    downgrading to a keys lookup that would find nothing.
    """
    # Portal mode: resolve via CredentialManager (system account + auto-fallback)
    try:
        from core.credential_manager import get_credential_manager
        _dg_cm = get_credential_manager()
        if _dg_cm:
            _resolved = _dg_cm.resolve_s3_credentials(
                dict(conn_config), f"stream:{connection_id}"
            )
            return (_resolved.get("aws_access_key_id", ""),
                    _resolved.get("aws_secret_access_key", ""),
                    _resolved.get("aws_session_token", ""))
    except Exception as _portal_exc:
        _logger.warning(
            "Portal credential resolution failed for DuckDB (conn=%s): %s",
            connection_id, _portal_exc,
        )
    return None


def _boto3_s3_creds(conn_config, region, auth_mode):
    """Resolve AWS keys for profile / assume_role / iam_role through THE
    credential chain (``core.credential_resolver``: the same STS call, the
    same session name, the same TLS rule as the feed worker).

    2026-10-26 -- this file carried its OWN STS / profile copy, which is
    how the query builder read a VPC-endpoint table the feed worker could
    not: two chains, two answers.  ``region`` is accepted for the
    callers' signature; the chain resolves it from the same function.

    A resolution failure yields EMPTY keys, not an exception: the caller
    stamps WHY they are empty on the connection (BF-476) so the eventual
    HTTP 403 names its cause instead of looking like a bad bucket.
    """
    try:
        from core.credential_resolver import resolve_s3_keys
        key, secret, token = resolve_s3_keys(conn_config)
    except Exception as exc:
        _logger.warning(
            "Failed to resolve AWS credentials for DuckDB (auth_mode=%s): %s",
            auth_mode, exc, exc_info=True,
        )
        return "", "", ""
    if not key:
        # the chain said why at WARNING ([cred-resolver] ...); this names
        # the road so the BF-476 stamp and the log agree
        _logger.warning(
            "Failed to resolve AWS credentials for DuckDB (auth_mode=%s): the "
            "credential chain returned no key", auth_mode)
    return key, secret, token


def _resolve_s3_creds_for_con(conn_config, connection_id, region):
    """Resolve credentials for all auth modes (keys, portal, profile,
    assume_role, iam_role).

    Returns ``(key, secret, token, auth_mode)`` -- the auth_mode comes BACK
    because portal resolution rewrites it to "keys", and the value that is
    reported and stamped must be the one actually used.
    """
    auth_mode = (conn_config.get("auth_mode") or "keys").lower()
    key = ""
    secret = ""
    token = ""

    if auth_mode == "portal":
        _portal = _portal_s3_creds(conn_config, connection_id)
        if _portal is not None:
            key, secret, token = _portal
            auth_mode = "keys"  # resolved — proceed with keys

    if auth_mode == "keys" and not key:
        # Static keys path (or portal already populated key above) -- through
        # THE chain (2026-10-26): literal keys pass through; a SYSTEM
        # ACCOUNT's keys come from the vault (this site read the row alone,
        # so such a connection had no keys here and the vault's on the feed
        # worker); a VPCE endpoint is normalised.  A vault that cannot answer
        # raises (fail-closed, as on every other road).
        from core.credential_resolver import resolve_s3_keys
        key, secret, token = resolve_s3_keys(
            conn_config, username=f"stream:{connection_id}")
    elif auth_mode in ("profile", "assume_role", "iam_role"):
        key, secret, token = _boto3_s3_creds(conn_config, region, auth_mode)

    return key, secret, token, auth_mode


def _stamp_empty_cred_reason(con, key, auth_mode):
    """Stamp WHY DuckDB will have no S3 secret, so the 403 names its cause.

    BF-476 (2026-05-19) — fail-fast visibility for the "DuckDB has no
    S3 credentials" failure mode the user reported.  Previously the
    silent-empty-cred path let CREATE VIEW fail downstream with a
    cryptic HTTP 403; BF-474 made that loud, BUT we can do better
    by surfacing the issue HERE with a stamp on the connection
    info so feed_engine / dashboard chip can pull it up by name.
    Empty key when auth_mode is portal/assume_role/iam is almost
    always actionable: vault password missing, system_account
    inactive, STS expired without refresh, etc.
    """
    if key or auth_mode not in ("portal", "assume_role", "iam_role"):
        return
    _empty_cred_warning = (
        f"DuckDB S3 secret will be EMPTY for this connection "
        f"(auth_mode={auth_mode}).  CREATE VIEW on s3:// will "
        f"fail with HTTP 403.  Likely cause: "
        + (
            "system_account password missing or inactive"
            if auth_mode == "portal"
            else f"{auth_mode} credential resolution returned no key"
        )
    )
    _logger.warning(_empty_cred_warning)
    # Stamp on the connection so the BF-474 surfaces this as the
    # PRIMARY cause of the downstream view-creation 403 instead
    # of just the generic 'auth failure' hint.
    try:
        setattr(con, "_qs_duckdb_no_creds_reason", _empty_cred_warning)
    except Exception:
        pass


def _apply_s3_endpoint_to_con(con, conn_config, ep, _esc):
    """Point DuckDB at a non-AWS S3 endpoint and its URL style.

    2026-09-26 -- the endpoint host, ``s3_use_ssl`` and ``s3_url_style`` are
    decided ONCE in ``core.s3_access`` (F2); this site only applies them.
    Credentials and region were already SET by the caller."""
    from core.s3_access import resolve_s3_access
    _access = resolve_s3_access(conn_config, proxy=False)
    for _stmt in _access.duckdb_statements(credentials=False, endpoint=True):
        if _stmt.startswith("SET s3_region="):
            continue        # the caller SET the region it resolved
        con.execute(_stmt)


def _apply_s3_http_tuning(con, *, presigned: bool = False):
    """THE in-process factory's HTTP settings -- native AND presigned.

    2026-10-06 -- ONE function.  There were two inline copies (this one for
    native, a loop in ``_configure_presigned_s3_con``), and NEITHER applied
    ``core.s3_http_transport.apply_s3_http_transport``: no
    ``httpfs_connection_caching`` (~2 new TCP+TLS connections per file) and
    ``http_retries`` pinned at 2 / 3, under the transport's floor of 10.
    Every ``setup_registered_views`` / ``register_s3_views`` road draws its
    connection from this factory -- among them the cross-source S3 side,
    measured on AWS reading a 672-file island for 20 minutes where the same
    statement single-source (subprocess child, transport applied) took
    60-110 s.  ``http_retries`` is no longer set here: the transport's floor
    owns it (setting 2 and then raising it to 10 was two answers to one
    question).

    Per setting, best-effort: an older DuckDB that does not know one still
    gets the rest (the old native block's single ``try`` dropped every
    setting after the first refusal).  httpfs is already LOADed (the
    transport settings do not exist before it).
    """
    try:
        from core.config import federation as _fed_cfg
        _http_s = int(_fed_cfg.http_timeout_seconds)
    except Exception:
        _http_s = 30
    # 2026-09-21: SECONDS -- the ms value once went through verbatim (a
    # 4-hour HTTP timeout).  The presigned copy hard-coded 30 (the default)
    # and ignored the configured value; both modes now read it.
    _wait_ms = 500 if presigned else 1000
    for _stmt in (
        "SET http_keep_alive=true;",
        f"SET http_retry_wait_ms={_wait_ms};",
        f"SET http_timeout={_http_s};",            # Phase 102-H: configurable
        "SET enable_http_metadata_cache=true;",
        "SET enable_object_cache=true;",
    ):
        try:
            con.execute(_stmt)
        except Exception as _http_exc:
            _logger.debug("DuckDB S3 tuning: %s refused: %s",
                          _stmt.strip(), _http_exc)
    try:
        from core.s3_http_transport import apply_s3_http_transport
        apply_s3_http_transport(
            con, label="data_grid presigned" if presigned else "data_grid")
    except Exception as _tr_exc:                      # noqa: BLE001
        _logger.warning("DuckDB S3 transport not applied (fail-open): %s",
                        _tr_exc)


def _duckdb_con_with_s3(
    conn_config: dict,
    connection_id: Optional[int] = None,
) -> "duckdb.DuckDBPyConnection":  # type: ignore[name-defined]
    """Return a DuckDB connection pre-configured with S3 credentials.

    When connection_id is provided the connection is drawn from (and returned
    to) a per-connection_id pool so that parquet footer reads and HTTP
    handshakes are reused across queries, eliminating cold-start overhead.

    conn_config is the 'config' sub-dict of a saved Connection record
    (connection_type='s3').  Supported keys:
      aws_access_key_id, aws_secret_access_key, aws_session_token,
      region_name / region, endpoint_url / endpoint
    """
    cred_hash = _s3_cred_hash(conn_config) if connection_id is not None else ""

    # ── Pool lookup ───────────────────────────────────────────────────────────
    if connection_id is not None:
        _pool_candidate, _cons_to_close = _take_pooled_s3_con(
            connection_id, cred_hash)
        _close_pooled_s3_cons(_cons_to_close)
        if _pool_candidate is not None:
            cached_con = _pool_candidate
            # BF-484: dynamic auth modes (portal/STS) rotate AWS keys at
            # runtime — the pooled connection's SET s3_session_token may be
            # expired even though cred_hash (static config fingerprint) is
            # unchanged.  Re-resolve and re-apply on every checkout so
            # CREATE VIEW doesn't 403.  (Outside _s3_pool_lock — see above.)
            _auth_mode = (conn_config.get("auth_mode") or "keys").lower()
            if _auth_mode in _DYNAMIC_AUTH_MODES:
                _k, _s, _t = _resolve_aws_keys_for_duckdb(
                    conn_config, connection_id,
                )
                _apply_s3_keys_to_con(cached_con, _k, _s, _t)
                _restamp_no_creds_marker(
                    cached_con, _k, _auth_mode, connection_id)
            _logger.info("STREAM-DIAG: returning POOLED connection (conn=%s)", connection_id)
            return _PooledS3Con(cached_con, connection_id, cred_hash)

    # ── Create new connection ─────────────────────────────────────────────────
    def _wrap(con):
        return _PooledS3Con(con, connection_id, cred_hash) if connection_id is not None else con

    _logger.info("STREAM-DIAG: creating NEW DuckDB connection (conn=%s)", connection_id)
    con = _duckdb_apply_limits(_duckdb.connect(database=":memory:"))

    if not _load_httpfs_into(con):
        return _wrap(con)

    from core.s3_storage import resolve_s3_region as _qs_region
    region = _qs_region(conn_config)
    # 2026-06-24 -- ``ep`` is the RAW endpoint URL (kept for the
    # ``use_ssl`` / scheme decision below).  The DuckDB SET pragma
    # consumes ``_ep_for_duckdb_set`` which is the VPCE-normalised,
    # scheme-stripped host -- the bucket.-prefix rewrite happens in
    # ssl_config so this site can't forget it.
    ep     = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")

    # ── On-prem S3 pre-signed mode: skip DuckDB S3 credential setup ──────
    # When access mode is "native", fall through to normal credential setup
    # (which already handles path_style by setting s3_url_style='path').
    _access_mode = get_s3_access_mode(conn_config)
    if _access_mode == "presigned":
        _configure_presigned_s3_con(con, conn_config, ep)
        return _wrap(con)

    key, secret, token, auth_mode = _resolve_s3_creds_for_con(
        conn_config, connection_id, region)

    def _esc(v: str) -> str:
        return v.replace("'", "''")

    _logger.debug("DuckDB: setting S3 credentials (region=%s, auth=%s)", region, auth_mode)
    con.execute(f"SET s3_region='{_esc(region)}';")
    _stamp_empty_cred_reason(con, key, auth_mode)
    if key:
        con.execute(f"SET s3_access_key_id='{_esc(key)}';")
    if secret:
        con.execute(f"SET s3_secret_access_key='{_esc(secret)}';")
    if token:
        con.execute(f"SET s3_session_token='{_esc(token)}';")
    if ep:
        _apply_s3_endpoint_to_con(con, conn_config, ep, _esc)

    _apply_native_s3_ssl(con, conn_config)

    _apply_s3_http_tuning(con)

    from core.proxy_utils import apply_duckdb_proxy
    apply_duckdb_proxy(con, endpoint_url=ep)

    return _wrap(con)


def _duckdb_iceberg_source(table_prefix: str) -> str:
    """Return a DuckDB iceberg_scan() table expression for an Iceberg table on S3.

    table_prefix is the S3 URI of the table root, e.g. 's3://bucket/warehouse/db/table/'.
    allow_moved_paths=true handles AWS Glue / EMR layouts where manifest paths
    reference a different S3 key prefix than the actual data location.
    """
    global _DUCKDB_ICEBERG_OK
    safe = table_prefix.replace("'", "''")
    return f"iceberg_scan('{safe}', allow_moved_paths=true)"


def _install_iceberg_extension(con) -> bool:
    """First-time iceberg INSTALL/LOAD; caches the verdict process-wide."""
    global _DUCKDB_ICEBERG_OK
    ok = _try_load_extension(con, "iceberg")
    _DUCKDB_ICEBERG_OK = ok
    if not ok:
        _logger.warning(
            "DuckDB iceberg extension unavailable — falling back to manifest reader"
        )
    return ok


def _ensure_iceberg_extension(con) -> bool:
    global _DUCKDB_ICEBERG_OK
    with _ext_load_lock:
        if _DUCKDB_ICEBERG_OK is False:
            return False
        if _DUCKDB_ICEBERG_OK is None:
            return _install_iceberg_extension(con)
        try:
            con.execute("LOAD 'iceberg';")
            return True
        except Exception:
            return False


def _duckdb_source(path: Path) -> str:
    """Return the DuckDB table-function expression for a file.
    Uses .as_posix() so Windows backslashes are not misinterpreted
    as SQL/octal escape sequences inside DuckDB string literals.
    """
    p = path.resolve().as_posix().replace("'", "''")
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return f"read_parquet('{p}')"
    if suffix == ".json":
        return f"read_json_auto('{p}')"
    # CSV / TXT (and anything else): auto-detect.
    # sample_size=1000 caps schema-inference to the first 1000 rows so DuckDB
    # doesn't scan the entire file just to figure out column types — critical
    # for 1000-column files where a full scan takes 30-60 s.
    return f"read_csv_auto('{p}', ignore_errors=true, all_varchar=false, sample_size=1000)"


def _duckdb_valid_cols(con, source: str) -> list:
    """Return ordered list of column names from the source."""
    try:
        df = con.execute(f"SELECT * FROM {source} LIMIT 0").fetchdf()
        return df.columns.tolist()
    except Exception as exc:
        _logger.warning("Failed to read column schema from %s: %s", source, exc, exc_info=True)
        return []


def _q(col_name: str) -> str:
    """Quote a column name for DuckDB, escaping embedded double-quotes."""
    return '"' + col_name.replace('"', '""') + '"'


_GRID_FILTER_CONTRACT = """A filter that cannot be applied must FAIL.

2026-08-20 -- this builder silently DISCARDED any condition it could not
render, on four separate paths, and every one of them returns MORE ROWS than
the caller asked for with a 200 status:

    col not in valid_set          -> `continue`
    op not in this chain          -> no else branch; fell off the end
    gt/gte/lt/lte with "abc"      -> `except (ValueError, TypeError): pass`
    every condition dropped       -> `if not parts: return "", []` = NO WHERE

Measured against the query-compiler chokepoint, same input:

    {"op":"gt","val":"abc"}   grid -> ('', [])        compiler -> "amt" > ?
    {"op":"in", ...}          grid -> ('', [])        compiler -> renders it
    {"op":"between", ...}     grid -> ('', [])        compiler -> renders it
    {"op":"equals","val":None} grid -> param 'None'   compiler -> raises

and with one good condition beside one bad one, the grid kept the good one
and quietly widened the result set.

This is the product's cap-vs-gate rule: a CAP may throttle, but a filter is a
CORRECTNESS GATE and must fail loudly.  Silently returning extra rows is the
worst failure mode for a reporting tool, because it is indistinguishable from
a correct answer.

The deeper fix is to route this through core.query_compiler.compile_where --
the documented single chokepoint, whose invariant #1 is exactly this -- and
retire the second vocabulary.  That is a behavioural change to every grid
filter and wants its own pass; refusing is the correct behaviour either way.
"""


def _grid_numeric_filter_part(qcol: str, col: str, op: str, val) -> tuple:
    """Render a numeric grid comparison; refuses a non-numeric value.

    2026-08-20 -- WAS `pass`.  `{"op":"gt","val":"abc"}` dropped
    the whole condition and returned every row as if no filter
    had been requested.
    """
    try:
        nval = float(val)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=400,
            detail=(f"Filter on {col!r} uses {op!r} but the value "
                    f"{val!r} is not numeric."))
    sym  = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[op]
    return f"TRY_CAST({qcol} AS DOUBLE) {sym} ?", [nval]


def _grid_filter_part(cond: dict, valid_set: set) -> tuple:
    """Render ONE grid filter condition as ``(sql, params)``.

    Every condition this builder cannot render RAISES -- see
    :data:`_GRID_FILTER_CONTRACT`.  A dropped filter returns MORE rows
    than were asked for, which is the one failure mode a reporting tool
    must never have.
    """
    col = cond.get("col", "")
    op  = cond.get("op", "contains")
    val = cond.get("val", "")
    if col not in valid_set:
        # 2026-08-20 -- WAS `continue`.  See _GRID_FILTER_CONTRACT below.
        raise HTTPException(
            status_code=400,
            detail=(f"Unknown filter column {col!r}. A filter that cannot "
                    f"be applied must fail, not be dropped -- dropping it "
                    f"returns MORE rows than were asked for."))

    qcol     = _q(col)
    cast_col = f'CAST({qcol} AS VARCHAR)'

    if op == "contains":
        return f"{cast_col} ILIKE ?", [f"%{val}%"]
    if op == "not_contains":
        return f"({cast_col} NOT ILIKE ? OR {qcol} IS NULL)", [f"%{val}%"]
    if op == "equals":
        return f"{cast_col} = ?", [str(val)]
    if op == "not_equals":
        return f"({cast_col} != ? OR {qcol} IS NULL)", [str(val)]
    if op == "starts_with":
        return f"{cast_col} ILIKE ?", [f"{val}%"]
    if op == "ends_with":
        return f"{cast_col} ILIKE ?", [f"%{val}"]
    if op in ("gt", "gte", "lt", "lte"):
        return _grid_numeric_filter_part(qcol, col, op, val)
    if op == "is_null":
        return f"{qcol} IS NULL", []
    if op == "is_not_null":
        return f"{qcol} IS NOT NULL", []
    # 2026-08-20 -- THERE WAS NO ELSE.  An operator this builder does
    # not know -- `in`, `not_in`, `between`, anything the query
    # compiler accepts -- fell off the end of the chain and vanished.
    raise HTTPException(
        status_code=400,
        detail=(f"Unsupported filter operator {op!r} on {col!r}. "
                f"Supported here: contains, not_contains, equals, "
                f"not_equals, starts_with, ends_with, gt, gte, lt, "
                f"lte, is_null, is_not_null."))


def _build_where(adv_filters_json: Optional[str], valid_cols: list) -> tuple:
    """
    Parse adv_filters JSON into a (WHERE-clause-string, params-list) pair.

    Raises HTTPException(400) for any condition it cannot render --
    see :data:`_GRID_FILTER_CONTRACT`.

    adv_filters format:
      { "conjunction": "AND" | "OR",
        "conditions": [
          { "col": "region", "op": "equals",   "val": "US" },
          { "col": "revenue","op": "gt",        "val": "1000" },
          ...
        ]
      }
    Supported ops: contains, not_contains, equals, not_equals,
                   starts_with, ends_with, gt, gte, lt, lte,
                   is_null, is_not_null
    """
    if not adv_filters_json:
        return "", []
    try:
        af = json.loads(adv_filters_json)
    except Exception as exc:
        _logger.warning("Failed to parse adv_filters JSON: %s", exc, exc_info=True)
        return "", []

    conjunction = af.get("conjunction", "AND").upper()
    if conjunction not in ("AND", "OR"):
        conjunction = "AND"

    valid_set = set(valid_cols)
    parts, params = [], []

    for cond in af.get("conditions", []):
        _part, _cond_params = _grid_filter_part(cond, valid_set)
        parts.append(_part)
        params.extend(_cond_params)

    if not parts and af.get("conditions"):
        # Conditions were requested and none survived -- refuse rather than
        # run unfiltered.
        raise HTTPException(
            status_code=400,
            detail="No requested filter could be applied to this dataset.")
    if not parts:
        return "", []
    return f" WHERE {(' ' + conjunction + ' ').join(parts)}", params


from core.config import limits as _limits_cfg  # noqa: E402
_MAX_DISPLAY_COLS = _limits_cfg.max_display_cols  # auto-project wide tables (configurable via admin)


def _effective_adv_filters(adv_filters: Optional[str],
                           filters: Optional[str]) -> Optional[str]:
    """Coerce legacy per-column ``filters`` into the adv_filters format.

    ``adv_filters`` always wins when present -- the legacy parameter is a
    fallback, never an override.  A malformed legacy payload is logged and
    IGNORED here (the grid's own filter contract, _GRID_FILTER_CONTRACT,
    governs what happens to a filter that cannot be RENDERED; this is about
    one that cannot be PARSED at all, where there is nothing to refuse).

    Three routes -- /executions/{id}/results, the download-centre preview
    and /api/files/data -- carried byte-identical copies of this block.
    """
    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conditions = [
                {"col": col, "op": "contains", "val": val}
                for col, val in json.loads(filters).items()
                if val
            ]
            if conditions:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conditions})
        except Exception as exc:
            _logger.warning("data_grid_api error: %s", exc, exc_info=True)
    return effective_adv


def _parquet_uncompressed_estimate(path: Path) -> int:
    """Uncompressed-size estimate from the parquet FOOTER — O(1), no row data.

    Sum of per-row-group ``total_byte_size`` (uncompressed).  Returns 0 when
    the footer cannot be read; callers treat 0 as "small" so behaviour
    degrades to the pre-existing pandas path rather than erroring.
    """
    try:
        import pyarrow.parquet as _pq
        md = _pq.ParquetFile(str(path)).metadata
        return sum(md.row_group(i).total_byte_size
                   for i in range(md.num_row_groups))
    except Exception as exc:
        _logger.warning("Parquet size estimate failed for %s: %s", path.name, exc)
        return 0


def _snappy_bounded_paginate(
    path: Path,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename: str,
    est_bytes: int,
) -> dict:
    """Bounded pagination for LARGE snappy parquet — memory O(page), not O(file).

    2026-07-31: the snappy fallback exists because DuckDB can segfault on
    snappy parquet on some platforms (see _duckdb_paginate), so routing these
    files back through DuckDB is not an option — that recorded crash risk is
    the whole reason this branch exists.  But the fallback did
    ``pd.read_parquet(path)`` of the ENTIRE file and cached it in RAM: an
    O(result) memory bomb at 10-20M rows x ~900 cols.  Above
    ``_SNAPPY_PANDAS_MAX_BYTES`` we now page through pyarrow's batch reader
    (same bounded shape as published_views_api._read_parquet_page: footer-only
    total_rows, offset/limit via iter_batches with early stop) and never cache.

    Sort/filter genuinely require scanning ALL rows (a global sort or a
    filtered count cannot be evaluated from a prefix), and this path returns
    every column, so there is no projection to soften a full read.  For files
    past the threshold those operations are therefore refused with a clear
    413 instead of silently OOM-ing the pod.  Query RESULTS are zstd (DuckDB
    handles them, sort/filter included) — this only affects oversized snappy
    uploads.
    """
    if sort_col or adv_filters_json:
        raise HTTPException(
            status_code=413,
            detail=(
                f"File '{filename}' is too large to sort or filter in this "
                f"viewer (~{est_bytes // (1024 * 1024)} MB uncompressed, "
                f"snappy-compressed parquet). Browsing pages is supported; "
                f"to sort or filter, query the file through the engine or "
                f"re-save it with zstd compression."
            ),
        )

    # Shared bounded reader (deferred import — router modules load lazily and
    # published_views_api is a sibling API module; at request time it is
    # already imported in-process).
    from api.published_views_api import _read_parquet_page

    offset = (page - 1) * page_size
    page_df, total_rows = _read_parquet_page(
        str(path), columns=None, limit=page_size, offset=offset,
    )
    col_names = page_df.columns.tolist()
    page_df = page_df.where(pd.notnull(page_df), None)
    page_df = _serialize_df(page_df)

    return {
        "columns":       col_names,
        "rows":          page_df.to_dict("records"),
        "total_rows":    total_rows,
        "filtered_rows": total_rows,
        "page":          page,
        "page_size":     page_size,
        "total_pages":   max(1, (total_rows + page_size - 1) // page_size),
        "filename":      filename,
    }


def _close_duckdb_quietly(con):
    """Close a DuckDB connection; a close failure must not replace the answer."""
    try:
        con.close()
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)


def _is_snappy_parquet(path: Path) -> bool:
    """Decide whether a parquet file is snappy-compressed.

    ── Safety check: route snappy-compressed parquet through pandas/PyArrow ──
    DuckDB can segfault on snappy parquet on some platforms/versions.
    Only check FIRST row-group's first column (compression is uniform per file).
    Result is cached in _meta_cache via the "snappy" key.

    A check that could not be MADE answers False: the pandas detour exists
    to dodge a segfault, and taking it for every unreadable footer would
    lose the DuckDB path for reasons that are nothing to do with snappy.
    """
    _snappy_cached = _get_cached_meta(path)
    _is_snappy = _snappy_cached.get("snappy") if _snappy_cached else None
    if _is_snappy is not None:
        return _is_snappy
    try:
        import pyarrow.parquet as _pq_check
        _pf = _pq_check.ParquetFile(str(path))
        _meta = _pf.metadata
        # O(1) check: first column of first row group
        return (
            _meta.num_row_groups > 0
            and _meta.row_group(0).num_columns > 0
            and (_meta.row_group(0).column(0).compression or "").upper() == "SNAPPY"
        )
    except Exception as exc:
        _logger.warning("Snappy compression check failed for %s: %s", path.name, exc, exc_info=True)
        return False


def _paginate_snappy_parquet(path, page, page_size, sort_col, sort_dir,
                             adv_filters_json, filename, _t0):
    """Page a snappy parquet through pandas/PyArrow instead of DuckDB.

    2026-07-31 memory bound: full-file pandas read + RAM cache
    only below the size threshold; large files page through a
    bounded Arrow batch reader (never fully materialised).
    """
    _t_read0 = _time.monotonic()
    df = _get_cached_snappy_df(path)
    _cache_hit = df is not None
    if df is None:
        _est_bytes = _parquet_uncompressed_estimate(path)
        if _est_bytes > _SNAPPY_PANDAS_MAX_BYTES:
            result = _snappy_bounded_paginate(
                path, page, page_size, sort_col, sort_dir,
                adv_filters_json, filename,
                _est_bytes,
            )
            _logger.info(
                "Paginate(snappy,bounded) %s: page=%d est=%.0fMB total=%.0fms rows=%d",
                path.name, page, _est_bytes / (1024 * 1024),
                (_time.monotonic() - _t0) * 1000,
                len(result.get("rows", [])),
            )
            return result
        df = pd.read_parquet(path)
        _set_cached_snappy_df(path, df)
    _t_read1 = _time.monotonic()
    result = _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename)
    _t_read2 = _time.monotonic()
    _logger.info(
        "Paginate(snappy) %s: page=%d cache_hit=%s read=%.0fms paginate=%.0fms total=%.0fms rows=%d",
        path.name, page, _cache_hit,
        (_t_read1 - _t_read0) * 1000, (_t_read2 - _t_read1) * 1000,
        (_t_read2 - _t0) * 1000, len(result.get("rows", [])),
    )
    return result


def _duckdb_schema_and_total(con, source, path, suffix, _is_snappy):
    """Read the file's columns and total row count.

    ── Schema + total_rows: use cache, compute only on first page ────────
    An unreadable schema is a 500, NOT an empty column list: "cannot read"
    and "has no columns" send the reader in opposite directions.
    """
    cached = _get_cached_meta(path)
    if cached:
        return cached["columns"], cached["total_rows"]
    valid_cols = _duckdb_valid_cols(con, source)
    if not valid_cols:
        raise HTTPException(status_code=500, detail="Cannot read file schema")
    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
    _set_cached_meta(path, valid_cols, total_rows)
    # Also cache snappy check result
    with _meta_cache_lock:
        entry = _meta_cache.get(str(path))
        if entry:
            entry["snappy"] = _is_snappy if suffix == ".parquet" else False
    return valid_cols, total_rows


def _duckdb_filtered_count(con, source, path, where_clause, params,
                           adv_filters_json, total_rows):
    """Count the rows the filter leaves.

    Filtered row count — cache per (file, filter) so paging within a
    filter only scans the file once instead of on every page flip.
    """
    if not where_clause:
        return total_rows
    _fkey = adv_filters_json or ""
    filtered_rows = _get_filtered_count_cache(path, _fkey)
    if filtered_rows is None:
        filtered_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}{where_clause}", params).fetchone()[0])
        _set_filtered_count_cache(path, _fkey, filtered_rows)
    return filtered_rows


def _duckdb_projection(requested_cols, valid_cols, sort_col):
    """Decide which columns the page projects.

    ── Column projection ────────────────────────────────────────
    Only project when the caller explicitly requests specific columns.
    Never auto-cap — always return all columns so downloads and
    partition pinning work correctly.  The frontend handles visibility.

    Returns (query_cols, all_columns_meta) -- the second is non-None only
    when the caller's column list matched NOTHING and the full list was
    substituted, which the response then discloses.
    """
    all_columns_meta = None
    if requested_cols:
        # Caller asked for specific columns — validate & use them
        query_cols = [c for c in requested_cols if c in set(valid_cols)]
        if not query_cols:
            query_cols = valid_cols
            all_columns_meta = valid_cols
    else:
        query_cols = valid_cols

    # Ensure sort column is included in projection
    if sort_col and sort_col in valid_cols and sort_col not in query_cols:
        query_cols.append(sort_col)
    return query_cols, all_columns_meta


def _json_safe_cell(val):
    """Convert one DuckDB cell to a JSON-safe value.

    NaN/Inf become None (not JSON-serializable), Decimal becomes float,
    anything with isoformat() becomes its ISO string, bytes become hex.
    """
    if val is None:
        return None
    if isinstance(val, float):
        return None if (_math.isnan(val) or _math.isinf(val)) else val
    if isinstance(val, _Decimal):
        return float(val)
    if hasattr(val, 'isoformat'):
        return val.isoformat()
    if isinstance(val, bytes):
        return val.hex()
    return val


def _serialize_duckdb_rows(col_names, raw_rows):
    """Turn DuckDB's native row tuples into JSON-safe dicts.

    ── Fetch + serialize directly (avoids 4 pandas DataFrame copies) ────
    fetchall() returns Python-native types; we just need to handle
    NaN/Inf floats, datetimes, Decimals, and bytes.
    """
    return [{col_names[j]: _json_safe_cell(val) for j, val in enumerate(raw)}
            for raw in raw_rows]


def _embedded_projection_metadata(path, result):
    """Attach the full column list / auto-partition note that a query-time
    auto-projection embedded in the parquet footer.

    Best-effort: the page is correct without it.
    """
    # Also check for embedded metadata from query-time auto-projection.
    try:
        import pyarrow.parquet as _pq_meta
        _pf_meta = _pq_meta.read_metadata(str(path))
        _file_meta = _pf_meta.schema.to_arrow_schema().metadata or {}
        _ac_bytes = _file_meta.get(b"all_columns")
        if _ac_bytes:
            result["all_columns"] = json.loads(_ac_bytes)
            result["column_projection_applied"] = True
            result["total_column_count"] = len(result["all_columns"])
        _ap_bytes = _file_meta.get(b"auto_partition")
        if _ap_bytes:
            result["auto_partition"] = json.loads(_ap_bytes)
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)


def _pandas_fallback_page(path, suffix, page, page_size, sort_col, sort_dir,
                          adv_filters_json, filename, _duck_err):
    """Page a file with pandas after DuckDB refused it.

    Raises for a format pandas cannot read here rather than answering an
    empty page -- an empty page reads as "the file has no rows".
    """
    # DuckDB raised a Python exception — fall back to pandas/PyArrow
    import logging as _lg
    _lg.getLogger(__name__).warning("DuckDB read failed (%s), falling back to pandas: %s", path.name, _duck_err, exc_info=True)
    if suffix == ".parquet":
        df = pd.read_parquet(path)
    elif suffix in (".csv", ".txt"):
        df = pd.read_csv(path)
    else:
        raise HTTPException(status_code=500, detail=f"Cannot read file: {_duck_err}")
    return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename)


def _duckdb_page_body(con, source, path, suffix, page, page_size, sort_col,
                      sort_dir, adv_filters_json, filename, requested_cols,
                      _is_snappy, _t0, _t1):
    """Build one page with DuckDB: schema, filter, projection, rows."""
    valid_cols, total_rows = _duckdb_schema_and_total(
        con, source, path, suffix, _is_snappy)

    where_clause, params = _build_where(adv_filters_json, valid_cols)

    order_clause = ""
    if sort_col and sort_col in valid_cols:
        direction = "ASC" if sort_dir == "asc" else "DESC"
        order_clause = f' ORDER BY {_q(sort_col)} {direction}'

    offset = (page - 1) * page_size

    filtered_rows = _duckdb_filtered_count(
        con, source, path, where_clause, params, adv_filters_json, total_rows)

    _t2 = _time.monotonic()

    query_cols, all_columns_meta = _duckdb_projection(
        requested_cols, valid_cols, sort_col)

    if len(query_cols) < len(valid_cols):
        col_list = ', '.join(_q(c) for c in query_cols)
        data_sql = f"SELECT {col_list} FROM {source}{where_clause}{order_clause} LIMIT {page_size} OFFSET {offset}"
    else:
        data_sql = f"SELECT * FROM {source}{where_clause}{order_clause} LIMIT {page_size} OFFSET {offset}"

    cursor = con.execute(data_sql, params)
    col_names = [desc[0] for desc in cursor.description]
    raw_rows = cursor.fetchall()
    _t3 = _time.monotonic()

    rows = _serialize_duckdb_rows(col_names, raw_rows)

    result = {
        "columns":       query_cols,
        "rows":          rows,
        "total_rows":    total_rows,
        "filtered_rows": filtered_rows,
        "page":          page,
        "page_size":     page_size,
        "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
        "filename":      filename,
    }

    # ── Wide-table metadata ───────────────────────────────────────
    # When we auto-projected, tell the frontend the full column list.
    if all_columns_meta:
        result["all_columns"] = all_columns_meta
        result["column_projection_applied"] = True
        result["total_column_count"] = len(all_columns_meta)

    if suffix == ".parquet" and page == 1 and not all_columns_meta:
        _embedded_projection_metadata(path, result)

    _t4 = _time.monotonic()
    _projected = len(query_cols) < len(valid_cols)
    _logger.info(
        "Paginate %s: page=%d snappy=%.0fms meta=%.0fms query=%.0fms serialize=%.0fms total=%.0fms rows=%d cols=%d/%d%s",
        path.name, page,
        (_t1 - _t0) * 1000, (_t2 - _t1) * 1000,
        (_t3 - _t2) * 1000, (_t4 - _t3) * 1000,
        (_t4 - _t0) * 1000, len(rows), len(query_cols), len(valid_cols),
        " (projected)" if _projected else "",
    )
    return result


def _duckdb_paginate(
    path: Path,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
    requested_cols: Optional[list] = None,
) -> dict:
    """
    DuckDB-powered pagination — works for CSV, Parquet, JSON of any size.
    Uses pushdown predicates; never loads the full file into Python RAM.
    Falls back to pandas for Excel (.xlsx/.xls).
    """
    suffix = path.suffix.lower()
    filename = filename_hint or path.name

    # Excel: DuckDB can't read natively
    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename)

    if not _DUCKDB_AVAILABLE:
        # Fallback to pandas (limited to files that fit in RAM)
        df = pd.read_parquet(path) if suffix == ".parquet" else pd.read_csv(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename)

    # Empty file → execution produced 0 rows.  Return an empty-but-valid response
    # instead of letting DuckDB fail on a schema-less file.
    if path.stat().st_size == 0:
        return {
            "columns":       [],
            "rows":          [],
            "total_rows":    0,
            "filtered_rows": 0,
            "page":          page,
            "page_size":     page_size,
            "total_pages":   1,
            "filename":      filename,
        }

    _t0 = _time.monotonic()

    _is_snappy = False
    if suffix == ".parquet":
        _is_snappy = _is_snappy_parquet(path)
        if _is_snappy:
            return _paginate_snappy_parquet(
                path, page, page_size, sort_col, sort_dir,
                adv_filters_json, filename, _t0)

    _t1 = _time.monotonic()

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        return _duckdb_page_body(
            con, source, path, suffix, page, page_size, sort_col, sort_dir,
            adv_filters_json, filename, requested_cols, _is_snappy, _t0, _t1)
    except HTTPException:
        raise
    except Exception as _duck_err:
        return _pandas_fallback_page(
            path, suffix, page, page_size, sort_col, sort_dir,
            adv_filters_json, filename, _duck_err)
    finally:
        _close_duckdb_quietly(con)


def _pandas_numeric_mask(df, col, op, val):
    """Build a numeric comparison mask; None when the value is not numeric.

    NOTE the asymmetry with the DuckDB path: this is the Excel /
    DuckDB-unavailable fallback and it SKIPS an unrenderable condition,
    which is what it has always done.
    """
    try:
        nval   = float(val)
        numcol = pd.to_numeric(df[col], errors="coerce")
        sym_fn = {"gt": numcol.__gt__, "gte": numcol.__ge__,
                  "lt": numcol.__lt__, "lte": numcol.__le__}[op]
        return sym_fn(nval).fillna(False)
    except (ValueError, TypeError):
        return None


def _pandas_filter_mask(df, cond):
    """Build ONE pandas boolean mask for a grid filter condition.

    None means "no mask" -- an unknown column or an unrenderable value.
    """
    col = cond.get("col", "")
    op  = cond.get("op", "contains")
    val = str(cond.get("val", ""))
    if col not in df.columns:
        return None
    s = df[col].astype(str)
    if op == "contains":
        return s.str.contains(val, case=False, na=False)
    if op == "not_contains":
        return ~s.str.contains(val, case=False, na=False)
    if op == "equals":
        return s.str.lower() == val.lower()
    if op == "not_equals":
        return s.str.lower() != val.lower()
    if op == "starts_with":
        return s.str.startswith(val, na=False)
    if op == "ends_with":
        return s.str.endswith(val, na=False)
    if op in ("gt", "gte", "lt", "lte"):
        return _pandas_numeric_mask(df, col, op, val)
    if op == "is_null":
        return df[col].isna()
    if op == "is_not_null":
        return df[col].notna()
    return None


def _pandas_apply_adv_filters(df, adv_filters_json):
    """Combine every renderable condition's mask and filter the frame."""
    try:
        af = json.loads(adv_filters_json)
        conjunction = af.get("conjunction", "AND").upper()
        masks = []
        for cond in af.get("conditions", []):
            _m = _pandas_filter_mask(df, cond)
            if _m is not None:
                masks.append(_m)
        if masks:
            combined = masks[0]
            for m in masks[1:]:
                combined = (combined | m) if conjunction == "OR" else (combined & m)
            df = df[combined]
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)
    return df


def _pandas_paginate(
    df: pd.DataFrame,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
) -> dict:
    """Pandas pagination (Excel files or DuckDB-unavailable fallback)."""
    total_rows = len(df)

    if adv_filters_json:
        df = _pandas_apply_adv_filters(df, adv_filters_json)

    filtered_rows = len(df)
    if sort_col and sort_col in df.columns:
        df = df.sort_values(by=sort_col, ascending=(sort_dir == "asc"))

    start   = (page - 1) * page_size
    page_df = df.iloc[start: start + page_size]
    page_df = page_df.where(pd.notnull(page_df), None)
    page_df = _serialize_df(page_df)

    return {
        "columns":       df.columns.tolist(),
        "rows":          page_df.to_dict("records"),
        "total_rows":    total_rows,
        "filtered_rows": filtered_rows,
        "page":          page,
        "page_size":     page_size,
        "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
        "filename":      filename_hint,
    }


def _sort_labels(labels: list[str]) -> list[str]:
    """Sort labels chronologically when they look like months/quarters/dates."""
    import re as _re
    if not labels:
        return labels
    # Guard against None / non-string values
    if any(not isinstance(_lb, str) for _lb in labels):
        return labels
    _SHORT = {"jan":0,"feb":1,"mar":2,"apr":3,"may":4,"jun":5,
              "jul":6,"aug":7,"sep":8,"oct":9,"nov":10,"dec":11}
    _LONG  = {"january":0,"february":1,"march":2,"april":3,"may":4,"june":5,
              "july":6,"august":7,"september":8,"october":9,"november":10,"december":11}
    MONTH_ORDER = {**_LONG, **_SHORT}  # short names take priority
    QUARTER_ORDER = {"q1": 1, "q2": 2, "q3": 3, "q4": 4}
    # Try month names (Jan, February, etc.)
    lower = [_lb.lower().strip() for _lb in labels]
    if all(_lb in MONTH_ORDER for _lb in lower):
        return sorted(labels, key=lambda x: MONTH_ORDER[x.lower().strip()])
    # Try quarters (Q1, Q2, ...)
    if all(_lb in QUARTER_ORDER for _lb in lower):
        return sorted(labels, key=lambda x: QUARTER_ORDER[x.lower().strip()])
    # Try ISO-ish dates: YYYY-MM, YYYY-MM-DD, YYYY/MM, etc.
    iso_pat = _re.compile(r"^\d{4}[-/]\d{1,2}([-/]\d{1,2})?$")
    if all(iso_pat.match(_lb) for _lb in labels):
        # Normalize to tuple for correct sorting of un-zero-padded months
        def _iso_key(lbl):
            parts = _re.split(r"[-/]", lbl)
            return tuple(int(p) for p in parts)
        return sorted(labels, key=_iso_key)
    # Try "Mon YYYY" or "YYYY Mon"
    mon_year = _re.compile(r"^([a-zA-Z]+)\s+(\d{4})$|^(\d{4})\s+([a-zA-Z]+)$")
    def _mon_year_key(lbl):
        m = mon_year.match(lbl.strip())
        if not m:
            return (9999, 99)
        if m.group(1):  # Mon YYYY
            mon, yr = m.group(1).lower(), int(m.group(2))
        else:            # YYYY Mon
            yr, mon = int(m.group(3)), m.group(4).lower()
        return (yr, MONTH_ORDER.get(mon, 99))
    if all(mon_year.match(_lb.strip()) for _lb in labels):
        # Only apply if at least one label contains a known month name
        all_mons = [_re.match(r"^([a-zA-Z]+)", _lb.strip()).group(1).lower() for _lb in labels]
        if any(m in MONTH_ORDER for m in all_mons):
            return sorted(labels, key=_mon_year_key)
    return labels


def _require_chart_columns(available, x_col, y_col, series_col):
    """Refuse a chart request naming a column the file does not have.

    A 400 naming the column, never a silently empty chart.
    """
    if x_col not in available:
        raise HTTPException(status_code=400, detail=f"Column '{x_col}' not found")
    if y_col not in available:
        raise HTTPException(status_code=400, detail=f"Column '{y_col}' not found")
    if series_col and series_col not in available:
        raise HTTPException(status_code=400, detail=f"Column '{series_col}' not found")


def _empty_chart_payload(x_col, y_col, agg, series_col):
    """The zero-row chart answer, shaped like the real one so the UI renders."""
    base = {"x_col": x_col, "y_col": y_col, "agg": agg,
            "total_rows": 0, "groups": 0, "grand_total": 0.0, "data": []}
    if series_col:
        base.update({"multi": True, "series_col": series_col, "series": []})
    else:
        base["multi"] = False
    return base


def _pivot_series_rows(pivot, top_series):
    """Turn a label x series pivot into the per-label row dicts the UI reads.

    A series missing for a label is None, NOT 0 -- 0 is a measurement and
    would draw a line through the axis for data that does not exist.
    """
    data = []
    for label in pivot.index:
        row_dict = {"label": str(label)}
        for s in top_series:
            if s in pivot.columns:
                v = pivot.loc[label, s]
                row_dict[s] = None if pd.isna(v) else float(v)
            else:
                row_dict[s] = None
        data.append(row_dict)
    return data


def _duckdb_multi_series_chart(con, source, x_col, y_col, series_col, agg_fn,
                               agg, top_n, max_series, total_rows, groups_cnt):
    """Aggregate a multi-series chart in DuckDB, then pivot in pandas."""
    # Find top N series by total aggregated value
    top_series_sql = f"""
        SELECT COALESCE(CAST({_q(series_col)} AS VARCHAR), '(blank)'),
               {agg_fn}(TRY_CAST({_q(y_col)} AS DOUBLE)) AS total
        FROM {source}
        GROUP BY 1 ORDER BY total DESC NULLS LAST LIMIT {max_series}
    """
    top_series = [str(r[0]) for r in con.execute(top_series_sql).fetchall()]

    # Aggregate grouped by x_col + series_col
    agg_sql = f"""
        SELECT CAST({_q(x_col)} AS VARCHAR),
               COALESCE(CAST({_q(series_col)} AS VARCHAR), '(blank)'),
               {agg_fn}(TRY_CAST({_q(y_col)} AS DOUBLE))
        FROM {source}
        GROUP BY 1, 2
    """
    raw_df = con.execute(agg_sql).fetchdf()
    raw_df.columns = ["label", "series", "value"]

    # Filter to top series only
    raw_df = raw_df[raw_df["series"].isin(top_series)]

    # Pivot: rows=label, columns=series, values=value
    # Use None for missing combos (semantically correct for avg/min/max)
    pivot = raw_df.pivot_table(index="label", columns="series",
                               values="value", aggfunc="sum")

    # Sort labels chronologically if possible
    sorted_labels = _sort_labels(pivot.index.tolist())
    pivot = pivot.reindex(sorted_labels)

    # Limit to top_n labels
    pivot = pivot.head(top_n)

    grand_total = float(pivot.values[~pd.isna(pivot.values)].sum()) if pivot.size > 0 else 0.0
    data = _pivot_series_rows(pivot, top_series)

    return {
        "x_col": x_col, "y_col": y_col, "agg": agg,
        "series_col": series_col, "series": top_series, "multi": True,
        "total_rows": total_rows, "groups": groups_cnt,
        "grand_total": grand_total, "data": data,
    }


def _duckdb_single_series_chart(con, source, x_col, y_col, agg_fn, agg, top_n,
                                total_rows, groups_cnt):
    """Aggregate a single-series chart entirely in DuckDB."""
    agg_sql = f"""
        SELECT
            CAST({_q(x_col)} AS VARCHAR) AS label,
            {agg_fn}(TRY_CAST({_q(y_col)} AS DOUBLE)) AS value,
            COUNT(*) AS cnt
        FROM {source}
        GROUP BY {_q(x_col)}
        ORDER BY value DESC NULLS LAST
        LIMIT {top_n}
    """
    result_df   = con.execute(agg_sql).fetchdf()
    grand_total = float(result_df["value"].sum()) if len(result_df) > 0 else 0.0

    data = []
    for _, row in result_df.iterrows():
        v = None if pd.isna(row["value"]) else float(row["value"])
        data.append({
            "label": str(row["label"]),
            "value": v,
            "count": int(row["cnt"]),
            "pct":   round(v / grand_total * 100, 2) if grand_total and v is not None else 0,
        })

    return {"x_col": x_col, "y_col": y_col, "agg": agg, "multi": False,
            "total_rows": total_rows, "groups": groups_cnt, "grand_total": grand_total, "data": data}


def _duckdb_chart(path: Path, x_col: str, y_col: str, agg: str, top_n: int,
                  series_col: str = None, max_series: int = 10) -> dict:
    """DuckDB-powered chart aggregation — full scan, server-side groupby.
    When series_col is provided, returns multi-series pivoted data."""
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name, series_col, max_series)

    if not _DUCKDB_AVAILABLE:
        df = pd.read_parquet(path) if suffix == ".parquet" else pd.read_csv(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name, series_col, max_series)

    if path.stat().st_size == 0:
        return _empty_chart_payload(x_col, y_col, agg, series_col)

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        valid_cols = set(_duckdb_valid_cols(con, source))
        _require_chart_columns(valid_cols, x_col, y_col, series_col)

        agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(agg, "SUM")
        total_rows  = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
        groups_cnt  = int(con.execute(f'SELECT COUNT(DISTINCT CAST({_q(x_col)} AS VARCHAR)) FROM {source}').fetchone()[0])

        # ── Multi-series path ──
        if series_col:
            return _duckdb_multi_series_chart(
                con, source, x_col, y_col, series_col, agg_fn, agg, top_n,
                max_series, total_rows, groups_cnt)

        # ── Single-series path (unchanged) ──
        return _duckdb_single_series_chart(
            con, source, x_col, y_col, agg_fn, agg, top_n, total_rows, groups_cnt)
    finally:
        con.close()


def _pandas_multi_series_chart(df, x_col, y_col, agg, agg_func, top_n,
                               series_col, max_series, total_rows):
    """Aggregate and pivot a multi-series chart in pandas."""
    if df.empty:
        return {"x_col": x_col, "y_col": y_col, "agg": agg,
                "series_col": series_col, "series": [], "multi": True,
                "total_rows": 0, "groups": 0, "grand_total": 0.0, "data": []}
    df[series_col] = df[series_col].fillna("(blank)").astype(str)
    df[x_col] = df[x_col].astype(str)

    # Top N series by total value
    series_totals = df.groupby(series_col)[y_col].agg(agg_func).sort_values(ascending=False)
    top_series = series_totals.head(max_series).index.tolist()
    df_filtered = df[df[series_col].isin(top_series)]

    # Pivot — leave NaN for missing combos (correct for avg/min/max)
    pivot = df_filtered.pivot_table(index=x_col, columns=series_col,
                                     values=y_col, aggfunc=agg_func)
    groups_cnt = len(pivot)
    sorted_labels = _sort_labels(pivot.index.tolist())
    pivot = pivot.reindex(sorted_labels).head(top_n)
    grand_total = float(pivot.values[~pd.isna(pivot.values)].sum()) if pivot.size > 0 else 0.0

    data = _pivot_series_rows(pivot, top_series)

    return {
        "x_col": x_col, "y_col": y_col, "agg": agg,
        "series_col": series_col, "series": top_series, "multi": True,
        "total_rows": total_rows, "groups": groups_cnt,
        "grand_total": grand_total, "data": data,
    }


def _pandas_chart(df: pd.DataFrame, x_col: str, y_col: str, agg: str, top_n: int, name: str,
                   series_col: str = None, max_series: int = 10) -> dict:
    _require_chart_columns(df.columns, x_col, y_col, series_col)

    df[y_col] = pd.to_numeric(df[y_col], errors="coerce")
    total_rows = len(df)
    agg_map = {"sum": "sum", "avg": "mean", "max": "max", "min": "min", "count": "count"}
    agg_func = agg_map.get(agg, "sum")

    # ── Multi-series path ──
    if series_col:
        return _pandas_multi_series_chart(
            df, x_col, y_col, agg, agg_func, top_n, series_col, max_series,
            total_rows)

    # ── Single-series path (unchanged) ──
    grouped = df.groupby(x_col, dropna=False)
    agg_s   = getattr(grouped[y_col], agg_func)()
    cnt_s   = grouped[y_col].count()
    res     = pd.DataFrame({"label": agg_s.index.astype(str), "value": agg_s.values, "count": cnt_s.values})\
                .sort_values("value", ascending=False).head(top_n)
    total   = float(res["value"].sum())
    return {
        "x_col": x_col, "y_col": y_col, "agg": agg, "multi": False,
        "total_rows": total_rows, "groups": len(agg_s), "grand_total": total,
        "data": [
            {"label": r["label"],
             "value": None if pd.isna(r["value"]) else float(r["value"]),
             "count": int(r["count"]),
             "pct":   round(float(r["value"]) / total * 100, 2) if total and not pd.isna(r["value"]) else 0}
            for _, r in res.iterrows()
        ],
    }


# ═══════════════════════════════════════════════════════════════════
# Paginated results — execution (1M+ rows supported via DuckDB)
# ═══════════════════════════════════════════════════════════════════
def _pending_page_payload(page: int, page_size: int) -> dict:
    """The "still running, no rows yet" page body.

    Shaped like a real page so the grid renders and RETRIES, rather than
    caching an empty result as the answer.
    """
    return {
        "status": "pending",
        "columns": [], "rows": [],
        "total_rows": 0, "page": page,
        "page_size": page_size, "total_pages": 0,
    }


async def _execution_status_record(execution_id: str) -> Optional[dict]:
    """Read the execution row for a status check; None when unreadable."""
    try:
        _db_pre = _get_db()
        return (await asyncio.to_thread(_db_pre.get_execution, execution_id)) if _db_pre else None
    except Exception:
        return None


async def _assert_token_scope(execution_id: str, user: dict) -> None:
    """Bind a share-token viewer to EXACTLY the execution it launched.

    The broad service-prefix grant in ``_enforce_execution_ownership`` is
    for authenticated users only, never for one share link reading
    another's data.
    """
    if not is_token_principal(user):
        return
    _tok_exec = await asyncio.to_thread(
        (lambda: (_get_db().get_execution(execution_id) if _get_db() else None)))
    assert_execution_visible_to_token(user, _tok_exec)


async def _paginated_page_response(path, page, page_size, sort_column,
                                   sort_direction, effective_adv, _req_cols,
                                   filename: str = "",
                                   error_prefix: str = "Error reading file"):
    """Page a file off the event loop and wrap the result as a JSON response.

    ``error_prefix`` keeps each route's own 500 message: the three callers
    said "Error reading results" / "Error reading file", and a shared
    helper must not quietly re-word what a caller reports.
    """
    try:
        result = await _aduckdb(lambda: _duckdb_paginate(
            path, page, page_size, sort_column, sort_direction or "asc",
            effective_adv, filename, requested_cols=_req_cols))
        return _JSONResp(content=result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{error_prefix}: {str(e)}")


async def _find_result_file_with_retry(execution_id: str) -> Optional[Path]:
    """Find the result file, retrying briefly for a late DB commit.

    BF-54: Retry with increasing delays — cross-source background tasks
    write the file and update DB asynchronously; the frontend may fetch
    results slightly before the DB commit is visible.
    """
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if csv_file:
        return csv_file
    import asyncio as _aio
    for _retry_delay in (0.5, 1.0, 1.5):
        await _aio.sleep(_retry_delay)
        csv_file = await asyncio.to_thread(find_csv_file, execution_id)
        if csv_file:
            return csv_file
    return None




@router.get("/api/executions/{execution_id}/results")
async def get_paginated_results(
    execution_id:   str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=5000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy per-column
    columns:        Optional[str] = None,   # comma-separated column names for wide-table projection
    user: dict      = Depends(require_capability("bqb.view", identity=require_execution_read_access)),
):
    """Paginated results with DuckDB — handles any file size.

    Phase 131 deep-dive #13 (round 3): enforces execution ownership —
    user must be the executor, an admin, or the execution must be a
    service identity (PV / embed / shared / scheduled / system).

    2026-08-23: the dependency is ``require_execution_read_access`` (not
    ``get_current_user``) so the anonymous SharedDashboardPage /
    SharedQueryPage viewer can read the rows of the widget it just executed
    via its share token.  A token viewer is then bound to EXACTLY the
    execution it launched (``assert_execution_visible_to_token``) — the broad
    service-prefix grant in ``_enforce_execution_ownership`` is for
    authenticated users only, never for one share link reading another's data.

    DELIBERATELY NOT SPLIT FURTHER (2026-09-12): the status gate, the
    progressive-serving attempt, the pending sentinel and the terminal-state
    answers stay INLINE here because
    ``test_progressive_results_2026_07_31::TestStructuralWiring`` asserts
    their ORDER in this function's source -- progressive serving strictly
    between the running gate and the sentinel, never reachable from
    failed/cancelled.  Extracting them would leave that guard unable to
    fail.  Everything that is not part of that ordering invariant has been
    extracted.
    """
    # Offloaded off the event loop: ownership does a sync SQLite read
    # (busy_timeout 30s) that would otherwise block health probes under
    # load.  See backend/docs/event_loop_blocking_audit.md (P0-A).
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    await _assert_token_scope(execution_id, user)
    # BF-265: status check FIRST.  When a query is mid-write the parquet
    # file exists but the writer hasn't called .close() yet, so the footer
    # isn't finalised — readers see 0 rows.  Without this gate the grid
    # would receive `{rows: []}` for a still-running query, cache it, and
    # never refresh.  Symptom: "first run empty, second run works".  If
    # the DB still says pending/running we return the same pending
    # sentinel as the missing-file branch below regardless of what
    # find_csv_file reports.
    _exec_pre = await _execution_status_record(execution_id)
    if _exec_pre and _exec_pre.get("status") in ("pending", "processing", "running"):
        # Progressive delivery (2026-07-31, flag OFF by default): while the
        # execution is still RUNNING, serve pages that are fully covered by
        # SEALED spool segments (footer-valid by construction — manifest is
        # written only after each segment writer closes, so BF-265's
        # mid-write-footer hazard cannot occur).  Deliberately INSIDE the
        # running-status gate: terminal states keep today's paths, so a
        # partially-spooled failed query can never present as complete.
        # Sort/filter on partial data would mislead → those requests keep
        # the pending sentinel.  Any error → pending sentinel (fail-open).
        if not sort_column and not adv_filters and not filters:
            try:
                from core.progressive_results import serve_page_if_available as _prog_serve
                _prog_page = await asyncio.to_thread(
                    _prog_serve, execution_id, page, page_size, columns)
                if _prog_page is not None:
                    return _JSONResp(content=_prog_page)
            except Exception as _prog_err:
                _logger.debug("progressive serve failed (fail-open): %s", _prog_err)
        return _JSONResp(content={
            "status": "pending",
            "columns": [], "rows": [],
            "total_rows": 0, "page": page,
            "page_size": page_size, "total_pages": 0,
        })

    csv_file = await _find_result_file_with_retry(execution_id)
    if not csv_file:
        _rec = await _execution_status_record(execution_id)
        # BF-167: Distinguish dedup shadow executions (pending, waiting for primary)
        # from truly missing results. Return 200 {status:"pending"} so DataGridViewer
        # auto-retries rather than showing a permanent "not found" error.
        if _rec and _rec.get("status") in ("pending", "running"):
            return _JSONResp(content=_pending_page_payload(page, page_size))
        # BF-238: Failed executions returned 404, causing the frontend to
        # poll for 30+ seconds (each /results retry is 3s).  The user never
        # saw the actual error or the agent's auto-fix suggestion.  Return
        # 200 {status:"failed", error:...} so the UI can render the error
        # immediately and stop polling.
        if _rec and _rec.get("status") in ("failed", "cancelled"):
            return _JSONResp(content={
                "status": _rec.get("status"),
                "error":  _rec.get("error_message") or "",
                "columns": [], "rows": [],
                "total_rows": 0, "page": page,
                "page_size": page_size, "total_pages": 0,
            })
        raise HTTPException(status_code=404, detail="Results file not found")

    _req_cols = [c.strip() for c in columns.split(",") if c.strip()] if columns else None
    effective_adv = _effective_adv_filters(adv_filters, filters)

    return await _paginated_page_response(
        csv_file, page, page_size, sort_column, sort_direction,
        effective_adv, _req_cols, error_prefix="Error reading results")


# ═══════════════════════════════════════════════════════════════════
# Chart data — full dataset aggregation (DuckDB)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/chart-data")
async def get_chart_data(
    execution_id: str,
    x_col: str,
    y_col: str,
    agg:        str           = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:      int           = Query(50, ge=1, le=500),
    series_col: Optional[str] = None,
    max_series: int           = Query(10, ge=1, le=20),
    user: dict                = Depends(require_capability("bqb.view")),
):
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    try:
        return await _aduckdb(lambda: _duckdb_chart(csv_file, x_col, y_col, agg, top_n, series_col, max_series))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Pivot Table — Excel-style multi-row, col-field, multi-value
# ═══════════════════════════════════════════════════════════════════

_AGG_MAP = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN",
            "count": "COUNT", "count_distinct": "COUNT(DISTINCT",
            "median": "MEDIAN", "stddev": "STDDEV_SAMP",
            "variance": "VAR_SAMP"}


#: Every function a pivot value may ask for -- ONE vocabulary, read by the
#: normaliser below.  ``count_rows`` is COUNT(*) and needs no column.
_PIVOT_FUNCTIONS = frozenset(_AGG_MAP) | {"count_rows"}


def _normalise_pivot_functions(values: list) -> list:
    """ONE reading of a pivot value's ``function`` (2026-10-25).

    The UI sends lower case (``sum``, ``count``, ``count_rows``); the
    pre-aggregation guard beside this lower-cased what it read, while the
    renderers looked the spelling up EXACTLY and fell back to ``SUM`` on a
    miss -- so an API caller asking ``COUNT`` (or any word outside the
    vocabulary) was answered the SUM of the column as if it were the count,
    behind a 200.  A number nobody asked for is a correctness defect, not a
    default: the spelling is normalised here, once, for the guard and the
    renderers alike, and a function the vocabulary lacks is a 400 naming it.
    """
    out = []
    for v in values or []:
        raw = (v or {}).get("function")
        fn = str(raw or "sum").strip().lower()
        if fn not in _PIVOT_FUNCTIONS:
            raise HTTPException(
                status_code=400,
                detail=(f"Unknown pivot function {raw!r}. Accepted: "
                        f"{', '.join(sorted(_PIVOT_FUNCTIONS))}."))
        out.append({**v, "function": fn})
    return out


def _pivot_validate_fields(valid_cols, row_fields, col_field, values):
    """Refuse a pivot naming a field the file does not have.

    ``count_rows`` needs no column, so its value entry is exempt.
    """
    for rf in row_fields:
        if rf not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Row field '{rf}' not found")
    if col_field and col_field not in valid_cols:
        raise HTTPException(status_code=400, detail=f"Column field '{col_field}' not found")
    for v in values:
        if v["function"] != "count_rows" and v["column"] not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Value column '{v['column']}' not found")


def _pivot_value_agg(v, alias):
    """Build ONE plain aggregate expression for a pivot value field.

    Serves both the simple-pivot value list and the cross-tab's row totals
    -- they were two byte-identical copies.
    """
    fn = v["function"]
    col = v.get("column", "*")
    if fn == "count_rows":
        return f"COUNT(*) AS {alias}"
    if fn == "count_distinct":
        return f'COUNT(DISTINCT {_q(col)}) AS {alias}'
    # normalised by _normalise_pivot_functions: a miss here is a programming
    # error, never a silent SUM
    sql_fn = _AGG_MAP[fn]
    return f'{sql_fn}(TRY_CAST({_q(col)} AS DOUBLE)) AS {alias}'


def _pivot_case_agg(v, alias, col_field, escaped):
    """Build ONE conditional aggregate for a single cross-tab column value."""
    fn = v["function"]
    col = v.get("column", "*")
    if fn == "count_rows":
        return f"COUNT(CASE WHEN CAST({_q(col_field)} AS VARCHAR)='{escaped}' THEN 1 END) AS {alias}"
    if fn == "count_distinct":
        return f"COUNT(DISTINCT CASE WHEN CAST({_q(col_field)} AS VARCHAR)='{escaped}' THEN {_q(col)} END) AS {alias}"
    sql_fn = _AGG_MAP[fn]          # normalised upstream (see _normalise_pivot_functions)
    return f"{sql_fn}(CASE WHEN CAST({_q(col_field)} AS VARCHAR)='{escaped}' THEN TRY_CAST({_q(col)} AS DOUBLE) END) AS {alias}"


def _pivot_value_aggs(values):
    """Build the plain aggregate expressions and their aliases, in order."""
    # Build aggregation expressions
    agg_exprs = []
    agg_aliases = []
    for i, v in enumerate(values):
        alias = f"val_{i}"
        agg_exprs.append(_pivot_value_agg(v, alias))
        agg_aliases.append(alias)
    return agg_exprs, agg_aliases


def _pivot_cell(raw):
    """Round one pivot cell to 4dp; a null cell stays null.

    ``pd.isna(None)`` is True, so the two spellings this replaces
    (``not pd.isna(raw)`` and ``raw is not None and not pd.isna(raw)``)
    always agreed; this is the explicit one.
    """
    if raw is None or pd.isna(raw):
        return None
    return round(float(raw), 4)


def _pivot_simple_rows(df, row_fields, values):
    """Project a simple pivot's result frame into the row dicts the UI reads."""
    rows = []
    for _, r in df.iterrows():
        row_key = {rf: str(r[rf]) if not pd.isna(r[rf]) else "(blank)" for rf in row_fields}
        vals = {}
        for i, v in enumerate(values):
            vals[f"val_{i}"] = _pivot_cell(r[f"val_{i}"])
        row_key["_values"] = vals
        row_key["_count"] = int(r["_row_count"])
        rows.append(row_key)
    return rows


def _pivot_simple(con, source, row_fields, values, top_n, total_rows):
    """── Simple pivot: GROUP BY row_fields, multiple agg values ──"""
    agg_exprs, agg_aliases = _pivot_value_aggs(values)
    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
    group_by = ", ".join(_q(rf) for rf in row_fields)
    agg_str = ", ".join(agg_exprs)

    sql = f"""
        SELECT {group_cols}, {agg_str}, COUNT(*) AS _row_count
        FROM {source}
        GROUP BY {group_by}
        ORDER BY {agg_aliases[0]} DESC NULLS LAST
        LIMIT {top_n}
    """
    df = con.execute(sql).fetchdf()

    rows = _pivot_simple_rows(df, row_fields, values)

    # Grand totals
    gt_sql = f"SELECT {', '.join(agg_exprs)}, COUNT(*) AS _row_count FROM {source}"
    gt_row = con.execute(gt_sql).fetchone()
    grand_totals = {}
    for i in range(len(values)):
        grand_totals[f"val_{i}"] = _pivot_cell(gt_row[i])
    grand_totals["_count"] = int(gt_row[-1])

    return {"row_fields": row_fields, "col_field": None, "values": values,
            "total_rows": total_rows, "rows": rows,
            "col_values": [], "grand_totals": grand_totals}


def _pivot_crosstab_rows(df, row_fields, col_values, values):
    """Project a cross-tab's result frame into per-row cells and row totals."""
    rows = []
    for _, r in df.iterrows():
        row_data = {rf: str(r[rf]) if not pd.isna(r[rf]) else "(blank)" for rf in row_fields}
        cells = {}
        for ci, cv in enumerate(col_values):
            cells[cv] = {f"val_{vi}": _pivot_cell(r[f"c{ci}_v{vi}"])
                         for vi in range(len(values))}
        row_totals = {f"val_{vi}": _pivot_cell(r[f"total_v{vi}"])
                      for vi in range(len(values))}
        row_data["_cells"] = cells
        row_data["_totals"] = row_totals
        row_data["_count"] = int(r["_row_count"])
        rows.append(row_data)
    return rows


def _pivot_crosstab_grand_totals(gt_row, col_values, values):
    """Read the cross-tab grand-total row POSITIONALLY.

    The single SELECT emits every (col_value, value) cell first and then the
    row totals, in exactly the order the aggregate list was built -- so the
    index walk below must stay in step with _pivot_crosstab's SQL.
    """
    grand_totals = {"_cells": {}, "_totals": {}}
    idx = 0
    for ci, cv in enumerate(col_values):
        cell_vals = {}
        for vi in range(len(values)):
            cell_vals[f"val_{vi}"] = _pivot_cell(gt_row[idx])
            idx += 1
        grand_totals["_cells"][cv] = cell_vals
    for vi in range(len(values)):
        grand_totals["_totals"][f"val_{vi}"] = _pivot_cell(gt_row[idx])
        idx += 1
    grand_totals["_count"] = int(gt_row[idx])
    return grand_totals


def _pivot_crosstab(con, source, row_fields, col_field, values, top_n,
                    total_rows):
    """── Cross-tab pivot: GROUP BY row_fields + col_field ──"""
    # First get distinct col_field values (top by frequency)
    col_vals_sql = f"""
        SELECT CAST({_q(col_field)} AS VARCHAR) AS cv, COUNT(*) AS cnt
        FROM {source}
        WHERE {_q(col_field)} IS NOT NULL
        GROUP BY {_q(col_field)}
        ORDER BY cnt DESC
        LIMIT 50
    """
    cv_df = con.execute(col_vals_sql).fetchdf()
    col_values = [str(v) for v in cv_df["cv"].tolist()]

    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
    group_by = ", ".join(_q(rf) for rf in row_fields)

    # Build per-col-value aggregations
    case_aggs = []
    for ci, cv in enumerate(col_values):
        escaped = cv.replace("'", "''")
        for vi, v in enumerate(values):
            case_aggs.append(_pivot_case_agg(v, f"c{ci}_v{vi}", col_field, escaped))

    # Also add row totals (across all col values)
    row_total_aggs = [_pivot_value_agg(v, f"total_v{vi}")
                      for vi, v in enumerate(values)]

    all_aggs = ", ".join(case_aggs + row_total_aggs)
    sql = f"""
        SELECT {group_cols}, {all_aggs}, COUNT(*) AS _row_count
        FROM {source}
        GROUP BY {group_by}
        ORDER BY total_v0 DESC NULLS LAST
        LIMIT {top_n}
    """
    df = con.execute(sql).fetchdf()

    rows = _pivot_crosstab_rows(df, row_fields, col_values, values)

    # Grand totals per col_value
    gt_aggs = ", ".join(case_aggs + row_total_aggs)
    gt_sql = f"SELECT {gt_aggs}, COUNT(*) AS _row_count FROM {source}"
    gt_row = con.execute(gt_sql).fetchone()
    grand_totals = _pivot_crosstab_grand_totals(gt_row, col_values, values)

    return {"row_fields": row_fields, "col_field": col_field, "values": values,
            "total_rows": total_rows, "rows": rows,
            "col_values": col_values, "grand_totals": grand_totals}


def _duckdb_pivot(path: Path, row_fields: list, col_field: str | None,
                  values: list, top_n: int) -> dict:
    """
    Excel-style pivot: GROUP BY row_fields, optionally cross-tab by col_field.
    values = [{"column": "amount", "function": "sum"}, ...]
    """
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xls"):
        raise HTTPException(status_code=400, detail="Pivot not supported for Excel files")
    if not _DUCKDB_AVAILABLE:
        raise HTTPException(status_code=500, detail="DuckDB not available")
    values = _normalise_pivot_functions(values)     # ONE vocabulary, refused by name
    if path.stat().st_size == 0:
        return {"row_fields": row_fields, "col_field": col_field, "values": values,
                "total_rows": 0, "rows": [], "col_values": [], "grand_totals": {}}

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        valid_cols = set(_duckdb_valid_cols(con, source))
        _pivot_validate_fields(valid_cols, row_fields, col_field, values)

        total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])

        if not col_field:
            return _pivot_simple(con, source, row_fields, values, top_n, total_rows)
        return _pivot_crosstab(con, source, row_fields, col_field, values,
                               top_n, total_rows)
    finally:
        con.close()


@router.get("/api/executions/{execution_id}/pivot-data")
async def get_pivot_data(
    execution_id: str,
    row_fields: str = Query(..., description="Comma-separated row field column names"),
    col_field: Optional[str] = Query(None, description="Column field for cross-tab"),
    values: str = Query(..., description="JSON array: [{column, function}]"),
    top_n: int = Query(200, ge=1, le=5000),
    user: dict = Depends(require_capability("bqb.view")),
):
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    try:
        _row_fields = [r.strip() for r in row_fields.split(",") if r.strip()]
        _values = json.loads(values)
        if not _row_fields:
            raise HTTPException(status_code=400, detail="At least one row field is required")
        if not _values:
            raise HTTPException(status_code=400, detail="At least one value field is required")
        # 2026-09-17 — refuse a pivot whose functions would describe the
        # GROUPS in an already-aggregated result rather than its rows, and
        # publish the grain either way so a caller that proceeds knows what
        # it is looking at.  See _guard_pivot_functions.
        _grain = _guard_pivot_functions(execution_id, _values)
        _out = await _aduckdb(
            lambda: _duckdb_pivot(csv_file, _row_fields, col_field or None,
                                  _values, top_n))
        if isinstance(_out, dict):
            _out["grain"] = _grain
        return _out
    except HTTPException:
        raise
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON in values parameter")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing pivot data: {str(e)}")


# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def pivot_data_download_file(
    file_id: str,
    row_fields: str = Query(...),
    col_field: Optional[str] = Query(None),
    values: str = Query(...),
    top_n: int = Query(200, ge=1, le=5000),
    # BF-559 (2026-05-29): missing auth check.  Every other pivot
    # endpoint in this module requires get_current_user — this one
    # silently accepted unauthenticated requests, exposing arbitrary
    # downloaded result files to the network.  Anyone who guessed a
    # file_id (UUID-but-still-enumerable) could pivot it.
    user: dict = Depends(require_capability("account.self")),
):
    # 2026-08-20 -- IDOR.  BF-559 added AUTHENTICATION to this endpoint and
    # stopped there; it never added AUTHORIZATION.  Every other consumer of a
    # download file in this module enforces ownership (11 call sites), and its
    # nearest sibling /downloads/{file_id}/chart-data does exactly the two
    # calls below on the same two code paths.  This one loaded the file and
    # pivoted it for whoever asked.
    #
    # Consequence: any authenticated user who guessed or enumerated another
    # user's file_id received that user's result data, aggregated -- and a
    # pivot with a single row_field and an aggregate over the value columns
    # is an efficient way to read a table you cannot open.  The same file_id
    # against chart-data returned 403.
    #
    # Authentication answers "who are you"; only the ownership check answers
    # "is this yours".
    path = None
    _db = _get_db()
    if _db:
        loop = asyncio.get_running_loop()
        record = await loop.run_in_executor(_get_executor(), _db.get_download_file, file_id)
        if record:
            await asyncio.to_thread(_enforce_download_ownership, record, user)
            # 2026-08-30: lifecycle too, not only ownership.  The
            # download route refuses a lapsed/expired/deleted row with
            # 410 while these three SERVED it — same record, opposite
            # verdicts, so a user whose retention had lapsed could not
            # download the file but could still page through all of it
            # here.  Reading it a page at a time is still reading it.
            _refusal = download_refusal(record)
            if _refusal:
                raise HTTPException(status_code=410, detail=_refusal)
            path = await asyncio.to_thread(_resolve_download_path, record, file_id)
    if path is None:
        # Fallback treats file_id as an execution_id -- guard that path too,
        # or the check above is trivially bypassed by passing an id that has
        # no download record.
        await asyncio.to_thread(_enforce_execution_ownership, file_id, user)
        path = await asyncio.to_thread(find_csv_file, file_id)
    if path is None:
        raise HTTPException(status_code=404,
            detail=f"No download record or results file found for id={file_id}")
    try:
        _row_fields = [r.strip() for r in row_fields.split(",") if r.strip()]
        _values = json.loads(values)
        return await _aduckdb(lambda: _duckdb_pivot(path, _row_fields, col_field or None, _values, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing pivot data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Export — background task (pandas OK here — converts once to target format)
# ═══════════════════════════════════════════════════════════════════
def _broadcast_export_event(kind, payload, username, loop, log):
    """Best-effort WS notification about an export.

    2026-08-20: close the coroutine when scheduling fails (dead
    loop) — dropping the message is intended, leaking the
    un-awaited coroutine is not.
    """
    import asyncio
    _emit_loop = loop or _main_loop
    if not (_ws_manager and _emit_loop):
        return
    _coro = None
    try:
        _coro = _ws_manager.broadcast_to_user(username, payload)
        asyncio.run_coroutine_threadsafe(_coro, _emit_loop)
    except Exception as _ws_exc:
        if _coro is not None:
            _coro.close()
        log.warning("Failed to broadcast %s: %s", kind, _ws_exc)


def _notify_export_failure(execution_id, file_id, filename, export_format,
                           username, loop, log, reason: str) -> None:
    """Tell the user their export failed.

    BF-272: broadcast a failure event so the frontend can surface a real
    error to the user instead of leaving them clicking the Downloads page
    waiting for a CSV row that's never going to appear.
    """
    log.error(f"Export [{execution_id}] failed: {reason}")
    _broadcast_export_event("export_failed", {
        "type": "export_failed", "file_id": file_id, "filename": filename,
        "format": export_format, "execution_id": execution_id, "username": username,
        "error": reason, "timestamp": datetime.now(timezone.utc).isoformat(),
    }, username, loop, log)


def _write_parquet_as_csv(csv_file, out) -> None:
    """parquet -> CSV in pandas' ``to_csv`` convention, ONE BATCH AT A TIME
    (2026-10-04: was ``pd.read_parquet(whole).to_csv`` -- every row in the
    heap).  Integer columns map to pandas' nullable integers in every batch,
    so a column with gaps prints ``5`` / empty consistently instead of
    flipping to ``5.0`` in whichever batch happens to hold a null."""
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    _int_map = {t: d for t, d in (
        (_pa.int8(), pd.Int8Dtype()), (_pa.int16(), pd.Int16Dtype()),
        (_pa.int32(), pd.Int32Dtype()), (_pa.int64(), pd.Int64Dtype()),
        (_pa.uint8(), pd.UInt8Dtype()), (_pa.uint16(), pd.UInt16Dtype()),
        (_pa.uint32(), pd.UInt32Dtype()), (_pa.uint64(), pd.UInt64Dtype()))}
    pf = _pq.ParquetFile(str(csv_file))
    first = True
    with open(str(out), "w", encoding="utf-8", newline="") as fh:
        for batch in pf.iter_batches(batch_size=_EXPORT_BATCH_ROWS):
            batch.to_pandas(types_mapper=_int_map.get).to_csv(
                fh, index=False, header=first)
            first = False
        if first:                               # empty result: header only
            pf.schema_arrow.empty_table().to_pandas().to_csv(fh, index=False)


def _write_parquet_as_json(csv_file, out) -> None:
    with open(str(out), "wb") as fh:
        for chunk in _json_stream_from_parquet(Path(csv_file)):
            fh.write(chunk)


def _write_parquet_as_xlsx(csv_file, out) -> None:
    """parquet -> xlsx through the ONE streaming Excel writer
    (``business_reports_api._write_excel_streaming``): typed cells, a new
    sheet every 1,048,575 rows, bounded memory.  ``pd.to_excel`` held every
    row as an openpyxl cell (~2 KB/row) and REFUSED a result past one
    sheet."""
    from api.business_reports_api import _write_excel_streaming
    from core.reports.export_stream import artifact_columns, iter_artifact_rows
    cols = artifact_columns(csv_file)
    _write_excel_streaming(str(out), cols,
                           iter_artifact_rows(csv_file, cols, native=True),
                           "Query Results", "1976D2", "FFFFFF", "", {})


def _write_csv_source_export(csv_file, out, export_format) -> None:
    """A legacy CSV result (rare, small by construction) in each format."""
    import shutil
    if export_format == "csv":
        shutil.copy2(str(csv_file), str(out))
        return
    df = pd.read_csv(csv_file)
    if export_format == "excel":
        with pd.ExcelWriter(str(out), engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Query Results")
    elif export_format == "json":
        out.write_text(df.to_json(orient="records", indent=2), encoding="utf-8")


#: parquet result -> its batched writer, per export format.
_PARQUET_EXPORT_WRITERS = {
    "csv": _write_parquet_as_csv,
    "json": _write_parquet_as_json,
    "excel": _write_parquet_as_xlsx,
}


def _write_export_file(csv_file, out, export_format, is_parquet) -> None:
    """Materialise the result file in the requested export format.

    2026-10-04: a parquet result is CONVERTED IN BATCHES for every format --
    the old body read the whole result into pandas first, so a background
    export of a multi-million-row result could take the pod down.  A
    partial file is removed when the writer fails (the caller reports the
    failure; nothing half-written is left to be registered later).
    """
    try:
        if is_parquet and export_format in _PARQUET_EXPORT_WRITERS:
            _PARQUET_EXPORT_WRITERS[export_format](csv_file, out)
        else:
            _write_csv_source_export(csv_file, out, export_format)
    except BaseException:
        _discard_partial(out)
        raise


def _discard_partial(out) -> None:
    try:
        Path(out).unlink(missing_ok=True)
    except OSError:
        pass


def _do_export(execution_id, export_format, output_path, file_id, filename, loop=None, cancel_event=None, username=""):
    import logging as _logging
    _log = _logging.getLogger(__name__)
    try:
        csv_file = find_csv_file(execution_id)
        if not csv_file:
            _notify_export_failure(execution_id, file_id, filename,
                                   export_format, username, loop, _log,
                                   "source result file not found")
            return

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        is_parquet = csv_file.suffix.lower() == ".parquet"
        _write_export_file(csv_file, out, export_format, is_parquet)

        file_size = out.stat().st_size
        _db = _get_db()
        if _db:
            _db.create_download_file(
                file_id=file_id, execution_id=execution_id, filename=filename,
                file_path=str(out), file_size_bytes=file_size,
                # 2026-08-22 — the one writer my regex sweep missed: it
                # carries a .replace(tzinfo=None) between the now() and the
                # timedelta, so the pattern did not match and the commit
                # claiming "all 13 sites" was wrong about this one.
                expires_at=_download_expires_at().replace(tzinfo=None),
            )
        # 2026-08-20: was UNGUARDED — a dead loop here raised into the
        # outer except AFTER the file was written and registered, so a
        # finished export was re-reported to the user as export_failed
        # (and the un-scheduled broadcast_to_user coroutine leaked).
        # The export is done: WS notify is best-effort from here.
        _broadcast_export_event("export_completed", {
            "type": "export_completed", "file_id": file_id, "filename": filename,
            "format": export_format, "execution_id": execution_id, "username": username,
            "file_size_bytes": file_size, "timestamp": datetime.now(timezone.utc).isoformat(),
        }, username, loop, _log)
        _log.info(f"Export completed [{execution_id}] → {filename}")
    except Exception as e:
        # BF-272: notify the user via WS — silent failure was sending people
        # to the Downloads page where they'd click the auto-created parquet
        # row thinking it was their CSV.
        _notify_export_failure(execution_id, file_id, filename, export_format,
                               username, loop, _log, str(e))
        _logging.getLogger(__name__).error(f"Export failed [{execution_id}]: {e}", exc_info=True)


def _enforce_export_rate_limit(username: str, _gov) -> None:
    """Refuse with 429 when this user has exported too often this minute.

    FB-48 (2026-09-20): skipped entirely when
    ``admin_governance.rate_limit_enabled`` is false -- the governance
    switch that had no reader.  One switch, both governance limiters, so an
    admin turning limiting off does not have to discover that exports have
    a separate one.
    """
    if not _gov.rate_limit_enabled:
        return
    # Export rate limit — separate bucket from "execute"
    try:
        from core.rate_limiter import check_rate_limit, RateLimitExceededError as _RLE
        check_rate_limit("export", username,
                         limit=_gov.export_rate_limit_per_minute,
                         window_seconds=60)
    except _RLE as _rle:
        raise HTTPException(
            status_code=429,
            detail=f"Export rate limit exceeded: max "
                   f"{_gov.export_rate_limit_per_minute}/min. "
                   f"Retry after {_rle.retry_after}s.",
            headers={"Retry-After": str(_rle.retry_after)},
        )


# ── Export formats: ONE declaration per surface ────────────────────────
# 2026-09-17.  Until today the answer to "which formats does execution
# export take?" was spelled FOUR times and no two agreed:
#
#   GET  route regex   csv|excel|json|parquet
#   POST route regex   csv|excel|json
#   role policy        admin csv,excel,json,PDF   (core/config.py)
#   implementation     csv, excel, json, parquet
#
# Two things fell through the gap, both reproduced against a live
# container.  ``parquet`` is implemented and accepted by the GET route but
# absent from every role's DEFAULT grant, so it 403s until an operator
# edits the config -- a shipped-off feature, not a refusal.  And ``pdf`` is
# GRANTED to admin by default while this surface has no PDF renderer at
# all: the request died on the route regex with
# ``string_pattern_mismatch`` -- a 422 that reads like malformed input
# rather than "this surface cannot do that".  A decision made twice is a
# bug (CLAUDE.md §4); this one was made four times.
#
# So: each surface declares what it can PRODUCE, the route patterns are
# built from those declarations, and a format an operator may legitimately
# grant but this surface cannot render is named here with the reason
# instead of being discovered as a regex miss.

#: Formats the DIRECT (streaming) export can produce.  Each has a branch in
#: ``export_results_direct`` / ``_export_via_pandas`` below.
GRID_EXPORT_FORMATS = ("csv", "excel", "json", "parquet")

#: Formats the BACKGROUND export can produce — it materialises a file per
#: the ``ext`` map in ``export_results_background``, which has no parquet
#: entry.  Narrower than the direct surface on purpose.
GRID_EXPORT_BACKGROUND_FORMATS = ("csv", "excel", "json")

#: Formats ``admin_governance.export_formats_*`` may grant that NO execution
#: export surface renders.  Listed so the grant reaches an honest refusal
#: naming the reason, instead of a regex mismatch.  Emptying this set is
#: correct the day the surface learns the format — the guard test in
#: tests/test_export_format_vocabulary_2026_09_17.py holds the two in step.
GRID_EXPORT_UNRENDERABLE = {
    "pdf": "this surface streams tabular result files and has no PDF "
           "renderer; business-report exports are the PDF surface",
}


def _export_pattern(supported: tuple) -> str:
    """Route regex = what the surface produces + what policy may grant.

    The unrenderable formats are ACCEPTED by the pattern so the handler can
    refuse them with a reason; keeping them out returned a 422 that blamed
    the caller for a gap on our side.
    """
    return "^(" + "|".join(tuple(supported) + tuple(GRID_EXPORT_UNRENDERABLE)) + ")$"


def _refuse_unrenderable_format(format: str, supported: tuple) -> None:
    """415 naming the reason, for a format this surface cannot produce."""
    fmt = (format or "").lower()
    if fmt in GRID_EXPORT_UNRENDERABLE:
        raise HTTPException(
            status_code=415,
            detail=f"Export format '{fmt}' is not available on this "
                   f"endpoint: {GRID_EXPORT_UNRENDERABLE[fmt]}. "
                   f"This endpoint produces: {sorted(supported)}.",
        )
    if fmt not in supported:
        raise HTTPException(
            status_code=415,
            detail=f"Export format '{fmt}' is not produced by this "
                   f"endpoint. Available: {sorted(supported)}.",
        )


def _enforce_export_guard(user: dict, format: str) -> None:
    """Phase 102-D — enforce per-role format restrictions + export rate limit.

    Raises 403 if the user's role is not allowed to export this format,
    429 if the per-minute export rate limit is exceeded.
    No-op when ``admin_governance.enabled`` is false (backwards-compatible).
    """
    try:
        from core.config import admin_governance as _gov
        if not _gov.enabled:
            return
        username = (user or {}).get("username", "guest")
        role = (user or {}).get("role", "viewer")
        allowed = _gov.export_formats_for_role(role)
        if format.lower() not in allowed:
            raise HTTPException(
                status_code=403,
                detail=f"Export format '{format}' not allowed for role '{role}'. "
                       f"Allowed: {sorted(allowed)}",
            )
        _enforce_export_rate_limit(username, _gov)
    except HTTPException:
        raise
    except Exception:
        pass  # governance must never block on internal errors


@router.post("/api/executions/{execution_id}/export")
async def export_results_background(
    execution_id: str,
    background_tasks: BackgroundTasks,
    format: str = Query("csv", pattern=_export_pattern(GRID_EXPORT_BACKGROUND_FORMATS)),
    user: dict = Depends(require_capability("bqb.view")),
):
    # Phase 131 deep-dive #13 (round 3): export must enforce ownership.
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    _enforce_export_guard(user, format)
    _refuse_unrenderable_format(format, GRID_EXPORT_BACKGROUND_FORMATS)
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    ext     = {"csv": ".csv", "excel": ".xlsx", "json": ".json"}[format]
    file_id = str(uuid.uuid4())
    fname   = f"export_{execution_id[:8]}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}{ext}"
    out_path = str(_get_downloads_dir() / f"{file_id}{ext}")
    import asyncio as _a
    try:
        loop = _a.get_running_loop()
    except RuntimeError:
        loop = None
    _username = user.get("username", "") if user else ""
    try:
        from core.worker_pool import get_pool, WorkType
        # Phase 0 reports rewire (2026-08-08): await the async submit — the
        # old submit_sync blocked the event loop in _acquire_slot while
        # waiting for an EXPORT slot (same defect class as reports_api
        # execute_report; pattern: execute_api.py:5482).  RuntimeError
        # fallback semantics unchanged.
        await get_pool().submit(WorkType.EXPORT, _do_export,
                                execution_id, format, out_path, file_id, fname, loop, None, _username,
                                execution_id=execution_id)
    except RuntimeError:
        background_tasks.add_task(_do_export, execution_id, format, out_path, file_id, fname, loop, None, _username)
    return {"file_id": file_id, "filename": fname, "format": format,
            "message": f"Export started. '{fname}' will appear on the Downloads page shortly."}


# BF-294: streaming converters — peak RAM is ~one parquet row group
# (~16-128 MB) regardless of total result size. Replaces the old
# pd.read_parquet().to_csv() / .to_json() path that loaded the entire
# DataFrame plus the encoded buffer into memory at once.
_EXPORT_BATCH_ROWS = 64_000


def _csv_stream_from_parquet(path: Path):
    # 2026-08-20 — mid-stream failure disclosure.  Once the first chunk is
    # yielded the 200 + headers are gone; a reader failure used to simply END
    # the body after N valid rows, and every CSV parser accepts a truncated
    # CSV silently.  Now: (1) the route sends a pre-body X-QS-Expected-Rows
    # header (parquet footer count) so consumers can reconcile, and (2) a
    # mid-stream failure emits an in-band ``#QS-EXPORT-ERROR`` trailer line
    # before re-raising, so the abort is visible in the payload itself as
    # well as via the chunked-transfer termination.
    import pyarrow.parquet as _pq
    import pyarrow.csv as _pa_csv
    import pyarrow as _pa
    pf = _pq.ParquetFile(str(path))
    first = True
    any_rows = False
    rows_sent = 0
    try:
        for batch in pf.iter_batches(batch_size=_EXPORT_BATCH_ROWS):
            any_rows = True
            sink = io.BytesIO()
            _pa_csv.write_csv(
                _pa.Table.from_batches([batch]),
                sink,
                _pa_csv.WriteOptions(include_header=first),
            )
            first = False
            rows_sent += batch.num_rows
            yield sink.getvalue()
        if not any_rows:
            # Empty result — emit a header-only CSV so the file isn't zero bytes
            sink = io.BytesIO()
            empty = _pa.Table.from_batches([], schema=pf.schema_arrow)
            _pa_csv.write_csv(empty, sink, _pa_csv.WriteOptions(include_header=True))
            yield sink.getvalue()
    except GeneratorExit:
        raise
    except Exception as exc:
        yield (f"\n#QS-EXPORT-ERROR: export aborted after {rows_sent} rows: "
               f"{type(exc).__name__}: {exc}\n").encode("utf-8")
        raise


def _json_stream_from_parquet(path: Path):
    """JSON-array stream: `[` + comma-separated record objects + `]`.
    Uses pyarrow batches → pandas-per-batch → to_json(orient="records").
    Memory peak is one batch DataFrame, not the whole result.

    2026-08-20 — mid-stream failure: emit an in-band error object and
    re-raise WITHOUT closing the array.  Closing ``]`` would hand parsers a
    VALID document containing a silent prefix of the data; leaving it open
    keeps the payload unparseable (fail-safe) while the marker makes the
    cause visible in a raw dump.
    """
    import pyarrow.parquet as _pq
    import json as _json
    pf = _pq.ParquetFile(str(path))
    yield b"["
    first_record = True
    rows_sent = 0
    try:
        for batch in pf.iter_batches(batch_size=_EXPORT_BATCH_ROWS):
            df_batch = batch.to_pandas()
            # to_json with orient=records returns "[{...},{...}]" — strip the brackets
            chunk = df_batch.to_json(orient="records")
            inner = chunk[1:-1] if chunk.startswith("[") and chunk.endswith("]") else chunk
            if not inner:
                continue
            if not first_record:
                yield b","
            yield inner.encode("utf-8")
            first_record = False
            rows_sent += batch.num_rows
    except GeneratorExit:
        raise
    except Exception as exc:
        marker = _json.dumps({"__qs_export_error__":
                              f"export aborted after {rows_sent} rows: "
                              f"{type(exc).__name__}: {exc}"})
        yield (marker if first_record else "," + marker).encode("utf-8")
        raise
    yield b"]"


def _expected_rows_headers(csv_file, disposition: str) -> dict:
    """Build the export response headers, disclosing the expected row count.

    2026-08-20 — pre-body row-count disclosure for the streaming exports.
    The try/except around StreamingResponse(...) only ever guarded response
    CONSTRUCTION: the generator body runs lazily, so a mid-stream reader
    failure ended a text/csv 200 after N valid rows with nothing for the
    consumer to reconcile against.  X-QS-Expected-Rows is footer-derived
    and emitted BEFORE the body (same contract as published_views/bulk.py),
    so rows-received vs expected is a real completeness check.
    """
    h = {"Content-Disposition": disposition}
    try:
        import pyarrow.parquet as _pq
        h["X-QS-Expected-Rows"] = str(_pq.read_metadata(str(csv_file)).num_rows)
        h["Access-Control-Expose-Headers"] = "X-QS-Expected-Rows"
    except Exception as _meta_exc:
        # Disclosure is best-effort; the in-band error marker still fires.
        _logging.getLogger(__name__).warning(
            "export: could not read parquet footer for expected-rows "
            "header (%s)", _meta_exc)
    return h


async def _export_parquet_response(csv_file, execution_id, is_parquet):
    """Serve the result as parquet.

    BF-293: serve the raw parquet inline so users can download from BQB
    directly (instead of navigating to the Download Center).
    """
    if is_parquet:
        return FileResponse(path=csv_file,
                             filename=f"query_results_{execution_id}.parquet",
                             media_type="application/octet-stream")
    try:
        # BF-NONBLOCK-AUDIT-5: pd.read_csv + to_parquet is heavy IO +
        # CPU on large results.  Run in worker thread.
        def _csv_to_parquet():
            _buf = io.BytesIO()
            pd.read_csv(csv_file).to_parquet(_buf, index=False)
            _buf.seek(0)
            return _buf
        buf = await asyncio.to_thread(_csv_to_parquet)
        return StreamingResponse(buf, media_type="application/octet-stream",
            headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.parquet"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")


def _parquet_stream_export(csv_file, execution_id, ext, media_type, stream_fn):
    """Stream a parquet result out as CSV/JSON, one row group at a time.

    BF-294: streaming parquet → CSV / JSON (one row group at a time).
    The whole construction stays inside the try, including the header
    build, because that is what the original guarded.
    """
    try:
        return StreamingResponse(
            stream_fn(csv_file),
            media_type=media_type,
            headers=_expected_rows_headers(
                csv_file,
                f"attachment; filename=query_results_{execution_id}.{ext}"),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")


async def _streamed_xlsx_response(csv_file, execution_id):
    """2026-10-04: the direct Excel export, streamed like the CSV / JSON
    branches -- bounded memory and sheets past 1,048,575 rows (pd.to_excel
    held every cell and refused a result past one sheet).  Written to a temp
    file on a worker thread, served from it, deleted after."""
    import shutil
    import tempfile
    from starlette.background import BackgroundTask
    tmp_dir = Path(tempfile.mkdtemp(prefix="qs_xlsx_"))
    out = tmp_dir / f"query_results_{execution_id}.xlsx"

    def _cleanup():
        shutil.rmtree(tmp_dir, ignore_errors=True)

    try:
        await asyncio.to_thread(_write_parquet_as_xlsx, csv_file, out)
    except Exception as e:
        _cleanup()
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")
    return FileResponse(
        path=str(out), filename=f"query_results_{execution_id}.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        background=BackgroundTask(_cleanup))


async def _export_via_pandas(csv_file, execution_id, format, is_parquet):
    """Excel + (JSON over a CSV input): fall back to pandas in-memory.

    xlsx format is row-capped at 1.04M and rare for huge results;
    CSV-source JSON is uncommon (results are written as parquet).
    """
    if format == "excel" and is_parquet:
        return await _streamed_xlsx_response(csv_file, execution_id)
    try:
        # BF-NONBLOCK-AUDIT-5: pandas read + Excel/JSON serialisation
        # can take 10s+ on large results; openpyxl is single-threaded
        # CPU.  Run in worker thread.
        def _materialise():
            return pd.read_parquet(csv_file) if is_parquet else pd.read_csv(csv_file)
        df = await asyncio.to_thread(_materialise)
        if format == "excel":
            def _to_excel():
                _buf = io.BytesIO()
                with pd.ExcelWriter(_buf, engine="openpyxl") as w:
                    df.to_excel(w, index=False, sheet_name="Query Results")
                _buf.seek(0)
                return _buf
            buf = await asyncio.to_thread(_to_excel)
            return StreamingResponse(buf,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.xlsx"})
        if format == "json":
            json_payload = await asyncio.to_thread(
                df.to_json, orient="records", indent=2)
            return StreamingResponse(io.StringIO(json_payload),
                media_type="application/json",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.json"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")


@router.get("/api/executions/{execution_id}/export")
async def export_results_direct(
    execution_id: str,
    format: str = Query("csv", pattern=_export_pattern(GRID_EXPORT_FORMATS)),
    user: dict = Depends(require_capability("bqb.view")),
):
    # Phase 131 deep-dive #13 (round 3): direct export needs ownership too.
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    _enforce_export_guard(user, format)
    _refuse_unrenderable_format(format, GRID_EXPORT_FORMATS)
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    is_parquet = csv_file.suffix.lower() == ".parquet"

    if format == "parquet":
        return await _export_parquet_response(csv_file, execution_id, is_parquet)

    if format == "csv":
        if not is_parquet:
            return FileResponse(path=csv_file, filename=f"query_results_{execution_id}.csv", media_type="text/csv")
        return _parquet_stream_export(csv_file, execution_id, "csv",
                                      "text/csv", _csv_stream_from_parquet)

    if format == "json" and is_parquet:
        return _parquet_stream_export(csv_file, execution_id, "json",
                                      "application/json", _json_stream_from_parquet)

    return await _export_via_pandas(csv_file, execution_id, format, is_parquet)


# ═══════════════════════════════════════════════════════════════════
# Release execution result — delete temp CSV when user is done
# ═══════════════════════════════════════════════════════════════════
@router.delete("/api/executions/{execution_id}/results")
async def release_execution_results(execution_id: str,
                                     user: dict = Depends(require_capability("bqb.view"))):
    """
    Delete the temporary CSV produced by a SQL execution.
    Called by the frontend when the user closes the result grid.
    This prevents temp files from accumulating on disk.

    Phase 131 deep-dive #13 (round 3): ownership check — only the
    executor or an admin can release results.  Service executions
    (PV / embed / shared / scheduled) are NOT releasable here —
    they have their own cleanup schedulers.
    """
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user, allow_service=False)
    import logging as _lg
    _log = _lg.getLogger(__name__)
    # Phase 6: never hydrate a result artifact just to delete the local
    # copy — release is LOCAL temp hygiene; the shared artifact (which
    # single-flight followers may still read) is owned by the TTL/GC
    # lifecycle, not by one user closing their grid.
    csv_file = await asyncio.to_thread(
        lambda: find_csv_file(execution_id, hydrate_artifact=False))

    def _release_file() -> None:
        # NFS exists() + unlink() off the event loop.
        if csv_file and csv_file.exists():
            try:
                csv_file.unlink()
                _evict_cached_meta(csv_file)
                _log.info(f"Released execution result: {csv_file.name}")
            except OSError as e:
                _log.warning(f"Could not delete {csv_file}: {e}", exc_info=True)
        # Progressive delivery (2026-07-31): also drop any leftover
        # segment spool for this execution (flag-independent — covers
        # spools orphaned by a flag flip or executor crash).  Never raises.
        try:
            from core.progressive_results import cleanup_segments as _prog_clean
            _prog_clean(execution_id)
        except Exception:
            pass
    await asyncio.to_thread(_release_file)
    return {"deleted": bool(csv_file), "execution_id": execution_id}


# ═══════════════════════════════════════════════════════════════════
# Column stats — full dataset
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/stats")
async def get_result_stats(execution_id: str,
                            user: dict = Depends(require_capability("bqb.view"))):
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, user)
    csv_file = await asyncio.to_thread(find_csv_file, execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")

    def _compute():
        if csv_file.suffix.lower() == ".parquet":
            df = pd.read_parquet(csv_file)
        else:
            df = pd.read_csv(csv_file)
        stats = {"total_rows": len(df), "total_columns": len(df.columns),
                 "file_size_bytes": csv_file.stat().st_size, "columns": []}
        for col in df.columns:
            cs = {"name": col, "type": str(df[col].dtype),
                  "null_count": int(df[col].isnull().sum()),
                  "unique_count": int(df[col].nunique())}
            if pd.api.types.is_numeric_dtype(df[col]):
                cs["min"]  = float(df[col].min())  if not pd.isna(df[col].min())  else None
                cs["max"]  = float(df[col].max())  if not pd.isna(df[col].max())  else None
                cs["mean"] = float(df[col].mean()) if not pd.isna(df[col].mean()) else None
            stats["columns"].append(cs)
        return stats

    try:
        return await _aduckdb(_compute)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing stats: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Download file helpers
# ═══════════════════════════════════════════════════════════════════
def _download_path_candidates(record: dict, file_id: str) -> list:
    """Every place a DownloadFile could be on disk, in preference order."""
    stored       = record.get("file_path", "")
    filename     = record.get("filename", "")
    execution_id = record.get("execution_id", "")

    candidates: list = []
    if stored:
        candidates.append(Path(stored))
    if stored and stored.startswith("./"):
        candidates.append(Path(stored[2:]))
    dl = _get_downloads_dir()
    for base in (dl, Path(str(_get_downloads_dir()))):
        candidates.append(base / f"{file_id}.parquet")
        candidates.append(base / f"{file_id}.csv")
        if filename:
            candidates.append(base / filename)
        if execution_id:
            candidates.append(base / f"{execution_id}.parquet")
            candidates.append(base / f"{execution_id}.csv")
    return candidates


def _download_candidate_matches(c: Path, _expected_ext: str) -> bool:
    """Decide whether one candidate path is the file the DB row describes.

    BF-272: enforce extension match.  If the row says .csv,
    never serve a .parquet — even if the stored path is
    missing and the only matching file on disk is a parquet.
    """
    try:
        if not (c.exists() and c.is_file()):
            return False
        return not (_expected_ext and c.suffix.lower() != _expected_ext)
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)
        return False


def _resolve_download_path(record: dict, file_id: str) -> Optional[Path]:
    """Try multiple locations to find a DownloadFile on disk.

    BF-272: filter candidates by extension so an export-CSV row never
    resolves to the underlying execution's parquet file.  Without this
    filter, when a CSV-export background job silently fails to write the
    .csv file, the resolver fell through to the {execution_id}.parquet
    fallback and the user downloaded a parquet — even though the row was
    labeled `export_xxx.csv`.  Symptom user reported: "from BQB selected
    export to csv ... download center downloading .parquet file".
    """
    filename = record.get("filename", "")

    # BF-272: derive the expected extension from the filename so we can
    # reject candidates that don't match.  e.g. "export_xxx.csv" → ".csv".
    _expected_ext = ""
    if filename and "." in filename:
        _expected_ext = "." + filename.rsplit(".", 1)[-1].lower()

    for c in _download_path_candidates(record, file_id):
        if _download_candidate_matches(c, _expected_ext):
            return c
    return None


# ═══════════════════════════════════════════════════════════════════
# Preview by file_id — DuckDB, any size
# ═══════════════════════════════════════════════════════════════════
# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def _download_record_path(file_id: str, user: dict) -> tuple:
    """Resolve a download row to (path, filename), owner- AND lifecycle-checked.

    Returns ``(None, "")`` when there is no such row, so the caller can fall
    back to treating the id as an execution id.

    Wiz-scan #1: enforce ownership before serving any bytes.

    2026-08-30: lifecycle too, not only ownership.  The
    download route refuses a lapsed/expired/deleted row with
    410 while these three SERVED it — same record, opposite
    verdicts, so a user whose retention had lapsed could not
    download the file but could still page through all of it
    here.  Reading it a page at a time is still reading it.
    """
    _db = _get_db()
    if not _db:
        return None, ""
    loop   = asyncio.get_running_loop()
    record = await loop.run_in_executor(_get_executor(), _db.get_download_file, file_id)
    if not record:
        return None, ""
    await asyncio.to_thread(_enforce_download_ownership, record, user)
    _refusal = download_refusal(record)
    if _refusal:
        raise HTTPException(status_code=410, detail=_refusal)
    path = await asyncio.to_thread(_resolve_download_path, record, file_id)
    if path is None:
        # 2026-09-24 (click crawl): the RECORD exists and its file does not.
        # The callers then fell back to "treat the id as an execution id",
        # found nothing, and answered 404 "No download record ... found" --
        # false, and the person could not tell a typo from a cleaned-up file.
        raise HTTPException(
            status_code=410,
            detail=("This file is no longer on the server (it was removed or "
                    "expired). Run the query or report again to produce it."))
    return path, record.get("filename", "")


#: What the pager can read.  Anything else -- a PDF export, an archive -- is
#: not a table, and reading it as CSV (the old fall-through) answered 500.
_PREVIEWABLE_SUFFIXES = frozenset({".parquet", ".csv", ".txt", ".tsv", ".json",
                                   ".jsonl", ".xlsx", ".xls"})


#: Compression the CSV reader opens transparently -- ``x.csv.gz`` is a table.
_TRANSPARENT_COMPRESSION = frozenset({".gz", ".zst"})


def _refuse_unpreviewable(path) -> None:
    suffixes = [s.lower() for s in Path(str(path)).suffixes]
    if suffixes and suffixes[-1] in _TRANSPARENT_COMPRESSION and len(suffixes) > 1:
        suffixes = suffixes[:-1]          # judge the file inside the compression
    suffix = suffixes[-1] if suffixes else ""
    if suffix and suffix not in _PREVIEWABLE_SUFFIXES:
        raise HTTPException(
            status_code=415,
            detail=(f"Preview is not available for {suffix} files -- "
                    f"download the file to open it."))


async def preview_download_file(
    file_id:        str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=500),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy
    columns:        Optional[str] = None,   # comma-separated column names
    user:           dict          = Depends(require_capability("account.self")),
):
    _req_cols = [c.strip() for c in columns.split(",") if c.strip()] if columns else None

    # Preferred: DB lookup for the DownloadFile record
    path, filename = await _download_record_path(file_id, user)

    # Fallback: treat file_id as an execution_id and look for the raw CSV
    if path is None:
        # Wiz-scan #1: the fallback treats file_id as an execution_id — gate
        # it with the same execution-ownership check.
        await asyncio.to_thread(_enforce_execution_ownership, file_id, user)
        path = await asyncio.to_thread(find_csv_file, file_id)

    if path is None:
        raise HTTPException(
            status_code=404,
            detail=f"No download record or results file found for id={file_id}")

    _refuse_unpreviewable(path)
    effective_adv = _effective_adv_filters(adv_filters, filters)

    return await _paginated_page_response(
        path, page, page_size, sort_column, sort_direction, effective_adv,
        _req_cols, filename=filename)


# ═══════════════════════════════════════════════════════════════════
# Chart data for download file (by file_id)
# ═══════════════════════════════════════════════════════════════════
# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def chart_data_download_file(
    file_id:    str,
    x_col:      str,
    y_col:      str,
    agg:        str           = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:      int           = Query(50, ge=1, le=500),
    series_col: Optional[str] = None,
    max_series: int           = Query(10, ge=1, le=20),
    user:       dict          = Depends(require_capability("account.self")),
):
    path = None
    _db  = _get_db()
    if _db:
        loop   = asyncio.get_running_loop()
        record = await loop.run_in_executor(_get_executor(), _db.get_download_file, file_id)
        if record:
            # Wiz-scan #1: enforce ownership before serving chart data.
            await asyncio.to_thread(_enforce_download_ownership, record, user)
            # 2026-08-30: lifecycle too, not only ownership.  The
            # download route refuses a lapsed/expired/deleted row with
            # 410 while these three SERVED it — same record, opposite
            # verdicts, so a user whose retention had lapsed could not
            # download the file but could still page through all of it
            # here.  Reading it a page at a time is still reading it.
            _refusal = download_refusal(record)
            if _refusal:
                raise HTTPException(status_code=410, detail=_refusal)
            path = await asyncio.to_thread(_resolve_download_path, record, file_id)
    if path is None:
        # Wiz-scan #1: fallback treats file_id as an execution_id.
        await asyncio.to_thread(_enforce_execution_ownership, file_id, user)
        path = await asyncio.to_thread(find_csv_file, file_id)
    if path is None:
        raise HTTPException(status_code=404,
            detail=f"No download record or results file found for id={file_id}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n, series_col, max_series))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Direct download of a DownloadFile by file_id
# ═══════════════════════════════════════════════════════════════════


# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def download_file_direct(
    file_id: str,
    user: dict = Depends(require_capability("account.self")),
):
    _db = _get_db()
    if not _db:
        raise HTTPException(status_code=503, detail="Service unavailable")
    loop = asyncio.get_running_loop()
    record = await loop.run_in_executor(_get_executor(), _db.get_download_file, file_id)
    if not record:
        raise HTTPException(status_code=404, detail=f"No download record for file_id={file_id}")
    # Wiz-scan #1: enforce ownership before returning the file bytes.
    await asyncio.to_thread(_enforce_download_ownership, record, user)
    # 2026-08-30: this route checked NEITHER status NOR expiry, so it
    # served rows the by-id sibling had already declared gone — including
    # status='deleted' whose file was still on disk.  Same rule, one home.
    from core.download_retention import download_refusal
    _refusal = download_refusal(record)
    if _refusal:
        raise HTTPException(status_code=410, detail=_refusal)
    path = await asyncio.to_thread(_resolve_download_path, record, file_id)
    if path is None:
        # File gone from disk — purge stale record so it stops showing in history
        try:
            await loop.run_in_executor(_get_executor(), lambda: _db.update_download_file(file_id, status="deleted"))
        except Exception as exc:
            _logger.error("Failed to mark download file %s as deleted: %s", file_id, exc, exc_info=True)
        raise HTTPException(status_code=410, detail="File has been deleted")
    filename   = record.get("filename", path.name)
    media_map  = {".csv": "text/csv", ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  ".json": "application/json"}
    media_type = media_map.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(path=str(path), filename=filename, media_type=media_type)


# ═══════════════════════════════════════════════════════════════════
# Raw file path resolution helper
# ═══════════════════════════════════════════════════════════════════
def _confined_path(base: Path, target: Path) -> Optional[Path]:
    """Return resolved target only if it stays within base.

    2026-08-03 SECURITY: was ``str(resolved).startswith(str(base))``.
    A string prefix is not containment -- with base
    ``/data/parquet`` it accepts ``/data/parquet-evil/secret.csv``,
    a SIBLING directory, because the base is a prefix of the
    sibling's name.  ``is_relative_to`` compares path COMPONENTS,
    so the sibling is correctly rejected.
    """
    try:
        resolved = target.resolve()
        base_resolved = base.resolve()
        if resolved.is_relative_to(base_resolved):
            return resolved
    except (OSError, ValueError):
        pass
    return None


def _connection_base_path_candidate(file_path: str,
                                    connection_id: Optional[int]) -> Optional[Path]:
    """Resolve ``file_path`` under the connection's own base_path, confined."""
    _db = _get_db()
    if not (connection_id and _db):
        return None
    try:
        conn = _db.get_connection_raw(connection_id)
        if not conn:
            return None
        cfg  = conn.get("config", {})
        base = cfg.get("base_path") or cfg.get("folder_path")
        if not base:
            return None
        base_p = Path(base)
        candidate = _confined_path(base_p, base_p / file_path)
        if candidate and candidate.exists():
            return candidate
    except Exception as exc:
        _logger.warning("data_grid_api error: %s", exc, exc_info=True)
    return None


def _resolve_raw_path(file_path: str, connection_id: Optional[int]) -> Path:
    """Resolve a relative/absolute path, trying connection base_path as fallback.

    All resolved paths are confined to their base directory to prevent traversal.
    """
    candidate = _connection_base_path_candidate(file_path, connection_id)
    if candidate is not None:
        return candidate

    # Confine to parquet_dir for non-connection paths
    pdir = _get_parquet_dir()
    confined = _confined_path(pdir, pdir / file_path)
    if confined and confined.exists():
        return confined

    # Also allow absolute paths that are within parquet_dir or data dir
    path = Path(file_path)
    if path.is_absolute():
        data_dir = pdir.parent  # typically data/
        confined = _confined_path(data_dir, path)
        if confined and confined.exists():
            return confined

    # 2026-08-03 SECURITY — fail CLOSED.
    #
    # This used to `return pdir / file_path` unconditionally, which defeated
    # every containment check above: `_confined_path` returns None on failure
    # and control simply fell through to here.  pathlib makes it worse — an
    # ABSOLUTE right-hand operand discards the base entirely, so
    # `Path("/data/parquet") / "/etc/passwd"` == `Path("/etc/passwd")`.
    # The three `/api/files/*` endpoints that reach this helper declare no
    # auth dependency and no global auth middleware exists (the only custom
    # middleware is the origin/CSRF check), so this was an UNAUTHENTICATED
    # arbitrary file read: `?file_path=/etc/passwd` returned the file paged
    # as rows via read_csv_auto.
    #
    # The fallback still has a legitimate job: a file that does not exist
    # must yield the caller's 404, not an error here.  So keep returning the
    # joined path — but ONLY when it stays inside the base directory.
    # Containment is checked WITHOUT requiring existence, which is exactly
    # what `_confined_path`'s `.exists()` callers could not do.
    _candidate = pdir / file_path
    try:
        # is_relative_to, NOT a string prefix: str.startswith would accept
        # "/data/parquet-evil" against a "/data/parquet" base.  resolve()
        # collapses ".." before the comparison, and works on paths that do
        # not exist -- which _confined_path's exists()-gated checks above
        # cannot.
        if _candidate.resolve().is_relative_to(pdir.resolve()):
            return _candidate
    except (OSError, ValueError) as _pexc:
        _logger.warning("path containment check failed for %r: %s",
                        file_path, _pexc)
    _logger.warning("REJECTED out-of-base file path request: %r", file_path)
    raise HTTPException(
        status_code=400,
        detail="Invalid file path — outside the permitted data directory",
    )


# ═══════════════════════════════════════════════════════════════════
# Raw file preview — CSV or Parquet by path (DuckDB, any size)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/data")
async def get_raw_file_data(
    file_path:      str,
    connection_id:  Optional[int] = None,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=5000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,  # legacy
    columns:        Optional[str] = None,  # comma-separated column names
    _user: dict = Depends(require_capability("bqb.view")),   # 2026-08-03: was UNAUTHENTICATED
):
    """Paginated preview of any file (CSV/Parquet/Excel/JSON).
    Supply connection_id when file_path is relative to a connection's base_path."""
    # _resolve_raw_path does a sync connection lookup + NFS resolve; the
    # exists()/is_file() are NFS stats — all off the event loop.
    path = await asyncio.to_thread(_resolve_raw_path, file_path, connection_id)
    if not await asyncio.to_thread(lambda: path.exists() and path.is_file()):
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

    _req_cols = [c.strip() for c in columns.split(",") if c.strip()] if columns else None
    effective_adv = _effective_adv_filters(adv_filters, filters)

    return await _paginated_page_response(
        path, page, page_size, sort_column, sort_direction, effective_adv,
        _req_cols)


# ═══════════════════════════════════════════════════════════════════
# Raw file chart data (CSV or Parquet, by path)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/chart-data")
async def get_raw_file_chart_data(
    file_path:     str,
    x_col:         str,
    y_col:         str,
    connection_id: Optional[int] = None,
    agg:           str           = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:         int           = Query(50, ge=1, le=500),
    series_col:    Optional[str] = None,
    max_series:    int           = Query(10, ge=1, le=20),
    _user: dict = Depends(require_capability("bqb.view")),   # 2026-08-03: was UNAUTHENTICATED
):
    # _resolve_raw_path does a sync connection lookup + NFS resolve; the
    # exists()/is_file() are NFS stats — all off the event loop.
    path = await asyncio.to_thread(_resolve_raw_path, file_path, connection_id)
    if not await asyncio.to_thread(lambda: path.exists() and path.is_file()):
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n, series_col, max_series))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


@router.get("/api/files/pivot-data")
async def get_raw_file_pivot_data(
    file_path: str,
    row_fields: str = Query(...),
    col_field: Optional[str] = Query(None),
    values: str = Query(...),
    connection_id: Optional[int] = None,
    top_n: int = Query(200, ge=1, le=5000),
    _user: dict = Depends(require_capability("bqb.view")),   # 2026-08-03: was UNAUTHENTICATED
):
    # _resolve_raw_path does a sync connection lookup + NFS resolve; the
    # exists()/is_file() are NFS stats — all off the event loop.
    path = await asyncio.to_thread(_resolve_raw_path, file_path, connection_id)
    if not await asyncio.to_thread(lambda: path.exists() and path.is_file()):
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    try:
        _row_fields = [r.strip() for r in row_fields.split(",") if r.strip()]
        _values = json.loads(values)
        return await _aduckdb(lambda: _duckdb_pivot(path, _row_fields, col_field or None, _values, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing pivot data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# /api/query/preview  — Direct DuckDB preview (no file created)
#
# Queries source files (local parquet, S3 parquet, or S3 Iceberg tables)
# directly via DuckDB without executing the full pipeline or writing any
# result file to disk.  Ideal for "preview first 500 rows" in the UI
# before committing to a full execution.
# ═══════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _BM  # noqa: E402


class _PreviewRequest(_BM):
    files:         list                     # local paths or s3:// URIs or __iceberg__:... refs
    adv_filters:   Optional[str]  = None   # adv_filters JSON (date expressions resolved internally)
    columns:       Optional[list] = None
    limit:         int            = 500
    connection_id: Optional[int]  = None   # resolve S3 credentials from saved connection


def _refuse_preview_under_rls() -> None:
    """Refuse the direct-preview path whenever row-level security is on.

    It is REFUSED under row-security rather than wrapped, and that is a
    deliberate choice.  ``secure_sql`` identifies governed tables by parsing
    table references out of the SQL; this endpoint's FROM clause is
    ``read_parquet('s3://...')`` over raw paths, so wrapping the call would
    very likely leave the SQL unchanged and hand back a guard that CANNOT
    FIRE — a protection everyone believes exists.  This codebase has been
    bitten by exactly that shape repeatedly, and a visibly-refused preview is
    strictly better than an invisibly-unfiltered one.
    """
    # UNKNOWN = UNSAFE: if we cannot determine the row-security state, refuse.
    try:
        from core.row_security.api import _is_enabled as _rs_enabled
        _rls_on = _rs_enabled()
    except Exception as _rs_exc:
        _preview_log = __import__("logging").getLogger(__name__)
        _preview_log.warning(
            "[preview] row-security state unreadable (%s) -- refusing the "
            "unfiltered preview path", _rs_exc)
        _rls_on = True
    if _rls_on:
        raise HTTPException(
            status_code=403,
            detail=(
                "Preview is unavailable while row-level security is enabled: "
                "this endpoint reads source files directly and cannot apply "
                "row policies. Use the query execution endpoint, which "
                "filters rows for your principal."
            ),
        )


async def _preview_conn_config(connection_id) -> dict:
    """Read the saved connection's config sub-dict; {} when there is none."""
    if not connection_id:
        return {}
    db = _get_db()
    if not db:
        return {}
    rec = await asyncio.to_thread(db.get_connection_raw, connection_id)
    if not rec:
        return {}
    return rec.get("config") or {}


def _preview_source_expr(f, conn_config, connection_id, _is_onprem_direct):
    """Decide the DuckDB table expression for ONE preview source ref."""
    if f.startswith("__iceberg__:"):
        if _is_onprem_direct:
            raise RuntimeError(
                "Iceberg format is not supported for on-prem S3 direct file access. "
                "Use parquet format instead."
            )
        table_uri = f[len("__iceberg__:"):]
        if not table_uri.startswith("s3://"):
            bucket = conn_config.get("bucket_name", "")
            table_uri = f"s3://{bucket}/{table_uri.lstrip('/')}"
        return _duckdb_iceberg_source(table_uri)
    if f.startswith("s3://"):
        if _is_onprem_direct:
            # On-prem S3: pre-sign individual file URL (BF-13)
            from core.s3_utilities import s3_urls_to_presigned as _dg_presign, make_s3_client_for_conn as _dg_make_s3
            _dg_s3 = _dg_make_s3({"id": connection_id, "config": conn_config})
            _dg_signed = _dg_presign(_dg_s3, [f], conn_config)
            safe = _dg_signed[0].replace("'", "''")
        else:
            safe = f.replace("'", "''")
        return f"read_parquet('{safe}')"
    return _duckdb_source(Path(f))


def _preview_plain_parquet_paths(files, conn_config, connection_id,
                                 _is_onprem_direct):
    """Quoted paths for a read_parquet([...]) union, or None.

    None means at least one ref is Iceberg, which has no list-reader form --
    the caller then emits an explicit UNION ALL BY NAME instead.
    """
    # Detect if all sources are plain parquet (local or S3) — no iceberg
    plain_parquet_paths = []
    for f in files:
        if f.startswith("__iceberg__:"):
            return None
        if f.startswith("s3://"):
            if _is_onprem_direct:
                from core.s3_utilities import s3_urls_to_presigned as _dg_presign2, make_s3_client_for_conn as _dg_make_s3_2
                _dg_s3_2 = _dg_make_s3_2({"id": connection_id, "config": conn_config})
                _dg_signed2 = _dg_presign2(_dg_s3_2, [f], conn_config)
                plain_parquet_paths.append(f"'{_dg_signed2[0].replace(chr(39), chr(39)*2)}'")
            else:
                plain_parquet_paths.append(f"'{f.replace(chr(39), chr(39)*2)}'")
        else:
            plain_parquet_paths.append(f"'{Path(f).resolve().as_posix().replace(chr(39), chr(39)*2)}'")
    return plain_parquet_paths


def _preview_from_clause(files, sources, conn_config, connection_id,
                         _is_onprem_direct):
    """Decide the preview's FROM clause: one source, a parquet list, or a UNION."""
    if len(sources) == 1:
        return sources[0]
    plain_parquet_paths = _preview_plain_parquet_paths(
        files, conn_config, connection_id, _is_onprem_direct)
    if plain_parquet_paths is not None:
        return f"read_parquet([{', '.join(plain_parquet_paths)}], union_by_name=true)"
    return (
        "(" + " UNION ALL BY NAME ".join(f"SELECT * FROM {s}" for s in sources) + ")"
    )


def _preview_reset_presigned_signing(con, from_clause) -> None:
    """Stop httpfs re-signing a URL that is already pre-signed.

    2026-06-23 -- defense in depth.  TODAY the on-prem
    presigned branches in _preview_source_expr /
    _preview_plain_parquet_paths only fire when
    _is_onprem_direct=True, which means the factory already
    skipped SET s3_endpoint -- no double-signing risk.  But
    if a future change starts presigning under VPC-native
    too (the way s3_urls_to_presigned's VPC inline branch
    would silently activate for vpce-* endpoints), the
    connection still has s3_endpoint set and httpfs would
    re-sign the URL.  Scan + reset is a no-op when there's
    nothing to reset.
    """
    try:
        from core.duckdb_s3_plan import (
            sql_has_presigned_marker,
            reset_s3_signing_on_connection,
        )
        if sql_has_presigned_marker(from_clause):
            reset_s3_signing_on_connection(con)
    except Exception:
        pass


def _preview_valid_cols(con, from_clause):
    """Read the preview source's column names.

    A schema that cannot be read is a 400 naming the sanitised source
    error, never an empty column list.
    """
    try:
        return con.execute(f"SELECT * FROM {from_clause} LIMIT 0").fetchdf().columns.tolist()
    except Exception as exc:
        from core.error_sanitizer import sanitize_error as _se
        raise HTTPException(status_code=400, detail=f"Cannot read source schema: {_se(str(exc))}")


def _preview_total_rows(con, from_clause, where, params):
    """Count the matching rows; -1 when the count itself fails.

    -1 is "unknown", deliberately NOT 0: the rows below it are real, and a
    0 here would read as an empty result.
    """
    try:
        return int(con.execute(
            f"SELECT COUNT(*) FROM {from_clause}{where}", params or []
        ).fetchone()[0])
    except Exception as exc:
        _logger.warning("Preview COUNT(*) query failed, using -1: %s", exc, exc_info=True)
        return -1


def _direct_preview_run(req, adv, conn_config) -> dict:
    """Run one direct preview on a DuckDB connection and shape the response."""
    has_remote  = any(f.startswith("s3://") or f.startswith("__iceberg__:") for f in req.files)
    has_iceberg = any(f.startswith("__iceberg__:") for f in req.files)

    con = _duckdb_con_with_s3(conn_config, req.connection_id) if (has_remote and conn_config) else _duckdb_con()
    try:
        if has_iceberg:
            _ensure_iceberg_extension(con)

        from core.s3_utilities import get_s3_access_mode as _get_access_mode_direct
        _is_onprem_direct = (_get_access_mode_direct(conn_config) == "presigned") if conn_config else False
        sources = [
            _preview_source_expr(f, conn_config, req.connection_id, _is_onprem_direct)
            for f in req.files
        ]

        if not sources:
            return {"columns": [], "rows": [], "total_rows": 0, "returned": 0}

        from_clause = _preview_from_clause(
            req.files, sources, conn_config, req.connection_id, _is_onprem_direct)

        _preview_reset_presigned_signing(con, from_clause)

        valid_cols = _preview_valid_cols(con, from_clause)

        select_cols = (
            ", ".join(_q(c) for c in req.columns if c in valid_cols) or "*"
            if req.columns else "*"
        )

        where, params = _build_where(adv, valid_cols)

        total_rows = _preview_total_rows(con, from_clause, where, params)

        limit_n = min(req.limit, 5000)
        df = con.execute(
            f"SELECT {select_cols} FROM {from_clause}{where} LIMIT {limit_n}", params or []
        ).fetchdf()
        df = _serialize_df(df)

        return {
            "columns":    df.columns.tolist(),
            "rows":       df.to_dict("records"),
            "total_rows": total_rows,
            "returned":   len(df),
        }
    finally:
        con.close()


@router.post("/api/query/preview")
async def direct_preview(req: _PreviewRequest,
                         _user: dict = Depends(require_capability("bqb.view"))):
    """Return up to `limit` rows from source files without creating any execution
    record or writing any result file to disk.

    Supports local parquet/csv/json, S3 parquet (via httpfs), and S3 Iceberg
    tables (via iceberg_scan — __iceberg__: prefix).
    Date expressions in adv_filters are resolved before the query is issued.

    ROW SECURITY (2026-08-20)
    -------------------------
    This endpoint took ``_user`` and then never referenced it again: it built
    ``SELECT ... FROM <files> WHERE ...`` and ran it straight against DuckDB
    with no ``secure_sql`` call and no ownership check.  Every other execution
    surface filters — published views (``_execute_view`` -> ``secure_sql``),
    the structured REST path, the SQL editor, reports — so the SAME governed
    table was filtered through /api/execute and UNFILTERED through here.
    The refusal and its reasoning live in
    :func:`_refuse_preview_under_rls`.

    The check is live: ``row_security.enabled`` is True by default since
    2026-09-26 (F0), so the moment the old behaviour would have started
    leaking rows is now every deployment's first day.
    The richer fix is to route preview through the same secured executor the
    structured path uses, which is a design change, not a guard.
    """
    _refuse_preview_under_rls()

    from core.date_resolver import resolve_adv_filters

    adv = resolve_adv_filters(req.adv_filters)
    conn_config: dict = await _preview_conn_config(req.connection_id)

    try:
        return await _aduckdb(lambda: _direct_preview_run(req, adv, conn_config))
    except HTTPException:
        raise
    except Exception as exc:
        from core.error_sanitizer import sanitize_error as _se
        raise HTTPException(status_code=500, detail=_se(str(exc)))
