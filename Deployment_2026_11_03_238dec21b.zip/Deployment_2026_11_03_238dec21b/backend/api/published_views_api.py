"""
Phase 75 — Published Views API.

Exposes saved queries as external REST endpoints for programmatic access.
Two sets of endpoints:
  1. Management (internal): publish/manage views, API keys — requires admin/analyst auth
     → Split to api/published_views/management.py (Phase 133-B)
  2. External consumer (/api/v1/views): data access — requires API key auth
     → Kept here (core file)

Traffic isolation:
  - Dedicated asyncio.Semaphore (max_concurrent from config)
  - Response caching (parquet files, configurable TTL per view)
  - Per-API-key rate limiting via slowapi

Phase 80 additions:
  - Runtime parameters:
      ?<name>=value             (preferred — RFC-safe bare form)
      ?param[<name>]=value      (back-compat — required when the param
                                 name collides with a framework query
                                 param like ``limit``, ``format``, etc)
    Both substitute {{<name>}} placeholders in the frozen query_config.
  - In-flight deduplication: concurrent identical requests share one execution
  - Cross-connection secondary engine support in _execute_view()

Phase 133-B: Split into sub-package (models, helpers, management) — this file
retains router, DI, globals, external endpoints, and execution engine.
"""
from __future__ import annotations

import asyncio
import logging
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from api.connector_errors import (
    failure_status as _failure_status,
    raise_if_self_clearing as _raise_if_self_clearing,
)
from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from fastapi.responses import JSONResponse

from api.deps import get_api_key_or_ad_user

# ── Phase 133-B: Import from sub-package ─────────────────────────────────────
# Models — re-exported for backward compatibility
from api.published_views.models import (  # noqa: F401
    ParamDefinition, PublishViewRequest, UpdateViewRequest,
    CreateApiKeyRequest, UpdateQueryConfigRequest, DetectPartitionsRequest,
    ImportViewRequest, WebhookCreateRequest, WebhookUpdateRequest,
)
from core.db_async import adb
from core.reports.preloaded import copy_view as _copy_view, served_db_for as _served_db_for

# Helpers — re-exported for backward compatibility
from api.published_views.helpers import (  # noqa: F401
    query_items_of as _query_items_of,
    _export_view_dict, _parse_rate_limit, _enforce_api_key_rate_limit,
    _check_key_scope, _check_view_access, _parse_filters,
    _parse_params, _validate_param_types, _substitute_params,
    _build_cache_key, _user_cache_scope, _report_version_scope,
    user_cache_scope_async as _user_cache_scope_async,
    pv_cache_path,
    _build_json_envelope, _extract_schema_from_config,
    _extract_schema_from_cache, _build_col_meta,
    _clear_view_cache, _read_cached_result,
    _csv_response, _parquet_download, _excel_response, _log_access, served_rows,
    _build_cache_hit_headers, _build_miss_headers, _send_response,
    _pv_stream_enabled,
    # P4 (2026-08-17) — serve-time limit resolution (NULL row values follow the
    # live published_views config; 0 = unlimited, product-wide spelling).
    resolve_view_limits, effective_page_limit, PV_UNLIMITED_ROWS,
)
# 2026-09-29 -- the paged CEILING rule (a page at or past a capped dataset's
# last servable row is 416, never an empty 200).  Called at the /data route's
# three exits before the access log; _send_response is the format backstop.
from api.published_views.envelope import refuse_past_ceiling as _refuse_past_ceiling
from api.published_views import cold_flight as _cold_flight
# 2026-10-04 -- the per-worker memory guard: new LARGE work (bulk, an
# uncached materialisation) is refused 503 + Retry-After while this worker
# is near its share of the pod's memory, and a give-back of retained memory
# is requested when large work ends.  See api/published_views/memory_guard.py.
from api.published_views.memory_guard import (
    large_work_finished as _large_work_finished,
    refuse_under_memory_pressure as _refuse_under_memory_pressure,
)
# 2026-10-10 -- dataset-file work (the parquet footer, the manifest sidecar,
# a page's Arrow decode, its rows) and the rate-limit store's round trip run
# OFF the event loop on dedicated lanes: api/published_views/page_io.py is
# THE rule.  Measured before it: 4.6 s of a 6 s window blocked at 32
# concurrent cached /data calls, a 50-row page p50 0.76 s.
from api.published_views import page_io as _page_io
#: What each guarded piece of large work is called in a refusal sentence.
_LARGE_DATA_MISS = "an uncached /data materialisation"
_LARGE_BULK_EXPORT = "a bulk export"
_LARGE_BULK_MANIFEST = "a bulk manifest (materialises the dataset)"
_LARGE_BULK_BUILD = "a background bulk build"

# Management router + endpoint functions — re-exported for backward compatibility
from api.published_views.management import (  # noqa: F401
    mgmt_router, set_management_deps,
    publish_view, list_views, get_view, update_view, deactivate_view,
    republish_view, detect_partitions, export_view, export_all_views,
    import_views, update_view_query, get_view_usage,
    create_api_key, list_api_keys, reveal_api_key, revoke_api_key,
    list_webhooks, create_webhook, update_webhook, delete_webhook,
)
from core.best_effort import note_best_effort

logger = logging.getLogger(__name__)

router = APIRouter()

# Include management endpoints (publish, API keys, webhooks, export/import)
router.include_router(mgmt_router)

# ── Module-level singletons — populated by set_published_views_dependencies() ─
_db_manager = None
_pv_cfg = None
_concurrency_sem: Optional[asyncio.Semaphore] = None
_cache_dir: Optional[Path] = None
_federation_engine = None  # Phase 91

class _InflightEvent(asyncio.Event):
    """The in-process half of a cold MISS's single flight: set once the
    leader's dataset is PUBLISHED (or it failed), carrying the failure its
    duplicates give -- ``failure`` is ``cold_flight.failure_outcome``."""
    failure: Optional[Dict[str, Any]] = None


# In-flight dedup registry: (view_id, cache_key) → _InflightEvent
_pv_inflight: Dict[tuple, asyncio.Event] = {}


def _materialisation_busy(slug: str, waited_s: float) -> HTTPException:
    """A duplicate whose wait ran out while its leader is ALIVE and still
    materialising: 503 + Retry-After, never a second materialisation."""
    _ra = _cold_flight.retry_after_seconds()
    return HTTPException(
        503,
        f"The dataset for this request is being materialised by an identical "
        f"request right now (waited {waited_s:.0f}s for it). Retry in {_ra}s -- "
        f"it is served from the cache as soon as it is published.",
        headers={"Retry-After": str(_ra), "X-QS-Refused": "materialisation_in_progress"},
    )

# 2026-09-29: the per-API-key concurrent request counter that lived here
# (``_per_key_active``, checked on /data at published_views.max_concurrent_
# per_key with a 429) is GONE.  "May this caller run another query" is
# answered ONCE, by the slot grant every handler takes
# (core.reports.admission.QuerySlot): an API-key identity is bounded by that
# same key, a person by query_engine.max_concurrent_per_user.  The bulk
# lane's per-key share (``_bulk_active``, bulk_max_per_key) is a different
# question -- a fair share of a deliberately small lane -- and stays.


def _admission_identity(consumer_user: Optional[Dict[str, Any]],
                        pv: Optional[Dict[str, Any]] = None) -> str:
    """WHO a published-view query's concurrency is charged to (2026-09-29).

    ONE rule for the per-key limiter of the /data and /bulk routes and for
    the per-user part of the global query slot every handler now takes
    (``core.reports.admission.QuerySlot``):

      * an API key  -> ``apikey:<api_key_id>`` -- the row id, not the
        ``key_prefix`` its ``username`` carries: the prefix is 8-12 chars
        "for display" and two keys may share one, and one key must never
        share a bucket with another;
      * a session, AD-Basic or dev-mode Basic caller -> their ``username``
        -- the SAME bucket their interactive ``/api/execute`` queries are
        charged to, because it is the same person and one per-user cap;
      * no consumer at all (warm-up, an internal bridge) -> the view
        itself, ``published_view:<slug>`` -- a deliberately shared bucket,
        because there is no caller to charge.

    Before this the /data and /bulk routes keyed their per-key counters on
    ``api_user.get("api_key_id", username)`` -- a ``dict.get`` DEFAULT,
    which never applies when the key is present with ``None``: every
    session and AD caller was charged to the ONE bucket named ``"None"``,
    so ten colleagues on the Explorer shared one key's allowance.
    """
    # 2026-10-17 -- ONE spelling for the limiter, the slot AND the call
    # record: core/published_api/calls.consumer_of (the key prefix is the
    # admission module's: published_views.max_concurrent_per_key keys on it).
    from core.published_api.calls import consumer_of
    identity, _method = consumer_of(consumer_user)
    if identity:
        return identity
    return f"published_view:{(pv or {}).get('slug', '')}"


async def _view_refusal(slug: str) -> HTTPException:
    """What a consumer is answered when the ACTIVE lookup found no view for
    ``slug`` (2026-10-17, core/published_api/lifecycle.py): a RETIRED API is
    ``published_views.lifecycle_retired_status`` (410) with the note and the
    successor in the body and the headers; a draft or a slug that never
    existed is 404.  One small read, OFF the loop, on the refused path only
    -- the hot path's active lookup is untouched."""
    from core.published_api.lifecycle import refusal_for
    info = None
    try:
        info = await adb(_db_manager.get_published_view_lifecycle, slug)
    except Exception as exc:                            # noqa: BLE001 -- unknown reads as not found, said
        logger.warning("[pv] lifecycle of %r unreadable (%s): answering not found", slug, exc)
    r = refusal_for(info, slug=slug, kind_word="view")
    return HTTPException(r["status"], r["detail"], headers=r["headers"] or None)


def _pv_http_reason(exc: HTTPException) -> str:
    """The sentence an execution row records for an ``HTTPException`` the
    published-view handler raised (2026-10-07, F11): its status and its
    detail -- a dict detail (``query_not_expressible``) by its message."""
    detail = exc.detail
    if isinstance(detail, dict):
        detail = detail.get("message") or detail.get("error") or detail
    return f"HTTP {exc.status_code}: {detail}"[:2000]


async def _settle_pv_execution(execution_id: str, status: str,
                               reason: Optional[str]) -> None:
    """Close a published-view execution row the handler is leaving.

    2026-10-07 (F11) -- ONE place, called from the handler's ``finally``
    once its row exists.  ``finalise_execution_if_pending`` is a single
    conditional UPDATE (``WHERE status = 'pending'``): a row an executor
    already moved on (processing / completed / failed / a sticky cancel)
    is never touched, so this is a no-op on every normal exit and the
    outcome on every exit no executor reached -- a 4xx raised before the
    engine, an executor that failed to start, a cancel.  Never raises: it
    runs in a ``finally`` and must not replace the exception in flight.
    """
    try:
        await adb(_db_manager.finalise_execution_if_pending, execution_id,
                  status=status, error_message=reason or "")
    except Exception as exc:
        note_best_effort("finalise published-view execution row", exc,
                         logger=logger, level=logging.WARNING)


def _sem_permits(configured, *, name: str) -> int:
    """Permit count for a concurrency semaphore, honouring 0 = UNLIMITED.

    2026-08-22 — delegates to core.concurrency_permits, the single definition.
    This was one of THREE private copies; the audit found the two semaphore
    constructors that never got the fix (published_views/warmup, graphql_api),
    which is what a copied fix always ends up costing.
    """
    from core.concurrency_permits import sem_permits as _sp
    return _sp(configured, name=name)


def set_published_views_dependencies(db_manager, pv_cfg, federation_engine=None, ws_manager=None) -> None:
    """Called once from main.py startup."""
    global _db_manager, _pv_cfg, _concurrency_sem, _cache_dir, _federation_engine
    _db_manager = db_manager
    _pv_cfg = pv_cfg
    _federation_engine = federation_engine  # Phase 91
# 2026-08-20 -- A ZERO-PERMIT SEMAPHORE IS AN OUTAGE, NOT A LIMIT.
    # These accessors are raw int(get(...)) with no clamp, so a configured
    # 0 -- which everywhere else in this product spells UNLIMITED, including
    # published_views.max_concurrent_per_key in this very module --
    # constructed a semaphore that can never be acquired:
    #   ETL  : threading acquire() with NO timeout -> hangs FOREVER, silently
    #   feed : acquire(timeout=300)                -> total outage after 300s
    #   PV   : asyncio.Semaphore(0) is TRUTHY, so it passes the readiness
    #          guard, then every request burns 30s and 429s
    # _sem_permits treats <=0 as 'no limit' so the operator's spelling means
    # what it means everywhere else.
    # 2026-10-03 -- the PV lane is a POD budget: an N-process pod gives each
    # process 1/N of it (core.process_topology; N = 1 leaves it whole).
    from core.process_topology import per_process_share as _pp_share
    _concurrency_sem = asyncio.Semaphore(
        _sem_permits(_pp_share(pv_cfg.max_concurrent), name='published_views'))
    _cache_dir = Path(pv_cfg.cache_dir)
    _cache_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Published Views API: max_concurrent=%d, cache_dir=%s",
                pv_cfg.max_concurrent, _cache_dir)
    # Phase 133-B: propagate deps to management module
    set_management_deps(db_manager, pv_cfg, _cache_dir, federation_engine, ws_manager=ws_manager)


# ══════════════════════════════════════════════════════════════════════════════
# EXTERNAL CONSUMER ENDPOINTS (/api/v1/ prefix — API key auth)
# ══════════════════════════════════════════════════════════════════════════════


def _shared_write_refused(shared_slot: Optional[bool], slug: str) -> bool:
    """2026-10-16 -- the cross-user leak the clean release check found: the
    slot's key was chosen BEFORE the query (shared: "no row policies"), the
    query's own rewrite then applied a policy created on another pod, and the
    FILTERED rows were published where every consumer reads (lt_10 was served
    lt_01's AFRICA rows).  A write into a slot that is -- or may be -- the
    UNSCOPED one needs a FRESH confirmation that no policy exists.  A caller
    that knows its slot is per-principal passes ``shared_slot=False``;
    ``None`` (unknown) is checked like shared.  Returns True to SKIP."""
    if shared_slot is False:
        return False
    from core.row_security.cache_scope import confirm_shared_slot
    if confirm_shared_slot():
        return False
    logger.warning("[pv-cache] view=%s: NOT cached -- the slot is the shared one and a "
                   "row-security policy now exists (decided before the query ran)", slug)
    return True


def _persist_result_to_cache(result: dict, cached_path: Path, *, slug: str = "?",
                             shared_slot: Optional[bool] = None) -> bool:
    """SINGLE chokepoint that publishes a materialized dataset into the shared
    response cache: atomic parquet copy (tmp + rename) PLUS the
    ``DatasetManifest`` truth sidecar.  Used by the request path AND the
    warmup loop — the two can no longer drift (the warmup loop used to
    execute views without ever writing this cache, burning S3 every 5
    minutes while consumers still got a MISS).  Returns True when the cache
    entry (and its manifest, when available) was published.

    F3 (2026-08-08) — PUBLISH ORDER.  A dataset and the manifest that tells
    the truth about it are two files, so there is always a window where a
    reader can see one without the other.  The old order made that window
    lethal: parquet first, sidecar second, so a reader landing in between
    bound the NEW parquet to the OLD manifest, advertised the old (smaller)
    ``total_rows``, streamed exactly that many rows of a larger dataset, and
    the consumer's reconcile PASSED on a truncated export.  The warmup loop
    rewrites the same key every 5 minutes, so a background job walks through
    this window routinely — this is not a rare race.

    Two changes make the window fail-CLOSED instead of silently-wrong:

      1. The stale sidecar is REMOVED before the new parquet is published, so
         a reader in the window finds no manifest at all.  No manifest =>
         ``total_mode="unknown"`` => the bulk materializer re-materializes and
         ``/data`` reports unknown.  Honest and recoverable, both of them.
      2. The new sidecar STAMPS the identity of the parquet it describes
         (``write_sidecar(bind=True)``), so even a sidecar that survives a
         crash, or two writers interleaving, can be checked by the reader
         (``DatasetManifest.read_bound``) instead of trusted.

    NOTE: this function does blocking file I/O (``shutil.copy2`` of the whole
    dataset).  ASYNC callers must use ``_persist_result_to_cache_async``.
    """
    src = result.get("_parquet_path")
    if not cached_path or not src:
        return False
    if _shared_write_refused(shared_slot, slug):
        return False
    _tmp_path = None
    try:
        import os as _os
        import shutil
        import uuid as _uuid
        from api.published_views.envelope import manifest_sidecar_path
        srcp = Path(str(src))
        if not srcp.exists():
            return False
        # 2026-08-20 — UNIQUE staging name per publish.  The old fixed
        # ``.tmp`` suffix was DETERMINISTIC, so the warmup loop, a
        # live consumer request and the GraphQL resolver publishing the same
        # dataset slot all copied into the SAME .tmp concurrently — and each
        # ``replace()`` promoted the interleaved mixture into the live cache
        # file.  The rename stays atomic; the staging path must be private.
        _tmp_path = cached_path.with_name(
            f"{cached_path.name}.{_os.getpid()}-{_uuid.uuid4().hex[:8]}.tmp")
        shutil.copy2(str(srcp), str(_tmp_path))
        _m = result.get("_manifest")
        # Stamp the identity of the bytes we are ABOUT to publish, read from
        # the staging copy — not from the destination after the rename, where
        # a competing publisher's file could be stamped instead.
        if _m is not None:
            _m.bind_to_file(_tmp_path)
        # Retire the previous truth BEFORE the new bytes land: for the
        # microseconds between the two renames a reader must find "no
        # manifest" (unknown => fail closed), never "old manifest" (a stale
        # smaller total => silent truncation that reconciles clean).
        try:
            manifest_sidecar_path(cached_path).unlink(missing_ok=True)
        except OSError as _sx:
            logger.warning("Could not retire stale manifest for view '%s': %s", slug, _sx)
        _tmp_path.replace(cached_path)
        if _m is not None:
            _m.write_sidecar(cached_path, bind=False)
        return True
    except Exception as exc:
        logger.warning("Cache write failed for view '%s': %s", slug, exc)
        # 2026-08-20 — with unique staging names a failed publish would
        # otherwise strand its .tmp forever (the next publish no longer
        # overwrites the same path).  Best-effort cleanup of OUR file only.
        try:
            if _tmp_path is not None:
                _tmp_path.unlink(missing_ok=True)
        except OSError as _tmp_rm_exc:
            # Not silent: a staging file we cannot remove is a slow disk leak,
            # and on Windows it usually means another handle is still open.
            logger.debug("[pv-cache] could not remove staging file %s: %s",
                         _tmp_path, _tmp_rm_exc)
        return False



async def _persist_result_to_cache_async(result: dict, cached_path: Path, *,
                                         slug: str = "?",
                                         shared_slot: Optional[bool] = None) -> bool:
    """Await ``_persist_result_to_cache`` off the event loop.

    2026-08-08 — the sync form copies the ENTIRE dataset with
    ``shutil.copy2``.  Called directly from an async endpoint that is exactly
    the known "API pod restarts = blocked event loop failing kubelet probes"
    pattern: for a multi-GB bulk dataset the loop is frozen for the whole
    copy, ``/health`` is starved, the kubelet kills the pod, and every
    interactive user on it loses their session — a bulk export taking the
    product down without a single error being logged.  The copy releases the
    GIL inside the C read/write calls, so a worker thread is the right home
    for it.
    """
    return await asyncio.to_thread(_persist_result_to_cache, result, cached_path, slug=slug,
                                   shared_slot=shared_slot)


def _apply_cached_manifest(result: dict, cached_path: Path) -> dict:
    """Merge the cached dataset's manifest truth into a page result.

    Missing / unreadable sidecar → ``total_mode: "unknown"`` — the envelope
    degrades honestly instead of implying exactness (UNKNOWN=UNSAFE is the
    fallback, never the strong claim).

    F3 (2026-08-08) — the manifest is accepted only when it PROVABLY describes
    the parquet just read.  The paged path has the same silent-truncation
    exposure as bulk: a stale manifest's smaller ``total_rows`` clamps the
    reported total, so ``/data`` reports fewer rows than the dataset holds and
    ``has_more`` goes false early — a truncated page set that looks complete.
    The file's identity is already in hand (``total_rows`` here is the parquet
    FOOTER count from ``read_page``), so verification costs one ``stat``."""
    from api.published_views.envelope import DatasetManifest
    try:
        _size = cached_path.stat().st_size
    except OSError:
        _size = None
    _rows = result.get("total_rows")
    m, _verified = DatasetManifest.read_bound(
        cached_path, size=_size,
        rows=(int(_rows) if isinstance(_rows, int) else None),
    )
    if m is None:
        result.setdefault("total_mode", "unknown")
        return result
    if m.total_mode.value == "at_least":
        # The capped dataset file holds cap+1 rows (overflow sentinel); the
        # manifest's total (== cap) is the honest reportable bound.
        try:
            result["total_rows"] = min(int(result.get("total_rows") or m.total_rows),
                                       int(m.total_rows))
        except (TypeError, ValueError):
            result["total_rows"] = m.total_rows
        # 2026-09-29 -- and the PAGE stops there too.  The MISS path clamps
        # its read window to the cap and the bulk lane refuses to emit the
        # sentinel; this HIT reader had already read ``offset + limit`` rows
        # of the file, so a page reaching the cap served row cap+1 -- the
        # sentinel, not data -- to the consumer (REST and GraphQL alike).  A
        # page-bounded prefix (``scan_bound``) is not clamped: its rows are
        # all measured data and ``_paged_entry_covers`` already refused any
        # page it does not hold.
        if m.scan_bound is None:
            _clamp_page_to_ceiling(result, ceiling=int(result["total_rows"]))
    return m.apply_to_result(result)


def _clamp_page_to_ceiling(result: dict, *, ceiling: int) -> None:
    """Trim a page read from a capped dataset file so no row at or past
    ``ceiling`` (the overflow sentinel) reaches the wire.  In place; every
    representation of the page (``data``, ``_page_table``, ``_stream_df``)
    and ``returned_rows`` agree afterwards."""
    try:
        _off = max(0, int(result.get("offset") or 0))
        _returned = int(result.get("returned_rows") or 0)
    except (TypeError, ValueError):
        return
    keep = max(0, int(ceiling) - _off)
    if _returned <= keep:
        return
    for key in ("_page_table", "_stream_df"):
        tbl = result.get(key)
        if tbl is not None and hasattr(tbl, "slice"):
            result[key] = tbl.slice(0, keep)
    data = result.get("data")
    if isinstance(data, list) and len(data) > keep:
        result["data"] = data[:keep]
    result["returned_rows"] = keep


def _paged_entry_covers(cached_path: Path, offset: int, limit: int,
                        sort_column: Optional[str]) -> Tuple[bool, int]:
    """Can this paged cache entry answer THIS page?  ``(covers, file_rows)``.

    2026-09-15 — a paged MISS may publish a PAGE-BOUNDED prefix into the slot
    (``DatasetManifest.scan_bound``).  Such an entry is truth about the rows it
    holds and nothing beyond them, so a page that reaches past it -- or a
    ``?sort``, which needs the whole dataset -- is a MISS that re-materialises
    wider (``file_rows`` is the floor the caller regrows from).  Unchanged for
    every full materialisation, and for an entry with no verifiable manifest
    (the reader already degrades that to ``total_mode=unknown``).  One
    footer read; the page reader reads the same footer again.
    """
    try:
        import pyarrow.parquet as _pq
        _size = cached_path.stat().st_size
        _rows = int(_pq.ParquetFile(str(cached_path)).metadata.num_rows)
    except Exception as exc:
        logger.debug("[pv-cache] coverage probe could not read %s: %s", cached_path, exc)
        return True, 0
    from api.published_views.envelope import DatasetManifest
    m, _verified = DatasetManifest.read_bound(cached_path, size=_size, rows=_rows)
    if m is None:
        return True, _rows
    return (m.covers_page(offset=offset, limit=limit, sort_column=sort_column,
                          file_rows=_rows), _rows)


def _paged_entry_safe_to_sort(cached_path: Path, slug: str = "?") -> bool:
    """Is this cache entry small enough for the SORT read that materializes it?

    F2 backstop.  ``envelope.read_page``'s sort branch is the one reader whose
    memory scales with the DATASET rather than the page: a global sort cannot be
    evaluated from a prefix, so it reads every value of the sort column
    (2026-10-04, ``envelope.sorted_page_rows``; before that ``pq.read_table``
    over the whole file) -- still O(dataset) for that one column.
    Everything else on the paged path is bounded by ``offset + limit`` and
    therefore by ``max_limit``.

    Separating the bulk cache slot stops NEW uncapped datasets from ever
    reaching this reader, but it cannot un-write the ones the previous build
    already published into the paged slot — at upgrade those files are sitting
    there, and the first interactive ``/data?sort=col`` against one would still
    OOM the pod.  So the reader checks, from the FOOTER (O(1), no row data),
    that the entry is actually a paged dataset before agreeing to materialize
    it.

    Returning False is a cache MISS, not an error: the request re-executes
    under the paged cap and the slot self-heals.  A cap that THROTTLES.
    Checked only on the sort path, so the ~1000 interactive users on unsorted
    reads pay nothing for it.
    """
    try:
        from api.published_views.envelope import dataset_row_cap
        cap = dataset_row_cap()
        if cap <= 0:
            return True                       # no paged cap configured
        import pyarrow.parquet as _pq
        rows = int(_pq.ParquetFile(str(cached_path)).metadata.num_rows)
        # cap + 1 is the legitimate size: the overflow sentinel row.
        if rows <= cap + 1:
            return True
        logger.error(
            "[pv-cache] paged cache entry %s holds %d rows, above the %d-row "
            "dataset cap — refusing to sort-materialize it and re-executing. "
            "An entry this size was written by the bulk path before bulk got "
            "its own cache slot; sorting it would load the whole dataset into "
            "memory and take the pod down for every interactive user. "
            "view=%s",
            cached_path.name, rows, cap, slug,
        )
        return False
    except Exception as exc:
        # Cannot verify => do not materialize.  UNKNOWN = UNSAFE, and the only
        # cost of being wrong is one re-execution.
        logger.warning(
            "[pv-cache] could not size-check paged entry %s (%s) — treating as "
            "unsafe to sort and re-executing", cached_path, exc,
        )
        return False


def _ensure_ready() -> None:
    """Phase 133-C: Guard — return 503 if dependencies not injected yet."""
    if _db_manager is None:
        raise HTTPException(503, "Service not ready — dependencies not initialized")


async def _served_report_version_scope(pv: dict, sdb) -> Optional[str]:
    """``_report_version_scope`` through the request's manager (2026-10-03).

    When ``sdb`` answers from the rows read with the view
    (``core.reports.preloaded.served_db_for``) the lifecycle identity costs no
    read, so it is computed inline -- a thread hop per request for no I/O is
    pure overhead at load.  Otherwise it reads, off the event loop, as before.
    """
    if sdb is not None and sdb is not _db_manager:
        return _report_version_scope(pv, sdb)
    return await adb(_report_version_scope, pv, sdb)



def _merge_filters_or_refuse(static_filters, consumer_filters, dynamic_columns=None):
    """The published-view merge: a consumer filter on a publisher-FIXED column
    is REFUSED (400 naming it), never silently replaced by the publisher's
    value.  One wrapper for the three serving paths (edge-case sweep
    2026-09-24)."""
    from core.where_clause_mapping import (
        LockedFilterOverride, merge_static_and_consumer_filters,
    )
    try:
        return merge_static_and_consumer_filters(
            static_filters=static_filters, consumer_filters=consumer_filters,
            dynamic_columns=dynamic_columns, refuse_locked=True)
    except LockedFilterOverride as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get("/api/v1/views")
async def ext_list_views(api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """List published views accessible to this caller (API key or AD user)."""
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)
    if _pv_cfg and not _pv_cfg.enabled:
        raise HTTPException(503, "Published Views API is disabled")
    all_views = await adb(_db_manager.list_published_views, active_only=True)

    # Filter to only views this caller may access
    accessible = []
    for v in all_views:
        try:
            _check_view_access(v, api_user)
            accessible.append(v)
        except HTTPException:
            pass  # silently exclude views the caller cannot access

    # Return metadata (no query_config) — includes version for change detection
    # P4 (2026-08-17): limits are the EFFECTIVE serve-time values (NULL rows
    # follow live config; 0 = unlimited) so consumers see the real contract.
    return [
        {
            "slug": v["slug"],
            "name": v["name"],
            "description": v["description"],
            "allowed_filters": v["allowed_filters"],
            "default_limit": resolve_view_limits(v)[0],
            "max_limit": resolve_view_limits(v)[1],
            "param_definitions": v.get("param_definitions") or [],
            "allowed_ad_groups": v.get("allowed_ad_groups") or [],
            "source_type": v.get("source_type", "saved_query"),
            "version": v.get("version", 1),
            "cache_ttl_seconds": v.get("cache_ttl_seconds", 28800),
        }
        for v in accessible
    ]


@router.get("/api/v1/views/{slug}")
async def ext_get_view_meta(slug: str, api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
                            response: Response = None):  # type: ignore[assignment]  -- FastAPI injects it (a plain Response annotation; Optional is refused)
    """Get view metadata including schema and allowed filters.

    ``response`` (2026-10-17) carries the lifecycle headers; FastAPI injects
    it, a direct in-process caller may omit it (the headers are then nowhere
    to put, the body still carries ``lifecycle``)."""
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)
    if _pv_cfg and not _pv_cfg.enabled:
        raise HTTPException(503, "Published Views API is disabled")
    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv:
        raise await _view_refusal(slug)

    _check_view_access(pv, api_user)

    # Extract column schema from frozen query_config
    columns = _extract_schema_from_config(pv["query_config"])

    # 133-F: fallback to cached parquet schema if config has no selected_columns
    if not columns:
        columns = _extract_schema_from_cache(pv["id"], _cache_dir)

    # P4 (2026-08-17): effective serve-time limits (see ext_list_views).
    _eff_default, _eff_max = resolve_view_limits(pv)
    # FB-38 (2026-09-19): ask before you pull.  True / False / null (could
    # not be determined), with the sentence the data routes refuse with.
    _tt_supported, _tt_reason = await _time_travel_capability_for(pv)
    from core.published_api.lifecycle import consumer_headers as _lifecycle_headers, lifecycle_of as _lifecycle_of
    _meta = {
        "slug": pv["slug"],
        "name": pv["name"],
        "description": pv["description"],
        "allowed_filters": pv["allowed_filters"],
        "default_limit": _eff_default,
        "max_limit": _eff_max,
        "columns": columns,
        "cache_ttl_seconds": pv["cache_ttl_seconds"],
        "param_definitions": pv.get("param_definitions") or [],
        "allowed_ad_groups": pv.get("allowed_ad_groups") or [],
        "source_type": pv.get("source_type", "saved_query"),
        "version": pv.get("version", 1),
        "time_travel_supported": _tt_supported,
        "time_travel_unavailable_reason": _tt_reason,
        # 2026-11-01 -- where a consumer lists the versions it may ask for
        # (one entry per Iceberg table the view reads; the list itself is
        # GET /api/v1/views/{slug}/versions -- core/iceberg_versions.py).
        "table_versions": ([{"table": _t, "versions_url":
                             f"/api/v1/views/{pv['slug']}/versions?table={_t}"}
                            for _t in await _view_iceberg_tables(pv)]
                           if _tt_supported else []),
        # 2026-10-17 -- the lifecycle a consumer should plan around
        # (core/published_api/lifecycle.py); deprecated adds the headers too
        "lifecycle": _lifecycle_of(pv, bool(pv.get("is_active"))),
    }
    if response is not None:
        for _hk, _hv in _lifecycle_headers(pv).items():
            response.headers[_hk] = _hv
    return _meta


_CONSUMER_DOCS_HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>QueryStudio published APIs</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:760px;margin:40px auto;padding:0 16px;
color:#1d1d1f;background:#fff;line-height:1.5}code{background:#f2f3f5;padding:1px 5px;border-radius:4px}
pre{background:#f2f3f5;padding:12px;border-radius:6px;overflow:auto}h1{font-size:1.5rem}h2{font-size:1.1rem;margin-top:28px}</style>
</head><body>
<h1>QueryStudio published APIs</h1>
<p>Every published API has its <b>own</b> OpenAPI 3.0 document -- its columns and types, filters,
parameters, limits, paging and error answers -- at:</p>
<pre>GET /api/v1/views/&lt;api-name&gt;/openapi.json
X-API-Key: &lt;your key&gt;</pre>
<p>It answers with the same key you call the API with (a key that may not call an API cannot read its
document either).</p>
<h2>Use it in Postman or Swagger</h2>
<p>Postman: <i>Import &rarr; Link</i>, paste the URL above, and set the <code>X-API-Key</code> header.
Swagger UI / Swagger Editor: <i>File &rarr; Import URL</i>. Your team's own test tool can read the same document.</p>
<h2>Call the data</h2>
<pre>GET /api/v1/views/&lt;api-name&gt;/data?limit=100&amp;filter.region=eq:EMEA
X-API-Key: &lt;your key&gt;</pre>
<p>The API Explorer in QueryStudio (menu <i>API Explorer</i>) lists the APIs you may call, builds the request and
downloads each one's OpenAPI document.</p>
<p>The document of the whole service (every route, for platform teams): <a href="/openapi.json">/openapi.json</a>
&middot; interactive: <a href="/api-docs">/api-docs</a>.</p>
</body></html>"""


@router.get("/docs", include_in_schema=False)
async def consumer_docs():
    """2026-10-24 (the owner's plan item 5: "/docs on the published-api pod
    points to the API's documentation instead of a 404").  Where a consumer's
    OWN API is documented -- plain HTML, no external script (on-prem pods have
    no internet)."""
    from fastapi.responses import HTMLResponse
    return HTMLResponse(_CONSUMER_DOCS_HTML)


async def _parse_pv_version_overrides(request: Request, pv: dict, api_user: dict,
                                      snapshot_id, as_of_ms, *, _tt_supported_for: dict):
    """The published API's table-version overrides for ONE call: ``?version.
    <table>=`` / ``?as_of=`` + the legacy pair, through THE parser.  Stamps
    them on the view dict the handler reads (``pv["_version_overrides"]``),
    answers the cache-key text, refuses (422) a version on a view that keeps
    none, and AUDITS an override (``published_api.version_override``)."""
    from core import iceberg_versions as _iv
    try:
        overrides = _iv.parse_version_overrides(
            getattr(request, "query_params", None) if request is not None else None,
            legacy_snapshot_id=snapshot_id, legacy_as_of_ms=as_of_ms)
    except _iv.IcebergVersionRefusal as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    per_table = {k: v for k, v in overrides.items() if k != _iv.EVERY_TABLE}
    if not per_table and not (overrides and (snapshot_id is None and as_of_ms is None)):
        pv.pop("_version_overrides", None)
        return overrides, None
    supported, reason = await _time_travel_capability_for(pv)
    if not supported:
        raise HTTPException(status_code=422 if supported is False else 503, detail=reason)
    tables = {t.lower() for t in await _view_iceberg_tables(pv)}
    for t in per_table:
        if t not in tables:
            raise HTTPException(status_code=422, detail=(
                f"This view does not read an Iceberg table called {t}; it reads "
                f"{', '.join(sorted(tables)) or 'no Iceberg table'}.  Versions are listed at "
                f"/api/v1/views/{pv.get('slug')}/versions."))
    pv["_version_overrides"] = _iv.serialize_overrides(overrides)
    try:
        from core.audit import audit_event
        audit_event(_db_manager, api_user or {}, request, action="published_api.version_override",
                    resource_type="published_view", resource_id=str(pv.get("id")),
                    details={"slug": pv.get("slug"), "versions": pv["_version_overrides"],
                             "consumer": _admission_identity(api_user)})
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("version override audit skipped: %s", exc)
    return overrides, _iv.overrides_key(overrides)


async def _view_iceberg_tables(pv: dict) -> list:
    """The Iceberg tables a view's frozen query reads (the FB-38 decision's
    own list), or [] when its connection cannot be read."""
    from api.published_views.time_travel import iceberg_table_refs
    qc = pv.get("query_config") or {}
    cid = qc.get("connection_id")
    if not cid or _db_manager is None:
        return []
    try:
        rec = await adb(_db_manager.get_connection_raw, int(cid))
    except Exception:                                          # noqa: BLE001
        return []
    return iceberg_table_refs(qc, (rec or {}).get("config") or {})


@router.get("/api/v1/views/{slug}/versions")
async def ext_get_view_versions(slug: str, table: Optional[str] = None, limit: int = 100,
                                api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """2026-11-01 -- the versions (Iceberg snapshots) a consumer may ask a
    view for, newest first, per table: ``?snapshot_id=`` takes a
    ``snapshot_id`` from here, ``?as_of_timestamp=`` a time.  The same
    listing the editor and ``"t$snapshots"`` read; metadata only."""
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)
    if _pv_cfg and not _pv_cfg.enabled:
        raise HTTPException(503, "Published Views API is disabled")
    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv:
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)
    supported, reason = await _time_travel_capability_for(pv)
    if not supported:
        raise HTTPException(status_code=422 if supported is False else 503, detail=reason)
    tables = await _view_iceberg_tables(pv)
    if table is not None:
        if table.lower() not in {t.lower() for t in tables}:
            raise HTTPException(status_code=422, detail=(
                f"This view does not read a table called {table}; it reads "
                f"{', '.join(tables) or 'no Iceberg table'}."))
        tables = [t for t in tables if t.lower() == table.lower()]
    qc = pv.get("query_config") or {}
    rec = await adb(_db_manager.get_connection_raw, int(qc.get("connection_id")))
    cfg = (rec or {}).get("config") or {}
    regs = {str(r.get("name")).lower(): r for r in cfg.get("registered_tables") or []
            if isinstance(r, dict) and r.get("name")}
    from core import iceberg_versions as _iv
    from core.s3_utilities import make_s3_client_for_conn
    s3 = make_s3_client_for_conn({"id": qc.get("connection_id"), "config": cfg})
    out = []
    # 2026-11-01 (security review of 5f04142e9) -- the consumer's rights on the
    # TABLE decide, as on every other listing (core/table_version_access.py):
    # a table it may not read is not listed, a narrowed one shows no counts.
    from core import table_version_access as _tva
    from core.sql_filter_wrapper import dialect_for_connection_type as _dfct
    _consumer = _with_entitlement_scope(api_user, pv) if api_user else api_user
    for t in tables:
        reg = regs.get(t.lower()) or {}
        access = await asyncio.to_thread(
            _tva.access_for, _consumer, reg.get("name") or t,
            connection_id=qc.get("connection_id"),
            dialect=_dfct((rec or {}).get("connection_type")) or "duckdb")
        if access.state == _tva.REFUSED:
            out.append({"table": t, "versions": None, "access": access.state,
                        "reason": access.words})
            continue
        try:
            _k, md = await asyncio.to_thread(
                _iv.read_table_metadata, s3, cfg.get("bucket_name") or cfg.get("bucket") or "",
                reg.get("s3_prefix"), force_fresh=True)
            rows = _tva.public_rows(
                _iv.snapshot_rows(md, limit=max(1, min(int(limit or 100), 1000))), access)
            out.append({"table": t, "versions": rows, "access": access.state,
                        "access_words": access.words})
        except Exception as exc:                               # noqa: BLE001
            out.append({"table": t, "versions": None,
                        "error": _tva.failure_words(t, exc)})
    return {"slug": pv["slug"], "tables": out}


@router.get("/api/v1/views/{slug}/openapi.json")
async def ext_get_view_openapi(slug: str, request: Request,
                               api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """THIS API as an OpenAPI 3.0 document (2026-10-23) -- what a consumer
    team imports into Postman / Swagger UI / their own test tool.  Built from
    the view's meta answer, so the SAME access check, rate limit and lifecycle
    refusal apply (core/published_api/openapi_doc.py)."""
    from core.published_api.openapi_doc import build_view_openapi, server_url_of
    meta = await ext_get_view_meta(slug, api_user=api_user)
    return build_view_openapi(meta, server_url=server_url_of(request))


@router.get("/api/v1/views/{slug}/data")
async def ext_get_view_data(
    request: Request,
    slug: str,
    response: Response,
    limit: Optional[int] = Query(None, ge=0),  # P4: 0 = unlimited (capped by effective max_limit)
    offset: int = Query(0, ge=0),
    sort: Optional[str] = Query(None),
    columns: Optional[str] = Query(None),
    format: str = Query("json", pattern="^(json|csv|parquet|excel|xlsx)$"),
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None, description="Iceberg snapshot ID for time travel (mutually exclusive with as_of_timestamp)"),
    as_of_timestamp: Optional[str] = Query(None, description="ISO8601 timestamp for time travel (e.g. 2024-01-15T00:00:00Z)"),
    engine: Optional[int] = Query(None, description="Phase 146-A — Override the execution engine to a different connection_id (must be in this view's allowed_engine_connections whitelist)."),
    dataset_version: Optional[str] = Query(None, description="The X-QS-Dataset-Version of the first page: every later page must come from the same data, or the answer is 409 (start again)."),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """
    Execute a published view and return data.

    Filters — RFC-safe dot notation (recommended) OR bracketed (back-compat):
      ?filter.column=operator:value      (preferred — no URL-encoding needed)
      ?filter[column]=operator:value     (back-compat — works if your HTTP
                                          client URL-encodes the brackets)
      operators: eq, ne, gt, gte, lt, lte, in, not_in, contains, between
      examples:
        ?filter.region=eq:APAC
        ?filter.year=gt:2024
        ?filter.status=in:active,pending

    Runtime parameters (Phase 80) — bare name (recommended) OR bracketed
    (back-compat):
      ?<name>=value                      (preferred — RFC-safe)
      ?param[<name>]=value               (back-compat — also required
                                          when the parameter name
                                          collides with a framework
                                          query param like ``limit``,
                                          ``format``, ``cache``, etc)
      example:  ?business_close_date=2025-09-30
      Substitutes {{name}} placeholders in the frozen query_config.

    Time travel (Phase 139 honest-fix — Iceberg-backed views only):
      ?snapshot_id=12345 — read this exact Iceberg snapshot
      ?as_of_timestamp=2024-01-15T00:00:00Z — read snapshot current at that time
      The two are mutually exclusive. Cache key includes them so cached
      time-travel results don't mix with live snapshot results.
    """
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)
    start_ms = time.time()
    # called as a function (the .csv / .parquet shortcuts, tests) the default
    # is FastAPI's Query object, not None -- only a real string is a pin
    dataset_version = dataset_version if isinstance(dataset_version, str) and dataset_version else None

    # 133-G: Request ID — accept from consumer or generate
    _request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
    response.headers["X-Request-ID"] = _request_id

    # Check if Published Views API is enabled
    if _pv_cfg and not _pv_cfg.enabled:
        raise HTTPException(503, "Published Views API is disabled")

    # BF-597: async DB.
    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    # 2026-10-03 -- the view's report and current version came back in the
    # SAME statement; every decision below resolves them through this
    # manager instead of re-reading them (core/reports/preloaded.py).
    _sdb = _served_db_for(pv, _db_manager)

    _check_view_access(pv, api_user)

    # ── Phase 146-A — ?engine= runtime override ──────────────────────────
    # Consumer can pick a different execution backend via ?engine={conn_id},
    # gated by the publisher-configured `allowed_engine_connections` whitelist.
    # The pinned engine becomes the connection for THIS request only (and its
    # ID is mixed into the cache key so different engines get distinct slots).
    # When omitted → legacy behaviour, runs against pv.connection_id.
    #
    # Defensive: same FieldInfo guard as snapshot_id below — direct test calls
    # may pass FastAPI's Query() default (a FieldInfo, not an int).  Treat
    # anything that isn't a real int as "no override".
    engine_connection_id: Optional[int] = None     # Only set when override active
    _engine_concrete = engine if isinstance(engine, int) else None
    if _engine_concrete is not None:
        # BF-415 — coerce whitelist entries to int defensively.  Storage is
        # JSON, normally a list[int], but JSON-text columns or hand-edited
        # admin payloads have been observed with stringified ints (["3","5"])
        # or even a JSON-string-of-list ("[3,5]").  Without coercion the
        # ``int(...) in _allowed`` membership check would silently fail
        # (DoS direction) or, in the wrong shape, accept unintended values.
        _raw_allowed = pv.get("allowed_engine_connections")
        if isinstance(_raw_allowed, str):
            try:
                import json as _j_allowed
                _raw_allowed = _j_allowed.loads(_raw_allowed)
            except Exception:
                _raw_allowed = []
        # BF-415 follow-up — admin payloads have been observed with a single
        # bare int instead of a list ([5] vs 5).  Without this normalisation
        # the ``for _x in _raw_allowed`` below would crash with TypeError
        # ("int is not iterable") and bubble up as 500 instead of the
        # intended 403.  Wrap scalar ints in a one-element list before the
        # coercion loop.
        if isinstance(_raw_allowed, int):
            _raw_allowed = [_raw_allowed]
        elif not isinstance(_raw_allowed, (list, tuple)):
            _raw_allowed = []
        _allowed = []
        for _x in (_raw_allowed or []):
            try:
                _allowed.append(int(_x))
            except (TypeError, ValueError):
                continue  # skip malformed entries
        if not _allowed:
            raise HTTPException(
                403,
                "This view has no engine whitelist configured — ?engine= overrides are disabled. "
                "Publisher must set allowed_engine_connections before consumers can pick an engine.",
            )
        if int(_engine_concrete) not in _allowed:
            raise HTTPException(
                403,
                f"engine={_engine_concrete} is not in this view's allowed_engine_connections "
                f"whitelist (allowed: {sorted(_allowed)})",
            )
        # Override the connection — both the top-level pv field and the
        # snapshotted query_config so downstream resolvers see the picked engine.
        engine_connection_id = int(_engine_concrete)
        pv = _copy_view(pv)  # defensive copy — don't mutate the cached row
        pv["connection_id"] = engine_connection_id
        _qc = dict(pv.get("query_config") or {})
        _qc["connection_id"] = engine_connection_id
        pv["query_config"] = _qc
        logger.info(
            "[pv-engine-override] slug=%s consumer=%s engine=%d (allowed=%s)",
            slug, (api_user or {}).get("name", "?"), engine_connection_id, sorted(_allowed),
        )

    # ── Parse parameters ─────────────────────────────────────────────────
    # P4 (2026-08-17) — single chokepoint for limit resolution:
    #   * a NULL per-view default/max follows the LIVE published_views config
    #     (a publish-time snapshot used to defeat any config-level change);
    #   * 0 means UNLIMITED at every level (consumer ?limit=0, per-view value,
    #     config value) — the old ``limit or pv["default_limit"]`` folded an
    #     explicit 0 into the default, the classic zero-fold idiom;
    #   * an explicit consumer limit is still capped by the effective max.
    effective_limit = effective_page_limit(pv, limit)

    # Parse runtime parameters first so we can exclude them from the
    # bare-form filter parser below.
    param_defs = pv.get("param_definitions") or []
    param_names = [
        p.get("name") for p in param_defs
        if isinstance(p, dict) and p.get("name")
    ]
    params = _parse_params(request, param_defs)

    # Parse filter[col]=op:val (and bare ?col=val — Phase 132.35).
    # Pass the DYNAMIC WHERE-mapping columns so a bare ?col=value binds as a
    # FILTER even though BF-491 also registered the column as a param — a
    # mapping column has no {{name}} placeholder, so ceding it to _parse_params
    # would silently drop it (filter-binding wins for mapping columns only;
    # hand-declared {{name}} params without a mapping row still cede).
    _qc_for_dyn = pv.get("query_config")
    _wc_rows = (_qc_for_dyn.get("_where_clauses_mapping")
                if isinstance(_qc_for_dyn, dict) else None) or []
    _dyn_where_cols = {
        (w.get("column") or "")
        for w in _wc_rows
        if isinstance(w, dict) and (w.get("mode") or "static") == "dynamic"
    }
    filters = _parse_filters(
        request, pv.get("allowed_filters") or [],
        param_names=param_names,
        dynamic_where_cols=_dyn_where_cols,
    )

    # Parse sort — 2026-08 redesign: invalid direction is REJECTED (400), not
    # silently degraded to asc.  Unknown sort COLUMN is rejected later at the
    # read_page chokepoint, which is the first place the dataset schema is
    # known (same 400 on cache HIT and MISS).
    from api.published_views.envelope import PageSpec as _PageSpec
    sort_column, sort_dir = _PageSpec.parse_sort(sort)

    # Parse column projection
    col_list = [c.strip() for c in columns.split(",") if c.strip()] if columns else None

    # ── E-H4 — decide whether to stream this response ────────────────────────
    # Streaming is bounded-memory and byte-identical to the materialized path;
    # it applies only to json/csv (parquet already streams a file; excel must
    # be built whole).  ``published_views.stream_results`` (default True) is the
    # master switch a deployment can flip to restore the fully-materialized
    # path.  When on, the executor / cache-reader defer the list-of-dicts
    # materialization and ``_send_response`` streams the encoding in batches.
    _should_stream = bool(_pv_stream_enabled()) and format in ("csv", "json")

    # ── Phase 98-G: Required parameter enforcement ────────────────────────
    # Check before any S3/cache work — zero cost for bad requests
    # Phase 133-D: Use `not in` instead of truthiness to accept valid 0/False/""
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params:
            raise HTTPException(400, f"Missing required parameter: {_pd['name']}")

    # ── Phase 139 honest-fix: time-travel param parsing ────────────────────
    # Defensive: only treat as concrete when the actual underlying type came
    # through (FastAPI passes int/str; direct test calls may pass FieldInfo).
    _snap_concrete = snapshot_id if isinstance(snapshot_id, int) else None
    _ts_concrete = as_of_timestamp if isinstance(as_of_timestamp, str) and as_of_timestamp else None
    if _snap_concrete is not None and _ts_concrete:
        raise HTTPException(400, "Cannot specify both snapshot_id and as_of_timestamp — pick one")
    _as_of_ms: Optional[int] = None
    if _ts_concrete:
        try:
            from datetime import datetime as _dt
            _dt_parsed = _dt.fromisoformat(_ts_concrete.replace("Z", "+00:00"))
            _as_of_ms = int(_dt_parsed.timestamp() * 1000)
        except Exception as _ts_exc:
            raise HTTPException(400, f"Invalid as_of_timestamp format: {_ts_exc}. Use ISO8601, e.g. 2024-01-15T00:00:00Z")
    snapshot_id = _snap_concrete
    # 2026-11-01 -- per-table overrides (?version.<table>= / ?as_of=), ONE
    # parser with the two legacy names (core/iceberg_versions.py).  They ride
    # the cache key (a pinned run has its own slot), the view's query_config
    # (``_execute_view_saved_query`` stamps them for the run's resolver) and
    # the audit log (who asked for which version).
    _iv_overrides, _iv_key = await _parse_pv_version_overrides(
        request, pv, api_user, snapshot_id, _as_of_ms, _tt_supported_for=pv)

    # ── Cache strategy ─────────────────────────────────────────────────────
    _cache_strategy = pv.get("cache_strategy") or "ttl"
    # min_cache_age: throttle guard to prevent hammering S3 on repeated refresh
    # an EXPLICIT 0 means "no throttle" (2026-10-24: `or 60` turned it into 60)
    _min_cache_age = int(60 if pv.get("min_cache_age_seconds") is None else pv["min_cache_age_seconds"])

    # Optional kill switch: admins can set allow_cache_bypass=false to force cached-only
    if cache in ("refresh", "bypass") and not pv.get("allow_cache_bypass", True):
        raise HTTPException(403, "Cache bypass is disabled for this view — contact the administrator")

    # live strategy: always skip cache, always query S3
    if _cache_strategy == "live":
        cache = "bypass"

    # ── Cache check ──────────────────────────────────────────────────────
    # Phase 146-A — engine_connection_id is mixed into the key so consumers
    # pinning ?engine=X get a distinct cache slot from the default-engine path.
    # BF-415 — when the PV has row-security policies, the executed SQL is
    # rewritten per consumer so the cache MUST be scoped per consumer.
    # _user_cache_scope returns None for non-RLS PVs (preserves the legacy
    # shared-cache behaviour and existing cache entries).
    _user_scope = await _user_cache_scope_async(pv, api_user, db=_sdb)
    # 2026-09-05 — PUBLISH-LIFECYCLE IDENTITY IN THE KEY.  The cache branch
    # below serves a materialised dataset and RETURNS, so the resolver the
    # business-report handler calls (``_resolve_execution_report(...,
    # consumer=True)``) never runs on a HIT: for the whole cache TTL an
    # ARCHIVED report kept answering 200 instead of 410 and a REPUBLISHED one
    # kept serving the previous version.  Mixing the lifecycle into dataset
    # IDENTITY makes both a MISS, and a miss runs the gate.  ``None`` for
    # every non-business-report view — legacy keys unchanged.
    _rv_scope = await _served_report_version_scope(pv, _sdb)
    cache_key = _build_cache_key(pv["id"], filters, sort_column, sort_dir, col_list, effective_limit, offset, params,
                                  snapshot_id=_iv_key or snapshot_id, as_of_timestamp_ms=_as_of_ms,
                                  engine_connection_id=engine_connection_id,
                                  user_scope=_user_scope,
                                  report_version=_rv_scope)
    cache_ttl = pv.get("cache_ttl_seconds", 28800)
    # Paged slot — bounded by ``published_views.dataset_row_cap``.  Bulk uses a
    # DISJOINT slot (F2): read_page's sort branch materializes the whole file,
    # so this reader must never be pointed at an uncapped bulk dataset.
    cached_path = pv_cache_path(_cache_dir, pv["id"], cache_key)

    # Phase 98-B ETag, 2026-08 redesign: the cache_key now identifies the
    # DATASET (page spec removed from it), so the ETag mixes the page spec +
    # format back in — each page/projection/format is a distinct HTTP
    # representation and must not 304-alias another.  The dataset file's
    # mtime is appended wherever a cache entry exists: the old ETag was
    # request-derived only, so a REFRESHED dataset (same key, new content)
    # would still 304 a stale client — a validator that never validated.
    import hashlib as _etag_hl
    _page_fp = _etag_hl.sha256(
        f"{effective_limit}|{offset}|{sort_column or ''}|{sort_dir}|"
        f"{','.join(col_list or [])}|{format}".encode()
    ).hexdigest()[:12]
    _etag_base = f'"{cache_key}-{_page_fp}'
    _etag = _etag_base + '"'          # content-unbound form (no cache entry yet)

    # Phase 98-G: if ?cache=refresh was allowed, enforce min freshness throttle
    if cache == "refresh" and cached_path and cached_path.exists():
        _age_now = time.time() - cached_path.stat().st_mtime
        if _age_now < _min_cache_age:
            _retry_after = int(_min_cache_age - _age_now)
            raise HTTPException(
                429,
                f"Cache is too fresh ({int(_age_now)}s old, min age {_min_cache_age}s) — retry after {_retry_after}s",
                headers={"Retry-After": str(_retry_after)},
            )
        # 2026-08 redesign — refresh past the throttle stays REFRESH.  The old
        # code converted it to bypass, and the cache-write guard skipped
        # bypass — so ``?cache=refresh`` NEVER refreshed the shared cache: the
        # refresher got fresh data while every other consumer kept the stale
        # file for the full TTL.  Refresh now means: skip the cache READ,
        # execute fresh, and WRITE the result back for everyone.

    # ── Cache intent (one place, two booleans) ───────────────────────────
    #   auto    → read + write        refresh → no read, WRITE
    #   bypass  → no read, no write   (live strategy maps to bypass above)
    _read_cache = (cache == "auto")
    _write_cache = cache in ("auto", "refresh")
    # 2026-10-24 -- a bypass page sent with the version of the run it came
    # from is read from THAT run, never a new one (page_io.keep_bypass_run);
    # a run that is gone is a 409 -- the pages of two runs never splice.
    _bypass_pin = _page_io.bypass_pin_seconds(cache_ttl)
    _slot_path, _bypass_pinned = cached_path, False
    if cache == "bypass" and dataset_version and cached_path:
        _run = await _page_io.off_loop(_page_io.find_bypass_run, cached_path,
                                       dataset_version, _bypass_pin)
        if _run is None:
            logger.info("[pv-page] %s bypass pin %s not found beside %s", slug, dataset_version,
                        cached_path.name)
            raise HTTPException(
                409,
                "The run these pages came from is no longer kept (cache=bypass runs "
                f"answer their later pages for {int(_bypass_pin)} s), so the rest of the "
                "pages would not match the pages you already have.  Start again from "
                f"offset 0 without dataset_version.  your_version={dataset_version}")
        cached_path, cache, cache_ttl = _run, "auto", _bypass_pin
        _read_cache, _write_cache, _bypass_pinned = True, False, True

    # F2 backstop — the sort read is the only one whose memory scales with the
    # dataset.  An entry too large to be a paged dataset (i.e. one the previous
    # build's bulk path wrote into this slot) is treated as a MISS.
    # 2026-10-10 -- every file read the HIT decision needs (stat, the
    # sort-safety footer, the coverage probe, the age) in ONE hop OFF the
    # loop: api/published_views/page_io.py, THE rule for dataset-file work.
    _entry = await _page_io.off_loop(
        _page_io.probe_cached_entry, cached_path, offset=offset,
        limit=effective_limit, sort_column=sort_column, slug=slug,
        cache_ttl=cache_ttl)
    _sortable = _entry.sortable

    # 2026-09-15 — does the entry COVER this page?  A page-bounded prefix
    # (see _paged_entry_covers) answers the pages it holds and no other; a
    # wider page is a MISS that regrows the entry.  ``_entry_rows`` is what
    # the regrow starts from.  Full materialisations always cover.
    _covers, _entry_rows = _entry.covers, _entry.entry_rows
    # 2026-10-24 -- a PINNED page past the entry's prefix: regrow the whole
    # dataset once, and continue the pin only if the new file starts with
    # the pinned rows (page_io.extends); otherwise the 409 stands.
    _pinned_regrow_from = (cached_path if (dataset_version and _entry.exists
                                           and _entry.fresh and not _covers) else None)
    # Cache-Control scope: a user-scoped dataset (RLS / principal-varying
    # SQL) must never be stored by a shared cache.
    _private = bool(_user_scope)

    if _read_cache and _entry.exists and _sortable and _covers:
        age = _entry.age
        if _entry.fresh:
            _mtime = _entry.mtime
            # Content-bound ETag: page representation + dataset version (mtime).
            _etag = f"{_etag_base}-{int(_mtime)}\""
            # Phase 98-B: Conditional GET — If-None-Match (ETag)
            _inm = request.headers.get("if-none-match", "")
            if _inm and (_inm == _etag or _inm == "*"):
                return Response(status_code=304, headers={"ETag": _etag})
            # Phase 98-B: Conditional GET — If-Modified-Since
            _ims = request.headers.get("if-modified-since", "")
            if _ims:
                try:
                    from email.utils import parsedate_to_datetime
                    _ims_ts = parsedate_to_datetime(_ims).timestamp()
                    if _mtime <= _ims_ts:
                        return Response(status_code=304, headers={"ETag": _etag})
                except Exception as _be_exc:
                    note_best_effort("Response(status_code=304, headers={'ETag': _etag})", _be_exc,
                                     logger=logger)

            result = await _page_io.off_loop(
                _page_io.read_cached_page, cached_path, col_list, offset,
                effective_limit, sort_column, sort_dir, stream=_should_stream)
            # 2026-09-29 -- a page at or past a capped dataset's ceiling is
            # 416 (envelope.refuse_past_ceiling, THE rule), decided BEFORE
            # the access log so the audit record and the response agree.
            _refuse_past_ceiling(result, slug=slug, offset=offset)
            elapsed_ms = int((time.time() - start_ms) * 1000)
            _log_access(api_user, pv, filters, served_rows(result), elapsed_ms, 200, request, _db_manager,
                        cache_status="HIT", columns_requested=col_list,
                        sort_spec=sort or "", params=params)
            _cache_hdrs = _build_cache_hit_headers(age, cache_ttl, _etag, _mtime, _request_id,
                                                   private=_private)
            return _send_response(
                format=format, result=result, slug=slug, pv=pv, elapsed_ms=elapsed_ms,
                cached=True, cache_age=int(age),
                api_user=api_user, request_id=_request_id, headers=_cache_hdrs,
                pv_cfg=_pv_cfg, cached_path=cached_path, response=response,
                dataset_version=dataset_version,
                query_items=_query_items_of(request),
            )

    # ── Duplicates of this MISS: in process, then across processes ───────
    # 2026-10-04 -- a cold dataset is materialised ONCE across every process
    # and pod (api/published_views/cold_flight.py): concurrent identical
    # MISSes follow one leader and are served the cache file it publishes.
    # In process, a duplicate waits on the local event (no store reads);
    # the one request per process that is not a local duplicate takes part
    # in the cross-process flight.  ONE wait budget covers both:
    # ``dedup_timeout_seconds``.
    _dedup_key = (pv["id"], cache_key)
    dedup_timeout = float(_pv_cfg.dedup_timeout_seconds if _pv_cfg else 60)
    _dup_deadline = time.monotonic() + dedup_timeout

    def _probe_entry():
        """What the slot holds for THIS request -- one hop of file work
        (api/published_views/page_io.py).  Cheap when the file is absent
        (the cold case): one ``stat``."""
        if cache == "bypass":
            return _page_io.CachedEntryProbe(exists=False)
        return _page_io.probe_cached_entry(
            cached_path, offset=offset, limit=effective_limit,
            sort_column=sort_column, slug=slug, cache_ttl=cache_ttl)

    async def _entry_serves_request() -> bool:
        """Does the cache hold a dataset that answers THIS request -- fresh,
        safe to sort, covering its page?  Read OFF the loop."""
        return (await _page_io.off_loop(_probe_entry)).serves

    async def _serve_published_entry():
        """The dataset a leader published, served as a HIT; None when the
        entry does not answer this request."""
        _probe = await _page_io.off_loop(_probe_entry)
        if not _probe.serves:
            return None
        _mtime2 = _probe.mtime
        age = _probe.age
        _hit_etag = f"{_etag_base}-{int(_mtime2)}\""
        result = await _page_io.off_loop(
            _page_io.read_cached_page, cached_path, col_list, offset,
            effective_limit, sort_column, sort_dir, stream=_should_stream)
        _refuse_past_ceiling(result, slug=slug, offset=offset)   # 2026-09-29, see the HIT branch
        elapsed_ms = int((time.time() - start_ms) * 1000)
        _log_access(api_user, pv, filters, served_rows(result), elapsed_ms, 200, request, _db_manager,
                    cache_status="HIT", columns_requested=col_list,
                    sort_spec=sort or "", params=params)
        _dedup_hdrs = _build_cache_hit_headers(age, cache_ttl, _hit_etag, _mtime2, _request_id,
                                               private=_private)
        return _send_response(
            format=format, result=result, slug=slug, pv=pv, elapsed_ms=elapsed_ms,
            cached=True, cache_age=int(age),
            api_user=api_user, request_id=_request_id, headers=_dedup_hdrs,
            pv_cfg=_pv_cfg, cached_path=cached_path, response=response,
            dataset_version=dataset_version,
            query_items=_query_items_of(request),
        )

    def _log_joined_failure(status: int, why: str) -> None:
        _log_access(api_user, pv, filters, 0, int((time.time() - start_ms) * 1000), status,
                    request, _db_manager, cache_status="ERROR", error_details=why,
                    columns_requested=col_list, sort_spec=sort or "", params=params)

    _local = _pv_inflight.get(_dedup_key)
    if _local is not None:
        logger.info("[pv-dedup] view=%s joining in-flight request (key=%.8s)", slug, cache_key)
        try:
            await asyncio.wait_for(_local.wait(),
                                   timeout=max(0.0, _dup_deadline - time.monotonic()))
        except asyncio.TimeoutError:
            # The leader is THIS process's own request, alive and working:
            # a second materialisation beside it is the stampede.
            logger.warning("[pv-dedup] Timed out waiting for in-flight view=%s", slug)
            _log_joined_failure(503, "waited for an in-flight materialisation (same process)")
            raise _materialisation_busy(slug, dedup_timeout) from None
        _served = await _serve_published_entry()
        if _served is not None:
            return _served
        _shared = getattr(_local, "failure", None)
        if _shared is not None:
            _log_joined_failure(int(_shared.get("status_code") or 500),
                                "the in-flight materialisation this request joined failed")
            raise _cold_flight.replay(_shared)

    _pv_event = _InflightEvent()
    _pv_inflight[_dedup_key] = _pv_event
    _flight = None
    _share_locally = True        # a follower's own wait timing out is not shared
    _capacity_refusal = False    # THIS process could not run it: never shared across
    try:
        if cached_path and cache == "auto":
            _flight = await _cold_flight.join(
                _cold_flight.flight_key(cached_path),
                is_ready=_entry_serves_request,
                wait_seconds=max(0.0, _dup_deadline - time.monotonic()),
                slug=slug,
            )
            if _flight.role == "ready":
                _served = await _serve_published_entry()
                if _served is not None:
                    return _served
            elif _flight.role == "replay":
                logger.info("[pv-flight] view=%s the materialisation this request "
                            "followed failed (flight %s) -- giving its answer",
                            slug, (_flight.flight_id or "")[:8])
                _log_joined_failure(int((_flight.outcome or {}).get("status_code") or 500),
                                    "the materialisation this request followed failed")
                raise _cold_flight.replay(_flight.outcome or {})
            elif _flight.role == "busy":
                _share_locally = False
                _log_joined_failure(503, "waited for a materialisation in another process")
                raise _materialisation_busy(slug, _flight.waited_s)

        # ── 2026-10-04 -- the per-worker memory guard ────────────────────
        # Every branch above that serves a cached page has returned; what is
        # left is a MATERIALISATION (up to dataset_row_cap + 1 rows).  A
        # worker already near its share of the pod's memory refuses it (503
        # + Retry-After) instead of starting it and being OOM-killed with
        # every request in flight on it (api/published_views/memory_guard.py).
        # Decided AFTER the flight: a follower reads a cache file, it is
        # never refused for memory; a refused LEADER abandons its flight so
        # a process with room takes it over.
        try:
            _refuse_under_memory_pressure(_LARGE_DATA_MISS)
        except HTTPException:
            _capacity_refusal = True
            raise

        # ── Acquire concurrency slot ─────────────────────────────────────────
        # (the per-caller bound is the slot grant inside _execute_view -- see the
        # note beside _admission_identity; this semaphore is the pod's PV lane)
        if not _concurrency_sem:
            raise HTTPException(503, "Service not ready")

        try:
            # Use wait_for with timeout to avoid hanging
            try:
                await asyncio.wait_for(_concurrency_sem.acquire(), timeout=30.0)
            except asyncio.TimeoutError:
                # THIS process's lane is full -- an answer about its capacity,
                # not about the query: another process may lead the flight.
                _capacity_refusal = True
                raise HTTPException(429, "Too many concurrent requests — try again later",
                                    headers={"X-QS-Refused": "lane_full"})

            try:
                _exec_timeout = float(getattr(_pv_cfg, 'execution_timeout_seconds', 300) if _pv_cfg else 300)
                # ── 2026-09-15 — the page intent (envelope.page_intent) ─────
                # scan_floor: materialise what THIS page needs (offset+limit+1,
                # see envelope.page_scan_bound), regrown from a fresh entry that
                # was too short (x2, so a sequential pager costs O(n) total, not
                # O(n^2)) and kept at least as wide as the entry a ``refresh``
                # replaces.  None = the old full materialisation (kill switch
                # published_views.bounded_page_scan).
                # engine_cache: bypass/refresh/live must reach the ENGINE's
                # result cache too, or X-Cache-Status: BYPASS is a lie.
                from api.published_views.envelope import page_intent as _page_intent
                from api.published_views.helpers import (
                    _pv_bounded_page_scan_enabled as _bounded_scan_on,
                )
                # a pinned regrow and a BYPASS run materialise in full: their
                # later pages must come from THIS file (2026-10-24)
                if (not _bounded_scan_on() or _pinned_regrow_from is not None
                        or cache == "bypass"):
                    _scan_floor = None
                elif _entry_rows and not _covers:
                    _scan_floor = 2 * _entry_rows
                elif _entry_rows and cache == "refresh":
                    _scan_floor = _entry_rows
                else:
                    _scan_floor = 0
                logger.info("[pv-page] %s MISS offset=%s limit=%s cache=%s covers=%s entry_rows=%s "
                            "pinned_regrow=%s scan_floor=%s", slug, offset, effective_limit, cache, _covers,
                            _entry_rows, _pinned_regrow_from is not None, _scan_floor)
                _engine_cache = "bypass" if cache in ("bypass", "refresh") else "auto"
                with _page_intent(scan_floor=_scan_floor, engine_cache=_engine_cache):
                    result = await asyncio.wait_for(
                        _execute_view(pv, filters, col_list, sort_column, sort_dir, effective_limit, offset, params,
                                      snapshot_id=snapshot_id, as_of_timestamp_ms=_as_of_ms,
                                      consumer_user=api_user, stream=_should_stream),
                        timeout=_exec_timeout,
                    )
            except asyncio.TimeoutError:
                elapsed_ms = int((time.time() - start_ms) * 1000)
                _log_access(api_user, pv, filters, 0, elapsed_ms, 504, request, _db_manager,
                            cache_status="TIMEOUT", error_details="Execution timed out")
                raise HTTPException(504, "Query execution timed out — contact administrator") from None
            finally:
                _concurrency_sem.release()
        except HTTPException:
            raise
        except Exception as exc:
            logger.error("View execution failed for '%s': %s", slug, exc, exc_info=True)
            elapsed_ms = int((time.time() - start_ms) * 1000)
            from core.error_sanitizer import sanitize_error as _sanitize
            # 2026-09-17 (FB-15c) -- the status is decided BEFORE the access log
            # so the audit record and the response cannot disagree about what
            # happened.  An open breaker is temporary and self-clearing (503);
            # 2026-10-02 -- a scan refusal carries its remedy (422).
            _status = _failure_status(exc)
            _log_access(api_user, pv, filters, 0, elapsed_ms, _status, request, _db_manager,
                        cache_status="ERROR", error_details=_sanitize(str(exc)),
                        columns_requested=col_list, sort_spec=sort or "", params=params)
            _raise_if_self_clearing(exc)
            raise HTTPException(500, "Query execution failed — contact administrator")
        finally:
            # 2026-10-04 -- the materialisation's transient memory is freed by
            # now; hand what the allocators kept back to the OS (debounced, off
            # the request path).  (The in-flight entry is released by the outer
            # finally, AFTER the dataset is published.)
            _large_work_finished(_LARGE_DATA_MISS)

        if _pinned_regrow_from is not None and result.get("_parquet_path"):
            # BEFORE the publish replaces the pinned file
            if await _page_io.off_loop(_page_io.extends, result["_parquet_path"],
                                       _pinned_regrow_from):
                result["_extends_version"] = dataset_version
            else:
                result["_pin_refusal"] = "prefix_reordered"

        # ── Publish dataset + manifest into the shared cache (one chokepoint) ─
        # _persist_result_to_cache is shared with the warmup loop, so warmup
        # writes EXACTLY the entry a consumer request will look up — the warmup
        # loop can no longer be inert by construction.
        if cached_path and _write_cache:
            if await _persist_result_to_cache_async(result, cached_path, slug=slug,
                                                    shared_slot=_user_scope is None):
                # the page served IS this materialization (2026-10-14)
                result["_dataset_version"] = await _page_io.off_loop(
                    _page_io.dataset_version_of, cached_path)
                try:
                    # Content-bound ETag for the just-published dataset version.
                    _etag = f"{_etag_base}-{int(cached_path.stat().st_mtime)}\""
                except OSError:
                    pass  # keep the content-unbound form
        elif _slot_path and (cache == "bypass" or _bypass_pinned) and (
                int(result.get("total_rows") or result.get("row_count") or 0) > offset + effective_limit):
            # kept only when there IS a later page to answer (security review:
            # an unbounded file per request); privately, never the shared slot
            _bv = await _page_io.off_loop(
                _page_io.keep_bypass_run, result, _slot_path, slug=slug,
                shared_slot=_user_scope is None, max_age=_bypass_pin)
            if _bv:
                result["_dataset_version"] = _bv

        if _flight is not None:
            await _flight.succeeded()
    except HTTPException as _miss_exc:
        if _share_locally:
            _pv_event.failure = _cold_flight.failure_outcome(_miss_exc)
        if _flight is not None and not _capacity_refusal:
            await _flight.failed(_miss_exc)
        raise
    finally:
        # The dataset is PUBLISHED by now (or this request failed): only now
        # wake the in-process duplicates -- woken before the publish, they
        # found no file and each ran its own materialisation.
        if _pv_inflight.get(_dedup_key) is _pv_event:
            _pv_inflight.pop(_dedup_key, None)
        _pv_event.set()
        if _flight is not None:
            await _flight.close()

    # 2026-09-29 -- the dataset is materialised and cached above (the next
    # page reads it); a page at or past its ceiling is still refused, and
    # refused BEFORE the access log records a 200.
    _refuse_past_ceiling(result, slug=slug, offset=offset)
    elapsed_ms = int((time.time() - start_ms) * 1000)
    _cache_status = ("BYPASS" if cache == "bypass"
                     else "REFRESH" if cache == "refresh"
                     else "MISS")
    _log_access(api_user, pv, filters, served_rows(result), elapsed_ms, 200, request, _db_manager,
                cache_status=_cache_status, columns_requested=col_list,
                sort_spec=sort or "", params=params)

    _miss_hdrs = _build_miss_headers(_cache_status, cache_ttl, _etag, _request_id,
                                     private=_private)
    return _send_response(
        format=format, result=result, slug=slug, pv=pv, elapsed_ms=elapsed_ms,
        cached=False, cache_age=0,
        api_user=api_user, request_id=_request_id, headers=_miss_hdrs,
        pv_cfg=_pv_cfg, cached_path=cached_path, response=response,
        dataset_version=dataset_version,
        query_items=_query_items_of(request),
    )


@router.get("/api/v1/views/{slug}/data.csv")
async def ext_get_view_csv(
    request: Request,
    slug: str,
    response: Response,
    limit: Optional[int] = Query(None, ge=0),  # P4: 0 = unlimited (capped by effective max_limit)
    offset: int = Query(0, ge=0),
    sort: Optional[str] = Query(None),
    columns: Optional[str] = Query(None),
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    engine: Optional[int] = Query(None),
    dataset_version: Optional[str] = Query(None),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """CSV download shortcut.

    2026-08 redesign — forwards the FULL request contract (snapshot_id /
    as_of_timestamp / engine included).  The old shortcut silently dropped
    them: a consumer asking for a historical Iceberg snapshot via /data.csv
    received CURRENT data labelled as their request.
    """
    return await ext_get_view_data(
        request=request, slug=slug, response=response, limit=limit, offset=offset,
        sort=sort, columns=columns, format="csv", cache=cache,
        snapshot_id=snapshot_id, as_of_timestamp=as_of_timestamp, engine=engine,
        dataset_version=dataset_version, api_user=api_user,
    )


@router.get("/api/v1/views/{slug}/data.parquet")
async def ext_get_view_parquet(
    request: Request,
    slug: str,
    response: Response,
    limit: Optional[int] = Query(None, ge=0),  # P4: 0 = unlimited (capped by effective max_limit)
    offset: int = Query(0, ge=0),
    sort: Optional[str] = Query(None),
    columns: Optional[str] = Query(None),
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    engine: Optional[int] = Query(None),
    dataset_version: Optional[str] = Query(None),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Parquet download shortcut (full contract forwarded — see data.csv)."""
    return await ext_get_view_data(
        request=request, slug=slug, response=response, limit=limit, offset=offset,
        sort=sort, columns=columns, format="parquet", cache=cache,
        snapshot_id=snapshot_id, as_of_timestamp=as_of_timestamp, engine=engine,
        dataset_version=dataset_version, api_user=api_user,
    )


# ══════════════════════════════════════════════════════════════════════════════
# BULK EXPORT — unbounded rows, memory bounded by CHUNK
# ══════════════════════════════════════════════════════════════════════════════
#
# WHY A SEPARATE ENDPOINT rather than lifting the caps on /data.
#
# /data's ``max_limit`` is a MEMORY bound, not a policy number: that path
# reads a page into ONE in-memory Arrow table (``envelope.read_page``) and
# streams the ENCODING of it.  Raising the cap there converts a clean 400
# into an OOM that kills the pod and every interactive user on it.  So /data
# keeps its contract EXACTLY — existing callers are byte-for-byte unaffected —
# and bulk gets a path whose reader never materializes a table at all
# (``bulk.iter_dataset_batches`` → one RecordBatch at a time).
#
# The dataset itself is already a stable parquet file on disk, which is what
# makes the rest possible: one materialization = one point-in-time snapshot,
# so a multi-minute 10M-row pull cannot tear; the footer gives an
# authoritative row count before any row is encoded; and a cursor can resume
# at an exact row offset because the file cannot move under the consumer.

_bulk_sem: Optional[asyncio.Semaphore] = None
_bulk_active: Dict[str, int] = {}


def _get_bulk_sem() -> Optional[asyncio.Semaphore]:
    """Dedicated bulk lane — created lazily so config changes take effect.

    SEPARATE from ``_concurrency_sem`` (the 50-wide general PV lane) on
    purpose.  Bulk pulls are long-lived and share the pod's WorkerPool
    threads with the interactive data grid, so bulk needs its own SMALL cap
    (default 4) or a burst of exports can hold the threads the ~1000
    interactive users need.  This is the isolation lever.
    """
    global _bulk_sem
    from api.published_views.bulk import bulk_max_concurrent
    from core.process_topology import per_process_share
    # 2026-10-03 -- "per pod" (the key's own definition): an N-process pod
    # gives each process 1/N of the lane, so workers=2 keeps 4 streams/pod.
    want = per_process_share(bulk_max_concurrent())
    if want <= 0:
        return None
    if _bulk_sem is None or getattr(_bulk_sem, "_qs_bulk_size", None) != want:
        _bulk_sem = asyncio.Semaphore(want)
        setattr(_bulk_sem, "_qs_bulk_size", want)
    return _bulk_sem


async def _materialize_bulk_dataset(
    pv: dict, filters, params, *, cached_path, cache_key: str,
    snapshot_id, as_of_ms, api_user, read_cache: bool, cache_ttl: int,
    build_timeout_override: Optional[float] = None,
    shared_slot: Optional[bool] = None,
) -> str:
    """Return the path of the dataset parquet a bulk stream will read.

    Reuses the cached dataset when one is fresh (that file IS the pinned
    point-in-time snapshot).  Otherwise executes ONCE with an unbounded
    materialization cap and publishes it through the same
    ``_persist_result_to_cache`` chokepoint the paged path and the warmup
    loop use — so bulk cannot drift from what /data would serve.

    F2 (2026-08-08) — ``cached_path`` is the BULK slot (see
    ``helpers.pv_cache_path``), never the paged one.  This function runs under
    ``dataset_row_cap_override(0)``: the dataset it publishes is UNBOUNDED, and
    ``envelope.read_page``'s sort branch (``pq.read_table``) would materialize
    the whole of it for an unrelated interactive ``/data?sort=col``.  Writing
    an uncapped dataset into the slot that reader opens is how a 50M-row export
    OOMs the pod for everyone else.
    """
    from api.published_views.bulk import (
        bulk_dataset_row_cap, bulk_build_timeout_seconds,
    )
    from api.published_views.envelope import dataset_row_cap_override

    _bulk_cap = bulk_dataset_row_cap()

    if read_cache and cached_path and cached_path.exists():
        age = time.time() - cached_path.stat().st_mtime
        if age < cache_ttl:
            # The cache key is DATASET identity, deliberately shared with the
            # paged /data path — so the entry sitting here may have been
            # materialized under /data's 1M cap.  Serving it to a bulk caller
            # who asked for everything would silently hand back a truncated
            # export.  A capped entry does not satisfy an uncapped request:
            # re-materialize instead.  (It stays honest either way — the
            # manifest says ``at_least`` — but honest-and-truncated is not
            # what the consumer asked for.)
            # 2026-08-08 -- UNKNOWN = UNSAFE.  This block used to fail OPEN in
            # two ways, and both delivered a truncated dataset as complete:
            #
            #   * ``read_sidecar`` returns None for an ABSENT file, a wrong
            #     schema, or any parse error -- and the old ``_m is not None``
            #     guard then left _reusable True, silently.
            #   * the ``except`` arm logged but still reused the entry.
            #
            # The day-one case is the damaging one: at upgrade the whole cache
            # directory is legacy entries with NO sidecars, every one of them
            # /data-capped at 1,000,001 rows (the cap plus the overflow
            # sentinel).  describe_dataset then reports total_mode="unknown"
            # with that raw footer count, start_offset + expected == total, so
            # NO next-cursor is emitted and a 40M-row view returns 1,000,001
            # rows looking complete.  The consumer's own reconcile passes,
            # because the number it checks against is the truncated one.
            #
            # A cache entry we cannot PROVE is complete is treated as capped.
            # The only cost of being wrong is one re-materialization; the cost
            # of the old behaviour is silently wrong data, which is the one
            # outcome this API cannot afford.
            _reusable = True
            try:
                from api.published_views.envelope import DatasetManifest as _DM
                _m = _DM.read_sidecar(cached_path)
                if _m is None:
                    logger.warning(
                        "[pv-bulk] cached dataset %s has NO readable manifest — "
                        "treating it as CAPPED and re-materializing.  Completeness "
                        "cannot be proven without the manifest, and a legacy or "
                        "/data-written entry is row-capped.",
                        cached_path,
                    )
                    _reusable = False
                elif _m.total_mode.value == "at_least":
                    if _bulk_cap <= 0 or int(_m.total_rows) < _bulk_cap:
                        logger.info(
                            "[pv-bulk] cached dataset for '%s' is capped at %d rows "
                            "(total_mode=at_least) — re-materializing for the bulk request",
                            pv.get("slug", "?"), _m.total_rows,
                        )
                        _reusable = False
            except Exception as _mexc:
                # Same rule on the error path: unreadable means unproven.
                logger.warning(
                    "[pv-bulk] manifest unreadable for cached dataset %s (%s) — "
                    "treating it as CAPPED and re-materializing; completeness "
                    "cannot be verified.",
                    cached_path, _mexc,
                )
                _reusable = False
            if _reusable:
                return str(cached_path)

    # ``build_timeout_override`` (2026-08-22): the background /bulk/prepare
    # job passes its own (much larger) budget — the inline default exists to
    # protect an OPEN HTTP REQUEST, which a background build does not hold.
    # Explicit 0 = no budget.
    _build_timeout = (bulk_build_timeout_seconds()
                      if build_timeout_override is None
                      else max(0.0, float(build_timeout_override)))

    async def _run():
        # Unbounded materialization: this writes to DISK, not RAM.  Running
        # out of disk is a clear, attributable error; running out of RAM
        # takes the pod's interactive users with it.
        with dataset_row_cap_override(bulk_dataset_row_cap()):
            return await _execute_view(
                pv, filters, None, None, "asc",
                limit=1, offset=0, params=params,
                snapshot_id=snapshot_id, as_of_timestamp_ms=as_of_ms,
                consumer_user=api_user, stream=False,
            )

    if _build_timeout > 0:
        result = await asyncio.wait_for(_run(), timeout=_build_timeout)
    else:
        result = await _run()

    src = result.get("_parquet_path")
    if not src or not Path(str(src)).exists():
        raise HTTPException(500, "Bulk execution produced no dataset")

    if cached_path:
        # OFF the event loop — a bulk dataset is exactly the multi-GB copy that
        # freezes the loop and gets the pod killed by its liveness probe.
        if await _persist_result_to_cache_async(result, cached_path,
                                                slug=pv.get("slug", "?"),
                                                shared_slot=shared_slot):
            return str(cached_path)
    return str(src)


def _bulk_parts_dir(cached_path) -> str:
    """The PARTS variant of a bulk cache slot — sits beside the single-file
    slot, same dataset identity (cache key is in the slot name)."""
    return str(cached_path) + ".parts"


def _resolve_parts_dataset(cached_path, cache_ttl: int,
                           *, allow_partial: bool = False) -> Optional[str]:
    """A fresh COMPLETE parts build in the slot's parts dir wins over
    re-materialising.  A PARTIAL one is admissible only under the
    caller's explicit ``allow_partial`` opt-in (streaming an in-flight
    prepare build) — and even then only while FRESH: a stale partial is
    a crashed build over data that may since have changed."""
    import os
    from core.feed.parts_manifest import MANIFEST_NAME, PARTIAL_MANIFEST_NAME
    d = _bulk_parts_dir(cached_path)
    for name, needs_opt_in in ((MANIFEST_NAME, False),
                               (PARTIAL_MANIFEST_NAME, True)):
        m = os.path.join(d, name)
        if not os.path.isfile(m):
            continue
        if needs_opt_in and not allow_partial:
            continue
        age = time.time() - os.path.getmtime(m)
        if cache_ttl <= 0 or age < cache_ttl:
            return d
    return None


def _partition_config(pv: dict) -> Dict[str, Any]:
    """The view's DECLARED partition config, from its frozen query_config.

    Deliberately read out of the existing ``query_config`` JSON rather
    than a new column: a new TABLE self-creates on this platform, a new
    COLUMN does not (alembic is never invoked at runtime), so a knob that
    needed one would be absent on every deployed pod.

    THE PRODUCER IS ``api.models.query_models.PartitionConfigModel``.
    That is not a detail: until 2026-09-05 this function was the only
    mention of ``partition_config`` in the product, because
    ``QueryConfigModel`` did not declare the field and pydantic drops
    what is not declared -- so a save returned 200, stored nothing, and
    the whole partitioned-scan lane was unreachable on every view that
    could exist.  Reading a knob out of a JSON blob is only safe while
    something on the WRITE side declares it; the two halves are checked
    together by ``TestPartitionConfigRoundTrip``.

    Shape (all optional; ``column`` is what turns the feature on)::

        "partition_config": {
            "enabled": true,
            "column": "region",          # or "fact.region"
            "max_buckets": 64,
            "max_concurrent": 2,
            "target_rows_per_bucket": 2000000,
            "bucket_size": null,         # pins cardinality bucketing
            "bucket_strategy": "auto",   # "auto" packs to fit; "fixed" refuses
            "discovery_sql": null,       # the CHEAP probe escape hatch
            "discovery_with_counts": true,
            "discovery_wrap": false,
            "preflight_count": null,     # null => on iff discovery_sql is set
            "max_discovery_values": 200000
        }
    """
    cfg = (pv.get("query_config") or {})
    part = cfg.get("partition_config") if isinstance(cfg, dict) else None
    return dict(part) if isinstance(part, dict) else {}


def _plan_progressive_scan(pv: dict, connector, final_sql: str, dialect: str,
                           *, job: Optional[dict] = None):
    """Plan a partitioned scan for this view, or return None.

    Returns None when the view declared no partition column at all -- the
    build then runs exactly as it did before this feature existed.  When
    a column IS declared but the query cannot be split, a SINGLE plan
    carrying the named refusal comes back and the refusal is published on
    the job: "we ran it whole, and here is why" is an answer; silence is
    not.
    """
    part = _partition_config(pv)
    column = str(part.get("column") or "").strip()
    if not column or part.get("enabled") is False:
        return None
    try:
        from core.scan_partitions import plan_partitioned_scan
        plan = plan_partitioned_scan(
            connector, final_sql, partition_column=column, dialect=dialect,
            max_buckets=int(part.get("max_buckets") or 64),
            max_concurrent=int(part.get("max_concurrent") or 2),
            target_rows_per_bucket=part.get("target_rows_per_bucket"),
            bucket_size=part.get("bucket_size"),
            bucket_strategy=str(part.get("bucket_strategy") or "auto"),
            discovery_sql=(str(part.get("discovery_sql") or "").strip()
                           or None),
            discovery_with_counts=bool(
                part.get("discovery_with_counts", True)),
            discovery_wrap=bool(part.get("discovery_wrap", False)),
            max_discovery_values=int(part.get("max_discovery_values")
                                     or 200_000),
            preflight_count=part.get("preflight_count"),
            on_refusal="declare")
    except Exception as exc:
        # Planning is an OPTIMISATION.  If it breaks, the whole-query build
        # must still run -- but the reason has to be visible, not absorbed.
        logger.warning("[pv-bulk-ladder] partition planning failed for '%s' "
                       "(%s: %s) -- building the whole query",
                       pv.get("slug"), type(exc).__name__, exc)
        if job is not None:
            job["scan_plan"] = {"mode": "single",
                                "planner_error": f"{type(exc).__name__}: {exc}"}
        return None
    if job is not None:
        job["scan_plan"] = plan.to_dict()
    if plan.refusal is not None:
        logger.info("[pv-bulk-ladder] view '%s' runs WHOLE: %s",
                    pv.get("slug"), plan.refusal.message())
    return plan


async def _ladder_build_bulk_parts(
    pv: dict, filters, params, *, cached_path, cache_key: str,
    snapshot_id, as_of_ms, api_user, job: Optional[dict] = None,
    read_cache: bool = True, cache_ttl: int = 0,
) -> Optional[str]:
    """Build the bulk dataset THROUGH THE WRITE LADDER into a parts dir.

    2026-08-22, design_starburst_140m §4.4: a published view over a
    Starburst source should materialise via rung 1 (the CLUSTER writes)
    or rung 3 (part-rotating stream) — not through a row-at-a-time pull
    into one giant file.

    How the SQL is obtained — deliberately NOT a second resolver: a
    1-row PROBE runs through ``_execute_view`` (params, filters,
    logical tables, ROW SECURITY — the one true path), which stamps the
    FINAL statement it executed (``_final_sql``); the ladder then runs
    that exact text.  Anything the probe does not stamp (cross-source,
    S3/parquet views, business reports, federation) returns None and
    the caller uses ``_materialize_bulk_dataset`` unchanged.

    Completed parts are announced on ``job`` as they land
    (``parts_completed`` / ``rows_so_far``) — the stream endpoint can
    serve them mid-build under the explicit ``allow_partial`` opt-in.
    """
    from api.published_views.envelope import dataset_row_cap_override
    from core.connectors import SQL_CONNECTOR_TYPES, get_connector

    # Cheap shape PRE-GATE (not a resolver): only a saved_query view on a
    # SQL-connector connection can possibly stamp a final statement, so
    # for every other shape skip the probe entirely — its 1-row
    # execution would be pure waste.  False negatives are safe: the
    # standard build runs, exactly as before.
    if str(pv.get("source_type") or "saved_query") != "saved_query":
        return None
    try:
        _pre_cid = (pv.get("execution_connection_id")
                    or pv.get("connection_id"))
        _pre_conn = await adb(_db_manager.get_connection_raw, _pre_cid)             if _pre_cid else None
        _pre_type = ""
        if isinstance(_pre_conn, dict):
            _pre_type = str(_pre_conn.get("connection_type") or "").lower()
    except Exception:
        return None
    if _pre_type not in SQL_CONNECTOR_TYPES:
        return None

    # 1-row probe through the one true resolution path.
    with dataset_row_cap_override(1):
        probe = await _execute_view(
            pv, filters, None, None, "asc", limit=1, offset=0,
            params=params, snapshot_id=snapshot_id,
            as_of_timestamp_ms=as_of_ms,
            consumer_user=api_user, stream=False,
        )
    try:
        _probe_path = probe.get("_parquet_path")
        if _probe_path:
            Path(str(_probe_path)).unlink(missing_ok=True)
    except OSError:
        pass
    final_sql = probe.get("_final_sql")
    conn_id = probe.get("_final_connection_id")
    conn_type = str(probe.get("_final_conn_type") or "").lower()
    if not final_sql or not conn_id or conn_type not in SQL_CONNECTOR_TYPES:
        logger.info(
            "[pv-bulk-ladder] view '%s' shape does not ride the ladder "
            "(final_sql=%s conn_type=%r) — using the standard build",
            pv.get("slug"), bool(final_sql), conn_type,
        )
        return None

    conn_raw = await adb(_db_manager.get_connection_raw, conn_id)
    if not conn_raw:
        return None
    conn_cfg = conn_raw.get("config") or {}
    parts_dir = _bulk_parts_dir(cached_path)

    # Freshness: a STALE or refresh-bypassed parts build must not be
    # resumed/reused — resume guards (sql hash + stable order) cannot see
    # that the SOURCE data changed since; TTL is the contract for that.
    # This clears both the complete manifest and any crashed partial.
    import os as _os
    import shutil as _sh
    from core.feed.parts_manifest import (
        MANIFEST_NAME as _MN, PARTIAL_MANIFEST_NAME as _PMN,
    )
    for _name in (_MN, _PMN):
        _mp = _os.path.join(parts_dir, _name)
        if _os.path.isfile(_mp):
            _age = time.time() - _os.path.getmtime(_mp)
            if (not read_cache) or (cache_ttl > 0 and _age >= cache_ttl):
                logger.info(
                    "[pv-bulk-ladder] clearing %s parts build for '%s' "
                    "(read_cache=%s age=%.0fs ttl=%ss)",
                    "stale" if read_cache else "bypassed",
                    pv.get("slug"), read_cache, _age, cache_ttl,
                )
                _sh.rmtree(parts_dir, ignore_errors=True)
                break

    def _on_part(info) -> None:
        if job is not None:
            job["parts_completed"] = int(job.get("parts_completed") or 0) + 1
            job["rows_so_far"] = int(job.get("rows_so_far") or 0) + int(info.rows)

    def _build_sync() -> str:
        # 2026-09-16 POOLED — a published-view build opens a source session
        # per build; the partitioned branch below opens one per worker
        # thread on top of that.  Both are borrowed now.
        from core.connection_pool import (
            acquire_pooled, discard_pooled, release_pooled,
        )
        _pool_args = (conn_id, conn_type, conn_cfg, "")
        connector = acquire_pooled(*_pool_args)
        try:
            from core.feed.write_ladder import (
                select_write_rung, RUNG_ENGINE_WRITE,
            )
            rung = select_write_rung(connector, {"id": f"pv:{pv.get('slug')}"})
            if job is not None:
                job["write_ladder"] = rung.to_dict()
            if rung.rung == RUNG_ENGINE_WRITE:
                from core.feed.engine_unload import (
                    run_engine_unload, materialize_parts_locally,
                    build_unload_s3_client, cleanup_unload_prefix,
                )
                res = run_engine_unload(
                    connector, final_sql,
                    feed_config={"id": f"pv:{pv.get('slug')}"},
                    exec_id=f"pv{pv.get('id')}_{cache_key[:12]}",
                )
                caps = (connector.write_capabilities() or {}).get(
                    "engine_write") or {}
                s3c = build_unload_s3_client(
                    connector.config, str(caps.get("s3_location") or ""))
                materialize_parts_locally(res.manifest, s3c, parts_dir,
                                          on_part=_on_part)
                cleanup_unload_prefix(s3c, res.s3_bucket, res.s3_prefix)
                if job is not None:
                    job["rows_so_far"] = int(res.manifest.total_rows)
            else:
                from core.connector_to_parquet import execute_sql_to_parts
                from core.config import feed_generation as _fg
                from core.sql_filter_wrapper import (
                    dialect_for_connection_type,
                )
                _rows_per_part = int(getattr(_fg, "parts_rows_per_part",
                                             5_000_000))
                _dialect = dialect_for_connection_type(conn_type)
                _plan = _plan_progressive_scan(
                    pv, connector, final_sql, _dialect, job=job)
                if _plan is not None and _plan.mode.value == "partition_values":
                    # PROGRESSIVE: one small ``WHERE col IN (...)`` query per
                    # bucket, each part adopted into this same dataset the
                    # moment it is durable.  The stream endpoint's
                    # allow_partial path can therefore serve page 1 while
                    # the later buckets are still extracting.
                    #
                    # NO ``resume=`` TWIN, DELIBERATELY.  The whole-query
                    # branch below passes ``resume=True`` and picks up a
                    # crashed build where it stopped; ``execute_plan_to_parts``
                    # instead takes ``reuse=True`` (default), which short-
                    # circuits only a COMPLETE manifest built by THIS plan
                    # signature and otherwise wipes and restarts from
                    # part-00000.  That is a stated property of the sibling
                    # path not preserved across the fork, and it is declared
                    # rather than quietly matched: a partitioned build has no
                    # durable per-BUCKET completion record (``PartInfo``
                    # carries an index, not a bucket key), so "resume" would
                    # have to guess which buckets already landed -- and a
                    # wrong guess re-runs a bucket, which DOUBLE-WRITES its
                    # rows under a green status.  Restarting is slower and
                    # correct; the manifest stays authoritative throughout,
                    # so no rows are lost either way.
                    #
                    # 2026-09-05 -- VERIFIED at this call site, not
                    # inherited from the sibling's comment.  Two things
                    # had to hold for the asymmetry to be safe as well as
                    # deliberate, and both do: (a) a leftover PARTIAL build
                    # is wiped and every bucket re-extracts exactly once,
                    # so the finished dataset holds each row once; and (b)
                    # the reuse short-circuit is keyed on the PLAN
                    # SIGNATURE, so a dataset built by a different bucket
                    # set is rebuilt rather than adopted.  The only branch
                    # of ``execute_plan_to_parts`` that does not wipe is
                    # its SINGLE fallback (``not plan.buckets``), which is
                    # unreachable from here -- ``plan_partitioned_scan``
                    # returns a SINGLE plan when discovery finds no values,
                    # never PARTITION_VALUES with an empty bucket list --
                    # and even that path passes ``resume=False``, which
                    # wipes a stale dir before writing.  Restart is the
                    # outcome on every reachable path.  See
                    # tests/test_pv_audit_close_2026_09_05.py.
                    from core.scan_partitions import execute_plan_to_parts
                    execute_plan_to_parts(
                        lambda: acquire_pooled(*_pool_args),
                        _plan, parts_dir,
                        connector_release=lambda c: release_pooled(*_pool_args, c),
                        connector_discard=lambda c: discard_pooled(*_pool_args, c),
                        rows_per_part=_rows_per_part,
                        source_meta={"published_view": pv.get("slug"),
                                     "connection_type": conn_type},
                        on_part_complete=_on_part)
                else:
                    _meta = {"published_view": pv.get("slug"),
                             "connection_type": conn_type}
                    if _plan is not None:
                        # A view that ASKED to be partitioned and was not
                        # carries the reason in its artifact, not only in a
                        # log line that has since rotated.
                        _meta["scan_plan"] = _plan.to_dict()
                    execute_sql_to_parts(
                        connector, final_sql, parts_dir,
                        rows_per_part=_rows_per_part,
                        resume=True,   # dataset identity is pinned by the slot
                        dialect=_dialect,
                        source_meta=_meta,
                        on_part_complete=_on_part,
                    )
            return parts_dir
        finally:
            # Hand back with the LIVE exception state: a connector whose
            # build raised is discarded, never pooled for the next caller.
            try:
                import sys as _sys
                if _sys.exc_info()[0] is not None:
                    discard_pooled(*_pool_args, connector)
                else:
                    release_pooled(*_pool_args, connector)
            except Exception as _be_exc:
                note_best_effort("connector release", _be_exc,
                                 logger=logger)

    return await asyncio.to_thread(_build_sync)


# ── OpenAPI: the reconciliation contract lives in HEADERS ────────────────────
# 2026-08-08 — the bulk routes declared no ``responses=`` metadata, so NONE of
# the X-QS-* headers appeared in /openapi.json.  Every guarantee this endpoint
# makes (authoritative total, dataset identity, resume position) is carried in
# a header, so a generated client could not discover the contract at all — it
# could only stream bytes and hope.  Documented here once and shared by all
# four bulk routes.
_BULK_RESPONSE_HEADERS: Dict[str, Any] = {
    "X-QS-Total-Rows": {
        "description": "Authoritative total row count of the pinned dataset, read "
                       "from the parquet FOOTER before any row is encoded. NOT "
                       "derived from the streamed payload. Reconcile rows received "
                       "against this.",
        "schema": {"type": "integer", "format": "int64"},
    },
    "X-QS-Total-Mode": {
        "description": "Provenance of X-QS-Total-Rows: `exact` (true cardinality), "
                       "`at_least` (materialization hit a cap), `unknown` "
                       "(provenance could not be verified — do NOT treat the count "
                       "as complete).",
        "schema": {"type": "string", "enum": ["exact", "at_least", "unknown"]},
    },
    "X-QS-Row-Count-Source": {
        "description": "How X-QS-Total-Rows was obtained. Always `parquet-footer`.",
        "schema": {"type": "string", "enum": ["parquet-footer"]},
    },
    "X-QS-Expected-Rows": {
        "description": "Rows THIS response should deliver. A short read is a "
                       "failed pull: compare against rows actually written.",
        "schema": {"type": "integer", "format": "int64"},
    },
    "X-QS-Row-Offset": {
        "description": "Row offset this response STARTS at. Resume position after "
                       "an interrupted read is exactly "
                       "`X-QS-Row-Offset + rows you actually wrote`.",
        "schema": {"type": "integer", "format": "int64"},
    },
    "X-QS-Dataset-Version": {
        "description": "Identity of the pinned materialization. Two responses "
                       "reporting the same version read byte-identical data. Pass "
                       "it back as `?dataset_version=` when resuming by offset; a "
                       "mismatch is a 409, never a silent splice of two snapshots.",
        "schema": {"type": "string"},
    },
    "X-QS-Snapshot-Id": {
        "description": "Iceberg snapshot id the dataset was materialized from, "
                       "when the source has one.",
        "schema": {"type": "integer", "format": "int64"},
    },
    "X-QS-As-Of-Timestamp-Ms": {
        "description": "Time-travel timestamp (epoch ms) the dataset was "
                       "materialized at, when one was requested.",
        "schema": {"type": "integer", "format": "int64"},
    },
    "X-QS-Data-Status": {
        "description": "`ok`, `empty` (verified zero rows) or `empty_unverified` "
                       "(a zero-row file that cannot be distinguished from a "
                       "swallowed upstream failure).",
        "schema": {"type": "string"},
    },
    "X-QS-Next-Cursor": {
        "description": "Resume token, present only when more rows remain. VALID "
                       "ONLY IF you received all X-QS-Expected-Rows rows — it is "
                       "computed before the body is sent and names where the "
                       "stream WOULD end. After a short read either replay it with "
                       "`?received=<rows you actually wrote>`, or resume with "
                       "`?offset=<X-QS-Row-Offset + rows written>` plus "
                       "`?dataset_version=<X-QS-Dataset-Version>`.",
        "schema": {"type": "string"},
    },
    "X-QS-Request-ID": {
        "description": "Correlation id for this response, echoed in server logs.",
        "schema": {"type": "string"},
    },
}

_BULK_RESPONSES: Dict[Any, Any] = {
    200: {
        "description": "Incremental stream of the whole dataset. Memory on both "
                       "ends is bounded by batch, not by result size.",
        "headers": _BULK_RESPONSE_HEADERS,
        "content": {
            "application/x-ndjson": {},
            "application/json": {},
            "text/csv": {},
            "application/vnd.apache.arrow.stream": {},
            "application/vnd.apache.parquet": {},
        },
    },
    400: {"description": "Rejected request — ?sort=, unknown ?columns, a malformed "
                         "cursor, or a ?received= larger than the response could hold."},
    403: {"description": "Cache bypass disabled for this view."},
    404: {"description": "View not found or not active."},
    409: {"description": "The dataset was refreshed since the cursor / "
                         "dataset_version was issued. Resuming would splice two "
                         "different point-in-time snapshots, so the request fails "
                         "loudly instead."},
    429: {"description": "Bulk lane or per-key bulk limit is full. Retry-After is set."},
    503: {"description": "Bulk export or the Published Views API is disabled."},
    504: {"description": "Dataset materialization exceeded bulk_build_timeout_seconds."},
}


@router.get("/api/v1/views/{slug}/bulk", responses=_BULK_RESPONSES)
async def ext_bulk_stream(
    request: Request,
    slug: str,
    response: Response,
    format: str = Query("jsonl", pattern="^(jsonl|json|csv|arrow|parquet)$"),
    columns: Optional[str] = Query(None),
    max_rows: Optional[int] = Query(None, ge=0, description="0 or omitted = UNBOUNDED"),
    offset: int = Query(0, ge=0),
    cursor: Optional[str] = Query(None, description="X-QS-Next-Cursor token from a prior partial pull. Pair it with ?received= unless you received every X-QS-Expected-Rows row."),
    received: Optional[int] = Query(None, ge=0, description="Rows you ACTUALLY wrote from the response that issued ?cursor=. Resumes at that exact position instead of the cursor's optimistic end."),
    dataset_version: Optional[str] = Query(None, description="Pin the materialization: the X-QS-Dataset-Version you observed. A mismatch is a 409. Makes ?offset= resume as safe as a cursor."),
    batch_rows: Optional[int] = Query(None, ge=1, le=1_000_000),
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    sort: Optional[str] = Query(None),
    allow_partial: bool = Query(
        False,
        description="Serve completed PARTS of an in-flight background build "
                    "(started via /bulk/prepare). The response is honest "
                    "about it: X-QS-Total-Mode=at_least, X-QS-Building=true, "
                    "and the cursor resumes across later parts of the SAME "
                    "build (a rebuild still 409s)."),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Stream an ENTIRE published view — no row cap, memory bounded by chunk.

    Formats: ``jsonl`` (default, what an ETL wants), ``json`` (paged-envelope
    shape), ``csv``, ``arrow`` (Arrow IPC stream — cheapest), ``parquet``.

    Response headers a downstream consumer can reconcile against:
      * ``X-QS-Total-Rows``       — authoritative, read from the parquet FOOTER
                                    before any row is encoded.  NOT derived
                                    from the streamed payload.
      * ``X-QS-Row-Count-Source`` — ``parquet-footer``
      * ``X-QS-Total-Mode``       — ``exact`` | ``at_least`` | ``unknown``
      * ``X-QS-Expected-Rows``    — rows THIS response should deliver
      * ``X-QS-Row-Offset``       — row offset this response STARTS at
      * ``X-QS-Dataset-Version``  — identity of the pinned materialization;
                                    two pulls reporting the same version read
                                    byte-identical data
      * ``X-QS-Snapshot-Id``      — Iceberg snapshot, when the source has one
      * ``X-QS-Next-Cursor``      — resume token (present when more rows remain)

    RESUMING — read this before trusting the token.  ``X-QS-Next-Cursor`` is
    computed as ``X-QS-Row-Offset + X-QS-Expected-Rows`` and emitted in the
    HEADERS, i.e. before a single row is on the wire.  It therefore names where
    the stream WOULD end, not where you got to.  If your reader died at row
    400 000 of a 1 000 000-row response and you replay that token unchanged,
    you resume at 1 000 000 and 600 000 rows are silently skipped — and the
    version check PASSES, because the dataset itself never moved.  Two safe
    forms, both of which fail with 409 if the dataset was refreshed:

        ?cursor=<token>&received=<rows you actually wrote>
        ?offset=<X-QS-Row-Offset + rows you actually wrote>&dataset_version=<X-QS-Dataset-Version>

    Replaying a bare ``?cursor=`` is correct ONLY when you verified that you
    received all ``X-QS-Expected-Rows`` rows.

    ``?sort=`` is rejected — see the 400 message.
    """
    # Direct function calls (the .jsonl/.arrow/.csv shortcuts) can leave
    # ``allow_partial`` as its declared default — a Query OBJECT, which is
    # truthy.  Normalise: anything but literal True means False.
    allow_partial = allow_partial is True
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)

    from api.published_views import bulk as _bulk

    if not _bulk.bulk_enabled():
        raise HTTPException(503, "Bulk export is disabled (published_views.bulk_enabled=false)")
    if _pv_cfg and not _pv_cfg.enabled:
        raise HTTPException(503, "Published Views API is disabled")

    _request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
    start_ms = time.time()

    # A global sort would have to read the whole dataset into RAM to evaluate —
    # exactly the OOM this endpoint exists to avoid.  Refuse loudly.
    if isinstance(sort, str) and sort.strip():
        raise HTTPException(
            400,
            "?sort= is not supported on bulk streams — a global sort cannot be evaluated "
            "incrementally and would require loading the entire dataset into memory. "
            "Push ORDER BY into the published view's query instead; the stream then "
            "delivers that order. Use /data for sorted pages.",
        )

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)

    param_defs = pv.get("param_definitions") or []
    param_names = [p.get("name") for p in param_defs if isinstance(p, dict) and p.get("name")]
    params = _parse_params(request, param_defs)
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params:
            raise HTTPException(400, f"Missing required parameter: {_pd['name']}")

    _qc_for_dyn = pv.get("query_config")
    _wc_rows = (_qc_for_dyn.get("_where_clauses_mapping")
                if isinstance(_qc_for_dyn, dict) else None) or []
    _dyn_where_cols = {
        (w.get("column") or "")
        for w in _wc_rows
        if isinstance(w, dict) and (w.get("mode") or "static") == "dynamic"
    }
    filters = _parse_filters(request, pv.get("allowed_filters") or [],
                             param_names=param_names, dynamic_where_cols=_dyn_where_cols)

    col_list = [c.strip() for c in columns.split(",") if c.strip()] if columns else None

    # Time travel — same contract as /data.
    _snap = snapshot_id if isinstance(snapshot_id, int) else None
    _ts = as_of_timestamp if isinstance(as_of_timestamp, str) and as_of_timestamp else None
    if _snap is not None and _ts:
        raise HTTPException(400, "Cannot specify both snapshot_id and as_of_timestamp — pick one")
    _as_of_ms = None
    if _ts:
        try:
            from datetime import datetime as _dt
            _as_of_ms = int(_dt.fromisoformat(_ts.replace("Z", "+00:00")).timestamp() * 1000)
        except Exception as _exc:
            raise HTTPException(400, f"Invalid as_of_timestamp format: {_exc}. Use ISO8601, e.g. 2024-01-15T00:00:00Z")

    if cache in ("refresh", "bypass") and not pv.get("allow_cache_bypass", True):
        raise HTTPException(403, "Cache bypass is disabled for this view — contact the administrator")
    if (pv.get("cache_strategy") or "ttl") == "live":
        cache = "bypass"

    _user_scope = await _user_cache_scope_async(pv, api_user, db=_served_db_for(pv, _db_manager))
    # Same publish-lifecycle ingredient as /data — the bulk slot serves a
    # materialised dataset too, so it bypassed the same gate for the same TTL.
    _rv_scope = await _served_report_version_scope(pv, _served_db_for(pv, _db_manager))
    _bulk_iv, _bulk_iv_key = await _parse_pv_version_overrides(
        request, pv, api_user, _snap, _as_of_ms, _tt_supported_for=pv)       # 2026-11-01
    cache_key = _build_cache_key(pv["id"], filters, None, "asc", None, 0, 0, params,
                                 snapshot_id=_bulk_iv_key or _snap, as_of_timestamp_ms=_as_of_ms,
                                 user_scope=_user_scope,
                                 report_version=_rv_scope)
    # F2 — the BULK slot.  Same dataset identity as /data (same cache_key),
    # deliberately DIFFERENT file: what lands here is materialized with the row
    # cap lifted, and ``envelope.read_page``'s sort branch would try to load all
    # of it into one Arrow table for an unrelated interactive request.
    cached_path = pv_cache_path(_cache_dir, pv["id"], cache_key, scope="bulk")
    cache_ttl = int(pv.get("cache_ttl_seconds", 28800) or 0)

    # 2026-10-04 -- a bulk stream is LARGE work whether or not its dataset is
    # cached (a long-lived encoder, and a materialisation on a miss): a
    # worker near its share of the pod's memory refuses it before taking a
    # lane slot (api/published_views/memory_guard.py).
    _refuse_under_memory_pressure(_LARGE_BULK_EXPORT)

    # ── Bulk lane ────────────────────────────────────────────────────────
    _sem = _get_bulk_sem()
    _key_identity = _admission_identity(api_user, pv)
    if _sem is not None:
        try:
            await asyncio.wait_for(_sem.acquire(), timeout=30.0)
        except asyncio.TimeoutError:
            raise HTTPException(
                429,
                "Too many concurrent bulk exports on this node — retry shortly. "
                "Bulk runs in a deliberately small lane so it cannot starve interactive users.",
                headers={"Retry-After": "30", "X-QS-Refused": "bulk_lane"},
            )
    # Per-key fairness, checked AFTER the lane slot so there is no race
    # between the check and the stream starting.  Without it one consumer can
    # hold the entire bulk lane and every other external team sees 429s.
    # 2026-10-03 -- a share of a POD lane, so this process's share of it
    # (core.process_topology; one process = the whole configured value).
    from core.process_topology import per_process_share as _pp_share
    _max_per_key = _pp_share(_bulk.bulk_max_per_key())
    if _max_per_key > 0 and _bulk_active.get(_key_identity, 0) >= _max_per_key:
        if _sem is not None:
            _sem.release()
        raise HTTPException(
            429,
            f"Too many concurrent bulk exports for this API key "
            f"({_bulk_active.get(_key_identity, 0)}/{_max_per_key}) — "
            "run them sequentially or use ?cursor= to resume one stream.",
            headers={"Retry-After": "30", "X-QS-Refused": "bulk_per_key"},
        )
    _bulk_active[_key_identity] = _bulk_active.get(_key_identity, 0) + 1

    _released = False

    def _release_lane():
        nonlocal _released
        if _released:
            return
        _released = True
        if _sem is not None:
            _sem.release()
        _n = max(0, _bulk_active.get(_key_identity, 1) - 1)
        if _n <= 0:
            _bulk_active.pop(_key_identity, None)
        else:
            _bulk_active[_key_identity] = _n

    # EVERY exit between acquiring the lane and handing the generator to
    # Starlette must release it — including the cursor 400/409 paths.  A leak
    # here does not fail loudly, it silently shrinks the bulk lane until
    # exports stop working, so the release is structural (one try/except
    # around the whole block) rather than per-branch.
    try:
        try:
            # 2026-08-22 — a PARTS build (write ladder, /bulk/prepare)
            # in the slot's parts dir wins over re-materialising; an
            # in-flight build's completed parts are served only under
            # the explicit ?allow_partial=true opt-in.
            _parts_ds = (None if cache == "refresh" else
                         _resolve_parts_dataset(cached_path, cache_ttl,
                                                allow_partial=allow_partial))
            if _parts_ds is not None:
                dataset_path = _parts_ds
            else:
                dataset_path = await _materialize_bulk_dataset(
                    pv, filters, params, cached_path=cached_path, cache_key=cache_key,
                    snapshot_id=_snap, as_of_ms=_as_of_ms, api_user=api_user,
                    read_cache=(cache == "auto"), cache_ttl=cache_ttl,
                    shared_slot=_user_scope is None,
                )
        except asyncio.TimeoutError:
            _log_access(api_user, pv, filters, 0, int((time.time() - start_ms) * 1000), 504,
                        request, _db_manager, cache_status="TIMEOUT",
                        error_details="Bulk materialization timed out")
            raise HTTPException(
                504,
                "Bulk dataset materialization timed out on the request path. "
                "POST /api/v1/views/{slug}/bulk/prepare to build it in the "
                "BACKGROUND and poll the returned status_url — a large view "
                "cannot finish inside an open HTTP request. (Or raise "
                "published_views.bulk_build_timeout_seconds / narrow the "
                "view's filters.)",
            ) from None
        except HTTPException:
            raise
        except Exception as exc:
            # F8 — never let the exception TEXT reach an external consumer: an
            # OSError renders the full internal dataset path.  Generic body to
            # the client, sanitized detail to the log (same split the paged
            # /data sibling already uses).
            from core.error_sanitizer import sanitize_error as _sanitize
            logger.error("[pv-bulk] materialization failed for '%s': %s", slug,
                         _sanitize(str(exc)), exc_info=True)
            raise HTTPException(500, "Bulk execution failed — contact administrator")

        # ONE handle for the footer read AND the row stream — a concurrent
        # cache refresh between the two would otherwise let us advertise
        # version A's count while streaming version B's rows.
        _pf = _bulk.open_dataset(dataset_path, allow_partial=allow_partial)
        ref = _bulk.describe_dataset(dataset_path, cache_key=cache_key, pf=_pf)
        read_cols = _bulk.validate_bulk_columns(ref, col_list)

        # ── Resume position ──────────────────────────────────────────────
        # F5 — ``?received=`` is what makes a resume correct after a SHORT
        # read: the cursor's own offset is optimistic (computed before the
        # body was sent), so only the client knows where it really stopped.
        # ``?dataset_version=`` gives a plain ``?offset=`` resume the identical
        # 409-on-refresh protection, so offset-based resume is a first-class
        # mechanism and not a downgrade.
        # Defensive: only treat as concrete when the actual underlying type came
        # through (FastAPI passes int/str; direct calls may pass FieldInfo) —
        # same guard the time-travel params above use.
        _received = received if isinstance(received, int) and not isinstance(received, bool) else None
        if _received is not None:
            _received = max(0, _received)
        _ds_version = dataset_version if isinstance(dataset_version, str) and dataset_version else None
        # Explicit version pin — a no-op when not supplied, 409 when the ground
        # moved.  Checked for cursor and offset resumes alike.
        _bulk.verify_dataset_version(_ds_version, ref)
        start_offset = max(0, int(offset))
        if cursor:
            cur = _bulk.BulkCursor.decode(cursor)
            cur.verify(ref)                   # 409 when the dataset moved
            start_offset = cur.resume_offset(_received)
        elif _received is not None:
            raise HTTPException(
                400,
                "?received= only means something alongside ?cursor= — it corrects a "
                "cursor's optimistic position. To resume by offset use "
                "?offset=<X-QS-Row-Offset + rows you wrote>&dataset_version=<X-QS-Dataset-Version>.",
            )

        _cap = _bulk.bulk_max_rows() if max_rows is None else max(0, int(max_rows))
        _remaining_in_dataset = max(0, ref.total_rows - start_offset)
        _expected = _remaining_in_dataset if _cap <= 0 else min(_cap, _remaining_in_dataset)

        _next_cursor = None
        if start_offset + _expected < ref.total_rows:
            # ``base``/``expected`` travel WITH the token so a client that fell
            # short can correct it via ?received= instead of skipping rows.
            _next_cursor = _bulk.BulkCursor(
                version=ref.version, offset=start_offset + _expected,
                base=start_offset, expected=_expected,
            ).encode()

        _batch = int(batch_rows) if batch_rows else _bulk.bulk_batch_rows()

        hdrs = _bulk.bulk_headers(
            ref, request_id=_request_id, offset=start_offset, expected_rows=_expected,
            next_cursor=_next_cursor, fmt=format, slug=slug,
        )
        # 2026-10-24 -- the entitlement disclosure a bulk consumer sees: the
        # dataset's stored summary (its manifest) + THIS caller's principal
        # (core/row_security/disclosure.py); a dataset with none is ``unknown``
        from core.row_security import disclosure as _disclosure
        hdrs.update(_disclosure.headers_for(
            _disclosure.for_response(ref.entitlement, consumer=api_user, pv=pv)))

        # ── Build the incremental pipeline (nothing is read yet) ─────────
        batches = _bulk.iter_dataset_batches(
            dataset_path, columns=read_cols, offset=start_offset,
            max_rows=_expected, batch_rows=_batch, pf=_pf,
        )

        _envelope = None
        if format == "json":
            _envelope = _build_json_envelope(
                slug,
                {
                    "data": [], "total_rows": ref.total_rows, "returned_rows": _expected,
                    "offset": start_offset, "limit": _expected,
                    "columns": [{"name": c, "type": "string"}
                                for c in (read_cols or ref.columns)],
                    "total_mode": ref.total_mode, "data_status": ref.data_status,
                },
                pv, int((time.time() - start_ms) * 1000),
                cached=False, cache_age=0,
                auth_method=api_user.get("auth_method", "api_key"),
                request_id=_request_id, pv_cfg=_pv_cfg,
            )
            try:
                _envelope.setdefault("meta", {}).update({
                    "dataset_version": ref.version,
                    "row_count_source": "parquet-footer",
                    "next_cursor": _next_cursor,
                    "snapshot_id": ref.snapshot_id,
                })
            except Exception as _menv:
                # The headers already carry all of this, so the response is
                # still reconcilable — but a consumer reading only the JSON
                # body would silently lose the provenance fields.
                logger.warning(
                    "[pv-bulk] could not attach provenance meta to the JSON envelope "
                    "for view=%s req=%s: %s (headers still carry it)",
                    slug, _request_id, _menv,
                )
    except BaseException:
        _release_lane()
        _large_work_finished(_LARGE_BULK_EXPORT)       # a failed build kept memory too
        raise

    _rows_sent = {"n": 0}

    def _counting(_it):
        for b in _it:
            _rows_sent["n"] += b.num_rows
            yield b

    _chunks = _bulk.encode_batches(format, _counting(batches), envelope=_envelope,
                                   columns=list(read_cols or ref.columns or []))
    _guarded = _bulk.stall_guard(_chunks, timeout_s=_bulk.bulk_stall_timeout_seconds())

    # ── Optional wire compression ────────────────────────────────────────
    # Bulk payloads are highly repetitive text (JSONL/CSV); gzip typically
    # cuts them 5-10x, which for an external team pulling 10M rows is the
    # difference between a viable nightly job and a saturated link.  Applied
    # INCREMENTALLY (one compressor object, flushed per chunk) so it cannot
    # reintroduce a whole-result buffer, and only when the client asked for
    # it — no behaviour change for clients that did not.
    _accept_enc = (request.headers.get("accept-encoding") or "").lower()
    if "gzip" in _accept_enc and format in ("jsonl", "json", "csv"):
        _guarded = _bulk.gzip_stream(_guarded)
        hdrs["Content-Encoding"] = "gzip"
        hdrs["Vary"] = "Accept-Encoding"

    def _body():
        try:
            for chunk in _guarded:
                yield chunk
        except TimeoutError as _t:
            # The body is already on the wire; the only honest signal left is
            # to break the stream so the client's read fails loudly rather
            # than looking like a clean short read.
            logger.error("[pv-bulk] view=%s req=%s %s", slug, _request_id, _t)
            raise
        finally:
            _release_lane()
            # 2026-10-04 -- give back what the stream's allocators kept.
            _large_work_finished(_LARGE_BULK_EXPORT)
            _elapsed = int((time.time() - start_ms) * 1000)
            logger.info(
                "[pv-bulk] view=%s req=%s fmt=%s version=%s offset=%d expected=%d "
                "sent=%d total=%d %dms",
                slug, _request_id, format, ref.version, start_offset, _expected,
                _rows_sent["n"], ref.total_rows, _elapsed,
            )
            try:
                _log_access(api_user, pv, filters, _rows_sent["n"], _elapsed, 200,
                            request, _db_manager, cache_status="BULK",
                            columns_requested=col_list, sort_spec="", params=params)
            except Exception as _lexc:
                # Never let audit-log trouble break a stream that already
                # delivered — but a missing access-log row is an audit gap,
                # so it must leave a trace somewhere.
                logger.warning(
                    "[pv-bulk] access log write failed for view=%s req=%s rows=%d: %s",
                    slug, _request_id, _rows_sent["n"], _lexc,
                )

    from starlette.responses import StreamingResponse as _SR
    return _SR(_body(), media_type=_bulk.media_type_for(format), headers=hdrs)


@router.get("/api/v1/views/{slug}/bulk.jsonl", responses=_BULK_RESPONSES)
async def ext_bulk_jsonl(request: Request, slug: str, response: Response,
                         columns: Optional[str] = Query(None),
                         max_rows: Optional[int] = Query(None, ge=0),
                         offset: int = Query(0, ge=0),
                         cursor: Optional[str] = Query(None),
                         received: Optional[int] = Query(None, ge=0),
                         dataset_version: Optional[str] = Query(None),
                         batch_rows: Optional[int] = Query(None, ge=1, le=1_000_000),
                         cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
                         snapshot_id: Optional[int] = Query(None),
                         as_of_timestamp: Optional[str] = Query(None),
                         api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """JSONL bulk shortcut — full contract forwarded."""
    return await ext_bulk_stream(
        request=request, slug=slug, response=response, format="jsonl", columns=columns,
        max_rows=max_rows, offset=offset, cursor=cursor, received=received,
        dataset_version=dataset_version, batch_rows=batch_rows,
        cache=cache, snapshot_id=snapshot_id, as_of_timestamp=as_of_timestamp,
        sort=None, allow_partial=False, api_user=api_user,
    )


@router.get("/api/v1/views/{slug}/bulk.arrow", responses=_BULK_RESPONSES)
async def ext_bulk_arrow(request: Request, slug: str, response: Response,
                         columns: Optional[str] = Query(None),
                         max_rows: Optional[int] = Query(None, ge=0),
                         offset: int = Query(0, ge=0),
                         cursor: Optional[str] = Query(None),
                         received: Optional[int] = Query(None, ge=0),
                         dataset_version: Optional[str] = Query(None),
                         batch_rows: Optional[int] = Query(None, ge=1, le=1_000_000),
                         cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
                         snapshot_id: Optional[int] = Query(None),
                         as_of_timestamp: Optional[str] = Query(None),
                         api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """Arrow IPC-stream bulk shortcut — the cheapest format on both ends."""
    return await ext_bulk_stream(
        request=request, slug=slug, response=response, format="arrow", columns=columns,
        max_rows=max_rows, offset=offset, cursor=cursor, received=received,
        dataset_version=dataset_version, batch_rows=batch_rows,
        cache=cache, snapshot_id=snapshot_id, as_of_timestamp=as_of_timestamp,
        sort=None, allow_partial=False, api_user=api_user,
    )


@router.get("/api/v1/views/{slug}/bulk.csv", responses=_BULK_RESPONSES)
async def ext_bulk_csv(request: Request, slug: str, response: Response,
                       columns: Optional[str] = Query(None),
                       max_rows: Optional[int] = Query(None, ge=0),
                       offset: int = Query(0, ge=0),
                       cursor: Optional[str] = Query(None),
                       received: Optional[int] = Query(None, ge=0),
                       dataset_version: Optional[str] = Query(None),
                       batch_rows: Optional[int] = Query(None, ge=1, le=1_000_000),
                       cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
                       snapshot_id: Optional[int] = Query(None),
                       as_of_timestamp: Optional[str] = Query(None),
                       api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user))):
    """CSV bulk shortcut — full contract forwarded."""
    return await ext_bulk_stream(
        request=request, slug=slug, response=response, format="csv", columns=columns,
        max_rows=max_rows, offset=offset, cursor=cursor, received=received,
        dataset_version=dataset_version, batch_rows=batch_rows,
        cache=cache, snapshot_id=snapshot_id, as_of_timestamp=as_of_timestamp,
        sort=None, allow_partial=False, api_user=api_user,
    )


@router.get("/api/v1/views/{slug}/bulk/manifest")
async def ext_bulk_manifest(
    request: Request,
    slug: str,
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Pre-flight: the authoritative row count + dataset version, no data.

    Lets a consumer size the job, record what it is about to pull, and later
    prove the pull was complete — WITHOUT streaming a byte.  Materializes the
    dataset (or reuses the cached one), then answers from the parquet footer.
    """
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)

    from api.published_views import bulk as _bulk
    if not _bulk.bulk_enabled():
        raise HTTPException(503, "Bulk export is disabled (published_views.bulk_enabled=false)")

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)

    param_defs = pv.get("param_definitions") or []
    param_names = [p.get("name") for p in param_defs if isinstance(p, dict) and p.get("name")]
    params = _parse_params(request, param_defs)
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params:
            raise HTTPException(400, f"Missing required parameter: {_pd['name']}")
    filters = _parse_filters(request, pv.get("allowed_filters") or [], param_names=param_names)

    _snap = snapshot_id if isinstance(snapshot_id, int) else None
    _ts = as_of_timestamp if isinstance(as_of_timestamp, str) and as_of_timestamp else None
    if _snap is not None and _ts:
        raise HTTPException(400, "Cannot specify both snapshot_id and as_of_timestamp — pick one")
    _as_of_ms = None
    if _ts:
        try:
            from datetime import datetime as _dt
            _as_of_ms = int(_dt.fromisoformat(_ts.replace("Z", "+00:00")).timestamp() * 1000)
        except Exception as _exc:
            raise HTTPException(400, f"Invalid as_of_timestamp format: {_exc}")

    _user_scope = await _user_cache_scope_async(pv, api_user, db=_served_db_for(pv, _db_manager))
    # Same publish-lifecycle ingredient as /data — the bulk slot serves a
    # materialised dataset too, so it bypassed the same gate for the same TTL.
    _rv_scope = await _served_report_version_scope(pv, _served_db_for(pv, _db_manager))
    cache_key = _build_cache_key(pv["id"], filters, None, "asc", None, 0, 0, params,
                                 snapshot_id=_snap, as_of_timestamp_ms=_as_of_ms,
                                 user_scope=_user_scope,
                                 report_version=_rv_scope)
    # Same BULK slot the stream endpoint uses, so the version this pre-flight
    # reports is the version the subsequent stream will pin (F2).
    cached_path = pv_cache_path(_cache_dir, pv["id"], cache_key, scope="bulk")

    # 2026-10-04 -- a pre-flight that misses materialises the UNBOUNDED
    # dataset: large work, refused near the worker's memory share.
    _refuse_under_memory_pressure(_LARGE_BULK_MANIFEST)

    _sem = _get_bulk_sem()
    if _sem is not None:
        try:
            await asyncio.wait_for(_sem.acquire(), timeout=30.0)
        except asyncio.TimeoutError:
            raise HTTPException(429, "Too many concurrent bulk exports on this node — retry shortly.",
                                headers={"Retry-After": "30", "X-QS-Refused": "bulk_lane"})
    try:
        _mf_ttl = int(pv.get("cache_ttl_seconds", 28800) or 0)
        _parts_ds = (None if cache == "refresh" else
                     _resolve_parts_dataset(cached_path, _mf_ttl))
        if _parts_ds is not None:
            dataset_path = _parts_ds
        else:
            dataset_path = await _materialize_bulk_dataset(
                pv, filters, params, cached_path=cached_path, cache_key=cache_key,
                snapshot_id=_snap, as_of_ms=_as_of_ms, api_user=api_user,
                read_cache=(cache == "auto"),
                cache_ttl=_mf_ttl,
                shared_slot=_user_scope is None,
            )
        ref = _bulk.describe_dataset(dataset_path, cache_key=cache_key)
    finally:
        if _sem is not None:
            _sem.release()
        _large_work_finished(_LARGE_BULK_MANIFEST)

    return {
        "view": slug,
        "total_rows": ref.total_rows,
        "total_mode": ref.total_mode,
        "row_count_source": "parquet-footer",
        "dataset_version": ref.version,
        "snapshot_id": ref.snapshot_id,
        "as_of_timestamp_ms": ref.as_of_timestamp_ms,
        "data_status": ref.data_status,
        "columns": ref.columns,
        "row_groups": ref.num_row_groups,
        "formats": list(_bulk.BULK_FORMATS),
        "batch_rows_default": _bulk.bulk_batch_rows(),
        "max_rows": _bulk.bulk_max_rows(),      # 0 = unbounded
        "stream_url": f"/api/v1/views/{slug}/bulk",
    }


# ══════════════════════════════════════════════════════════════════════════════
# BACKGROUND BULK BUILDS — POST /bulk/prepare + GET /bulk/jobs/{id}
# ══════════════════════════════════════════════════════════════════════════════
#
# 2026-08-22 (design_starburst_140m §1.4/§4.4, bug #7).  The bulk build used
# to run INSIDE the HTTP request under asyncio.wait_for(1800s): a 140M-row
# Starburst materialisation (1-2.5 h) 504'd every time, the client retried,
# and the build restarted from zero — no job handle, no progress, no reuse
# of the half-built work.  /bulk/prepare turns the build into a BACKGROUND
# job: 202 + a pollable status_url; the dataset lands in the SAME bulk cache
# slot, so when the job reports ready the existing streaming endpoints serve
# it with unchanged (resumable version+offset) cursor semantics.  Small
# views keep the one-round-trip inline UX on GET /bulk exactly as before.
#
# The registry is PER-POD and in-memory: a pod restart forgets job ids, but
# never the WORK — the dataset cache is the durable artifact, so the 404
# tells the client to POST prepare again and a finished build is answered
# from cache without re-executing.  (Serving a PARTIAL build from its parts
# is Phase 1 — the parts-manifest writer; a job here is whole or absent.)

_bulk_prepare_jobs: Dict[str, dict] = {}
_bulk_prepare_by_dataset: Dict[Any, str] = {}
_BULK_JOB_TERMINAL_RETENTION_S = 3600.0


def _prune_bulk_jobs(now: Optional[float] = None) -> None:
    """Drop terminal jobs older than the retention window so the registry
    cannot grow without bound.  In-flight jobs are never pruned."""
    now = time.time() if now is None else now
    for jid in list(_bulk_prepare_jobs.keys()):
        j = _bulk_prepare_jobs.get(jid) or {}
        if j.get("status") in ("ready", "failed") and (
                now - float(j.get("finished_at") or now)
                > _BULK_JOB_TERMINAL_RETENTION_S):
            _bulk_prepare_jobs.pop(jid, None)
            if _bulk_prepare_by_dataset.get(j.get("_dkey")) == jid:
                _bulk_prepare_by_dataset.pop(j.get("_dkey"), None)


def _bulk_job_body(job: dict, slug: str) -> dict:
    """Wire shape of one job — private keys stay private.

    2026-08-22 — a ladder (parts) build additionally reports
    ``parts_completed`` / ``rows_so_far`` while running (progress a
    2-hour build was previously silent about), and ``write_ladder``
    says which rung is building and why."""
    body = {
        "job_id": job["job_id"],
        "view": slug,
        "status": job["status"],
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "finished_at": job.get("finished_at"),
        "status_url": f"/api/v1/views/{slug}/bulk/jobs/{job['job_id']}",
        "stream_url": f"/api/v1/views/{slug}/bulk",
        "error": job.get("error"),
    }
    if job.get("status") == "ready":
        body.update({
            "total_rows": job.get("total_rows"),
            "total_mode": job.get("total_mode"),
            "dataset_version": job.get("dataset_version"),
        })
    # Ladder (parts) builds report progress while RUNNING — completed
    # parts are durable and, under ?allow_partial=true, already
    # streamable.  Absent on non-ladder builds (nothing to claim).
    if job.get("parts_completed") is not None:
        body["parts_completed"] = int(job["parts_completed"])
        body["rows_so_far"] = int(job.get("rows_so_far") or 0)
    if job.get("write_ladder"):
        body["write_ladder"] = job["write_ladder"]
    # 2026-09-05 -- and the SCAN PLAN, for the same reason write_ladder is
    # here.  ``_plan_progressive_scan`` stamps ``job["scan_plan"]`` with the
    # planner's verdict -- the bucket plan, or a NAMED refusal carrying a
    # remedy, or ``planner_error`` -- and this function never copied it, so
    # it was computed, logged and discarded: unreachable from any client,
    # on the one lane where progressive serving actually works today.
    # "A value computed and then thrown away will disagree with what the
    # system does" is this codebase's own rule, and it was broken twice
    # more on 2026-09-05 (the feed row-cap disclosure, the S3 truncation
    # verdict) before this one.
    if job.get("scan_plan"):
        # REDACTED ON THE WAY OUT.  The plan itself is safe to publish --
        # its refusal is the planner's own vocabulary (code / subject /
        # detail / remedy), it carries no base SQL and no credentials, and
        # its bucket values are post-RLS.  ``planner_error`` is not: it is
        # stamped as f"{type(exc).__name__}: {exc}" from a CONNECTOR
        # exception, which on this lane has carried the fully-qualified
        # table, the rewritten probe SQL and the coordinator hostname --
        # to any scoped API key, and to every authenticated user on a view
        # with empty allowed_ad_groups.
        #
        # Three lines above, this same function replaces ``error`` with a
        # fixed constant for exactly that reason.  Shipping the planner's
        # exception verbatim beside it was mine, added 2026-09-05 and
        # caught the same day.  The FACT of a planner error is useful to a
        # consumer; its text is not, and it is already in the log with the
        # execution id.
        _sp = dict(job["scan_plan"])
        if _sp.get("planner_error"):
            _sp["planner_error"] = ("the scan planner failed; the query ran "
                                    "whole. See the server log for this "
                                    "job id.")
        body["scan_plan"] = _sp
    return body


def _shared_job_response(job: dict, slug: str, cache: str):
    """The answer a POST /bulk/prepare gives for a job ANOTHER process holds
    (2026-10-03) -- the same rule as the local registry above it: in flight
    = 202 join; ready with its dataset on disk (and no ``refresh``) = 200;
    anything else (failed, dead, refreshed, file gone) = None, build anew."""
    st = job.get("status")
    if st in ("queued", "running"):
        return JSONResponse(status_code=202, content=_bulk_job_body(job, slug))
    if (st == "ready" and cache != "refresh" and job.get("dataset_path")
            and Path(str(job["dataset_path"])).exists()):
        return JSONResponse(status_code=200, content=_bulk_job_body(job, slug))
    return None


@router.post("/api/v1/views/{slug}/bulk/prepare", status_code=202)
async def ext_bulk_prepare(
    request: Request,
    slug: str,
    cache: str = Query("auto", pattern="^(auto|bypass|refresh)$"),
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Start (or join) a BACKGROUND bulk materialisation.

    Returns 202 with ``{job_id, status, status_url, stream_url}``.  Poll
    ``status_url`` until ``status`` is ``ready`` (then stream from
    ``stream_url`` — same headers, same resumable cursor) or ``failed``.
    POSTing again while a build for the same dataset identity is in flight
    JOINS it (one build, many pollers); ``?cache=refresh`` forces a new
    build once the current one finishes.
    """
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)

    from api.published_views import bulk as _bulk
    if not _bulk.bulk_enabled():
        raise HTTPException(503, "Bulk export is disabled (published_views.bulk_enabled=false)")

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)

    param_defs = pv.get("param_definitions") or []
    param_names = [p.get("name") for p in param_defs if isinstance(p, dict) and p.get("name")]
    params = _parse_params(request, param_defs)
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params:
            raise HTTPException(400, f"Missing required parameter: {_pd['name']}")
    filters = _parse_filters(request, pv.get("allowed_filters") or [], param_names=param_names)

    _snap = snapshot_id if isinstance(snapshot_id, int) else None
    _ts = as_of_timestamp if isinstance(as_of_timestamp, str) and as_of_timestamp else None
    if _snap is not None and _ts:
        raise HTTPException(400, "Cannot specify both snapshot_id and as_of_timestamp — pick one")
    _as_of_ms = None
    if _ts:
        try:
            from datetime import datetime as _dt
            _as_of_ms = int(_dt.fromisoformat(_ts.replace("Z", "+00:00")).timestamp() * 1000)
        except Exception as _exc:
            raise HTTPException(400, f"Invalid as_of_timestamp format: {_exc}")

    _user_scope = await _user_cache_scope_async(pv, api_user, db=_served_db_for(pv, _db_manager))
    # Same publish-lifecycle ingredient as /data — the bulk slot serves a
    # materialised dataset too, so it bypassed the same gate for the same TTL.
    _rv_scope = await _served_report_version_scope(pv, _served_db_for(pv, _db_manager))
    cache_key = _build_cache_key(pv["id"], filters, None, "asc", None, 0, 0, params,
                                 snapshot_id=_snap, as_of_timestamp_ms=_as_of_ms,
                                 user_scope=_user_scope,
                                 report_version=_rv_scope)
    cached_path = pv_cache_path(_cache_dir, pv["id"], cache_key, scope="bulk")
    cache_ttl = int(pv.get("cache_ttl_seconds", 28800) or 0)

    _prune_bulk_jobs()

    # One build per dataset identity: joining an in-flight job is the
    # dedup that stops N impatient pollers from launching N 2-hour builds.
    _dkey = (pv["id"], cache_key)
    _existing_id = _bulk_prepare_by_dataset.get(_dkey)
    if _existing_id:
        _existing = _bulk_prepare_jobs.get(_existing_id)
        if _existing and _existing.get("status") in ("queued", "running"):
            return JSONResponse(status_code=202,
                                content=_bulk_job_body(_existing, slug))
        if (_existing and _existing.get("status") == "ready"
                and cache != "refresh"
                and _existing.get("dataset_path")
                and Path(str(_existing["dataset_path"])).exists()):
            return JSONResponse(status_code=200,
                                content=_bulk_job_body(_existing, slug))

    # 2026-10-03 -- ONE build per dataset across EVERY process: the dict
    # above only knows this process's jobs.  A sibling worker / pod may be
    # building this very slot (the shared claim names its job), or may
    # have finished it.  See api/published_views/bulk_jobs.py.
    from api.published_views import bulk_jobs as _jobs
    await adb(_jobs.prune)
    _shared_dkey = _jobs.dataset_key(cached_path)
    _prev_shared = await adb(_jobs.current_for, _shared_dkey)
    if _prev_shared is not None:
        _resp = _shared_job_response(_prev_shared, slug, cache)
        if _resp is not None:
            return _resp

    # 2026-10-04 -- joining / reusing a build (above) is not new work; a NEW
    # build is, and a worker near its memory share refuses to start one.
    _refuse_under_memory_pressure(_LARGE_BULK_BUILD)

    job_id = uuid.uuid4().hex[:16]
    job = {
        "job_id": job_id, "view_id": pv["id"], "slug": slug,
        "status": "queued", "created_at": time.time(),
        "started_at": None, "finished_at": None, "error": None,
        "_dkey": _dkey, "_shared_dkey": _shared_dkey,
    }
    # Recorded BEFORE claiming, so a sibling that loses the claim to this
    # job can read the row it is told to join.
    await adb(_jobs.save, job, dkey=_shared_dkey)
    _holder = await adb(_jobs.claim, _shared_dkey, job_id,
                        previous_job_id=(_prev_shared or {}).get("job_id"))
    if _holder is not None and _holder != job_id:
        await adb(_jobs.forget, job_id)
        _winner = await adb(_jobs.get, _holder)
        if _winner is not None:
            _resp = _shared_job_response(_winner, slug, cache)
            if _resp is not None:
                return _resp
        # The winner is unreadable or already unusable: build here, as one
        # process always did (never a lost request).
        await adb(_jobs.save, job, dkey=_shared_dkey)
    _bulk_prepare_jobs[job_id] = job
    _bulk_prepare_by_dataset[_dkey] = job_id

    async def _heartbeat():
        """Mirror the job (status, progress) into the shared registry while
        it is queued / running, so a poll on any process sees it live."""
        while job.get("status") in ("queued", "running"):
            await adb(_jobs.save, job)
            await asyncio.sleep(_jobs.HEARTBEAT_SECONDS)

    async def _run_build():
        job["status"] = "running"
        job["started_at"] = time.time()
        _hb_task = asyncio.create_task(_heartbeat())
        _sem = _get_bulk_sem()
        _acquired = False
        try:
            if _sem is not None:
                # Background: wait for a lane slot rather than 429 — the
                # point of prepare is that nobody is holding a connection.
                await _sem.acquire()
                _acquired = True
            # ── Write-ladder build first (2026-08-22, §4.4) ──────────
            # A view that resolves to ONE SQL-connector statement builds
            # via the ladder into a PARTS dir: rung 1 (the cluster
            # writes) or rung 3 (part-rotating stream, resumable, parts
            # served as they land).  ``None`` = the view's shape does
            # not ride the ladder — the standard build below runs
            # unchanged.  A ladder build that STARTS and fails, fails
            # the job loudly: silently re-running a 140M pull through
            # the single-file path is hours of surprise, not a fallback.
            dataset_path = await _ladder_build_bulk_parts(
                pv, filters, params, cached_path=cached_path,
                cache_key=cache_key, snapshot_id=_snap, as_of_ms=_as_of_ms,
                api_user=api_user, job=job,
                read_cache=(cache == "auto"), cache_ttl=cache_ttl,
            )
            if dataset_path is None:
                dataset_path = await _materialize_bulk_dataset(
                    pv, filters, params, cached_path=cached_path,
                    cache_key=cache_key, snapshot_id=_snap, as_of_ms=_as_of_ms,
                    api_user=api_user, read_cache=(cache == "auto"),
                    cache_ttl=cache_ttl,
                    build_timeout_override=_bulk.bulk_prepare_timeout_seconds(),
                    shared_slot=_user_scope is None,
                )
            ref = _bulk.describe_dataset(dataset_path, cache_key=cache_key)
            job.update({
                "status": "ready", "dataset_path": str(dataset_path),
                "total_rows": ref.total_rows, "total_mode": ref.total_mode,
                "dataset_version": ref.version, "finished_at": time.time(),
            })
            logger.info("[pv-bulk-prepare] job %s for '%s' ready: %s rows "
                        "(%s)", job_id, slug, ref.total_rows, ref.total_mode)
        except asyncio.TimeoutError:
            job.update({
                "status": "failed", "finished_at": time.time(),
                "error": ("materialization exceeded "
                          "published_views.bulk_prepare_timeout_seconds"),
            })
            logger.error("[pv-bulk-prepare] job %s for '%s' timed out",
                         job_id, slug)
        except Exception as exc:
            # Same F8 rule as the inline path: no internal paths to
            # external consumers; sanitized detail to the log.
            from core.error_sanitizer import sanitize_error as _sanitize
            logger.error("[pv-bulk-prepare] job %s for '%s' failed: %s",
                         job_id, slug, _sanitize(str(exc)), exc_info=True)
            job.update({
                "status": "failed", "finished_at": time.time(),
                "error": "Bulk build failed — contact administrator",
            })
        finally:
            if _acquired and _sem is not None:
                _sem.release()
            _large_work_finished(_LARGE_BULK_BUILD)        # 2026-10-04
            # The terminal state reaches every process (2026-10-03).
            _hb_task.cancel()
            try:
                await _hb_task
            except BaseException:          # noqa: BLE001 -- cancelled is the point
                pass
            if job.get("status") in ("queued", "running"):
                # cancelled mid-build: say so rather than leave it "running"
                job.update({"status": "failed", "finished_at": time.time(),
                            "error": "Bulk build was cancelled"})
            await adb(_jobs.save, job)

    job["_task"] = asyncio.create_task(_run_build())
    return JSONResponse(status_code=202, content=_bulk_job_body(job, slug))


@router.get("/api/v1/views/{slug}/bulk/jobs/{job_id}")
async def ext_bulk_prepare_status(
    slug: str,
    job_id: str,
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Poll one background bulk build.  ``ready`` → stream from
    ``stream_url`` (unchanged resumable cursor contract)."""
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)

    _prune_bulk_jobs()
    job = _bulk_prepare_jobs.get(job_id)
    if not job or job.get("slug") != slug:
        # 2026-10-03 -- a job another process (worker or pod) runs is in
        # the shared registry; a dead one comes back failed with a reason.
        from api.published_views import bulk_jobs as _jobs
        job = await adb(_jobs.get, job_id)
    if not job or job.get("slug") != slug:
        raise HTTPException(
            404,
            "Unknown bulk prepare job (never created, or finished more than "
            "an hour ago) — the BUILD is not lost: POST "
            f"/api/v1/views/{slug}/bulk/prepare again; a finished build is "
            "answered from the dataset cache without re-executing.",
        )
    return _bulk_job_body(job, slug)


# ══════════════════════════════════════════════════════════════════════════════
# SIGNED PART DOWNLOAD — the dataset as its immutable files, zero re-copies
# ══════════════════════════════════════════════════════════════════════════════


@router.get("/api/v1/views/{slug}/bulk/download")
async def ext_bulk_download(
    request: Request,
    slug: str,
    snapshot_id: Optional[int] = Query(None),
    as_of_timestamp: Optional[str] = Query(None),
    api_user: dict = Depends(require_capability("published_api.consume", identity=get_api_key_or_ad_user)),
):
    """Signed download handoff (2026-08-22, design_starburst_140m §4.4).

    Returns per-part parquet URLs, each signed with an HMAC over
    (view, dataset identity, dataset version, part index, expiry).  The
    part routes then stream the EXISTING immutable files — the dataset
    is never converted, concatenated or otherwise re-materialised in the
    pod for a download; what was built once is what is handed over.

    This endpoint NEVER builds: an absent/stale dataset is a 409 naming
    ``POST /bulk/prepare`` — a download URL that silently triggered a
    2-hour build would be the inline-504 defect reborn.
    """
    _ensure_ready()
    await _page_io.rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, _pv_cfg)

    from api.published_views import bulk as _bulk
    if not _bulk.bulk_enabled():
        raise HTTPException(503, "Bulk export is disabled (published_views.bulk_enabled=false)")

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)
    _check_view_access(pv, api_user)

    param_defs = pv.get("param_definitions") or []
    param_names = [p.get("name") for p in param_defs if isinstance(p, dict) and p.get("name")]
    params = _parse_params(request, param_defs)
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params:
            raise HTTPException(400, f"Missing required parameter: {_pd['name']}")
    filters = _parse_filters(request, pv.get("allowed_filters") or [], param_names=param_names)

    _snap = snapshot_id if isinstance(snapshot_id, int) else None
    _ts = as_of_timestamp if isinstance(as_of_timestamp, str) and as_of_timestamp else None
    _as_of_ms = None
    if _ts:
        try:
            from datetime import datetime as _dt
            _as_of_ms = int(_dt.fromisoformat(_ts.replace("Z", "+00:00")).timestamp() * 1000)
        except Exception as _exc:
            raise HTTPException(400, f"Invalid as_of_timestamp format: {_exc}")

    _user_scope = await _user_cache_scope_async(pv, api_user, db=_served_db_for(pv, _db_manager))
    # Same publish-lifecycle ingredient as /data — the bulk slot serves a
    # materialised dataset too, so it bypassed the same gate for the same TTL.
    _rv_scope = await _served_report_version_scope(pv, _served_db_for(pv, _db_manager))
    cache_key = _build_cache_key(pv["id"], filters, None, "asc", None, 0, 0, params,
                                 snapshot_id=_snap, as_of_timestamp_ms=_as_of_ms,
                                 user_scope=_user_scope,
                                 report_version=_rv_scope)
    cached_path = pv_cache_path(_cache_dir, pv["id"], cache_key, scope="bulk")
    _ttl = int(pv.get("cache_ttl_seconds", 28800) or 0)

    dataset_path = _resolve_parts_dataset(cached_path, _ttl)
    if dataset_path is None:
        _single = Path(str(cached_path))
        if _single.exists() and (
                _ttl <= 0 or time.time() - _single.stat().st_mtime < _ttl):
            dataset_path = str(_single)
        else:
            raise HTTPException(
                409,
                "No materialised dataset to download. POST "
                f"/api/v1/views/{slug}/bulk/prepare first, poll the job to "
                "'ready', then call this endpoint again.")

    ref = _bulk.describe_dataset(dataset_path, cache_key=cache_key)
    ttl = _bulk.bulk_download_url_ttl_seconds()

    def _part_url(index: int) -> str:
        tok = _bulk.sign_part_token(pv["id"], cache_key, ref.version,
                                    index, ttl)
        return (f"/api/v1/views/{slug}/bulk/parts/{index}"
                f"?ck={cache_key}&v={ref.version}&token={tok}")

    parts_out = []
    if ref.is_parts:
        for pinfo in ref.parts_manifest.parts:
            if pinfo.location != "local":
                raise HTTPException(
                    501,
                    f"part {pinfo.index} of this dataset is not pod-resident "
                    f"({pinfo.location}) — the presigned remote handoff is "
                    f"not wired yet; stream via GET /bulk instead")
            parts_out.append({
                "index": pinfo.index, "rows": pinfo.rows,
                "bytes": pinfo.bytes, "checksum": pinfo.checksum,
                "url": _part_url(pinfo.index),
            })
    else:
        parts_out.append({
            "index": 0, "rows": ref.total_rows,
            "bytes": Path(str(dataset_path)).stat().st_size,
            "checksum": None,
            "url": _part_url(0),
        })

    return {
        "view": slug,
        "dataset_version": ref.version,
        "total_rows": ref.total_rows,
        "total_mode": ref.total_mode,
        "format": "parquet",
        "parts": parts_out,
        "expires_in_seconds": ttl,
    }


@router.get("/api/v1/views/{slug}/bulk/parts/{part_index}")
async def ext_bulk_part(
    slug: str,
    part_index: int,
    ck: str = Query(..., description="dataset identity (from /bulk/download)"),
    v: str = Query(..., description="dataset version the token was minted for"),
    token: str = Query(..., description="HMAC download token"),
):
    """One immutable part file, streamed from disk.

    The TOKEN is the credential: it was minted inside an authenticated
    ``/bulk/download`` call and is HMAC-bound to (view, dataset identity,
    version, THIS part index, expiry) — so this route deliberately takes
    no API key, which is what lets plain curl/wget/browser clients pull
    parts in parallel.  An expired or altered token is a 403; a token
    for a version that is no longer the dataset's version is a 409
    (refreshed under you — re-request /bulk/download).
    """
    _ensure_ready()
    from api.published_views import bulk as _bulk
    if not _bulk.bulk_enabled():
        raise HTTPException(503, "Bulk export is disabled (published_views.bulk_enabled=false)")

    pv = await adb(_db_manager.get_published_view_by_slug, slug)
    if not pv or not pv.get("is_active"):
        raise await _view_refusal(slug)

    _bulk.verify_part_token(token, view_id=pv["id"], cache_key=ck,
                            dataset_version=v, part_index=part_index)

    cached_path = pv_cache_path(_cache_dir, pv["id"], ck, scope="bulk")
    _pdir = _bulk_parts_dir(cached_path)
    from core.feed.parts_manifest import MANIFEST_NAME as _MN
    import os as _os
    if _os.path.isfile(_os.path.join(_pdir, _MN)):
        dataset_path = _pdir
    elif Path(str(cached_path)).exists():
        dataset_path = str(cached_path)
    else:
        raise HTTPException(
            409, "Dataset no longer materialised — request "
                 "/bulk/download again (after /bulk/prepare if needed)")

    ref = _bulk.describe_dataset(dataset_path, cache_key=ck)
    if ref.version != v:
        raise HTTPException(
            409,
            "Dataset was refreshed since this download link was issued — "
            "re-request GET /bulk/download for fresh links. "
            f"link_version={v} current_version={ref.version}")

    if ref.is_parts:
        _parts = ref.parts_manifest.parts
        if not (0 <= int(part_index) < len(_parts)):
            raise HTTPException(404, f"No part {part_index} in this dataset")
        _file = Path(_pdir) / _parts[int(part_index)].name
    else:
        if int(part_index) != 0:
            raise HTTPException(404, "Single-file dataset has only part 0")
        _file = Path(str(dataset_path))
    if not _file.is_file():
        raise HTTPException(409, "Part file missing — dataset was evicted; "
                                 "re-run /bulk/prepare")

    from fastapi.responses import FileResponse
    return FileResponse(
        str(_file),
        media_type="application/octet-stream",
        filename=f"{slug}.part-{int(part_index):05d}.parquet",
        headers={
            "X-QS-Dataset-Version": ref.version,
            "X-QS-Part-Rows": str(ref.parts_manifest.parts[int(part_index)].rows
                                  if ref.is_parts else ref.total_rows),
            "Cache-Control": "no-store",
        },
    )


# ══════════════════════════════════════════════════════════════════════════════
# EXECUTION ENGINE
# ══════════════════════════════════════════════════════════════════════════════


def _read_parquet_page(
    path: str,
    *,
    columns: Optional[List[str]] = None,
    limit: int = 100,
    offset: int = 0,
    sort_column: Optional[str] = None,
    sort_dir: str = "asc",
):
    """Read ONE PAGE from a result parquet with BOUNDED memory.

    Returns ``(df, total_rows)``.

    2026-07-31 -- replaces the ``pq.read_table(path).to_pandas()`` pattern that
    both Published-API result readers used.  That pattern loaded the ENTIRE
    result into an Arrow table AND a second full pandas copy, then applied
    projection / offset / limit afterwards -- so an API consumer asking for
    100 rows of a 20M-row x 900-column result materialised the whole thing
    (~180 GB uncompressed, twice) to hand back 100 rows.  Guaranteed OOM, and
    a consumer requesting 5 columns still paid for all 900.

    Three pushdowns, in the order that matters:

      1. ``total_rows`` from the parquet FOOTER (``metadata.num_rows``) -- O(1),
         no row data read at all.  Previously ``len(df)`` on the full load.
      2. COLUMN projection into the reader, so only the requested column chunks
         are fetched off disk.  This is the big win at 900 columns.
      3. ROW offset+limit via ``iter_batches``, stopping as soon as the page is
         full.  Memory is O(limit + one batch), independent of result size.

    SORTING is the one case that genuinely needs the whole column set: a global
    sort cannot be evaluated from a prefix.  When ``sort_column`` is requested
    we still fall back to a full read -- but WITH the column projection applied,
    which is where most of the bytes are at 900 columns.

    2026-08 redesign — this is now a LEGACY-COMPAT WRAPPER for internal
    pandas callers (data_grid_api's virtual-dataset page reader).  The real
    pager is ``api.published_views.envelope.read_page`` (Arrow-native, strict
    validation for the external contract); every Published-API path calls it
    directly so the wire never touches pandas (which coerces nullable int64 →
    float64, silently corrupting IDs above 2^53).  Lenient semantics
    (unknown columns dropped, unknown sort ignored) are preserved HERE ONLY
    via strict=False — external consumers get 400s from the strict pager.
    """
    from api.published_views.envelope import read_page as _read_page

    table, total_rows = _read_page(
        path, columns=columns, limit=limit, offset=offset,
        sort_column=sort_column, sort_dir=sort_dir, strict=False,
    )
    return table.to_pandas(), total_rows


def report_row_limit_for_cap(cap: int) -> int:
    """The row_limit a report-backed view hands the report engine for a
    dataset cap: cap + 1 (the overflow sentinel) when bounded, and 0 --
    UNLIMITED in the federation engine -- when not.  Never None: the engine
    reads None as its default PAGE (semantic_layer.default_row_limit,
    10,000), which is how /bulk on a 2.47M-row view served 10,000 rows
    labelled exact (2026-10-03, real Snowflake)."""
    return (int(cap) + 1) if int(cap or 0) > 0 else 0


async def _execute_view_business_report(
    pv: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    params: Optional[Dict[str, Any]] = None,
    consumer_user: Optional[Dict[str, Any]] = None,
    snapshot_id: Optional[int] = None,          # time travel: REFUSED here --
    as_of_timestamp_ms: Optional[int] = None,   # see _refuse_unless_time_travel_
    stream: bool = False,                       # supported (FB-38, 2026-09-19)
) -> dict:
    """Phase 91 — Execute a business report as a published view.

    Phase 131 deep-dive #9: accepts consumer_user to thread the
    triggering user identity into credential resolution + row-security
    policies.  Previously the BR path called _run_report_query with a
    hardcoded synthetic principal — RLS policies on BR-sourced PVs
    were applied against "viewer", not the actual consumer.
    """
    import asyncio as _asyncio
    import uuid as _uuid
    from pathlib import Path as _Path

    await _refuse_unless_time_travel_supported(pv, snapshot_id, as_of_timestamp_ms)  # FB-38

    if not _federation_engine:
        raise HTTPException(503, "Federation engine not available for business report views")

    br_id = pv.get("business_report_id")
    if not br_id:
        raise HTTPException(500, "Published view missing business_report_id")

    # BF-597: async DB.  2026-10-03 -- through the request's manager: when
    # the view was read by its slug the report and its current version came
    # back in the same statement, and the cache key was built from those
    # same rows, so the run and the slot it lands in agree on the version.
    _rdb = _served_db_for(pv, _db_manager)
    report = await adb(_rdb.get_business_report, br_id)
    if not report:
        raise HTTPException(404, f"Business report {br_id} not found")

    # ── 2026-09-05 — PUBLISH-LIFECYCLE PARITY (surface divergence) ───────
    # This handler executed the LIVE ``business_reports`` row — the
    # author's DRAFT.  Every OTHER consumer surface of the same report
    # resolves the CURRENT PUBLISHED VERSION first: business_reports_api
    # (execute / pivot / export / share + embed token pages),
    # core.reports.sources (headless delivery) and
    # core.reports.subscription_preflight.  So ONE report answered TWO
    # ways depending on which door the consumer came through, and an
    # author's half-saved edit reached published-API consumers instantly —
    # precisely the state core/reports/versions.py exists to prevent.  A
    # decision made twice is the bug: this calls the SAME resolver, it does
    # not add a second one.
    #
    # ``consumer=True``: a published-view caller is a consumer BY
    # CONSTRUCTION (API key / AD-Basic / shared-token holder), never the
    # author editing their own draft — the same flag the share/embed token
    # surfaces pass.
    #
    # AUTHORIZATION IS NOT MOVED.  ``apply_version`` overlays ONLY
    # ``DEFINITION_FIELDS`` onto the live row; owner / role_whitelist /
    # is_published / owner_group_id / lifecycle_status are deliberately
    # NOT snapshotted and stay LIVE, so revoking access still kills old
    # versions.  The PV's own gates (active check, allowed_ad_groups, API
    # key scope) already ran against the live PV row before this handler.
    #
    # NO PUBLISHED VERSION → REFUSED (2026-09-15).  This surface is consumed
    # by API-key holders with no session; the resolver used to fall back to
    # the DRAFT here, so an unpublished (withdrawn) report kept serving the
    # author's edits through the view.  Now: unpublished / never-published /
    # no version row ⇒ 410, version store unreadable ⇒ 503 — the shared
    # wrapper transcribes the resolver's verdict, identical to the share and
    # embed token surfaces.  ARCHIVED is REFUSED (410) the same way.  Every
    # run that gets past this line ran a PUBLISHED version, stated below
    # (the JSON envelope in published_views/helpers.py is a whitelist, so a
    # per-response ``served_version`` key would be dropped there — and a
    # cached dataset could not carry one honestly anyway).
    from api.business_reports_api import _resolve_execution_report
    report, _br_served_version = await adb(
        _resolve_execution_report, _rdb, report, None, True)
    logger.info("[pv-br] view=%s br_id=%s definition=published v%s",
                pv.get("slug"), br_id,
                (_br_served_version or {}).get("version_no"))

    from api.business_reports_api import _build_report_filters, _run_report_query

    # Phase 133-D: validate param types for BR path (defense-in-depth)
    if params and pv.get("param_definitions"):
        params = _validate_param_types(params, pv.get("param_definitions") or [])
    param_values = dict(params) if params else {}

    # ── Phase 132.37 — Static rows + consumer Dynamic merge ──────────────
    # Both Static rows (frozen at publish-time into ``pv.query_config.filters``
    # by management.publish_view) AND consumer URL Dynamic filters flow
    # through the SAME REPLACE-semantics helper used by saved_query.  This
    # closes the BR-path gap surfaced after Phase 132.37's first cut, where
    # Static rows were silently dropped at runtime because the BR handler
    # only forwarded consumer filters into ``extra_filters``.
    from api.published_views.helpers import merge_static_and_consumer_filters
    _br_qc = pv.get("query_config") or {}
    _br_static = _br_qc.get("filters") or []
    # F3 static-lock: only mode='dynamic' columns are consumer-overridable.
    # Scope to views that actually declare a mapping (None → legacy replace-all).
    _br_map = _br_qc.get("_where_clauses_mapping") or []
    _br_dyn = ({(r.get("column") or "").strip() for r in _br_map
                if isinstance(r, dict)
                and (r.get("mode") or "static").lower() == "dynamic"
                and (r.get("column") or "").strip()}
               if _br_map else None)
    merged_filters = _merge_filters_or_refuse(
        static_filters=_br_static,
        consumer_filters=filters or [],
        dynamic_columns=_br_dyn,
    )
    # Which merged rows came from the CALLER (a 400 is theirs to fix) and
    # which from the PUBLISHER (a 409: the view is misconfigured, and serving
    # without the row would deliver rows it exists to withhold).
    from core.where_clause_mapping import col_key as _br_ck
    _br_consumer_keys = {_br_ck((f.get("column") if isinstance(f, dict)
                                 else getattr(f, "column", "")) or "")
                         for f in (filters or [])}

    def _br_unapplied(cols, why):
        cols = sorted(set(cols))
        mine = [c for c in cols if _br_ck(c) in _br_consumer_keys]
        if mine:
            raise HTTPException(
                400, f"Filter column(s) {mine} cannot be applied to this view: "
                     f"{why}. Refusing rather than returning unfiltered rows.")
        raise HTTPException(
            409, f"This view's publisher filter on column(s) {cols} cannot be "
                 f"applied: {why}. Refusing rather than serving rows the view "
                 f"exists to withhold -- the publisher must fix the view.")
    # Phase 134-P — resolve date tokens (``@TODAY`` / ``${today}`` /
    # bare ``today``) in the publisher's Dynamic defaults BEFORE they
    # reach the raw_sql wrap.  Without this, a BR with
    # default=``@TODAY`` and no consumer override produces literal
    # ``WHERE business_close_date = '@TODAY'`` → SQL error / 0 rows.
    try:
        from core.date_resolver import CalendarTokenRefused, resolve_filter_tokens
        merged_filters = resolve_filter_tokens(merged_filters) or []
    except CalendarTokenRefused:
        raise          # a filter that cannot be rendered refuses (400)
    except Exception as _tok_br_exc:
        logger.warning(
            "[pv-br] date-token resolution failed for view=%s br_id=%s: %s "
            "— proceeding with un-resolved tokens (may fail at SQL execution)",
            pv.get("slug"), br_id, _tok_br_exc,
        )

    # Phase 134-M parity (audit follow-up #2) — Dynamic-column set
    # used both for the raw_sql BR wrap below AND surfaced in logs.
    _br_mapping = (pv.get("query_config") or {}).get("_where_clauses_mapping") or []
    _br_dyn_columns = {
        (row.get("column") or "").strip()
        for row in _br_mapping
        if isinstance(row, dict)
        and (row.get("mode") or "static").lower() == "dynamic"
        and (row.get("column") or "").strip()
    }

    # Phase 134-M parity — when the BR's data_source_type is "raw_sql",
    # the dataset_id is a 0 sentinel and the name→column_id mapping
    # below collapses to "row dropped" for EVERY filter (because the
    # raw_sql BR has no dataset schema to map against).  This silently
    # dropped every consumer override on PV-over-BR-with-raw_sql, so
    # the publisher's hardcoded WHERE in the raw SQL always won —
    # identical user-visible bug as the saved_query / federation paths
    # got in da53cd0 + 27c0815.  Fix: when the BR is raw_sql source,
    # apply wrap_sql_with_filters directly to the BR's raw SQL and
    # stash the wrapped version back into ``report["raw_sql_override"]``
    # so the downstream _execute_raw_sql_report → _run_sql_report path
    # picks it up.  The column_id mapping branch below is then skipped
    # because the wrap already encoded the consumer overrides.
    _br_data_src = (report.get("data_source_type") or "").lower()
    _is_raw_sql_br = (_br_data_src == "raw_sql")

    extra_filters: list = []
    if _is_raw_sql_br and merged_filters:
        from core.sql_filter_wrapper import FilterValueRefused
        try:
            # Resolve the raw SQL from one of the four possible sources.
            # raw_sql_override wins (already inline); else raw_sql_file_id
            # → NFS content; else saved-query lookup; else the legacy
            # raw_saved_query_id (Phase 111 backwards-compat).
            _br_raw_sql: Optional[str] = report.get("raw_sql_override")
            if not _br_raw_sql:
                _br_sql_file_id = report.get("raw_sql_file_id")
                if _br_sql_file_id:
                    from api.business_reports_api import _resolve_sql_file_to_override
                    _br_raw_sql, _ = _resolve_sql_file_to_override(int(_br_sql_file_id))
            if not _br_raw_sql:
                _br_sq_id = (report.get("raw_sql_saved_query_id")
                              or report.get("raw_saved_query_id"))
                if _br_sq_id and _db_manager is not None:
                    # BF-597: async DB.
                    _sq = await adb(_db_manager.get_query, int(_br_sq_id))
                    _qc = (_sq or {}).get("query_config") or {}
                    _br_raw_sql = (_qc.get("raw_sql")
                                    or _qc.get("custom_sql") or "")

            if not _br_raw_sql:
                _br_unapplied([f.get("column", "") for f in merged_filters],
                              "the report's raw SQL could not be resolved")
            if _br_raw_sql:
                from core.sql_filter_wrapper import (
                    wrap_sql_with_filters as _wrap_sql_br,
                    dialect_for_connection_type as _dial_br,
                )
                # BR's raw_sql executes against the connection chosen at
                # BR-config time.  Look up its connection_type so the
                # wrapper picks the right sqlglot dialect.
                _br_conn_id = (report.get("raw_connection_override_id")
                                or pv.get("connection_id"))
                _br_dialect = "duckdb"
                if _br_conn_id and _db_manager is not None:
                    try:
                        # BF-597: async DB.
                        _br_crec = await adb(_db_manager.get_connection_raw, _br_conn_id)
                        if _br_crec:
                            _br_dialect = _dial_br(_br_crec.get("connection_type"))
                    except Exception as _be_exc:
                        note_best_effort("_dial_br(_br_crec.get('connection_type'))", _be_exc,
                                         logger=logger)
                # 2026-10-05 -- the COLUMN's type, as on the saved-query
                # path (declared mapping type, else the view's recorded
                # schema, else the source's description of this SQL), so a
                # date filter on a raw-SQL report's view is a DATE literal on
                # Trino rather than ``date = varchar`` -> 500.
                from core.raw_sql_filter_types import (
                    filter_column_types as _br_filter_types,
                    recorded_view_types as _br_recorded_types,
                )
                _br_declared = {
                    (r.get("column") or "").strip(): str(r.get("data_type") or "")
                    for r in (_br_mapping or [])
                    if isinstance(r, dict) and (r.get("column") or "").strip()
                    and str(r.get("data_type") or "")
                }
                _br_types = await _br_filter_types(
                    _br_raw_sql, merged_filters,
                    connection_id=_br_conn_id, db=_db_manager,
                    recorded=await adb(_br_recorded_types, _db_manager, pv.get("id")),
                    declared=_br_declared,
                )
                _br_wrapped = _wrap_sql_br(
                    _br_raw_sql, merged_filters,
                    dialect=_br_dialect,
                    dynamic_columns=_br_dyn_columns or None,
                    column_types=_br_types or None,
                )
                if _br_wrapped and _br_wrapped != _br_raw_sql:
                    # Stuff the wrapped SQL back into raw_sql_override
                    # so _execute_raw_sql_report → _as_legacy_report
                    # picks it up.  raw_sql_override wins over both
                    # raw_sql_file_id (line 920) and the saved-query
                    # lookup downstream, so this is the safe override
                    # point.
                    report["raw_sql_override"] = _br_wrapped
                    logger.info(
                        "[pv-br-wrap] view=%s br_id=%s dialect=%s "
                        "filters=%d dynamic_cols=%s sql=%s",
                        pv.get("slug"), br_id, _br_dialect,
                        len(merged_filters),
                        sorted(_br_dyn_columns) if _br_dyn_columns else [],
                        _br_wrapped[:4000],
                    )
                    logger.info(
                        "[pv-br-wrap-original] view=%s br_id=%s sql=%s",
                        pv.get("slug"), br_id, _br_raw_sql[:4000],
                    )
        except HTTPException:
            raise
        except FilterValueRefused as _br_val_exc:
            # The caller named a value its column cannot hold: 400 with the
            # column, the type and the accepted formats (2026-10-05).
            raise HTTPException(400, str(_br_val_exc)) from _br_val_exc
        except Exception as _br_wrap_exc:
            # Edge-case sweep 2026-09-24: this used to fall through to a path
            # that drops every filter for a raw_sql report ("no worse than
            # before") and answer 200 with unfiltered rows.  It is worse: it
            # looks filtered.
            logger.warning(
                "[pv-br-wrap] view=%s br_id=%s wrap failed: %s",
                pv.get("slug"), br_id, _br_wrap_exc,
            )
            _br_unapplied([f.get("column", "") for f in merged_filters],
                          f"the filters could not be applied to the report's SQL "
                          f"({type(_br_wrap_exc).__name__}: {_br_wrap_exc})")

    # Legacy column_id mapping path — used for parquet / federation BR
    # sources (where dataset_id maps to a real dataset schema).  For
    # raw_sql BRs the wrap above already encoded the overrides, so
    # this branch is effectively a no-op (no dataset columns to map
    # against, every filter gets the "row dropped" warning).
    _br_missing: list = []
    if merged_filters and not _is_raw_sql_br:
        col_map: dict = {}
        try:
            if hasattr(_db_manager, "list_dataset_columns"):
                # BF-597: async DB.
                ds_cols = await adb(_db_manager.list_dataset_columns, report.get("dataset_id"))
                # Build a case-insensitive name → column_id map so the
                # snapshot's qualified or differently-cased Static rows
                # still resolve (matches the publish-time _col_key
                # normalisation).
                col_map: dict = {}
                for c in (ds_cols or []):
                    pname = (c.get("physical_name") or "").lower()
                    if pname:
                        col_map[pname] = c["id"]
                for f in merged_filters:
                    raw_col = f.get("column", "") or ""
                    bare = raw_col.rsplit(".", 1)[-1] if "." in raw_col else raw_col
                    cid = col_map.get(bare.lower()) or col_map.get(raw_col.lower())
                    if cid:
                        extra_filters.append({
                            "column_id": cid,
                            "operator": f.get("operator", "eq"),
                            "value": f.get("value"),
                        })
                    else:
                        _br_missing.append(raw_col)
        except HTTPException:
            raise
        except Exception as _br_map_exc:
            logger.warning("[pv-br] dataset column lookup failed for view=%s: %s",
                           pv.get("slug"), _br_map_exc)
            raise HTTPException(
                503, "The report's columns could not be read, so this view's "
                     "filters cannot be applied; retry later.") from None
        if _br_missing:
            # Edge-case sweep 2026-09-24: measured -- ?filter[nope]=eq:1 on
            # view 7 answered 200 with every row; the row was "dropped" with
            # a log line.  A filter that cannot be rendered must refuse.
            _br_unapplied(_br_missing,
                          "no such column on the report's dataset (known: "
                          + ", ".join(sorted(col_map)) + ")")

    combined_filters = _build_report_filters(
        report=report,
        param_values=param_values,
        db=_db_manager,
        report_id=br_id,
        extra_filters=extra_filters,
        # ``param_values`` here is the VIEW's parameter vocabulary (validated
        # against pv.param_definitions above), not the report's -- names the
        # report does not declare are expected, not typos.
        strict_parameter_names=False,
    )
    # 2026-10-29 -- the report's SOURCE parameters (filter at the source) ride
    # the engine's own argument, never the filter list
    from api.business_reports_api import _build_source_bindings
    source_bindings = _build_source_bindings(report, param_values, _db_manager, br_id)

    execution_id = f"pv_br_{_uuid.uuid4().hex[:12]}"
    # 2026-08 redesign — materialize the DATASET (up to the cap), not the
    # requested page.  ``limit + offset`` truncated the BR result at the page
    # boundary and the truncated footer became ``total_rows`` — same metadata
    # lie as the saved_query path.  cap+1 = overflow sentinel (see saved_query
    # handler).  The federation engine additionally clamps to its own
    # semantic_layer.max_rows — a clamp there also means AT_LEAST semantics,
    # detected below by footer == requested cap.
    from api.published_views.envelope import dataset_row_cap as _br_cap_fn
    _br_cap = _br_cap_fn()
    # 2026-10-03, REAL Snowflake load test: an UNBOUNDED cap (bulk runs under
    # ``dataset_row_cap_override(0)``) used to become ``None`` here -- and the
    # federation engine reads None as "the default page"
    # (semantic_layer.default_row_limit = 10,000).  /bulk on a 2.47M-row view
    # served 10,000 rows and its manifest said EXACT.  Unlimited is 0 there.
    row_limit = report_row_limit_for_cap(_br_cap)
    from core.reports.admission import (
        ReportAdmissionRefused as _PvAdmissionRefused,
        run_admitted as _run_admitted_pv,
    )
    from core.worker_pool import WorkType as _WorkTypePV
    # 2026-09-24 -- THE ROW-SECURITY PRINCIPAL IS THE CONSUMER, in every
    # credential mode.  Phase 133-J swapped this variable by credential_mode:
    # 'publisher' -> {"username": <publisher>}, 'shared' -> None.  But on
    # this path ``user_ctx`` reaches NOTHING but row security (and
    # ${user.*} rendering): the dataset executes on its OWN stored
    # connection, so the swap never moved a credential.  What it moved was
    # WHOSE ROWS:
    #   * 'publisher' (the UI's default) filtered every caller as a
    #     role-less, group-less copy of the publisher -- measured on the
    #     login rig: admin, analyst and API key all got 0 rows; a publisher
    #     holding a grant would have handed THEIR rows to every API key;
    #   * 'shared' passed None, and the engine skips row security for a
    #     None principal (it only warns) -- every row of a governed table
    #     to anyone holding a key.
    # The federation handler below already keeps credentials on the
    # publisher and the principal on the consumer; this is the same rule.
    # 2026-10-25 -- an API key is the RESOLVED principal ``api_key:<id>``
    # (core/row_security/principal.py); whether this API applies any data
    # policy to it is the view's switch, stamped below.  With no consumer at
    # all (warmup / internal) the principal is the view itself, MARKED
    # unresolved: fail closed, never unfiltered (decided 2026-10-25: no
    # background principal is widened).
    # 2026-10-24 -- WITH the view's data-policy surface (an API key is
    # governed only under ``apply``): the raw ``consumer_user`` lacked it, so
    # a key on a view switched OFF was entitled as a PERSON holding nothing
    # and read 0 rows (rig proof).  Stamped here, not only by the
    # dispatcher, so direct callers get the same rule (idempotent).
    _effective_user_ctx = _with_entitlement_scope(consumer_user, pv) if consumer_user is not None else {
        "username": f"published_view:{pv.get('slug', '')}",
        "role": "pv_consumer", "groups": [], "is_admin": False,
        "rls_unresolved": True,
    }
    try:
        if _is_raw_sql_br:
            # 2026-08-29 — the missing half of the wrap above.  That code
            # stashes the consumer-filtered SQL into ``raw_sql_override`` "so
            # the downstream _execute_raw_sql_report path picks it up", and no
            # such downstream existed in this function: execution went to
            # _run_report_query -> execute_dataset_query with the raw_sql
            # dataset_id=0 sentinel, which raises "Dataset 0 not found".  So
            # publishing a raw_sql report as a view produced a view that
            # answered every data request with a generic 500, and the wrapped
            # SQL -- and every ${user.*} in it -- was computed and discarded.
            from api.business_reports_api import _execute_raw_sql_report
            # 2026-09-15: through the admission gate as PUBLISHED_API work
            # (the type the saved_query PV path already uses -- external
            # consumers are isolated from internal REPORT slots), not the
            # default executor every adb() call shares.
            # 2026-09-29: the gate's slot in the global query cap is charged
            # to the CONSUMER (_admission_identity), not to the view -- the
            # view's name was one shared bucket for every key and every
            # session that called it.
            result = await _run_admitted_pv(
                _WorkTypePV.PUBLISHED_API, _execute_raw_sql_report,
                report, params or {}, row_limit, br_id, _db_manager,
                "viewer", _effective_user_ctx,
                execution_id=execution_id,
                username=_admission_identity(consumer_user, pv))
        else:
            result = await _run_admitted_pv(
                _WorkTypePV.PUBLISHED_API, _run_report_query,
                _federation_engine, report, combined_filters, row_limit,
                execution_id, "viewer", user_ctx=_effective_user_ctx,
                source_bindings=source_bindings,
                execution_id=execution_id,
                username=_admission_identity(consumer_user, pv))
    except _PvAdmissionRefused as _ref:
        # 2026-09-15: the gate refused -- 503 + reason + Retry-After, the
        # same shape /api/execute returns; never a generic 500.
        logger.warning("[pv-br] view=%s br_id=%s refused at admission: %s",
                       pv.get("slug"), br_id, _ref.reason)
        raise _ref.as_http()
    except HTTPException:
        # Parameter validation and the authoring-error refusal already carry
        # a precise status and message; flattening them into a 500 would hide
        # exactly the diagnosis the caller needs.
        raise
    except Exception as exc:
        # 2026-09-24: row security REFUSED this principal (an API key on a
        # governed table: no directory identity, so no grant can match).
        # That is an answer, not a fault -- 403 with the reason, the shape
        # the raw-SQL view path already returns, never "contact support".
        from core.row_security.api import RowSecurityRefused as _RsRefusedBr
        if isinstance(exc, _RsRefusedBr):
            logger.warning("[pv-br] view=%s br_id=%s refused by row security: %s",
                           pv.get("slug"), br_id, exc)
            raise HTTPException(
                status_code=403,
                detail=f"Row-security policy enforcement failed: {exc}")
        logger.error("[pv-br] BR execution failed br_id=%d: %s", br_id, exc, exc_info=True)
        # 2026-09-17 (FB-15c) -- an open circuit breaker is TEMPORARY and
        # self-clearing, and its message was written for the caller;
        # answering 500 "contact support" turned a 45-second wait into a
        # support ticket.  See raise_if_self_clearing.
        _raise_if_self_clearing(exc)
        raise HTTPException(500, "Query execution failed — contact administrator")

    # Locate output parquet
    output_path = getattr(result, "output_path", None)
    if output_path is None and isinstance(result, dict):
        output_path = result.get("output_path")
    if not output_path or not _Path(str(output_path)).exists():
        raise HTTPException(500, "Business report produced no output file")

    from api.published_views.envelope import (
        DatasetManifest as _BrManifest, TotalMode as _BrTotalMode,
        col_meta_from_schema as _br_col_meta, read_page as _br_read_page,
        rows_from_table as _br_rows,
    )
    def _br_page_blocking():
        """The result file's footer, the page and its rows -- file I/O and
        Arrow decode, run OFF the loop (api/published_views/page_io.py)."""
        # Cap-overflow detection: footer == our cap+1 sentinel, OR the
        # federation engine clamped to its own semantic_layer.max_rows.
        import pyarrow.parquet as _br_pq
        _br_total = _br_pq.ParquetFile(str(output_path)).metadata.num_rows
        _br_engine_max = None
        try:
            from core import config as _br_cfg
            _br_engine_max = int(getattr(_br_cfg.semantic_layer, "max_rows", 0) or 0)
        except Exception:
            _br_engine_max = None
        _cap_hit = bool(
            (_br_cap > 0 and _br_total == _br_cap + 1)
            or (_br_engine_max and _br_total == _br_engine_max)
        )
        _br_page_offset, _br_page_limit = offset, limit
        _br_reported_total = _br_total
        if _br_cap > 0 and _br_total == _br_cap + 1:
            _br_reported_total = _br_cap
            _br_page_offset = min(offset, _br_cap)
            _br_page_limit = max(0, min(limit, _br_cap - _br_page_offset))
        _tbl, _footer_total = _br_read_page(
            str(output_path), columns=columns, limit=_br_page_limit, offset=_br_page_offset,
            sort_column=sort_column, sort_dir=sort_dir, strict=True,
        )
        return _tbl, _br_reported_total, _cap_hit, _br_rows(_tbl)

    try:
        table, total_rows, _br_cap_hit, _br_data = await _page_io.off_loop(_br_page_blocking)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to read business report result for view: %s", exc)
        # 2026-09-17 (FB-15c) -- an open circuit breaker is TEMPORARY and
        # self-clearing, and its message was written for the caller;
        # answering 500 "contact support" turned a 45-second wait into a
        # support ticket.  See raise_if_self_clearing.
        _raise_if_self_clearing(exc)
        raise HTTPException(500, "Query execution failed — contact administrator")

    col_meta = _br_col_meta(table.schema)

    try:
        # BF-597: async DB.
        await adb(_db_manager.increment_business_report_execution, br_id)
    except Exception as e:
        logger.warning("Failed to increment business report execution counter: %s", e)

    _br_manifest = _BrManifest(
        total_rows=total_rows,
        total_mode=(_BrTotalMode.AT_LEAST if _br_cap_hit else _BrTotalMode.EXACT),
        source_type="business_report",
        execution_id=execution_id,
        data_status=("empty_unverified" if total_rows == 0 else "ok"),
        empty_causes=(["business report produced 0 rows; emptiness not independently verified"]
                      if total_rows == 0 else []),
    )
    _br_out = {
        "total_rows": total_rows,
        "returned_rows": table.num_rows,
        "offset": offset,
        "limit": limit,
        "columns": col_meta,
        "data": _br_data,
        "_parquet_path": str(output_path),
        "_manifest": _br_manifest,
        "_page_table": table,
    }
    return _br_manifest.apply_to_result(_br_out)


async def _execute_view_federation(
    pv: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    params: Optional[Dict[str, Any]] = None,
    consumer_user: Optional[Dict[str, Any]] = None,
    snapshot_id: Optional[int] = None,          # time travel: REFUSED here --
    as_of_timestamp_ms: Optional[int] = None,   # see _refuse_unless_time_travel_
    stream: bool = False,                       # supported (FB-38, 2026-09-19)
) -> dict:
    """Phase 93 — Execute a federation view as a published view.

    Phase 131 deep-dive #9 / 2026-09-05: ``consumer_user`` is the RLS
    principal and IS threaded into ``execute_federation_view`` as
    ``user_ctx``.  Credential resolution stays on the PUBLISHER's
    ``username`` — see the block comment at the call site for why the two
    identities are deliberately different.
    """
    await _refuse_unless_time_travel_supported(pv, snapshot_id, as_of_timestamp_ms)  # FB-38

    fv_id = pv.get("federation_view_id")
    if not fv_id:
        raise HTTPException(500, "Published view missing federation_view_id")
    # BF-597: async DB.
    fv = await adb(_db_manager.get_federation_view, fv_id)
    if not fv:
        raise HTTPException(404, f"Federation view {fv_id} not found")
    return await _execute_federation_shape(
        pv, fv, filters, columns, sort_column, sort_dir, limit, offset,
        consumer_user=consumer_user, source_type="federation")


async def _execute_federation_shape(
    pv: dict,
    fv: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    *,
    consumer_user: Optional[Dict[str, Any]] = None,
    source_type: str = "federation",
    credential_user: Optional[str] = None,
) -> dict:
    """THE federation road of the published API (2026-10-24).

    ``fv`` is a federation-view SHAPE -- ``primary_conn_id`` /
    ``primary_query`` / ``secondary_conn_id`` / ``secondary_query`` /
    ``combine_mode`` / ``join_on`` / ``join_how`` / ``output_columns`` --
    whether it is a stored ``federation_views`` row (``_execute_view_federation``)
    or the query editor's cross-source saved SQL translated into that shape
    (``_execute_view_cross_source``).  Everything below is decided ONCE for
    both: the static + consumer filter merge, date tokens, the Dynamic
    columns, the RLS and credential identities, the slot in the global query
    cap, ``execute_federation_view`` with ``materialize_to`` + ``full_fetch``,
    the dataset cap and the manifest.  ``source_type`` is what the manifest
    says the dataset came from.

    This body used to live in ``_execute_view_federation`` alone while the
    cross-source saved-SQL views ran ``execute_cross_query_background``,
    whose S3 raw-SQL leg runs ``setup_registered_views`` IN the API worker:
    6.5 min / ~2.9 GB RSS for 20,000 rows and a 504, where the same SQL
    through here took seconds (measured on the rig against real AWS S3 and
    an on-prem Starburst-shaped Trino).  A decision made twice is a bug.
    """
    fv_id = fv.get("id") or f"xs{pv.get('id')}"
    from api.federation_views_api import execute_federation_view

    # ── Phase 132.37 — Static rows + consumer Dynamic merge ──────────────
    # Identical contract to the saved_query / business_report handlers:
    # Static rows the publisher locked at publish-time (frozen into
    # ``pv.query_config.filters`` by management.publish_view) AND consumer
    # URL filters flow through the same REPLACE-semantics helper so the
    # federation handler stays at parity with the other two.  Closes the
    # gap surfaced after Phase 132.37's first cut where federation PVs
    # ignored Static rows at runtime.
    from api.published_views.helpers import merge_static_and_consumer_filters
    _fv_qc = pv.get("query_config") or {}
    _fv_static = _fv_qc.get("filters") or []
    # F3 static-lock (see BR path): only mode='dynamic' columns overridable;
    # None → legacy replace-all for views without a mapping.
    _fv_map = _fv_qc.get("_where_clauses_mapping") or []
    _fv_dyn = ({(r.get("column") or "").strip() for r in _fv_map
                if isinstance(r, dict)
                and (r.get("mode") or "static").lower() == "dynamic"
                and (r.get("column") or "").strip()}
               if _fv_map else None)
    merged_filters = _merge_filters_or_refuse(
        static_filters=_fv_static,
        consumer_filters=filters or [],
        dynamic_columns=_fv_dyn,
    )
    # Phase 134-P — resolve date tokens before passing to the FV side
    # wrap (executed inside execute_federation_view → _execute_side →
    # wrap_sql_with_filters when the FV side has raw_sql).
    try:
        from core.date_resolver import CalendarTokenRefused, resolve_filter_tokens
        merged_filters = resolve_filter_tokens(merged_filters) or []
    except CalendarTokenRefused:
        raise          # a filter that cannot be rendered refuses (400)
    except Exception as _tok_fv_exc:
        logger.warning(
            "[pv-fv] date-token resolution failed for view=%s: %s",
            pv.get("slug"), _tok_fv_exc,
        )
    extra_filters = merged_filters or None

    # Phase 134-M parity — derive the Dynamic-column set from the PV's
    # snapshot ``_where_clauses_mapping`` so the federation view path
    # gets the same REPLACE-semantics on raw_sql as PV/Feed/Recon.
    # Without this a federation view with raw_sql + hardcoded
    # ``WHERE business_close_date='2025-09-30'`` ignored the consumer
    # override (engine bypasses the structured ``filters`` list when
    # raw_sql is set, so the publisher's hardcoded value always won).
    _fv_mapping = (pv.get("query_config") or {}).get("_where_clauses_mapping") or []
    _fv_dyn_columns = {
        (row.get("column") or "").strip()
        for row in _fv_mapping
        if isinstance(row, dict)
        and (row.get("mode") or "static").lower() == "dynamic"
        and (row.get("column") or "").strip()
    }
    # 2026-10-24 -- a publisher-declared ``data_type`` on a mapping row types
    # the filter literal on each side (``core.raw_sql_filter_types``: the
    # declared type wins, then the source's description).  The saved-query
    # road always honoured it; the federation road now does too.
    _fv_declared_types = {
        (row.get("column") or "").strip(): str(row.get("data_type") or "")
        for row in _fv_mapping
        if isinstance(row, dict) and (row.get("column") or "").strip()
        and str(row.get("data_type") or "")
    }

    # ── 2026-08 redesign — materialize the DATASET once, page centrally ──
    # The old flow applied LIMIT/OFFSET in DuckDB inside
    # execute_federation_view AND re-applied ``df.iloc[offset:]`` here, so
    # page 2 (?offset=100) came back EMPTY and the consumer concluded the
    # view had ≤100 rows.  That double-application is impossible now by
    # construction: the federation engine materializes the FULL combined
    # dataset to parquet (limit=0/offset=0 = no page clause), and paging /
    # sorting / projection happen in exactly one place — the same
    # envelope.read_page every other source type uses.  total_rows is the
    # engine's exact COUNT(*), so TotalMode.EXACT is justified, and a 0-row
    # combine is verified-empty ("empty", not "empty_unverified").
    from api.published_views.envelope import (
        DatasetManifest as _FvManifest, TotalMode as _FvTotalMode,
        col_meta_from_schema as _fv_col_meta, read_page as _fv_read_page,
        rows_from_table as _fv_rows,
    )
    _tmp_dir = Path(tempfile.gettempdir()) / "qs_pv_federation"
    _tmp_dir.mkdir(parents=True, exist_ok=True)
    _dataset_path = _tmp_dir / f"pv_fed_{fv_id}_{uuid.uuid4().hex[:12]}.parquet"

    # ── 2026-09-05 — RLS IDENTITY: the CONSUMER, not the publisher ───────
    # This call accepted ``consumer_user`` (and said so in the docstring)
    # and then never passed it on: it handed ``execute_federation_view``
    # only ``username`` = the PUBLISHER and no ``user_ctx`` at all.  With
    # ``user_ctx=None``, ``federation_views_api._fv_principal`` fabricates
    # an ``fv_consumer`` principal with ``groups: []`` MARKED
    # ``rls_unresolved`` — which core/row_security/rewriter.py turns into a
    # per-governed-table REFUSAL.  So this was FAIL-CLOSED, never a leak;
    # the harm is that a consumer whose groups legitimately grant access
    # was refused, and the principal the engine (and the audit trail) saw
    # was not the caller's.  The other three PV handlers already thread
    # ``pv["_consumer_user_ctx"]`` (stashed by the dispatcher); this one
    # now does too.  ``consumer_user`` is read as a fallback so DIRECT
    # handler callers (tests, the BR/feed bridges) get the same identity
    # as dispatched ones.
    #
    # ONLY THE REAL CONSUMER CTX IS FORWARDED — deliberately NOT the
    # ``pv:<slug>`` synthetic that ``_pv_user_ctx`` falls back to in the
    # saved_query handler.  That synthetic carries
    # ``groups=allowed_ad_groups`` and NO ``rls_unresolved`` marker, and in
    # this GRANT-shaped engine an UNMARKED principal that matches no
    # binding reads governed tables UNFILTERED (spelled out in
    # core/reports/sources.py::_require_owner_principal).  Handing it to
    # ``_fv_principal``, which uses a real-looking ctx AS-IS, would convert
    # today's refusal into an ESCALATION.  No consumer ctx ⇒ pass None ⇒
    # keep the marked, fail-closed fabricated principal.
    #
    # ``username`` STAYS THE PUBLISHER — deliberately.  It is the
    # CREDENTIAL identity (``_execute_side`` feeds it to
    # ``resolve_s3_for_consumer``), a different axis from the RLS
    # principal, and the FV API keeps the two as separate parameters for
    # exactly this reason.  A published view runs against the source the
    # PUBLISHER configured; re-pointing credential resolution at the
    # consumer (typically an API key with no AWS mapping) would change
    # which STS role the query signs with — a credential-model change, not
    # an identity fix, and not what this defect is.  (Per-view
    # ``credential_mode`` parity with the BR handler is a separate,
    # unimplemented piece of work; it belongs on ``username``, not here.)
    # ── 2026-09-05 (round 2) — GUARD THE PROPERTY, NOT THE PROVENANCE ───
    # Everything above is right about the ``pv:<slug>`` SYNTHETIC and it
    # still must not be forwarded.  But "synthetic" is not the property that
    # decides anything.  The dangerous shape is UNMARKED + GROUPLESS, and the
    # REAL consumer ctx on this surface has exactly that shape whenever the
    # caller holds an API key (``deps.get_api_key_user``) or auth is off
    # (``basic_noauth``): both return ``groups: []`` with no marker,
    # ``_fv_principal`` uses a ctx that has a username AS-IS, and
    # ``core/row_security/rewriter.py`` refuses a governed table ONLY when
    # the marker is present.  So forwarding the real ctx — this morning's
    # fix — turned yesterday's refusal into a full UNFILTERED read for
    # API-key consumers.  Executed probe:
    #     pre-fix  principal: {... groups: [], rls_unresolved: True} -> refuse
    #     post-fix principal: {'username': 'apikey:pk_live', groups: []}
    #     secured SQL: 'SELECT * FROM payroll'   (governed, NOT filtered)
    #
    # ── 2026-10-25 -- THE RULE CHANGED (the owner: "no one should get 403")
    # An API key is the RESOLVED principal ``api_key:<id>`` (core/row_security/
    # principal.py): a binding made to it applies, a group binding does not,
    # and what it holds nothing of is FB-45's composition (no grant held =
    # no rows) -- never a refusal.  Whether THIS API applies any data policy
    # to its keys is the view's switch (``entitlement_mode``, stamped as the
    # ``entitlement_scope`` by ``with_entitlement_scope``): the dispatcher
    # stamps ``_consumer_user_ctx``; a direct caller's ``consumer_user`` is
    # stamped here so both roads carry the same surface.  No consumer at all
    # still passes None, and ``_fv_principal`` keeps its MARKED fabricated
    # principal (fail closed; decided 2026-10-25: no background principal is
    # widened).
    _fv_consumer_ctx = pv.get("_consumer_user_ctx") or (
        _with_entitlement_scope(consumer_user, pv) if consumer_user else None)

    # ── 2026-09-05 — ``full_fetch=True`` PLUS a real cap ─────────────────
    # ``full_fetch`` strips any per-side ``limit`` saved in
    # ``fv.primary_query`` / ``fv.secondary_query``.  That value is a
    # PREVIEW limit — ``federation_views_api._execute_side`` says so in its
    # own docstring ("removes any saved row limit ... not just the preview
    # limit") — never a safety cap.  Leaving it applied truncated a
    # materialisation whose manifest then declared ``TotalMode.EXACT``: a
    # short dataset announcing an exact total, which is the success that is
    # a failure.  The sibling materialisation
    # (``federation_views_api.materialize_view``) has always passed it.
    #
    # The earlier assessment left it on the ground that this handler applies
    # NO ``dataset_row_cap``, so the preview limit was the only bound on a
    # materialisation running inside an open HTTP request.  That does not
    # survive checking, for the reason the same note gives: the shipped
    # authoring UI never writes a ``limit`` into either side
    # (FederationViewsPage.tsx seeds ``{files, filters, columns}``), so on
    # every federation view the product itself can create the
    # materialisation is ALREADY unbounded.  The "bound" was an accident of
    # a hand-written API payload — present on a few views and absent on all
    # the rest, and silent on both.  A cap must throttle and a correctness
    # gate must fail; this was neither.
    #
    # So: strip the preview limit AND give this path the ``dataset_row_cap``
    # its two sibling handlers already have.  The cap cannot be pushed into
    # the combine — the engine's ``materialize_to`` branch ignores
    # ``limit``/``offset`` BY CONSTRUCTION so that paging happens exactly
    # once, in the caller — so it is applied to the SERVED dataset the way
    # the business-report handler applies its cap+1 sentinel: the reported
    # total is clamped to the cap, the readable window is clamped with it,
    # and ``TotalMode.AT_LEAST`` says out loud that there are more.  No
    # sentinel ROW is needed here: ``total_rows`` off the engine is an exact
    # ``COUNT(*)`` over the combined result, so overflow is a comparison.
    # ── 2026-09-29 — a slot in the pod's GLOBAL query cap, like every ──
    # other query path.  This handler went straight to the engine: the
    # cap /api/execute and the report lanes are bounded by never saw a
    # federation view served through the published API.  Charged to the
    # consumer (_admission_identity); refused at the cap with the ONE wire
    # shape (503 + Retry-After: 5); released on EVERY exit, the request's
    # cancellation included (the ``finally``).  No wait on this sync
    # path unless an async report runner armed one by scope.
    from core.reports.admission import (
        QuerySlot as _FvQuerySlot,
        ReportAdmissionRefused as _FvAdmissionRefused,
        release_when_all_work_ends as _release_when_all_work_ends,
    )
    _fv_slot = _FvQuerySlot(
        _admission_identity(pv.get("_consumer_user_ctx") or consumer_user, pv),
        _dataset_path.stem, per_user=True)
    try:
        await _fv_slot.acquire()
    except _FvAdmissionRefused as _fv_ref:
        logger.warning("[pv-fv] view=%s fv=%s refused at admission: %s",
                       pv.get("slug"), fv_id, _fv_ref.reason)
        raise _fv_ref.as_http()
    _fv_side_ids: List[str] = []        # each side appends its execution id as minted
    try:
        result = await execute_federation_view(
            fv, limit=0, offset=0,          # dataset, not a page — no LIMIT/OFFSET
            extra_filters=extra_filters,
            # CREDENTIAL identity: the publisher for a federation view; a moved
            # sql_query / sql_file view passes the one its credential_mode
            # names (2026-10-24, security review -- _execute_view_cross_source)
            username=(credential_user if credential_user is not None
                      else pv.get("created_by", "system")),
            user_ctx=_fv_consumer_ctx,                 # RLS identity
            full_fetch=True,                # a saved PREVIEW limit is not a cap
            dynamic_columns=_fv_dyn_columns or None,
            materialize_to=str(_dataset_path),
            side_execution_ids=_fv_side_ids,
            declared_filter_types=_fv_declared_types or None,
        )
    finally:
        # The slot is the ENGINE's, not this coroutine's.  Each side runs as
        # a pool task under the execution id it appended to ``_fv_side_ids``
        # (before any await, so a cancel cannot lose it); the combine runs
        # inline on the loop and cannot be split by a cancel.  A request
        # cancelled mid-side leaves here while a side's thread is still
        # inside the engine: the release rides the LAST live side's
        # done-callback, once, and happens now when no side is live.
        _release_when_all_work_ends(_fv_side_ids, _fv_slot)
    _fv_source_total = int(result["total_rows"])

    from api.published_views.envelope import dataset_row_cap as _fv_cap_fn
    _fv_cap = _fv_cap_fn()
    _fv_cap_hit = bool(_fv_cap > 0 and _fv_source_total > _fv_cap)
    total_rows = _fv_source_total
    _fv_page_offset, _fv_page_limit = offset, limit
    if _fv_cap_hit:
        # Announced, not inferred: an operator reading the log must be able
        # to tell a capped dataset from a small one.
        logger.warning(
            "[pv-fv] view=%s fv=%s combined %d rows, over the "
            "published_views.dataset_row_cap of %d — serving the first %d and "
            "reporting total_mode=at_least",
            pv.get("slug"), fv_id, _fv_source_total, _fv_cap, _fv_cap,
        )
        total_rows = _fv_cap
        _fv_page_offset = min(offset, _fv_cap)
        _fv_page_limit = max(0, min(limit, _fv_cap - _fv_page_offset))

    def _fv_page_blocking():
        """The page and its rows -- Arrow decode OFF the loop
        (api/published_views/page_io.py)."""
        _tbl, _footer_total = _fv_read_page(
            str(_dataset_path), columns=columns,
            limit=_fv_page_limit, offset=_fv_page_offset,
            sort_column=sort_column, sort_dir=sort_dir, strict=True,
        )
        return _tbl, _fv_rows(_tbl)

    table, _fv_data = await _page_io.off_loop(_fv_page_blocking)

    _fv_manifest = _FvManifest(
        total_rows=total_rows,
        total_mode=(_FvTotalMode.AT_LEAST if _fv_cap_hit else _FvTotalMode.EXACT),
        source_type=source_type,
        data_status=("empty" if total_rows == 0 else "ok"),
    )
    _fv_out = {
        "total_rows": total_rows,
        "returned_rows": table.num_rows,
        "offset": offset,
        "limit": limit,
        "columns": _fv_col_meta(table.schema),
        "data": _fv_data,
        "_parquet_path": str(_dataset_path),
        "_manifest": _fv_manifest,
        "_page_table": table,
    }
    return _fv_manifest.apply_to_result(_fv_out)


# ── ONE cross-source road for the query editor's saved SQL (2026-10-24) ──────
#
# A ``sql_query`` (CQB saved query) or ``sql_file`` published view whose
# snapshot carries a SECONDARY connection is two statements on two
# connections combined by UNION or JOIN -- exactly what a federation view is.
# Its snapshot spells that in the saved query's vocabulary; the federation
# engine reads the federation view's.  The translation below is the ONE
# place the two vocabularies meet; the execution is ``_execute_federation_shape``,
# the same function a ``federation`` view runs.
#
# The road it replaced -- ``execute_cross_query_background`` -- ran an S3
# raw-SQL side IN-PROCESS in the API worker (``_exec_side_to_parquet`` ->
# ``_raw_sql_with_views`` -> ``setup_registered_views``): on the rig, 20,000
# rows of fact_tetb (6 parquet files on AWS S3) took 6.5 minutes with
# "no progress" heartbeats, drove the worker to ~2.9 GB RSS of its 3 GB share,
# the request timed out (504) and the memory guard then refused every request
# on that worker.  The SAME SQL as a federation view -- the S3 side through
# ``execute_query_background`` (the DuckDB subprocess), the connector side
# through ``cross_source_combine.run_side_to_parquet`` -- took seconds in
# bounded memory and passed every paging check.  A decision made twice is a bug.

#: The published-view source types whose snapshot may carry a secondary side
#: in the saved-SQL spelling (``api/published_views/management.py``).
CROSS_SOURCE_SQL_SOURCE_TYPES = frozenset({"sql_query", "sql_file"})


def _is_cross_source_sql_view(pv: dict, query_config: dict) -> bool:
    """Is this a ``sql_query`` / ``sql_file`` view with a SECONDARY connection?

    The single-source ``sql_query`` / ``sql_file`` views (no secondary) and
    every ``saved_query`` view -- cross-source or not -- are NOT this: they
    keep the saved-query handler unchanged.
    """
    src = (query_config.get("source_type") or pv.get("source_type")
           or "saved_query")
    return (src in CROSS_SOURCE_SQL_SOURCE_TYPES
            and bool(query_config.get("secondary_connection_id")))


async def _federation_shape_of_cross_source_view(pv: dict, query_config: dict) -> dict:
    """Translate a cross-source saved-SQL snapshot into the federation view SHAPE.

    Field by field (``query_config`` is the snapshot AFTER ``{{param}}``
    substitution, which covers ``raw_sql`` AND ``secondary_raw_sql`` --
    ``helpers._QC_SQL_FIELDS``):

    * ``primary_conn_id``   <- ``pv.execution_connection_id`` (the publish-time
      override, as on every other road) else ``pv.connection_id`` else
      ``query_config.connection_id``;
    * ``primary_query``     <- ``{"raw_sql": <primary statement>, "files": []}``;
      the primary statement is ``raw_sql`` / ``custom_sql``, read through
      ``core.cross_source_display.primary_statement_of`` for a pre-2026-10-07
      query builder row that stored its LABELLED display, with
      ``__logical__:`` references resolved against the primary connection;
    * ``secondary_conn_id`` <- ``query_config.secondary_connection_id``;
    * ``secondary_query``   <- ``{"raw_sql": <secondary_raw_sql>, "files": []}``,
      ``__logical__:`` references resolved against the secondary connection;
    * ``combine_mode`` / ``join_how`` / ``join_on`` <- ``combine_mode`` +
      ``join_config {how, left_on[], right_on[]}`` through THE combine
      vocabulary (``cross_source_combine.combine_spec``; blank mode = union,
      the snapshot's historical default): ``join_on`` is
      ``[{"left": l, "right": r}, ...]`` pairwise, ``join_how`` the normalised
      type (``outer`` -> ``full``);
    * ``output_columns``    <- ``[]`` (the saved SQL's projection IS the output);
    * ``id``                <- ``None`` (the result cache keys the sides' final
      SQL and the principal; the dataset file name uses the view's own id).

    REFUSES, never primary-only (the 2026-08-05 posture; the commit a4d7f4221
    guard on this road): no primary SQL, a secondary connection with no
    secondary SQL, a secondary connection that does not exist, a combine that
    cannot run (a JOIN without keys, an unknown join type) -- each a 400
    naming the view and the fix, BEFORE either side runs.
    """
    slug = pv.get("slug")
    sec_conn_id = query_config.get("secondary_connection_id")
    primary_conn_id = (pv.get("execution_connection_id")
                       or pv.get("connection_id")
                       or query_config.get("connection_id"))
    if not primary_conn_id:
        raise HTTPException(500, "View connection not available — contact administrator")

    primary_sql = str(query_config.get("raw_sql") or query_config.get("custom_sql") or "")
    if primary_sql.strip():
        # 2026-10-07 -- a cross-source query saved by the query builder before
        # that date holds its LABELLED display (primary AND secondary) in
        # raw_sql; the primary statement is the one that runs on the primary.
        from core.cross_source_display import primary_statement_of as _pso
        primary_sql = _pso(primary_sql)
    secondary_sql = str(query_config.get("secondary_raw_sql") or "")
    if not primary_sql.strip():
        raise HTTPException(
            400,
            f"Published view '{slug}' is cross-source but has no primary SQL to "
            f"run on connection {primary_conn_id}. Fix: re-publish the view from a "
            f"saved query with both statements.")
    if not secondary_sql.strip():
        raise HTTPException(
            400,
            f"Published view '{slug}' is cross-source but its secondary side "
            f"(connection {sec_conn_id}) has no SQL to run. Running it would "
            f"silently emit only the primary side's rows. Fix: re-publish the "
            f"view with both statements, or remove the secondary configuration.")
    # The secondary connection must EXIST -- a deleted one used to halve the
    # answer without an error (2026-08-05).  Named here, before any side runs.
    sec_rec = await adb(_db_manager.get_connection_raw, sec_conn_id)
    if not sec_rec:
        raise HTTPException(
            400,
            f"Published view '{slug}' is cross-source but its "
            f"secondary connection {sec_conn_id} does not exist "
            f"(deleted or never created). Running it would silently "
            f"emit only the primary side's rows. Fix: point the view "
            f"at an existing secondary connection, or remove the "
            f"secondary configuration.")

    # Phase 146-B -- ``__logical__:name`` references resolve against EACH
    # side's own connection; fail-CLOSED on a missing binding (400).
    from core.logical_table_service import (
        get_service as _lt_svc,
        LogicalTableResolutionError as _LtErr,
    )
    sides = []
    for _sql, _cid in ((primary_sql, primary_conn_id), (secondary_sql, sec_conn_id)):
        if "__logical__:" in _sql.lower():
            try:
                _sql = _lt_svc().rewrite_sql(_sql, _cid)
            except _LtErr as _lt_exc:
                raise HTTPException(400, str(_lt_exc))
        sides.append(_sql)
    primary_sql, secondary_sql = sides

    # THE combine vocabulary: the saved query's ``combine_mode`` +
    # ``join_config {how, left_on, right_on}`` -> the federation view's
    # ``combine_mode`` / ``join_how`` / ``join_on``.  A combine that cannot
    # run is refused HERE, before either side runs.
    from core.executors.cross_source_combine import (
        CrossSourceRefusal as _XRefusal, combine_spec as _x_spec)
    try:
        spec = _x_spec(query_config.get("combine_mode"),
                       query_config.get("join_config") or {},
                       default_mode="union")
    except _XRefusal as _x_ref:
        raise HTTPException(
            400, f"Published view '{slug}' cannot combine its two sides: {_x_ref}")
    join_on = [{"left": l, "right": r} for l, r in zip(spec.left_on, spec.right_on)]

    return {
        "id": None,
        "name": f"published view {slug}",
        "primary_conn_id": primary_conn_id,
        "primary_query": {"raw_sql": primary_sql, "files": []},
        "secondary_conn_id": sec_conn_id,
        "secondary_query": {"raw_sql": secondary_sql, "files": []},
        "combine_mode": spec.mode,
        "join_on": join_on,
        "join_how": spec.how,
        "output_columns": [],
    }


async def _execute_view_cross_source(
    pv: dict,
    query_config: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    consumer_user: Optional[Dict[str, Any]] = None,
) -> dict:
    """A cross-source ``sql_query`` / ``sql_file`` view, on THE federation road.

    ``query_config`` is the snapshot with ``{{params}}`` substituted on both
    statements and on the static filter values.  The static rows
    (``query_config.filters``) and the Dynamic columns + declared types
    (``_where_clauses_mapping``) are read by ``_execute_federation_shape``
    from the view it is handed, so that copy carries the substituted config.
    """
    fv = await _federation_shape_of_cross_source_view(pv, query_config)
    pv_for_run = _copy_view(pv)
    pv_for_run["query_config"] = query_config
    logger.info(
        "[pv-xs] view=%s source=%s on the federation road: primary conn=%s, "
        "secondary conn=%s, combine=%s%s",
        pv.get("slug"), pv.get("source_type"), fv["primary_conn_id"],
        fv["secondary_conn_id"], fv["combine_mode"],
        (f" {fv['join_how']} on {fv['join_on']}" if fv["combine_mode"] == "join" else ""),
    )
    return await _execute_federation_shape(
        pv_for_run, fv, filters, columns, sort_column, sort_dir, limit, offset,
        consumer_user=consumer_user,
        source_type=str(pv.get("source_type") or "sql_query"),
        credential_user=await _cross_source_credential_user(pv, fv, consumer_user),
    )


async def _cross_source_credential_user(pv: dict, fv: dict, consumer_user) -> str:
    """The CREDENTIAL identity a moved cross-source view runs with -- the
    one its ``credential_mode`` names, as the saved-query road's resolver did
    (``_pv_resolve_s3``): consumer -> the caller; publisher -> the publisher
    frozen at publish time; shared -> no user, which resolves to the
    connection's SHARED account only when BOTH connections are shared --
    otherwise refused (never a silent fall-back to someone else's
    credentials).  Security review 2026-10-24: the federation road always
    used the publisher, so a consumer-mode view would have escalated."""
    from core.credential_resolver import extract_username_from_consumer
    mode = str(pv.get("credential_mode") or "consumer").lower()
    if mode == "publisher":
        return str(pv.get("publisher_username") or pv.get("created_by") or "")
    if mode == "shared":
        for cid in (fv.get("primary_conn_id"), fv.get("secondary_conn_id")):
            rec = await adb(_db_manager.get_connection_raw, int(cid)) if cid else None
            if not (rec or {}).get("is_shared"):
                raise HTTPException(
                    400,
                    f"Published view '{pv.get('slug')}' uses the shared credential mode, but "
                    f"connection {cid} is not shared. Share both connections, or publish the "
                    f"view with the publisher's or the consumer's credentials.")
        return ""
    return extract_username_from_consumer(consumer_user)


async def _execute_view_saved_query(
    pv: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    params: Optional[Dict[str, Any]] = None,
    snapshot_id: Optional[int] = None,
    as_of_timestamp_ms: Optional[int] = None,
    consumer_user: Optional[Dict[str, Any]] = None,
    stream: bool = False,
) -> dict:
    """Execute the published view's frozen query_config (saved_query source).

    Hotspot F refactor: this is the body that used to live inline in
    _execute_view's default branch.  Extracted as a peer to
    _execute_view_business_report / _execute_view_federation so the dispatcher
    is a clean 3-branch route and each handler can be reasoned about in
    isolation.  Behaviour is preserved exactly — no caller signature change.
    """

    logger.info(
        "[pv-execute] entry view=%s source=%s filters=%d limit=%d offset=%d "
        "snapshot=%s as_of=%s consumer=%s",
        pv.get("slug"), pv.get("source_type"),
        len(filters or []), limit, offset,
        snapshot_id, as_of_timestamp_ms,
        (consumer_user or {}).get("username"),
    )

    # FB-38: a saved_query view travels only when it reads an ICEBERG table;
    # on parquet / local / SQL-connector sources the snapshot was stashed
    # into query_config and consumed by nothing.
    await _refuse_unless_time_travel_supported(pv, snapshot_id, as_of_timestamp_ms)

    query_config = dict(pv["query_config"])

    # Substitute {{param_name}} placeholders before building QueryConfigModel — Phase 80
    # Phase 133-C: pass param_defs for type validation before substitution
    if params and (_pv_cfg and _pv_cfg.param_substitution_enabled):
        query_config = _substitute_params(query_config, params,
                                          param_defs=pv.get("param_definitions") or [])

    # 2026-10-24 -- a CROSS-SOURCE sql_query / sql_file view takes THE
    # federation road (see ``_federation_shape_of_cross_source_view``): the
    # in-process cross-connection executor below is no longer entered for it.
    # The single-source views and every saved_query view are untouched.
    if _is_cross_source_sql_view(pv, query_config):
        return await _execute_view_cross_source(
            pv, query_config, filters, columns, sort_column, sort_dir,
            limit, offset, consumer_user=consumer_user)

    # Inject runtime filters from API consumer.
    # Keep operators in short form (eq, ne, gt, gte, lt, lte, in, not_in,
    # contains, between) — that is what FilterModel.operator accepts and what
    # build_query_sql / parquet_engine_v2 expects. The old _OP_MAP that
    # converted these to "equals"/"greater_than"/etc. caused Pydantic
    # ValidationError on every filtered request (BF-73).
    #
    # Phase 132.36 — REPLACE semantics for "dynamic" columns.
    # Before: a saved query with ``region='APAC'`` + consumer ``?region=EMEA``
    # would APPEND, producing two contradictory WHERE clauses that empty the
    # result set.  Now: when a consumer-supplied filter targets a column
    # that already has a static filter in the frozen snapshot, the static
    # one is DROPPED and replaced by the consumer's value.  The publisher's
    # static filter acts as the DEFAULT — overridden when the consumer
    # provides a value.  Columns the consumer doesn't supply keep their
    # static value untouched.
    #
    # Phase 132.36 hotfix-1 (deep-dive):
    #   * Case-insensitive match  → snapshot ``"Region"`` and consumer
    #     ``?region=EMEA`` collide as expected, no spurious AND-ed pair.
    #   * Qualified column strip  → snapshot ``"trades.region"`` matches
    #     consumer ``?region=...`` after stripping the table prefix.
    #   * Pydantic/dict mixed shapes already handled.
    #
    # Phase 132.37 (parity round): the inline REPLACE-merge originally
    # lived here; we extracted it to ``helpers.merge_static_and_consumer_filters``
    # so the BR and federation handlers can use the SAME logic and the
    # WHERE-mapping contract is identical across every source type.
    if filters or (query_config.get("filters") or []):
        from api.published_views.helpers import merge_static_and_consumer_filters
        # F3 static-lock (see BR path): only mode='dynamic' columns overridable;
        # None → legacy replace-all for views without a mapping.
        _pv_map = query_config.get("_where_clauses_mapping") or []
        _pv_dyn = ({(r.get("column") or "").strip() for r in _pv_map
                    if isinstance(r, dict)
                    and (r.get("mode") or "static").lower() == "dynamic"
                    and (r.get("column") or "").strip()}
                   if _pv_map else None)
        query_config["filters"] = _merge_filters_or_refuse(
            static_filters=query_config.get("filters") or [],
            consumer_filters=filters,
            dynamic_columns=_pv_dyn,
        )

    # ── Phase 132.37 — apply the merged filter list to raw_sql ───────────
    # Structured query_config sources (BQB/CQB without raw_sql) have their
    # filters honoured by parquet_engine_v2._build_where at WHERE-build
    # time.  Raw-SQL sources (sql_file, custom_sql, published .sql files)
    # would otherwise IGNORE the filter list entirely — the engine runs
    # the SQL text as-is.  Generic fix: wrap the SQL as a derived table
    # and emit the merged filters as an outer WHERE clause.  Both Static
    # rows (from the publisher's mapping, frozen into the snapshot at
    # publish time by management.publish_view) and Dynamic rows
    # (consumer overrides merged just above by REPLACE-semantics) flow
    # through this single wrap, with no duplication of filter logic.
    #
    # Applied to all three raw-SQL fields independently:
    #   * raw_sql            — primary side
    #   * custom_sql         — alternate field name used by some sources
    #   * secondary_raw_sql  — secondary side of a cross-source PV
    #
    # The wrapper is a no-op when the filter list is empty OR when no
    # filter row produces a usable condition (unknown operator, missing
    # column, …) so legacy PVs continue to behave identically.
    _merged_filters = query_config.get("filters") or []
    if _merged_filters:
        from core.sql_filter_wrapper import (
            FilterWrapError as _FilterWrapError,
            wrap_sql_with_filters as _wrap_sql,
            dialect_for_connection_type as _dial,
        )
        # Phase 134-P — resolve every date-token form in filter values
        # BEFORE the wrap so the publisher's Dynamic default (``@TODAY``
        # / ``${today}`` / bare ``today``) becomes a concrete ISO date
        # string instead of being baked literally into raw_sql.  Without
        # this, a BR with default=``@TODAY`` produces
        # ``WHERE business_close_date = '@TODAY'`` which SQL refuses.
        try:
            from core.date_resolver import CalendarTokenRefused, resolve_filter_tokens
            _merged_filters = resolve_filter_tokens(_merged_filters) or []
            query_config["filters"] = _merged_filters
        except CalendarTokenRefused:
            raise          # a filter that cannot be rendered refuses (400)
        except Exception as _tok_exc:
            logger.warning(
                "[pv-execute] date-token resolution failed for view=%s: %s "
                "— proceeding with un-resolved tokens (raw_sql may fail)",
                pv.get("slug"), _tok_exc,
            )

        # Phase 134-M (audit follow-up) — Dynamic columns identified from
        # the publisher's WHERE-clause mapping.  Their existing predicates
        # in raw_sql / custom_sql / secondary_raw_sql get REMOVED before
        # the merged predicate is AND-ed back on, so a hardcoded
        # ``WHERE business_close_date='2025-09-30'`` no longer fights the
        # consumer's ``?business_close_date=2025-09-29`` override.  Static
        # rows are NOT in this set — their existing predicate (if any)
        # stays and the merged value AND-s on top (the publisher meant
        # both to apply).
        _mapping = query_config.get("_where_clauses_mapping") or []
        _dyn_columns = {
            (row.get("column") or "").strip()
            for row in _mapping
            if isinstance(row, dict)
            and (row.get("mode") or "static").lower() == "dynamic"
            and (row.get("column") or "").strip()
        }
        # Resolve the PV's runtime dialect so the rewrite preserves
        # dialect-specific syntax (Oracle hints, Snowflake keywords,
        # Trino lambda).  Best-effort — unknown / missing connection
        # falls back to duckdb inside the helper.
        _pv_dialect = "duckdb"
        try:
            # 2026-08-09: this used to read `connection_id`, which is a
            # LOCAL of this function assigned ~140 lines BELOW (see the
            # "Ensure connection_id is embedded" block) — so whenever
            # pv["connection_id"] was empty the `or` fell through to an
            # unbound local, UnboundLocalError, and the except below
            # silently pinned the dialect to "duckdb".  Inline the same
            # precedence that block uses, so the dialect describes the
            # connection the PV actually EXECUTES against (the Phase 133-J
            # execution_connection_id override wins there too).
            _cid = (
                pv.get("execution_connection_id")
                or pv.get("connection_id")
                or query_config.get("connection_id")
            )
            if _cid and _db_manager is not None:
                # BF-597: async DB.
                _crec = await adb(_db_manager.get_connection_raw, _cid)
                if _crec:
                    _pv_dialect = _dial(_crec.get("connection_type"))
        except Exception as _be_exc:
            note_best_effort("_dial(_crec.get('connection_type'))", _be_exc,
                             logger=logger)
        # Phase 133-G fix — cross-source PVs run secondary_raw_sql on a
        # DIFFERENT connection than the primary, so the wrap helper has
        # to use the secondary's dialect when wrapping that side.  Else
        # an Oracle secondary gets Trino-rendered (hint quoting fails,
        # case folding wrong).  Look up the secondary's dialect once.
        _sec_dialect = _pv_dialect
        try:
            _sec_cid = query_config.get("secondary_connection_id")
            if _sec_cid and _db_manager is not None:
                # BF-597: async DB.
                _sec_crec = await adb(_db_manager.get_connection_raw, _sec_cid)
                if _sec_crec:
                    _sec_dialect = _dial(_sec_crec.get("connection_type"))
        except Exception as _be_exc:
            note_best_effort("_dial(_sec_crec.get('connection_type'))", _be_exc,
                             logger=logger)
        _dialect_by_key = {
            "raw_sql":           _pv_dialect,
            "custom_sql":        _pv_dialect,
            "secondary_raw_sql": _sec_dialect,
        }
        # 2026-08-13 -- column -> semantic type, so a date column renders a
        # TYPED literal (``DATE '2025-09-30'``).  A PV pointed at
        # Trino/Starburst, Snowflake or Oracle otherwise gets
        # ``date_col = '2025-09-30'`` and the engine refuses in strict mode
        # ("Cannot apply operator: date = varchar(27)"); DuckDB coerces, so
        # the same PV works on parquet and fails on a SQL connector.
        # Publisher-declared type wins; absent, the literal is quoted
        # exactly as before.
        _col_types = {
            (row.get("column") or "").strip(): str(row.get("data_type") or "")
            for row in _mapping
            if isinstance(row, dict) and (row.get("column") or "").strip()
            and str(row.get("data_type") or "")
        }
        # 2026-10-05 -- ...and when nobody DECLARED a type (a view published
        # with ``allowed_filters``, the common case), the COLUMN's type comes
        # from the view's recorded schema, else the source's own description
        # of the statement (``core.raw_sql_filter_types``).  Before this every
        # date / timestamp filter on a SQL-sourced view on Trino was a 500
        # ("Cannot apply operator: date = varchar(10)").  Unknown stays
        # unknown: the literal is quoted exactly as before.
        from core.raw_sql_filter_types import (
            filter_column_types as _filter_column_types,
            recorded_view_types as _recorded_view_types,
        )
        _pv_recorded = await adb(_recorded_view_types, _db_manager, pv.get("id"))
        _type_cid_by_key = {
            "raw_sql": (pv.get("execution_connection_id")
                        or pv.get("connection_id")
                        or query_config.get("connection_id")),
            "custom_sql": (pv.get("execution_connection_id")
                           or pv.get("connection_id")
                           or query_config.get("connection_id")),
            "secondary_raw_sql": query_config.get("secondary_connection_id"),
        }
        for _sql_key in ("raw_sql", "custom_sql", "secondary_raw_sql"):
            _orig = query_config.get(_sql_key)
            if isinstance(_orig, str) and _orig.strip():
                _key_dialect = _dialect_by_key.get(_sql_key, _pv_dialect)
                _key_types = await _filter_column_types(
                    _orig, _merged_filters,
                    connection_id=_type_cid_by_key.get(_sql_key),
                    db=_db_manager,
                    # the recorded schema describes what the VIEW serves --
                    # the primary statement's output, not one side's
                    recorded=(_pv_recorded if _sql_key != "secondary_raw_sql"
                              else None),
                    declared=_col_types,
                )
                try:
                    _wrapped = _wrap_sql(
                        _orig, _merged_filters,
                        dialect=_key_dialect,
                        dynamic_columns=_dyn_columns or None,  # 134-M
                        column_types=_key_types or None,
                    )
                except _FilterWrapError as _fw_exc:
                    # A filter that cannot be rendered -- a value that is not
                    # of its column's type, an empty IN list -- is the
                    # caller's to fix: 400 with the sentence.  It was an
                    # uncaught ValueError, i.e. "Query execution failed".
                    raise HTTPException(400, str(_fw_exc)) from _fw_exc
                if _wrapped is not None and _wrapped != _orig:
                    query_config[_sql_key] = _wrapped
                    # Audit follow-up — log the FULL wrapped SQL so the
                    # operator can see exactly what's hitting S3.  Was
                    # truncated to 1000/1500 chars before, which is
                    # shorter than a typical SELECT *-FROM-(... WHERE …)
                    # wrap on a real PV.  4000 chars covers ~95% of
                    # production PV queries; the remaining are CTEs
                    # large enough to log on a separate INFO line.
                    logger.info(
                        "[pv-execute] view=%s key=%s dialect=%s "
                        "filters=%d dynamic_cols=%s sql=%s",
                        pv.get("slug"), _sql_key, _key_dialect,
                        len(_merged_filters),
                        sorted(_dyn_columns) if _dyn_columns else [],
                        _wrapped[:4000],
                    )
                    # Phase 134-M — also log the ORIGINAL SQL alongside
                    # so the operator can diff the publisher's intent
                    # vs what actually ran.  Helps catch silent rewrites.
                    logger.info(
                        "[pv-execute-original] view=%s key=%s sql=%s",
                        pv.get("slug"), _sql_key, _orig[:4000],
                    )

    # ── 2026-08 redesign — materialize the DATASET, not the page ─────────
    # The old code set ``query_config["limit"] = limit + offset``: the engine
    # materialized a file truncated at the requested page boundary, the
    # truncated file's footer count was then reported as ``total_rows``
    # (page 1 of a million-row view said ``total_rows=100, has_more=false``),
    # the consumer's ?sort ordered only that arbitrary prefix, and every page
    # was a SEPARATE nondeterministically-ordered execution that could
    # overlap or miss rows.  That design cannot be patched correct.
    #
    # Now: one execution materializes the dataset up to ``dataset_row_cap``
    # (+1 so overflow is DETECTABLE), the result parquet is the stable
    # artifact every page / sort / projection reads from (and the entry the
    # response cache stores, keyed on dataset identity), and the manifest
    # records whether the cap was hit (TotalMode.AT_LEAST) so the envelope
    # never lies about the total.  KEYSET/CURSOR was assessed and rejected:
    # PV sources execute frozen arbitrary SQL across heterogeneous engines —
    # there is no general sort key to push a cursor into, and a bolted-on
    # cursor silently drops/duplicates rows on non-unique keys.  A stable
    # materialized scan is the design that is CORRECT for every source type.
    # NOTE on cost: page 1 now materializes the dataset instead of a prefix;
    # on the dominant S3 path LIMIT never reduced scan cost anyway (pruning
    # does), and pages 2..N become cache reads instead of re-executions.
    # 2026-09-15 — ...unless the PAGED route said what it needs.  Materialising
    # 1,000,001 rows to answer ``?limit=10`` is the "downloading first, then
    # serving" the operator sees; ``page_scan_bound`` bounds the engine to
    # offset+limit+1 (the page, plus the row that decides has_more) when a
    # page intent is set, and to the cap+1 sentinel otherwise (sort, an
    # unlimited page, bulk, warm-up, business reports).  A bounded run that
    # hits its bound is disclosed below as total_mode=at_least with the
    # MEASURED prefix length -- never as an exact total.
    from api.published_views.envelope import (
        current_page_intent as _cur_intent,
        dataset_row_cap as _ds_cap_fn,
        page_scan_bound as _page_scan_bound,
    )
    _ds_cap = _ds_cap_fn()
    _scan_bound = _page_scan_bound(limit=limit, offset=offset,
                                   sort_column=sort_column, cap=_ds_cap)
    if _scan_bound is not None:
        query_config["limit"] = _scan_bound     # page-bounded scan
    elif _ds_cap > 0:
        query_config["limit"] = _ds_cap + 1     # +1 = overflow sentinel
    else:
        query_config["limit"] = None            # unbounded materialization
    # The engine's own result cache must see the same intent the route
    # answered with (``?cache=bypass|refresh``, a ``live`` view): "auto"
    # for every caller that did not say.
    _engine_cache_strategy = _cur_intent().engine_cache

    # ── Build QueryConfigModel ────────────────────────────────────────────
    from api.models.query_models import QueryConfigModel

    # Phase 133-I — defensive shape for raw-SQL sources.  ``QueryConfigModel.files``
    # is a REQUIRED ``List[str]`` but PVs published from sql_file / custom_sql
    # store no ``files`` field (the SQL is in ``raw_sql``).  Without this, every
    # /api/v1/views/<slug>/data call against a sql_file-backed PV returns
    # ``View configuration error: files Field required`` — exactly the error
    # the user hit at 4 AM today on query12345-sql.  Inject ``files=[]`` so
    # the model accepts the snapshot; the downstream engine ignores ``files``
    # when ``raw_sql`` is present (verified in build_query_sql).
    _src_type_for_files = query_config.get("source_type") or pv.get("source_type") or "saved_query"
    if "files" not in query_config:
        if _src_type_for_files in ("sql_file", "custom_sql") or query_config.get("raw_sql"):
            query_config["files"] = []

    try:
        qc_model = QueryConfigModel(**query_config)
    except Exception as exc:
        # BF-PV-MASKED-ERROR (2026-05-20): the old behaviour was to log the
        # ValidationError and return a generic "View configuration error —
        # contact administrator" — which meant consumers / admins had no
        # signal at all about WHY the request failed.  Common real causes
        # surfaced once this is unmasked:
        #   * {{param}} placeholder remained unsubstituted because the
        #     consumer passed it under a different name or one that
        #     collides with a reserved name like ``limit``/``code``.
        #   * Filter operator or value-shape doesn't match FilterModel
        #     (e.g. ``in`` expects a list, not a scalar string).
        #   * connection_id / source_type drift after a model migration.
        # We surface the sanitized detail so the caller can fix their
        # request without needing to ask an admin to grep the logs.
        from core.error_sanitizer import sanitize_error
        logger.error("Invalid frozen query_config for view %s: %s",
                       pv["slug"], exc)
        raise HTTPException(
            500,
            f"View configuration error: {sanitize_error(str(exc))}",
        )

    # Ensure connection_id is embedded (critical for cache key isolation).
    # Phase 133-J — execution_connection_id is the publisher-time override
    # picked in the publish dialog ("Run consumer requests against connection
    # X" instead of inheriting the saved query's connection).  It wins over
    # the snapshot when set; otherwise legacy resolution applies.  We force
    # the override onto qc_model (not just-when-empty) so the downstream
    # engine + cache key both pick up the redirect.
    _exec_conn_override = pv.get("execution_connection_id")
    connection_id = (
        _exec_conn_override
        or pv.get("connection_id")
        or query_config.get("connection_id")
    )
    if _exec_conn_override:
        qc_model = qc_model.model_copy(update={"connection_id": _exec_conn_override})
    elif connection_id and not qc_model.connection_id:
        qc_model = qc_model.model_copy(update={"connection_id": connection_id})

    # Resolve dynamic date expressions in filters
    try:
        from core.date_resolver import CalendarTokenRefused, resolve_filter_dates
        if qc_model.filters:
            resolved = resolve_filter_dates(qc_model.filters)
            qc_model = qc_model.model_copy(update={"filters": resolved})
    except CalendarTokenRefused:
        raise          # a filter that cannot be rendered refuses (400)
    except Exception as e:
        logger.debug("Failed to resolve filter dates in business report: %s", e)

    # ── Resolve execution engine ──────────────────────────────────────────
    from api.execute_api import (
        execute_query_background,
        _engine as _default_engine,
        _paths as _exec_paths,
        _qe_cfg as _exec_qe_cfg,
    )
    from core.parquet_engine_v2 import ParquetQueryEngine
    from core.s3_storage import build_s3_config

    active_engine = _default_engine
    # BF-PV-CONNECTOR-PARITY: SQL connector flag — when True, the
    # execution path below dispatches to execute_sql_connector_background
    # instead of execute_query_background.  Was missing entirely; published
    # views with snowflake/trino/starburst/databricks/oracle/athena
    # connections silently fell through to ParquetQueryEngine and failed.
    _sql_connector_instance = None
    _sql_connector_type = None
    _sql_connector_cfg = None

    # Phase 133-J — single resolver that honors pv.credential_mode for
    # both primary and secondary S3 sides.  Closes three gaps in one:
    #   (1) is_shared is now propagated to the resolver (was missing — BQB
    #       at execute_api.py:7748 has done this since BF-286 but the PV
    #       path didn't, so shared-account fallback never engaged).
    #   (2) Per-mode user selection:
    #         consumer  → calling user (legacy behaviour)
    #         publisher → publisher's vault, frozen at publish time
    #         shared    → forces is_shared=true → CredentialManager goes
    #                     to system_account, no vault lookup needed
    #   (3) PersonalPasswordRequired is now caught and re-raised as a
    #       structured 401 (mirrors execute_api.py:7794-7801) so the
    #       frontend BF-285 modal can still trigger when a publisher
    #       chose consumer-mode for a private connection.
    _pv_credential_mode = (pv.get("credential_mode") or "consumer").lower()
    _pv_publisher_user  = pv.get("publisher_username") or ""

    def _pv_resolve_s3(cfg_in: dict, conn_record_in: dict, side: str) -> dict:
        from core.credential_manager import PersonalPasswordRequired
        from core.credential_resolver import (
            resolve_s3_for_consumer as _resolve_s3,
            extract_username_from_consumer,
        )
        from core.config import aws_portal as _ap_cfg
        cfg_out = dict(cfg_in)
        cfg_out["is_shared"] = bool(conn_record_in.get("is_shared", False))
        if _pv_credential_mode == "shared":
            cfg_out["is_shared"] = True
            resolve_user: object = ""
        elif _pv_credential_mode == "publisher":
            resolve_user = _pv_publisher_user
        else:
            resolve_user = consumer_user
        try:
            return _resolve_s3(
                cfg_out, resolve_user,
                min_lifetime_seconds=_ap_cfg.preflight_min_lifetime_seconds,
            )
        except PersonalPasswordRequired as _ppr:
            _eff_user = (
                _pv_publisher_user if _pv_credential_mode == "publisher"
                else extract_username_from_consumer(consumer_user)
            )
            raise HTTPException(status_code=401, detail={
                "type":    "portal_password_required",
                "message": str(_ppr),
                "username": _eff_user or "",
                "connection_id": conn_record_in.get("id"),
                "credential_mode": _pv_credential_mode,
                "side": side,
            })

    if connection_id:
        # BF-597: async DB.
        conn_record = await adb(_db_manager.get_connection_raw, connection_id)
        if not conn_record:
            raise HTTPException(500, "View connection not available — contact administrator")
        conn_type = conn_record.get("connection_type", "")
        cfg = conn_record.get("config", {})

        if conn_type == "local":
            active_engine = ParquetQueryEngine(
                base_path=str(cfg.get("base_path", "/usr/local/querystudioapi/nfs/data/parquet")),
                chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
            )
        elif conn_type == "s3":
            # Phase 133-J — resolution + structured 401 + credential_mode
            # routing all live in _pv_resolve_s3 above.  Long-running PVs
            # still get the BF-461 preflight refresh (aws_portal config).
            s3_cfg = _pv_resolve_s3(cfg, conn_record, side="primary")
            active_engine = ParquetQueryEngine(
                base_path=str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet",
                chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
                s3_config=build_s3_config(s3_cfg),
            )
            # Support registered/virtual tables
            active_engine._registered_tables = cfg.get("registered_tables", [])
            active_engine._s3_conn_config = s3_cfg  # resolved creds, not original portal config
            active_engine._s3_bucket = cfg.get("bucket_name", "")
            active_engine._s3_conn_id = connection_id
        else:
            # BF-PV-CONNECTOR-PARITY: SQL connector path
            # (snowflake, trino, starburst, databricks, oracle, athena, ...).
            try:
                from core.connectors import SQL_CONNECTOR_TYPES, get_connector
                if conn_type in SQL_CONNECTOR_TYPES:
                    _sql_connector_instance = get_connector(
                        conn_type, cfg, connection_id, conn_record.get("name", "")
                    )
                    _sql_connector_type = conn_type
                    _sql_connector_cfg = cfg
                else:
                    raise HTTPException(
                        500,
                        f"Published view connection_type {conn_type!r} not supported. "
                        f"Supported: s3, local, {', '.join(sorted(SQL_CONNECTOR_TYPES))}",
                    )
            except HTTPException:
                raise
            except Exception as _conn_exc:
                # FB-41: a missing driver (501) or an unreachable source
                # (503 + Retry-After) answers as itself; the published
                # lanes keep a refusal generic on purpose (CWE-209 for an
                # external consumer), so only the transient arm is taken.
                _raise_if_self_clearing(_conn_exc)
                logger.error("Published view %s: failed to build %s connector: %s",
                              pv["slug"], conn_type, _conn_exc, exc_info=True)
                raise HTTPException(
                    500, f"Failed to initialise {conn_type} connector — see logs",
                )

    # ── Cross-connection secondary engine — Phase 80 ─────────────────────────
    secondary_engine = None
    secondary_qc_model = None
    sec_conn_id = query_config.get("secondary_connection_id")
    sec_query_config_dict = query_config.get("secondary_query_config")
    combine_mode = query_config.get("combine_mode", "union")
    join_config_dict = query_config.get("join_config")

    # Phase 124-C: Cross-connection sql_file — secondary has raw SQL, not query_config
    sec_raw_sql = query_config.get("secondary_raw_sql")
    # 2026-10-24 (rig, the owner's on-prem side): a SQL-CONNECTOR secondary
    # (Starburst / Trino / Snowflake / Oracle ...) -- run as a connector side
    # below, its statement secured in ITS dialect.
    _sec_connector_record = None

    # Phase 146-B -- rewrite ``__logical__:`` refs in secondary_raw_sql
    # against the SECONDARY connection so cross-source PVs pick the
    # right physical_ref on each side.  Fail-CLOSED on missing binding
    # matching the primary-side behaviour a few lines below.
    if sec_raw_sql and sec_conn_id and "__logical__:" in sec_raw_sql.lower():
        from core.logical_table_service import (
            get_service as _lt_svc_sec,
            LogicalTableResolutionError as _LtErrSec,
        )
        try:
            sec_raw_sql = _lt_svc_sec().rewrite_sql(sec_raw_sql, sec_conn_id)
        except _LtErrSec as _lt_exc_sec:
            raise HTTPException(400, str(_lt_exc_sec))
    if sec_conn_id and not sec_query_config_dict and sec_raw_sql:
        sec_query_config_dict = {
            "files": [],
            "connection_id": sec_conn_id,
        }
        # raw_sql flows via secondary_raw_sql param, not QueryConfigModel
        # combine_mode and join_config already extracted above from query_config

    if sec_conn_id and sec_query_config_dict:
        # BF-597: async DB.
        sec_conn_record = await adb(_db_manager.get_connection_raw, sec_conn_id)
        if sec_conn_record:
            sec_type = sec_conn_record.get("connection_type", "")
            sec_cfg = sec_conn_record.get("config", {})
            # Phase 133-J — secondary side uses the same mode-aware resolver.
            # is_shared propagation, publisher/shared mode, and structured 401
            # all apply uniformly to cross-source PVs.
            sec_cfg_inj = _pv_resolve_s3(sec_cfg, sec_conn_record, side="secondary")
            if sec_type == "local":
                secondary_engine = ParquetQueryEngine(
                    base_path=str(sec_cfg.get("base_path", "/usr/local/querystudioapi/nfs/data/parquet")),
                    chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
                )
            elif sec_type == "s3":
                secondary_engine = ParquetQueryEngine(
                    base_path=str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet",
                    chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
                    s3_config=build_s3_config(sec_cfg_inj),
                )
                secondary_engine._registered_tables = sec_cfg.get("registered_tables", [])
                secondary_engine._s3_conn_config = sec_cfg_inj
                secondary_engine._s3_bucket = sec_cfg.get("bucket_name", "")
                secondary_engine._s3_conn_id = sec_conn_id
            else:
                from core.connectors import SQL_CONNECTOR_TYPES as _SQLC
                if sec_type in _SQLC and sec_raw_sql:
                    # the engine is built once its statement is SECURED (below)
                    _sec_connector_record = sec_conn_record
            try:
                # Phase 133-I — same files-default defense as primary side.
                if "files" not in sec_query_config_dict and (
                    sec_query_config_dict.get("raw_sql")
                    or sec_query_config_dict.get("source_type") in ("sql_file", "custom_sql")
                ):
                    sec_query_config_dict["files"] = []
                secondary_qc_model = QueryConfigModel(**sec_query_config_dict)
                if sec_conn_id and not secondary_qc_model.connection_id:
                    secondary_qc_model = secondary_qc_model.model_copy(update={"connection_id": sec_conn_id})
            except Exception as exc:
                # 2026-08-05 BR cross-source audit: this used to fall back
                # to PRIMARY ONLY with a log line nobody reads — half the
                # data served as a success.  Refuse instead (UNKNOWN =
                # UNSAFE; same posture as feed CROSS_CONFIG_PARTIAL).
                logger.error("Invalid secondary_query_config for view %s: %s",
                             pv["slug"], exc)
                raise HTTPException(
                    400,
                    f"Published view '{pv['slug']}' is cross-source but its "
                    f"secondary_query_config is invalid ({exc}). Running it "
                    f"would silently emit only the primary side's rows. "
                    f"Fix: re-publish the view with a valid secondary side, "
                    f"or remove the secondary configuration.")
        else:
            # 2026-08-05 BR cross-source audit: same silent primary-only
            # degrade as above — a deleted secondary connection halved the
            # result set without an error.  Refuse with the fix named.
            raise HTTPException(
                400,
                f"Published view '{pv['slug']}' is cross-source but its "
                f"secondary connection {sec_conn_id} does not exist "
                f"(deleted or never created). Running it would silently "
                f"emit only the primary side's rows. Fix: point the view "
                f"at an existing secondary connection, or remove the "
                f"secondary configuration.")

    # ── Execution id (the ROW is written after admission, below) ─────────
    # 2026-10-07 (F11): the row used to be INSERTed here, before the
    # row-security rewrite and the admission gate, and nothing finalised it
    # when the request left by one of those doors -- every 503 at the cap,
    # every queue timeout, every RLS 403 left a ``pending`` row forever
    # (150 on the rig).  See ``_settle_pv_execution``.
    execution_id = f"pv_{uuid.uuid4().hex[:12]}"

    # Phase 131 deep-dive #13 (hardening): register with api_key_lifecycle
    # using the REAL execution_id (the one worker_pool.submit will key on
    # inside execute_query_background).  Admin Revoke or sweep can now
    # fire this execution's cancel_event correctly.  Wrapped in try so
    # an unrelated registry failure cannot break the request path.
    _akl_key_id_pv = None
    try:
        _cu_pv = pv.get("_consumer_user_ctx") or {}
        _akl_key_id_pv = _cu_pv.get("api_key_id")
        if _akl_key_id_pv:
            from core.api_key_lifecycle import register_execution as _akl_reg
            _akl_reg(execution_id, int(_akl_key_id_pv))
    except Exception:
        _akl_key_id_pv = None

    # ── Execute via the main pipeline (reuses cross-conn, DuckDB, etc.) ──
    # Phase 98-A: route external API executions to the dedicated PUBLISHED_API
    # worker pool so external consumers cannot starve internal QueryBuilder users.
    from core.worker_pool import WorkType as _WorkType
    _pv_work_type = _WorkType.PUBLISHED_API

    # Phase 122B: Extract raw_sql from query_config for CTE support
    _pv_raw_sql = query_config.get("raw_sql") or query_config.get("custom_sql") or None
    # 2026-10-07 -- a cross-source query saved by the query builder before
    # that date holds its LABELLED display (primary AND secondary) in raw_sql;
    # run only the primary statement on the primary connection.
    if _pv_raw_sql and query_config.get("secondary_connection_id"):
        from core.cross_source_display import primary_statement_of as _pso
        _pv_raw_sql = _pso(_pv_raw_sql)

    # Phase 146-B -- resolve ``__logical__:name`` references against
    # the ACTIVE connection (may differ from pv['connection_id'] when
    # the consumer supplied ?engine=... under Phase 146-A).  Fail-CLOSED
    # if a binding is missing at execute time -- surfaces a clean 400
    # to the consumer instead of a downstream SQL syntax failure.
    if _pv_raw_sql and "__logical__:" in _pv_raw_sql.lower():
        from core.logical_table_service import (
            get_service as _lt_svc,
            LogicalTableResolutionError as _LtErr,
        )
        try:
            _pv_raw_sql = _lt_svc().rewrite_sql(_pv_raw_sql, connection_id)
        except _LtErr as _lt_exc:
            raise HTTPException(400, str(_lt_exc))

    # Phase 141: Apply row-security rewrite to PV raw_sql.  The "user" here is
    # the API consumer (API key, AD-Basic, or shared-token holder) threaded
    # down via consumer_user → pv["_consumer_user_ctx"].  When that isn't
    # available (warmup, internal callers) we fall back to a synthetic
    # principal scoped to the PV slug so admin-defined "PV viewer" policies
    # still apply.  Wrapped in asyncio.to_thread because the rewriter does
    # DB lookups and we are inside an async handler — calling it inline
    # would block the FastAPI event loop on every PV request.
    #
    # Phase 131 deep-dive #13 (round 4): structured PVs (no raw_sql) used to
    # bypass RLS — execute_query_background built SQL internally and never
    # saw secure_sql.  We now pass user_ctx + connection_id down so the
    # engine applies RLS at the SQL-build site.
    _pv_user_ctx = (pv.get("_consumer_user_ctx")
                     or {"username": f"pv:{pv['slug']}",
                          "role":     "pv_consumer",
                          "groups":   pv.get("allowed_ad_groups") or [],
                          "is_admin": False})
    if _pv_raw_sql:
        try:
            from core.row_security import secure_sql as _rs_secure
            _pv_raw_sql = await asyncio.to_thread(
                _rs_secure,
                _pv_raw_sql,
                dialect="duckdb",
                user_ctx=_pv_user_ctx,
                connection_id=connection_id,
                request_id=execution_id,
            )
        except HTTPException:
            raise
        except Exception as _rs_exc:
            logger.error("Row-security rewrite failed for PV %s: %s",
                          pv.get("slug"), _rs_exc)
            raise HTTPException(
                status_code=403,
                detail=f"Row-security policy enforcement failed: {_rs_exc}",
            )

    # 2026-08-05 BR cross-source audit — RLS on the SECONDARY raw-SQL leg.
    # Policies are scoped per connection (find_applicable_policies matches
    # connection_id OR NULL), and execute_cross_query_background only
    # rewrites a leg whose raw SQL is None (structured legs).  A cross-
    # source PV with a raw-SQL secondary therefore ran that side
    # UNFILTERED — row policies applied to the primary connection only.
    # Same principal, same fail-closed posture as the primary block above;
    # dialect is duckdb because the cross secondary engine is the
    # local/s3 parquet path.
    if sec_raw_sql:
        try:
            from core.row_security import secure_sql as _rs_secure_sec
            from core.sql_filter_wrapper import dialect_for_connection_type as _sec_dial_fn
            sec_raw_sql = await asyncio.to_thread(
                _rs_secure_sec,
                sec_raw_sql,
                # a connector side runs in ITS grammar (2026-10-24); the
                # local / s3 parquet path is duckdb
                dialect=(_sec_dial_fn(_sec_connector_record.get("connection_type"))
                         if _sec_connector_record else "duckdb"),
                user_ctx=_pv_user_ctx,
                connection_id=sec_conn_id,
                request_id=execution_id,
            )
        except HTTPException:
            raise
        except Exception as _rs_sec_exc:
            logger.error("Row-security rewrite failed for PV %s secondary: %s",
                          pv.get("slug"), _rs_sec_exc)
            raise HTTPException(
                status_code=403,
                detail=f"Row-security policy enforcement failed (secondary): {_rs_sec_exc}",
            )

    # Phase 139 honest-fix: stash time-travel params in query_config_dict so
    # downstream setup_registered_views can pass them to get_iceberg_data_files.
    if snapshot_id is not None:
        query_config["_iceberg_snapshot_id"] = int(snapshot_id)
    if as_of_timestamp_ms is not None:
        query_config["_iceberg_as_of_ms"] = int(as_of_timestamp_ms)
    # 2026-11-01 -- the per-table overrides the route parsed (``?version.<t>=``
    # / ``?as_of=``) travel to the run's resolver the same way
    # (core/iceberg_versions.py QC_OVERRIDES_KEY; execute_api reads it).
    if pv.get("_version_overrides"):
        from core.iceberg_versions import QC_OVERRIDES_KEY as _QC_IV
        query_config[_QC_IV] = dict(pv["_version_overrides"])

    # BF-430A — per-PV reader override.  PV column wins over the snapshotted
    # query_config value.  NULL = whatever the snapshot has (which itself
    # defaults to NULL = use global s3_readers config).  The router validates
    # the name against the registry; unknown names degrade to "auto" with a
    # warning rather than failing the request.  We mutate BOTH the dict (used
    # by setup_registered_views' _extract_reader_override on the dict path)
    # AND the Pydantic qc_model (the actual source for convert_query_config_to_engine
    # below) so the override survives the conversion to engine QueryConfig.
    _pv_reader_override = pv.get("reader_override")
    if _pv_reader_override:
        query_config["reader_override"] = _pv_reader_override
        try:
            qc_model.reader_override = _pv_reader_override
        except Exception as _ro_exc:
            # Defensive: if the model rejects assignment (frozen / validator
            # error), the dict-path injection still covers the streaming
            # callsites that read query_config_dict.
            logger.warning("PV %s reader_override assignment to qc_model failed: %s",
                            pv.get("slug"), _ro_exc)

    # BF-99: Convert Pydantic QueryConfigModel → engine QueryConfig (dict-based
    # dataclass) before passing to execute_query_background.  The engine methods
    # (build_query_sql, execute_duckdb_query, _apply_filters, _build_where) use
    # dict subscript access f["column"] which fails on Pydantic models.
    from core.query_converter import convert_query_config_to_engine
    engine_qc = convert_query_config_to_engine(qc_model)
    secondary_engine_qc = convert_query_config_to_engine(secondary_qc_model) if secondary_qc_model else None
    if _sec_connector_record is not None:
        # 2026-10-24 -- the SQL-connector secondary as a connector SIDE (THE
        # side runner /api/execute uses): it used to be built only for a
        # local / s3 secondary, so an on-prem Starburst secondary was never
        # run and the API served the PRIMARY's rows alone, "exact".
        from api.execute_api import _CrossSourceConnectorEngine
        secondary_engine = _CrossSourceConnectorEngine(
            connection={**_sec_connector_record, "id": sec_conn_id},
            sql=sec_raw_sql,
            chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000)
    if sec_conn_id and not (secondary_engine and secondary_engine_qc):
        # Never half the answer as a success: a cross-source view whose
        # secondary cannot be run REFUSES (the 2026-08-05 posture, on the
        # one road it did not cover).
        raise HTTPException(
            500,
            f"Published view '{pv['slug']}' is cross-source but its secondary side "
            f"(connection {sec_conn_id}) cannot be run here, so only the primary's rows "
            f"would be served. Refusing. Contact an administrator.")

    # ── 2026-09-29 — a slot in the pod's GLOBAL query cap, like every ──
    # other query path.  All three branches below run the same engines
    # /api/execute does, behind a PUBLISHED_API pool slot only -- so the
    # cap that protects the pod's memory never counted a published-view
    # query.  Charged to the consumer (_admission_identity); refused at the
    # cap with the ONE wire shape (503 + Retry-After: 5, before any engine
    # is touched); released on EVERY exit -- success, the 500 below, and the
    # request's cancellation (the ``finally`` on this try).  No wait on
    # this sync path unless an async report runner armed one by scope.
    from core.reports.admission import (
        QuerySlot as _SqQuerySlot,
        ReportAdmissionRefused as _SqAdmissionRefused,
        release_when_work_ends as _release_when_work_ends,
    )
    _sq_slot = _SqQuerySlot(
        _admission_identity(pv.get("_consumer_user_ctx") or consumer_user, pv),
        execution_id, per_user=True)
    try:
        await _sq_slot.acquire()
    except _SqAdmissionRefused as _sq_ref:
        logger.warning("[pv-execute] view=%s refused at admission: %s",
                       pv.get("slug"), _sq_ref.reason)
        raise _sq_ref.as_http()

    # ── Create execution record -- AFTER admission (2026-10-07, F11) ─────
    # A refused request never ran, so it writes no row (the /api/execute
    # rule: "No DB record was created yet"); the 503 carries the reason.
    # From the INSERT on, EVERY exit settles the row in the ``finally``
    # below: a 4xx/5xx raised before an executor ran, an engine failure, a
    # cancel -- the row can no longer be left ``pending``.
    _pv_row_written = False
    _pv_exit_status = "cancelled"     # a BaseException (a cancel) unless set
    _pv_exit_reason: Optional[str] = (
        "The published-view request ended before the query finished "
        "(cancelled).")
    try:
        # BF-597: async DB.
        await adb(_db_manager.create_execution,
            execution_id=execution_id,
            query_config=query_config,
            executed_by=f"published_view:{pv['slug']}",
        )
        _pv_row_written = True
        if secondary_engine and secondary_engine_qc:
            # Cross-connection execution — Phase 80
            try:
                from api.execute_api import execute_cross_query_background
                await execute_cross_query_background(
                    execution_id=execution_id,
                    primary_engine=active_engine,
                    primary_config=engine_qc,
                    secondary_engine=secondary_engine,
                    secondary_config=secondary_engine_qc,
                    combine_mode=combine_mode,
                    join_config=join_config_dict,
                    executed_by=f"published_view:{pv['slug']}",
                    query_config_dict=query_config,
                    work_type=_pv_work_type,
                    primary_raw_sql=_pv_raw_sql,
                    secondary_raw_sql=sec_raw_sql,
                    primary_connection_id=connection_id,
                    secondary_connection_id=sec_conn_id,
                    # Phase 131 deep-dive #13 (round 4): RLS on structured legs.
                    user_ctx=_pv_user_ctx,
                )
            except (ImportError, TypeError) as cross_err:
                # 2026-08-05 BR cross-source audit: this used to FALL BACK
                # to a primary-only execution — an infra/signature failure
                # silently halved a cross-source result and served it as a
                # success.  Refuse: the consumer asked for the combined
                # result; half of it is not a degraded mode, it is wrong
                # data (the exact defect shape the feed audit found).
                logger.error("Cross-query execution unavailable for view %s "
                             "(%s) — refusing primary-only fallback",
                             pv["slug"], cross_err)
                raise HTTPException(
                    500,
                    f"Published view '{pv['slug']}' is cross-source but the "
                    f"cross-connection executor failed to start "
                    f"({type(cross_err).__name__}). Refusing to serve only "
                    f"the primary side. Contact an administrator — this is "
                    f"a deployment/code issue, not a data issue.")
        elif _sql_connector_instance is not None:
            # BF-PV-CONNECTOR-PARITY: route SQL connector views to the
            # dedicated execution path.  Was the missing branch — published
            # views with snowflake/trino/starburst/databricks/oracle/athena
            # silently fell through to the parquet path.
            from api.execute_api import execute_sql_connector_background
            # Build SQL: prefer raw_sql when set, else compose from
            # query_config like sql_query_api does.
            if _pv_raw_sql:
                _sql_str_pv = _pv_raw_sql
            else:
                # 2026-09-05 round 2 -- the SAME chokepoint /api/execute
                # and /api/execute/preview-sql use.  This was ``files[0]``
                # verbatim: a published view over ``__registered__:sales``
                # on a Trino connection served an EXTERNAL consumer rows
                # from whatever ``sales`` that session's default catalog
                # resolved to, with a 200 and no warning anywhere.
                from core.parquet_engine_v2 import (
                    native_from_ref as _native_from_ref_pv,
                    QueryNotExpressible as _QNE_pv)
                try:
                    _table_ref_pv = _native_from_ref_pv(
                        getattr(engine_qc, "files", None),
                        getattr(engine_qc, "joins", None),
                        str(_sql_connector_type or "").lower())
                except _QNE_pv as _qne_pv:
                    raise HTTPException(400, detail={
                        "error": "query_not_expressible",
                        "engine": str(_sql_connector_type or "").lower(),
                        "connection_id": connection_id,
                        "slug": pv.get("slug"),
                        "message": str(_qne_pv),
                        "sql": "",
                    })
                if _table_ref_pv is None:
                    _table_ref_pv = (engine_qc.files[0]
                                     if getattr(engine_qc, "files", None)
                                     else None)
                if not _table_ref_pv:
                    raise HTTPException(
                        500,
                        f"Published view '{pv['slug']}' on {_sql_connector_type} "
                        f"connector requires either raw_sql or query_config.files[0] "
                        f"(table name)",
                    )
                # 2026-08-19 -- dialect: see reports_api.
                # 2026-08-19 -- type the filters; see reports_api.  The
                # published API is the external surface, so an untyped date
                # filter here is a consumer-visible hard failure.
                from core.column_types import (
                    annotate_from_connector as _annot_pv)
                _annot_pv(engine_qc.filters, _sql_connector_instance,
                          _table_ref_pv, None, connection_id)
                _sql_str_pv = _default_engine.build_query_sql(
                    engine_qc, _table_ref_pv,
                    dialect=str(_sql_connector_type or "").lower())
                # 2026-08-19 -- ROW SECURITY.  Only _pv_raw_sql / secondary
                # raw SQL were secured above; a STRUCTURED published view on
                # a SQL connector built its SQL here and handed it straight
                # to execute_sql_connector_background, which contains no
                # row-security code.  The published API is the EXTERNAL
                # surface, so this was the widest instance of the gap.
                try:
                    from core.row_security import secure_sql as _rs_pv2
                    from core.row_security.api import (
                        PolicyResolutionError as _RsErrPv)
                    # Imported HERE rather than reusing the ``_dial`` alias
                    # bound earlier in this function: that binding sits
                    # inside a conditional branch, so relying on it would
                    # make the dialect depend on whether an unrelated
                    # branch ran.
                    from core.sql_filter_wrapper import (
                        dialect_for_connection_type)
                    _pv_secured = await asyncio.to_thread(
                        _rs_pv2, _sql_str_pv,
                        # 2026-09-05 -- THE vocabulary, not a fourth copy.
                        # This site kept a private connection-type ->
                        # dialect map (``_RS_PV_DIALECTS``) while the three
                        # OTHER dialect sites in this same file already
                        # imported the shared resolver.  The copy answered
                        # ``athena -> trino`` where the shared map answers
                        # ``athena -> athena``, and knew nothing of
                        # sqlserver / redshift / bigquery -- so their SQL
                        # was parsed as duckdb for the RLS rewrite, which
                        # can alter what finally runs.  A decision made
                        # twice is a bug; the resolver now answers once.
                        dialect=dialect_for_connection_type(
                            str(_sql_connector_type or "")),
                        user_ctx=_pv_user_ctx,
                        connection_id=connection_id,
                        request_id=execution_id,
                    )
                    if _pv_secured:
                        _sql_str_pv = _pv_secured
                except _RsErrPv as _rs_pv_exc:
                    raise HTTPException(
                        status_code=403,
                        detail=("Row-security policy enforcement failed: "
                                f"{_rs_pv_exc}"),
                    )
            # 2026-08-22 — stamp the FINAL statement (params substituted,
            # filters wrapped, logical tables rewritten, ROW-SECURED)
            # exactly as it is about to execute.  The bulk-prepare ladder
            # build reads these stamps off a 1-row probe so it can run the
            # SAME text through the write ladder — SQL resolution stays in
            # THIS function, the one true path; a second resolver is the
            # twin-defect this codebase keeps re-finding (08-22 P0).
            query_config["_qs_final_sql"] = _sql_str_pv
            query_config["_qs_final_connection_id"] = connection_id
            query_config["_qs_final_conn_type"] = str(
                _sql_connector_type or "").lower()
            try:
                await execute_sql_connector_background(
                    execution_id=execution_id,
                    connector=_sql_connector_instance,
                    sql=_sql_str_pv,
                    query_id=None,
                    executed_by=f"published_view:{pv['slug']}",
                    query_config_dict=query_config,
                    # 2026-08-22 — dataset_row_cap was enforced ONLY by writing
                    # query_config["limit"], which this path never reads: the
                    # raw SQL goes to the connector verbatim, so a raw-SQL view
                    # over a 70M-row table materialised all 70M rows into the
                    # pod and the cap-overflow sentinel at the bottom of this
                    # function could never fire.  The cap travels with the
                    # request now, and the connector applies it in its own
                    # dialect.
                    row_limit=query_config.get("limit"),
                    cache_strategy=_engine_cache_strategy,
                    # 2026-10-05 -- the source's verdict comes back as
                    # itself (recorded as a failed run first), so the
                    # handler below answers it through api.connector_errors
                    # instead of "Execution produced no result" -> 500.
                    reraise_failure=True,
                )
            finally:
                try:
                    _sql_connector_instance.close()
                except Exception as _be_exc:
                    note_best_effort("_sql_connector_instance.close()", _be_exc,
                                     logger=logger)
        else:
            await execute_query_background(
                execution_id=execution_id,
                query_config=engine_qc,
                query_id=None,
                active_engine=active_engine,
                executed_by=f"published_view:{pv['slug']}",
                raw_sql=_pv_raw_sql,
                query_config_dict=query_config,
                work_type=_pv_work_type,
                # Phase 131 deep-dive #13 (round 4): plumb identity so
                # structured-PV path applies RLS too.
                user_ctx=_pv_user_ctx,
                rls_connection_id=connection_id,
                # 2026-09-15 — the row bound is DECLARED to the executor (the
                # raw-SQL generators and the COPY paths never read
                # query_config["limit"]; see execute_query_background), and
                # the route's cache intent reaches the engine's result cache.
                row_bound=query_config.get("limit"),
                cache_strategy=_engine_cache_strategy,
                # 2026-10-02 -- a scan refusal (the presigned file cap, the
                # scan budget) comes back as itself, not as "no result":
                # the handler below answers it 422 with its remedy.
                reraise_refusals=True,
            )
        # The executor returned: it wrote the outcome.  The settle below
        # still finalises a row it left ``pending`` -- that is a defect of
        # its own, and must not be a row nobody ever closes.
        _pv_exit_status = "failed"
        _pv_exit_reason = ("The query returned without recording an "
                           "outcome for this execution.")
    except HTTPException as _pv_http_exc:
        # 2026-08-05: specific refusals (cross-source executor unavailable,
        # RLS enforcement failure) carry an actionable message — do not
        # flatten them into the generic 500 below.
        _pv_exit_status = "failed"
        _pv_exit_reason = _pv_http_reason(_pv_http_exc)
        raise
    except Exception as exc:
        _pv_exit_status = "failed"
        _pv_exit_reason = (f"Query execution failed: "
                           f"{type(exc).__name__}: {exc}")[:2000]
        logger.error("View execution failed for '%s': %s", pv["slug"], exc, exc_info=True)
        # 2026-09-17 (FB-15c) -- an open circuit breaker is TEMPORARY and
        # self-clearing, and its message was written for the caller;
        # answering 500 "contact support" turned a 45-second wait into a
        # support ticket.  See raise_if_self_clearing.
        _raise_if_self_clearing(exc)
        # 2026-10-05 -- the SOURCE's verdict on the statement (Trino
        # TYPE_MISMATCH / COLUMN_NOT_FOUND, ORA-00904) is the request being
        # unprocessable at the source: 400 with the source's sentence (the
        # federation-view preview answers the same way).  Only the residue
        # the classifier has no opinion about stays the generic 500.  Asked
        # for the SQL-connector branch only: the DuckDB-run branches' errors
        # are the engine's own (paths, internals), not a source's sentence.
        if _sql_connector_instance is not None and not (
                secondary_engine and secondary_engine_qc):
            from api.connector_errors import raise_if_source_error as _raise_if_src
            _raise_if_src(exc, str(_sql_connector_type or ""),
                          subject="The statement sent to the {conn_type} source")
        raise HTTPException(500, "Query execution failed — contact administrator")
    finally:
        # Every exit, a CancelledError included -- but the slot is the
        # ENGINE's, not this coroutine's: a cancelled request leaves here
        # while the pool thread is still inside the work, and releasing then
        # would undercount the cap.  The executors above submit ONE pool
        # task keyed by this execution id, so the release rides its
        # done-callback when it is still live, and happens now otherwise.
        _release_when_work_ends(execution_id, _sq_slot)
        if _pv_row_written:
            await _settle_pv_execution(execution_id, _pv_exit_status,
                                       _pv_exit_reason)

    # ── Locate result file ────────────────────────────────────────────────
    result_path = None
    # BF-597: async DB.
    execution = await adb(_db_manager.get_execution, execution_id)
    if execution:
        rf = execution.get("result_file") or execution.get("output_file")
        if rf and Path(rf).exists():
            result_path = rf

    if not result_path:
        from core.config import paths as _paths_cfg
        for ext in ("parquet", "csv"):
            p = _paths_cfg.downloads_dir / f"{execution_id}.{ext}"
            if p.exists():
                result_path = str(p)
                break

    if not result_path or not Path(result_path).exists():
        raise HTTPException(500, "Execution produced no result")

    # ── Read one PAGE from the materialized dataset (Arrow, strict) ───────
    from api.published_views.envelope import (
        DatasetManifest, TotalMode, col_meta_from_schema, read_page,
        rows_from_table,
    )
    def _sq_page_blocking():
        """The result file's footer and the page -- file I/O and Arrow
        decode, run OFF the loop (api/published_views/page_io.py)."""
        # Bounded page read (envelope.read_page): footer-only total_rows +
        # column projection + offset/limit pushdown.  Arrow end-to-end — no
        # pandas on the wire path, so int64 with NULLs stays exact.
        # strict=True → unknown ?columns / ?sort are REJECTED with 400 here,
        # the same chokepoint the cache-HIT path uses.
        _dataset_total = None
        try:
            import pyarrow.parquet as _pq_meta
            _dataset_total = _pq_meta.ParquetFile(str(result_path)).metadata.num_rows
        except Exception:
            _dataset_total = None
        # Cap-overflow detection: we asked the engine for cap+1 rows; a footer
        # of EXACTLY cap+1 means the dataset was truncated by our sentinel —
        # report AT_LEAST cap and clamp the readable window to cap.
        _cap_hit = bool(_ds_cap > 0 and _dataset_total == _ds_cap + 1)
        # 2026-09-15 — a PAGE-bounded scan that reached its bound: the file
        # is a prefix.  ``total_rows`` stays the footer count (rows that were
        # MEASURED to exist -- the bound plus the has_more row), the manifest
        # says at_least and records the bound so the cache reader refuses to
        # answer a wider page from it.  ``>=`` not ``==``: an engine cache
        # can hand back a wider bounded file for the same SQL; wider is
        # still "at least", never exact.
        _page_bound_hit = bool(
            _scan_bound is not None and not _cap_hit
            and _dataset_total is not None and _dataset_total >= _scan_bound
        )
        _page_limit, _page_offset = limit, offset
        if _cap_hit:
            _page_offset = min(offset, _ds_cap)
            _page_limit = max(0, min(limit, _ds_cap - _page_offset))
        _tbl, _total = read_page(
            str(result_path), columns=columns, limit=_page_limit, offset=_page_offset,
            sort_column=sort_column, sort_dir=sort_dir, strict=True,
        )
        if _cap_hit:
            _total = _ds_cap
        return _tbl, _total, _dataset_total, _cap_hit, _page_bound_hit

    try:
        table, total_rows, _dataset_total, _cap_hit, _page_bound_hit = \
            await _page_io.off_loop(_sq_page_blocking)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to read result parquet: %s", exc)
        raise HTTPException(500, "Failed to read execution result")

    # BF-271: When PV returns 0 rows, log enough context for an admin to diagnose
    # *why* — without this, the consumer sees `data: []` and the admin sees
    # nothing in logs.  Common silent-empty cases:
    #   - files=[]: BQB save before any tables were selected → local-only path
    #     against a SQL that references S3 tables → DuckDB error swallowed,
    #     0-row parquet written
    #   - registered_tables list at connection level no longer contains the
    #     table referenced in raw_sql (admin removed it after the query was saved)
    #   - All partition values pruned away → empty view → 0 rows
    # ── Empty-result honesty (BF-271 made STRUCTURAL) ─────────────────────
    # The engine can write a 0-row parquet as "success" in cases where the
    # real cause was a swallowed failure (files=[], deregistered table, ...).
    # That knowledge used to live only in a server-side log line while the
    # consumer got a bare 200 ``data: []``.  Now it is recorded on the
    # DatasetManifest and rendered into the envelope (meta.data_status /
    # meta.empty_causes) so the consumer can distinguish verified-empty from
    # unverifiable-empty.
    _empty_causes: list = []
    _data_status = "ok"
    if total_rows == 0:
        _pv_files = query_config.get("files") or []
        _pv_has_raw_sql = bool(query_config.get("raw_sql"))
        _data_status = "empty_unverified"
        if not _pv_files and not _pv_has_raw_sql:
            _empty_causes.append("query_config.files is empty and no raw_sql — view may have been saved before tables were selected")
        if filters or query_config.get("filters"):
            _empty_causes.append("filters may have matched no rows")
        if params:
            _empty_causes.append("runtime parameters may have matched no rows")
        if not _empty_causes:
            _empty_causes.append("engine reported success with 0 rows; emptiness could not be independently verified")
        logger.warning(
            "[pv-empty] view=%s returned 0 rows. frozen_files=%s, has_raw_sql=%s, "
            "connection_id=%s, causes=%s",
            pv["slug"], _pv_files, _pv_has_raw_sql, connection_id, _empty_causes,
        )

    # Projection / sort / offset / limit are applied INSIDE read_page above
    # (pushed into the parquet reader) — re-applying them here would re-slice
    # an already-sliced page.

    col_meta = col_meta_from_schema(table.schema)

    # ── Manifest: the single owner of what is TRUE about this dataset ─────
    # FB-38: the artifact records WHICH version it represents.  When the
    # consumer pinned a snapshot that is it; otherwise the reader stashed the
    # CURRENT snapshot it resolved into query_config (core.duckdb_views,
    # first Iceberg table wins), and that is recorded so a later pull can be
    # told apart from this one.  None only when no Iceberg table was read.
    _manifest_snapshot = snapshot_id
    if _manifest_snapshot is None:
        try:
            _resolved = query_config.get("_iceberg_snapshot_id")
            _manifest_snapshot = int(_resolved) if _resolved not in (None, "") else None
        except (TypeError, ValueError):
            _manifest_snapshot = None
    _manifest = DatasetManifest(
        total_rows=total_rows,
        total_mode=(TotalMode.AT_LEAST if (_cap_hit or _page_bound_hit) else TotalMode.EXACT),
        source_type=pv.get("source_type") or "saved_query",
        snapshot_id=_manifest_snapshot,
        as_of_timestamp_ms=as_of_timestamp_ms,
        engine_connection_id=query_config.get("connection_id"),
        execution_id=execution_id,
        data_status=_data_status,
        empty_causes=_empty_causes,
        scan_bound=(_scan_bound if _page_bound_hit else None),
    )

    # Phase 100: include cache_key for Business Report ETag-like skip optimization
    # BF-415: scope by user when PV has RLS so the ETag isn't shared across
    # consumers with different RLS rewrites.
    #
    # 2026-09-05 -- the SIXTH call site, and it was missing the lifecycle
    # ingredient the other five gained today.  This token is what a client
    # sends back as an ETag to be told "nothing changed", so an identity
    # that does not move when the backing report is ARCHIVED or REPUBLISHED
    # tells the consumer their copy is current after the definition
    # changed underneath it -- the same bypass closed on the /data slot,
    # one door along.  ``_report_version_scope`` answers ``None`` for every
    # non-report-backed view, so this stays byte-identical for them.
    _ck = _build_cache_key(pv["id"], filters, sort_column, sort_dir,
                           columns, limit, offset, params,
                           user_scope=_user_cache_scope(pv, pv.get("_consumer_user_ctx")),
                           report_version=await adb(_report_version_scope,
                                                    pv, _db_manager))

    # Phase 101: enrich with semantic column metadata if backed by a dataset
    semantic_col_meta = {}
    try:
        qc_dataset_id = query_config.get("dataset_id")
        if qc_dataset_id and _db_manager:
            # BF-597: async DB.
            ds_cols = await adb(_db_manager.list_dataset_columns, int(qc_dataset_id))
            for dc in ds_cols:
                semantic_col_meta[dc["physical_name"]] = {
                    "friendly_name": dc.get("friendly_name", ""),
                    "format_pattern": dc.get("format_pattern", ""),
                    "column_type": dc.get("column_type", ""),
                    "aggregation": dc.get("aggregation", ""),
                    "description": dc.get("description", ""),
                }
    except Exception as _be_exc:
        note_best_effort("semantic_col_meta[dc['physical_name']] = {'friendly_name': dc.get...", _be_exc,
                         logger=logger)

    # Phase 131 deep-dive #13 (hardening): unregister api_key_lifecycle
    # entry on happy-path exit.  Exceptional exits leak until the next
    # sweep GC pass cleans up orphan entries (entries whose worker_pool
    # record is gone).
    if _akl_key_id_pv:
        try:
            from core.api_key_lifecycle import unregister_execution as _akl_unreg
            _akl_unreg(execution_id)
        except Exception as _be_exc:
            note_best_effort("_akl_unreg(execution_id)", _be_exc,
                             logger=logger)

    _result_out = {
        "total_rows": total_rows,
        "returned_rows": table.num_rows,
        "offset": offset,
        "limit": limit,
        "columns": col_meta,
        "_parquet_path": result_path,
        "cache_key": _ck,
        "column_metadata": semantic_col_meta,
        "_manifest": _manifest,
        "_page_table": table,
        # 2026-08-22 — the FINAL secured statement of a single-source SQL-
        # connector execution (None on every other shape).  Consumed by
        # the bulk-prepare write-ladder build; see the stamp site above.
        "_final_sql": query_config.get("_qs_final_sql"),
        "_final_connection_id": query_config.get("_qs_final_connection_id"),
        "_final_conn_type": query_config.get("_qs_final_conn_type"),
    }
    _manifest.apply_to_result(_result_out)
    # E-H4 — when the caller requested streaming (json/csv), defer the
    # expensive encoding to the streaming response builder; attach the Arrow
    # page instead.  Otherwise materialize ``data`` (Arrow → pylist keeps
    # int64 exact) for every other caller (BR / federation / GraphQL / warmup).
    if stream:
        _result_out["data"] = []
        _result_out["_stream_df"] = table
    else:
        _result_out["data"] = await _page_io.off_loop(rows_from_table, table)
    return _result_out


async def _time_travel_capability_for(pv: dict):
    """(supported, reason) for THIS view -- ``api.published_views.time_travel``
    decides; this only fetches the connection config a registered-table ref
    needs, and reports an unreadable connection as UNKNOWN (None), never as
    "no"."""
    from api.published_views.time_travel import (
        TIME_TRAVEL_SOURCE_TYPES, time_travel_capability,
    )
    conn_cfg = None
    unreadable = None
    if (pv.get("source_type") or "saved_query") in TIME_TRAVEL_SOURCE_TYPES:
        qc = pv.get("query_config") or {}
        cid = qc.get("connection_id")
        if cid and _db_manager is not None:
            try:
                rec = await adb(_db_manager.get_connection_raw, int(cid))
                if rec:
                    conn_cfg = rec.get("config") or {}
                else:
                    unreadable = f"connection {cid} was not found"
            except Exception as exc:                     # noqa: BLE001
                unreadable = f"connection {cid} could not be read ({type(exc).__name__})"
    return time_travel_capability(pv, conn_cfg, connection_unreadable=unreadable)


async def _refuse_unless_time_travel_supported(pv: dict,
                                               snapshot_id: Optional[int],
                                               as_of_timestamp_ms: Optional[int]) -> None:
    """FB-38 (2026-09-19): ``?snapshot_id=`` / ``?as_of_timestamp=`` on a view
    that cannot travel used to return CURRENT data with 200 -- numbers from a
    different point in time than the one requested, under the requested
    label.  Refuse with the reason (400), or 503 when the answer could not
    be determined.  No-op when neither parameter was sent."""
    if snapshot_id is None and as_of_timestamp_ms is None:
        return
    supported, reason = await _time_travel_capability_for(pv)
    if supported is True:
        return
    if supported is None:
        raise HTTPException(503, reason)
    raise HTTPException(400, reason)


# 2026-10-24 -- THE rule lives in helpers (the cache scope reads it too).
from api.published_views.helpers import with_entitlement_scope as _with_entitlement_scope  # noqa: E402


async def _execute_view(
    pv: dict,
    filters: List[Dict],
    columns: Optional[List[str]],
    sort_column: Optional[str],
    sort_dir: str,
    limit: int,
    offset: int,
    params: Optional[Dict[str, Any]] = None,
    snapshot_id: Optional[int] = None,
    as_of_timestamp_ms: Optional[int] = None,
    consumer_user: Optional[Dict[str, Any]] = None,
    stream: bool = False,
) -> dict:
    """Dispatch to the source-type-specific handler via the REGISTRY below.

    2026-08 redesign — source types are a PLUGIN SEAM, not an if-chain.
    Every handler implements the same contract: execute, produce a
    materialized dataset parquet + ``DatasetManifest`` (truth: total_rows,
    total_mode, data_status), and return the page result built by
    ``envelope.read_page``.  Adding a new source type = one handler + one
    ``_SOURCE_HANDLERS`` entry; paging, validation, totals, caching, warmup
    and every output format come for free from the shared envelope layer.

    Caller signature is unchanged from the pre-refactor monolith — all 6
    production callers (REST endpoint, 3 BR paths, GraphQL bridge, warmup)
    keep working with no change.
    """
    # Stash the real consumer's identity on the PV dict so downstream
    # handlers (specifically the row-security hook in _execute_view_saved_query)
    # can apply policies against the actual principal — not a synthetic
    # placeholder.  Phase 141.
    if consumer_user is not None:
        pv = _copy_view(pv)   # keeps the rows read with the view (2026-10-03)
        pv["_consumer_user_ctx"] = _with_entitlement_scope(consumer_user, pv)

    # FB-38 (2026-09-19): a time-travel request on a view that cannot travel
    # is REFUSED at the seam every source type passes through -- a plugin
    # handler that does not implement snapshots is covered without knowing
    # this exists.  The handlers repeat the same call for direct callers.
    await _refuse_unless_time_travel_supported(pv, snapshot_id, as_of_timestamp_ms)

    # Phase 131 deep-dive #13: api_key_lifecycle registration happens
    # inside the saved_query handler where the REAL execution_id exists
    # (the one threaded into worker_pool.submit).  Registering here would
    # use a synthetic id that the cancel mechanism couldn't find.

    src = pv.get("source_type") or "saved_query"
    _handler_name = _SOURCE_HANDLERS.get(src, "_execute_view_saved_query")
    handler = globals()[_handler_name]
    # 2026-10-24 -- the entitlement DISCLOSURE (core/row_security/disclosure.py):
    # every row-security decision the handler's query makes -- on this task
    # and on the threads it hands work to -- is collected here, summarised
    # ONCE and stamped on the result AND its DatasetManifest, so a cache HIT
    # later says what THIS materialisation was filtered by.  Nothing is
    # resolved a second time.
    from core.row_security import disclosure as _disclosure
    with _disclosure.collecting() as _ent_entries:
        result = await handler(
            pv, filters, columns, sort_column, sort_dir, limit, offset,
            params=params, snapshot_id=snapshot_id,
            as_of_timestamp_ms=as_of_timestamp_ms,
            consumer_user=consumer_user, stream=stream,
        )
    return stamp_entitlement_disclosure(result, _ent_entries)


def stamp_entitlement_disclosure(result: Any, entries: List[Dict[str, Any]]) -> Any:
    """``result["_entitlement"]`` = the summary of ``entries``, and the same
    on the result's ``DatasetManifest`` (``_manifest``) so the sidecar the
    publish chokepoint writes carries it.  A result that is not a dict is
    handed back untouched."""
    from core.row_security import disclosure as _disclosure
    if not isinstance(result, dict):
        return result
    summary = _disclosure.summarise(entries)
    result["_entitlement"] = summary
    manifest = result.get("_manifest")
    if manifest is not None:
        try:
            manifest.entitlement = dict(summary)
        except Exception as exc:          # a stand-in manifest: the page still carries it
            logger.debug("[pv] manifest did not take the entitlement disclosure: %s", exc)
    return result


# ── Source-type plugin registry ───────────────────────────────────────────────
# One handler per source type, uniform contract (see _execute_view docstring).
# Maps to the handler's NAME (resolved via module globals at dispatch time) so
# handlers stay overridable — tests patch the module attribute, and a plugin
# can both register a new source type and re-bind an existing one.
# saved_query is the dispatch default for unknown/legacy source_type values.
_SOURCE_HANDLERS: Dict[str, str] = {
    "saved_query": "_execute_view_saved_query",
    "business_report": "_execute_view_business_report",
    "federation": "_execute_view_federation",
}
