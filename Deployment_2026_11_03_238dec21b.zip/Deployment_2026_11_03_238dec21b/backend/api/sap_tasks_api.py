"""SAP Task Config API (Phase 132.29).

Admin CRUD for ``SapTaskConfig`` rows.  Used by ops UI + by the Airflow
standalone runner (which reads task_id and resolves the full config
incl. encrypted Connection creds).

Auth: admin only on writes; any authenticated user on reads.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

# Import auth deps directly — single source of truth in api/deps.py.
# FastAPI resolves them at request time via Depends().
from api.deps import (require_capability, 
    get_current_user as _user_dep,
    require_admin as _admin_dep,
)

logger = logging.getLogger(__name__)
router = APIRouter(tags=["sap-tasks"])

# Module-level deps injected by main.py at startup
_db_manager = None
_get_current_user_dep = None
_require_admin_dep = None
_audit = lambda *a, **k: None  # set at startup


def set_sap_tasks_dependencies(
    db_manager: Any,
    get_current_user_dep: Any,
    require_admin_dep: Any,
    audit_fn: Any = None,
) -> None:
    global _db_manager, _get_current_user_dep, _require_admin_dep, _audit
    _db_manager = db_manager
    _get_current_user_dep = get_current_user_dep
    _require_admin_dep = require_admin_dep
    if audit_fn is not None:
        # 2026-10-30 (found by the switch-off proof): main.py wires
        # ``core.audit.audit_event(db_manager, user, request, action, ...)``
        # but every route here calls ``_audit(user, action, target=, details=)``
        # -- a TypeError raised AFTER the commit, so every SAP task create /
        # update / delete answered 500 having done the write.  Adapt once.
        def _adapted(user, action, target=None, details=None, _fn=audit_fn, _db=db_manager):
            try:
                _fn(_db, user, None, action, resource_type="sap_task",
                    resource_id=target, details=details)
            except Exception as exc:  # an audit line must never fail the write it records
                logger.warning("sap_task audit %s failed: %s", action, exc)
        _audit = _adapted


def _username(user: dict) -> str:
    return user.get("username") or user.get("user") or user.get("name") or "anon"


def _refuse_name_taken(other: Any, name: str) -> None:
    """409 either way; a switched-off task says how to get it back."""
    from core.config_active import is_on, name_held_message
    if not is_on(other):
        raise HTTPException(status_code=409, detail=name_held_message("SAP task", name))
    raise HTTPException(status_code=409, detail=f"task name {name!r} already exists")


def _require_deps() -> None:
    if _db_manager is None:
        raise HTTPException(status_code=503,
                              detail="sap_tasks_api dependencies not initialised")


# ── Body models ─────────────────────────────────────────────────────────


class SapTaskBody(BaseModel):
    name:                 str  = Field(..., min_length=1, max_length=120)
    is_active:            bool = True
    sap_connection_id:    int
    odata_service_path:   str
    company_code_endpoint: str
    company_code_field:   Optional[str] = "Companycode"
    # Phase 132.31 — OData entity set + filter style.  See SapTaskConfig
    # docstring for semantics + valid values.
    entity_set:           Optional[str] = "MEBALParameters"
    filter_style:         Optional[str] = "eq"   # eq | range
    period_mode:          Optional[str] = "current"
    p_gjahr:              Optional[str] = None
    p_poper:              Optional[str] = None
    num_groups:           Optional[int] = 5
    max_parallel_groups:  Optional[int] = 3
    page_size:            Optional[int] = 100000
    timeout_seconds:      Optional[int] = 120
    max_retries:          Optional[int] = 3
    retry_backoff:        Optional[int] = 2
    rate_limit_rps:       Optional[int] = 5
    verify_ssl:           Optional[bool] = True
    proxy_url:            Optional[str] = None
    output_dir:           str
    output_format:        Optional[str] = "csv"
    consolidated_filename: Optional[str] = "MEBAL_{GJAHR}_{POPER}"
    group_history_path:   Optional[str] = None
    delete_group_files:   Optional[bool] = True
    column_mapping_path:  Optional[str] = None
    gzip_level:           Optional[int] = 6
    gzip_chunk_size:      Optional[int] = 67108864
    delete_uncompressed:  Optional[bool] = True
    ctl_template:         Optional[str] = None
    ctl_filename:         Optional[str] = None
    ctl_custom_variables: Optional[Dict[str, Any]] = None
    delivery_type:        Optional[str] = "nfs"
    nfs_dest_dir:         Optional[str] = None
    sftp_connection_id:   Optional[int] = None
    sftp_remote_dir:      Optional[str] = None
    s3_connection_id:     Optional[int] = None
    s3_bucket:            Optional[str] = None
    s3_prefix:            Optional[str] = None
    notify_emails:        Optional[str] = None
    # Phase 132.33 — live OData passthrough configuration.
    passthrough_enabled:          Optional[bool] = False
    passthrough_partition_field:  Optional[str]  = "company_code"
    passthrough_required_filters: Optional[List[str]] = None
    passthrough_rate_limit_rpm:   Optional[int]  = 60
    passthrough_max_rows:         Optional[int]  = 10000


# ── Routes ──────────────────────────────────────────────────────────────


@router.get("/api/sap-tasks")
def list_sap_tasks(
    user: dict = Depends(require_capability("etl.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.config_active import active_clause
    from core.db.models import SapTaskConfig
    with _db_manager.get_session(read_only=True) as session:
        rows = session.query(SapTaskConfig).filter(active_clause(SapTaskConfig)).order_by(
            SapTaskConfig.name.asc()).all()
        return [r.to_dict() for r in rows]


@router.get("/api/sap-tasks/{task_id}")
def get_sap_task(
    task_id: int, user: dict = Depends(require_capability("etl.view")),
) -> Dict[str, Any]:
    _require_deps()
    from core.config_active import active_clause
    from core.db.models import SapTaskConfig
    with _db_manager.get_session(read_only=True) as session:
        row = session.query(SapTaskConfig).filter(
            SapTaskConfig.id == task_id, active_clause(SapTaskConfig)).first()
        if row is None:
            raise HTTPException(status_code=404, detail="task not found")
        return row.to_dict()


@router.post("/api/sap-tasks")
def create_sap_task(
    body: SapTaskBody, user: dict = Depends(require_capability("etl.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import SapTaskConfig, Connection
    with _db_manager.get_session() as session:
        # Validate the referenced SAP connection
        sap_conn = session.query(Connection).filter(
            Connection.id == body.sap_connection_id).first()
        if sap_conn is None:
            raise HTTPException(
                status_code=400,
                detail=f"sap_connection_id {body.sap_connection_id} not found",
            )
        # Dedupe by name -- a switched-off task keeps its name (2026-10-30)
        same = session.query(SapTaskConfig).filter(SapTaskConfig.name == body.name).first()
        if same is not None:
            _refuse_name_taken(same, body.name)
        row = SapTaskConfig(**body.model_dump())
        session.add(row)
        session.flush()
        result = row.to_dict()
    _audit({"username": _username(user)}, "sap_task.create",
            target=f"sap_task:{result['id']}",
            details={"name": body.name})
    return result


@router.patch("/api/sap-tasks/{task_id}")
def update_sap_task(
    task_id: int, body: SapTaskBody, user: dict = Depends(require_capability("etl.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.config_active import active_clause
    from core.db.models import SapTaskConfig
    with _db_manager.get_session() as session:
        row = session.query(SapTaskConfig).filter(
            SapTaskConfig.id == task_id, active_clause(SapTaskConfig)).first()
        if row is None:
            raise HTTPException(status_code=404, detail="task not found")
        # Block renaming to a name that collides (an ON or a switched-off task)
        existing = session.query(SapTaskConfig).filter(
            SapTaskConfig.name == body.name,
            SapTaskConfig.id != task_id).first()
        if existing is not None:
            _refuse_name_taken(existing, body.name)
        for k, v in body.model_dump().items():
            setattr(row, k, v)
        row.updated_at = datetime.now(timezone.utc)
        session.flush()
        result = row.to_dict()
    _audit({"username": _username(user)}, "sap_task.update",
            target=f"sap_task:{task_id}")
    return result


@router.delete("/api/sap-tasks/{task_id}")
def delete_sap_task(
    task_id: int, user: dict = Depends(require_capability("etl.manage")),
) -> Dict[str, Any]:
    _require_deps()
    # 2026-10-30 (owner): switched OFF, never erased -- the loader refuses a
    # switched-off task ("is inactive"), so the runner and the passthrough
    # stop; Admin -> Switched off brings it back.
    from core.config_active import active_clause, switch_off, switched_off_message
    from core.db.models import SapTaskConfig
    with _db_manager.get_session() as session:
        row = session.query(SapTaskConfig).filter(
            SapTaskConfig.id == task_id, active_clause(SapTaskConfig)).first()
        if row is None:
            raise HTTPException(status_code=404, detail="task not found")
        switch_off(row)
    _audit({"username": _username(user)}, "sap_task.delete",
            target=f"sap_task:{task_id}")
    return {"deleted": True, "detail": switched_off_message("SAP task")}


@router.get("/api/sap-tasks/{task_id}/resolved")
async def get_sap_task_resolved(
    task_id: int, user: dict = Depends(require_capability("etl.manage")),
) -> Dict[str, Any]:
    """Phase 132.29 — admin debug view: returns the full resolved dict
    (the same shape the standalone runner sees), with secrets masked.
    Use this to verify Connection lookups + column_mapping_path before
    you trigger the Airflow DAG.
    """
    _require_deps()
    from core.sap_task_loader import load_task_config, load_column_mapping
    try:
        cfg = load_task_config(_db_manager, task_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    # Mask secrets
    masked = dict(cfg)
    for k in ("sap_password", "sftp_password", "s3_secret_key"):
        if masked.get(k):
            masked[k] = "****"
    # Show whether column_mapping file is readable
    mp = cfg.get("column_mapping_path")
    masked["_column_mapping_status"] = (
        "absent" if not mp
        else ("readable" if load_column_mapping(mp) else "missing/unreadable")
    )
    return masked
