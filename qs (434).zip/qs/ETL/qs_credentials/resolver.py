"""qs_credentials.resolver -- ETL facade for vault-backed credentials.

Translates yaml-driven secret_refs into vault calls (via the shared
chokepoint in qs_credentials.vault) + caches via QSCredCache.

Usage:
    from qs_credentials import resolve_db_account
    user, pw = resolve_db_account("dest_oracle")
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from contextvars import ContextVar
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import yaml

# Relative import works in BOTH ETL containers (polling-service flat
# PYTHONPATH + sync-cron prefixed PYTHONPATH) since resolver.py is a
# package member.
from .cache import QSCredCache
from .vault import is_valid_vault_payload


_PROD_PATH = "/usr/local/spark/pvc/code/configs/vault_config.yaml"
# 2026-06-27 -- LOCAL fallback path FIXED.  Previously pointed at
# ``ETL/qs_credentials/configs/vault_config.yaml`` (under THIS module's
# directory) -- which never existed.  The actual file lives at
# ``ETL/configs/vault_config.yaml`` (one level UP, alongside
# starburst_config.yaml + oracle_config.yaml).  Resolver was silently
# returning empty secrets.refs on local dev / non-PVC pods.
#
# Probe order (first existing path wins, matches the other loaders'
# convention):
#   1. /usr/local/spark/pvc/code/configs/vault_config.yaml   (PROD PVC)
#   2. <ETL_ROOT>/configs/vault_config.yaml                  (repo + dev)
# Where ETL_ROOT = the parent of qs_credentials/ (i.e., the ETL/ dir).
_LOCAL_PATH = str(
    Path(__file__).resolve().parent.parent / "configs" / "vault_config.yaml"
)

_logger = logging.getLogger("qs_credentials.resolver")


# 2026-07-02 -- ContextVar signalling the SOURCE of the last
# ``_resolve_with_cache`` call.  Values: "mem" | "disk" | "plain" |
# "vault" | None.  Consumed by prewarm.py so ``_verify_cache_written``
# can distinguish "resolved via vault (cache write expected)" from
# "resolved via plain yaml (no cache write expected)" and not raise
# a spurious verification error when every OK ref was plain-served.
# ContextVar-scoped so concurrent prewarm calls don't clobber each
# other's per-ref view.
_LAST_RESOLVE_SOURCE_CV: "ContextVar[Optional[str]]" = ContextVar(
    "qs_last_resolve_source", default=None,
)


def get_last_resolve_source() -> Optional[str]:
    """Return the source of the most recent ``_resolve_with_cache`` call
    on THIS asyncio task / thread: ``"mem" | "disk" | "plain" | "vault"``,
    or ``None`` if no resolve happened.  Consumers (currently prewarm)
    use this to distinguish "vault was touched, disk cache should have
    a write" from "plain-yaml served, no cache write expected".
    """
    try:
        return _LAST_RESOLVE_SOURCE_CV.get()
    except LookupError:
        return None


# ────────────────────────────────────────────────────────────────────────
#  Global enable/disable
# ────────────────────────────────────────────────────────────────────────


def is_vault_enabled(workflow_config: Optional[Dict[str, Any]] = None) -> bool:
    """Four-layer toggle for vault-based credential resolution.

    Resolution order (highest priority wins):

      1. ``ETL_USE_VAULT=0`` env var (kill switch)
         * "0" / "false" / "no"  -> OFF (returns False immediately).
         Safety-critical: an ops "turn off vault fleet-wide" always
         wins over anything else.  Reason: turning vault OFF cannot
         make credentials less secure (dev DBs fall back to literal
         yaml creds, prod DBs loud-fail with a clear message).

      2. Per-workflow explicit override -- when ``workflow_config``
         is supplied AND has a ``vault_enabled`` key with explicit
         true/false (NOT empty / None).  Each workflow's yaml can
         independently opt in or opt out.
         **2026-07-01 fix**: previously env var ``ETL_USE_VAULT=1``
         short-circuited BEFORE checking this, so ops who set the env
         to enable Starburst vault also silently forced Oracle vault
         even when ``oracle.vault_enabled: false``.  Per-workflow
         explicit setting NOW wins over env=1 to support mixed
         posture (Starburst=vault, Oracle=plain yaml, or vice versa).

      3. ``ETL_USE_VAULT=1`` env var (ops default ON for workflows
         that don't opt out at layer 2).

      4. Global yaml setting ``secrets.enabled`` in
         ``vault_config.yaml``.  Default false (dev-safe).

    Args:
      workflow_config: optional per-workflow yaml dict (e.g., what
        ``starburst_config_loader.load_shared_starburst_config()``
        returns, or ``load_shared_oracle_config()``).  Pass the inner
        workflow section, not the full yaml.
    """
    env = os.environ.get("ETL_USE_VAULT", "").strip().lower()

    # Layer 1: env var kill switch -- ``ETL_USE_VAULT=0`` ALWAYS wins.
    # Fleet-wide safe direction: turning vault OFF cannot degrade
    # security posture; dev falls back to literal yaml creds, prod
    # loud-fails with an actionable message.
    if env in ("0", "false", "no"):
        return False

    # Layer 2: per-workflow explicit override -- wins over env=1 so
    # mixed posture works (e.g., Starburst wants vault ON via env=1,
    # Oracle yaml explicitly opts out with ``vault_enabled: false``).
    #
    # 2026-07-01 shape tolerance: workflow_config may be either the
    # INNER workflow section (``{"vault_enabled": ..., "etl": {...}}``)
    # OR the FULL yaml root (``{"oracle": {"vault_enabled": ...}, ...}``).
    # Auto-loaded oracle_config.yaml passes the full yaml root; explicit
    # callers (resolve_etl_connection_string) pass the oracle block.
    # Try top-level first; on miss, probe common section names so both
    # shapes work.
    if isinstance(workflow_config, dict):
        wf_flag = workflow_config.get("vault_enabled")
        if wf_flag is None or str(wf_flag).strip() == "":
            # Probe common workflow section names for the flag
            for section_key in ("oracle", "starburst", "s3"):
                sub = workflow_config.get(section_key)
                if isinstance(sub, dict):
                    sub_flag = sub.get("vault_enabled")
                    if sub_flag is not None and str(sub_flag).strip() != "":
                        wf_flag = sub_flag
                        break
        if wf_flag is not None and str(wf_flag).strip() != "":
            return str(wf_flag).strip().lower() in ("1", "true", "yes")

    # Layer 3: env var default ON -- when workflow was silent AND
    # ops set the env var to opt-in.  Now the "1" branch is a DEFAULT,
    # not a FORCE; per-workflow explicit at Layer 2 outranks it.
    if env in ("1", "true", "yes"):
        return True

    # Layer 4: global yaml flag in vault_config.yaml
    #
    # 2026-06-29 BUG-FIX: docstring + vault_config.yaml comments
    # document ``secrets.enabled`` as the master switch.  Previous
    # code read ``_vault_settings().get("enabled")`` which is
    # ``secrets.vault.enabled`` (the INNER block) -- a different key
    # that doesn't exist in the documented yaml shape.  Operators
    # setting ``secrets.enabled: true`` (the documented location) saw
    # no effect because the resolver was reading a key one level
    # deeper than promised.  Surfaced in prod via the prewarm DAG run.
    # Fix: read directly from ``_load_vault_yaml()`` which returns the
    # ``secrets`` block, so ``.get("enabled")`` is ``secrets.enabled``.
    # Falls back to ``secrets.vault.enabled`` for back-compat with any
    # deployment that placed the flag in the inner block to work
    # around the bug.
    secrets_block = _load_vault_yaml()
    if "enabled" in secrets_block:
        return bool(secrets_block.get("enabled", False))
    # Back-compat: legacy deployments that worked around the bug by
    # putting the flag in secrets.vault.enabled.
    return bool(_vault_settings().get("enabled", False))

# ────────────────────────────────────────────────────────────────────────
#  yaml loading
# ────────────────────────────────────────────────────────────────────────


def _load_vault_yaml() -> Dict[str, Any]:
    """Return the parsed ``secrets`` section of vault_config.yaml,
    or ``{}`` if absent / malformed.

    2026-06-27 -- emits one INFO log on the path used (or DEBUG when no
    yaml found) so operators can verify which file the resolver picked
    up.  Critical for debugging "I updated vault_config.yaml but
    nothing changed" symptoms.
    """
    for path in (_PROD_PATH, _LOCAL_PATH):
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            secrets_block = data.get("secrets", {}) or {}
            refs = secrets_block.get("refs", {}) or {}
            _logger.info(
                "[vault] loaded vault_config.yaml from %s (refs registered: %s)",
                path, sorted(refs.keys()),
            )
            return secrets_block
        except yaml.YAMLError as exc:
            _logger.warning(
                "vault_config.yaml at %s is malformed (%s) -- secret "
                "resolution will fail.", path, exc,
            )
            return {}
        except OSError as exc:
            _logger.warning(
                "Cannot read vault_config.yaml at %s (%s).", path, exc,
            )
            return {}
    # No yaml at all -- emit a clear marker so the operator sees this
    # in the log, not just a downstream "ref not found" mystery.
    _logger.warning(
        "[vault] NO vault_config.yaml found.  Probed:\n"
        "  PROD: %s (exists=%s)\n"
        "  LOCAL: %s (exists=%s)\n"
        "If you set secret_ref + vault_enabled, this will surface as "
        "'secret_ref=... not found in vault_config.yaml -- Available refs: []'.",
        _PROD_PATH, os.path.exists(_PROD_PATH),
        _LOCAL_PATH, os.path.exists(_LOCAL_PATH),
    )
    return {}


@lru_cache(maxsize=1)
def _vault_settings() -> Dict[str, Any]:
    """Cached parse of the ``secrets.vault`` block (machine, token_method, ttl)."""
    secrets = _load_vault_yaml()
    return secrets.get("vault", {}) or {}


@lru_cache(maxsize=1)
def _secret_refs() -> Dict[str, Dict[str, Any]]:
    """Cached parse of the ``secrets.refs`` block."""
    secrets = _load_vault_yaml()
    return secrets.get("refs", {}) or {}


# ────────────────────────────────────────────────────────────────────────
#  Shared cache + retry/stale fallback (Phase 158 chokepoint)
# ────────────────────────────────────────────────────────────────────────


def _etl_disk_cache_settings() -> Dict[str, Any]:
    """Pod-specific settings provider for the shared QSCredCache.

    Read from ``vault_config.yaml -> secrets.vault.*`` -- ETL's own
    knobs.  Backend uses ``core.config.secrets.*`` for the same keys.
    """
    s = _vault_settings()
    return {
        "enabled": bool(s.get("disk_cache_enabled", True)),
        "path":    str(s.get("disk_cache_path", "/tmp/.etl_secrets.enc")),
        "ttl":     int(s.get("disk_cache_ttl_seconds", 86400) or 0),
        "key_env": str(s.get("disk_cache_key_env", "ETL_SECRETS_KEY")),
        "mem_ttl": int(s.get("cache_ttl_seconds", 900) or 0),
    }


# Pod-singleton instance of the shared cache.  Constructed lazily on
# first access so module import doesn't fail when ETL is loaded in
# import-only test contexts.
_cred_cache = QSCredCache(
    settings_provider=_etl_disk_cache_settings,
    plaintext_env_var="ETL_SECRETS_ALLOW_PLAINTEXT",
    logger=_logger,
)


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R4 -- periodic refresh daemon
# ────────────────────────────────────────────────────────────────────────
#
# Bounds the rotation propagation window.  The mem_ttl (default 15 min)
# already guarantees Vault rotations get picked up within 15 min on the
# happy path, but a hot secret that's continuously re-cached will never
# hit the natural TTL expiry.  This periodic invalidation forces a
# fresh fetch every ``ETL_CRED_REFRESH_HOURS`` hours (default 24h).
#
# Set ``ETL_CRED_REFRESH_HOURS=0`` to disable (tests, dev pods).
_REFRESH_HOURS = float(
    os.environ.get("ETL_CRED_REFRESH_HOURS", "24") or 24,
)
_cred_cache.start_periodic_refresh(
    _REFRESH_HOURS, name_hint="etl-cred-cache-refresh",
)


def reset_cache() -> None:
    """Drop yaml + secret caches (test hook)."""
    _vault_settings.cache_clear()
    _secret_refs.cache_clear()
    _cred_cache.reset_mem()


# Back-compat aliases -- existing call sites use these names.
def _cache_get(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_fresh(name)


def _mem_get_fresh(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_fresh(name)


def _mem_get_any(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_any(name)


def _cache_put(name: str, payload: Any, ttl_seconds: int) -> None:
    _cred_cache.mem_put(name, payload, ttl_seconds)


def invalidate(name: str) -> None:
    """Drop the cached entry for ``name`` -- call after an auth
    failure so the next resolve fetches a fresh secret."""
    _cred_cache.invalidate(name)


# ────────────────────────────────────────────────────────────────────────
#  Public API
# ────────────────────────────────────────────────────────────────────────


def _get_ref_config(name: str) -> Dict[str, Any]:
    """Look up the secret access config for ``name``; raise with
    actionable error when the name isn't registered."""
    refs = _secret_refs()
    if name not in refs:
        available = sorted(refs.keys())
        raise ValueError(
            f"secret_ref={name!r} not found in vault_config.yaml.\n"
            f"  Available refs: {available}\n"
            f"  Add an entry under configs/vault_config.yaml -> "
            f"secrets.refs.{name} with type / auth_url / role_name / "
            f"role_type / rotate_url / secret_url fields."
        )
    ref = refs[name]
    required = ("type", "auth_url", "role_name", "role_type", "secret_url")
    missing = [k for k in required if not ref.get(k)]
    if missing:
        raise ValueError(
            f"secret_ref={name!r} entry in vault_config.yaml is "
            f"missing required field(s) {missing}.  Fill in "
            f"configs/vault_config.yaml -> secrets.refs.{name}."
        )
    return ref


# ────────────────────────────────────────────────────────────────────────
#  Plain-yaml credentials fast path (2026-07-01, operator report)
# ────────────────────────────────────────────────────────────────────────
#
# Operator report: "if connection string defined and vault disabled ...
# still we should cache these oracle string credentials".
#
# Before this addition, ``_resolve_with_cache`` raised RuntimeError
# whenever vault was disabled -- even when the yaml already had literal
# user/password embedded in ``etl_connection_string`` or in the
# structured ``etl.username``/``password`` fields.  Every DAG that
# called into the resolver (dynamic_dags_airflow, daily_sod_dag, ...)
# would crash for dev DBs that weren't onboarded to vault.
#
# Fix: give the resolver a THIRD source of credentials that lives
# BETWEEN the caches and the vault fetch:
#   1. In-process cache
#   2. Disk cache
#   3. NEW: plain creds parsed from workflow_config (or auto-loaded
#      oracle_config.yaml if the caller didn't pass it)
#   4. Existing: vault-enabled check + vault fetch
#
# The cache treats plain creds identically to vault creds -- keyed by
# secret_ref, same TTL, same disk write-back.  Subsequent calls hit
# cache regardless of source.


_DEFAULT_ORACLE_CONFIG_PATHS = (
    "/usr/local/spark/pvc/code/configs/oracle_config.yaml",
    str(Path(__file__).resolve().parent.parent / "configs" / "oracle_config.yaml"),
)


def _load_oracle_config_yaml_if_available() -> Optional[Dict[str, Any]]:
    """Fallback loader when the caller didn't pass workflow_config.
    Tries the standard PVC path first, then the local repo copy.
    Returns None if neither exists -- caller falls through to vault.
    """
    # Env var override first.
    env_path = (os.environ.get("ETL_ORACLE_CONFIG_PATH") or "").strip()
    candidates = ([env_path] if env_path else []) + list(_DEFAULT_ORACLE_CONFIG_PATHS)
    for path in candidates:
        try:
            if not path or not Path(path).exists():
                continue
            with open(path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
            if isinstance(data, dict):
                return data
        except Exception as exc:
            _logger.debug(
                "plain-creds: oracle_config yaml at %s not usable: %s",
                path, exc,
            )
    return None


def _parse_userid_password_from_oledb(conn_str: str) -> Tuple[str, str]:
    """Extract (user, password) from an OLEDB-shape Oracle connection string:
    ``(DESCRIPTION=...); User Id = X; Password = Y;``
    Case-insensitive, tolerates whitespace around ``=`` and trailing ``;``.
    Returns ``("", "")`` when either field is missing or looks like a
    placeholder (``PLACEHOLDER``, ``<...>``, or empty).
    """
    import re as _re
    if not conn_str or not isinstance(conn_str, str):
        return "", ""
    m_user = _re.search(r"User\s*Id\s*=\s*([^;]+)", conn_str, _re.IGNORECASE)
    m_pass = _re.search(r"Password\s*=\s*([^;]+)", conn_str, _re.IGNORECASE)
    user = (m_user.group(1).strip() if m_user else "")
    password = (m_pass.group(1).strip() if m_pass else "")
    # Reject placeholder-style values -- if they look like a vault
    # placeholder, treat as "no plain creds" so we fall through to vault.
    def _is_placeholder(v: str) -> bool:
        vv = v.strip().upper()
        return (not vv
                or vv.startswith("<")
                or vv in ("PLACEHOLDER", "VAULT", "TBD", "TODO"))
    if _is_placeholder(user) or _is_placeholder(password):
        return "", ""
    return user, password


def _parse_userid_password_from_easyconnect(conn_str: str) -> Tuple[str, str]:
    """Extract (user, password) from an Easy Connect DSN:
    ``user/password@host:port/service``.
    Returns ``("", "")`` when the shape doesn't match.
    """
    if not conn_str or not isinstance(conn_str, str):
        return "", ""
    at_idx = conn_str.find("@")
    if at_idx <= 0:
        return "", ""
    left = conn_str[:at_idx]
    slash_idx = left.find("/")
    if slash_idx <= 0:
        return "", ""
    user = left[:slash_idx].strip()
    password = left[slash_idx + 1:].strip()
    if not user or not password:
        return "", ""
    return user, password


def _extract_plain_creds_from_workflow_config(
    workflow_config: Optional[Dict[str, Any]],
    name: str = "",
) -> Tuple[str, str, str]:
    """Look for literal user/password bound to ``name`` in oracle_config.yaml.
    Returns (user, password, tns_alias) or ("", "", "") if none matches.

    2026-07-02 -- INCIDENT FIX.  Prior implementation returned the
    FIRST plain user/password it found in ANY section, regardless of
    which ``name`` (secret_ref) was requested.  Symptom in prod:
    prewarm asked for ``starburst_cloud_acct`` -> the resolver
    matched Oracle's plain creds in oracle.etl.username/password ->
    served ORACLE creds under the STARBURST ref name (silent, wrong-
    workflow authentication).  Also: vault was never touched even
    though ``vault_enabled=true`` and the ref existed in
    vault_config.yaml.

    Scoping rule (this call):
      * Only match a section whose ``secret_ref`` explicitly equals
        the requested ``name``.
      * Sections with empty ``secret_ref`` (dev-mode where the operator
        left the binding unset) match ONLY when ``name`` starts with
        an Oracle-namespace prefix (``etl_oracle_`` / ``oracle_`` /
        ``dest_``) so foreign-namespace refs (starburst_/s3_/sap_/...)
        never get served Oracle creds silently.  A blank ``name``
        argument (legacy caller) preserves pre-2026-07-02 behaviour
        and matches unbound sections without a prefix check.
      * Connection-string forms (``etl_connection_string`` /
        ``dest_connection_string``) live at the ``oracle.*`` top level
        so they inherit the same scoping via the section's parent.

    Priority order within the config (first MATCHING section wins):
      1. oracle.etl               (secret_ref should equal ``name``)
      2. oracle.destination       (secret_ref should equal ``name``)
      3. oracle.etl_connection_string
      4. oracle.dest_connection_string

    Placeholder-looking values ("PLACEHOLDER", "<vault>", empty) are
    treated as absent so the caller falls through to vault.
    """
    if not isinstance(workflow_config, dict):
        return "", "", ""
    # workflow_config may be either the FULL yaml ({"oracle": {...}, ...})
    # or the ORACLE section itself ({"etl": {...}, "destination": {...}}).
    oracle = workflow_config.get("oracle")
    if not isinstance(oracle, dict):
        oracle = workflow_config    # assume caller passed oracle section directly

    _ORACLE_NAMESPACE_PREFIXES = ("etl_oracle_", "oracle_", "dest_")

    def _section_matches(section: Any) -> bool:
        """Decide if ``section`` is bound to serve creds for ``name``.

        A missing (None) section is treated as "unbound" -- e.g. yaml
        with only ``oracle.etl_connection_string`` at the top level
        (no sub-dict).  The name-scoping rules for unbound sections
        still apply.
        """
        section_ref = ""
        if isinstance(section, dict):
            section_ref = (section.get("secret_ref") or "").strip()
        if section_ref:
            # Explicit binding wins -- must match exactly.
            return section_ref == name
        # Unbound section (dev mode).  Legacy no-name callers keep
        # the old "any section can serve" behaviour so downstream
        # non-prewarm call sites are undisturbed.
        if not name:
            return True
        # Foreign-namespace refs are refused -- prevents the incident
        # where oracle.etl silently authenticated a Starburst ref.
        return any(name.startswith(pfx) for pfx in _ORACLE_NAMESPACE_PREFIXES)

    def _from_section(section: Any) -> Tuple[str, str, str]:
        if not isinstance(section, dict):
            return "", "", ""
        if not _section_matches(section):
            return "", "", ""
        u = (section.get("username") or "").strip()
        p = (section.get("password") or "").strip()
        if u and p:
            host = (section.get("host") or "").strip()
            svc = (section.get("service") or "").strip()
            try:
                port = int(section.get("port")) if section.get("port") else 1521
            except (TypeError, ValueError):
                port = 1521
            tns = f"{host}:{port}/{svc}" if host and svc else ""
            return u, p, tns
        return "", "", ""

    # Structured ETL section
    u, p, tns = _from_section(oracle.get("etl"))
    if u and p:
        return u, p, tns
    # Structured destination section
    u, p, tns = _from_section(oracle.get("destination"))
    if u and p:
        return u, p, tns
    # OLEDB or Easy Connect string forms -- inherit scoping from the
    # PARENT section.  The `oracle.etl_connection_string` string sits
    # alongside `oracle.etl.secret_ref`; the string is "bound" to the
    # etl section, so its scoping key is that section's secret_ref.
    _cs_binding = {
        "etl_connection_string":  oracle.get("etl"),
        "dest_connection_string": oracle.get("destination"),
    }
    for cs_key, parent_section in _cs_binding.items():
        cs = oracle.get(cs_key) or ""
        if not isinstance(cs, str) or not cs.strip():
            continue
        if not _section_matches(parent_section):
            continue
        # Try OLEDB shape first (has "User Id=" and "Password=")
        u, p = _parse_userid_password_from_oledb(cs)
        if u and p:
            return u, p, ""
        # Try Easy Connect shape
        u, p = _parse_userid_password_from_easyconnect(cs)
        if u and p:
            return u, p, ""
    return "", "", ""


def _resolve_with_cache(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Any:
    """Cache-aware resolver -- single point of Vault traffic.

    Phase 158 (2026-06-26) -- delegates the cache + retry + stale
    fallback to the shared ``QSCredCache`` instance so this function
    only owns ETL-specific concerns (vault toggle, ref lookup,
    machine/token-method from yaml).

    2026-07-01 (operator report) -- added plain-yaml-creds fast path
    between disk-cache and vault so dev DBs with literal user/password
    in oracle_config.yaml work WITHOUT touching vault.

    Linear flow:
      1. In-process cache fresh?          hit -> return
      2. Disk cache fresh?                hit -> warm memory + return
      3. Plain creds in workflow_config (or oracle_config.yaml)?
                                          hit -> cache + return  [NEW]
      4. vault enabled?  (env var > workflow yaml > global yaml)
                                          no  -> raise (operator bug)
      5. Vault fetch (retry + stale-fallback inside ``fetch_with_fallback``)
    """
    # Layer 1: in-process cache (only fresh entries) -- both vault creds
    # AND plain-yaml creds land here so this hits regardless of source.
    fresh = _cred_cache.mem_get_fresh(name)
    if fresh is not None:
        try:
            _LAST_RESOLVE_SOURCE_CV.set("mem")
        except LookupError:
            pass
        return fresh

    # Layer 2: disk cache (only fresh entries)
    disk_fresh = _cred_cache.disk_get_fresh(name)
    if disk_fresh is not None:
        ttl_proc = int(_etl_disk_cache_settings().get("mem_ttl", 0) or 0)
        _cred_cache.mem_put(name, disk_fresh, ttl_proc)
        try:
            _LAST_RESOLVE_SOURCE_CV.set("disk")
        except LookupError:
            pass
        return disk_fresh

    # Layer 3 (NEW 2026-07-01): plain-creds fast path.  Look at the
    # yaml the operator gave us.  If both user + password are literal
    # (not placeholder), cache them under the ref name and return --
    # this closes the "dev DB not onboarded to vault" gap without
    # touching every DAG.
    #
    # Uses the passed workflow_config first (explicit), falls back to
    # auto-loading oracle_config.yaml from the standard PVC path so
    # DAGs that call resolve_db_account(name) with NO config (see
    # dynamic_dags_airflow.py:70) still benefit.
    cfg_for_lookup = workflow_config
    if cfg_for_lookup is None:
        cfg_for_lookup = _load_oracle_config_yaml_if_available()
    plain_user, plain_password, plain_tns = (
        _extract_plain_creds_from_workflow_config(cfg_for_lookup, name=name)
    )
    if plain_user and plain_password:
        # Cache under the ref name identically to vault creds.
        # tns_alias goes third so resolve_db_account_with_tns unpacks
        # cleanly.
        payload = (plain_user, plain_password, plain_tns)
        # Use the same TTL as vault entries so subsequent calls hit
        # cache.  Zero TTL means "cache-lifetime" per QSCredCache.
        ttl_proc = int(_etl_disk_cache_settings().get("mem_ttl", 0) or 0)
        _cred_cache.mem_put(name, payload, ttl_proc)
        try:
            _LAST_RESOLVE_SOURCE_CV.set("plain")
        except LookupError:
            pass
        _logger.info(
            "qs_credentials.resolver: served plain creds from "
            "oracle_config.yaml for secret_ref=%r (vault not touched)",
            name,
        )
        return payload

    # Layer 4: vault-enabled toggle (only reached when NO plain creds
    # were found -- so raise is appropriate).
    #
    # 2026-07-01 fix (2nd part of same incident): pass
    # ``cfg_for_lookup`` here -- not the original ``workflow_config``.
    # When the caller was a DAG that supplied None (see
    # dynamic_dags_airflow.py:70), Layer 3 auto-loaded oracle_config.yaml
    # into ``cfg_for_lookup`` but the ORIGINAL parameter stayed None,
    # so ``is_vault_enabled(workflow_config)`` couldn't see
    # ``oracle.vault_enabled: false`` -- Layer 2 in is_vault_enabled
    # was silently skipped for every DAG caller.  Threading
    # cfg_for_lookup closes that gap.
    if not is_vault_enabled(cfg_for_lookup):
        raise RuntimeError(
            f"secret_ref={name!r} requested but vault resolution is "
            f"DISABLED and no plain creds found in oracle_config.yaml.\n"
            f"Three places control the vault toggle:\n"
            f"  1. ETL_USE_VAULT env var (set '1' to force ON, "
            f"'0' to force OFF)\n"
            f"  2. per-workflow yaml: vault_enabled in starburst_config "
            f"/ oracle_config / s3_config\n"
            f"  3. global yaml: secrets.enabled in vault_config.yaml\n"
            f"For dev without vault: fill literal user/password in yaml "
            f"under oracle.etl.username/password OR embed User Id + "
            f"Password directly into oracle.etl_connection_string."
        )

    # Layer 3: Vault (retry + last-known-good inside QSCredCache)
    ref = _get_ref_config(name)
    vault_settings = _vault_settings()

    # 2026-06-27 -- ``machine`` is a per-pod-environment value (which
    # token endpoint to hit), NOT a per-secret value.  Resolution order:
    #   1. ETL_VAULT_MACHINE env var  -- Airflow / spark-submit / local
    #      override.  Set this per pod so the SAME yaml works across
    #      Airflow driver pods (tprd), polling-service pods (tprd), and
    #      local dev (test).  Avoids forking vault_config.yaml per env.
    #   2. ``secrets.vault.machine`` in vault_config.yaml  -- global
    #      default for installations that don't vary by pod.
    #   3. "tprd"  -- final fallback (production OpenShift behaviour).
    machine = (
        os.environ.get("ETL_VAULT_MACHINE", "").strip().lower()
        or (vault_settings.get("machine") or "").strip().lower()
        or "tprd"
    )

    # 2026-06-27 -- token_method also per-pod-environment when needed.
    token_method = (
        os.environ.get("ETL_VAULT_TOKEN_METHOD", "").strip()
        or vault_settings.get("token_method", "JWT")
    )
    payload = _cred_cache.fetch_with_fallback(
        name, ref, machine=machine, token_method=token_method,
    )
    try:
        _LAST_RESOLVE_SOURCE_CV.set("vault")
    except LookupError:
        pass
    return payload


# Disk cache test-hook -- delegates to the shared instance.
def disk_cache_clear() -> None:
    """Wipe the disk cache file + sidecar key (test hook + manual
    rotation trigger).  Delegates to the shared QSCredCache."""
    _cred_cache.disk_clear()


# Back-compat aliases for any older caller / test that pokes the disk
# layer directly.  All forward to the shared QSCredCache instance.
def _disk_cache_get(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_fresh(name)


def _disk_cache_get_any(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_any(name)


def _disk_cache_put(name: str, payload: Any) -> None:
    _cred_cache.disk_put(name, payload)


def _disk_cache_settings() -> Dict[str, Any]:
    """Back-compat: returns the ETL settings dict (tests + old callers)."""
    return _etl_disk_cache_settings()


def _is_valid_payload(payload: Any, secret_type: str) -> bool:
    """Back-compat alias to the shared chokepoint validator."""
    return is_valid_vault_payload(payload, secret_type)


def resolve_db_account(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str]:
    """Fetch DB account creds via Vault (QSClient).

    Returns ``(user, password)``.  Used for Oracle DB schema creds.

    Args:
      name: secret_ref name registered in vault_config.yaml.
      workflow_config: per-workflow yaml dict for the vault_enabled
        flag check (e.g., the ``oracle`` section dict).
    """
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, (tuple, list)) and len(payload) >= 2:
        return str(payload[0]), str(payload[1])
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected (user, password) tuple, got {type(payload).__name__})."
    )


def resolve_db_account_with_tns(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str, str]:
    """Variant that also returns tns_alias."""
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, (tuple, list)) and len(payload) >= 3:
        return str(payload[0]), str(payload[1]), str(payload[2])
    if isinstance(payload, (tuple, list)) and len(payload) >= 2:
        return str(payload[0]), str(payload[1]), ""
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected (user, password, tns_alias) tuple, got {type(payload).__name__})."
    )


def resolve_ad_account(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str]:
    """Fetch AD account creds (e.g., Starburst service account)."""
    return resolve_db_account(name, workflow_config)


def resolve_kv_secret(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Fetch a kv-store secret (AWS keys, API tokens, ...)."""
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, dict):
        return payload
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected dict for kv_secrets, got {type(payload).__name__})."
    )


def fill_creds_from_ref(
    config: Dict[str, Any],
    *,
    user_key: str,
    password_key: str,
    ref_key: str = "secret_ref",
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Helper for config loaders.

    If ``config[user_key]`` OR ``config[password_key]`` is blank AND
    ``config[ref_key]`` is set, resolve via vault and fill the blanks.
    Per-job literal values ALWAYS win when set -- vault only fills blanks.

    In-place mutation; returns the same dict for chaining.

    Raises ValueError when ref is set but resolution fails (operator
    sees the actionable Vault error).
    """
    log = logger or _logger
    user_val = config.get(user_key) or ""
    pass_val = config.get(password_key) or ""
    ref = (config.get(ref_key) or "").strip()

    if not ref:
        return config  # no vault ref -- literal values stand
    if user_val and pass_val:
        return config  # both filled in literal -- no need to hit vault

    try:
        user, password = resolve_db_account(ref)
    except (ValueError, RuntimeError) as exc:
        # Re-raise with context but don't swallow.
        raise

    if not user_val:
        config[user_key] = user
    if not pass_val:
        config[password_key] = password

    log.info(
        "Resolved secret_ref=%s via vault (filled %s%s%s)",
        ref,
        user_key if not user_val else "",
        ", " if not user_val and not pass_val else "",
        password_key if not pass_val else "",
    )
    return config


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R4 -- auth-failure refresh + retry helpers
# ────────────────────────────────────────────────────────────────────────


def refresh(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Any:
    """Drop the cached entry for ``name`` and re-resolve from Vault.

    Use this when an auth attempt with cached creds returned a
    password-failure error -- e.g., Oracle ORA-01017 (invalid
    user/password) or Starburst 401.  The cache may be holding a
    pre-rotation credential; this forces a fresh fetch.

    Returns the freshly-resolved payload (tuple for DB/AD, dict for
    kv).  Raises with the actionable cause if Vault is also down.
    """
    _cred_cache.invalidate(name)
    _logger.info(
        "qs_credentials.refresh: cache invalidated for secret_ref=%r "
        "(auth failure suspected) -- re-fetching from Vault.", name,
    )
    return _resolve_with_cache(name, workflow_config)


def resolve_with_auth_retry(
    name: str,
    auth_callable,
    *,
    workflow_config: Optional[Dict[str, Any]] = None,
    secret_type: str = "AD_accounts",
):
    """Resolve creds + call ``auth_callable(creds)``.  If the call
    raises (typical: driver auth failure), drop the cache + re-fetch
    fresh creds + retry ONCE.  Re-raises on the second failure.

    Apply rule: use this wrapper around DB driver / connector
    constructors so a rotated-password incident self-heals on the
    NEXT request rather than the next mem_ttl expiry (15 min default).

    Example::

        from qs_credentials import resolve_with_auth_retry

        def _open_oracle(creds):
            return oracledb.connect(
                user=creds[0], password=creds[1], dsn=tns,
            )

        conn = resolve_with_auth_retry(
            "dest_oracle", _open_oracle,
            secret_type="DB_accounts",
        )

    Args:
      name:           secret_ref name.
      auth_callable:  callable taking the resolved creds tuple/dict and
                      returning the authenticated object (connection,
                      client, ...) or raising on failure.
      workflow_config: per-workflow vault_enabled toggle dict.
      secret_type:    ``DB_accounts`` / ``AD_accounts`` (returns tuple)
                      or ``kv_secrets`` (returns dict).  Drives which
                      resolver function to call.

    Returns whatever ``auth_callable`` returns on success.
    Raises the second auth_callable exception when retry also fails.
    """
    def _resolve_one():
        if secret_type == "kv_secrets":
            return resolve_kv_secret(name, workflow_config)
        # default DB/AD shape
        if secret_type == "DB_accounts":
            payload = _resolve_with_cache(name, workflow_config)
            # Preserve tns_alias slot when present.
            if isinstance(payload, (tuple, list)):
                if len(payload) >= 3:
                    return (str(payload[0]), str(payload[1]),
                            str(payload[2]))
                if len(payload) >= 2:
                    return (str(payload[0]), str(payload[1]))
        return resolve_ad_account(name, workflow_config)

    creds = _resolve_one()
    try:
        return auth_callable(creds)
    except Exception as exc:
        # First failure -- could be auth (cached stale password) OR
        # something else (network, syntax, ...).  Either way we drop
        # the cache to be safe, re-fetch, retry ONCE.  If the cause
        # was non-auth, the retry will hit the same error + raise.
        # Inline invalidate + re-resolve (NOT refresh()) so we make
        # exactly TWO resolve calls total, not three -- refresh()
        # would do its own internal resolve before _resolve_one().
        _logger.warning(
            "resolve_with_auth_retry: secret_ref=%r auth attempt "
            "raised %s: %s -- refreshing cache + retrying once.",
            name, type(exc).__name__, exc,
        )
        _cred_cache.invalidate(name)
        creds = _resolve_one()
        return auth_callable(creds)  # raises if still bad
