import { appConfirm } from './common/appDialogs';
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Autocomplete, InputAdornment, Select, MenuItem, FormControl, InputLabel,
  FormControlLabel, Switch,
} from '@mui/material';
import {
  VpnKey as KeyIcon, Delete as DeleteIcon, Add as AddIcon,
  ContentCopy as CopyIcon, Refresh as RefreshIcon, AllInclusive as NeverIcon,
  Visibility as RevealIcon, Badge as IdentityIcon,
} from '@mui/icons-material';

const EXPIRY_OPTIONS = [
  { label: 'Never expires', value: '' },
  { label: '30 days',       value: String(30 * 24) },
  { label: '90 days',       value: String(90 * 24) },
  { label: '1 year',        value: String(365 * 24) },
  { label: '2 years',       value: String(2 * 365 * 24) },
  { label: 'Custom (hours)', value: '__custom__' },
];
import api from '../services/api';
import ListPager, { clientPage } from './common/ListPager';

interface ApiKeyItem {
  id: number;
  key_prefix: string;
  name: string;
  created_by: string | null;
  // 2026-10-17 -- a key's FACE (design §3.3): the team / system it
  // represents, the person answerable, a contact address.  Edited through
  // PUT /api/api-keys/{id}/identity; the inventory's consumer column reads them.
  consumer?: string | null;
  owner_username?: string | null;
  contact_email?: string | null;
  // May contain the explicit global sentinel "*" / -1 (2026-08-17 P1), and
  // may be null on legacy rows.
  scoped_view_ids: (number | string)[] | null;
  rate_limit: string | null;
  // 2026-10-18 -- the limit the consumer is HELD to: the operator's
  // published_views.max_rate_limit caps every key (the enforcement and this
  // display read ONE function, core/published_api/rate_limits.py)
  effective_rate_limit?: string | null;
  rate_limit_capped?: boolean | null;
  rate_limit_cap_reason?: string | null;
  is_active: boolean;
  expires_at: string | null;
  created_at: string | null;
  last_used_at: string | null;
  usage_count: number;
}

// Mirrors backend helpers._GLOBAL_SCOPE_MARKERS — the EXPLICIT all-views
// sentinel a deliberately-global key carries in its scope list.
const isGlobalScope = (scoped: (number | string)[] | null): boolean =>
  (scoped || []).some(s => s === '*' || s === -1 || s === '-1');

interface PublishedView {
  id: number;
  slug: string;
  name: string;
}

/** ``embedded``: rendered inside the Published APIs page's "Consumers & keys"
 *  tab (2026-10-17) -- no outer padding, a section heading instead of the page title. */
const ApiKeysPage = ({ embedded = false }: { embedded?: boolean } = {}) => {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  // identity (consumer / owner / contact) on create and on edit
  const [newConsumer, setNewConsumer] = useState('');
  const [newOwner, setNewOwner] = useState('');
  const [newContact, setNewContact] = useState('');
  const [identityKey, setIdentityKey] = useState<ApiKeyItem | null>(null);
  const [idConsumer, setIdConsumer] = useState('');
  const [idOwner, setIdOwner] = useState('');
  const [idContact, setIdContact] = useState('');
  const [idSaving, setIdSaving] = useState(false);
  // Revoked keys are history, not something to act on: hidden unless asked
  // for (the rig had 124 revoked beside 26 live ones, in one list).
  const [showRevoked, setShowRevoked] = useState(false);
  // Pages (2026-10-13, "pagination in all grids"): keys grow with use.
  const [keyPage, setKeyPage] = useState(1);
  const [keyPageSize, setKeyPageSize] = useState(50);
  const [views, setViews] = useState<PublishedView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Create dialog
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newScoped, setNewScoped] = useState<PublishedView[]>([]);
  const [newRateLimit, setNewRateLimit] = useState('');
  const [newExpiryOption, setNewExpiryOption] = useState('');       // '' = never
  const [newExpiresHours, setNewExpiresHours] = useState('');       // custom hours
  const [creating, setCreating] = useState(false);

  // Key reveal dialog
  const [revealedKey, setRevealedKey] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [k, v] = await Promise.all([
        api.listApiKeys(),
        api.listPublishedViews(),
      ]);
      setKeys(Array.isArray(k) ? k : []);
      setViews(Array.isArray(v) ? v : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      // Resolve expiry hours: '' = never, preset = preset value, custom = user input
      const resolvedHours =
        newExpiryOption === '' ? undefined :
        newExpiryOption === '__custom__' ? (newExpiresHours ? Number(newExpiresHours) : undefined) :
        Number(newExpiryOption);
      const result = await api.createApiKey({
        name: newName.trim(),
        scoped_view_ids: newScoped.map(v => v.id),
        rate_limit: newRateLimit.trim() || undefined,
        expires_hours: resolvedHours,
        consumer: newConsumer.trim() || undefined,
        owner_username: newOwner.trim() || undefined,
        contact_email: newContact.trim() || undefined,
      });
      setShowCreate(false);
      setNewName('');
      setNewScoped([]);
      setNewRateLimit('');
      setNewExpiryOption('');
      setNewExpiresHours('');
      setNewConsumer('');
      setNewOwner('');
      setNewContact('');
      // Show the raw key
      if (result.raw_key) {
        setRevealedKey(result.raw_key);
      }
      loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleRevoke = async (id: number) => {
    if (!await appConfirm('Revoke this API key? This cannot be undone.')) return;
    try {
      await api.revokeApiKey(id);
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleReveal = async (id: number) => {
    try {
      const res = await api.revealApiKey(id);
      if (res?.raw_key) setRevealedKey(res.raw_key);
      else setError('Raw key not available for this key');
    } catch (err: any) {
      setError(err.message || 'Failed to reveal key');
    }
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
  };

  const openIdentity = (k: ApiKeyItem) => {
    setIdentityKey(k);
    setIdConsumer(k.consumer || '');
    setIdOwner(k.owner_username || '');
    setIdContact(k.contact_email || '');
  };

  const saveIdentity = async () => {
    if (!identityKey) return;
    setIdSaving(true);
    try {
      await (api as any).setApiKeyIdentity(identityKey.id, {
        consumer: idConsumer.trim() || null,
        owner_username: idOwner.trim() || null,
        contact_email: idContact.trim() || null,
      });
      setIdentityKey(null);
      loadData();
    } catch (err: any) {
      setError(err.message || 'The identity could not be saved');
    } finally {
      setIdSaving(false);
    }
  };

  const viewNameMap = new Map(views.map(v => [v.id, v.name]));
  const revokedCount = keys.filter(k => !k.is_active).length;
  const shownKeys = showRevoked ? keys : keys.filter(k => k.is_active);
  const pagedKeys = clientPage(shownKeys, keyPage, keyPageSize);

  return (
    <Box sx={embedded ? {} : { p: 3, maxWidth: 1200, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: embedded ? 1 : 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <KeyIcon />
          <Typography variant={embedded ? 'h6' : 'h5'} fontWeight={600}>API Keys</Typography>
        </Box>
        <Stack direction="row" spacing={1} alignItems="center">
          {revokedCount > 0 && (
            <FormControlLabel
              control={<Switch size="small" checked={showRevoked} onChange={e => { setShowRevoked(e.target.checked); setKeyPage(1); }} />}
              label={`Show revoked (${revokedCount})`}
            />
          )}
          <Button startIcon={<RefreshIcon />} onClick={loadData} size="small">Refresh</Button>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setShowCreate(true)} size="small">
            Create Key
          </Button>
        </Stack>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : shownKeys.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            {revokedCount > 0
              ? `No active API keys. ${revokedCount} revoked key${revokedCount === 1 ? ' is' : 's are'} hidden -- "Show revoked" lists them.`
              : 'No API keys yet. Create one to allow external systems to access published views.'}
          </Typography>
        </Paper>
      ) : (
        <Paper variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Name</strong></TableCell>
                <TableCell><strong>Consumer · owner · contact</strong></TableCell>
                <TableCell><strong>Prefix</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
                <TableCell><strong>Scoped Views</strong></TableCell>
                <TableCell><strong>Rate Limit</strong></TableCell>
                <TableCell><strong>Usage</strong></TableCell>
                <TableCell><strong>Last Used</strong></TableCell>
                <TableCell><strong>Expires</strong></TableCell>
                <TableCell align="right"><strong>Actions</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pagedKeys.rows.map(k => (
                <TableRow key={k.id} sx={{ opacity: k.is_active ? 1 : 0.5 }}>
                  <TableCell>
                    <Typography variant="body2" fontWeight={500}>{k.name}</Typography>
                    <Typography variant="caption" color="text.secondary">{k.created_by || '-'}</Typography>
                  </TableCell>
                  <TableCell data-testid={`key-identity-${k.id}`}>
                    {k.consumer || k.owner_username || k.contact_email ? (
                      <>
                        <Typography variant="body2">{k.consumer || <em style={{ opacity: 0.6 }}>no consumer named</em>}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {k.owner_username || 'no owner'}{k.contact_email ? ` · ${k.contact_email}` : ''}
                        </Typography>
                      </>
                    ) : (
                      <Tooltip title="Who is this key? Name the team / system, the person answerable and a contact address -- the inventory and the alerts read them.">
                        <Chip size="small" variant="outlined" color="warning" label="identity not recorded" />
                      </Tooltip>
                    )}
                  </TableCell>
                  <TableCell><code style={{ fontSize: 11 }}>{k.key_prefix}...</code></TableCell>
                  <TableCell>
                    <Chip
                      label={k.is_active ? 'Active' : 'Revoked'}
                      size="small"
                      color={k.is_active ? 'success' : 'default'}
                    />
                  </TableCell>
                  <TableCell>
                    {/* 2026-08-23 (P6 D10) — since the 2026-08-17 P1 fix an EMPTY
                        scope means NO views (fail-closed), not every view; "all
                        views" is only the explicit "*" / -1 sentinel.  The old
                        render said "All views" for an empty scope — the exact
                        inverse of what the key can reach. */}
                    {isGlobalScope(k.scoped_view_ids)
                      ? <Chip label="All views (global key)" size="small" color="warning" variant="outlined" />
                      : (k.scoped_view_ids || []).length > 0
                        ? (k.scoped_view_ids || []).map(id => (
                            <Chip key={String(id)} label={viewNameMap.get(id as number) || `#${id}`} size="small" sx={{ mr: 0.5, mb: 0.5 }} />
                          ))
                        : <Tooltip title="Empty scope grants access to NO views. Re-create the key with explicit view ids, or as an explicit global key.">
                            <Chip label="No views (empty scope)" size="small" color="error" variant="outlined" />
                          </Tooltip>
                    }
                  </TableCell>
                  <TableCell data-testid={`key-rate-limit-${k.id}`}>
                    {k.effective_rate_limit ? (
                      <>
                        <Typography variant="caption">{k.effective_rate_limit}</Typography>
                        {k.rate_limit_capped && (
                          <Tooltip title={`${k.rate_limit_cap_reason || 'capped by the operator'}; the key declares ${k.rate_limit}`}>
                            <Chip size="small" color="warning" variant="outlined" label="capped" sx={{ ml: 0.5, height: 18, fontSize: 10 }} />
                          </Tooltip>
                        )}
                        {!k.rate_limit && !k.rate_limit_capped && (
                          <Typography variant="caption" color="text.secondary"> (default)</Typography>
                        )}
                      </>
                    ) : (
                      <Typography variant="caption">{k.rate_limit || 'Default'}</Typography>
                    )}
                  </TableCell>
                  <TableCell>{k.usage_count}</TableCell>
                  <TableCell>
                    <Typography variant="caption">
                      {k.last_used_at ? new Date(k.last_used_at).toLocaleString() : 'Never'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {k.expires_at
                      ? <Typography variant="caption">{new Date(k.expires_at).toLocaleDateString()}</Typography>
                      : <Chip icon={<NeverIcon />} label="Never expires" size="small" color="success" variant="outlined" />
                    }
                  </TableCell>
                  <TableCell align="right">
                    {k.is_active && (
                      <>
                        <Tooltip title="Who is this key? (consumer, owner, contact)">
                          <IconButton size="small" onClick={() => openIdentity(k)} aria-label={`Identity of ${k.name}`}>
                            <IdentityIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Reveal raw key (admin)">
                          <IconButton size="small" onClick={() => handleReveal(k.id)}>
                            <RevealIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Revoke key">
                          <IconButton size="small" color="error" onClick={() => handleRevoke(k.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={pagedKeys.paging} onPage={setKeyPage} onPageSize={setKeyPageSize}
                     testid="api-keys-pager" />
        </Paper>
      )}

      {/* Create Key Dialog */}
      <Dialog open={showCreate} onClose={() => setShowCreate(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create API Key</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Key Name"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              fullWidth size="small"
              placeholder="e.g., Risk Team ETL Pipeline"
            />
            <Autocomplete
              multiple size="small"
              options={views}
              getOptionLabel={v => `${v.name} (${v.slug})`}
              value={newScoped}
              onChange={(_, v) => setNewScoped(v)}
              renderInput={params => (
                <TextField {...params} label="Scoped Views" placeholder="Leave empty for all views" />
              )}
            />
            <Stack direction="row" spacing={1}>
              <TextField label="Consumer (team / system)" value={newConsumer} onChange={e => setNewConsumer(e.target.value)}
                         size="small" sx={{ flex: 1 }} placeholder="e.g., Risk Reporting" inputProps={{ 'data-testid': 'new-key-consumer' }} />
              <TextField label="Owner (username)" value={newOwner} onChange={e => setNewOwner(e.target.value)}
                         size="small" sx={{ flex: 1 }} placeholder="who answers for it" />
            </Stack>
            <TextField label="Contact e-mail" value={newContact} onChange={e => setNewContact(e.target.value)}
                       fullWidth size="small" placeholder="told of deprecations, sunsets, retirements" />
            <TextField
              label="Rate Limit (optional)"
              value={newRateLimit}
              onChange={e => setNewRateLimit(e.target.value)}
              fullWidth size="small"
              placeholder="e.g., 120/minute"
              helperText="Leave empty for default rate limit"
            />
            <FormControl fullWidth size="small">
              <InputLabel id="sel-apikeyspage-expiration">Expiration</InputLabel>
              <Select labelId="sel-apikeyspage-expiration"
                value={newExpiryOption}
                label="Expiration"
                onChange={e => { setNewExpiryOption(e.target.value); setNewExpiresHours(''); }}
              >
                {EXPIRY_OPTIONS.map(o => (
                  <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            {newExpiryOption === '__custom__' && (
              <TextField
                label="Custom expiry (hours)"
                value={newExpiresHours}
                onChange={e => setNewExpiresHours(e.target.value)}
                fullWidth size="small" type="number"
                helperText="e.g. 720 = 30 days"
              />
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCreate(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={creating || !newName.trim()}>
            {creating ? 'Creating...' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Identity dialog -- who the key is (2026-10-17) */}
      <Dialog open={!!identityKey} onClose={() => setIdentityKey(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Who is this key? {identityKey?.name}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Consumer (team / system)" value={idConsumer} onChange={e => setIdConsumer(e.target.value)}
                       size="small" fullWidth inputProps={{ 'data-testid': 'identity-consumer' }} />
            <TextField label="Owner (username)" value={idOwner} onChange={e => setIdOwner(e.target.value)} size="small" fullWidth
                       helperText="told in the bell when this consumer's API changes or breaks" />
            <TextField label="Contact e-mail" value={idContact} onChange={e => setIdContact(e.target.value)} size="small" fullWidth
                       helperText="told by e-mail of deprecations, sunsets and retirements" />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIdentityKey(null)}>Cancel</Button>
          <Button variant="contained" onClick={saveIdentity} disabled={idSaving} data-testid="identity-save">{idSaving ? 'Saving...' : 'Save'}</Button>
        </DialogActions>
      </Dialog>

      {/* Key Reveal Dialog */}
      <Dialog open={!!revealedKey} onClose={() => setRevealedKey('')} maxWidth="sm" fullWidth>
        <DialogTitle>API Key</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            Treat this key as a password. It can be re-revealed later by an admin from this page.
          </Alert>
          <TextField
            fullWidth size="small"
            value={revealedKey}
            inputProps={{ 'aria-label': 'API key' }}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => copyKey(revealedKey)} size="small" aria-label="Copy API key">
                    <CopyIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              ),
              sx: { fontFamily: 'monospace', fontSize: 13 },
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button variant="contained" onClick={() => setRevealedKey('')}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ApiKeysPage;
