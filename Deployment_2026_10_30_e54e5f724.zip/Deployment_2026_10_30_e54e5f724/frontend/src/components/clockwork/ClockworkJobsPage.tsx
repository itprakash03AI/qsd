/**
 * ClockworkJobsPage — every scheduled job, with what an operator needs to
 * tell at a glance whether it is alive: enabled, the schedule (cron, a
 * reading of it, the timezone), the next occurrence, the last outcome,
 * the owner, the target connection and the credential health MEASURED ON
 * THE CLOCKWORK POD.
 *
 * An empty table says WHY it is empty.  "No jobs", "you are not entitled
 * to see any" and "the backend could not be reached" are three different
 * findings that lead to three different next steps, and a 200 with an
 * empty list is the only one of them that means the scheduler has nothing
 * to run.  Unknown is never rendered as none: a job whose next occurrence
 * or last outcome the server did not send shows "not reported", not "—",
 * and when the FIRE LOG itself could not be read (the list says so in
 * `fire_log`) every null `last_fire` reads "fire log unreadable", never
 * "never fired".
 */
import { appConfirm } from '../common/appDialogs';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, FormControlLabel, IconButton,
  InputAdornment, MenuItem, Paper, Select, Stack, Switch, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, TextField, Tooltip,
  Typography,
} from '@mui/material';
import {
  Add as AddIcon, Search as SearchIcon, Refresh as RefreshIcon,
  History as HistoryIcon, Edit as EditIcon, PlayArrow as FireIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import type { ClockworkJobSummary, FireLogAvailability } from '../../services/api/clockwork';
import { useClockworkAccess } from '../../context/ClockworkAccessContext';
import { describeCronExpression } from './clockworkCron';
import { FireStatusChip, fmtDt, healthLook } from './fireStatus';
import ListPager, { clientPage } from '../common/ListPager';

type Load =
  | { phase: 'loading' }
  | { phase: 'ready'; jobs: ClockworkJobSummary[]; total: number; fireLog: FireLogAvailability | null }
  | { phase: 'forbidden'; message: string }
  | { phase: 'unreachable'; message: string };

type EnabledFilter = 'all' | 'enabled' | 'disabled';
type OutcomeFilter = 'all' | 'SUCCESS' | 'FAILED' | 'UNKNOWN' | 'CLAIMED' | 'REFUSED' | 'SKIPPED_MISSED' | 'never';

const idempotentLabel = (v: boolean | null): string =>
  v === true ? 'idempotent' : v === false ? 'not idempotent' : 'idempotency unknown';

const ClockworkJobsPage: React.FC = () => {
  const navigate = useNavigate();
  const access = useClockworkAccess();
  const [load, setLoad] = useState<Load>({ phase: 'loading' });
  const [search, setSearch] = useState('');
  const [enabledFilter, setEnabledFilter] = useState<EnabledFilter>('all');
  const [outcomeFilter, setOutcomeFilter] = useState<OutcomeFilter>('all');
  const [healthFilter, setHealthFilter] = useState<string>('all');
  const [actionError, setActionError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const refresh = useCallback(() => {
    setLoad({ phase: 'loading' });
    api.clockwork.listJobs()
      .then(res => {
        const jobs = Array.isArray(res?.jobs) ? res.jobs : null;
        if (!jobs) {
          setLoad({ phase: 'unreachable', message: 'the server answered without a jobs list' });
          return;
        }
        // A missing `fire_log` block is "not stated", which is not "available".
        const fl = res.fire_log && typeof res.fire_log === 'object' ? res.fire_log : null;
        setLoad({ phase: 'ready', jobs, total: typeof res.total === 'number' ? res.total : jobs.length, fireLog: fl });
      })
      .catch(err => {
        if (err?.status === 403 || err?.status === 401) {
          setLoad({ phase: 'forbidden', message: err?.message || 'not entitled' });
        } else {
          setLoad({ phase: 'unreachable', message: err?.message || 'the backend could not be reached' });
        }
      });
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const visible = useMemo(() => {
    if (load.phase !== 'ready') return [];
    const q = search.trim().toLowerCase();
    return load.jobs.filter(j => {
      if (enabledFilter === 'enabled' && !j.enabled) return false;
      if (enabledFilter === 'disabled' && j.enabled) return false;
      if (outcomeFilter === 'never' && j.last_fire) return false;
      if (outcomeFilter !== 'all' && outcomeFilter !== 'never' && j.last_fire?.status !== outcomeFilter) return false;
      if (healthFilter !== 'all' && j.health?.state !== healthFilter) return false;
      if (q) {
        const hay = [j.name, j.owner, j.cron, j.timezone, j.connection?.name || '',
                     describeCronExpression(j.cron)].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [load, search, enabledFilter, outcomeFilter, healthFilter]);
  // A new search or filter starts again at page 1; the list is filtered first, then paged.
  useEffect(() => { setPage(1); }, [search, enabledFilter, outcomeFilter, healthFilter]);
  const shown = clientPage(visible, page, pageSize);

  const toggleEnabled = (j: ClockworkJobSummary) => {
    setBusyId(j.id); setActionError(null);
    api.clockwork.setEnabled(j.id, !j.enabled)
      .then(() => refresh())
      .catch(err => setActionError(`${j.name}: ${err?.message || 'could not change enabled'}`))
      .finally(() => setBusyId(null));
  };

  const fireNow = async (j: ClockworkJobSummary) => {
    if (!await appConfirm(`Run "${j.name}" now? The scheduler starts it the next time it checks for work.`, { confirmText: 'Run now' })) return;
    setBusyId(j.id); setActionError(null);
    api.clockwork.fireNow(j.id)
      .then(res => navigate(`/scheduler/jobs/${j.id}/runs`, { state: { requested: res?.fire_key } }))
      .catch(err => setActionError(`${j.name}: ${err?.message || 'could not fire'}`))
      .finally(() => setBusyId(null));
  };

  return (
    <Box sx={{ p: 3 }} data-testid="clockwork-jobs-page">
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5" fontWeight={600}>Scheduled Jobs</Typography>
          <Typography variant="body2" color="text.secondary">
            Clockwork fires each job exactly once per occurrence and records what it did and what it declined to do.
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RefreshIcon />} onClick={refresh} disabled={load.phase === 'loading'}>Refresh</Button>
          <Tooltip title={access.canAuthor ? '' : 'You may view jobs but not author them (backend verdict).'}>
            <span>
              <Button variant="contained" startIcon={<AddIcon />} disabled={!access.canAuthor && access.source === 'backend'}
                      onClick={() => navigate('/scheduler/jobs/new')} data-testid="clockwork-new-job">
                New job
              </Button>
            </span>
          </Tooltip>
        </Stack>
      </Stack>

      <Paper variant="outlined" sx={{ p: 1.5, mb: 2 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.5}>
          <TextField size="small" placeholder="Search name, owner, cron, connection…" value={search}
                     onChange={e => setSearch(e.target.value)} sx={{ minWidth: 300 }}
                     inputProps={{ 'aria-label': 'search jobs' }}
                     InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
          <Select size="small" value={enabledFilter} onChange={e => setEnabledFilter(e.target.value as EnabledFilter)}
                  inputProps={{ 'aria-label': 'enabled filter' }}>
            <MenuItem value="all">Enabled and disabled</MenuItem>
            <MenuItem value="enabled">Enabled only</MenuItem>
            <MenuItem value="disabled">Disabled only</MenuItem>
          </Select>
          <Select size="small" value={outcomeFilter} onChange={e => setOutcomeFilter(e.target.value as OutcomeFilter)}
                  inputProps={{ 'aria-label': 'last outcome filter' }}>
            <MenuItem value="all">Any last outcome</MenuItem>
            <MenuItem value="SUCCESS">Last SUCCESS</MenuItem>
            <MenuItem value="FAILED">Last FAILED</MenuItem>
            <MenuItem value="UNKNOWN">Last UNKNOWN</MenuItem>
            <MenuItem value="CLAIMED">Still CLAIMED</MenuItem>
            <MenuItem value="REFUSED">Last REFUSED</MenuItem>
            <MenuItem value="SKIPPED_MISSED">Last SKIPPED (missed)</MenuItem>
            <MenuItem value="never">Never fired</MenuItem>
          </Select>
          <Select size="small" value={healthFilter} onChange={e => setHealthFilter(String(e.target.value))}
                  inputProps={{ 'aria-label': 'health filter' }}>
            <MenuItem value="all">Any health</MenuItem>
            <MenuItem value="ok">Healthy</MenuItem>
            <MenuItem value="failing">Failing</MenuItem>
            <MenuItem value="never_probed">Never probed</MenuItem>
            <MenuItem value="unroutable">Unroutable</MenuItem>
          </Select>
        </Stack>
      </Paper>

      {actionError && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setActionError(null)}>{actionError}</Alert>}

      {load.phase === 'loading' && (
        <Stack direction="row" spacing={1} alignItems="center" data-testid="clockwork-jobs-loading">
          <CircularProgress size={18} /><Typography variant="body2">Loading jobs…</Typography>
        </Stack>
      )}
      {load.phase === 'forbidden' && (
        <Alert severity="warning" data-testid="clockwork-jobs-forbidden">
          You are not entitled to see scheduled jobs ({load.message}). The list is not empty — it is
          hidden from you. Ask an administrator for the scheduler entitlement.
        </Alert>
      )}
      {load.phase === 'unreachable' && (
        <Alert severity="error" data-testid="clockwork-jobs-unreachable"
               action={<Button color="inherit" size="small" onClick={refresh}>Retry</Button>}>
          The scheduler backend could not be reached: {load.message}. Jobs may exist and may be
          firing; this screen cannot see them right now.
        </Alert>
      )}
      {load.phase === 'ready' && load.fireLog && !load.fireLog.available && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="clockwork-jobs-firelog-unavailable">
          The fire log could not be read: {load.fireLog.reason || 'no reason given'}. Last outcomes below are
          unknown, not absent — a job may have fired.
        </Alert>
      )}
      {load.phase === 'ready' && !load.fireLog && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="clockwork-jobs-firelog-unstated">
          The server did not say whether the fire log was readable; last outcomes below cannot be trusted as absent.
        </Alert>
      )}
      {load.phase === 'ready' && load.jobs.length === 0 && (
        <Alert severity="info" data-testid="clockwork-jobs-empty">
          No scheduled jobs exist. The server answered and the list is genuinely empty — nothing is
          scheduled. Create the first one.
        </Alert>
      )}
      {load.phase === 'ready' && load.jobs.length > 0 && visible.length === 0 && (
        <Alert severity="info" data-testid="clockwork-jobs-filtered-out">
          {load.jobs.length} job{load.jobs.length === 1 ? '' : 's'} exist but none match the current filters.
        </Alert>
      )}

      {load.phase === 'ready' && visible.length > 0 && (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Enabled</TableCell>
                <TableCell>Schedule</TableCell>
                <TableCell>Next occurrence</TableCell>
                <TableCell>Last outcome</TableCell>
                <TableCell>Owner</TableCell>
                <TableCell>Target connection</TableCell>
                <TableCell>Credential health</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {shown.rows.map(j => {
                const h = healthLook(j.health?.state ?? 'never_probed');
                const fireLogReadable = load.phase === 'ready' && load.fireLog?.available === true;
                return (
                  <TableRow key={j.id} hover data-testid={`clockwork-job-${j.id}`}>
                    <TableCell>
                      <Typography sx={{ fontFamily: 'monospace', fontWeight: 600, fontSize: 13 }}>{j.name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        v{j.version} · {j.step_count} step{j.step_count === 1 ? '' : 's'} · {idempotentLabel(j.idempotent)}
                        {' · '}{j.authority ? `authority ${j.authority}` : 'no authority — every deployment declines it'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <FormControlLabel sx={{ m: 0 }}
                        control={<Switch size="small" checked={j.enabled} disabled={busyId === j.id}
                                         inputProps={{ 'aria-label': `${j.name} enabled` }}
                                         onChange={() => toggleEnabled(j)} />}
                        label={<Typography variant="caption">{j.enabled ? 'on' : 'off'}</Typography>} />
                    </TableCell>
                    <TableCell>
                      <Typography sx={{ fontFamily: 'monospace', fontSize: 12 }}>{j.cron}</Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                        {describeCronExpression(j.cron)} · {j.timezone}
                      </Typography>
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                      {j.next_occurrence_at === undefined
                        ? <Typography variant="caption" color="warning.main">not reported</Typography>
                        : j.next_occurrence_at === null
                          ? <Tooltip title={j.next_occurrence_reason || ''}>
                              <Typography variant="caption" color={j.next_occurrence_reason ? 'warning.main' : 'text.secondary'}
                                          data-testid={`next-occurrence-none-${j.id}`}>
                                {j.next_occurrence_reason ? `none: ${j.next_occurrence_reason}` : 'none computed'}
                              </Typography>
                            </Tooltip>
                          : fmtDt(j.next_occurrence_at)}
                    </TableCell>
                    <TableCell>
                      {j.last_fire === undefined
                        ? <Typography variant="caption" color="warning.main">not reported</Typography>
                        : j.last_fire === null
                          ? (fireLogReadable
                              ? <Typography variant="caption" color="text.secondary">never fired</Typography>
                              : <Typography variant="caption" color="warning.main">fire log unreadable</Typography>)
                          : <Stack spacing={0.25} alignItems="flex-start">
                              <FireStatusChip status={j.last_fire.status} />
                              <Typography variant="caption" color="text.secondary">
                                {fmtDt(j.last_fire.scheduled_fire)}
                              </Typography>
                            </Stack>}
                    </TableCell>
                    <TableCell>{j.owner || <Typography variant="caption" color="warning.main">no owner</Typography>}</TableCell>
                    <TableCell>
                      {j.connection
                        ? <><Typography variant="body2">{j.connection.name}</Typography>
                            <Typography variant="caption" color="text.secondary">{j.connection.type}</Typography></>
                        : <Typography variant="caption" color="error.main">none — cannot fire</Typography>}
                    </TableCell>
                    <TableCell>
                      <Tooltip title={j.health
                        ? `${j.health.reason || ''} ${j.health.checked_at ? `checked ${fmtDt(j.health.checked_at)} by ${j.health.checked_by || '?'}` : 'never checked on the Clockwork pod'}`.trim()
                        : 'the server sent no health row'}>
                        <Chip label={j.health ? h.label : 'not reported'} color={j.health ? h.color : 'warning'}
                              size="small" variant="outlined" data-testid={`clockwork-job-${j.id}-health`} />
                      </Tooltip>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Run history and why-did-this-not-run">
                        <IconButton size="small" aria-label={`history of ${j.name}`}
                                    onClick={() => navigate(`/scheduler/jobs/${j.id}/runs`)}>
                          <HistoryIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={j.can_edit === false ? 'Open (read-only — you may view but not edit)' : 'Edit'}>
                        <IconButton size="small" aria-label={`edit ${j.name}`}
                                    onClick={() => navigate(`/scheduler/jobs/${j.id}`)}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={!j.connection ? 'No target connection — cannot fire'
                        : j.can_fire === false ? 'You may view this job but not fire it (backend verdict)'
                        : j.run_now === undefined ? 'the server did not state whether run now is allowed'
                        : !j.run_now.allowed ? `Run now refused: ${j.run_now.reason}`
                        : 'Run now (a PENDING request a deployment claims on its tick)'}>
                        <span>
                          <IconButton size="small" aria-label={`fire ${j.name} now`}
                                      disabled={busyId === j.id || !j.connection || j.can_fire === false || j.run_now?.allowed !== true}
                                      onClick={() => fireNow(j)}>
                            <FireIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      {load.phase === 'ready' && visible.length > 0 && (
        <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                   testid="clockwork-jobs-pager" />
      )}
      {load.phase === 'ready' && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
          {visible.length} of {load.total} shown. Health is measured on the Clockwork pod, not this one —
          "never probed" is a state, not OK.
        </Typography>
      )}
    </Box>
  );
};

export default ClockworkJobsPage;
