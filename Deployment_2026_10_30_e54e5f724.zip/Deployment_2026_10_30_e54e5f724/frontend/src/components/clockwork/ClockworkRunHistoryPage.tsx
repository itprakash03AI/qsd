/**
 * ClockworkRunHistoryPage — one row per fire, the step rows nested
 * beneath, and at the top the panel that earns the project: "Why did
 * this not run?".
 *
 * Each fire status renders unmistakably (fireStatus.tsx).  An UNKNOWN row
 * carries the "do not simply re-run this" warning, because that status
 * means the side effect may have happened.  A CLAIMED row is "still
 * running" — or a dead pod — and is never auto-cleared.
 *
 * Actions:
 *   run now              a new manual occurrence under its own key —
 *                        written as a PENDING request row that a Clockwork
 *                        deployment claims on its tick (QueryStudio never
 *                        executes a job); the request queue is shown so a
 *                        request that nobody claimed is visible, not lost.
 *                        GATED BY THE SERVER'S `run_now` verdict on the job
 *                        (disabled job; latest fire CLAIMED; latest fire
 *                        UNKNOWN and unresolved on a job not declared
 *                        idempotent) — the button shows the reason and
 *                        never offers what the route refuses;
 *   resume from step N   disabled unless the job DECLARES idempotent =
 *                        true, with the reason shown — NULL is "unknown —
 *                        re-drive disabled";
 *   record a resolution  on a CLAIMED / UNKNOWN / FAILED row; writes the
 *                        resolution columns and never rewrites the status.
 */
import { appConfirm } from '../common/appDialogs';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions,
  DialogContent, DialogTitle, IconButton, MenuItem, Paper, Select, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField,
  Tooltip, Typography,
} from '@mui/material';
import {
  ArrowBack as BackIcon, Refresh as RefreshIcon, ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon, PlayArrow as FireIcon, Replay as ResumeIcon,
  Gavel as ResolveIcon, Edit as EditIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../../services/api';
import type {
  ClockworkFire, ClockworkFireStep, ClockworkJob, ClockworkManualRequest,
  ClockworkResolution,
} from '../../services/api/clockwork';
import WhyNotRunPanel, { type WhyNotRunLoad } from './WhyNotRunPanel';
import { useClockworkAccess } from '../../context/ClockworkAccessContext';
import { fireLogAbsence } from './clockworkRules';
import { FireStatusChip, StepStatusChip, fireLook, fmtDt, fmtDur } from './fireStatus';
import ListPager, { clientPage } from '../common/ListPager';

type FiresLoad =
  | { phase: 'loading' }
  | { phase: 'ready'; fires: ClockworkFire[]; total: number }
  /** 424: the fire-log tables are not in this database — Clockwork has
   *  not been deployed against it.  Not "no fires", not "unreachable". */
  | { phase: 'not_deployed'; reason: string; code: string }
  | { phase: 'failed'; message: string; status?: number };

type RequestsLoad =
  | { phase: 'loading' }
  | { phase: 'ready'; requests: ClockworkManualRequest[] }
  | { phase: 'failed'; message: string };

const REQUEST_STATUS_COLOR: Record<string, 'default' | 'info' | 'success' | 'warning' | 'error'> = {
  PENDING: 'warning', CLAIMED: 'info', DONE: 'success', COMPLETED: 'success',
  REFUSED: 'error', FAILED: 'error', EXPIRED: 'default', RESOLVED: 'default',
};

/** Why a resume is or is not allowed — the tri-state made into words. */
export const resumeVerdict = (job: ClockworkJob | null, fire: ClockworkFire): { allowed: boolean; reason: string } => {
  if (!job) return { allowed: false, reason: 'the job definition could not be read' };
  if (job.idempotent === null) return { allowed: false, reason: 'idempotency unknown — re-drive disabled (declare it on the job)' };
  if (job.idempotent === false) return { allowed: false, reason: 'the job declares it is NOT idempotent — re-drive disabled' };
  if (fire.status === 'CLAIMED') return { allowed: false, reason: 'still CLAIMED — resolve the row first' };
  if (fire.status === 'SUCCESS') return { allowed: false, reason: 'every step succeeded; nothing to resume' };
  if ((job.steps || []).length === 0) return { allowed: false, reason: 'the job has no steps to resume' };
  return { allowed: true, reason: 'the job declares idempotent = true' };
};

/** The guard column of a step row: the deployment records whatever JSON
 *  it evaluated; three shapes are read, anything else is shown raw. */
const guardText = (g: unknown): string => {
  if (g === null || g === undefined) return 'unconditional';
  if (typeof g === 'object' && !Array.isArray(g)) {
    const o = g as { held?: unknown; result?: unknown };
    const held = o.held ?? o.result;
    if (held === true) return 'held';
    if (held === false) return 'did not hold';
    return 'guarded — outcome not recorded';
  }
  if (Array.isArray(g)) return `guarded (${g.length} clause${g.length === 1 ? '' : 's'})`;
  return String(g);
};

const KV: React.FC<{ label: string; value: unknown }> = ({ label, value }) => (
  <Box sx={{ display: 'flex', gap: 1, fontSize: 12 }}>
    <Typography component="span" variant="caption" color="text.secondary" sx={{ minWidth: 140 }}>{label}</Typography>
    <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: 12, wordBreak: 'break-all' }}>
      {value === null || value === undefined ? '—'
        : typeof value === 'object' ? JSON.stringify(value) : String(value)}
    </Typography>
  </Box>
);

/** What one step SENT, from the fire record, beside its row.  Three
 *  findings, kept apart on purpose: the record was not written at all
 *  (older row), the type could not report, the step bound nothing. */
const SentCell: React.FC<{ fire: ClockworkFire; seq: number | null | undefined }> = ({ fire, seq }) => {
  if (!fire.placeholders_recorded || !fire.placeholders) {
    return <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>not recorded</Typography>;
  }
  const steps = fire.placeholders.steps;
  if (steps === null || steps === undefined) {
    return <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>{fire.placeholders.steps_omitted || 'not recorded'}</Typography>;
  }
  const entry = steps.find(s => s.step_no === seq);
  if (!entry) return <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>not recorded</Typography>;
  if (entry.sent === null) {
    return (
      <Tooltip title={entry.reason || 'the task type did not report'}>
        <Typography variant="caption" color="warning.main" sx={{ fontStyle: 'italic' }}>not reported by this task type</Typography>
      </Tooltip>
    );
  }
  if (entry.sent.length === 0) {
    return <Typography variant="caption" color="text.secondary">no placeholders</Typography>;
  }
  return (
    <Stack spacing={0} data-testid={`fire-step-sent-${fire.fire_key}-${seq}`}>
      {entry.sent.map(b => (
        <Typography key={b.name} component="span" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
          {b.name}={b.value}
          <Typography component="span" variant="caption" color="text.secondary"> ({b.placeholder}{b.format ? `, ${b.format}` : ''})</Typography>
        </Typography>
      ))}
    </Stack>
  );
};

/** The occurrence-level date table of the record, or the reason there is
 *  none.  "Not recorded" and "no placeholders" are opposite findings. */
const PlaceholderRecord: React.FC<{ fire: ClockworkFire }> = ({ fire }) => {
  if (fire.placeholders_problem) {
    return (
      <Alert severity="warning" data-testid={`fire-${fire.fire_key}-placeholders-problem`} sx={{ py: 0 }}>
        Placeholders were written but cannot be read: {fire.placeholders_problem}
      </Alert>
    );
  }
  if (!fire.placeholders_recorded || !fire.placeholders) {
    return (
      <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }} data-testid={`fire-${fire.fire_key}-placeholders-not-recorded`}>
        Placeholders not recorded — this fire predates the record (Clockwork before 2026-09-11), or its fire log lacks the columns.
        What was sent cannot be read from this row.
      </Typography>
    );
  }
  const rec = fire.placeholders;
  const dates = Object.entries(rec.dates || {});
  return (
    <Box data-testid={`fire-${fire.fire_key}-placeholders`}>
      {rec.error && <Alert severity="warning" sx={{ py: 0, mb: 0.5 }}>{rec.error}</Alert>}
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
        {dates.map(([name, value]) => (
          <Box key={name} sx={{ fontSize: 12 }}>
            <Typography component="span" variant="caption" color="text.secondary">{name} </Typography>
            <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
              {value ?? <Tooltip title={rec.unresolved?.[name] || 'could not be resolved'}><span>unresolved</span></Tooltip>}
            </Typography>
          </Box>
        ))}
      </Stack>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
        calendar: {rec.calendar ? `${rec.calendar.name} v${rec.calendar.version}` : 'none bound (declared weekend)'}
        {rec.timezone ? ` · zone ${rec.timezone}` : ''}
        {rec.steps_omitted ? ` · ${rec.steps_omitted}` : ''}
      </Typography>
    </Box>
  );
};

const StepRows: React.FC<{ steps: ClockworkFireStep[]; fireKey: string; fire: ClockworkFire }> = ({ steps, fireKey, fire }) => {
  const [open, setOpen] = useState<number | null>(null);
  if (steps.length === 0) {
    return (
      <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }} data-testid="fire-steps-none">
        No step rows. A refusal or a miss writes none; a claimed fire writes one per step as it starts.
      </Typography>
    );
  }
  return (
    <Table size="small" sx={{ '& td, & th': { py: 0.5 } }}>
      <TableHead>
        <TableRow>
          <TableCell>#</TableCell><TableCell>Step</TableCell><TableCell>Type</TableCell>
          <TableCell>Status</TableCell><TableCell>Started</TableCell><TableCell>Duration</TableCell>
          <TableCell>Guard</TableCell><TableCell>Sent</TableCell><TableCell />
        </TableRow>
      </TableHead>
      <TableBody>
        {steps.map((s, idx) => (
          <React.Fragment key={s.seq ?? `i${idx}`}>
            <TableRow data-testid={`fire-step-${fireKey}-${s.seq ?? 'x'}`}>
              <TableCell>{s.seq ?? '?'}</TableCell>
              <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{s.name || <em>unnamed</em>}</TableCell>
              <TableCell><Chip label={s.task_type || 'type not recorded'} size="small" variant="outlined" sx={{ fontSize: 10 }} /></TableCell>
              <TableCell>{s.status ? <StepStatusChip status={String(s.status)} /> : <Chip label="status not recorded" size="small" color="error" />}</TableCell>
              <TableCell sx={{ fontSize: 12 }}>{fmtDt(s.started_at)}</TableCell>
              <TableCell sx={{ fontSize: 12 }}>{fmtDur(s.duration_seconds)}</TableCell>
              <TableCell sx={{ fontSize: 12 }}>{guardText(s.guard)}</TableCell>
              <TableCell sx={{ fontSize: 12 }}><SentCell fire={fire} seq={s.seq} /></TableCell>
              <TableCell align="right">
                <IconButton size="small" aria-label={`details of step ${s.seq ?? idx + 1}`} onClick={() => setOpen(open === idx ? null : idx)}>
                  {open === idx ? <CollapseIcon fontSize="small" /> : <ExpandIcon fontSize="small" />}
                </IconButton>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colSpan={9} sx={{ p: 0, border: 0 }}>
                <Collapse in={open === idx}>
                  <Box sx={{ p: 1.5, bgcolor: 'action.hover' }}>
                    <Stack spacing={0.5}>
                      <KV label="resolved params" value={s.params} />
                      <KV label="outputs" value={s.outputs} />
                      <KV label="ended" value={s.ended_at} />
                      {s.guard !== null && s.guard !== undefined && <KV label="guard (as recorded)" value={s.guard} />}
                      <KV label="detail" value={s.detail} />
                      {s.status === 'UNKNOWN' && (
                        <Alert severity="warning" sx={{ mt: 1 }}>
                          This step's answer was lost after it started. Its side effect may have happened —
                          the chain stopped here and nothing after it ran.
                        </Alert>
                      )}
                    </Stack>
                  </Box>
                </Collapse>
              </TableCell>
            </TableRow>
          </React.Fragment>
        ))}
      </TableBody>
    </Table>
  );
};

const ClockworkRunHistoryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const jobId = Number(id);
  const navigate = useNavigate();
  const access = useClockworkAccess();

  const [job, setJob] = useState<ClockworkJob | null>(null);
  const [jobError, setJobError] = useState<string | null>(null);
  const [fires, setFires] = useState<FiresLoad>({ phase: 'loading' });
  const [requests, setRequests] = useState<RequestsLoad>({ phase: 'loading' });
  const [why, setWhy] = useState<WhyNotRunLoad>({ phase: 'loading' });
  const [open, setOpen] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionOk, setActionOk] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [resumeFor, setResumeFor] = useState<ClockworkFire | null>(null);
  const [resumeStep, setResumeStep] = useState<number>(1);
  const [resolveFor, setResolveFor] = useState<ClockworkFire | null>(null);
  const [resolveVerdict, setResolveVerdict] = useState<ClockworkResolution['verdict']>('confirmed_did_not_run');
  const [resolveNote, setResolveNote] = useState('');
  const [firePage, setFirePage] = useState(1);
  const [firePageSize, setFirePageSize] = useState(50);
  const [requestPage, setRequestPage] = useState(1);
  const [requestPageSize, setRequestPageSize] = useState(50);

  const loadFires = useCallback(() => {
    setFires({ phase: 'loading' });
    // the SERVER pages the fire log (limit + offset, total): every fire is
    // reachable however many there are
    api.clockwork.listFires(jobId, firePageSize, (firePage - 1) * firePageSize)
      .then(r => {
        if (!r || !Array.isArray(r.fires)) { setFires({ phase: 'failed', message: 'the server answered without a fires list' }); return; }
        setFires({ phase: 'ready', fires: r.fires, total: typeof r.total === 'number' ? r.total : r.fires.length });
      })
      .catch(err => {
        const absent = fireLogAbsence(err);
        if (absent) { setFires({ phase: 'not_deployed', ...absent }); return; }
        setFires({ phase: 'failed', message: err?.message || 'unreachable', status: err?.status });
      });
  }, [jobId, firePage, firePageSize]);

  const loadRequests = useCallback(() => {
    setRequests({ phase: 'loading' });
    api.clockwork.listRequests(jobId)
      .then(r => setRequests({ phase: 'ready', requests: Array.isArray(r?.requests) ? r.requests : [] }))
      .catch(err => setRequests({ phase: 'failed', message: err?.message || 'unreachable' }));
  }, [jobId]);

  const loadWhy = useCallback(() => {
    setWhy({ phase: 'loading' });
    api.clockwork.whyNotRun(jobId)
      .then(r => setWhy({ phase: 'ready', data: r }))
      .catch(err => setWhy({ phase: 'failed', message: err?.message || 'unreachable', status: err?.status }));
  }, [jobId]);

  const loadJob = useCallback(() => {
    api.clockwork.getJob(jobId).then(j => { setJob(j); setJobError(null); })
      .catch(err => { setJob(null); setJobError(err?.message || 'the job could not be read'); });
  }, [jobId]);

  useEffect(() => { loadJob(); loadRequests(); loadWhy(); }, [loadJob, loadRequests, loadWhy]);
  useEffect(() => { loadFires(); }, [loadFires]);       // a new page reloads the fire log only
  // Another job starts again at page 1.
  useEffect(() => { setFirePage(1); setRequestPage(1); }, [jobId]);
  const shownFires = {
    rows: fires.phase === 'ready' ? fires.fires : [],
    paging: fires.phase === 'ready' ? (() => {
      const total = fires.total;
      const pages = Math.max(1, Math.ceil(total / firePageSize));
      const first = fires.fires.length ? (firePage - 1) * firePageSize + 1 : 0;
      return { page: firePage, page_size: firePageSize, total, pages, first, last: first ? first + fires.fires.length - 1 : 0 };
    })() : null,
  };
  const shownRequests = clientPage(requests.phase === 'ready' ? requests.requests : [], requestPage, requestPageSize);

  const refreshAll = () => { loadJob(); loadFires(); loadRequests(); loadWhy(); };

  const fireNow = async () => {
    if (!await appConfirm('Run this job now? The scheduler starts it the next time it checks for work.', { confirmText: 'Run now' })) return;
    setBusy(true); setActionError(null); setActionOk(null);
    api.clockwork.fireNow(jobId)
      .then(r => { setActionOk(`Requested as ${r?.fire_key || 'key not returned'} — ${r?.status || 'PENDING'} until a deployment claims it.`); refreshAll(); })
      .catch(err => setActionError(err?.message || 'could not fire'))
      .finally(() => setBusy(false));
  };

  const doResume = () => {
    if (!resumeFor) return;
    setBusy(true); setActionError(null); setActionOk(null);
    api.clockwork.resumeFire(resumeFor.fire_key, resumeStep)
      .then(r => { setActionOk(`Resume from step ${resumeStep} requested as ${r?.fire_key || 'key not returned'} — ${r?.status || 'PENDING'} until a deployment claims it.`); setResumeFor(null); refreshAll(); })
      .catch(err => setActionError(err?.message || 'could not resume'))
      .finally(() => setBusy(false));
  };

  const doResolve = () => {
    if (!resolveFor) return;
    setBusy(true); setActionError(null); setActionOk(null);
    api.clockwork.recordResolution(resolveFor.fire_key, resolveVerdict, resolveNote)
      .then(r => {
        const retired = r?.retired_request;
        setActionOk(retired
          ? `Resolution recorded on ${resolveFor.fire_key}; the status is unchanged. Request #${retired.id} was retired (${retired.status}) and run now is allowed again.`
          : `Resolution recorded on ${resolveFor.fire_key}; the status is unchanged.`);
        setResolveFor(null); setResolveNote(''); refreshAll();
      })
      .catch(err => setActionError(err?.message || 'could not record the resolution'))
      .finally(() => setBusy(false));
  };

  const stuck = (f: ClockworkFire) =>
    (f.status === 'CLAIMED' || f.status === 'UNKNOWN' || f.status === 'FAILED') && !f.resolution;
  /** Resolving a CLAIMED fire asserts an occurrence that may have run is
   *  finished, retires its request and lifts run now: the server takes it
   *  from an admin only (403 otherwise), so the button says so here. */
  const claimedNeedsAdmin = (f: ClockworkFire) => f.status === 'CLAIMED' && !access.canAdmin;
  const resolveTitle = (f: ClockworkFire) => {
    if (f.resolution) return 'already resolved';
    if (!stuck(f)) return 'only a CLAIMED, UNKNOWN or FAILED row takes a resolution';
    if (claimedNeedsAdmin(f)) return 'Resolving a CLAIMED fire retires its request and lifts run now — an admin records it';
    if (f.status === 'CLAIMED') return 'Record a resolution: retires the CLAIMED request and lifts run now (admin)';
    return 'Record a resolution on this row';
  };

  return (
    <Box sx={{ p: 3 }} data-testid="clockwork-run-history">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <IconButton size="small" aria-label="back to jobs" onClick={() => navigate('/scheduler')}><BackIcon /></IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight={600}>
            {job ? job.name : `job ${jobId}`} — run history
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {job ? `${job.cron} · ${job.timezone} · ${job.enabled ? 'enabled' : 'disabled'} · v${job.version}` : jobError ? `definition unreadable: ${jobError}` : 'loading definition…'}
          </Typography>
        </Box>
        <Button startIcon={<EditIcon />} onClick={() => navigate(`/scheduler/jobs/${jobId}`)}>Edit</Button>
        <Button startIcon={<RefreshIcon />} onClick={refreshAll} disabled={busy}>Refresh</Button>
        <Tooltip title={!job?.connection_id ? 'no target connection — cannot fire'
          : job?.can_fire === false ? 'You may view this job but not fire it (backend verdict)'
          : job?.run_now === undefined ? 'the server did not state whether run now is allowed'
          : !job.run_now.allowed ? `Run now refused: ${job.run_now.reason}` : ''}>
          <span>
            <Button variant="contained" startIcon={<FireIcon />} onClick={fireNow}
                    disabled={busy || !job?.connection_id || job?.can_fire === false || job?.run_now?.allowed !== true}
                    data-testid="run-now">Run now</Button>
          </span>
        </Tooltip>
      </Stack>

      {actionError && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setActionError(null)}>{actionError}</Alert>}
      {actionOk && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setActionOk(null)}>{actionOk}</Alert>}

      <Box sx={{ mb: 2 }}>
        <WhyNotRunPanel load={why} onRefresh={loadWhy} />
      </Box>

      <Paper variant="outlined" sx={{ mb: 2 }} data-testid="manual-requests">
        <Box sx={{ p: 1.5, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="subtitle2">Manual requests</Typography>
          <Typography variant="caption" color="text.secondary">
            Run-now and resume are request rows; a Clockwork deployment with this job's authority claims
            them on its tick. A request still PENDING after a tick is a finding, not a delay.
          </Typography>
        </Box>
        {requests.phase === 'loading' && <Typography variant="body2" color="text.secondary" sx={{ p: 1.5 }}>Loading requests…</Typography>}
        {requests.phase === 'failed' && (
          <Alert severity="error" sx={{ m: 1.5 }} data-testid="manual-requests-failed">
            The request queue could not be read: {requests.message}. A request may be waiting.
          </Alert>
        )}
        {requests.phase === 'ready' && requests.requests.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ p: 1.5, fontStyle: 'italic' }} data-testid="manual-requests-empty">
            No manual requests for this job.
          </Typography>
        )}
        {requests.phase === 'ready' && requests.requests.length > 0 && (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Requested</TableCell><TableCell>Kind</TableCell><TableCell>Status</TableCell>
                <TableCell>By</TableCell><TableCell>Fire key</TableCell><TableCell>Claimed</TableCell><TableCell>Detail</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {shownRequests.rows.map(r => (
                <TableRow key={r.id} data-testid={`manual-request-${r.id}`}>
                  <TableCell sx={{ fontSize: 12 }}>{fmtDt(r.requested_at)}</TableCell>
                  <TableCell sx={{ fontSize: 12 }}>
                    {r.kind === 'resume' ? `resume from step ${r.from_step ?? '?'}` : 'run now'}
                    {r.parent_fire_key ? <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>of {r.parent_fire_key}</Typography> : null}
                  </TableCell>
                  <TableCell>
                    <Chip label={r.status} size="small" color={REQUEST_STATUS_COLOR[String(r.status).toUpperCase()] || 'default'}
                          variant={String(r.status).toUpperCase() === 'PENDING' ? 'filled' : 'outlined'} />
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{r.requested_by || '—'}</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>{r.fire_key}</TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{r.claimed_by ? `${r.claimed_by} at ${fmtDt(r.claimed_at)}` : 'not yet'}</TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{r.detail || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {requests.phase === 'ready' && requests.requests.length > 0 && (
          <ListPager paging={shownRequests.paging} onPage={setRequestPage} onPageSize={setRequestPageSize}
                     testid="clockwork-requests-pager" />
        )}
      </Paper>

      <Paper variant="outlined">
        <Box sx={{ p: 1.5, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="subtitle2">Fires</Typography>
        </Box>
        {fires.phase === 'loading' && (
          <Stack direction="row" spacing={1} alignItems="center" sx={{ p: 2 }} data-testid="fires-loading">
            <CircularProgress size={16} /><Typography variant="body2">Loading fires…</Typography>
          </Stack>
        )}
        {fires.phase === 'not_deployed' && (
          <Alert severity="warning" sx={{ m: 2 }} data-testid="fires-not-deployed">
            The scheduler has not been deployed against this database yet: {fires.reason} ({fires.code}).
            The fire-log tables Clockwork writes are absent, so there is no history to show — this is not an
            empty history. Deploy Clockwork against this database, or point this QueryStudio at the one it
            writes to.
          </Alert>
        )}
        {fires.phase === 'failed' && (
          <Alert severity="error" sx={{ m: 2 }} data-testid="fires-failed">
            {fires.status === 403 ? 'You are not entitled to this job\'s history.' : `The fire log could not be read: ${fires.message}. Fires may exist.`}
          </Alert>
        )}
        {fires.phase === 'ready' && fires.fires.length === 0 && (
          <Alert severity="info" sx={{ m: 2 }} data-testid="fires-empty">
            No fires recorded for this job. The server answered and the log is genuinely empty — see the panel
            above for why the last expected occurrence did not run.
          </Alert>
        )}
        {fires.phase === 'ready' && fires.fires.length > 0 && (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell /><TableCell>Scheduled</TableCell><TableCell>Status</TableCell>
                  <TableCell>Trigger</TableCell><TableCell>Claimed</TableCell><TableCell>Completed</TableCell>
                  <TableCell>Deployment</TableCell><TableCell>Steps</TableCell><TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownFires.rows.map(f => {
                  const rv = resumeVerdict(job, f);
                  const isOpen = open === f.fire_key;
                  return (
                    <React.Fragment key={f.fire_key}>
                      <TableRow hover data-testid={`fire-${f.fire_key}`}
                                sx={f.status === 'UNKNOWN' ? { bgcolor: 'warning.light' } : f.status === 'CLAIMED' ? { bgcolor: 'info.light' } : undefined}>
                        <TableCell>
                          <IconButton size="small" aria-label={`details of ${f.fire_key}`} onClick={() => setOpen(isOpen ? null : f.fire_key)}>
                            {isOpen ? <CollapseIcon fontSize="small" /> : <ExpandIcon fontSize="small" />}
                          </IconButton>
                        </TableCell>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{fmtDt(f.scheduled_fire)}</TableCell>
                        <TableCell>
                          <Stack spacing={0.5} alignItems="flex-start">
                            <FireStatusChip status={f.status} />
                            {f.resolution && <Chip label={`resolved: ${f.resolution.verdict.replace(/_/g, ' ')}`} size="small" variant="outlined" />}
                          </Stack>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12 }}>
                          {f.trigger}{f.parent_fire_key ? ` (from step ${f.resume_from_step ?? '?'} of ${f.parent_fire_key})` : ''}
                        </TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{fmtDt(f.claimed_at)}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{fmtDt(f.completed_at)}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{f.deployment_id || f.claimed_by || '—'}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>
                          {(f.steps || []).length} · {(f.steps || []).filter(s => s.status === 'SUCCESS').length} ok
                        </TableCell>
                        <TableCell align="right">
                          <Tooltip title={rv.allowed ? 'Resume from a step (a new occurrence carrying this key)' : `Resume disabled: ${rv.reason}`}>
                            <span>
                              <IconButton size="small" disabled={!rv.allowed || busy} aria-label={`resume ${f.fire_key}`}
                                          data-testid={`resume-${f.fire_key}`}
                                          onClick={() => { setResumeFor(f); setResumeStep(Math.max(1, (f.steps || []).findIndex(s => s.status !== 'SUCCESS') + 1 || 1)); }}>
                                <ResumeIcon fontSize="small" />
                              </IconButton>
                            </span>
                          </Tooltip>
                          <Tooltip title={resolveTitle(f)}>
                            <span>
                              <IconButton size="small" disabled={!stuck(f) || claimedNeedsAdmin(f) || busy} aria-label={`resolve ${f.fire_key}`}
                                          data-testid={`resolve-${f.fire_key}`}
                                          onClick={() => setResolveFor(f)}>
                                <ResolveIcon fontSize="small" />
                              </IconButton>
                            </span>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell colSpan={9} sx={{ p: 0, border: 0 }}>
                          <Collapse in={isOpen} unmountOnExit>
                            <Box sx={{ p: 2, bgcolor: 'background.default' }}>
                              {f.status === 'UNKNOWN' && (
                                <Alert severity="warning" sx={{ mb: 1.5 }} data-testid={`fire-${f.fire_key}-unknown-warning`}>
                                  {fireLook('UNKNOWN').meaning}
                                </Alert>
                              )}
                              {f.status === 'CLAIMED' && (
                                <Alert severity="info" sx={{ mb: 1.5 }}>{fireLook('CLAIMED').meaning}</Alert>
                              )}
                              <Stack spacing={0.5} sx={{ mb: 1.5 }}>
                                <KV label="fire key" value={f.fire_key} />
                                <KV label="job version" value={f.job_version} />
                                <KV label="scope" value={f.scope} />
                                <KV label="cron at fire" value={f.cron_expression} />
                                <KV label="task type" value={f.task_type} />
                                <KV label="task ref" value={f.task_ref} />
                                <KV label="claimed by" value={f.claimed_by} />
                                <KV label="calendar version" value={f.calendar_version} />
                                <KV label="detail" value={f.detail} />
                                {f.resolution && (
                                  <KV label="resolution" value={`${f.resolution.verdict} — ${f.resolution.note} (${f.resolution.resolved_by}, ${fmtDt(f.resolution.resolved_at)})`} />
                                )}
                              </Stack>
                              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>Placeholders resolved for this fire</Typography>
                              <Box sx={{ mb: 1.5 }}><PlaceholderRecord fire={f} /></Box>
                              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>Steps</Typography>
                              <StepRows steps={f.steps || []} fireKey={f.fire_key} fire={f} />
                            </Box>
                          </Collapse>
                        </TableCell>
                      </TableRow>
                    </React.Fragment>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        )}
        {fires.phase === 'ready' && fires.fires.length > 0 && (
          <ListPager paging={shownFires.paging} onPage={setFirePage} onPageSize={setFirePageSize}
                     testid="clockwork-fires-pager" />
        )}
        {fires.phase === 'ready' && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', p: 1.5 }}>
            {fires.total} fires in all, newest first. Nothing here is ever deleted.
          </Typography>
        )}
      </Paper>

      <Dialog open={resumeFor !== null} onClose={() => setResumeFor(null)}>
        <DialogTitle>Resume from a step</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 2 }}>
            A NEW occurrence is written as a PENDING request under its own key, carrying <code>{resumeFor?.fire_key}</code> as
            its parent. Steps before the chosen one are not re-run. Allowed because {resumeFor ? resumeVerdict(job, resumeFor).reason : ''}.
          </Typography>
          <Select size="small" fullWidth value={resumeStep} inputProps={{ 'aria-label': 'resume from step' }}
                  onChange={e => setResumeStep(Number(e.target.value))}>
            {(job?.steps || []).map((s, i) => {
              const recorded = (resumeFor?.steps || []).find(x => x.seq === i + 1 || x.name === s.name);
              return (
                <MenuItem key={i} value={i + 1}>
                  step {i + 1} — {s.name} ({recorded?.status ? String(recorded.status) : 'not reached'})
                </MenuItem>
              );
            })}
          </Select>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setResumeFor(null)} disabled={busy}>Cancel</Button>
          <Button variant="contained" onClick={doResume} disabled={busy} data-testid="resume-confirm">Resume</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={resolveFor !== null} onClose={() => setResolveFor(null)}>
        <DialogTitle>Record a resolution</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 2 }}>
            Writes who resolved <code>{resolveFor?.fire_key}</code>, what they found and when. The status
            ({resolveFor?.status}) is NOT rewritten — the row stays what it was, with your finding beside it.
          </Typography>
          {resolveFor?.status === 'CLAIMED' && (
            <Alert severity="warning" sx={{ mb: 2 }} data-testid="resolve-claimed-warning">
              This fire is still CLAIMED: a pod is running it, or died mid-fire. Recording a resolution asserts the
              occurrence is FINISHED — it retires the CLAIMED request holding this job's run-now slot and lifts the
              run-now refusal. Check the target first and say what you found; the note is required and the act is
              audited under your name.
            </Alert>
          )}
          <Select size="small" fullWidth value={resolveVerdict} sx={{ mb: 2 }} inputProps={{ 'aria-label': 'resolution verdict' }}
                  onChange={e => setResolveVerdict(e.target.value as ClockworkResolution['verdict'])}>
            <MenuItem value="confirmed_ran">Confirmed at the target: it RAN</MenuItem>
            <MenuItem value="confirmed_did_not_run">Confirmed at the target: it did NOT run</MenuItem>
            <MenuItem value="completed_by_hand">Completed by hand</MenuItem>
          </Select>
          <TextField fullWidth multiline minRows={3} label="What you checked and found" value={resolveNote}
                     inputProps={{ 'aria-label': 'resolution note' }} onChange={e => setResolveNote(e.target.value)} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setResolveFor(null)} disabled={busy}>Cancel</Button>
          <Button variant="contained" onClick={doResolve} disabled={busy || !resolveNote.trim()} data-testid="resolve-confirm">Record</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ClockworkRunHistoryPage;
