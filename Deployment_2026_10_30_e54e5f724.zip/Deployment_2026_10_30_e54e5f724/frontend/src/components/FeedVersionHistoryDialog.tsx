/**
 * FeedVersionHistoryDialog (2026-09-27) — a feed's definition versions,
 * the field-level diff between a version and the one before it, and a
 * restore that goes through the ONE update route.
 *
 * Backend: api/feed_versions_api.py.  A version is minted by every save
 * and by every run's claim-time pin (deduplicated by hash), so the list
 * is "what ran and what was saved", newest first.  Secrets are masked by
 * the server; a password change reads as *** -> *** (it changed; the
 * values are not shown).
 *
 * Restore is refused by the server for a retired feed (409); the button
 * says so up front when the parent knows the feed is retired, and renders
 * the server's refusal verbatim otherwise.  The newest version is the
 * current definition and cannot be "restored".
 *
 * Pattern: QueryVersionHistory.tsx (list + restore), plus the diff panel.
 */
import { appConfirm } from './common/appDialogs';
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, Tooltip, Typography,
} from '@mui/material';
import {
  History as HistoryIcon, Restore as RestoreIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  FeedVersionChange, FeedVersionSummary,
} from '../services/api/feeds';
import { clickableRow } from '../utils/clickable';
import ListPager, { clientPage } from './common/ListPager';

interface Props {
  feedId: number | null;
  feedName?: string | null;
  open: boolean;
  /** When the parent knows the feed is retired, restore is disabled with the reason. */
  retired?: boolean;
  onClose: () => void;
  /** After a successful restore -- the parent reloads the feed. */
  onRestored: () => void;
}

const fmt = (v: any): string => {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'string') return v;
  try { return JSON.stringify(v); } catch { return String(v); }
};

const FeedVersionHistoryDialog: React.FC<Props> = ({
  feedId, feedName, open, retired = false, onClose, onRestored,
}) => {
  const [versions, setVersions] = useState<FeedVersionSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [diff, setDiff] = useState<
    { phase: 'idle' } | { phase: 'loading' } | { phase: 'error'; message: string }
    | { phase: 'ready'; from: number | null; to: number; changes: FeedVersionChange[] }
  >({ phase: 'idle' });
  const [restoring, setRestoring] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [diffPage, setDiffPage] = useState(1);
  const [diffPageSize, setDiffPageSize] = useState(50);

  const load = async (id: number) => {
    setLoading(true);
    setError(null);
    setNotice(null);
    setSelected(null);
    setDiff({ phase: 'idle' });
    setPage(1);
    try {
      const d = await api.listFeedVersions(id);
      setVersions(d.items || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load the version history');
      setVersions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open && feedId != null) void load(feedId);
  }, [open, feedId]);  // eslint-disable-line react-hooks/exhaustive-deps

  const showDiff = async (v: FeedVersionSummary) => {
    if (feedId == null) return;
    setSelected(v.version);
    setDiffPage(1);
    const prev = versions.find(x => x.version === v.version - 1);
    if (!prev) {
      // the first version has nothing before it: its summary IS the answer
      setDiff({ phase: 'ready', from: null, to: v.version,
                changes: v.changed_fields.map(f => ({
                  field: f, path: f, kind: 'added', from: null, to: '(first version)',
                })) });
      return;
    }
    setDiff({ phase: 'loading' });
    try {
      const d = await api.diffFeedVersions(feedId, prev.version, v.version);
      setDiff({ phase: 'ready', from: prev.version, to: v.version, changes: d.changes });
    } catch (e: any) {
      setDiff({ phase: 'error', message: e?.message || 'Failed to load the diff' });
    }
  };

  const restore = async (v: FeedVersionSummary) => {
    if (feedId == null) return;
    if (!await appConfirm(
      `Restore version ${v.version} of ${feedName || `feed #${feedId}`}? `
      + 'This saves it as the current definition (a new version) through the normal update; '
      + 'the feed\'s active state and schedule are not changed.')) return;
    setRestoring(v.version);
    setError(null);
    try {
      const r = await api.restoreFeedVersion(feedId, v.version);
      onRestored();
      await load(feedId);          // clears the panel; the notice goes AFTER
      setNotice(`Restored version ${v.version} as version ${r.now_version ?? '?'} `
                + `(${r.restored_fields.length} field(s)).`);
    } catch (e: any) {
      setError(e?.message || 'Failed to restore the version');
    } finally {
      setRestoring(null);
    }
  };

  const newest = versions[0]?.version;
  const pg = clientPage(versions, page, pageSize);
  const diffPg = clientPage(diff.phase === 'ready' ? diff.changes : [], diffPage, diffPageSize);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, fontWeight: 700 }}>
        <HistoryIcon color="primary" />
        Version history — {feedName || (feedId != null ? `feed #${feedId}` : '')}
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="versions-error">{error}</Alert>}
        {notice && <Alert severity="success" sx={{ mb: 2 }} data-testid="versions-notice">{notice}</Alert>}
        {retired && (
          <Alert severity="info" sx={{ mb: 2 }}>
            This feed is retired: its history stays readable, but a retired feed's
            definition is not restorable. Unretire it first.
          </Alert>
        )}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>
        ) : versions.length === 0 ? (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}
                      data-testid="versions-empty">
            No versions yet. A version is recorded each time the feed is saved or run.
          </Typography>
        ) : (
          <>
          <Table size="small" data-testid="versions-table">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Version</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Recorded</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>By</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Changed fields</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Deploy</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {pg.rows.map(v => {
                const isCurrent = v.version === newest;
                const why = retired ? 'A retired feed is not restorable'
                  : isCurrent ? 'This is the current definition' : '';
                return (
                  <TableRow key={v.id} hover selected={selected === v.version}
                            {...clickableRow(() => void showDiff(v),
                                             { label: `version ${v.version}`, selected: selected === v.version })}
                            sx={{ cursor: 'pointer' }}>
                    <TableCell>
                      <Chip label={`v${v.version}`} size="small"
                            color={isCurrent ? 'primary' : 'default'} />
                    </TableCell>
                    <TableCell sx={{ whiteSpace: 'nowrap', fontSize: 12 }}>
                      {v.created_at ? new Date(v.created_at).toLocaleString() : '—'}
                    </TableCell>
                    <TableCell sx={{ fontSize: 12 }}>{v.created_by || '—'}</TableCell>
                    <TableCell>
                      <Stack direction="row" gap={0.5} flexWrap="wrap">
                        {/* 2026-10-13 -- the FIRST version changed nothing: it is
                            the feed as created (it listed every field) */}
                        {v.version === 1
                          ? <Typography variant="caption" color="text.secondary" data-testid="version-first">
                              First version (the feed as created)
                            </Typography>
                          : v.changed_fields.length === 0
                          ? <Typography variant="caption" color="text.secondary">—</Typography>
                          : v.changed_fields.slice(0, 6).map(f => (
                            <Chip key={f} label={f} size="small" variant="outlined"
                                  sx={{ height: 18, fontSize: '0.65rem' }} />
                          ))}
                        {v.version !== 1 && v.changed_fields.length > 6 && (
                          <Typography variant="caption" color="text.secondary">
                            +{v.changed_fields.length - 6} more
                          </Typography>
                        )}
                      </Stack>
                    </TableCell>
                    <TableCell sx={{ fontSize: 11, color: 'text.secondary', fontFamily: 'monospace' }}>
                      {v.git_commit ? v.git_commit.slice(0, 8) : '—'}
                      {v.image_tag ? ` · ${v.image_tag}` : ''}
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title={why || `Restore version ${v.version}`}>
                        <span>
                          <Button size="small" variant="outlined"
                                  startIcon={restoring === v.version
                                    ? <CircularProgress size={14} /> : <RestoreIcon fontSize="small" />}
                                  aria-label={`Restore version ${v.version}`}
                                  disabled={Boolean(why) || restoring !== null}
                                  onClick={e => { e.stopPropagation(); void restore(v); }}>
                            Restore
                          </Button>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="versions-pager" />
          </>
        )}

        {diff.phase !== 'idle' && (
          <Box sx={{ mt: 2 }} data-testid="version-diff">
            {diff.phase === 'loading' && <CircularProgress size={18} />}
            {diff.phase === 'error' && <Alert severity="error">{diff.message}</Alert>}
            {diff.phase === 'ready' && (
              <>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  {diff.from == null
                    ? `Version ${diff.to} — the first recorded definition`
                    : `Changes from v${diff.from} to v${diff.to} (${diff.changes.length})`}
                </Typography>
                {diff.changes.length === 0 ? (
                  <Typography variant="body2" color="text.secondary">No field differs.</Typography>
                ) : (
                  <>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 600 }}>Field</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Change</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>From</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>To</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {diffPg.rows.map(c => (
                        <TableRow key={c.path}>
                          <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{c.path}</TableCell>
                          <TableCell>
                            <Chip size="small" label={c.kind} variant="outlined"
                                  color={c.kind === 'removed' ? 'error' : c.kind === 'added' ? 'success' : 'default'}
                                  sx={{ height: 18, fontSize: '0.65rem' }} />
                          </TableCell>
                          <TableCell sx={{ fontSize: 12, wordBreak: 'break-all', maxWidth: 260 }}>{fmt(c.from)}</TableCell>
                          <TableCell sx={{ fontSize: 12, wordBreak: 'break-all', maxWidth: 260 }}>{fmt(c.to)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <ListPager paging={diffPg.paging} onPage={setDiffPage} onPageSize={setDiffPageSize}
                             testid="version-diff-pager" />
                  </>
                )}
              </>
            )}
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default FeedVersionHistoryDialog;
