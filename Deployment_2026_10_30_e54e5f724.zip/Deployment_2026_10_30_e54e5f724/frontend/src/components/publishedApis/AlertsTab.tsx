/**
 * Published-API ALERTS (2026-10-17, design §3.8): the thresholds (rows an
 * admin adds / edits / deletes; an owner sees the ones that apply to their
 * APIs) with each (threshold, API) verdict, and the alerts raised through
 * THE alert road with every channel's outcome.  The kind editor is the
 * feed board's (Feed Run Status -> Settings), linked, not duplicated.
 */
import { appConfirm } from '../common/appDialogs';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControl,
  FormControlLabel, IconButton, InputLabel, MenuItem, Paper, Select, Stack, Switch, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import api from '../../services/api';
import type { PublishedApiRow } from './types';

interface Threshold {
  id: number; name: string; scope: 'global' | 'kind' | 'api'; api_kind: string; scope_key: string; metric: string;
  operator: string; value: number; window_minutes: number; min_calls: number; clear_after_windows: number;
  alert_kind: string; is_active: boolean; created_by?: string | null; updated_at?: string | null;
  states?: { api_kind: string; api_id: number; api_slug?: string; state: string; value?: number | null; calls?: number | null;
             detail?: string | null; evaluated_at?: string | null; alert_id?: number | null }[];
}

interface Props { apis: PublishedApiRow[]; canEdit: boolean }

const EMPTY: Omit<Threshold, 'id'> = {
  name: '', scope: 'global', api_kind: '', scope_key: '', metric: 'error_rate', operator: '>', value: 5,
  window_minutes: 15, min_calls: 50, clear_after_windows: 2, alert_kind: 'api_error_rate', is_active: true,
};

const STATE_COLOR: Record<string, 'success' | 'error' | 'warning' | 'default'> = {
  ok: 'success', breach: 'error', insufficient: 'warning', unknown: 'default',
};

export default function AlertsTab({ apis, canEdit }: Props) {
  const [data, setData] = useState<any>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [alertStatus, setAlertStatus] = useState<'open' | 'cleared' | 'all'>('open');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<Partial<Threshold> | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const a: any = api;
    const [t, al] = await Promise.allSettled([a.listAlertThresholds(), a.listPublishedApiAlerts({ status: alertStatus, limit: 500 })]);
    if (t.status === 'fulfilled') setData(t.value); else { setData(null); setError(t.reason?.message || 'the thresholds could not be read'); }
    setAlerts(al.status === 'fulfilled' ? al.value : { error: al.reason?.message || 'unreadable' });
    setLoading(false);
  }, [alertStatus]);

  useEffect(() => { load(); }, [load]);

  const metrics: Record<string, any> = data?.metrics || {};
  const kinds: any[] = data?.alert_kinds || [];

  const save = async () => {
    if (!editing) return;
    setSaving(true);
    setSaveError(null);
    try {
      const body = { ...editing };
      delete (body as any).states;
      const a: any = api;
      if (editing.id) await a.updateAlertThreshold(editing.id, body);
      else await a.createAlertThreshold(body);
      setEditing(null);
      load();
    } catch (e: any) {
      setSaveError(e?.message || 'refused');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (t: Threshold) => {
    if (!await appConfirm(`Delete threshold '${t.name}'? Its open alerts clear the next time alerts are checked.`)) return;
    try {
      await (api as any).deleteAlertThreshold(t.id);
      load();
    } catch (e: any) {
      setError(e?.message || 'the delete was refused');
    }
  };

  const scopeWords = (t: Threshold) =>
    t.scope === 'global' ? 'every API' : t.scope === 'kind' ? `every ${t.api_kind.replace('published_', '')}` : `${t.api_kind.replace('published_', '')} ${t.scope_key}`;

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="h6" fontWeight={600}>Thresholds</Typography>
        <Box sx={{ flex: 1 }} />
        {data?.alert_group && (
          <Tooltip title="The Netcool AlertGroup the API alert kinds are seeded with (published_views.alert_group); the kinds themselves are edited on Feed Run Status -> Settings -> Alert kinds">
            <Chip size="small" variant="outlined" label={`AlertGroup ${data.alert_group}`} />
          </Tooltip>
        )}
        <Button size="small" startIcon={<RefreshIcon />} onClick={load}>Refresh</Button>
        {canEdit && (
          <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => { setSaveError(null); setEditing({ ...EMPTY }); }}
                  data-testid="threshold-add">Add threshold</Button>
        )}
      </Stack>
      {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="alerts-error">{error}</Alert>}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 3 }}><CircularProgress size={24} /></Box>
      ) : (
        <Paper variant="outlined" sx={{ mb: 3 }}>
          <Table size="small" data-testid="thresholds-table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell><TableCell>Applies to</TableCell><TableCell>Rule</TableCell>
                <TableCell>Window · min calls · clear after</TableCell><TableCell>Alert kind</TableCell>
                <TableCell>Verdicts</TableCell><TableCell>Active</TableCell>
                {canEdit && <TableCell align="right">Actions</TableCell>}
              </TableRow>
            </TableHead>
            <TableBody>
              {(data?.thresholds || []).map((t: Threshold) => {
                const unit = metrics[t.metric]?.unit || '';
                const states = t.states || [];
                const breaches = states.filter(s => s.state === 'breach');
                return (
                  <TableRow key={t.id} sx={{ opacity: t.is_active ? 1 : 0.5 }} data-testid={`threshold-${t.id}`}>
                    <TableCell><Typography variant="body2" fontWeight={500}>{t.name}</Typography></TableCell>
                    <TableCell><Typography variant="caption">{scopeWords(t)}</Typography></TableCell>
                    <TableCell><code style={{ fontSize: 12 }}>{t.metric} {t.operator} {t.value} {unit}</code></TableCell>
                    <TableCell><Typography variant="caption">{t.metric === 'no_calls_days' ? 'window n/a' : `${t.window_minutes} min`} · {t.min_calls} · {t.clear_after_windows}</Typography></TableCell>
                    <TableCell><Chip size="small" label={t.alert_kind} variant="outlined" /></TableCell>
                    <TableCell>
                      {states.length === 0 ? <Typography variant="caption" color="text.secondary">not evaluated yet</Typography> : (
                        <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                          {breaches.length > 0 && (
                            <Tooltip title={breaches.map(s => `${s.api_slug}: ${s.detail}`).join('; ')}>
                              <Chip size="small" color="error" label={`${breaches.length} breach`} />
                            </Tooltip>
                          )}
                          {(['ok', 'insufficient', 'unknown'] as const).map(st => {
                            const n = states.filter(s => s.state === st).length;
                            return n ? <Chip key={st} size="small" color={STATE_COLOR[st]} variant="outlined" label={`${n} ${st}`} /> : null;
                          })}
                        </Stack>
                      )}
                    </TableCell>
                    <TableCell>{t.is_active ? <Chip size="small" color="success" label="on" /> : <Chip size="small" label="off" />}</TableCell>
                    {canEdit && (
                      <TableCell align="right">
                        <Tooltip title="Edit"><IconButton size="small" onClick={() => { setSaveError(null); setEditing({ ...t }); }} aria-label={`Edit threshold ${t.name}`}><EditIcon fontSize="small" /></IconButton></Tooltip>
                        <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => remove(t)} aria-label={`Delete threshold ${t.name}`}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
              {(data?.thresholds || []).length === 0 && (
                <TableRow><TableCell colSpan={8}><Typography variant="caption" color="text.secondary">No threshold applies to your APIs.</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </Paper>
      )}

      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="h6" fontWeight={600}>Alerts</Typography>
        <ToggleButtonGroup size="small" exclusive value={alertStatus} onChange={(_, v) => v && setAlertStatus(v)}>
          <ToggleButton value="open">open</ToggleButton>
          <ToggleButton value="cleared">cleared</ToggleButton>
          <ToggleButton value="all">all</ToggleButton>
        </ToggleButtonGroup>
      </Stack>
      <Paper variant="outlined">
        {alerts?.error ? <Alert severity="error">The alerts could not be read: {alerts.error}</Alert> : (
          <Table size="small" data-testid="api-alerts-table">
            <TableHead>
              <TableRow><TableCell>Raised</TableCell><TableCell>API</TableCell><TableCell>Kind</TableCell><TableCell>Message</TableCell><TableCell>Channels</TableCell><TableCell>Status</TableCell></TableRow>
            </TableHead>
            <TableBody>
              {(alerts?.alerts || []).map((a: any) => (
                <TableRow key={a.id}>
                  <TableCell><Typography variant="caption">{a.raised_at ? new Date(a.raised_at).toLocaleString() : '-'}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{a.feed_name}</Typography><Typography variant="caption" color="text.secondary">{a.subject_key}</Typography></TableCell>
                  <TableCell><Chip size="small" label={a.kind} color={a.severity >= 4 ? 'error' : a.severity >= 3 ? 'warning' : 'default'} variant="outlined" /></TableCell>
                  <TableCell><Typography variant="caption">{a.message}</Typography></TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                      {(a.deliveries || []).map((d: any, i: number) => (
                        <Tooltip key={i} title={d.reason || (Array.isArray(d.to) ? d.to.join(', ') : '')}>
                          <Chip size="small" label={`${d.channel} ${d.status}`} data-testid={`board-alert-${d.channel}`}
                                color={['sent', 'queued'].includes(d.status) ? 'success' : d.status === 'pending' ? 'default' : 'warning'} variant="outlined" />
                        </Tooltip>
                      ))}
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip size="small" label={a.status} color={a.status === 'open' ? 'error' : 'default'} />
                    {a.cleared_by && <Typography variant="caption" display="block" color="text.secondary">by {a.cleared_by}</Typography>}
                  </TableCell>
                </TableRow>
              ))}
              {(alerts?.alerts || []).length === 0 && (
                <TableRow><TableCell colSpan={6}><Typography variant="caption" color="text.secondary">No {alertStatus === 'all' ? '' : alertStatus} alert.</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </Paper>

      <Dialog open={!!editing} onClose={() => setEditing(null)} maxWidth="sm" fullWidth>
        <DialogTitle>{editing?.id ? 'Edit threshold' : 'New threshold'}</DialogTitle>
        <DialogContent>
          {editing && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              {saveError && <Alert severity="error" data-testid="threshold-error">{saveError}</Alert>}
              <TextField label="Name" size="small" value={editing.name || ''} onChange={e => setEditing({ ...editing, name: e.target.value })}
                         inputProps={{ 'data-testid': 'threshold-name' }} />
              <Stack direction="row" spacing={1}>
                <FormControl size="small" sx={{ flex: 1 }}>
                  <InputLabel id="thr-scope">Applies to</InputLabel>
                  <Select labelId="thr-scope" label="Applies to" value={editing.scope || 'global'}
                          onChange={e => setEditing({ ...editing, scope: e.target.value as any, api_kind: e.target.value === 'global' ? '' : (editing.api_kind || 'published_view'), scope_key: e.target.value === 'api' ? editing.scope_key || '' : '' })}>
                    <MenuItem value="global">every API</MenuItem>
                    <MenuItem value="kind">every API of a kind</MenuItem>
                    <MenuItem value="api">one API</MenuItem>
                  </Select>
                </FormControl>
                {editing.scope !== 'global' && (
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="thr-kind">Kind</InputLabel>
                    <Select labelId="thr-kind" label="Kind" value={editing.api_kind || 'published_view'} onChange={e => setEditing({ ...editing, api_kind: String(e.target.value) })}>
                      <MenuItem value="published_view">view</MenuItem>
                      <MenuItem value="published_report">report</MenuItem>
                    </Select>
                  </FormControl>
                )}
              </Stack>
              {editing.scope === 'api' && (
                <FormControl size="small">
                  <InputLabel id="thr-api">API</InputLabel>
                  <Select labelId="thr-api" label="API" value={editing.scope_key || ''} onChange={e => setEditing({ ...editing, scope_key: String(e.target.value) })}>
                    {apis.filter(a => a.api_kind === (editing.api_kind || 'published_view') && !a.is_redacted).map(a => (
                      <MenuItem key={a.key} value={a.key}>{a.name} ({a.key})</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
              <Stack direction="row" spacing={1}>
                <FormControl size="small" sx={{ flex: 2 }}>
                  <InputLabel id="thr-metric">Metric</InputLabel>
                  <Select labelId="thr-metric" label="Metric" value={editing.metric || 'error_rate'} onChange={e => setEditing({ ...editing, metric: String(e.target.value) })}>
                    {Object.entries(metrics).map(([m, spec]: any) => <MenuItem key={m} value={m}>{m} ({spec.unit}) — {spec.words}</MenuItem>)}
                  </Select>
                </FormControl>
                <FormControl size="small" sx={{ width: 90 }}>
                  <InputLabel id="thr-op">Op</InputLabel>
                  <Select labelId="thr-op" label="Op" value={editing.operator || '>'} onChange={e => setEditing({ ...editing, operator: String(e.target.value) })}>
                    {(data?.operators || ['>', '>=', '<', '<=']).map((o: string) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
                  </Select>
                </FormControl>
                <TextField label={`Value (${metrics[editing.metric || '']?.unit || ''})`} size="small" type="number" sx={{ flex: 1 }}
                           value={editing.value ?? ''} onChange={e => setEditing({ ...editing, value: Number(e.target.value) })}
                           inputProps={{ 'data-testid': 'threshold-value' }} />
              </Stack>
              <Stack direction="row" spacing={1}>
                <TextField label="Window (min)" size="small" type="number" value={editing.window_minutes ?? 15}
                           onChange={e => setEditing({ ...editing, window_minutes: Number(e.target.value) })}
                           helperText={editing.metric === 'no_calls_days' ? 'ignored for no_calls_days' : 'hourly rollup rows overlapping the window'} />
                <TextField label="Min calls" size="small" type="number" value={editing.min_calls ?? 50}
                           onChange={e => setEditing({ ...editing, min_calls: Number(e.target.value) })}
                           helperText="below it the window is insufficient, never a breach" />
                <TextField label="Clear after (windows)" size="small" type="number" value={editing.clear_after_windows ?? 2}
                           onChange={e => setEditing({ ...editing, clear_after_windows: Number(e.target.value) })}
                           helperText="consecutive healthy windows" />
              </Stack>
              <FormControl size="small">
                <InputLabel id="thr-alert-kind">Alert kind (severity, channels, AlertGroup)</InputLabel>
                <Select labelId="thr-alert-kind" label="Alert kind (severity, channels, AlertGroup)" value={editing.alert_kind || ''}
                        onChange={e => setEditing({ ...editing, alert_kind: String(e.target.value) })}>
                  {kinds.map((k: any) => (
                    <MenuItem key={k.kind} value={k.kind}>
                      {k.kind} — sev {k.severity}{k.to_bell ? ' · bell' : ''}{k.to_email ? ' · e-mail' : ''}{k.to_netcool ? ` · Netcool ${k.alert_group}` : ''}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControlLabel control={<Switch checked={editing.is_active !== false} onChange={e => setEditing({ ...editing, is_active: e.target.checked })} />} label="Active" />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditing(null)}>Cancel</Button>
          <Button variant="contained" onClick={save} disabled={saving} data-testid="threshold-save">{saving ? 'Saving...' : 'Save'}</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
