/**
 * Who may release or reject a HELD file (2026-10-12, the owner: "variance
 * hold admin or feed owner ... need generic mapping also ... can't just
 * hardcode").  An admin and the feed's owner always may; everyone else
 * through a USER GROUP mapped here, at a scope:
 *
 *   Every feed     global
 *   Feed group     e.g. one system entity's group -- both tables, every event
 *   Template       every member of one template
 *   One feed
 *
 * Everyone sees the mappings; an admin adds and removes them.  Targets are
 * PICKED by name, never typed as ids.  Backed by /api/feed-hold-approvers.
 */
import { appConfirm } from '../common/appDialogs';
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Autocomplete, Box, Button, IconButton, MenuItem, Paper, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import { Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { isAdminLike } from '../../utils/reportLifecycle';
import ListPager, { clientPage } from '../common/ListPager';

interface Approver {
  id: number; scope: string; scope_id: number | null; user_group_id: number;
  user_group_name: string | null; applies_to: string; created_by: string | null;
}
type Option = { id: number; name: string };

const SCOPES: { value: string; label: string }[] = [
  { value: 'global', label: 'Every feed' },
  { value: 'feed_group', label: 'A feed group (e.g. a system entity)' },
  { value: 'template', label: 'A template (all its feeds)' },
  { value: 'feed', label: 'One feed' },
];

export default function HoldApprovers() {
  const { user } = useAuth() as any;
  const admin = isAdminLike(user);
  const [rows, setRows] = useState<Approver[] | null>(null);
  const [deployment, setDeployment] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scope, setScope] = useState('feed_group');
  const [target, setTarget] = useState<Option | null>(null);
  const [group, setGroup] = useState<Option | null>(null);
  const [targets, setTargets] = useState<Option[]>([]);
  const [groups, setGroups] = useState<Option[]>([]);
  const [busy, setBusy] = useState(false);
  // a mapping may exist per feed (thousands of feeds): the list pages
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const pg = clientPage(rows || [], page, pageSize);

  const load = useCallback(() => {
    api.holdApprovers()
      .then((r: any) => { setRows(r.approvers || []); setDeployment(r.deployment_group || null); setError(null); })
      .catch((e: any) => setError(e?.message || 'Could not read the approvers'));
  }, []);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!admin) return;
    api.listUserGroups({ is_active: true })
      .then((r: any) => setGroups((Array.isArray(r) ? r : r?.items || r?.groups || []).map((g: any) => ({ id: g.id, name: g.name }))))
      .catch(() => setGroups([]));
  }, [admin]);

  useEffect(() => {
    setTarget(null);
    if (!admin || scope === 'global') { setTargets([]); return; }
    const pick = (r: any) => (Array.isArray(r) ? r : r?.items || r?.feeds || r?.templates || []);
    const p = scope === 'feed_group' ? api.listFeedGroups()
      : scope === 'template' ? api.listFeedTemplates() : api.listFeeds();
    p.then((r: any) => setTargets(pick(r).map((x: any) => ({ id: x.id, name: x.display_label || x.name }))))
      .catch(() => setTargets([]));
  }, [admin, scope]);

  const add = async () => {
    if (!group || (scope !== 'global' && !target)) return;
    setBusy(true);
    try {
      await api.addHoldApprover({ scope, scope_id: scope === 'global' ? null : target!.id, user_group_id: group.id });
      setTarget(null); setGroup(null); load();
    } catch (e: any) {
      setError(e?.message || 'The mapping was refused');
    } finally {
      setBusy(false);
    }
  };
  const remove = async (a: Approver) => {
    if (!await appConfirm(`Remove ${a.user_group_name} as approver for ${a.applies_to}?`)) return;
    try { await api.deleteHoldApprover(a.id); load(); } catch (e: any) { setError(e?.message || 'Could not remove it'); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 1.5, mb: 1.5 }} data-testid="hold-approvers">
      <Typography variant="subtitle2">Who can release or reject a held file</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        An admin and the feed's owner always can. Anyone else, through a user group mapped below.
        {deployment ? ` The deployment also names ${deployment} for every feed.` : ''}
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setError(null)}>{error}</Alert>}
      <Table size="small">
        <TableHead>
          <TableRow><TableCell>User group</TableCell><TableCell>Approves for</TableCell>
            <TableCell>Added by</TableCell>{admin && <TableCell align="right" />}</TableRow>
        </TableHead>
        <TableBody>
          {rows && rows.length === 0 && (
            <TableRow><TableCell colSpan={4}>
              <Typography variant="body2" color="text.secondary" data-testid="hold-approvers-none">
                No approver group is mapped — only admins and each feed's owner decide.
              </Typography>
            </TableCell></TableRow>
          )}
          {pg.rows.map(a => (
            <TableRow key={a.id} data-testid="hold-approver">
              <TableCell>{a.user_group_name ?? `group ${a.user_group_id}`}</TableCell>
              <TableCell>{a.applies_to}</TableCell>
              <TableCell>{a.created_by || '-'}</TableCell>
              {admin && (
                <TableCell align="right">
                  <Tooltip title="Remove this mapping">
                    <IconButton size="small" aria-label={`Remove ${a.user_group_name} for ${a.applies_to}`}
                                onClick={() => remove(a)}><DeleteIcon fontSize="small" /></IconButton>
                  </Tooltip>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {rows && rows.length > 0 && (
        <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="hold-approvers-pager" />
      )}
      {admin && (
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} sx={{ mt: 1 }} alignItems={{ md: 'center' }}>
          <TextField select size="small" label="Approves for" value={scope} sx={{ minWidth: 230 }}
                     onChange={e => setScope(String(e.target.value))} inputProps={{ 'aria-label': 'Approves for' }}>
            {SCOPES.map(s => <MenuItem key={s.value} value={s.value}>{s.label}</MenuItem>)}
          </TextField>
          {scope !== 'global' && (
            <Autocomplete size="small" options={targets} value={target} sx={{ minWidth: 260 }}
                          getOptionLabel={o => o.name} isOptionEqualToValue={(a, b) => a.id === b.id}
                          onChange={(_, v) => setTarget(v)}
                          renderInput={p => <TextField {...p} label={SCOPES.find(s => s.value === scope)?.label.split(' (')[0]} />} />
          )}
          <Autocomplete size="small" options={groups} value={group} sx={{ minWidth: 220 }}
                        getOptionLabel={o => o.name} isOptionEqualToValue={(a, b) => a.id === b.id}
                        onChange={(_, v) => setGroup(v)}
                        renderInput={p => <TextField {...p} label="User group" />} />
          <Box>
            <Button variant="contained" size="small" startIcon={<AddIcon />} onClick={add}
                    disabled={busy || !group || (scope !== 'global' && !target)} data-testid="hold-approver-add">
              Add approver
            </Button>
          </Box>
        </Stack>
      )}
    </Paper>
  );
}
