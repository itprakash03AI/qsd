import { appConfirm } from '../common/appDialogs';
/**
 * Stopping a running feed -- the words, ONCE (2026-10-26).
 *
 * The owner: "if any feed is running and we need to cancel, we should be
 * able to cancel in case something is wrong ... the same cancellation
 * should be done at the source also".
 *
 * Every place that shows a running feed (the Feed Run Status board row and
 * its task panel, the Feeds list's last-run cell, the run steps dialog, the
 * executions panel) asks the same question in the same plain words and
 * shows the same "Cancelled by X at T" afterwards.  The server does the
 * stopping (core/feed/cancel.py) and writes what the stop reached; the
 * screen only repeats its words.
 */

/** The confirm question.  `source` = where the query runs, when known. */
export function stopRunQuestion(feedName?: string | null, source?: string | null): string {
  const what = feedName ? `Stop this run of ${feedName}?` : 'Stop this run?';
  const where = source ? `The query on ${source} is stopped too` : 'The query at the source is stopped too';
  return `${what} ${where}; nothing is delivered.`;
}

/** The confirm, through the app's own dialog (appConfirm, 2026-10-30).
 *  ASYNC: every caller must `await` it -- a bare `if (!confirmStopRun(..))`
 *  tests a Promise, which is always truthy, and would stop without asking. */
export function confirmStopRun(feedName?: string | null, source?: string | null): Promise<boolean> {
  return appConfirm(stopRunQuestion(feedName, source));
}

/** "Cancelled by X at T" from the row's own columns. */
export function cancelledWords(by?: string | null, at?: string | null): string {
  const who = by ? `Cancelled by ${by}` : 'Cancelled';
  if (!at) return who;
  const d = new Date(at);
  const when = Number.isFinite(d.getTime())
    ? d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' })
    : at;
  return `${who} at ${when}`;
}

/** What the screen says once the stop was asked for. */
export const STOP_REQUESTED = 'stop requested — the query is being stopped at the source; nothing is delivered';
