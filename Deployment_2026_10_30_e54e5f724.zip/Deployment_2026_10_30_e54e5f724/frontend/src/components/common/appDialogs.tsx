/**
 * The app's own confirm / message / question popups (2026-10-30).
 *
 * About 120 places called the browser's window.confirm / alert / prompt -- the
 * grey "localhost says..." box that looks like a different, older application
 * next to every MUI dialog.  They now call appConfirm / appAlert / appPrompt,
 * which open ONE styled dialog mounted once in App.tsx (<AppDialogHost />, the
 * same single-mount pattern as PortalPasswordHost).
 *
 * When no host is mounted -- a unit test rendering one component, the login
 * screen -- each call falls back to the browser's own box, so behaviour (and
 * every test that stubs window.confirm) is unchanged.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography,
} from '@mui/material';

type Kind = 'confirm' | 'alert' | 'prompt';

export interface AppDialogOptions {
  title?: string;
  /** label of the button that says yes; derived from the message when omitted */
  confirmText?: string;
  /** red button -- derived from the message (delete / remove / ...) when omitted */
  danger?: boolean;
}

interface Request extends AppDialogOptions {
  kind: Kind;
  message: string;
  defaultValue?: string;
  resolve: (value: any) => void;
}

let openDialog: ((req: Request) => void) | null = null;

const DANGER = /^(delete|remove|revoke|drop|deactivate|archive|cancel|stop|hard delete|bulk-delete|mark)\b/i;
const VERBS = /^(delete|remove|revoke|drop|deactivate|archive|cancel|stop|rerun|re-run|run|force-start|request|mark|bulk-delete|discard|restore|replace|overwrite|send|publish|apply|reset|clear)\b/i;

function verbOf(message: string): string | undefined {
  const m = message.trim().match(VERBS);
  if (!m) return undefined;
  const w = m[1].toLowerCase();
  if (w === 'request') return 'Run now';
  if (w === 'mark') return 'Mark';
  return w.charAt(0).toUpperCase() + w.slice(1);
}

export function appConfirm(message: string, options: AppDialogOptions = {}): Promise<boolean> {
  if (!openDialog) return Promise.resolve(window.confirm(message));
  const host = openDialog;
  return new Promise<boolean>(resolve => host({ kind: 'confirm', message, ...options, resolve }));
}

export function appAlert(message: string, options: AppDialogOptions = {}): Promise<void> {
  if (!openDialog) { window.alert(message); return Promise.resolve(); }
  const host = openDialog;
  return new Promise<void>(resolve => host({ kind: 'alert', message, ...options, resolve }));
}

export function appPrompt(message: string, defaultValue = '', options: AppDialogOptions = {}): Promise<string | null> {
  if (!openDialog) return Promise.resolve(window.prompt(message, defaultValue));
  const host = openDialog;
  return new Promise<string | null>(resolve => host({ kind: 'prompt', message, defaultValue, ...options, resolve }));
}

const AppDialogHost: React.FC = () => {
  const queue = useRef<Request[]>([]);
  const showing = useRef<Request | null>(null);
  const [current, setCurrent] = useState<Request | null>(null);
  const [text, setText] = useState('');

  const show = useCallback((req: Request | undefined) => {
    showing.current = req || null;
    setCurrent(req || null);
    setText(req?.defaultValue ?? '');
  }, []);

  useEffect(() => {
    openDialog = (req: Request) => {
      if (showing.current) queue.current.push(req);
      else show(req);
    };
    return () => {
      openDialog = null;
      // a request still waiting must not hang its caller
      if (showing.current) queue.current.unshift(showing.current);
      showing.current = null;
      queue.current.forEach(r => r.resolve(r.kind === 'confirm' ? false : r.kind === 'prompt' ? null : undefined));
      queue.current = [];
    };
  }, [show]);

  const finish =(answer: boolean) => {
    if (!current) return;
    if (current.kind === 'confirm') current.resolve(answer);
    else if (current.kind === 'prompt') current.resolve(answer ? text : null);
    else current.resolve(undefined);
    show(queue.current.shift());
  };

  if (!current) return null;
  const isAlert = current.kind === 'alert';
  const danger = current.danger ?? (current.kind === 'confirm' && DANGER.test(current.message.trim()));
  const yes = current.confirmText || (isAlert ? 'OK' : current.kind === 'prompt' ? 'OK' : verbOf(current.message) || 'OK');
  const title = current.title || (isAlert ? 'Please note' : current.kind === 'prompt' ? 'Please enter' : 'Please confirm');

  return (
    <Dialog open onClose={() => finish(false)} maxWidth="sm" fullWidth data-testid="app-dialog">
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {current.message}
        </Typography>
        {current.kind === 'prompt' && (
          <TextField autoFocus fullWidth size="small" sx={{ mt: 2 }} value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') finish(true); }} />
        )}
      </DialogContent>
      <DialogActions>
        {!isAlert && <Button onClick={() => finish(false)}>Cancel</Button>}
        <Button variant="contained" color={danger ? 'error' : 'primary'} autoFocus={current.kind !== 'prompt'}
          onClick={() => finish(true)}>{yes}</Button>
      </DialogActions>
    </Dialog>
  );
};

export default AppDialogHost;
