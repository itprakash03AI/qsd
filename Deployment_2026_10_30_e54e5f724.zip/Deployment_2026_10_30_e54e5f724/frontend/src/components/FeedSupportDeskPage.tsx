/**
 * FeedSupportDeskPage (2026-09-27) — the operator's screen at 04:50.
 *
 * ONE read, GET /api/run-surface (api/run_surface_api.py over
 * core/feed/run_surface.py, BRD §13.1), scoped by the server to the feeds
 * the signed-in user may view: what is running now and on which pod with
 * which connection claims; what is blocked and on WHAT (the blocking set,
 * never a count); what failed, at which step, with which error; the
 * active change windows.  Pick a feed for its delivery record and its
 * decisions.
 *
 * Every section is independent.  "No rows" and "could not be read" are
 * OPPOSITE findings and render apart: an unavailable section is a red
 * alert naming the reason, never an empty table that reads as "nothing to
 * report".
 *
 * Row actions are the controls that already exist, with their own guards:
 *   * Rerun          -> POST /api/feed-runs/{id}/rerun
 *   * Skip deps      -> FeedRunSkipDepsDialog (POST .../skip-dependencies)
 *   * Retry a hop    -> FeedDeliveryAttemptsDialog (POST /api/delivery-attempts/{id}/retry)
 * The page itself never writes.
 */
import { appConfirm } from './common/appDialogs';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Autocomplete, Box, Button, Chip, CircularProgress, Paper, Stack,
  Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip,
  Typography,
} from '@mui/material';
import {
  Refresh as RefreshIcon, Replay as RerunIcon,
  RemoveCircleOutline as SkipDepsIcon, LocalShipping as DeliveryIcon,
  SupportAgent as DeskIcon, OpenInNew as OpenIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  RunSurfaceBlockedRow, RunSurfaceFailureRow, RunSurfaceResponse,
  RunSurfaceRunningRow, RunSurfaceSection,
} from '../services/api/feedOperations';
import { toArray } from '../utils/toArray';
import RowActions from './common/RowActions';
import type { DependencyClocks } from '../services/api/feedDependencies';
import type { ReportSloRow } from '../services/api/reportReadiness';
import { deadlineLine, stageColor, stageLabel, usualByLine } from '../utils/actingTime';
import { promiseText, sloCause, sloStatusLabel, sloTone } from '../utils/reportReadiness';
import { reportPath } from '../utils/reportUrls';
import FeedRunSkipDepsDialog from './FeedRunSkipDepsDialog';
import FeedDeliveryAttemptsDialog from './FeedDeliveryAttemptsDialog';

type FeedRef = { id: number; name: string; display_name?: string | null };

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; data: RunSurfaceResponse };

const todayIso = () => new Date().toISOString().slice(0, 10);

const fmtTs = (v: string | null | undefined) => {
  if (!v) return '—';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleTimeString();
};

/** A section's verdict, in words: unavailable / none / n rows. */
const SectionHeader: React.FC<{
  title: string; section?: RunSurfaceSection<any>; hint: string;
}> = ({ title, section, hint }) => (
  <Stack direction="row" alignItems="center" gap={1} sx={{ mb: 1 }}>
    <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{title}</Typography>
    {section && !section.unavailable && (
      <Chip size="small" label={section.count} sx={{ height: 20 }} />
    )}
    <Typography variant="caption" color="text.secondary">{hint}</Typography>
  </Stack>
);

const Unavailable: React.FC<{ name: string; reason: string }> = ({ name, reason }) => (
  <Alert severity="error" data-testid={`section-unavailable-${name}`} sx={{ mb: 1 }}>
    This section could not be read — an empty list here would NOT mean "nothing to report". {reason}
  </Alert>
);

const NoRows: React.FC<{ text: string; name: string }> = ({ text, name }) => (
  <Typography variant="body2" color="text.secondary" data-testid={`section-empty-${name}`}
              sx={{ px: 1, pb: 1 }}>{text}</Typography>
);

const FeedSupportDeskPage: React.FC = () => {
  const navigate = useNavigate();
  const [businessDate, setBusinessDate] = useState<string>(todayIso());
  const [feeds, setFeeds] = useState<FeedRef[]>([]);
  const [feedsError, setFeedsError] = useState<string | null>(null);
  const [focusFeed, setFocusFeed] = useState<FeedRef | null>(null);
  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });
  const [notice, setNotice] = useState<{ tone: 'success' | 'error'; text: string } | null>(null);
  const [skipRun, setSkipRun] = useState<{ id: number; feed_config_id: number; feed_name: string | null; deps: string[] } | null>(null);
  const [deliveryFeed, setDeliveryFeed] = useState<{ id: number; name: string } | null>(null);
  const [rerunning, setRerunning] = useState<number | null>(null);
  // 2026-09-28 -- which "late by history" rows have their blocked feeds shown
  const [lateOpen, setLateOpen] = useState<Record<string, boolean>>({});

  const feedById = useMemo(() => {
    const m = new Map<number, FeedRef>();
    feeds.forEach(f => m.set(f.id, f));
    return m;
  }, [feeds]);
  const feedLabel = (id: number | null | undefined): string => {
    if (id == null) return '—';
    const f = feedById.get(id);
    return f ? (f.display_name || f.name) : `feed #${id}`;
  };

  const loadFeeds = useCallback(async () => {
    try {
      const rows = toArray(await api.listFeeds()) as any[];
      setFeeds(rows.map(r => ({ id: r.id, name: r.name, display_name: r.display_name })));
      setFeedsError(null);
    } catch (e: any) {
      // the surface still loads; feed NAMES fall back to ids and the page says why
      setFeedsError(e?.message || 'the feed list could not be read');
    }
  }, []);

  const loadSurface = useCallback(async () => {
    setLoad({ phase: 'loading' });
    try {
      const data = await api.getRunSurface({
        business_date: businessDate,
        ...(focusFeed ? { feed_config_id: focusFeed.id } : {}),
      });
      setLoad({ phase: 'ready', data });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || 'Failed to load the run surface' });
    }
  }, [businessDate, focusFeed]);

  useEffect(() => { void loadFeeds(); }, [loadFeeds]);
  useEffect(() => { void loadSurface(); }, [loadSurface]);

  const rerun = async (row: RunSurfaceFailureRow) => {
    const label = feedLabel(row.feed_config_id);
    if (!await appConfirm(`Rerun ${label} (run ${row.feed_run_id}) for ${businessDate}?`)) return;
    setRerunning(row.feed_run_id);
    setNotice(null);
    try {
      await api.rerunFeedRun(row.feed_run_id);
      setNotice({ tone: 'success', text: `Rerun accepted for ${label} (run ${row.feed_run_id}).` });
      void loadSurface();
    } catch (e: any) {
      setNotice({ tone: 'error', text: `Rerun of ${label} refused: ${e?.message || e}` });
    } finally {
      setRerunning(null);
    }
  };

  const data = load.phase === 'ready' ? load.data : null;
  const sec = <T,>(name: keyof RunSurfaceResponse['sections']) =>
    (data?.sections?.[name] as RunSurfaceSection<T> | undefined);
  const late = sec<DependencyClocks>('late_by_history');
  const reportSlos = sec<ReportSloRow>('report_slos');
  const running = sec<RunSurfaceRunningRow>('running_now');
  const blocked = sec<RunSurfaceBlockedRow>('blocked');
  const failures = sec<RunSurfaceFailureRow>('failures');
  const windows = sec<Record<string, any>>('deployment_windows');
  const delivery = sec<Record<string, any>>('delivery');
  const decisions = sec<Record<string, any>>('decisions');

  return (
    <Box sx={{ p: { xs: 2, md: 3 } }}>
      <Stack direction="row" alignItems="center" gap={1} flexWrap="wrap" sx={{ mb: 2 }}>
        <DeskIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 700, flexGrow: 1 }}>Support Desk</Typography>
        <TextField label="Business date" type="date" size="small" value={businessDate}
                   onChange={e => setBusinessDate(e.target.value || todayIso())}
                   InputLabelProps={{ shrink: true }}
                   inputProps={{ 'aria-label': 'Business date' }} />
        <Autocomplete
          size="small" sx={{ minWidth: 260 }}
          options={feeds}
          value={focusFeed}
          onChange={(_, v) => setFocusFeed(v)}
          getOptionLabel={f => f.display_name ? `${f.display_name} (${f.name})` : f.name}
          isOptionEqualToValue={(a, b) => a.id === b.id}
          renderInput={params => (
            <TextField {...params} label="Focus on a feed (delivery record + decisions)" />
          )}
        />
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => void loadSurface()}
                aria-label="Refresh">Refresh</Button>
        <Button variant="text" endIcon={<OpenIcon />} onClick={() => navigate('/feeds/today')}
                aria-label="Open the Feed Run Status page">Feed Run Status</Button>
      </Stack>

      {notice && (
        <Alert severity={notice.tone} sx={{ mb: 2 }} onClose={() => setNotice(null)}
               data-testid="desk-notice">{notice.text}</Alert>
      )}
      {feedsError && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Feed names are unavailable ({feedsError}); rows show feed ids.
        </Alert>
      )}
      {load.phase === 'error' && (
        <Alert severity="error" data-testid="desk-load-error">{load.message}</Alert>
      )}
      {load.phase === 'loading' && (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>
      )}

      {data && (
        <>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
            {data.business_date} · generated {fmtTs(data.generated_at)}
            {data.unavailable_sections.length > 0 && (
              <> · <b>{data.unavailable_sections.length} section(s) could not be read</b></>
            )}
          </Typography>

          {/* ── Late by its own history (2026-09-28) ──────────────────
              One row per blocking dependency, worst first, from the SAME
              clocks the SLA watcher alerts on (acting_time.clocks_for_blocked).
              Three states per row, never folded: a minted clock; no usable
              history yet; could not tell.  Skip opens the existing per-run
              skip dialog with this dependency pre-selected. */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-late_by_history">
            <SectionHeader title="Late by its own history" section={late}
                           hint="each blocking dependency against its usual arrival (p95) and the time left to decide — the clocks the SLA alert uses" />
            {late?.unavailable && <Unavailable name="late_by_history" reason={late.unavailable} />}
            {late && !late.unavailable && late.rows.length === 0 && (
              <NoRows name="late_by_history" text="No dependency is blocking a run." />
            )}
            {late && !late.unavailable && late.rows.length > 0 && (
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell>Dependency</TableCell><TableCell>Stage</TableCell>
                  <TableCell>By its own history</TableCell>
                  <TableCell>Blocks · tightest SLA · decide by</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {late.rows.flatMap(r => {
                    const feedsOf = r.blocked_feeds || [];
                    // The run to skip: the tightest-SLA feed's when it is in view, else the first.
                    const first = feedsOf.find(f => f.feed_name && f.feed_name === r.sla_feed) || feedsOf[0];
                    const open = !!lateOpen[r.dependency];
                    const out = [(
                      <TableRow key={r.dependency} data-testid={`late-row-${r.dependency}`}>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 700 }}>{r.dependency}</Typography>
                          {r.summary && (
                            <Typography variant="caption" color="text.secondary" component="div"
                                        data-testid={`late-summary-${r.dependency}`}>
                              {r.summary}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={stageLabel(r)} color={stageColor(r)}
                                variant={r.stage ? 'filled' : 'outlined'} sx={{ height: 20 }}
                                data-testid={`late-stage-${r.dependency}`} />
                        </TableCell>
                        <TableCell data-testid={`late-history-${r.dependency}`}>
                          <Typography variant="body2">{usualByLine(r)}</Typography>
                        </TableCell>
                        <TableCell data-testid={`late-deadline-${r.dependency}`}>
                          <Typography variant="body2">{deadlineLine(r)}</Typography>
                        </TableCell>
                        <TableCell align="right">
                          <RowActions rowName={r.dependency} primary={[
                            { label: 'Skip dependency', icon: <SkipDepsIcon fontSize="small" />,
                              disabled: !first || first.feed_run_id == null,
                              disabledReason: 'none of the held runs is in your view',
                              onClick: () => {
                                if (!first || first.feed_run_id == null) return;
                                setSkipRun({ id: first.feed_run_id, feed_config_id: first.feed_config_id,
                                             feed_name: first.feed_name || feedLabel(first.feed_config_id),
                                             deps: [r.dependency] });
                              } },
                          ]} more={[
                            { label: open ? 'Hide blocked feeds' : 'Show blocked feeds',
                              icon: <OpenIcon fontSize="small" />,
                              description: `${r.blocked_count} feed(s) are waiting on this dependency`,
                              onClick: () => setLateOpen(prev => ({ ...prev, [r.dependency]: !open })) },
                          ]} />
                        </TableCell>
                      </TableRow>
                    )];
                    if (open) {
                      out.push(
                        <TableRow key={`${r.dependency}-feeds`} data-testid={`late-feeds-${r.dependency}`}>
                          <TableCell colSpan={5} sx={{ bgcolor: 'action.hover' }}>
                            <Stack direction="row" gap={0.5} flexWrap="wrap">
                              {feedsOf.map(f => (
                                <Chip key={`${f.feed_config_id}-${f.feed_run_id ?? 'x'}`} size="small" variant="outlined"
                                      label={`${f.feed_name || feedLabel(f.feed_config_id)}${
                                        f.feed_run_id != null ? ` · run ${f.feed_run_id}` : ''}`} />
                              ))}
                            </Stack>
                          </TableCell>
                        </TableRow>,
                      );
                    }
                    return out;
                  })}
                </TableBody>
              </Table>
            )}
          </Paper>

          {/* ── Reports at risk (2026-09-28) ───────────────────────────
              Every report PROMISE ("fresh and served by 07:00 London") for
              the date the reader may see, worst first: missed with its
              cause, at risk, could not evaluate, served late, ready, met.
              Scoped by the report view rule on the server.  The page
              writes nothing: the promise is declared on the report. */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-report_slos">
            <SectionHeader title="Reports at risk" section={reportSlos}
                           hint="each report promise for this date — met when a run completed with readiness Complete by the promised time" />
            {reportSlos?.unavailable && <Unavailable name="report_slos" reason={reportSlos.unavailable} />}
            {reportSlos && !reportSlos.unavailable && reportSlos.rows.length === 0 && (
              <NoRows name="report_slos" text="No report promises for this date." />
            )}
            {reportSlos && !reportSlos.unavailable && reportSlos.rows.length > 0 && (
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell>Report</TableCell><TableCell>Status</TableCell>
                  <TableCell>Promise</TableCell><TableCell>Why</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {reportSlos.rows.map(r => (
                    <TableRow key={r.report_id} data-testid={`slo-row-${r.report_id}`}>
                      <TableCell>
                        <Button size="small" variant="text" sx={{ textTransform: 'none', p: 0, minWidth: 0 }}
                                aria-label={`Open report ${r.report_name || r.report_id}`}
                                onClick={() => navigate(reportPath({ id: r.report_id, slug: r.report_slug }))}>
                          {r.report_name || `report #${r.report_id}`}
                        </Button>
                      </TableCell>
                      <TableCell data-testid={`slo-status-${r.report_id}`}>
                        <Chip size="small" label={sloStatusLabel(r)} color={sloTone(r.status)}
                              variant={r.status === 'breached' || r.status === 'met' ? 'filled' : 'outlined'}
                              sx={{ height: 22 }} />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{promiseText(r)}{r.calendar_name ? ` · ${r.calendar_name}` : ''}</Typography>
                        {r.sla_at && (
                          <Typography variant="caption" color="text.secondary" component="div">
                            {fmtTs(r.sla_at)}{r.served_at ? ` · served ${fmtTs(r.served_at)}` : ''}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell data-testid={`slo-why-${r.report_id}`}>
                        <Typography variant="body2">
                          {r.cause ? `${sloCause(r.cause)}` : ''}
                          {r.detail ? (r.cause ? ' — ' : '') + r.detail : ''}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Paper>

          {/* ── Running now ─────────────────────────────────────────── */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-running_now">
            <SectionHeader title="Running now" section={running}
                           hint="across the fleet: the claims table, not this pod" />
            {running?.unavailable && <Unavailable name="running_now" reason={running.unavailable} />}
            {running && !running.unavailable && running.rows.length === 0 && (
              <NoRows name="running_now" text="Nothing is running." />
            )}
            {running && !running.unavailable && running.rows.length > 0 && (
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell>Feed</TableCell><TableCell>Run</TableCell><TableCell>Pod</TableCell>
                  <TableCell>Claimed</TableCell><TableCell>Heartbeat</TableCell><TableCell>Connections</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {running.rows.map((r, i) => (
                    <TableRow key={`${r.run_kind}-${r.run_id}-${i}`}>
                      <TableCell>{feedLabel(r.feed_config_id)}</TableCell>
                      <TableCell>{r.run_kind || '—'} {r.run_id ?? ''}</TableCell>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{r.pod_id || '—'}</TableCell>
                      <TableCell>{fmtTs(r.claimed_at)}</TableCell>
                      <TableCell>{fmtTs(r.heartbeat_at)}</TableCell>
                      <TableCell>{(r.connection_ids || []).filter(x => x != null).join(', ') || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Paper>

          {/* ── Blocked, on WHAT ────────────────────────────────────── */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-blocked">
            <SectionHeader title="Blocked" section={blocked}
                           hint="held runs and the dependencies holding them" />
            {blocked?.unavailable && <Unavailable name="blocked" reason={blocked.unavailable} />}
            {blocked && !blocked.unavailable && blocked.rows.length === 0 && (
              <NoRows name="blocked" text="No run is waiting on a dependency." />
            )}
            {blocked && !blocked.unavailable && blocked.rows.length > 0 && (
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell>Feed</TableCell><TableCell>Run</TableCell>
                  <TableCell>Waiting on</TableCell><TableCell align="right">Actions</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {blocked.rows.map(r => {
                    const label = feedLabel(r.feed_config_id);
                    const deps = (r.blocking || []).map(b => b.dependency).filter(Boolean);
                    return (
                      <TableRow key={r.feed_run_id} data-testid={`blocked-row-${r.feed_run_id}`}>
                        <TableCell>{label}</TableCell>
                        <TableCell>{r.feed_run_id}</TableCell>
                        <TableCell>
                          {r.blocking.length === 0 ? (
                            <Typography variant="caption" color="text.secondary">
                              blocking set unknown (the feed row could not be read)
                            </Typography>
                          ) : (
                            <Stack gap={0.25}>
                              {r.blocking.map(b => (
                                <Tooltip key={b.dependency} title={b.reason || ''}>
                                  <span>
                                    <Chip size="small" variant="outlined" label={b.dependency}
                                          color={b.verdict === 'COULD_NOT_TELL' ? 'warning' : 'default'}
                                          sx={{ height: 20, mr: 0.5 }} />
                                    <Typography variant="caption" color="text.secondary">
                                      {b.verdict}{b.reason ? ` — ${b.reason}` : ''}
                                    </Typography>
                                  </span>
                                </Tooltip>
                              ))}
                            </Stack>
                          )}
                        </TableCell>
                        <TableCell align="right">
                          <RowActions rowName={`${label} run ${r.feed_run_id}`} primary={[
                            { label: 'Skip dependencies', icon: <SkipDepsIcon fontSize="small" />,
                              onClick: () => setSkipRun({ id: r.feed_run_id, feed_config_id: r.feed_config_id,
                                                          feed_name: label, deps }) },
                          ]} more={[
                            { label: 'Open on Feed Run Status', icon: <OpenIcon fontSize="small" />,
                              onClick: () => navigate(`/feeds/today?feed=${encodeURIComponent(
                                feedById.get(r.feed_config_id)?.name || String(r.feed_config_id))}`) },
                          ]} />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </Paper>

          {/* ── Failures, with the step ─────────────────────────────── */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-failures">
            <SectionHeader title="Failed" section={failures}
                           hint="the step and the error decide what support does next" />
            {failures?.unavailable && <Unavailable name="failures" reason={failures.unavailable} />}
            {failures && !failures.unavailable && failures.rows.length === 0 && (
              <NoRows name="failures" text="No run has failed." />
            )}
            {failures && !failures.unavailable && failures.rows.length > 0 && (
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell>Feed</TableCell><TableCell>Run</TableCell><TableCell>Step</TableCell>
                  <TableCell>Error</TableCell><TableCell>Completeness</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {failures.rows.map(r => {
                    const label = feedLabel(r.feed_config_id);
                    const feedName = feedById.get(r.feed_config_id)?.name || String(r.feed_config_id);
                    return (
                      <TableRow key={r.feed_run_id} data-testid={`failure-row-${r.feed_run_id}`}>
                        <TableCell>{label}</TableCell>
                        <TableCell>{r.feed_run_id}</TableCell>
                        <TableCell>
                          {r.failed_stage
                            ? <Chip size="small" color="error" variant="outlined" label={r.failed_stage} sx={{ height: 20 }} />
                            : <Typography variant="caption" color="text.secondary">step not recorded</Typography>}
                        </TableCell>
                        <TableCell sx={{ fontSize: 12, maxWidth: 420, wordBreak: 'break-word' }}>
                          {r.error || '—'}
                        </TableCell>
                        <TableCell sx={{ fontSize: 12 }}>
                          {r.completeness?.state || r.completeness?.verdict || '—'}
                        </TableCell>
                        <TableCell align="right">
                          <RowActions rowName={`${label} run ${r.feed_run_id}`} primary={[
                            { label: 'Rerun', icon: rerunning === r.feed_run_id
                                ? <CircularProgress size={14} /> : <RerunIcon fontSize="small" />,
                              disabled: rerunning !== null, disabledReason: 'A rerun is being accepted',
                              onClick: () => void rerun(r) },
                            { label: 'Delivery attempts', icon: <DeliveryIcon fontSize="small" />,
                              description: 'Per-hop history; retry a hop with a reason',
                              onClick: () => setDeliveryFeed({ id: r.feed_config_id, name: feedName }) },
                          ]} more={[
                            { label: 'Open on Feed Run Status', icon: <OpenIcon fontSize="small" />,
                              onClick: () => navigate(`/feeds/today?feed=${encodeURIComponent(feedName)}`) },
                          ]} />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </Paper>

          {/* ── Change windows ──────────────────────────────────────── */}
          <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-deployment_windows">
            <SectionHeader title="Change windows" section={windows}
                           hint="a run that silently did not start is indistinguishable from a broken scheduler" />
            {windows?.unavailable && <Unavailable name="deployment_windows" reason={windows.unavailable} />}
            {windows && !windows.unavailable && windows.rows.length === 0 && (
              <NoRows name="deployment_windows" text="No active or imminent window." />
            )}
            {windows && !windows.unavailable && windows.rows.length > 0 && (
              <Stack gap={0.5}>
                {windows.rows.map((w, i) => (
                  <Typography key={w.id ?? i} variant="body2">
                    <b>{w.scope || 'window'}{w.scope_id ? ` ${w.scope_id}` : ''}</b>
                    {w.reason ? ` — ${w.reason}` : ''}
                    {w.ends_at ? ` (until ${fmtTs(w.ends_at)})` : ''}
                    {typeof w.refusals === 'number' ? ` · ${w.refusals} refusal(s)` : ''}
                  </Typography>
                ))}
              </Stack>
            )}
          </Paper>

          {/* ── The focused feed ────────────────────────────────────── */}
          {focusFeed && (
            <Paper sx={{ p: 1.5, mb: 2 }} data-testid="section-focus">
              <Stack direction="row" alignItems="center" gap={1} sx={{ mb: 1 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                  {focusFeed.display_name || focusFeed.name}
                </Typography>
                <Button size="small" startIcon={<DeliveryIcon />}
                        onClick={() => setDeliveryFeed({ id: focusFeed.id, name: focusFeed.name })}
                        aria-label={`Delivery attempts — ${focusFeed.name}`}>
                  Delivery attempts / retry a hop
                </Button>
              </Stack>
              <SectionHeader title="Delivered?" section={delivery}
                             hint="produced and delivered are two different questions" />
              {delivery?.unavailable && <Unavailable name="delivery" reason={delivery.unavailable} />}
              {delivery && !delivery.unavailable && delivery.rows.length === 0 && (
                <NoRows name="delivery" text="No delivery attempt recorded for this feed." />
              )}
              {delivery && !delivery.unavailable && delivery.rows.length > 0 && (
                <Table size="small" sx={{ mb: 2 }}>
                  <TableHead><TableRow>
                    <TableCell>Hop</TableCell><TableCell>Type</TableCell><TableCell>Attempt</TableCell>
                    <TableCell>Status</TableCell><TableCell>Ack</TableCell><TableCell>URI / error</TableCell>
                  </TableRow></TableHead>
                  <TableBody>
                    {delivery.rows.map((d, i) => (
                      <TableRow key={i}>
                        <TableCell>{d.hop || '—'}</TableCell>
                        <TableCell>{d.target_type || '—'}</TableCell>
                        <TableCell>{d.attempt ?? '—'}</TableCell>
                        <TableCell>
                          <Chip size="small" label={d.status || '?'} sx={{ height: 20 }}
                                color={d.status === 'succeeded' ? 'success' : d.status === 'failed' ? 'error' : 'default'} />
                        </TableCell>
                        <TableCell>{d.acknowledgment || '—'}</TableCell>
                        <TableCell sx={{ fontSize: 12, wordBreak: 'break-all' }}>{d.uri || d.error || '—'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
              <SectionHeader title="Who decided what" section={decisions}
                             hint="from the append-only ledger, not from current state" />
              {decisions?.unavailable && <Unavailable name="decisions" reason={decisions.unavailable} />}
              {decisions && !decisions.unavailable && decisions.rows.length === 0 && (
                <NoRows name="decisions" text="No decision recorded for this date." />
              )}
              {decisions && !decisions.unavailable && decisions.rows.length > 0 && (
                <Stack gap={0.5}>
                  {decisions.rows.map((e, i) => (
                    <Typography key={e.id ?? i} variant="body2">
                      <b>{e.event_type}</b>{e.actor ? ` by ${e.actor}` : ''}
                      {e.created_at ? ` at ${fmtTs(e.created_at)}` : ''}
                      {e.reason ? ` — ${e.reason}` : e.detail ? ` — ${typeof e.detail === 'string' ? e.detail : JSON.stringify(e.detail)}` : ''}
                    </Typography>
                  ))}
                </Stack>
              )}
            </Paper>
          )}
        </>
      )}

      <FeedRunSkipDepsDialog
        run={skipRun ? { id: skipRun.id, feed_config_id: skipRun.feed_config_id, feed_name: skipRun.feed_name } : null}
        knownDeps={skipRun ? (skipRun.deps.length ? skipRun.deps : null) : null}
        onClose={() => setSkipRun(null)}
        onDone={() => void loadSurface()}
      />
      <FeedDeliveryAttemptsDialog
        feed={deliveryFeed}
        onClose={() => { setDeliveryFeed(null); void loadSurface(); }}
      />
    </Box>
  );
};

export default FeedSupportDeskPage;
