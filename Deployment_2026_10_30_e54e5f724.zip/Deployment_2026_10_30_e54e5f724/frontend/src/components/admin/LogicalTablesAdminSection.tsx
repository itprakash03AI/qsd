/**
 * Phase 146-C — Logical Tables admin section.
 *
 * Backing endpoints (all admin-gated):
 *   GET    /api/admin/logical-tables
 *   POST   /api/admin/logical-tables
 *   GET    /api/admin/logical-tables/{id}
 *   PUT    /api/admin/logical-tables/{id}
 *   DELETE /api/admin/logical-tables/{id}
 *   GET    /api/admin/logical-tables/{id}/bindings
 *   POST   /api/admin/logical-tables/{id}/bindings
 *   POST   /api/admin/logical-tables/{id}/bindings/bulk-add
 *   PUT    /api/admin/logical-tables/bindings/{binding_id}
 *   DELETE /api/admin/logical-tables/bindings/{binding_id}
 *   GET    /api/admin/logical-tables/by-connection/{conn_id}
 *
 * Sections:
 *   1. Logical Tables list -- create, edit description, delete.
 *   2. Per-row expander showing bindings for that logical table --
 *      add / edit / remove per (connection, physical_ref).
 *   3. Inline connection picker restricted to registered connections.
 */
import { appConfirm } from '../common/appDialogs';
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, IconButton,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Dialog, DialogTitle, DialogContent, DialogActions,
  FormControl, InputLabel, Select, MenuItem,
  Collapse, Chip, Tooltip, CircularProgress, Alert,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import ListPager, { clientPage } from '../common/ListPager';

interface Notification {
  type: string; title: string; message: string;
}

interface Props {
  addNotification: (n: Notification) => void;
}

interface LogicalTable {
  id: number;
  logical_name: string;
  description: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
}

interface LogicalBinding {
  id: number;
  logical_table_id: number;
  connection_id: number;
  physical_ref: string;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
}

interface ConnectionSummary {
  id: number;
  name: string;
  connection_type: string;
}

const LogicalTablesAdminSection: React.FC<Props> = ({ addNotification }) => {
  const [rows, setRows] = useState<LogicalTable[]>([]);
  const [connections, setConnections] = useState<ConnectionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [bindingsByLt, setBindingsByLt] = useState<Record<number, LogicalBinding[]>>({});
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [bindingDialogLt, setBindingDialogLt] = useState<LogicalTable | null>(null);
  const [bindingConn, setBindingConn] = useState<number | ''>('');
  const [bindingRef, setBindingRef] = useState('');
  const [editRow, setEditRow] = useState<LogicalTable | null>(null);
  const [ltPage, setLtPage] = useState(1);
  const [ltSize, setLtSize] = useState(50);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [lts, conns] = await Promise.all([
        safeFetch<LogicalTable[]>('/api/admin/logical-tables'),
        safeFetch<ConnectionSummary[]>('/api/connections'),
      ]);
      setRows(toArray(lts));
      setConnections(toArray(conns));
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Load failed', message: String(e?.message ?? e) });
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  useEffect(() => { void loadAll(); }, [loadAll]);

  const loadBindings = useCallback(async (lt: LogicalTable) => {
    try {
      const bs = await safeFetch<LogicalBinding[]>(
        `/api/admin/logical-tables/${lt.id}/bindings`,
      );
      setBindingsByLt(prev => ({ ...prev, [lt.id]: toArray(bs) }));
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Bindings load failed', message: String(e?.message ?? e) });
    }
  }, [addNotification]);

  const toggleExpand = (lt: LogicalTable) => {
    if (expandedRow === lt.id) {
      setExpandedRow(null);
    } else {
      setExpandedRow(lt.id);
      if (!bindingsByLt[lt.id]) void loadBindings(lt);
    }
  };

  const doCreate = async () => {
    if (!newName.trim()) return;
    try {
      await safeFetch('/api/admin/logical-tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          logical_name: newName.trim(),
          description:  newDesc.trim() || undefined,
        }),
      });
      addNotification({ type: 'success', title: 'Created', message: newName });
      setCreateOpen(false);
      setNewName(''); setNewDesc('');
      void loadAll();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Create failed', message: String(e?.message ?? e) });
    }
  };

  const doDelete = async (lt: LogicalTable) => {
    if (!await appConfirm(`Delete logical table "${lt.logical_name}" and its bindings?`)) return;
    try {
      await safeFetch(`/api/admin/logical-tables/${lt.id}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Deleted', message: lt.logical_name });
      void loadAll();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Delete failed', message: String(e?.message ?? e) });
    }
  };

  const doUpdate = async () => {
    if (!editRow) return;
    try {
      await safeFetch(`/api/admin/logical-tables/${editRow.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          logical_name: editRow.logical_name,
          description:  editRow.description || undefined,
        }),
      });
      addNotification({ type: 'success', title: 'Updated', message: editRow.logical_name });
      setEditRow(null);
      void loadAll();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Update failed', message: String(e?.message ?? e) });
    }
  };

  const doAddBinding = async () => {
    if (!bindingDialogLt || bindingConn === '' || !bindingRef.trim()) return;
    try {
      await safeFetch(`/api/admin/logical-tables/${bindingDialogLt.id}/bindings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          connection_id: Number(bindingConn),
          physical_ref:  bindingRef.trim(),
        }),
      });
      addNotification({
        type: 'success', title: 'Binding added',
        message: `${bindingDialogLt.logical_name} → conn ${bindingConn}`,
      });
      setBindingConn(''); setBindingRef('');
      setBindingDialogLt(null);
      void loadBindings(bindingDialogLt);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Binding add failed', message: String(e?.message ?? e) });
    }
  };

  const doDeleteBinding = async (lt: LogicalTable, b: LogicalBinding) => {
    if (!await appConfirm(`Remove binding for connection ${b.connection_id}?`)) return;
    try {
      await safeFetch(`/api/admin/logical-tables/bindings/${b.id}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Binding removed', message: b.physical_ref });
      void loadBindings(lt);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Binding remove failed', message: String(e?.message ?? e) });
    }
  };

  const connName = (id: number): string => {
    const c = connections.find(cn => cn.id === id);
    return c ? c.name : `connection ${id}`;
  };

  return (
    <Box sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Box>
          <Typography variant="h5">Logical Tables</Typography>
          <Typography variant="body2" color="text.secondary">
            Phase 146-B — map ``__logical__:name`` in Published-View SQL to
            per-connection physical references so one PV serves multiple engines.
          </Typography>
        </Box>
        <Box>
          <Tooltip title="Reload">
            <IconButton onClick={() => void loadAll()}><RefreshIcon /></IconButton>
          </Tooltip>
          <Button
            variant="contained" startIcon={<AddIcon />}
            onClick={() => setCreateOpen(true)}
            sx={{ ml: 1 }}
          >
            New logical table
          </Button>
        </Box>
      </Box>

      {loading && <CircularProgress size={24} />}
      {!loading && rows.length === 0 && (
        <Alert severity="info">
          No logical tables defined.  Click <b>New logical table</b> to create one.
        </Alert>
      )}

      {!loading && rows.length > 0 && (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: 48 }} />
                <TableCell>Logical name</TableCell>
                <TableCell>Description</TableCell>
                <TableCell>Created by</TableCell>
                <TableCell>Updated</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {clientPage(rows, ltPage, ltSize).rows.map(lt => {
                const bindings = bindingsByLt[lt.id] || [];
                const open = expandedRow === lt.id;
                return (
                  <React.Fragment key={lt.id}>
                    <TableRow hover>
                      <TableCell>
                        <IconButton aria-label="Collapse" size="small" onClick={() => toggleExpand(lt)}>
                          {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                        </IconButton>
                      </TableCell>
                      <TableCell>
                        <Chip label={`__logical__:${lt.logical_name}`} size="small" />
                      </TableCell>
                      <TableCell>{lt.description || '—'}</TableCell>
                      <TableCell>{lt.created_by || '—'}</TableCell>
                      <TableCell>
                        {lt.updated_at
                          ? new Date(lt.updated_at).toLocaleString()
                          : '—'}
                      </TableCell>
                      <TableCell align="right">
                        <IconButton aria-label="Edit" size="small" onClick={() => setEditRow({ ...lt })}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton aria-label="Delete" size="small" color="error" onClick={() => void doDelete(lt)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell colSpan={6} sx={{ py: 0, borderBottom: 'none' }}>
                        <Collapse in={open}>
                          <Box sx={{ p: 2, bgcolor: 'action.hover' }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                              <Typography variant="subtitle2">
                                Bindings ({bindings.length})
                              </Typography>
                              <Button
                                size="small" startIcon={<AddIcon />}
                                onClick={() => setBindingDialogLt(lt)}
                              >
                                Add binding
                              </Button>
                            </Box>
                            {bindings.length === 0 && (
                              <Alert severity="info" sx={{ mb: 1 }}>
                                No bindings.  Add at least one per engine you want to serve
                                this logical name on.
                              </Alert>
                            )}
                            {bindings.length > 0 && (
                              <Table size="small">
                                <TableHead>
                                  <TableRow>
                                    <TableCell>Connection</TableCell>
                                    <TableCell>Physical reference</TableCell>
                                    <TableCell align="right">Actions</TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  {bindings.map(b => (
                                    <TableRow key={b.id}>
                                      <TableCell>{connName(b.connection_id)}</TableCell>
                                      <TableCell><code>{b.physical_ref}</code></TableCell>
                                      <TableCell align="right">
                                        <IconButton aria-label="Delete"
                                          size="small" color="error"
                                          onClick={() => void doDeleteBinding(lt, b)}
                                        >
                                          <DeleteIcon fontSize="small" />
                                        </IconButton>
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            )}
                          </Box>
                        </Collapse>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
          <ListPager paging={clientPage(rows, ltPage, ltSize).paging}
                     onPage={setLtPage} onPageSize={setLtSize} testid="logical-tables-pager" />
        </TableContainer>
      )}

      {/* Create dialog */}
      <Dialog open={createOpen} onClose={() => setCreateOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>New logical table</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus fullWidth label="Logical name" margin="dense"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            helperText="Referenced from SQL as `__logical__:name`.  Case-insensitive on lookup."
          />
          <TextField
            fullWidth label="Description (optional)" margin="dense"
            value={newDesc}
            onChange={e => setNewDesc(e.target.value)}
            multiline rows={2}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={() => void doCreate()} disabled={!newName.trim()}>
            Create
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={!!editRow} onClose={() => setEditRow(null)} fullWidth maxWidth="sm">
        <DialogTitle>Edit logical table</DialogTitle>
        <DialogContent>
          {editRow && (
            <>
              <TextField
                fullWidth label="Logical name" margin="dense"
                value={editRow.logical_name}
                onChange={e => setEditRow({ ...editRow, logical_name: e.target.value })}
              />
              <TextField
                fullWidth label="Description" margin="dense"
                value={editRow.description || ''}
                onChange={e => setEditRow({ ...editRow, description: e.target.value })}
                multiline rows={2}
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditRow(null)}>Cancel</Button>
          <Button variant="contained" onClick={() => void doUpdate()}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Add binding dialog */}
      <Dialog
        open={!!bindingDialogLt}
        onClose={() => setBindingDialogLt(null)}
        fullWidth maxWidth="sm"
      >
        <DialogTitle>
          Add binding to {bindingDialogLt?.logical_name}
        </DialogTitle>
        <DialogContent>
          <FormControl fullWidth margin="dense">
            <InputLabel id="sel-logicaltablesadminsection-connection">Connection</InputLabel>
            <Select labelId="sel-logicaltablesadminsection-connection"
              value={bindingConn}
              label="Connection"
              onChange={e => setBindingConn(e.target.value as any)}
            >
              {connections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  {c.name} ({c.connection_type})
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            fullWidth label="Physical reference" margin="dense"
            value={bindingRef}
            onChange={e => setBindingRef(e.target.value)}
            helperText="e.g. `MY_DB.PUBLIC.orders` for SQL connectors, `__registered__:orders` for S3."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBindingDialogLt(null)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={() => void doAddBinding()}
            disabled={!bindingRef.trim() || bindingConn === ''}
          >
            Add
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default LogicalTablesAdminSection;
