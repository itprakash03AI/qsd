/**
 * Data entitlement by column -- the admin tab (2026-10-24,
 * docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html).
 *
 * A DIMENSION is a set of column names (``sap_company_id``, ``company_code``);
 * a VALUE says which principal (user / group / API key / feed owner group)
 * may see which values of it.  Every query touching a table that carries one
 * of the columns is filtered to the reader's values -- by the server
 * (core/row_security/entitlement.py); this tab only authors the rows.
 *
 *   GET/POST/PUT/DELETE /api/admin/row-security/entitlements/dimensions
 *   GET                 /api/admin/row-security/entitlements/dimensions/{id}/tables
 *   GET/POST/DELETE     /api/admin/row-security/entitlements/values
 *   POST                /api/admin/row-security/entitlements/values/upload
 */
import { appConfirm } from '../common/appDialogs';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, MenuItem, Dialog, DialogTitle, DialogContent, DialogActions,
  Alert, IconButton, Tooltip, Switch, FormControlLabel,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, UploadFile as UploadIcon } from '@mui/icons-material';
import { safeFetch, uploadFetch } from '../../services/api/core';
import { clickableRow } from '../../utils/clickable';

export const PRINCIPAL_TYPES = ['user', 'group', 'api_key', 'feed_owner_group'] as const;
const PRINCIPAL_WORDS: Record<string, string> = {
  user: 'User', group: 'Group (directory or QueryStudio)', api_key: 'API key (id)',
  feed_owner_group: 'Feed owner group (id)',
};

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

/** The dimension's columns as the form's one text field ("a, b:integer"). */
export function columnsFromText(text: string): { column_name: string; value_type: string }[] {
  return text.split(',').map(s => s.trim()).filter(Boolean).map(s => {
    const [name, type] = s.split(':').map(x => x.trim());
    return { column_name: name, value_type: type === 'integer' ? 'integer' : 'text' };
  });
}

export function columnsToText(cols: { column_name: string; value_type?: string }[]): string {
  return (cols || []).map(c => (c.value_type === 'integer' ? `${c.column_name}:integer` : c.column_name)).join(', ');
}

/** What the "no value" rule means, in the words the page shows. */
export function noValueWords(rule: string): string {
  return rule === 'see_everything'
    ? 'Someone with no value sees every row'
    : 'Someone with no value sees no rows';
}

const EMPTY_DIM = { id: 0, name: '', description: '', columns: '', no_value_behaviour: 'see_nothing', is_active: true };

const EntitlementAdminTab: React.FC<Props> = ({ addNotification }) => {
  const [dims, setDims] = useState<any[]>([]);
  const [meta, setMeta] = useState<{ enabled?: boolean; inline_max_values?: number }>({});
  const [loadError, setLoadError] = useState<string | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [values, setValues] = useState<{ items: any[]; total: number }>({ items: [], total: 0 });
  const [tables, setTables] = useState<any | null>(null);
  const [dimDialog, setDimDialog] = useState(false);
  const [dimForm, setDimForm] = useState({ ...EMPTY_DIM });
  const [valForm, setValForm] = useState({ principal_type: 'user', principal_id: '', value: '', is_all: false,
                                           valid_from: '', valid_to: '' });
  const [upload, setUpload] = useState<{ file: File | null; mode: string; preview: any | null }>(
    { file: null, mode: 'merge', preview: null });

  const err = (title: string, e: any) => addNotification({ type: 'error', title, message: e?.message || String(e) });

  const loadDims = useCallback(async () => {
    try {
      const r = await safeFetch(`/api/admin/row-security/entitlements/dimensions`);
      setDims(r?.items || []);
      setMeta({ enabled: r?.enabled, inline_max_values: r?.inline_max_values });
      setLoadError(null);
    } catch (e: any) {
      // Unknown != empty: say the list could not be read.
      setLoadError(e?.message || String(e));
    }
  }, []);

  const loadDetail = useCallback(async (id: number) => {
    try {
      const [v, t] = await Promise.all([
        safeFetch(`/api/admin/row-security/entitlements/values?dimension_id=${id}&limit=500`),
        safeFetch(`/api/admin/row-security/entitlements/dimensions/${id}/tables`).catch((e: any) => ({ tables: null, reason: e?.message })),
      ]);
      setValues({ items: v?.items || [], total: v?.total || 0 });
      setTables(t);
    } catch (e: any) {
      err('Could not read the values', e);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { loadDims(); }, [loadDims]);
  useEffect(() => { if (selected) loadDetail(selected); }, [selected, loadDetail]);

  const saveDim = async () => {
    const body = { name: dimForm.name, description: dimForm.description || null,
                   no_value_behaviour: dimForm.no_value_behaviour, is_active: dimForm.is_active,
                   columns: columnsFromText(dimForm.columns) };
    try {
      const saved = dimForm.id
        ? await safeFetch(`/api/admin/row-security/entitlements/dimensions/${dimForm.id}`, { method: 'PUT', body: JSON.stringify(body) })
        : await safeFetch(`/api/admin/row-security/entitlements/dimensions`, { method: 'POST', body: JSON.stringify(body) });
      setDimDialog(false);
      await loadDims();
      setSelected(saved?.id ?? null);
      addNotification({ type: 'success', title: dimForm.id ? 'Dimension saved' : 'Dimension created', message: body.name });
    } catch (e: any) { err('Save failed', e); }
  };

  const deleteDim = async (d: any) => {
    if (!await appConfirm(`Delete dimension ${d.name} and every value of it? Its filter stops at once.`)) return;
    try {
      await safeFetch(`/api/admin/row-security/entitlements/dimensions/${d.id}`, { method: 'DELETE' });
      if (selected === d.id) setSelected(null);
      loadDims();
    } catch (e: any) { err('Delete failed', e); }
  };

  const addValue = async () => {
    if (!selected) return;
    const row: any = { dimension_id: selected, principal_type: valForm.principal_type,
                       principal_id: valForm.principal_id.trim(), is_all: valForm.is_all,
                       value: valForm.is_all ? null : valForm.value.trim(),
                       valid_from: valForm.valid_from || null, valid_to: valForm.valid_to || null };
    try {
      const r = await safeFetch(`/api/admin/row-security/entitlements/values`, { method: 'POST', body: JSON.stringify({ values: [row] }) });
      addNotification({ type: r?.added ? 'success' : 'info', title: r?.added ? 'Value added' : 'Already held',
                        message: `${row.principal_type} ${row.principal_id}: ${row.is_all ? 'every value' : row.value}` });
      setValForm(f => ({ ...f, value: '' }));
      loadDetail(selected);
    } catch (e: any) { err('Add failed', e); }
  };

  const deleteValue = async (id: number) => {
    try {
      await safeFetch(`/api/admin/row-security/entitlements/values/${id}`, { method: 'DELETE' });
      if (selected) loadDetail(selected);
    } catch (e: any) { err('Delete failed', e); }
  };

  const sendUpload = async (dryRun: boolean) => {
    if (!selected || !upload.file) return;
    const fd = new FormData();
    fd.append('file', upload.file);
    try {
      const r = await uploadFetch(
        `/api/admin/row-security/entitlements/values/upload?dimension_id=${selected}&mode=${upload.mode}&dry_run=${dryRun}`, fd);
      setUpload(u => ({ ...u, preview: r }));
      if (!dryRun) {
        addNotification({ type: 'success', title: 'Upload applied',
                          message: `${r?.rows_added} added, ${r?.rows_removed} removed, ${r?.rows_rejected} rejected` });
        loadDetail(selected);
      }
    } catch (e: any) { err(dryRun ? 'Preview failed' : 'Upload failed', e); }
  };

  const dim = dims.find(d => d.id === selected);

  return (
    <Box>
      <Alert severity="info" sx={{ mb: 2 }}>
        A dimension names columns (for example <code>sap_company_id</code>). Any query on a table that has one of
        them returns only the rows whose value the reader is entitled to -- on the SQL page, reports, published APIs
        (when the API says so) and feeds (when the feed says so). Administrators are not filtered; each such query is
        audited.
        {meta.enabled === false && <strong> Data entitlement is switched OFF in this deployment
          (row_security.entitlement_enabled).</strong>}
      </Alert>
      {loadError && <Alert severity="error" sx={{ mb: 2 }}>Could not read the dimensions: {loadError}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          <Typography variant="subtitle1" sx={{ flex: 1 }}>Dimensions</Typography>
          <Button size="small" startIcon={<AddIcon />}
                  onClick={() => { setDimForm({ ...EMPTY_DIM }); setDimDialog(true); }}>
            New dimension
          </Button>
        </Stack>
        <TableContainer>
          <Table size="small" aria-label="Entitlement dimensions">
            <TableHead><TableRow>
              <TableCell>Name</TableCell><TableCell>Columns</TableCell><TableCell>No value</TableCell>
              <TableCell>Active</TableCell><TableCell />
            </TableRow></TableHead>
            <TableBody>
              {dims.map(d => (
                <TableRow key={d.id} hover selected={d.id === selected}
                          {...clickableRow(() => setSelected(d.id), { label: d.name, selected: d.id === selected })}
                          sx={{ cursor: 'pointer' }}>
                  <TableCell>{d.name}</TableCell>
                  <TableCell>{columnsToText(d.columns)}</TableCell>
                  <TableCell>{noValueWords(d.no_value_behaviour)}</TableCell>
                  <TableCell>{d.is_active ? 'Yes' : 'No'}</TableCell>
                  <TableCell align="right" onClick={e => e.stopPropagation()}>
                    <Button size="small" onClick={() => {
                      setDimForm({ id: d.id, name: d.name, description: d.description || '',
                                   columns: columnsToText(d.columns), no_value_behaviour: d.no_value_behaviour,
                                   is_active: d.is_active });
                      setDimDialog(true);
                    }}>Edit</Button>
                    <Tooltip title="Delete"><IconButton size="small" aria-label={`Delete dimension ${d.name}`}
                                                        onClick={() => deleteDim(d)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
                  </TableCell>
                </TableRow>
              ))}
              {!dims.length && !loadError && (
                <TableRow><TableCell colSpan={5}>No dimension yet -- nothing is filtered by entitlement.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {dim && (
        <Paper sx={{ p: 2 }} aria-label={`Values of ${dim.name}`}>
          <Typography variant="subtitle1">Who sees which {dim.name} ({values.total})</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            {noValueWords(dim.no_value_behaviour)}. A filter lists at most {meta.inline_max_values ?? 1000} values
            per person; more is refused (give "every value" instead).
          </Typography>
          {tables && (
            <Typography variant="body2" sx={{ mb: 1 }}>
              Applies to: {tables.tables === null
                ? `unknown (${tables.reason || 'the catalog could not be read'})`
                : tables.tables.length
                  ? tables.tables.slice(0, 12).map((t: any) => t.table).join(', ') +
                    (tables.tables.length > 12 ? ` and ${tables.tables.length - 12} more` : '')
                  : 'no catalogued table has these columns yet'}
            </Typography>
          )}
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} sx={{ mb: 1 }} alignItems="center">
            <TextField select size="small" label="Who" value={valForm.principal_type} sx={{ minWidth: 200 }}
                       onChange={e => setValForm(f => ({ ...f, principal_type: e.target.value }))}>
              {PRINCIPAL_TYPES.map(p => <MenuItem key={p} value={p}>{PRINCIPAL_WORDS[p]}</MenuItem>)}
            </TextField>
            <TextField size="small" label="Name or id" value={valForm.principal_id}
                       onChange={e => setValForm(f => ({ ...f, principal_id: e.target.value }))} />
            <TextField size="small" label="Value" value={valForm.value} disabled={valForm.is_all}
                       onChange={e => setValForm(f => ({ ...f, value: e.target.value }))} />
            <FormControlLabel control={<Switch checked={valForm.is_all}
                                               onChange={e => setValForm(f => ({ ...f, is_all: e.target.checked }))} />}
                              label="Every value" />
            <TextField size="small" type="date" label="From" slotProps={{ inputLabel: { shrink: true } }}
                       value={valForm.valid_from} onChange={e => setValForm(f => ({ ...f, valid_from: e.target.value }))} />
            <TextField size="small" type="date" label="Until" slotProps={{ inputLabel: { shrink: true } }}
                       value={valForm.valid_to} onChange={e => setValForm(f => ({ ...f, valid_to: e.target.value }))} />
            <Button variant="contained" size="small" onClick={addValue}
                    disabled={!valForm.principal_id.trim() || (!valForm.is_all && !valForm.value.trim())}>
              Add
            </Button>
          </Stack>
          <TableContainer sx={{ maxHeight: 360 }}>
            <Table size="small" stickyHeader aria-label="Entitlement values">
              <TableHead><TableRow>
                <TableCell>Who</TableCell><TableCell>Name or id</TableCell><TableCell>Value</TableCell>
                <TableCell>Valid</TableCell><TableCell>Source</TableCell><TableCell />
              </TableRow></TableHead>
              <TableBody>
                {values.items.map(v => (
                  <TableRow key={v.id}>
                    <TableCell>{PRINCIPAL_WORDS[v.principal_type] || v.principal_type}</TableCell>
                    <TableCell>{v.principal_id}</TableCell>
                    <TableCell>{v.is_all ? <Chip size="small" label="every value" /> : v.value}</TableCell>
                    <TableCell>{v.valid_from || v.valid_to ? `${v.valid_from || '...'} to ${v.valid_to || '...'}` : 'always'}</TableCell>
                    <TableCell>{v.source}</TableCell>
                    <TableCell align="right">
                      <IconButton size="small" aria-label={`Delete value ${v.id}`} onClick={() => deleteValue(v.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {!values.items.length && <TableRow><TableCell colSpan={6}>
                  Nobody holds a value yet -- {noValueWords(dim.no_value_behaviour).toLowerCase()}.
                </TableCell></TableRow>}
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2">Upload a file</Typography>
            <Typography variant="body2" color="text.secondary">
              CSV with the header <code>principal_type,principal_id,value</code> (optional <code>valid_from,valid_to</code>,
              YYYY-MM-DD); a value of <code>*</code> means every value. Preview first: nothing is written until you apply.
            </Typography>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
              <Button component="label" size="small" startIcon={<UploadIcon />}>
                {upload.file ? upload.file.name : 'Choose file'}
                <input hidden type="file" accept=".csv,text/csv" aria-label="Entitlement file"
                       onChange={e => setUpload({ file: e.target.files?.[0] || null, mode: upload.mode, preview: null })} />
              </Button>
              <TextField select size="small" label="Mode" value={upload.mode} sx={{ minWidth: 220 }}
                         onChange={e => setUpload(u => ({ ...u, mode: e.target.value, preview: null }))}>
                <MenuItem value="merge">Add to the existing values</MenuItem>
                <MenuItem value="replace">Replace every value of this dimension</MenuItem>
              </TextField>
              <Button size="small" disabled={!upload.file} onClick={() => sendUpload(true)}>Preview</Button>
              <Button size="small" variant="contained" disabled={!upload.preview || upload.preview.dry_run !== true}
                      onClick={() => sendUpload(false)}>Apply</Button>
            </Stack>
            {upload.preview && (
              <Alert severity={upload.preview.rows_rejected ? 'warning' : 'success'} sx={{ mt: 1 }}>
                {upload.preview.dry_run ? 'Preview: ' : 'Applied: '}
                {upload.preview.rows_accepted} row(s) accepted, {upload.preview.rows_rejected} rejected
                {upload.preview.mode === 'replace' && `; ${upload.preview.would_remove} existing row(s) will be removed`}
                {(upload.preview.rejected || []).slice(0, 10).map((r: any) => (
                  <div key={r.line}>line {r.line}: {r.reason}</div>
                ))}
              </Alert>
            )}
          </Box>
        </Paper>
      )}

      <Dialog open={dimDialog} onClose={() => setDimDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{dimForm.id ? 'Edit dimension' : 'New dimension'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" value={dimForm.name} onChange={e => setDimForm(f => ({ ...f, name: e.target.value }))} />
            <TextField label="Columns" value={dimForm.columns}
                       helperText='Every spelling of the column, comma-separated; add ":integer" for a number column (company_code:integer)'
                       onChange={e => setDimForm(f => ({ ...f, columns: e.target.value }))} />
            <TextField select label="Someone with no value" value={dimForm.no_value_behaviour}
                       onChange={e => setDimForm(f => ({ ...f, no_value_behaviour: e.target.value }))}>
              <MenuItem value="see_nothing">sees no rows (safest)</MenuItem>
              <MenuItem value="see_everything">sees every row</MenuItem>
            </TextField>
            <TextField label="Description" value={dimForm.description}
                       onChange={e => setDimForm(f => ({ ...f, description: e.target.value }))} />
            <FormControlLabel control={<Switch checked={dimForm.is_active}
                                               onChange={e => setDimForm(f => ({ ...f, is_active: e.target.checked }))} />}
                              label="Active (filters queries)" />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDimDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={saveDim}
                  disabled={!dimForm.name.trim() || !columnsFromText(dimForm.columns).length}>Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default EntitlementAdminTab;
