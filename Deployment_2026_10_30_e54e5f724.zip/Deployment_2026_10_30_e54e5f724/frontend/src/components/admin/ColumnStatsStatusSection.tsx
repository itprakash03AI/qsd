/**
 * Column-Stats Status — admin UI (2026-06-03; v3 drill-down 2026-07-13).
 *
 * Lists every (bucket, table_prefix, snapshot_id) tuple that has column-stats
 * coverage, with counts + freshness, so admins can answer:
 *   * Which tables have supplement coverage?
 *   * When was the last scan?
 *   * How many files / columns are covered?
 *   * Is the running scan actually making progress?
 *
 * 2026-07-13 — the backend column-stats storage is now per-FILE (v3 grain,
 * default), one row per file with all columns packed into a column_stats JSON
 * map — the way Starburst stores per-file statistics.  This section:
 *   * shows the effective grain (v2 / both / v3) as a chip;
 *   * lets you EXPAND a table to a Starburst-style per-file view — each file
 *     with its row-count, size and per-column min / max / nulls / #values;
 *   * offers a "Backfill v3 ← v2" action so a fresh v3 table can be populated
 *     from existing v2 rows without an S3 re-scan.
 *
 * Reads:  GET  /api/admin/iceberg/column-stats/status
 *         GET  /api/admin/iceberg/file-stats/grain
 *         GET  /api/admin/iceberg/file-stats/files
 *         POST /api/admin/iceberg/file-stats/backfill
 */
import { appAlert } from '../common/appDialogs';
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, Collapse, Link,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as PlayIcon,
  Storage as StorageIcon,
  KeyboardArrowDown as ExpandIcon,
  KeyboardArrowRight as CollapseIcon,
  CloudSync as BackfillIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import ListPager, { clientPage } from '../common/ListPager';


interface StatusRow {
  bucket:             string;
  table_prefix:       string;
  snapshot_id:        string;
  file_count:         number | null;
  column_count:       number | null;
  row_count:          number;
  last_scanned_at:    string | null;
  last_connection_id: number | null;
  last_table_name:    string | null;
}

interface ColStat {
  lo?:    string | number | null;
  hi?:    string | number | null;
  nulls?: number;
  vals?:  number;
  size?:  number;
}
interface FileRow {
  file_path:    string;
  snapshot_id:  string;
  row_count:    number;
  file_size:    number;
  columns:      number;
  scanned_at:   string | null;
  column_stats: Record<string, ColStat>;
}
interface GrainInfo {
  grain:     string;
  writes_v3: boolean;
  writes_v2: boolean;
}


const relativeAge = (iso: string | null): string => {
  if (!iso) return '—';
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < 0) return iso;
  const s = Math.round(ms / 1000);
  if (s < 60)        return `${s}s ago`;
  if (s < 3600)      return `${Math.round(s / 60)}m ago`;
  if (s < 86400)     return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
};

const ageSeverity = (iso: string | null): 'success' | 'warning' | 'error' => {
  if (!iso) return 'error';
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < 3600 * 1000)        return 'success';   // < 1h fresh
  if (ms < 24 * 3600 * 1000)   return 'warning';   // < 1d stale-ish
  return 'error';                                    // > 1d stale
};

const fmtBytes = (n: number): string => {
  if (!n || n <= 0) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0; let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
};

const fmtBound = (v: string | number | null | undefined): string => {
  if (v === null || v === undefined || v === '') return '—';
  const s = String(v);
  return s.length > 24 ? `${s.slice(0, 24)}…` : s;
};

const baseName = (p: string): string => {
  const parts = p.split('/');
  return parts[parts.length - 1] || p;
};

const rowKey = (r: StatusRow) => `${r.bucket}/${r.table_prefix}/${r.snapshot_id}`;


/** Starburst-style per-file column-stats table for one snapshot. */
const FileStatsDrill: React.FC<{ row: StatusRow }> = ({ row }) => {
  const [files, setFiles] = useState<FileRow[]>([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [openFile, setOpenFile] = useState<string | null>(null);
  const PAGE = 50;

  const loadFiles = useCallback(async (offset: number) => {
    setLoading(true); setErr(null);
    try {
      const r = await api.icebergFileStatsFiles({
        bucket:       row.bucket,
        table_prefix: row.table_prefix,
        snapshot_id:  row.snapshot_id,
        limit:        PAGE,
        offset,
      });
      // Defensive boundary mapping: the response is `any`, so default every
      // field (a null row_count would otherwise crash `.toLocaleString()`).
      const batch: FileRow[] = (r?.files ?? []).map((f: any) => ({
        file_path:    f?.file_path ?? '',
        snapshot_id:  f?.snapshot_id ?? '',
        row_count:    f?.row_count ?? 0,
        file_size:    f?.file_size ?? 0,
        columns:      f?.columns ?? 0,
        scanned_at:   f?.scanned_at ?? null,
        column_stats: f?.column_stats ?? {},
      }));
      if (offset === 0) setFiles(batch);
      else setFiles(prev => [...prev, ...batch]);
      setTotal(r?.total ?? 0);
      // Gate "Load more" on whether the last page was FULL — robust even if
      // the backend omits `total` (which would otherwise hide the button and
      // silently truncate the drill-down to page 1).
      setHasMore(batch.length >= PAGE);
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [row.bucket, row.table_prefix, row.snapshot_id]);

  useEffect(() => { loadFiles(0); }, [loadFiles]);

  if (loading && files.length === 0) {
    return <Box sx={{ p: 2 }}><CircularProgress size={18} /> <Typography variant="caption">Loading per-file stats…</Typography></Box>;
  }
  if (err) return <Alert severity="error" sx={{ m: 1 }}>{err}</Alert>;
  if (files.length === 0) {
    return (
      <Alert severity="info" sx={{ m: 1 }}>
        No per-file rows in <code>iceberg_file_stats_v3</code> for this snapshot.
        If this table has legacy v2 coverage, use “Backfill v3 ← v2”.
      </Alert>
    );
  }

  return (
    <Box sx={{ p: 1, bgcolor: 'action.hover', borderRadius: 1 }}>
      <Typography variant="caption" color="text.secondary" sx={{ pl: 1 }}>
        {files.length.toLocaleString()}
        {total > 0 ? ` of ${total.toLocaleString()}` : ''} files
        (per-file column statistics — click a file to see its columns)
      </Typography>
      <Table size="small" sx={{ mt: 0.5 }}>
        <TableHead>
          <TableRow>
            <TableCell />
            <TableCell>File</TableCell>
            <TableCell align="right">Rows</TableCell>
            <TableCell align="right">Size</TableCell>
            <TableCell align="right">Cols</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {files.map((f) => {
            const open = openFile === f.file_path;
            const cols = Object.entries(f.column_stats || {});
            return (
              <React.Fragment key={f.file_path}>
                <TableRow hover sx={{ cursor: 'pointer' }}
                          onClick={() => setOpenFile(open ? null : f.file_path)}>
                  <TableCell sx={{ width: 32 }}>
                    <IconButton aria-label={`Column stats of ${baseName(f.file_path)}`} aria-expanded={open} size="small">
                      {open ? <ExpandIcon fontSize="small" /> : <CollapseIcon fontSize="small" />}
                    </IconButton>
                  </TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                    <Tooltip title={f.file_path}><span>{baseName(f.file_path)}</span></Tooltip>
                  </TableCell>
                  <TableCell align="right">{(f.row_count ?? 0).toLocaleString()}</TableCell>
                  <TableCell align="right">{fmtBytes(f.file_size)}</TableCell>
                  <TableCell align="right">{f.columns ?? 0}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell colSpan={5} sx={{ py: 0, border: 0 }}>
                    <Collapse in={open} timeout="auto" unmountOnExit>
                      <Box sx={{ m: 1, ml: 4 }}>
                        <Table size="small">
                          <TableHead>
                            <TableRow>
                              <TableCell>Column</TableCell>
                              <TableCell>Min</TableCell>
                              <TableCell>Max</TableCell>
                              <TableCell align="right">Nulls</TableCell>
                              <TableCell align="right">Values</TableCell>
                              <TableCell align="right">Size</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {cols.length === 0 && (
                              <TableRow><TableCell colSpan={6}>
                                <Typography variant="caption" color="text.secondary">No column stats recorded.</Typography>
                              </TableCell></TableRow>
                            )}
                            {cols.map(([cname, st]) => (
                              <TableRow key={cname}>
                                <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>{cname}</TableCell>
                                <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>{fmtBound(st.lo)}</TableCell>
                                <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>{fmtBound(st.hi)}</TableCell>
                                <TableCell align="right">{st.nulls != null ? st.nulls.toLocaleString() : '—'}</TableCell>
                                <TableCell align="right">{st.vals != null ? st.vals.toLocaleString() : '—'}</TableCell>
                                <TableCell align="right">{st.size ? fmtBytes(st.size) : '—'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </Box>
                    </Collapse>
                  </TableCell>
                </TableRow>
              </React.Fragment>
            );
          })}
        </TableBody>
      </Table>
      {hasMore && (
        <Button size="small" onClick={() => loadFiles(files.length)} disabled={loading} sx={{ mt: 1 }}>
          {loading ? <CircularProgress size={14} />
            : `Load more${total > 0 ? ` (${Math.max(total - files.length, 0).toLocaleString()} remaining)` : ''}`}
        </Button>
      )}
    </Box>
  );
};


const ColumnStatsStatusSection: React.FC = () => {
  const [rows, setRows] = useState<StatusRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState<string | null>(null);
  const [grain, setGrain] = useState<GrainInfo | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [backfilling, setBackfilling] = useState<string | null>(null);
  const [statusPage, setStatusPage] = useState(1);
  const [statusSize, setStatusSize] = useState(50);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [statusResp, grainResp] = await Promise.all([
        api.icebergColumnStatsStatus(true),
        api.icebergFileStatsGrain().catch(() => null),
      ]);
      if (grainResp) setGrain(grainResp);
      const list = statusResp?.rows ?? statusResp?.entries ?? [];
      setRows(list.map((row: any) => ({
        bucket:             row.bucket ?? '',
        table_prefix:       row.table_prefix ?? '',
        snapshot_id:        row.snapshot_id ?? '',
        file_count:         row.files ?? row.file_count ?? null,
        column_count:       row.columns ?? row.column_count ?? null,
        row_count:          row.rows ?? row.row_count ?? 0,
        last_scanned_at:    row.last_scanned ?? row.last_scanned_at ?? null,
        last_connection_id: row.last_connection_id ?? row.connection_id ?? null,
        last_table_name:    row.last_table_name ?? row.table_name ?? null,
      })));
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const triggerRescan = useCallback(async (row: StatusRow) => {
    if (!row.last_connection_id || !row.last_table_name) {
      void appAlert('Cannot rescan: this row has no connection/table telemetry.  Trigger from Admin → Iceberg Metadata Sync instead.');
      return;
    }
    const key = rowKey(row);
    setScanning(key);
    try {
      const r = await api.icebergColumnStatsScan({
        connection_id: row.last_connection_id,
        table_name:    row.last_table_name,
        force:         true,
      });
      void appAlert(`Scan triggered: ${JSON.stringify(r ?? {}, null, 2).slice(0, 400)}`);
      await load();
    } catch (e: any) {
      void appAlert(`Rescan failed: ${e?.message || String(e)}`);
    } finally {
      setScanning(null);
    }
  }, [load]);

  const triggerBackfill = useCallback(async (row: StatusRow) => {
    const key = rowKey(row);
    setBackfilling(key);
    try {
      const r = await api.icebergFileStatsBackfill({
        bucket:       row.bucket,
        table_prefix: row.table_prefix,
        snapshot_id:  row.snapshot_id,
      });
      void appAlert(`Backfilled ${r?.rows_written ?? 0} per-file rows into v3.`);
      await load();
    } catch (e: any) {
      void appAlert(`Backfill failed: ${e?.message || String(e)}`);
    } finally {
      setBackfilling(null);
    }
  }, [load]);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <StorageIcon fontSize="small" />
        <Typography variant="h6">Column Stats — Per-File Coverage</Typography>
        {grain && (
          <Tooltip title={`Effective iceberg.file_stats_grain on this pod. v3 = one row per file (Starburst-style); v2 = one row per (file × column).`}>
            <Chip size="small" variant="outlined"
                  color={grain.writes_v3 ? 'primary' : 'default'}
                  label={`grain: ${grain.grain}`} />
          </Tooltip>
        )}
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}
                variant="outlined" size="small">
          {loading ? <CircularProgress size={16} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          Per-file column statistics — one row per file, all columns packed
          together, the way Starburst stores per-file stats. Under the default
          <code> v3</code> grain these come from <code>iceberg_file_stats_v3</code>;
          under <code>v2</code> from <code>iceberg_column_stats_supplement_v2</code>.
          Populated by the background sync
          (<code>iceberg.column_stats_sync_enabled</code>) or a manual scan.
          Click a table to drill into its files and per-column min / max / nulls.
          When v3 is empty after a grain cutover, use <b>Backfill v3 ← v2</b>
          to seed it from existing v2 rows (no S3 re-scan).
        </Typography>
      </Paper>

      {rows.length === 0 && !loading && !error && (
        <Alert severity="warning">
          No coverage rows yet. Either the sync is disabled
          (<code>iceberg.column_stats_sync_enabled</code> defaults false), OR no
          scans have completed (check Admin → Background Jobs →
          iceberg_metadata_sync, OR POST
          <code> /api/admin/iceberg/column-stats/scan</code> for a table).
          {grain && grain.grain === 'v2' && (
            <> Note: this pod’s grain is <b>v2</b> — scans write the legacy
            per-column table, so <code>iceberg_file_stats_v3</code> stays empty
            by design.</>
          )}
        </Alert>
      )}

      {rows.length > 0 && (
        <Paper>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: 32 }} />
                <TableCell>Bucket / Prefix</TableCell>
                <TableCell>Table (last)</TableCell>
                <TableCell>Snapshot</TableCell>
                <TableCell align="right">Files</TableCell>
                <TableCell align="right">Cols</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell>Last scan</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {clientPage(rows, statusPage, statusSize).rows.map((r, i) => {
                const key = rowKey(r);
                const open = expanded === key;
                return (
                  <React.Fragment key={i}>
                    <TableRow hover>
                      <TableCell sx={{ width: 32 }}>
                        <IconButton aria-label="Expand" size="small" onClick={() => setExpanded(open ? null : key)}>
                          {open ? <ExpandIcon fontSize="small" /> : <CollapseIcon fontSize="small" />}
                        </IconButton>
                      </TableCell>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                        <Link component="button" underline="hover" sx={{ textAlign: 'left' }}
                              onClick={() => setExpanded(open ? null : key)}>
                          {r.bucket}
                        </Link><br/>
                        <span style={{ color: '#888' }}>{r.table_prefix}</span>
                      </TableCell>
                      <TableCell>{r.last_table_name || '—'}</TableCell>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                        {r.snapshot_id?.slice(0, 12)}…
                      </TableCell>
                      <TableCell align="right">{r.file_count === null ? '—' : r.file_count.toLocaleString()}</TableCell>
                      <TableCell align="right">{r.column_count === null ? '—' : r.column_count}</TableCell>
                      <TableCell align="right">{r.row_count.toLocaleString()}</TableCell>
                      <TableCell>
                        <Chip size="small" label={relativeAge(r.last_scanned_at)}
                              color={ageSeverity(r.last_scanned_at)} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          {grain?.writes_v3 && (
                            <Tooltip title="Backfill the per-file v3 table from existing v2 rows (no S3 re-scan)">
                              <span>
                                <IconButton aria-label="Backfill the per-file v3 table from existing v2 rows (no S3 re-scan)" size="small" disabled={backfilling !== null}
                                            onClick={() => triggerBackfill(r)}>
                                  {backfilling === key ? <CircularProgress size={16} /> : <BackfillIcon fontSize="small" />}
                                </IconButton>
                              </span>
                            </Tooltip>
                          )}
                          <Tooltip title="Force a fresh scan for this snapshot (writes new rows, replaces existing)">
                            <span>
                              <IconButton aria-label="Force a fresh scan for this snapshot (writes new rows, replaces existing)" size="small"
                                          disabled={scanning !== null || !r.last_connection_id || !r.last_table_name}
                                          onClick={() => triggerRescan(r)}>
                                {scanning === key ? <CircularProgress size={16} /> : <PlayIcon fontSize="small" />}
                              </IconButton>
                            </span>
                          </Tooltip>
                        </Stack>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell colSpan={9} sx={{ py: 0, border: 0 }}>
                        <Collapse in={open} timeout="auto" unmountOnExit>
                          {open && <FileStatsDrill row={r} />}
                        </Collapse>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
          <ListPager paging={clientPage(rows, statusPage, statusSize).paging}
                     onPage={setStatusPage} onPageSize={setStatusSize} testid="column-stats-status-pager" />
        </Paper>
      )}
    </Box>
  );
};

export default ColumnStatsStatusSection;
