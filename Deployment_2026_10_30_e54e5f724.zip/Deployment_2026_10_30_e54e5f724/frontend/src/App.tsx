import React, { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useParams, useNavigate } from 'react-router-dom';
import { ThemeContextProvider } from './context/ThemeContext';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import CloudOffIcon from '@mui/icons-material/CloudOff';
import RefreshIcon from '@mui/icons-material/Refresh';
import Layout, { ROLE_ACCESS } from './components/Layout';
import { REPORTS_PATH, reportPath } from './utils/reportUrls';
import api from './services/api';
import LoginPage from './components/LoginPage';
import QueryTabManager from './components/QueryTabManager';
import SavedQueries from './components/SavedQueries';
import Downloads from './components/Downloads';
import ExecutionHistory from './components/ExecutionHistory';
import ConnectionManager from './components/ConnectionManager';
// Phase 111: ReportsManagerPage removed — /report-manager now redirects to /business-reports
import ReportConnectorsPage from './components/ReportConnectorsPage';
import FilePreviewPage from './components/FilePreviewPage';
import DashboardPage from './components/DashboardPage';
import SharedQueryPage from './components/SharedQueryPage';
import SharedDashboardPage from './components/SharedDashboardPage';
import SharedBusinessReportPage from './components/SharedBusinessReportPage';
import EmbeddedBusinessReportPage from './components/EmbeddedBusinessReportPage';
import ErrorBoundary from './components/ErrorBoundary';
import PortalPasswordHost from './components/PortalPasswordHost';
import AppDialogHost from './components/common/appDialogs';
import ReauthModal from './components/ReauthModal';
import ConnectionBanner from './components/ConnectionBanner';
import DeploymentBanner from './components/DeploymentBanner';

// Lazy-loaded heavy pages — split into separate chunks to reduce initial bundle size
// 2026-09-20 (wiring sweep): four lazy() declarations for components no route
// rendered were removed here -- BusinessReportBuilder, BusinessReportViewer,
// PivotReportBuilder, PivotReportViewer.  Each still shipped as a chunk the app
// never requested; the Pivot one was the chunk a stale tab asked for (FB-47).
// The unified builder/viewer own those routes.
const AdminPage = lazy(() => import('./components/AdminPage'));
const SystemAccountsPage = lazy(() => import('./components/SystemAccountsPage'));
const LineagePage = lazy(() => import('./components/LineagePage'));
const ReportCatalogPage = lazy(() => import('./components/ReportCatalogPage'));
const DatasetManagerPage = lazy(() => import('./components/DatasetManagerPage'));
const DatasetQueryPanel = lazy(() => import('./components/DatasetQueryPanel'));
const BusinessGlossary = lazy(() => import('./components/BusinessGlossary'));
const ValueListsPage = lazy(() => import('./components/ValueListsPage'));
const ReportsListPage = lazy(() => import('./components/ReportsListPage'));
const ReportPortalPage = lazy(() => import('./components/ReportPortalPage'));
const UnifiedReportBuilder = lazy(() => import('./components/UnifiedReportBuilder'));
// 2026-10-26 -- the canvas builder (fields left, tiles on a 12-column grid, properties right)
const CanvasReportBuilder = lazy(() => import('./components/reports/canvas/CanvasReportBuilder'));
const UnifiedReportViewer = lazy(() => import('./components/UnifiedReportViewer'));
const BusinessPortalPage = lazy(() => import('./components/BusinessPortalPage'));
const SqlQueryPage = lazy(() => import('./components/SqlQueryPage'));
const SchedulesPage = lazy(() => import('./components/SchedulesPage'));
const MaterializedViewsPage = lazy(() => import('./components/MaterializedViewsPage'));
const LocalTablesPage = lazy(() => import('./components/LocalTablesPage'));
const PublishedViewsPage = lazy(() => import('./components/PublishedViewsPage'));
const FeedConfigsPage = lazy(() => import('./components/FeedConfigsPage'));
const FeedTodayPage = lazy(() => import('./components/FeedTodayPage'));
// 2026-09-27 -- the support desk over the run surface
const FeedSupportDeskPage = lazy(() => import('./components/FeedSupportDeskPage'));
// 2026-09-28 -- My Feeds: delivery receipts for feed CONSUMERS (any role, the viewer included)
const MyFeedsPage = lazy(() => import('./components/MyFeedsPage'));
// Phase 133 — Source-vs-destination reconciliation reports
const ReconciliationPage = lazy(() => import('./components/ReconciliationPage'));
// Phase 132 — DataFlow engine UI
const DataFlowDashboardPage = lazy(() => import('./components/DataFlowDashboardPage'));
const DataFlowsPage = lazy(() => import('./components/DataFlowsPage'));
const DataFlowBuilderPage = lazy(() => import('./components/DataFlowBuilderPage'));
const DataFlowSimpleJobPage = lazy(() => import('./components/DataFlowSimpleJobPage'));
const DataFlowRunsPage = lazy(() => import('./components/DataFlowRunsPage'));
const DataFlowRunDetailPage = lazy(() => import('./components/DataFlowRunDetailPage'));
const DataFlowSchedulesPage = lazy(() => import('./components/DataFlowSchedulesPage'));
const DataFlowApprovalsPage = lazy(() => import('./components/DataFlowApprovalsPage'));
const DataFlowStageCatalogPage = lazy(() => import('./components/DataFlowStageCatalogPage'));
const DataFlowCustomStagesPage = lazy(() => import('./components/DataFlowCustomStagesPage'));
const DataFlowOpsPage = lazy(() => import('./components/DataFlowOpsPage'));
const DataFlowNotificationPoliciesPage = lazy(() => import('./components/DataFlowNotificationPoliciesPage'));
const DataFlowVariablesPage = lazy(() => import('./components/DataFlowVariablesPage'));
const DataFlowWebhooksPage = lazy(() => import('./components/DataFlowWebhooksPage'));
const FeedSodOnDemandPage = lazy(() => import('./components/FeedSodOnDemandPage'));
const FeedCalendarsPage = lazy(() => import('./components/FeedCalendarsPage'));
// 2026-09-03 — operator controls: groups, service review, windows
const FeedGroupsPage = lazy(() => import('./components/FeedGroupsPage'));
const ServiceReviewPage = lazy(() => import('./components/ServiceReviewPage'));
const DeploymentWindowsPage = lazy(() => import('./components/DeploymentWindowsPage'));
const MyGroupsPage = lazy(() => import('./components/MyGroupsPage'));
const FeedControlFileFormatsPage = lazy(() => import('./components/FeedControlFileFormatsPage'));
// 2026-09-05 - the FeedGen step model: flows (the mapping) + the step-type catalogue
const FeedFlowsAdminPage = lazy(() => import('./components/FeedFlowsAdminPage'));
const FeedStepCatalogPage = lazy(() => import('./components/FeedStepCatalogPage'));
const UserGroupsPage = lazy(() => import('./components/UserGroupsPage'));
// 2026-09-10 - Clockwork, the scheduler: jobs list, editor, run history
const ClockworkJobsPage = lazy(() => import('./components/clockwork/ClockworkJobsPage'));
const ClockworkJobEditorPage = lazy(() => import('./components/clockwork/ClockworkJobEditorPage'));
const ClockworkRunHistoryPage = lazy(() => import('./components/clockwork/ClockworkRunHistoryPage'));
const ClockworkTemplatesPage = lazy(() => import('./components/clockwork/ClockworkTemplatesPage'));
const ClockworkSchemaPage = lazy(() => import('./components/clockwork/ClockworkSchemaPage'));
const FederationViewsPage = lazy(() => import('./components/FederationViewsPage'));
const MetadataCatalogPage = lazy(() => import('./components/MetadataCatalogPage'));
const ApiExplorerPage = lazy(() => import('./components/ApiExplorerPage'));
const ApiDashboardPage = lazy(() => import('./components/ApiDashboardPage'));
const DataQualityPage = lazy(() => import('./components/DataQualityPage'));
const BusinessQueryTabManager = lazy(() => import('./components/BusinessQueryTabManager'));
const NotFoundPage = lazy(() => import('./components/NotFoundPage'));
import { WebSocketProvider } from './context/WebSocketContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppSettingsProvider } from './context/AppSettingsContext';
import { WorkspaceProvider } from './context/WorkspaceContext';
import { AssistantContextProvider } from './context/AssistantContext';
import { UIVisibilityProvider, useComponentVisible } from './context/UIVisibilityContext';
import { ClockworkAccessProvider, useClockworkAccess } from './context/ClockworkAccessContext';
import { TourProvider } from './context/TourContext';
import GuidedTour from './components/GuidedTour';
import NotificationCenter from './components/NotificationCenter';
import './App.css';

// Shown when a signed-in user opens a PAGE their role may not use.
//
// 2026-09-24 (walked as a real viewer): this said the account "does not have
// permission to access QueryStudio" and offered only Sign Out -- for a user
// who may use the rest of the product.  It now says it is THIS page, who may
// open it, who you are signed in as, and takes you back into the product.
const AccessDenied = ({ allowed }: { allowed?: string[] }) => {
  const { user } = useAuth();
  const role = (user as any)?.role || 'viewer';
  return (
    <Box data-testid="page-access-denied" role="alert"
         sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 2, px: 2, textAlign: 'center' }}>
      <LockOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
      <Typography variant="h5" fontWeight={600}>You don't have access to this page</Typography>
      <Typography color="text.secondary">
        You are signed in as <strong>{user?.display_name || user?.username}</strong> ({role}).
        {allowed && allowed.length > 0
          ? <> This page is available to: {allowed.join(', ')}.</>
          : <> Your role cannot open this page.</>}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        If you need it, ask an administrator to change your role.
      </Typography>
      <Button variant="contained" href="/">Go to Home</Button>
    </Box>
  );
};

// Role guard — restricts route access based on RBAC role
//
// 2026-09-20 -- this returned children unconditionally whenever auth was
// off, so on a no-auth rig every guard was a no-op and nothing about a
// non-admin could be proven.  It now judges the ROLE the backend reports:
// with auth off that role is 'admin' (the guest) unless the guest is
// acting as a lesser role (X-QS-Act-As-Role), in which case the guards
// are exactly what that role would meet with auth on.
const RoleGuard = ({ roles, children }: { roles: string[], children: React.ReactNode }) => {
  const { user } = useAuth();
  const role = (user as any)?.role || 'viewer';
  // Phase 107-I: super_admin bypasses all role-based route guards.
  if (role === 'super_admin') return <>{children}</>;
  if (!roles.includes(role)) return <AccessDenied allowed={roles} />;
  return <>{children}</>;
};

// 2026-09-20 -- a route gated by the SAME list that filters the sidebar.
// ROLE_ACCESS (Layout.tsx) is the single source for what a non-admin role
// may reach; a sidebar filter is not a lock, and /smart-query was reachable
// by URL for a viewer while absent from their nav.  Admin-like roles are
// not listed there and pass; a listed role passes only for a listed path.
const AllowedByRole = ({ path, children }: { path: string, children: React.ReactNode }) => {
  const { user } = useAuth();
  const role = (user as any)?.role || 'viewer';
  if (role === 'super_admin' || role === 'admin') return <>{children}</>;
  if (!(ROLE_ACCESS[role]?.includes(path) ?? false)) return <AccessDenied />;
  return <>{children}</>;
};

// Component visibility guard — hides routes disabled by admin for the current role
const ComponentDisabledGuard = ({ componentKey, children }: { componentKey: string, children: React.ReactNode }) => {
  const visible = useComponentVisible(componentKey);
  if (!visible) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 2 }}>
        <LockOutlinedIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
        <Typography variant="h6" color="text.secondary">This feature is not available for your role.</Typography>
      </Box>
    );
  }
  return <>{children}</>;
};

// 2026-09-10 — the scheduler scope's LANDING (plan §7).  A scheduler-only
// principal is sent to /scheduler from any other URL, including "/": the
// routes themselves are already hidden through ComponentDisabledGuard
// (UIVisibilityContext applies the scope), and this is the one place a
// redirect beats a "not available" panel — there is nowhere else to go.
// Presentation only; the backend enforces every scheduler route.
const SchedulerScopeLanding = ({ children }: { children: React.ReactNode }) => {
  const { schedulerOnly } = useClockworkAccess();
  const location = useLocation();
  if (schedulerOnly && !location.pathname.startsWith('/scheduler')) {
    return <Navigate to="/scheduler" replace />;
  }
  return <>{children}</>;
};

// Phase 111: redirect helper that preserves :id param in the URL
// 2026-09-20 -- the browser URL for a report is /finance-reports/<slug>
// (the REST API keeps numeric ids).  An OLD URL (/business-reports/:id,
// /pivot-reports/:id, with or without /edit) is redirected to the slug URL
// of the same report: RedirectWithId's shape, with the id resolved to a
// slug through the report payload first.  A token that is not numeric is
// forwarded under the new prefix unchanged; an id nothing resolves is
// forwarded as-is so the viewer answers "not found" rather than a blank.
const RedirectReportById = ({ suffix = '' }: { suffix?: string }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  useEffect(() => {
    if (!id) { navigate(REPORTS_PATH, { replace: true }); return; }
    if (!/^\d+$/.test(id)) { navigate(`${reportPath(id)}${suffix}`, { replace: true }); return; }
    api.getBusinessReport(Number(id))
      .then((r: any) => navigate(`${reportPath(r || id)}${suffix}`, { replace: true }))
      .catch(() => navigate(`${reportPath(id)}${suffix}`, { replace: true }));
  }, [id, suffix, navigate]);
  return null;
};

// 2026-09-26 (FB-60) -- /reports/:reportId was the RETIRED parametric
// report.  A migrated one is a finance report now (a NEW id), so the old
// bookmark opens THAT report; one that was never migrated, or that this user
// may not see, says so instead of dropping the user on a list with no reason.
const RedirectLegacyReport = () => {
  const { reportId } = useParams<{ reportId: string }>();
  const navigate = useNavigate();
  const [problem, setProblem] = React.useState<string | null>(null);
  useEffect(() => {
    if (!reportId || !/^\d+$/.test(reportId)) { navigate(REPORTS_PATH, { replace: true }); return; }
    api.getBusinessReportByLegacyId(Number(reportId))
      .then((r: any) => navigate(reportPath(r), { replace: true }))
      .catch((e: any) => {
        const status = e?.status ?? e?.response?.status;
        setProblem(status === 403
          ? 'You do not have access to the finance report this link now points to.'
          : `Report ${reportId} was a parametric report. Parametric reports have been replaced by finance reports, and this one has not been moved over yet. Ask an administrator to migrate it.`);
      });
  }, [reportId, navigate]);
  if (!problem) return null;
  return (
    <Box sx={{ p: 4, maxWidth: 640 }}>
      <Typography variant="h6" gutterBottom>This report link is out of date</Typography>
      <Typography variant="body1" sx={{ mb: 2 }}>{problem}</Typography>
      <Button variant="contained" onClick={() => navigate(REPORTS_PATH)}>Go to Finance Reports</Button>
    </Box>
  );
};

const RedirectWithId = ({ basePath, suffix = '' }: { basePath: string; suffix?: string }) => {
  const { id } = useParams<{ id: string }>();
  // 2026-09-18 -- ``suffix`` exists because dropping it silently turned an
  // EDIT link into a VIEW link.  /pivot-reports/:id/edit redirected to
  // /business-reports/:id, so the Edit button on a pivot report navigated
  // back to the page it was clicked from: the control was there, it just
  // could not reach the editor.
  return <Navigate to={id ? `${basePath}/${id}${suffix}` : basePath} replace />;
};

const AppRoutes = () => {
  const { authEnabled, user, isLoading, apiOnline, retryConnection } = useAuth();
  const location = useLocation();

  // BF-468 (2026-05-19) — WebSocketProvider hoisted ABOVE the
  // conditional returns so it stays mounted regardless of
  // isLoading / authEnabled / user state changes.
  //
  // Previous shape was:
  //    if (isLoading)        return <Spinner />;       // WS not mounted
  //    if (!user)            return <LoginPage />;     // WS not mounted
  //    return <...WebSocketProvider>...               // WS mounted
  // → Any toggle of those flags unmounted WebSocketProvider, fired
  //   the cleanup's ws.close() (code 1000), and remounted on the
  //   next render → reconnect.  Repeated toggles (e.g. cross-tab
  //   storage events, transient /me failures) created a storm of
  //   close/reconnect cycles that BF-467's watchdog-removal alone
  //   could not stop, because the unmount cleanup is still the
  //   legitimate close path.
  //
  // New shape: WebSocketProvider wraps EVERYTHING.  The conditional
  // returns now sit INSIDE it, so the WS stays alive across:
  //   - Initial /me probe (isLoading false → true → false)
  //   - Login / logout (user null ↔ realUser)
  //   - Cross-tab auth sync events
  //   - Any future conditional render added to AppRoutes
  //
  // Connecting before login means the WS is anonymous until the user
  // logs in — harmless, server-routed broadcasts simply find no
  // matching user and drop.  Re-identification fires when AuthContext
  // writes qs_ws_username (BF-464v2 CustomEvent path).
  return (
    <WebSocketProvider>
      <AppRoutesInner
        authEnabled={authEnabled}
        user={user}
        isLoading={isLoading}
        apiOnline={apiOnline}
        retryConnection={retryConnection}
        location={location}
      />
    </WebSocketProvider>
  );
};

interface AppRoutesInnerProps {
  authEnabled: boolean;
  user: ReturnType<typeof useAuth>['user'];
  isLoading: boolean;
  apiOnline: boolean;
  retryConnection: () => void;
  location: ReturnType<typeof useLocation>;
}

const AppRoutesInner: React.FC<AppRoutesInnerProps> = ({
  authEnabled, user, isLoading, apiOnline, retryConnection, location,
}) => {
  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Phase 141 honest-fix: NEVER nuke the app on a network blip.  The
  // previous behaviour replaced the entire React tree with a "Backend
  // API Unavailable" screen when /health failed 5 times — destroying
  // in-flight queries, typed SQL, open tabs.  Now we render normally
  // and let the ConnectionBanner (mounted below in the main tree) show
  // a non-intrusive top banner instead.  Critical: user context is
  // preserved across transient backend hiccups.

  // Auth enabled but not logged in → login screen
  if (authEnabled && !user) {
    return <LoginPage />;
  }

  return (
    <AppSettingsProvider>
    <ClockworkAccessProvider>
    <UIVisibilityProvider>
    <TourProvider>
    <AssistantContextProvider>
    <WorkspaceProvider>
      <NotificationProvider>
        <Layout>
          <GuidedTour />
          <NotificationCenter />
          {/* BF-285: global AWS portal password prompt — listens for
              the 'portal-password-required' CustomEvent and pops the
              modal.  Single mount point so any feature can trigger it. */}
          <PortalPasswordHost />
          {/* 2026-10-30: the app's own confirm / message popups (appConfirm /
              appAlert / appPrompt) -- replaces the browser's grey box */}
          <AppDialogHost />
          {/* BF-403: global re-auth modal — overlays the app when a 401
              triggers mid-session.  Never unmounts BQB/CQB/admin pages so
              in-flight queries, typed SQL, and tabs survive re-auth. */}
          <ReauthModal />
          {/* Phase 141: non-intrusive top banner shown when the backend is
              briefly unreachable.  Replaces the old full-screen takeover
              that destroyed user context on every network blip. */}
          <ConnectionBanner />
          {/* FB-47: offers a reload once the server reports a newer build than
              this tab was compiled with, before a lazy route fails on a chunk
              that no longer exists. */}
          <DeploymentBanner />
          <ErrorBoundary resetKey={location.pathname}>
            <Suspense fallback={<Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress /></Box>}>
              <SchedulerScopeLanding>
              <Routes>
                <Route path="/connections"       element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="connections"><ConnectionManager /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/materialized-views" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="materialized_views"><MaterializedViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/local-tables"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="local_tables"><LocalTablesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/lineage"            element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="lineage"><LineagePage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-08-25 — analysts too.  POST /api/datasets has allowed
                    require_role("admin","analyst") since the 2026-08-09
                    self-service work, and DatasetManagerPage is already
                    ownership-aware (canMutate = isAdmin || ownsDataset, publish
                    disabled for non-admins).  Only this route still said
                    admin-only, so an analyst the API permits was bounced by the
                    router — and BQB's "Create Dataset…" deep-link led nowhere
                    for every non-admin.  Every sibling authoring page
                    (/connections, /materialized-views, /local-tables, /lineage,
                    /query-builder) already uses ['admin','analyst']; this was
                    the outlier.  Viewers stay out: the role exists to be
                    read-only, and the API would refuse the create anyway. */}
                <Route path="/datasets"          element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="semantic_layer"><DatasetManagerPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/glossary"          element={<ComponentDisabledGuard componentKey="glossary"><BusinessGlossary /></ComponentDisabledGuard>} />
                <Route path="/value-lists"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="semantic_layer"><ValueListsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* FB-49 (2026-09-20): ":id" carries the dataset SLUG.  The
                    PATH is unchanged on purpose -- what widened is the token,
                    and GET /api/datasets/by-slug/<token> resolves a numeric
                    one by id, so every /datasets/13/query anyone bookmarked
                    still opens and the panel then canonicalises the address.
                    A redirect route would have been a second resolution of
                    one question. */}
                <Route path="/datasets/:id/query" element={<ComponentDisabledGuard componentKey="semantic_layer"><DatasetQueryPanel /></ComponentDisabledGuard>} />
                {/* Phase 111 — Unified Reports (all report types under one URL) */}
                {/* 2026-09-20 -- /finance-reports/<slug> is the browser URL; ":id" is the
                    route param NAME (the inner components read it) and carries the SLUG. */}
                <Route path="/finance-reports"          element={<ComponentDisabledGuard componentKey="business_reports"><ReportsListPage /></ComponentDisabledGuard>} />
                {/* 2026-09-24: authoring is analyst/admin (the API enforces it now). */}
                <Route path="/finance-reports/new"      element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="business_reports"><UnifiedReportBuilder /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/finance-reports/new/canvas" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="business_reports"><CanvasReportBuilder /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/finance-reports/:id/canvas" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="business_reports"><CanvasReportBuilder /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/finance-reports/:id"      element={<ComponentDisabledGuard componentKey="business_reports"><UnifiedReportViewer /></ComponentDisabledGuard>} />
                <Route path="/finance-reports/:id/edit" element={<ComponentDisabledGuard componentKey="business_reports"><UnifiedReportBuilder /></ComponentDisabledGuard>} />
                {/* the OLD browser URLs redirect -- never 404 -- to the slug URLs above */}
                <Route path="/business-reports"        element={<Navigate to="/finance-reports" replace />} />
                <Route path="/business-reports/new"    element={<Navigate to="/finance-reports/new" replace />} />
                <Route path="/business-reports/:id"    element={<RedirectReportById />} />
                <Route path="/business-reports/:id/edit" element={<RedirectReportById suffix="/edit" />} />
                {/* Phase 111 — Legacy pivot routes redirect to unified (preserving :id) */}
                <Route path="/pivot-reports/new"      element={<Navigate to="/finance-reports/new" replace />} />
                <Route path="/pivot-reports/:id"      element={<RedirectReportById />} />
                <Route path="/pivot-reports/:id/edit" element={<RedirectReportById suffix="/edit" />} />
                <Route path="/"                  element={<ComponentDisabledGuard componentKey="business_portal"><BusinessPortalPage /></ComponentDisabledGuard>} />
                <Route path="/query-builder"     element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="query_builder"><QueryTabManager /></ComponentDisabledGuard></RoleGuard>} />
                {/* /reports and /reports/:id were the LEGACY parametric surface (FB-60,
                    decommissioned 2026-09-26).  Both redirect to finance reports so an
                    old bookmark lands on the list rather than a 404, and an old
                    REPORT link opens the finance report it was migrated into. */}
                <Route path="/reports"           element={<Navigate to="/finance-reports" replace />} />
                <Route path="/reports/:reportId" element={<RedirectLegacyReport />} />
                <Route path="/saved-queries"     element={<AllowedByRole path="/saved-queries"><ComponentDisabledGuard componentKey="saved_queries"><SavedQueries /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/executions"        element={<ComponentDisabledGuard componentKey="executions"><ExecutionHistory /></ComponentDisabledGuard>} />
                <Route path="/downloads"         element={<ComponentDisabledGuard componentKey="downloads"><Downloads /></ComponentDisabledGuard>} />
                <Route path="/sql"               element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="sql_editor"><SqlQueryPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/smart-query"      element={<AllowedByRole path="/smart-query"><ComponentDisabledGuard componentKey="business_query_builder"><BusinessQueryTabManager /></ComponentDisabledGuard></AllowedByRole>} />
                {/* Phase 111 — the old Reports Manager URL redirects to the finance-report list */}
                <Route path="/report-manager"    element={<Navigate to="/finance-reports" replace />} />
                {/* 2026-08-10 — consumer-facing portal: published reports mapped to
                    the caller.  Guarded by the same componentKey as the landing
                    portal so an operator turns both on or off together. */}
                <Route path="/report-portal"     element={<ComponentDisabledGuard componentKey="business_portal"><ReportPortalPage /></ComponentDisabledGuard>} />
                <Route path="/report-catalog"    element={<ComponentDisabledGuard componentKey="report_catalog"><ReportCatalogPage /></ComponentDisabledGuard>} />
                <Route path="/report-connectors" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="report_connectors"><ReportConnectorsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/schedules"         element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="schedules"><SchedulesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/file-preview"      element={<ComponentDisabledGuard componentKey="file_preview"><FilePreviewPage /></ComponentDisabledGuard>} />
                <Route path="/dashboards"        element={<AllowedByRole path="/dashboards"><ComponentDisabledGuard componentKey="dashboards"><DashboardPage /></ComponentDisabledGuard></AllowedByRole>} />
                {/* 2026-10-17 -- the support role (the API's read-only operations
                    principal, require_admin_read) may OPEN the admin panel; AdminPage
                    shows it only the read-only sections (Component Health, Audit Log)
                    and every control refuses it server-side (403). */}
                <Route path="/admin"             element={<RoleGuard roles={['admin', 'support']}><ComponentDisabledGuard componentKey="admin"><AdminPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/system-accounts"  element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="system_accounts"><SystemAccountsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/published-views"  element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="published_views"><PublishedViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-10-17 -- the API Keys page is the Published APIs page's "Consumers & keys" tab */}
                <Route path="/api-keys"         element={<Navigate to="/published-views?tab=consumers" replace />} />
                <Route path="/feeds"           element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedConfigsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 133 — Reconciliation reports */}
                <Route path="/reconciliation"  element={<RoleGuard roles={['admin','analyst']}><ReconciliationPage /></RoleGuard>} />
                <Route path="/feeds/today"     element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedTodayPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/feeds/support"   element={<RoleGuard roles={['admin','analyst','support']}><ComponentDisabledGuard componentKey="feeds"><FeedSupportDeskPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-09-28 -- a CONSUMER surface: every signed-in role, the viewer included;
                    the server answers 404 for a feed the caller is not declared on.  Gated on
                    its own component key so hiding the producer's feed screens for a role
                    does not hide the receipts they consume. */}
                <Route path="/feeds/mine"      element={<ComponentDisabledGuard componentKey="my_feeds"><MyFeedsPage /></ComponentDisabledGuard>} />
                {/* End-user on-demand SOD — any authenticated user (idempotent backend) */}
                <Route path="/feeds/sod"       element={<ComponentDisabledGuard componentKey="feeds"><FeedSodOnDemandPage /></ComponentDisabledGuard>} />
                <Route path="/feeds/calendars" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="feeds"><FeedCalendarsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-10-11 -- every upstream Kafka / QS_KAFKA_MESSAGE message and what it released; auto-onboarded entities */}
                {/* 2026-10-12 -- the upstream-message monitor lives IN Feed Run Status (its "Upstream messages" tab); the old path opens it there */}
                <Route path="/feeds/messages"  element={<Navigate to="/feeds/today?tab=messages" replace />} />
                {/* 2026-10-12 -- ONE dashboard (owner): the board, the SLA and the
                    variance holds live in Feed Run Status; old links land there. */}
                <Route path="/feeds/dashboard" element={<Navigate to="/feeds/today" replace />} />
                <Route path="/feeds/variance-holds" element={<Navigate to="/feeds/today" replace />} />
                <Route path="/feeds/groups"    element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedGroupsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-10-26 -- the review covers ALL of QueryStudio (feeds, reports, published APIs, platform): its own path, not under feeds */}
                <Route path="/service-review" element={<RoleGuard roles={['admin']}><ServiceReviewPage /></RoleGuard>} />
                <Route path="/feeds/service-review" element={<Navigate to="/service-review" replace />} />
                <Route path="/feeds/deployment-windows" element={<ComponentDisabledGuard componentKey="feeds"><DeploymentWindowsPage /></ComponentDisabledGuard>} />
                <Route path="/feeds/control-file-formats" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="feeds"><FeedControlFileFormatsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/feeds/flows" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="feeds"><FeedFlowsAdminPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/feeds/step-types" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedStepCatalogPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/admin/user-groups" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="admin"><UserGroupsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 130 hotfix-13 — end-user My Groups (any authenticated user) */}
                <Route path="/my-groups"         element={<MyGroupsPage />} />
                <Route path="/federation-views" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="federation_views"><FederationViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/catalog"        element={<AllowedByRole path="/catalog"><ComponentDisabledGuard componentKey="data_catalog"><MetadataCatalogPage /></ComponentDisabledGuard></AllowedByRole>} />
                {/* viewer included: end users need the API Explorer to test the Published APIs they consume. */}
                {/* 2026-09-20 -- this RoleGuard listed 'viewer' while ROLE_ACCESS.viewer
                    omits /api-explorer: two sources, two answers.  The allowlist decides
                    (the API Explorer is a machine-consumer surface, not a report). */}
                <Route path="/api-explorer"  element={<AllowedByRole path="/api-explorer"><ComponentDisabledGuard componentKey="api_explorer"><ApiExplorerPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/api-dashboard" element={<AllowedByRole path="/api-dashboard"><ComponentDisabledGuard componentKey="published_views"><ApiDashboardPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/data-quality" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="data_quality"><DataQualityPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 132 — DataFlow engine routes (admin) */}
                {/* FB-49 (2026-09-20) -- these keep NUMERIC ids, deliberately.
                    The line drawn is: an entity a non-operator LINKS TO and
                    SHARES gets a slug (a report, a dataset -- both done); an
                    OPERATOR surface and an EVENT record keep the id.
                      * /dataflows/runs/:id and /scheduler/jobs/:id/runs
                        address a RUN.  A run is an event, not a named thing;
                        its id IS its identity and a slug would have to be
                        invented for it.
                      * /dataflows/:id, /dataflows/simple/:id and
                        /scheduler/jobs/:id are named, but they are reached
                        from their own list by an admin or analyst who is
                        already looking at the list.  Nobody pastes one into
                        a ticket for a business user to open.
                    Extending slugs here is a product decision, not a
                    technical one -- core/slugs.py and the by-slug route shape
                    are generic, so it is a small change IF the answer to
                    "does anyone share these links?" ever becomes yes. */}
                <Route path="/dataflows"                  element={<RoleGuard roles={['admin','analyst']}><DataFlowDashboardPage /></RoleGuard>} />
                <Route path="/dataflows/list"             element={<RoleGuard roles={['admin','analyst']}><DataFlowsPage /></RoleGuard>} />
                {/* /dataflows/new defaults to the Simple Job builder; the
                    Advanced DAG editor is at /dataflows/new/advanced.
                    Both write into the same DataFlow rows. */}
                <Route path="/dataflows/new"              element={<RoleGuard roles={['admin']}><DataFlowSimpleJobPage /></RoleGuard>} />
                <Route path="/dataflows/new/advanced"     element={<RoleGuard roles={['admin']}><DataFlowBuilderPage /></RoleGuard>} />
                <Route path="/dataflows/simple/:id"       element={<RoleGuard roles={['admin','analyst']}><DataFlowSimpleJobPage /></RoleGuard>} />
                <Route path="/dataflows/runs"             element={<RoleGuard roles={['admin','analyst']}><DataFlowRunsPage /></RoleGuard>} />
                <Route path="/dataflows/ops"              element={<RoleGuard roles={['admin','analyst']}><DataFlowOpsPage /></RoleGuard>} />
                <Route path="/dataflows/notification-policies" element={<RoleGuard roles={['admin']}><DataFlowNotificationPoliciesPage /></RoleGuard>} />
                <Route path="/dataflows/variables"        element={<RoleGuard roles={['admin']}><DataFlowVariablesPage /></RoleGuard>} />
                <Route path="/dataflows/webhooks"         element={<RoleGuard roles={['admin']}><DataFlowWebhooksPage /></RoleGuard>} />
                <Route path="/dataflows/runs/:id"         element={<RoleGuard roles={['admin','analyst']}><DataFlowRunDetailPage /></RoleGuard>} />
                <Route path="/dataflows/schedules"        element={<RoleGuard roles={['admin']}><DataFlowSchedulesPage /></RoleGuard>} />
                <Route path="/dataflows/approvals"        element={<RoleGuard roles={['admin']}><DataFlowApprovalsPage /></RoleGuard>} />
                <Route path="/dataflows/stages"           element={<RoleGuard roles={['admin','analyst']}><DataFlowStageCatalogPage /></RoleGuard>} />
                <Route path="/dataflows/custom-stages"    element={<RoleGuard roles={['admin']}><DataFlowCustomStagesPage /></RoleGuard>} />
                <Route path="/dataflows/:id"              element={<RoleGuard roles={['admin','analyst']}><DataFlowBuilderPage /></RoleGuard>} />
                {/* 2026-09-10 — Clockwork.  No RoleGuard on purpose: who may see
                    the scheduler is the backend predicate's verdict
                    (GET /api/clockwork/access), applied through the `scheduler`
                    componentKey, and a scheduler-only principal carries whatever
                    role string the backend gave it.  A client-side role list
                    would be a second answer to that question. */}
                <Route path="/scheduler"               element={<AllowedByRole path="/scheduler"><ComponentDisabledGuard componentKey="clockwork"><ClockworkJobsPage /></ComponentDisabledGuard></AllowedByRole>} />
                {/* 2026-09-24 (walked as a real viewer): the section entry was
                    guarded and its sub-pages were not, so a typed URL opened a
                    page whose data the API then refused.  Sub-pages follow the
                    SECTION's rule; Schema State follows its API (require_admin). */}
                <Route path="/scheduler/jobs/new"      element={<AllowedByRole path="/scheduler"><ComponentDisabledGuard componentKey="clockwork"><ClockworkJobEditorPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/scheduler/jobs/:id"      element={<AllowedByRole path="/scheduler"><ComponentDisabledGuard componentKey="clockwork"><ClockworkJobEditorPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/scheduler/jobs/:id/runs" element={<AllowedByRole path="/scheduler"><ComponentDisabledGuard componentKey="clockwork"><ClockworkRunHistoryPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/scheduler/templates"     element={<AllowedByRole path="/scheduler"><ComponentDisabledGuard componentKey="clockwork"><ClockworkTemplatesPage /></ComponentDisabledGuard></AllowedByRole>} />
                <Route path="/scheduler/schema"        element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="clockwork"><ClockworkSchemaPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* 2026-10-23 -- an address no route matches is SAID, never a blank page. */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
              </SchedulerScopeLanding>
            </Suspense>
          </ErrorBoundary>
        </Layout>
      </NotificationProvider>
    </WorkspaceProvider>
    </AssistantContextProvider>
    </TourProvider>
    </UIVisibilityProvider>
    </ClockworkAccessProvider>
    </AppSettingsProvider>
  );
};

function App() {
  return (
    <ThemeContextProvider>
      <Router>
        {/* Public routes — no auth required */}
        <Routes>
          <Route path="/shared/:token" element={<SharedQueryPage />} />
          <Route path="/shared-dashboard/:token" element={<SharedDashboardPage />} />
          <Route path="/shared-business-report/:token" element={<SharedBusinessReportPage />} />
          <Route path="/embedded-business-report/:token" element={<EmbeddedBusinessReportPage />} />
          <Route path="/*" element={
            <AuthProvider>
              <AppRoutes />
            </AuthProvider>
          } />
        </Routes>
      </Router>
    </ThemeContextProvider>
  );
}

export default App;
