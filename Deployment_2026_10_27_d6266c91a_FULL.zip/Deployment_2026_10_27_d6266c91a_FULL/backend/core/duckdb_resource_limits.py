"""BF-528..529 (2026-05-28) — cgroup-aware DuckDB resource limits.

Enterprise reliability fix.  Without these, the DuckDB subprocess
crashes in production:

  * **Memory**: default ``memory_limit`` auto-detects host RAM (64 GB on a
    typical node) instead of the pod's cgroup limit (4 GB).  DuckDB
    allocates ~50 GB → OOM-killed by the cgroup → "subprocess died
    silently" with no diagnostic.
  * **Threads**: default = all host CPUs (16) → a single query saturates
    the pod's CPU budget; concurrent queries throttle each other.
  * **Spill quota**: default is unbounded → one pathological join fills
    the PVC → "no space on device" for every other query for hours
    until the cleanup sweep runs.

This module resolves each limit from the cgroup (Linux containers) +
honourable env-var override.  Works in vanilla VMs (cgroup absent →
falls back to /proc/meminfo + os.cpu_count + shutil.disk_usage).

All three resolvers fail-safe: any exception returns the conservative
default (empty string for memory / 1 thread / 0 spill quota = unbounded)
so the subprocess never refuses to start because the resolver broke.
"""
from __future__ import annotations

import logging
import os
import shutil
import threading
from typing import Optional

logger = logging.getLogger(__name__)


# ── R3 (2026-08-03): loud, once-per-process alarm when the cgroup is
# unreadable.  An unreadable cgroup silently disarms EVERY memory defense
# at once:
#   * resolve_memory_limit_for_duckdb falls back to /proc/meminfo, which is
#     NOT namespaced in a pod → the DuckDB ceiling becomes 75% of the NODE.
#   * worker_pool admission's memory budget becomes 0 → memory accounting
#     disabled entirely.
#   * the BF-558c pressure gate returns False → inert.
# With cgroup-v2 memory.oom.group=1 the first big query then OOM-kills the
# whole pod.  Previously the ONLY trace of this chain engaging was a debug
# log — invisible in production.  This helper is called from each of those
# three consumers; the first caller wins and logs ONE warning.
_no_cgroup_warned = False
_no_cgroup_warn_lock = threading.Lock()


def warn_cgroup_unreadable_once(context: str) -> None:
    """Log one WARNING per process naming the consequence of an unreadable
    cgroup memory limit.  Never raises."""
    global _no_cgroup_warned
    try:
        with _no_cgroup_warn_lock:
            if _no_cgroup_warned:
                return
            _no_cgroup_warned = True
        logger.warning(
            "MEMORY DEFENSES DEGRADED (%s): cgroup memory limit is "
            "unreadable.  Consequences: (1) DuckDB memory_limit is sized "
            "from /proc/meminfo = the ENTIRE NODE's RAM, not this pod's "
            "limit; (2) worker-pool memory-aware admission is DISABLED "
            "(budget=0); (3) the memory-pressure admission gate is INERT.  "
            "In a container with memory.oom.group=1 the first large query "
            "can OOM-kill the whole pod.  Expected on dev boxes / bare "
            "VMs; NEVER expected inside a k8s pod — if this is a pod, fix "
            "the cgroup mount / securityContext.", context,
        )
    except Exception:                                        # pragma: no cover
        logger.debug("warn_cgroup_unreadable_once failed", exc_info=True)


# ── Memory ──────────────────────────────────────────────────────────────────


def _read_cgroup_memory_limit_bytes() -> Optional[int]:
    """Return the cgroup memory limit in bytes, or None if unavailable
    or unset (== effectively unlimited)."""
    candidates = (
        # cgroup v2 unified hierarchy (modern OpenShift / k8s).
        "/sys/fs/cgroup/memory.max",
        # cgroup v1 (older clusters).
        "/sys/fs/cgroup/memory/memory.limit_in_bytes",
    )
    for path in candidates:
        try:
            with open(path, "r") as fh:
                raw = fh.read().strip()
            if not raw or raw == "max":
                continue
            val = int(raw)
            # cgroup v1 reports a sentinel close to int64 max when
            # "unlimited" — anything > 1 PiB is effectively unlimited.
            if val > (1 << 50):
                continue
            return val
        except (FileNotFoundError, PermissionError, ValueError):
            continue
        except Exception as exc:
            logger.debug(
                "BF-528 cgroup memory read failed (%s): %s", path, exc)
            continue
    return None


def _read_cgroup_working_set_bytes() -> Optional[int]:
    """cgroup-only working-set read (usage minus reclaimable page cache).
    Returns None off-cgroup — deliberately NO psutil fallback here: an
    off-cgroup "used" counts every process on the box (browser, IDE, other
    services), so any consumer that must reason about THIS pod's cgroup
    (the OOM-killer's accounting domain) would draw wrong conclusions from
    it.  ``read_pod_memory_usage_bytes`` layers the psutil fallback on top
    for consumers that just want a best-effort number.  Never raises.
    """
    # (usage_path, stat_path, inactive_file_key)
    candidates = (
        ("/sys/fs/cgroup/memory.current",                      # cgroup v2
         "/sys/fs/cgroup/memory.stat", "inactive_file"),
        ("/sys/fs/cgroup/memory/memory.usage_in_bytes",        # cgroup v1
         "/sys/fs/cgroup/memory/memory.stat", "total_inactive_file"),
    )
    for path, stat_path, inactive_key in candidates:
        try:
            with open(path, "r") as fh:
                raw = fh.read().strip()
            if not raw:
                continue
            val = int(raw)
            if val <= 0:
                continue
            # BF-558f: report WORKING SET, not raw usage.  ``memory.current``
            # includes reclaimable page cache, which on an IO-heavy pod (spill
            # traffic — which the memory divisor deliberately INCREASES — plus
            # the proxy path that pre-downloads S3 objects to local temp) grows
            # until usage sits pinned near the limit indefinitely.  A gate
            # reading raw usage would then engage permanently: all latency, no
            # protection, because the kernel reclaims that cache long before it
            # OOM-kills.  kubelet evicts on working set for the same reason.
            try:
                with open(stat_path, "r") as sfh:
                    for line in sfh:
                        if line.startswith(inactive_key + " "):
                            inactive = int(line.split()[1])
                            if 0 < inactive < val:
                                val -= inactive
                            break
            except (FileNotFoundError, PermissionError, ValueError, IndexError):
                pass          # fail-safe: fall back to raw usage
            return val
        except (FileNotFoundError, PermissionError, ValueError):
            continue
        except Exception as exc:
            logger.debug("BF-558c cgroup usage read failed (%s): %s", path, exc)
            continue
    return None


def read_pod_memory_usage_bytes() -> Optional[int]:
    """Return CURRENT pod memory usage in bytes, or None if unavailable.

    BF-558c: admission control needs to know how much memory is actually
    in use.  Deliberately MEASURED, not estimated: a per-query memory
    prediction we do not have would either over-estimate (serialising
    every query behind one reservation) or under-estimate (protecting
    nothing).  Measured usage needs no prediction at all.

    cgroup first (it is what the OOM-killer actually watches), psutil as
    the fallback for Windows / non-containerised dev boxes.  Never raises.
    """
    val = _read_cgroup_working_set_bytes()
    if val is not None:
        return val
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.total - vm.available)
    except Exception as exc:
        logger.debug("BF-558c psutil usage read failed: %s", exc)
    return None


def _read_proc_meminfo_total_bytes() -> Optional[int]:
    """Linux /proc/meminfo fallback when cgroup is absent."""
    try:
        with open("/proc/meminfo", "r") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    return kb * 1024
    except Exception as exc:
        # Non-Linux platforms (Windows / macOS) won't have /proc/meminfo.
        # Caller's fallback chain handles this — debug-log only so we
        # can spot real surprises in production.
        logger.debug("BF-528 /proc/meminfo read failed: %s", exc)
    return None


# Smallest per-child memory_limit we will ever hand DuckDB.  Below this
# DuckDB struggles to build even one hash table, and it is better to let
# a child spill hard than to shrink it into constant thrashing.
MIN_PER_CHILD_MEMORY_BYTES = 256 * 1024 * 1024


# ── Role-aware reserve (2026-08-02) ─────────────────────────────────────────
#
# INCIDENT (2026-08-02): single-table query, 31 files, SINGLE worker, on a
# 30 GiB / 4-CPU HYBRID pod (QS_POD_ROLE unset -> "hybrid": the API process
# co-hosts the ENTIRE background daemon fleet — ~18 daemons, measured at
# >20 GiB in the 2026-07-02 incident that created core.pod_role).  This
# resolver handed that ONE child 75% of the cgroup = 22.5 GiB.  A
# memory_limit is a CEILING, not a reservation: the child grew freely
# (never spilling — it believed it had 22.5 GiB) until
# ceiling-in-progress + API + daemons crossed the 30 GiB cgroup limit and
# the KERNEL OOM-killed the pod (cgroup-v2 memory.oom.group=1 kills the
# whole tree, API included) ~100 s into the query.  Concurrency was 1, so
# the BF-558b divisor could not help — the 25% reserve itself was sized
# for a pod that runs ONLY queries.
#
# THE INVARIANT: DuckDB's memory ceiling PLUS everything else co-resident
# in the pod must stay below the cgroup limit AT EVERY CONCURRENCY,
# INCLUDING 1.  Two complementary mechanisms enforce it:
#
#   1. STATIC role-aware reserve — ``core.pod_role`` already knows whether
#      the daemon fleet lives here:
#        * role=api                       -> caller's reserve (default 25%).
#          No daemons; byte-identical to the pre-2026-08-02 answer, so the
#          split topology (the deployment shape that ALREADY paid for
#          isolation) is never shrunk.
#        * role=hybrid + scheduler.mode=external -> caller's reserve.
#          Hybrid's legacy gate parks the daemons on the scheduler pod, so
#          this pod's co-residents are API-sized, not fleet-sized.
#        * role=hybrid (embedded) / role=worker  -> max(caller's, 50%).
#          The fleet is co-resident and its footprint is NOT optional.
#      Applies only when the budget came from a CGROUP: off-cgroup (dev
#      boxes, bare VMs) there is no group OOM-kill and the historical
#      answers are pinned by the Windows-BSOD gates — unchanged.
#
#   2. MEASURED co-habitant clamp — the static reserve keeps idle pods
#      deterministic, but the recorded fleet footprint (>20 GiB) can
#      exceed ANY static reserve.  So the per-child ceiling is additionally
#      clamped to what the cgroup can actually still absorb:
#      ``limit - current working set - margin``.  Working set comes from
#      the cgroup ONLY (``_read_cgroup_working_set_bytes``): the psutil
#      fallback would count the whole box off-cgroup and wrongly shrink
#      dev-machine limits.  The clamp only ever LOWERS a ceiling (floored
#      at MIN_PER_CHILD_MEMORY_BYTES so the query still starts and spills)
#      and unknown usage means NO clamp.
#
# Fail-open everywhere: any resolution failure falls back to the caller's
# reserve / no clamp.  A larger reserve can only mean earlier SPILL —
# never a refused query.

DEFAULT_RESERVE_PCT = 0.25
HYBRID_RESERVE_PCT = 0.50
_HEADROOM_MARGIN_FRACTION = 0.10     # of the cgroup limit
_HEADROOM_MARGIN_MIN_BYTES = 1024 ** 3


def _pod_hosts_daemon_fleet() -> bool:
    """True when the background daemon fleet is co-resident on THIS pod.

    api -> False.  worker -> True.  hybrid -> follows the legacy
    ``scheduler.mode`` gate (external = daemons live on the scheduler pod,
    mirroring ``PodRole.should_run``).  Fail-open to True: the unknown
    case behaves like the default hybrid-embedded posture, where a larger
    reserve is the safe direction (spill, not OOM)."""
    try:
        from core import pod_role
        role = pod_role.current()
        if role.is_api():
            return False
        if role.is_worker():
            return True
        # hybrid — same gate should_run() applies per-daemon.
        try:
            from core.config import scheduler as _sched_cfg
            mode = str(getattr(_sched_cfg, "mode", "embedded")
                       or "embedded").strip().lower()
        except Exception as exc:
            logger.debug(
                "role-aware reserve: scheduler.mode read failed "
                "(assuming embedded): %s", exc)
            mode = "embedded"
        return mode != "external"
    except Exception as exc:
        logger.debug(
            "role-aware reserve: pod role probe failed (assuming "
            "fleet-resident): %s", exc)
        return True


def _hybrid_reserve_pct() -> float:
    """Operator-tunable reserve for fleet-resident pods.  Env wins over
    config; both optional.  Values outside (0, 1) are ignored."""
    raw = ""
    try:
        raw = os.environ.get("QS_DUCKDB_HYBRID_RESERVE_PCT", "").strip()
        if not raw:
            try:
                from core.config import get as _cfg_get
                raw = str(_cfg_get(
                    "duckdb", "hybrid_reserve_pct", "") or "").strip()
            except Exception as exc:
                logger.debug(
                    "hybrid reserve: config read failed (default): %s", exc)
                raw = ""
        if raw:
            val = float(raw)
            if 0.0 < val < 1.0:
                return val
            logger.debug(
                "hybrid reserve: %r outside (0,1) — using default", raw)
    except (TypeError, ValueError) as exc:
        logger.debug("hybrid reserve: unparseable %r (default): %s", raw, exc)
    except Exception as exc:
        logger.debug("hybrid reserve: resolve failed (default): %s", exc)
    return HYBRID_RESERVE_PCT


def effective_reserve_pct(reserve_pct: float = DEFAULT_RESERVE_PCT,
                          budget_from_cgroup: bool = True) -> float:
    """The reserve fraction that actually applies on this pod.

    ``max(caller's reserve, hybrid reserve)`` when the daemon fleet is
    co-resident AND the budget is cgroup-bounded; the caller's reserve
    otherwise.  max() so an explicit larger caller choice always wins and
    the function can only ever RAISE the reserve (shrink DuckDB), never
    hand out more than the caller intended.  Never raises."""
    try:
        base = max(0.0, min(1.0, float(reserve_pct)))
    except (TypeError, ValueError):
        base = DEFAULT_RESERVE_PCT
    try:
        if not budget_from_cgroup:
            return base
        if not _pod_hosts_daemon_fleet():
            return base
        return max(base, _hybrid_reserve_pct())
    except Exception as exc:
        logger.debug("effective reserve failed (using base %.2f): %s",
                     base, exc)
        return base


def _cohabitant_headroom_bytes(limit_bytes: int) -> Optional[int]:
    """MEASURED ceiling for a new DuckDB child on a fleet-resident pod:
    ``cgroup limit - working set of everything already running - margin``.

    Returns None for "no clamp" (api role / off-cgroup / unreadable usage
    / operator opt-out via QS_DUCKDB_DISABLE_HEADROOM_CLAMP), or a value
    >= 0 that the caller may only use to LOWER a ceiling.  Never raises."""
    try:
        opt_out = os.environ.get(
            "QS_DUCKDB_DISABLE_HEADROOM_CLAMP", "").strip().lower()
        if opt_out in ("1", "true", "yes", "on"):
            return None
        if not limit_bytes or limit_bytes <= 0:
            return None
        if not _pod_hosts_daemon_fleet():
            return None
        used = _read_cgroup_working_set_bytes()
        if used is None or used <= 0:
            return None
        margin = max(_HEADROOM_MARGIN_MIN_BYTES,
                     int(limit_bytes * _HEADROOM_MARGIN_FRACTION))
        return max(0, int(limit_bytes) - int(used) - margin)
    except Exception as exc:
        logger.debug("cohabitant headroom probe failed (no clamp): %s", exc)
        return None


def resolve_memory_limit_for_duckdb(reserve_pct: float = 0.25,
                                    concurrency: int = 1) -> str:
    """Return the ``memory_limit`` string to feed to DuckDB
    (e.g. ``"3.0GB"``).  Empty string = let DuckDB auto-detect.

    Args:
        reserve_pct: fraction of cgroup memory to LEAVE for everything
            else (python runtime, S3 client buffers, OS).  Default
            25% → DuckDB gets 75% of cgroup limit, matching its own
            auto-detect heuristic but bounded by the cgroup not the
            host.
        concurrency: how many DuckDB children will run CONCURRENTLY in
            this pod.  The pod budget is shared, so each child may only
            claim ``1/concurrency`` of it.  Default 1 keeps the
            single-child answer byte-identical to the pre-BF-558b
            behaviour.

            Without this divisor every child independently claimed 75%
            of the WHOLE pod, so an N-way fan-out promised N × 75% of
            memory that does not exist — the pod is then OOM-killed by
            the kernel rather than spilling, because no single DuckDB
            ever believes it is over budget.

    Returns the bare GB / MB string DuckDB accepts.  Returns ``""``
    when the resolver can't infer a bound — caller leaves the PRAGMA
    unset and DuckDB falls back to its own auto-detect.

    2026-08-02: the reserve is now ROLE-AWARE and additionally clamped by
    the pod's MEASURED headroom on fleet-resident (hybrid/worker) pods —
    see the block comment above ``effective_reserve_pct``.  With
    ``QS_POD_ROLE=api`` (or off-cgroup) the answer is byte-identical to
    the pre-2026-08-02 behaviour.
    """
    try:
        budget = _read_cgroup_memory_limit_bytes()
        _from_cgroup = budget is not None and budget > 0
        if not _from_cgroup:
            # R3 (2026-08-03): this fallback chain used to engage with no
            # log above debug — make it loud, once per process.
            warn_cgroup_unreadable_once("resolve_memory_limit_for_duckdb")
            budget = _read_proc_meminfo_total_bytes()
        if budget is None or budget <= 0:
            return ""
        _reserve = effective_reserve_pct(
            reserve_pct, budget_from_cgroup=_from_cgroup)
        usable = int(budget * (1.0 - max(0.0, min(1.0, _reserve))))
        # 2026-08-02 measured co-habitant clamp (fleet-resident pods on a
        # cgroup only): never promise a ceiling the cgroup cannot absorb on
        # top of what is ALREADY resident.  min() — the clamp can only
        # LOWER a ceiling; the MIN_PER_CHILD floor keeps the child able to
        # start and spill even on a pod that is already saturated.
        #
        # Applied BEFORE the concurrency divisor, deliberately: N children
        # share ONE headroom, so the clamp must bound the POOL they divide,
        # not each child independently (clamping after the division would
        # let N children each take the full headroom = N x an amount the
        # pod can absorb exactly once).
        if _from_cgroup:
            _headroom = _cohabitant_headroom_bytes(int(budget))
            if _headroom is not None and usable > _headroom:
                _clamped = min(usable,
                               max(_headroom, MIN_PER_CHILD_MEMORY_BYTES))
                logger.info(
                    "resolve_memory_limit_for_duckdb: measured headroom "
                    "clamp %.1f GB -> %.1f GB (cgroup=%.1f GB, co-resident "
                    "working set leaves %.1f GB headroom)",
                    usable / 1024 ** 3, _clamped / 1024 ** 3,
                    budget / 1024 ** 3, _headroom / 1024 ** 3)
                usable = _clamped
        # Share the pod budget across concurrent children.  Clamp rather
        # than returning "" — an empty limit makes DuckDB auto-detect the
        # HOST's memory, which is strictly worse than a small explicit
        # bound under high fan-out.
        try:
            _conc = int(concurrency)
        except (TypeError, ValueError):
            _conc = 1
        if _conc > 1:
            usable = max(usable // _conc, MIN_PER_CHILD_MEMORY_BYTES)
        if usable < (256 * 1024 * 1024):
            # Pathologically small container — let DuckDB error itself
            # rather than us shipping a "0 MB" limit.
            return ""
        # DuckDB accepts integer-MB / integer-GB strings.  Prefer GB
        # when round-ish, else fall back to MB.
        gb = usable / (1024 ** 3)
        if gb >= 1.0:
            return f"{gb:.1f}GB"
        mb = usable // (1024 ** 2)
        return f"{mb}MB"
    except Exception as exc:
        logger.debug("BF-528 memory resolver failed: %s", exc)
        return ""


# ── Width-aware limits (2026-08-02) ─────────────────────────────────────────
#
# MEASURED DEFECT: at memory_limit=256MB a 900-column COPY-to-parquet dies
# with OutOfMemoryException instead of spilling — even with temp_directory
# set and preserve_insertion_order=false.  A narrow (12-col) query at the
# same 256 MB spills hundreds of MB and completes.  WIDTH is the difference:
# DuckDB's per-thread buffers (a full 2048-row vector per column per
# operator, plus one parquet column-writer state per column) scale with
# column count, and none of that memory is spillable — so below a
# width-dependent floor the query CANNOT complete at any spill budget.
#
# Measured minimum-viable (memory, threads) pairs, DuckDB 1.5.2,
# COPY (SELECT * FROM read_parquet(<w>-col file)) TO parquet (zstd),
# width-aware ROW_GROUP_SIZE already applied, temp_directory set,
# preserve_insertion_order=false  (tests bracketing each boundary):
#
#     cols   threads=1            threads=2            threads=4
#     130    256MB OK             —                    256MB FAIL
#     450    384 FAIL / 512 OK    768 FAIL             —
#     900    640 FAIL / 768 OK    1024 FAIL / 1536 OK  1024 FAIL
#
# Two conclusions, both load-bearing:
#   1. The cost is PER THREAD: 900 cols needs ~768 MB x threads.
#      Reducing threads is the cheapest fix when the budget is small.
#   2. Threads=1 alone is NOT sufficient: at >=450 columns the floor
#      itself must rise above 256 MB (450 -> ~512, 900 -> ~768).
#
# The floor formula below is the measured per-thread minimum with a ~1.4x
# safety margin (production files can have larger row groups and wider
# values than the repro): max(256MB, 1.4MB x n_columns) per thread.
# Validated by execution: 900 cols @ 1260MB/1 thread OK, 450 @ 630/1 OK.
#
# Tables at or below WIDTH_FLOOR_COLUMN_THRESHOLD are untouched — the
# same <=130-column boundary where core.parquet_write_opts leaves
# ROW_GROUP_SIZE alone, and measured fine at the 256 MB floor with 1
# thread.  This keeps the common (narrow) case byte-identical.

WIDTH_FLOOR_COLUMN_THRESHOLD = 130
WIDTH_FLOOR_MB_PER_COLUMN = 1.4
# current_setting('memory_limit') reports binary units for a decimal SET
# ('256MB' reads back '244.1 MiB').  Without slack the round-trip alone
# would trigger pointless nudges at the boundary.
_WIDTH_ADJUST_SLACK = 0.95


def min_memory_mb_for_width(n_columns) -> int:
    """Minimum viable ``memory_limit`` in MB for a single-threaded DuckDB
    operation over ``n_columns`` columns.  256 (the existing floor) for
    narrow/unknown widths; grows linearly above the threshold.  Never
    raises."""
    try:
        n = int(n_columns or 0)
    except (TypeError, ValueError):
        return MIN_PER_CHILD_MEMORY_BYTES // (1024 * 1024)
    floor_mb = MIN_PER_CHILD_MEMORY_BYTES // (1024 * 1024)
    if n <= WIDTH_FLOOR_COLUMN_THRESHOLD:
        return floor_mb
    return max(floor_mb, int(n * WIDTH_FLOOR_MB_PER_COLUMN + 0.999))


def _pod_usable_memory_bytes(reserve_pct: float = 0.25) -> int:
    """Usable (post-reserve) pod memory in bytes, 0 when unknowable.
    Same resolution chain as resolve_memory_limit_for_duckdb plus the
    psutil fallback used by the multi-worker resolver.

    2026-08-02: role-aware — this value caps the width-aware memory
    ESCALATION, so on a fleet-resident (hybrid/worker) pod it must not
    promise the daemons' share either."""
    try:
        budget = _read_cgroup_memory_limit_bytes()
        _from_cgroup = budget is not None and budget > 0
        if not _from_cgroup:
            budget = _read_proc_meminfo_total_bytes()
        if budget is None or budget <= 0:
            try:
                import psutil
                budget = int(psutil.virtual_memory().total)
            except Exception:
                budget = None
        if budget is None or budget <= 0:
            return 0
        _reserve = effective_reserve_pct(
            reserve_pct, budget_from_cgroup=_from_cgroup)
        return int(budget * (1.0 - max(0.0, min(1.0, _reserve))))
    except Exception:
        return 0


def width_aware_limits(n_columns,
                       memory_limit_bytes,
                       threads,
                       sql_text: Optional[str] = None):
    """Given a query's column count and the currently-effective
    (memory_limit, threads), return ``(new_memory_mb, new_threads)`` where
    each element is ``None`` for "leave unchanged".

    ``sql_text`` (optional): when it contains an ORDER BY, the per-thread
    floor is DOUBLED.  Measured: a 900-col external sort fails at the
    1260MB scan/copy floor but completes at 2520MB with 1.5 GB genuinely
    spilled — sort payload rows carry every column and DuckDB's sort
    keeps a larger unspillable working set than a streaming scan.  A
    substring check (window functions count too — they also sort) errs
    toward granting bounded extra memory to wide queries only.

    Decision ladder (all measured — see the matrix above):
      * narrow (<= WIDTH_FLOOR_COLUMN_THRESHOLD cols), unknown width, or
        unknown memory limit -> no change.  The common case stays
        byte-identical.
      * budget >= per-thread-need x threads -> no change (wide but rich).
      * budget fits >= 1 thread -> REDUCE THREADS to what fits; memory
        unchanged (no extra budget claimed — the free lever).
      * budget cannot fit even 1 thread -> threads=1 AND RAISE memory to
        the single-thread width floor, capped at the pod's usable budget.
        This deliberately lets a wide query exceed its fair concurrency
        share by a bounded amount (~1.4MB/column, e.g. ~1.3GB at 900
        cols): below the floor the query is GUARANTEED to fail — it
        cannot spill its way out — so the fair share is a promise of
        wasted work.  Bounded over-share + spill beats certain
        OutOfMemoryException.  Never LOWERS the memory limit.

    Pure and fail-open: any bad input returns (None, None).  Never raises.
    """
    try:
        n = int(n_columns or 0)
        if n <= WIDTH_FLOOR_COLUMN_THRESHOLD:
            return (None, None)
        mem_b = int(memory_limit_bytes or 0)
        if mem_b <= 0:
            # Unknown/unset limit — DuckDB auto-detect; do not guess.
            return (None, None)
        try:
            t = max(1, int(threads or 1))
        except (TypeError, ValueError):
            t = 1
        need1_mb = min_memory_mb_for_width(n)
        try:
            if sql_text and "order by" in str(sql_text).lower():
                need1_mb *= 2
        except Exception as _sort_exc:
            # Not silent: a str() failure here means the ORDER BY doubling
            # was skipped, so a wide external sort gets the scan-sized floor
            # and may OOM instead of spilling.  Worth a breadcrumb.
            logger.debug(
                "width_aware_limits: ORDER BY probe failed, using the "
                "un-doubled floor (%s)", _sort_exc)
        cur_mb = mem_b / (1024.0 * 1024.0)
        if cur_mb >= need1_mb * t * _WIDTH_ADJUST_SLACK:
            return (None, None)
        fit_t = int(cur_mb / (need1_mb * _WIDTH_ADJUST_SLACK))
        if fit_t >= 1:
            new_t = min(t, fit_t)
            return (None, new_t if new_t != t else None)
        # Even one thread cannot fit: escalate memory to the width floor,
        # capped at the pod's usable budget (never above it, never below
        # the current limit).
        new_mem_mb = need1_mb
        usable_b = _pod_usable_memory_bytes()
        if usable_b > 0:
            usable_mb = usable_b // (1024 * 1024)
            if usable_mb > 0:
                new_mem_mb = min(new_mem_mb, int(usable_mb))
        if new_mem_mb <= cur_mb:
            # Cap swallowed the escalation — at least drop to 1 thread.
            return (None, 1 if t != 1 else None)
        return (int(new_mem_mb), 1 if t != 1 else None)
    except Exception as exc:                                 # pragma: no cover
        logger.debug("width_aware_limits failed (fail-open): %s", exc)
        return (None, None)


# ── Threads ─────────────────────────────────────────────────────────────────


def _read_cgroup_cpu_quota() -> Optional[float]:
    """Return effective CPU count from cgroup quota, or None."""
    try:
        # cgroup v2: "<quota> <period>" in cpu.max.  If quota == "max",
        # no limit.
        path_v2 = "/sys/fs/cgroup/cpu.max"
        if os.path.exists(path_v2):
            with open(path_v2, "r") as fh:
                raw = fh.read().strip().split()
            if len(raw) >= 2 and raw[0] != "max":
                quota = int(raw[0])
                period = int(raw[1])
                if period > 0 and quota > 0:
                    return quota / period
        # cgroup v1.
        q_path = "/sys/fs/cgroup/cpu/cpu.cfs_quota_us"
        p_path = "/sys/fs/cgroup/cpu/cpu.cfs_period_us"
        if os.path.exists(q_path) and os.path.exists(p_path):
            with open(q_path, "r") as fh:
                q = int(fh.read().strip())
            with open(p_path, "r") as fh:
                p = int(fh.read().strip())
            if q > 0 and p > 0:
                return q / p
    except Exception as exc:
        logger.debug("BF-528 cgroup CPU read failed: %s", exc)
    return None


def resolve_thread_count_for_duckdb(headroom: int = 1,
                                    concurrency: int = 1) -> int:
    """Return a bounded ``threads`` value for DuckDB.

    Reads cgroup CPU quota first (containers), falls back to
    ``os.cpu_count()``.  Reserves ``headroom`` CPU for the python
    runtime / heartbeat / cancel watchdog so the pod stays
    responsive while DuckDB is hot.

    Small-pod rule: when the cgroup CPU quota is <= 2, we DO NOT
    reserve a headroom CPU.  On a 2-CPU pod, headroom=1 would leave
    DuckDB with threads=1 — observed in prod 2026-06-18 with the
    error log "SUBPROCESS: DuckDB threads=1" alongside slow BQB
    queries.  Headroom only buys responsiveness when there's slack
    to give.

    2026-08-02: ``concurrency`` mirrors the memory divisor (BF-558b).
    The pod's CPU quota is shared by every concurrent DuckDB engine,
    but each engine independently claimed ``cpus - 1`` threads — 30
    concurrent engines x 7 threads on an 8-vCPU pod = 210 runnable
    threads, a 26x oversubscription where every query thrashes and
    holds its slot longer.  Each engine may only claim
    ``1/concurrency`` of the quota.  Default 1 keeps the answer
    byte-identical to the pre-2026-08-02 behaviour.

    Minimum return is 1 — DuckDB rejects threads=0, and a starved
    engine must still make progress (floor, mirroring the 256 MB
    memory floor).
    """
    try:
        cpus = _read_cgroup_cpu_quota()
        if cpus is None:
            cpus = float(os.cpu_count() or 1)
        cpus_int = max(1, int(round(cpus)))
        if cpus_int <= 2:
            base = cpus_int
        else:
            base = max(1, cpus_int - headroom)
        try:
            _conc = int(concurrency)
        except (TypeError, ValueError):
            _conc = 1
        if _conc > 1:
            # ROUND, do not floor.  The goal is that the SUM of threads
            # across concurrent engines lands near the CPU quota — not that
            # each engine is individually conservative.  Floor division
            # overshoots downward and wastes the pod: on 8 vCPU a 4-worker
            # dispatch got 7//4 = 1 thread each = 4 threads TOTAL, leaving
            # half the CPU idle while the query ran ~3.5x slower than at 8
            # threads (measured 2026-08-02).  Rounding gives 2 each = 8
            # total, which is the intent.
            #
            # Over-subscription is still bounded: worst case is one extra
            # thread per engine, and the OS scheduler handles that far
            # better than idle cores handle a starved query.
            return max(1, int(round(base / _conc)))
        return base
    except Exception as exc:
        logger.debug("BF-528 thread resolver failed: %s", exc)
        return 1


def parse_memory_limit_to_bytes(limit: str) -> int:
    """Parse a DuckDB memory-limit string ('22.5GB', '512MB', '1TiB') to bytes.

    Returns 0 when the value is empty or unparseable — callers must treat 0 as
    "unknown" and fall back to their previous behaviour rather than assuming a
    size.

    2026-07-31 CORRECTION: an earlier version of this docstring claimed
    "DuckDB itself treats the suffixes as binary multiples".  That is FALSE --
    measured, ``SET memory_limit='1GB'`` reports back 953.6 MiB, i.e. DuckDB
    reads GB as DECIMAL (10^9).  We keep the binary reading here because the
    only consumer is the spill-quota derivation, where over-estimating the
    memory limit by ~7% errs toward a LARGER spill budget (the safe
    direction).  Do NOT reuse this function anywhere that needs to agree with
    DuckDB's own accounting without fixing the units first.
    """
    if not limit:
        return 0
    s = str(limit).strip().upper().replace("_", "")
    if not s:
        return 0
    units = (
        ("PIB", 1024 ** 5), ("TIB", 1024 ** 4), ("GIB", 1024 ** 3),
        ("MIB", 1024 ** 2), ("KIB", 1024),
        ("PB", 1024 ** 5), ("TB", 1024 ** 4), ("GB", 1024 ** 3),
        ("MB", 1024 ** 2), ("KB", 1024), ("B", 1),
    )
    for suffix, mult in units:
        if s.endswith(suffix):
            head = s[: -len(suffix)].strip()
            try:
                return int(float(head) * mult)
            except ValueError:
                return 0
    try:
        return int(float(s))          # bare number == bytes
    except ValueError:
        return 0


# ── Spill quota ─────────────────────────────────────────────────────────────

# Spill budget as a multiple of the in-core memory limit.  Spilling exists to
# serve working sets LARGER than memory, so this must be > 1 or the mechanism
# cannot do its job (the old flat 10 GB alongside a 22.5 GB memory_limit was
# effectively 0.44x).  4x matches the Trino/Starburst convention of sizing
# spill in multiples of query memory.  Still ceilinged by free disk.
SPILL_TO_MEMORY_RATIO = 4.0

# ── Fleet-safety (2026-08-02): spill on SHARED storage ──────────────────────
#
# The free-disk ceiling below is sampled INDEPENDENTLY by every pod.  When
# the spill dir sits on a shared RWX volume (the pre-2026-08 Helm layout put
# DUCKDB_TEMP_DIR on the same 50Gi NFS PVC that carries result parquet, the
# query/agg caches and DuckDB extensions), N pods each read the SAME free
# number and each grant themselves the same share — a collective promise of
# N x the disk, redeemed simultaneously at peak memory pressure (which is
# exactly when everything spills) and landing as ENOSPC mid-query.  The
# intra-pod ``concurrent_children`` divisor (F3) cannot see other pods.
#
# The REAL fix is pod-local spill (Helm ``spill.podLocal``, default ON) —
# spill is per-query scratch with no cross-pod value, so an emptyDir is its
# natural home and the divisor question disappears.  For deployments that
# keep the shared layout, the DEPLOYMENT declares the sharing topology and
# the resolver divides honestly:
#
#   QS_SPILL_POD_COUNT       env  /  duckdb.spill_pod_count       config
#       Number of pods sharing the spill volume.  The Helm chart stamps
#       this automatically when spill.podLocal is disabled.
#   QS_SPILL_DIR_SHARED      env  /  duckdb.spill_dir_shared      config
#       Truthy = the dir is shared even though the pod count is unknown;
#       falsy = explicitly not shared (silences the path heuristic).
#   QS_SPILL_DIR_CAPACITY_GB env  /  duckdb.spill_dir_capacity_gb config
#       Declared capacity of the spill VOLUME in GiB.  Needed for
#       emptyDir-backed spill: statvfs on an emptyDir reports the NODE's
#       free disk, but the kubelet EVICTS the pod once the volume exceeds
#       its sizeLimit — the quota must respect the declared limit, not
#       raw free space.
#
# Pod count is UNKNOWABLE from inside a pod without asking the Kubernetes
# API (which this resolver must not require — it also runs on VMs and dev
# boxes).  Branches:
#   * declared shared + declared count -> divide the disk share by count.
#   * declared shared + count unknown  -> divide by the conservative
#     fallback below.  We KNOW the promise doesn't compose; guessing low
#     would re-create the defect, so we guess high (4 ~= this chart's
#     typical per-component replica counts).
#   * nothing declared, path merely LOOKS shared (…/nfs/…) -> divisor 1
#     plus a debug breadcrumb.  We cannot distinguish N=1 from N=10 here,
#     and dividing on a guess would shrink today's single-pod budget —
#     the hard compatibility constraint (a smaller budget turns working
#     queries into failures).  core.fleet_safety's ``spill_is_pod_local``
#     precondition surfaces this state to operators instead.
_SHARED_POD_COUNT_FALLBACK = 4


def _spill_dir_is_declared(temp_dir: str) -> bool:
    """True when ``temp_dir`` is (inside) the deployment-declared spill dir.

    The QS_SPILL_* topology declarations describe THAT volume.  When a
    child has fallen back to a pod-local OS temp dir (the 2026-07-16
    writable-fallback chain in ``_child_main``) they must NOT apply: the
    fallback dir is neither shared nor capacity-limited, and shrinking
    its budget would punish exactly the constrained child the fallback
    exists to save.  With no declared dir at all the declarations apply
    to whatever dir the caller passes (the operator set them globally).
    """
    try:
        declared = []
        env_dir = os.environ.get("DUCKDB_TEMP_DIR", "").strip()
        if env_dir:
            declared.append(env_dir)
        try:
            from core.config import get as _cfg_get
            for _key in ("duckdb_spill_dir", "duckdb_temp_dir"):
                _val = str(_cfg_get("paths", _key, "") or "").strip()
                if _val:
                    declared.append(_val)
        except Exception as exc:
            logger.debug("spill topology: config paths read failed: %s", exc)
        if not declared:
            return True
        probe = os.path.normcase(os.path.abspath(str(temp_dir)))
        for d in declared:
            base = os.path.normcase(os.path.abspath(d))
            if probe == base or probe.startswith(
                    base.rstrip("\\/") + os.sep):
                return True
        return False
    except Exception as exc:
        # Fail toward the honest (divided/capped) math — the child still
        # has a usable dir either way.
        logger.debug("spill topology: declared-dir probe failed: %s", exc)
        return True


def spill_dir_capacity_bytes(temp_dir: str) -> int:
    """Declared capacity of the spill volume in bytes; 0 = undeclared.

    Sourced from ``QS_SPILL_DIR_CAPACITY_GB`` (env, stamped by the Helm
    chart from the emptyDir sizeLimit) or ``duckdb.spill_dir_capacity_gb``
    (config.json).  Applies only to the declared spill dir — see
    ``_spill_dir_is_declared``.  Never raises.
    """
    try:
        if not _spill_dir_is_declared(temp_dir):
            return 0
        raw = os.environ.get("QS_SPILL_DIR_CAPACITY_GB", "").strip()
        if not raw:
            try:
                from core.config import get as _cfg_get
                raw = str(_cfg_get(
                    "duckdb", "spill_dir_capacity_gb", "") or "").strip()
            except Exception as exc:
                logger.debug(
                    "spill capacity: config read failed: %s", exc)
                raw = ""
        if not raw:
            return 0
        val = float(raw)
        if val <= 0:
            return 0
        return int(val * (1024 ** 3))
    except (TypeError, ValueError) as exc:
        logger.debug(
            "spill capacity: unparseable declaration (fail-open): %s", exc)
        return 0
    except Exception as exc:
        logger.debug("spill capacity resolver failed (fail-open): %s", exc)
        return 0


def spill_shared_pod_divisor(temp_dir: str) -> int:
    """How many PODS share the spill volume (always >= 1).

    See the fleet-safety block comment above for the branch rationale.
    Never raises; any failure returns 1 (today's behaviour).
    """
    try:
        if not _spill_dir_is_declared(temp_dir):
            return 1
        raw = os.environ.get("QS_SPILL_POD_COUNT", "").strip()
        if not raw:
            try:
                from core.config import get as _cfg_get
                raw = str(_cfg_get(
                    "duckdb", "spill_pod_count", "") or "").strip()
            except Exception as exc:
                logger.debug(
                    "spill pod count: config read failed: %s", exc)
                raw = ""
        if raw:
            try:
                pods = int(float(raw))
                if pods >= 1:
                    return pods
            except (TypeError, ValueError):
                logger.debug(
                    "spill pod count: unparseable %r (ignored)", raw)
        shared_raw = os.environ.get("QS_SPILL_DIR_SHARED", "").strip()
        if not shared_raw:
            try:
                from core.config import get as _cfg_get
                _cfg_val = _cfg_get("duckdb", "spill_dir_shared", None)
                shared_raw = "" if _cfg_val is None else str(_cfg_val).strip()
            except Exception as exc:
                logger.debug(
                    "spill shared flag: config read failed: %s", exc)
                shared_raw = ""
        if shared_raw:
            if shared_raw.lower() in ("1", "true", "yes", "on"):
                # Declared shared, pod count UNKNOWABLE from in here (no
                # k8s API dependency allowed) — conservative branch.
                return _SHARED_POD_COUNT_FALLBACK
            return 1        # explicitly declared not-shared
        # Nothing declared.  Heuristic (mirrors core.fleet_safety
        # _spill_is_pod_local): a path under an NFS mount LOOKS shared,
        # but dividing on a guess would shrink a single-pod deployment's
        # working budget — breadcrumb only.
        norm = str(temp_dir).replace("\\", "/").lower()
        if "/nfs/" in norm or norm.endswith("/nfs"):
            logger.debug(
                "spill dir %s looks like SHARED storage but neither "
                "QS_SPILL_POD_COUNT nor QS_SPILL_DIR_SHARED is declared — "
                "assuming a single pod (dividing on a guess would shrink "
                "a single-pod deployment's budget).  Prefer pod-local "
                "spill (Helm spill.podLocal) or declare the topology.",
                temp_dir)
        return 1
    except Exception as exc:
        logger.debug(
            "spill shared-pod divisor failed (fail-open to 1): %s", exc)
        return 1


def resolve_spill_quota_bytes(temp_dir: str,
                                max_default_gb: int = 10,
                                free_disk_fraction: float = 0.5,
                                memory_limit_bytes: int = 0,
                                concurrent_children: int = 1) -> int:
    """Return a max-temp-directory-size in bytes.

    Bounded at the smaller of:
      * the absolute cap (see below)
      * ``free_disk_fraction`` of the free space on ``temp_dir`` (default
        50%) so a pathological query can't fill the PVC and crash every
        other query.

    2026-07-31 -- THE ABSOLUTE CAP IS NOW DERIVED FROM ``memory_limit_bytes``.

    The old flat 10 GB default was INCOHERENT with the memory limit it sits
    beside: a pod resolved to ``memory_limit=22.5GB`` but only 10 GB of spill,
    so the OUT-OF-CORE budget was less than HALF the IN-CORE budget.  Any
    operator whose working set exceeded RAM by more than 10 GB was dead by
    construction -- which is exactly how a 900-column scan died with
    ``OutOfMemoryException: failed to offload data block of size 256.0 KiB
    (10.0 GiB/10.0 GiB used)``.  Spilling exists precisely to handle
    working sets LARGER than memory; capping it below memory defeats it.

    Trino/Starburst size spill as a MULTIPLE of query memory.  We do the same:
    ``SPILL_TO_MEMORY_RATIO x memory_limit``, floored at the historical
    ``max_default_gb`` so this can only ever RAISE the cap (no deployment gets
    a smaller budget than it has today), and still ceilinged by free disk so
    the PVC guarantee from BF-529 is preserved.

    Resolution order:
      1. ``DUCKDB_SPILL_QUOTA_GB`` env var (absolute override, unchanged)
      2. ``duckdb.spill_quota_gb`` in config.json (NEW -- previously this
         value was a Python function-arg default with NO config key at all,
         so operators could not change it without setting an env var)
      3. ``max(max_default_gb, ratio x memory_limit)``, capped by free disk

    2026-08-02 (fleet safety) -- the free-disk ceiling additionally honours
    the declared sharing topology: the basis is capped at
    ``QS_SPILL_DIR_CAPACITY_GB`` (emptyDir sizeLimit) and the share is
    divided by ``QS_SPILL_POD_COUNT`` on top of ``concurrent_children``
    when the volume is declared shared.  See the fleet-safety block
    comment above ``_SHARED_POD_COUNT_FALLBACK``.  With nothing declared
    (today's single-pod deployment) the answer is byte-identical.

    Returns 0 on resolver failure → caller leaves the PRAGMA unset (DuckDB
    defaults to unbounded; the operator is back to the old failure mode but
    at least nothing breaks).
    """
    try:
        override = os.environ.get("DUCKDB_SPILL_QUOTA_GB", "").strip()
        if override:
            return int(float(override) * (1024 ** 3))

        # config.json knob (new) — same units as the env var.
        cfg_gb = 0.0
        try:
            from core.config import get as _cfg_get
            cfg_gb = float(_cfg_get("duckdb", "spill_quota_gb", 0) or 0)
        except Exception:
            cfg_gb = 0.0
        if cfg_gb > 0:
            absolute = int(cfg_gb * (1024 ** 3))
        else:
            absolute = int(max_default_gb) * (1024 ** 3)
            if memory_limit_bytes and memory_limit_bytes > 0:
                derived = int(memory_limit_bytes * SPILL_TO_MEMORY_RATIO)
                # Floor at the historical default: never SHRINK an existing
                # deployment's budget as a side effect of this change.
                absolute = max(absolute, derived)

        usage = shutil.disk_usage(temp_dir)
        # 2026-08-02 fleet-safety: cap the basis at the DECLARED volume
        # capacity.  emptyDir-backed spill reports the NODE's free space,
        # but the kubelet evicts the pod once the volume hits its
        # sizeLimit — sizing from raw free would over-promise straight
        # into an eviction.  0 (undeclared) leaves the basis untouched.
        _free_basis = usage.free
        _cap_b = spill_dir_capacity_bytes(temp_dir)
        if _cap_b > 0:
            _free_basis = min(_free_basis, _cap_b)
        from_disk = int(_free_basis * max(0.0, min(1.0, free_disk_fraction)))
        # 2026-07-31 audit fix (F3) -- DIVIDE the disk share by the number of
        # children that will sample it CONCURRENTLY.
        #
        # Every child computes its quota independently from the SAME free-space
        # reading, so N workers each granted "50% of free" is a combined
        # promise of N x 50%.  That was tolerable when the absolute cap was a
        # hard 10 GB (4 x 10 = 40 GB); once the cap became memory-derived (up
        # to 90 GB) the disk ceiling is the load-bearing bound and it MUST
        # compose.  Concrete case from the audit: 4 workers on a 22.5 GB-memory
        # pod = up to 200% of free disk promised.
        try:
            _n = max(1, int(concurrent_children or 1))
        except (TypeError, ValueError):
            _n = 1
        # 2026-08-02 fleet-safety: the same reasoning applies ACROSS pods
        # when the spill dir is on a shared RWX volume — every pod samples
        # the same free number too.  pods x children is one combined
        # divisor.  Defaults to 1 (undeclared topology / pod-local spill),
        # keeping the single-pod answer byte-identical.
        _n *= spill_shared_pod_divisor(temp_dir)
        if _n > 1 and from_disk > 0:
            from_disk = from_disk // _n
        return min(from_disk, absolute) if from_disk > 0 else absolute
    except Exception as exc:
        logger.debug("BF-529 spill quota resolver failed: %s", exc)
        return 0
