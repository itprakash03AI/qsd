"""Feed templates -- authoring at scale (2026-10-10, the owner's ~4,000
monthly (SYSTEM_ENTITY, EventCode) feeds).

ONE template (``core/feed/feed_template.py``) + a matrix of parameter rows
-> N ``feed_configs`` rows, created and kept current THROUGH THE ordinary
authoring routes (``feed_api.create_feed`` / ``update_feed`` /
``replace_feed_dependencies`` called in-process, the way the version
restore calls the update), so every rule they enforce applies to a member
exactly as to a hand-authored feed.  Idempotent: a member is found by
(``template_id``, ``template_member_key``), compared and left alone /
updated / created; the report names every row's outcome (created /
updated / unchanged / conflict / refused / retired / orphaned) -- never one
aggregate "done".  A template edit (PUT) or a new matrix (apply)
propagates to every member.

Routes (any signed-in author may create; modifying, applying and deleting
a template is its creator's or an admin's):

    POST   /api/feed-templates                 create + apply (201)
    GET    /api/feed-templates                 list
    GET    /api/feed-templates/{id}            one, with member counts
    GET    /api/feed-templates/{id}/members    the members
    PUT    /api/feed-templates/{id}            edit + apply
    POST   /api/feed-templates/{id}/apply      (re)apply, optional new matrix
    DELETE /api/feed-templates/{id}            detach (default) or retire members
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field

from api.deps import get_current_user
from core.db_async import adb
from core.feed import feed_template as _ft

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/feed-templates", tags=["feed-templates"])

_db_manager: Any = None


def set_feed_template_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="feed templates not wired to a database")
    return _db_manager


def _feed_api():
    from api import feed_api
    return feed_api


# ── bodies ───────────────────────────────────────────────────────────────

class FeedTemplateCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    parameters: List[str]
    feed: Dict[str, Any]
    dependencies: List[Dict[str, Any]] = Field(default_factory=list)
    matrix: List[Dict[str, Any]] = Field(default_factory=list)
    #: 2026-10-11 -- a NEW system entity named by a COMPLETE message onboards
    #: itself from this template (core/feed/auto_onboard.py): {"match":
    #: {"DATA_SOURCE": ...}, "params": {PARAM: message field}, "events": [...]}
    auto_onboard: Optional[Dict[str, Any]] = None
    #: plan only: nothing is written, the report says what WOULD happen
    dry_run: bool = False
    #: a member whose row left the matrix is RETIRED (soft-deleted); the
    #: default leaves it alone and reports it ``orphaned``
    retire_missing: bool = False
    #: run the apply as a background JOB (202 + ``job``; poll
    #: ``GET /api/feed-templates/{id}/apply-status``).  None = the route
    #: decides: a matrix over ``SYNC_APPLY_MAX_ROWS`` rows goes to the
    #: background, a smaller one answers with the report inline.  A dry
    #: run is always inline.
    background: Optional[bool] = None


class FeedTemplateUpdate(BaseModel):
    description: Optional[str] = None
    parameters: Optional[List[str]] = None
    feed: Optional[Dict[str, Any]] = None
    dependencies: Optional[List[Dict[str, Any]]] = None
    matrix: Optional[List[Dict[str, Any]]] = None
    dry_run: bool = False
    retire_missing: bool = False
    background: Optional[bool] = None
    #: {} switches auto-onboarding OFF; omitted leaves it as it is
    auto_onboard: Optional[Dict[str, Any]] = None


class FeedTemplateApply(BaseModel):
    matrix: Optional[List[Dict[str, Any]]] = None
    dry_run: bool = False
    retire_missing: bool = False
    background: Optional[bool] = None


# ── guards ───────────────────────────────────────────────────────────────

def _checked_auto_onboard(declaration: Optional[Dict[str, Any]],
                          parameters: List[str]) -> Optional[Dict[str, Any]]:
    """The declaration as stored ({} / None -> None), or 422 naming the fault
    -- a declaration that cannot say where a parameter comes from would onboard
    nothing, silently."""
    if not declaration:
        return None
    from core.feed.auto_onboard import declaration_problem
    problem = declaration_problem({"auto_onboard": declaration, "parameters": parameters})
    if problem:
        raise HTTPException(status_code=422, detail=f"auto_onboard: {problem}")
    return dict(declaration)

def _may_manage(template: dict, user: dict) -> None:
    fa = _feed_api()
    if not fa._auth_on():
        return
    from core.roles import is_admin_like
    if is_admin_like(user):
        return
    if str(template.get("created_by") or "") == str(user.get("username") or ""):
        return
    raise HTTPException(status_code=403,
                        detail="only the template's creator or an admin may "
                               "change or apply it")


async def _require_template(template_id: int, user: dict, *, manage: bool) -> dict:
    row = await adb(_db().get_feed_template, int(template_id))
    if not row:
        raise HTTPException(status_code=404, detail=f"feed template {template_id} not found")
    if manage:
        _may_manage(row, user)
    return row


def _spec_of(row: dict) -> _ft.TemplateSpec:
    d = row.get("definition") or {}
    try:
        return _ft.parse_template(row.get("parameters"), d.get("feed"),
                                  d.get("dependencies"))
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _rows_of(spec: _ft.TemplateSpec, matrix: Any) -> List[Dict[str, str]]:
    try:
        return _ft.parse_matrix(spec, matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _hash(parameters, definition, matrix) -> str:
    from core.feed.pinning import definition_hash
    return definition_hash({"parameters": parameters, "definition": definition,
                            "matrix": matrix})


# ── the apply ────────────────────────────────────────────────────────────

def _entry(key: str, values: Dict[str, str], name: str, **extra) -> Dict[str, Any]:
    out = {"member_key": key, "values": values, "name": name}
    out.update(extra)
    return out


async def _declare_dependencies(fid: int, rendered: _ft.RenderedMember,
                                type_ids: Dict[str, int], user: dict) -> None:
    fa = _feed_api()
    rows = []
    for d in rendered.dependencies:
        d = dict(d)
        if d.get("dependency_type_id") is None:
            tname = str(d.pop("dependency_type", "") or "").upper()
            if tname not in type_ids:
                raise HTTPException(
                    status_code=422,
                    detail=f"dependency type {tname!r} is not in the catalogue "
                           f"({sorted(type_ids)})")
            d["dependency_type_id"] = type_ids[tname]
        else:
            d.pop("dependency_type", None)
        rows.append(fa.FeedDependencyRow(**d))
    await fa.replace_feed_dependencies(
        fid, fa.FeedDependenciesReplace(dependencies=rows), user)


async def _apply(template: dict, spec: _ft.TemplateSpec, rows: List[Dict[str, str]],
                 user: dict, *, dry_run: bool, retire_missing: bool) -> _ft.ApplyReport:
    """Apply the matrix under ONE snapshot of the estate (2026-10-10).

    Every member still goes through ``feed_api.create_feed`` / ``update_feed``
    / ``replace_feed_dependencies``, so every authoring rule holds -- but the
    two rules that need "every feed" (FR-ART-10 filename collision, FR-DEP-22
    dependency cycle) read ``core.feed.authoring_index.AuthoringIndex``,
    loaded here once (two queries) and kept current by the routes as each
    member lands, instead of listing the database per member.  That listing
    made the apply quadratic: 0.56 s/feed at N=50, 0.98 s/feed at N=400,
    ~3 h for the owner's 4,000 -- found live.  A collision between two
    members of the SAME matrix is still refused (member 2 against member 1,
    which the index already holds).  A dry run writes nothing and so needs
    no snapshot.
    """
    if dry_run:
        return await _apply_members(template, spec, rows, user, dry_run=True,
                                    retire_missing=retire_missing)
    return await _under_snapshot(
        lambda on_progress: _apply_members(template, spec, rows, user, dry_run=False,
                                           retire_missing=retire_missing,
                                           on_progress=on_progress))


async def _under_snapshot(run: Callable[[Any], Awaitable[Any]],
                          on_progress: Any = None) -> Any:
    """Run ``run(on_progress)`` with ONE ``AuthoringIndex`` in force for
    the duration (``feed_api._authoring_index``), loaded here (two queries)."""
    fa = _feed_api()
    from core.feed.authoring_index import AuthoringIndex
    index = await adb(AuthoringIndex.load, _db())
    token = fa._authoring_index.set(index)
    try:
        return await run(on_progress)
    finally:
        fa._authoring_index.reset(token)


# ── the apply as a JOB (2026-10-10, later) ───────────────────────────────

def _owner_id() -> str:
    return f"{socket.gethostname()}:{os.getpid()}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


#: the background tasks this process is running (a reference keeps them alive)
_background_tasks: set = set()


def _background_default(rows: List[Any], requested: Optional[bool]) -> bool:
    """The route's decision when the body does not say: a matrix over
    ``SYNC_APPLY_MAX_ROWS`` rows is applied in the background."""
    if requested is not None:
        return bool(requested)
    return len(rows) > _ft.SYNC_APPLY_MAX_ROWS


async def _claim_apply_job(template: dict, rows: List[Any], user: dict, *,
                           background: bool) -> Dict[str, Any]:
    """ONE apply at a time per template.  A live job (fresh heartbeat) is a
    409 naming it; a dead owner's job (stale heartbeat) is superseded.  The
    claim itself is the compare-and-swap on ``feed_templates.apply_job_id``,
    so two requests racing here get exactly one claim."""
    db = _db()
    now = _now()
    live = _ft.apply_job_view(template.get("apply_status"), now=now)
    if live and live["state"] in _ft.JOB_LIVE_STATES:
        raise HTTPException(
            status_code=409,
            detail=f"template {template['name']!r} is being applied already "
                   f"(job {live['job_id']}, {live.get('done', 0)}/{live.get('total')} "
                   f"members, started {live.get('started_at')} by {live.get('by')}); "
                   f"poll GET /api/feed-templates/{template['id']}/apply-status "
                   f"and apply again when it has finished")
    job_id = uuid.uuid4().hex
    claimed = await adb(db.claim_feed_template_apply, int(template["id"]), job_id,
                        template.get("apply_job_id"))
    if not claimed:
        raise HTTPException(
            status_code=409,
            detail=f"template {template['name']!r} was claimed by another apply "
                   f"a moment ago; poll GET /api/feed-templates/{template['id']}"
                   f"/apply-status")
    job = _ft.new_apply_job(job_id, total=len(rows), by=user.get("username"),
                            owner=_owner_id(), background=background, now=now)
    await adb(db.set_feed_template_apply_status, int(template["id"]), job_id, job)
    return job


async def _run_apply_job(template: dict, spec: _ft.TemplateSpec, rows: List[Dict[str, str]],
                         user: dict, job: Dict[str, Any], *, retire_missing: bool
                         ) -> _ft.ApplyReport:
    """The claimed job: the SAME ``_apply_members`` pass, under one snapshot,
    with progress + heartbeat written to the row every
    ``APPLY_PROGRESS_EVERY_SECONDS`` and the report written when done."""
    db = _db()
    tid, job_id = int(template["id"]), job["job_id"]
    last_write = [time.monotonic()]

    async def _write() -> None:
        job["heartbeat_at"] = _now().isoformat()
        await adb(db.set_feed_template_apply_status, tid, job_id, job)
        last_write[0] = time.monotonic()

    async def on_progress(done: int, report: _ft.ApplyReport) -> None:
        if time.monotonic() - last_write[0] >= _ft.APPLY_PROGRESS_EVERY_SECONDS:
            job["done"] = int(done)
            job["counts"] = report.to_dict()["counts"]
            await _write()

    job["state"] = _ft.JOB_RUNNING
    await _write()
    try:
        report = await _under_snapshot(
            lambda cb: _apply_members(template, spec, rows, user, dry_run=False,
                                      retire_missing=retire_missing, on_progress=cb),
            on_progress)
    except Exception as exc:  # noqa: BLE001 -- recorded on the job, then re-raised
        job.update(state=_ft.JOB_FAILED, finished_at=_now().isoformat(),
                   error=f"{type(exc).__name__}: {exc}"[:2000])
        await _write()
        raise
    rep = report.to_dict()
    job.update(state=_ft.JOB_COMPLETED, done=len(rows), counts=rep["counts"],
               finished_at=_now().isoformat(), report=rep)
    await _write()
    return report


async def _apply_or_schedule(template: dict, spec: _ft.TemplateSpec,
                             rows: List[Dict[str, str]], user: dict, *,
                             dry_run: bool, retire_missing: bool,
                             background: Optional[bool]) -> Dict[str, Any]:
    """What a route answers: ``{"report": ...}`` for an inline apply (and
    every dry run), ``{"job": ..., "report": None}`` for a background one
    (the caller answers 202 and the client polls)."""
    if dry_run:
        report = await _apply(template, spec, rows, user, dry_run=True,
                              retire_missing=retire_missing)
        return {"report": report.to_dict(), "job": None}
    bg = _background_default(rows, background)
    job = await _claim_apply_job(template, rows, user, background=bg)
    if not bg:
        report = await _run_apply_job(template, spec, rows, user, job,
                                      retire_missing=retire_missing)
        return {"report": report.to_dict(),
                "job": {k: v for k, v in job.items() if k != "report"}}

    async def _runner() -> None:
        try:
            await _run_apply_job(template, spec, rows, user, job,
                                 retire_missing=retire_missing)
        except Exception:  # noqa: BLE001 -- the job row carries it
            logger.exception("[feed_template] background apply of %s (job %s) failed",
                             template.get("name"), job["job_id"])

    task = asyncio.create_task(_runner(), name=f"feed-template-apply-{job['job_id']}")
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)
    logger.info("[feed_template] %s: %d rows applied in the BACKGROUND (job %s) by %s",
                template.get("name"), len(rows), job["job_id"], user.get("username"))
    return {"report": None, "job": dict(job)}


def _job_status(row: dict) -> Optional[Dict[str, Any]]:
    return _ft.apply_job_view(row.get("apply_status"), now=_now())


def _member_group_id(db, gname: str, cache: dict, user: dict, dry_run: bool) -> Optional[int]:
    """The Feed Group a member's rendered group rule names: an existing group
    (active or not -- the operator's state stands), else created ONCE per
    apply.  A dry run creates nothing (None: the plan does not set it)."""
    if gname in cache:
        return cache[gname]
    if not gname or len(gname) > 100:
        raise ValueError(f"group rule rendered {gname!r}: a Feed Group name must be "
                         f"1-100 characters")
    g = db.get_feed_group_by_name(gname)
    if g is None and not dry_run:
        try:
            g = db.create_feed_group({"name": gname, "display_label": gname,
                                      "description": "created by a feed template's group rule",
                                      "created_by": (user or {}).get("username")})
        except Exception:                               # noqa: BLE001 -- a racing apply made it
            g = db.get_feed_group_by_name(gname)
    cache[gname] = int(g["id"]) if g else None
    return cache[gname]


async def _apply_members(template: dict, spec: _ft.TemplateSpec,
                         rows: List[Dict[str, str]], user: dict, *,
                         dry_run: bool, retire_missing: bool,
                         on_progress: Optional[Callable[[int, _ft.ApplyReport],
                                                        Awaitable[None]]] = None
                         ) -> _ft.ApplyReport:
    fa = _feed_api()
    db = _db()
    t0 = time.monotonic()
    report = _ft.ApplyReport(template_id=template["id"], dry_run=dry_run)
    types = await adb(db.list_etl_dependency_types, None)
    type_ids = {str(t["dependency_type"]).upper(): int(t["id"]) for t in types}
    members = ({} if template.get("id") is None else
               {m["template_member_key"]: m
                for m in (await adb(db.list_template_members, template["id"]))})
    seen_keys = set()

    groups: Dict[str, Optional[int]] = {}
    for done, values in enumerate(rows):
        if on_progress is not None and done:
            await on_progress(done, report)
        rendered = _ft.render_member(spec, values)
        key, name = rendered.member_key, rendered.name
        seen_keys.add(key)
        stored = members.get(key)
        # 2026-10-12 (owner R1) -- the group RULE: the rendered name is a
        # DEFINED Feed Group (created on first use); the member stores its id.
        gname = rendered.feed.pop(_ft.FEED_GROUP_RULE_FIELD, None)
        if gname is not None:
            try:
                gid = await adb(_member_group_id, db, str(gname).strip(), groups,
                                user, dry_run)
            except ValueError as exc:
                report.refused.append(_entry(key, values, name, status=422, reason=str(exc)))
                continue
            if gid is not None:
                rendered.feed["feed_group_id"] = gid
        if stored is None:
            dup = await adb(db.get_feed_ids_by_name, name)
            if dup:
                report.conflicts.append(_entry(
                    key, values, name, feed_id=dup[0],
                    reason=f"feed {name!r} already exists (id {dup[0]}) and is "
                           f"not a member of this template; rename it or the "
                           f"template -- nothing is adopted silently"))
                continue
            if dry_run:
                report.created.append(_entry(key, values, name, planned=True))
                continue
            try:
                created = await fa.create_feed(fa.FeedConfigCreate(**rendered.feed), user)
            except HTTPException as exc:
                report.refused.append(_entry(key, values, name, status=exc.status_code,
                                             reason=str(exc.detail)[:1000]))
                continue
            except Exception as exc:  # noqa: BLE001 -- a pydantic shape error is a per-row refusal
                report.refused.append(_entry(key, values, name, status=422,
                                             reason=f"{type(exc).__name__}: {exc}"[:1000]))
                continue
            fid = int(created["id"])
            await adb(db.stamp_template_member, fid, int(template["id"]), key)
            try:
                await _declare_dependencies(fid, rendered, type_ids, user)
            except HTTPException as exc:
                # keep the apply atomic per member: a feed without its gate
                # is not a member, it is a feed that would run ungated.
                await adb(db.deactivate_feed_config, fid)
                await adb(db.stamp_template_member, fid, None, None)
                report.refused.append(_entry(
                    key, values, name, status=exc.status_code,
                    reason=f"dependencies refused, member retired again: "
                           f"{exc.detail}"[:1000]))
                continue
            report.created.append(_entry(key, values, name, feed_id=fid))
            continue

        fid = int(stored["id"])
        changes = _ft.changed_fields(stored, rendered.feed)
        if not stored.get("is_active", True):
            changes["is_active"] = True
        etl_id = fa._resolve_etl_id_for_feed(stored)
        current_deps = await adb(db.list_etl_dependency_mappings, etl_id)
        deps_changed = _ft.dependencies_differ(current_deps, rendered.dependencies, type_ids)
        if not changes and not deps_changed:
            report.unchanged.append(_entry(key, values, name, feed_id=fid))
            continue
        if dry_run:
            report.updated.append(_entry(key, values, name, feed_id=fid, planned=True,
                                         fields=sorted(changes),
                                         dependencies=deps_changed))
            continue
        try:
            if changes:
                await fa.update_feed(fid, fa.FeedConfigUpdate(**changes), user)
            if deps_changed:
                await _declare_dependencies(fid, rendered, type_ids, user)
        except HTTPException as exc:
            report.refused.append(_entry(key, values, name, feed_id=fid,
                                         status=exc.status_code,
                                         reason=str(exc.detail)[:1000]))
            continue
        except Exception as exc:  # noqa: BLE001
            report.refused.append(_entry(key, values, name, feed_id=fid, status=422,
                                         reason=f"{type(exc).__name__}: {exc}"[:1000]))
            continue
        report.updated.append(_entry(key, values, name, feed_id=fid,
                                     fields=sorted(changes), dependencies=deps_changed))
    if on_progress is not None and rows:
        await on_progress(len(rows), report)

    for key, m in members.items():
        if key in seen_keys or not m.get("is_active", True):
            continue
        entry = _entry(key, {}, m["name"], feed_id=int(m["id"]))
        if not retire_missing:
            report.orphaned.append(entry)
            continue
        if dry_run:
            entry["planned"] = True
            report.retired.append(entry)
            continue
        try:
            await fa.delete_feed(int(m["id"]), True, user)
            report.retired.append(entry)
        except HTTPException as exc:
            entry.update(status=exc.status_code, reason=str(exc.detail)[:1000])
            report.refused.append(entry)

    report.seconds = time.monotonic() - t0
    if not dry_run:
        await adb(db.update_feed_template, template["id"], {
            "last_applied_at": datetime.now(timezone.utc),
            "last_apply_report": {"counts": report.to_dict()["counts"],
                                  "seconds": round(report.seconds, 3),
                                  "by": user.get("username")},
        })
    logger.info("[feed_template] %s applied by %s: %s in %.1fs%s", template["name"],
                user.get("username"), report.to_dict()["counts"], report.seconds,
                " (dry run)" if dry_run else "")
    return report


# ── routes ───────────────────────────────────────────────────────────────

@router.post("", status_code=201)
async def create_feed_template(body: FeedTemplateCreate, response: Response,
                               user: dict = Depends(get_current_user)):
    """Create + apply.  201 with the report; 202 with ``job`` when the apply
    runs in the background (``background: true``, or a matrix over
    ``SYNC_APPLY_MAX_ROWS`` rows) -- poll ``GET .../{id}/apply-status``."""
    db = _db()
    try:
        spec = _ft.parse_template(body.parameters, body.feed, body.dependencies)
        rows = _ft.parse_matrix(spec, body.matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if await adb(db.get_feed_template_by_name, body.name):
        raise HTTPException(status_code=409,
                            detail=f"feed template {body.name!r} already exists; "
                                   f"PUT or apply it instead")
    definition = spec.to_definition()
    data = {"name": body.name.strip(), "description": body.description,
            "parameters": spec.parameters, "definition": definition,
            "matrix": rows, "definition_hash": _hash(spec.parameters, definition, rows),
            "created_by": user.get("username", "unknown"), "is_active": True,
            "auto_onboard": _checked_auto_onboard(body.auto_onboard, spec.parameters)}
    if body.dry_run:
        template = dict(data, id=None)
        report = await _apply(template, spec, rows, user, dry_run=True,
                              retire_missing=body.retire_missing)
        return {"template": None, "report": report.to_dict(), "job": None}
    template = await adb(db.create_feed_template, data)
    outcome = await _apply_or_schedule(template, spec, rows, user, dry_run=False,
                                       retire_missing=body.retire_missing,
                                       background=body.background)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template": await adb(db.get_feed_template, template["id"]),
            "report": outcome["report"], "job": outcome["job"]}


@router.get("/onboarding")
async def list_onboarding_requests(status: Optional[str] = Query(None),
                                   limit: Optional[int] = Query(None, ge=1, le=5000),
                                   page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                                   user: dict = Depends(get_current_user)):
    """2026-10-11 -- every NEW system entity a COMPLETE message named and what
    became of it (pending / onboarded / refused / failed), newest first, with
    the feed it became and what SOD did for its business date
    (core/feed/auto_onboard.py).  PAGED (2026-10-12, core/feed/paging.py):
    the counts are over every request, never the page's."""
    from core.feed.paging import block, paging
    p = paging(page, limit if limit is not None else page_size)
    rows = await adb(_db().list_onboarding_requests, status, p.page_size, p.offset)
    counts = await adb(_db().onboarding_request_counts)
    total = counts.get(status, 0) if status else sum(counts.values())
    return {"requests": rows, "counts": counts, "paging": block(total, p, len(rows))}


@router.get("")
async def list_feed_templates(user: dict = Depends(get_current_user)):
    db = _db()
    out = []
    for t in await adb(db.list_feed_templates):
        members = await adb(db.list_template_members, t["id"])
        t = dict(t)
        t.pop("definition", None)
        t["matrix_rows"] = len(t.pop("matrix", []) or [])
        t["members"] = len(members)
        t["active_members"] = sum(1 for m in members if m.get("is_active", True))
        out.append(t)
    return {"items": out, "count": len(out)}


@router.get("/{template_id}")
async def get_feed_template(template_id: int, user: dict = Depends(get_current_user)):
    row = await _require_template(template_id, user, manage=False)
    members = await adb(_db().list_template_members, row["id"])
    row = dict(row)
    row["members"] = len(members)
    row["active_members"] = sum(1 for m in members if m.get("is_active", True))
    row["definition"] = {"feed": _feed_api()._mask_feed_secrets(
        dict((row.get("definition") or {}).get("feed") or {})),
        "dependencies": (row.get("definition") or {}).get("dependencies") or []}
    row["apply_status"] = _job_status(row)
    return row


@router.get("/{template_id}/apply-status")
async def get_feed_template_apply_status(template_id: int,
                                         user: dict = Depends(get_current_user)):
    """The current / last apply as a JOB: state (queued / running /
    completed / failed), done / total, counts so far, heartbeat, and the
    full report once completed -- read from the template row, so any pod
    answers.  A running job whose owner stopped (stale heartbeat) is
    reported ``failed`` with the reason, never in flight for ever.
    ``job`` is null for a template never applied."""
    row = await _require_template(template_id, user, manage=False)
    return {"template_id": row["id"], "job": _job_status(row)}


@router.get("/{template_id}/members")
async def list_feed_template_members(template_id: int,
                                     user: dict = Depends(get_current_user)):
    row = await _require_template(template_id, user, manage=False)
    members = await adb(_db().list_template_members, row["id"])
    return {"template_id": row["id"], "count": len(members),
            "items": [{"id": m["id"], "name": m["name"],
                       "member_key": m["template_member_key"],
                       "is_active": m.get("is_active", True),
                       "schedule_enabled": m.get("schedule_enabled")} for m in members]}


@router.put("/{template_id}")
async def update_feed_template(template_id: int, body: FeedTemplateUpdate,
                               response: Response,
                               user: dict = Depends(get_current_user)):
    db = _db()
    row = await _require_template(template_id, user, manage=True)
    d = row.get("definition") or {}
    parameters = body.parameters if body.parameters is not None else row.get("parameters")
    feed = body.feed if body.feed is not None else d.get("feed")
    dependencies = (body.dependencies if body.dependencies is not None
                    else d.get("dependencies"))
    matrix = body.matrix if body.matrix is not None else row.get("matrix")
    try:
        spec = _ft.parse_template(parameters, feed, dependencies)
        rows = _ft.parse_matrix(spec, matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    definition = spec.to_definition()
    if body.dry_run:
        probe = dict(row, parameters=spec.parameters, definition=definition, matrix=rows)
        report = await _apply(probe, spec, rows, user, dry_run=True,
                              retire_missing=body.retire_missing)
        return {"template": row, "report": report.to_dict()}
    updated = await adb(db.update_feed_template, row["id"], {
        "description": body.description if body.description is not None else row.get("description"),
        "parameters": spec.parameters, "definition": definition, "matrix": rows,
        "definition_hash": _hash(spec.parameters, definition, rows),
        "auto_onboard": (_checked_auto_onboard(body.auto_onboard, spec.parameters)
                         if body.auto_onboard is not None else row.get("auto_onboard"))})
    outcome = await _apply_or_schedule(updated, spec, rows, user, dry_run=False,
                                       retire_missing=body.retire_missing,
                                       background=body.background)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template": await adb(db.get_feed_template, row["id"]),
            "report": outcome["report"], "job": outcome["job"]}


@router.post("/{template_id}/apply")
async def apply_feed_template(template_id: int, response: Response,
                              body: Optional[FeedTemplateApply] = None,
                              user: dict = Depends(get_current_user)):
    db = _db()
    body = body or FeedTemplateApply()
    row = await _require_template(template_id, user, manage=True)
    spec = _spec_of(row)
    matrix = body.matrix if body.matrix is not None else row.get("matrix")
    rows = _rows_of(spec, matrix)
    if body.matrix is not None and not body.dry_run:
        row = await adb(db.update_feed_template, row["id"], {
            "matrix": rows,
            "definition_hash": _hash(spec.parameters, row.get("definition"), rows)})
    outcome = await _apply_or_schedule(row, spec, rows, user, dry_run=body.dry_run,
                                       retire_missing=body.retire_missing,
                                       background=body.background)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template_id": row["id"], "report": outcome["report"], "job": outcome["job"]}


@router.delete("/{template_id}")
async def delete_feed_template(template_id: int,
                               delete_members: bool = Query(default=False),
                               user: dict = Depends(get_current_user)):
    """Remove the template.  ``delete_members=true`` RETIRES every member
    (the ordinary soft delete, dependents acknowledged); the default only
    DETACHES them -- they stay as ordinary feeds, no longer managed."""
    db = _db()
    row = await _require_template(template_id, user, manage=True)
    members = await adb(db.list_template_members, row["id"])
    retired, failed = [], []
    if delete_members:
        fa = _feed_api()

        async def _retire_all(_cb) -> None:
            # under ONE snapshot: delete_feed's downstream check used to
            # list every feed and query each one's mappings per member
            for m in members:
                try:
                    if m.get("is_active", True):
                        await fa.delete_feed(int(m["id"]), True, user)
                    retired.append(int(m["id"]))
                except HTTPException as exc:
                    failed.append({"feed_id": int(m["id"]), "status": exc.status_code,
                                   "reason": str(exc.detail)[:500]})
        await _under_snapshot(_retire_all)
    detached = await adb(db.detach_template_members, row["id"])
    await adb(db.delete_feed_template, row["id"])
    return {"deleted": row["id"], "members": len(members), "retired": retired,
            "detached": detached, "failed": failed}
