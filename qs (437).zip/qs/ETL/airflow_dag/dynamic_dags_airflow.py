import sys
import oracledb
import yaml
import logging
from typing import List, Dict, Optional
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.models.param import Param
from airflow.models import Variable
from datetime import datetime, timedelta


# ═══════════════════════════════════════════════════════════════════════
#  SafeSparkSubmitOperator
# ═══════════════════════════════════════════════════════════════════════
#
# 2026-07-01 prod incident: Airflow's stock ``SparkSubmitHook`` builds
# the spark-submit CLI as a Python list, then does
# ``" ".join(connection_cmd)`` inside ``_mask_cmd`` for logging.  If
# ANY element of that list is not a ``str`` (e.g. the Airflow
# connection ``spark_on_prem`` has ``num-executors: 5`` in its extras
# JSON, which lands as ``int`` in the hook's ``self._num_executors``),
# the join raises ``TypeError: sequence item N: expected str
# instance, int found`` -- BEFORE spark-submit even fires.
#
# The stock hook has this bug in every provider version we've seen:
# it appends ``[flag, self._numeric_field]`` without ``str()``.  The
# leaky fields include (but are not limited to):
#   * num_executors            (--num-executors)
#   * executor_cores           (--executor-cores)
#   * total_executor_cores     (--total-executor-cores)
#   * driver_cores             (--driver-cores)
#
# Fix strategy: subclass the operator and intercept the built command
# just before submit.  Force-str every element; also EMIT one WARNING
# log line naming the exact index + field so ops can fix the root
# cause in the Airflow connection instead of relying on the wrapper
# forever.  Fail-open: on any wrapper error, fall through to the
# stock operator (which will fail loud with the original TypeError
# -- same outcome as today).


def _coerce_cmd_to_str_list(cmd):
    """Return a copy of ``cmd`` where every element is guaranteed
    ``str``.  ``None`` -> ``""``.  Anything that can't be str()-ified
    (rare -- would require a __str__ that raises) is replaced with
    its repr() so we don't crash the coercer itself.

    Extracted as a plain function so it can be unit-tested WITHOUT
    Airflow installed.
    """
    out = []
    for x in cmd:
        if isinstance(x, str):
            out.append(x)
        elif x is None:
            out.append("")
        else:
            try:
                out.append(str(x))
            except Exception:
                try:
                    out.append(repr(x))
                except Exception:
                    out.append("<unstringifiable>")
    return out


class SafeSparkSubmitOperator(SparkSubmitOperator):
    """Drop-in for ``SparkSubmitOperator`` that force-coerces every
    element of the spark-submit CLI to ``str`` so ``" ".join(cmd)``
    inside ``SparkSubmitHook._mask_cmd`` cannot blow up when a
    connection extras field lands as ``int`` (a stock provider bug
    across every version we've seen).

    Hardening properties (never fails in a NEW way):
      * The wrapper is FAIL-OPEN: if any line inside the wrapper
        raises (e.g. attribute access on a version-specific hook
        internal), we log-debug and fall through to the stock
        method.  Worst case is the same failure operators see today.
      * Attribute access uses ``getattr(..., default)`` for
        ``conn_id`` (2.7+) vs ``_conn_id`` (<=2.6) so the warning
        log survives every provider version.
      * Wrapper is fully idempotent -- patching the same class twice
        with the same wrapper is a no-op (patched marker check).
      * Restoration in ``finally:`` even if super().execute() raises.
    """

    _WRAPPER_MARKER = "_qs_safe_spark_wrapper"

    def execute(self, context):
        # Lazy import so this DAG file still parses when the Spark
        # provider isn't installed (dev boxes / smoke tests).
        try:
            from airflow.providers.apache.spark.hooks.spark_submit import (
                SparkSubmitHook,
            )
        except Exception as _imp_exc:  # pragma: no cover
            # Fail-open: provider missing → fall through to stock,
            # which will raise a cleaner error immediately.
            self.log.debug(
                "SafeSparkSubmitOperator: SparkSubmitHook import failed "
                "(%s); using stock SparkSubmitOperator.execute", _imp_exc,
            )
            return super().execute(context)

        original = SparkSubmitHook._build_spark_submit_command

        # Idempotency guard: if another SafeSparkSubmitOperator
        # instance in the same process already patched, don't
        # double-wrap.
        if getattr(original, self._WRAPPER_MARKER, False):
            return super().execute(context)

        conn_id_str = str(
            getattr(self, "conn_id", None)
            or getattr(self, "_conn_id", None)
            or "unknown"
        )
        log = self.log

        def _safe_build(hook_self, application):
            try:
                cmd = original(hook_self, application)
            except Exception:
                # Stock method exploded -- nothing we can do; let it
                # propagate so the task fails with the actual reason.
                raise
            try:
                coerced = _coerce_cmd_to_str_list(cmd)
            except Exception as _coerce_exc:
                # Coercer itself failed -- extremely unlikely given
                # the fallbacks inside _coerce_cmd_to_str_list.  Log
                # debug + return original list; " ".join() will fail
                # loudly with the SAME TypeError operators see today.
                log.debug(
                    "SafeSparkSubmitOperator: coercer failed (%s); "
                    "returning original cmd unchanged", _coerce_exc,
                )
                return cmd
            # Report any indices that were coerced so ops fix the
            # root cause (Airflow connection extras JSON) rather
            # than relying on this wrapper forever.
            try:
                offenders = [
                    (i, type(x).__name__, repr(x))
                    for i, x in enumerate(cmd)
                    if not isinstance(x, str)
                ]
                if offenders:
                    log.warning(
                        "SafeSparkSubmitOperator: connection %s "
                        "produced %d non-str element(s) in the "
                        "spark-submit cmd: %s. Coerced to str so "
                        "' '.join() succeeds.  ACTION: fix the "
                        "connection extras JSON so the offending "
                        "field is a string (e.g. num-executors: "
                        "\"5\" not num-executors: 5), then this "
                        "wrapper becomes a silent no-op.",
                        conn_id_str, len(offenders), offenders,
                    )
            except Exception as _log_exc:  # pragma: no cover
                # Never let logging failures break the task.
                log.debug(
                    "SafeSparkSubmitOperator: offender-log failed "
                    "(%s)", _log_exc,
                )
            return coerced

        # Tag the wrapper so a nested call recognizes it.
        setattr(_safe_build, SafeSparkSubmitOperator._WRAPPER_MARKER, True)

        SparkSubmitHook._build_spark_submit_command = _safe_build
        try:
            return super().execute(context)
        finally:
            # Always restore so the patch cannot leak across tasks
            # running in the same worker process (LocalExecutor).
            try:
                SparkSubmitHook._build_spark_submit_command = original
            except Exception as _restore_exc:  # pragma: no cover
                self.log.debug(
                    "SafeSparkSubmitOperator: restore failed (%s)",
                    _restore_exc,
                )


# qs_credentials package + oracle_config.yaml both live on the shared PVC.  Same
# root that the prewarm DAG + SOD DAG use (confirmed working in prod).
# Both PVCs mount on every relevant pod (Airflow + Spark).  Single
# source of truth for code + configs + cache lives on the SPARK PVC --
# Airflow tasks AND Spark workflows hit the SAME files.  DAGs
# themselves still live on /usr/local/airflow/pvc/dags/ (different
# concern: Airflow's dags_folder).
_PVC_CODE_ROOT      = "/usr/local/spark/pvc/code"
_ORACLE_CONFIG_PATH = f"{_PVC_CODE_ROOT}/configs/oracle_config.yaml"


# 2026-07-01 hotfix -- log handler NOW writes to NFS
# (/usr/local/spark/nfs/bcp/batch/logs/dag/) instead of the shared
# PVC.  PVC has a 2 GB quota that a chatty parse cycle filled
# within hours; NFS is the persistent shared filesystem already
# mounted for ETL bulk output + polling logs.  Module name is
# preserved (pvc_log) for back-compat; the substance is NFS.
if _PVC_CODE_ROOT not in sys.path:
    sys.path.insert(0, _PVC_CODE_ROOT)
try:
    from qs_credentials.pvc_log import setup_pvc_logging
    setup_pvc_logging("dag_generation")
except Exception as _pvc_log_exc:  # noqa: BLE001
    logging.getLogger(__name__).warning(
        "Shared NFS log handler not attached (%s) -- Airflow's own "
        "task log path still captures task output", _pvc_log_exc,
    )


def _ensure_pvc_on_path() -> None:
    """Add the shared PVC code root to sys.path so qs_credentials +
    oracle_config_loader resolve.  Idempotent."""
    if _PVC_CODE_ROOT not in sys.path:
        sys.path.insert(0, _PVC_CODE_ROOT)


# 2026-07-01 -- removed ``update_connection_string`` and
# ``_get_etl_creds``.  Both are dead after ``modify_db_config`` was
# refactored to delegate DSN resolution to the canonical
# ``oracle_config_loader.resolve_etl_connection_string`` chokepoint,
# which internally handles vault / structured / literal / env-var
# resolution in the correct order (including the a3a2c5f mixed-
# posture vault_enabled fix).  Keeping shadow copies of the same
# logic in this file just guarantees drift between the DAG and the
# rest of the ETL codebase.


# Helper function to return the runtime instance of oracledb config with updated username password
def modify_db_config(yaml_file: str = _ORACLE_CONFIG_PATH) -> Dict:
    """Load ``oracle_config.yaml``, resolve credentials, and return an
    oracle config dict where ``etl_connection_string`` is guaranteed
    to carry the resolved user + password inline.

    2026-07-01 fix: previously this function ASSUMED
    ``etl_connection_string`` was already populated AND already
    contained ``User Id=``/``Password=`` markers to regex-replace.
    That silently broke when operators used the STRUCTURED shape
    (host/port/service + oracle.etl.username/password) with the
    connection string field left blank.  Also, ``secret_ref`` was
    read from the WRONG yaml path (``oracle.secret_ref`` instead
    of ``oracle.etl.secret_ref``) so operator overrides never
    took effect.

    New flow:
      1. Delegate the full DSN resolution to the canonical
         ``oracle_config_loader.resolve_etl_connection_string``
         chokepoint, which handles ALL four layers correctly
         (literal / structured / vault / env var) AND is aware
         of the mixed-posture vault_enabled toggle (2026-07-01
         resolver fix in a3a2c5f).
      2. If the resolver returns a string without User Id/Password
         markers (structured-shape yaml), fetch creds via the
         resolver and inject them via
         ``update_connection_string`` (which now APPENDS when the
         markers are absent -- another 2026-07-01 fix).

    The result is a connection string with creds inline, ready for
    ``parse_oracle_connection_string`` downstream.
    """
    try:
        _ensure_pvc_on_path()
        logging.debug(
            "[dag_generation] modify_db_config: reading yaml at %s",
            yaml_file,
        )
        with open(yaml_file, 'r') as file:
            config = yaml.safe_load(file) or {}
        oracle_config = config.get('oracle', {}) or {}
        if not oracle_config:
            raise ValueError("Oracle configuration not found in oracle_config.yaml")

        # Log which yaml layers HAVE content so ops can spot config
        # drift without opening a shell on the pod.  We do NOT log
        # user / password values -- only the presence of each key.
        # 2026-07-01 hotfix -- yaml-shape breakdown downgraded to
        # DEBUG.  Emitted once per parse cycle; useful for one-shot
        # ops debugging but not for continuous INFO volume.
        _etl_section = oracle_config.get("etl", {}) or {}
        _dest_section = oracle_config.get("destination", {}) or {}
        logging.debug(
            "[dag_generation] yaml shape: "
            "vault_enabled=%r  etl_connection_string=%s  "
            "etl.host=%s  etl.username=%s  etl.secret_ref=%s  "
            "dest_connection_string=%s  dest.host=%s  "
            "dest.username=%s  dest.secret_ref=%s",
            oracle_config.get("vault_enabled"),
            "SET" if oracle_config.get("etl_connection_string") else "blank",
            "SET" if _etl_section.get("host") else "blank",
            "SET" if _etl_section.get("username") else "blank",
            "SET" if _etl_section.get("secret_ref") else "blank",
            "SET" if oracle_config.get("dest_connection_string") else "blank",
            "SET" if _dest_section.get("host") else "blank",
            "SET" if _dest_section.get("username") else "blank",
            "SET" if _dest_section.get("secret_ref") else "blank",
        )

        # Delegate DSN resolution to the canonical chokepoint.  Handles
        # literal / structured / vault / env-var in the correct order.
        from oracle_config_loader import resolve_etl_connection_string
        etl_conn_str = (resolve_etl_connection_string(config) or "").strip()

        if not etl_conn_str:
            logging.error(
                "[dag_generation] resolve_etl_connection_string returned "
                "empty -- no config layer produced creds"
            )
            raise ValueError(
                "Oracle ETL connection string could not be resolved from "
                f"{yaml_file}.  Fill one of: "
                "(a) oracle.etl_connection_string literal (OLEDB / Easy Connect), "
                "(b) oracle.etl.{host,port,service,username,password} structured, "
                "(c) oracle.etl.secret_ref + ETL_USE_VAULT=1 for vault, "
                "or (d) ETL_ORACLE_CONN env var."
            )

        # Log the SHAPE of the resolved string (OLEDB vs Easy Connect)
        # so operators can confirm which resolution path fired.  We
        # log the descriptor prefix + host visible in the DSN but NOT
        # the User Id / Password trailer.
        _shape = "OLEDB" if etl_conn_str.lstrip().startswith("(") else "EasyConnect"
        _safe_preview = etl_conn_str[:80].replace("Password=", "Password=***")
        # 2026-07-01 hotfix -- DEBUG (per-parse cycle noise).
        logging.debug(
            "[dag_generation] resolved DSN shape=%s len=%d preview=%r",
            _shape, len(etl_conn_str), _safe_preview,
        )

        # If the resolved string already contains ``User Id=X`` /
        # ``Password=Y`` (came from an OLEDB literal or vault-resolved
        # path), leave it alone -- parse_oracle_connection_string
        # downstream will pick up the creds.  If it's a bare descriptor
        # or an Easy Connect ``user/pw@host:port/svc`` shape, both are
        # parseable AS-IS by parse_oracle_connection_string, so no
        # further mutation needed here.
        oracle_config['etl_connection_string'] = etl_conn_str
        return oracle_config
    except Exception as e:
        logging.error(
            "[dag_generation] modify_db_config FAILED for %s: %s",
            yaml_file, e, exc_info=True,
        )
        raise


def parse_oracle_connection_string(conn_str: str):
    """Parse the (now vault-credential-filled) connection string into
    (dsn, user, password).  Delegates to the canonical ETL parser
    which handles BOTH Easy Connect ('user/pwd@host:port/svc') AND
    OLEDB ('(DESCRIPTION=...); User Id = u; Password = p') shapes,
    with or without whitespace around `=` and with or without a
    trailing `;`.  The old local regex was strict about all three."""
    _ensure_pvc_on_path()
    from oracle_config_loader import (
        parse_oracle_connection_string as _canonical_parse,
    )
    parsed = _canonical_parse(conn_str)
    dsn = (parsed.get("dsn") or "").strip()
    user = (parsed.get("user") or "").strip()
    password = (parsed.get("password") or "").strip()
    if not dsn or not user or not password:
        raise ValueError(
            "Connection string parsed incomplete  "
            f"dsn={bool(dsn)} user={bool(user)} password={bool(password)}"
        )
    return dsn, user, password


def load_db_config(yaml_file: str = _ORACLE_CONFIG_PATH):
    try:
        oracle_cfg = modify_db_config(yaml_file)
        conn_str = oracle_cfg['etl_connection_string']
        dsn, user, password = parse_oracle_connection_string(conn_str)
        return dsn, user, password
    except Exception as e:
        logging.error(f"Error loading oracle_config.yaml: {e}", exc_info=True)
        return None, None, None


# JARs live on the PVC that both the Spark driver and executor pods
# mount.  Using the ``local://`` URI scheme tells Spark the JAR is
# ALREADY PRESENT at that path on every pod -- no upload at submit
# time.  With the previous ``spark.jars=/usr/local/spark/pvc/code/jars/x.jar``
# (no scheme), Spark would re-upload both JARs to the driver pod on
# every spark-submit.
_JAR_OJDBC  = f"local://{_PVC_CODE_ROOT}/jars/ojdbc11-23.9.0.25.07.jar"
_JAR_TRINO  = f"local://{_PVC_CODE_ROOT}/jars/trino-jdbc-468-e.6.jar"
_SPARK_JARS = f"{_JAR_OJDBC},{_JAR_TRINO}"


# Spark config loader
def get_spark_confs(spark_conf_path: str, delimiter: str = ';;;') -> Dict[str, str]:
    # All paths below are SPARK-pod paths -- driver + executor see
    # the spark PVC at _PVC_CODE_ROOT.  Same path Airflow uses; both
    # PVCs are mounted on both pod types.
    spark_conf = {
        'spark.kubernetes.driverEnv.PYTHONPATH': f'{_PVC_CODE_ROOT}:{_PVC_CODE_ROOT}/code',
        'spark.kubernetes.executorEnv.PYTHONPATH': f'{_PVC_CODE_ROOT}:{_PVC_CODE_ROOT}/code',
        'spark.jars': _SPARK_JARS,
    }

    try:
        overrides = {
            'spark.jars': _SPARK_JARS,
            'spark.kubernetes.driverEnv.SPARK_DIST_CLASSPATH': f'{_PVC_CODE_ROOT}/jars/*',
            'spark.kubernetes.executorEnv.SPARK_DIST_CLASSPATH': f'{_PVC_CODE_ROOT}/jars/*',
            'spark.kubernetes.driverEnv.PYTHONPATH': f'{_PVC_CODE_ROOT}:{_PVC_CODE_ROOT}/code',
            'spark.kubernetes.executorEnv.PYTHONPATH': f'{_PVC_CODE_ROOT}:{_PVC_CODE_ROOT}/code',
        }
        spark_conf = overrides.copy()
        with open(spark_conf_path) as spark_props:
            for line in spark_props:
                line = line.strip()
                if line and delimiter in line:
                    key, value = line.split(delimiter, 1)
                    key = key.strip()
                    value = value.strip()
                    # Only add if not already overridden
                    if key not in spark_conf:
                        spark_conf[key] = value
    except Exception as e:
        logging.error(f"Error reading spark properties from {spark_conf_path}: {e}")
    return spark_conf


# Default DAG arguments
def get_default_args(email: List[str]) -> Dict:
    return {
        'owner': Variable.get("dag_owner", default_var="Output Gateway"),
        'depends_on_past': False,
        'start_date': datetime(2025, 7, 14),
        'retries': 0,
        'retry_delay': timedelta(minutes=5),
        'email_on_failure': bool(email),  # was True; SMTP errors with empty list mask the real failure
        'email': email,
    }


def get_dag_configs_async(batch_size: int = 1000) -> List[Dict]:
    import time as _t
    _t_start = _t.monotonic()
    logging.info(
        "[dag_generation] ===== DAG PARSE CYCLE START "
        "(batch_size=%d, yaml=%s) =====",
        batch_size, _ORACLE_CONFIG_PATH,
    )
    configs = []
    dsn, user, password = load_db_config(_ORACLE_CONFIG_PATH)
    if not all([user, password, dsn]):
        logging.error(
            "[dag_generation] Incomplete Oracle DB config -- "
            "user=%s dsn=%s password=%s.  Cannot proceed with DAG "
            "generation; Airflow UI will show NO dynamically-created "
            "DAGs until yaml is fixed.",
            "SET" if user else "blank",
            "SET" if dsn else "blank",
            "SET" if password else "blank",
        )
        return []
    try:
        logging.info(
            "[dag_generation] Connecting Oracle user=%r dsn=%r "
            "(tcp_connect_timeout=10s)", user, dsn,
        )
        _t_connect = _t.monotonic()
        # 2026-07-01: bounded TCP connect + retry-count on the DAG-
        # parse Oracle call.  Without a timeout, an Oracle outage
        # would block the Airflow scheduler for the OS TCP default
        # (up to 75s) EVERY parse cycle -- DAG UI freezes fleet-wide.
        with oracledb.connect(
            user=user, password=password, dsn=dsn,
            tcp_connect_timeout=10,
            retry_count=1,
        ) as connection:
            logging.info(
                "[dag_generation] Oracle connect OK in %.2fs",
                _t.monotonic() - _t_connect,
            )
            with connection.cursor() as cursor:
                # Query for DAG configurations
                query = """
                Select DISTINCT DAG_ID, FK_REPORT_ID, DESCRIPTION,
                       SCHEDULE_INTERVAL, TAGS, FK_DEST_APPID, OTG_DAG_ID, SYSTEM_ENTITY,
                       CONFIG_PATH, LOG_FILE_PATH, SPARK_PROPERTY, SUPPORT_EMAIL_ID, EXECUTABLE_FILE, DAG_TYPE
                from VW_OTG_DAG_Gen_CONFIG
                """
                offset = 0
                skipped_missing_fields = 0
                pages_read = 0
                while True:
                    paginated_query = f"{query} OFFSET {offset} ROWS FETCH NEXT {batch_size} ROWS ONLY"
                    cursor.execute(paginated_query)
                    rows = cursor.fetchall()
                    if not rows:
                        break
                    pages_read += 1
                    logging.info(
                        "[dag_generation] Fetched page %d (offset=%d, "
                        "rows=%d)",
                        pages_read, offset, len(rows),
                    )
                    columns = [col[0].lower() for col in cursor.description]
                    for row in rows:
                        # 2026-07-02 -- per-row try/except.  Previously
                        # any single row with NULL ``fk_report_id`` or
                        # ``fk_dest_appid`` would raise TypeError inside
                        # ``int(None)``, aborting the whole ``for row in
                        # rows:`` loop -- silently dropping every
                        # subsequent row on THIS page AND every subsequent
                        # page (since ``fetchall`` had already advanced).
                        # Result: one bad polling row would erase most
                        # of the DAGs from the Airflow UI on next parse.
                        # Now: bad row is logged + counted as skipped;
                        # sibling rows keep processing.
                        try:
                            row_dict = dict(zip(columns, row))
                            schedule = None if row_dict['schedule_interval'] == 'None' else row_dict['schedule_interval']

                            # Safe-cast helper: allow NULL through as None
                            # for optional int columns, raise for required.
                            def _safe_int(v, field: str, required: bool):
                                if v is None:
                                    if required:
                                        raise ValueError(
                                            f"{field} is NULL (required)"
                                        )
                                    return None
                                return int(v)

                            config = {
                                'DAG_ID': row_dict['dag_id'],
                                'FK_REPORT_ID': _safe_int(
                                    row_dict['fk_report_id'],
                                    'fk_report_id', required=True,
                                ),
                                'DESCRIPTION': row_dict['description'],
                                'SCHEDULE_INTERVAL': schedule,
                                'TAGS': row_dict['tags'].split(',') if row_dict['tags'] else [],
                                'FK_DEST_APPID': _safe_int(
                                    row_dict['fk_dest_appid'],
                                    'fk_dest_appid', required=False,
                                ),
                                'OTG_DAG_ID': row_dict['otg_dag_id'],
                                'APPLICATION_PATH': row_dict['executable_file'],
                                'CONFIG_PATH': row_dict['config_path'],
                                'SPARK_CONF_PATH': row_dict['spark_property'],
                                'EMAIL': row_dict['support_email_id'].split(',') if row_dict['support_email_id'] else ['test@tyet.com'],
                                'LOG_FILE_PATH': row_dict['log_file_path'],
                                'DAG_TYPE': row_dict['dag_type']
                            }
                        except Exception as _row_exc:
                            skipped_missing_fields += 1
                            # Row may not be fully-mapped when the failure
                            # is on _safe_int -- log the raw row shape so
                            # the operator can find the bad polling row.
                            _row_id = None
                            try:
                                _row_id = dict(zip(columns, row)).get('dag_id')
                            except Exception:
                                pass
                            logging.warning(
                                "[dag_generation] SKIP row -- construction "
                                "failed: dag_id=%r err=%s: %s",
                                _row_id, type(_row_exc).__name__, _row_exc,
                            )
                            continue
                        if not all([config['DAG_ID'], config['APPLICATION_PATH'], config['CONFIG_PATH']]):
                            skipped_missing_fields += 1
                            logging.warning(
                                "[dag_generation] SKIP row -- missing "
                                "required fields: DAG_ID=%r "
                                "APPLICATION_PATH=%r CONFIG_PATH=%r",
                                config['DAG_ID'],
                                config['APPLICATION_PATH'],
                                config['CONFIG_PATH'],
                            )
                            continue
                        configs.append(config)
                    # Advance the page (was incremented per-row inside
                    # the for loop, producing wrong offsets when more
                    # than one page exists).
                    offset += batch_size
        logging.info(
            "[dag_generation] DB fetch DONE: "
            "pages=%d valid_configs=%d skipped_missing_fields=%d "
            "elapsed=%.2fs",
            pages_read, len(configs), skipped_missing_fields,
            _t.monotonic() - _t_start,
        )
        return configs
    except Exception as e:
        logging.error(
            "[dag_generation] Error fetching DAG configurations "
            "(elapsed=%.2fs): %s",
            _t.monotonic() - _t_start, e, exc_info=True,
        )
        raise


# Create a single DAG
def create_dag(config: Dict) -> Optional[DAG]:
    try:
        dag_id = config['DAG_ID']
        # Create DAG
        dag = DAG(
            dag_id=dag_id,
            default_args=get_default_args(config['EMAIL']),
            description=config['DESCRIPTION'],
            schedule_interval=config['SCHEDULE_INTERVAL'],
            catchup=False,
            is_paused_upon_creation=True,
            tags=config['TAGS'],
            params={
                'report_id': Param(
                    config['FK_REPORT_ID'],
                    type='integer',
                    description='Report ID to process'
                ),
                'business_event': Param(
                    default='SOD',
                    type='string',
                    title='Business Event ID',
                    description='Dag Instance ID to process',
                    enum=['SOD', 'EOD', 'INTRADAY'],
                    values_display={
                        'SOD': 'Start of Day',
                        'EOD': 'End of Day',
                        'INTRADAY': 'Intraday'
                    },
                ),
                'business_date': Param(
                    Variable.get("default_business_date", default_var="14-07-2025"),
                    type='string',
                    description='Business date to process (DD-MM-YYYY)'
                )
            },
            render_template_as_native_obj=True
        )

        # SparkSubmit task -- attached to the DAG via the dag= kwarg.
        # Using SafeSparkSubmitOperator (defined at top of this file)
        # instead of stock SparkSubmitOperator so a connection extras
        # field that comes out as int/number cannot crash
        # ``" ".join(cmd)`` inside SparkSubmitHook._mask_cmd.
        SafeSparkSubmitOperator(
            task_id=config['DAG_TYPE'],
            application=config['APPLICATION_PATH'],
            conn_id=Variable.get("spark_conn_id", default_var="spark_on_prem"),
            # 2026-07-01 -- match working dynamic_dags.py pattern:
            # every templated arg is wrapped in double quotes so the
            # rendered value is always a string, defeating the
            # ``render_template_as_native_obj=True`` int-rendering
            # of ``params.report_id`` (Param type=integer).  This is
            # the same pattern the operator confirmed as working in
            # the deprecated dynamic_dags.py.
            application_args=[
                '--report_id', '"{{ params.report_id }}"',
                '--business_date', '"{{ params.business_date }}"',
                '--dag_id',
                '"{{ dag.dag_id }}'
                '{% if params.report_id == 76 and params.business_event in ["SOD", "EOD", "INTRADAY"] %}'
                '_finance_sl_balance_{{ params.business_event }}'
                '{% elif params.report_id == 77 and params.business_event in ["SOD", "EOD", "INTRADAY"] %}'
                '_finance_sl_balance_ext_{{ params.business_event }}'
                '{% endif %}"',
                '--config_path', config['CONFIG_PATH']
            ],
            # 2026-07-01 defense-in-depth: force every conf key + value
            # to str.  Even though ``get_spark_confs`` returns
            # ``Dict[str, str]`` by construction, an operator who edits
            # the .conf file might supply a value that yaml/pyyaml
            # parses as int (unlikely but possible in cross-cutting
            # config).  Airflow's SparkSubmitHook builds
            # ``--conf key=value`` args and then joins the whole list
            # with `" ".join(...)`; any non-str element raises
            # ``TypeError: sequence item N: expected str instance,
            # int found``.  This coerce guarantees we never get bitten
            # by an unexpected type in the conf dict.
            conf={
                str(k): str(v)
                for k, v in get_spark_confs(config['SPARK_CONF_PATH']).items()
            },
            dag=dag,
        )

        # 2026-07-01 hotfix -- downgraded per-DAG "Created" log to
        # DEBUG.  Airflow re-parses this file every ~30s; on a fleet
        # of N DAGs this line alone was N * (30s * 24h) = massive
        # daily volume.  Aggregate counts still land in the
        # PARSE CYCLE DONE line at INFO level.
        logging.debug(
            "[dag_generation] Created DAG dag_id=%s report_id=%s "
            "dag_type=%s app=%s",
            dag_id,
            config.get('FK_REPORT_ID'),
            config.get('DAG_TYPE'),
            config.get('APPLICATION_PATH'),
        )
        return dag
    except Exception as e:
        logging.error(
            "[dag_generation] Error creating DAG dag_id=%s: %s",
            config.get('DAG_ID', 'unknown'), e, exc_info=True,
        )
        return None


# Main function -- generates DAGs at module load so the Airflow
# scheduler picks them up on each parse cycle.
def main():
    import time as _t_main
    _t_main_start = _t_main.monotonic()
    logging.info(
        "[dag_generation] main() START -- fetching configs + "
        "registering DAGs"
    )
    dag_configs = get_dag_configs_async(batch_size=1000)
    created = 0
    failed = 0
    globals_dict = globals()
    for config in dag_configs:
        dag = create_dag(config)
        if dag:
            globals_dict[config['DAG_ID']] = dag
            created += 1
        else:
            failed += 1
    logging.info(
        "[dag_generation] ===== DAG PARSE CYCLE DONE "
        "created=%d failed=%d fetched=%d elapsed=%.2fs =====",
        created, failed, len(dag_configs),
        _t_main.monotonic() - _t_main_start,
    )


# Module-load: actually generate the DAGs.  Without this call, Airflow
# would parse the file, find no DAGs at module scope, and nothing
# would appear in the UI.
main()
