"""Deep-dive #13 (2026-07-01): plain-yaml creds fast path in resolver.

Operator report: "if connection string defined and vault disabled ...
still we should cache these oracle string credentials".

Pre-fix, ``qs_credentials.resolver._resolve_with_cache`` raised
RuntimeError whenever ``is_vault_enabled`` was False -- even when the
yaml already had literal user/password embedded.  Every DAG that
called into the resolver would crash for dev DBs not onboarded to vault.

Fix: added a "plain-creds" layer BETWEEN the caches and the vault
fetch.  The resolver extracts user/password from oracle_config.yaml
(structured fields OR embedded in connection strings), caches under
the ref name identically to vault creds, and returns.  Cache treats
both sources uniformly.

These tests lock:
  * OLEDB shape parsing ("User Id=X; Password=Y")
  * Easy Connect shape parsing ("user/password@host:port/service")
  * Structured section fallback (oracle.etl.username + password)
  * Placeholder rejection (PLACEHOLDER / <vault> / TBD -> treat as absent)
  * Cache hit on second call (no repeat parse)
  * Both API surfaces: resolve_db_account (2-tuple) + resolve_db_account_with_tns (3-tuple)
  * Vault-disabled + no plain creds -> actionable error (not silent None)
  * Auto-loading of oracle_config.yaml when caller passes None
"""
from __future__ import annotations

import os
import sys
import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ── Helper: reset the resolver's caches before each test ─────────────


@pytest.fixture(autouse=True)
def _reset_resolver_state(monkeypatch):
    """Ensure each test starts with cold caches + vault disabled by
    default so the test's yaml is the sole source of truth.

    Also clears the DISK cache to prevent tests from cross-polluting
    subsequent test files that rely on the vault-fetch path being
    hit (test_runtime_env_chokepoint) or on a specific empty state.
    """
    # Vault off by default; tests that need it on will set explicitly.
    monkeypatch.setenv("ETL_USE_VAULT", "0")
    from qs_credentials import resolver
    resolver.reset_cache()
    resolver._cred_cache.reset_mem()
    try:
        resolver._cred_cache.disk_clear()
    except Exception:
        pass
    yield
    resolver.reset_cache()
    resolver._cred_cache.reset_mem()
    try:
        resolver._cred_cache.disk_clear()
    except Exception:
        pass


# ── Extractor unit tests (no cache involvement) ─────────────────────


class TestOLEDBParser:
    def test_extracts_user_and_password(self):
        from qs_credentials.resolver import _parse_userid_password_from_oledb
        cs = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=s))); User Id = ALICE; Password = s3cret;"
        u, p = _parse_userid_password_from_oledb(cs)
        assert u == "ALICE"
        assert p == "s3cret"

    def test_case_insensitive_and_no_trailing_semicolon(self):
        from qs_credentials.resolver import _parse_userid_password_from_oledb
        cs = "(DESCRIPTION=...); user id=bob; password=pw123"
        u, p = _parse_userid_password_from_oledb(cs)
        assert u == "bob"
        assert p == "pw123"

    def test_placeholder_rejected(self):
        from qs_credentials.resolver import _parse_userid_password_from_oledb
        # PLACEHOLDER / VAULT sentinels used in prod yamls when vault
        # fills the real value at runtime -- must NOT be returned as
        # plain creds, otherwise vault mode gets shadowed by the yaml.
        cs = "(DESC=...); User Id=PLACEHOLDER; Password=PLACEHOLDER;"
        u, p = _parse_userid_password_from_oledb(cs)
        assert u == "" and p == ""

    def test_bracket_placeholder_rejected(self):
        from qs_credentials.resolver import _parse_userid_password_from_oledb
        cs = "(DESC=...); User Id=<VAULT>; Password=<REPLACE_ME>;"
        u, p = _parse_userid_password_from_oledb(cs)
        assert u == "" and p == ""

    def test_missing_fields_returns_blanks(self):
        from qs_credentials.resolver import _parse_userid_password_from_oledb
        assert _parse_userid_password_from_oledb("") == ("", "")
        assert _parse_userid_password_from_oledb("(DESC=...)") == ("", "")
        # Only user, no password
        assert _parse_userid_password_from_oledb("(DESC=...); User Id=a;") == ("", "")


class TestEasyConnectParser:
    def test_extracts_user_password(self):
        from qs_credentials.resolver import _parse_userid_password_from_easyconnect
        u, p = _parse_userid_password_from_easyconnect("alice/s3cret@host:1521/svc")
        assert u == "alice"
        assert p == "s3cret"

    def test_shape_mismatch_returns_blanks(self):
        from qs_credentials.resolver import _parse_userid_password_from_easyconnect
        assert _parse_userid_password_from_easyconnect("no_at_sign") == ("", "")
        assert _parse_userid_password_from_easyconnect("@host/svc") == ("", "")
        assert _parse_userid_password_from_easyconnect("user@host/svc") == ("", "")


class TestExtractPlainCreds:
    def test_structured_etl_section(self):
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {"etl": {
            "username": "u1", "password": "p1",
            "host": "h1", "port": 1521, "service": "svc1",
        }}}
        u, p, tns = _extract_plain_creds_from_workflow_config(cfg)
        assert (u, p) == ("u1", "p1")
        assert tns == "h1:1521/svc1"

    def test_structured_destination_section(self):
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {"destination": {
            "username": "u2", "password": "p2",
            "host": "h2", "service": "svc2",
        }}}
        u, p, tns = _extract_plain_creds_from_workflow_config(cfg)
        assert (u, p) == ("u2", "p2")

    def test_oledb_connection_string(self):
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {
            "etl_connection_string":
                "(DESC=...); User Id=EMBEDDED_U; Password=EMBEDDED_P;",
        }}
        u, p, tns = _extract_plain_creds_from_workflow_config(cfg)
        assert (u, p) == ("EMBEDDED_U", "EMBEDDED_P")

    def test_easy_connect_connection_string(self):
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {
            "etl_connection_string": "user1/pw1@host:1521/svc",
        }}
        u, p, tns = _extract_plain_creds_from_workflow_config(cfg)
        assert (u, p) == ("user1", "pw1")

    def test_prefers_structured_over_conn_string(self):
        """If BOTH shapes are present, structured wins (more explicit)."""
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {
            "etl": {"username": "STRUCT_U", "password": "STRUCT_P"},
            "etl_connection_string":
                "(DESC=...); User Id=STRING_U; Password=STRING_P;",
        }}
        u, p, _ = _extract_plain_creds_from_workflow_config(cfg)
        assert (u, p) == ("STRUCT_U", "STRUCT_P")

    def test_falls_through_when_placeholder(self):
        """Placeholders anywhere -> empty extraction -> caller hits vault."""
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        cfg = {"oracle": {"etl_connection_string":
                            "(DESC=...); User Id=PLACEHOLDER; Password=PLACEHOLDER;"}}
        assert _extract_plain_creds_from_workflow_config(cfg) == ("", "", "")

    def test_oracle_section_passed_directly(self):
        """Callers may pass just the oracle section instead of the full yaml."""
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        section = {"etl": {"username": "u", "password": "p"}}
        u, p, _ = _extract_plain_creds_from_workflow_config(section)
        assert (u, p) == ("u", "p")

    def test_empty_config(self):
        from qs_credentials.resolver import (
            _extract_plain_creds_from_workflow_config,
        )
        assert _extract_plain_creds_from_workflow_config({}) == ("", "", "")
        assert _extract_plain_creds_from_workflow_config(None) == ("", "", "")


# ── Integration: resolve_db_account with plain creds ────────────────


class TestResolveDBAccountPlainCreds:
    def test_dev_yaml_no_vault_returns_plain_creds(self):
        """Operator's dev DB case: vault disabled, yaml has plain conn
        string, resolve_db_account must return the yaml creds instead
        of raising."""
        from qs_credentials.resolver import resolve_db_account
        cfg = {"oracle": {"etl": {
            "username": "dev_user", "password": "dev_pass",
        }}}
        u, p = resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        assert u == "dev_user"
        assert p == "dev_pass"

    def test_resolve_with_tns_returns_3tuple(self):
        """resolve_db_account_with_tns must unpack cleanly to 3-tuple
        when plain-creds path fires."""
        from qs_credentials.resolver import resolve_db_account_with_tns
        cfg = {"oracle": {"etl": {
            "username": "u", "password": "p",
            "host": "h", "port": 1521, "service": "svc",
        }}}
        u, p, tns = resolve_db_account_with_tns(
            "etl_oracle_meta", workflow_config=cfg,
        )
        assert (u, p, tns) == ("u", "p", "h:1521/svc")

    def test_second_call_hits_cache(self):
        """After plain creds are served, subsequent calls with the
        SAME ref name must hit in-process cache -- do NOT re-parse
        yaml -- so hot DAG paths stay fast."""
        from qs_credentials import resolver
        from qs_credentials.resolver import resolve_db_account
        cfg = {"oracle": {"etl": {"username": "u", "password": "p"}}}
        # First call: cold cache, populates via plain-creds path.
        resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        # Poison the config to prove second call doesn't re-parse it.
        cfg2 = {"oracle": {"etl": {"username": "different", "password": "different"}}}
        u, p = resolve_db_account("etl_oracle_meta", workflow_config=cfg2)
        # Second call MUST return the cached first-call creds.
        assert (u, p) == ("u", "p"), (
            "Cache did not hit -- resolver re-parsed the passed config "
            "instead of serving from _cred_cache"
        )

    def test_vault_disabled_no_plain_creds_raises_actionable(self):
        """Cover the intended error path: vault off + no plain creds =>
        clear operator-facing message."""
        from qs_credentials.resolver import resolve_db_account
        cfg = {"oracle": {"etl": {}}}  # empty section
        with pytest.raises(RuntimeError) as excinfo:
            resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        msg = str(excinfo.value)
        # Message must mention BOTH the vault toggle AND the plain-creds
        # alternative -- otherwise operator can't tell which path to fix.
        assert "vault" in msg.lower()
        assert "yaml" in msg.lower()
        assert "username" in msg.lower() or "connection_string" in msg.lower()

    def test_dev_yaml_via_conn_string_embedded_oledb(self):
        """The DAG's real-world case: yaml has User Id / Password
        embedded in etl_connection_string as OLEDB."""
        from qs_credentials.resolver import resolve_db_account
        cfg = {"oracle": {
            "etl_connection_string":
                "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=dev-oracle)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=DEVDB))); User Id=DEV_USER; Password=DEV_PASS;",
        }}
        u, p = resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        assert u == "DEV_USER"
        assert p == "DEV_PASS"


class TestAutoLoadOracleConfig:
    def test_falls_back_to_yaml_file_when_no_config_passed(self, tmp_path,
                                                              monkeypatch):
        """DAGs that call resolve_db_account(name) WITHOUT
        workflow_config (dynamic_dags_airflow.py:70) must still work --
        resolver falls back to auto-loading oracle_config.yaml from
        the standard PVC path."""
        # Write a dev-shaped oracle_config.yaml
        yaml_path = tmp_path / "oracle_config.yaml"
        yaml_path.write_text(
            "oracle:\n"
            "  etl:\n"
            "    username: auto_user\n"
            "    password: auto_pass\n"
            "    host: h\n"
            "    port: 1521\n"
            "    service: svc\n",
            encoding="utf-8",
        )
        monkeypatch.setenv("ETL_ORACLE_CONFIG_PATH", str(yaml_path))
        from qs_credentials.resolver import resolve_db_account
        u, p = resolve_db_account("etl_oracle_meta")   # no workflow_config
        assert u == "auto_user"
        assert p == "auto_pass"

    def test_missing_yaml_falls_through_cleanly(self, monkeypatch):
        """When no yaml exists AND caller passed None AND vault off,
        raise the actionable error (not a stray FileNotFoundError)."""
        monkeypatch.setenv("ETL_ORACLE_CONFIG_PATH", "/nonexistent/path.yaml")
        from qs_credentials.resolver import resolve_db_account
        with pytest.raises(RuntimeError) as excinfo:
            resolve_db_account("etl_oracle_meta")   # no config, no yaml
        assert "vault" in str(excinfo.value).lower()


# ── Vault path unchanged -- regression check ─────────────────────────


class TestVaultPathUnchanged:
    def test_vault_enabled_and_no_plain_creds_still_tries_vault(self, monkeypatch):
        """When vault is enabled AND yaml has NO plain creds, the
        resolver must fall through to the vault fetch path.  We stub
        the vault fetch to prove the code path is reached (we don't
        want a real network call in tests).

        Uses CLASS-level monkeypatch on QSCredCache.fetch_with_fallback
        to avoid the instance-level teardown shadow bug (an instance
        setattr survives as a shadow attribute after teardown and
        blocks other tests' class-level patches from being visible).
        """
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        # Empty config -- no plain creds
        cfg = {"oracle": {}}
        # Stub the vault fetch to return a sentinel.
        from qs_credentials import resolver, cache as _cache_mod
        stub_called = {"n": 0}
        def _stub_fetch(self, name, ref, **kw):
            stub_called["n"] += 1
            return ("VAULT_USER", "VAULT_PASS")
        monkeypatch.setattr(_cache_mod.QSCredCache,
                              "fetch_with_fallback", _stub_fetch)
        # Also stub _get_ref_config to skip vault_config.yaml lookup.
        monkeypatch.setattr(resolver, "_get_ref_config",
                              lambda name: {"type": "DB_accounts",
                                              "auth_url": "x",
                                              "role_name": "r",
                                              "role_type": "rt",
                                              "secret_url": "u"})
        from qs_credentials.resolver import resolve_db_account
        u, p = resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        assert (u, p) == ("VAULT_USER", "VAULT_PASS")
        assert stub_called["n"] == 1, "Vault fetch path not reached"

    def test_vault_enabled_but_plain_creds_present_prefers_plain(self, monkeypatch):
        """Predictable priority: when yaml has plain creds, they win
        over vault EVEN IF vault_enabled=1.  This is intentional --
        operator's yaml is the source of truth; vault only fills gaps.

        Uses class-level monkeypatch (see companion test's docstring).
        """
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        cfg = {"oracle": {"etl": {"username": "explicit_u",
                                     "password": "explicit_p"}}}
        # If vault path fires, this stub raises -- must NOT be reached.
        from qs_credentials import cache as _cache_mod
        def _fail(self, name, ref, **kw):
            raise AssertionError("vault fetch should not have been called")
        monkeypatch.setattr(_cache_mod.QSCredCache,
                              "fetch_with_fallback", _fail)
        from qs_credentials.resolver import resolve_db_account
        u, p = resolve_db_account("etl_oracle_meta", workflow_config=cfg)
        assert (u, p) == ("explicit_u", "explicit_p")
