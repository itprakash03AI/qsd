"""qs_credentials.prewarm -- Vault credential pre-warm logic.

The pure-Python core of the ``vault_credential_prewarm`` Airflow DAG.
Kept Airflow-free so it's importable from tests, the smoke harness, an
admin "manual refresh" endpoint, and the DAG wrapper itself.

Single chokepoint: every cache-warming surface (DAG, admin endpoint,
smoke probe) consumes :func:`prewarm_vault_cache` so the retry +
validation contract stays consistent.

Behaviour summary:
  * Reads ``/usr/local/spark/pvc/code/configs/vault_config.yaml`` (or
    the path you pass) and iterates ``secrets.refs.*``.
  * Skips refs whose name starts with ``_disabled_`` OR whose
    ``auth_url`` is blank (smoke / dev placeholders).
  * Per-ref retry with exponential backoff (3 attempts: 0s / 2s / 8s).
  * Successful resolves write to the shared QSCredCache disk file via
    the existing resolver code path (no new cache machinery here).
  * Post-run verification: confirms the disk cache file exists, is
    non-empty, and was written within the current run window.
  * Returns a structured summary dict (used by Airflow XComs, the smoke
    harness, and the admin endpoint identically).
"""
from __future__ import annotations

import logging
import os
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


# ── Defaults aligned with the prod Helm-mounted PVC ──────────────────
DEFAULT_PVC_CODE_ROOT = "/usr/local/spark/pvc/code"
DEFAULT_VAULT_CONFIG  = (
    f"{DEFAULT_PVC_CODE_ROOT}/configs/vault_config.yaml"
)

# Per-ref retry policy.  3 attempts total (initial + 2 retries) with
# exponential backoff -- absorbs a brief Vault hiccup mid-prewarm.
DEFAULT_RETRY_ATTEMPTS = 3
DEFAULT_RETRY_BACKOFF  = (0.0, 2.0, 8.0)


def ensure_pvc_code_on_path(pvc_code_root: str = DEFAULT_PVC_CODE_ROOT) -> None:
    """Add the shared PVC code root to ``sys.path`` so ``qs_credentials``
    is importable from any pod that mounts the PVC.  Idempotent."""
    if pvc_code_root and pvc_code_root not in sys.path:
        sys.path.insert(0, pvc_code_root)


def load_refs_from_yaml(
    vault_config_path: str = DEFAULT_VAULT_CONFIG,
) -> Dict[str, Any]:
    """Parse the vault yaml and return the ``secrets`` block.

    Returns a dict with keys ``refs`` (mapping) + ``vault`` (settings).
    Raises with an operator-actionable message when the file is missing
    or malformed -- callers MUST fail loudly in those cases.
    """
    if not os.path.exists(vault_config_path):
        raise FileNotFoundError(
            f"vault_config.yaml not found at {vault_config_path}.  "
            "Confirm the PVC is mounted on this pod AND the config has "
            "been deployed under configs/."
        )
    try:
        with open(vault_config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as exc:
        raise RuntimeError(
            f"vault_config.yaml at {vault_config_path} is malformed: "
            f"{exc}.  Fix the yaml syntax before the prewarm can run."
        ) from exc
    secrets = data.get("secrets", {}) or {}
    refs    = secrets.get("refs", {}) or {}
    vault   = secrets.get("vault", {}) or {}
    if not isinstance(refs, dict):
        raise RuntimeError(
            f"vault_config.yaml -> secrets.refs must be a mapping; "
            f"got {type(refs).__name__}."
        )
    if not refs:
        raise ValueError(
            f"vault_config.yaml at {vault_config_path} has no "
            "``secrets.refs`` entries -- nothing to prewarm.  Pause "
            "the DAG in Airflow UI if this is intentional."
        )
    # Pass the full secrets block up so callers can also read the
    # master enable flag (secrets.enabled) without re-parsing.
    return {"refs": refs, "vault": vault, "secrets": secrets}


def _is_skippable(name: str, ref: Dict[str, Any]) -> Optional[str]:
    """Return a skip reason (str) or ``None`` when the ref should be
    resolved.  Centralises the "is this ref real" decision so the DAG
    + smoke harness + admin endpoint share one definition."""
    if name.startswith("_disabled_"):
        return "disabled_prefix"
    # Smoke / dev refs left intentionally blank in vault_config.yaml
    # so misconfigured ETL_USE_VAULT=1 fails LOUD on a real ref, not
    # on these.  Skip them in prewarm -- they have no real Vault target.
    if not (ref.get("auth_url") or "").strip():
        return "blank_auth_url"
    if not (ref.get("secret_url") or "").strip():
        return "blank_secret_url"
    return None


def _describe_payload(payload: Any) -> str:
    """Credential-safe shape descriptor for logs / XComs.  Mirrors the
    QSClient diagnostic helper so logs are uniform.  Never leaks the
    secret value -- shows tuple length + dict keys only."""
    if payload is None:
        return "None"
    if isinstance(payload, (tuple, list)):
        return f"{type(payload).__name__}(len={len(payload)})"
    if isinstance(payload, dict):
        return f"dict(keys={sorted(str(k) for k in payload.keys())})"
    return type(payload).__name__


def _resolve_one(
    name: str,
    ref: Dict[str, Any],
    *,
    retry_backoff: tuple = DEFAULT_RETRY_BACKOFF,
    sleep: Any = time.sleep,
) -> Dict[str, Any]:
    """Resolve a single ref via the shared chokepoint with retry.

    Each successful resolve writes the validated payload to the disk
    cache as a side-effect via ``QSCredCache.fetch_with_fallback``.

    Returns a diagnostic dict (no secret material).
    """
    # Lazy import -- the resolver imports its sibling modules at
    # import time; deferring keeps test environments that don't have
    # the full vault deps able to import this module.
    from qs_credentials.resolver import _resolve_with_cache  # type: ignore

    attempts = len(retry_backoff)
    last_exc: Optional[BaseException] = None
    t_start = time.monotonic()

    for attempt, backoff_s in enumerate(retry_backoff, start=1):
        if backoff_s > 0:
            sleep(backoff_s)
        t_call = time.monotonic()
        try:
            payload = _resolve_with_cache(name)
        except Exception as exc:
            last_exc = exc
            logger.warning(
                "[prewarm] ref=%r attempt %d/%d FAILED in %.2fs: %s: %s",
                name, attempt, attempts,
                time.monotonic() - t_call,
                type(exc).__name__, exc,
            )
            continue
        shape   = _describe_payload(payload)
        elapsed = round(time.monotonic() - t_start, 3)
        logger.info(
            "[prewarm] ref=%r OK on attempt %d/%d  type=%s  shape=%s  elapsed=%ss",
            name, attempt, attempts, ref.get("type"), shape, elapsed,
        )
        return {
            "name":      name,
            "status":    "ok",
            "shape":     shape,
            "attempts":  attempt,
            "elapsed_s": elapsed,
        }

    # Exhausted retries.
    elapsed = round(time.monotonic() - t_start, 3)
    err_repr = (f"{type(last_exc).__name__}: {last_exc}"
                if last_exc is not None else "no exception captured")
    logger.error(
        "[prewarm] ref=%r EXHAUSTED %d attempts in %.2fs  err=%s",
        name, attempts, elapsed, err_repr,
    )
    return {
        "name":      name,
        "status":    "failed",
        "shape":     None,
        "attempts":  attempts,
        "elapsed_s": elapsed,
        "error":     err_repr,
    }


def _verify_cache_written(
    disk_cache_path: str,
    *,
    run_started_at: float,
    n_eligible_ok: int,
) -> Dict[str, Any]:
    """Post-run sanity check on the on-disk cache file.

    Confirms:
      * file exists (the resolver wrote SOMETHING this run)
      * file is non-empty
      * file mtime is >= the prewarm start time when at least one ref
        succeeded (rules out the case where the disk-cache write
        silently no-op'd due to misconfigured env / ENV).

    Returns a diagnostic dict; raises ``RuntimeError`` when verification
    fails AND at least one ref reported success (mismatch implies a
    real write-side bug operators must see).
    """
    info: Dict[str, Any] = {
        "path":   disk_cache_path,
        "exists": False,
        "size":   0,
        "mtime":  None,
    }
    if not disk_cache_path:
        info["skipped"] = "no disk_cache_path configured"
        return info
    if not os.path.exists(disk_cache_path):
        if n_eligible_ok > 0:
            raise RuntimeError(
                f"[prewarm] verification FAILED: {n_eligible_ok} refs "
                f"resolved OK but disk cache file at {disk_cache_path} "
                "does not exist.  Likely causes: disk_cache_enabled=false, "
                "cryptography import failure, or the path is not "
                "writable on this pod."
            )
        return info
    info["exists"] = True
    info["size"]   = os.path.getsize(disk_cache_path)
    info["mtime"]  = os.path.getmtime(disk_cache_path)
    if info["size"] == 0:
        raise RuntimeError(
            f"[prewarm] verification FAILED: disk cache at "
            f"{disk_cache_path} is empty (size=0).  Cache file was "
            "created but no payload was written."
        )
    # 1-second tolerance on the mtime comparison -- filesystem mtime
    # granularity is 1 second on common deployments (ext4 default,
    # NFS, older Linux), so a write that happens in the SAME second
    # as the run start can legitimately come back with mtime ==
    # run_started_at.  Only flag when mtime is BEFORE run_start by
    # more than that 1-second window (true "didn't write" signal).
    _MTIME_GRANULARITY_S = 1.0
    if (n_eligible_ok > 0
            and info["mtime"] + _MTIME_GRANULARITY_S < run_started_at):
        raise RuntimeError(
            f"[prewarm] verification FAILED: {n_eligible_ok} refs "
            f"resolved OK but disk cache mtime "
            f"({info['mtime']:.0f}) is OLDER than this run's start "
            f"({run_started_at:.0f}) by more than 1s.  The resolver "
            "did NOT write -- check QSCredCache disk_put failure logs."
        )
    return info


def _assert_vault_enabled(secrets_block: Dict[str, Any]) -> None:
    """Refuse loudly when vault is GLOBALLY disabled.

    Without this guard, every ref produces an identical "vault
    resolution is DISABLED" error -- a yaml with 20 refs floods the
    operator with 20 copies of the same root cause.  Single early
    error makes the fix path obvious.

    Honors the 3-layer toggle in resolver.is_vault_enabled():
      1. ETL_USE_VAULT env var (forced ON / OFF)
      2. global yaml secrets.enabled
      3. default False
    """
    env = os.environ.get("ETL_USE_VAULT", "").strip().lower()
    if env in ("1", "true", "yes"):
        return  # env override ON wins, regardless of yaml
    if env in ("0", "false", "no"):
        raise RuntimeError(
            "[prewarm] ETL_USE_VAULT env var is set to FALSE on this "
            "pod.  The pre-warm DAG cannot resolve any secrets while "
            "vault is force-disabled.  Either unset the env var (and "
            "ensure vault_config.yaml -> secrets.enabled: true) OR "
            "pause this DAG in Airflow UI."
        )
    yaml_enabled = bool(secrets_block.get("enabled", False))
    if not yaml_enabled:
        raise RuntimeError(
            "[prewarm] vault resolution is GLOBALLY DISABLED.  Three "
            "layers control this; at least one must be ON:\n"
            "  1. ETL_USE_VAULT=1 env var on this pod (Helm chart) "
            "-- highest priority\n"
            "  2. vault_config.yaml -> secrets.enabled: true "
            "-- current value is false\n"
            "Without one of these, every ref refuses to resolve and "
            "the cache stays empty.  Fix the yaml in place at "
            "/usr/local/spark/pvc/code/configs/vault_config.yaml "
            "(sed -i 's/enabled: false/enabled: true/') and re-trigger "
            "the DAG -- no Helm change needed."
        )


def _assert_disk_cache_enabled(vault_settings: Dict[str, Any]) -> None:
    """The whole point of the DAG is to populate the disk cache.  If
    the operator has disabled it (yaml typo, accidentally flipped
    while debugging, or a stale dev override), every successful
    resolve would land in in-process memory then disappear with the
    Airflow worker -- shared pods see NOTHING.  Refuse loudly so the
    misconfig is visible in the FIRST DAG run, not after a week of
    workflows mysteriously paying the Vault tax."""
    # ``True`` is the default when the field is missing, matching the
    # resolver's own default behaviour.  Reject only when EXPLICITLY false.
    raw = vault_settings.get("disk_cache_enabled", True)
    if raw is False or (isinstance(raw, str) and raw.strip().lower() in
                          ("0", "false", "no")):
        raise RuntimeError(
            "[prewarm] vault_config.yaml -> secrets.vault.disk_cache_enabled "
            "is FALSE.  The pre-warm DAG depends on the disk cache to "
            "share creds across pods -- without it, every successful "
            "resolve writes into an in-process dict that dies with the "
            "Airflow worker, defeating the entire point of the DAG.  "
            "Either set disk_cache_enabled=true in vault_config.yaml OR "
            "pause this DAG in Airflow UI."
        )
    if not (vault_settings.get("disk_cache_path") or "").strip():
        raise RuntimeError(
            "[prewarm] vault_config.yaml -> secrets.vault.disk_cache_path "
            "is empty.  Set it to a PVC-mounted path (e.g., "
            "/usr/local/spark/pvc/code/.cache/etl_secrets.enc) so the "
            "cache is shared across Airflow + Spark + polling-service pods."
        )


def _verify_round_trip(resolved_names: List[str]) -> Dict[str, Any]:
    """For every ref that resolved OK, confirm it's readable BACK from
    the disk cache as another pod's QSClient would read it.

    Catches the silent-killer prod incident: Fernet key mismatch
    between Airflow worker and Spark driver (`ETL_SECRETS_KEY` set
    differently via Helm typo) -- the prewarm writes a file Spark
    can't decrypt.  Without this check, the DAG reports SUCCESS and
    workflows then fail with confusing "decryption failed" errors.

    Uses ``disk_get_any`` (no TTL gate) so a freshly-written entry
    with mtime <= now is still considered readable.  Returns a
    diagnostic dict; raises when ANY OK ref is unreadable -- mismatch
    discovery should be loud.
    """
    if not resolved_names:
        return {"checked": 0, "not_readable": []}
    # Use the SAME _cred_cache instance the resolver writes through --
    # if read-side disagrees with write-side it's the same process,
    # which would be a cache class bug not a key mismatch.  The check
    # is most valuable in real prod where this code runs on the
    # Airflow worker pod and the cache was written by ITS resolver.
    try:
        from qs_credentials.resolver import _cred_cache  # type: ignore
    except Exception as exc:
        # Cannot import the cache -- treat as a no-op (already caught
        # by the resolver's own import chain).  Log + return.
        logger.warning(
            "[prewarm] round-trip skipped: cannot import _cred_cache: %s",
            exc,
        )
        return {"checked": 0, "not_readable": [],
                "skipped_reason": "cred_cache import failed"}

    not_readable: List[str] = []
    for name in resolved_names:
        try:
            entry = _cred_cache.disk_get_any(name)
        except Exception as exc:
            # Any read-side exception (decrypt failure, json parse,
            # OSError) lands here -- treat as unreadable.
            not_readable.append(f"{name} (read err: {type(exc).__name__}: {exc})")
            continue
        if entry is None:
            not_readable.append(f"{name} (returned None)")
    info = {"checked": len(resolved_names),
            "not_readable": not_readable,
            "readable":     len(resolved_names) - len(not_readable)}
    if not_readable:
        raise RuntimeError(
            "[prewarm] ROUND-TRIP verification FAILED -- "
            f"{len(not_readable)}/{len(resolved_names)} freshly-written "
            "refs are NOT readable from the disk cache.\n"
            "Likely causes (in order of probability):\n"
            "  * ETL_SECRETS_KEY env var differs between this pod and "
            "the pods that wrote previous entries (Helm typo).  Set "
            "it identically Helm-wide.\n"
            "  * cryptography package missing in the Airflow worker "
            "image -- falls back to disabled mode.\n"
            "  * Disk-cache write path silently failed (check "
            "QSCredCache disk_put logs).\n"
            f"Not readable: {not_readable}"
        )
    return info


def prewarm_vault_cache(
    *,
    vault_config_path: str = DEFAULT_VAULT_CONFIG,
    pvc_code_root: str     = DEFAULT_PVC_CODE_ROOT,
    retry_backoff: tuple   = DEFAULT_RETRY_BACKOFF,
    sleep: Any             = time.sleep,
    verify_round_trip: bool = True,
) -> Dict[str, Any]:
    """End-to-end prewarm.  Single chokepoint consumed by the Airflow
    DAG, the smoke harness, and the admin "refresh now" endpoint.

    Args:
      vault_config_path: yaml path (defaults to the prod PVC location).
      pvc_code_root:     PVC code dir prepended to sys.path so
                          ``qs_credentials`` is importable.
      retry_backoff:     per-ref retry schedule in seconds.  3-tuple by
                          default (initial + 2 retries with backoff).
      sleep:             injectable for tests so retries don't actually
                          sleep wall-clock time.

    Returns the summary dict (used by Airflow XCom / smoke / admin).

    Raises:
      ``FileNotFoundError`` / ``RuntimeError`` / ``ValueError`` from
      ``load_refs_from_yaml`` when the yaml is missing / malformed.
      ``RuntimeError`` from ``_verify_cache_written`` when post-run
      verification fails.
      ``RuntimeError`` when EVERY eligible ref failed (Vault outage
      signal -- DAG must escalate to operator alerts).
    """
    ensure_pvc_code_on_path(pvc_code_root)
    parsed = load_refs_from_yaml(vault_config_path)
    refs           = parsed["refs"]
    vault_settings = parsed["vault"]
    secrets_block  = parsed["secrets"]
    # Master switch guard: refuse the entire run early so the operator
    # sees ONE actionable error, not N copies of "vault is disabled"
    # (one per ref).  Honors the same 3-layer toggle the resolver uses.
    _assert_vault_enabled(secrets_block)
    # Loud refusal when the disk cache is disabled or pointed nowhere --
    # the prewarm would otherwise resolve into a process-local dict
    # that dies with the Airflow worker.
    _assert_disk_cache_enabled(vault_settings)
    disk_cache_path = (vault_settings.get("disk_cache_path") or "").strip()

    run_started_at = time.time()
    logger.info(
        "[prewarm] starting  refs=%d  disk_cache_path=%s",
        len(refs), disk_cache_path or "<unset>",
    )

    results: List[Dict[str, Any]] = []
    for name in sorted(refs.keys()):
        skip_reason = _is_skippable(name, refs[name])
        if skip_reason:
            logger.info(
                "[prewarm] ref=%r SKIPPED (%s)", name, skip_reason,
            )
            results.append({"name": name, "status": "skipped",
                             "reason": skip_reason, "elapsed_s": 0.0})
            continue
        results.append(_resolve_one(
            name, refs[name],
            retry_backoff=retry_backoff, sleep=sleep,
        ))

    n_total     = len(results)
    n_ok        = sum(1 for r in results if r["status"] == "ok")
    n_failed    = sum(1 for r in results if r["status"] == "failed")
    n_skipped   = sum(1 for r in results if r["status"] == "skipped")
    n_eligible  = n_total - n_skipped

    cache_info = _verify_cache_written(
        disk_cache_path,
        run_started_at=run_started_at,
        n_eligible_ok=n_ok,
    )

    # Round-trip read-back verification.  Catches the silent Fernet-
    # key-mismatch incident (Helm typo) BEFORE downstream workflows
    # fail with confusing decrypt errors.  Disabled in unit tests
    # where the resolver is stubbed (no real cache writes happened).
    round_trip_info: Dict[str, Any] = {"checked": 0, "not_readable": []}
    if verify_round_trip and n_ok > 0:
        ok_names = [r["name"] for r in results if r["status"] == "ok"]
        round_trip_info = _verify_round_trip(ok_names)

    summary: Dict[str, Any] = {
        "total":       n_total,
        "eligible":    n_eligible,
        "ok":          n_ok,
        "failed":      n_failed,
        "skipped":     n_skipped,
        "results":     results,
        "cache":       cache_info,
        "round_trip":  round_trip_info,
        "ran_at_utc":  datetime.now(timezone.utc).isoformat(
            timespec="seconds",
        ),
    }
    logger.info(
        "[prewarm] done  ok=%d failed=%d skipped=%d eligible=%d  "
        "cache_size=%s",
        n_ok, n_failed, n_skipped, n_eligible, cache_info.get("size"),
    )

    # FAIL-LOUD when EVERY eligible ref failed -- almost certainly a
    # Vault outage / wrong endpoint config / expired machine token.
    # Partial failures don't raise -- workflows reading still-fresh
    # refs keep working off the previous cache window.
    if n_eligible > 0 and n_failed == n_eligible:
        raise RuntimeError(
            f"[prewarm] ALL {n_failed} eligible refs failed -- Vault "
            "is likely down OR vault_config.yaml endpoint URLs are "
            "wrong.  See per-ref ERROR logs above for the underlying "
            "cause; do NOT silence this alert by raising the failure "
            "threshold -- the cache is now stale for every workflow."
        )

    return summary


__all__ = [
    "prewarm_vault_cache",
    "load_refs_from_yaml",
    "ensure_pvc_code_on_path",
    "DEFAULT_PVC_CODE_ROOT",
    "DEFAULT_VAULT_CONFIG",
    "DEFAULT_RETRY_ATTEMPTS",
    "DEFAULT_RETRY_BACKOFF",
]
