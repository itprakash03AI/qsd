"""
Federation Engine — Cross-Source Query Execution for Semantic Layer (Phase 54)

Generates and executes SQL from semantic layer metadata, supporting:
  1. Single-dataset execution (one or more S3/SQL sources with relationships)
  2. Multi-dataset merged execution (BO-style multiple data providers)
  3. DuckDB named secrets for multi-S3-endpoint queries in a single session
  4. Smart routing: S3 → DuckDB, SQL connectors → connector SDK, mixed → hybrid

The engine translates semantic layer column selections, filters, and conditions
into physical SQL, resolves connections, and returns results as Parquet files.
"""

from __future__ import annotations

import contextvars
import logging
import shutil
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from core.connectors.base import SourceStatementError, wrap_source_failure
from core.json_utils import sanitize_for_json
from core.s3_utilities import get_s3_access_mode

logger = logging.getLogger(__name__)


def _artifact_file_name(execution_id: str) -> str:
    """The result file's name for this execution AS THIS ATTEMPT writes it
    (2026-11-03, query pods phase 4): ``{id}.parquet``, or ``{id}.a{n}.parquet``
    when the run is a retry on another query pod -- the ONE spelling lives in
    ``core/reports/pagination.py`` (``artifact_file_name`` /
    ``artifact_attempt_scope``), so a fenced late writer of the first attempt
    can never overwrite the retry's file."""
    from core.reports.pagination import artifact_file_name
    return artifact_file_name(execution_id)


def _artifact_stem(execution_id: str) -> str:
    """The attempt-qualified stem of this execution's result file (``{id}``
    or ``{id}.a{n}``) -- every INTERMEDIATE file a build writes beside its
    artifact carries it too, so a retry's intermediates never collide with
    a fenced first attempt's still flushing on the same shared directory
    (2026-11-03, fourth review)."""
    return Path(_artifact_file_name(execution_id)).stem

# 2026-08-09 — the pre-2026-08-09 hardcoded default, kept ONLY as a last-ditch
# fallback if config cannot be imported.  Note it lacks the ``nfs/`` segment the
# configured path carries; see _default_output_dir.
_LEGACY_OUTPUT_DIR = "/usr/local/querystudioapi/data/downloads"


def _default_output_dir() -> str:
    """The configured shared downloads dir (``core.config.paths.downloads_dir``
    — the same source the BR raw_sql reader uses), resolved at call time.

    Mirrors ``core/cross_source_engine._default_output_dir`` deliberately: both
    engines write execution artifacts that OTHER pods must be able to read.
    """
    try:
        from core.config import paths as _paths
        d = str(_paths.downloads_dir)
        if d:
            return d
    except Exception as exc:  # pragma: no cover — config is always importable
        logger.error("federation_engine: could not resolve configured "
                     "downloads dir (%s) — falling back to legacy pod-local "
                     "path %s", exc, _LEGACY_OUTPUT_DIR)
    return _LEGACY_OUTPUT_DIR


# ═══════════════════════════════════════════════════════════════════════════════
# ROW-SECURITY SAFETY NET — make a bypassed RLS scope loudly visible
# ═══════════════════════════════════════════════════════════════════════════════


def _label_sides(per_side: List[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """Flatten per-side source lists, saying WHICH SIDE each came from.

    2026-09-17 (FB-10).  Each side is built independently by ``_build_query``,
    which labels its own base table ``"primary"`` -- correct in isolation.
    Concatenated, a merge therefore reported BOTH legs as ``primary`` and a
    union reported every leg as ``primary``.

    Cosmetic until you remember what this field is for: it is what an operator
    reads to confirm which half of a federated result came from where.  A
    wrong label makes the one diagnostic on the surface untrustworthy, which
    is worse than not having it -- an absent field prompts a question, a wrong
    one ends the investigation.

    The ORIGINAL ``type`` is preserved as ``role`` so nothing that already
    reads "primary"/"joined" loses information.
    """
    names = ["primary", "secondary"]
    out: List[Dict[str, Any]] = []
    for i, side in enumerate(per_side or []):
        side_name = names[i] if i < len(names) else f"side_{i + 1}"
        for entry in (side or []):
            e = dict(entry or {})
            e["role"] = e.get("type", "")
            e["side"] = side_name
            # The base table of a side IS that side; a table it joined to is
            # still a join, and calling it "secondary" would claim it is the
            # other DATASET.
            if e.get("type") == "primary":
                e["type"] = side_name
            out.append(e)
    return out


def _resolve_drill_columns(hierarchies: List[Dict[str, Any]],
                           drill: Dict[str, Any],
                           column_ids: List[int],
                           col_map: Dict[int, Any]) -> List[int]:
    """Turn a drill request into the dimension column ids to GROUP BY.

    A hierarchy is an ORDERED list of dataset columns, so "drill to level
    N" is "select levels 0..N as the dimensions".  Resolving to column ids
    means the result rejoins the ordinary column path: RLS, visibility by
    role, aggregation and the cost gates all apply unchanged, and there is
    no second builder.

    MEASURES ARE KEPT.  A drill changes which DIMENSIONS group the result,
    never what is being measured -- dropping the measures would silently
    turn a drill into a different report.

    Every refusal names the field and the reason: a drill that quietly did
    nothing is what this function exists to end.
    """
    hid = drill.get("hierarchy_id")
    if hid is None:
        raise ValueError("drill: hierarchy_id is required")
    match = next((h for h in hierarchies
                  if str(h.get("id")) == str(hid)), None)
    if match is None:
        raise ValueError(
            f"drill: hierarchy {hid!r} does not belong to this dataset. "
            f"Available: {[h.get('id') for h in hierarchies] or 'none'}")
    levels = match.get("levels") or []
    if not levels:
        raise ValueError(
            f"drill: hierarchy {match.get('name', hid)!r} declares no "
            f"levels, so there is nothing to drill into")

    raw_level = drill.get("level", len(levels) - 1)
    try:
        level = int(raw_level)
    except (TypeError, ValueError):
        raise ValueError(f"drill: level {raw_level!r} is not an integer")
    if not 0 <= level < len(levels):
        raise ValueError(
            f"drill: level {level} is outside hierarchy "
            f"{match.get('name', hid)!r}, which has {len(levels)} level(s) "
            f"(0..{len(levels) - 1})")

    drill_ids: List[int] = []
    for i, lv in enumerate(levels[:level + 1]):
        cid = lv.get("column_id") if isinstance(lv, dict) else lv
        if cid is None:
            raise ValueError(
                f"drill: level {i} of {match.get('name', hid)!r} declares "
                f"no column_id")
        if cid not in col_map:
            raise ValueError(
                f"drill: level {i} points at column {cid}, which is not in "
                f"this dataset -- the hierarchy and the dataset have drifted")
        if cid not in drill_ids:
            drill_ids.append(int(cid))

    # Keep every selected MEASURE; replace the dimensions with the drill
    # path.  A measure the caller chose is what they are drilling INTO.
    kept = [cid for cid in (column_ids or [])
            if cid in col_map
            and str((col_map[cid] or {}).get("column_type", "")).lower()
            in ("measure", "kpi", "calculated_metric")
            and cid not in drill_ids]
    return drill_ids + kept


def _warn_if_rls_policies_skipped(db, sql: str, *, dataset_id: int,
                                  execution_id: Optional[str]) -> None:
    """Emit a LOUD WARNING when a query runs with NO principal (user_ctx=None)
    yet references a table covered by an enabled row/column policy.

    This is a defence-in-depth net for the RLS engine: ``secure_sql`` is only
    applied when a principal is supplied, so a caller that forgets to thread
    ``user_ctx`` silently delivers unfiltered rows.  We deliberately do NOT
    fail-closed or inject a deny-by-default principal here, because some
    internal callers (e.g. the shared aggregate-cache materialiser) pass
    ``user_ctx=None`` on purpose to build an unrestricted result — a hard
    failure or empty-principal rewrite would break them.  Instead we surface
    the event so a genuine leak is auditable and gets a real fix.

    Best-effort and fully defensive: any error (row_security disabled, no
    sqlglot, DB hiccup) is swallowed — this must never break query execution.
    """
    try:
        from core.config import row_security as _rs_cfg
        if not bool(_rs_cfg.enabled):
            return
    except Exception:
        return

    # Collect enabled policies (principal-independent — we only care whether a
    # policy EXISTS for a referenced table, not whether it binds to a user).
    try:
        row_pols = db.list_row_policies(enabled_only=True) or []
        col_pols = db.list_column_policies(enabled_only=True) or []
    except Exception as exc:
        logger.debug("RLS safety-net policy lookup failed (non-fatal): %s", exc)
        return
    patterns = [p.get("table_pattern", "") for p in (row_pols + col_pols)
                if p.get("table_pattern")]
    if not patterns:
        return

    # Extract table references from the generated SQL.
    tables: List[str] = []
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(sql, dialect="duckdb")
        from core.row_security.rewriter import _resolved_table_ref
        for tbl in tree.find_all(exp.Table):
            tref = _resolved_table_ref(tbl)
            if tref:
                tables.append(tref)
    except Exception as exc:
        logger.debug("RLS safety-net table parse failed (non-fatal): %s", exc)
        return
    if not tables:
        return

    try:
        from core.row_security.resolver import table_matches_pattern
        hit = sorted({
            t for t in tables
            for pat in patterns
            if table_matches_pattern(t, pat)
        })
    except Exception as exc:
        logger.debug("RLS safety-net match failed (non-fatal): %s", exc)
        return
    if not hit:
        return

    # Identify the caller (first stack frame outside this module).
    caller = "<unknown>"
    try:
        import traceback
        for frame in reversed(traceback.extract_stack()[:-1]):
            if "federation_engine.py" not in (frame.filename or ""):
                caller = f"{frame.filename}:{frame.lineno} in {frame.name}"
                break
    except Exception:
        pass

    logger.warning(
        "ROW-SECURITY BYPASS: dataset=%s execution=%s ran with NO principal "
        "(user_ctx=None) but references RLS-protected table(s) %s — rows are "
        "UNFILTERED. Caller: %s. If this caller serves user-facing data it must "
        "thread user_ctx; if it is an intentional internal unrestricted query, "
        "this warning is expected.",
        dataset_id, execution_id, hit, caller,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# JOIN-PRUNER (federation) — synthesise secondary filters from primary bounds
# ═══════════════════════════════════════════════════════════════════════════════


def _federation_synth_filters_from_primary(
    primary_output_path: str,
    merge_keys: List[Dict[str, str]],
    secondary_dataset_id: int,
    db_manager,
) -> List[Dict[str, Any]]:
    """Read primary's output parquet metadata (no row scan), aggregate
    min/max for each merge-key's LEFT column, look up the RIGHT
    column's ``column_id`` in the secondary dataset's metadata, and
    return synth filter dicts in federation's expected shape:
    ``[{column_id, operator, value, value2?}]``.

    Returns empty list when:
      * pyarrow unavailable
      * primary parquet has no per-column stats for the merge keys
      * secondary dataset has no matching physical_name column

    Fail-OPEN at every step — pruning is an optimisation, not
    correctness.  Logged at debug when skipped.

    149.5 (2026-06-09) enhancements:
      * **Cardinality cost-gate**: skip the probe entirely when the
        primary's total row count exceeds
        ``federation.synth_filter_max_primary_rows`` (default 1M).
        Synthesising a [min, max] range over a billion-row primary
        spans the whole secondary anyway — wastes the read for no
        prune.
      * **IN-list for narrow primaries**: when primary's row count is
        below ``federation.synth_filter_in_list_max_rows`` (default
        2000), read the actual merge-key column values, dedupe, and
        emit an ``in`` filter when distinct_count <= 200.  Gives DuckDB
        EXACT-match pruning on secondary instead of a wide range.
      * **Telemetry**: log the synth-filter decision per merge key so
        the diagnose UI can render "between" vs "in (N values)" vs
        "skipped (anchor too wide)".
    """
    try:
        import pyarrow.parquet as pq
    except Exception:
        logger.debug("federation synth: pyarrow not available")
        return []

    # 149.5 — config-driven cost gates.  Hot-reloadable; defaults chosen
    # so most workloads engage the IN-list optimisation but a billion-
    # row anchor doesn't waste a column scan.
    _max_primary_rows = 1_000_000
    _in_list_max_rows = 2_000
    _in_list_max_distinct = 200
    try:
        from core.config import get_section as _gs
        _fcfg = (_gs("federation") or {})
        _max_primary_rows = int(_fcfg.get("synth_filter_max_primary_rows",
                                          _max_primary_rows) or _max_primary_rows)
        _in_list_max_rows = int(_fcfg.get("synth_filter_in_list_max_rows",
                                          _in_list_max_rows) or _in_list_max_rows)
        _in_list_max_distinct = int(_fcfg.get("synth_filter_in_list_max_distinct",
                                              _in_list_max_distinct) or _in_list_max_distinct)
    except Exception:
        pass

    # 1. Read primary's parquet metadata + aggregate per-column min/max.
    try:
        md = pq.read_metadata(primary_output_path)
    except Exception as exc:
        logger.debug("federation synth: read_metadata failed (%s)", exc)
        return []

    # 149.5 cardinality cost-gate.  num_rows from metadata is free (no
    # row scan).  Big anchor → bounds project to a wide range that
    # prunes nothing on secondary → net-negative read cost.
    _primary_rows = int(md.num_rows or 0)
    if _max_primary_rows > 0 and _primary_rows > _max_primary_rows:
        logger.info(
            "149.5: federation synth-filter SKIPPED — primary has %d rows "
            "(> cost-gate %d).  A wide [min, max] over a large anchor "
            "wouldn't prune the secondary; raise "
            "federation.synth_filter_max_primary_rows if your anchor's "
            "merge-key range is genuinely narrow.",
            _primary_rows, _max_primary_rows,
        )
        return []
    _left_cols = [str(mk.get("left") or "") for mk in merge_keys if mk.get("left")]
    if not _left_cols:
        return []
    _stats: Dict[str, Tuple[Any, Any]] = {}
    try:
        for rg_idx in range(md.num_row_groups):
            rg = md.row_group(rg_idx)
            for c_idx in range(rg.num_columns):
                col = rg.column(c_idx)
                _name = col.path_in_schema
                if _name not in _left_cols:
                    continue
                s = col.statistics
                if s is None or not s.has_min_max:
                    continue
                cur = _stats.get(_name)
                if cur is None:
                    _stats[_name] = (s.min, s.max)
                else:
                    _lo, _hi = cur
                    try:
                        _new_lo = _lo if s.min is None else (
                            s.min if _lo is None else min(_lo, s.min))
                        _new_hi = _hi if s.max is None else (
                            s.max if _hi is None else max(_hi, s.max))
                        _stats[_name] = (_new_lo, _new_hi)
                    except TypeError:
                        _stats.pop(_name, None)
    except Exception as exc:
        logger.debug("federation synth: stats walk failed (%s)", exc)
        return []
    if not _stats:
        return []

    # 2. Resolve right column physical_name → column_id in secondary dataset.
    try:
        ds = db_manager.get_dataset_full(secondary_dataset_id)
    except Exception as exc:
        logger.debug("federation synth: dataset lookup failed (%s)", exc)
        return []
    if not ds:
        return []
    _phys_to_cid: Dict[str, int] = {}
    for c in ds.get("columns", []) or []:
        _pn = c.get("physical_name")
        _cid = c.get("id")
        if _pn and _cid is not None:
            _phys_to_cid[str(_pn).lower()] = int(_cid)

    # 149.5 — IN-list opportunity: when primary is small enough to
    # afford a column read, try to emit ``in (v1, v2, ...)`` instead of
    # the wider ``between (lo, hi)``.  Reading the column is a single
    # parquet read (cheap when num_rows is low) and gives DuckDB
    # exact-match pruning on the secondary instead of a range that may
    # include many non-matching rows.
    _in_list_values: Dict[str, List[Any]] = {}
    if 0 < _primary_rows <= _in_list_max_rows:
        try:
            tbl = pq.read_table(primary_output_path, columns=_left_cols)
            for _name in _left_cols:
                try:
                    arr = tbl.column(_name)
                    _vals = arr.to_pylist()
                    _distinct = {v for v in _vals if v is not None}
                    if 0 < len(_distinct) <= _in_list_max_distinct:
                        # sort when comparable for stable downstream behaviour;
                        # fall back to insertion-order list when mixed types.
                        try:
                            _in_list_values[_name] = sorted(_distinct)
                        except TypeError:
                            _in_list_values[_name] = list(_distinct)
                except Exception:
                    continue
        except Exception as _in_exc:
            logger.debug(
                "149.5: in-list extraction failed (between fallback): %s",
                _in_exc,
            )

    # 3. Build synth filters.  Federation uses ``op="between"`` with
    # ``value`` + ``value2`` (per _apply_filters_to_df line 747).
    out: List[Dict[str, Any]] = []
    _synth_decisions: List[str] = []   # 149.5 telemetry — per-key op chosen
    for mk in merge_keys:
        _left = str(mk.get("left") or "")
        _right = str(mk.get("right") or "")
        if not _left or not _right:
            continue
        _bounds = _stats.get(_left)
        if not _bounds:
            continue
        _lo, _hi = _bounds
        if _lo is None or _hi is None:
            continue
        _cid = _phys_to_cid.get(_right.lower())
        if _cid is None:
            continue
        # 149.5 priority: IN-list (tightest) > EQ (singleton) > BETWEEN
        _in_vals = _in_list_values.get(_left)
        if _in_vals and len(_in_vals) > 1:
            out.append({"column_id": _cid, "operator": "in", "value": _in_vals})
            _synth_decisions.append(
                f"{_left}->{_right}: in ({len(_in_vals)} values)"
            )
        elif _lo == _hi:
            out.append({"column_id": _cid, "operator": "eq", "value": _lo})
            _synth_decisions.append(f"{_left}->{_right}: eq")
        else:
            out.append({
                "column_id": _cid, "operator": "between",
                "value": _lo, "value2": _hi,
            })
            _synth_decisions.append(f"{_left}->{_right}: between")
    if _synth_decisions:
        logger.info(
            "149.5: federation synth-filter chose %s (primary_rows=%d, "
            "in_list_cap=%d/%d)",
            "; ".join(_synth_decisions), _primary_rows,
            _in_list_max_rows, _in_list_max_distinct,
        )
    return out


def _record_dataset_execution_path(execution_id: str, dataset_id) -> None:
    """AQD-01 (2026-09-23) -- put a semantic-layer execution on the admin
    "last N queries" list (/api/admin/queries/diagnose/recent).

    That list is built from the ``record_execution_path`` registry, and the
    product's main reporting path never wrote to it: a business report run
    with ``force_refresh`` came back 200 with 57 rows and the list said
    ``{"queries": []}`` in the same process.  The only report caller was the
    legacy parametric-reports route being decommissioned (FB-60).  Recording
    here, in the one wrapper every dataset query passes through, covers the
    report route, a view over a report, dashboards and exports at once.

    FIRST WRITER WINS: an entry point that already recorded a more specific
    branch for this id (a feed run, a DataFlow stage) keeps it.  Diagnostics
    must never break a query, so any failure is logged and dropped.
    """
    try:
        from core.brain.scan_plan import record_execution_path_if_absent
        record_execution_path_if_absent(
            execution_id, "semantic_dataset", notes=f"dataset_id={dataset_id}")
    except Exception:                  # pragma: no cover - defensive
        logger.debug("could not record execution path for %s", execution_id,
                     exc_info=True)


# ═══════════════════════════════════════════════════════════════════════════════
# Data classes
# ═══════════════════════════════════════════════════════════════════════════════

#: The statement the SOURCE actually received, published by
#: ``_transpile_for_connector`` (the one point where generated SQL leaves
#: DuckDB-land) and read when a FederationResult is assembled.  A
#: ContextVar because the two are separated by several helpers whose return
#: contracts are shared with other callers, and because the engine is used
#: from more than one thread -- a plain attribute would cross-attribute one
#: execution's SQL onto another's result, which is worse than not having it.
_EXECUTED_SQL: "contextvars.ContextVar[str]" = contextvars.ContextVar(
    "qs_federation_executed_sql", default="")


@dataclass
class FederationResult:
    """Result of a federated dataset execution."""
    execution_id: str
    dataset_id: int
    output_path: str = ""
    total_rows: int = 0
    columns: List[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    sql_generated: str = ""
    #: The statement the SOURCE actually received.
    #:
    #: 2026-09-15 -- ``sql_generated`` is the engine's DuckDB-dialect SQL,
    #: BEFORE ``_transpile_for_connector`` rewrites it for the target.  On
    #: Oracle it therefore reports ``... LIMIT 10``, which Oracle rejects
    #: (ORA-03047) -- so an operator debugging a failing report copied the
    #: diagnostic into sqlplus and chased a syntax error the product had
    #: already fixed for them.  The answer was right and the diagnostic
    #: lied.  Additive, and empty when no transpile happened (DuckDB paths),
    #: so no existing caller changes.
    sql_executed: str = ""
    sources_used: List[Dict[str, Any]] = field(default_factory=list)
    merged_dataset_id: Optional[int] = None
    primary_rows: int = 0
    secondary_rows: int = 0
    # Phase 55: Aggregation cache metadata
    cache_hit: bool = False
    cache_age_seconds: float = 0.0
    cache_entry_id: Optional[int] = None
    cache_grain: str = ""
    # 2026-08-09 silent-truncation fix (drilldown audit D1): the EFFECTIVE
    # row limit the engine actually applied — after the federation.
    # max_result_rows clamp in execute_dataset_query — NOT the limit the
    # caller asked for.  The truncation verdict downstream
    # (business_reports_api._with_contract_keys) must compare total_rows
    # against THIS value; comparing against the caller's (larger) limit
    # reported ``truncated: False`` on a result silently cut at the clamp.
    row_limit: Optional[int] = None
    # Engine-computed truncation verdict, stamped only when the engine has
    # evidence the caller's simple ``total >= limit`` check cannot see
    # (e.g. a merged query whose SIDE was cut before the merge).  None =
    # no engine override; downstream computes from total_rows/row_limit.
    truncated: Optional[bool] = None
    # True when the result was cut at the limit WITHOUT an ORDER BY: the
    # kept rows are then an arbitrary sample (source-agnostic disclosure —
    # parallel engines like Trino/Snowflake/Databricks return a different
    # sample run to run; DuckDB's insertion-order stability is an
    # implementation default, not a contract).  Disclosed, never "fixed"
    # by injecting an ORDER BY — that would change query cost/plans on
    # working reports.
    unstable_truncation: Optional[bool] = None
    # 2026-08-22 dataset UNION — per-side alignment disclosure:
    # {"columns": [...unified...], "sides": [{dataset_id, execution_id,
    #  rows, columns, padded_columns}], "type_promotions": [...],
    #  "on_mismatch": "pad_nulls"|"fail"}.  A column one side lacks is
    #  NULL-padded BY NAME — never silently dropped — and this report is
    #  where that decision is DISCLOSED.  None on non-union results.
    union_report: Optional[Dict[str, Any]] = None
    # 2026-09-07 result cache (core/dataset_result_cache.py).  SEPARATE
    # from ``cache_hit``, which the aggregation cache already owns: a
    # consumer must be able to tell "answered from a pre-aggregated cube"
    # from "answered from a stored copy of this exact query", and a
    # freshness verdict only means something for the latter.
    result_cache_hit: Optional[bool] = None
    # 2026-09-27 -- WHICH ENGINE ANSWERED (core/engine_attribution.py key:
    # duckdb / hybrid / trino / oracle / agg_cache / result_cache ...).
    # Stamped by the route that ran; None = not recorded, which the viewer
    # renders as such, never as a default.  ``execution_`` prefix because the
    # report envelope's bare ``engine`` already means the PRESENTATION engine
    # (server / client, core/reports/contract.py) -- one word, two meanings,
    # would be the identity bug this repo has paid for before.
    execution_engine: Optional[str] = None
    #: 2026-11-01 -- the version each Iceberg table of the run was read at
    #: (``iceberg_versions.run_record``: table, snapshot_id, committed_at,
    #: pinned, decided_by, words); None = the run read no Iceberg table.
    iceberg_versions: Optional[List[Dict[str, Any]]] = None
    #: "verified" (fingerprint re-checked against the source and
    #: unchanged) or "unknown" (nothing to check against — a connector
    #: source, an unregistered table, or the probe declined).  NEVER
    #: silently promoted to "fresh": a consumer that cannot tell the
    #: difference will assume the stronger claim.
    cache_freshness: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "execution_id": self.execution_id,
            "dataset_id": self.dataset_id,
            "output_path": self.output_path,
            "total_rows": self.total_rows,
            "columns": self.columns,
            "duration_seconds": self.duration_seconds,
            "sql_generated": self.sql_generated,
            "sql_executed": self.sql_executed,
            "sources_used": self.sources_used,
            "merged_dataset_id": self.merged_dataset_id,
            "primary_rows": self.primary_rows,
            "secondary_rows": self.secondary_rows,
            "cache_hit": self.cache_hit,
            "cache_age_seconds": self.cache_age_seconds,
            "cache_entry_id": self.cache_entry_id,
            "cache_grain": self.cache_grain,
        }
        # D1 2026-08-09: additive keys, emitted only when stamped — absent
        # keys keep every setdefault-based consumer behaving exactly as
        # before for paths that don't stamp them.
        if self.row_limit is not None:
            d["row_limit"] = self.row_limit
        if self.truncated is not None:
            d["truncated"] = self.truncated
        if self.unstable_truncation is not None:
            d["unstable_truncation"] = self.unstable_truncation
        if self.union_report is not None:
            d["union_report"] = self.union_report
        if self.result_cache_hit is not None:
            d["result_cache_hit"] = self.result_cache_hit
        if self.cache_freshness is not None:
            # The freshness verdict rides ALONGSIDE the hit flag, never
            # instead of it: a consumer that reads only one of the two
            # would either not know it was cached, or not know how well
            # that was checked.  Both or neither.
            d["cache_freshness"] = self.cache_freshness
        if self.execution_engine:
            from core.engine_attribution import with_engine as _with_engine
            _with_engine(d, self.execution_engine, field="execution_engine")
        if self.iceberg_versions is not None:
            d["iceberg_versions"] = list(self.iceberg_versions)
        return d


#: FB-26 -- the aggregations only a NUMERIC column supports, and the stored
#: data_type values that can never be numeric.  Unknown ("") is not refused:
#: an unrecognised spelling and a text column are different facts.
_NUMERIC_ONLY_AGGREGATIONS = frozenset({"SUM", "AVG"})
_NON_NUMERIC_DATA_TYPES = frozenset({"string", "boolean", "date"})


@dataclass
class ColumnSelection:
    """A column selected by the user for query execution."""
    column_id: int
    physical_name: str
    friendly_name: str
    column_type: str          # dimension | measure | detail | kpi | calculated_metric
    aggregation: str = ""     # sum, avg, count, min, max, count_distinct
    source_table: str = ""    # resolved source table for multi-table datasets
    expression: str = ""      # Phase 101: SQL expression for calculated metrics
    is_metric: bool = False   # Phase 101: True for CalculatedMetric entries
    data_type: str = ""       # FB-26: string|number|date|boolean; "" = unknown
    source_data_type: str = ""  # FB-42: what the SOURCE declares (from the column catalog); "" = unknown


#: sqlglot spells duckdb's ``TIMESTAMP '...'`` as TIMESTAMPNTZ; the other
#: members are here so a tz-aware or precision-qualified literal is covered
#: too rather than silently falling through to CAST.
_ORACLE_TS_TYPES = frozenset({
    "TIMESTAMP", "TIMESTAMPNTZ", "TIMESTAMPTZ", "TIMESTAMPLTZ",
    "TIMESTAMP_MS", "TIMESTAMP_NS", "TIMESTAMP_S",
})


def _oracle_temporal_literal(node):
    """Rewrite ``CAST('2025-09-30' AS DATE)`` to Oracle's ``TO_DATE``.

    2026-08-13.  ``_transpile_for_connector`` renders with
    ``read="duckdb", write=<target>``, and sqlglot's Oracle generator emits
    CAST for a typed temporal literal.  ORACLE CONVERTS A STRING TO DATE
    THROUGH ``NLS_DATE_FORMAT`` -- commonly ``DD-MON-RR`` -- so
    ``CAST('2025-09-30' AS DATE)`` raises ORA-01861 on any session whose
    format is not ISO.  ``TO_DATE`` with an explicit mask is
    format-independent, which is the same rule the ETL side already
    records: ``TO_DATE(..., 'DD-MON-RR')`` is an EXPLICIT PARSE, not
    redundant.

    NOTE this is only needed on the FEDERATION path.  The published-view /
    feed wrap parses AND renders as the target dialect, and oracle→oracle
    already yields TO_DATE.  I claimed federation was Oracle-safe for the
    same reason and it is not -- it reads as duckdb.

    Only a STRING LITERAL inside the cast is rewritten: ``CAST(col AS DATE)``
    is a real column conversion and must be left exactly as written.
    """
    from sqlglot import exp

    if not isinstance(node, exp.Cast):
        return node
    inner = node.this
    if not (isinstance(inner, exp.Literal) and inner.is_string):
        return node
    tname = getattr(node.to.this, "name", str(node.to.this)).upper()
    if tname == "DATE":
        return exp.func("TO_DATE", inner, exp.Literal.string("YYYY-MM-DD"))
    if tname in _ORACLE_TS_TYPES:
        fmt = ("YYYY-MM-DD HH24:MI:SS.FF" if "." in str(inner.this)
               else "YYYY-MM-DD HH24:MI:SS")
        return exp.func("TO_TIMESTAMP", inner, exp.Literal.string(fmt))
    return node


def filter_value_problem(value: Any, data_type: str, column: str) -> Optional[str]:
    """None when ``value`` can be written as ``data_type``, else ONE sentence
    saying why not (2026-10-25: the owner, "we should have all validation
    rather than just allowing to create a report blindly").  THE check, used
    at save (business_reports_api) and at run (_checked_literal).  A typed
    literal (``DATE '...'``) and NULL always pass; unknown / text types pass."""
    if value is None or isinstance(value, bool):
        return None
    from core.column_types import normalise_sql_type
    from core.query_compiler import _TYPED_LITERAL_RE, _numeric_literal, temporal_literal
    kind = normalise_sql_type(data_type) or (data_type or "").strip().lower()
    s = str(value).strip()
    if isinstance(value, (int, float)) or _TYPED_LITERAL_RE.match(s):
        return None
    if kind in ("number", "numeric", "decimal", "integer", "int", "bigint", "double", "float", "real"):
        if _numeric_literal(s) is None:
            return (f"'{s}' is not a number, but '{column}' holds numbers in its source -- "
                    f"use a number like 42 or 3.5.")
    elif kind in ("date", "datetime", "timestamp"):
        if not temporal_literal(s):
            return (f"'{s}' is not a date, but '{column}' holds dates in its source -- "
                    f"use YYYY-MM-DD (or YYYY-MM-DD HH:MM:SS).")
    elif kind in ("boolean", "bool"):
        if s.lower() not in ("true", "false", "1", "0", "yes", "no", "y", "n", "t", "f"):
            return f"'{s}' is not true or false, but '{column}' holds true / false in its source."
    return None


@dataclass
class FilterSpec:
    """A filter applied by the user."""
    column_id: int
    physical_name: str
    operator: str             # eq, neq, gt, gte, lt, lte, in, not_in, like, between, is_null, is_not_null
    value: Any = None
    value2: Any = None        # for 'between' operator
    source_table: str = ""
    # 2026-08-13 -- the column's semantic type (string|number|date|boolean),
    # carried so the SQL literal can be TYPED.  Without it every value was
    # emitted as a quoted string, which DuckDB implicitly casts and Trino
    # REFUSES: "Cannot apply operator: date = varchar(27)".  Empty means
    # unknown, and unknown keeps the old quoted-string behaviour.
    data_type: str = ""
    # 2026-10-25 -- the column's type IN THE SOURCE (the catalog's, FB-42).
    # When known it decides how a value is WRITTEN: the dataset's data_type
    # is a label ("id" is a dimension, so "string"), and a literal written to
    # the label was a Trino TYPE_MISMATCH -- "IN value and list items must be
    # the same type ... bigint and varchar(1)" (the owner, report 254).
    source_data_type: str = ""


#: Every key a filter dict may legitimately carry on the way into
#: ``_resolve_filters``.  A key OUTSIDE this set is refused (see that method)
#: because ``filters`` is untyped in the request schema, so a misspelling
#: like ``values`` for ``value`` otherwise costs the predicate its operand
#: and returns MORE rows with no visible signal.
#:
#: DERIVED FROM REAL PAYLOADS, NOT GUESSED — a set that is too narrow breaks
#: working reports, which is why each member is justified:
#:   column_id/operator/value/value2  read by _resolve_filters itself, and
#:                                    exactly what the frontend sends
#:                                    (DatasetQueryPanel, BusinessReportBuilder,
#:                                    PivotReportBuilder) and what the
#:                                    cascading-parameter builders in
#:                                    business_reports_api construct.
#:   column                           present on EVERY stored filter in
#:                                    federation_executions, saved_queries
#:                                    and published_views (the human-readable
#:                                    name carried alongside the id).
#:   data_type                        present on stored saved_queries /
#:                                    published_views filters.
#:   source_table/physical_name       FilterSpec fields a caller may pass
#:                                    through pre-resolved.
_FILTER_KEYS = frozenset({
    "column_id", "operator", "value", "value2",
    "column", "data_type", "source_table", "physical_name",
})


@dataclass
class OrderBySpec:
    """Sort specification."""
    column_id: int
    physical_name: str
    direction: str = "asc"    # asc | desc


# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

# Operators mapped to SQL fragments
_OP_MAP = {
    "eq":          "= {v}",
    "neq":         "!= {v}",
    "gt":          "> {v}",
    "gte":         ">= {v}",
    "lt":          "< {v}",
    "lte":         "<= {v}",
    "like":        "LIKE {v}",
    "not_like":    "NOT LIKE {v}",
    "is_null":     "IS NULL",
    "is_not_null": "IS NOT NULL",
}

# Operators handled by their own branch in _filter_to_sql rather than by a
# template — a template substitutes the whole quoted literal, which cannot
# express an IN-list, a BETWEEN pair, or a wildcard that belongs INSIDE the
# quotes.
_BRANCH_OPS = frozenset({
    "in", "not_in", "between",
    "starts_with", "ends_with", "contains", "not_contains",
})

# 2026-08-31 — THE filter vocabulary, in one place.
#
# The report builder offered "Starts With" and "Ends With" while this engine
# implemented neither, so a report saved with one returned 200 and was then
# permanently unrunnable: 400 on execute, 500 on every export, and nothing at
# save time to warn the author.  The engine's own refusal message was also
# assembling its "Supported:" list inline, so it could not stay true as the
# branch operators grew.  One name, read by the engine's error message and by
# the API's save-time validation, so a UI/engine mismatch is caught where the
# author can still fix it.
SUPPORTED_FILTER_OPERATORS = frozenset(_OP_MAP) | _BRANCH_OPS

#: Operators that take no operand.
_NO_VALUE_OPS = frozenset({"is_null", "is_not_null"})


def is_unfilled_filter(operator: Any, value: Any, value2: Any = None) -> bool:
    """True when a filter row was never given the value its operator needs.

    2026-10-03 -- THE answer to "is this filter row filled in?", asked by the
    report save gate (``business_reports_api._refuse_unfilled_filters``) so a
    report cannot be SAVED with what ``_filter_to_sql`` refuses to RUN.  The
    owner's report carried ``{"operator": "eq", "value": ""}`` from an
    untouched "Add Filter" row and answered 0 rows while its dataset
    returned 4.  An empty string is unfilled; ``is_null`` / ``is_not_null``
    are the spellings for a missing value.
    """
    op = str(operator or "eq")
    if op in _NO_VALUE_OPS:
        return False
    if op in ("in", "not_in"):
        return not FederationEngine._coerce_in_list(value)
    if op == "between":
        lo, hi = value, value2
        if hi is None and isinstance(lo, (list, tuple)) and len(lo) == 2:
            lo, hi = lo[0], lo[1]
        return lo is None or hi is None or lo == "" or hi == ""
    return value is None or (isinstance(value, str) and value == "")

# Whitelisted aggregation functions — only these are allowed in generated SQL
VALID_AGGREGATIONS = {"SUM", "AVG", "COUNT", "MIN", "MAX", "COUNT_DISTINCT"}

# Valid sort directions
VALID_DIRECTIONS = {"ASC", "DESC"}

# S3-type connection types that use DuckDB
S3_CONNECTION_TYPES = {"s3", "s3_minio", "s3_compatible"}

# SQL connector types: DELETED 2026-09-05, not delegated.
#
# ``SQL_CONNECTION_TYPES`` lived here with EIGHT entries and no readers
# at all -- this module routes on
# ``core.connection_manager._is_sql_connector_type`` (the registry).  Two
# of its entries, ``postgresql`` and ``mysql``, were never registered
# connectors: ``get_connector("postgresql", ...)`` raises
# ``ValueError: Unsupported connection type``.  So the only thing it did
# was tell the next reader that this product supports two databases it
# cannot open -- ``core/dataflow/stages/sql_query_stage.py`` says so in a
# comment, and had to write code to avoid believing it.
#
# The one answer is ``core.connectors.SQL_EXECUTABLE_TYPES``, DERIVED
# from the registry.  Same treatment the dead ``_SQLGLOT_WRITE_DIALECTS``
# copies got above, for the same reason: a vocabulary with no readers can
# only drift and mislead.

# 2026-08-09 dialect fix (source-agnostic audit §3): the engine generates
# DuckDB-dialect SQL (ANSI double-quoted identifiers + LIMIT) and used to run
# it VERBATIM on external engines.  Spark SQL treats "x" as a STRING LITERAL
# → a Databricks dataset report selected constant strings instead of columns
# (silently wrong data); Oracle rejects LIMIT → ORA-00933 on every dataset
# report.
#
# 2026-08-19 that fix was LIFTED OUT of this module into
# ``core/sql_connector_dialect.py`` so every route shares one transpile
# chokepoint; ``_transpile_for_connector`` below delegates there.  The two
# maps that used to live here (``_SQLGLOT_WRITE_DIALECTS`` and
# ``_VERBATIM_SAFE_DIALECTS``) were copied rather than moved and had NO
# readers left — dead vocabularies that could only drift from the live one
# and mislead the next reader into editing them.  Deleted 2026-09-05.

def _parts_rows_per_part() -> int:
    """Rows per part for a partitioned build -- the SAME knob the published
    view lane reads (``core.config.feed_generation.parts_rows_per_part``).

    One config key, two lanes: a part size that differed by lane would make
    the same query produce differently-shaped artifacts depending on which
    surface ran it.  Read at CALL time, never captured at import, because a
    persisted ``config.json`` defeats a default resolved once.
    """
    try:
        from core.config import feed_generation as _fg
        return max(1, int(getattr(_fg, "parts_rows_per_part", 5_000_000)))
    except Exception:                                        # noqa: BLE001
        logger.debug("parts_rows_per_part unreadable -- using 5,000,000",
                     exc_info=True)
        return 5_000_000


def dataset_partition_config(ds: Dict[str, Any]) -> Dict[str, Any]:
    """The dataset's DECLARED progressive-scan config, or ``{}``.

    2026-09-05.  The reports lane's answer to the question the published
    view lane answers with ``query_config.partition_config``: reports come
    from DATASETS, not from saved queries, so the producer is different and
    had to be worked out rather than assumed.

    WHERE IT LIVES, AND WHY THERE ARE TWO HOMES.  A TABLE-sourced dataset
    hangs it off the ``source_tables`` entry it describes::

        "source_tables": [
            {"connection_id": 3, "table": "hive.sales.orders",
             "partition_config": {"column": "region", "max_buckets": 32}}
        ]

    A dataset created in the wizard's **sql** mode has a ``base_query`` and
    an EMPTY ``source_tables``, so that home DOES NOT EXIST for it -- and a
    custom-SQL dataset over a huge Starburst table is precisely the case
    progressive loading exists for.  2026-09-05 round 3 therefore added the
    DATASET-LEVEL declaration, ``business_datasets.partition_config``::

        {"id": 12, "base_query": "SELECT ... FROM hive.sales.orders",
         "source_tables": [],
         "partition_config": {"column": "region", "max_buckets": 32}}

    That is a real COLUMN, which is not free on this platform: a new TABLE
    self-creates via ``create_all``, a new COLUMN does not (alembic is never
    invoked at runtime), so it ships with a ``_MIGRATIONS`` entry in
    ``core/database.py`` -- without which it would exist in the model and on
    no deployed pod.  It was chosen over a SYNTHETIC ``source_tables`` entry
    because a config-only entry is not a source table: every reader here
    treats a non-empty ``source_tables`` as "this dataset names tables"
    (``_base_from_expression`` reads ``source_tables[0]["table"]``), and the
    dataset editor rewrites that list from rows that all name a connection
    and a table -- so a synthetic entry would be silently deleted by the
    next save.  Dataset scope is also what the refusal rule below has always
    said the scope is: one dataset has one partition plan.

    The KEY SHAPE IS THE PUBLISHED VIEW'S, verbatim (``column``, ``enabled``,
    ``max_buckets``, ``max_concurrent``, ``target_rows_per_bucket``,
    ``bucket_size``, ``bucket_strategy``, ``discovery_sql``,
    ``discovery_with_counts``, ``discovery_wrap``, ``preflight_count``,
    ``max_discovery_values``) -- see
    ``api.published_views_api._partition_config``.  One vocabulary for one
    question; an operator who has configured one lane can read the other.

    THE PRODUCER IS ALREADY DECLARED.  ``DatasetConfigModel.source_tables``
    is ``List[Dict[str, Any]]``, so pydantic keeps the key instead of
    dropping it, and ``db.update_dataset`` stores ``source_tables`` whole.
    That is not a detail: on 2026-09-05 the published-view lane was
    unreachable on every view that could exist because ``QueryConfigModel``
    did not declare ``partition_config`` and a save returned 200 having
    stored nothing.  Reading a knob out of a JSON blob is only safe while
    the WRITE side keeps it, which
    ``TestDatasetPartitionConfigRoundTrip`` holds by executing the save.

    TWO ENTRIES THAT DISAGREE ARE REFUSED, not resolved by position: a
    dataset whose source tables declare DIFFERENT partition columns has no
    single answer, and picking the first would make the plan depend on list
    order.  ``{}`` (run whole) is the honest response, and the reason is
    stamped on the execution by the caller.
    """
    seen: List[Dict[str, Any]] = []
    # The dataset-level declaration is ONE MORE DECLARATION, not a
    # precedence rule.  Making it "win" over a source-table entry would be
    # a second way to answer one question, and the loser would be a
    # setting the author can see stored and cannot see applied -- which is
    # the whole failure this feature keeps hitting.  It goes into the same
    # list and through the same agreement test, so a dataset that declares
    # two different plans is REFUSED by name exactly as two source tables
    # declaring two different plans already are.
    _ds_level = ds.get("partition_config")
    if isinstance(_ds_level, dict) and _ds_level:
        seen.append(_ds_level)
    for st in (ds.get("source_tables") or []):
        if not isinstance(st, dict):
            continue
        part = st.get("partition_config")
        if isinstance(part, dict) and part:
            seen.append(part)
    if not seen:
        return {}
    columns = {str(p.get("column") or "").strip() for p in seen}
    if len(columns) > 1:
        logger.warning(
            "dataset declares %d DIFFERENT partition columns (%s) -- running "
            "the query whole; one dataset, one partition column",
            len(columns), ", ".join(sorted(columns)))
        return {"column": "", "conflict": sorted(columns),
                "conflict_kind": "column"}

    # 2026-09-05 round 2 -- EVERY OTHER KNOB HAS TO AGREE TOO.
    #
    # This compared ``column`` and then returned ``dict(seen[0])``, so
    # ``enabled``, ``max_buckets``, ``discovery_sql`` and ``preflight_count``
    # WERE resolved by position -- the exact thing the docstring above says
    # is refused.  Executed: the same two declarations gave FEATURE OFF in
    # one list order and FEATURE ON in the other, and ``_carry_scan_config``,
    # ``create_dataset`` and PUT all rebuild that list.
    #
    # An ABSENT key counts as a disagreement: absent means "take the
    # default", which is a different instruction from a value.
    import json as _json

    #: A key that is ABSENT is not a key set to None -- absent means "take
    #: the default", which is a different instruction from a value.  This
    #: sentinel keeps the two distinguishable in the comparison below.
    _UNSET = "__QS_KEY_ABSENT__"

    def _norm(p, k):
        if k not in p:
            return _UNSET
        try:
            return _json.dumps(p[k], sort_keys=True, default=str)
        except Exception:              # noqa: BLE001
            return repr(p[k])

    # ``column`` is excluded because the branch above already compared it
    # STRIPPED; leaving it in would flag "region" vs " region " as a
    # conflict the caller has already been told is not one.
    knobs = sorted({k for p in seen for k in p} - {"column"})
    disagreed = [k for k in knobs if len({_norm(p, k) for p in seen}) > 1]
    if disagreed:
        logger.warning(
            "the dataset's source tables disagree on partition setting(s) "
            "%s -- running the query whole; the order of a JSON list is "
            "not a declaration", ", ".join(disagreed))
        return {"column": "", "conflict": disagreed,
                "conflict_kind": "settings"}
    return dict(seen[0])


# Valid merge types for pd.merge
# 2026-10-04 -- the merge-type vocabulary is THE cross-source capability's
# (core.executors.cross_source_combine.normalise_join_how): inner / left /
# right / full (also "outer") / cross.  The local set that lived here knew
# "outer" but not "full", while DatasetMergeRequest validates "full" -- so a
# FULL merge passed the route and was refused here.

# Thread lock for DuckDB extension loading (shared with data_grid_api)
_ext_lock = threading.Lock()


# ═══════════════════════════════════════════════════════════════════════════════
# Federation Engine
# ═══════════════════════════════════════════════════════════════════════════════


def _is_temporal_column(col: Dict[str, Any]) -> bool:
    """A dataset column the product types as a date/time (``data_type``)."""
    return str((col or {}).get("data_type") or "").lower() in (
        "date", "datetime", "timestamp", "time")


def _contains_text_clause(phys_sql: str, search: str) -> str:
    """``LOWER(CAST(<col> AS VARCHAR)) LIKE '%<search>%'`` with the search
    text ESCAPED: a quote is doubled, and a ``%`` / ``_`` the user typed is a
    character to find, not a wildcard (2026-10-24, the value-list search)."""
    bs = "\\"
    esc = (str(search).lower().replace(bs, bs + bs).replace("%", bs + "%")
           .replace("_", bs + "_").replace("'", "''"))
    return f"LOWER(CAST({phys_sql} AS VARCHAR)) LIKE '%{esc}%' ESCAPE '{bs}'"


def _lov_temporal_value(v: Any) -> Any:
    """A date/time value as a filter can USE it (2026-10-02).

    The S3/DuckDB road hands a DATE back as a pandas Timestamp, which JSON
    renders ``2026-01-03T00:00:00`` -- DuckDB casts that back to a date, but
    Trino refuses ``CAST('2026-01-03T00:00:00' AS DATE)``, and it is not what
    a person means by a business date.  Midnight -> ``YYYY-MM-DD``; any other
    time -> ``YYYY-MM-DD HH:MM:SS`` (the spelling every engine reads).
    Anything that is not a date/time passes through untouched."""
    import datetime as _dt
    to_py = getattr(v, "to_pydatetime", None)
    if callable(to_py):
        v = to_py()
    if isinstance(v, _dt.datetime):
        if (v.hour, v.minute, v.second, v.microsecond) == (0, 0, 0, 0):
            return v.date().isoformat()
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, _dt.date):
        return v.isoformat()
    return v

def _base_query_for_duckdb(sql: str, declared: Optional[str] = None) -> str:
    """A dataset's custom SQL as QueryStudio's own engine runs it, read in the
    dialect the CONNECTION declares (``config.sql_dialect``), else the
    deployment's, else a recorded guess (``sql_dialect_translator.
    translate_for_qs_engine``).  Fail-open on a translation error; a declared
    dialect the translator does not know refuses."""
    from core.sql_dialect_translator import UnknownSourceDialect, translate_for_qs_engine
    try:
        out, info = translate_for_qs_engine(sql, declared)
    except UnknownSourceDialect:
        raise
    except Exception as exc:  # noqa: BLE001 -- fail-open, like the raw-SQL path
        logger.debug("[federation] dataset SQL translation skipped: %s", exc)
        return sql
    if info.get("from"):
        logger.info("[federation] SQL read as %s (%s) for QueryStudio's engine",
                    info["from"], info["how"])
    return out


class FederationEngine:
    """Executes queries against semantic layer datasets.

    Resolves connections, generates SQL from semantic layer metadata,
    and uses DuckDB named secrets for multi-S3-endpoint federation.
    """

    def __init__(self, db_manager, output_dir: Optional[str] = None):
        self._db = db_manager
        # 2026-08-09: was a hardcoded "/usr/local/querystudioapi/data/downloads".
        # That literal is missing the ``nfs/`` segment the configured default
        # carries, so it pointed at a pod-local directory nothing else reads —
        # broken SAME-POD, not just cross-pod, and invisible to the reports and
        # published-api pods entirely.  Resolved from config at call time (the
        # identical fix and helper shape as core/cross_source_engine.py), so a
        # future caller cannot reintroduce it by omitting the argument.
        self._output_dir = output_dir or _default_output_dir()

    # ── Public API ────────────────────────────────────────────────────────────

    def execute_dataset_query(self, **kwargs) -> "FederationResult":
        """PUBLISH the execution id for the whole call, then run it.

        2026-09-04.  Deep modules stamp their findings against "the
        current execution": ``scan_truncation`` records a capped S3
        listing, ``iceberg_reader`` records pruning, and the completeness
        certificate is DOWNGRADED from those records.  They resolve it
        through ``get_current_execution_id()``, which the feed engine and
        both dispatchers set — and the report path never did.

        The consequence was silent and serious.  A hive table over the
        5000-file listing cap is truncated to a SUBSET, so the query
        returns FEWER ROWS than the data holds; the federation call site
        invokes ``surface_truncated_listing`` with no execution_id and no
        out_meta, so the verdict resolved to nothing and reached neither
        the diagnostic store nor the certificate.  The report came back
        looking complete.  Verified by execution before the fix:
        ``certificate`` None, ``file_cap`` absent.

        A ContextVar rather than a new parameter, because the gap is not
        one call site: EVERY deep module on this path was cut off from
        the execution in the same way, and the mechanism is already built
        on one.  Restored in ``finally`` so a nested or subsequent
        execution on this thread cannot be stamped with a stale id —
        mis-attributed diagnostics are worse than none.

        A thin delegating wrapper (rather than wrapping the body in a
        ``with``) keeps the 500-line implementation untouched: the change
        is the publishing, not the query.
        """
        from core.query_diagnostic_store import (
            get_current_execution_id as _get_eid,
            set_current_execution_id as _set_eid,
        )
        import uuid as _uuid

        eid = kwargs.get("execution_id") or str(_uuid.uuid4())
        kwargs["execution_id"] = eid
        prev = None
        published = False
        try:
            prev = _get_eid()
            _set_eid(eid)
            published = True
        except Exception as exc:      # pragma: no cover - defensive
            # Diagnostics must never break a query.
            logger.debug("could not publish execution id (%s)", exc)
        # 2026-09-15 -- clear the executed-SQL slot for THIS execution and
        # restore it afterwards, for the same reason the execution id is
        # restored: a stale value is worse than none.  Without the reset a
        # DuckDB-only run (which never transpiles) would report the previous
        # Oracle run's statement as the SQL its source received.
        _sql_token = _EXECUTED_SQL.set("")
        _record_dataset_execution_path(eid, kwargs.get("dataset_id"))
        # 2026-10-07 -- a report's Refresh (``force_refresh``) asks for the
        # NEWEST committed Iceberg snapshot, not just "skip the cube".  The
        # table expressions read Iceberg through get_iceberg_data_files
        # with no force_fresh parameter, so the intent rides the same
        # ContextVar mechanism the execution id does: the reader runs this
        # call with a staleness bound of 0 (core/iceberg_freshness_bound).
        from core.iceberg_freshness_bound import newest_snapshot_required
        from core import iceberg_versions as _iv
        _iv_token = _iv.activate(None)          # a fresh run map for THIS run
        self._iv_record = None
        try:
            with newest_snapshot_required(bool(kwargs.get("force_refresh"))):
                _res = self._execute_dataset_query_inner(**kwargs)
            if self._iv_record is not None:
                try:
                    _res.iceberg_versions = list(self._iv_record)
                except Exception:      # pragma: no cover - defensive
                    pass
            return _res
        finally:
            _iv.deactivate(_iv_token)
            self._iv_record = None
            try:
                _EXECUTED_SQL.reset(_sql_token)
            except Exception:          # pragma: no cover - defensive
                logger.debug("could not restore executed sql", exc_info=True)
            if published:
                try:
                    _set_eid(prev)
                except Exception:      # pragma: no cover - defensive
                    logger.debug("could not restore execution id",
                                 exc_info=True)

    def _execute_dataset_query_inner(
        self,
        *,
        dataset_id: int,
        column_ids: List[int],
        metric_ids: Optional[List[int]] = None,
        filters: Optional[List[Dict[str, Any]]] = None,
        condition_ids: Optional[List[int]] = None,
        order_by: Optional[List[Dict[str, Any]]] = None,
        limit: Optional[int] = None,
        execution_id: Optional[str] = None,
        user_role: str = "viewer",
        progress_callback=None,
        agg_overrides: Optional[Dict[int, str]] = None,
        user_ctx: Optional[Dict[str, Any]] = None,
        decompose_avg: bool = False,
        comparison: Optional[Dict[str, Any]] = None,
        drill: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False,
        source_bindings: Optional[List[Dict[str, Any]]] = None,
        version_overrides: Optional[Dict[str, Any]] = None,
    ) -> FederationResult:
        """Execute a query against a single dataset using semantic layer metadata.

        ``version_overrides`` (2026-11-01, core/iceberg_versions.py): the
        report's "Data version" run control -- ``{table: {snapshot_id} |
        {as_of} | "latest"}`` per Iceberg table of the dataset's storage
        connection(s).  THE precedence (``decide_pin``): this override > the
        version the dataset's own SQL pins (``FOR VERSION AS OF``) > latest.
        Every table is resolved ONCE here, before anything is built, and the
        map is active for the whole run (the reader, the MoR deletes, the
        cache keys read it); ``FederationResult.iceberg_versions`` names each
        table's version and who decided it.

        ``source_bindings`` (2026-10-29): the values a REPORT's declared
        source parameters supply for predicates INSIDE the dataset's own SQL
        (``[{"source_column": key, "value": ..}]``, core/source_filters.py),
        built only by ``business_reports_api._build_source_bindings`` from
        the report's parameter rows.  They never travel in ``filters``: a
        caller-supplied filter list (extra_filters, an export's ``?filters=``,
        a share / embed body, the dataset execute route) that carries a
        ``source_column`` is REFUSED here, or anyone holding a link could
        replace the query's own conditions.

        ``force_refresh`` (FB-36, 2026-09-19): the caller wants a LIVE
        answer -- the viewer's Refresh button.  Threaded into BOTH cube
        routes (``check_cache_hit`` / ``check_cache_hit_rls``) as
        ``bypass``: the matching cube is not served, its rebuild is
        triggered, and the query runs at the source.  Before this the flag
        stopped at instance serving and a cube answered "refresh" with the
        same 818-second-old rows.

        Args:
            dataset_id:    Semantic layer dataset ID
            column_ids:    List of DatasetColumn.id to select
            filters:       [{column_id, operator, value, value2?}]
            condition_ids: Pre-defined condition IDs to apply
            order_by:      [{column_id, direction}]
            limit:         Max rows (falls back to config default)
            execution_id:  Execution UUID (generated if omitted)
            user_role:     Role for column visibility filtering
            progress_callback: Optional callable(dict) for progress
            decompose_avg: Phase 5 RLS-aware cubes (2026-08-09) — emit
                           ``SUM(x) AS x__sum, COUNT(x) AS x__cnt``
                           ALONGSIDE every avg measure so the stored
                           aggregate re-aggregates exactly (an AVG cannot
                           be re-derived from stored averages).  Used by
                           the agg-cache build path only; default False is
                           byte-identical to before.

        Returns:
            FederationResult with output parquet path and metadata
        """
        execution_id = execution_id or str(uuid.uuid4())
        t_start = datetime.now(timezone.utc)

        def _emit(step: str, **kw):
            if progress_callback:
                try:
                    progress_callback({"step": step, "execution_id": execution_id, **kw})
                except Exception as exc:
                    logger.warning("progress_callback failed: %s", exc)

        _emit("resolving", message="Resolving dataset metadata")

        # 1. Load full dataset
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        # 1b. FILTER AT THE SOURCE (2026-10-29, docs/REPORT_SOURCE_FILTERS_
        # 2026_10_29.html).  A filter dict carrying ``source_column`` binds a
        # predicate INSIDE the dataset's own SQL (its WHERE literal is the
        # default); the values are put into that predicate here, BEFORE
        # anything is built, so every reader downstream -- the builder, the
        # row-security rewrite, the registered-table views and their pruning,
        # the result cache's identity (the FINAL SQL) -- sees the substituted
        # text.  A binding the SQL cannot host REFUSES (never runs unfiltered);
        # an empty value keeps the query's own literal.  The aggregate cache
        # is skipped for such a run: a cube was built from the query as
        # written and would answer a differently-filtered query wrongly.
        from core import source_filters as _sf
        _forged = [f for f in (filters or []) if _sf.is_source_binding(f)]
        if _forged:
            # SECURITY (review of 3a799c243): a binding may come ONLY from the
            # report's declared parameters, through ``source_bindings``.
            raise ValueError(
                "A filter on the dataset's own query (source_column "
                f"{', '.join(repr(str(f.get(_sf.SOURCE_KEY))) for f in _forged)}) can only be "
                "set through the report's own parameters -- never through a filter list. "
                "Remove it from the filters; the report is not run with it.")
        _source_bindings = list(source_bindings or [])
        _sf.split_filters(_source_bindings)        # refuses a misspelt binding key
        _source_bound = False
        if _source_bindings:
            _connections_for_sql = self._resolve_connections(ds)
            _dialect = self._source_filter_dialect(ds.get("base_query") or "", _connections_for_sql)
            _new_base = _sf.apply(ds.get("base_query") or "", _dialect, _source_bindings)
            from core.reports.diagnostics import note_source_filters as _note_sf   # 2026-10-30 Diagnostics panel
            _note_sf(execution_id, ds.get("base_query") or "", _new_base, _dialect, _source_bindings)
            if _new_base != (ds.get("base_query") or ""):
                ds = dict(ds)
                ds["base_query"] = _new_base
                _source_bound = True
                logger.info("[%s] dataset %s: source filters bound (%s), dialect=%s",
                            execution_id, dataset_id, _sf.bound_summary(_source_bindings),
                            _dialect or "generic")

        # 1c. 2026-11-01 -- THE RUN'S TABLE VERSIONS (core/iceberg_versions.py).
        # Every Iceberg table of the dataset's storage connection(s) is
        # resolved ONCE, before anything is built: a dataset SQL that pins
        # a version (its clause becomes the marker the engine reads), the
        # report's Data version override, else latest.  A refusal fails the
        # run with its sentence; a table never reads another version.
        ds = self._resolve_dataset_versions(ds, execution_id, version_overrides)

        # 2. Resolve config.
        #
        # The caller's own limit applies.  Three cases, and the difference
        # between the last two is load-bearing (2026-08-11):
        #
        #   limit is None  -> semantic_layer.default_row_limit (unchanged:
        #                     an interactive caller that names no limit gets
        #                     the product's default page)
        #   limit <= 0     -> UNLIMITED, no LIMIT clause at all.  Previously
        #                     ``limit or default`` folded 0 into the default,
        #                     so a caller asking for "everything" silently got
        #                     10k rows.  agg_cache passes 0 now that the
        #                     governance knob ships disabled, and a cube built
        #                     from 10k of its rows and then served as complete
        #                     is a worse defect than any truncated query.
        #   limit > 0      -> exactly that.
        from core import config
        row_limit = (config.semantic_layer.default_row_limit
                     if limit is None else int(limit))

        # 3. Resolve selected columns
        all_columns = ds.get("columns", [])
        # FB-42: the column catalog's DECLARED type beside the stored one --
        # the SUM/AVG gate must not trust only the record that is wrong.
        self._annotate_source_types(ds, all_columns)
        col_map = {c["id"]: c for c in all_columns}

        # 2026-09-17 — DRILL-DOWN, finally applied.
        #
        # ``drill_hierarchy_id`` has been persisted and versioned on reports
        # since the hierarchy feature landed, and the execution engine NEVER
        # READ IT: the field appears only in db/models.py,
        # reports/instances.py, reports/versions.py and the API model.  A
        # saved drill level therefore round-tripped perfectly and changed
        # nothing about the query -- BUILT but not WIRED, on a surface whose
        # whole purpose is to change the GROUP BY.
        #
        # Resolution is deliberately small: a hierarchy is an ORDERED list of
        # dataset columns, so "drill to level N" IS "select levels 0..N as
        # the dimensions".  It therefore resolves to column ids and rejoins
        # the ordinary path -- no second builder, exactly as the comparison
        # spec does below.
        if drill is not None:
            column_ids = _resolve_drill_columns(
                ds.get("hierarchies") or [], drill, column_ids, col_map)

        selected = self._resolve_columns(column_ids, col_map, user_role)
        if not selected:
            raise ValueError("No valid columns selected")

        # 3a. Phase 106: apply aggregation overrides for pivot reports
        if agg_overrides:
            for col in selected:
                if col.column_id in agg_overrides:
                    col.aggregation = agg_overrides[col.column_id]

        # 3b. Resolve calculated metrics (Phase 101)
        if metric_ids:
            for m in ds.get("metrics", []):
                if m["id"] in metric_ids:
                    alias = m["name"].lower().replace(" ", "_")
                    selected.append(ColumnSelection(
                        column_id=0,
                        physical_name=alias,
                        friendly_name=m["name"],
                        column_type="calculated_metric",
                        expression=m["expression"],
                        is_metric=True,
                    ))

        # 3c. Expand a COMPARISON spec (2026-09-17).
        #
        # Buckets of one axis, side by side, plus their derived columns:
        # FD-04..FD-08 with a date axis, budget-vs-actual with a `scenario`
        # axis, restatement with `version`.  See core/comparison.py for why
        # the axis is not special-cased to dates.
        #
        # It lands HERE, as ordinary calculated-metric ColumnSelections,
        # precisely so it is NOT a second query builder: everything
        # downstream -- RLS, the cost gates, transpilation to the target
        # dialect, the aggregate cache -- treats these exactly like the
        # hand-written metrics that already work.  A parallel path would be
        # the "one correct helper, three builders that ignore it" shape this
        # engine already carries three instances of.
        #
        # A bad spec REFUSES.  Emitting a comparison whose numbers look
        # plausible and are not is the failure mode this whole feature is
        # meant to avoid, so ComparisonError propagates rather than being
        # downgraded to "no comparison columns".
        comparison_meta: Optional[Dict[str, Any]] = None
        if comparison:
            from core.comparison import ComparisonSpec
            _cmp = ComparisonSpec.from_dict(comparison)
            comparison_meta = _cmp.describe()
            for gc in _cmp.generate():
                selected.append(ColumnSelection(
                    column_id=0,
                    physical_name=gc.name.lower(),
                    friendly_name=gc.name,
                    column_type="calculated_metric",
                    expression=gc.expression,
                    is_metric=True,
                ))
            logger.info(
                "[%s] comparison: axis=%s buckets=%d measures=%d derived=%s "
                "-> %d generated column(s); grain=%s non_additive_safe=%s",
                execution_id, comparison_meta["axis"],
                len(comparison_meta["buckets"]),
                len(comparison_meta["measures"]),
                comparison_meta["derived"] or "-",
                len(_cmp.generate()), comparison_meta["grain"],
                comparison_meta["non_additive_safe"],
            )

        # 4. Resolve filters
        filter_specs = self._resolve_filters(filters or [], col_map)

        # 5. Resolve pre-defined conditions
        conditions = ds.get("conditions", [])
        cond_clauses = [
            c.get("where_clause", "") for c in conditions
            if c.get("id") in (condition_ids or []) and c.get("where_clause")
        ]

        # 6. Resolve order by
        order_specs = self._resolve_order_by(order_by or [], col_map)

        # 6.5  Smart routing -- check aggregation cache (BO Aggregate Awareness)
        # Phase 131 deep-dive #13: agg cache is shared across users; serving
        # it to an RLS-scoped consumer would bypass row-security policies.
        # Skip the cache entirely when user_ctx is set and RLS is enabled
        # (admins still bypass RLS at secure_sql so this path is fine for
        # them, but we have no cheap way to tell at this layer — go safe).
        #
        # Phase 5 RLS-aware cubes (2026-08-09, target architecture §3.3):
        # with `agg_cache.rls_serving_enabled` ON the blanket skip is
        # replaced by the fail-closed eligibility gate in
        # core.agg_cache.check_cache_hit_rls — a cube answers a secured
        # query only when the caller's RESOLVED predicates reference only
        # the cube's grouping columns and every measure re-aggregates
        # exactly; the predicates are then applied as a DuckDB WHERE over
        # the cube (Power BI: "it would be insecure to answer queries from
        # the aggregation table if the RLS filter can't be applied" — so it
        # is answered only when it CAN be).  Every uncertainty is a MISS to
        # the live path below, where SqlRewriter enforces RLS at source.
        # Flag OFF (the default) keeps the blanket skip byte-identical.
        _skip_agg_cache = bool(_source_bound)     # a source-filtered run: no cube (read or write)
        _rls_cube_gate = False
        if user_ctx is not None and not _source_bound:
            try:
                from core.row_security.api import _is_enabled as _rs_is_enabled
                if _rs_is_enabled():
                    _rls_serving = False
                    try:
                        _rls_serving = bool(config.agg_cache.rls_serving_enabled)
                    except Exception:
                        # Unreadable flag = feature OFF (the flag is an
                        # access WIDENER — its fail mode is closed).
                        _rls_serving = False
                    if _rls_serving:
                        _rls_cube_gate = True
                    else:
                        _skip_agg_cache = True
            except Exception:
                _skip_agg_cache = False

        try:
            from core.agg_cache import (
                check_cache_hit, check_cache_hit_rls,
            )
            dim_col_ids = [c.column_id for c in selected
                           if c.column_type in ("dimension", "detail")]
            measure_col_ids = [c.column_id for c in selected
                               if c.column_type in ("measure", "kpi") and c.aggregation]

            # ── Phase 5: secured serve for RLS-scoped callers (flag-gated) ──
            if dim_col_ids and measure_col_ids and not _skip_agg_cache and _rls_cube_gate:
                _req_dims = [(c.column_id, c.physical_name) for c in selected
                             if c.column_type in ("dimension", "detail")]
                # Aggregations AFTER agg_overrides (step 3a) — the gate must
                # judge what will actually be computed.
                _req_measures = [
                    (c.column_id, c.physical_name, (c.aggregation or "").lower())
                    for c in selected
                    if c.column_type in ("measure", "kpi") and c.aggregation]
                secured_hit = None
                # Calculated metrics carry arbitrary expressions a cube
                # cannot compute — a request containing one is ineligible
                # (MISS ⇒ live), never served without its metric column.
                if not any(c.is_metric for c in selected):
                    secured_hit = check_cache_hit_rls(
                        bypass=bool(force_refresh),
                        dataset_id=dataset_id,
                        requested_dims=_req_dims,
                        requested_measures=_req_measures,
                        user_ctx=user_ctx,
                        dataset=ds,
                        # Phase 7 (2026-08-09): context for the candidate-
                        # source registry (customer pre-agg tables under
                        # RLS — eligible ONLY when every resolved predicate
                        # lands on the table's own dimensions).  Inert with
                        # the agg_awareness_serving flag OFF (default).
                        filter_columns=[f.physical_name for f in filter_specs],
                        condition_ids=list(condition_ids or []),
                    )
                if secured_hit is not None:
                    _emit("cache_hit",
                          message=f"Serving from RLS-aware aggregation cache "
                                  f"({secured_hit.grain_label})")
                    # Polymorphic serve (Phase 7): a parquet cube runs one
                    # bounded DuckDB query with the caller's predicates as
                    # WHERE (read_secured_cube — exactly as before); a
                    # customer pre-agg table executes its rollup SQL with
                    # the same predicates through this engine.
                    df = secured_hit.load_df(execution_id=execution_id,
                                             requested_dims=_req_dims,
                                             requested_measures=_req_measures)
                    df = self._apply_filters_to_df(df, filter_specs)
                    if order_specs:
                        sort_cols = [o.physical_name for o in order_specs
                                     if o.physical_name in df.columns]
                        sort_asc = [o.direction.upper() == "ASC" for o in order_specs
                                    if o.physical_name in df.columns]
                        if sort_cols:
                            df = df.sort_values(sort_cols, ascending=sort_asc)
                    if row_limit and len(df) > row_limit:
                        df = df.head(row_limit)
                    req_phys = [c.physical_name for c in selected
                                if c.physical_name in df.columns]
                    if req_phys:
                        df = df[req_phys]
                    out_dir = Path(self._output_dir)
                    out_dir.mkdir(parents=True, exist_ok=True)
                    output_path = str(out_dir / _artifact_file_name(execution_id))
                    from core.connector_to_parquet import df_to_parquet_streaming
                    df_to_parquet_streaming(df, output_path)
                    duration = (datetime.now(timezone.utc) - t_start).total_seconds()
                    _emit("completed",
                          message=f"Cache hit: {len(df)} rows in {duration:.3f}s",
                          total_rows=len(df))
                    logger.info("[%s] AGG CACHE HIT (RLS-aware) dataset %d: "
                                "entry=%d grain=%s mode=%s predicates=%d "
                                "regroup=%s rows=%d time=%.3fs",
                                execution_id, dataset_id, secured_hit.entry_id,
                                secured_hit.grain_label, secured_hit.rls_mode,
                                len(secured_hit.predicates),
                                secured_hit.needs_regroup, len(df), duration)
                    _cache_limit_hit = bool(row_limit and len(df) >= row_limit)
                    return FederationResult(
                        execution_id=execution_id,
                        dataset_id=dataset_id,
                        output_path=output_path,
                        total_rows=len(df),
                        columns=df.columns.tolist(),
                        duration_seconds=round(duration, 3),
                        # Phase 7: hit classes render their own provenance
                        # (parquet hits produce the exact pre-Phase-7 text).
                        sql_generated=secured_hit.describe(),
                        sources_used=secured_hit.sources_used(),
                        primary_rows=len(df),
                        cache_hit=True,
                        cache_age_seconds=secured_hit.cache_age_seconds,
                        cache_entry_id=secured_hit.entry_id,
                        cache_grain=secured_hit.grain_label,
                        execution_engine="agg_cache",
                        row_limit=row_limit,
                        unstable_truncation=(
                            _cache_limit_hit and not order_specs) or None,
                    )

            if dim_col_ids and measure_col_ids and not _skip_agg_cache and not _rls_cube_gate:
                cache_result = check_cache_hit(
                    bypass=bool(force_refresh),                  # FB-36
                    dataset_id=dataset_id,
                    requested_dimension_col_ids=dim_col_ids,
                    requested_measure_col_ids=measure_col_ids,
                    # Phase 7 (2026-08-09): request context for the
                    # candidate-source registry (customer pre-agg tables).
                    # With `agg_cache.agg_awareness_serving_enabled` OFF
                    # (the shipped default) these are inert and routing is
                    # byte-identical to before.
                    requested_dims=[(c.column_id, c.physical_name)
                                    for c in selected
                                    if c.column_type in ("dimension", "detail")],
                    requested_measures=[
                        (c.column_id, c.physical_name,
                         (c.aggregation or "").lower())
                        for c in selected
                        if c.column_type in ("measure", "kpi") and c.aggregation],
                    filter_columns=[f.physical_name for f in filter_specs],
                    condition_ids=list(condition_ids or []),
                    dataset=ds,
                    has_metrics=any(c.is_metric for c in selected),
                )
                if cache_result:
                    _emit("cache_hit",
                          message=f"Serving from aggregation cache ({cache_result.grain_label})")
                    # Phase 7: polymorphic serve — a parquet-backed hit
                    # reads its file (exactly the old pd.read_parquet); a
                    # table-backed hit executes its rollup SQL through this
                    # engine.  Any load failure falls through to live via
                    # the surrounding exception fence.
                    df = cache_result.load_df(execution_id=execution_id)
                    # Post-filter cached data
                    df = self._apply_filters_to_df(df, filter_specs)
                    # Apply order
                    if order_specs:
                        sort_cols = [o.physical_name for o in order_specs
                                     if o.physical_name in df.columns]
                        sort_asc = [o.direction.upper() == "ASC" for o in order_specs
                                    if o.physical_name in df.columns]
                        if sort_cols:
                            df = df.sort_values(sort_cols, ascending=sort_asc)
                    # Apply limit
                    if row_limit and len(df) > row_limit:
                        df = df.head(row_limit)
                    # Select only requested columns
                    req_phys = [c.physical_name for c in selected
                                if c.physical_name in df.columns]
                    if req_phys:
                        df = df[req_phys]
                    # Save result via strategic streaming chokepoint.
                    out_dir = Path(self._output_dir)
                    out_dir.mkdir(parents=True, exist_ok=True)
                    output_path = str(out_dir / _artifact_file_name(execution_id))
                    from core.connector_to_parquet import df_to_parquet_streaming
                    df_to_parquet_streaming(df, output_path)
                    duration = (datetime.now(timezone.utc) - t_start).total_seconds()
                    _emit("completed",
                          message=f"Cache hit: {len(df)} rows in {duration:.3f}s",
                          total_rows=len(df))
                    logger.info("[%s] AGG CACHE HIT dataset %d: entry=%d grain=%s "
                                "rows=%d time=%.3fs",
                                execution_id, dataset_id, cache_result.entry_id,
                                cache_result.grain_label, len(df), duration)
                    # D1 2026-08-09: stamp the EFFECTIVE limit + stability
                    # signal (see the same stamp on the live path below).
                    _cache_limit_hit = bool(row_limit and len(df) >= row_limit)
                    return FederationResult(
                        execution_id=execution_id,
                        dataset_id=dataset_id,
                        output_path=output_path,
                        total_rows=len(df),
                        columns=df.columns.tolist(),
                        duration_seconds=round(duration, 3),
                        # Phase 7: hit classes render their own provenance
                        # (parquet hits produce the exact pre-Phase-7 text).
                        sql_generated=cache_result.describe(),
                        sources_used=cache_result.sources_used(),
                        primary_rows=len(df),
                        cache_hit=True,
                        cache_age_seconds=cache_result.cache_age_seconds,
                        cache_entry_id=cache_result.entry_id,
                        cache_grain=cache_result.grain_label,
                        execution_engine="agg_cache",
                        row_limit=row_limit,
                        unstable_truncation=(
                            _cache_limit_hit and not order_specs) or None,
                    )
        except Exception as _cache_exc:
            logger.warning("[%s] Agg cache check failed (falling through to live): %s",
                           execution_id, _cache_exc)

        # 7. Resolve connections and determine execution mode
        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        relationships = ds.get("relationships", [])

        # 7.5  ENGINE-level row bound — OPERATOR GOVERNANCE ONLY (2026-08-11).
        #
        # This clamp used to be a MEMORY GUARD and it is not one any more.
        # Every route now either streams or spills:
        #
        #   * DETAIL results stream engine -> RecordBatch -> parquet at
        #     O(one batch) — measured flat, 34.7 MB at 4M rows;
        #   * AGGREGATING results are bounded by DuckDB's own memory_limit and
        #     SPILL to temp_directory (both set in core/duckdb_factory.py, the
        #     same policy core/reports/microcube.py uses).  Measured: a 4M-row
        #     high-cardinality GROUP BY under memory_limit=256MB COMPLETES at
        #     255 MB peak with a byte-identical checksum to the 4 GB run;
        #   * the HYBRID S3+connector route — the last hold-out — no longer
        #     merges in pandas.  Its connector side is streamed to parquet and
        #     the join runs in DuckDB, which spills like every other route.
        #     See ``_execute_hybrid_to_parquet`` and ``_engine_cannot_spill``.
        #
        # Spilling is what every comparable engine does — Power BI,
        # Tableau/Hyper, Trino, Snowflake — none of them answers a request with
        # silently fewer rows.  So ``federation.max_result_rows`` survives only
        # as an ADMIN POLICY knob and it now ships DISABLED (<= 0).  When an
        # operator does set it, it applies to EVERY route uniformly (a
        # governance limit that depended on which engine happened to run the
        # query would be incoherent policy) and the cut is DISCLOSED via
        # row_limit / truncated / unstable_truncation — never silent.
        max_rows = config.federation.max_result_rows
        if (max_rows and max_rows > 0
                and (row_limit <= 0 or row_limit > max_rows)):
            logger.warning(
                "[%s] federation.max_result_rows: caller limit %s clamped to "
                "%s for dataset %s. REASON: an operator has set this ADMIN "
                "GOVERNANCE limit (it ships disabled, and it is no longer a "
                "memory guard — every route streams or spills). The result is "
                "delivered, cut at the clamp, and flagged "
                "(row_limit/truncated/unstable_truncation). Set "
                "federation.max_result_rows <= 0 to deliver whole results.",
                execution_id, "unlimited" if row_limit <= 0 else row_limit,
                max_rows, dataset_id)
            row_limit = max_rows

        _emit("generating_sql", message="Generating SQL from semantic layer")

        # 8. Build SQL
        sql, source_info = self._build_query(
            selected=selected,
            filter_specs=filter_specs,
            cond_clauses=cond_clauses,
            order_specs=order_specs,
            limit=row_limit,
            source_tables=source_tables,
            relationships=relationships,
            connections=connections,
            base_query=ds.get("base_query", ""),
            decompose_avg=decompose_avg,
        )

        logger.info("[%s] Generated SQL for dataset %s: %s", execution_id, dataset_id, sql[:200])

        # 8b. Phase 131 deep-dive #13 — row-security rewrite.
        # FederationEngine builds SQL internally so the previous report
        # path (secure_sql in reports_api) never saw it.  Apply policies
        # here before execution.  Dialect = duckdb because federation
        # always executes via DuckDB (either direct, S3 attach, or
        # connector materialise-and-join).  Hard-fail on enforcement
        # errors — matches sql_query_api and _run_sql_report posture.
        if user_ctx is not None:
            # 2026-08-05 BR cross-source audit rule, stated once in
            # _apply_rls_all_connections: the rewrite runs per DISTINCT
            # connection so a policy scoped to the SECOND connection of a
            # multi-connection dataset is never silently skipped.
            sql = self._apply_rls_all_connections(
                sql, connections, user_ctx,
                label=f"dataset {dataset_id}", request_id=execution_id)
        else:
            # SECURITY SAFETY NET: user_ctx is None → secure_sql is skipped and
            # the query runs UNFILTERED.  That is correct for a handful of
            # legitimate internal callers that intentionally build unrestricted
            # result sets (e.g. agg_cache shared-aggregate materialisation), but
            # it is exactly how a NEW caller could silently leak RLS-protected
            # rows.  We cannot hard fail-closed or inject a deny-by-default
            # principal here without breaking those legitimate unrestricted
            # callers (it would poison the shared agg cache with empty rows), so
            # we make the skip LOUDLY VISIBLE: if any table in the generated SQL
            # is covered by an enabled row/column policy, emit a WARNING naming
            # the caller + tables so a silent leak becomes an auditable event.
            _warn_if_rls_policies_skipped(
                self._db, sql, dataset_id=dataset_id, execution_id=execution_id,
            )

        # 9/10. Execute AND persist.
        #
        # 2026-08-11: these were two steps — materialise the whole result as
        # one DataFrame, then stream the write.  Peak memory was
        # O(total_rows x row_width), which is what made
        # federation.max_result_rows a memory ceiling rather than a policy.
        # The streaming route fuses them: rows go from the engine into the
        # artifact in batches and are never all resident at once.  The
        # artifact is byte-for-byte the same contract, so the microcube, the
        # agg-cache write-through (which reads output_path, not the frame),
        # the paged viewer and retention are all untouched.
        _emit("executing", message="Executing federated query")

        out_dir = Path(self._output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / _artifact_file_name(execution_id))

        # ── 8c.  RESULT CACHE (2026-09-07) ──────────────────────────────
        #
        # THE ONE consult on this road.  Placed here, not at the eleven
        # call sites, because everything that runs a dataset query funnels
        # through this function and a gate the caller has to remember is a
        # gate a caller will forget.  The SQL above is FINAL and
        # RLS-REWRITTEN, so parameters, row limit, column visibility and
        # the row-security predicates are already inside the key; the
        # principal, the role, the dataset's lifecycle stamp and the
        # connection set are added by ``build_identity``.  Freshness is
        # verified on the HIT (never on the miss — a cache must not tax
        # the first run) and DISCLOSED, never assumed.
        #
        # See core/dataset_result_cache.py for why this path had no cache
        # at all before today: the only consult in the product hangs off
        # ``query_config.files``, which does not exist on this road.
        _rc_identity = None
        _rc_key = ""
        try:
            from core import dataset_result_cache as _drc
            _rc_identity = _drc.build_identity(
                sql=sql, dataset_id=dataset_id, dataset=ds,
                source_tables=source_tables, connections=connections,
                row_limit=row_limit, user_role=user_role, user_ctx=user_ctx)
            _rc_dec = _drc.lookup(identity=_rc_identity,
                                  output_path=output_path,
                                  db_manager=self._db)
            _rc_key = _rc_dec.key
            if _rc_dec.served:
                _duration = (datetime.now(timezone.utc) - t_start).total_seconds()
                _emit("completed",
                      message=f"Served from result cache: "
                              f"{_rc_dec.row_count} rows in {_duration:.3f}s",
                      total_rows=_rc_dec.row_count)
                import pyarrow.parquet as _pq_rc
                try:
                    _cols = list(_pq_rc.ParquetFile(output_path).schema.names)
                except Exception:
                    _cols = []
                _lim_hit = bool(row_limit and row_limit > 0
                                and _rc_dec.row_count >= row_limit)
                return FederationResult(
                    execution_id=execution_id,
                    dataset_id=dataset_id,
                    output_path=output_path,
                    total_rows=_rc_dec.row_count,
                    columns=_cols,
                    duration_seconds=round(_duration, 3),
                    sql_generated=sql,
                    sql_executed=_EXECUTED_SQL.get(""),
                    sources_used=source_info,
                    primary_rows=_rc_dec.row_count,
                    cache_hit=True,
                    cache_age_seconds=_rc_dec.age_seconds,
                    cache_grain="result",
                    result_cache_hit=True,
                    cache_freshness=_rc_dec.freshness,
                    execution_engine="result_cache",
                    row_limit=row_limit,
                    unstable_truncation=(_lim_hit and not order_specs) or None,
                )
        except Exception as _rc_exc:
            # Fail-open in BOTH directions: a broken cache must not break a
            # query, and a miss must cost nothing but this try block.
            logger.debug("[%s] result-cache consult skipped: %s",
                         execution_id, _rc_exc)

        # 2026-08-22 — custom-SQL datasets (base_query, incl. saved-query
        # sourced ones) may reference REGISTERED S3 tables by bare name, the
        # way the SQL editor lets users write them.  Resolve those names to
        # DuckDB views BEFORE execution — see _registered_table_views_for_sql.
        _table_views: Optional[List[Tuple[str, str]]] = None
        if (ds.get("base_query") or "").strip():
            # 2026-10-02: the dataset's filters ride along so the view's
            # file list can be pruned on them -- when lineage proves it.
            _table_views = self._registered_table_views_for_sql(
                sql, connections, source_tables,
                base_query=ds.get("base_query"),
                filter_specs=filter_specs) or None

        streamed = self._try_execute_to_parquet(
            sql=sql,
            connections=connections,
            execution_id=execution_id,
            output_path=output_path,
            row_limit=row_limit,
            source_tables=source_tables,
            filter_specs=filter_specs,
            table_views=_table_views,
            # The dataset's DECLARED progressive-scan knob.  Resolved
            # here, from the dataset already loaded, so the engine
            # never re-reads it and the two halves cannot disagree.
            partition_config=dataset_partition_config(ds),
        )
        if streamed is not None:
            total_rows = int(streamed.get("total_rows", 0))
            out_columns = list(streamed.get("columns") or [])
        else:
            # Fallback: routes that genuinely need a frame (hybrid S3+connector
            # in-memory merge), or a streaming failure.  Unchanged behaviour.
            df = self._execute_query(
                sql=sql,
                connections=connections,
                source_tables=source_tables,
                execution_id=execution_id,
                progress_callback=progress_callback,
                table_views=_table_views,
            )
            from core.connector_to_parquet import df_to_parquet_streaming
            df_to_parquet_streaming(df, output_path)
            total_rows = len(df)
            out_columns = df.columns.tolist()

        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Completed: {total_rows} rows in {duration:.1f}s",
              total_rows=total_rows)

        # 2026-09-27 -- WHICH ENGINE ANSWERED.  The same classification both
        # routes above dispatch on (``_classify_connections``), read AFTER the
        # run so it names what happened.  Stamped on the execution's
        # diagnostics too, so the report-scoped scan disclosure
        # (core/reports/scan_disclosure.py) can answer without the envelope.
        _engine_key = None
        try:
            from core.engine_attribution import engine_for_routes as _efr
            _s3c, _sqlc = self._classify_connections(connections)
            _engine_key = _efr(_s3c, _sqlc)
            self._note_scan_diagnostic(execution_id,
                                       {"execution_engine": _engine_key})
        except Exception:                                    # noqa: BLE001
            logger.debug("[%s] engine attribution skipped", execution_id,
                         exc_info=True)

        logger.info("[%s] Dataset %s executed: %d rows, %.1fs (%s, engine=%s)",
                    execution_id, dataset_id, total_rows, duration,
                    "streamed" if streamed is not None else "materialised",
                    _engine_key)

        # 10.4  RESULT CACHE write-through — the other half of step 8c.
        # Best-effort and non-blocking on correctness: the answer has
        # already been produced, so a store failure costs a future miss
        # and nothing else.  The identity is the SAME object the lookup
        # used, so the store key cannot drift from the lookup key.
        if _rc_identity is not None:
            try:
                from core import dataset_result_cache as _drc_w
                _drc_w.store(identity=_rc_identity, output_path=output_path,
                             row_count=total_rows,
                             column_count=len(out_columns),
                             source_tables=source_tables,
                             db_manager=self._db, key=_rc_key)
            except Exception as _rc_w_exc:
                logger.debug("[%s] result-cache store skipped: %s",
                             execution_id, _rc_w_exc)

        # 10.5  Write-through cache population (optional)
        # Phase 131 deep-dive #13: skip write-through when the result was
        # produced under an RLS scope — otherwise we'd cache scoped rows
        # and serve them to other users on later cache hits.  Mirror of
        # the skip-on-read above.  Phase 5 keeps this posture under the
        # rls_serving flag too (`_rls_cube_gate`): a secured caller's live
        # result may be SCOPED rows — populating a shared entry with it
        # would serve one caller's rows to everyone.  Secured cubes are
        # populated only by their governed build path (and
        # maybe_write_through itself also refuses non-open entries).
        try:
            from core import config as _cfg
            if (_cfg.agg_cache.enabled and _cfg.agg_cache.write_through_enabled
                    and not _skip_agg_cache and not _rls_cube_gate):
                from core.agg_cache import maybe_write_through
                # 2026-08-20 completeness facts — the LIVE response
                # discloses row_limit/truncated but a cube copy discloses
                # nothing, so maybe_write_through now REFUSES any result
                # that was limited (row_limit is the EFFECTIVE limit after
                # the max_result_rows clamp; an interactive caller that
                # named no limit runs under semantic_layer.
                # default_row_limit), ad-hoc filtered, or conditioned.
                maybe_write_through(
                    dataset_id=dataset_id,
                    column_ids=column_ids,
                    output_path=output_path,
                    total_rows=total_rows,
                    row_limit=row_limit,
                    filter_count=len(filter_specs),
                    condition_ids=list(condition_ids or []),
                )
        except Exception as _wt_exc:
            logger.debug("Write-through cache population skipped: %s", _wt_exc)

        # D1 2026-08-09 (silent-truncation fix): stamp the EFFECTIVE limit
        # this execution actually applied (post federation.max_result_rows
        # clamp, step 2 above) so the downstream truncation verdict compares
        # against the real cut point — not the caller's larger configured
        # limit (which made a result cut at the clamp report truncated=False).
        # unstable_truncation: cut at the limit with no ORDER BY → the kept
        # rows are an arbitrary sample (disclosed; ORDER BY is never injected).
        # The disclosure is computed from the SAME row count either route
        # produced, so streaming cannot change what a consumer is told about
        # truncation — only how much memory it took to get there.
        _limit_hit = bool(row_limit and row_limit > 0 and total_rows >= row_limit)
        return FederationResult(
            execution_id=execution_id,
            dataset_id=dataset_id,
            output_path=output_path,
            total_rows=total_rows,
            columns=out_columns,
            duration_seconds=round(duration, 3),
            sql_generated=sql,
            sql_executed=_EXECUTED_SQL.get(""),
            sources_used=source_info,
            primary_rows=total_rows,
            row_limit=row_limit,
            unstable_truncation=(_limit_hit and not order_specs) or None,
            execution_engine=_engine_key,
        )

    # ── 2026-11-01: table VERSIONS on the report / dataset road ─────────────
    _iv_record: Optional[List[Dict[str, Any]]] = None

    def _resolve_dataset_versions(self, ds: Dict[str, Any], execution_id: Optional[str],
                                  version_overrides: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Resolve the dataset's Iceberg tables ONCE through THE resolver
        (``iceberg_versions.resolve_for_connection``), per storage connection,
        activate the map for the run and keep its record.  Returns ``ds``,
        with ``base_query`` rewritten when the dataset's own SQL pinned a
        version (the clause becomes the marker the engine reads)."""
        from core import iceberg_versions as _iv
        from core.s3_utilities import make_s3_client_for_conn
        overrides = _iv.parse_body_overrides(version_overrides)
        conns = {cid: c for cid, c in (self._resolve_connections(ds) or {}).items()
                 if self._get_connection_type(c) == "s3"}
        base_sql = ds.get("base_query") or ""
        if not conns:
            if overrides:
                raise _iv.IcebergVersionRefusal(
                    "A data version can be chosen only for Iceberg tables on a storage "
                    "connection; this dataset reads none.")
            return ds
        source_names = [str(t.get("table") or t.get("name") or "").lower()
                        for t in (ds.get("source_tables") or []) if isinstance(t, dict)]
        merged: Dict[str, Any] = {}
        records: List[Dict[str, Any]] = []
        new_sql = None
        for cid, conn in conns.items():
            cfg = conn.get("config") or {}
            regs = cfg.get("registered_tables") or []
            if not any(str(r.get("format") or "").lower() == "iceberg" for r in regs if isinstance(r, dict)):
                continue
            bucket = cfg.get("bucket_name") or cfg.get("bucket") or ""
            s3 = make_s3_client_for_conn({"id": cid, "config": cfg})
            from core.iceberg_freshness_bound import newest_snapshot_is_required
            res = _iv.resolve_for_connection(
                s3_client=s3, bucket=bucket, registered_tables=regs,
                sql=base_sql or None,
                referenced_names=None if base_sql else source_names,
                overrides=overrides, force_fresh=newest_snapshot_is_required(),
                allow_renamed_views=False)
            if res is None:
                continue
            merged.update(res.versions)
            records.extend(res.record())
            if res.sql is not None:
                new_sql = res.sql
                base_sql = new_sql
        if not merged:
            if overrides and any(k != _iv.EVERY_TABLE for k in overrides):
                raise _iv.IcebergVersionRefusal(
                    "The data version names a table this dataset does not read.")
            return ds
        _iv.activate(merged)
        self._iv_record = records
        for rec in records:
            logger.info("[iceberg-versions] execution=%s reads %s (%s)",
                        execution_id, rec.get("words"), rec.get("decided_by"))
        if new_sql is not None:
            ds = dict(ds)
            ds["base_query"] = new_sql
        return ds

    #: The public method delegates through ``**kwargs``, which would
    #: otherwise HIDE the real contract: ``inspect.signature`` would
    #: report ``(**kwargs)`` and callers (and the test that pins
    #: ``agg_overrides``) could no longer see what this accepts.
    #: ``__wrapped__`` makes ``inspect.signature`` follow through to
    #: the implementation, so publishing the execution id costs
    #: nothing in discoverability.  Set here rather than with
    #: ``functools.wraps`` so the wrapper keeps its OWN docstring,
    #: which explains why it exists.
    execute_dataset_query.__wrapped__ = _execute_dataset_query_inner

    def _selected_physical_names(self, dataset_id: int,
                                 column_ids: List[int]) -> List[str]:
        """The physical names the merge will actually see for one side."""
        ds = self._db.get_dataset_full(dataset_id) or {}
        by_id = {c["id"]: c for c in (ds.get("columns") or [])}
        out = []
        for cid in (column_ids or []):
            col = by_id.get(cid)
            if col and col.get("physical_name"):
                out.append(str(col["physical_name"]))
        return out

    def _validate_merge_keys(self, merge_keys, primary_dataset_id,
                             primary_column_ids, secondary_dataset_id,
                             secondary_column_ids) -> None:
        """Refuse up front, naming the key and what IS available.  See FB-9.

        Fails OPEN on a metadata read it cannot do: this is a better error
        message, not a new gate, and blocking a merge because the column list
        could not be loaded would be a regression dressed as a fix.
        """
        if not merge_keys:
            raise ValueError(
                "A merged query needs at least one merge key "
                "({'left': <primary column>, 'right': <secondary column>}).")
        try:
            left_avail = self._selected_physical_names(
                primary_dataset_id, primary_column_ids)
            right_avail = self._selected_physical_names(
                secondary_dataset_id, secondary_column_ids)
        except Exception as exc:                            # noqa: BLE001
            logger.debug("merge-key pre-check skipped (%s)", exc)
            return
        if not left_avail or not right_avail:
            return              # nothing to check against -- do not invent one
        problems = []
        for i, mk in enumerate(merge_keys):
            left = str((mk or {}).get("left") or "")
            right = str((mk or {}).get("right") or "")
            if not left or not right:
                problems.append(
                    f"merge_keys[{i}] needs both 'left' and 'right'; got "
                    f"{mk!r}")
                continue
            if left not in left_avail:
                problems.append(
                    f"merge key '{left}' is not among the columns selected "
                    f"from the primary dataset. Selected: "
                    f"{sorted(left_avail)}. Add it to the primary "
                    f"column_ids -- a join key has to be selected on the "
                    f"side it joins from.")
            if right not in right_avail:
                problems.append(
                    f"merge key '{right}' is not among the columns selected "
                    f"from the secondary dataset. Selected: "
                    f"{sorted(right_avail)}. Add it to the secondary "
                    f"column_ids.")
        if problems:
            raise ValueError(" ".join(problems))

    def execute_merged_query(
        self,
        *,
        primary_dataset_id: int,
        secondary_dataset_id: int,
        primary_column_ids: List[int],
        secondary_column_ids: List[int],
        merge_keys: List[Dict[str, str]],  # [{"left": "col_name", "right": "col_name"}]
        merge_type: str = "inner",         # inner | left | right | full
        primary_filters: Optional[List[Dict[str, Any]]] = None,
        secondary_filters: Optional[List[Dict[str, Any]]] = None,
        primary_condition_ids: Optional[List[int]] = None,
        secondary_condition_ids: Optional[List[int]] = None,
        limit: Optional[int] = None,
        execution_id: Optional[str] = None,
        user_role: str = "viewer",
        progress_callback=None,
        user_ctx: Optional[Dict[str, Any]] = None,
    ) -> FederationResult:
        """Execute a merged query across two datasets (BO multiple data providers).

        Each dataset is queried independently, then results are merged on
        shared dimension columns (merge keys).
        """
        execution_id = execution_id or str(uuid.uuid4())
        t_start = datetime.now(timezone.utc)

        def _emit(step: str, **kw):
            if progress_callback:
                try:
                    progress_callback({"step": step, "execution_id": execution_id, **kw})
                except Exception as exc:
                    logger.warning("progress_callback failed: %s", exc)

        from core import config
        # 2026-08-13 -- ``limit or default`` FOLDS 0 INTO THE DEFAULT, and
        # this default is semantic_layer.default_row_limit = 10,000.  A
        # merged query asking for UNLIMITED (limit=0) therefore came back
        # with 10k rows and no disclosure.
        #
        # 56dd9fff recorded this EXACT trap when it fixed the sibling call
        # site: "agg_cache passes that knob as its bound, and ``limit or
        # default`` would have folded 0 into
        # semantic_layer.default_row_limit=10k -- A CUBE SILENTLY REBUILT
        # FROM 10K ROWS AND SERVED AS COMPLETE."  This site kept the idiom.
        #
        # Resolve by PRESENCE: an explicit 0 stays 0 (unlimited downstream);
        # only a genuinely absent limit falls back to the default.
        row_limit = (int(limit) if limit is not None
                     else int(config.semantic_layer.default_row_limit))
        if row_limit < 0:
            row_limit = 0

        # 2026-09-17 (FB-9) -- REFUSE A MERGE KEY THAT IS NOT SELECTED,
        # before either side is read.
        #
        # Forgetting to select the join key is an easy and common authoring
        # mistake.  It used to surface as a DuckDB BinderException deep in the
        # merge -- "Table \"b\" does not have a column named \"region\"" --
        # which the route rendered as 500 "contact support".  So the user paid
        # for BOTH dataset reads and then got a support reference for a
        # mistake they could have fixed in one click.  This surface already
        # validates subtler things (the merge TYPE, three lines down, was
        # moved ahead of the reads for exactly this reason).
        self._validate_merge_keys(
            merge_keys,
            primary_dataset_id, primary_column_ids,
            secondary_dataset_id, secondary_column_ids)

        # THE combine description, BEFORE either side is read: the one join
        # vocabulary ("full" == "outer"), the pandas-merge result shape every
        # saved merged layout addresses (right keys kept, ``_merged`` suffix).
        from core.executors.cross_source_combine import (
            CrossSourceRefusal, SHAPE_MERGE, combine_spec)
        try:
            merge_spec = combine_spec(
                "join", None, join_on=list(merge_keys or []),
                join_how=merge_type or "inner", shape=SHAPE_MERGE,
                default_suffixes=("", "_merged"))
        except CrossSourceRefusal as exc:
            raise ValueError(f"Invalid merge type / keys: {exc}")
        merge_type = merge_spec.how

        # 2026-10-04 -- ROW LIMITS, the plain-report rule: ``row_limit``
        # bounds the MERGED RESULT (0 = unlimited) and is disclosed with an
        # overflow sentinel.  Each SIDE runs WHOLE (limit=0): a side cut at
        # the report limit made the merge run over a 50,000-row SAMPLE of
        # each dataset and come back looking complete (measured live, X5).
        # An operator's federation.max_result_rows clamp still applies to a
        # side and is disclosed through that side's row_limit/total below.
        _SIDE_LIMIT = 0

        # Execute primary dataset
        _emit("primary_query", message="Executing primary dataset")
        primary_result = self.execute_dataset_query(
            dataset_id=primary_dataset_id,
            column_ids=primary_column_ids,
            filters=primary_filters,
            condition_ids=primary_condition_ids,
            limit=_SIDE_LIMIT,
            execution_id=f"{execution_id}_primary",
            user_role=user_role,
            progress_callback=progress_callback,
            user_ctx=user_ctx,
        )

        # JOIN-PRUNER (2026-06-01 deep-audit round 5) — cross-source
        # semi-join pruning for federation.  After primary executes, read
        # its OUTPUT parquet's min/max for the merge_keys' left columns,
        # then synthesise filters on the corresponding right columns and
        # AND them into ``secondary_filters``.  Pre-filters the secondary
        # read so we don't scan rows that can't possibly match.
        #
        # OUTER-JOIN SAFETY (deep-audit round 6) — pruning the SECONDARY
        # side is safe only when secondary's unmatched rows would NOT
        # appear in the result.  By merge_type:
        #
        #   * inner: unmatched secondary rows dropped → SAFE to prune
        #   * left  (primary preserved): unmatched secondary rows dropped
        #                                anyway → SAFE to prune
        #   * right (secondary preserved): unmatched secondary rows appear
        #                                  NULL-padded → UNSAFE (would
        #                                  drop rows that should appear)
        #   * full  (both preserved): UNSAFE for same reason
        #
        # Mirrors the JoinPruner safety matrix.  Uses parquet metadata
        # only (no row scan).  Fail-OPEN.
        _merge_type_lower = (merge_type or "inner").lower().strip()
        _fed_prune_safe = _merge_type_lower in ("inner", "left")
        if _fed_prune_safe:
            try:
                from core.join_pruner import JoinPruner as _JPFed
                _jp_fed = _JPFed(caller="federation")
                if _jp_fed.is_enabled() and merge_keys:
                    _synth_fed = _federation_synth_filters_from_primary(
                        primary_result.output_path, merge_keys,
                        secondary_dataset_id, self._db,
                    )
                    if _synth_fed:
                        secondary_filters = list(secondary_filters or []) + _synth_fed
                        logger.info(
                            "JOIN-PRUNER (federation): injected %d synth filter(s) "
                            "on secondary dataset %s (merge_type=%s) — keys: %s",
                            len(_synth_fed), secondary_dataset_id, _merge_type_lower,
                            [(f.get("column_id"), f.get("operator")) for f in _synth_fed],
                        )
            except Exception as _jp_fed_exc:
                logger.debug(
                    "Federation JoinPruner synth failed (fail-open): %s", _jp_fed_exc)
        else:
            logger.debug(
                "Federation JoinPruner: merge_type=%s preserves secondary; "
                "skipping synth (would drop NULL-padded rows)",
                _merge_type_lower,
            )

        # Execute secondary dataset
        _emit("secondary_query", message="Executing secondary dataset")
        secondary_result = self.execute_dataset_query(
            dataset_id=secondary_dataset_id,
            column_ids=secondary_column_ids,
            filters=secondary_filters,
            condition_ids=secondary_condition_ids,
            limit=_SIDE_LIMIT,
            execution_id=f"{execution_id}_secondary",
            user_role=user_role,
            progress_callback=progress_callback,
            user_ctx=user_ctx,
        )

        # Build merge keys
        left_on = list(merge_spec.left_on)

        # ── Merge the two sides (2026-08-11: DuckDB, not pandas) ───────────
        #
        # This was ``pd.read_parquet`` x2 -> ``pd.merge`` -> write.  BOTH
        # sides AND the merged frame were resident in the API pod at once, so
        # peak memory was O(primary + secondary + merged) and
        # ``federation.max_result_rows`` was the only thing standing between a
        # large merge and an OOM that takes every other user's query down with
        # it.  pandas cannot spill.  DuckDB can, and this pod already
        # configures it to: ``core/duckdb_factory.py`` sets ``memory_limit`` +
        # ``temp_directory``, the same policy ``core/reports/microcube.py``
        # uses.  That is what every comparable engine does — Power BI,
        # Tableau/Hyper, Trino, Snowflake all spill and COMPLETE; none of them
        # answers a request with silently fewer rows.
        #
        # THE RESULT SHAPE IS UNCHANGED.  ``build_pandas_merge_select_sql``
        # reproduces ``pd.merge``'s columns, their names, their order and the
        # row order exactly — including keeping the ``right_on`` key columns,
        # which the feed engine's ``build_join_combine_sql`` deliberately
        # DROPS.  Reusing that builder here would have silently deleted and
        # renamed columns in every saved merged report, because report layouts
        # address columns by name.  Both engines are run against the same data
        # and compared, for all five join types, in
        # ``tests/test_federation_merge_duckdb_2026_08_11.py``.
        #
        # One recorded difference: an integer column on the side a LEFT /
        # RIGHT / OUTER merge can leave unmatched used to be widened to
        # float64 (numpy int64 has no NaN); DuckDB returns nullable INT64
        # instead.  Same values, same aggregates, better precision above
        # 2^53 — but it is a physical type change, so it is asserted in that
        # test file rather than left to be discovered in a report.
        _emit("merging", message="Merging datasets on shared dimensions")

        out_dir = Path(self._output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / _artifact_file_name(execution_id))

        # THE combine (core.executors.cross_source_combine.combine_sides):
        # the same DuckDB merge builder as before, now with the overflow
        # sentinel (``truncated`` only when a row past the cap existed) and
        # key-type harmonisation disclosed rather than a binder error.
        from core.executors.cross_source_combine import combine_sides
        _merge_outcome = combine_sides(
            primary_result.output_path, secondary_result.output_path,
            output_path, merge_spec, row_limit=row_limit)
        if _merge_outcome.key_casts:
            logger.info("[%s] merge keys compared as text: %s", execution_id,
                        _merge_outcome.key_casts)
        _merge_stats = {"total_rows": _merge_outcome.total_rows,
                        "columns": list(_merge_outcome.columns)}

        merged_rows = int(_merge_stats.get("total_rows", 0))
        merged_columns = list(_merge_stats.get("columns") or [])

        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Merged: {merged_rows} rows in {duration:.1f}s",
              total_rows=merged_rows)

        logger.info("[%s] Merged datasets %s + %s: %d rows, %.1fs "
                    "(DuckDB join, spills to temp_directory)",
                    execution_id, primary_dataset_id, secondary_dataset_id,
                    merged_rows, duration)

        # D1 2026-08-09: each SIDE ran through execute_dataset_query and may
        # have been cut at ITS effective (clamped) limit — the merged length
        # alone cannot reveal that.  Force truncated=True whenever a side hit
        # its cap or the merge itself was cut; otherwise leave None so the
        # contract chokepoint computes the ordinary total-vs-limit verdict.
        _side_truncated = any(
            bool(r.row_limit and r.row_limit > 0 and r.total_rows >= r.row_limit)
            for r in (primary_result, secondary_result)
        )
        # The SENTINEL verdict, not ``merged_rows >= row_limit``: a merge that
        # produced exactly the cap is COMPLETE and says so.
        _merged_cut = bool(_merge_outcome.truncated)
        return FederationResult(
            execution_id=execution_id,
            dataset_id=primary_dataset_id,
            merged_dataset_id=secondary_dataset_id,
            output_path=output_path,
            total_rows=merged_rows,
            columns=merged_columns,
            duration_seconds=round(duration, 3),
            sql_generated=f"MERGE({primary_result.sql_generated}) ON {left_on}",
            sources_used=_label_sides([primary_result.sources_used,
                                       secondary_result.sources_used]),
            primary_rows=primary_result.total_rows,
            secondary_rows=secondary_result.total_rows,
            execution_engine="duckdb",          # the merge itself runs in DuckDB
            row_limit=row_limit,
            # Stamped EXPLICITLY both ways: the engine has the sentinel
            # verdict, so downstream must not recompute ``total >= limit``.
            truncated=bool(_side_truncated or _merged_cut),
            # An OUTER merge cut at the limit is an ARBITRARY sample: pandas
            # used to order an outer merge by the join key, the DuckDB path
            # orders by each side's row ordinal, and neither is a contract.
            # The other join types keep the preserved side's order, so their
            # cut point is stable and only the sides' own disclosure applies.
            unstable_truncation=(
                primary_result.unstable_truncation
                or secondary_result.unstable_truncation
                or (_merged_cut and merge_type == "full")) or None,
        )

    def execute_union_query(
        self,
        *,
        datasets: List[Dict[str, Any]],
        limit: Optional[int] = None,
        on_mismatch: str = "pad_nulls",
        execution_id: Optional[str] = None,
        user_role: str = "viewer",
        progress_callback=None,
        user_ctx: Optional[Dict[str, Any]] = None,
        reaggregate: Optional[Dict[str, Any]] = None,
    ) -> FederationResult:
        """UNION two or more datasets — cross-source by construction.

        ``reaggregate`` (2026-10-24, a report over a union): ``{"group_by":
        [names], "measures": [{"name", "fn"}]}`` -- each side returns its own
        GROUPED partial, so the stacked rows hold one row per group PER SIDE;
        they are grouped again here (``fn`` in sum / min / max -- a COUNT's
        partials are summed).  The cap then bounds the regrouped result.

        2026-08-22, operator ask: *"how same query will be executed cross
        sources n unioned the datasets"*.  Each entry in ``datasets``
        (``{dataset_id, column_ids, filters?, condition_ids?}``) executes
        through :meth:`execute_dataset_query` — the ONE dataset door, so RLS,
        role visibility, condition resolution, connection routing (S3 →
        DuckDB, connector → its own driver via ``_transpile_for_connector``)
        and truncation disclosure all apply per side exactly as they do for a
        single dataset.  Each side lands as a parquet artifact; the sides are
        then combined with ``cross_source_combine.build_union_combine_sql`` —
        the SAME ``UNION ALL BY NAME`` chokepoint the cross-source query path
        uses — folded pairwise for N sides (zero new SQL shapes).

        Alignment is BY NAME with typed NULL padding (DuckDB ``UNION ALL BY
        NAME``), and the decision is DISCLOSED, never silent: the result's
        ``union_report`` lists, per side, which columns were NULL-padded, and
        every column whose type differs across sides.  ``on_mismatch="fail"``
        turns any padding into a refusal instead.

        The zero-copy parts-manifest union (``build_union_parts_manifest``,
        2026-08-22 write-ladder) is deliberately NOT used here: it produces a
        parts DIRECTORY for feed delivery, while the federation execution
        store contract (paged results viewer, agg-cache write-through,
        retention) is ONE parquet file at ``output_path``.
        """
        if len(datasets) < 2:
            raise ValueError("Union needs at least 2 datasets")
        if on_mismatch not in ("pad_nulls", "fail"):
            raise ValueError(
                f"on_mismatch must be 'pad_nulls' or 'fail', got {on_mismatch!r}")

        execution_id = execution_id or str(uuid.uuid4())
        t_start = datetime.now(timezone.utc)

        def _emit(step: str, **kw):
            if progress_callback:
                try:
                    progress_callback({"step": step, "execution_id": execution_id, **kw})
                except Exception as exc:
                    logger.warning("progress_callback failed: %s", exc)

        from core import config
        # Presence rule (same as execute_merged_query): None → default page,
        # explicit <= 0 → UNLIMITED.  Never ``limit or default``.
        row_limit = (int(limit) if limit is not None
                     else int(config.semantic_layer.default_row_limit))
        if row_limit < 0:
            row_limit = 0

        # ── 1. Execute every side through the one dataset door ──────────────
        side_results: List[FederationResult] = []
        for i, spec in enumerate(datasets):
            _emit("side_query", message=f"Executing dataset {spec['dataset_id']} "
                                        f"({i + 1}/{len(datasets)})")
            side_results.append(self.execute_dataset_query(
                dataset_id=int(spec["dataset_id"]),
                column_ids=list(spec.get("column_ids") or []),
                filters=spec.get("filters"),
                condition_ids=spec.get("condition_ids"),
                limit=row_limit,
                execution_id=f"{execution_id}_s{i}",
                user_role=user_role,
                progress_callback=progress_callback,
                user_ctx=user_ctx,
            ))

        # ── 2. Describe sides, build the alignment report ────────────────────
        from core.duckdb_factory import duckdb_connection
        from core.executors.cross_source_combine import (
            build_union_combine_sql, describe_columns,
        )

        out_dir = Path(self._output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / _artifact_file_name(execution_id))

        _emit("combining", message="Combining sides (UNION ALL BY NAME)")
        combine_sqls: List[str] = []
        intermediates: List[str] = []
        with duckdb_connection() as con:
            # 2026-10-24 -- a side may carry ``rename`` ({its column: the
            # name to stack under}), e.g. a Trino side that spells ``REGION``
            # where the first side spells ``region``: BY NAME is exact, so the
            # side is rewritten with the target names FIRST, and everything
            # below (alignment report, type census, fold) sees the final names.
            side_paths: List[str] = [r.output_path for r in side_results]
            for i, spec in enumerate(datasets):
                ren = {str(k): str(v) for k, v in (spec.get("rename") or {}).items() if str(k) != str(v)}
                if not ren:
                    continue
                _q = lambda n: '"' + n.replace('"', '""') + '"'
                _lit = lambda p: "'" + p.replace("'", "''") + "'"
                renamed = str(out_dir / f"{_artifact_stem(execution_id)}_s{i}_renamed.parquet")
                con.execute(
                    f"COPY (SELECT * RENAME ({', '.join(f'{_q(k)} AS {_q(v)}' for k, v in ren.items())}) "
                    f"FROM read_parquet({_lit(side_paths[i])})) TO {_lit(renamed)} (FORMAT PARQUET)")
                side_paths[i] = renamed
                intermediates.append(renamed)
            side_cols: List[List[Tuple[str, Any]]] = [
                describe_columns(con, p) for p in side_paths]

            # Unified column set: order-preserving union across sides
            # (BF-121 __empty__ placeholder excluded — the combine SQL
            # excludes it from the projection too).
            unified: List[str] = []
            for cols in side_cols:
                for name, _t in cols:
                    if name != "__empty__" and name not in unified:
                        unified.append(name)

            # Per-column type census → promotions report.
            _types_by_col: Dict[str, Dict[str, List[int]]] = {}
            for spec, cols in zip(datasets, side_cols):
                for name, typ in cols:
                    if name == "__empty__":
                        continue
                    _types_by_col.setdefault(name, {}).setdefault(
                        str(typ), []).append(int(spec["dataset_id"]))
            type_promotions = [
                f"{col}: " + " vs ".join(
                    f"{typ} (dataset {', '.join(map(str, ds_ids))})"
                    for typ, ds_ids in typemap.items())
                for col, typemap in _types_by_col.items() if len(typemap) > 1
            ]

            sides_report = []
            for r, spec, cols in zip(side_results, datasets, side_cols):
                own = [c for c, _t in cols if c != "__empty__"]
                padded = [c for c in unified if c not in own]
                sides_report.append({
                    "dataset_id": int(spec["dataset_id"]),
                    "execution_id": r.execution_id,
                    "rows": r.total_rows,
                    "columns": own,
                    "padded_columns": padded,
                })

            if on_mismatch == "fail":
                _mismatched = [s for s in sides_report if s["padded_columns"]]
                if _mismatched:
                    raise ValueError(
                        "Union refused (on_mismatch='fail'): column sets "
                        "differ — " + "; ".join(
                            f"dataset {s['dataset_id']} lacks "
                            f"{s['padded_columns']}" for s in _mismatched) +
                        ". Re-run with on_mismatch='pad_nulls' to align by "
                        "name with typed NULL padding.")

            # ── 3. Pairwise fold through the ONE union combine builder ───────
            _regroup = bool(reaggregate and (reaggregate.get("measures") or []))
            prev_path = side_paths[0]
            for i, r in enumerate(side_results[1:], start=1):
                is_last = (i == len(side_results) - 1) and not _regroup
                fold_out = (output_path if is_last else
                            str(out_dir / f"{_artifact_stem(execution_id)}_fold{i}.parquet"))
                sql = build_union_combine_sql(
                    prev_path, side_paths[i], fold_out,
                    describe_columns(con, prev_path),
                    describe_columns(con, side_paths[i]),
                    # The cap bounds the COMBINED result only — cutting an
                    # intermediate fold would silently drop later sides.
                    limit=(row_limit if (is_last and row_limit > 0) else None),
                )
                combine_sqls.append(sql)
                con.execute(sql)
                if not is_last:
                    intermediates.append(fold_out)
                prev_path = fold_out

            if _regroup:
                _q = lambda n: '"' + str(n).replace('"', '""') + '"'
                _fns = {"sum": "SUM", "count": "SUM", "min": "MIN", "max": "MAX"}
                dims = [str(d) for d in (reaggregate.get("group_by") or [])]
                sel = [_q(d) for d in dims] + [
                    f"{_fns[str(m['fn']).lower()]}({_q(m['name'])}) AS {_q(m['name'])}"
                    for m in reaggregate["measures"]]
                _lit = "'" + prev_path.replace("'", "''") + "'"
                _out = "'" + output_path.replace("'", "''") + "'"
                sql = (f"COPY (SELECT {', '.join(sel)} FROM read_parquet({_lit})"
                       + (f" GROUP BY {', '.join(_q(d) for d in dims)}" if dims else "")
                       + (f" LIMIT {int(row_limit)}" if row_limit > 0 else "")
                       + f") TO {_out} (FORMAT PARQUET)")
                combine_sqls.append(sql)
                con.execute(sql)

            total_rows = int(con.execute(
                f"SELECT COUNT(*) FROM read_parquet('{output_path.replace(chr(39), chr(39) * 2)}')"
            ).fetchone()[0])
            out_columns = [c for c, _t in describe_columns(con, output_path)]

        for p in intermediates:
            try:
                Path(p).unlink(missing_ok=True)
            except OSError as exc:
                logger.warning("[%s] could not remove union intermediate %s: %s",
                               execution_id, p, exc)

        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Union: {total_rows} rows in {duration:.1f}s",
              total_rows=total_rows)
        logger.info("[%s] Union of datasets %s: %d rows, %d columns, %.1fs",
                    execution_id, [s["dataset_id"] for s in sides_report],
                    total_rows, len(out_columns), duration)

        _side_truncated = any(
            bool(r.row_limit and r.row_limit > 0 and r.total_rows >= r.row_limit)
            for r in side_results)
        _final_cut = bool(row_limit and row_limit > 0 and total_rows >= row_limit)
        return FederationResult(
            execution_id=execution_id,
            dataset_id=int(datasets[0]["dataset_id"]),
            merged_dataset_id=(int(datasets[1]["dataset_id"])
                               if len(datasets) == 2 else None),
            output_path=output_path,
            total_rows=total_rows,
            columns=out_columns,
            duration_seconds=round(duration, 3),
            sql_generated="\n".join(combine_sqls),
            sources_used=_label_sides([r.sources_used for r in side_results]),
            primary_rows=side_results[0].total_rows,
            secondary_rows=side_results[1].total_rows,
            row_limit=row_limit,
            truncated=True if (_side_truncated or _final_cut) else None,
            # A cut union has no ORDER BY: the kept rows are the leading
            # sides in fold order — an arbitrary sample of the union.
            unstable_truncation=True if _final_cut else None,
            execution_engine="duckdb",          # the union itself runs in DuckDB
            union_report={
                "columns": unified,
                "sides": sides_report,
                "type_promotions": type_promotions,
                "on_mismatch": on_mismatch,
            },
        )

    def get_column_distinct_values(
        self,
        *,
        dataset_id: int,
        column_id: int,
        parent_filters: Optional[List[Dict[str, Any]]] = None,
        limit: int = 500,
        user_ctx: Optional[Dict[str, Any]] = None,
        search: Optional[str] = None,
    ) -> List[Any]:
        """Get distinct values for a column (for cascading prompts / LOV).

        ``search`` (2026-10-24): a case-insensitive "contains" on the value
        as text, so a value past the list's cap can still be found.

        When parent_filters are provided, values are filtered by parent selections
        (e.g., selecting Country=US filters Region LOV to US regions).

        Phase 131 deep-dive #13: accepts ``user_ctx`` so the DISTINCT
        SELECT is rewritten by row-security policies — otherwise users
        see distinct values they shouldn't (a column-masking leak).
        """
        def _render(phys: str, base_table: str, where_sql: str,
                    temporal: bool) -> str:
            # 2026-10-02 -- a DATE column's list is NEWEST first.  The list
            # is capped, and ascending gave a business-date filter the
            # OLDEST days of the table (1992-01-01.. on a table that runs to
            # 1998-08-02) with the days anyone filters on cut off.
            order = f"{phys} DESC" if temporal else phys
            return (f"SELECT DISTINCT {phys} FROM {base_table}{where_sql} "
                    f"ORDER BY {order} LIMIT {limit}")

        df, temporal = self._run_column_lov_sql(
            dataset_id=dataset_id, column_id=column_id,
            parent_filters=parent_filters, user_ctx=user_ctx,
            render=_render, label="LOV query", search=search)
        values = df.iloc[:, 0].dropna().tolist() if len(df) > 0 else []
        # every value, not only a date-TYPED parameter's: a dropdown over a DATE
        # column offered 2025-08-31T00:00:00 on S3 (rig 2026-10-24); a non-date
        # passes through untouched
        return [_lov_temporal_value(v) for v in values]

    def get_table_column_values(
        self,
        *,
        connections: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        table_ref: str,
        column: str,
        search: Optional[str] = None,
        limit: int = 500,
        temporal: bool = False,
        user_ctx: Optional[Dict[str, Any]] = None,
        label: str = "table value list",
    ) -> List[Any]:
        """A TABLE column's distinct values, read off the source table itself
        (2026-10-24, core/reports/column_lineage.py): ``SELECT DISTINCT
        <column> FROM <table_ref>`` -- ``table_ref`` / ``column`` as the
        source query spells them -- built and row-security-rewritten in the
        SOURCE's dialect (an S3 source = DuckDB; Oracle gets FETCH FIRST),
        newest first for a date, ``search`` = a case-insensitive "contains"
        on the value as text.  Exactly ONE connection: a value list does not
        federate.  Raises on any failure; the caller words it."""
        import sqlglot
        from sqlglot import exp
        from core.sql_filter_wrapper import dialect_for_connection_type
        if len(connections) != 1:
            raise ValueError(f"a table value list reads ONE connection, not {len(connections)}")
        conn = next(iter(connections.values()))
        is_s3 = self._get_connection_type(conn) == "s3"
        dialect = "duckdb" if is_s3 else (dialect_for_connection_type(conn.get("connection_type")) or "duckdb")
        # SECURITY (2026-10-24 review): only PLAIN identifiers -- a table
        # "name" that is a function (read_csv('/etc/passwd')), a string or a
        # quoted path would make DuckDB read a FILE (replacement scan).
        col = sqlglot.parse_one(column, read=dialect)
        if not (isinstance(col, exp.Column) and isinstance(col.this, exp.Identifier)):
            raise ValueError(f"{column!r} is not a plain column name")
        tbl = sqlglot.parse_one(table_ref, read=dialect, into=exp.Table)
        if not (isinstance(tbl, exp.Table) and isinstance(tbl.this, exp.Identifier)
                and all(isinstance(tbl.args.get(k), exp.Identifier) for k in ("db", "catalog")
                        if tbl.args.get(k) is not None)
                and not any(ch in tbl.name for ch in ("/", "\\", ":", "'"))):
            raise ValueError(f"{table_ref!r} is not a plain table name")
        q = exp.select(col.copy().as_("qs_v")).distinct().from_(tbl)
        if search:
            # a LIKE wildcard the user typed is a character to find, not a wildcard
            esc = str(search).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            text = exp.Lower(this=exp.Cast(this=col.copy(), to=exp.DataType.build("VARCHAR(4000)")))
            q = q.where(exp.Escape(this=exp.Like(this=text, expression=exp.Literal.string(f"%{esc.lower()}%")),
                                   expression=exp.Literal.string("\\")))
        q = q.order_by(exp.Ordered(this=col.copy(), desc=bool(temporal))).limit(int(limit))
        sql = q.sql(dialect=dialect)
        if user_ctx is not None:
            sql = self._apply_rls_all_connections(sql, connections, user_ctx, label=label,
                                                  dialect=dialect)
        views = None
        if is_s3:
            views = self._registered_table_views_for_sql(
                sql, connections, source_tables, base_query=sql) or None
            # On DuckDB an unknown name falls through to a replacement scan
            # (a file): only a REGISTERED table of this connection is read.
            if not any(str(v[0]).lower() == tbl.name.lower() for v in (views or [])):
                raise ValueError(f"{table_ref!r} is not a registered table of this connection")
        df = self._execute_query(sql=sql, connections=connections, source_tables=source_tables,
                                 execution_id=str(uuid.uuid4()), table_views=views)
        values = df.iloc[:, 0].dropna().tolist() if len(df) > 0 else []
        # every value, not only a date-TYPED parameter's: a dropdown over a DATE
        # column offered 2025-08-31T00:00:00 on S3 (rig 2026-10-24); a non-date
        # passes through untouched
        return [_lov_temporal_value(v) for v in values]

    def get_column_value_range(
        self,
        *,
        dataset_id: int,
        column_id: int,
        parent_filters: Optional[List[Dict[str, Any]]] = None,
        user_ctx: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Any, Any]:
        """(MIN, MAX) of a column over the same scope as its value list.

        2026-10-03 -- when a date column's value list is CUT (``truncated``),
        the picker says which dates exist from MIN..MAX instead of silently
        hiding the older ones.  Same base expression, the same parent
        (cascade) filters and the same row security as
        ``get_column_distinct_values`` -- one scope, two questions.
        """
        def _render(phys: str, base_table: str, where_sql: str,
                    temporal: bool) -> str:
            return (f"SELECT MIN({phys}) AS qs_lo, MAX({phys}) AS qs_hi "
                    f"FROM {base_table}{where_sql}")

        df, temporal = self._run_column_lov_sql(
            dataset_id=dataset_id, column_id=column_id,
            parent_filters=parent_filters, user_ctx=user_ctx,
            render=_render, label="LOV range query")
        if len(df) == 0:
            return None, None
        lo, hi = df.iloc[0, 0], df.iloc[0, 1]
        _none = lambda v: None if v is None or (isinstance(v, float) and v != v) else v  # noqa: E731
        lo, hi = _none(lo), _none(hi)
        if temporal:
            lo, hi = _lov_temporal_value(lo), _lov_temporal_value(hi)
        return lo, hi

    def _run_column_lov_sql(self, *, dataset_id: int, column_id: int,
                            parent_filters: Optional[List[Dict[str, Any]]],
                            user_ctx: Optional[Dict[str, Any]],
                            render, label: str, search: Optional[str] = None):
        """THE scope a column's value list is read over: the dataset's base
        expression, the parent (cascade) filters, row security.  Returns
        ``(dataframe, is_temporal)``; ``render(phys, base, where, temporal)``
        supplies the SELECT."""
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        # the source's types reach the drill's filters too (2026-10-25)
        self._annotate_source_types(ds, ds.get("columns", []) or [])
        col_map = {c["id"]: c for c in ds.get("columns", [])}
        col = col_map.get(column_id)
        if not col:
            raise ValueError(f"Column {column_id} not found in dataset {dataset_id}")

        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        relationships = ds.get("relationships", [])

        phys = self._quote_ident(col["physical_name"])

        # 2026-08-02 sweep: resolve parent filters BEFORE the base-table
        # expression so the iceberg file enumeration can prune on them.
        where_parts = []
        filter_specs: List[FilterSpec] = []
        if parent_filters:
            filter_specs = self._resolve_filters(parent_filters, col_map)
            for f in filter_specs:
                clause = self._filter_to_sql(f)
                if clause:
                    where_parts.append(clause)

        # 2026-08-22: base_query-aware (was _resolve_base_table → "DUAL" on
        # every custom-SQL dataset → LOV always failed).
        base_table = self._base_from_expression(
            ds, connections, source_tables,
            filter_specs=filter_specs or None,
            relationships=relationships)

        if search:
            where_parts.append(_contains_text_clause(phys, search))
        where_sql = f" WHERE {' AND '.join(where_parts)}" if where_parts else ""
        temporal = _is_temporal_column(col)
        sql = render(phys, base_table, where_sql, temporal)

        # Phase 131 deep-dive #13: apply RLS to LOV queries too.
        # 2026-08-22: per DISTINCT connection (the stricter execute-path
        # rule), not just the first — see _apply_rls_all_connections.
        if user_ctx is not None:
            sql = self._apply_rls_all_connections(
                sql, connections, user_ctx,
                label=f"{label} on dataset {dataset_id} col {column_id}")

        _table_views = None
        if (ds.get("base_query") or "").strip():
            # 2026-10-02: a cascading LOV's parent filters prune the view's
            # file list too, under the same lineage proof as execute.
            _table_views = self._registered_table_views_for_sql(
                sql, connections, source_tables,
                base_query=ds.get("base_query"),
                filter_specs=filter_specs or None) or None

        df = self._execute_query(
            sql=sql,
            connections=connections,
            source_tables=source_tables,
            execution_id=str(uuid.uuid4()),
            table_views=_table_views,
        )
        return df, temporal

    def preview_dataset(
        self,
        *,
        dataset_id: int,
        limit: int = 100,
        user_role: str = "viewer",
        user_ctx: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Quick preview of a dataset's data — first N rows of all visible columns.

        Phase 131 deep-dive #13 (round 3): accepts ``user_ctx`` so the
        preview is RLS-rewritten too — preview was bypassing policies.
        """
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        all_columns = ds.get("columns", [])
        # Filter by role
        visible = [
            c for c in all_columns
            if not c.get("is_hidden")
            and (not c.get("role_whitelist") or user_role in c["role_whitelist"])
        ]

        if not visible:
            return {"columns": [], "rows": [], "total_rows": 0,
                    "row_limit": limit, "truncated": False,
                    "truncation_note": ""}

        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        # 2026-08-22: base_query-aware (was _resolve_base_table → "DUAL" on
        # every custom-SQL dataset → preview always failed).
        base_table = self._base_from_expression(ds, connections, source_tables)

        col_exprs = ", ".join(self._quote_ident(c["physical_name"]) for c in visible)
        sql = f"SELECT {col_exprs} FROM {base_table} LIMIT {limit}"

        # Phase 131 deep-dive #13 (round 3): RLS rewrite on preview too.
        # 2026-08-22: per DISTINCT connection (the stricter execute-path
        # rule), not just the first — see _apply_rls_all_connections.
        if user_ctx is not None:
            sql = self._apply_rls_all_connections(
                sql, connections, user_ctx,
                label=f"preview on dataset {dataset_id}")

        _table_views = None
        if (ds.get("base_query") or "").strip():
            # 2026-10-02: the base query's own WHERE prunes the view's files.
            _table_views = self._registered_table_views_for_sql(
                sql, connections, source_tables,
                base_query=ds.get("base_query")) or None

        df = self._execute_query(
            sql=sql,
            connections=connections,
            source_tables=source_tables,
            execution_id=str(uuid.uuid4()),
            table_views=_table_views,
        )

        # 2026-08-20 — a CAP may throttle; it may not LIE.  ``df`` is bounded
        # by the injected LIMIT, so ``total_rows`` here has always been the
        # POST-CAP count: a dataset bigger than the preview limit reported
        # total_rows == limit and consumers read that as "this is the whole
        # dataset".  Same fix shape as embed_api (2026-08-09): the number
        # keeps its meaning (returned rows), and the response now DISCLOSES
        # the bound.  ``truncated`` is True exactly when the cap was hit —
        # at the ceiling the real total is unknown and must not be implied.
        _returned = len(df)
        _hit_ceiling = _returned >= limit
        return {
            "columns": [
                {"physical_name": c["physical_name"], "friendly_name": c["friendly_name"],
                 "column_type": c["column_type"], "data_type": c.get("data_type", "string")}
                for c in visible
            ],
            "rows": sanitize_for_json(df.to_dict(orient="records")),
            "total_rows": _returned,
            "row_limit": limit,
            "truncated": _hit_ceiling,
            "truncation_note": (
                f"Showing the first {_returned:,} rows — the preview row "
                f"limit of {limit:,} was reached, so this is NOT the "
                f"complete dataset."
                if _hit_ceiling else ""
            ),
        }

    # ── Internal: DataFrame post-filtering (for cache hits) ─────────────────

    def _apply_filters_to_df(self, df: pd.DataFrame,
                             filter_specs: list) -> pd.DataFrame:
        """Apply FilterSpec list to a pandas DataFrame (post-cache-hit filtering).

        2026-08-13 -- EVERY unapplied filter now RAISES.  This method serves
        the agg-cache paths (``load_df`` -> here, lines ~810 and ~895), so a
        skipped predicate meant a CACHED CUBE SERVED WITHOUT THE USER'S
        FILTER: wrong aggregate numbers presented as correct, which is the
        worst outcome this product has.  Three ways it could skip silently:
        a column missing from the cached frame, a non-list IN value, and an
        unrecognised operator (there was no ``else`` at all).

        Raising is SAFE here and is the correct degradation: the callers'
        surrounding exception fence falls through to LIVE execution ("Any
        load failure falls through to live"), so an inapplicable filter costs
        a recompute instead of returning a wrong number.

        A test in test_149_5_federation_probe_enhancements already warned
        that a lost operator would make emitted filters "silently no-op" --
        it pinned the risk with a source-text assertion rather than removing
        it.
        """
        for f in filter_specs:
            col = f.physical_name
            if col not in df.columns:
                raise ValueError(
                    f"Cached result has no column '{col}' to filter on "
                    f"(columns: {list(df.columns)[:20]}).  Refusing to serve "
                    f"it unfiltered — re-executing live instead."
                )
            op = f.operator
            if op == "eq":
                df = df[df[col] == f.value]
            elif op == "neq":
                # 2026-08-22 -- match LIVE SQL three-valued logic.  Pandas
                # ``!=`` keeps NULL rows; SQL ``col != v`` drops them.  The
                # cached cube and the live execution must return the SAME
                # row set for the same filter, or a cache hit silently
                # changes aggregate numbers on NULL-bearing columns.
                df = df[(df[col] != f.value) & df[col].notna()]
            elif op == "gt":
                df = df[df[col] > f.value]
            elif op == "gte":
                df = df[df[col] >= f.value]
            elif op == "lt":
                df = df[df[col] < f.value]
            elif op == "lte":
                df = df[df[col] <= f.value]
            elif op == "like":
                pattern = str(f.value).replace("%", ".*")
                df = df[df[col].astype(str).str.contains(
                    pattern, case=False, regex=True, na=False)]
            elif op in ("in", "not_in"):
                # Same coercion as the SQL path and sql_filter_wrapper -- one
                # answer to "what is an IN-list?".  A non-list value used to
                # fall through both branches and apply NOTHING.
                items = self._coerce_in_list(f.value)
                if not items:
                    raise ValueError(
                        f"Filter on '{col}' uses operator '{op}' with no "
                        f"usable values ({f.value!r}) — refusing to serve "
                        f"cached rows without it."
                    )
                mask = df[col].isin(items)
                # NOT IN must also drop NULLs (SQL 3VL) -- see neq above.
                df = df[mask] if op == "in" \
                    else df[~mask & df[col].notna()]
            elif op == "between":
                df = df[(df[col] >= f.value) & (df[col] <= f.value2)]
            elif op == "is_null":
                df = df[df[col].isna()]
            elif op == "is_not_null":
                df = df[df[col].notna()]
            else:
                # There was NO else: an unrecognised operator applied nothing
                # and the cached rows were returned as if filtered.
                raise ValueError(
                    f"Filter on '{col}' uses operator '{op}', which the "
                    f"cached-result filter cannot apply.  Refusing to serve "
                    f"unfiltered cached rows — re-executing live instead."
                )
        return df

    # ── Internal: Column resolution ──────────────────────────────────────────

    def _annotate_source_types(self, ds: Dict[str, Any],
                               columns: List[Dict[str, Any]]) -> None:
        """FB-42: stamp ``_source_data_type`` on each column dict from the
        column catalog's DECLARED type for the dataset's tables.  Reads the
        local catalog only (``ColumnCatalog.get_entry`` never touches the
        source); best-effort -- a missing catalog, an unknown spelling or a
        query-sourced dataset leaves the stored type as the only fact."""
        tables = ds.get("source_tables") or []
        if not tables or not columns:
            return
        try:
            from core.schema_catalog import ColumnCatalog
            from core.source_types import driver_data_type
            catalog = ColumnCatalog(self._db)
        except Exception as exc:                        # noqa: BLE001
            logger.debug("source-type annotation unavailable: %s", exc)
            return
        declared: Dict[str, str] = {}
        for t in tables:
            if not isinstance(t, dict):
                continue
            try:
                entry = catalog.get_entry(int(t.get("connection_id") or 0),
                                          str(t.get("table") or ""))
            except Exception as exc:                    # noqa: BLE001
                logger.debug("source-type lookup failed for %s: %s", t, exc)
                continue
            if not (entry or {}).get("columns"):
                # 2026-10-25 -- a table nobody browsed is not in the local
                # catalog, and then the dataset's LABEL decided how a value
                # was written (report 254: id IN ('1', ...) on a bigint).
                # Ask the source once and record it in the catalog.
                entry = self._probe_source_columns(catalog, t)
            for c in (entry or {}).get("columns") or []:
                if not isinstance(c, dict):
                    continue
                name = str(c.get("name") or "").casefold()
                mapped = driver_data_type(c.get("data_type") or c.get("type"))
                if name and mapped:
                    declared.setdefault(name, mapped)
        if not declared:
            return
        for col in columns:
            src = declared.get(str(col.get("physical_name") or "").casefold())
            if src:
                col["_source_data_type"] = src

    def _probe_source_columns(self, catalog: Any, t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """One DESCRIBE of a SQL source's table (pooled connector), recorded in
        the column catalog -- so the next run reads it locally.  Fail-open:
        None when the connection is not SQL, unreadable or refuses."""
        try:
            cid = int(t.get("connection_id") or 0)
            table = str(t.get("table") or "")
            conn = self._db.get_connection_raw(cid) if cid else None
            if not conn or not table or self._get_connection_type(conn) != "sql":
                return None
            from core.column_types import _split_table_ref
            from core.connection_pool import get_pooled_connector
            cfg = conn.get("config") or {}
            parts = _split_table_ref(table, cfg)
            if not parts:
                return None
            with get_pooled_connector(cid, conn.get("connection_type", ""), cfg,
                                      conn.get("name", "")) as connector:
                cols = list(connector.list_columns(*parts) or [])
            if not cols:
                return None
            shaped = [{"name": c.get("name"), "type": c.get("type")} for c in cols if c.get("name")]
            try:
                catalog.record_columns(cid, table, shaped, source="schema_read")
            except Exception as exc:                    # noqa: BLE001 -- the answer still counts
                logger.debug("catalog record after type probe failed for %s: %s", table, exc)
            return {"columns": [{"name": c["name"], "data_type": c.get("type")} for c in shaped]}
        except Exception as exc:                        # noqa: BLE001 -- the label then decides, as before
            logger.debug("source-type probe failed for %s: %s", t, exc)
            return None

    def _resolve_columns(
        self,
        column_ids: List[int],
        col_map: Dict[int, Dict[str, Any]],
        user_role: str,
    ) -> List[ColumnSelection]:
        """Resolve column IDs to ColumnSelection objects, respecting role visibility.

        2026-08-22 — a requested column that cannot be served is a REFUSAL,
        not a skip.  This used to ``logger.warning(...); continue`` on both an
        unknown id (stale saved report after a column was deleted) and a
        role-restricted id.  A silently dropped DIMENSION changes the
        GROUP BY grain, so the aggregates that come back are DIFFERENT
        NUMBERS presented as the answer to the original question — the
        "unselected column looks exactly like a NULL one" defect class.  A
        correctness gate must FAIL; only caps may throttle.
        """
        missing: List[int] = []
        forbidden: List[int] = []
        result = []
        for cid in column_ids:
            col = col_map.get(cid)
            if not col:
                missing.append(cid)
                continue
            # Role check
            whitelist = col.get("role_whitelist") or []
            if whitelist and user_role not in whitelist:
                forbidden.append(cid)
                continue
            result.append(ColumnSelection(
                column_id=cid,
                physical_name=col["physical_name"],
                friendly_name=col.get("friendly_name", col["physical_name"]),
                column_type=col.get("column_type", "dimension"),
                aggregation=col.get("aggregation", ""),
                data_type=str(col.get("data_type") or ""),     # FB-26
                source_data_type=str(col.get("_source_data_type") or ""),   # FB-42
            ))
        if missing or forbidden:
            parts = []
            if missing:
                parts.append(
                    f"column id(s) {sorted(missing)} do not exist on this "
                    f"dataset (deleted or never created — refresh the report's "
                    f"column selection)")
            if forbidden:
                parts.append(
                    f"column id(s) {sorted(forbidden)} are not visible to "
                    f"role '{user_role}' (role_whitelist)")
            raise ValueError(
                "Cannot serve the requested columns: " + "; ".join(parts) +
                ". Refusing to run with a silently reduced column set — the "
                "aggregation grain would change and the numbers would be "
                "wrong without any visible signal.")
        return result

    def _resolve_filters(
        self,
        raw_filters: List[Dict[str, Any]],
        col_map: Dict[int, Dict[str, Any]],
    ) -> List[FilterSpec]:
        result = []
        for f in raw_filters:
            # ── AN UNRECOGNISED KEY IS NOT AN EMPTY ONE (2026-09-20) ──────
            # ``filters`` is untyped in the request schema (List[Dict[str,
            # Any]]), so a dict reaches here with WHATEVER keys the caller
            # sent and this loop reads the four it knows by name.  A filter
            # spelled ``{"column_id": 5, "operator": "in", "values": [...]}``
            # — ``values`` for ``value`` — therefore became ``value=None``:
            # the predicate silently lost its operand, the query returned
            # MORE rows than were asked for, and the answer looked correct.
            #
            # Same class as the island-never-formed incident: an unrecognised
            # SPELLING and a deliberate refusal are indistinguishable, and
            # both fail OPEN.  The engine already refuses the harder cases
            # loudly (a bad operator, an unresolvable column_id); the unknown
            # KEY was the one unguarded door.
            #
            # A CORRECTNESS GATE FAILS.  Refuse, and name both the key we did
            # not understand and the set we do.
            if isinstance(f, dict):
                _unknown = sorted(set(f) - _FILTER_KEYS)
                if _unknown:
                    raise ValueError(
                        f"Filter contains unrecognised key(s) {_unknown}. "
                        f"Recognised keys: {sorted(_FILTER_KEYS)}. Refusing "
                        f"to run the query rather than silently ignoring "
                        f"them -- an ignored filter component returns MORE "
                        f"rows than asked for and the result looks correct.")
            cid = f.get("column_id")
            col = col_map.get(cid) if cid else None
            if not col:
                # 2026-09-17 -- WAS ``continue``, and that is the CLAUDE.md s4
                # invariant exactly: "a filter that cannot be rendered must
                # refuse, never silently drop (it would return MORE rows)".
                #
                # Measured live on a business report: an extra_filter naming a
                # column_id that does not exist -- or one belonging to ANOTHER
                # dataset -- vanished, the query ran with NO WHERE clause at
                # all, and the answer came back 200 with five regions instead
                # of the one that was asked for.  Every number larger than the
                # truth, nothing to indicate it.
                #
                # The engine already refuses the HARDER case loudly: an
                # unsupported OPERATOR raises and lists the supported set.  So
                # a malformed filter was caught and an unresolvable one was
                # not -- the easy half was the unguarded one.
                _known = sorted(col_map.keys())
                raise ValueError(
                    f"Filter references column_id {cid!r}, which is not a "
                    f"column of this dataset. Available column_ids: "
                    f"{_known[:40]}{' ...' if len(_known) > 40 else ''}. "
                    f"Refusing to run the query without the filter -- "
                    f"dropping it would return MORE rows than asked for, and "
                    f"the result would look correct.")
            result.append(FilterSpec(
                column_id=cid,
                physical_name=col["physical_name"],
                operator=f.get("operator", "eq"),
                value=f.get("value"),
                value2=f.get("value2"),
                data_type=str(col.get("data_type") or ""),
                source_data_type=str(col.get("_source_data_type") or ""),
            ))
        return result

    def _resolve_order_by(
        self,
        raw_order: List[Dict[str, Any]],
        col_map: Dict[int, Dict[str, Any]],
    ) -> List[OrderBySpec]:
        result = []
        for o in raw_order:
            cid = o.get("column_id")
            col = col_map.get(cid) if cid else None
            if not col:
                # DELIBERATELY lenient, unlike _resolve_filters above, and the
                # asymmetry is the point: an unresolvable ORDER BY changes the
                # ORDER of the rows, never WHICH rows.  A filter is a
                # correctness gate and must fail; ordering is a presentation
                # preference and degrading it is survivable.  Logged so it is
                # not invisible.
                logger.warning(
                    "order_by references column_id %r, which is not a column "
                    "of this dataset -- ignoring it. Rows are unaffected; "
                    "only their order is.", cid)
                continue
            result.append(OrderBySpec(
                column_id=cid,
                physical_name=col["physical_name"],
                direction=o.get("direction", "asc"),
            ))
        return result

    # ── Internal: Connection resolution ──────────────────────────────────────

    def _resolve_connections(self, ds: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
        """Load raw (decrypted) connection configs for all connection_ids in a dataset."""
        conn_ids = ds.get("connection_ids", [])
        result = {}
        for cid in conn_ids:
            conn = self._db.get_connection_raw(cid)
            if conn:
                result[cid] = conn
            else:
                # 2026-11-04: this logged and carried on, so a dataset whose connection was gone
                # ran on the local engine with no source at all.  A gate must fail.
                logger.warning("Connection %d not found for dataset %s", cid, ds.get("name"))
                raise ValueError(f"The connection this dataset uses (id {cid}) no longer exists. Open the "
                                 f"dataset, go to its Source tab, and choose the connection it runs on.")
        return result

    def _get_connection_type(self, conn: Dict[str, Any]) -> str:
        """Determine if a connection is S3-based or SQL-based."""
        ct = (conn.get("connection_type") or "").lower()
        if ct in S3_CONNECTION_TYPES or ct == "s3":
            return "s3"
        return "sql"

    # ── Internal: SQL generation ─────────────────────────────────────────────

    def _build_query(
        self,
        *,
        selected: List[ColumnSelection],
        filter_specs: List[FilterSpec],
        cond_clauses: List[str],
        order_specs: List[OrderBySpec],
        limit: int,
        source_tables: List[Dict[str, Any]],
        relationships: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
        base_query: str = "",
        decompose_avg: bool = False,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """Generate SQL from semantic layer metadata.

        Returns (sql_string, source_info_list).
        """
        # If dataset has a base_query (custom SQL), use it as a CTE
        if base_query.strip():
            # 2026-10-14 -- warehouse-dialect SQL translated for DuckDB on S3
            # (the ONE rule: _base_query_as_engine_runs)
            base_query = self._base_query_as_engine_runs(base_query, connections)
            return self._build_from_base_query(
                base_query=base_query,
                selected=selected,
                filter_specs=filter_specs,
                cond_clauses=cond_clauses,
                order_specs=order_specs,
                limit=limit,
                decompose_avg=decompose_avg,
            )

        # Determine the base table expression
        # 2026-08-02 sweep: thread the user's filters into the iceberg
        # file enumeration (was: unconditional full enumeration).
        base_table = self._resolve_base_table(
            source_tables, connections,
            filter_specs=filter_specs, relationships=relationships)
        source_info = [{"table": base_table, "type": "primary"}]

        # Build JOIN clauses from relationships
        join_clauses = []
        for rel in relationships:
            join_type = (rel.get("join_type") or "inner").upper()
            right_table = rel.get("right_table", "")
            # Resolve right table to DuckDB expression.  Only filters
            # explicitly qualified to the right table are forwarded
            # (single_table_scope=False — a joined dataset is never a
            # single-table scope).
            right_expr = self._table_to_expression(
                right_table, source_tables, connections,
                filter_specs=filter_specs, single_table_scope=False)
            join_keys = rel.get("join_keys", [])
            on_parts = []
            for jk in join_keys:
                left_col = self._quote_ident(jk.get("left", ""))
                right_col = self._quote_ident(jk.get("right", ""))
                left_table = rel.get("left_table", "")
                # Use table aliases
                on_parts.append(f"{self._quote_ident(left_table)}.{left_col} = {self._quote_ident(right_table)}.{right_col}")
            on_clause = " AND ".join(on_parts) if on_parts else "1=1"
            join_clauses.append(f"{join_type} JOIN {right_expr} AS {self._quote_ident(right_table)} ON {on_clause}")
            source_info.append({"table": right_table, "type": "joined"})

        # SELECT clause — dimensions as-is, measures wrapped in aggregation
        select_parts = []
        group_by_parts = []
        has_aggregation = False

        for col in selected:
            sel, grp, agg = self._column_select_terms(
                col, decompose_avg=decompose_avg)
            select_parts.extend(sel)
            group_by_parts.extend(grp)
            has_aggregation = has_aggregation or agg

        # FROM clause
        from_clause = f"{base_table}"
        if source_tables and len(source_tables) > 0:
            first_table = source_tables[0].get("table", "")
            if first_table:
                from_clause = f"{base_table} AS {self._quote_ident(first_table)}"

        # WHERE clause
        where_parts = []
        for f in filter_specs:
            clause = self._filter_to_sql(f)
            if clause:
                where_parts.append(clause)
        for cond in cond_clauses:
            where_parts.append(f"({cond})")

        # Assemble SQL
        sql = f"SELECT {', '.join(select_parts)}"
        sql += f"\nFROM {from_clause}"
        if join_clauses:
            sql += "\n" + "\n".join(join_clauses)
        if where_parts:
            sql += f"\nWHERE {' AND '.join(where_parts)}"
        if has_aggregation and group_by_parts:
            sql += f"\nGROUP BY {', '.join(group_by_parts)}"
        if order_specs:
            order_parts = []
            for o in order_specs:
                direction = o.direction.upper() if o.direction.upper() in VALID_DIRECTIONS else "ASC"
                order_parts.append(f"{self._quote_ident(o.physical_name)} {direction}")
            sql += f"\nORDER BY {', '.join(order_parts)}"
        # limit <= 0 = UNLIMITED (2026-08-11).  ``federation.max_result_rows``
        # now ships DISABLED, and the callers that used to pass it as their
        # bound (agg_cache cube builds) therefore pass 0.  Emitting ``LIMIT 0``
        # would return nothing, and silently swapping in
        # ``semantic_layer.default_row_limit`` would rebuild a cube from 10k of
        # its rows and then serve it as complete.
        if int(limit) > 0:
            sql += f"\nLIMIT {int(limit)}"

        return sql, source_info

    def _column_select_terms(
        self, col: "ColumnSelection", *, decompose_avg: bool = False,
    ) -> Tuple[List[str], List[str], bool]:
        """How ONE selected column becomes SELECT terms.

        Returns ``(select_terms, group_by_terms, aggregates)``.

        THE single vocabulary for turning a ColumnSelection into SQL,
        shared by both builders.  It exists because they disagreed:
        ``_build_query`` (the table path) resolved a calculated metric to
        its EXPRESSION, and ``_build_from_base_query`` (the custom-SQL
        path) had no metric branch at all -- it emitted the metric's
        ALIAS as a bare column, so every custom-SQL dataset carrying a
        metric died with

            Binder Error: Referenced column "<metric>" not found in
            FROM clause

        That was known: business_reports_api recorded it on 2026-08-30
        as VERIFIED BY EXECUTION, and the response was to REFUSE metrics
        on base_query datasets at report-config time.  The refusal
        guarded one caller; datasets_api hit the same engine gap
        unguarded, and the capability stayed unreachable for every
        custom-SQL dataset.

        Two builders holding one contract is the defect; a second copy
        of this branch would be the same defect again.  So there is one
        function, and adding a column kind means changing it once.
        """
        phys = self._quote_ident(col.physical_name)
        select_terms: List[str] = []
        group_by_terms: List[str] = []

        # A calculated metric carries its own aggregation inside the
        # expression, so it is never grouped BY.
        if col.is_metric and col.expression:
            return [f"({col.expression}) AS {phys}"], [], True

        if col.column_type in ("measure", "kpi") and col.aggregation:
            agg = col.aggregation.upper()
            if agg not in VALID_AGGREGATIONS:
                logger.warning(
                    "Invalid aggregation '%s' for column %s, treating as "
                    "dimension", agg, col.physical_name)
                return [phys], [phys], False
            # FB-26 (2026-09-19): a CORRECTNESS gate, so it FAILS.  A stored
            # type is trusted by this builder, which cannot check it against
            # the source; when the stored type itself says the column is
            # text / boolean / date, SUM or AVG over it is SQL every engine
            # rejects -- and each rejection counts against the source's
            # circuit breaker.  Refuse with the column, the type, the
            # aggregation and the fix, before any SQL is sent.  COUNT, MIN,
            # MAX and COUNT_DISTINCT are valid on any type and pass.
            # FB-42: the SOURCE's declared type outranks the stored one --
            # a dataset created before the FB-26 fix stores "number" for a
            # varchar, and a gate that reads only that record cannot see
            # the class it exists for.
            # 2026-11-05 (the owner: "we can change datatype and it should convert"): text in the
            # source + number on the dataset is CONVERTED.  CAST, not TRY_CAST: a value that is not
            # a number must fail in the source's words, never become NULL and shrink a total.
            _operand = phys
            _effective = (col.source_data_type or col.data_type or "").lower()
            if (agg in _NUMERIC_ONLY_AGGREGATIONS
                    and (col.data_type or "").lower() == "number"
                    and (col.source_data_type or "").lower() == "string"):
                _operand = f"CAST({phys} AS DECIMAL(38,10))"
            elif agg in _NUMERIC_ONLY_AGGREGATIONS and \
                    _effective in _NON_NUMERIC_DATA_TYPES:
                if col.source_data_type and col.source_data_type != (col.data_type or ""):
                    raise ValueError(
                        f"Column '{col.physical_name}' is stored as "
                        f"'{col.data_type}' with aggregation {agg}, but the "
                        f"source declares it '{col.source_data_type}', which "
                        f"SUM/AVG cannot aggregate -- the stored type is "
                        f"wrong.  Run POST /api/datasets/{{id}}/auto-detect "
                        f"to reconcile the column from the source (it will be "
                        f"re-typed and its aggregation dropped; reports keep "
                        f"referencing it by id).")
                raise ValueError(
                    f"Column '{col.physical_name}' is typed "
                    f"'{col.data_type}' but its aggregation is {agg}, which "
                    f"only a numeric column supports; the source would "
                    f"reject SUM/AVG over it.  Fix the dataset column: set "
                    f"its aggregation to count / count_distinct / min / max, "
                    f"make it a dimension, or correct its data_type if the "
                    f"column really is numeric.")
            if agg == "COUNT_DISTINCT":
                return [f"COUNT(DISTINCT {phys}) AS {phys}"], [], True
            select_terms.append(f"{agg}({_operand}) AS {phys}")
            if agg == "AVG" and decompose_avg:
                # Phase 5 RLS-aware cubes: SUM/COUNT pair so the stored
                # average re-aggregates exactly (an AVG cannot be
                # re-derived from stored averages).
                select_terms.append(
                    f"SUM({_operand}) AS "
                    f"{self._quote_ident(col.physical_name + '__sum')}")
                select_terms.append(
                    f"COUNT({_operand}) AS "
                    f"{self._quote_ident(col.physical_name + '__cnt')}")
            return select_terms, [], True

        return [phys], [phys], False

    @staticmethod
    def _base_query_projection(base_query: str) -> Optional[set]:
        """The column names the base query RETURNS, or None if unknowable.

        ``None`` means "cannot tell" and is never treated as "returns
        nothing" — a ``SELECT *``, an unparsable statement or a dialect
        the parser does not know must not make the caller refuse a
        perfectly good report.  That distinction is the whole safety of
        the guard below.
        """
        try:
            from core.sql_output_columns import derive_columns_from_sql_text
            cols = derive_columns_from_sql_text(base_query or "")
        except Exception as exc:            # noqa: BLE001
            logger.debug("base-query projection unreadable (%s)", exc)
            return None
        names = {(c.get("physical_name") or "").casefold()
                 for c in (cols or []) if c.get("physical_name")}
        return names or None

    def _assert_columns_are_projected(
        self, base_query: str, selected: List["ColumnSelection"],
        filter_specs: List["FilterSpec"],
        order_specs: List["OrderBySpec"],
    ) -> None:
        """Refuse to reference a column the base query does not return.

        2026-09-04 — reported as *"created dataset unable to execute query
        on starburst column_NOT_FOUND"*.  The dataset held three columns
        (``system_id``, ``source_data_set``, ``sap_account_level_4_name``)
        that the base query uses ONLY IN ITS WHERE CLAUSE and does not
        project.  They had been projected by an EARLIER version of the
        query — the statement still carries a ``/* code change */``
        marker — and nothing reconciled the dataset when the query was
        edited.

        The report then selected them, and this builder wrapped the query
        and emitted ``SELECT "system_id" ... FROM (...) AS _base``.  That
        is valid SQL against a relation that does not have the column, so
        the failure surfaced at the SOURCE as COLUMN_NOT_FOUND — naming
        the column but explaining nothing: not that the dataset is stale,
        not which query stopped returning it, not what to do.

        A column that is not projected is unusable in EVERY position —
        select, filter and order-by all reference ``_base`` — so all three
        are checked here rather than only the projection.

        Refusing rather than dropping: silently dropping a selected column
        changes the report's shape, and a report that quietly returns
        fewer columns than it was built with is the failure this codebase
        exists to prevent.
        """
        projected = self._base_query_projection(base_query)
        if not projected:
            return                      # cannot tell — never refuse

        wanted: List[Tuple[str, str]] = []
        for c in selected or []:
            # A calculated METRIC's physical_name is the ALIAS of an
            # expression the builder injects (``(expr) AS margin_pct``) —
            # it is not, and must not be, a column of the base query.
            # What has to be projected are the columns INSIDE the
            # expression, and those are the author's SQL to get right;
            # demanding the alias itself refuses every metric on a
            # custom-SQL dataset, which is what the first version of this
            # guard did (5 tests, immediately).
            if getattr(c, "is_metric", False) and getattr(c, "expression", ""):
                continue
            wanted.append((c.physical_name, "selected"))
        for f in filter_specs or []:
            wanted.append((f.physical_name, "filtered on"))
        for o in order_specs or []:
            wanted.append((getattr(o, "physical_name", ""), "sorted by"))

        missing = []
        seen = set()
        for name, why in wanted:
            key = (name or "").casefold()
            if not key or key in seen or key in projected:
                continue
            seen.add(key)
            missing.append((name, why))

        if not missing:
            return

        detail = ", ".join(f"'{n}' ({why})" for n, why in missing)
        raise ValueError(
            f"This report uses {len(missing)} column(s) the dataset's query "
            f"no longer returns: {detail}. The query selects "
            f"{len(projected)} column(s), and these are not among them. "
            f"A column a query only FILTERS ON is not a column it "
            f"RETURNS — so a dataset column that is not in the SELECT "
            f"list cannot be selected, filtered or sorted downstream. "
            f"Re-run auto-detect on the dataset to reconcile its "
            f"columns, then remove these from the report. "
            f"Running as-is would fail at the source with COLUMN_NOT_FOUND."
        )

    def _build_from_base_query(
        self,
        *,
        base_query: str,
        selected: List[ColumnSelection],
        filter_specs: List[FilterSpec],
        cond_clauses: List[str],
        order_specs: List[OrderBySpec],
        limit: int,
        decompose_avg: bool = False,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """Build a query wrapping a user-defined base_query as a CTE."""
        # Checked BEFORE anything is rendered: the message names the
        # columns and the fix, where the source's COLUMN_NOT_FOUND names
        # only the first column it happened to reject.
        self._assert_columns_are_projected(
            base_query, selected, filter_specs, order_specs)
        select_parts = []
        group_by_parts = []
        has_agg = False

        for col in selected:
            sel, grp, agg = self._column_select_terms(
                col, decompose_avg=decompose_avg)
            select_parts.extend(sel)
            group_by_parts.extend(grp)
            has_agg = has_agg or agg

        where_parts = []
        for f in filter_specs:
            clause = self._filter_to_sql(f)
            if clause:
                where_parts.append(clause)
        for cond in cond_clauses:
            where_parts.append(f"({cond})")

        # The alias comes from the ONE declaration that checks it against
        # every verified engine's identifier rule.  It was the literal
        # ``_base`` until 2026-09-15: legal on DuckDB and Trino, ORA-00911
        # on Oracle, so every custom-SQL dataset on an Oracle connection
        # failed at its first execute while auto-detect (which runs the
        # base query unwrapped) succeeded.  The spark_k8s lane fixed the
        # same alias defect two days earlier (``qs_subq``); this is the
        # other twin.
        from core.sql_connector_dialect import BASE_QUERY_ALIAS
        sql = (f"WITH {BASE_QUERY_ALIAS} AS (\n"
               f"{base_query.rstrip().rstrip(';')}\n)\n")
        sql += f"SELECT {', '.join(select_parts)}\nFROM {BASE_QUERY_ALIAS}"
        if where_parts:
            sql += f"\nWHERE {' AND '.join(where_parts)}"
        if has_agg and group_by_parts:
            sql += f"\nGROUP BY {', '.join(group_by_parts)}"
        if order_specs:
            parts = [
                f"{self._quote_ident(o.physical_name)} {o.direction.upper() if o.direction.upper() in VALID_DIRECTIONS else 'ASC'}"
                for o in order_specs
            ]
            sql += f"\nORDER BY {', '.join(parts)}"
        if int(limit) > 0:          # limit <= 0 = UNLIMITED — see _build_query
            sql += f"\nLIMIT {int(limit)}"

        return sql, [{"table": f"{BASE_QUERY_ALIAS} (custom SQL)",
                      "type": "base_query"}]

    def _resolve_base_table(
        self,
        source_tables: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
        filter_specs: Optional[List["FilterSpec"]] = None,
        relationships: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Resolve the primary source table to a DuckDB-compatible expression.

        2026-08-02 sweep: *filter_specs* flow into the iceberg file
        enumeration.  Unqualified filters are attributable to the base
        table only when the dataset reads a single table and has no
        relationships (``single_table_scope``) — otherwise only filters
        explicitly qualified via ``source_table`` are used (fail-open).
        """
        if not source_tables:
            return "DUAL"  # fallback
        first = source_tables[0]
        _single = (not relationships
                   and len({(st.get("table") or "").lower()
                            for st in source_tables if st.get("table")}) == 1)
        return self._table_to_expression(
            first.get("table", ""),
            source_tables,
            connections,
            connection_id=first.get("connection_id"),
            filter_specs=filter_specs,
            single_table_scope=_single,
        )

    # 2026-08-02 partition-predicate sweep — FilterSpec.operator → the
    # reader's adv_filters op vocabulary.  Ops absent from this map are
    # forwarded verbatim; the reader treats unknown ops as inert
    # (fail-open: file kept), so an unmapped operator can only ever
    # UNDER-prune, never wrong-prune.
    _READER_OP_MAP = {
        "eq": "equals", "neq": "ne", "in": "in", "between": "between",
        "gt": "gt", "gte": "gte", "lt": "lt", "lte": "lte",
        "is_null": "is_null", "is_not_null": "is_not_null",
    }

    def _filters_for_table_pruning(
        self,
        table_name: str,
        filter_specs: Optional[List["FilterSpec"]],
        single_table_scope: bool,
    ) -> Optional[List[Dict[str, Any]]]:
        """Convert the dataset's FilterSpecs into reader partition_filters
        for *table_name* — ATTRIBUTION-SAFE (2026-08-02 sweep).

        A filter is forwarded ONLY when it provably belongs to this table:
        its ``source_table`` matches (case-insensitive, bare last segment
        both ways), or it is unqualified AND the dataset reads exactly one
        table (``single_table_scope``).  Anything ambiguous is skipped —
        skipping only reduces pruning (over-scan); it can never prune a
        file another table's leg needs.  Fail-open on every error.
        """
        if not filter_specs:
            return None
        try:
            _bare = lambda s: (s or "").rsplit(".", 1)[-1].rsplit("/", 1)[-1].lower()
            _tgt_l = (table_name or "").lower()
            _tgt_b = _bare(table_name)
            out: List[Dict[str, Any]] = []
            for f in filter_specs:
                src = (getattr(f, "source_table", "") or "").strip()
                if src:
                    if src.lower() != _tgt_l and _bare(src) != _tgt_b:
                        continue
                elif not single_table_scope:
                    continue  # unqualified + multi-table scope → ambiguous
                op = self._READER_OP_MAP.get(
                    (f.operator or "").lower(), f.operator)
                if op == "between":
                    # Same normaliser as the WHERE clause: a shape one
                    # understands and the other does not means the query
                    # filters while the reader scans everything.  A
                    # refusal here is caught by this method's fail-open
                    # handler, which skips the predicate — under-pruning,
                    # never wrong-pruning.
                    val: Any = list(self._between_bounds(f))
                elif op in ("is_null", "is_not_null"):
                    val = None
                else:
                    val = f.value
                if op not in ("is_null", "is_not_null") and val is None:
                    continue
                out.append({"col": f.physical_name, "op": op, "val": val,
                            "table": table_name})
            return out or None
        except Exception as _pf_exc:
            logger.debug(
                "Federation: filter→pruning conversion failed for '%s' "
                "(fail-open, no pruning): %s", table_name, _pf_exc)
            return None

    # ── Plain-parquet file-list narrowing (2026-09-06) ───────────────────
    #
    # THE DEFECT.  ``_table_to_expression`` has two S3 branches and only the
    # ICEBERG one pruned.  The plain-parquet branch listed the WHOLE table
    # prefix and inlined every key into ``read_parquet([...])``; measured
    # through the product's own API against a request-counting S3 server, a
    # report over a 240-file hive tree needing 4 files and returning 20,000
    # rows cost **485 round trips and 4.27 MB** (1 LIST of 240 keys, then
    # 240 HEAD + 244 GET as DuckDB opened every file's footer).
    #
    # The two things that fix it BOTH ALREADY EXIST and were wired only into
    # ``core/duckdb_views.py`` — never onto the route every dataset and
    # business report takes:
    #
    #   1. ``island_prefix_planner`` — the partition IS the key path, so an
    #      equality/IN run on the LEADING partition columns collapses into a
    #      concrete prefix.  It walks the tree with delimiter LISTs (which
    #      enumerate DIRECTORIES, not files), takes the partition ORDER FROM
    #      THE DATA rather than from the filter, and returns ``None`` on ANY
    #      doubt.  This narrows the LIST ITSELF — 240 keys enumerated to keep
    #      4 is still 240 keys enumerated.
    #   2. ``filter_iceberg_files_by_partitions`` — the shared per-file hive
    #      chokepoint, for whatever the LIST did return (a predicate on a
    #      NON-leading partition column cannot narrow a prefix but can still
    #      drop keys).
    #
    # NO NEW PRUNING VOCABULARY IS INTRODUCED HERE.  Every file-drop decision
    # on this path is made by one of those two shared components or by DuckDB
    # itself, so the 2026-08-21 failure — a spelling one vocabulary knew and
    # its sibling did not, failing open indistinguishably from a deliberate
    # refusal — cannot be reintroduced by a third opinion living here.
    #
    # THE ASYMMETRY, which is the whole design: pruning too little is today's
    # behaviour (slow, correct); pruning too much is ROW LOSS behind a 200.
    # So every uncertain outcome here widens: the planner returning ``None``,
    # a proven-EMPTY island, an all-files-dropped verdict, any exception —
    # all fall back to the full, unpruned list.
    def _narrow_parquet_file_list(
        self,
        _s3c: Any,
        bucket: str,
        prefix: str,
        table_name: str,
        connection_id: Optional[int],
        partition_filters: Optional[List[Dict[str, Any]]],
        or_groups: Optional[List[List[Dict[str, Any]]]] = None,
    ) -> Tuple[Optional[List[str]], Dict[str, Any]]:
        """Island-targeted LIST for a hive prefix.

        Returns ``(files, diag)``.  ``files`` is ``None`` whenever the caller
        must run the full listing — including for a PROVEN-EMPTY island,
        because an empty file list is overloaded downstream ("prefix holds no
        files at all" raises on presigned connections) and turning a
        zero-row answer into an error is a regression.  Slow and correct.
        ``or_groups`` (2026-10-08) lists the union of the branch islands.
        """
        diag: Dict[str, Any] = {"island": "not_attempted"}
        if not partition_filters and not or_groups:
            diag["island"] = "no_partition_filters"
            return None, diag
        # MEASURE THE LATENCY YOU ADD.  On a FLAT prefix the walk costs one
        # delimiter LIST to learn what a recent listing already told us, and
        # the planner never caches a refusal, so that probe repeated on every
        # query (measured: flat report 485 -> 486 round trips, warm as well
        # as cold).  ``None`` from the memo means "no opinion" -> probe, so a
        # cold hive table is never denied its island.
        try:
            from core.s3_utilities import looks_hive_partitioned
            if looks_hive_partitioned(connection_id or 0, bucket,
                                      prefix) is False:
                diag["island"] = "skipped:prefix_not_hive"
                return None, diag
        except Exception as _memo_exc:                 # noqa: BLE001
            # SWALLOWED but not SILENT.  This memo is an optimisation about
            # an optimisation -- it can only suppress an island PROBE, never
            # a file -- so a failure here must not fail the query.  But
            # silence is what turns "the memo is broken and every query pays
            # a wasted LIST" into a mystery: the island still works, the
            # numbers just quietly get worse.  Debug, because on a healthy
            # system this never fires and an operator reading a slow query
            # needs it in the same breath as the [s3-prune] line.
            logger.debug("[s3-prune] hive-layout memo unavailable for "
                         "s3://%s/%s (%s); probing anyway",
                         bucket, prefix, _memo_exc)
        try:
            from core.island_prefix_planner import (
                list_island_parquet_files_cached as _island_list,
            )
            _meta: Dict[str, Any] = {}
            files = _island_list(connection_id or 0, _s3c, bucket, prefix,
                                 partition_filters, _out_meta=_meta,
                                 or_groups=or_groups)
            _reason = ((_meta.get("island_listing") or {}).get("reason")
                       or "engaged")
            if files is None:
                diag["island"] = f"declined:{_reason}"
                return None, diag
            if not files:
                # PROVEN empty — a real answer, but the empty-list branch
                # below was written for "the prefix has no files at all"
                # and RAISES on presigned connections.  Re-run the full
                # listing so a filter that matches no partition keeps
                # returning 0 rows rather than an error.
                diag["island"] = "proven_empty_fallback"
                logger.info(
                    "[island-list] Federation '%s': island proven EMPTY — "
                    "re-running the full listing to preserve the existing "
                    "empty-result handling (slow, correct).", table_name)
                return None, diag
            diag["island"] = "engaged"
            diag["island_files"] = len(files)
            return list(files), diag
        except Exception as exc:
            diag["island"] = f"error:{type(exc).__name__}"
            logger.warning(
                "[island-list] Federation '%s': island listing unavailable "
                "(%s: %s) — full enumeration follows.",
                table_name, type(exc).__name__, exc)
            return None, diag

    def _prune_parquet_by_hive_parts(
        self,
        files: List[str],
        partition_filters: Optional[List[Dict[str, Any]]],
        table_name: str,
        or_groups: Optional[List[List[Dict[str, Any]]]] = None,
    ) -> List[str]:
        """Drop keys whose hive segments cannot match — shared chokepoint.

        ``filter_iceberg_files_by_partitions`` is fail-open on every axis
        that matters here: a filter column that is not a partition column
        prunes NOTHING (it returns the input untouched), an unknown operator
        contributes no constraint, a disjunction is unioned per branch only
        under ``filter_ops.disjunction_decision`` (2026-10-08), and
        zero-padding, booleans, dates-as-strings, NULL sentinels and
        URL-encoded values each have a keep-only bridge.  An all-dropped
        verdict is widened back to the input for the same reason
        ``_narrow_parquet_file_list`` widens a proven-empty island.
        """
        if (not partition_filters and not or_groups) or not files:
            return files
        try:
            from core.s3_utilities import (
                filter_iceberg_files_by_partitions as _fibp,
            )
            kept = _fibp(list(files), partition_filters, or_groups=or_groups)
            if kept and len(kept) < len(files):
                logger.info(
                    "Federation: '%s' hive-partition pruning %d -> %d "
                    "file(s) handed to read_parquet.",
                    table_name, len(files), len(kept))
                return list(kept)
            if not kept:
                logger.info(
                    "Federation: '%s' hive-partition pruning dropped every "
                    "file — keeping the unpruned list so the existing "
                    "empty-result handling is unchanged.", table_name)
            return files
        except Exception as exc:
            logger.warning(
                "Federation: '%s' hive-partition pruning failed (%s: %s) — "
                "keeping the full file list (over-scan, never row loss).",
                table_name, type(exc).__name__, exc)
            return files

    def _prune_parquet_by_footer_stats(
        self,
        files: List[str],
        partition_filters: Optional[List[Dict[str, Any]]],
        _s3c: Any,
        bucket: str,
        connection_id: Optional[int],
        table_name: str,
        sizes: Optional[Dict[str, int]] = None,
    ) -> List[str]:
        """Min/max prune by parquet footer statistics — the ONLY lever a
        FLAT (unpartitioned) prefix has, since there is no path to narrow.

        WHY THIS IS GATED THE WAY IT IS.  DuckDB already does exactly this
        pruning, from the same footers, in parallel, and it has to open them
        anyway — so our pass is pure addition whenever the footer cache is
        cold.  Measured at the wire on a 240-file flat prefix with a filter
        selecting 4 files:

            today (no pass)          1 LIST + 240 HEAD + 244 GET = 485 RT
            cold cache, with pass    1 LIST + 240 GET + 12       = 253 RT
            warm cache, with pass    1 LIST + 12                 =  13 RT

        It therefore runs ONLY when it can plausibly win: at least one filter
        on a column that is NOT a hive partition segment (a partition-only
        filter has already been settled, for free, by the two steps above),
        and the existing ``s3.footer_stats_*`` gates the other engine honours.

        FAIL-OPEN EVERYWHERE, because a missing statistic is not "no matching
        rows".  ``prune_files_by_footer_stats`` keeps every key whose footer
        could not be read, whose column is absent from the stats, or whose
        operator it does not support; an all-dropped verdict and any
        exception are widened back to the input here.
        """
        if not files or not partition_filters or len(files) < 2:
            return files
        try:
            from core.config import s3 as _s3_cfg
            if not _s3_cfg.footer_stats_enabled:
                return files
            if len(files) < int(_s3_cfg.footer_stats_min_files_threshold):
                return files
            from core.s3_footer_stats import FooterStatsCache
            cache = FooterStatsCache.instance()
            if cache is None:
                return files
            # Does any filter address a column the HIVE PATH cannot answer?
            # If every predicate is on a partition segment, the hive prune
            # above is exact and a footer pass can only add round trips.
            from core.s3_utilities import extract_hive_parts
            part_cols: set = set()
            for f in files[:20]:
                part_cols |= {k.lower() for k in extract_hive_parts(str(f))}
            data_preds = [pf for pf in partition_filters
                          if isinstance(pf, dict) and pf.get("col")
                          and str(pf["col"]).rsplit(".", 1)[-1].lower()
                          not in part_cols]
            if not data_preds:
                return files
            # MEASURE THE LATENCY YOU ADD, part two.  The probe is a suffix
            # GET of ``footer_stats_probe_bytes`` (64 KiB by default).  On a
            # prefix of SMALL objects that fetches most of the file in order
            # to decide whether to fetch the file — measured on 84 KiB parts,
            # 240 files: round trips 485 -> 254 but bytes 4.31 MB -> 16.17 MB.
            # The S3 LIST already told us every object's size (S3FileListing
            # .sizes), so this costs nothing to check.  No sizes = no opinion
            # = proceed, exactly as before.
            _sizes = sizes or getattr(files, "sizes", None) or {}
            _known = [_sizes[str(f)] for f in files if str(f) in _sizes]
            if _known:
                _probe = int(getattr(_s3_cfg, "footer_stats_probe_bytes", 0)
                             or 65536)
                _known.sort()
                _median = _known[len(_known) // 2]
                if _median < _probe * 4:
                    logger.info(
                        "Federation: '%s' footer probe DECLINED — median "
                        "object is %d B against a %d B probe, so reading "
                        "the footer costs most of the file; DuckDB reads "
                        "the same footers itself, in parallel.",
                        table_name, _median, _probe)
                    return files
            keys, index = [], []
            for f in files:
                s = str(f)
                if s.startswith("s3://"):
                    parts = s[5:].split("/", 1)
                    keys.append(parts[1] if len(parts) > 1 else s)
                else:
                    keys.append(s)
                index.append(f)
            from core.s3_footer_stats import prune_files_by_footer_stats
            kept, pruned_n, _fs = prune_files_by_footer_stats(
                keys, data_preds, connection_id or 0, _s3c, bucket, cache)
            if pruned_n <= 0 or not kept:
                return files
            kept_set = set(kept)
            out = [f for f, k in zip(index, keys) if k in kept_set]
            if not out:
                return files
            logger.info(
                "Federation: '%s' footer min/max pruning %d -> %d file(s) "
                "on %d non-partition predicate(s).",
                table_name, len(files), len(out), len(data_preds))
            return out
        except Exception as exc:
            logger.warning(
                "Federation: '%s' footer stats pruning failed (%s: %s) — "
                "keeping the full file list (over-scan, never row loss).",
                table_name, type(exc).__name__, exc)
            return files

    def _table_to_expression(
        self,
        table_name: str,
        source_tables: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
        connection_id: Optional[int] = None,
        filter_specs: Optional[List["FilterSpec"]] = None,
        single_table_scope: bool = False,
        or_groups: Optional[List[List[Dict[str, Any]]]] = None,
    ) -> str:
        """Convert a logical table name to a DuckDB expression.

        ``or_groups`` (2026-10-08): the base query's own top-level OR of
        AND-groups for THIS table, proven by ``core.base_query_lineage``;
        the Iceberg reader, the island planner and the hive-path pruner
        union the branch islands under ``filter_ops.disjunction_decision``.

        For S3 sources: read_parquet('s3://bucket/prefix/**/*.parquet')
        For local: read_parquet('/path/to/data/*.parquet')
        For SQL: the table name directly

        2026-08-02 partition-predicate sweep: *filter_specs* (the
        dataset's WHERE filters) are forwarded to the iceberg reader as
        ``partition_filters`` — pre-fix this path enumerated EVERY data
        file of the table (partition_filters=None, table_name=None), so
        Business Reports / dataset queries full-ocean-scanned iceberg
        tables regardless of the user's filters.
        """
        # Find connection_id from source_tables if not provided
        if connection_id is None:
            for st in source_tables:
                if st.get("table") == table_name:
                    connection_id = st.get("connection_id")
                    break

        if connection_id and connection_id in connections:
            conn = connections[connection_id]
            conn_type = (conn.get("connection_type") or "").lower()
            cfg = conn.get("config", {})

            if conn_type in S3_CONNECTION_TYPES or conn_type == "s3":
                bucket = cfg.get("bucket_name", cfg.get("bucket", ""))
                prefix = table_name.strip("/")
                # BF-506 (2026-05-28) — when the registered table is
                # ICEBERG format, read its file list via
                # ``get_iceberg_data_files`` so federation_engine
                # benefits from the same fixes BQB / CQB / Feed Gen /
                # Published API get:
                #   - BF-498  date-vs-timestamp pruning compare
                #   - BF-501  source→partition-field name translation
                #   - BF-502  bucket/truncate bound decoder
                #   - BF-503  metadata-pointer verification on cache hit
                #   - BF-505  ice_cache snapshot-id verification
                # Without this, BR (which dispatches into federation_
                # engine) used a brute-force boto3 LIST under the
                # table prefix, picking up DELETE marker files and
                # orphaned data that iceberg's current snapshot has
                # marked invisible.  Now we honour the manifest.
                _registered_tables = cfg.get("registered_tables") or []
                _rt = next(
                    (t for t in _registered_tables
                     if t.get("name", "").lower() == table_name.lower()),
                    None,
                )
                _is_iceberg = (_rt is not None
                               and (_rt.get("format") or "").lower() == "iceberg")
                # Pre-list files via boto3 to avoid DuckDB glob crash on on-prem S3
                _pq_files = []
                _s3c = None
                _esc = lambda v: v.replace("'", "''")
                # 2026-10-25 -- what the merge-on-read chokepoint needs after
                # the presign below: the reader's meta (delete lists, read
                # plan, summary counters), the ORIGINAL writer URIs (position
                # deletes name them) and the table's prefix.
                _ice_meta_out: Optional[Dict[str, Any]] = None
                _ice_orig_paths: List[str] = []
                _ice_prefix = ""
                try:
                    # 2026-09-06 LATENCY.  This built a NEW
                    # ``S3StorageHandler`` -- a new boto3 Session, a new
                    # client and a new connection pool -- on EVERY report
                    # execution.  Measured: 67 ms of pure CPU per query
                    # for the client construction alone (3.5 ms when the
                    # Session is reused), plus a cold TCP/TLS pool, so the
                    # first S3 request of every query paid a fresh
                    # handshake.  With ``auth_mode='assume_role'`` it also
                    # re-ran STS AssumeRole, and with ``auth_mode='portal'``
                    # the whole three-step portal flow, once per query.
                    #
                    # ``make_s3_client_for_conn`` is the chokepoint the
                    # OTHER S3 engine (duckdb_views, nine call sites) has
                    # always used: it serves the connection manager's
                    # cached handler, injects portal credentials, and tags
                    # the client with its connection id so an ExpiredToken
                    # can invalidate it.  The report path was the one place
                    # resolving "the S3 client for this connection" a
                    # second way -- and getting a colder, less capable
                    # answer.
                    from core.s3_utilities import (
                        make_s3_client_for_conn as _mk_s3c,
                    )
                    _s3c = _mk_s3c({"id": connection_id, "config": cfg})
                    if _is_iceberg:
                        # BF-506 — iceberg manifest-driven file list.
                        # ``get_iceberg_data_files`` runs through the
                        # BF-498..505 hardening: cache-pointer verify,
                        # snapshot-id check, partial-read refusal, etc.
                        from core.iceberg_reader import get_iceberg_data_files as _gidf
                        _ice_prefix = _rt.get("s3_prefix") or prefix
                        _ice_meta_out = {}
                        # 2026-08-02 sweep: forward the dataset's WHERE
                        # filters (attribution-safe subset for THIS table)
                        # + table_name so manifest/entry pruning and the
                        # hive-island heal can engage.  Pre-fix: neither
                        # was passed → guaranteed full ocean scan.
                        _ice_pf = self._filters_for_table_pruning(
                            table_name, filter_specs, single_table_scope)
                        _ice_files = _gidf(
                            _s3c, bucket, _ice_prefix,
                            partition_filters=_ice_pf,
                            keys_only=True, _out_meta=_ice_meta_out,
                            connection_id=connection_id,
                            table_name=_rt.get("name") or table_name,
                            db_manager=self._db,
                            or_groups=or_groups,   # 2026-10-08 disjunction union
                        )
                        # Convert {"key": "<s3-key>"} → "s3://<bucket>/<key>"
                        _pq_files = [
                            f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                            for f in (_ice_files or [])
                        ]
                        _ice_orig_paths = list(_pq_files)
                        logger.info(
                            "Federation: iceberg table '%s' resolved %d "
                            "files via manifest (snapshot=%s)",
                            table_name, len(_pq_files),
                            _ice_meta_out.get("snapshot_id") or "?",
                        )
                    else:
                        from core.s3_utilities import list_s3_parquet_files_cached as _list_s3_cached
                        # 2026-11-05: a registered table's folder is its s3_prefix, as on every other
                        # road; only an unregistered name is its own folder.
                        _src_prefix = (((_rt or {}).get("s3_prefix") or prefix).strip("/")
                                       if not table_name.startswith("s3://")
                                       else table_name.replace(f"s3://{bucket}/", ""))
                        # 2026-09-06 "diving in oceans not island".  The
                        # iceberg branch above has computed and forwarded the
                        # table's partition filters since 2026-08-02; this
                        # branch threw them away and enumerated the whole
                        # prefix.  Same call, same attribution-safe subset.
                        _pq_pf = self._filters_for_table_pruning(
                            table_name, filter_specs, single_table_scope)
                        # (1) ISLAND-TARGETED LIST — narrow the PREFIX before
                        # listing, so enumeration scales with the surviving
                        # partition rather than with the table.  None means
                        # "could not decide" and the full listing runs.
                        _pq_files, _isl_diag = self._narrow_parquet_file_list(
                            _s3c, bucket, _src_prefix, table_name,
                            connection_id, _pq_pf, or_groups=or_groups)
                        if _pq_files is None:
                            _pq_files = _list_s3_cached(connection_id or 0, _s3c, bucket, _src_prefix)
                            # 2026-08-20 — the listing's truncated=True verdict
                            # (stamped since 2026-08-03) had no consumer here: a
                            # >cap federated parquet table silently queried a
                            # subset.  Surface it (diagnostic store + certificate
                            # INCOMPLETE) before the presign below drops the flag.
                            #
                            # Deliberately INSIDE the full-listing branch: the
                            # island planner refuses to return a truncated
                            # island at all (it returns None, and we are then
                            # on this line), so there is no truncation verdict
                            # to lose — and calling this on an island list
                            # would report "complete" for a listing that never
                            # enumerated the table.
                            try:
                                from core.scan_truncation import surface_truncated_listing
                                surface_truncated_listing(
                                    _pq_files, table=table_name, bucket=bucket,
                                    prefix=_src_prefix)
                            except Exception as _fed_trunc_exc:
                                logger.warning(
                                    "Federation: could not surface listing "
                                    "truncation for '%s' (%s)",
                                    table_name, _fed_trunc_exc)
                            # Teach the layout memo from the listing we just
                            # paid for, so the next query on a FLAT prefix
                            # does not spend a probe LIST rediscovering it.
                            try:
                                from core.s3_utilities import record_hive_layout
                                record_hive_layout(connection_id or 0, bucket,
                                                   _src_prefix, _pq_files)
                            except Exception as _hl_exc:
                                logger.debug(
                                    "Federation: hive-layout memo skipped "
                                    "(non-fatal): %s", _hl_exc)
                        # ── A TRUNCATED LISTING CANNOT BE PARTITION-FILTERED ──
                        # 2026-09-06.  Reachable only when an operator has set
                        # ``s3.refuse_truncated_listing=false`` (the listing
                        # itself refuses otherwise) — which is exactly when
                        # this matters, because that flag buys "partial is
                        # acceptable" and this is the case where partial is
                        # not merely small but WRONG.  S3 lists
                        # LEXICOGRAPHICALLY, so pruning a truncated ocean
                        # yields a truncated ISLAND: a partition sorting after
                        # the cut is invisible, the filter matches nothing,
                        # and the report returns ZERO rows reporting success.
                        # duckdb_views has refused this since 2026-08-21;
                        # federation — the REPORT path — never did.
                        if (_pq_pf or or_groups) and getattr(_pq_files, "truncated", False):
                            from core.scan_truncation import (
                                refuse_truncated_partition_scan as _fed_refuse,
                                TruncatedScanRefusal as _FedTSRefuse,
                            )
                            _fed_msg = _fed_refuse(
                                {"capped": True, "kind": "listing_cap",
                                 "cap": len(_pq_files),
                                 "files_registered": len(_pq_files),
                                 "files_before_cap": None, "dropped": None},
                                True, table_name)
                            if _fed_msg:
                                logger.error("Federation: %s", _fed_msg)
                                raise _FedTSRefuse(_fed_msg)
                        # Capture the LIST's size map BEFORE any pruning step
                        # copies the list and drops the attribute.
                        _pq_sizes = dict(getattr(_pq_files, "sizes", None) or {})
                        _pq_pre_prune = len(_pq_files or [])
                        # (2) POST-LIST HIVE PRUNE — the shared chokepoint,
                        # for predicates a prefix cannot express (a filter on
                        # a NON-LEADING partition column narrows nothing at
                        # the prefix level but still drops keys).
                        _pq_files = self._prune_parquet_by_hive_parts(
                            _pq_files, _pq_pf, table_name, or_groups=or_groups)
                        # (3) FOOTER MIN/MAX — the only lever a FLAT prefix
                        # has.  Self-gated: it runs only for predicates the
                        # hive path could not answer.
                        _pq_post_hive = len(_pq_files or [])
                        _pq_files = self._prune_parquet_by_footer_stats(
                            _pq_files, _pq_pf, _s3c, bucket, connection_id,
                            table_name, sizes=_pq_sizes)
                        # The system logs what it DID, never what it DECLINED
                        # to do — so this line is UNCONDITIONAL, exactly as
                        # the [island] line is.  "listed 240, kept 240" and
                        # "no filters to prune with" are different findings
                        # and an operator must be able to tell them apart.
                        logger.info(
                            "[s3-prune] Federation '%s' s3://%s/%s: "
                            "filters=%d island=%s listed=%d after_hive=%d "
                            "kept=%d",
                            table_name, bucket, _src_prefix,
                            len(_pq_pf or []), _isl_diag.get("island"),
                            _pq_pre_prune, _pq_post_hive,
                            len(_pq_files or []))
                        # ── THE HIVE/PARQUET SCAN BUDGET (2026-09-20) ────
                        # A CORRECTNESS GATE: it REFUSES, it never truncates.
                        # Placed HERE, after the island list, the hive prune
                        # AND the footer prune, because truncate-then-prune
                        # gives a WRONG island rather than a small one — the
                        # number it judges must be what the query would
                        # really read.  Default budget 0 = off; 7,300 files
                        # is not too many files (measured 5.5 s once the
                        # transport stopped opening 2 TCP connections per
                        # file), so this is for the estate where a scan
                        # genuinely cannot be served.
                        #
                        # 2026-09-21 (FB-55) — the budget is RESOLVED, not
                        # read.  It used to read ``s3.max_files_per_query``
                        # inline here while ``core/duckdb_views.py`` read a
                        # DIFFERENT key (``s3.scan_budget_hard``, shipped at
                        # 1000) for the same decision about the same table,
                        # so the same question got two answers depending on
                        # which road the user took.  One chokepoint now owns
                        # the number and the name of the knob that set it.
                        from core.scan_budget import (
                            enforce_scan_budget as _enforce_budget,
                        )
                        _enforce_budget(
                            len(_pq_files or []), table=table_name,
                            bucket=bucket, prefix=_src_prefix,
                            listed=_pq_pre_prune, filters=len(_pq_pf or []),
                            road="federation")
                except Exception as _fe:
                    # 2026-09-06 — A CORRECTNESS REFUSAL IS NOT A LISTING
                    # FAILURE, and this handler could not tell them apart.
                    #
                    # ``TruncatedScanRefusal`` says "this prefix could not be
                    # enumerated completely, so we must not answer".  On
                    # NATIVE access this handler logged a warning, left
                    # ``_pq_files`` empty and fell through to the glob branch
                    # below, which returns
                    # ``read_parquet('s3://b/p/**/*.parquet')`` — handing
                    # DuckDB the WHOLE prefix and answering HTTP 200.  That is
                    # the exact shape the refusal type was created for
                    # (2026-08-22: "retry is the bug"): the question we
                    # declined to answer gets asked again by another route,
                    # this time with the partition filters computed above
                    # thrown away entirely.  On a prefix too large to
                    # enumerate, that glob is also the read most likely to
                    # exhaust the pod.
                    #
                    # Re-raised BEFORE the generic warning so the operator
                    # reads the refusal, not "boto3 listing failed".
                    #
                    # 2026-09-20 — ``ScanBudgetRefusal`` joins it for exactly
                    # the same reason.  A budget refusal that fell through to
                    # the glob would refuse a 7,300-file scan and then serve
                    # the WHOLE PREFIX with the partition filters discarded:
                    # strictly worse than not gating at all.
                    #
                    # 2026-10-25 -- the Iceberg reader's MERGE-ON-READ refusals
                    # join them, for the same reason again: a V2 table whose
                    # delete manifests could not be read (or whose deletes
                    # MoR is configured not to apply) fell through to the glob
                    # here and served every data file ever written under the
                    # prefix -- the deleted rows AND every orphan -- as 200.
                    try:
                        from core.scan_truncation import (
                            TruncatedScanRefusal, ScanBudgetRefusal,
                        )
                        from core.iceberg_mor import (
                            MorDeleteCollectionError, MorDeletesUnresolvableError,
                            MorDisabledWithDeletesError,
                        )
                        _scan_refusals = (TruncatedScanRefusal,
                                          ScanBudgetRefusal,
                                          MorDeleteCollectionError,
                                          MorDeletesUnresolvableError,
                                          MorDisabledWithDeletesError)
                    except Exception:                    # pragma: no cover
                        _scan_refusals = ()
                    if _scan_refusals and isinstance(_fe, _scan_refusals):
                        logger.error(
                            "Federation: refusing table '%s' — %s",
                            table_name, _fe)
                        raise
                    logger.warning("Federation: %s listing failed for %s/%s: %s",
                                   "iceberg manifest" if _is_iceberg else "boto3",
                                   bucket, prefix, _fe)
                    if get_s3_access_mode(cfg) == "presigned":
                        raise RuntimeError(
                            f"Failed to list parquet files for federated table '{table_name}' on on-prem S3: {_fe}"
                        ) from _fe
                if _is_iceberg and not _pq_files:
                    # ── PRUNED TO NOTHING (2026-10-29) ──────────────────────
                    # Found on the rig: a report's SOURCE filter on a date no
                    # partition holds pruned the owner's Iceberg table to 0
                    # files, this branch fell through to the glob fallback
                    # below (``read_parquet('s3://b/p/**/*.parquet')``) and
                    # DuckDB answered "No files found that match the pattern"
                    # -- a 500 for a question whose answer is "no rows".  The
                    # SQL page has had the rule since BF-504: an emptiness the
                    # reader PROVED (``empty_island.proven``) is an EMPTY,
                    # TYPED relation from the table's schema (JOIN-safe); an
                    # emptiness it could not prove is widened to the full
                    # enumeration first (unknown is not empty), and only a
                    # full enumeration that is itself empty answers no rows.
                    from core.pruning_gate import empty_island_proven as _ei_proven
                    _pruned = bool(_ice_pf or or_groups)
                    if _pruned and not _ei_proven(_ice_meta_out):
                        logger.warning(
                            "Federation: iceberg table '%s' pruned to 0 files and the "
                            "emptiness is NOT proven (verdict=%s) -- widening to the full "
                            "enumeration (DuckDB applies the WHERE)", table_name,
                            (_ice_meta_out or {}).get("empty_island"))
                        _ice_files = _gidf(
                            _s3c, bucket, _ice_prefix, partition_filters=None,
                            keys_only=True, _out_meta={}, connection_id=connection_id,
                            table_name=_rt.get("name") or table_name, db_manager=self._db)
                        _pq_files = [f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                                     for f in (_ice_files or [])]
                        _ice_orig_paths = list(_pq_files)
                    if not _pq_files:
                        from core.duckdb_views import typed_empty_select_sql as _typed_empty
                        _empty = _typed_empty(_rt.get("name") or table_name, connection_id, self._db)
                        if not _empty:
                            raise ValueError(
                                f"Iceberg table '{table_name}' holds no data file for this "
                                f"query's filters, and its schema could not be read to answer "
                                f"an empty result. Open the table once in the catalog, then run "
                                f"again.")
                        # (the reader has already recorded this read's 0 files
                        # for the scan disclosure -- one recording point)
                        logger.info(
                            "Federation: iceberg table '%s' -- 0 data files for the filters "
                            "(%s): an empty, typed relation from its schema", table_name,
                            "proven empty island" if _pruned else "the table holds no file")
                        return f"({_empty})"
                if _pq_files:
                    # On-prem S3: pre-sign to avoid DuckDB '=' URL-encoding issue
                    try:
                        from core.s3_utilities import s3_urls_to_presigned as _s3_urls_to_presigned
                        _pq_files = _s3_urls_to_presigned(_s3c, _pq_files, cfg)
                    except Exception:
                        pass
                    if _is_iceberg and _ice_meta_out is not None:
                        # ── MERGE-ON-READ, the ONE rule (2026-10-25) ────────
                        # Found on the rig against Trino (real AWS):
                        # fact_tetb_month_end, 30 data files + 2 position-
                        # delete files (9 rows deleted).  The SQL page answered
                        # 600,056 (setup_registered_views -> _apply_mor_view);
                        # a REPORT over a custom-SQL dataset on the same
                        # table, its parameter lists and the published API
                        # over it answered 600,065 -- this branch returned
                        # read_parquet([<data files>]) and the delete files
                        # the reader had collected into _ice_meta_out were
                        # never applied.  Every federation S3 read inherited
                        # it: _build_query, _build_from_base_query (through
                        # _registered_table_views_for_sql), dataset preview,
                        # LOVs, value lists, column ranges, report-backed
                        # published views.
                        #
                        # The SAME chokepoint the view routes use builds the
                        # delete-aware read (core.duckdb_views._apply_mor_view
                        # -> core.iceberg_mor.build_mor_select_sql): position
                        # deletes anti-joined on (original writer URI, physical
                        # row) through the read-path -> original map (the
                        # presigned / on-prem road rewrites the read paths;
                        # the delete files name the s3:// URIs), equality
                        # deletes by NOT EXISTS with Iceberg's NULL = NULL,
                        # partition- and sequence-scoped; delete files
                        # presigned / pre-downloaded exactly as data files;
                        # the read plan decides projection.  The data-file
                        # PRUNING above never drops a delete file: the reader
                        # collects EVERY delete file of the snapshot (Step
                        # 4a), whatever island the data files were pruned to.
                        # fail_loud: deletes that exist but cannot be applied
                        # on this road REFUSE (MorDeletesUnresolvableError,
                        # a 422 with the sentence) -- never the deleted rows.
                        # An append-only snapshot returns None here at no
                        # cost (no delete manifest = no collection, no extra
                        # S3 request) and keeps the expression below
                        # byte-identical.
                        from core.duckdb_views import _apply_mor_view as _mor_chokepoint
                        _mor_body = _mor_chokepoint(
                            None, table_name, table_name, list(_pq_files),
                            orig_s3_paths=_ice_orig_paths,
                            ice_meta_out=_ice_meta_out, bucket=bucket,
                            conn_config=cfg, s3_client=_s3c, s3_prefix=_ice_prefix,
                            log_prefix="FEDERATION", fail_loud=True,
                            select_only=True,
                        )
                        if _mor_body:
                            logger.info(
                                "Federation: iceberg table '%s' read MERGE-ON-READ "
                                "(%d data files, %d position + %d equality delete "
                                "files applied)", table_name, len(_pq_files),
                                len(_ice_meta_out.get("pos_delete_files") or []),
                                len(_ice_meta_out.get("eq_delete_files") or []))
                            return f"({_mor_body})"
                        # ── APPEND-ONLY: THE SAME DECISION AS EVERY OTHER
                        #    ICEBERG ROUTE (2026-10-26, the owner's P0) ──────
                        # Found on the rig against real AWS: the owner's JOIN
                        # query (``UPPER(DATE_FORMAT(FACT_TETB.BUSINESS_CLOSE_
                        # DATE, '%d-%b-%y'))``) as a custom-SQL dataset on the
                        # direct-S3 connection failed every run with DuckDB's
                        # ``strftime(VARCHAR, STRING_LITERAL)`` binder error.
                        # ``fact_tetb`` is partitioned IDENTITY on
                        # ``business_close_date`` (Iceberg type ``date``, and
                        # stored in every data file as DATE); its directory key
                        # ``business_close_date=2025-09-30`` overrides the file
                        # column under ``hive_partitioning=true``, and this
                        # branch typed that key through
                        # ``hive_partition_types.declared_partition_types`` --
                        # the PLAIN-PARQUET rule (the ``schema_cache`` row, or
                        # a LIST-based decision that refuses a non-parquet
                        # registered table).  An Iceberg table has no such row,
                        # so the clause was a bare ``hive_types_autocast=false``
                        # and EVERY identity partition key read as VARCHAR: a
                        # DATE key mis-binds, a numeric key compares as text.
                        # Before 2026-10-06 DuckDB's autocast happened to guess
                        # DATE here; since then the read was deterministically
                        # wrong on this road and right on the SQL page.
                        #
                        # The Iceberg rule already exists -- ``core.iceberg_
                        # read_plan.plan_iceberg_read`` types an identity key
                        # from its source column in the CURRENT schema
                        # (``iceberg_identity_partition_types``), reads the
                        # values from the FILES when the manifest proves they
                        # are stored there, and projects the current schema --
                        # and the MoR body above already uses it on this road.
                        # An append-only table was the ONE Iceberg read in the
                        # product still spelling its own ``read_parquet``.  A
                        # decision made twice is a bug: it is made once now.
                        from core.iceberg_read_plan import (
                            plan_iceberg_read as _plan_ice_read,
                            iceberg_view_select_sql as _ice_select_sql,
                        )
                        _ice_plan = _plan_ice_read(
                            list(_pq_files), meta=_ice_meta_out,
                            union_by_name=True, table_name=table_name,
                            log_prefix="FEDERATION")
                        logger.info(
                            "Federation: iceberg table '%s' read through the ONE "
                            "read plan (fidelity=%s, projection=%s, %d data "
                            "file(s), no delete files)", table_name,
                            _ice_plan.fidelity, _ice_plan.projection,
                            len(_pq_files))
                        return f"({_ice_select_sql(_ice_plan)})"
                    _paths = ", ".join(f"'{self._esc(f)}'" for f in _pq_files)
                    # ── union_by_name=true STAYS.  The call, and why. ─────
                    #
                    # The 2026-09-06 latency audit charged this flag with the
                    # whole 484-round-trip bill: it makes DuckDB open every
                    # file's footer to build a union schema BEFORE it can
                    # plan, so hive-path pruning never gets a chance.  That
                    # is true, and it is not the flag's fault — it is what
                    # happens when a 240-file list reaches DuckDB in the
                    # first place.  Measured at the wire, same query, same
                    # answer (20,000 rows), 10 ms simulated RTT:
                    #
                    #   240 files + union_by_name   484 RT  4.03 MB  1.77 s
                    #   240 files, flag removed      14 RT  0.36 MB  0.23 s
                    #     4 files (island) + flag    12 RT  0.35 MB  0.09 s
                    #     4 files, flag removed      12 RT  0.35 MB  0.12 s
                    #
                    # Once the file list is the ISLAND the flag costs NOTHING
                    # — the fix is the list, not the flag.  And on a FLAT
                    # prefix, where there is no path to prune on and DuckDB
                    # must open every footer anyway, removing it costs zero
                    # round trips and is 6.4x SLOWER in wall clock (0.71 s ->
                    # 4.54 s over 240 files; COUNT(*) 0.85 s -> 4.52 s),
                    # because union_by_name is also what makes DuckDB read
                    # that metadata in PARALLEL rather than file by file.
                    #
                    # THE FAILURE MODE OF KEEPING IT: a prefix whose files
                    # have genuinely different schemas is silently unioned —
                    # a file missing a selected column contributes NULLs
                    # instead of failing.  Removing it makes that case a hard
                    # ``InvalidInputException: schema mismatch in glob:
                    # column "amount" was read from the original file ... but
                    # could not be found`` (verified; an EXTRA column is
                    # tolerated either way).  A loud 500 is usually better
                    # than quiet NULLs — but it is a behaviour change for
                    # schema-evolved prefixes that buys ZERO round trips once
                    # the list is pruned, so it is not this change's to make.
                    # ``s3.duckdb_union_by_name_parquet`` and
                    # ``s3.union_by_name_max_files`` remain the operator's
                    # levers on the duckdb_views engine.
                    # 2026-10-06 -- partition keys typed as DECLARED (the
                    # table's recorded schema), never DuckDB's per-read guess.
                    # PLAIN PARQUET ONLY from here (2026-10-26): an Iceberg
                    # table returned above through the read plan, whose
                    # identity keys are typed from the Iceberg schema --
                    # ``declared_partition_types`` cannot answer for one.
                    from core.hive_partition_types import (
                        declared_partition_types as _decl_pt,
                        hive_types_clause_for_paths as _ht_paths,
                    )
                    _ht = _ht_paths(_pq_files, _decl_pt(
                        connection_id, table_name.split(":", 1)[-1], paths=_pq_files))
                    return f"read_parquet([{_paths}], hive_partitioning=true, union_by_name=true{_ht})"
                # Fallback to glob — only safe when DuckDB has native S3 access
                if get_s3_access_mode(cfg) == "presigned":
                    raise RuntimeError(
                        f"No parquet files found for federated table '{table_name}' on on-prem S3 under s3://{bucket}/{prefix}/"
                    )
                if table_name.startswith("s3://"):
                    return f"read_parquet('{table_name}/**/*.parquet', hive_partitioning=true, hive_types_autocast=false)"
                elif bucket:
                    return f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true, hive_types_autocast=false)"

            # ── SQL connectors (Trino/Starburst/Snowflake/Databricks/…) ──
            #
            # 2026-08-10.  This branch did not exist: a SQL connection fell
            # through to ``_quote_ident(table_name)`` at the bottom, which
            # wraps the WHOLE string in ONE pair of quotes.  Both spellings
            # the UI can produce were therefore wrong at the source:
            #
            #   ``orders``            -> "orders"
            #        Trino: "Schema must be specified when session schema
            #        is not set" — the query never names a schema.
            #   ``hive.sales.orders`` -> "hive.sales.orders"
            #        ONE identifier that happens to contain dots, so Trino
            #        looks for a table literally named ``hive.sales.orders``
            #        and answers "Table does not exist".
            #
            # A qualified reference must quote each PART separately.  Parts
            # the caller omitted are filled from the connection's configured
            # catalog/schema — the same defaulting rule
            # ``GET /api/connections/{id}/tables`` already applies, so a
            # dataset built from either spelling resolves identically.
            # Imported here rather than at module scope: federation_engine is
            # imported during app boot and core.connection_manager pulls in
            # duckdb/pyarrow/boto3 — a lazy import keeps that cost (and any
            # future import cycle) out of the boot path.  Python caches the
            # module, so this is a dict lookup after the first call.
            from core.connection_manager import (
                _is_sql_connector_type, resolve_table_address,
            )
            if _is_sql_connector_type(conn_type):
                # THE resolver -- the same call the schema read makes, so
                # the address whose columns auto-detect stored is the
                # address rendered here.  On Oracle it drops the browse
                # route's pseudo-catalog (``"OTG"."OTG"."T"`` was
                # ORA-03048, 2026-09-15) and REFUSES a name it cannot
                # render, which the routes report as a 422 with the reason.
                catalog, schema, table = resolve_table_address(
                    table_name, conn_type,
                    default_catalog=cfg.get("catalog", "") or "",
                    default_schema=cfg.get("schema", "") or "",
                )
                if table:
                    return ".".join(
                        self._quote_ident(p) for p in (catalog, schema, table) if p
                    )

        # Local path or plain table name
        if "/" in table_name or "\\" in table_name:
            return f"read_parquet('{table_name}/*.parquet', hive_partitioning=true)"

        return self._quote_ident(table_name)

    # ── Internal: base_query-aware helpers (2026-08-22) ──────────────────────

    def _base_query_as_engine_runs(self, base_query: str,
                                   connections: Dict[int, Dict[str, Any]]) -> str:
        """A dataset's custom SQL as it is EXECUTED -- ONE answer for the run,
        the preview, a parameter's list and a value range (2026-10-24).

        Custom SQL is written in the WAREHOUSE's dialect (Trino / Starburst /
        Snowflake ...).  On a connection QueryStudio's own engine runs (S3 /
        local: DuckDB) it is translated exactly as the raw-SQL path translates
        it (translate_to_duckdb_with_fixes, api/execute_api.py) -- found live:
        the owner's JOIN query ran as a FEED on S3 and failed as a REPORT on
        the same S3 dataset ("date_format does not exist"), and later its
        parameter list failed the same way.  A SQL connector keeps the text:
        _transpile_for_connector handles that side."""
        if connections and all(self._get_connection_type(c) == "s3"
                               for c in connections.values()):
            _decl = {str(((c.get("config") or {}) if isinstance(c, dict) else {})
                         .get("sql_dialect") or "").strip().lower()
                     for c in connections.values()} - {""}
            return _base_query_for_duckdb(
                base_query, next(iter(_decl)) if len(_decl) == 1 else None)
        return base_query

    def _source_filter_dialect(self, base_query: str,
                               connections: Dict[int, Dict[str, Any]]) -> Optional[str]:
        """The sqlglot dialect a dataset's custom SQL is WRITTEN in -- what
        ``core.source_filters`` parses and renders with (2026-10-29).  On
        QueryStudio's own engine (every connection S3) it is the connection's
        declared ``sql_dialect``, else the translator's own answer
        (``source_dialect_for``: configured, else a recorded guess); on a SQL
        connector it is that connector's dialect.  ``None`` = sqlglot's
        generic grammar."""
        if connections and all(self._get_connection_type(c) == "s3" for c in connections.values()):
            _decl = {str(((c.get("config") or {}) if isinstance(c, dict) else {})
                         .get("sql_dialect") or "").strip().lower()
                     for c in connections.values()} - {""}
            try:
                from core.sql_dialect_translator import source_dialect_for
                d, _how = source_dialect_for(base_query, next(iter(_decl)) if len(_decl) == 1 else None)
                return d or None
            except Exception as exc:                            # noqa: BLE001
                logger.info("[source-filters] dialect not resolved (%s); generic grammar", exc)
                return None
        for c in (connections or {}).values():
            if self._get_connection_type(c) == "sql":
                from core.sql_filter_wrapper import dialect_for_connection_type
                return dialect_for_connection_type(c.get("connection_type")) or None
        return None

    def dataset_sql_dialect(self, ds: Dict[str, Any]) -> Optional[str]:
        """:meth:`_source_filter_dialect` for a dataset dict -- the ONE answer the
        routes use to list a dataset's source filters and to check a parameter's
        binding against them."""
        return self._source_filter_dialect(ds.get("base_query") or "", self._resolve_connections(ds))

    def _base_from_expression(
        self,
        ds: Dict[str, Any],
        connections: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        filter_specs: Optional[List["FilterSpec"]] = None,
        relationships: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """The FROM expression for a dataset — custom SQL wrapped as
        ``(sql) AS _base`` when ``base_query`` is set, otherwise the resolved
        source-table expression.

        2026-08-22 — ``preview_dataset`` and ``get_column_distinct_values``
        used to call ``_resolve_base_table`` UNCONDITIONALLY, and a custom-SQL
        dataset has no source_tables, so that returned the "DUAL" fallback:
        EVERY preview and EVERY filter LOV on a SQL-defined dataset failed
        with "Table with name DUAL does not exist" while execute worked.  One
        definition of "where does this dataset's data come from", shared by
        all three, so they cannot disagree again.
        """
        base_query = (ds.get("base_query") or "").strip()
        if base_query:
            from core.sql_connector_dialect import BASE_QUERY_ALIAS
            # the SAME text the report run executes (rig 2026-10-24: the
            # owner's Trino JOIN ran as a report on S3 and its parameter list
            # failed with "date_format does not exist")
            base_query = self._base_query_as_engine_runs(base_query, connections)
            return f"({base_query.rstrip().rstrip(';')}) AS {BASE_QUERY_ALIAS}"
        return self._resolve_base_table(
            source_tables, connections,
            filter_specs=filter_specs, relationships=relationships)

    def _apply_rls_all_connections(
        self,
        sql: str,
        connections: Dict[int, Dict[str, Any]],
        user_ctx: Dict[str, Any],
        *,
        label: str,
        request_id: Optional[str] = None,
        dialect: str = "duckdb",
    ) -> str:
        """Row-security rewrite once per DISTINCT connection id.

        ``dialect`` (2026-10-24): the dialect ``sql`` is WRITTEN in -- a
        statement built for a source connector is rewritten in that source's
        dialect (a value list read straight off the source table).

        The 2026-08-05 BR cross-source audit established this rule for
        ``execute_dataset_query``: policies are scoped per connection
        (``find_applicable_policies`` matches connection_id OR NULL), so
        passing only the FIRST connection silently skipped a policy scoped to
        the second — the cross-tenant leak shape.  ``preview_dataset`` and
        ``get_column_distinct_values`` kept the single-connection call; this
        helper is that fix stated ONCE so the three paths cannot drift.
        NULL-scoped (global) policies match on every pass; re-applying them
        is a redundant AND of the same predicate — restrictive-safe.

        Hard-fails on enforcement errors (ValueError) — an RLS rewrite that
        cannot complete must never degrade to the unfiltered query.
        """
        _conn_ids: List[Any] = []
        for _c in (connections or {}).values():
            try:
                _cid = _c.get("id")
            except Exception:
                _cid = None
            if _cid is not None and _cid not in _conn_ids:
                _conn_ids.append(_cid)
        if not _conn_ids:
            _conn_ids = [None]
        try:
            from core.row_security import secure_sql as _rs_secure
            for _rls_cid in _conn_ids:
                sql = _rs_secure(
                    sql, dialect=dialect,
                    user_ctx=user_ctx, connection_id=_rls_cid,
                    request_id=request_id,
                )
        except Exception as _rs_exc:
            # 2026-09-24: TYPED, so a caller can answer 403 with the reason
            # instead of a generic 500 (still a ValueError for old handlers).
            from core.row_security.api import RowSecurityRefused
            raise RowSecurityRefused(
                f"Row-security enforcement failed for {label}: {_rs_exc}") from _rs_exc
        return sql

    #: Pruning-format op (what ``core.sql_partition_extractor`` emits) -> the
    #: FilterSpec operator ``_filters_for_table_pruning`` maps straight back
    #: through ``_READER_OP_MAP``.  An op absent here is declined, logged.
    _PRUNING_OP_TO_SPEC = {
        "equals": "eq", "not_equals": "neq", "in": "in", "not_in": "not_in",
        "greater_than": "gt", "greater_equals": "gte",
        "less_than": "lt", "less_equals": "lte",
        "is_null": "is_null", "is_not_null": "is_not_null",
        "not_between": "not_between",
    }

    def _filters_to_forward_into_view(
        self,
        table_name: str,
        base_query: Optional[str],
        filter_specs: Optional[List["FilterSpec"]],
        partition_columns: Optional[List[str]] = None,
        or_groups_out: Optional[List[List[Dict[str, Any]]]] = None,
    ) -> List["FilterSpec"]:
        """The predicates that may narrow the FILE LIST of the view bound
        for ``table_name`` -- two sources, both decided by
        ``core.base_query_lineage`` (the rules are spelled out there) and
        LOGGED, forwarded and declined alike, once per table.
        ``or_groups_out`` (2026-10-08), when given, receives the base
        WHERE's proven OR branches (``WhereVerdict.or_groups``) for
        ``_table_to_expression(or_groups=...)``:

          * the dataset's own filters (``filter_specs``), when the base
            query provably passes that column through unchanged;
          * the base query's OWN top-level WHERE conjuncts (2026-10-02,
            second half -- the wizard's Preview / Columns steps carry no
            dataset filter at all), when the statement reads the table
            once, bare, and the conjunct is ``bare column <op> literal``.

        An empty answer means today's behaviour: the view reads every file
        and the outer WHERE does all the work.
        """
        if not (base_query or "").strip():
            return []
        from core.base_query_lineage import base_where_filters, forwardable_filters
        out: List["FilterSpec"] = []
        ds_summary = "none"
        if filter_specs:
            verdict = forwardable_filters(base_query or "", table_name, filter_specs)
            out.extend(verdict.forwarded)
            ds_summary = verdict.summary
        wv = base_where_filters(base_query or "", table_name, partition_columns)
        if or_groups_out is not None and wv.or_groups:
            or_groups_out.extend([dict(d, table=table_name) for d in b]
                                 for b in wv.or_groups)
        unmapped: List[str] = []
        for d in wv.forwarded:
            op = self._PRUNING_OP_TO_SPEC.get(str(d.get("op") or ""))
            if op is None:
                unmapped.append(f"{d.get('col')} {d.get('op')}")
                continue
            out.append(FilterSpec(column_id=0, physical_name=str(d.get("col")),
                                  operator=op, value=d.get("val"),
                                  source_table=table_name))
        # The system logs what it DECLINED, not only what it did -- one
        # unconditional line per decision, so "slow because nothing could
        # be forwarded" is readable next to the [s3-prune] line.
        logger.info(
            "[lineage] custom-SQL dataset: registered table '%s' -- dataset "
            "filters: %s; base WHERE: %s%s (a predicate is pushed into the "
            "view's file pruning ONLY when the base query provably reads this "
            "table once, bare, and the column unchanged; the statement's own "
            "WHERE and the outer WHERE are applied regardless)",
            table_name, ds_summary, wv.summary,
            f"; op not mappable {unmapped}" if unmapped else "")
        return out

    def _registered_table_views_for_sql(
        self,
        sql: str,
        connections: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        base_query: Optional[str] = None,
        filter_specs: Optional[List["FilterSpec"]] = None,
    ) -> List[Tuple[str, str]]:
        """``[(table_name, table_expression)]`` for REGISTERED S3 tables the
        custom SQL references by bare name.

        A saved query / base_query written in the SQL editor references
        registered tables by NAME (``SELECT * FROM sales``) because the query
        pipeline registers DuckDB views for them (``setup_registered_views``).
        The federation engine never did, so a custom-SQL dataset over an S3
        connection failed with "Table with name sales does not exist" — the
        semantic layer could not run the very SQL its own wizard accepts.

        REGISTERING views rather than rewriting the SQL is deliberate (same
        doctrine as ``_register_parquet_as_tables``: string surgery on a
        compiled query is how a WHERE clause goes missing).  Each view body
        comes from ``_table_to_expression`` — the SAME chokepoint the
        table-mode path uses, so iceberg manifest resolution (BF-506) and
        presigned-URL handling apply identically.  Enumeration errors
        PROPAGATE: a table that cannot be resolved would fail inside DuckDB
        anyway, and the chokepoint's error names the table and the reason.

        ``base_query`` + ``filter_specs`` (2026-10-02): the dataset's own
        filters sit OUTSIDE the base query (``WITH qs_base AS (...) SELECT
        ... WHERE "dt" = ...``), so this call used to hand the chokepoint NO
        filters and the view listed, presigned and opened EVERY file of the
        table -- 11-18 s and the connection-exhaustion 500 on a 365-day tree,
        where the TABLE-mode dataset with the same filter read one partition.
        A filter now reaches ``_table_to_expression(filter_specs=...)`` only
        when ``core.base_query_lineage`` proves the dataset column IS the
        table's column unchanged (``_filters_to_forward_into_view``); the
        chokepoint prunes with the same code table mode uses, and the outer
        WHERE is still applied unchanged.
        """
        s3_conns = {cid: c for cid, c in (connections or {}).items()
                    if self._get_connection_type(c) == "s3"}
        if not s3_conns or not sql:
            return []
        referenced: set = set()
        try:
            import sqlglot
            from sqlglot import exp
            tree = sqlglot.parse_one(sql, dialect="duckdb")
            for tbl in tree.find_all(exp.Table):
                # Bare, unqualified names only — qualified names belong to
                # connector catalogs, and CTE names shadow views anyway.
                if tbl.this is not None and not tbl.db and not tbl.catalog:
                    referenced.add(tbl.name.lower())
        except Exception as exc:
            # Parse failure = no views; the query then fails LOUDLY in DuckDB
            # with the unresolved name — never a silent behaviour change.
            logger.warning(
                "[federation] base_query table scan failed (%s) — no "
                "registered-table views registered; unresolved names will "
                "fail loudly in DuckDB", exc)
            return []
        if not referenced:
            return []
        # 2026-11-01 -- a statement that reached this road with a version
        # marker (the SECOND side of a cross-source run, a published view's
        # federation side) and no run map yet: resolve ITS tables ONCE here,
        # against THIS connection's metadata (an id belongs to one table on
        # one side), and bind a "t@v<id>" view beside the registered ones.
        # A run that already resolved (the dataset road above) keeps its map.
        from core import iceberg_versions as _iv
        _extra_by_conn: Dict[int, List[Dict[str, Any]]] = {}
        _iv_pins = _iv.pins_in_sql(sql)
        _merged: Dict[str, Any] = {}
        _recs: List[Dict[str, Any]] = []
        if _iv_pins and not any(v in _iv.run_versions() for v in _iv_pins):
            from core.s3_utilities import make_s3_client_for_conn
            from core.iceberg_freshness_bound import newest_snapshot_is_required
            for cid, conn in s3_conns.items():
                cfg = conn.get("config") or {}
                regs = cfg.get("registered_tables") or []
                _ice_names = {str(r.get("name")).lower() for r in regs if isinstance(r, dict)
                              and str(r.get("format") or "").lower() == "iceberg"}
                if not any(p.table in _ice_names for p in _iv_pins.values()):
                    continue
                res = _iv.resolve_for_connection(
                    s3_client=make_s3_client_for_conn({"id": cid, "config": cfg}),
                    bucket=cfg.get("bucket_name") or cfg.get("bucket") or "",
                    registered_tables=regs, sql=sql,
                    referenced_names=[n for n in referenced if n in _ice_names or "@" in n],
                    force_fresh=newest_snapshot_is_required())
                if res is None:
                    continue
                _merged.update(res.versions)
                _recs.extend(res.record())
                _extra_by_conn[cid] = list(res.extra_tables)
        _side_token = None
        try:
            if _iv_pins and _merged:
                # scoped to THIS binding: the file lists are baked into the
                # view SQL below, and a map left active would serve the NEXT
                # statement on this thread (a stale map is the mix this
                # feature exists to prevent)
                _side_token = _iv.activate({**_iv.run_versions(), **_merged})
                self._iv_record = (list(self._iv_record or []) + _recs)
                for rec in _recs:
                    logger.info("[iceberg-versions] side reads %s (%s)",
                                rec.get("words"), rec.get("decided_by"))
            return self._bind_registered_views(sql, connections, s3_conns, source_tables, base_query,
                                               filter_specs, referenced, _extra_by_conn)
        finally:
            if _side_token is not None:
                _iv.deactivate(_side_token)

    def _bind_registered_views(self, sql, connections, s3_conns, source_tables, base_query,
                               filter_specs, referenced, _extra_by_conn) -> List[Tuple[str, str]]:
        views: List[Tuple[str, str]] = []
        seen: set = set()
        for cid, conn in s3_conns.items():
            _regs_here = list(conn.get("config", {}).get("registered_tables") or [])
            if _extra_by_conn.get(cid):
                conn = dict(conn)
                conn["config"] = dict(conn.get("config") or {})
                conn["config"]["registered_tables"] = _regs_here + _extra_by_conn[cid]
                connections = dict(connections)
                connections[cid] = conn
                _regs_here = conn["config"]["registered_tables"]
            for rt in _regs_here:
                name = rt.get("name") or ""
                if name.lower() in referenced and name.lower() not in seen:
                    _og: List[List[Dict[str, Any]]] = []
                    _fwd = self._filters_to_forward_into_view(
                        name, base_query, filter_specs,
                        partition_columns=list(rt.get("partition_columns") or []),
                        or_groups_out=_og)
                    if _fwd or _og:
                        # ``source_table`` is stamped on every forwarded
                        # copy, so the chokepoint's attribution rule
                        # (``_filters_for_table_pruning``) matches it to
                        # THIS table and no other.  ``_og`` (2026-10-08) is
                        # the base WHERE's proven OR of AND-groups.
                        expr = self._table_to_expression(
                            name, source_tables, connections, connection_id=cid,
                            filter_specs=_fwd or None, single_table_scope=True,
                            or_groups=_og or None)
                    else:
                        expr = self._table_to_expression(
                            name, source_tables, connections, connection_id=cid)
                    if expr and expr != self._quote_ident(name):
                        views.append((name, expr))
                        seen.add(name.lower())
        if views:
            logger.info(
                "[federation] custom-SQL dataset: registered %d S3 table "
                "view(s): %s", len(views), [v[0] for v in views])
        return views

    def preview_storage_sql(self, sql: str, connection_id: int, limit: int = 10) -> Dict[str, Any]:
        """Run an author's SELECT against an S3 (storage) connection, capped,
        through the SAME road a custom-SQL dataset over that connection runs
        (2026-10-02).

        A storage connection has no SQL engine of its own, but QueryStudio
        does: tables registered on the connection are bound as DuckDB views
        by ``_registered_table_views_for_sql`` (the chokepoint every
        custom-SQL dataset uses, so manifest resolution and presigned-URL
        handling are identical) and the statement runs on the DuckDB/S3
        route.  The dataset wizard used to answer an S3 preview from the
        SQL's text alone, so ``SELECT * FROM t`` -- the commonest first
        query -- had no columns to show and was refused, although the very
        same statement ran in the query builder and would run in every
        report built on the dataset.  Preview and execution now cannot
        disagree.

        Returns the connector preview shape: ``{"columns": [{"name",
        "type"}], "rows": [dict], "total_rows": n}``.
        """
        connections = self._resolve_connections({"connection_ids": [int(connection_id)],
                                                 "name": "dataset preview"})
        if not connections:
            raise ValueError(f"Connection {connection_id} not found")
        body = str(sql).strip().rstrip(";")
        # 2026-10-02: the author's own WHERE prunes the view's files -- the
        # wizard wraps it as ``SELECT * FROM (<sql>) __preview__ LIMIT n`` and
        # the lineage rule sees through output-consuming wrappers.
        views = self._registered_table_views_for_sql(
            body, connections, [], base_query=body) or None
        capped = f"SELECT * FROM ({body}) AS qs_preview LIMIT {max(1, int(limit))}"
        df = self._execute_query(sql=capped, connections=connections, source_tables=[],
                                 execution_id="dataset-preview", table_views=views)
        columns = [{"name": str(c), "type": str(t)} for c, t in zip(df.columns, df.dtypes)]
        rows = df.astype(object).where(df.notna(), None).to_dict(orient="records")
        return {"columns": columns, "rows": rows, "total_rows": len(rows)}

    # ── Internal: SQL execution ──────────────────────────────────────────────

    def _classify_connections(
        self, connections: Dict[int, Dict[str, Any]],
    ) -> Tuple[Dict[int, Dict[str, Any]], Dict[int, Dict[str, Any]]]:
        """Split connections into (s3, non-s3).  ONE definition, shared by the
        streaming router and the row-bound decision so they cannot disagree
        about which route a query takes."""
        s3_conns, sql_conns = {}, {}
        for cid, conn in connections.items():
            if self._get_connection_type(conn) == "s3":
                s3_conns[cid] = conn
            else:
                sql_conns[cid] = conn
        return s3_conns, sql_conns

    def _engine_cannot_spill(self, connections: Dict[int, Dict[str, Any]]) -> bool:
        """Always False.  No federation route is bounded by a row cap.

        KEPT AS A NAMED PREDICATE ON PURPOSE.  It used to return True for the
        hybrid S3+connector query, which merged its two sides in pandas and so
        genuinely could not spill — that one route was the reason
        ``federation.max_result_rows`` behaved as a memory ceiling and the last
        place in the product where a query could come back with silently fewer
        rows than it asked for.

        2026-08-11 removed the pandas merge: the connector side is streamed to
        parquet through the Phase 154 chokepoint and the join runs in DuckDB,
        which spills to ``temp_directory`` (``core/duckdb_factory.py``) exactly
        like every other route.  See ``_execute_hybrid_to_parquet``.

        This stays as a function rather than being deleted so that a future
        route which genuinely cannot spill has an obvious, single place to
        declare itself — and so the invariant is assertable
        (``tests/test_federation_merge_duckdb_2026_08_11.py``).  Anything that
        makes this return True again must arrive WITH a measurement.
        """
        return False

    def _try_execute_to_parquet(
        self,
        *,
        sql: str,
        connections: Dict[int, Dict[str, Any]],
        execution_id: str,
        output_path: str,
        row_limit: Optional[int] = None,
        source_tables: Optional[List[Dict[str, Any]]] = None,
        filter_specs: Optional[List["FilterSpec"]] = None,
        table_views: Optional[List[Tuple[str, str]]] = None,
        partition_config: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Execute straight into the parquet artifact with bounded memory.

        2026-08-11.  ``execute_dataset_query`` used to materialise the FULL
        result as one pandas DataFrame in this pod and stream only the WRITE,
        so peak memory was O(total_rows x row_width) and
        ``federation.max_result_rows`` was the only thing preventing an OOM.
        Every route below now pulls the result in batches instead:

          * pure DuckDB (S3 or plain) — ``to_arrow_reader`` -> one
            ``ParquetWriter`` (``core.federation_stream``), O(one batch);
          * pure SQL connector — ``connector_to_parquet.execute_sql_to_parquet``,
            the Phase 154 chokepoint that has always streamed
            ``execute_query_streaming`` -> ``ParquetStreamWriter``.  The engine
            simply never called it, going through ``execute_sql_to_dataframe``
            instead.  ``execute_sql_to_dataframe`` keeps its semantics for its
            other callers; this is a sibling, not a change to it.

          * HYBRID S3+connector (2026-08-11) — the connector side is streamed
            to parquet and published into the DuckDB catalog, then the whole
            SQL runs in DuckDB and spills.  This was the last route that
            materialised in the pod, and therefore the last one bounded by
            ``federation.max_result_rows``.  See ``_execute_hybrid_to_parquet``.

        ``partition_config`` (2026-09-05) — the dataset's DECLARED
        progressive-scan knob (``dataset_partition_config``).  Only the
        pure-SQL-connector route reads it, and only to try
        ``_execute_sql_connector_partitioned`` before the whole-query
        call; absent or undeclared, every route below is exactly what it
        was.  The HYBRID route above deliberately ignores it: its
        connector side is one input to a DuckDB join, not the answer.

        Returns ``{"total_rows", "columns", ...}`` on success, or **None** when
        the caller must fall back to the DataFrame path.

        Any failure returns None (logged) rather than propagating: a streaming
        optimisation must never be the reason a report stops working.
        The one exception (2026-10-30): a failure while the run's cancel event
        is set IS the cancellation and propagates -- the fallback would send
        the cancelled statement to the source again.
        """
        s3_conns, sql_conns = self._classify_connections(connections)

        if s3_conns and sql_conns:
            try:
                return self._execute_hybrid_to_parquet(
                    sql=sql, s3_conns=s3_conns, sql_conns=sql_conns,
                    source_tables=source_tables or [],
                    filter_specs=filter_specs,
                    execution_id=execution_id, output_path=output_path)
            except Exception as exc:
                try:
                    Path(output_path).unlink(missing_ok=True)
                except OSError:
                    pass
                # Do NOT fall through to the legacy DataFrame route here.  Its
                # hybrid branch answers from ONE side when DuckDB can't take
                # the query, which is a wrong result dressed as a right one.
                # An error is the honest outcome.
                logger.error(
                    "[%s] hybrid S3+connector execution failed: %s",
                    execution_id, exc, exc_info=True)
                raise

        # Capability pre-check.  ``sql_conns`` is "everything that is not s3",
        # so it can hold a local/file connection that no SQL connector can
        # serve.  Deciding that BEFORE executing matters: the fallback below
        # re-runs the query, and discovering the incapability by exception
        # would pay for the whole query twice.
        if sql_conns:
            from core.connection_manager import _is_sql_connector_type
            if not all(_is_sql_connector_type(c.get("connection_type", ""))
                       for c in sql_conns.values()):
                logger.debug("[%s] non-SQL-connector connection in the query — "
                             "leaving it on the existing route", execution_id)
                return None

        try:
            if s3_conns:
                return self._execute_duckdb_s3(
                    sql, s3_conns, execution_id, sink_path=output_path,
                    table_views=table_views)
            if sql_conns:
                # 2026-09-05 progressive partition loading.  Tried FIRST
                # and returning None means "not partitionable", so the
                # whole-query call below is reached BYTE-IDENTICALLY for
                # every dataset that declares no partition column -- an
                # opt-in feature that changed the default path would not
                # be opt-in.  ``row_limit`` is forwarded because the
                # planner refuses to split under a cap; dropping it here
                # would silently re-enable splitting and spend the cap
                # once PER BUCKET.
                partitioned = self._execute_sql_connector_partitioned(
                    sql, sql_conns, execution_id, output_path,
                    partition_config=partition_config,
                    row_limit=row_limit)
                if partitioned is not None:
                    return partitioned
                return self._execute_sql_connector_to_parquet(
                    sql, sql_conns, execution_id, output_path,
                    row_limit=row_limit)
            return self._execute_duckdb_plain(
                sql, execution_id, sink_path=output_path)
        except Exception as exc:
            # 2026-10-30: a run the USER CANCELLED is not a streaming failure.
            # The cancel stopped the statement at the source; falling back
            # re-sent the same statement, so a cancelled report restarted
            # itself and kept its slot (found by capacity_wait_proof).
            from core.duckdb_cancel import lookup_cancel_event
            _ev = lookup_cancel_event(execution_id)
            if _ev is not None and _ev.is_set():
                Path(output_path).unlink(missing_ok=True)
                raise
            # Remove any partial artifact so the fallback writes a clean file.
            try:
                Path(output_path).unlink(missing_ok=True)
            except OSError:
                pass
            logger.warning(
                "[%s] streaming execution failed (%s) — falling back to the "
                "materialising route; the result is unaffected, only its peak "
                "memory is", execution_id, exc, exc_info=True)
            return None

    # ── Hybrid S3 + SQL-connector: the last route that could not spill ──────

    def _register_parquet_as_tables(
        self,
        con,
        views: List[Tuple[str, str, str, str]],
        execution_id: str = "",
    ) -> None:
        """Publish ``(catalog, schema, table, parquet)`` into a DuckDB catalog.

        The generated SQL refers to a connector table by its FULLY QUALIFIED
        name (``"hive"."sales"."orders"`` — see ``_table_to_expression``).
        DuckDB can host that shape natively: ``ATTACH ':memory:' AS hive``
        creates the catalog, ``CREATE SCHEMA`` the middle part.  Building the
        catalog to match the SQL means the SQL never has to be rewritten.
        """
        attached: set = set()
        for catalog, schema, table, parquet_path in views:
            q = self._quote_ident
            path_lit = self._esc(parquet_path)
            target = ".".join(q(p) for p in (catalog, schema, table) if p)
            if catalog and catalog not in attached:
                # ``memory`` is DuckDB's own default catalog — never re-attach
                # it, and never fail the query because it already exists.
                if catalog.lower() != "memory":
                    try:
                        con.execute(f"ATTACH ':memory:' AS {q(catalog)}")
                    except Exception as exc:  # noqa: BLE001
                        logger.debug("[%s] ATTACH %s skipped (%s)",
                                     execution_id, catalog, exc)
                attached.add(catalog)
            if schema:
                schema_path = ".".join(q(p) for p in (catalog, schema) if p)
                con.execute(f"CREATE SCHEMA IF NOT EXISTS {schema_path}")
            con.execute(
                f"CREATE OR REPLACE VIEW {target} AS "
                f"SELECT * FROM read_parquet('{path_lit}')")
            logger.info("[%s] hybrid: %s -> %s", execution_id, target,
                        parquet_path)

    def _where_sql_for_table(
        self,
        table_name: str,
        filter_specs: Optional[List["FilterSpec"]],
        single_table_scope: bool,
    ) -> str:
        """WHERE fragment carrying only the filters that PROVABLY belong to
        *table_name* — same attribution rule as
        ``_filters_for_table_pruning``.

        This is a pushdown, so being wrong in either direction matters.
        Forwarding another table's predicate would DELETE rows; forwarding
        nothing only over-fetches.  Anything ambiguous is therefore skipped,
        and every failure is fail-open (empty string = pull the whole table).
        """
        if not filter_specs:
            return ""
        try:
            def _bare(s: str) -> str:
                return (s or "").rsplit(".", 1)[-1].rsplit("/", 1)[-1].lower()

            tgt_l, tgt_b = (table_name or "").lower(), _bare(table_name)
            parts: List[str] = []
            for f in filter_specs:
                src = (getattr(f, "source_table", "") or "").strip()
                if src:
                    if src.lower() != tgt_l and _bare(src) != tgt_b:
                        continue
                elif not single_table_scope:
                    continue        # unqualified + multi-table → ambiguous
                clause = self._filter_to_sql(f)
                if clause:
                    parts.append(clause)
            return f" WHERE {' AND '.join(parts)}" if parts else ""
        except Exception:  # noqa: BLE001 - pushdown is never a correctness gate
            logger.debug("hybrid WHERE pushdown skipped", exc_info=True)
            return ""

    def _execute_hybrid_to_parquet(
        self,
        *,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
        sql_conns: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        filter_specs: Optional[List["FilterSpec"]],
        execution_id: str,
        output_path: str,
    ) -> Dict[str, Any]:
        """Hybrid S3 + SQL-connector query, in DuckDB, with bounded memory.

        THIS ROUTE WAS BOTH CAPPED AND BROKEN.  ``_execute_hybrid`` handed the
        whole generated SQL to DuckDB, which cannot resolve a connector table
        (it appears as ``"hive"."sales"."orders"``), then fell back to handing
        the same SQL to the connector, which cannot resolve
        ``read_parquet('s3://…')``.  In practice the query errored; when it
        did not, the fallback answered from the connector side ALONE.
        Meanwhile ``federation.max_result_rows`` clamped the route "because
        pandas cannot spill".

        What happens now:

          1. every connector-side table is streamed to a local parquet through
             ``connector_to_parquet.execute_sql_to_parquet`` (the Phase 154
             chokepoint — cursor -> ParquetStreamWriter, O(one chunk)), with
             the dataset's attributable WHERE predicates pushed down so the
             pull is as small as the filters allow;
          2. each parquet is published into the DuckDB catalog under the exact
             ``catalog.schema.table`` path the SQL names;
          3. the generated SQL runs UNCHANGED in DuckDB alongside the S3
             tables, and DuckDB spills the join to ``temp_directory``;
          4. the result streams into the artifact one RecordBatch at a time.

        Peak memory is O(one chunk + DuckDB's memory_limit) at every step, so
        nothing here needs a row cap.  Raises on failure — there is no
        single-side fallback, because a half-sided answer that looks like a
        successful one is the defect this replaces.
        """
        from core.connection_manager import (
            _is_sql_connector_type, resolve_table_address,
        )
        from core.connector_to_parquet import execute_sql_to_parquet
        from core.connectors import get_connector
        from core.connection_pool import get_pooled_connector
        from core.duckdb_cancel import lookup_cancel_event

        single_table_scope = len(source_tables or []) == 1
        tmp_dir = Path(self._output_dir) / "hybrid_tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)

        views: List[Tuple[str, str, str, str]] = []
        temp_files: List[str] = []
        try:
            for st in (source_tables or []):
                cid = st.get("connection_id")
                if cid not in sql_conns:
                    continue
                conn = sql_conns[cid]
                conn_type = (conn.get("connection_type") or "").lower()
                if not _is_sql_connector_type(conn_type):
                    raise RuntimeError(
                        f"hybrid query includes table '{st.get('table')}' on a "
                        f"'{conn_type}' connection, which is neither S3 nor a "
                        f"SQL connector — refusing rather than answering from "
                        f"the other side alone")
                cfg = conn.get("config", {}) or {}
                table_name = st.get("table") or ""
                catalog, schema, table = resolve_table_address(
                    table_name, conn_type,
                    default_catalog=cfg.get("catalog", "") or "",
                    default_schema=cfg.get("schema", "") or "",
                )
                if not table:
                    raise RuntimeError(
                        f"hybrid query: cannot resolve connector table "
                        f"'{table_name}'")

                qualified = ".".join(
                    self._quote_ident(p) for p in (catalog, schema, table) if p)
                side_sql = (f"SELECT * FROM {qualified}"
                            + self._where_sql_for_table(
                                table_name, filter_specs, single_table_scope))
                side_sql = self._transpile_for_connector(
                    side_sql, conn_type, execution_id)

                side_path = str(
                    tmp_dir / f"{execution_id}_{uuid.uuid4().hex[:8]}.parquet")
                connector = None
                try:
                    connector = get_connector(conn_type, cfg)
                    try:
                        stats = execute_sql_to_parquet(
                            connector, side_sql, side_path,
                            # NO row_limit: this side feeds a join, and silently
                            # truncating an input is how a join loses rows without
                            # anyone being told.  Memory is bounded by the
                            # streaming writer, not by a cap.
                            cancel_event=lookup_cancel_event(execution_id),
                        )
                    except (InterruptedError, ValueError):
                        raise
                    except Exception as exc:
                        raise wrap_source_failure(exc, conn_type) from exc
                finally:
                    if connector is not None:
                        try:
                            connector.close()
                        except Exception:  # noqa: BLE001
                            logger.debug("connector close failed", exc_info=True)
                temp_files.append(side_path)
                views.append((catalog, schema, table, side_path))
                logger.info(
                    "[%s] hybrid: streamed %s rows from %s (%s) to %s",
                    execution_id, stats.get("total_rows", 0), qualified,
                    conn_type, side_path)

            if not views:
                raise RuntimeError(
                    "hybrid route selected but no connector-side source table "
                    "was found — refusing to run the S3 side alone")

            return self._execute_duckdb_s3(
                sql, s3_conns, execution_id,
                sink_path=output_path, register_views=views)
        finally:
            for f in temp_files:
                try:
                    Path(f).unlink(missing_ok=True)
                except OSError:
                    logger.debug("could not remove hybrid side-file %s", f)

    def _note_scan_diagnostic(self, execution_id: str,
                              payload: Dict[str, Any]) -> None:
        """Stamp a progressive-scan decision on THIS execution's record.

        ``core.query_diagnostic_store.record_pruning`` is what "the
        execution's diagnostics" means in this engine: ``scan_truncation``
        writes the completeness certificate there, ``iceberg_reader`` writes
        pruning there, and ``execute_dataset_query`` publishes the execution
        id through a ContextVar precisely so deep modules can reach it.  The
        entry MERGES, so several stamps during one execution accumulate.

        Best-effort by construction -- a diagnostic must never be the reason
        a report fails -- but never SILENT: a failure to stamp is logged,
        because "we ran it whole, and here is why" is the whole point.
        """
        try:
            from core.query_diagnostic_store import record_pruning
            record_pruning(str(execution_id or ""), payload)
        except Exception:                                    # noqa: BLE001
            logger.debug("[%s] could not stamp scan diagnostics",
                         execution_id, exc_info=True)

    def _execute_sql_connector_partitioned(
        self,
        sql: str,
        sql_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
        output_path: str,
        *,
        partition_config: Optional[Dict[str, Any]] = None,
        row_limit: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Progressive sibling of ``_execute_sql_connector_to_parquet``.

        One small ``WHERE col IN (...)`` query per bucket, a few running at
        a time through the SAME chokepoint the whole-query route uses, each
        part adopted into one growing parts dataset -- then merged into the
        single parquet FILE this route's readers open.

        Returns **None** when the query cannot (or should not) be
        partitioned, so the caller falls through to the whole-query route
        UNCHANGED.  Every None carries a REASON onto the execution's
        diagnostics, never only into a log line: an unrecognised spelling
        and a deliberate refusal are otherwise indistinguishable, and both
        fail open.

        ``partition_config`` is the dataset's declared knob, in the
        published view's exact shape (see :func:`dataset_partition_config`).
        The sketch in ``docs/PROGRESSIVE_PARTITION_LOADING_2026_09_05.html``
        took a separate ``partition_column=`` argument BESIDE the config; it
        is ONE parameter here because the column already lives in the config
        under ``column``, and two ways to say the same thing is how the two
        come to disagree.

        ``row_limit`` IS FORWARDED, and that is load-bearing.  A cap is
        defined over the WHOLE result; split across N concurrent buckets
        there is no correct way to spend it, so ``plan_partitioned_scan``
        REFUSES (``row_limit_in_force``) and returns a SINGLE plan.  Drop
        the argument and splitting silently re-enables under a cap, each
        bucket honouring it separately -- up to N times too many rows, and
        WHICH rows survive would depend on which bucket finished first.
        Forwarding it preserves today's cap semantics exactly: the
        fall-through route applies the cap once, as it always has.

        NO PROGRESSIVE SERVING HERE, DELIBERATELY.  The parts land one by
        one, but this route's contract is ``output_path`` -- a single
        parquet file that the paged report reader, the microcube, the
        agg-cache write-through and retention all open as a FILE.  So the
        parts are consolidated and removed, gated on the merged file's own
        FOOTER (``core/scan_partitions/consolidate.py``), and the report
        gets exactly the artifact it gets today, extracted in parallel.  The
        snapshot rule a paging reader needs -- page N and page N+1 over the
        same rows -- holds the way it already does: one immutable file,
        written tmp-then-``os.replace``, so a reader opens the old artifact
        or the new one and never a splice.  Serving the parts dir directly
        (``open_dataset(..., allow_partial=True)``, which pins the manifest
        at open time and reports ``total_mode="at_least"``) is where "start
        showing results right away" lands for reports, and it needs a
        parts-aware reader in ``api/business_reports_api.py`` -- a separate
        change, in a module this one does not own.
        """
        cfg = dict(partition_config or {})
        if not cfg:
            return None                       # not declared: nothing to say
        column = str(cfg.get("column") or "").strip()
        if cfg.get("conflict"):
            # 2026-09-05 round 2 -- a conflict is now one of TWO kinds, and
            # this message named only the first.  Telling an operator their
            # source tables "declare different partition columns" when they
            # actually disagree on ``max_buckets`` sends them to look at the
            # one field that agrees.  A diagnostic that misnames the cause
            # costs an investigation, which is the whole reason this line
            # carries a detail at all.
            _kind = cfg.get("conflict_kind") or "column"
            _is_col = _kind == "column"
            self._note_scan_diagnostic(execution_id, {"scan_plan": {
                "mode": "single",
                "declined": ("conflicting_partition_columns" if _is_col
                             else "conflicting_partition_settings"),
                "detail": ("the dataset's source tables disagree on "
                           + ("the partition column" if _is_col
                              else "partition setting(s)")
                           + " (" + ", ".join(cfg.get("conflict") or [])
                           + "); one dataset has one partition plan")}})
            return None
        if not column or cfg.get("enabled") is False:
            return None

        from core.connectors import get_connector
        from core.connection_pool import get_pooled_connector
        from core.duckdb_cancel import lookup_cancel_event
        from core.scan_partitions import (
            consolidate_parts_to_file, execute_plan_to_parts,
            plan_partitioned_scan,
        )
        from core.sql_filter_wrapper import dialect_for_connection_type

        conn_id, conn = next(iter(sql_conns.items()))
        conn_type = conn.get("connection_type", "")
        conn_config = conn.get("config", {})
        # The planner PARSES this statement and rewrites it, so it has to see
        # the SQL the connector will actually run -- the same transpile the
        # whole-query route applies.  Kept under its own name so the
        # fall-through hands the caller's original string over untouched.
        target_sql = self._transpile_for_connector(sql, conn_type,
                                                   execution_id)
        dialect = dialect_for_connection_type(conn_type)
        # 2026-09-05 -- ONE spelling, shared with the reader.  This was
        # ``f"{output_path}.parts"`` here and the identical expression in
        # core/reports/pagination.py, held together by a guard test.  If the
        # two ever drift, progressive serving goes SILENTLY DARK: the reader
        # looks in a directory nothing writes, finds nothing, and reports
        # every report as non-partitioned behind a 200.  A convention two
        # modules each spell for themselves is a decision made twice.
        from core.reports.pagination import parts_dir_for
        parts_dir = str(parts_dir_for(output_path))

        # -- plan ---------------------------------------------------------
        # Planning is an OPTIMISATION: if it breaks, the whole-query build
        # must still run.  The reason is stamped, not absorbed.
        # 2026-09-16 -- the PLANNING probe is pooled too.  It is a short,
        # metadata-only connection opened once per partitioned execution and
        # thrown away; reusing it is the clearest win in this file.
        probe = None
        try:
            probe_cm = get_pooled_connector(conn_id, conn_type, conn_config,
                                            conn.get("name", ""))
            probe = probe_cm.__enter__()
            plan = plan_partitioned_scan(
                probe, target_sql, partition_column=column, dialect=dialect,
                max_buckets=int(cfg.get("max_buckets") or 64),
                max_concurrent=int(cfg.get("max_concurrent") or 2),
                target_rows_per_bucket=cfg.get("target_rows_per_bucket"),
                bucket_size=cfg.get("bucket_size"),
                bucket_strategy=str(cfg.get("bucket_strategy") or "auto"),
                discovery_sql=(str(cfg.get("discovery_sql") or "").strip()
                               or None),
                discovery_with_counts=bool(
                    cfg.get("discovery_with_counts", True)),
                discovery_wrap=bool(cfg.get("discovery_wrap", False)),
                max_discovery_values=int(cfg.get("max_discovery_values")
                                         or 200_000),
                preflight_count=cfg.get("preflight_count"),
                row_limit=row_limit,
                on_refusal="declare")
        except Exception as exc:                             # noqa: BLE001
            logger.warning(
                "[%s] partition planning failed (%s: %s) -- running the "
                "query whole", execution_id, type(exc).__name__, exc)
            self._note_scan_diagnostic(execution_id, {"scan_plan": {
                "mode": "single",
                "planner_error": f"{type(exc).__name__}: {exc}"}})
            return None
        finally:
            if probe is not None:
                try:
                    # __exit__ RELEASES to the pool (or closes when pooling
                    # is off).  Passing no exc_info is correct here: any
                    # planner exception was already caught and turned into a
                    # "run it whole" fallback above, so the connector is
                    # healthy and belongs back in the pool.
                    probe_cm.__exit__(None, None, None)
                except Exception:                            # noqa: BLE001
                    logger.debug("probe connector release failed",
                                 exc_info=True)

        # Stamped BEFORE we act on it, so "why did this run whole" is
        # answerable from the execution record either way.  The per-bucket
        # SQL is deliberately NOT stamped: 64 rewritten statements per
        # execution x 500 retained executions is a memory store, not a
        # diagnostic.  ``bucket_count`` and the refusal are what a reader
        # needs, and they are both kept.
        _stamp = {k: v for k, v in plan.to_dict().items() if k != "buckets"}
        self._note_scan_diagnostic(execution_id, {"scan_plan": _stamp})
        if plan.mode.value != "partition_values":
            if plan.refusal is not None:
                logger.info("[%s] dataset query runs WHOLE: %s",
                            execution_id, plan.refusal.message())
            return None                       # caller runs it whole

        # -- execute ------------------------------------------------------
        # A failure here PROPAGATES: ``_try_execute_to_parquet``'s handler
        # falls back to the materialising route, which re-runs the whole
        # query and produces the same answer.  The half-built parts are
        # removed first -- a partial manifest left beside the artifact is
        # what the next build's reuse check would find.
        try:
            # 2026-09-16 -- the per-worker-thread connectors are BORROWED
            # now.  This is the biggest connection saving in the engine: a
            # partitioned execution opened one connector per worker thread
            # and threw it away, every time.  The factory acquires and
            # ``connector_release`` gives back -- CLOSING a pooled connector
            # here would shut the session while the pool still counts it
            # active, leaking the slot until the pool wedged.
            from core.connection_pool import (
                acquire_pooled, discard_pooled, release_pooled,
            )
            _pool_args = (conn_id, conn_type, conn_config, conn.get("name", ""))
            res = execute_plan_to_parts(
                lambda: acquire_pooled(*_pool_args), plan,
                parts_dir,
                connector_release=lambda c: release_pooled(*_pool_args, c),
                # A connector that failed mid-query is thrown away, never
                # pooled -- the next caller must not inherit it.
                connector_discard=lambda c: discard_pooled(*_pool_args, c),
                rows_per_part=int(cfg.get("rows_per_part")
                                  or _parts_rows_per_part()),
                cancel_event=lookup_cancel_event(execution_id),
                source_meta={"execution_id": execution_id,
                             "connection_type": conn_type})
            merged = consolidate_parts_to_file(parts_dir, output_path,
                                               delete_parts=True)
        except BaseException:
            self._note_scan_diagnostic(execution_id, {"scan_plan": dict(
                _stamp, build_failed=True)})
            shutil.rmtree(parts_dir, ignore_errors=True)
            raise

        # The verdict outlives the parts it was computed over: consolidation
        # deletes the manifest that carried it, so it goes on the execution.
        self._note_scan_diagnostic(
            execution_id, {"scan_completeness": res["ledger"]})
        logger.info(
            "[%s] partitioned scan (%s): %d bucket(s) -> %d rows -> %s (%s)",
            execution_id, conn_type, len(plan.buckets),
            merged["total_rows"], output_path, res["ledger"]["verdict"])
        return {"total_rows": merged["total_rows"],
                "file_size_bytes": merged["file_size_bytes"],
                "columns": res.get("columns") or [],
                "scan_plan": _stamp,
                "completeness": res["ledger"]}

    def _execute_sql_connector_to_parquet(
        self,
        sql: str,
        sql_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
        output_path: str,
        *,
        row_limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Streaming sibling of ``_execute_sql_connector`` — cursor straight to
        parquet via the Phase 154 chokepoint, never one big DataFrame."""
        from core.connectors import get_connector
        from core.connection_pool import get_pooled_connector
        from core.connector_to_parquet import execute_sql_to_parquet
        from core.duckdb_cancel import lookup_cancel_event

        conn_id, conn = next(iter(sql_conns.items()))
        conn_type = conn.get("connection_type", "")
        conn_config = conn.get("config", {})
        sql = self._transpile_for_connector(sql, conn_type, execution_id)

        # 2026-09-16 -- POOLED.  Same lifetime as the hand-rolled
        # try/finally this replaces: the context manager RELEASES on success
        # and DISCARDS (closes) on any exception, so a connector that raised
        # never goes back into the pool.  Inert when
        # connection_pool.enabled=false -- that branch creates a fresh
        # connector and closes it, which is exactly the old behaviour.
        with get_pooled_connector(conn_id, conn_type, conn_config,
                                  conn.get("name", "")) as connector:
            try:
                if self._progressive_stream_parts_enabled():
                    stats = self._stream_connector_to_parts(
                        connector, sql, execution_id, output_path,
                        conn_type=conn_type, row_limit=row_limit,
                        cancel_event=lookup_cancel_event(execution_id))
                else:
                    stats = execute_sql_to_parquet(
                        connector, sql, output_path,
                        row_limit=row_limit,
                        # Same cancel contract as the DataFrame route: the connector
                        # spawns a watchdog that calls cursor.cancel() at the SOURCE.
                        cancel_event=lookup_cancel_event(execution_id),
                    )
            except (InterruptedError, ValueError):
                # A cancel and the engine's own refusals keep their type.
                raise
            except Exception as exc:
                # The source's verdict, not an internal error: a ValueError
                # whose text is the engine's (sanitised), so the route
                # answers 422 with the ORA/Trino line the author must act
                # on instead of a generic 500 (SourceStatementError) -- or,
                # FB-39, a SourceUnavailableError when the source could not
                # be REACHED (503 + Retry-After).  Classified once, in
                # wrap_source_failure.
                raise wrap_source_failure(exc, conn_type) from exc
            logger.info("[%s] SQL connector (%s) streamed %d rows to parquet",
                        execution_id, conn_type, stats.get("total_rows", 0))
            return stats

    @staticmethod
    def _progressive_stream_parts_enabled() -> bool:
        """The DECLARED flag ``business_reports.progressive_stream_parts``
        (ships OFF).  Read at call time, never captured at import."""
        try:
            from core import config as _cfg
            return bool(_cfg.business_reports.progressive_stream_parts)
        except Exception:                                    # noqa: BLE001
            return False

    def _stream_connector_to_parts(
        self,
        connector,
        sql: str,
        execution_id: str,
        output_path: str,
        *,
        conn_type: str,
        row_limit: Optional[int] = None,
        cancel_event=None,
    ) -> Dict[str, Any]:
        """PROGRESSIVE SERVING FOR A REPORT WITH NO PARTITION PLAN (2026-09-27).

        The whole-query route above writes ONE parquet, whose footer lands
        at close -- so the first row was servable only when the last row
        had been drained.  This sibling drains the same cursor through
        ``core.connector_to_parquet.execute_sql_to_parts`` (the same
        bounded-memory contract, rotated into durable parts beside the
        artifact, the partial manifest rewritten after each one) and THEN
        consolidates the parts into the single file every other reader
        opens.  While the parts exist and the file does not, the paged
        reader (``core/reports/pagination.py::paginate_result`` ->
        ``read_parts_page``) serves page 1 from them, and the async status
        poll discloses ``partial_results_available`` -- the same reader the
        partitioned build already uses, so the 2026-09-25 invariants hold
        by construction rather than by a second implementation:

        * page N and page N+1 come from ONE snapshot -- the reader pins
          ``dataset_version`` at the part count it first saw and serves
          every later page from that prefix; a pin the parts no longer
          answer is a 409, never a splice;
        * the consolidated file replaces the parts under a pin that names
          the PARTS build, so a paging session that started on the parts
          is told ``consolidated`` and restarts, never served file rows
          under a parts pin.

        The final multiset is the canonical run's: one cursor, one
        ORDER-preserving drain, every row written exactly once (proven by
        value in ``tests/test_report_progressive_stream_parts_2026_09_27.py``).
        The part size is ``feed_generation.parts_rows_per_part`` -- the ONE
        knob the published-view lane and the partitioned build read, so the
        same query makes the same-shaped parts on every surface.

        A failure PROPAGATES (the caller's handler wraps it as the source's
        verdict) after the parts directory is removed: a partial manifest
        left beside the artifact is what a later reader would find and
        serve as "still building".  ``resume=False`` on purpose -- a report
        execution id is minted per run, so there is never a build to
        resume, and a stale directory under this id is wiped by the writer.
        """
        from core.connector_to_parquet import execute_sql_to_parts
        from core.reports.pagination import parts_dir_for
        from core.scan_partitions import consolidate_parts_to_file
        from core.sql_filter_wrapper import dialect_for_connection_type

        parts_dir = str(parts_dir_for(output_path))
        rows_per_part = _parts_rows_per_part()

        _rows_so_far = [0]

        def _on_part(info) -> None:
            # A durable part is a fact worth recording where the status poll
            # cannot see it (the manifest is what it reads); the diagnostic
            # store is where "what did this execution do" already lives.
            try:
                _rows_so_far[0] += int(getattr(info, "rows", 0) or 0)
                self._note_scan_diagnostic(execution_id, {
                    "progressive_parts": {
                        "parts_ready": int(getattr(info, "index", -1)) + 1,
                        "rows_so_far": _rows_so_far[0],
                    }})
            except Exception:                                # noqa: BLE001
                logger.debug("[%s] progressive part note skipped",
                             execution_id, exc_info=True)

        try:
            res = execute_sql_to_parts(
                connector, sql, parts_dir,
                rows_per_part=rows_per_part,
                row_limit=row_limit,
                cancel_event=cancel_event,
                resume=False,
                dialect=dialect_for_connection_type(conn_type),
                source_meta={"execution_id": execution_id,
                             "connection_type": conn_type,
                             "progressive": "stream_parts"},
                on_part_complete=_on_part,
            )
            merged = consolidate_parts_to_file(parts_dir, output_path,
                                               delete_parts=True)
        except BaseException:
            shutil.rmtree(parts_dir, ignore_errors=True)
            raise
        self._note_scan_diagnostic(execution_id, {
            "progressive_parts": {"parts_ready": int(res.get("parts", 0) or 0),
                                  "rows_so_far": int(merged["total_rows"]),
                                  "consolidated": True}})
        logger.info("[%s] SQL connector (%s) streamed %d rows through %d "
                    "progressive part(s) -> %s", execution_id, conn_type,
                    merged["total_rows"], int(res.get("parts", 0) or 0),
                    output_path)
        return {"total_rows": int(merged["total_rows"]),
                "file_size_bytes": int(merged.get("file_size_bytes", 0) or 0),
                "columns": list(res.get("columns") or []),
                "progressive_parts": int(res.get("parts", 0) or 0)}

    def _execute_query(
        self,
        *,
        sql: str,
        connections: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        execution_id: str,
        progress_callback=None,
        table_views: Optional[List[Tuple[str, str]]] = None,
    ) -> pd.DataFrame:
        """Execute the generated SQL against the appropriate engine.

        For S3 sources: Creates a DuckDB connection with named secrets for
        all involved S3 endpoints, then executes the SQL directly.

        For SQL sources: Uses the existing connector SDK.
        """
        # Classify connections
        s3_conns = {}
        sql_conns = {}
        for cid, conn in connections.items():
            if self._get_connection_type(conn) == "s3":
                s3_conns[cid] = conn
            else:
                sql_conns[cid] = conn

        # Route based on connection types
        if s3_conns and not sql_conns:
            # Pure S3 — use DuckDB with named secrets
            return self._execute_duckdb_s3(sql, s3_conns, execution_id,
                                           table_views=table_views)
        elif sql_conns and not s3_conns:
            # Pure SQL — use first SQL connector
            return self._execute_sql_connector(sql, sql_conns, execution_id)
        elif s3_conns and sql_conns:
            # Hybrid — use DuckDB for S3 part, connector for SQL, merge in-memory
            return self._execute_hybrid(sql, s3_conns, sql_conns, source_tables, execution_id)
        else:
            # No connections — try DuckDB in-memory (dataset might use base_query with CTEs)
            return self._execute_duckdb_plain(sql, execution_id)

    def _execute_duckdb_s3(
        self,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
        sink_path: Optional[str] = None,
        register_views: Optional[List[Tuple[str, str, str, str]]] = None,
        table_views: Optional[List[Tuple[str, str]]] = None,
    ) -> Any:
        """Execute SQL in DuckDB with named secrets for each S3 connection.

        ``table_views`` (2026-08-22) — ``[(name, table_expression)]`` for
        registered S3 tables a custom-SQL dataset references by bare name;
        each becomes ``CREATE OR REPLACE VIEW name AS SELECT * FROM expr``
        before the SQL runs.  See ``_registered_table_views_for_sql``.

        ``register_views`` (2026-08-11) — ``[(catalog, schema, table, parquet)]``
        published into the DuckDB catalog before the SQL runs.  Used by the
        HYBRID S3+connector route to make the already-materialised connector
        side resolvable under the exact name the generated SQL uses.

        ``sink_path`` (2026-08-11): when given, the result is STREAMED into
        that parquet path in RecordBatches and a
        ``{"total_rows", "columns", "file_size_bytes"}`` dict is returned —
        peak memory O(one batch).  When omitted the behaviour is exactly as
        before: the full result is materialised as one DataFrame and returned.
        The DataFrame route is still used by callers that genuinely need a
        frame in hand (the hybrid merge), so it is kept rather than removed.

        Round 10 (2026-06-02) — JoinPruner pre-execution hook: when the
        compiled SQL has JOINs and one side carries a WHERE filter, plan
        a semi-join probe via ``core.join_pruner.JoinPruner``, fetch the
        filtered side's bounds via ``iceberg_reader``, and AND-append a
        BETWEEN/IN clause to the SQL so the JOIN partner gets pruned
        too.  Mirrors the wiring ``setup_registered_views`` does for the
        non-federation path.  Fail-open at every step — pruning never
        blocks query execution.
        """
        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB not installed — required for S3 federation")

        # Round 10 — best-effort SQL augmentation with synth JOIN filters.
        try:
            sql = self._augment_sql_with_join_pruner_filters(sql, s3_conns)
        except Exception as _jp_aug_exc:
            logger.debug("[%s] JoinPruner SQL augmentation failed (fail-open): %s",
                         execution_id, _jp_aug_exc)

        # ── ONE ATTEMPT OF THE SCAN ────────────────────────
        # 2026-09-21 — factored into a nested function so a DECLARED
        # transient failure can be retried on a FRESH connection.  Everything
        # from ``duckdb_connection()`` down sits inside it deliberately: an
        # ``InternalException`` is DuckDB's "this should not have happened"
        # channel, so the handle that raised one is not trustworthy and the
        # retry RE-OPENS rather than re-executes.  Redoing the secrets /
        # views / pragma setup costs milliseconds against a 9-second scan.
        def _run_scan_once():
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                # Factory already calls ensure_extension_directory

                # Load httpfs extension — LOAD first (works with pre-downloaded
                # extensions in air-gapped environments), INSTALL as fallback.
                with _ext_lock:
                    try:
                        con.execute("LOAD 'httpfs';")
                    except Exception:
                        con.execute("INSTALL 'httpfs';")
                        con.execute("LOAD 'httpfs';")

                from core.proxy_utils import apply_duckdb_proxy
                # Federation may join multiple S3 connections (mixed AWS + on-prem).
                # We apply proxy globally; libcurl NO_PROXY env var (set by
                # setup_proxy_env() at startup) handles on-prem bypass.
                apply_duckdb_proxy(con)

                # Create named secrets for each S3 connection
                self._setup_duckdb_secrets(con, s3_conns)

                # Configure DuckDB performance + SSL (uses first s3_conn's
                # ssl_verify -- mixed configs across federated sources
                # must standardise; DuckDB SSL pragmas are global per
                # connection).
                #
                # 2026-10-25 -- BEFORE the views are created, not after.
                # ``CREATE VIEW ... AS SELECT * FROM read_parquet([...],
                # union_by_name=true)`` BINDS at creation: DuckDB opens every
                # file's footer (a HEAD + a ranged GET each) right there.
                # This call -- the S3 transport (connection caching, the retry
                # floor), the HTTP metadata cache -- and the remote-I/O
                # decision below used to run AFTER the ``table_views`` loop,
                # so that whole bind pass ran at the CPU thread count over a
                # NEW TCP connection per file, and the query then re-opened
                # every footer a second time.  Measured at the wire
                # (tests/test_federation_views_bound_after_transport_2026_10_25.py,
                # 24 files, threads 2): 48 HEAD + 24 GET over 27-40
                # connections -> 24 HEAD + 24 GET over 3-4 connections.  On a
                # real region a connection is 2-3 round trips, so a 2,688-file
                # island paid ~2,700 extra TLS handshakes two at a time before
                # the statement ran.  Every road through here -- a custom-SQL
                # dataset / report, the wizard preview, a value-list sync, the
                # cross-source storage side -- binds its views this way.
                self._configure_duckdb_performance(con, s3_conns=s3_conns)

                # 2026-10-06 -- remote-I/O concurrency for THIS query's
                # files (the same decision the multi-worker workers and the
                # subprocess child make; core/s3_http_transport): threads
                # sized for the cores read a remote file list a couple of
                # files at a time.  Fail-open.  Decided from the view
                # EXPRESSIONS, which are known before the views exist, so the
                # bind pass runs at the query's I/O width too.
                try:
                    from core.s3_http_transport import (
                        apply_remote_io_concurrency, remote_file_uris,
                    )
                    from core.measured_file_bytes import bytes_for_uris
                    _fed_uris = remote_file_uris(
                        sql if isinstance(sql, str) else "",
                        *[str(_e) for _n, _e in (table_views or [])])
                    if _fed_uris:
                        apply_remote_io_concurrency(
                            con, remote_files=len(_fed_uris), share=1,
                            label="federation",
                            measured=bytes_for_uris(_fed_uris))
                except Exception as _rio_exc:
                    logger.debug("[%s] remote I/O concurrency skipped: %s",
                                 execution_id, _rio_exc)

                # HYBRID route (2026-08-11): the SQL-connector side of a hybrid
                # query has already been streamed to local parquet; publish each
                # one under the SAME catalog.schema.table path the generated SQL
                # names, so that SQL runs VERBATIM.  Registering rather than
                # rewriting the SQL is deliberate — string surgery on a compiled
                # query is how a WHERE clause goes missing.
                if register_views:
                    self._register_parquet_as_tables(con, register_views, execution_id)

                # Custom-SQL dataset: registered S3 tables referenced by bare
                # name resolve as views (same "register, never rewrite" doctrine
                # as register_views above).
                if table_views:
                    for _tv_name, _tv_expr in table_views:
                        con.execute(
                            f"CREATE OR REPLACE VIEW {self._quote_ident(_tv_name)} "
                            f"AS SELECT * FROM {_tv_expr}")
                    logger.info(
                        "[%s] DuckDB S3 federation: registered table view(s): %s",
                        execution_id, [v[0] for v in table_views])

                # 2026-06-23 -- if the federated SQL embedded presigned URLs
                # (smart-VPC fast path inside _build_s3_table_expr ->
                # s3_urls_to_presigned), the named secrets / pragmas just
                # applied would cause httpfs to double-sign the URLs at
                # query time -> HTTP 0 / 403.  Detect the SigV4 marker in
                # the SQL we're about to execute and RESET signing if
                # present.  Connection isn't pooled by federation_engine
                # (single-use per call) so the RESET has no downstream
                # impact.  Same root cause as the subprocess bug closed by
                # core.duckdb_s3_plan.
                try:
                    from core.duckdb_s3_plan import (
                        sql_has_presigned_marker,
                        reset_s3_signing_on_connection,
                    )
                    if isinstance(sql, str) and sql_has_presigned_marker(sql):
                        # Pass sql_context so the reset is SCOPE-AWARE:
                        # only drops SECRETs whose endpoint matches a
                        # presigned URL host in the SQL.  Critical for
                        # cross-source federation that mixes vanilla AWS
                        # (per-conn SECRET, native s3://) with VPC (per-
                        # conn SECRET, presigned URLs) -- the AWS-side
                        # SECRET stays so its native s3:// reads still
                        # have credentials.
                        reset_s3_signing_on_connection(con, sql_context=sql)
                        logger.info(
                            "[%s] DuckDB S3 federation: detected presigned "
                            "URLs in SQL -- scope-aware RESET to avoid "
                            "httpfs double-sign (HTTP 0 / 403).",
                            execution_id,
                        )
                except Exception as _reset_exc:
                    logger.debug(
                        "[%s] federation S3-signing reset probe skipped: %s",
                        execution_id, _reset_exc,
                    )

                # Execute query — wire cooperative cancel so user-clicked Cancel
                # can abort mid-statement (con.interrupt() is thread-safe).
                from core.duckdb_cancel import maybe_spawn_watchdog as _maybe_wd
                _wd_stop = _maybe_wd(con, execution_id)
                try:
                    logger.info("[%s] DuckDB S3 federation executing: %s", execution_id, sql[:200])
                    result = con.execute(sql)
                    if sink_path is not None:
                        # Bounded-memory route: stream RecordBatches straight into
                        # the artifact.  ALL the connection/secret/JoinPruner setup
                        # above is shared with the DataFrame route on purpose —
                        # duplicating it is how the two paths would drift apart.
                        from core.federation_stream import duckdb_result_to_parquet
                        return duckdb_result_to_parquet(
                            result, sink_path, execution_id=execution_id,
                            label="DuckDB S3 federation")
                    df = result.fetchdf()
                    logger.info("[%s] DuckDB S3 federation: %d rows returned", execution_id, len(df))
                    return df
                finally:
                    if _wd_stop is not None:
                        _wd_stop.set()

        # ── THE RETRY ────────────────────────────────────
        # BOUNDED, DECLARED, never inherited.  ``core/s3_scan_retry.py``
        # fires only on the transient signatures DECLARED there, only when
        # this statement PARSES as read-only, and a ``TruncatedScanRefusal``
        # / ``ScanBudgetRefusal`` passes straight through untouched — a
        # retry that swallowed a correctness refusal would re-ask a question
        # the system declined to answer, which is worse than the flakiness.
        #
        # Measured on the 7,300-file corpus through this very chokepoint:
        # attempt 1 alone 9/12, with one retry 12/12.  RETRY SAFETY IS A
        # DECLARATION, NOT A DEFAULT — this scan is a pure read and
        # re-running it returns the same rows; that is why it qualifies and
        # why the module refuses to retry anything it cannot prove is one.
        from core.s3_scan_retry import retry_read_only_scan
        return retry_read_only_scan(
            _run_scan_once,
            sql=sql,
            label="DuckDB S3 federation",
            execution_id=execution_id,
        )

    def _augment_sql_with_join_pruner_filters(
        self,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
    ) -> str:
        """Round 10 — federation single-dataset JoinPruner integration.

        Parses the compiled SQL via sqlglot, identifies JOINs on
        different-name keys with a WHERE filter on one side, fetches the
        filtered side's bounds for the join key via ``iceberg_reader``,
        and AND-appends a BETWEEN clause to the outer WHERE so the join
        partner is row-group-pruned by DuckDB.

        Returns the original SQL unchanged when:
          * sqlglot can't parse
          * no JOINs present
          * no filtered/unfiltered asymmetry
          * iceberg source can't be located in ``s3_conns``
          * iceberg bounds aren't surfaced (writer didn't track stats)

        Fail-OPEN at every step — augmentation is an optimisation, never
        a correctness gate.  Worst case: no augmentation → original SQL
        runs as before.
        """
        if not sql or not s3_conns:
            return sql
        # Round 11 — admin kill switch.  Operators can disable the
        # federation augment without touching code if it misbehaves.
        # Default ON; flip ``federation.join_pruner_enabled=false`` to
        # disable.  Reads on every call (hot-reloadable).
        try:
            from core.config import get_section as _gs
            _fed_cfg = (_gs("federation") or {})
            if not _fed_cfg.get("join_pruner_enabled", True):
                return sql
        except Exception:
            pass
        try:
            import sqlglot
            from sqlglot import exp
        except Exception:
            return sql
        try:
            from core.join_pruner import JoinPruner, JoinKeyProbe
            from core.sql_partition_extractor import (
                _extract_join_equivalences,
                _extract_table_aliases,
            )
        except Exception:
            return sql

        try:
            parsed = sqlglot.parse_one(sql, read="duckdb",
                                        error_level=sqlglot.ErrorLevel.IGNORE)
        except Exception:
            return sql
        if parsed is None:
            return sql

        # Round 11 — bail out on complex SQL shapes that my parse-and-
        # set("where", ...) rewrite can't safely handle:
        #
        #   * CTEs (``WITH cte AS ...``): my augment only walks the
        #     outer SELECT's WHERE.  CTEs have their own WHERE that I
        #     don't touch.  If a JOIN+filter lives inside a CTE, my
        #     probe-extraction would emit an augment targeting the
        #     wrong scope.
        #
        #   * UNION / UNION ALL: parsed.args.get("where") is undefined
        #     for compound statements.  My set("where", ...) would
        #     either no-op or worse, attach to one branch.
        #
        #   * Multiple SELECTs (subqueries in FROM/SELECT): my augment
        #     can't tell which SELECT to attach to.
        #
        # When in doubt, return SQL unchanged — manifest-level pruning
        # at the iceberg layer still fires; we just lose the row-group
        # cherry from the SQL WHERE.
        try:
            if list(parsed.find_all(exp.CTE)):
                logger.debug(
                    "JoinPruner (federation): SQL has CTEs — skipping augment "
                    "(parse-set('where') would attach to wrong scope)")
                return sql
            if list(parsed.find_all(exp.Union)):
                logger.debug(
                    "JoinPruner (federation): SQL has UNION — skipping augment")
                return sql
            # Multiple top-level SELECTs (subqueries) — count.  Allow ONE
            # outer SELECT max; anything nested skips.
            _selects = list(parsed.find_all(exp.Select))
            if len(_selects) > 1:
                logger.debug(
                    "JoinPruner (federation): SQL has nested SELECTs (%d) — "
                    "skipping augment", len(_selects))
                return sql
        except Exception:
            return sql

        # Need at least one JOIN to even consider augmentation.
        try:
            _joins = list(parsed.find_all(exp.Join))
        except Exception:
            _joins = []
        if not _joins:
            return sql

        # Extract aliases + join column equalities.
        alias_map = _extract_table_aliases(parsed)
        join_eqs = _extract_join_equivalences(parsed, alias_map)
        if not join_eqs:
            return sql

        # Extract WHERE filters (no partition gate — we want all filters
        # for selecting anchor/target).
        try:
            from core.sql_partition_extractor import extract_all_filters_from_sql
            all_filters = extract_all_filters_from_sql(sql, dialect="duckdb")
        except Exception:
            return sql
        filtered_tables = {f.table.lower() for f in all_filters if f.table}
        if not filtered_tables:
            return sql

        # Identify candidate probes: (anchor_table, anchor_col, target_table, target_col)
        # where exactly one side is in filtered_tables and the join key
        # has different names on the two sides.
        candidate_probes: List[tuple] = []
        for (lt, lc, rt, rc) in join_eqs:
            if lc == rc:
                continue  # same-name: rely on column-stats pruning, not synth
            if lt in filtered_tables and rt not in filtered_tables:
                candidate_probes.append((lt, lc, rt, rc))
            elif rt in filtered_tables and lt not in filtered_tables:
                candidate_probes.append((rt, rc, lt, lc))
        if not candidate_probes:
            return sql

        # For each candidate, attempt to locate the anchor as an iceberg
        # source in s3_conns + fetch its bounds.  This requires the
        # caller's connection metadata to include enough info to
        # construct a boto3 client + bucket + prefix.  When that info
        # isn't available (SQL connector side, plain parquet, etc.),
        # skip silently.
        synth_clauses: List[str] = []
        try:
            from core.iceberg_reader import get_iceberg_data_files
            from core.s3_storage import S3StorageHandler, build_s3_config
        except Exception:
            return sql

        for (anchor_t, anchor_c, target_t, target_c) in candidate_probes:
            # Find anchor's iceberg config in s3_conns by matching against
            # the table name embedded in the SQL's iceberg_scan/read_parquet
            # URL.  Use sqlglot to find ``iceberg_scan('s3://bucket/prefix/anchor_t/...')``.
            _anchor_bucket = None
            _anchor_prefix = None
            _anchor_conn_id = None
            try:
                for _tbl_node in parsed.find_all(exp.Table):
                    _name = (str(_tbl_node.name) or "").lower()
                    if _name != anchor_t:
                        continue
                    # Table found in SQL — try to map to an iceberg source.
                    # Walk parent Func nodes for iceberg_scan / read_parquet.
                    _parent = _tbl_node.parent
                    _hops = 0
                    while _parent is not None and _hops < 5:
                        if isinstance(_parent, (exp.Anonymous, exp.Function)) and \
                           str(getattr(_parent, "name", "") or "").lower() in (
                               "iceberg_scan", "read_parquet",
                           ):
                            # Inspect arguments for an s3:// URL.
                            for _arg in _parent.find_all(exp.Literal):
                                _v = str(_arg.this or "")
                                if _v.startswith("s3://"):
                                    _rest = _v[5:].split("/", 1)
                                    if len(_rest) == 2:
                                        _anchor_bucket = _rest[0]
                                        _anchor_prefix = _rest[1]
                                    break
                            break
                        _parent = _parent.parent
                        _hops += 1
                    if _anchor_bucket and _anchor_prefix:
                        break
            except Exception:
                continue
            if not (_anchor_bucket and _anchor_prefix):
                continue
            # Pick the matching s3 connection (first one whose config
            # bucket matches).  Federation supports multiple but for
            # this hook, "first match" is good enough.
            for cid, conn in s3_conns.items():
                ccfg = conn.get("config") or {}
                if (ccfg.get("bucket_name") or "").lower() == _anchor_bucket.lower():
                    _anchor_conn_id = cid
                    break
            if _anchor_conn_id is None:
                continue

            # Build the anchor's partition_filters from extracted WHERE
            # filters that qualify to this table.
            _anchor_pf = []
            for f in all_filters:
                if (f.table or "").lower() != anchor_t:
                    continue
                _anchor_pf.append({
                    "col": f.column,
                    "op": f.operator,
                    "val": (f.values[0] if len(f.values) == 1 else f.values),
                })
            if not _anchor_pf:
                continue

            # Fetch bounds.
            _bounds_out: Dict[str, Any] = {}
            try:
                handler = S3StorageHandler(build_s3_config(s3_conns[_anchor_conn_id].get("config") or {}))
                # Strip any trailing path component to get the table prefix.
                _prefix_clean = _anchor_prefix.rstrip("/")
                get_iceberg_data_files(
                    handler.s3_client, _anchor_bucket, _prefix_clean,
                    partition_filters=_anchor_pf,
                    keys_only=True,
                    join_key_columns=[anchor_c],
                    _out_meta=_bounds_out,
                    # Phase H (2026-06-08) — thread db_manager so the L2
                    # short-circuit can engage on federation JOIN bounds
                    # aggregation.  Without it, federated joins always
                    # walk manifests even when the brain is fresh.
                    db_manager=self._db,
                )
            except Exception as _ice_exc:
                logger.debug(
                    "JoinPruner (federation): iceberg read failed for %s/%s: %s",
                    _anchor_bucket, _anchor_prefix, _ice_exc,
                )
                continue
            _jkb = (_bounds_out.get("join_key_bounds") or {}).get(anchor_c.lower())
            # Phase Q (2026-06-08) -- record federation JOIN-pruner
            # decision into the unified ScanPlan so the cross-source
            # bounds flow is visible via /api/admin/queries/scan-plan.
            try:
                from core.brain.scan_plan import (
                    get_recent, remember, PruneContext, JoinPlan,
                )
                from core.query_diagnostic_store import get_current_execution_id
                _eid = get_current_execution_id()
                if _eid:
                    _ctx = get_recent(_eid)
                    if _ctx is None:
                        _ctx = PruneContext(execution_id=_eid)
                        remember(_ctx)
                    _ctx.add_join(JoinPlan(
                        anchor_table=anchor_t, anchor_col=anchor_c,
                        target_table=target_t, target_col=target_c,
                        bounds_required=True,
                        bounds_available=bool(_jkb),
                        notes=[
                            f"federation cross-source: "
                            f"anchor_conn={_anchor_conn_id}, "
                            f"bucket={_anchor_bucket}, "
                            f"prefix={_anchor_prefix}"
                        ],
                    ))
            except Exception as _sp_q:
                logger.debug(
                    "[scan_plan] federation Q-shadow-write skipped: %s",
                    _sp_q)
            if not _jkb:
                continue
            _lo, _hi = _jkb
            if _lo is None or _hi is None:
                continue
            # Build a synth filter via JoinPruner so we get the SAME
            # selectivity preference (IN > EQUALS > BETWEEN) used elsewhere.
            jp = JoinPruner()
            probe = JoinKeyProbe(
                anchor_table=anchor_t, anchor_col=anchor_c,
                target_table=target_t, target_col=target_c,
            )
            _jkd = {anchor_c.lower(): (_bounds_out.get("join_key_distinct_values") or {}).get(anchor_c.lower())}
            sf = jp.synthesize_filter(
                probe, {anchor_c: (_lo, _hi)},
                anchor_surviving_files=1,  # we didn't track count; min OK
                anchor_distinct_values={k: v for k, v in _jkd.items() if v},
            )
            if sf is None:
                continue
            frag = sf.to_sql_where_fragment()
            if not frag:
                continue
            # The target table's alias in the SQL might differ; we use
            # the bare column name in the fragment, which DuckDB will
            # resolve against whichever table has that column in scope.
            synth_clauses.append(frag)

        if not synth_clauses:
            return sql

        # Append synth WHERE clauses to the outer SELECT's WHERE.
        # Round 12 deep-audit fix: build the new predicate as an AST node
        # FIRST, then graft into the existing WHERE via exp.And.  The
        # previous round-10 implementation round-tripped the existing
        # WHERE through ``{sql} AND {new_pred}`` string-concat then
        # re-parsed — fragile if the existing SQL had stray quotes /
        # comments / dialect quirks.  AST grafting is dialect-agnostic
        # and quote-safe.
        try:
            _where = parsed.args.get("where")
            _new_pred = " AND ".join(synth_clauses)
            # Parse ONLY the new predicate (no surrounding SQL).
            _new_parsed = sqlglot.parse_one(
                f"SELECT 1 WHERE {_new_pred}", read="duckdb",
            )
            # Round 13 deep-audit fix — defensive None guards.  parse_one
            # CAN return None on truly broken input, and even a successful
            # parse might lack ``where`` if sqlglot's parser silently
            # dropped a malformed fragment.  Without these guards we'd
            # construct ``exp.And(expression=None)`` which renders as
            # broken SQL, raises on parsed.sql(), and gets caught by the
            # outer except — wasteful + log-spammy.
            if _new_parsed is None:
                logger.debug(
                    "JoinPruner (federation): new-pred parse returned None — skipping")
                return sql
            _new_where_node = _new_parsed.args.get("where")
            if _new_where_node is None or _new_where_node.this is None:
                logger.debug(
                    "JoinPruner (federation): new-pred had no WHERE body — skipping")
                return sql
            _new_node = _new_where_node.this
            if _where is not None and _where.this is not None:
                # AND-combine the existing WHERE AST with the new one.
                _combined = exp.And(this=_where.this, expression=_new_node)
                parsed.set("where", exp.Where(this=_combined))
            else:
                parsed.set("where", exp.Where(this=_new_node))
            augmented = parsed.sql(dialect="duckdb")
            if not augmented or not isinstance(augmented, str):
                logger.debug(
                    "JoinPruner (federation): rewrite emitted non-string SQL — skipping")
                return sql
            logger.info(
                "JoinPruner (federation): augmented SQL with %d synth WHERE clause(s) — %s",
                len(synth_clauses), _new_pred[:200],
            )
            return augmented
        except Exception as _rewrite_exc:
            logger.debug(
                "JoinPruner (federation): SQL rewrite failed (%s) — using original",
                _rewrite_exc,
            )
            return sql

    def _setup_duckdb_secrets(
        self,
        con,
        s3_conns: Dict[int, Dict[str, Any]],
    ) -> None:
        """Create DuckDB named secrets for each S3 connection.

        Uses CREATE SECRET to allow multiple S3 endpoints in a single session.
        Each secret is scoped to its bucket path so DuckDB auto-resolves
        which credentials to use for each S3 URI.
        """
        for conn_id, conn in s3_conns.items():
            cfg = conn.get("config", {})

            # Determine S3 access mode: 'presigned' skips DuckDB credentials
            # (pre-signed URLs handle auth); 'native' falls through to CREATE SECRET.
            _access_mode = get_s3_access_mode(cfg)
            logger.info("S3 access mode for connection %d: %s", conn_id, _access_mode)
            if _access_mode == "presigned":
                logger.info("Skipping DuckDB secret for on-prem S3 connection %d "
                            "(pre-signed URLs handle auth)", conn_id)
                continue

            secret_name = f"s3_conn_{conn_id}"
            bucket = cfg.get("bucket_name", cfg.get("bucket", ""))

            # Resolve credentials (STS for profile / assume_role / iam_role)
            key, secret, token = self._resolve_s3_credentials(cfg)
            # 2026-09-26 -- endpoint / ssl / url-style / region from the ONE
            # resolver (core.s3_access).  This site had stripped the scheme
            # by hand and never VPCE-normalised, the only SET site that did
            # not; the SECRET now carries the same host every SET site does.
            from core.s3_access import resolve_s3_access
            _access = resolve_s3_access(
                cfg, connection_id=conn_id, credentials=(key, secret, token),
                proxy=False)
            params = _access.duckdb_secret_params(scope_bucket=bucket or None)

            create_sql = f"CREATE SECRET {secret_name} ({', '.join(params)});"
            try:
                con.execute(create_sql)
                logger.info("Created DuckDB secret '%s' for connection %d (bucket=%s)",
                            secret_name, conn_id, bucket)
            except Exception as exc:
                logger.warning("Failed to create DuckDB secret for conn %d: %s — "
                               "falling back to SET pragmas", conn_id, exc)
                # Fallback: use SET pragmas (works for single S3 endpoint)
                self._setup_duckdb_pragmas(con, cfg)

    def _resolve_s3_credentials(self, cfg: Dict[str, Any]) -> Tuple[str, str, str]:
        """``(key, secret, token)`` through THE credential chain
        (``core.credential_resolver.resolve_s3_keys``).

        2026-10-26 -- this was the federation engine's OWN copy of the
        STS / profile chain: no portal, no system account, its own
        on-prem rule and its own session name.  A connection the feed
        worker read with the vault's keys reached a federation SECRET
        with the pod's ambient identity.  Empty strings when the chain
        found nothing -- the SECRET is then created without keys and the
        read says so."""
        try:
            from core.credential_resolver import resolve_s3_keys
            return resolve_s3_keys(cfg)
        except Exception as exc:
            logger.warning("Failed to resolve S3 credentials (auth_mode=%s): %s",
                           (cfg.get("auth_mode") or "keys").lower(), exc)
        return "", "", ""

    def _setup_duckdb_pragmas(self, con, cfg: Dict[str, Any]) -> None:
        """Fallback: configure S3 via SET pragmas (single endpoint only)."""
        # Presigned mode: pre-signed URLs handle auth — skip S3 credential setup (BF-13)
        _access_mode = get_s3_access_mode(cfg)
        logger.info("S3 access mode for pragma setup: %s", _access_mode)
        if _access_mode == "presigned":
            logger.info("Skipping DuckDB S3 pragmas for on-prem connection (pre-signed URLs handle auth)")
            return
        key, secret, token = self._resolve_s3_credentials(cfg)
        # 2026-09-26 -- the ONE resolver (core.s3_access) decides endpoint /
        # ssl / url-style / region; the STS-resolved credentials travel in.
        from core.s3_access import resolve_s3_access
        resolve_s3_access(cfg, credentials=(key, secret, token),
                          proxy=False).apply_to_duckdb(con)

    def _configure_duckdb_performance(self, con, s3_conns: Optional[Dict[int, Dict[str, Any]]] = None) -> None:
        """Apply DuckDB performance tuning settings + SSL config."""
        # 2026-06-24 -- HTTP timeout reads from federation config.
        # 2026-09-21 -- in SECONDS.  This passed the millisecond value
        # straight to DuckDB, whose http_timeout is seconds, so the
        # federation connection (which serves S3 reads too, see the
        # s3_* settings above) ran with a 4-hour timeout.
        try:
            from core.config import federation as _fed_cfg
            _http_s = int(_fed_cfg.http_timeout_seconds)
        except Exception:
            _http_s = 30
        for stmt in (
            "SET http_keep_alive=true;",
            "SET http_retries=2;",
            "SET http_retry_wait_ms=1000;",
            f"SET http_timeout={_http_s};",
            "SET enable_http_metadata_cache=true;",
            "SET enable_object_cache=true;",
        ):
            try:
                con.execute(stmt)
            except Exception:
                pass
        # ── S3 HTTP transport (2026-09-20) ───────────────────────────────
        # THIS is the path that fell over: federation's in-process DuckDB
        # reading a presigned URL list.  ``http_keep_alive`` above is
        # necessary and NOT sufficient — with it on, DuckDB still opened two
        # TCP connections per file, so 7,300 files meant 14,600 connections
        # and the endpoint refused.  ``httpfs_connection_caching`` is what
        # actually reuses them (4,000 connections -> 10 for the same 10,000
        # requests).  It only exists once httpfs is LOADED, which is why it
        # lives here rather than in duckdb_factory: this method is called at
        # line ~4916, after the LOAD at ~4877.
        try:
            from core.s3_http_transport import apply_s3_http_transport
            apply_s3_http_transport(con, label="federation")
        except Exception as _tr_exc:                  # pragma: no cover
            logger.debug("could not apply S3 http transport policy: %s",
                         _tr_exc)
        # 2026-06-24 -- SSL config: stop unconditionally disabling
        # cert verification.  Route through the shared SSL helper so
        # operator's ``ssl_verify=<path-to-pem>`` is HONORED and
        # ``ssl_verify=True`` (default) uses the system CA store
        # instead of being silently turned OFF.  Cross-source
        # federation: pick the FIRST conn's SSL config -- DuckDB SSL
        # SETs are global per connection, can't be per-source.
        # Operator with mixed SSL configs across federated sources
        # must standardise on one.
        _picked_cfg: Optional[Dict[str, Any]] = None
        if s3_conns:
            for _conn in s3_conns.values():
                _picked_cfg = _conn.get("config", {})
                if _picked_cfg:
                    break
        if _picked_cfg is not None:
            try:
                from core.ssl_config import apply_ssl_to_duckdb_con
                apply_ssl_to_duckdb_con(
                    con, _picked_cfg,
                    log_prefix="federation_engine SSL",
                )
            except Exception as _ssl_exc:
                logger.warning(
                    "federation_engine: SSL helper failed (%s) -- "
                    "leaving DuckDB SSL defaults in place.",
                    _ssl_exc,
                )

    def _transpile_for_connector(self, sql: str, conn_type: str,
                                 execution_id: str) -> str:
        """Transpile engine-generated DuckDB-dialect SQL to the target
        connector's dialect — the ONE point where generated SQL leaves
        DuckDB-land (2026-08-09 source-agnostic audit §3).

        The builder (_build_query/_build_from_base_query) and the RLS
        rewrite both emit DuckDB-shaped SQL; running it verbatim made
        Databricks datasets silently wrong ("x" = string literal in Spark
        SQL) and Oracle datasets loudly broken (LIMIT → ORA-00933).
        sqlglot is already a dependency of this module (~_prune_via_join).

        Failure posture — this is a correctness GATE, not a cap:
          * unknown connector dialect → raise (UNKNOWN = UNSAFE; a dataset
            on e.g. a rest_api connection classifies as "sql" and must not
            receive DuckDB SQL it can only mis-execute);
          * transpile error on a dialect where the verbatim DuckDB shape is
            itself valid SQL (trino/starburst/athena/snowflake/postgres) →
            fall back to verbatim with a warning (exactly the pre-fix
            behaviour that works on those engines);
          * transpile error on databricks/oracle/mysql → raise loudly — a
            refusal beats silent wrong data.
        """
        # 2026-08-19 -- delegates to core.sql_connector_dialect, which is
        # this same logic lifted out so it is no longer reachable from only
        # ONE handoff.  Its absence everywhere else is why the 2026-08-09
        # Databricks fix never protected the execute / scheduler / reports /
        # published-view / preview / feed paths.
        from core.sql_connector_dialect import transpile_for_connector

        _out = transpile_for_connector(
            sql, conn_type, context=execution_id,
            oracle_transform=_oracle_temporal_literal,
        )
        # 2026-09-15 -- publish what the SOURCE will actually receive.  This
        # is the only point where generated SQL leaves DuckDB-land, so it is
        # the only place that knows.  A ContextVar rather than a return-value
        # change because the statement has to reach ``FederationResult``
        # across several helpers (streaming, hybrid, whole-query) whose
        # return contracts are shared with other callers -- the same reason
        # the execution id travels this way.
        try:
            _EXECUTED_SQL.set(_out)
        except Exception:      # never let a diagnostic break an execution
            pass
        return _out

    def _execute_sql_connector(
        self,
        sql: str,
        sql_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
    ) -> pd.DataFrame:
        """Execute SQL via a SQL connector (Trino, Snowflake, etc.)."""
        from core.connectors import get_connector
        from core.connection_pool import get_pooled_connector

        # Use the first SQL connection
        conn_id, conn = next(iter(sql_conns.items()))
        conn_type = conn.get("connection_type", "")
        conn_config = conn.get("config", {})

        # 2026-08-09: generated SQL is DuckDB-dialect — transpile it to the
        # target engine's dialect at this single handoff point (audit §3).
        sql = self._transpile_for_connector(sql, conn_type, execution_id)

        # 2026-09-16 -- POOLED (see _execute_sql_connector_to_parquet).
        with get_pooled_connector(conn_id, conn_type, conn_config,
                                  conn.get("name", "")) as connector:
            # Phase 153 strategic chokepoint -- streaming fetch (no list-of-dicts
            # intermediate; bounded peak memory).
            from core.connector_to_parquet import execute_sql_to_dataframe
            # 2026-08-10 -- cancel_event was NEVER passed here.
            #
            # ``execute_sql_to_dataframe`` has accepted ``cancel_event`` all
            # along, and each SQL connector spawns a watchdog on it that calls
            # ``cursor.cancel()`` -- SYSTEM$CANCEL_QUERY on Snowflake, a
            # coordinator query-cancel on Trino/Starburst.  Omitting the kwarg
            # meant no watchdog was ever spawned on the FEDERATION path, which
            # is the path Business Reports and dataset queries take.  Cancelling
            # such a report flipped the row to 'cancelled' and returned control
            # to the user while the query kept burning source cluster capacity
            # to completion.  The DuckDB half of the same path already resolves
            # its event through ``core.duckdb_cancel.maybe_spawn_watchdog``;
            # this is the connector half of the identical contract.
            from core.duckdb_cancel import lookup_cancel_event
            _cancel_event = lookup_cancel_event(execution_id)
            try:
                df, _cols, _n = execute_sql_to_dataframe(
                    connector, sql, cancel_event=_cancel_event,
                )
            except (InterruptedError, ValueError):
                raise
            except Exception as exc:
                raise wrap_source_failure(exc, conn_type) from exc
            logger.info("[%s] SQL connector (%s) returned %d rows", execution_id, conn_type, len(df))
            return df

    def _execute_hybrid(
        self,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
        sql_conns: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        execution_id: str,
    ) -> pd.DataFrame:
        """Hybrid execution, DataFrame flavour — the streaming route is
        ``_execute_hybrid_to_parquet`` and that is what ``execute_dataset_query``
        uses.  This remains for the legacy ``_execute_query`` callers.

        2026-08-11 — the fallback here USED to be
        ``self._execute_sql_connector(sql, sql_conns, execution_id)``: when
        DuckDB could not resolve the connector-side tables (which it never
        can — they compile to ``"catalog"."schema"."table"``), the whole
        query was handed to ONE SQL connector, which cannot resolve
        ``read_parquet('s3://…')`` either.  It therefore normally raised a
        confusing connector error, and in the cases where it did NOT raise it
        returned the connector side ALONE and called that success — the same
        half-the-data-reported-as-complete shape the feed audit found.

        It now routes through the same materialise-and-join path as the
        streaming route (via a temp artifact) so both flavours give the SAME
        answer, and raises rather than answering from one side.
        """
        try:
            return self._execute_duckdb_s3(sql, s3_conns, execution_id)
        except Exception as exc:
            logger.info("[%s] DuckDB hybrid direct attempt failed (%s) — "
                        "materialising the connector side and joining in "
                        "DuckDB", execution_id, exc)
            tmp_out = str(Path(self._output_dir) / "hybrid_tmp"
                          / f"{execution_id}_{uuid.uuid4().hex[:8]}.parquet")
            try:
                self._execute_hybrid_to_parquet(
                    sql=sql, s3_conns=s3_conns, sql_conns=sql_conns,
                    source_tables=source_tables or [], filter_specs=None,
                    execution_id=execution_id, output_path=tmp_out)
                return pd.read_parquet(tmp_out)
            finally:
                try:
                    Path(tmp_out).unlink(missing_ok=True)
                except OSError:
                    pass

    def _execute_duckdb_plain(
        self,
        sql: str,
        execution_id: str,
        sink_path: Optional[str] = None,
    ) -> Any:
        """Execute SQL in plain DuckDB (no S3, no connectors).

        ``sink_path`` — see ``_execute_duckdb_s3``: streams to parquet at
        O(one batch) instead of materialising a DataFrame.
        """
        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB not installed")

        from core.duckdb_factory import duckdb_connection
        with duckdb_connection() as con:
            from core.duckdb_cancel import maybe_spawn_watchdog as _maybe_wd
            _wd_stop = _maybe_wd(con, execution_id)
            try:
                try:
                    result = con.execute(sql)
                except (duckdb.CatalogException, duckdb.BinderException) as _unknown:
                    # 2026-11-04: SQL written for a source reached the local engine: say that,
                    # as a refusal (422), not a 500 "Table with name X does not exist".
                    from core.error_sanitizer import local_engine_unknown_catalog
                    _said = local_engine_unknown_catalog(_unknown)
                    if _said:
                        raise ValueError(_said) from _unknown
                    raise
                if sink_path is not None:
                    from core.federation_stream import duckdb_result_to_parquet
                    return duckdb_result_to_parquet(
                        result, sink_path, execution_id=execution_id,
                        label="Plain DuckDB")
                df = result.fetchdf()
                logger.info("[%s] Plain DuckDB: %d rows", execution_id, len(df))
                return df
            finally:
                if _wd_stop is not None:
                    _wd_stop.set()

    # ── Internal: SQL helpers ────────────────────────────────────────────────

    def _filter_to_sql(self, f: FilterSpec) -> str:
        """Convert a FilterSpec to a SQL WHERE clause fragment."""
        phys = self._quote_ident(f.physical_name)
        op = f.operator

        if op in ("is_null", "is_not_null"):
            return f"{phys} {_OP_MAP[op]}"

        # The column's type must reach EVERY literal on this path, not just
        # the equality one -- IN, NOT IN and BETWEEN compare against the
        # same column and fail identically on Trino when handed a varchar.
        # 2026-10-25 -- the SOURCE's type when the catalog knows it (a label
        # is not a type), checked: a value that cannot be written as that
        # type is refused here, by name, never sent for the engine to reject.
        dt = self._literal_type(f)

        if op in ("in", "not_in"):
            # 2026-08-13 -- a non-list value used to ``return ""``, and EVERY
            # caller does ``if clause: where_parts.append(clause)``, so the
            # filter VANISHED from the WHERE clause and the query returned
            # MORE rows than the user asked for, silently.  A filter that
            # cannot be rendered is a correctness problem, not a cap: it must
            # never degrade quietly.
            #
            # ``core.sql_filter_wrapper._coerce_list`` has always accepted a
            # comma-separated string for IN-lists ("Permit a single
            # comma-separated string for IN-list operators"), so the
            # Published-API path coerced while this one dropped -- the same
            # divergence that let three literal renderers drift apart.
            # Coerce identically here.
            items = self._coerce_in_list(f.value)
            if not items:
                raise ValueError(
                    f"Filter on '{f.physical_name}' uses operator '{op}' with "
                    f"no usable values ({f.value!r}).  Refusing to run the "
                    f"query without it — dropping the filter would return "
                    f"more rows than the report asked for."
                )
            vals = ", ".join(self._checked_literal(v, dt, f) for v in items)
            return (f"{phys} IN ({vals})" if op == "in"
                    else f"{phys} NOT IN ({vals})")

        if op == "between":
            # 2026-09-04 -- this rendered whatever it was given, including
            # ``AND NULL``.  ``x BETWEEN 'a' AND NULL`` is NULL for every
            # row, so the report returned ZERO ROWS behind a 200 and blamed
            # the user's filters; on Trino, comparing a date column to a
            # varchar bound is a type error and the report fails outright.
            # Neither says the bound was missing.
            #
            # Two ways it arrived without an upper bound, both reachable
            # from the product:
            #   * PivotReportBuilder offers "Between" with a SINGLE value
            #     box, so it never sent one;
            #   * a range control naturally produces ONE field holding two
            #     values -- ``value=[lo, hi]`` -- and that rendered the
            #     Python list's repr as the lower bound.
            #
            # So: accept the pair however it is spelled, and refuse when a
            # bound is genuinely absent.  The ``in`` branch above already
            # works this way, and for the same reason -- a filter that
            # cannot be rendered is a correctness problem, not a cap, and
            # must never degrade quietly.
            lo, hi = self._between_bounds(f)
            return (f"{phys} BETWEEN {self._checked_literal(lo, dt, f)} "
                    f"AND {self._checked_literal(hi, dt, f)}")

        # 2026-08-31 — starts_with / ends_with / contains.
        #
        # The report builder has always OFFERED these ("Starts With",
        # "Ends With", each with its own value placeholder) and every other
        # filter consumer implements them — optimized_engine, iceberg_reader,
        # parquet_pruning, pruning_support, brain.filter.  This engine was
        # the one that did not, so a report saved with one of them returned
        # 200 and was then PERMANENTLY unrunnable: execute 400, every export
        # 500, with nothing at save time to warn the author.  The line below
        # that keeps LIKE operands as strings already NAMED these three, so
        # the intent was here all along — only the map entry was missing.
        #
        # They cannot be _OP_MAP templates: "{v}" substitutes the whole
        # quoted literal, and the wildcard has to go INSIDE the quotes.
        #
        # Semantics follow the pandas sibling (str.startswith / endswith /
        # contains): the operand is a LITERAL, not a pattern.  So % and _
        # in the user's value are escaped and an explicit ESCAPE clause is
        # emitted — otherwise searching for "50%" would silently match
        # everything beginning with "50".  `like` keeps its pattern
        # semantics untouched; it is a different operator on purpose.
        # Edge-case sweep 2026-09-24 -- a value-taking operator with NO value,
        # or a LIST where one value is expected, rendered anyway:
        #   * eq/gt/... with no value -> "= NULL": zero rows behind a 200;
        #   * contains/starts_with with no value -> LIKE '%%': EVERY row --
        #     a missing value WIDENED the result;
        #   * a list handed to a single-value parameter -> the list's repr as
        #     a literal: zero rows behind a 200.
        # Both are the caller's mistake and both have a spelling that says
        # what they meant (is_null / in), so refuse and name it.
        if op not in ("is_null", "is_not_null", "in", "not_in", "between"):
            if f.value is None:
                raise ValueError(
                    f"Filter on '{f.physical_name}' uses operator '{op}' with no "
                    f"value.  Pass a value, or use 'is_null' / 'is_not_null' to "
                    f"test for a missing one.  Refusing rather than running a "
                    f"filter that matches nothing (or, for text matches, "
                    f"everything).")
            if isinstance(f.value, (list, tuple, set, dict)):
                raise ValueError(
                    f"Filter on '{f.physical_name}' uses operator '{op}', which "
                    f"takes ONE value, with {type(f.value).__name__} "
                    f"{f.value!r}.  Use 'in' for several values.")
            # 2026-10-03 (owner, real Snowflake): a report saved from the
            # builder with an untouched "Add Filter" row carried
            # {"operator": "eq", "value": ""}; this rendered
            # ``"REGION" = ''`` and the report answered 0 rows behind a 200
            # while its dataset returned 4.  An empty string from a filter
            # row is an UNFILLED row, not a request for empty text -- and for
            # the text matches it would match EVERY row (LIKE '%%').  The
            # product has no "is empty text" operator; is_null / is_not_null
            # are the spellings for a missing value.  Save time refuses the
            # same thing (business_reports_api._refuse_unfilled_filters);
            # this is the run-time half for rows stored before that.
            if isinstance(f.value, str) and f.value == "":
                raise ValueError(
                    f"Filter on '{f.physical_name}' uses operator '{op}' with an "
                    f"EMPTY value -- an unfilled filter row, not a filter.  Pick "
                    f"a value for it or remove it (use 'is_null' / "
                    f"'is_not_null' to test for a missing value).  Refusing "
                    f"rather than running \"= ''\", which returns no rows (and "
                    f"a text match on '' returns every row).")

        if op in ("starts_with", "ends_with", "contains", "not_contains"):
            raw = "" if f.value is None else str(f.value)
            esc = (raw.replace("\\", "\\\\")
                      .replace("%", "\\%")
                      .replace("_", "\\_"))
            pattern = {"starts_with": esc + "%",
                       "ends_with":   "%" + esc,
                       "contains":    "%" + esc + "%",
                       "not_contains": "%" + esc + "%"}[op]
            keyword = "NOT LIKE" if op == "not_contains" else "LIKE"
            return (f"{self._text_operand(phys, dt)} {keyword} "
                    f"{self._sql_literal(pattern)} ESCAPE '\\'")

        template = _OP_MAP.get(op)
        if not template:
            # 2026-08-13 -- was ``logger.warning(...); return ""``.  The
            # callers append only truthy clauses, so an unrecognised operator
            # SILENTLY REMOVED the filter and the query returned more rows
            # than were asked for.  A warning in a log nobody reads is not a
            # disclosure.  Refuse instead: wrong data is worse than no data.
            raise ValueError(
                f"Filter on '{f.physical_name}' uses unsupported operator "
                f"'{op}'.  Supported: {sorted(SUPPORTED_FILTER_OPERATORS)}. "
                f"Refusing to run the query without the filter."
            )

        # LIKE is a STRING operator on both sides.  The literal stays a
        # plain string (a typed temporal literal would make
        # `date LIKE DATE '2025-09%'` invalid), and the COLUMN is cast when
        # it is not already text -- see _text_operand.  Getting only the
        # literal right still left `date LIKE varchar`, which is a binder
        # error, not a filter.
        if op in ("like", "not_like", "contains", "starts_with", "ends_with"):
            return (f"{self._text_operand(phys, dt)} "
                    f"{template.format(v=self._sql_literal(f.value))}")

        return f"{phys} {template.format(v=self._checked_literal(f.value, dt, f))}"

    def filter_spec_problems(self, dataset_ids: List[int], specs: List[Dict[str, Any]]) -> List[str]:
        """Every value of every filter that its column's type cannot hold --
        the SAVE-time twin of ``_checked_literal`` (2026-10-25).  Types as
        the run reads them (the source's via the catalog / one DESCRIBE, else
        the dataset's label); values split the way the run splits them.  One
        sentence per problem, naming the filter and the column."""
        cols: Dict[int, Dict[str, Any]] = {}
        for did in dataset_ids:
            try:
                ds = self._db.get_dataset_full(int(did)) or {}
            except Exception:                          # noqa: BLE001 -- the run still refuses
                continue
            dcols = list(ds.get("columns") or [])
            self._annotate_source_types(ds, dcols)
            cols.update({int(c["id"]): c for c in dcols if c.get("id") is not None})
        out: List[str] = []
        for i, spec in enumerate(specs or []):
            if not isinstance(spec, dict):
                continue
            try:
                col = cols.get(int(spec.get("column_id")))
            except (TypeError, ValueError):
                col = None
            if not col:
                continue
            op = str(spec.get("operator") or "eq").lower()
            if op in ("is_null", "is_not_null", "like", "not_like", "contains", "not_contains",
                      "starts_with", "ends_with"):
                continue
            dt = str(col.get("_source_data_type") or col.get("data_type") or "")
            name = col.get("friendly_name") or col.get("physical_name")
            if op in ("in", "not_in"):
                values = self._coerce_in_list(spec.get("value"))
            elif op == "between":
                v, v2 = spec.get("value"), spec.get("value2")
                values = list(v) if isinstance(v, (list, tuple)) and v2 in (None, "") else [v, v2]
            else:
                values = [spec.get("value")]
            for v in values:
                problem = filter_value_problem(v, dt, str(name))
                if problem:
                    out.append(f"Filter {i + 1} ({name}): {problem}")
                    break
        return out

    @staticmethod
    def _literal_type(f: "FilterSpec") -> str:
        """The type a filter's values are WRITTEN as: the source's, when the
        catalog knows it (text included -- a text column of number-like values
        stays quoted, '007' is not 7), else the dataset's label."""
        return f.source_data_type or f.data_type

    @staticmethod
    def _checked_literal(value: Any, dt: str, f: "FilterSpec") -> str:
        """``_sql_literal``, refusing a value the column's type cannot hold
        -- in words a person can act on, before any SQL is sent."""
        problem = filter_value_problem(value, dt, f.physical_name)
        if problem:
            raise ValueError(problem)
        return FederationEngine._sql_literal(value, dt)

    @staticmethod
    def _text_operand(phys: str, data_type: str) -> str:
        """The left-hand side of a LIKE, for a column of ``data_type``.

        2026-09-04.  LIKE / NOT LIKE / starts_with / ends_with / contains
        compared the column DIRECTLY, so a text match on a date or numeric
        column was::

            WHERE "tradedate" LIKE '2026-01%'

        which is not a filter that returns nothing — it is a hard failure
        at the source.  DuckDB answers *No function matches the given name
        and argument types '~~(DATE, STRING_LITERAL)'*; Trino answers
        *Cannot apply operator: date LIKE varchar*.  The report 500s and
        the message is about function signatures, so nothing points at the
        filter the author chose.

        The builder offers "Contains" / "Starts With" / "Ends With" for
        EVERY column, and the in-memory sibling in ``_apply_filters_to_df``
        has always answered the same question by casting::

            df[df[col].astype(str).str.contains(...)]

        So the two implementations of one contract disagreed: the same
        report filtered correctly in memory and failed in SQL.  Casting
        here makes them agree, and "does this date CONTAIN 2026-01" is a
        reasonable thing to ask — it is why the operator is offered on
        every column in the first place.

        Only non-text columns are cast: a VARCHAR column keeps its bare
        reference, so nothing that worked before changes shape, and any
        index or statistic on it stays usable.
        """
        kind = (data_type or "").strip().lower()
        if kind and kind not in ("string", "text", "varchar", "char"):
            return f"CAST({phys} AS VARCHAR)"
        return phys

    @staticmethod
    def _between_bounds(f: "FilterSpec") -> Tuple[Any, Any]:
        """The (low, high) pair of a BETWEEN filter, however it was spelled.

        2026-09-04.  TWO consumers ask what a between filter's bounds are —
        ``_filter_to_sql``, which renders the WHERE clause, and
        ``_filters_for_table_pruning``, which forwards the predicate to the
        parquet/iceberg readers so they can skip files.  They each read the
        FilterSpec their own way, and a shape one understood the other did
        not:

          * ``value=lo, value2=hi``   — what the report builder sends;
          * ``value=[lo, hi]``        — what a range control naturally
            produces, and what an API client writes.

        Teaching only the SQL side about the list form would have been the
        defect this repository keeps producing: the query would filter
        correctly while the pruner, handed ``[[lo, hi], None]``, fails open
        and keeps every file.  No wrong rows — the readers are careful — but
        pruning silently switched off, which is the "scanning oceans instead
        of the island" symptom, on the one filter shape most likely to be
        used on a partitioned date column.

        So there is one answer, and both callers ask for it.

        Raises ``ValueError`` when a bound is genuinely absent: ``x BETWEEN
        a AND NULL`` is NULL for every row, so rendering it returns an EMPTY
        report behind a 200 and blames the author's filters.
        """
        lo, hi = f.value, f.value2
        if hi is None and isinstance(lo, (list, tuple)):
            pair = list(lo)
            if len(pair) == 2:
                lo, hi = pair[0], pair[1]
        if lo is None or hi is None or lo == "" or hi == "":
            raise ValueError(
                f"Filter on '{f.physical_name}' uses BETWEEN but is missing "
                f"a bound (from={f.value!r}, to={f.value2!r}). Refusing to "
                f"run the query: 'BETWEEN x AND NULL' matches no rows at "
                f"all, so the report would come back empty as though the "
                f"data were missing."
            )
        return lo, hi

    @staticmethod
    def _quote_ident(name: str) -> str:
        """Quote an identifier for the engine's INTERMEDIATE dialect (DuckDB).

        THE DIALECT HERE IS DELIBERATELY NOT THE TARGET'S, and that is the one
        thing worth knowing about this function.  ``_build_query`` /
        ``_build_from_base_query`` / ``_table_to_expression`` emit DuckDB-shaped
        SQL on purpose -- the same text runs on DuckDB for S3 and hybrid
        datasets -- and every handoff to a SQL connector converts it at ONE
        point, ``_transpile_for_connector`` (four call sites: whole-query,
        partitioned, to-parquet, hybrid side).  sqlglot parses ``"col"`` as an
        IDENTIFIER in the duckdb grammar and re-emits it as ```col``` for
        Databricks/MySQL, so the ANSI double quote written here is correct
        BECAUSE it is transpiled, not in spite of it.  Measured end to end:

            builder     SELECT "order", "top" FROM "hive"."sales"."orders" ...
            databricks  SELECT `order`, `top` FROM `hive`.`sales`.`orders` ...

        Reading the builder's output with ``read="databricks"`` shows string
        literals and a constant-false predicate, but that text never reaches
        Databricks: skipping the transpile is what makes it look broken.
        Rendering the TARGET's delimiters here would instead put backticks into
        SQL that DuckDB itself executes on the S3 and hybrid routes.

        2026-09-05: the body is now the shared renderer
        (:func:`core.sql_filter_wrapper.quote_identifier_for_dialect`) rather
        than a fifth hand-written quoting site, so the escaping rule and the
        read-back verification live in one place.  ``always_quote=True``
        because this path has always emitted a quoted identifier and the
        builders' output is compared against it verbatim
        (``_registered_table_views_for_sql``); letting the renderer choose
        bare-where-safe would change generated SQL on every dialect, which is
        far wider than anything it would fix.  Proven byte-identical over a
        3,000-name corpus for every name except the two cases kept below.
        """
        if not name:
            # Kept, not routed: the shared renderer REFUSES an empty name, and
            # a refusal here would turn a malformed relationship (a join key
            # with one side missing) into a hard failure at a point that has
            # always produced a loud engine error of its own.
            return '""'
        if str(name).startswith('"') and str(name).endswith('"'):
            # Already quoted -- a physical name can arrive carrying the
            # source's own quoting.  Re-quoting would address a DIFFERENT
            # column ("My Col" -> """My Col"""), so pass it through as before.
            return str(name)
        from core.sql_filter_wrapper import (DEFAULT_DIALECT,
                                             quote_identifier_for_dialect)
        return quote_identifier_for_dialect(name, DEFAULT_DIALECT,
                                            always_quote=True)

    @staticmethod
    def _coerce_in_list(value: Any) -> list:
        """Normalise an IN/NOT IN value into a list of usable items.

        Mirrors ``core.sql_filter_wrapper._coerce_list`` deliberately: that
        path has always accepted a single comma-separated string, and having
        two different answers to "what is an IN-list?" is how the two paths
        disagreed about whether a filter applied at all.
        """
        if value is None:
            return []
        if isinstance(value, (list, tuple, set)):
            return [v for v in value if v is not None and v != ""]
        if isinstance(value, str):
            if "," in value:
                return [s.strip() for s in value.split(",") if s.strip() != ""]
            return [value] if value != "" else []
        return [value]

    @staticmethod
    def _sql_literal(value: Any, data_type: str = "") -> str:
        """Convert a Python value to a SQL literal.

        DELEGATES to :func:`core.query_compiler.sql_literal` — the single
        inline-literal renderer.  This method used to be its own third
        implementation, and it was the WEAKEST of the three: it had no
        typed-prefix passthrough, so it quoted every non-numeric value and
        Starburst rejected date filters with
        ``Cannot apply operator: date = varchar(27)``.  It is also why the
        operator's own workarounds failed — ``DATE '2025-09-30'`` and
        ``CAST('2025-09-30' as date)`` were quoted into strings.

        Do not reintroduce a local implementation here.  Three renderers
        with three capability sets is what caused the outage; the fix for
        the next engine quirk belongs in the chokepoint so every route
        gets it at once.
        """
        from core.query_compiler import sql_literal as _sql_lit
        return _sql_lit(value, data_type)

    @staticmethod
    def _esc(v: str) -> str:
        """Escape single quotes for DuckDB SQL strings."""
        return v.replace("'", "''")
