"""
Connection Manager
Manages data source connections (S3 and local) for the Parquet Query Engine.
Provides per-connection file listing and schema retrieval.
"""

import logging
import re
import sys
import threading
import time
from pathlib import Path
from typing import Dict, Any, Optional, Tuple


from core.s3_storage import S3StorageHandler, build_s3_config
from core.database import DatabaseManager
from core.file_formats import SUPPORTED_EXTENSIONS as _SUPPORTED_EXTS, get_format_adapter

logger = logging.getLogger(__name__)


# BF-278 / BF-282: module-level singleton holder so callers in
# core/iceberg_reader.py and core/duckdb_views.py can invalidate cached
# S3 handlers on ExpiredToken without taking a circular import on
# api.connections_api (which has its own ``_conn_manager`` instance set
# at startup via its setter).  The singleton is wired via
# ``set_connection_manager()`` from main.py during boot.
_GLOBAL_CONN_MANAGER: Optional["ConnectionManager"] = None

# 2026-08-02 — sentinel for "no coherence epoch observed yet" (see
# ConnectionManager._check_connections_epoch).
_EPOCH_UNSET = object()


def set_connection_manager(cm: "ConnectionManager") -> None:
    """Register the process-wide ConnectionManager singleton.  Called
    once during app startup (main.py) so background helpers can find
    the same instance the API routes use."""
    global _GLOBAL_CONN_MANAGER
    _GLOBAL_CONN_MANAGER = cm


def get_connection_manager() -> Optional["ConnectionManager"]:
    """Return the process-wide ConnectionManager singleton, or None if
    not initialized.  Callers must handle the None case (typical in
    test harnesses where main.py boot doesn't run)."""
    return _GLOBAL_CONN_MANAGER


def _is_sql_connector_type(connection_type: str) -> bool:
    """True for Trino/Starburst/Snowflake/Databricks/Oracle/Athena-style
    connections — the ones you BROWSE (catalog → schema → table) rather than
    register files against.

    Imported lazily so ``core.connection_manager`` keeps working in the test
    harnesses that never import the connector package; an import failure means
    "no SQL connectors available", which routes callers down the pre-existing
    local/S3 branches exactly as before.
    """
    try:
        from core.connectors import SQL_CONNECTOR_TYPES
    except Exception:  # noqa: BLE001 - optional dependency
        return False
    return str(connection_type or "").lower() in SQL_CONNECTOR_TYPES


def _split_qualified_table(
    table_path: str, *, default_catalog: str = "", default_schema: str = "",
) -> Tuple[str, str, str]:
    """Split ``catalog.schema.table`` into its three parts.

    Accepts the partly-qualified spellings the UI produces, filling any missing
    leading part from the connection's configured defaults:

        ``hive.sales.orders`` → ("hive", "sales", "orders")
        ``sales.orders``      → (default_catalog, "sales", "orders")
        ``orders``            → (default_catalog, default_schema, "orders")

    Extra leading segments are folded into the catalog so a catalog containing a
    dot cannot silently shift the table name.  Double quotes are stripped, and
    a ``__registered__:`` prefix (the file-connection spelling) is tolerated.
    """
    raw = str(table_path or "").strip()
    if raw.startswith("__registered__:"):
        raw = raw[len("__registered__:"):]
    parts = [p.strip().strip('"') for p in raw.split(".") if p.strip().strip('"')]
    if not parts:
        return default_catalog, default_schema, ""
    if len(parts) == 1:
        return default_catalog, default_schema, parts[0]
    if len(parts) == 2:
        return default_catalog, parts[0], parts[1]
    return ".".join(parts[:-2]), parts[-2], parts[-1]


#: Connection types whose engine has NO catalog level: a table is addressed
#: as ``schema.table`` and nothing longer is a valid identifier chain.
#:
#: Oracle is the proven member (2026-09-15, live against 23-free):
#: ``"OTG"."OTG"."QS_SPARK_DEMO"`` is ORA-03048.  Its connector's
#: ``list_catalogs()`` nevertheless answers with CURRENT_SCHEMA, because
#: the browse route (``/api/connections/{id}/tables``) and the table picker
#: are shaped catalog -> schema -> table for every SQL source -- so the
#: product itself MINTS ``OTG.OTG.QS_SPARK_DEMO`` for an Oracle table, and
#: every Oracle dataset picked from the UI carries that pseudo-catalog.
#: Declared here, next to the splitter, because the splitter is the only
#: thing that can act on it.  Widen deliberately, per engine, with a live
#: proof; MySQL is the same shape but is not in this set until someone
#: runs it.
NO_CATALOG_LEVEL_TYPES = frozenset({"oracle"})


class TableAddressNotRenderable(ValueError):
    """The table name cannot be rendered as an address on this engine.

    A ValueError so the dataset routes' existing refusal branch maps it to
    a 422 that carries the reason; raised at ADMISSION (dataset create /
    update) and again at EXECUTE by the same function, so the two cannot
    disagree.
    """


def qualified_table_sql(
    table_path: str, connection_type: str, *,
    default_catalog: str = "", default_schema: str = "",
    dialect: Optional[str] = None, always_quote: bool = False,
) -> str:
    """THE way to render a possibly-dotted table name as SQL.

    ``resolve_table_address`` answers *which* (catalog, schema, table) a name
    means.  This answers *how it is written*, and the two belong together:
    every caller that resolved an address then had to quote it, and the ones
    that hand-rolled the second half all made the SAME mistake --

        FROM "tpch.tiny.nation"      MISSING_SCHEMA_NAME     (one identifier)
        FROM "tpch"."tiny"."nation"  25 rows                 (three)

    A dotted path quoted as ONE identifier names a table whose literal name
    contains dots.  No engine has such a table, so it does not resolve --
    which is the GOOD case.  The bad case is ``mv_manager``, where the same
    mistake let a materialized view materialise the WRONG DATA and report
    ``ready`` (FB-12, measured 2026-09-17: a filter matching 2.9M rows wrote
    0 rows, ``last_error=None``).

    Measured on the live stack 2026-09-17, this one mistake sat behind three
    findings filed separately -- the data-quality subsystem could not check
    ANY qualified table (and on Trino every table is qualified), the MV above,
    and NL-to-SQL emitting unqualified SQL at 0.82 confidence.  One bug, in
    three copies of the half that was never shared.

    ``dialect`` is a sqlglot dialect; ``None`` resolves it from
    ``connection_type``, which is what a caller executing DIRECTLY on that
    connection wants.  ``FederationEngine`` passes ``"duckdb"`` explicitly
    because its builders emit an INTERMEDIATE dialect converted at one later
    chokepoint (``_transpile_for_connector``) -- see ``_quote_ident``'s
    docstring for why that is correct rather than an oversight.

    Raises :class:`TableAddressNotRenderable` for a name this engine cannot
    address -- the same refusal, from the same resolver, that the dataset
    routes already map to a 422 carrying the reason.
    """
    catalog, schema, table = resolve_table_address(
        table_path, connection_type,
        default_catalog=default_catalog, default_schema=default_schema)
    if not table:
        raise TableAddressNotRenderable(
            f"Table name {table_path!r} resolved to no table part on a "
            f"{connection_type!r} connection, so there is nothing to select "
            f"FROM. Refusing rather than emitting SQL that names nothing.")
    from core.sql_filter_wrapper import (
        dialect_for_connection_type, quote_identifier_for_dialect,
    )
    _dialect = dialect or dialect_for_connection_type(connection_type)
    return ".".join(
        quote_identifier_for_dialect(p, _dialect, always_quote=always_quote)
        for p in (catalog, schema, table) if p
    )


def resolve_table_address(
    table_path: str, connection_type: str, *,
    default_catalog: str = "", default_schema: str = "",
) -> Tuple[str, str, str]:
    """THE answer to "which (catalog, schema, table) is this name" for a
    SQL connection -- the address the schema read looks up AND the address
    the query renders.

    Until 2026-09-15 the two paths answered differently for Oracle.  Both
    called ``_split_qualified_table`` and got ``("OTG", "OTG", "T")``; the
    schema read then handed all three to ``OracleConnector.list_columns``,
    which ignores the catalog argument, so auto-detect SUCCEEDED -- while
    the federation builder rendered every non-empty part and Oracle refused
    ``"OTG"."OTG"."T"`` (ORA-03048).  A dataset that detected its columns
    could not run.  A decision made twice is a bug.

    On an engine without a catalog level the leading segment of a 3-part
    name is the pseudo-catalog the browse route minted, and it is dropped
    from the ADDRESS (the name the dataset stores is untouched).  Anything
    longer than 3 parts has no rendering on such an engine and is REFUSED
    with the reason, never folded or truncated -- a mangled name would
    read a different table or fail at run time, both silently worse than a
    refusal at save.  Engines with a catalog level keep the historical
    splitter behaviour exactly (extra leading segments fold into the
    catalog; see ``_split_qualified_table``).
    """
    ct = str(connection_type or "").strip().lower()
    if ct not in NO_CATALOG_LEVEL_TYPES:
        return _split_qualified_table(
            table_path, default_catalog=default_catalog,
            default_schema=default_schema)

    raw = str(table_path or "").strip()
    if raw.startswith("__registered__:"):
        raw = raw[len("__registered__:"):]
    parts = [p.strip().strip('"') for p in raw.split(".")
             if p.strip().strip('"')]
    if not parts:
        raise TableAddressNotRenderable(
            f"Table name {table_path!r} is empty -- nothing to address on "
            f"the {ct} connection.")
    if len(parts) > 3:
        raise TableAddressNotRenderable(
            f"Table name {table_path!r} has {len(parts)} dot-separated parts; "
            f"{ct} addresses a table as SCHEMA.TABLE (a leading catalog "
            f"segment is tolerated because the catalog browser adds one) and "
            f"has no rendering for a {len(parts)}-part name. Use "
            f"'{parts[-2]}.{parts[-1]}'.")
    if len(parts) == 3:
        # The pseudo-catalog.  Named in the log so a reader of the SQL can
        # see where the first segment went.
        logging.getLogger(__name__).info(
            "%s has no catalog level: address %r resolves to %s.%s (the "
            "leading %r is the browse route's pseudo-catalog)",
            ct, table_path, parts[1], parts[2], parts[0])
        return "", parts[1], parts[2]
    if len(parts) == 2:
        return "", parts[0], parts[1]
    return "", default_schema, parts[0]


def _normalize_path(path_str: str) -> Path:
    """
    Normalize a path string to a Path object.

    - **Windows host**: returns Path(path_str) as-is.
    - **Linux / Docker / WSL**: converts Windows-style paths:
        C:\\foo\\bar  →  /mnt/c/foo/bar   (WSL convention)
      UNC paths (\\\\server\\share) → /mnt/shared/server/share
      Native Linux paths (/app/data/...) pass through unchanged.

    In Docker, users should use the container-internal path (e.g. /app/data/parquet)
    in connection configs, matching the volume mount in docker run / docker-compose.
    """
    if sys.platform == "win32":
        return Path(path_str)

    # ── UNC / shared paths: \\server\share\... or //server/share/... ──
    unc_match = re.match(r"^(?:\\\\|//)([\w.\-]+)[/\\]([\w.\-]+)(?:[/\\](.*))?$", path_str)
    if unc_match:
        server = unc_match.group(1)
        share = unc_match.group(2)
        rest = (unc_match.group(3) or "").replace("\\", "/")
        # Try common mount conventions in order
        candidates = [
            Path(f"/mnt/shared/{server}/{share}"),   # explicit shared mount
            Path(f"/mnt/{share}"),                     # direct CIFS mount
        ]
        for base in candidates:
            full = base / rest if rest else base
            if full.exists():
                return full
        # Return first candidate even if not found (clearest error message)
        return (candidates[0] / rest) if rest else candidates[0]

    # ── Windows drive paths: C:\... or C:/... ──
    win_abs = re.match(r"^([a-zA-Z]):[/\\](.*)", path_str)
    if win_abs:
        drive = win_abs.group(1).lower()
        rest = win_abs.group(2).replace("\\", "/")
        return Path(f"/mnt/{drive}/{rest}")

    # ── Already a Linux/native path ──
    return Path(path_str)


def _config_fingerprint(config) -> str:
    """A stable digest of a connection config, for cache validity only."""
    import hashlib
    import json
    try:
        raw = json.dumps(config or {}, sort_keys=True, default=str)
    except Exception:
        raw = repr(config)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class ConnectionManager:
    """
    Manages data source connections and provides file operations
    per connection. Caches S3 handler instances to avoid recreating
    boto3 sessions on every request.
    """

    def __init__(self, db_manager: DatabaseManager):
        """
        Initialize the connection manager.

        Args:
            db_manager: DatabaseManager instance for connection CRUD
        """
        self.db = db_manager
        # Cache: connection_id → (handler, created_at_monotonic)
        self._s3_handlers: Dict[int, Tuple[S3StorageHandler, float]] = {}
        self._s3_lock = threading.Lock()  # guards check-then-set on _s3_handlers
        # 2026-09-26 -- the config each cached handler was BUILT from, as a
        # fingerprint.  The cache was keyed on the connection id alone, so a
        # handler outlived the config it was built from until the TTL or an
        # epoch bump noticed: a connection whose id was reused (SQLite reuses
        # ids) or whose credentials changed on a pod that had not yet seen
        # the epoch served the OLD endpoint/credentials.  A caller always
        # hands its current config in, so a mismatch is decidable here.
        self._s3_handler_fps: Dict[int, str] = {}
        # 2026-08-02 — cross-pod invalidation (see invalidate_cache /
        # _is_handler_expired).  ``_coherence_bus`` None → module singleton
        # bus (tests inject per-"pod" buses).  ``_connections_epoch_seen``
        # is the last epoch token observed; ``_epoch_barrier`` is the
        # monotonic instant a PEER pod's connection-config change was
        # noticed — handlers built before it are expired.
        self._coherence_bus = None
        self._connections_epoch_seen: Any = _EPOCH_UNSET
        self._epoch_barrier: Optional[float] = None

    def test_connection(self, connection_type: str, config: dict) -> dict:
        """
        Test a connection configuration without saving it.

        Args:
            connection_type: 's3', 'local', or 'upload'
            config: Connection configuration dictionary

        Returns:
            Dict with 'success' (bool) and 'message' (str)
        """
        if connection_type == "s3":
            return self._test_s3_connection(config)
        elif connection_type in ("local", "upload"):
            return self._test_local_connection(config)
        else:
            return {
                "success": False,
                "message": f"Unsupported connection type: {connection_type}"
            }

    def _test_s3_connection(self, config: dict) -> dict:
        """Test an S3 connection configuration.

        Injects AWS portal credentials when portal auth is enabled and the
        connection does not already have explicit keys.
        """
        try:
            # Inject portal creds if available (auto-refresh expired tokens)
            test_cfg = config
            auth_mode = (config.get("auth_mode") or "").lower()
            if auth_mode == "portal":
                try:
                    from core.credential_manager import get_credential_manager
                    from core.aws_portal_auth import _current_portal_user
                    cm = get_credential_manager()
                    portal_user = _current_portal_user.get("")
                    if cm:
                        test_cfg = cm.resolve_s3_credentials(config, portal_user)
                except Exception as exc:
                    logger.debug("Portal credential resolution for test failed: %s", exc)
            else:
                try:
                    from core.aws_portal_auth import inject_portal_creds, _current_portal_user
                    portal_user = _current_portal_user.get("")
                    if portal_user:
                        test_cfg = inject_portal_creds(config, portal_user)
                except Exception:
                    pass  # portal not available — use original config

            handler = S3StorageHandler(build_s3_config(test_cfg))
            result = handler.test_connection()

            # 2026-06-16 — surface the RESOLVED endpoint so the operator
            # can see whether the test actually routed through their VPC
            # endpoint or fell back to the public AWS S3 endpoint.
            # Multiple report tickets came in saying "it tries to connect
            # like https://bucket.s3.region.amazonaws.com" — that's what
            # boto3 does when endpoint_url is empty.  Showing the
            # endpoint_used field on both success and failure makes this
            # immediately visible in the Test result Alert.
            endpoint_used = handler.config.endpoint_url or "standard AWS S3"

            if result.get("connected"):
                return {
                    "success": True,
                    "message": f"Successfully connected to S3 bucket '{config['bucket_name']}'",
                    "endpoint_used": endpoint_used,
                }
            else:
                # 2026-06-16 — forward the [DIAG] block from s3_storage so the
                # API caller / UI can show the same multi-line diagnostic that
                # the server log carries.  Without this, the diagnostic was
                # built but silently dropped at this stripping wrapper.
                response = {
                    "success": False,
                    "message": f"Failed to connect to S3: {result.get('error', 'Unknown error')}",
                    "endpoint_used": endpoint_used,
                }
                if result.get("diagnostic"):
                    response["diagnostic"] = result["diagnostic"]
                return response
        except Exception as e:
            logger.error(f"S3 connection test failed: {e}", exc_info=True)
            from core.error_sanitizer import explain_failure
            return {
                "success": False,
                "message": explain_failure(e, subject="S3 connection test",
                                           config=config),
            }

    def _test_local_connection(self, config: dict) -> dict:
        """Test a local filesystem connection configuration."""
        try:
            base_path = config.get("base_path")
            if not base_path:
                return {
                    "success": False,
                    "message": "Missing 'base_path' in configuration"
                }

            path = _normalize_path(base_path)
            if not path.exists():
                hint = ""
                if sys.platform != "win32" and re.match(r"^[a-zA-Z]:[/\\]", base_path):
                    hint = (
                        ". In Docker, use the container path (e.g. /app/data/parquet) "
                        "matching your volume mount, not the Windows host path"
                    )
                return {
                    "success": False,
                    "message": f"Path does not exist: {base_path} (resolved: {path}){hint}"
                }

            if not path.is_dir():
                return {
                    "success": False,
                    "message": f"Path is not a directory: {base_path}"
                }

            # Count files for a useful success message
            try:
                file_count = sum(1 for f in path.rglob("*.parquet"))
                extra = f" — {file_count} parquet file(s) found" if file_count else " — no parquet files found"
            except Exception:
                extra = ""

            return {
                "success": True,
                "message": f"Successfully connected to local path '{path}'{extra}"
            }
        except Exception as e:
            logger.error(f"Local connection test failed: {e}", exc_info=True)
            from core.error_sanitizer import explain_failure
            return {
                "success": False,
                "message": explain_failure(e, subject="Local connection test",
                                           config=config),
            }

    # ── S3 handler cache eviction policy ──────────────────────────────
    #
    # STRATEGIC SIMPLIFICATION (2026-06-16):
    #
    #   Every cached handler — regardless of auth mode — expires after
    #   ``handler_cache_ttl_seconds`` from core.config.s3 (default 60 s).
    #
    # Why this replaces the previous tiered logic + multi-worker
    # updated_at comparison + legacy-entry detection:
    #
    #   1. The old "keys / portal never expire" rule meant any cached
    #      handler from BEFORE a config change persisted indefinitely
    #      until invalidate_cache() fired.  In multi-pod / multi-worker
    #      setups, invalidate_cache() only evicts ONE process's cache.
    #      Other workers kept serving stale config (no VPC URL, no
    #      auto-path-style, etc.).
    #
    #   2. The DB-updated_at comparison + _built_wall_clock attribute
    #      bridge fixes were fix-on-fix territory.  Removed.
    #
    #   3. The data_grid streaming pool (data_grid_api._s3_pool) already
    #      has a TTL.  Single coherent rule across both caches.
    #
    # Trade-off: every connection rebuilds the handler ~once per minute
    # under steady load.  boto3 client construction is ~50-200 ms; well
    # below any S3 round-trip.  Bursty queries within the TTL window
    # still hit the cache.
    #
    # OPERATOR TUNABLE: ``core.config.s3.handler_cache_ttl_seconds``
    # via PUT /api/admin/s3/config.  Default 60 s.  Set higher for
    # high-throughput envs where the rebuild cost matters; the
    # 60 s default is safe for almost all setups.
    _HANDLER_CACHE_TTL_FALLBACK = 60

    def _is_handler_expired(self, connection_id: int,
                              connection_updated_at: Optional[Any] = None) -> bool:
        """Single rule for non-portal: TTL.  Portal handlers never expire
        via TTL because their RefreshableCredentials handle STS refresh
        internally and forcing rebuild every minute triggers an
        unnecessary portal HTTP call (5-15 s through corp proxy) AND
        may yield a freshly-scoped STS session that AWS-side IAM
        policies treat differently.

        ``connection_updated_at`` is accepted for API compatibility with
        existing callers but ignored — the TTL handles staleness for
        the auth modes it applies to.
        """
        del connection_updated_at  # unused — TTL-only policy now
        entry = self._s3_handlers.get(connection_id)
        if not entry:
            return True
        handler, created_at = entry

        # 2026-08-02 — cross-pod config-change barrier.  An admin editing a
        # connection on ANOTHER pod bumps the "connections" epoch; every
        # handler built BEFORE we noticed the bump was built from config
        # that may no longer exist (old endpoint / old credentials) and is
        # expired immediately instead of silently serving the stale config
        # for the rest of its TTL.  Applies to portal handlers too — the
        # TTL exemption below protects them from ROUTINE rebuild churn,
        # but a config change invalidates the very config they were built
        # from.  Fail-open: bus/DB errors leave the TTL policy in charge.
        self._check_connections_epoch()
        if self._epoch_barrier is not None and created_at < self._epoch_barrier:
            return True

        # Portal handlers never expire from cache.  Restores the
        # pre-d02c5ce behaviour for this auth mode only.
        # NOTE: `is True` (not truthy) so MagicMock test handlers don't
        # auto-pass via attribute-creation magic.
        auth_mode = (handler.config.auth_mode or "").lower()
        if auth_mode == "portal" or getattr(handler, "_portal_origin", None) is True:
            return False

        try:
            from core.config import s3 as s3_cfg
            ttl = int(getattr(s3_cfg, "handler_cache_ttl_seconds",
                                self._HANDLER_CACHE_TTL_FALLBACK))
            if ttl <= 0:
                ttl = self._HANDLER_CACHE_TTL_FALLBACK
        except Exception:
            ttl = self._HANDLER_CACHE_TTL_FALLBACK
        return (time.monotonic() - created_at) > ttl

    def _check_connections_epoch(self) -> None:
        """2026-08-02 — poll-throttled (inside the bus, default 5 s) check
        whether a PEER pod announced a connection-config change.  On a
        token change, records a monotonic barrier; handlers created before
        it are treated as expired by ``_is_handler_expired``.  The pod that
        performed the invalidation itself self-acknowledges its token in
        ``invalidate_cache`` so its own surgical eviction is not widened.

        First-ever observation only records the baseline (a barrier there
        would nuke handlers on every pod boot); a bump that lands in that
        first-observation race window is still bounded by the pre-existing
        60 s handler TTL.  Fail-open on any bus/DB error."""
        try:
            bus = self._coherence_bus
            if bus is None:
                from core.cache_coherence import get_bus
                bus = get_bus()
            token = bus.current_token("connections")
        except Exception as exc:
            logger.debug("connection epoch check failed (fail-open, TTL "
                         "policy still applies): %s", exc)
            return
        seen = self._connections_epoch_seen
        if seen is _EPOCH_UNSET:
            self._connections_epoch_seen = token
            return
        if token is not None and token != seen:
            self._connections_epoch_seen = token
            self._epoch_barrier = time.monotonic()
            logger.info(
                "Connection config changed on a peer pod — cached S3 "
                "handlers built before this instant are expired and will "
                "rebuild with fresh config on next use")

    def invalidate_s3_handler(self, connection_id: int, reason: str = "",
                              _forget_account: bool = True) -> bool:
        """BF-278: drop the cached S3StorageHandler for this connection so
        the next caller builds a fresh one (with re-resolved credentials).

        Used when boto3 raises ``ExpiredToken`` mid-query — without this,
        the cached handler keeps serving stale STS credentials forever
        and every subsequent S3 call fails until something else evicts
        the entry.

        2026-10-30 -- "re-resolve credentials" was only half true for a
        connection whose keys come from a Vault System Account: the rebuilt
        handler asked the credential resolver, whose 15-minute memory / 24-hour
        disk cache handed back the SAME rejected keys.  The account is now
        FORGOTTEN too (``core/qs_credentials/freshness.py::forget`` -- memory
        dropped, disk distrusted, pooled connectors closed), so the rebuild
        reads Vault.  ``_forget_account=False`` is for ``forget`` itself,
        which calls here after it has already done that.

        Returns True if an entry was evicted, False if no entry existed.
        Thread-safe — takes the same lock as ``_get_s3_handler``.
        """
        with self._s3_lock:
            existed = connection_id in self._s3_handlers
            if existed:
                self._s3_handlers.pop(connection_id, None)
                logger.warning(
                    "S3 handler invalidated for connection %d (reason=%s) "
                    "— next call will re-resolve credentials",
                    connection_id, reason or "manual",
                )
        if _forget_account:
            try:
                conn = self.db.get_connection_raw(int(connection_id)) if self.db else None
                from core.qs_credentials import freshness as _fresh
                sa_ref = _fresh.account_ref((conn or {}).get("config") or {})
                if sa_ref is not None:
                    _fresh.forget(sa_ref, reason=f"S3 handler invalidated: {reason or 'manual'}")
            except Exception as exc:
                logger.debug("S3 handler invalidation: account forget skipped (%s)", exc)
        return existed


    def _get_s3_handler(self, connection_id: int, config: dict) -> S3StorageHandler:
        """
        Get or create a cached S3StorageHandler for the given connection.

        Uses a lock to prevent check-then-set races when multiple threads
        request the same connection simultaneously.

        2026-06-16 strategic simplification: every handler expires after
        ``_HANDLER_CACHE_TTL_SECONDS`` (default 60 s).  See the policy
        comment on ``_is_handler_expired``.  Stale config — whether from
        a per-worker invalidate or a cross-pod config change — self-clears
        within the TTL window.
        """
        _fp = _config_fingerprint(config)
        # 2026-11-05: a portal handler holds the keys of whoever asked, so it serves that person only
        if (config.get("auth_mode") or "").lower() == "portal":
            from core.aws_portal_auth import _current_portal_user
            _fp = f"{_fp}|{_current_portal_user.get('')}"

        def _usable() -> bool:
            return (connection_id in self._s3_handlers
                    and self._s3_handler_fps.get(connection_id) == _fp
                    and not self._is_handler_expired(connection_id))

        # Fast path
        if _usable():
            return self._s3_handlers[connection_id][0]

        with self._s3_lock:
            # Re-check inside lock
            if _usable():
                return self._s3_handlers[connection_id][0]

            # Evict an expired entry, or one built from a DIFFERENT config
            # (or written by a path that recorded no fingerprint -- unknown
            # is treated as different: one rebuild, never a stale client).
            if connection_id in self._s3_handlers:
                logger.info("S3 handler for connection %d expired or built from "
                            "a different config — recreating", connection_id)
                del self._s3_handlers[connection_id]

            # Inject portal credentials for auth_mode="portal"
            effective_config = config
            auth_mode = (config.get("auth_mode") or "").lower()
            if auth_mode == "portal":
                try:
                    from core.credential_manager import get_credential_manager
                    from core.aws_portal_auth import _current_portal_user
                    cm = get_credential_manager()
                    if cm:
                        portal_user = _current_portal_user.get("")
                        effective_config = cm.resolve_s3_credentials(config, portal_user)
                except Exception as exc:
                    logger.warning("Portal credential injection failed for conn %d: %s", connection_id, exc)

            handler = S3StorageHandler(build_s3_config(effective_config))
            if auth_mode == "portal":
                handler._portal_origin = True  # mark for TTL-based expiry
            self._s3_handlers[connection_id] = (handler, time.monotonic())
            self._s3_handler_fps[connection_id] = _fp
            logger.info(
                "S3 handler built for connection=%d endpoint_url=%s "
                "auth_mode=%s",
                connection_id,
                handler.config.endpoint_url or "(none — public AWS S3)",
                handler.config.auth_mode or "keys",
            )
        return self._s3_handlers[connection_id][0]

    def list_files(self, connection_id: int, folder: str = "") -> list:
        """
        List parquet files from the specified connection.

        Args:
            connection_id: Database ID of the connection
            folder: Optional subfolder/prefix to filter files

        Returns:
            List of file information dictionaries

        Raises:
            ValueError: If connection is not found
        """
        # Use get_connection_raw so S3 credentials are decrypted — get_connection()
        # returns masked values (e.g. aws_secret_access_key="***") which cause 403s.
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            # Apply root_prefix from connection config to scope browsing
            root_prefix = (conn["config"].get("root_prefix") or "").strip().strip("/")
            if root_prefix:
                effective = f"{root_prefix}/{folder}" if folder else f"{root_prefix}/"
            else:
                effective = folder
            return handler.list_parquet_files(folder_path=effective)
        else:  # local or upload
            return self._list_local_files(conn["config"], folder)

    def _list_local_files(self, config: dict, folder: str = "") -> list:
        """
        List queryable files in a local directory.

        Args:
            config: Local connection configuration with 'base_path'
            folder: Optional subfolder relative to base_path

        Returns:
            List of file information dictionaries
        """
        base = _normalize_path(config["base_path"]).resolve()
        search_path = base / folder if folder else base
        search_path = search_path.resolve()

        # Prevent path traversal — search_path must stay within base
        if not str(search_path).startswith(str(base)):
            logger.warning("Path traversal blocked: %s escapes %s", search_path, base)
            return []

        if not search_path.exists() or not search_path.is_dir():
            return []

        files = []
        for file_path in sorted(search_path.rglob("*")):
            if file_path.suffix.lower() not in _SUPPORTED_EXTS:
                continue
            try:
                stat = file_path.stat()
                relative_path = file_path.relative_to(base)
                files.append({
                    "name": file_path.name,
                    "path": str(relative_path).replace("\\", "/"),
                    "size_bytes": stat.st_size,
                    "last_modified": stat.st_mtime,
                    "folder": str(relative_path.parent).replace("\\", "/") if relative_path.parent != Path(".") else "",
                })
            except OSError as e:
                logger.warning(f"Could not stat file {file_path}: {e}")
                continue

        logger.info(f"Found {len(files)} previewable files in local path '{search_path}'")
        return files

    def get_excel_sheets(self, connection_id: int, file_path: str) -> list:
        """Return worksheet names for an Excel file within a connection's directory.

        Args:
            connection_id: Database ID of the connection
            file_path: Relative path to the Excel file within the connection

        Returns:
            List of sheet name strings

        Raises:
            ValueError: If connection not found, file not Excel, path traversal, or file missing
        """
        import os as _os

        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        ext = _os.path.splitext(file_path)[1].lower()
        if ext not in (".xlsx", ".xls"):
            raise ValueError("Only Excel files (.xlsx, .xls) have worksheets")

        # Path traversal guard
        if ".." in file_path.replace("\\", "/").split("/"):
            raise ValueError("Invalid file path")

        conn_type = conn["connection_type"]
        if conn_type not in ("local", "upload"):
            raise ValueError("Excel sheet listing only supported for local/upload connections")

        base = _normalize_path(conn["config"]["base_path"]).resolve()
        full_path = (base / file_path).resolve()

        # Ensure resolved path stays within base directory
        if not str(full_path).startswith(str(base)):
            raise ValueError("Invalid file path")

        if not full_path.is_file():
            raise FileNotFoundError(f"File not found: {file_path}")

        import pandas as pd
        xls = pd.ExcelFile(str(full_path))
        sheets = xls.sheet_names
        xls.close()
        return sheets

    def get_schema(self, connection_id: int, file_path: str) -> dict:
        """
        Get schema information for a file within a connection.

        Args:
            connection_id: Database ID of the connection
            file_path: Path to the parquet file (S3 key or local relative path)

        Returns:
            Schema information dictionary

        Raises:
            ValueError: If connection is not found
        """
        # Use get_connection_raw for decrypted credentials (S3 auth requires real creds)
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            # Accept both full S3 URI (s3://bucket/key) and raw S3 key
            s3_key = file_path
            if s3_key.startswith("s3://"):
                s3_key = s3_key[5:].split("/", 1)[1] if "/" in s3_key[5:] else s3_key[5:]
            return handler.get_file_schema(s3_key)
        if _is_sql_connector_type(conn["connection_type"]):
            return self._get_sql_connector_schema(conn, file_path)
        # local
        return self._get_local_schema(conn["config"], file_path)

    def _get_sql_connector_schema(self, conn: dict, table_path: str) -> dict:
        """Schema for one table on a SQL connector (Trino/Starburst/Snowflake/…).

        2026-08-10.  This branch did not exist.  ``get_schema`` handled ``s3``
        and fell through to ``_get_local_schema`` for EVERYTHING else, which
        immediately does ``config["base_path"]`` — a key a Trino connection has
        never had.  So every schema read against a SQL connector raised, and
        because ``core.schema_reader.SchemaReader`` is the single chokepoint
        behind ``GET /api/datasets/connections/{id}/schema/{table}``, the report
        builder's "Set Up Data Source" step silently created a dataset with
        ZERO columns and the report then failed with "No valid columns
        selected".  (SchemaReader's own docstring already claimed this path
        supported "Snowflake, Trino, Databricks, Oracle" — it did not.)

        ``table_path`` may be fully qualified (``catalog.schema.table``), partly
        qualified (``schema.table``) or bare (``table``); anything missing is
        taken from the connection's configured ``catalog`` / ``schema``, which
        is the same defaulting rule ``/api/connections/{id}/tables`` uses.

        Returns the legacy schema dict shape every caller already expects.
        ``num_rows`` is deliberately None: counting rows on a fact table to
        render a column list would be an unbounded query against the source.
        """
        from core.connectors import get_connector

        cfg = conn.get("config") or {}
        # THE resolver -- the same call the federation builder makes when
        # it renders this table, so the address whose columns are read is
        # the address that is queried (2026-09-15: they differed on Oracle).
        catalog, schema, table = resolve_table_address(
            table_path, conn.get("connection_type", ""),
            default_catalog=cfg.get("catalog", "") or "",
            default_schema=cfg.get("schema", "") or "",
        )
        if not table:
            raise ValueError(f"Cannot determine table name from '{table_path}'")

        # 2026-09-16 POOLED — schema reads are the most frequent connector
        # use in the product.  Entered by hand because the existing finally
        # below already owns the release path.
        from core.connection_pool import get_pooled_connector
        _schema_cm = get_pooled_connector(
            conn.get("id"), conn["connection_type"], cfg, conn.get("name", ""),
        )
        connector = _schema_cm.__enter__()
        # 2026-08-13 -- this dict used to omit ``partition_columns``
        # entirely, and that one missing key is why "BQB doesn't show
        # partitions" on a Starburst table:
        #
        #   schema has no partition_columns
        #     -> datasets_api marks every column is_partition=False
        #     -> BQB's partition-value effect keeps only tables whose
        #        partCols is non-empty, so it matches NONE
        #     -> GET /connections/{id}/tables/{t}/partitions is never called
        #        -- and that endpoint ALREADY enumerates values via Trino's
        #        "<table>$partitions" metadata table with a SELECT DISTINCT
        #        fallback.  The enumeration was built and unreachable.
        #
        # OPERATOR DECLARATION IS AUTHORITATIVE.  Introspection is NOT
        # reliable on Starburst (operator, 2026-08-13: "we dont have
        # capabilties to detect partions columns from starbust rather than
        # asking users") -- TrinoConnector.detect_partitions parses
        # SHOW CREATE TABLE, which needs that grant and only says anything
        # for a partition-bearing catalog.  So the declared list on the
        # registered table (set via
        # ConnectionManager.update_registered_table_partition_columns) wins,
        # and detection is a best-effort fallback for connections that never
        # declared one.  A user who tells us the partition columns must
        # never be overridden by a probe that guessed differently.
        declared: list = []
        for _rt in (cfg.get("registered_tables") or []):
            if not isinstance(_rt, dict):
                continue
            _nm = str(_rt.get("name") or "").strip()
            if not _nm:
                continue
            if _nm == table_path or _nm == table or _nm.lower() == table_path.lower():
                declared = [
                    str(c).strip()
                    for c in (_rt.get("partition_columns") or [])
                    if str(c).strip()
                ]
                break

        partition_columns: list = list(declared)
        try:
            raw_cols = connector.list_columns(catalog, schema, table) or []
            # FAIL-OPEN: a connector without partition support, or one that
            # raises, yields [] and the schema read still succeeds -- a
            # column list must never fail because the partition probe did.
            if not partition_columns:
                try:
                    _parts = connector.detect_partitions(catalog, schema, table) or []
                    partition_columns = [
                        p for p in (
                            str(x.get("name") or x.get("column") or "").strip()
                            for x in _parts if isinstance(x, dict)
                        ) if p
                    ]
                except Exception:  # noqa: BLE001
                    logger.debug(
                        "detect_partitions unavailable for %s on %s -- "
                        "declare partition columns on the registered table "
                        "instead", table_path, conn.get("connection_type"),
                        exc_info=True,
                    )
        finally:
            try:
                # sys.exc_info() so a connector whose read RAISED is
                # discarded rather than released -- (None, None, None) would
                # hand a possibly broken session to the next caller.
                import sys as _sys
                _schema_cm.__exit__(*_sys.exc_info())
            except Exception:  # noqa: BLE001 - release must never mask the read
                logger.debug("Connector release failed after schema read", exc_info=True)

        columns = [
            {
                "name": c.get("name") or c.get("column") or "",
                "type": c.get("type") or c.get("data_type") or "unknown",
                "nullable": c.get("nullable", True),
            }
            for c in raw_cols
            if isinstance(c, dict)
        ]
        columns = [c for c in columns if c["name"]]
        if not columns:
            raise ValueError(
                f"No columns returned for '{table_path}' on "
                f"{conn['connection_type']} connection {conn.get('id')}"
            )
        return {
            "file": table_path,
            "columns": columns,
            # Same key the S3/hive path emits, so SchemaReader,
            # datasets_api._classify_schema_columns and the BQB/CQB pickers
            # need no special case for connectors.
            "partition_columns": partition_columns,
            "num_rows": None,
            "num_row_groups": None,
            "size_bytes": None,
            "catalog": catalog,
            "schema": schema,
            "table": table,
        }

    def _get_local_schema(self, config: dict, file_path: str) -> dict:
        """
        Get schema for a local file (.parquet, .csv, .txt) using DuckDB.

        DuckDB uses shared-read access on Windows, avoiding WinError 32
        ("The process cannot access the file because it is being used by
        another process") that PyArrow's exclusive-lock approach causes.
        """
        from core.file_formats import parse_sheet_from_path
        fp_clean, _sheet = parse_sheet_from_path(file_path)

        base = _normalize_path(config["base_path"]).resolve()
        full_path = (base / fp_clean).resolve()

        # Prevent path traversal — full_path must stay within base
        if not str(full_path).startswith(str(base)):
            raise ValueError(f"Path traversal blocked: {file_path}")

        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {fp_clean}")

        ext = full_path.suffix.lower()
        fp = str(full_path).replace("\\", "/")
        adapter = get_format_adapter(ext)

        from core.duckdb_factory import duckdb_connection
        with duckdb_connection() as con:
            adapter.setup_duckdb(con)
            cols_raw = con.execute(adapter.duckdb_describe_sql(fp, sheet=_sheet)).fetchall()
            row_count = con.execute(adapter.duckdb_count_sql(fp, sheet=_sheet)).fetchone()[0]

            columns = [
                {"name": col[0], "type": col[1], "nullable": True}
                for col in cols_raw
            ]

        return {
            "file": file_path,
            "columns": columns,
            "num_rows": row_count,
            "num_row_groups": None,
            "size_bytes": full_path.stat().st_size,
        }

    def invalidate_cache(self, connection_id: int):
        """
        Remove cached S3 handler when connection config changes.

        2026-08-02 — also announces the change fleet-wide on the
        "connections" coherence epoch (Postgres system_settings row) so
        PEER pods expire their handlers + connection-derived caches
        (schema/partition) instead of silently querying the OLD
        endpoint/credentials until their TTLs run out.  Best-effort: a
        bus/DB failure never breaks the local invalidation.

        Args:
            connection_id: Database ID of the connection to invalidate
        """
        with self._s3_lock:
            self._s3_handlers.pop(connection_id, None)
        logger.info(f"Invalidated cached handler for connection {connection_id}")
        try:
            bus = self._coherence_bus
            if bus is None:
                from core.cache_coherence import get_bus
                bus = get_bus()
            token = bus.bump("connections",
                             reason=f"connection_update:{connection_id}")
            if token is not None:
                # Self-acknowledge: we already evicted the right entry
                # locally — our own bump must not expire our OTHER handlers.
                self._connections_epoch_seen = token
        except Exception as exc:
            logger.debug("connection invalidation broadcast failed "
                         "(fail-open, peers converge via TTL): %s", exc)

    def get_cache_info(self) -> list:
        """Return info about cached S3 handlers for admin monitoring."""
        now = time.monotonic()
        info = []
        for conn_id, (handler, created_at) in self._s3_handlers.items():
            age = round(now - created_at, 1)
            auth_mode = (handler.config.auth_mode or "keys").lower()
            info.append({
                "connection_id": conn_id,
                "auth_mode": auth_mode,
                "age_seconds": age,
                "bucket": handler.config.bucket_name,
                "expired": self._is_handler_expired(conn_id),
            })
        return info

    # ── Registered Tables ─────────────────────────────────────────────

    def get_registered_tables(self, connection_id: int) -> list:
        """Return the registered_tables list from connection config."""
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        return conn.get("config", {}).get("registered_tables", [])

    def register_table(self, connection_id: int, table: dict) -> dict:
        """Add a registered table to the connection config.

        Args:
            table: {name: str, s3_prefix: str, format: str, description: str}

        Returns:
            The added table dict.
        """
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        config = conn["config"]
        tables = config.get("registered_tables", [])
        if any(t["name"] == table["name"] for t in tables):
            raise ValueError(f"Table '{table['name']}' already registered")
        if table.get("format") not in ("iceberg", "parquet", "csv"):
            raise ValueError(f"Invalid format: {table.get('format')}")
        tables.append(table)
        config["registered_tables"] = tables
        self.db.update_connection(connection_id, config=config)
        logger.info("Registered table '%s' for connection %d", table["name"], connection_id)
        return table

    def update_registered_table_partition_columns(
        self, connection_id: int, table_name: str, partition_columns: list
    ) -> dict:
        """Set partition_columns on an existing registered table.

        partition_columns: list of column name strings (e.g. ["business_close_date", "code"]).
        Replaces the existing list (caller is responsible for merging if needed).
        Returns the updated table dict.
        """
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        config = conn["config"]
        tables = config.get("registered_tables", [])
        for t in tables:
            if t["name"] == table_name:
                t["partition_columns"] = [c.strip() for c in partition_columns if c and c.strip()]
                config["registered_tables"] = tables
                self.db.update_connection(connection_id, config=config)
                logger.info(
                    "Updated partition_columns for table '%s' on connection %d: %s",
                    table_name, connection_id, t["partition_columns"],
                )
                return t
        raise ValueError(f"Table '{table_name}' not found in connection {connection_id}")

    def unregister_table(self, connection_id: int, table_name: str):
        """Remove a registered table by name."""
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        config = conn["config"]
        tables = config.get("registered_tables", [])
        config["registered_tables"] = [t for t in tables if t["name"] != table_name]
        self.db.update_connection(connection_id, config=config)
        logger.info("Unregistered table '%s' from connection %d", table_name, connection_id)
