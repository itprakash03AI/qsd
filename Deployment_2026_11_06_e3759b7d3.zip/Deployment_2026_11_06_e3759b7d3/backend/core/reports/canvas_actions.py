"""Canvas ACTIONS -- "Download detail" through a Published API (2026-10-30).

Plan: docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html section 5.  The
owner: on a Book ID (any column, bar or slice) click -> the detail data from
a configured Published API, given the business date / the report's chosen
parameters / the clicked row's values / the linked-tile filters / fixed
values; CSV; into the Download Centre; a note on the report with the file
name.

The canvas carries ``layout_config.canvas.actions``::

    [{id, kind: 'detail_download', label, view_slug,
      params: [{api_param, from: 'row'|'parameter'|'link'|'fixed',
                column_id?, parameter?, value?}],
      file_name?, on: [{tile_id, column_id?}]}]

``api_param`` is one of the API's own names: a parameter it declares
(``param_definitions``) or ``filter.<column>`` for a column it allows a
filter on (``allowed_filters``, sent as ``eq``).

The rules this module owns (the route, ``api/canvas_actions_api.py``, only
resolves and maps):

* ``actions_problems`` -- what is wrong with the canvas's actions, checked on
  save beside ``canvas_problems`` (one line there calls this);
* ``read_clicked_values`` -- the clicked row's values are READ from the run's
  STORED, row-secured result through the microcube.  The browser names the
  row (its key: the dimension values of the clicked cell); a key that is not
  in this user's result is refused, and every value sent is the stored one,
  never the browser's;
* ``build_sent`` / ``query_string`` -- the ordered values sent and the exact
  query string the API is called with (recorded on the run, so a direct call
  of the API with the same string is byte-identical: the Docker proof);
* ``file_name_for`` -- the file's name from its template;
* the run row (``report_canvas_action_runs``): the job AND its audit, the
  status words a person reads (preparing / ready / empty / failed / refused).

THE DETAIL POPUP (2026-10-31; docs/CANVAS_DETAIL_POPUP_2026_10_31.html).  The
owner: "if we clicked bookid n someone wants details ... show in popup n popup
can have all option to download ... either execute query or via published api
... both option should while configuring".  ONE action model, two roads, one
generic mapping -- additive, so a saved action with none of the new fields is
exactly what it was::

    {..., source?: 'published_api' (default) | 'query', dataset_id?,
     show?: 'download' (default) | 'popup',
     params: [{target | api_param, from, column_id?, parameter?, value?}]}

``target`` is what the value is given to: on the API road one of the API's
names (as ``api_param`` always was -- ``api_param`` stays readable as its
alias); on the query road a column of the dataset (``=`` for one value, ``IN``
for several) or ``where.<key>``, a condition inside the dataset's own query
(``core/source_filters.py``).  ``query_filters`` turns what is sent into the
engine's TYPED filters and source bindings -- never SQL text -- and refuses
in words anything it cannot place (a dropped filter would return MORE rows).
"""
from __future__ import annotations

import datetime as _dt
import re
import uuid
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote

ACTION_KINDS = ("detail_download",)
PARAM_SOURCES = ("row", "parameter", "link", "fixed")
#: a value the REPORT's own run gave the detail (2026-11-01: ``pass_parameters``) --
#: never a mapping entry an author writes; recorded in ``values_sent`` with its words
FROM_REPORT = "report"
#: where the detail comes from; the first is the default of a saved action
SOURCE_API = "published_api"
SOURCE_QUERY = "query"
SOURCES = (SOURCE_API, SOURCE_QUERY)
#: what a click does; ``download`` (the first) is the default of a saved action
SHOW_DOWNLOAD = "download"
SHOW_POPUP = "popup"
SHOWS = (SHOW_DOWNLOAD, SHOW_POPUP)
#: the formats a detail file is written in, and their file endings
FILE_FORMATS = {"csv": ".csv", "xlsx": ".xlsx", "parquet": ".parquet"}
FORMAT_WORDS = {"csv": "CSV", "xlsx": "Excel", "parquet": "Parquet"}
#: the query road's prefix for a condition inside the dataset's own query
WHERE_PREFIX = "where."
#: rows the popup reads (``business_reports.detail_popup_max_rows``)
DEFAULT_POPUP_MAX_ROWS = 10_000
#: a run row's kind: a file (the default) or a popup view
RUN_FILE = "file"
RUN_VIEW = "view"
MAX_ACTIONS = 20
MAX_PARAMS = 30
DEFAULT_FILE_NAME = "{report_code}_{value}_{business_date}.csv"
#: a run still "preparing" after this long died with its process (a pod
#: restart): it is answered as failed, in words, instead of spinning forever.
STALE_AFTER = _dt.timedelta(hours=3)

STATUS_PREPARING = "preparing"
STATUS_READY = "ready"
STATUS_EMPTY = "empty"
STATUS_FAILED = "failed"
STATUS_REFUSED = "refused"
#: a popup view that read its rows (0 rows is still shown: the popup says so)
STATUS_SHOWN = "shown"
TERMINAL = (STATUS_READY, STATUS_EMPTY, STATUS_FAILED, STATUS_REFUSED, STATUS_SHOWN)

_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_API_PARAM_RE = re.compile(r"^(filter\.)?[A-Za-z_][A-Za-z0-9_.]{0,127}$")
#: a query-road target: a column, or ``where.<key>`` (a key may carry ``#2``)
_QUERY_TARGET_RE = re.compile(r"^(where\.)?[A-Za-z_][A-Za-z0-9_.#$]{0,190}$")
_TOKEN_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_.]*)\}")
_UNSAFE_FILE_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]+')


class ActionRefused(Exception):
    """A click that cannot run: ``status`` is the HTTP answer, ``str()`` the
    plain sentence the person reads."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


# ── the canvas's actions, checked on save ───────────────────────────────────

def _int(v: Any) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def read_actions(canvas: Any) -> List[dict]:
    """The canvas's actions as stored (a missing / unreadable list = none)."""
    acts = canvas.get("actions") if isinstance(canvas, dict) else None
    return [a for a in acts if isinstance(a, dict)] if isinstance(acts, list) else []


def find_action(canvas: Any, action_id: str) -> Optional[dict]:
    for a in read_actions(canvas):
        if str(a.get("id") or "") == str(action_id):
            return a
    return None


def template_tokens(template: str) -> List[str]:
    return _TOKEN_RE.findall(template or "")


def target_of(p: Any) -> str:
    """What a mapping entry gives its value to: ``target``, else the saved
    actions' ``api_param`` (its alias)."""
    if not isinstance(p, dict):
        return ""
    t = p.get("target")
    if t is None or t == "":
        t = p.get("api_param")
    return "" if t is None else str(t)


def source_of(action: dict) -> str:
    """The action's road; a saved action without one calls a Published API."""
    return str(action.get("source") or SOURCE_API)


def pass_parameters_of(action: dict, report: dict) -> bool:
    """Does the detail ALSO take the report's own parameters and filters (the
    run's values, read server-side from the run's record)?  (rig 2026-11-01:
    the popup for a Book showed its WHOLE history while the report was on one
    quarter.)  The author's setting when written; else ON for a query on the
    report's OWN dataset (the same columns, so the scope carries over), OFF
    for another dataset or a Published API."""
    v = action.get("pass_parameters")
    if isinstance(v, bool):
        return v
    ds = _int(action.get("dataset_id"))
    return source_of(action) == SOURCE_QUERY and ds is not None and ds == _int((report or {}).get("dataset_id"))


def actions_problems(canvas: Any, *, cols: Dict[int, dict], selected: Iterable[int],
                     targets_for: Any = None) -> List[Dict[str, Optional[str]]]:
    """Every problem of the canvas's actions, in words (empty = fine).

    ``cols`` = the dataset's columns by id, ``selected`` = the report's
    column ids (an action reads only what the run returns).  ``targets_for``
    (optional, the save route passes it): ``targets_for(action)`` ->
    ``(names, problem)`` -- the names the action's source takes (an API's
    parameters and ``filter.<col>``; a dataset's columns and ``where.<key>``),
    or ``names=None`` with the sentence saying why the source cannot be used;
    ``(None, None)`` = not known here (not checked)."""
    out: List[Dict[str, Optional[str]]] = []
    if not isinstance(canvas, dict) or "actions" not in canvas or canvas.get("actions") is None:
        return out
    raw = canvas.get("actions")
    if not isinstance(raw, list):
        return [{"tile_id": None, "message": "The canvas actions must be a list."}]
    if len(raw) > MAX_ACTIONS:
        out.append({"tile_id": None, "message": f"A canvas can hold {MAX_ACTIONS} actions; this one has {len(raw)}."})
    sel = {i for i in (_int(x) for x in selected) if i is not None}
    tiles = {str(t.get("id")): t for t in (canvas.get("tiles") or []) if isinstance(t, dict)}
    seen: set = set()

    for a in raw:
        if not isinstance(a, dict):
            out.append({"tile_id": None, "message": "Every action must be an object."})
            continue
        name = str(a.get("label") or a.get("id") or "an action")

        def say(msg: str, tile_id: Optional[str] = None) -> None:
            out.append({"tile_id": tile_id, "message": f'Action "{name}": {msg}'})

        aid = a.get("id")
        if not isinstance(aid, str) or not _ID_RE.match(aid) or aid in seen:
            say("its id is missing or used twice.")
        seen.add(aid)
        if a.get("kind") not in ACTION_KINDS:
            say(f'"{a.get("kind")}" is not a kind of action.')
        if not str(a.get("label") or "").strip():
            say("give it a name people will see on the link.")
        elif len(str(a.get("label"))) > 120:
            say("its name is longer than 120 characters.")
        source = a.get("source") or SOURCE_API
        if source not in SOURCES:
            say(f'"{source}" is not a place the detail can come from: pick a Published API or a query on a dataset.')
        if a.get("show") is not None and a.get("show") not in SHOWS:
            say(f'"{a.get("show")}" is not something a click can do: show it in a popup, or download a file.')
        if a.get("pass_parameters") is not None and not isinstance(a.get("pass_parameters"), bool):
            say("'also apply the report's parameters' is on or off.")
        if source == SOURCE_QUERY:
            if _int(a.get("dataset_id")) is None:
                say("pick the dataset whose query it runs.")
        elif not isinstance(a.get("view_slug"), str) or not a["view_slug"].strip():
            say("pick the Published API it calls.")
        fname = a.get("file_name")
        if fname is not None:
            if not isinstance(fname, str) or not fname.strip():
                say("its file name is empty -- leave it out to use the default.")
            elif len(fname) > 200:
                say("its file name is longer than 200 characters.")
            else:
                known = {"report_code", "report_name", "value", "business_date", "label"}
                api_names = {target_of(p) for p in (a.get("params") or []) if isinstance(p, dict)}
                for tok in template_tokens(fname):
                    if tok not in known and tok not in api_names:
                        say(f'its file name uses {{{tok}}}, which is not something it knows. Use '
                            '{report_code}, {value}, {business_date}, {label} or one of the API names it sends.')
        params = a.get("params")
        if not isinstance(params, list):
            say("its values must be a list.")
            params = []
        if len(params) > MAX_PARAMS:
            say(f"it sends at most {MAX_PARAMS} values.")
        sent_names: set = set()
        names, why_not = (None, None)
        if targets_for is not None and source in SOURCES:
            try:
                names, why_not = targets_for(a)
            except Exception:                                # noqa: BLE001 -- unknown = not checked here
                names, why_not = None, None
            if why_not:
                say(why_not)
        on_query = source == SOURCE_QUERY
        name_re = _QUERY_TARGET_RE if on_query else _API_PARAM_RE
        for p in params:
            if not isinstance(p, dict):
                say("every value it sends must be an object.")
                continue
            ap = p.get("target") if p.get("target") not in (None, "") else p.get("api_param")
            if not isinstance(ap, str) or not name_re.match(ap):
                say(f'"{ap}" is not a column or a condition of the dataset.' if on_query
                    else f'"{ap}" is not one of the API\'s names.')
                continue
            if names is not None and ap not in names:
                pick = ", ".join(sorted(names)) or "none"
                say(f'it gives a value to "{ap}", which is not a column or a condition of the dataset. '
                    f'Pick one of: {pick}.' if on_query else
                    f'it gives a value to "{ap}", which the API does not take. Pick one of its names: {pick}.')
            if ap in sent_names:
                say(f"it sends {ap} twice.")
            sent_names.add(ap)
            src = p.get("from")
            if src not in PARAM_SOURCES:
                say(f'{ap}: "{src}" is not a place a value can come from.')
            elif src in ("row", "link"):
                cid = _int(p.get("column_id"))
                if cid is None or cid not in cols:
                    say(f"{ap}: it reads a column that is no longer in the data.")
                elif cid not in sel:
                    label = cols[cid].get("friendly_name") or cols[cid].get("physical_name")
                    say(f"{ap}: {label} is not one of the report's columns, so the run does not return it.")
            elif src == "parameter":
                if not str(p.get("parameter") or "").strip():
                    say(f"{ap}: pick the report parameter it takes.")
            elif src == "fixed":
                v = p.get("value")
                if v is None or (isinstance(v, str) and not v.strip()):
                    say(f"{ap}: give the fixed value.")
        if not any(isinstance(p, dict) and p.get("from") == "row" for p in params):
            say("it must send at least one value of the clicked row (e.g. the Book ID).")
        on = a.get("on")
        if not isinstance(on, list) or not on:
            say("pick at least one tile that shows the link.")
            on = []
        for place in on:
            if not isinstance(place, dict) or str(place.get("tile_id")) not in tiles:
                say("it is shown on a tile that is not on the canvas.")
                continue
            tile = tiles[str(place["tile_id"])]
            cid = place.get("column_id")
            if cid is not None:
                dims = row_field_ids(tile)
                if _int(cid) not in dims:
                    say("its link is on a column the tile does not show.", str(place["tile_id"]))
    return out


def row_field_ids(tile: Dict[str, Any]) -> List[Optional[int]]:
    """The fields a tile's ROWS are made of -- an outline's ``levels`` (its
    Book ID cells carry the link), else its ``dimensions``.  The browser's
    ``canvasActions.rowFieldIds`` is the same rule."""
    ids = tile.get("levels") if tile.get("kind") == "outline" else tile.get("dimensions")
    return [_int(d) for d in (ids or [])]


# ── the clicked row, read from the STORED result ─────────────────────────────

def _plain(v: Any) -> Any:
    """A stored value as the text / number the API is given."""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, _dt.datetime):
        return v.isoformat()
    if isinstance(v, _dt.date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return format(v, "f")
    return v


def read_clicked_values(artifact: Path, *, key: Dict[str, Any], wanted: Sequence[str]) -> Dict[str, Any]:
    """The values of ``wanted`` columns on the stored rows the clicked key
    names.

    ``key`` = {physical column: value} -- the clicked cell's dimension values,
    as the browser saw them.  They only IDENTIFY: the rows are found in the
    stored, row-secured result, and every value returned is the stored one.
    A key no row matches (a row this user's result does not hold) is refused;
    a wanted column that has several values on the matched rows is refused
    (the click does not name one value).  Synchronous -- call off the loop."""
    from core.reports import microcube as _mc

    if not key:
        raise ActionRefused(400, "The click did not say which row it was on.")
    cols = list(dict.fromkeys([*key.keys(), *wanted]))
    try:
        page = _mc.read_artifact_drill(
            artifact, dimensions=cols, measures=[],
            path_filters=[{"column": c, "value": v} for c, v in key.items()],
            page=1, page_size=2, artifact_grain=_mc.GRAIN_DETAIL)
    except _mc.ArtifactNotReady as exc:
        raise ActionRefused(409, str(exc)) from None
    except ValueError as exc:
        raise ActionRefused(400, f"This run does not have every column the action reads ({exc}). "
                                 "Run the report again.") from None
    rows = page.get("rows") or []
    if not rows:
        raise ActionRefused(404, "That row is not in your result of this report, so nothing was sent.")
    if int(page.get("total_rows") or 0) > 1:
        varied = [c for c in wanted if c not in key and len({repr(r.get(c)) for r in rows}) > 1]
        raise ActionRefused(400, "The clicked row has more than one value for "
                                 f"{', '.join(varied) or 'a column the action sends'}; "
                                 "show that column on the tile, or click a more detailed row.")
    return {c: rows[0].get(c) for c in cols}


def link_value_seen(artifact: Path, column: str, value: Any) -> bool:
    """Is ``value`` a value of ``column`` in the stored result (a linked
    chip the browser names must be one this user can see)?"""
    from core.reports import microcube as _mc
    try:
        page = _mc.read_artifact_drill(artifact, dimensions=[column], measures=[],
                                       path_filters=[{"column": column, "value": value}],
                                       page=1, page_size=1, artifact_grain=_mc.GRAIN_DETAIL)
    except (ValueError, _mc.ArtifactNotReady):
        return False
    return bool(page.get("rows"))


# ── what is sent ─────────────────────────────────────────────────────────────

def build_sent(action: dict, *, row_values: Dict[int, Any], parameter_values: Dict[str, Any],
               link_values: Dict[int, Any]) -> List[Dict[str, Any]]:
    """The ordered values the API is given: ``[{api_param, from, value}]``
    (``target`` in place of ``api_param`` when the entry names a ``target``,
    so a saved action's record stays exactly what it was).
    ``row_values`` / ``link_values`` are keyed by column id and already READ
    from the stored result; a parameter / link with no value is left out (the
    API decides whether it needs it, and says so)."""
    sent: List[Dict[str, Any]] = []
    for p in action.get("params") or []:
        if not isinstance(p, dict):
            continue
        src = p.get("from")
        key = "target" if p.get("target") not in (None, "") else "api_param"
        ap = str(p.get(key))
        if src == "row":
            v = row_values.get(_int(p.get("column_id")))
        elif src == "link":
            cid = _int(p.get("column_id"))
            if cid not in link_values:
                continue
            v = link_values[cid]
        elif src == "parameter":
            name = str(p.get("parameter") or "")
            if name not in parameter_values:
                continue
            v = parameter_values[name]
            if v is None or v == "" or v == []:
                continue
        elif src == "fixed":
            v = p.get("value")
        else:
            continue
        sent.append({key: ap, "from": src,
                     "value": [_plain(x) for x in v] if isinstance(v, (list, tuple)) else _plain(v)})
    return sent


def sent_target(s: Dict[str, Any]) -> str:
    """The name a recorded value was given to (either spelling)."""
    t = s.get("target")
    return str(t if t not in (None, "") else (s.get("api_param") or ""))


def query_string(sent: Sequence[Dict[str, Any]]) -> str:
    """The exact query string the API is called with.  A parameter goes in
    the bracketed form (``param[name]``: safe for a name that collides with
    one of the route's own, e.g. ``limit``); ``filter.<col>`` as ``eq``.  A
    list repeats the key (a multi-select parameter)."""
    parts: List[str] = []
    for s in sent:
        ap = sent_target(s)
        vals = s["value"] if isinstance(s["value"], list) else [s["value"]]
        for v in vals:
            text = "" if v is None else str(v)
            if ap.startswith("filter."):
                parts.append(f"{quote(ap, safe='.')}={quote('eq:' + text, safe=':')}")
            else:
                parts.append(f"{quote(f'param[{ap}]', safe='')}={quote(text, safe='')}")
    return "&".join(parts)


def query_filters(sent: Sequence[Dict[str, Any]], *, columns: Dict[str, dict],
                  conditions: Iterable[str]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """The query road: what is sent as the engine's TYPED inputs --
    ``(filters, source_bindings)``.

    A column target is a filter ``{column_id, operator: eq | in, value}``
    (the engine renders and type-checks the literal, and refuses a value the
    column cannot hold); ``where.<key>`` is a binding of the condition inside
    the dataset's own query (``core/source_filters.apply``: one value ``=``,
    several ``IN``).  Nothing is ever dropped: a target the dataset no longer
    has, or a value that is missing, REFUSES in words -- leaving a filter out
    would return MORE rows than the click asked for.  ``columns`` = the
    dataset's columns by physical name; ``conditions`` = its condition keys."""
    by_lower = {str(k).lower(): c for k, c in columns.items()}
    known = set(conditions or ())
    filters: List[Dict[str, Any]] = []
    bindings: List[Dict[str, Any]] = []
    for s in sent:
        target = sent_target(s)
        raw = s.get("value")
        vals = list(raw) if isinstance(raw, (list, tuple)) else [raw]
        col_for_blank = columns.get(target) or by_lower.get(target.lower())
        if (s.get("from") in ("row", "link") and len(vals) == 1 and vals[0] is None
                and col_for_blank and _int(col_for_blank.get("id")) is not None):
            # 2026-11-05: a blank is a value a row can hold: the rows that are blank, never no filter
            filters.append({"column_id": _int(col_for_blank["id"]), "operator": "is_null", "value": None})
            continue
        if not vals or any(v is None for v in vals):
            raise ActionRefused(422, f'There is no value for "{target}", so the detail cannot be narrowed '
                                     "to what was clicked. Nothing was run.")
        if target.startswith(WHERE_PREFIX):
            key = target[len(WHERE_PREFIX):]
            if key not in known:
                raise ActionRefused(422, f'The dataset\'s query no longer has the condition "{key}", so the '
                                         "detail cannot be narrowed by it. Nothing was run; ask the report's "
                                         "owner to fix the action.")
            bindings.append({"source_column": key, "value": vals if len(vals) > 1 else vals[0]})
            continue
        col = columns.get(target) or by_lower.get(target.lower())
        if not col or _int(col.get("id")) is None:
            raise ActionRefused(422, f'The dataset has no column "{target}" any more, so the detail cannot be '
                                     "narrowed by it. Nothing was run; ask the report's owner to fix the action.")
        if len(vals) > 1:
            filters.append({"column_id": _int(col["id"]), "operator": "in", "value": vals})
        else:
            filters.append({"column_id": _int(col["id"]), "operator": "eq", "value": vals[0]})
    return filters, bindings


_FROM_WORDS = {"row": "the clicked row", "parameter": "the report parameter",
               "link": "the linked filter", "fixed": "a fixed value", FROM_REPORT: "the report's own parameters"}
_OP_WORDS = {"eq": "=", "in": "in", "gte": "from", "lte": "to", "gt": ">", "lt": "<", "ne": "is not", "between": "between"}


def report_filter_words(flt: Dict[str, Any], label: str) -> str:
    """'Region in ASIA, EUROPE' / 'Trade date from 1998-05-01' -- one of the
    report's filters in words, for the popup's 'What was asked for'."""
    op = str(flt.get("operator") or "eq").lower()
    return f"{label} {_OP_WORDS.get(op, op)} {_value_words(flt.get('value'))}".strip()


def _value_words(v: Any) -> str:
    if isinstance(v, list):
        return ", ".join("" if x is None else str(x) for x in v)
    return "" if v is None else str(v)


def sent_words(action: dict, sent: Sequence[Dict[str, Any]], cols: Dict[int, dict]) -> Dict[str, List[dict]]:
    """What was sent, in plain words, for the popup: ``{sent: [{target,
    value, from, where, words}], not_sent: [{target, words}]}`` -- each value
    and the place it came from ("Book = BK-1, from the clicked row's Book")."""
    by_target = {target_of(p): p for p in action.get("params") or [] if isinstance(p, dict)}
    out: List[dict] = []
    not_sent: List[dict] = []
    for s in sent:
        t = sent_target(s)
        src = s.get("from")
        if src == FROM_REPORT:
            # the report's own scope: its words were written when it was applied (or not)
            (not_sent if s.get("skipped") else out).append(
                {"target": t, "value": s.get("value"), "from": src, "where": _FROM_WORDS[FROM_REPORT],
                 "words": str(s.get("words") or "")})
            continue
        p = by_target.get(t) or {}
        where = _FROM_WORDS.get(src, "")
        c = cols.get(_int(p.get("column_id"))) if src in ("row", "link") else None
        if c:
            label = c.get("friendly_name") or c.get("physical_name")
            where = f"the clicked row's {label}" if src == "row" else f"the linked filter on {label}"
        elif src == "parameter":
            where = f"the report parameter {p.get('parameter')}"
        out.append({"target": t, "value": s.get("value"), "from": src, "where": where,
                    "words": f"{t} = {_value_words(s.get('value'))} (from {where})"})
    sent_names = {sent_target(s) for s in sent}
    for t, p in by_target.items():
        if t in sent_names:
            continue
        why = (f"the report parameter {p.get('parameter')} has no value (All)" if p.get("from") == "parameter"
               else "no linked filter is set on that column" if p.get("from") == "link" else "it has no value")
        not_sent.append({"target": t, "words": f"{t}: not sent -- {why}"})
    return {"sent": out, "not_sent": not_sent}


def popup_max_rows() -> int:
    """The rows the popup reads (a CAP: it throttles what is shown and says
    so; the downloads hold every row)."""
    try:
        from core import config
        n = int(config.get("business_reports", "detail_popup_max_rows", DEFAULT_POPUP_MAX_ROWS))
    except Exception:                                        # noqa: BLE001 -- the default stands
        n = DEFAULT_POPUP_MAX_ROWS
    return max(1, n)


def view_words(*, shown: int, total: Optional[int], capped: bool) -> str:
    """The popup's row sentence.  ``shown`` = the rows the popup reads (at
    most the cap), ``total`` = the detail's true total when it is known
    cheaply (``None`` = not counted), ``capped`` = there are more than the
    cap.  A cap says so; it never reads as the whole."""
    def rows(n: int) -> str:
        return f"{n:,} row" + ("" if n == 1 else "s")
    if capped:
        if total is not None:
            return f"Showing the first {rows(shown)} of {total:,}. A download gets all {total:,}."
        return (f"Showing the first {rows(shown)}; there are more than {shown:,}. "
                "A download gets all of them.")
    if shown <= 0:
        return "No rows for these values."
    return f"{rows(shown)}."


def file_name_for(template: Optional[str], *, report_code: str, report_name: str, value: Any,
                  business_date: Optional[str], label: str, sent: Sequence[Dict[str, Any]],
                  ext: str = ".csv") -> str:
    """The CSV's name: the template's tokens filled, unsafe characters
    removed, ``.csv`` at the end.  An empty token leaves no double ``__``.
    ``ext`` (2026-10-31): another format's ending in place of ``.csv``."""
    tpl = (template or "").strip() or DEFAULT_FILE_NAME
    by_param = {sent_target(s): s["value"] for s in sent}
    known = {"report_code": report_code, "report_name": report_name, "value": value,
             "business_date": business_date, "label": label}

    def fill(m: "re.Match[str]") -> str:
        tok = m.group(1)
        v = known[tok] if tok in known else by_param.get(tok)
        if isinstance(v, list):
            v = "-".join(str(x) for x in v)
        return "" if v is None else str(v)

    name = _TOKEN_RE.sub(fill, tpl)
    name = _UNSAFE_FILE_CHARS.sub("-", name).strip(" .")
    name = re.sub(r"_{2,}", "_", re.sub(r"_+(\.csv)$", r"\1", name, flags=re.I)).strip("_")
    if not name.lower().endswith(".csv"):
        name += ".csv"
    if name.lower() == ".csv":
        name = "detail.csv"
    name = name[:200]
    if ext and ext.lower() != ".csv" and name.lower().endswith(".csv"):
        name = name[:-4] + ext
    return name


def report_code_of(report: dict) -> str:
    """The report's short code: ``layout_config.report_code`` when the owner
    set one, else its name made safe for a file."""
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else {}
    code = str((lc or {}).get("report_code") or "").strip()
    if not code:
        code = re.sub(r"[^A-Za-z0-9-]+", "-", str(report.get("name") or "report")).strip("-")
    return code[:60] or "report"


def business_date_of(parameter_values: Dict[str, Any], subject_param: Optional[str]) -> Optional[str]:
    """The run's business date: the parameter the report's readiness names,
    else a parameter called ``business_date``; ``None`` when there is none."""
    names = [subject_param] if subject_param else []
    names += [k for k in parameter_values if k.lower() in ("business_date", "businessdate", "bus_date")]
    for n in names:
        v = parameter_values.get(n)
        if isinstance(v, (list, tuple)):
            v = v[0] if len(v) == 1 else None
        if v not in (None, ""):
            return str(_plain(v))[:10]
    return None


# ── the run: job + audit ─────────────────────────────────────────────────────

def _now() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def _aware(t: Optional[_dt.datetime]) -> Optional[_dt.datetime]:
    if t is None:
        return None
    return t.replace(tzinfo=_dt.timezone.utc) if t.tzinfo is None else t


def record_run(db, **fields) -> dict:
    from core.db.models import ReportCanvasActionRun
    fields.setdefault("id", str(uuid.uuid4()))
    fields.setdefault("status", STATUS_PREPARING)
    with db.get_session() as s:
        row = ReportCanvasActionRun(**fields)
        s.add(row)
        s.flush()
        out = row.to_dict()
        s.commit()
    return out


def finish_run(db, run_id: str, **fields) -> Optional[dict]:
    """The terminal write.  Only a PREPARING run moves (a run the stale rule
    already answered is not rewritten)."""
    from core.db.models import ReportCanvasActionRun
    with db.get_session() as s:
        row = s.query(ReportCanvasActionRun).filter(ReportCanvasActionRun.id == run_id).first()
        if row is None:
            return None
        if row.status == STATUS_PREPARING:
            for k, v in fields.items():
                setattr(row, k, v)
            row.finished_at = _now()
        out = row.to_dict()
        s.commit()
    return out


def get_run(db, run_id: str) -> Optional[dict]:
    from core.db.models import ReportCanvasActionRun
    with db.get_session(read_only=True) as s:
        row = s.query(ReportCanvasActionRun).filter(ReportCanvasActionRun.id == run_id).first()
        return row.to_dict() if row else None


def view_result_path(db, run_id: str) -> Optional[str]:
    """A popup view's stored detail on the server's disk (never sent to a
    browser: ``to_dict`` leaves it out)."""
    from core.db.models import ReportCanvasActionRun
    with db.get_session(read_only=True) as s:
        row = s.query(ReportCanvasActionRun).filter(ReportCanvasActionRun.id == run_id).first()
        return row.result_path if row is not None else None


def list_runs(db, report_id: int, *, username: Optional[str] = None, limit: int = 50) -> List[dict]:
    from core.db.models import ReportCanvasActionRun
    with db.get_session(read_only=True) as s:
        q = s.query(ReportCanvasActionRun).filter(ReportCanvasActionRun.report_id == report_id)
        if username is not None:
            q = q.filter(ReportCanvasActionRun.username == username)
        rows = q.order_by(ReportCanvasActionRun.created_at.desc()).limit(max(1, min(500, limit))).all()
        return [r.to_dict() for r in rows]


def find_preparing(db, *, report_id: int, action_id: str, username: str, query: str) -> Optional[dict]:
    """The same person's same click still being prepared (a second click
    joins it rather than building the same file twice)."""
    from core.db.models import ReportCanvasActionRun
    since = _now() - STALE_AFTER
    with db.get_session(read_only=True) as s:
        rows = (s.query(ReportCanvasActionRun)
                .filter(ReportCanvasActionRun.report_id == report_id,
                        ReportCanvasActionRun.action_id == action_id,
                        ReportCanvasActionRun.username == username,
                        ReportCanvasActionRun.status == STATUS_PREPARING)
                .order_by(ReportCanvasActionRun.created_at.desc()).limit(5).all())
        for r in rows:
            if r.query_string == query and (_aware(r.created_at) or _now()) >= since:
                return r.to_dict()
    return None


def _size_words(n: Optional[int]) -> str:
    if n is None:
        return ""
    if n < 1024:
        return f"{n} bytes"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def public_run(run: dict, now: Optional[_dt.datetime] = None) -> dict:
    """The run as the report shows it: the status, the plain sentence, and
    for a ready file its name, rows, size and download id.  A run still
    preparing after ``STALE_AFTER`` is answered as failed (its process is
    gone), never as preparing forever."""
    out = dict(run)
    now = now or _now()
    created = None
    try:
        created = _aware(_dt.datetime.fromisoformat(run["created_at"])) if run.get("created_at") else None
    except ValueError:
        created = None
    if run.get("status") == STATUS_PREPARING and created is not None and now - created > STALE_AFTER:
        out["status"] = STATUS_FAILED
        out["message"] = ("The download stopped before it finished (the server was restarted). "
                          "Click the link again to start it again.")
    out["size_words"] = _size_words(run.get("file_size_bytes"))
    if out["status"] == STATUS_PREPARING and not out.get("message"):
        out["message"] = f"Preparing {run.get('label') or 'the detail'}…"
    # "ready" is only ever said of a file that exists in the Download Centre
    if out["status"] == STATUS_READY and not (run.get("download_id") and (run.get("row_count") or 0) > 0):
        out["status"] = STATUS_FAILED
        out["message"] = "The file was not kept, so there is nothing to download. Click the link again."
    return out


def ready_words(label: str, file_name: str, rows: int, size: int, total: Optional[int]) -> str:
    cut = (f" The API gives at most {rows:,} rows in one file; it has {total:,}, so this file holds the "
           f"first {rows:,}." if total is not None and total > rows else "")
    return f"{label} detail is ready — {file_name} · {rows:,} rows · {_size_words(size)}.{cut}"


def refusal_words(status: int, detail: Any, api_name: str) -> str:
    """The plain sentence for a refusal the published API answered with."""
    if isinstance(detail, dict):
        detail = detail.get("message") or detail.get("error") or ""
    detail = str(detail or "").strip()
    if status in (401, 403):
        return f"You do not have access to the API \"{api_name}\", so no file was made. Ask its owner for access."
    if status in (404, 410):
        return f"The API \"{api_name}\" is no longer available, so no file was made. Ask the report's owner to pick another."
    if status == 429:
        return "Too many downloads are running right now. Wait a minute and click again."
    if status == 503:
        return f"Downloads from the API \"{api_name}\" are switched off on this server. Ask an administrator."
    if status == 400:
        return f"The API \"{api_name}\" did not accept the values sent: {detail or 'no reason given'}."
    if status == 504:
        return f"The API \"{api_name}\" took too long to answer. Try again later."
    return f"The API \"{api_name}\" could not prepare the file ({status})."
