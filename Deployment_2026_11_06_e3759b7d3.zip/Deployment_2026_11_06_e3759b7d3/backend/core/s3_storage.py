"""
S3 Storage Handler
Manages S3 connections and file operations for Parquet files
"""

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError, NoCredentialsError
from typing import List, Dict, Any, Optional, Tuple, Union, Generator
from pathlib import Path
import logging
import re
import threading
from dataclasses import dataclass
import pyarrow.parquet as pq
import pyarrow as pa
from io import BytesIO
import tempfile
import os
import urllib3

logger = logging.getLogger(__name__)

# Default CA bundle — place tls_bundle.pem in the certs/ folder next to main.py
_DEFAULT_CA_BUNDLE = Path(__file__).resolve().parent.parent / "certs" / "tls_bundle.pem"

_SSL_HINT = (
    "SSL certificate verification failed. This usually means a corporate proxy is intercepting HTTPS, "
    "OR the VPCE cert chain isn't in the CA bundle DuckDB / boto3 is using.  "
    "To fix: (1) set SSL Verification to 'Enabled' and place your org's CA bundle at ANY of these "
    "auto-detected paths INSIDE THE POD: "
    "/usr/local/querystudioapi/certs/tls-ca-bundle.pem (the canonical path), "
    "/usr/local/querystudioapi/certs/tls_bundle.pem, "
    "backend/certs/tls_bundle.pem, "
    "backend/certs/tls-ca-bundle.pem, "
    "/etc/ssl/certs/tls-ca-bundle.pem  -- OR set QS_CA_BUNDLE_PATH env var to an explicit path; "
    "(2) OR set SSL Verification to 'Custom CA Bundle' and enter an explicit path that exists on the pod; "
    "(3) OR set SSL Verification to 'Disabled' as a quick workaround.  "
    "Note: when picking 'Custom CA Bundle', the path you enter must be the path INSIDE the container "
    "(mounted via k8s volume / ConfigMap / Secret), NOT your local-machine path."
)


def _is_ssl_error(exc: Exception) -> bool:
    """Return True if the exception (or its cause chain) is an SSL verification failure."""
    msg = str(exc).lower()
    return 'certificate' in msg or 'ssl' in msg or 'cert' in msg


def _classify_ip(ip: str) -> str:
    """RFC1918/CGNAT classifier — tells operator whether the IP is reachable
    only inside the VPC ('private') or via public internet ('public')."""
    if not ip or "." not in ip:
        return "unknown"
    parts = ip.split(".")
    if len(parts) != 4:
        return "unknown"
    try:
        a, b = int(parts[0]), int(parts[1])
    except ValueError:
        return "unknown"
    if a == 10:
        return "private"
    if a == 172 and 16 <= b <= 31:
        return "private"
    if a == 192 and b == 168:
        return "private"
    if a == 100 and 64 <= b <= 127:
        return "private (CGNAT)"
    if a == 169 and b == 254:
        return "link-local"
    if a == 127:
        return "loopback"
    return "public"


def _validate_bucket_name(bucket: str) -> str:
    """Apply AWS S3 DNS-compliant naming rules and return a human-readable
    issue list, or "ok" when the name passes.

    AWS rules (Virtual-Hosted Style):
      - 3-63 chars
      - lowercase letters, digits, hyphens, dots
      - must start + end with letter/digit
      - no underscores, no uppercase, no consecutive periods
      - not IP-formatted
    """
    issues = []
    if not bucket:
        return "empty bucket name"
    if len(bucket) < 3 or len(bucket) > 63:
        issues.append(f"length {len(bucket)} (must be 3-63)")
    bad_chars = set()
    for ch in bucket:
        if ch.isupper():
            bad_chars.add("UPPERCASE")
        elif ch == "_":
            bad_chars.add("underscore '_'")
        elif not (ch.isalnum() or ch in "-."):
            bad_chars.add(f"'{ch}'")
    if bad_chars:
        issues.append(f"invalid characters: {', '.join(sorted(bad_chars))}")
    if bucket[0] in "-." or bucket[-1] in "-.":
        issues.append("must start and end with letter/digit, not hyphen/dot")
    if ".." in bucket:
        issues.append("consecutive '..' not allowed")
    try:
        ip_parts = bucket.split(".")
        if len(ip_parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in ip_parts):
            issues.append("looks like an IP address (not allowed)")
    except Exception:
        pass
    return "ok" if not issues else "; ".join(issues)


def _diagnose_endpoint_failure(
    exc: Exception,
    *,
    bucket: str,
    configured_endpoint: str,
    configured_region: str,
    path_style: bool,
) -> str:
    """Produce a multi-line diagnostic explaining a TCP/DNS-layer S3
    connection failure.  Called when test_connection's catch-all branch
    fires — gives the operator everything needed to triage WITHOUT a
    second test pass.

    What it inspects:
      1. The exception chain — extract the actual url + underlying
         socket error (ConnectionRefused / Timeout / Name resolution).
      2. The bucket name — flag DNS-incompatible characters BEFORE
         blaming the network.
      3. DNS resolution for the host boto3 actually tried.
      4. Whether that IP is private (VPC) or public.
      5. Current proxy env vars (masked for creds).
      6. The configured endpoint_url and how boto3 likely composed
         the final URL.

    Each line is prefixed [DIAG] so a log scrape can pluck the block
    out cleanly.
    """
    import os as _os
    import socket as _socket
    from urllib.parse import urlparse as _urlparse

    lines = ["[DIAG] S3 connection failure breakdown:"]

    # ── 1. Exception chain ────────────────────────────────────────────
    chain = []
    _cur = exc
    _seen = set()
    while _cur is not None and id(_cur) not in _seen:
        _seen.add(id(_cur))
        chain.append(f"{type(_cur).__name__}: {str(_cur)[:200]}")
        _cur = getattr(_cur, "__cause__", None) or getattr(_cur, "__context__", None)
    lines.append("[DIAG] exception chain (innermost last):")
    for i, c in enumerate(chain[-4:]):    # cap at 4 levels so logs stay bounded
        lines.append(f"[DIAG]   {i+1}. {c}")

    # ── 2. URL boto3 actually tried ───────────────────────────────────
    failed_url = ""
    try:
        # botocore.exceptions.EndpointConnectionError exposes endpoint_url
        kw = getattr(exc, "kwargs", None)
        if isinstance(kw, dict):
            failed_url = kw.get("endpoint_url", "") or ""
    except Exception:
        pass
    if not failed_url:
        # Fallback: parse from the exception string
        s = str(exc)
        if 'endpoint URL: "' in s:
            try:
                failed_url = s.split('endpoint URL: "', 1)[1].split('"', 1)[0]
            except Exception:
                pass
    if failed_url:
        lines.append(f"[DIAG] failed URL: {failed_url}")
    else:
        lines.append("[DIAG] failed URL: <could not extract from exception>")

    # ── 3. Bucket name validation ─────────────────────────────────────
    bn_check = _validate_bucket_name(bucket)
    if bn_check == "ok":
        lines.append(f"[DIAG] bucket name '{bucket}' — DNS-compliant ✓")
    else:
        lines.append(
            f"[DIAG] bucket name '{bucket}' — INVALID: {bn_check}.  "
            f"AWS S3 requires DNS-compliant names: 3-63 chars, lowercase "
            f"letters/digits/hyphens/dots only.  Fix the bucket name in the "
            f"connection config and retry."
        )

    # ── 4. DNS resolution + IP classification ─────────────────────────
    host = ""
    try:
        if failed_url:
            host = _urlparse(failed_url).hostname or ""
    except Exception:
        pass
    if not host and bucket:
        # Reconstruct what boto3 would have used
        if configured_endpoint:
            _p = _urlparse(configured_endpoint)
            host = (f"{bucket}.{_p.hostname}" if _p.hostname and not path_style
                    else _p.hostname or "")
        else:
            host = f"{bucket}.s3.{configured_region}.amazonaws.com"
    if host:
        try:
            addrs = _socket.gethostbyname_ex(host)[2]
            if addrs:
                ip = addrs[0]
                klass = _classify_ip(ip)
                lines.append(
                    f"[DIAG] DNS: {host} -> {ip} ({klass}"
                    f"{', ' + str(len(addrs)) + ' addresses total' if len(addrs) > 1 else ''})"
                )
                if klass == "loopback":
                    lines.append(
                        "[DIAG] HOST-RESOLUTION HIJACKED: hostname resolves "
                        "to 127.x.x.x — DNS is returning localhost.  Check "
                        "/etc/hosts, dnsmasq, or split-horizon DNS config."
                    )
                elif klass == "public":
                    lines.append(
                        "[DIAG] DNS returned a PUBLIC IP — VPC private DNS "
                        "is NOT in effect for this hostname.  Pod must "
                        "either reach the public internet (proxy/NAT) or "
                        "enable private DNS on the VPC S3 endpoint."
                    )
                elif klass.startswith("private"):
                    lines.append(
                        "[DIAG] DNS returned a PRIVATE IP — traffic is "
                        "intended for the VPC endpoint.  If the connect "
                        "still refused, check the VPC endpoint's security "
                        "group allows port 443 from this pod's subnet/SG."
                    )
            else:
                lines.append(f"[DIAG] DNS: {host} resolved 0 addresses (lookup failed silently)")
        except _socket.gaierror as _ge:
            lines.append(
                f"[DIAG] DNS: {host} FAILED to resolve ({type(_ge).__name__}: {_ge}).  "
                f"Either the URL is malformed (check bucket name above) or "
                f"the pod's DNS resolver doesn't know this hostname (VPC "
                f"private DNS not enabled / wrong Route 53 zone)."
            )
        except Exception as _de:
            lines.append(f"[DIAG] DNS: {host} lookup error: {type(_de).__name__}: {_de}")
    else:
        lines.append("[DIAG] DNS: could not determine target hostname (failed URL missing)")

    # ── 5. Proxy environment ──────────────────────────────────────────
    proxy_present = False
    for key in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"):
        v = _os.environ.get(key, "")
        if not v:
            continue
        proxy_present = True
        masked = v
        if "@" in v and "://" in v:
            try:
                _scheme, _rest = v.split("://", 1)
                if "@" in _rest:
                    _creds, _host = _rest.split("@", 1)
                    masked = f"{_scheme}://***:***@{_host}"
            except Exception:
                pass
        lines.append(f"[DIAG] env {key}={masked}")
    if not proxy_present:
        lines.append("[DIAG] env: no HTTP(S)_PROXY set — direct connection attempted")
    no_proxy = _os.environ.get("NO_PROXY", "") or _os.environ.get("no_proxy", "")
    if no_proxy:
        lines.append(f"[DIAG] env NO_PROXY={no_proxy}")

    # ── 6. Endpoint config recap ──────────────────────────────────────
    _ep_display = repr(configured_endpoint) if configured_endpoint else "(default AWS public)"
    lines.append(
        f"[DIAG] connection config: bucket={bucket!r} region={configured_region!r} "
        f"endpoint_url={_ep_display} path_style={path_style}"
    )

    # ── 7. Per-error remediation hint ─────────────────────────────────
    exc_name = type(exc).__name__
    err_str = str(exc).lower()
    hint = None
    if "connection refused" in err_str or "errno 111" in err_str:
        hint = (
            "Connection REFUSED at TCP layer — the destination IP exists "
            "but rejected port 443.  Common causes: (a) corporate firewall "
            "with REJECT egress rule, (b) VPC endpoint SG blocking inbound "
            "from this pod, (c) DNS returned a bad IP (loopback / dead host)."
        )
    elif "timed out" in err_str or "timeout" in exc_name.lower():
        hint = (
            "Connection TIMED OUT — destination unreachable.  Either no "
            "route to the IP (check pod's egress / VPC route table) or "
            "destination silently dropping SYN (security group DROP rule, "
            "not REJECT)."
        )
    elif "name or service not known" in err_str or "name resolution" in err_str:
        hint = (
            "DNS RESOLUTION FAILED — the hostname doesn't exist or this "
            "pod's resolver can't see it.  Common causes: (a) typo in "
            "bucket name (see validation above), (b) VPC private DNS "
            "needed but not enabled, (c) Route 53 private hosted zone "
            "missing for this VPC."
        )
    elif "EndpointConnectionError" in exc_name:
        hint = (
            "EndpointConnectionError covers any network-level failure.  "
            "Check the DNS line above for the underlying cause."
        )
    if hint:
        lines.append(f"[DIAG] LIKELY CAUSE: {hint}")

    return "\n".join(lines)


# AWS error codes that mean the session / token has expired
_EXPIRED_TOKEN_CODES = {
    'ExpiredToken', 'ExpiredTokenException', 'RequestExpired',
    'TokenRefreshRequired', 'InvalidToken', 'InvalidIdentityToken',
    'InvalidSecurity',
}

_TOKEN_EXPIRED_HINT = (
    "Your AWS session token has expired. "
    "Please update your connection credentials with a fresh token "
    "(run `aws sts get-session-token` or `aws sso login` and copy the new values)."
)


class TokenExpiredError(RuntimeError):
    """Raised when AWS temporary credentials (session token) have expired."""
    pass


def _is_expired_token(exc: Exception) -> bool:
    """Return True if a boto3 ClientError signals an expired session token."""
    if hasattr(exc, 'response'):
        code = exc.response.get('Error', {}).get('Code', '')
        if code in _EXPIRED_TOKEN_CODES:
            return True
    msg = str(exc).lower()
    return 'expired' in msg and 'token' in msg


def _check_token_expired(exc: Exception, config: "S3Config" = None):
    """Raise TokenExpiredError only when the user explicitly provided a session token
    (keys auth mode). For iam_role / profile / assume_role the token lifecycle is
    managed by AWS SDK or infra — surfacing a 'please re-enter token' prompt would
    be misleading."""
    if not _is_expired_token(exc):
        return
    if config and config.auth_mode == 'keys' and config.aws_session_token:
        raise TokenExpiredError(_TOKEN_EXPIRED_HINT) from exc
    # For other auth modes, let the original boto3 error propagate as-is


@dataclass
class S3Config:
    """S3 Configuration"""
    bucket_name: str
    region_name: str = "us-east-1"
    # auth_mode: "keys" | "iam_role" | "profile" | "assume_role" | "portal" (BF-284)
    auth_mode: str = "keys"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None  # for temporary credentials (STS / SSO / sts get-session-token)
    aws_profile: Optional[str] = None        # for SSO / named profile
    role_arn: Optional[str] = None           # for STS AssumeRole
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # for cross-account AssumeRole
    endpoint_url: Optional[str] = None       # for S3-compatible storage (MinIO etc.)
    path_style: bool = False                 # force path-style URLs (required for MinIO, NetApp, Ceph)
    # 2026-06-24 -- explicit operator override for URL addressing
    # style.  Set to "virtual" or "path" to force boto3 + DuckDB to
    # emit URLs in that form.  Takes precedence over path_style and
    # the VPC auto-detect.  Required for VPCs whose private DNS only
    # resolves the wildcard ``*.vpce-XXX.s3.<region>.vpce.amazonaws
    # .com`` -- those operators set addressing_style="virtual" so
    # URLs come out as ``<bucket>.vpce-XXX.s3.<region>.vpce.amazonaws
    # .com/<key>`` instead of ``vpce-XXX.s3.<region>.vpce.amazonaws
    # .com/<bucket>/<key>``.
    addressing_style: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"
    root_prefix: Optional[str] = None        # Phase 78L — root prefix for browsing and accessibility test
    # BF-284: AWS portal auth fields — used when auth_mode="portal".
    # The portal flow auto-refreshes STS credentials before they expire
    # via boto3's RefreshableCredentials, so long-running queries no
    # longer hit ExpiredToken mid-execution.
    portal_username:    Optional[str] = None  # AD username for AWS portal (defaults to aws_access_key_id)
    portal_password:    Optional[str] = None  # AD password (defaults to aws_secret_access_key)
    portal_base_url:    Optional[str] = None  # e.g. "https://awsportal.acme.com"
    portal_role_name:   Optional[str] = None  # filter for /v1/creds-provider/roles?search=
    portal_account_id:  Optional[str] = None  # find role_arn matching this account
    portal_sf_ref_no:   Optional[str] = None  # service_first_number passed to provide-credentials


def _parse_ssl_verify(val) -> Union[bool, str]:
    """Normalise ssl_verify: 'true'/'false' strings → bool, path strings kept as-is.
    If the value is True (default) and certs/tls_bundle.pem exists, use it automatically."""
    if isinstance(val, bool):
        if val and _DEFAULT_CA_BUNDLE.exists():
            logger.info(f"Using default CA bundle: {_DEFAULT_CA_BUNDLE}")
            return str(_DEFAULT_CA_BUNDLE)
        return val
    if isinstance(val, str):
        if val.lower() == 'false':
            return False
        if val.lower() == 'true':
            # treat as default True — auto-detect bundle
            if _DEFAULT_CA_BUNDLE.exists():
                logger.info(f"Using default CA bundle: {_DEFAULT_CA_BUNDLE}")
                return str(_DEFAULT_CA_BUNDLE)
            return True
        return val  # treat as explicit CA-bundle path
    return True  # safe default


def _strip(val) -> Optional[str]:
    """Strip whitespace from a credential string; return None if empty."""
    if val is None:
        return None
    s = str(val).strip()
    return s if s else None


def effective_addressing_style(cfg: Optional[dict]) -> str:
    """Single decision point for S3 URL addressing-style resolution.

    Returns ``'path'`` or ``'virtual'`` -- both boto3 and DuckDB
    consult this helper so they NEVER disagree about which URL form
    to use.

    2026-06-24 -- strategic 3-tier rule designed to support every
    real-world VPC topology we've seen + the standard AWS S3 + the
    on-prem S3 case, without a single hardcoded auto-magic that
    blocks operators from opting out:

      Tier 1 (explicit operator override -- highest precedence):
          ``addressing_style`` set to ``'path'`` or ``'virtual'``
          -> return that value.  Used by operators whose VPC has
          wildcard DNS for ``*.vpce-XXX.s3.<region>.vpce.amazonaws
          .com`` and need virtual-hosted on the VPCE host.

      Tier 2 (legacy ``path_style=True`` toggle):
          ``path_style == True`` -> ``'path'``.  Preserves
          backwards compatibility with every existing connection
          where operator explicitly chose path-style.

      Tier 3 (auto-detect when no operator preference):
          ``path_style`` unset OR False + VPC endpoint
              -> ``'path'`` (auto-enable; the common VPC pattern
              without wildcard DNS).
          ``path_style`` unset OR False + empty / standard endpoint
              -> ``'virtual'`` (standard AWS S3 pattern, routes via
              Private DNS for VPC if enabled).

    The operator ALWAYS has an escape hatch via
    ``addressing_style``.  No silently-overridden settings.

    Every S3-adjacent code path (boto3 client, DuckDB SET pragmas,
    federation, mv_manager) MUST go through this helper.

    None-safe: ``cfg=None`` defaults to ``'virtual'`` (the safe default
    for standard AWS S3).  Subprocess wraps every call in try/except
    too -- defence in depth.
    """
    if not cfg:
        return "virtual"
    # Tier 0 (2026-10-26, moved here from core.s3_access so boto3 and DuckDB
    # answer alike): a custom endpoint on PLAIN HTTP is path-style, whatever
    # else is declared -- virtual-hosted addressing over http:// needs a
    # wildcard DNS record no on-prem store has.  DuckDB had applied this
    # since 2026-09-26; the boto3 client (the presigner, every listing) did
    # not, so ``http://minio:9000`` without the path-style flag presigned
    # ``http://bucket.minio:9000/...`` for a DuckDB that read path-style.
    _ep_raw = str(cfg.get("endpoint_url") or cfg.get("endpoint") or "").strip().lower()
    if _ep_raw.startswith("http://"):
        return "path"
    # Tier 1: explicit operator override.
    _explicit = cfg.get("addressing_style")
    if isinstance(_explicit, str):
        _e = _explicit.strip().lower()
        if _e in ("path", "virtual"):
            return _e
    # Tier 2: legacy path_style=True toggle.
    if cfg.get("path_style") is True:
        return "path"
    # Tier 3: auto-detect for VPC, virtual everywhere else.
    _ep = _ep_raw
    if ".vpce." in _ep or "vpce-" in _ep:
        logger.info(
            "effective_addressing_style: VPC endpoint detected (%s) -- "
            "auto-enabling path-style addressing (the standard VPC "
            "pattern when wildcard DNS isn't wired).  Operators with "
            "wildcard DNS for *.vpce-XXX.s3.<region>.vpce.amazonaws.com "
            "should set addressing_style='virtual' in connection "
            "config to opt out.",
            cfg.get("endpoint_url"),
        )
        return "path"
    return "virtual"


def effective_path_style(cfg: dict) -> bool:
    """Back-compat shim: True if effective addressing style is 'path'.

    Existing callers (~14 sites) read a boolean ``path_style``; this
    shim lets them keep doing so while the routing logic is owned by
    ``effective_addressing_style``.  New code should call
    ``effective_addressing_style`` directly.
    """
    return effective_addressing_style(cfg) == "path"


def build_boto3_s3_config_kwargs(conn_config: Optional[dict]) -> dict:
    """Single source of truth for the BotoConfig kwargs every
    ``boto3.client('s3', config=...)`` site in the codebase needs to
    set the same way.  Returns a dict suitable for splatting into
    ``BotoConfig(**...)``.

    2026-06-24 -- created because audit kept finding the same kind of
    copy-paste divergence at each boto3 client construction site:
    one site set ``signature_version='s3v4'`` but not
    ``addressing_style``, another set neither, the parent's
    S3StorageHandler set both.  Each missed setting was a silent bug
    waiting for the right operator config to surface it.

    Single chokepoint -- if AWS adds a new s3-client config knob the
    operator needs to control (use_dualstack_endpoint, transfer
    accelerator, etc.), it goes here and every call site picks it up
    automatically.  No more "this client uses virtual but that one
    uses path".

    Returns at minimum::
      {'signature_version': 's3v4',
       's3': {'addressing_style': '<from effective_addressing_style>'}}

    Caller merges with their own connect_timeout / read_timeout /
    retries / max_pool_connections / proxies kwargs and passes the
    union to ``BotoConfig``.
    """
    return {
        # 2026-06-23 -- force SigV4.  VPC endpoints REQUIRE it; boto3
        # default against ``endpoint_url=vpce-*`` can fall back to
        # SigV2 (legacy AWSAccessKeyId/Signature/Expires form) which
        # VPC rejects with 403.
        "signature_version": "s3v4",
        # Single 3-tier resolver: explicit operator override
        # (addressing_style) > legacy path_style toggle > auto-detect.
        "s3": {"addressing_style": effective_addressing_style(conn_config)},
    }


def _auto_path_style_for_vpc(endpoint_url: Optional[str],
                              explicit_path_style: bool) -> bool:
    """Default path_style=True for AWS VPC interface endpoints WHEN
    the operator hasn't expressed a preference.

    Strategic fix for the most common VPC-endpoint regression:
    virtual-hosted addressing requires a wildcard DNS record for
    ``<bucket>.vpce-<id>.s3.<region>.vpce.amazonaws.com``.  Many
    VPC endpoint setups don't enable AWS private DNS on the endpoint
    AND/OR don't provision the wildcard in their private hosted
    zone — head_bucket happens to succeed (single-host) but
    list_objects_v2 / GetObject silently fail because the
    bucket-prefixed hostname doesn't resolve.

    Path-style addressing puts the bucket in the URL path
    (``https://vpce-….amazonaws.com/<bucket>/...``) — single
    hostname, no wildcard dependency, works regardless of private
    DNS setup.

    2026-06-24 -- this helper now ONLY fires when the operator has
    NOT set ``path_style`` explicitly.  Operators whose VPC has
    private DNS + wildcard properly wired (and therefore EXPECTS
    virtual-hosted ``<bucket>.s3.<region>.vpce.amazonaws.com`` URLs)
    set ``path_style=False`` to opt out.  ``effective_path_style``
    is the single chokepoint that enforces the three-state rule.

    Behaviour (when called):
      - explicit_path_style=True               -> return True
      - endpoint_url is a VPC interface URL    -> return True
      - otherwise                              -> return False

    The auto-enable case is logged at INFO level so operators see
    why a connection that worked through the proxy starts working
    direct after this fix.
    """
    if explicit_path_style:
        return True
    if not endpoint_url:
        return False
    _ep_lower = endpoint_url.lower()
    if ".vpce." in _ep_lower or "vpce-" in _ep_lower:
        logger.info(
            "build_s3_config: VPC endpoint detected (%s) — auto-enabling "
            "path_style addressing.  This avoids the wildcard-DNS gap that "
            "causes head_bucket to work but list_objects to fail when "
            "private DNS isn't fully wired in your VPC.  Set the connection's "
            "``path_style=False`` to opt out (when your VPC has wildcard "
            "DNS wired and EXPECTS virtual-hosted bucket-as-subdomain URLs).",
            endpoint_url,
        )
        return True
    return False



# ── Bucket-region resolution ────────────────────────────────────────────────
#
# 2026-08-20 — OPERATOR REPORT: "to find 3 files it took 100s ... error: the
# authorization header is malformed, the region 'us-east-1' is wrong ... and
# never defined".
#
# Both halves were true.  ``build_s3_config`` read
# ``cfg.get("region_name") or "us-east-1"``, so LEAVING THE REGION FIELD EMPTY
# did not mean "work it out" — it meant "sign every request for us-east-1".
# Against a bucket in eu-west-1 that is a SigV4 mismatch: HTTP 400
# AuthorizationHeaderMalformed on every call, for listing, HEAD and GET alike.
#
# The code already knew how to find the right answer — ``_detect_bucket_region``
# — but it lived NESTED INSIDE ``test_connection`` and only produced a HINT for
# the admin screen.  So a connection could test "OK, but set Region to
# eu-west-1" and then fail on every actual query, which is the worst possible
# split: the diagnostic path is smarter than the working path.
#
# Now it is a real resolution, at the single chokepoint every caller already
# goes through, and cached per bucket because a bucket's region cannot change.
#
# DELIBERATELY NARROW — this only fires when ALL of:
#   * the operator left region_name EMPTY (an explicit region is never
#     overridden; a wrong-but-deliberate value is the operator's to own), and
#   * there is no custom endpoint_url (MinIO / on-prem / VPCE have their own
#     region semantics and must not be probed against the AWS global endpoint).
# Anything else, or any failure, falls back to today's "us-east-1" — so the
# worst case is exactly the behaviour that shipped before.
_BUCKET_REGION_CACHE: dict = {}
_BUCKET_REGION_LOCK = threading.Lock()
#: Per-bucket probe locks, so concurrent cold-cache callers queue behind
#: ONE probe instead of each firing their own.
_BUCKET_REGION_INFLIGHT: dict = {}


#: An AWS region token: two letters, optional gov/iso qualifier, a word, a digit.
_AWS_REGION_RE = re.compile(r"^[a-z]{2}(?:-gov|-iso[a-z]?)?-[a-z]+-\d$")


def region_from_endpoint(endpoint_url: str) -> Optional[str]:
    """The AWS region named inside an S3 endpoint hostname, or None.

    2026-08-20 — the operator's endpoint SPELLS OUT its region and we ignored
    it::

        https://bucket.vpce-0abc.s3.eu-west-1.vpce.amazonaws.com/...
                                  ^^^^^^^^^

    while signing every request for ``us-east-1``:

        AuthorizationHeaderMalformed: the region 'us-east-1' is wrong;
        expecting 'eu-west-1'                       (HTTP 400, every object)

    Deterministic and offline — no probe, no credentials, no network — which is
    what makes it usable in the DuckDB child process and for VPCE endpoints,
    where an unsigned probe of the AWS global endpoint is neither possible nor
    meaningful.

    Recognises the standard shapes:
        s3.<region>.amazonaws.com
        <bucket>.s3.<region>.amazonaws.com
        bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com
        s3-<region>.amazonaws.com
    Returns None for anything it cannot read with confidence — MinIO, a
    hostname with no region token, or a private domain — so the caller keeps
    whatever it would have used.
    """
    if not endpoint_url:
        return None
    try:
        host = str(endpoint_url).split("://", 1)[-1].split("/", 1)[0]
        host = host.split("@")[-1].split(":")[0].lower()
        # Only trust a token that sits directly beside an s3 label; a bucket
        # merely NAMED like a region must never be read as one.
        parts = host.split(".")
        for i, part in enumerate(parts):
            if part == "s3" or part.startswith("s3-"):
                if part.startswith("s3-"):
                    cand = part[3:]
                    if _AWS_REGION_RE.match(cand):
                        return cand
                if i + 1 < len(parts) and _AWS_REGION_RE.match(parts[i + 1]):
                    return parts[i + 1]
    except Exception:
        return None
    return None


def s3_source_identity(cfg: Optional[dict]) -> Optional[Tuple[str, str]]:
    """``(store, bucket)`` -- WHICH bucket an S3 connection reads, or None.

    2026-10-07, owner requirement: "if the same bucket has multiple
    connections we should not allow creating a duplicate connection".  Two
    connections are the same source when this is equal.  ONE answer, used by
    every route that creates, edits or clones (``core/connection_duplicates``).

    ``bucket`` is the bucket name, case-folded.  ``store`` names the object
    store that bucket lives in:

    * every AWS spelling of one partition is ONE store -- no endpoint, the
      global or a regional host, ``s3-<region>``, dual-stack / FIPS, a
      ``vpce-<id>`` interface endpoint in its generic or ``bucket.vpce-``
      form (``ssl_config.normalize_vpce_endpoint_for_s3_data``): AWS bucket
      names are unique per PARTITION, so the endpoint is a route, not an
      identity.  The partition comes from the region the endpoint NAMES
      (``region_from_endpoint``, the offline half of ``resolve_s3_region``)
      or the explicit Region field -- never from the network probe, which a
      validation must not wait on: ``aws``, ``aws-us-gov``, ``aws-cn``.
    * any other endpoint (MinIO, a private domain, an IP) is its own store:
      the lower-cased host[:port] with the scheme, default port, path and a
      leading virtual-host ``<bucket>.`` label removed.

    None when there is no bucket (nothing to compare).
    """
    if not isinstance(cfg, dict):
        return None
    bucket = str(cfg.get("bucket_name") or cfg.get("bucket") or "").strip().lower()
    if not bucket:
        return None
    ep_raw = str(cfg.get("endpoint_url") or cfg.get("endpoint") or "").strip()
    try:
        from core.ssl_config import normalize_vpce_endpoint_for_s3_data
        ep = normalize_vpce_endpoint_for_s3_data(ep_raw) or ep_raw
    except Exception:
        ep = ep_raw
    scheme = "https"
    rest = ep
    if "://" in ep:
        scheme, rest = ep.split("://", 1)
        scheme = scheme.lower()
    host = rest.split("/", 1)[0].split("@")[-1].lower().rstrip(".")
    port = ""
    if ":" in host:
        host, port = host.rsplit(":", 1)
    if (scheme, port) in (("https", "443"), ("http", "80")):
        port = ""
    if not host or host.endswith(".amazonaws.com") or host.endswith(
            ".amazonaws.com.cn") or host == "amazonaws.com":
        region = (region_from_endpoint(host) or
                  str(cfg.get("region_name") or cfg.get("region") or "")
                  ).strip().lower()
        if host.endswith(".amazonaws.com.cn") or region.startswith("cn-"):
            return ("aws-cn", bucket)
        if region.startswith("us-gov-"):
            return ("aws-us-gov", bucket)
        return ("aws", bucket)
    if host.startswith(bucket + "."):
        host = host[len(bucket) + 1:]
    return (f"{host}:{port}" if port else host, bucket)


def resolve_bucket_region(bucket: str) -> Optional[str]:
    """Best-effort: the bucket's real AWS region, via an UNSIGNED HEAD.

    Unsigned on purpose — this runs before credentials are known to be usable,
    and S3 returns ``x-amz-bucket-region`` on the error response regardless.
    Cached forever (including the misses, as ``None``): a bucket does not move,
    and a failed probe must not be retried on every query.
    """
    if not bucket:
        return None
    with _BUCKET_REGION_LOCK:
        if bucket in _BUCKET_REGION_CACHE:
            return _BUCKET_REGION_CACHE[bucket]
    # 2026-08-20 — HARD WALL-CLOCK BOUND, not just socket timeouts.
    #
    # botocore's connect_timeout / read_timeout do not cover every stall mode:
    # a proxy that accepts and holds the connection, or a blackholed DNS
    # lookup, can outlast them.  Measured with a probe that hangs: the first
    # query blocked for the FULL duration, because nothing above botocore
    # enforced a ceiling.
    #
    # This runs on the query path, so it gets a deadline it cannot exceed.  The
    # worker is a daemon thread — if it overruns we stop waiting and fall back;
    # if it finishes later it still populates the cache, so the NEXT query
    # benefits.  Never blocks a demo for more than _PROBE_DEADLINE_S.
    # ONE probe per bucket even when N queries arrive cold together.  Measured:
    # 20 concurrent callers fired 20 identical probes.  Harmless in result, but
    # it is 20 simultaneous network calls at exactly the worst moment — the
    # first query after a restart, which on a demo is the one being watched.
    with _BUCKET_REGION_LOCK:
        _inflight = _BUCKET_REGION_INFLIGHT.get(bucket)
        if _inflight is None:
            _inflight = threading.Lock()
            _BUCKET_REGION_INFLIGHT[bucket] = _inflight
    with _inflight:
        # Re-check: the probe we queued behind may have already answered.
        with _BUCKET_REGION_LOCK:
            if bucket in _BUCKET_REGION_CACHE:
                return _BUCKET_REGION_CACHE[bucket]
        return _probe_once(bucket)


def _probe_once(bucket: str):
    """Run the deadline-bounded probe exactly once for *bucket*."""
    _result: list = []

    def _probe_worker() -> None:
        _result.append(_probe_bucket_region_blocking(bucket))

    _t = threading.Thread(target=_probe_worker, name="qs-s3-region-probe",
                          daemon=True)
    _t.start()
    _t.join(_PROBE_DEADLINE_S)
    if _t.is_alive():
        logger.warning(
            "[s3-region] region probe for bucket %r exceeded %.0fs — falling "
            "back without it.  Set the connection's Region field to remove "
            "this probe entirely.", bucket, _PROBE_DEADLINE_S)
        return None          # deliberately NOT cached: a transient stall must
                             # not pin a wrong answer for the process lifetime
    region = _result[0] if _result else None
    with _BUCKET_REGION_LOCK:
        _BUCKET_REGION_CACHE[bucket] = region
    return region


#: Ceiling on the bucket-region probe.  It sits on the query path; a demo must
#: never stall on it.
_PROBE_DEADLINE_S = 3.0


def _probe_bucket_region_blocking(bucket: str):
    """The actual probe.  Runs on a worker thread under a deadline."""
    region = None
    try:
        from botocore import UNSIGNED
        from botocore.config import Config as _BC
        from core.proxy_utils import get_boto_proxies as _gbp
        _kw = {"signature_version": UNSIGNED,
               "retries": {"max_attempts": 1, "mode": "standard"},
               "connect_timeout": 5, "read_timeout": 5}
        _px = _gbp()
        if _px:
            _kw["proxies"] = _px
        _probe = boto3.client("s3", region_name="us-east-1", config=_BC(**_kw))
        try:
            _probe.head_bucket(Bucket=bucket)
            region = "us-east-1"          # answered from the global endpoint
        except ClientError as exc:
            region = (exc.response.get("ResponseMetadata", {})
                      .get("HTTPHeaders", {}).get("x-amz-bucket-region"))
        finally:
            try:
                _probe.close()
            except Exception as _close_exc:
                # Not silent: tests/test_silent_exceptions.py ratchets the
                # count of bare `except: pass` sites, and "this one is
                # obviously uninteresting" is precisely how 760 of them
                # accumulated.  A closed-socket failure here is harmless but
                # traceable.
                logger.debug("[s3-region] probe client close failed: %s",
                             _close_exc)
    except Exception as exc:
        logger.debug("[s3-region] probe failed for %s (fail-open): %s", bucket, exc)
    return region


def resolve_s3_region(cfg: dict) -> str:
    """THE region an S3 connection signs with.  One implementation, all callers.

    2026-08-20 — this decision was independently re-derived in FIFTEEN places
    as ``cfg.get("region_name") or cfg.get("region") or "us-east-1"``:
    credential_resolver (x2), federation_engine (x3), etl_engine (x2),
    iceberg_service, iceberg_writer, mirror_common, iceberg_mirror,
    athena_connector, feed_engine (x2), duckdb_subprocess and s3_storage.

    Fifteen copies of a default is not fifteen small conveniences, it is one
    decision nobody owns.  Fixing "the region bug" in one of them leaves the
    other fourteen — which is exactly what happened: the boto3 copy was fixed
    and the DuckDB child kept signing every object read for us-east-1.

    RESOLUTION ORDER
      1. an EXPLICIT region on the connection — never second-guessed, even when
         the endpoint disagrees; a wrong-but-deliberate value is the operator's
      2. the region NAMED IN THE ENDPOINT hostname (VPCE / regional S3) —
         offline, exact, and the case that was failing in the field
      3. an unsigned probe of the bucket (AWS endpoints only, cached per bucket)
      4. ``us-east-1`` — the historical default, so the worst case is exactly
         the behaviour that shipped before

    Steps 3 and 4 both warn, because a region nobody configured is a fact the
    operator needs to see once, not a silent guess.
    """
    # BOTH spellings (2026-10-26).  A system account's vault secret injects
    # its region as ``region`` (core.qs_credentials), the feed's delivery
    # client and the Spark lanes read ``region_name or region`` -- this
    # resolver read ``region_name`` alone, so the same connection signed
    # for two regions depending on the road.
    explicit = str(cfg.get("region_name") or cfg.get("region") or "").strip()
    _ep_raw = ((cfg.get("endpoint_url") or cfg.get("endpoint") or "")).strip()
    _ep_region = region_from_endpoint(_ep_raw)
    bucket = str(cfg.get("bucket_name") or cfg.get("bucket") or "").strip()

    # 2026-08-21 — A CONTRADICTED REGION IS NOT A PREFERENCE, IT IS A GUARANTEED
    # 400.
    #
    # The rule used to be "an explicit region is never second-guessed".  That is
    # right when the explicit value is merely UNVERIFIABLE — and wrong when the
    # endpoint hostname flatly contradicts it, because AWS validates the
    # signature against the endpoint it served.  Signing eu-west-1 traffic as
    # us-east-1 cannot succeed; honouring the config there is not deference, it
    # is sending a request we know will fail with
    # AuthorizationHeaderMalformed on every object.
    #
    # AND THE CONFIG IS USUALLY NOT THE OPERATOR'S CHOICE AT ALL.  The
    # connection form ships `region_name: 'us-east-1'` as its DEFAULT
    # (frontend ConnectionManager.tsx) and saves it, so a VPCE connection
    # arrives pre-stamped us-east-1 without anyone typing it.  That is exactly
    # the operator's report: "the region 'us-east-1' ... never defined".  They
    # had not defined it; the form had.
    if explicit and _ep_region and explicit.lower() != _ep_region.lower():
        # Said ONCE per connection per process, in plain words (2026-10-26:
        # the owner saw it on every query of every road and read it as a
        # fault in each).  The region used is the endpoint's; the saved
        # field is the thing to change.
        _say_once(
            ("contradiction", bucket.lower(), explicit.lower(), _ep_raw.lower()),
            "The S3 connection for bucket '%s' has Region set to '%s', but "
            "its endpoint %s is in '%s'.  QueryStudio reads with '%s' (the "
            "endpoint's region; signing with '%s' would fail every request).  "
            "To stop this message, open the connection and set its Region field to "
            "Auto-detect or to '%s'.",
            bucket or "?", explicit, _ep_raw, _ep_region, _ep_region, explicit,
            _ep_region)
        return _ep_region
    if explicit:
        return explicit
    # BOTH key spellings.  duckdb_subprocess reads
    # `endpoint_url or endpoint`; reading only the first here meant a config
    # stored under `endpoint` resolved to us-east-1 in the boto3 half while the
    # child got it right — the two halves disagreeing again, which is the exact
    # failure this resolver exists to end.
    _ep = _ep_raw
    if _ep:
        # A VPCE / regional S3 endpoint NAMES its region in the hostname.  Read
        # it — offline and exact.  This is the case the operator hit: the
        # endpoint said eu-west-1 and every request was signed us-east-1.
        _from_host = region_from_endpoint(_ep)
        if _from_host:
            logger.info("[s3-region] region %r read from the endpoint hostname "
                        "(%s)", _from_host, _ep)
            return _from_host
        # A genuinely custom endpoint (MinIO, private domain): do NOT probe the
        # AWS global endpoint, and keep the historical default.
        return "us-east-1"
    detected = resolve_bucket_region(bucket)
    if detected:
        _say_once(
            ("detected", bucket.lower(), detected.lower()),
            "The S3 connection for bucket '%s' has no Region set; AWS says the "
            "bucket is in '%s' and QueryStudio uses that.  To skip this lookup, "
            "open the connection and set its Region field to '%s'.",
            bucket, detected, detected)
        return detected
    _say_once(
        ("fallback", bucket.lower()),
        "The S3 connection for bucket '%s' has no Region set and AWS did not "
        "say where the bucket is; QueryStudio signs for 'us-east-1'.  If the "
        "bucket is in another region every read fails -- open the connection "
        "and set its Region field.", bucket)
    return "us-east-1"


#: The region messages already said in this process (one per connection:
#: bucket + what was saved + the endpoint).  Every later call logs at DEBUG.
_REGION_SAID: set = set()
_REGION_SAID_LOCK = threading.Lock()


def _say_once(key: tuple, msg: str, *args) -> None:
    with _REGION_SAID_LOCK:
        first = key not in _REGION_SAID
        if first:
            _REGION_SAID.add(key)
    logger.log(logging.WARNING if first else logging.DEBUG, "[s3-region] " + msg, *args)


def build_s3_config(cfg: dict) -> "S3Config":
    """Build an S3Config from a plain config dict (handles all auth modes).

    2026-06-24 -- ``endpoint_url`` is normalised through the single
    chokepoint ``ssl_config.normalize_vpce_endpoint_for_s3_data`` so
    operators who entered the generic ``vpce-XXX.s3...`` form get the
    cert-aligned ``bucket.vpce-XXX.s3...`` form automatically.  Every
    downstream consumer of ``S3Config.endpoint_url`` (boto3 client,
    presigning, DuckDB ``SET s3_endpoint``) inherits the normalised
    value -- no per-site rewiring required."""
    # 2026-10-26 -- a SYSTEM ACCOUNT (vault kv) names the keys for this
    # connection, and THE chain (core.credential_resolver) is the one place
    # that reads it.  Every boto3 road (the presigner, every listing, the
    # Iceberg watcher / sync / bloom / prefetcher) built its client from the
    # raw row, so a connection whose keys live in the vault signed with the
    # pod's AMBIENT identity here while the feed worker used the vault's.
    # Role modes keep boto3's own refreshable chain (the handler below);
    # only the vault lookup is delegated.
    if ((cfg.get("system_account_id") or cfg.get("system_account_name")
         or cfg.get("system_account"))
            and not ((cfg.get("aws_access_key_id") or "").strip()
                     and (cfg.get("aws_secret_access_key") or "").strip())):
        from core.credential_resolver import resolve_s3_credentials
        cfg = resolve_s3_credentials(cfg)
    # THE on-prem rule, from the chain: a role / profile chain never runs
    # against an on-prem store (the DuckDB roads sign with nothing there);
    # boto3 then takes the pod's ambient identity -- the same "no connection
    # credential" answer.  The handler used to run STS against MinIO.
    _mode_in = (cfg.get("auth_mode") or "keys").strip().lower()
    if _mode_in in ("iam_role", "profile", "assume_role"):
        from core.credential_resolver import is_onprem_s3
        if is_onprem_s3(cfg):
            logger.info("build_s3_config: auth_mode=%s on an on-prem endpoint (%s) -- "
                        "the role chain does not run there; ambient credentials",
                        _mode_in, cfg.get("endpoint_url") or cfg.get("endpoint") or "path-style")
            cfg = dict(cfg, auth_mode="keys")
    _ep_raw = cfg.get("endpoint_url") or None
    try:
        from core.ssl_config import normalize_vpce_endpoint_for_s3_data
        _ep = normalize_vpce_endpoint_for_s3_data(_ep_raw) or _ep_raw
        if _ep and _ep_raw and _ep != _ep_raw:
            logger.info(
                "build_s3_config: VPCE endpoint normalised (%s -> %s) "
                "-- bucket-data sub-domain for cert + path-style.",
                _ep_raw.lower(), _ep.lower(),
            )
    except Exception:
        _ep = _ep_raw
    return S3Config(
        bucket_name=(cfg.get("bucket_name") or "").strip(),
        # Was ``cfg.get("region_name") or "us-east-1"`` — an EMPTY region field
        # silently meant "sign for us-east-1" rather than "work it out".
        region_name=resolve_s3_region(cfg),
        auth_mode=(cfg.get("auth_mode") or "keys").strip(),
        aws_access_key_id=_strip(cfg.get("aws_access_key_id")),
        aws_secret_access_key=_strip(cfg.get("aws_secret_access_key")),
        aws_session_token=_strip(cfg.get("aws_session_token")),
        aws_profile=_strip(cfg.get("aws_profile")),
        role_arn=_strip(cfg.get("role_arn")),
        role_session_name=_strip(cfg.get("role_session_name")) or "parquet-engine",
        external_id=_strip(cfg.get("external_id")),
        endpoint_url=_ep,
        # Path-style derivation goes through the shared
        # ``effective_path_style`` shim which now consults
        # ``effective_addressing_style`` (single chokepoint).  When
        # operator sets ``addressing_style="virtual"`` explicitly,
        # path_style returns False regardless of VPC auto-enable.
        path_style=effective_path_style(cfg),
        addressing_style=cfg.get("addressing_style"),
        ssl_verify=_parse_ssl_verify(cfg.get("ssl_verify", True)),
        root_prefix=_strip(cfg.get("root_prefix")),
        # BF-284: portal-auth fields — used when auth_mode="portal".
        portal_username=_strip(cfg.get("portal_username")),
        portal_password=_strip(cfg.get("portal_password")),
        portal_base_url=_strip(cfg.get("portal_base_url")),
        portal_role_name=_strip(cfg.get("portal_role_name") or cfg.get("role_name")),
        portal_account_id=_strip(cfg.get("portal_account_id") or cfg.get("aws_account_id")),
        portal_sf_ref_no=_strip(cfg.get("portal_sf_ref_no") or cfg.get("sf_ref_no")),
    )


class S3StorageHandler:
    """
    Handles S3 storage operations for Parquet files
    Supports reading from specific folders and file management
    """
    
    def __init__(self, config: S3Config):
        """
        Initialize S3 storage handler
        
        Args:
            config: S3 configuration
        """
        self.config = config
        self.s3_client = None
        self.s3_resource = None
        self._initialize_clients()
    
    def _initialize_clients(self):
        """
        Initialize S3 client using the configured auth mode:
          - 'keys'        : explicit Access Key ID + Secret (long-term credentials)
          - 'iam_role'    : no credentials — uses IAM instance profile / ECS task role /
                            environment variable chain automatically (boto3 default)
          - 'profile'     : named AWS profile from ~/.aws/config, including SSO profiles
                            created via `aws configure sso`
          - 'assume_role' : STS AssumeRole — obtains temporary credentials for a given
                            role ARN; optionally uses a named profile as the source identity
        """
        try:
            mode = (self.config.auth_mode or 'keys').lower()

            if mode == 'profile':
                # Named profile — works for SSO profiles too (after `aws sso login`)
                session = boto3.Session(
                    profile_name=self.config.aws_profile,
                    region_name=self.config.region_name,
                )

            elif mode == 'assume_role':
                # Optionally start from a named profile, then assume the target role
                if not self.config.role_arn:
                    raise ValueError("role_arn is required for auth_mode='assume_role'")
                base_session = boto3.Session(
                    profile_name=self.config.aws_profile,  # None → default chain
                    region_name=self.config.region_name,
                )
                from core.proxy_utils import get_boto_proxies as _gbp
                _sts_proxies = _gbp()
                sts = base_session.client(
                    'sts', verify=self.config.ssl_verify,
                    config=BotoConfig(proxies=_sts_proxies) if _sts_proxies else None,
                )
                try:
                    assume_kwargs = {
                        "RoleArn": self.config.role_arn,
                        "RoleSessionName": self.config.role_session_name or "parquet-engine",
                    }
                    if self.config.external_id:
                        assume_kwargs["ExternalId"] = self.config.external_id
                    creds = sts.assume_role(**assume_kwargs)["Credentials"]
                finally:
                    sts.close()
                session = boto3.Session(
                    aws_access_key_id=creds["AccessKeyId"],
                    aws_secret_access_key=creds["SecretAccessKey"],
                    aws_session_token=creds["SessionToken"],
                    region_name=self.config.region_name,
                )

            elif mode == 'iam_role':
                # Pure default credential chain — IAM instance profile, ECS task role,
                # environment vars (AWS_ACCESS_KEY_ID etc.), or ~/.aws/credentials default
                session = boto3.Session(region_name=self.config.region_name)

            elif mode == 'portal':
                # BF-284: AWS portal auth with auto-refresh.  Uses
                # botocore.RefreshableCredentials so boto3 transparently
                # re-fetches creds before they expire — no ExpiredToken
                # cascade mid-query.  Same 3-step portal flow as the
                # user's reference snippet (jwttoken → roles → provide-
                # credentials/{role_arn}).
                from core.aws_portal_auth import build_refreshable_credentials
                _portal_user = (self.config.portal_username
                                  or getattr(self.config, "aws_access_key_id", "") or "")
                _portal_pw = (self.config.portal_password
                                or getattr(self.config, "aws_secret_access_key", "") or "")
                if not _portal_user or not _portal_pw:
                    from core.credential_manager import NO_PORTAL_LOGIN
                    raise ValueError(NO_PORTAL_LOGIN)
                refreshable = build_refreshable_credentials(
                    _portal_user, _portal_pw,
                    portal_base_url=getattr(self.config, "portal_base_url", None) or None,
                    role_name=getattr(self.config, "portal_role_name", None) or None,
                    account_id=getattr(self.config, "portal_account_id", None) or None,
                    sf_ref_no=getattr(self.config, "portal_sf_ref_no", None) or None,
                )
                if refreshable is None:
                    raise RuntimeError(
                        "Failed to build refreshable credentials — botocore unavailable"
                    )
                # Build a botocore session, install the refreshable creds,
                # then wrap it as a boto3 Session.
                import botocore.session as _bcsession
                _bs = _bcsession.Session()
                _bs._credentials = refreshable  # private API but stable since boto3 1.0+
                if self.config.region_name:
                    _bs.set_config_variable("region", self.config.region_name)
                session = boto3.Session(botocore_session=_bs,
                                         region_name=self.config.region_name)
                logger.info("[s3-portal] auth_mode=portal — RefreshableCredentials installed")

            else:  # 'keys' (default)
                session_kwargs = {"region_name": self.config.region_name}
                if self.config.aws_access_key_id and self.config.aws_secret_access_key:
                    session_kwargs["aws_access_key_id"] = self.config.aws_access_key_id
                    session_kwargs["aws_secret_access_key"] = self.config.aws_secret_access_key
                    if self.config.aws_session_token:
                        session_kwargs["aws_session_token"] = self.config.aws_session_token
                session = boto3.Session(**session_kwargs)

            client_kwargs = {}
            if self.config.endpoint_url:
                client_kwargs["endpoint_url"] = self.config.endpoint_url
            # SSL — False skips verification (useful when corporate proxy intercepts TLS)
            # or supply a path to your org's CA bundle PEM file
            client_kwargs["verify"] = self.config.ssl_verify
            if self.config.ssl_verify is False:
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Adaptive retry with exponential backoff for S3 throttling (503 SlowDown)
            from core.proxy_utils import get_boto_proxies
            _proxies = get_boto_proxies(endpoint_url=self.config.endpoint_url or "")
            # BF-349 + BF-544 (2026-05-28): pool size scales with the
            # actual concurrency the pod will exercise.  Without this,
            # the hardcoded 64 was below the real high-water mark:
            #   30 INTERACTIVE workers (worker_pool DEFAULT_TYPE_CONFIGS)
            #   + up to 128 parallel column-stats threads
            #   + per-query S3 prefetch fan-out (default 8 workers)
            # urllib3 then spams "Connection pool is full, discarding
            # connection" and silently re-establishes the TCP+TLS
            # session for every overflow → 100-200 ms latency hit on
            # every prefetch under load.
            #
            # Heuristic: 2× the worker_pool total concurrency, capped
            # at 256 (above this boto3's underlying urllib3 starts to
            # thrash).  Operator can still pin via config.
            try:
                from core import config as _cfgm
                _pool_cfg = _cfgm.get("s3", "max_pool_connections", 0)
                if _pool_cfg:
                    _pool = int(_pool_cfg)
                else:
                    try:
                        from core.worker_pool import DEFAULT_TYPE_CONFIGS
                        # BF-588 (2026-05-29): DEFAULT_TYPE_CONFIGS values are
                        # ``TypeConfig`` DATACLASSES, not dicts.  Calling
                        # ``.get(...)`` on a dataclass raises AttributeError,
                        # which the outer except swallows → ``_total_workers``
                        # silently fell through to the except branch (30) for
                        # YEARS.  The intended 2× worker total was effectively
                        # always 64 (the floor).  Audit Agent 3 caught this.
                        # Fix: use ``getattr`` with default 0.
                        _total_workers = sum(
                            int(getattr(c, "max_workers", 0) or 0)
                            for c in DEFAULT_TYPE_CONFIGS.values()
                        )
                    except Exception:
                        _total_workers = 30
                    _pool = max(64, _total_workers * 2)
            except Exception:
                _pool = 64
            _pool = max(10, min(_pool, 256))
            boto_kwargs: dict = {
                "retries": {"max_attempts": 5, "mode": "adaptive"},
                "connect_timeout": 10,
                "read_timeout": 30,
                "max_pool_connections": _pool,
            }
            if _proxies:
                boto_kwargs["proxies"] = _proxies
            # 2026-06-24 -- single chokepoint via
            # ``build_boto3_s3_config_kwargs``.  Returns both the
            # addressing_style (from the 3-tier resolver) AND the
            # forced signature_version='s3v4'.  Every boto3.client
            # ('s3', config=...) site goes through this helper so
            # future audits never find divergence again.
            boto_kwargs.update(build_boto3_s3_config_kwargs({
                "addressing_style": getattr(
                    self.config, "addressing_style", None),
                "path_style": self.config.path_style,
                "endpoint_url": self.config.endpoint_url,
            }))
            # 2026-06-24 -- SigV4 is now forced UNCONDITIONALLY by the
            # shared ``build_boto3_s3_config_kwargs`` helper above (was
            # previously only forced for VPC endpoints; SigV4 is the
            # correct default for all modern AWS S3 access anyway).
            # The VPC-specific branch below is removed; the helper
            # covers it.
            boto_config = BotoConfig(**boto_kwargs)
            self.s3_client = session.client('s3', config=boto_config, **client_kwargs)

            logger.info(f"S3 client created (mode={mode}) for bucket: {self.config.bucket_name}")

        except NoCredentialsError:
            logger.error("AWS credentials not found")
            raise
        except Exception as e:
            if _is_ssl_error(e):
                raise RuntimeError(_SSL_HINT) from e
            logger.error(f"Failed to create S3 client: {e}", exc_info=True)
            raise
    
    def list_folders(self, prefix: str = "") -> List[Dict[str, Any]]:
        """
        List all folders in the S3 bucket
        
        Args:
            prefix: Prefix to filter folders
            
        Returns:
            List of folder information
        """
        try:
            folders = []
            paginator = self.s3_client.get_paginator('list_objects_v2')
            
            # Use delimiter to get folder structure
            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=prefix,
                Delimiter='/'
            )
            
            for page in pages:
                # CommonPrefixes contains the "folders"
                for prefix_obj in page.get('CommonPrefixes', []):
                    folder_path = prefix_obj['Prefix']
                    folders.append({
                        'path': folder_path,
                        'name': folder_path.rstrip('/').split('/')[-1],
                        'type': 'folder'
                    })
            
            logger.info(f"Found {len(folders)} folders with prefix '{prefix}'")
            return folders
            
        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error listing folders: {e}", exc_info=True)
            raise
    
    def list_parquet_files(self, folder_path: str = "") -> List[Dict[str, Any]]:
        """
        List parquet files and subfolders at ONE level using Delimiter='/'.
        This avoids scanning the entire bucket recursively — only the immediate
        children of *folder_path* are returned.  Subfolders are returned as
        entries with  type='folder'  so the frontend can lazy-load them on click.
        """
        try:
            items: List[Dict[str, Any]] = []
            paginator = self.s3_client.get_paginator('list_objects_v2')

            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=folder_path,
                Delimiter='/',
            )

            for page in pages:
                # Sub-folders at this level
                for prefix_obj in page.get('CommonPrefixes', []):
                    fp = prefix_obj['Prefix']
                    items.append({
                        'key': fp,
                        'path': fp,
                        'name': fp.rstrip('/').split('/')[-1],
                        'folder': folder_path,  # keep as-is — empty string for root
                        'type': 'folder',
                    })

                # Files at this level (.parquet, .csv, .txt)
                _QUERYABLE_EXTS = ('.parquet', '.csv', '.txt')
                for obj in page.get('Contents', []):
                    key = obj['Key']
                    # Skip the prefix itself (shows up as a 0-byte "key")
                    if key == folder_path:
                        continue
                    if any(key.lower().endswith(ext) for ext in _QUERYABLE_EXTS):
                        items.append({
                            'key': key,
                            'path': f"s3://{self.config.bucket_name}/{key}",
                            'name': key.split('/')[-1],
                            'size_bytes': obj['Size'],
                            'last_modified': obj['LastModified'].isoformat(),
                            'folder': folder_path,  # keep as-is — matches parent folder key
                            'storage_class': obj.get('StorageClass', 'STANDARD'),
                            'etag': obj.get('ETag', '').strip('"'),
                        })

            # 78D/78U: Cap folder browser results to prevent UI overload
            try:
                from core.config import s3_validation as _sv
                _max_items = _sv.max_folder_browser_items
            except Exception:
                _max_items = 500
            truncated = len(items) > _max_items
            if truncated:
                items = items[:_max_items]
            logger.info(f"Listed {len(items)} items at prefix '{folder_path}'" +
                        (" (truncated)" if truncated else ""))
            if truncated:
                return {"items": items, "truncated": True}
            return items

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error listing files: {e}", exc_info=True)
            raise
    
    def get_file_schema(self, s3_key: str) -> Dict[str, Any]:
        """
        Get schema information for a parquet file in S3
        
        Args:
            s3_key: S3 key of the parquet file
            
        Returns:
            Schema information dictionary
        """
        try:
            # Read only the Parquet footer (last 8 bytes = magic + footer length,
            # then the actual footer) instead of downloading the entire file.
            head = self.s3_client.head_object(Bucket=self.config.bucket_name, Key=s3_key)
            file_size = head['ContentLength']

            # Read last 8 bytes to get footer length
            range_end = file_size - 1
            range_start = max(0, file_size - 8)
            tail_resp = self.s3_client.get_object(
                Bucket=self.config.bucket_name, Key=s3_key,
                Range=f"bytes={range_start}-{range_end}"
            )
            tail = tail_resp['Body'].read()
            tail_resp['Body'].close()

            import struct
            footer_len = struct.unpack('<I', tail[:4])[0]

            # Read footer + the 8-byte trailer
            footer_start = max(0, file_size - footer_len - 8)
            footer_resp = self.s3_client.get_object(
                Bucket=self.config.bucket_name, Key=s3_key,
                Range=f"bytes={footer_start}-{range_end}"
            )
            footer_bytes = footer_resp['Body'].read()
            footer_resp['Body'].close()

            # PyArrow can read metadata from footer bytes
            buffer = BytesIO(footer_bytes)
            metadata = pq.read_metadata(buffer)
            schema = pq.read_schema(BytesIO(footer_bytes))

            return {
                'file': s3_key,
                'bucket': self.config.bucket_name,
                'columns': [
                    {
                        'name': field.name,
                        'type': str(field.type),
                        'nullable': field.nullable
                    }
                    for field in schema
                ],
                'num_rows': metadata.num_rows,
                'num_row_groups': metadata.num_row_groups,
                'size_bytes': file_size,
            }

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error getting schema for {s3_key}: {e}", exc_info=True)
            raise
        except Exception:
            # Fallback: if footer-only read fails (e.g. encrypted parquet), try full download
            try:
                obj = self.s3_client.get_object(Bucket=self.config.bucket_name, Key=s3_key)
                body = obj['Body']
                try:
                    buffer = BytesIO(body.read())
                finally:
                    body.close()
                parquet_file = pq.ParquetFile(buffer)
                schema = parquet_file.schema_arrow
                metadata = parquet_file.metadata
                return {
                    'file': s3_key, 'bucket': self.config.bucket_name,
                    'columns': [{'name': f.name, 'type': str(f.type), 'nullable': f.nullable} for f in schema],
                    'num_rows': metadata.num_rows, 'num_row_groups': metadata.num_row_groups,
                    'size_bytes': obj['ContentLength'],
                }
            except ClientError as e2:
                _check_token_expired(e2, self.config)
                raise
    
    def read_parquet_chunked(self, s3_key: str, chunk_size: int = 100000,
                            columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file from S3 in chunks for memory efficiency
        
        Args:
            s3_key: S3 key of the parquet file
            chunk_size: Number of rows per chunk
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        # BF-50: Use delete=False + manual cleanup.  On Windows,
        # NamedTemporaryFile(delete=True) keeps the file handle locked so
        # PyArrow cannot open the same file by name ("the process cannot
        # access the file because it is being used by another process").
        tmp_path = None
        try:
            tmp_file = tempfile.NamedTemporaryFile(
                delete=False, suffix='.parquet'
            )
            tmp_path = tmp_file.name
            try:
                logger.info(f"Downloading {s3_key} to temporary file...")
                self.s3_client.download_fileobj(
                    self.config.bucket_name,
                    s3_key,
                    tmp_file,
                )
                tmp_file.flush()
            finally:
                tmp_file.close()          # release handle before PyArrow opens it

            # Read in chunks — file handle is closed, safe on all platforms
            parquet_file = pq.ParquetFile(tmp_path)

            for batch in parquet_file.iter_batches(batch_size=chunk_size, columns=columns):
                yield pa.Table.from_batches([batch])
                    
        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error reading file {s3_key}: {e}", exc_info=True)
            raise
        finally:
            # BF-50: Clean up temp file after reading (delete=False requires manual cleanup)
            if tmp_path:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

    def read_parquet(self, s3_key: str, columns: Optional[List[str]] = None) -> pa.Table:
        """
        Read entire parquet file from S3 into memory
        
        Args:
            s3_key: S3 key of the parquet file
            columns: Optional list of columns to read
            
        Returns:
            PyArrow table
        """
        try:
            obj = self.s3_client.get_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )

            body = obj['Body']
            try:
                buffer = BytesIO(body.read())
            finally:
                body.close()
            table = pq.read_table(buffer, columns=columns)

            logger.info(f"Read {len(table)} rows from {s3_key}")
            return table

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error reading file {s3_key}: {e}", exc_info=True)
            raise
    
    def upload_file(self, local_path: str, s3_key: str) -> Dict[str, Any]:
        """
        Upload a file to S3
        
        Args:
            local_path: Local file path
            s3_key: S3 key for the uploaded file
            
        Returns:
            Upload information
        """
        try:
            self.s3_client.upload_file(
                local_path,
                self.config.bucket_name,
                s3_key
            )
            
            # Get file info
            head = self.s3_client.head_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Uploaded file to s3://{self.config.bucket_name}/{s3_key}")
            
            return {
                'bucket': self.config.bucket_name,
                'key': s3_key,
                'size_bytes': head['ContentLength'],
                'etag': head['ETag'].strip('"')
            }
            
        except ClientError as e:
            logger.error(f"Error uploading file: {e}", exc_info=True)
            raise
    
    def delete_file(self, s3_key: str) -> bool:
        """
        Delete a file from S3
        
        Args:
            s3_key: S3 key of the file to delete
            
        Returns:
            True if successful
        """
        try:
            self.s3_client.delete_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Deleted file: s3://{self.config.bucket_name}/{s3_key}")
            return True
            
        except ClientError as e:
            logger.error(f"Error deleting file: {e}", exc_info=True)
            raise
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test S3 connection and return bucket info.
        Tries head_bucket first; falls back to list_objects_v2 if 403
        (common when IAM policy lacks s3:HeadBucket but grants s3:ListBucket).
        On region mismatch / 400, auto-detects the correct region and retries.
        Returns actionable error messages for common credential/bucket problems.
        """
        bucket = self.config.bucket_name
        configured_region = self.config.region_name or 'us-east-1'
        auth_mode = self.config.auth_mode or 'keys'
        has_endpoint = bool(self.config.endpoint_url)
        has_token = bool(self.config.aws_session_token)

        logger.info(
            "S3 connection test — bucket=%s, region=%s, auth_mode=%s, "
            "endpoint_url=%s, path_style=%s, has_session_token=%s",
            bucket, configured_region, auth_mode,
            self.config.endpoint_url or '(none)', self.config.path_style, has_token,
        )

        def _detect_region_from_error(e: ClientError) -> Optional[str]:
            """Extract the actual bucket region from S3 error response headers."""
            return (e.response.get('ResponseMetadata', {})
                    .get('HTTPHeaders', {})
                    .get('x-amz-bucket-region'))

        def _detect_bucket_region() -> Optional[str]:
            """Best-effort region detection via unsigned HEAD to global endpoint."""
            if has_endpoint:
                return None  # custom endpoint — skip detection
            try:
                from botocore import UNSIGNED
                from core.proxy_utils import get_boto_proxies as _gbp2
                _det_cfg = {"signature_version": UNSIGNED}
                _det_px = _gbp2()
                if _det_px:
                    _det_cfg["proxies"] = _det_px
                detection = boto3.client(
                    's3', region_name='us-east-1',
                    config=BotoConfig(**_det_cfg),
                )
                try:
                    detection.head_bucket(Bucket=bucket)
                except ClientError as det_e:
                    return _detect_region_from_error(det_e)
                finally:
                    detection.close()
            except Exception:
                pass
            return None

        def _region_hint(e: ClientError) -> str:
            """Build a helpful region hint from the error or auto-detection."""
            actual = _detect_region_from_error(e)
            if not actual:
                actual = _detect_bucket_region()
            if actual and actual != configured_region:
                return (f" Detected bucket region: '{actual}' "
                        f"(you configured: '{configured_region}'). "
                        f"Update the Region field to '{actual}'.")
            if actual:
                return f" Bucket region: '{actual}'."
            return (f" Current region: '{configured_region}'. "
                    f"Verify this matches the bucket's actual AWS region.")

        def _diag_suffix(e: ClientError) -> str:
            """Append diagnostic info for troubleshooting."""
            code = e.response.get('Error', {}).get('Code', '')
            http_status = e.response.get('ResponseMetadata', {}).get('HTTPStatusCode', 0)
            parts = [f"AWS error: [{http_status}] {code}"]
            parts.append(f"region={configured_region}")
            if has_endpoint:
                parts.append(f"endpoint={self.config.endpoint_url}")
            parts.append(f"auth_mode={auth_mode}")
            if has_token:
                parts.append("session_token=present")
            return " (" + ", ".join(parts) + ")"

        def _parse_error(e: ClientError) -> Dict[str, Any]:
            code = e.response.get('Error', {}).get('Code', '')
            msg = e.response.get('Error', {}).get('Message', str(e))
            http_status = e.response.get('ResponseMetadata', {}).get('HTTPStatusCode', 0)
            logger.warning(
                "S3 test error — HTTP %s, code=%s, msg=%s, headers=%s",
                http_status, code, msg,
                e.response.get('ResponseMetadata', {}).get('HTTPHeaders', {}),
            )
            # Expired / invalid session token
            if _is_expired_token(e):
                if auth_mode == 'keys' and has_token:
                    return {'connected': False, 'error': _TOKEN_EXPIRED_HINT, 'error_code': 'TOKEN_EXPIRED'}
                # For other auth modes, give a broader hint
                return {'connected': False, 'error': (
                    f"AWS session token is expired or invalid. "
                    f"Auth mode: '{auth_mode}'. "
                    f"If using temporary credentials, refresh them and try again."
                    + _diag_suffix(e)
                )}
            if code == 'InvalidAccessKeyId':
                return {'connected': False, 'error': (
                    'Invalid Access Key ID. Common causes: (1) extra whitespace when '
                    'copy-pasting — try re-entering the key manually, (2) key was deleted '
                    'or deactivated in AWS IAM, (3) wrong AWS partition (e.g., GovCloud key '
                    'used against standard endpoint). If using temporary credentials '
                    '(SSO/STS), ensure the session token is also provided and has not expired.'
                )}
            if code == 'SignatureDoesNotMatch':
                return {'connected': False, 'error': (
                    'Invalid Secret Access Key. The signature does not match — '
                    'verify the secret key. If you recently rotated keys, '
                    'make sure the access key ID and secret key are from the same keypair.'
                    + _diag_suffix(e)
                )}
            if code in ('NoSuchBucket', '404'):
                return {'connected': False, 'error': f"Bucket '{bucket}' does not exist. Check the bucket name and region."}
            if code == 'PermanentRedirect':
                hint = _region_hint(e)
                return {'connected': False, 'error': f"Bucket '{bucket}' is in a different region.{hint}",
                        'auto_detect_region': True}
            if code == 'AuthorizationHeaderMalformed':
                hint = _region_hint(e)
                return {'connected': False, 'error': f"Wrong region specified.{hint}",
                        'auto_detect_region': True}
            # 400 Bad Request — region mismatch, or expired/invalid token
            if http_status == 400 or code in ('BadRequest', 'InvalidRequest',
                                               'IllegalLocationConstraintException'):
                hint = _region_hint(e)
                return {'connected': False, 'error': (
                    f"Bad Request from AWS S3. Common causes: "
                    f"(1) region mismatch — AWS console auto-selects the correct region "
                    f"but this tool needs it set explicitly, "
                    f"(2) expired or invalid session token — refresh credentials and retry, "
                    f"(3) bucket name contains invalid characters.{hint}"
                    + _diag_suffix(e)
                ), 'auto_detect_region': True}
            if code in ('403', 'AccessDenied'):
                return None  # caller will try fallback
            return {'connected': False, 'error': f"[{code}] {msg}" + _diag_suffix(e)}

        def _try_with_region(region: str) -> Optional[Dict[str, Any]]:
            """Retry connection test with a different region (auto-detected)."""
            if has_endpoint:
                return None  # custom endpoint — don't retry with different region
            logger.info("Auto-retrying S3 connection with detected region '%s'", region)
            try:
                retry_session = boto3.Session(
                    aws_access_key_id=self.config.aws_access_key_id,
                    aws_secret_access_key=self.config.aws_secret_access_key,
                    aws_session_token=self.config.aws_session_token,
                    region_name=region,
                )
                retry_kwargs = {"verify": self.config.ssl_verify}
                from core.proxy_utils import get_boto_proxies as _gbp3
                _retry_px = _gbp3()
                _retry_base = {
                    "retries": {"max_attempts": 2, "mode": "standard"},
                    "connect_timeout": 10, "read_timeout": 15,
                }
                if _retry_px:
                    _retry_base["proxies"] = _retry_px
                retry_config = BotoConfig(**_retry_base)
                if self.config.path_style:
                    _retry_base["s3"] = {"addressing_style": "path"}
                    retry_config = BotoConfig(**_retry_base)
                retry_client = retry_session.client('s3', config=retry_config, **retry_kwargs)
                try:
                    retry_client.head_bucket(Bucket=bucket)
                    logger.info("S3 connection OK after region auto-correct to '%s'", region)
                    return {
                        'connected': True, 'bucket': bucket, 'region': region,
                        'accessible': True,
                        'note': (f"Connected! Your configured region was '{configured_region}' "
                                 f"but the bucket is in '{region}'. "
                                 f"Update the Region field to avoid this warning."),
                    }
                finally:
                    retry_client.close()
            except Exception as retry_exc:
                logger.debug("Region auto-retry with '%s' also failed: %s", region, retry_exc)
            return None

        # --- Attempt 1: head_bucket ---
        try:
            self.s3_client.head_bucket(Bucket=bucket)
            try:
                loc = self.s3_client.get_bucket_location(Bucket=bucket)
                region = loc.get('LocationConstraint') or 'us-east-1'
            except ClientError:
                region = configured_region
            logger.info("S3 connection OK (head_bucket) — bucket=%s region=%s", bucket, region)
            result = {'connected': True, 'bucket': bucket, 'region': region, 'accessible': True}
            # 78L: Test root_prefix accessibility (warning only — not a failure)
            self._test_root_prefix_accessibility(result)
            return result

        except ClientError as e:
            parsed = _parse_error(e)
            if parsed is not None:
                # Auto-retry with detected region if applicable
                if parsed.get('auto_detect_region'):
                    actual = _detect_region_from_error(e) or _detect_bucket_region()
                    if actual and actual != configured_region:
                        retry_result = _try_with_region(actual)
                        if retry_result:
                            return retry_result
                logger.error("S3 connection test failed: %s", parsed['error'])
                return parsed
            # 403 / AccessDenied — credentials may still be valid, try list fallback

        except Exception as e:
            if _is_ssl_error(e):
                logger.error("S3 SSL error: %s", e, exc_info=True)
                return {'connected': False, 'error': _SSL_HINT}
            # 2026-06-16 — deep diagnostic on connection failures.  Without
            # this, the only signal was "Connection refused" with no
            # explanation of which IP, whether DNS worked, whether proxy was
            # in play, or whether the bucket name was DNS-compliant.  This
            # block emits a structured multi-line diagnostic the operator
            # can paste directly into a triage ticket.
            diagnostic = _diagnose_endpoint_failure(
                e, bucket=bucket,
                configured_endpoint=self.config.endpoint_url or "",
                configured_region=configured_region,
                path_style=self.config.path_style,
            )
            logger.error(
                "S3 connection test error: %s\n%s",
                e, diagnostic, exc_info=True,
            )
            return {
                'connected': False,
                'error': str(e),
                'diagnostic': diagnostic,
            }

        # --- Attempt 2: list_objects_v2 fallback (covers restricted IAM policies) ---
        try:
            self.s3_client.list_objects_v2(Bucket=bucket, MaxKeys=1)
            try:
                loc = self.s3_client.get_bucket_location(Bucket=bucket)
                region = loc.get('LocationConstraint') or 'us-east-1'
            except ClientError:
                region = configured_region
            logger.info("S3 connection OK (list fallback) — bucket=%s region=%s", bucket, region)
            result = {'connected': True, 'bucket': bucket, 'region': region, 'accessible': True,
                      'note': 'Connected (limited permissions — HeadBucket not allowed)'}
            # 78L: Test root_prefix accessibility (warning only — not a failure)
            self._test_root_prefix_accessibility(result)
            return result

        except ClientError as e:
            parsed = _parse_error(e)
            if parsed is not None:
                logger.error("S3 connection test failed: %s", parsed['error'])
                return parsed
            # 2026-06-16 BUG FIX — both HeadBucket AND ListBucket returned
            # 403.  Pre-fix this branch returned ``connected: True`` with
            # a "limited permissions" note, but file browse / partition
            # discovery / queries ALL use list_objects_v2 internally and
            # immediately fail with the same AccessDenied.  Operators saw
            # green "Successfully connected" then "AccessDenied when
            # calling ListObjectsV2" the moment they clicked Browse.
            #
            # Now we report the connection as FAILED with a clear
            # actionable message.  If the operator genuinely needs
            # object-only access (rare — they must know the exact key
            # they're fetching), they can still save the connection;
            # only the test result truthfully reports the gap.
            logger.warning(
                "S3 bucket '%s' rejected both HeadBucket and ListBucket "
                "with 403 — IAM policy is missing s3:ListBucket",
                bucket,
            )
            return {
                'connected': False,
                'bucket': bucket,
                'region': configured_region,
                'accessible': False,
                'error_code': 'S3_LIST_BUCKET_DENIED',
                'error': (
                    "AccessDenied on both HeadBucket and ListBucket. "
                    "Your IAM policy must grant at minimum s3:ListBucket "
                    "on this bucket for file browsing, partition "
                    "discovery, and query operations to work.  "
                    "Verify your IAM policy or AWS portal role permissions."
                ),
            }

        except Exception as e:
            if _is_ssl_error(e):
                logger.error("S3 SSL error (fallback): %s", e, exc_info=True)
                return {'connected': False, 'error': _SSL_HINT}
            # 2026-06-16 — same deep diagnostic as attempt 1, for the rare
            # path where head_bucket got a 403 (network OK) but
            # list_objects_v2 then suffered a transient network failure.
            # Without this, the fallback path silently dropped the
            # diagnostic and the operator saw only the one-line cause.
            diagnostic = _diagnose_endpoint_failure(
                e, bucket=bucket,
                configured_endpoint=self.config.endpoint_url or "",
                configured_region=configured_region,
                path_style=self.config.path_style,
            )
            logger.error(
                "S3 connection test error (fallback): %s\n%s",
                e, diagnostic, exc_info=True,
            )
            return {
                'connected': False,
                'error': str(e),
                'diagnostic': diagnostic,
            }
    
    def _test_root_prefix_accessibility(self, result: dict) -> None:
        """Phase 78L: Test that root_prefix is accessible; adds warning to result dict if not."""
        root_prefix = self.config.root_prefix
        if not root_prefix:
            return
        try:
            from core.config import s3_validation as _sv
            if not _sv.root_prefix_test_on_create:
                return
        except Exception:
            pass
        prefix_clean = root_prefix.rstrip("/") + "/"
        try:
            self.s3_client.list_objects_v2(
                Bucket=self.config.bucket_name, Prefix=prefix_clean, MaxKeys=1
            )
            result['root_prefix_accessible'] = True
        except ClientError as e:
            code = e.response.get('Error', {}).get('Code', '')
            if code == 'AccessDenied':
                result['root_prefix_accessible'] = False
                result['root_prefix_error'] = (
                    f"Access denied to root_prefix '{root_prefix}'. "
                    "Check that the IAM policy grants s3:ListBucket on this prefix."
                )
                logger.warning("root_prefix '%s' in bucket '%s' is not accessible: %s",
                               root_prefix, self.config.bucket_name, code)
        except Exception as e:
            logger.debug("root_prefix accessibility test failed: %s", e)

    def get_folder_tree(self, max_depth: int = 3) -> List[Dict[str, Any]]:
        """
        Get hierarchical folder structure
        
        Args:
            max_depth: Maximum depth to traverse
            
        Returns:
            Hierarchical folder structure
        """
        def get_subfolders(prefix: str, depth: int) -> List[Dict[str, Any]]:
            if depth >= max_depth:
                return []
            
            folders = self.list_folders(prefix)
            result = []
            
            for folder in folders:
                folder_data = {
                    'path': folder['path'],
                    'name': folder['name'],
                    'type': 'folder',
                    'children': get_subfolders(folder['path'], depth + 1)
                }
                result.append(folder_data)
            
            return result
        
        return get_subfolders('', 0)


# ── S3 Result Storage helpers ──────────────────────────────────────────────

def maybe_upload_result_to_s3(
    output_file: "Path",
    execution_id: str,
    s3_config: Optional[S3Config],
) -> Optional[Dict[str, Any]]:
    """Upload a query-result parquet to S3 if it exceeds the configured size threshold.

    Returns upload metadata dict or None if not uploaded.
    Called from execute_query_background / execute_sql_connector_background.
    """
    from core.config import s3_results as _s3r_cfg

    if not _s3r_cfg.enabled:
        return None
    mode = _s3r_cfg.storage_mode  # "local" | "s3" | "auto"
    if mode == "local":
        return None
    if s3_config is None:
        logger.debug("S3 results enabled but no s3_config — skipping upload for %s", execution_id)
        return None
    if not output_file.exists():
        return None

    file_size = output_file.stat().st_size
    if mode == "auto" and file_size < _s3r_cfg.size_threshold_bytes:
        logger.debug(
            "Result %s (%d bytes) below threshold (%d MB) — keeping local only",
            execution_id, file_size, _s3r_cfg.size_threshold_mb,
        )
        return None
    # mode == "s3" uploads everything regardless of size

    # Determine target bucket
    bucket = (_s3r_cfg.bucket_override or "").strip() or s3_config.bucket_name
    s3_key = f"{_s3r_cfg.prefix.rstrip('/')}/{execution_id}.parquet"

    try:
        upload_cfg = S3Config(
            bucket_name=bucket,
            region_name=s3_config.region_name,
            auth_mode=s3_config.auth_mode,
            aws_access_key_id=s3_config.aws_access_key_id,
            aws_secret_access_key=s3_config.aws_secret_access_key,
            aws_session_token=s3_config.aws_session_token,
            aws_profile=s3_config.aws_profile,
            role_arn=s3_config.role_arn,
            role_session_name=s3_config.role_session_name,
            external_id=s3_config.external_id,
            endpoint_url=s3_config.endpoint_url,
            ssl_verify=s3_config.ssl_verify,
            path_style=s3_config.path_style,
        )
        handler = S3StorageHandler(upload_cfg)
        info = handler.upload_file(str(output_file), s3_key)
        logger.info(
            "Uploaded result %s to s3://%s/%s (%d bytes)",
            execution_id, bucket, s3_key, file_size,
        )

        if _s3r_cfg.delete_local_after_upload:
            try:
                output_file.unlink()
                logger.info("Deleted local result file %s after S3 upload", output_file)
            except OSError as exc:
                logger.warning("Failed to delete local file %s: %s", output_file, exc)

        info["s3_uri"] = f"s3://{bucket}/{s3_key}"
        return info

    except Exception as exc:
        logger.error("S3 result upload failed for %s: %s", execution_id, exc, exc_info=True)
        return None


def download_result_from_s3(
    execution_id: str,
    local_dir: "Path",
    s3_config: Optional[S3Config],
) -> Optional["Path"]:
    """Download a query-result parquet from S3 back to local disk.

    Returns the local Path if successful, None otherwise.
    Called from find_csv_file() as a fallback when local file is missing.
    """
    from core.config import s3_results as _s3r_cfg

    if not _s3r_cfg.enabled or s3_config is None:
        return None

    bucket = (_s3r_cfg.bucket_override or "").strip() or s3_config.bucket_name
    s3_key = f"{_s3r_cfg.prefix.rstrip('/')}/{execution_id}.parquet"
    local_path = local_dir / f"{execution_id}.parquet"

    try:
        handler = S3StorageHandler(
            S3Config(
                bucket_name=bucket,
                region_name=s3_config.region_name,
                auth_mode=s3_config.auth_mode,
                aws_access_key_id=s3_config.aws_access_key_id,
                aws_secret_access_key=s3_config.aws_secret_access_key,
                aws_session_token=s3_config.aws_session_token,
                aws_profile=s3_config.aws_profile,
                role_arn=s3_config.role_arn,
                role_session_name=s3_config.role_session_name,
                external_id=s3_config.external_id,
                endpoint_url=s3_config.endpoint_url,
                ssl_verify=s3_config.ssl_verify,
                path_style=s3_config.path_style,
            )
        )
        local_dir.mkdir(parents=True, exist_ok=True)
        # Use get_object() instead of download_file() to avoid implicit
        # HeadObject call that corporate proxies may reject with HTTP 400.
        resp = handler.s3_client.get_object(Bucket=bucket, Key=s3_key)
        body = resp["Body"]
        try:
            with open(str(local_path), "wb") as f:
                while True:
                    chunk = body.read(1024 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
        finally:
            body.close()
        logger.info("Downloaded result from s3://%s/%s → %s", bucket, s3_key, local_path)
        return local_path
    except Exception as exc:
        logger.debug("S3 result download failed for %s: %s", execution_id, exc)
        return None
