"""Transpile engine-generated DuckDB SQL to a target connector's dialect.

WHY THIS MODULE EXISTS
----------------------
``ParquetQueryEngine.build_query_sql`` and the row-security rewriter both emit
DuckDB-shaped SQL: ANSI double-quoted identifiers and ``LIMIT``.  Sending that
verbatim to another engine is not a style problem.

* **Databricks / Spark SQL treats ``"x"`` as a STRING LITERAL.**  So
  ``SELECT "region" FROM t WHERE "region" = 'EMEA'`` compares the constant
  ``'region'`` to ``'EMEA'`` -- zero rows, HTTP 200 -- and a projection returns
  the column NAME as every row's value.  This is not hypothetical: it happened
  in production and is recorded in ``core/federation_engine.py`` on 2026-08-09
  as "a Databricks dataset report selected constant strings instead of columns
  (silently wrong data)".
* **Oracle has no ``LIMIT``** -- ORA-00933 on every query.

That 2026-08-09 fix was applied at ONE handoff, inside FederationEngine, and
``_transpile_for_connector`` had no other callers.  Every other route that
builds SQL for a connector -- the main execute path, the scheduler, reports,
published views, the SQL preview, feeds -- still shipped the pre-fix shape.
This module is that helper, lifted out so there is ONE transpile chokepoint;
FederationEngine now delegates to it.

FAILURE POSTURE -- a correctness GATE, not a cap
------------------------------------------------
* unknown connector dialect -> **raise** (UNKNOWN = UNSAFE: a connection type
  with no verified mapping must not receive SQL it can only mis-execute);
* transpile error on a dialect where the verbatim DuckDB shape is itself valid
  SQL (trino / starburst / athena / snowflake / postgresql) -> fall back to
  verbatim with a warning, which is exactly the behaviour that works there;
* transpile error on databricks / oracle / mysql -> **raise**.  A refusal beats
  silent wrong data.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Optional

from core.sql_filter_wrapper import dialect_for_connection_type

logger = logging.getLogger(__name__)

#: The unquoted-identifier rule EVERY verified engine accepts: a letter
#: first, then letters / digits / underscores.  Oracle is the strict one --
#: a leading underscore is ORA-00911 "invalid character" -- and the
#: DuckDB-shaped SQL this module transpiles carries generated aliases
#: UNQUOTED, so an alias that only DuckDB and Trino accept is a statement
#: that only DuckDB and Trino can run.
PORTABLE_IDENTIFIER_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def portable_alias(name: str) -> str:
    """Declare a generated alias, refusing one some verified engine rejects.

    Called at import time on every alias the SQL builders emit, so a
    spelling only DuckDB accepts fails the module load rather than the
    3am run.  The spark_k8s lane learnt this on 2026-09-13
    (``spark/jobs/generic_feed.py::JDBC_SUBQUERY_ALIAS``: ``_subq`` died on
    Oracle inside the detached pod); the federation engine's ``_base`` CTE
    was the same defect in the other twin and was found by live execution
    two days later.  The job image cannot import this module, so the two
    constants are pinned to the SAME rule by a test rather than a shared
    symbol.
    """
    if not PORTABLE_IDENTIFIER_RE.match(str(name or "")):
        raise ValueError(
            f"Generated alias {name!r} is not a legal unquoted identifier on "
            f"every verified engine (Oracle refuses a leading '_': "
            f"ORA-00911). Use a letter-first name.")
    return name


#: The alias the federation engine gives a custom-SQL dataset's base query
#: (``WITH <alias> AS (...) SELECT ... FROM <alias>`` and
#: ``(...) AS <alias>``).  Was ``_base`` until 2026-09-15; every custom-SQL
#: dataset on Oracle failed at its first execute with ORA-00911 while
#: auto-detect -- which runs the base query unwrapped -- succeeded.
BASE_QUERY_ALIAS = portable_alias("qs_base")

#: The connection types this gate has VERIFIED.  This set is the gate's own
#: declaration and is load-bearing in a way the dialect answers are not: a
#: type absent from it must RAISE (see ``transpile_for_connector``), because
#: shipping generated SQL to an engine nobody checked is the failure this
#: module exists to prevent.  Widening it is a deliberate act.
#:
#: The VALUES are a different question, and it is not this module's to
#: answer.  Until 2026-09-05 they were spelled out here — a second copy of
#: ``core.sql_filter_wrapper.CONNECTION_TYPE_DIALECTS`` that already
#: disagreed with it on ``athena`` (this one said ``trino``, a workaround
#: from before sqlglot had an Athena dialect).  Now the keys are declared
#: here and the answers come from the one resolver, so the two cannot drift:
#: the gate decides WHETHER, the resolver decides WHICH.
VERIFIED_CONNECTOR_TYPES = frozenset({
    "trino", "starburst", "athena", "snowflake", "databricks",
    "oracle", "postgresql", "mysql",
})

#: QueryStudio connection type -> sqlglot write dialect, for the verified
#: types only.  Derived, never declared -- see above.
SQLGLOT_WRITE_DIALECTS = {
    ct: dialect_for_connection_type(ct)
    for ct in sorted(VERIFIED_CONNECTOR_TYPES)
}

#: Engines on which the raw DuckDB shape (double quotes + LIMIT) is itself
#: valid SQL.  For these a transpile failure may fall back to verbatim; for
#: any other target fallback is FORBIDDEN.
#:
#: Keyed by CONNECTION TYPE, not by sqlglot dialect, despite the name --
#: ``starburst`` and ``postgresql`` are QueryStudio slugs, not dialects, and
#: the membership test below is against ``ct``.  Said out loud because a
#: reader who took it for a dialect set would "fix" it into the very second
#: vocabulary this module now avoids.
VERBATIM_SAFE_DIALECTS = {"trino", "starburst", "athena", "snowflake",
                          "postgresql"}


def dialect_is_known(conn_type: Optional[str]) -> bool:
    """True when ``conn_type`` has a verified sqlglot mapping."""
    return (conn_type or "").strip().lower() in SQLGLOT_WRITE_DIALECTS


#: Engines that store an unquoted name in capitals and match a quoted one exactly.
UPPER_FOLDING_DIALECTS = {"snowflake", "oracle"}


def _match_base_query_spelling(tree: Any) -> None:
    """Make the wrapper's quoted names match what the base query's columns are really called.

    2026-11-05, the owner on Snowflake: "Hierarchy_LEVEL_3_ID not found", for a query that runs in
    the query builder.  ``SELECT 1 AS Hierarchy_LEVEL_3_ID`` makes a column HIERARCHY_LEVEL_3_ID on
    these engines, and the wrapper asked for ``"Hierarchy_LEVEL_3_ID"``, which is another name there.
    A column the wrapper returns bare keeps the dataset's spelling as its alias, so whoever reads the
    result by that name still finds it.  A ``SELECT *`` names nothing, so nothing is rewritten for it.
    """
    from sqlglot import exp

    # A report wraps it in WITH; a dataset preview and a value list as FROM (...) AS qs_base.
    base = next((n for n in tree.find_all(exp.CTE, exp.Subquery) if n.alias == BASE_QUERY_ALIAS), None)
    if base is None or not isinstance(base.this, exp.Select):
        return
    inside = {id(c) for c in base.find_all(exp.Column)}
    real: dict = {}
    for item in base.this.selects:
        ident = item.args.get("alias") if isinstance(item, exp.Alias) else (
            item.this if isinstance(item, exp.Column) else None)
        if isinstance(ident, exp.Identifier) and not isinstance(ident.this, exp.Star):
            real[ident.name.casefold()] = ident.name if ident.quoted else ident.name.upper()
    for projection in list(tree.selects):
        if (isinstance(projection, exp.Column) and id(projection) not in inside
                and real.get(projection.name.casefold()) not in (None, projection.name)):
            projection.replace(exp.alias_(projection.copy(), projection.name, quoted=True))
    for column in list(tree.find_all(exp.Column)):
        if id(column) in inside or column.table:
            continue
        spelled = real.get(column.name.casefold())
        if spelled and spelled != column.name:
            column.set("this", exp.to_identifier(spelled, quoted=True))


def transpile_for_connector(sql: str, conn_type: str,
                            context: str = "",
                            oracle_transform: Any = None) -> str:
    """Rewrite ``sql`` (DuckDB dialect) into ``conn_type``'s dialect.

    ``context`` is a free-form label used only in log lines (an execution id,
    a route name) so an operator can trace which query was rewritten.

    ``oracle_transform`` is an optional sqlglot node transform applied only for
    Oracle -- FederationEngine passes its temporal-literal fixer.
    """
    ct = (conn_type or "").strip().lower()
    dialect = SQLGLOT_WRITE_DIALECTS.get(ct)
    if dialect is None:
        raise ValueError(
            f"Queries cannot run on connection type '{conn_type}': no "
            f"verified SQL dialect mapping exists, so the generated SQL would "
            f"execute with undefined semantics. Supported SQL connector "
            f"types: {sorted(SQLGLOT_WRITE_DIALECTS)}."
        )
    try:
        import sqlglot
        tree = sqlglot.parse_one(sql, read="duckdb")
        if tree is None:
            raise ValueError("sqlglot produced an empty statement")
        if dialect == "oracle" and oracle_transform is not None:
            tree = tree.transform(oracle_transform)
        if dialect in UPPER_FOLDING_DIALECTS:
            _match_base_query_spelling(tree)
        transpiled = tree.sql(dialect=dialect)
        if not transpiled.strip():
            raise ValueError("sqlglot produced an empty statement")
        if transpiled != sql:
            logger.info("[%s] transpiled generated SQL duckdb->%s for "
                        "connector '%s'", context or "-", dialect, ct)
        return transpiled
    except Exception as exc:
        if ct in VERBATIM_SAFE_DIALECTS:
            logger.warning(
                "[%s] duckdb->%s transpile failed (%s) -- executing verbatim; "
                "the DuckDB shape is valid SQL on '%s'.",
                context or "-", dialect, exc, ct)
            return sql
        _risk = ("silently WRONG (double-quoted identifiers are string "
                 "literals in Spark SQL)" if dialect == "databricks"
                 else "invalid")
        raise ValueError(
            f"Cannot safely execute the generated SQL on '{conn_type}': "
            f"transpiling duckdb->{dialect} failed ({exc}). Running it "
            f"verbatim would be {_risk} on this engine -- refusing instead."
        ) from exc


# ── Qualify a typed statement's bare table names with the browsed context ──
#
# 2026-10-03, REAL Snowflake: an author picks QS_DEMO / FIN in the query
# builder's catalog / schema pickers and types ``select * from TRADES``; the
# pickers only drove the table LIST, the statement went out bare, and the
# connection has no default database -> 002003 "Object 'TRADES' does not
# exist".  The fix is a REWRITE, not a session default: row security matches
# a policy on ``QS_DEMO.FIN.TRADES`` against the statement's table names
# (``core.row_security.resolver._normalize_table_ref`` only SHORTENS a name),
# so a session default would have let a bare ``TRADES`` read a governed table
# unfiltered.  Qualified in the TEXT, the policy matches, the engine gets an
# exact name and the result-cache key differs per context.

#: Engines whose tables are addressed catalog.schema.table, and the case an
#: unquoted identifier folds to there.
_QUALIFY_FOLD = {"snowflake": str.upper, "trino": str.lower,
                 "starburst": str.lower, "databricks": str.lower}
_BARE_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*\Z")


def qualify_unqualified_tables(sql: str, connection_type: str,
                               catalog: Optional[str],
                               schema: Optional[str]) -> str:
    """``sql`` with every table reference that names no schema qualified as
    ``catalog.schema.table`` (one naming a schema but no catalog gets the
    catalog).  CTE names and table functions are left alone.

    Unchanged when the engine is not catalog.schema.table addressed, when no
    schema was chosen, or when the statement does not parse as ONE statement
    -- an unparsable statement is sent as written and fails at the source as
    before; it is never guessed at."""
    fold = _QUALIFY_FOLD.get(str(connection_type or "").lower())
    catalog = str(catalog or "").strip()
    schema = str(schema or "").strip()
    if fold is None or not schema or not str(sql or "").strip():
        return sql
    import sqlglot
    from sqlglot import exp
    dialect = dialect_for_connection_type(connection_type) or None
    try:
        trees = [t for t in sqlglot.parse(sql, read=dialect) if t is not None]
    except Exception:  # noqa: BLE001 -- unparsable: send as written
        return sql
    if len(trees) != 1:
        return sql
    tree = trees[0]

    def ident(name):
        quoted = not _BARE_IDENT.match(name) or fold(name) != name
        return exp.to_identifier(name, quoted=quoted)

    ctes = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
    changed = False
    for t in tree.find_all(exp.Table):
        if not isinstance(t.this, exp.Identifier) or not t.name:
            continue
        has_db, has_cat = bool(t.args.get("db")), bool(t.args.get("catalog"))
        if not has_db and t.name.lower() in ctes:
            continue
        if not has_db:
            t.set("db", ident(schema))
            changed = True
        if catalog and not has_cat:
            t.set("catalog", ident(catalog))
            changed = True
    return tree.sql(dialect=dialect) if changed else sql
