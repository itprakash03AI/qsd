"""
AWS Portal Credential Provider — automatically fetch temporary AWS credentials
from a corporate credential-provider portal.

Matches the real corporate portal 3-step flow:
  1. POST /v1/jwttoken with {username, password} → JWT token
  2. GET  /v1/creds-provider/roles?search={role_name} (Basic Auth) → find role_arn by account_id
  3. POST /v1/creds-provider/provide-credentials/{role_arn} (Bearer) + {service_first_number} → STS creds

Config section ``aws_portal`` in config.json controls the portal URLs and behaviour.
Supports per-connection overrides (portal_base_url, role_name, account_id, sf_ref_no).
"""
from __future__ import annotations

import contextvars
import hashlib
import time
import logging
import threading
import urllib3
from typing import Any, Optional, Dict, Tuple

import requests

from core import config

logger = logging.getLogger(__name__)


def _global_proxy_url() -> str:
    """Return the global proxy URL from ``proxy`` config section (Phase 119 fallback)."""
    try:
        from core.config import proxy_cfg
        if proxy_cfg.enabled:
            return proxy_cfg.url_resolved
    except Exception:
        pass
    return ""

# Suppress InsecureRequestWarning when verify_ssl=False (corporate on-prem portals)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── Request-scoped context variable for current portal user ───────────────
# Set at the start of each request handler so _make_s3_client_for_conn
# can automatically inject portal credentials without explicit threading.
_current_portal_user: contextvars.ContextVar[str] = contextvars.ContextVar(
    "_current_portal_user", default=""
)

# ── Module-level credential cache ─────────────────────────────────────────
# Key: "<username>"  →  (creds_dict, expiry_epoch)
_cred_cache: Dict[str, Tuple[dict, float]] = {}
_cache_lock = threading.Lock()

# ── Role ARN cache (avoids repeated role lookups) ─────────────────────────
# Key: "<username>:<role_name>:<account_id>"  →  (role_arn, expiry_epoch)
_role_cache: Dict[str, Tuple[str, float]] = {}
_ROLE_CACHE_TTL = 3600  # 1 hour


def get_cached_credentials(username: str, min_lifetime_seconds: float = 0) -> Optional[dict]:
    """Return cached AWS creds for *username* if still valid, else ``None``.

    ``min_lifetime_seconds`` (BF-461, 2026-05-19) — when > 0, the cache
    entry must have at least this many seconds of remaining lifetime to
    be considered a hit.  Used by long-running operations (feed gen,
    cross-source, raw-SQL streaming, PV execute) that can't tolerate a
    mid-flight ``ExpiredToken`` from the static-keys path.

    Passing ``min_lifetime_seconds=600`` (10 minutes) before a feed
    starts means: only return the cached creds if they'll still be valid
    10 minutes from now.  Otherwise treat as cache miss → caller will
    force_refresh and we'll get a fresh ~1h-TTL session before the scan
    begins.

    Default 0 preserves existing behavior — short-running query paths
    (BQB structured, EXPLAIN, row-estimate) don't pay the preflight cost.
    """
    with _cache_lock:
        entry = _cred_cache.get(username)
        if entry and (time.time() + min_lifetime_seconds) < entry[1]:
            return entry[0]
    return None


def creds_cache_key(base: str, *, role_name: Optional[str] = None, account_id: Optional[str] = None,
                    portal_base_url: Optional[str] = None, jwt_url: Optional[str] = None,
                    credential_url: Optional[str] = None, sf_ref_no: Optional[str] = None,
                    **_ignored: Any) -> str:
    """THE cache key of portal credentials (2026-11-04, the owner: "vault based connection failing
    ... one system account used with multiple connections").  The key was the login alone, so
    the second connection asking for ANOTHER role or AWS account was handed the first one's keys
    for up to an hour, and S3 refused them.  Keys belong to (login, role, account, portal).  A
    connection that overrides none of them keeps the plain key."""
    where = [str(v or "") for v in (role_name, account_id, portal_base_url, jwt_url, credential_url, sf_ref_no)]
    return base if not any(where) else f"{base}|{'|'.join(where)}"


def _build_proxies(proxy_url: str) -> Optional[dict]:
    """Build requests proxies dict from a proxy URL."""
    if not proxy_url:
        return None
    return {"http": proxy_url, "https": proxy_url}


def _resolve_portal_config(jwt_url: Optional[str] = None,
                            credential_url: Optional[str] = None,
                            portal_base_url: Optional[str] = None,
                            role_name: Optional[str] = None,
                            account_id: Optional[str] = None,
                            sf_ref_no: Optional[str] = None,
                            proxy_url: Optional[str] = None,
                            use_admin_settings: Optional[bool] = None) -> dict:
    """Merge per-connection overrides with the Admin -> AWS Portal settings.

    2026-10-28 (owner: "admin aws portal config ... badly impacted my
    existing aws connection ... i did not enable it ... removed all config
    from admin aws portal n connection started working"): the Admin page's
    values filled every field a connection left empty -- proxy, base URL,
    role, account -- even with its Enabled switch OFF.  Those now apply ONLY
    while ``aws_portal.enabled`` is on (``use_admin_settings=None``); off, a
    connection logs in with its own.  Verify SSL and the timeout apply either
    way (they never change where a login goes).  The Admin page's own Test passes
    ``use_admin_settings=True`` so the settings can be tried before enabling.
    """
    cfg = config.aws_portal
    if use_admin_settings is None:
        use_admin_settings = bool(cfg.enabled)
    if use_admin_settings:
        g_base, g_jwt = cfg.portal_base_url, cfg.jwt_url
        g_role, g_account, g_sf = cfg.role_name, cfg.account_id, cfg.sf_ref_no
        g_proxy = cfg.proxy_url_resolved
    else:
        g_base = g_jwt = g_role = g_account = g_sf = g_proxy = ""
    # Verify SSL and the timeout follow the page EITHER way: they decide how
    # strictly and how long, never WHERE a login goes -- and tying Verify SSL
    # to the switch would turn TLS verification OFF for every connection
    # while the page is disabled (security review, 2026-10-28).
    verify, timeout = cfg.verify_ssl, cfg.timeout_seconds
    base = (portal_base_url or g_base or "").rstrip("/")

    return {
        "portal_base_url": base,
        "jwt_url": jwt_url or g_jwt or (f"{base}/v1/jwttoken" if base else ""),
        "roles_url": f"{base}/v1/creds-provider/roles" if base else "",
        "creds_url_base": f"{base}/v1/creds-provider/provide-credentials" if base else "",
        # Legacy: if someone had a direct credential_url, still support it
        "credential_url": credential_url or "",
        "role_name": role_name or g_role or "",
        "account_id": account_id or g_account or "",
        "sf_ref_no": sf_ref_no or g_sf or "",
        # the platform-wide proxy (Admin -> Proxy) is NOT this page's: it applies either way
        "proxy_url": proxy_url or g_proxy or _global_proxy_url() or "",
        "verify_ssl": verify,
        "timeout": timeout,
    }


def _lookup_role_arn(username: str, password: str, resolved: dict) -> str:
    """Step 2: GET /v1/creds-provider/roles → find matching role_arn.

    If role_name is provided it is used as a search filter, otherwise all
    available roles are returned and the first one matching account_id (or
    the very first result) is selected automatically.

    Uses Basic Auth (username:password).  Caches the result for 1 hour.
    """
    role_name = resolved["role_name"]
    account_id = resolved["account_id"]
    cache_key = f"{username}:{role_name}:{account_id}"

    # Check role cache
    with _cache_lock:
        entry = _role_cache.get(cache_key)
        if entry and time.time() < entry[1]:
            return entry[0]

    roles_url = resolved["roles_url"]
    if not roles_url:
        raise PortalAuthError("No portal_base_url configured — cannot look up roles")

    proxies = _build_proxies(resolved["proxy_url"])
    verify = resolved["verify_ssl"]
    timeout = resolved["timeout"]

    # Only include search param when role_name is explicitly set
    params = {"search": role_name} if role_name else {}

    try:
        resp = requests.get(
            roles_url,
            params=params,
            auth=(username, password),
            headers={"Content-Type": "application/json"},
            verify=verify,
            timeout=timeout,
            proxies=proxies,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as exc:
        from core.proxy_utils import sanitize_proxy_error
        raise PortalAuthError(f"Role lookup failed: {sanitize_proxy_error(str(exc))}") from exc

    items = data.get("items", [])
    if not items:
        hint = f" for search='{role_name}'" if role_name else ""
        raise PortalAuthError(f"No roles found{hint}")

    # Find the role matching our account_id
    target_arn = None
    if account_id:
        for role in items:
            arn = role.get("role_arn", "")
            if account_id in arn:
                target_arn = arn
                break
    if not target_arn:
        # If no account_id filter or no match, use first result
        target_arn = items[0].get("role_arn", "")

    if not target_arn:
        available = [r.get("role_arn") for r in items if r.get("role_arn")]
        raise PortalAuthError(
            f"Could not find role ARN for account '{account_id}'. "
            f"Available roles: {available}"
        )

    # Cache the role ARN
    with _cache_lock:
        _role_cache[cache_key] = (target_arn, time.time() + _ROLE_CACHE_TTL)

    logger.info("[portal] Found role ARN: %s", target_arn)
    return target_arn


#: a login the portal refused -> when it may be tried again.  A hash, never the password.
_REFUSED_LOGINS: Dict[str, float] = {}
REFUSED_LOGIN_SECONDS = 300


def _refused_login_key(url: str, username: str, password: str) -> str:
    return hashlib.sha256(f"{url}|{username}|{password}".encode()).hexdigest()


def _login_refused_recently(key: str) -> bool:
    now = time.time()
    with _cache_lock:
        for k in [k for k, until in _REFUSED_LOGINS.items() if until <= now]:
            _REFUSED_LOGINS.pop(k, None)
        return key in _REFUSED_LOGINS


def fetch_credentials(username: str, password: str,
                      jwt_url: Optional[str] = None,
                      credential_url: Optional[str] = None,
                      portal_base_url: Optional[str] = None,
                      role_name: Optional[str] = None,
                      account_id: Optional[str] = None,
                      sf_ref_no: Optional[str] = None,
                      proxy_url: Optional[str] = None,
                      use_admin_settings: Optional[bool] = None) -> dict:
    """Authenticate against the AWS portal and return temporary AWS credentials.

    ``use_admin_settings`` -- see ``_resolve_portal_config`` (None = only while
    Admin -> AWS Portal is Enabled; True = an Admin test of those settings).

    Full 3-step flow (corporate portal):
      1. POST jwt_url {username, password} → JWT token
      2. GET  roles_url?search={role_name} (Basic Auth) → find role_arn by account_id
      3. POST creds_url/{role_arn} (Bearer token) + {service_first_number} → STS creds

    Legacy 2-step flow (if credential_url is provided directly):
      1. POST jwt_url → JWT token
      2. GET  credential_url (Bearer token) → STS creds

    Returns dict with keys: ``aws_access_key_id``, ``aws_secret_access_key``,
    ``aws_session_token``, ``expires_at`` (epoch).

    Raises ``PortalAuthError`` on any failure.
    """
    resolved = _resolve_portal_config(
        jwt_url=jwt_url, credential_url=credential_url,
        portal_base_url=portal_base_url, role_name=role_name,
        account_id=account_id, sf_ref_no=sf_ref_no, proxy_url=proxy_url,
        use_admin_settings=use_admin_settings,
    )

    effective_jwt_url = resolved["jwt_url"]
    if not effective_jwt_url:
        raise PortalAuthError(
            "No JWT URL configured (set aws_portal.portal_base_url or aws_portal.jwt_url)"
        )

    verify = resolved["verify_ssl"]
    timeout = resolved["timeout"]
    proxies = _build_proxies(resolved["proxy_url"])

    # 2026-11-05 ONE place, every road (queries, Test, background refresh): the same username and
    # password the portal just refused are not sent again for REFUSED_LOGIN_SECONDS.  Each try is a
    # failed AD login, and enough of them lock the account.  A network failure is not a refusal.
    _refused_key = _refused_login_key(effective_jwt_url, username, password)
    if _login_refused_recently(_refused_key):
        raise PortalAuthError(
            f"The portal refused this password for '{username}' a moment ago. It is not being tried "
            f"again for up to {REFUSED_LOGIN_SECONDS // 60} minutes, to avoid locking the AD account. "
            "Correct the password to try again at once.")

    # ── Step 1: Get JWT token ─────────────────────────────────────────────
    try:
        jwt_resp = requests.post(
            effective_jwt_url,
            json={"username": username, "password": password},
            headers={"Content-Type": "application/json"},
            verify=verify,
            timeout=timeout,
            proxies=proxies,
        )
        # Deep-dive: capture portal's response body BEFORE raise_for_status
        # eats it.  Many portals return useful "missing field X" messages
        # in the body which would otherwise be invisible to the user.
        if jwt_resp.status_code >= 400:
            _body = (jwt_resp.text or "")[:500].strip()
            _safe = effective_jwt_url.split("?")[0]
            _diag = (
                f"HTTP {jwt_resp.status_code} from {_safe} "
                f"(user='{username}'). Portal said: {_body!r}"
            )
            logger.error("[portal] JWT auth %s", _diag)
            if jwt_resp.status_code in (401, 403):
                with _cache_lock:
                    _REFUSED_LOGINS[_refused_key] = time.time() + REFUSED_LOGIN_SECONDS
            raise PortalAuthError(f"JWT authentication failed: {_diag}")
        token = jwt_resp.json().get("token")
        if not token:
            body_keys = list((jwt_resp.json() or {}).keys())[:10]
            raise PortalAuthError(
                f"JWT response did not contain a 'token' field "
                f"(body keys: {body_keys})"
            )
    except requests.RequestException as exc:
        from core.proxy_utils import sanitize_proxy_error
        raise PortalAuthError(f"JWT authentication failed: {sanitize_proxy_error(str(exc))}") from exc

    logger.debug("[portal] JWT token obtained for user '%s'", username)

    # ── Decide: 3-step (role lookup) or legacy 2-step (direct URL) ────────
    direct_creds_url = resolved["credential_url"]

    if direct_creds_url:
        # Legacy 2-step: direct credential URL (backward compat)
        creds_url = direct_creds_url
        creds_method = "GET"
        creds_payload = None
    else:
        # 3-step: role lookup → dynamic credential URL
        role_arn = _lookup_role_arn(username, password, resolved)
        creds_url = f"{resolved['creds_url_base']}/{role_arn}"
        creds_method = "POST"
        creds_payload = {}
        if resolved["sf_ref_no"]:
            creds_payload["service_first_number"] = resolved["sf_ref_no"]

    # ── Step 3 (or 2): Get AWS temporary credentials ─────────────────────
    try:
        creds_headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        if creds_method == "POST":
            creds_resp = requests.post(
                creds_url,
                headers=creds_headers,
                json=creds_payload,
                verify=verify,
                timeout=timeout,
                proxies=proxies,
            )
        else:
            creds_resp = requests.get(
                creds_url,
                headers=creds_headers,
                verify=verify,
                timeout=timeout,
                proxies=proxies,
            )
        # Deep-dive fix: capture the server's response body BEFORE raise_for_status
        # swallows it.  The portal returns useful messages in the body (which
        # field is missing, what role is expected, etc.); without this we'd
        # just see "400 Client Error: Bad Request" and have no idea why.
        if creds_resp.status_code >= 400:
            _body_snippet = (creds_resp.text or "")[:500].strip()
            _safe_url = creds_url.split("?")[0]   # don't echo query string
            _payload_keys = list(creds_payload.keys()) if isinstance(creds_payload, dict) else None
            _diag = (
                f"HTTP {creds_resp.status_code} from {_safe_url} "
                f"(method={creds_method}, payload_keys={_payload_keys}, "
                f"sf_ref_no_set={bool(resolved.get('sf_ref_no'))}). "
                f"Portal said: {_body_snippet!r}"
            )
            logger.error("[portal] Credential fetch %s", _diag)
            raise PortalAuthError(f"Credential fetch failed: {_diag}")
        raw = creds_resp.json().get("Credentials")
        if not raw:
            raise PortalAuthError(
                f"Credentials response did not contain a 'Credentials' field. "
                f"Body keys: {list((creds_resp.json() or {}).keys())[:10]}"
            )
    except requests.RequestException as exc:
        from core.proxy_utils import sanitize_proxy_error
        raise PortalAuthError(f"Credential fetch failed: {sanitize_proxy_error(str(exc))}") from exc

    creds = {
        "aws_access_key_id": raw["AccessKeyId"],
        "aws_secret_access_key": raw["SecretAccessKey"],
        "aws_session_token": raw["SessionToken"],
    }

    # BF-284: parse the REAL STS Expiration from the portal response
    # (matches the user's reference snippet — `aws_session.get('Credentials',
    # {}).get('Expiration')`).  Fall back to configurable creds_ttl_seconds
    # when the portal omits the field.  Storing the actual expiry lets
    # downstream RefreshableCredentials trigger refresh BEFORE the token
    # expires, instead of guessing based on config TTL.
    cfg = config.aws_portal
    raw_expiration = raw.get("Expiration")
    expiry = None
    expiration_iso = None
    if raw_expiration:
        try:
            from datetime import datetime as _dt
            if isinstance(raw_expiration, (int, float)):
                expiry = float(raw_expiration)
                expiration_iso = _dt.fromtimestamp(expiry).isoformat()
            else:
                _raw_str = str(raw_expiration).strip()
                _exp_dt = None
                # Try ISO 8601 first (e.g. "2026-05-06T14:32:11+00:00") —
                # the AWS STS native format.
                try:
                    _exp_str = _raw_str.rstrip("Z").replace("Z", "+00:00")
                    if "T" in _exp_str and not _exp_str.endswith(("+00:00", "-00:00")):
                        if "+" not in _exp_str[10:] and "-" not in _exp_str[10:]:
                            _exp_str = _exp_str + "+00:00"
                    _exp_dt = _dt.fromisoformat(_exp_str)
                except ValueError:
                    # BF-485 — some portal implementations return RFC 1123 / 2822
                    # HTTP-date format (e.g. "Wed, 27 May 2026 17:32:00 GMT")
                    # instead of ISO 8601.  Falling through to the configured
                    # TTL on these is wasteful + masks the real expiry.  Use
                    # email.utils.parsedate_to_datetime which handles every
                    # RFC 2822 variant (and HTTP-date by extension).
                    try:
                        from email.utils import parsedate_to_datetime
                        _exp_dt = parsedate_to_datetime(_raw_str)
                    except (TypeError, ValueError):
                        _exp_dt = None
                if _exp_dt is None:
                    raise ValueError(
                        "unrecognized date format (tried ISO 8601 + RFC 2822/HTTP)"
                    )
                # BF-485 follow-up — both parse paths can yield a tz-naive
                # datetime (date-only ISO strings; RFC 2822 without tz).
                # ``.timestamp()`` on a tz-naive datetime interprets it
                # against the LOCAL timezone, which silently shifts the
                # expiry by hours and breaks RefreshableCredentials'
                # proactive refresh window.  Per HTTP-date / STS convention,
                # tz-missing values are UTC — stamp explicitly.
                if _exp_dt.tzinfo is None:
                    from datetime import timezone as _tz
                    _exp_dt = _exp_dt.replace(tzinfo=_tz.utc)
                expiry = _exp_dt.timestamp()
                expiration_iso = _exp_dt.isoformat()
        except Exception as _exp_exc:
            logger.warning("[portal] Could not parse Expiration='%s': %s — using TTL fallback",
                            raw_expiration, _exp_exc)
            expiry = None
    if not expiry:
        ttl = cfg.creds_ttl_seconds
        expiry = time.time() + ttl
        logger.info("[portal] No STS Expiration in response — using config TTL=%ds", ttl)
    creds["expires_at"] = expiry
    if expiration_iso:
        creds["expiration_iso"] = expiration_iso

    with _cache_lock:
        _cred_cache[creds_cache_key(username, role_name=role_name, account_id=account_id,
                                    portal_base_url=portal_base_url, jwt_url=jwt_url,
                                    credential_url=credential_url,
                                    sf_ref_no=sf_ref_no)] = (creds, expiry)

    _ttl_remaining = max(0, int(expiry - time.time()))
    logger.info("[portal] AWS credentials fetched for user '%s' (expires in %ds)",
                username, _ttl_remaining)
    return creds


def get_or_fetch_credentials(username: str, password: str,
                              force_refresh: bool = False,
                              **kwargs) -> dict:
    """Return cached credentials if valid, otherwise fetch fresh ones.

    Extra kwargs are passed to fetch_credentials (portal_base_url, role_name, etc).
    """
    if not force_refresh:
        cached = get_cached_credentials(creds_cache_key(username, **kwargs))
        if cached:
            return cached
    return fetch_credentials(username, password, **kwargs)


def clear_cache(username: Optional[str] = None) -> int:
    """Clear cached credentials.  Returns number of entries removed."""
    with _cache_lock:
        if username:
            # the login's plain entry and its per-role entries (creds_cache_key)
            keys = [k for k in _cred_cache if k == username or k.startswith(f"{username}|")]
            for k in keys:
                _cred_cache.pop(k, None)
            removed = len(keys)
            # Also clear role cache entries for this user
            to_remove = [k for k in _role_cache if k.startswith(f"{username}:")]
            for k in to_remove:
                _role_cache.pop(k, None)
            return removed
        count = len(_cred_cache)
        _cred_cache.clear()
        _role_cache.clear()
        return count


def cache_stats() -> dict:
    """Return cache statistics."""
    with _cache_lock:
        now = time.time()
        active = sum(1 for _, (_, exp) in _cred_cache.items() if exp > now)
        expired = len(_cred_cache) - active
        return {
            "total_entries": len(_cred_cache),
            "active": active,
            "expired": expired,
            "users": [k for k in _cred_cache.keys()],
            "role_cache_size": len(_role_cache),
        }


# ──────────────────────────────────────────────────────────────────────────
# BF-PORTAL-CONN-OVERRIDES — single source of truth for per-connection
# portal-call kwargs.  Every caller that fetches AWS portal creds for a
# specific connection (login pre-fetch, modal-driven auth, runtime query
# injection, system-account resolver) reads the SAME 5-7 fields with the
# SAME names; this helper centralises that mapping so the four old
# inline copies can't drift apart again.
#
# The original drift caused a latent bug: ``inject_portal_creds`` was
# silently dropping ``role_name`` and ``sf_ref_no`` while the login flow
# was forwarding all five — so the same connection minted the wrong IAM
# role depending on which code path ran.
# ──────────────────────────────────────────────────────────────────────────

# Mapping: ``Connection.config`` JSON key  →  ``fetch_credentials`` kwarg.
# Kept as an explicit list so adding a new field is a one-line change here
# rather than 4 places.
_PORTAL_OVERRIDE_FIELDS: Tuple[Tuple[str, str], ...] = (
    ("portal_base_url",   "portal_base_url"),
    ("role_name",         "role_name"),
    ("portal_account_id", "account_id"),
    ("sf_ref_no",         "sf_ref_no"),
    ("proxy_url",         "proxy_url"),
    # Legacy direct-URL overrides — used by older connections that pre-date
    # the role-lookup flow.  Both ``CredentialManager.resolve_s3_credentials``
    # and ``fetch_credentials`` already accept these.
    ("jwt_token_url",     "jwt_url"),
    ("credential_url",    "credential_url"),
)


#: The one sentence for an environment that still has the typed pair saved
#: and no System Account chosen -- the Admin page, the portal status, the
#: page's Test and a connection that relied on the pair all say exactly this.
TYPED_PAIR_NOT_USED = (
    "The default portal login must be a System Account — choose one "
    "(the typed username/password is no longer used)"
)


def global_service_configured() -> bool:
    """True when the Admin page names a default (global) login: a chosen
    System Account.  The typed username/password is not one (2026-10-30)."""
    return bool(config.aws_portal.service_system_account_id)


def global_service_problem(even_if_disabled: bool = False) -> Optional[str]:
    """``TYPED_PAIR_NOT_USED`` when a typed service username/password is still
    saved and NO System Account is chosen; else None.  Applies only while the
    page is Enabled, like every value on it (``even_if_disabled`` = the Admin
    page's own reads)."""
    cfg = config.aws_portal
    if not (cfg.enabled or even_if_disabled):
        return None
    if cfg.service_system_account_id:
        return None
    if cfg.service_username or cfg.service_password:
        return TYPED_PAIR_NOT_USED
    return None


def global_service_login(even_if_disabled: bool = False) -> Optional[Tuple[str, str, str]]:
    """THE default (global) portal login: ``(username, password, label)`` or None.

    ONE rule, one place (owner 2026-10-30: "override global portal setting
    should just take vault system account"): the login is ONLY the System
    Account chosen on Admin -> AWS Portal (``aws_portal.service_system_account_id``),
    its password from Vault or the account by the same rule as a connection's
    system account (``credential_manager.system_account_login``).  The typed
    ``service_username`` / ``service_password`` is NEVER read here -- it was a
    second way to the same decision, the pattern that once let an old typed
    password beat Vault.  A chosen account that cannot give a login is None.
    A saved typed pair with no account is ``global_service_problem``.
    Like every Admin -> AWS Portal value, it applies only while the page is
    Enabled (``even_if_disabled`` = the page's own Test).
    """
    cfg = config.aws_portal
    if not (cfg.enabled or even_if_disabled):
        return None
    acct_id = cfg.service_system_account_id
    if not acct_id:
        return None
    from core.credential_manager import system_account_login
    from core.database import get_db_manager
    db = get_db_manager()
    if db is None:
        return None
    login = system_account_login(db, acct_id)
    if not login or not login[0] or not login[1]:
        return None
    return login[0], login[1], f"system account #{acct_id}"


def build_portal_kwargs_for_connection(conn_config: Optional[dict]) -> Dict[str, str]:
    """Return a kwargs dict ready to splat into ``fetch_credentials(...)``.

    Reads per-connection portal overrides from ``conn_config`` (the JSON
    payload of a ``Connection`` row) and returns the subset of non-empty
    values mapped to ``fetch_credentials``'s parameter names.

    Empty / missing keys are filtered out so the global config defaults in
    ``_resolve_portal_config`` apply for those fields — i.e. a connection
    that only overrides ``role_name`` doesn't accidentally null out the
    global ``portal_base_url``.

    Use this from EVERY site that calls ``fetch_credentials`` on behalf of
    a specific connection so the field mapping stays in lock-step.
    """
    out: Dict[str, str] = {}
    if not isinstance(conn_config, dict):
        return out
    for cfg_key, kw_key in _PORTAL_OVERRIDE_FIELDS:
        val = conn_config.get(cfg_key)
        if val:  # non-empty string / non-None
            out[kw_key] = val
    return out


def inject_portal_creds(conn_config: dict, username: str) -> dict:
    """If portal auth is enabled, inject AWS creds into the connection config.

    Resolution order:
      1. Connection already has explicit AWS keys → skip (no injection)
      2. Connection has portal_username + portal_password → connection-level system account
      3. User has cached portal creds → inject those (per-user AD session)
      4. Service account configured globally → auto-fetch + inject (global fallback)
      5. None of the above → return config unchanged (fail-open)

    This is called before building an S3 client so that portal creds are
    used transparently without the user entering AWS keys manually.
    """
    cfg = config.aws_portal
    if not cfg.enabled:
        return conn_config

    # Only inject if the connection doesn't already have explicit keys
    has_explicit = bool(
        (conn_config.get("aws_access_key_id") or "").strip()
        and (conn_config.get("aws_secret_access_key") or "").strip()
    )
    if has_explicit:
        return conn_config

    # BF-PORTAL-CONN-OVERRIDES — single source of truth for the per-connection
    # override kwargs.  Previously this site inlined a 3-key subset
    # (portal_base_url, account_id, proxy_url) and SILENTLY DROPPED
    # role_name + sf_ref_no, so connections that customised those fields
    # ended up assuming the wrong IAM role when this code path ran.  Now
    # every fetch_credentials call below uses the same helper as
    # auth_api._refresh_aws_creds_for_user and admin_api.user_portal_authenticate.
    portal_kwargs = build_portal_kwargs_for_connection(conn_config)

    # Connection-level system account credentials (Phase 104-N)
    conn_portal_user = (conn_config.get("portal_username") or "").strip()
    conn_portal_pass = (conn_config.get("portal_password") or "").strip()

    cached = None

    # Try 1 (NEW): connection-level system account — used by published API, scheduled jobs,
    # and interactive queries where the connection carries its own AD system account.
    if conn_portal_user and conn_portal_pass:
        cached = get_cached_credentials(creds_cache_key(conn_portal_user, **portal_kwargs))
        if not cached:
            try:
                cached = fetch_credentials(
                    conn_portal_user, conn_portal_pass,
                    **portal_kwargs,
                )
            except PortalAuthError as exc:
                from core.proxy_utils import sanitize_proxy_error
                logger.warning("[portal] Connection-level portal auth failed for '%s': %s",
                               conn_portal_user, sanitize_proxy_error(str(exc)))
                # Fall through — don't return yet, try other options

    # Try 2: per-user cached creds (interactive AD sessions via ContextVar)
    if not cached:
        cached = get_cached_credentials(creds_cache_key(username, **portal_kwargs)) if username else None

    # BF-285: Try 2b — user has a portal password vaulted from a prior
    # POST /api/aws-portal/credentials call.  We don't store passwords
    # at rest (per QueryStudio's session design) but we DO cache them
    # encrypted in memory for the duration of the session, so the
    # interactive user doesn't get prompted on every query.
    if not cached and username:
        try:
            from core.portal_password_vault import get_password as _vault_get
            _vault_pw = _vault_get(username)
            if _vault_pw:
                cached = fetch_credentials(
                    username, _vault_pw,
                    **portal_kwargs,
                )
        except PortalAuthError as exc:
            from core.proxy_utils import sanitize_proxy_error
            logger.warning("[portal] vault-driven fetch failed for '%s': %s",
                            username, sanitize_proxy_error(str(exc)))
            # Fall through — service-account fallback below may still work
        except Exception as _vault_exc:
            logger.debug("[portal-vault] read failed (non-fatal): %s", _vault_exc)

    # Try 3: global service account (Admin -> AWS Portal) → auto-fetch (cached internally)
    svc = global_service_login() if not cached else None
    if svc:
        svc_user, svc_pass, _svc_label = svc
        cached = get_cached_credentials(creds_cache_key(svc_user, **portal_kwargs))
        if not cached:
            try:
                cached = fetch_credentials(
                    svc_user, svc_pass,
                    **portal_kwargs,
                )
            except PortalAuthError as exc:
                logger.warning("Service account portal auth failed: %s", exc)
                return conn_config

    if not cached:
        # A connection that relied on the old typed pair fails with the one
        # sentence -- never a silent login with the pair, never a silent
        # "no credentials" either.
        _problem = global_service_problem()
        if _problem:
            from core.credential_manager import PortalLoginMustBeSystemAccount
            raise PortalLoginMustBeSystemAccount(_problem)
        return conn_config

    # Inject portal creds into a COPY of the config (don't mutate original)
    injected = dict(conn_config)
    injected["aws_access_key_id"] = cached["aws_access_key_id"]
    injected["aws_secret_access_key"] = cached["aws_secret_access_key"]
    injected["aws_session_token"] = cached["aws_session_token"]
    injected["auth_mode"] = "keys"  # force keys mode with portal creds
    _trace = conn_portal_user or username or "service-account"
    logger.debug("[portal] Injected AWS credentials (identity='%s')", _trace)
    return injected


class PortalAuthError(Exception):
    """Raised when AWS portal authentication fails."""
    pass


# ──────────────────────────────────────────────────────────────────────────
# BF-284: boto3 RefreshableCredentials integration
# ──────────────────────────────────────────────────────────────────────────
#
# The previous design fetched portal credentials once + pinned them on
# boto3.Session(aws_access_key_id=...).  When STS expired mid-query, every
# subsequent S3 call returned ExpiredToken until something invalidated the
# cached client and we re-fetched manually.
#
# boto3 has built-in support for refreshing credentials on-the-fly via
# `botocore.credentials.RefreshableCredentials`.  When credentials are within
# 15 minutes of expiry, boto3 transparently calls our refresh callback BEFORE
# the next S3 call — no ExpiredToken, no cascade, no cache-invalidation
# dance.  Matches the user's reference snippet which calls the portal each
# time but with our cache layer added back so we don't hit the portal on
# every API call.

def _refresh_metadata(username: str, password: str, **portal_kwargs) -> dict:
    """Refresh callback for boto3 RefreshableCredentials.

    Called by botocore when the cached credentials are within
    ``advisory_refresh_timeout`` (default 15 min) of expiry.  We re-fetch
    fresh credentials from the portal and return them in the shape
    botocore expects:

        {
            "access_key": ...,
            "secret_key": ...,
            "token": ...,
            "expiry_time": ISO-8601 string,
        }

    Force_refresh is True so we always hit the portal — botocore is
    asking BECAUSE the cached entry is about to expire.
    """
    fresh = fetch_credentials(username, password, **portal_kwargs)
    expiry_iso = fresh.get("expiration_iso")
    if not expiry_iso:
        from datetime import datetime as _dt, timezone as _tz
        expiry_iso = _dt.fromtimestamp(
            fresh["expires_at"], tz=_tz.utc
        ).isoformat()
    return {
        "access_key":  fresh["aws_access_key_id"],
        "secret_key":  fresh["aws_secret_access_key"],
        "token":       fresh["aws_session_token"],
        "expiry_time": expiry_iso,
    }


def build_refreshable_credentials(username: str, password: str, **portal_kwargs):
    """BF-284: build a boto3 RefreshableCredentials object that auto-refreshes
    via our portal flow.

    Pass the result to ``botocore.session.Session._credentials = ...`` on a
    boto3 Session, and every S3 client built from that session will
    transparently refresh credentials before they expire.

    Returns ``None`` (not a RefreshableCredentials) if botocore isn't
    available — caller should fall back to the static-creds path.
    """
    try:
        from botocore.credentials import RefreshableCredentials
    except ImportError:
        logger.warning("[portal] botocore not available — refreshable creds unsupported")
        return None

    # Initial fetch — this populates the cache and gives botocore real
    # credentials right away (so the first API call doesn't hit the
    # refresh path).
    initial = _refresh_metadata(username, password, **portal_kwargs)

    return RefreshableCredentials.create_from_metadata(
        metadata=initial,
        refresh_using=lambda: _refresh_metadata(username, password, **portal_kwargs),
        method="aws-portal-jwt",
    )
