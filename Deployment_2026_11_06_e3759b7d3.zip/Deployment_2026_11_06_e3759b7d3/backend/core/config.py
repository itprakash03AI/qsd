"""
QueryStudio — centralised configuration loader.

Resolution order (highest → lowest priority):
  1. Environment variables  (QUERYSTUDIO_<SECTION>_<KEY>  e.g. QUERYSTUDIO_SERVER_PORT)
  2. config.json            (backend/config.json)
  3. Built-in defaults      (hardcoded in this file)

For OpenShift / container deployments set env vars in the Deployment manifest or
a ConfigMap/Secret — no code changes required.
"""
from __future__ import annotations

import copy as _copy_mod
import json
import logging
import os
import re
import sys as _sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

# config.json lives next to main.py (backend/)
_CONFIG_FILE = Path(__file__).resolve().parent.parent / "config.json"

# ── Built-in defaults (fallback when neither env var nor config.json provides a value) ──
_DEFAULTS: dict = {
    # ══════════════════════════════════════════════════════════════════
    # WHICH ENVIRONMENT THIS DEPLOYMENT IS  (2026-09-07)
    # ══════════════════════════════════════════════════════════════════
    #
    # Read by ``deploy_environment()`` below, which is the ONE resolver
    # for this fact.  Before this block existed the same three keys were
    # consulted by FOUR hand-copied readers (main.py, core/daemon_registry,
    # core/feed_engine and, by a different spelling, core/feed/steps) and
    # NONE of the keys was declared, so:
    #
    #   * a deployment that set ``app.environment`` in config.json got
    #     "[app] unknown config section (typo?)" from validate_config();
    #   * ``QUERYSTUDIO_APP_ENVIRONMENT`` did NOTHING, because _apply_env
    #     only writes into sections/fields that already exist in the merged
    #     config — so the documented env-var path could not carry it;
    #   * the value therefore resolved to "" on every pod, and
    #     ``netcool.build_identifier`` REFUSES a blank environment, so the
    #     feed SLA watcher detected breaches it could never raise.
    #
    # Default "" is UNSET ON PURPOSE and is NOT a guess.  The deployed
    # environments are UAT and PROD: defaulting to PROD would label a UAT
    # alert as production, and defaulting to UAT (or "dev") would label a
    # real PROD breach as noise and get it triaged away.  Both are worse
    # than a stated refusal, so "" makes the alerting daemons refuse LOUDLY
    # AT STARTUP naming this key, instead of at 04:50 naming nothing.
    #
    # The value is NOT validated against a fixed set.  "DEV or PROD" and
    # "UAT or PROD" arrived five minutes apart from the same operator; an
    # allow-list in code would have rejected the second one.  Whatever the
    # deployment sets is what the console sees, and the resolved value is
    # reported by ``get_status()`` so a pod that believes it is UAT while
    # sitting in PROD is visible rather than inferred.
    #
    # Precedence (first non-empty wins), so a Helm value can carry it:
    #   app.environment -> app.env -> deployment.environment
    #   -> $QUERYSTUDIO_ENV -> $ENVIRONMENT
    "app": {
        # Canonical.  Set this one.  Settable as
        # QUERYSTUDIO_APP_ENVIRONMENT=PROD from the Deployment manifest.
        "environment": "",
        # Accepted alias, declared because ``deploy_environment()`` READS
        # it — a guard on an undeclared key is vacuous, and an undeclared
        # key that IS read is a ghost.
        "env":         "",
    },
    "deployment": {
        # Third accepted spelling, declared for the same reason.
        "environment": "",
    },
    "database": {
        "type": "sqlite",           # "sqlite" | "postgresql" | "oracle"
        "postgresql_url": "",       # "postgresql://user:pass@host:5432/querystudio"
        "postgresql_pool_size": 20,
        "postgresql_max_overflow": 30,
        "postgresql_pool_timeout": 30,
        # 2026-10-03 -- ping a pooled PostgreSQL connection only when it sat
        # idle longer than this (seconds); 0 = SQLAlchemy pool_pre_ping, a
        # SELECT 1 before EVERY checkout.  Why the default is safe for a
        # failover: core/db/idle_ping.py.  SQLite always pre-pings.
        "pool_ping_idle_seconds": 5,
        "postgresql_ssl_mode": "prefer",  # disable, allow, prefer, require, verify-ca, verify-full
        # BF-409 — Postgres-from-parts (alternative to full URL).  Individual
        # fields each env-var-overridable via QUERYSTUDIO_DATABASE_POSTGRESQL_*.
        # Used only when no full URL is resolvable (URL takes precedence).
        "postgresql_user": "",
        "postgresql_password": "",
        "postgresql_host": "",
        "postgresql_port": 5432,
        "postgresql_db": "",
        # BF-409 — Schema isolation (multi-tenant Postgres).  Empty = use the
        # connecting role's default search_path (usually "$user", public).
        # When set, the engine `CREATE SCHEMA IF NOT EXISTS` at startup and
        # every new connection runs `SET search_path TO <schema>, public`.
        "postgresql_schema": "",
        "oracle_dsn": "",
        "oracle_user": "",
        "oracle_password": "",
        # BF-403 — slow-query logger (sqlalchemy after_cursor_execute hook).
        # Logs any query exceeding this many ms at WARNING in db.slow_query.
        # Statement template only (placeholders), never parameter values.
        # Set to 0 to log EVERY query at DEBUG (short-term debugging only;
        # never leave on in production — one log line per query).
        "slow_query_ms": 1000,
        # BF-408 — SQLite on a networked PVC (NFS/GlusterFS/CephFS) corrupts
        # under WAL mode because those filesystems can't reliably honour
        # fcntl-based locks.  Symptoms: "database disk image is malformed",
        # "database is locked", missing rows, intermittent OperationalError.
        # Switch to DELETE mode on network storage — slower writes but
        # POSIX-locking-free and corruption-proof on flaky FS.
        # Choices: "WAL" (default, local storage) | "DELETE" (network FS)
        #          | "TRUNCATE" | "PERSIST" | "MEMORY" | "OFF"
        "sqlite_journal_mode": "WAL",
        # Durability vs speed: NORMAL is the SQLite default, FULL adds an
        # extra fsync per transaction.  Use FULL when journal_mode=DELETE
        # on a network FS — extra fsync cost is negligible vs the corruption
        # risk.  Choices: "OFF" | "NORMAL" | "FULL" | "EXTRA"
        "sqlite_synchronous": "NORMAL",
        # Run PRAGMA integrity_check on every startup and log the result.
        # Already runs once today; flag is here so admins can disable it
        # for ultra-large DBs where the check takes minutes.
        "sqlite_integrity_check_on_startup": True,
        # Read replica settings (Phase 43)
        "replica_urls": [],                    # list of PostgreSQL replica URLs
        "read_preference": "replica",          # "primary" | "replica" | "primary_preferred"
        "replica_pool_size": 10,
        "replica_max_overflow": 15,
        "replica_pool_timeout": 20,
        "replica_health_interval_seconds": 30,
        "replica_max_lag_seconds": 5,
    },
    "auth": {
        # "ad" | "local" | "none".  UNSET by default (2026-10-18, the owner: "if
        # someone not authorized how come they can see everything"): an unset
        # type is LOGIN REQUIRED (_AuthCfg.type -> "local"), never a guest admin.
        # "none" (no login, every caller a guest admin) only when SET on purpose.
        "type": "",
        "local_users": "",          # "user1:pass1,user2:pass2" format
        "user_roles": "",           # "user1:admin,user2:analyst,user3:viewer"
        # 2026-09-29 -- the /auth/login limiter (api/auth_api.py::login).
        # It used to be 10/min per client ADDRESS, and behind an ingress
        # (see server.forwarded_allow_ips) the address is the ingress for
        # everyone: one bucket for the whole organisation, so the 11th
        # person to sign in within a minute of a 9am wave got 429.
        #   per_account: attempts per minute per (client address, username)
        #   with the username stripped and lower-cased -- the brute-force
        #   cap on one account, 10 as it always was.
        #   per_ip: attempts per minute per client address across every
        #   username -- bounds password spraying (one address, many
        #   accounts) while colleagues behind one office NAT or one coarse
        #   proxy address never lock each other out.  300 = thirty accounts
        #   each spending their full 10, or five attempts a second: far
        #   above any human login wave from one address, and a sprayer at
        #   300 guesses a minute is still capped, where an unthrottled pod
        #   would take thousands.  The same number bounds GET /auth/public-key
        #   per address (its own bucket): a client fetches the key at most
        #   once per login attempt, and that fetch used to be a hard-coded
        #   30/min -- thirty for the whole organisation behind an ingress,
        #   after which the frontend sent passwords PLAINTEXT.
        "login_rate_limit_per_account_per_minute": 10,
        "login_rate_limit_per_ip_per_minute": 300,
        # 2026-09-29 -- what /auth/login does with a PLAINTEXT ``password``
        # (the browser could not fetch GET /auth/public-key or has no Web
        # Crypto, so frontend/src/services/loginCrypto.ts falls back; curl /
        # Postman post it by design).
        #   "allow"  (default): accept it.  The transport is TLS at the
        #            route, and refusing would turn a public-key hiccup on
        #            one pod into an org-wide login outage.  Every such
        #            login is AUDITED (login_transport=plaintext_fallback on
        #            the login / login_failed row) and logged at WARNING
        #            once per (process, account, hour), so it is never
        #            silent.
        #   "refuse": answer 400 login_plaintext_refused; the browser, told
        #            through /auth/config plaintext_fallback, never sends it
        #            and shows the reload sentence instead.  A site choosing
        #            fail-closed sets this.  Anything but "allow" refuses
        #            (a misspelling is named by validate_config).
        "login_plaintext_fallback": "allow",
        "ad_server": "",
        "ad_domain": "",
        "ad_base_dn": "",
        "ad_user_search_filter": "(sAMAccountName={username})",
        "ad_group_attribute": "memberOf",
        "ad_admin_groups": "",
        "ad_analyst_groups": "",
        "ad_viewer_groups": "",
        "ad_service_account": "",   # Service account for LDAP lookups (e.g. "CN=svc_qs,OU=Service,DC=example,DC=com")
        "ad_service_password": "",  # Service account password
        "ad_connect_timeout": 3,    # seconds to wait for LDAP socket connect (0 = no limit); was 10, lowered to fail fast
        "ad_receive_timeout": 10,   # seconds to wait for LDAP response after connect
        "ad_use_ssl": False,        # True for ldaps:// connections (port 636)
        "ad_tls_validate": True,    # Validate server TLS cert (set False for self-signed certs in dev)
        "ad_tls_check_hostname": False,  # Verify cert CN/SAN matches ad_server hostname.
                                    # Default False because AD certs are typically issued to the DC's FQDN
                                    # (e.g. dc01.corp.example.com) not the domain (corp.example.com).
                                    # Set True only if your AD cert has SANs matching the ad_server hostname.
        "ad_tls_ca_file": "",       # PEM CA bundle for AD server cert. Empty = use OS default trust store.
                                    # Set to a mounted file path (e.g. "/app/certs/ad-ca/ca.crt") when the
                                    # AD server uses an internal CA not in the image's trust store.
        # Phase 1 SECURITY (2026-07-23) — service-auth escape hatch for the
        # report endpoints (burst / enterprise reports / PDF export) whose
        # forgeable header-trusting _get_user was replaced by the verified
        # identity boundary.  When True, a machine caller may authenticate
        # with an X-API-Key header (existing hashed-key path, role
        # 'api_consumer' — never admin-tier).  Default OFF: non-interactive
        # callers normally use Basic with a REAL password or a Bearer
        # session; the old unauthenticated/forgeable path no longer exists
        # in any mode.
        "reports_service_api_key": False,
    },
    "server": {
        # REVIEWED 2026-09-13 (ruff S104 "binding to all interfaces").
        # Correct by necessity, not an oversight: this process is deployed
        # as a container. A server bound to 127.0.0.1 inside a pod is
        # unreachable by the kubelet's probes and by every Service that
        # fronts it, so the container would be dead on arrival. Network
        # exposure is decided by the Service/Ingress and NetworkPolicy,
        # which is where it belongs -- the bind address cannot express it.
        "host": "0.0.0.0",
        "port": 8000,
        "log_level": "info",
        "log_format": "json",       # "json" (structured, for ELK/Splunk) | "text" (human-readable)
        "log_file": "",             # Path to log file. Empty = stdout only. e.g. "logs/querystudio.log"
        # BF-406 — retention bumped 2 → 14 days.  Two days was too short for
        # meaningful prod debugging (Friday's logs gone by Monday).  Two
        # weeks fits a typical incident-response window without exploding
        # disk usage thanks to gzip compression of rotated files (below).
        "log_retention_days": 14,
        # BF-406 — size cap.  Force rotation when the active file exceeds
        # this many MEGABYTES even mid-day.  Protects against a single bad
        # day (query loop, 1000-req/sec burst, NL chatbot stuck retrying)
        # producing a 10 GB file that fills the PVC and crashes the pod.
        # BF-574 (2026-05-29): default lowered 100 → 25 MB so the active
        # file stays openable in standard text editors (VS Code's
        # default "large file" warning fires at 50 MB; most JSON tools
        # struggle past 10 MB).  Set higher in config if you want
        # bigger archives, or 0 to disable size-based rotation.
        "log_max_mb": 25,
        # BF-406 — gzip rotated files in place.  Reduces disk usage by ~10×
        # on typical JSON / text logs.  Set false to keep raw rotated files
        # (slightly faster archive but much more disk).
        "log_compress": True,
        # 2026-10-07 — log I/O OFF the event loop.  true: every log record
        # is handed to a queue (O(1), on the calling thread) and ONE listener
        # thread writes it to stdout / the log file, so a slow pipe (the
        # container log driver under load) or an NFS log dir never stalls
        # the asyncio loop -- measured in-process, the access-log line of
        # every request was the largest event-loop stall source left once
        # the DB writes were moved off it.  false: handlers write inline on
        # the calling thread (the pre-2026-10-07 behaviour).
        "log_async": True,
        # BF-410.1 — graceful shutdown drain seconds.  When SIGTERM hits,
        # wait this long for in-flight `/api/execute` queries to finish
        # before cancelling.  OpenShift default grace period is 30 s, so
        # 25 s leaves 5 s for cleanup + SIGKILL margin.
        "shutdown_drain_seconds": 25,
        "otel_endpoint": "",        # OpenTelemetry OTLP endpoint e.g. "http://jaeger:4317" (empty = disabled)
        "workers": 1,
        # 2026-10-10 -- with workers > 1, how long uvicorn's multiprocess
        # supervisor waits for a worker's pong before it KILLS and respawns
        # it (uvicorn.run(timeout_worker_healthcheck=...), passed by
        # main.run_server; uvicorn's own default is 5).  Every request in
        # flight on the killed worker dies at the socket ("Connection reset
        # by peer").  Found live 2026-10-10 at 50 concurrent published-API
        # consumers: "Child process [164] died" with the container never
        # restarting.  The pong is answered by a daemon thread, so this
        # bounds a WHOLE process standing still (a stop-the-world
        # collection on a large heap, a C call holding the GIL, CPU
        # starvation of the container) -- a backstop; an event loop that
        # blocks is fixed where it blocks (api/published_views/page_io.py).
        # The ledger a respawn leaves is /health "workers"
        # (core/worker_ledger.py).  Range 1..600 (validate_config).
        "worker_healthcheck_timeout_seconds": 30,
        # 2026-10-04 -- glibc malloc arenas per server process
        # (core/process_memory.py::configure_allocator, applied by
        # main.run_server to itself and, via MALLOC_ARENA_MAX, to the uvicorn
        # workers it spawns; an operator-set MALLOC_ARENA_MAX wins).  glibc's
        # default is 8 x cores: every thread that mallocs (the anyio pool,
        # bulk producer threads, the parquet writer) gets an arena that never
        # shrinks.  Measured: 3 concurrent 1.5M-row CSV streams retained
        # 313 MiB with the default and 201 MiB at 2.  0 = glibc's default.
        "malloc_arena_max": 2,
        # TLS / HTTPS — set ssl_certfile + ssl_keyfile to serve HTTPS directly.
        # For production, prefer terminating TLS at a reverse proxy (nginx/Caddy).
        "ssl_certfile": "",         # Path to PEM cert file  e.g. "certs/cert.pem"
        "ssl_keyfile": "",          # Path to PEM key file   e.g. "certs/key.pem"
        "ssl_keyfile_password": "", # Key passphrase (if encrypted private key)
        "https_redirect": False,    # True → redirect all plain HTTP requests to HTTPS
        # 2026-09-29 -- which peers' X-Forwarded-For / X-Forwarded-Proto
        # uvicorn BELIEVES (passed to uvicorn.run as forwarded_allow_ips,
        # with proxy_headers=True, by main.run_server).  Behind an ingress
        # every request arrives from the ingress, so anything keyed on
        # request.client.host -- the /auth/login limiter, audit ip_address,
        # the published-view access log, the access-log line -- sees ONE
        # address for the whole organisation unless the ingress's own
        # X-Forwarded-For is trusted.  Comma-separated hosts or CIDR
        # networks (the ingress pods' range -- CIDR needs uvicorn >= 0.31,
        # the manifest floor; 0.30 read a CIDR as "not an IP" and trusted
        # nothing, silently), or "*" only when nothing but the proxy can
        # reach the pod.  The default is uvicorn's own default, so declaring
        # the key moved nothing: every deployment before it trusted loopback
        # alone.  Never trust a range a client can reach the pod from
        # directly -- X-Forwarded-For is then a header the client writes,
        # and every per-address limit becomes an address the attacker picks.
        # A TLS-PASSTHROUGH route is that case too: the router is a TCP
        # proxy and never writes the header, so the pod must trust nobody
        # (the Helm overlays spell this default as a value, and
        # tests/test_forwarded_headers_need_an_http_router_2026_09_29.py
        # refuses a range unless every Route is edge/reencrypt with
        # set-forwarded-headers: replace).
        "forwarded_allow_ips": "127.0.0.1",
    },
    "paths": {
        "data_dir": "/usr/local/querystudioapi/nfs/data",
        "parquet_dir": "/usr/local/querystudioapi/nfs/data/parquet",
        "downloads_dir": "/usr/local/querystudioapi/nfs/data/downloads",
        "db_file": "/usr/local/querystudioapi/nfs/data/parquet_query_engine.db",
        "secret_key_file": "/usr/local/querystudioapi/nfs/data/secret.key",
        "upload_dir": "/usr/local/querystudioapi/nfs/data/uploads",
        "duckdb_temp_dir": "/usr/local/querystudioapi/nfs/data/tmp/duckdb",
        "duckdb_extension_dir": "/usr/local/querystudioapi/nfs/data/duckdb_extensions",
        "download_temp_dir": "/usr/local/querystudioapi/nfs/data/tmp/downloads",
        # 2026-08-04 discoverability — DuckDB spill dir; "" = derive from duckdb_temp_dir (multi_worker_executor.py _resolve_spill_dir).
        "duckdb_spill_dir": "",
    },
    "query_engine": {
        "chunk_size": 100000,
        "max_workers": 0,
        "query_timeout_seconds": 1800,     # 30 min; 0 = no limit
        # BF-584 (2026-05-29): defaults raised so typical interactive
        # usage doesn't hit 429s.  Pair with queue-wait timeout so
        # bursts beyond the cap WAIT rather than fail.
        "max_concurrent_per_user": 5,      # max parallel queries per user (BF-600-M5: 50→5)
        "max_concurrent_global":   200,    # system-wide max active queries
        "max_queue_size":          200,    # max queries WAITING per user
        # BF-584: how long a queued query waits before giving up with
        # 503.  0 disables queueing (legacy: refuse immediately at cap).
        "queue_wait_timeout_seconds": 60,
        # 2026-10-07: places in the POD-WIDE fair queue an interactive run
        # (/api/execute, /api/sql/execute, business-report execute, dataset
        # preview) takes when the pod is at max_concurrent_global -- FIFO
        # across users, at most max_concurrent_per_user places per user,
        # waiting up to queue_wait_timeout_seconds.  Full queue = the same
        # 503 + Retry-After as before.  0 = no queue: refuse at once (the
        # pre-2026-10-07 answer).  Published-API roads never queue here.
        "global_queue_size":       200,
        "duckdb_threads_per_query": 0,     # 0 = auto (use all CPU cores). Set explicit positive int to cap. BF-378.
        "duckdb_memory_limit_mb": 2048,    # per-query memory cap in MB (2GB default); 0 = unlimited
        # SQL dialect translation — auto-transpile cross-platform SQL to DuckDB.
        # Users write SQL once for Starburst/Snowflake/Trino; it runs unchanged there
        # and is automatically converted to DuckDB syntax for CQB/BQB local execution.
        "sql_translation": {
            "enabled": True,          # master switch; false = pass SQL through unchanged
            "source_dialect": "auto", # "auto" (detect from SQL patterns) | "mysql" | "spark"
                                      # | "trino" | "presto" | "hive" | "snowflake" | "tsql"
                                      # | "oracle" | "bigquery" | "postgres" | "databricks"
        },
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "memory_pressure_threshold":    0.9,
    },
    "s3": {
        "default_region": "us-east-1",
        "handler_cache_ttl_seconds": 60,    # 2026-06-16 — single TTL for ALL auth modes (was 45min for temp-creds only).  Stale config self-clears within 60s without cross-worker coordination.
        "default_onprem_access_mode": "presigned",  # "presigned" (boto3 pre-signs, safe for hive partitions) or "native" (DuckDB S3 creds)
        "parallel_download_workers": 32,    # threads for parallel presigned URL signing + file downloads (BF-255: was 8 — too low for proxy-bound 1000-file scans)
        "download_retries":          3,     # per-file retry attempts for transient S3 errors (503, throttling, network)
        "download_timeout_seconds":  120,   # per-file read timeout for boto3 downloads (seconds)
        "min_free_disk_gb":          1.0,   # fail-fast if less than this much free space before download
        # ── BF-578 (2026-05-29) — production-safe pre-download defaults ──
        # Audit found these were 0 (uncapped / always-fire) and could
        # land 50+ GB on the local pod for a single bad query.
        # New defaults: HARD CAP at 20 GB AND skip pre-download for
        # tiny scans (≤10 files — let httpfs stream those directly).
        "predownload_max_disk_gb":   20.0,  # hard cap; refuse if projected > this
        "predownload_skip_threshold": 10,   # ≤N files post-prune → skip pre-download (httpfs streams)
        "predownload_warn_mb":       1024.0,  # warn at 1 GB per call
        # 2026-06-18 -- VPC-endpoint forcing master switch.
        # When True (default): VPC endpoints force boto3 pre-download
        # because DuckDB httpfs URL-encodes '=' in hive partition
        # paths (year=2024 -> year%3D2024) which breaks SigV4 ->
        # SignatureDoesNotMatch on every file.  When False: VPC
        # endpoints still go through DuckDB httpfs native -- use this
        # if your DuckDB version doesn't have the URL-encoding bug
        # OR your tables aren't hive-partitioned.
        # 2026-06-24 -- file-count threshold for the
        # schema-evolution -> union_by_name=true auto-enable.  See
        # the property accessor above for details.
        "union_by_name_max_files": 200,
        # 2026-08-20 -- DECLARED so the stage guard can see it.  The knob is
        # live (property accessor below reads get("s3","footer_stats_enabled",
        # True) and duckdb_views gates footer-stats collection on it), but it
        # was absent from _DEFAULTS, so tests that compare "config value" to
        # "code default" resolved the default to None and early-returned.
        # A config setting it false passed the guard that exists to catch
        # exactly that.  Value matches the inline fallback: no change.
        "footer_stats_enabled": True,
        # 2026-09-07 — DECLARED, same shape as footer_stats_enabled above
        # and for the same reason: the sibling knob that decides WHEN
        # footer-stats pruning engages had no _DEFAULTS entry at all, so
        # the env route could not carry it and a "config vs code default"
        # guard resolved the default to None.  Value = the accessor's
        # inline fallback (Phase 139 lowered it 100 → 8); effective value
        # measured 8 before and 8 after.
        "footer_stats_min_files_threshold": 8,
        # 2026-06-24 -- flipped from True to False.  Operator verified
        # on the pod that DuckDB httpfs reads s3:// URLs natively
        # (no presigning) against the bucket.-prefixed VPCE endpoint
        # with path-style + creds.  The libcurl '=' URL-encoding bug
        # this defaulted-True was hedging against does NOT fire with
        # the bucket-prefix + path-style combination -- it was an
        # artefact of the older virtual-hosted-against-generic-VPCE
        # setup.  The presigning workaround now ACTIVELY HARMS prod
        # (the presigned URL GETs return HTTP 0 / CURLE_GOT_NOTHING)
        # so default OFF.  Flip to True to re-enable the legacy
        # presign-then-stream path for deployments that need it.
        "force_boto3_for_vpc":       False,
        # Operator-opt-in worker ceiling.  0 (default) = honour
        # parallel_download_workers literally.  >0 = clamp workers
        # to max(workers_per_cpu_min, cpus * workers_per_cpu) so
        # tiny pods don't thrash.
        "workers_per_cpu":           0,
        "workers_per_cpu_min":       2,
        # ── DEPRECATED ALIAS (2026-09-21, FB-55) ─────────────────────
        # This is no longer the name of the plain-parquet file-count
        # ceiling.  ``s3.max_files_per_query`` below is, and
        # ``core/scan_budget.resolve_scan_budget`` is the only thing
        # that resolves either: this key is honoured ONLY when that one
        # is off, so a deployment that deliberately set a ceiling keeps
        # it and no deployment ends up holding two answers.
        #
        # WHY THE DEFAULT IS NO LONGER 1000.  BF-578 (18964923,
        # 2026-05-29) lowered it from 5000 with this reason: "lower
        # scan_budget_hard so the file-count warning at
        # duckdb_views.py:2181 fires BEFORE the 5000-file listing cap at
        # s3_utilities.py:381 hides the over-fetch."  At that time the
        # gate was a WARNING followed by ``pq_files[:_hard]`` and
        # ``list_s3_parquet_files`` stopped at a hardcoded 5,000 keys —
        # so a 5,000 budget could never fire, and the 1,000 was chosen
        # to make a LOG LINE REACHABLE.  Both halves of that premise are
        # gone: f8ed9bf1 (2026-07-06) turned the truncation into a hard
        # REFUSAL, and 82231705 (2026-09-06) deleted the 5,000-key
        # silent listing cap in favour of complete enumeration inside
        # ``listing_max_files`` (50,000) with a refusal above it.  The
        # workaround outlived its bug by eleven weeks and, in between,
        # changed from throttling a log line into refusing queries.
        #
        # Neither line number in that comment still points at what it
        # named — a comment that names a line is not a line.
        "scan_budget_hard":          0,  # DEPRECATED alias of s3.max_files_per_query; 0 = off
        # 2026-08-03 — read-strategy SHADOW observer.  Default OFF.
        # Emits one "[read-strategy-shadow]" line per query attributing the
        # two independent sources of local-disk bytes (whole-file COPY vs
        # DuckDB SPILL) and reporting whether the projected row-group reader
        # could replace an active copy.  Observation only — it changes no
        # behaviour.  Env override: QS_S3_READ_STRATEGY_SHADOW=1.
        "read_strategy_shadow":      False,
        # 2026-08-04 discoverability — boto3 connection-pool size; 0 = auto-size (duckdb_subprocess.py + s3_storage.py both read with 0).
        "max_pool_connections":      0,
        # 2026-08-04 discoverability — union_by_name on read_parquet (config.py duckdb_union_by_name_* properties, both default False).
        "duckdb_union_by_name_iceberg": False,
        "duckdb_union_by_name_parquet": False,
        # 2026-09-06 footer-stats latency.  The pruning pass reads one
        # parquet footer per surviving file; both of these bound what
        # that costs in ROUND TRIPS rather than in bytes.
        #   footer_stats_workers      — fan-out for the per-file reads
        #                               (0 = built-in 16; 1 = serial, the
        #                               pre-2026-09-06 behaviour).
        #   footer_stats_probe_bytes  — size of the single suffix GET that
        #                               returns footer + size + ETag
        #                               together (0 = built-in 64 KiB).  A
        #                               footer larger than this costs one
        #                               extra ranged read, never a re-read.
        "footer_stats_workers":      0,
        "footer_stats_probe_bytes":  0,
        # ── 2026-09-20 HIVE/PARQUET SCAN BUDGET — a GATE, not a cap ──────
        # ``iceberg.max_files_per_query`` has existed since BF-316; the
        # hive/parquet path — the one that actually fell over at 4,000 files
        # — had no equivalent.  This is the equivalent, and the distinction
        # the house is firm about is spelled out because the two are
        # identical in code and opposite in meaning:
        #
        #   A CAP THROTTLES.  A CORRECTNESS GATE FAILS.  This is a GATE.
        #
        # It REFUSES above the budget.  It never truncates and never samples
        # — ``list_s3_parquet_files`` once stopped at 5,000 keys and served
        # the SUBSET with a 200, and the rows it dropped were the
        # lexicographic TAIL rather than a sample.  It is evaluated strictly
        # AFTER pruning, because truncate-then-prune yields a WRONG island
        # rather than a small one.
        #
        # DEFAULT 0 = OFF (measure and log only), matching the iceberg
        # precedent, and deliberately so: 7,300 files is NOT too many files.
        # Measured 2026-09-20, it reads in 5.5 s once
        # ``httpfs_connection_caching`` stops DuckDB opening two TCP
        # connections per file.  This budget exists for the estate where a
        # scan genuinely cannot be served, so the operator gets a refusal
        # naming a remedy instead of a pod that dies mid-query.
        # 2026-09-21 (FB-55) — THIS IS NOW THE ONLY NAME FOR THIS
        # CEILING, and it governs EVERY road that reads plain parquet:
        # federation (dataset execute), the registered-view / SQL route
        # and the streaming route.  It used to govern federation alone
        # while ``s3.scan_budget_hard`` (shipped 1000) governed the SQL
        # route, so the SAME table with NO filters answered 200 on one
        # road and refused on the other — measured side by side on a
        # 7,300-file table.  A DECISION MADE TWICE IS A BUG.
        # ``core/scan_budget.resolve_scan_budget`` is the one resolver;
        # ``scan_budget_hard`` survives only as a deprecated alias,
        # honoured when this key is 0.
        "max_files_per_query":       0,
        # ── 2026-09-21 SCAN RETRY — a BOUNDED, DECLARED retry ───────
        # The transport fix (httpfs_connection_caching) made the 7,300-file
        # scan possible; a RESIDUE remained at 9 runs in 12, arriving as
        # ``InternalException: Information loss on integer cast: value -N``
        # — httpfs computing a negative length in its ERROR PATH after a
        # connection-layer failure.  DuckDB does not retry that itself,
        # because it is not classified as an I/O error, so ``http_retries``
        # cannot reach it.  The CALLER can: measured 9/12 -> 12/12 with one
        # retry on a fresh connection, and the failures fail FAST (2.8-6.7 s
        # against an 8.8-9.1 s success) so the retry is not "3x slower and
        # still broken".
        #
        # RETRY SAFETY IS A DECLARATION, NOT A DEFAULT.  This applies to ONE
        # declared call site (the S3 federation scan), only to a statement
        # that PARSES as read-only, and only to the signatures declared in
        # ``core/s3_scan_retry.py``.  A ``TruncatedScanRefusal`` /
        # ``ScanBudgetRefusal`` is checked FIRST and passes straight through:
        # retrying a correctness refusal re-asks a question the system
        # declined to answer, and this codebase has that exact scar.
        #
        #   scan_retry_attempts        TOTAL attempts including the first.
        #                              1 = OFF (no retry), 2 = one retry
        #                              (the default and what was measured),
        #                              capped at 5 in code so a config typo
        #                              cannot turn a dead endpoint into a
        #                              five-minute hang.
        #   scan_retry_backoff_seconds Wait between attempts.  Small on
        #                              purpose: the disease is per-attempt
        #                              connection churn, not a rate limit,
        #                              and a fresh connection is the remedy.
        "scan_retry_attempts":          2,
        "scan_retry_backoff_seconds":   1.0,
        # ── 2026-10-06 REMOTE I/O CONCURRENCY — requests in flight per QUERY ──
        # A DuckDB engine reads at most ``threads`` remote files at once, and
        # every engine was sized for the CPU (cgroup cpus-1, divided across
        # workers): 2 threads on the rig.  On AWS (~150 ms a request) the
        # owner's one-COB join read 1,345 files two at a time -- 405 s, where
        # Trino took 2.8 s.  On MinIO over the Docker LAN a request costs
        # ~1 ms, so it never showed.  This is the per-QUERY budget of reads in
        # flight; each worker gets its share (budget / workers), never more
        # than the files it reads, never less than its CPU threads, and
        # capped by its memory_limit (core/s3_http_transport.py
        # ``remote_io_threads``).  Only engines reading REMOTE files (s3://,
        # https://) are raised; a local / pre-downloaded scan is untouched.
        # DUCKDB_THREADS / duckdb_threads_per_query size the CPU value it
        # starts from, they do not cap it (a thread waiting on a round trip
        # burns no CPU).  0 = off (threads stay CPU-sized, the
        # pre-2026-10-06 behaviour).
        "remote_io_concurrency":        32,
        # 2026-10-06 -- and no more of that budget than the engine's
        # memory_limit can carry at this many MB per thread (DuckDB's own
        # minimum guidance).  Measured: a 244 MB engine raised to 15 threads
        # for I/O failed the owner's heavy GROUP BY with OutOfMemory on AWS;
        # at 125 MB/thread it gets 1 and spills.  Fewer requests in flight,
        # never an engine that cannot spill.
        "remote_io_memory_per_thread_mb": 125,
        # ── 2026-09-06 S3 LISTING BUDGET — the 5000-file data-loss cap ──
        # ``list_s3_parquet_files`` used to stop at a hardcoded 5000 keys and
        # return the SUBSET, so a table over that size answered HTTP 200 with
        # FEWER ROWS than it holds.  Measured 2026-09-06: nothing breaks at
        # 5001 — 50,000 keys is 50 LIST round trips, 74 ms of walk CPU, 8.4 MB
        # retained and a 4.2 MB / 359 ms read_parquet path list; DuckDB
        # accepts 200,000 paths.  The number was arbitrary, and it was buying
        # a resource guard the resource did not need with a correctness loss.
        #   listing_max_files       — key budget for a FULL enumeration.
        #                             0 = unlimited (and 0 must NOT fold into
        #                             "empty" — see resolve_listing_budget).
        #   listing_max_seconds     — wall-clock budget for the same walk, so
        #                             a slow endpoint cannot hang a query.
        #                             0 = no time guard.
        #   refuse_truncated_listing— True (default): a full enumeration that
        #                             cannot complete inside the budget raises
        #                             TruncatedScanRefusal instead of serving
        #                             a subset.  A cap may THROTTLE; this is a
        #                             correctness gate and it must FAIL — the
        #                             same posture s3.scan_budget_hard already
        #                             takes one layer later.  False restores
        #                             the pre-2026-09-06 flagged-subset
        #                             behaviour for operators who have chosen
        #                             KNOWN-INCOMPLETE results.
        # Explicit small ``max_files`` (schema/partition probes pass 1/3/5)
        # are SAMPLE requests and never refuse.
        "listing_max_files":         50000,
        "listing_max_seconds":       60.0,
        "refuse_truncated_listing":  True,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "allow_partial_results":                 True,
        "allow_stale_list_on_failure":           True,
        "cache_atomic_writes":                   True,
        "cache_encryption_enabled":              False,
        "cache_encryption_key_source":           'config',
        "circuit_breaker_cooldown_seconds":      30,
        "circuit_breaker_enabled":               True,
        "circuit_breaker_threshold":             5,
        "circuit_breaker_window_seconds":        60,
        "column_pruning_download":               'auto',
        "estimate_enabled":                      True,
        "estimate_mode":                         'threshold',
        "estimate_threshold":                    200,
        "file_cache_dir":                        '/usr/local/querystudioapi/nfs/data/s3_file_cache',
        "file_cache_enabled":                    True,
        "file_cache_eviction_interval_hours":    1,
        "file_cache_max_gb":                     20,
        "file_cache_ttl_hours":                  8,
        "file_cache_validate_etag":              True,
        "footer_stats_dir":                      '/usr/local/querystudioapi/nfs/data/s3_footer_stats',
        "footer_stats_ttl_hours":                24,
        "graceful_degradation_enabled":          True,
        "parallel_predownload_for_query":        False,
        "partial_result_threshold":              0.8,
        "perf_audit_enabled":                    True,
        "perf_audit_retention_days":             90,
        "scan_budget_soft":                      500,
        "scan_quota_admin":                      0,
        "scan_quota_analyst_daily":              50000,
        "scan_quota_analyst_hourly":             10000,
        "scan_quota_api_key_daily":              25000,
        "scan_quota_api_key_hourly":             5000,
        "scan_quota_viewer_daily":               10000,
        "scan_quota_viewer_hourly":              2000,
        "scan_quotas_enabled":                   False,
        "suggest_partitions":                    True,
    },
    # BF-257 — Persistent S3 file cache (QueryStudio-side "compaction equivalent").
    # When enabled, files downloaded via boto3 pre-download stay on local NFS
    # so subsequent queries on the same files skip the S3 round-trip entirely.
    # Iceberg data files are IMMUTABLE — same s3://bucket/key always resolves
    # to byte-identical content — so a path-based cache is safe with no ETag
    # check needed.  This is exactly what Trino's split-cache / Snowflake's
    # warehouse cache does, just using your NFS PVC instead of SSDs on each
    # worker.  Background scheduler evicts LRU entries when size exceeds
    # ``max_size_gb``.  Disabled by default — admin opt-in.
    "s3_local_cache": {
        "enabled":        False,                                                # opt-in
        "cache_dir":      "/usr/local/querystudioapi/nfs/data/s3_cache",        # PVC-backed
        "max_size_gb":    100,                                                  # evict oldest when over
        "evict_interval_minutes": 30,                                           # how often to run LRU sweep
        "min_free_disk_gb": 5.0,                                                # never write if free < this
    },
    # BF-428 — Pluggable S3 reader strategies.  Picks HOW S3 parquet/iceberg
    # gets read: direct httpfs, full pre-download, smart pre-download (footer
    # + col chunks), pyarrow+s3fs (boto3 column projection), S3 Select
    # (server-side WHERE), or Athena (server-side full SQL).  See
    # core/s3_readers/__init__.py for the architecture.  ``"auto"`` =
    # let the router pick per query.
    "s3_readers": {
        "default":                       "auto",       # auto | direct_httpfs | full_predownload | pyarrow_s3fs | smart_predownload | s3_select | athena
        "auto_route_enabled":            True,         # Phase F kill-switch — set False to use simple proxy-on/off heuristic
        "per_connection":                {},           # {connection_id_str: reader_name} — admin-pinned overrides
        "athena_workgroup":              "primary",
        "athena_database":               "",           # required to enable Athena reader
        "athena_output_location":        "",           # s3://bucket/path/ — required to enable Athena reader
        "athena_poll_interval_seconds":  1.0,
        "athena_timeout_seconds":        300,
        "s3_select_max_file_bytes":      5368709120,   # 5 GiB — S3 Select hard limit
        "pyarrow_max_rows":              50000000,     # 50M — memory guardrail; truncates above
        "pyarrow_default_region":        "us-east-1",  # used when boto client has no region
        "integration_enabled":           False,        # MASTER SWITCH (AWS path) — flip to True after smoke testing
        "presigned_router_enabled":      False,        # MASTER SWITCH (on-prem presigned path) — independent opt-in
        "onprem_pyarrow_enabled":        False,        # MASTER SWITCH (on-prem PROJECTED read via pyarrow+s3fs) — default OFF; fail-open to predownload
        # BF-428J — knobs the audit found hardcoded
        "enabled_readers":               ["*"],        # ["*"] = all; ["pyarrow_s3fs", "athena"] = subset
        "fallback_when_proxy_active":    "full_predownload",  # simple auto-select pick when proxy on
        "fallback_when_proxy_off":       "direct_httpfs",     # simple auto-select pick when proxy off
        "cost_overrides":                {},           # {reader: {setup_cost, per_byte, per_file}}
        "byte_fraction_overrides":       {},           # {reader: float} — % of file bytes that transit our process
        "estimated_default_file_bytes":  104857600,    # 100 MiB — fallback file size when no estimator
        "athena_fetch_batch_size":       1000,         # rows per fetchmany call
        "pyarrow_connect_timeout_seconds": 10,         # s3fs/boto connect timeout
        "pyarrow_read_timeout_seconds":  60,           # s3fs/boto read timeout
        "pyarrow_max_attempts":          3,            # s3fs/boto retry count
        "pyarrow_sts_refresh_attempts":  1,            # rebuild s3fs on ExpiredToken N times
        "smart_cache_namespace":         "smart",      # sub-bucket under cache_backend for smart predl
        "cache_parquet_compression":     "snappy",     # snappy | zstd | gzip | lz4 | brotli | none
        "arrow_temp_prefix":             "qs_arrow_",  # temp-parquet name prefix for arrow materialisation
    },
    # BF-382 — Result Cache (Option D).  Caches FINAL query results
    # keyed by SHA256(SQL + params + snapshot_fingerprint).  Repeat
    # queries on stable data return in <50ms instead of re-executing.
    # Auto-invalidates when the underlying Iceberg snapshot rolls
    # forward (snapshot_id is in the key).  Two-tier (L1 in-memory +
    # L2 parquet on PVC).  Skips non-deterministic SQL (NOW(), etc.)
    # and results above max_result_mb.
    "result_cache": {
        # 2026-08-20 -- DECISION RECORDED, not silently inherited.
        # 2c86f510 flagged that config.example.json shipped this false while
        # the code default is True, and that the example's own comment warned
        # multi-pod operators "should NOT enable this until a shared backing
        # store (Redis) is wired".  Deleting the example would otherwise have
        # resolved that open question by accident.  The operator was asked
        # directly and answered "if its require tru thn keep it" -- and the
        # live config.json already carried enabled: true.  So: stays True by
        # DECISION.  A multi-pod deployment without shared Redis gets
        # process-local caching; revisit here if that becomes a correctness
        # problem rather than a hit-rate one.
        "enabled":              True,                                               # BF-391: default ON — fail-open at every error path
        "cache_dir":            "",                                                 # blank = <data>/result-cache
        "max_entries_l1":       100,                                                # in-memory cap
        "max_size_gb_l2":       10,                                                 # on-disk cap (LRU evict)
        "default_ttl_seconds":  3600,                                               # 1h; per-query override possible
        "max_result_mb":        100,                                                # don't cache big result sets
        "skip_patterns":        [],                                                 # admin regex patterns to skip
        # 2026-09-07 -- the DATASET/REPORT road (core/dataset_result_cache).
        # Separate from "enabled" so an operator can darken THIS road
        # without also darkening the SQL editor's cache, which is a
        # different consult with a different key.  Declared here because a
        # knob no _DEFAULTS entry names is a knob no guard can see.
        "dataset_path_enabled": True,
        # None/absent = inherit default_ttl_seconds.  A report is read far
        # more often than the data behind it changes, and staleness on this
        # road is CHECKED on every hit (not merely aged out), so the TTL is
        # a backstop rather than the invalidation.
        "dataset_path_ttl_seconds": None,
        # 2026-09-07 -- may a cached body be served when its source's
        # freshness CANNOT be established (a SQL connector has nothing
        # cheap to fingerprint)?  0 = never, and that is the default:
        # the dataset/report road always re-executed before the cache
        # existed, so silently converting that into "up to an hour
        # stale" would change a contract nobody asked to change.  Set
        # this to the number of seconds you are willing to be wrong
        # for; such a serve is still disclosed as cache_freshness
        # "unknown", never upgraded to "verified".
        "serve_unverifiable_seconds": 0,
        "per_user_namespacing": False,                                              # BF-392: mix username into cache key (set TRUE when row_security.enabled=true so principals never share entries)
    },
    # BF-383 — Multi-worker query execution (Option F).  Splits the
    # post-pruning file list into N chunks; each chunk runs in its own
    # DuckDB subprocess in parallel.  Results merged by coordinator.
    # Supports SELECT/WHERE/agg/GROUP BY/HAVING; JOINs handled via
    # partition-aligned (Phase 144) or broadcast-JOIN (Phase 141/143).
    "multi_worker": {
        # ── Declared 2026-10-07 ─────────────────────────────────────
        # Read by production through an idiom the declared-config guard
        # could not see (an aliased getter, a 3-arg forwarding wrapper,
        # or a get_section sub-dict chain).  VERBATIM from the read site.
        "partial_agg_decomposition": False,   # query_splitter.py / multi_worker_dispatcher.py
        "sketch_partials":           False,
        "sketch_max_groups":         50000,   # query_splitter._SKETCH_MAX_GROUPS_DEFAULT
        # 2026-08-20 -- DECISION RECORDED.  Same flagged pair as
        # result_cache.enabled above: the deleted example shipped false with
        # "flip enabled=true after operator validation".  Operator confirmed
        # true is wanted, and the live config.json already had it.  Stays
        # True by decision, not by the example simply going away.
        "enabled":              True,                                               # BF-391: default ON — only fires when splittable + files ≥ threshold
        "max_workers":          4,                                                  # parallel DuckDB processes
        "min_files_to_split":   50,                                                 # don't split tiny queries
        "max_files_per_worker": 5000,                                               # cap per chunk
        "fallback_on_error":    True,                                               # on partial failure, retry single-worker
        # Phase 141/143 — broadcast-JOIN.  When TRUE the dispatcher also
        # splits JOIN queries by replicating the small (< broadcast_max_rows)
        # side to every worker.  HAVING is supported via Phase 143-B post-
        # merge filter.  Refuses unsafe shapes automatically: DISTINCT /
        # WINDOW / WITH / ORDER-without-LIMIT / FULL OUTER + small side
        # with > broadcast_max_small_files (default 50).  When a refusal
        # fires the dispatcher gracefully falls back to single-worker —
        # so flipping this on is ZERO downside for unsupported queries
        # and a 4-8x speedup for the supported ones.
        #
        # 2026-06-03 — default flipped to True.  Previously False as
        # "alpha, opt-in after validation" but operators reported 3000-
        # file JOIN queries silently routing to single-worker because
        # this guard was never flipped on.  Internal guards make the
        # default safe; admins who want the old refuse-all behaviour
        # explicitly set false.
        "allow_broadcast_join":        True,
        "broadcast_max_rows":          10_000_000,
        "broadcast_max_small_files":   50,
        # Phase 144 — partition-aligned JOIN.  When TRUE and both tables
        # share the same Hive partition columns AND values, splits each
        # table's file list per partition tuple and gives ONE worker per
        # tuple.  Each worker runs the full JOIN locally — no shuffle, no
        # broadcast, no Spark needed.  This is THE big × big JOIN path that
        # does NOT require Spark Connect.  Correctness contract: related
        # rows (same JOIN key) MUST share partition values on both sides.
        # Refuses LEFT/RIGHT/FULL OUTER JOIN automatically.
        #
        # 2026-07-22 — DEFAULT-ON, now that decide_partition_aligned_join
        # enforces the correctness contract AUTOMATICALLY: it splits ONLY on
        # partition columns that are proven cross-table equi-join keys
        # (_equi_join_columns), so a JOIN not ON the partition column is
        # refused (→ single-worker fallback) instead of producing wrong
        # results.  The planner is fail-CLOSED (unparseable SQL, outer joins,
        # non-co-partitioned tuples, <2 tuples all refuse), so enabling it can
        # only ADD parallelism to provably-safe big×big JOINs, never corrupt a
        # result.  This is the fix for "two 2k-file tables → single worker on 4
        # idle CPUs".  Set back to False to force the pre-2026-07-22 behaviour.
        "allow_partition_aligned_join": True,
        # 2026-07-22 — ESCAPE HATCH for CO-LOCATED tables (fact + fact-extension).
        # The safe default gate splits big×big JOINs only on partition columns
        # that are proven equi-join keys.  A fact table + its extension are
        # co-located (the SAME natural key always lands in the SAME partition on
        # BOTH sides), so a join on the natural key (e.g. transaction_id) is
        # partition-local even though the key isn't the partition column — but QS
        # cannot PROVE that from the SQL.  Set true ONLY when you can guarantee
        # co-location; it lets those joins parallelize.  WRONG setting on
        # NON-co-located tables would drop cross-partition JOIN matches.
        "partition_aligned_trust_colocation": False,
        # 2026-06-03 — when the dispatcher FALLS BACK to single-worker
        # AND file count exceeds this threshold, log a WARNING line
        # tagged ``[multi-worker] SINGLE-WORKER on >N files`` so admins
        # can see in pod logs when a query is genuinely paying the
        # full sequential cost.  The Query Diagnostic UI also flags
        # this in its bottleneck hints.  0 = no warn.
        "single_worker_large_file_warn_threshold": 100,
        # 2026-08-04 discoverability — worker process model: "thread" | "subprocess" (multi_worker_dispatcher reads with default "thread").
        "executor_mode": "thread",
        # 2026-08-04 discoverability — per-worker query timeout seconds (dispatcher + exchange_b1_executor read with default 1800).
        "per_worker_timeout_seconds": 1800,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "streaming_union_merge":    True,
    },
    # SCAN-STRATEGY (2026-06-01) — single source of truth for per-scan
    # execution decisions.  Replaces a patchwork of ad-hoc flags
    # (hard-coded BF-535 smallest-first sort, scattered max_workers reads
    # at 4 call sites, no parallel footer pre-warm) with one coherent
    # block.  See backend/core/scan_strategy.py for the full design.
    #
    # ``profile`` picks the workload shape.  Each profile encodes a
    # *coherent* set of decisions (file_order + worker count + prewarm
    # behaviour + DuckDB pragmas) — NOT a sprawl of independent toggles.
    #
    #   * ``auto`` (default) — strategist picks per call based on caller
    #     + file_count + has_limit.  Feed gen + reports + reconciliation
    #     get ``bulk_scan``; BQB/CQB with LIMIT get ``interactive``;
    #     published-API gets ``low_latency``.
    #   * ``bulk_scan`` — largest-first ordering (so the biggest file
    #     starts early and doesn't become a tail-end straggler),
    #     16 workers, parallel footer pre-warm, DuckDB 8 threads,
    #     boto3 pool 64.  Tuned for the 3000-file VPC-link feed-gen
    #     case where the legacy 4-worker + smallest-first default
    #     was leaving the largest file as the straggler.
    #   * ``interactive`` — smallest-first (so LIMIT pushdown trips
    #     before the giants open), 4 workers, no pre-warm (cache likely
    #     warm anyway), conservative pool.
    #   * ``low_latency`` — published-API.  Cache-first, size-balanced
    #     order, no blocking pre-warm.
    #
    # ``default_file_order`` is the FALLBACK ordering used by callers
    # that haven't been migrated to pass an explicit ScanPlan yet.
    #
    # 2026-06-03 — restored default to ``smallest_first`` after audit
    # caught the BF-535 regression.  ce947c4 (ScanStrategist unification)
    # silently changed this from smallest_first to manifest_order, and
    # the replacement file_order kwarg is wired into ZERO callers
    # (duckdb_views.setup_registered_views, register_s3_views,
    # federation_engine, iceberg_metadata_sync all call get_iceberg_data_files
    # without file_order=, so they get this default).  Manifest-order
    # means DuckDB's LIMIT pushdown can't bail early on small queries —
    # it starts with whatever file the writer committed first (often a
    # giant historical partition).  smallest_first restores the BF-535
    # behaviour so `SELECT ... LIMIT 100` returns fast.
    # Admin can flip back to ``manifest_order`` or to ``largest_first``
    # depending on workload mix; smallest_first is the safe interactive
    # default.
    "scan_strategy": {
        "profile":             "auto",            # auto | bulk_scan | interactive | low_latency
        "default_file_order":  "smallest_first",  # BF-535 restored
        "profiles": {
            "bulk_scan":   {},   # accept built-in defaults; admin fills as needed
            "interactive": {},
            "low_latency": {},
        },
        # 2026-08-04 discoverability — footer pre-warm knobs (scan_strategy.py _prewarm_footers reads the subsection).
        "prewarm": {
            # per-HEAD timeout seconds; matches the function parameter default 5.0 the code keeps when unset.
            "per_head_timeout_s": 5,
            # 2026-08-20 -- the GLOBAL prewarm kill switch, read by
            # prewarm_background_service._global_prewarm_enabled() with an
            # inline True.  Undeclared until now, so the 2026-08-04
            # "discoverability" pass above missed the one knob in this
            # subsection an operator actually reaches for.
            "enabled": True,
        },
    },
    # 2026-06-03 — pre-flight resource admission.  User request:
    # 'should run query whatever resources available'.  Probes live
    # system RAM + CPU before dispatch and computes the LARGEST safe
    # (max_workers, per_worker_memory) pair so the query always runs
    # within headroom instead of crashing the box.  Defaults are
    # opt-in but enabled by default.
    "query_admission": {
        "enabled":               True,
        # auto_throttle  — adapts max_workers / memory_limit on the
        #                  fly so the query always runs within
        #                  headroom.  Never refuses.  Recommended.
        # log_only       — log what auto_throttle WOULD have done but
        #                  proceed with the original plan.  Useful for
        #                  a week of observation before flipping on.
        # reject         — raise a typed RuntimeError when cost
        #                  exceeds headroom.  Opt-in for strict envs.
        "policy":                "auto_throttle",
        # Use this fraction of available RAM for the query.  Leaves
        # the remainder for OS file cache + other queries + Python.
        "headroom_factor":       0.7,
        # Refuse-mode floor: if available RAM is below this, refuse
        # under reject policy; under auto_throttle proceed with the
        # most-squeezed plan + log a critical warning.
        "min_free_ram_mb":       2048,
        # Conservative estimate of per-file overhead (DuckDB parquet
        # footer cache + page-index buffers).  2026-06-04 lowered
        # default 4.0 → 2.0 to better match real-world Iceberg parquet
        # files (typical 1-2 MB compressed); the old 4.0 was an upper
        # bound for wide-column tables, but it was over-throttling
        # multi-worker dispatch on tight-RAM boxes (e.g. a 14 GB dev
        # machine running a 4000-file JOIN clamped to 1 worker because
        # the admission estimated 17 GB of footer cache instead of
        # the actual ~8 GB).  Raise back to 4.0 if your tables have
        # many small columns or very wide types.
        "per_file_overhead_mb":  2.0,

        # Phase 150 (2026-06-04) — OS page-cache cost per mmap'd file.
        # DuckDB mmaps every parquet footer; this lives in OS Standby
        # (Windows) / page-cache (Linux) and is NOT bounded by
        # duckdb_memory_limit_mb.  On Windows it's the BSOD vector:
        # kernel runs out of contiguous pages, can't allocate for a
        # driver, blue-screens.  null = let resource_admission pick
        # the platform default (4 MB on Windows, 0.5 MB elsewhere).
        # Tune up if you observe BSODs / OOMs with the default;
        # tune down on Linux servers with abundant RAM.
        "mmap_overhead_mb_per_file": None,

        # 2026-06-03 — pod-level memory ceiling.  Set to the pod's
        # actual memory limit (cgroup) so admission can refuse new
        # queries when in-flight queries' combined memory_limit would
        # exceed this.  0 = auto-detect (cgroup on Linux, psutil
        # elsewhere).  Production OpenShift: set to 25000.  Windows
        # local dev: set to (system_ram_mb − 4096) to leave OS room.
        "pod_memory_cap_mb":     0,

        # Background memory watchdog — samples
        # psutil.virtual_memory().available every N seconds.  When
        # available falls below critical_low_mb, cancels the oldest
        # in-flight query whose memory_limit can recover the gap.
        # Last line of defence against BSOD / OOMKiller.
        "watchdog_enabled":             True,
        "watchdog_interval_seconds":    5,
        # Kernel-OOM safety floor.  On OpenShift (cgroup OOMKiller
        # fires at the cgroup limit) 512 MB is enough.  On Windows
        # the BSOD risk hits earlier — keep this >= 1024 MB.
        # 2026-06-10 — platform-aware default: Windows gets 1024 MB
        # (matches the comment above and prevents the BSOD vector that
        # the 2026-06-03 lowering re-introduced for Windows hosts).
        # Linux / OpenShift stays at 512 since the cgroup OOMKiller
        # gives us another layer of defence the kernel doesn't have
        # on Windows.
        "critical_low_mb":              1024 if _sys.platform == "win32" else 512,
        # 2026-06-04 — auto-throttle floor + bulk-file threshold.
        # Replaces hardcoded magic numbers in resource_admission.
        # When admission must shrink the plan (pod-cap exceeded OR
        # watchdog low-RAM), it uses these floors so a busy box doesn't
        # silently degrade to single-worker on a 3000-file scan.
        "min_workers_when_throttled":   2,
        "min_memory_mb_when_throttled": 512,
        # File count above which we require at least
        # min_workers_when_throttled workers (single worker can't
        # handle thousands of files in reasonable time).
        "bulk_file_threshold":          200,
        # Sweep inflight accountant entries older than this (seconds).
        # Defends against leaked entries from queries that crashed
        # before release_query fired.  0 = never sweep.
        "inflight_max_age_s":           3600,
        # Watchdog action on low-RAM trip:
        #   block_admission  (default — refuse NEW queries; running
        #                     ones continue)
        #   cancel_oldest    (set cancel_event on the oldest in-flight
        #                     query; required on Windows where the
        #                     kernel will BSOD before block_admission
        #                     can drain the running query that's
        #                     consuming memory)
        # 2026-06-10 — platform-aware default: cancel_oldest on Windows
        # (kernel BSOD risk under sustained low-RAM), block_admission
        # everywhere else (cgroup OOMKiller catches the truly runaway
        # case so we don't need the more aggressive action).
        "watchdog_action":              (
            "cancel_oldest" if _sys.platform == "win32" else "block_admission"
        ),
    },
    # 2026-06-04 — loop_watchdog (event-loop stall detector) config.
    # Was hardcoded to 5s threshold; on a busy dev box with browser+IDE
    # + heavy queries the loop briefly stalls under sync work that's
    # NOT a real problem and logs spam.  Raise stall_threshold_seconds
    # to 10-15 on dev; keep 5 in production where every stall matters.
    # Setting enabled=false silences the watchdog entirely.
    "loop_watchdog": {
        "enabled":                  True,
        "stall_threshold_seconds":  5.0,
        "poll_interval_seconds":    1.0,
    },
    # BF-384 — Multi-pod query workers (Option G).  Distributes chunks
    # across SEPARATE pods over HTTP.  Workers are discovered via:
    # (1) static URL list, (2) K8s headless service DNS, or (3) Phase 45
    # worker_registry. Falls back to in-pod F when no pods reachable.
    "multi_pod": {
        # ── Declared 2026-10-07 ─────────────────────────────────────
        # Read by production through an idiom the declared-config guard
        # could not see (an aliased getter, a 3-arg forwarding wrapper,
        # or a get_section sub-dict chain).  VERBATIM from the read site.
        "worker_memory_limit": "4GB",         # core/query_worker_node.py
        # 2026-11-02 -- FALSE: the multi-pod "Worker Pool" (BF-384 / Option G)
        # is RETIRED.  Three roads ran a query off the API pod (this pool, the
        # task_queue executor, query pods); the one road is a QUERY POD of the
        # right size (core/jobqueue, query_pods.classes).  The pool's chart is
        # gone; this code path stays until its removal and is OFF, so
        # multi_pod_state() reads "disabled", never "inert".  (2026-06-24 had
        # flipped it to True on "by default whatever required should be on";
        # nothing ever dispatched to it on a cluster.)  Record:
        # docs/COMPONENT_RESPONSIBILITIES_2026_11_02.html §5.
        "enabled":         False,
        "worker_urls":     [],                                                      # static list: ["http://qs-w-1:8000", ...]
        "k8s_service":     "",                                                      # e.g. "qs-worker-headless.default.svc.cluster.local"
        "k8s_service_port": 8000,
        "worker_port":     8000,                                                    # port for registry-discovered pods
        "shared_secret":   "",                                                      # HMAC secret — set via env QS_WORKER_SECRET in production
        "per_worker_timeout_seconds": 1800,
        "fallback_on_error": True,
        # BF-393 — SQL-connector parallelism (Snowflake/Trino/Starburst/etc).
        # Disabled by default — admins explicitly opt in per cluster.  Each
        # query then either uses these defaults or per-query overrides.
        "sql_connector_enabled":           False,
        "sql_connector_shard_count":       4,                                       # how many shards to split a connector query into
        "sql_connector_shard_strategy":    "bucket",                                # "bucket" or "range"
        "sql_connector_default_shard_column": "",                                   # hint — usually overridden per query (PK/clustering key)
    },
    # BF-385 — Engine Router.  Picks single / multi_worker / multi_pod /
    # spark_connect per query based on configurable rules.  Default rules
    # in core.engine_router.DEFAULT_RULES handle most cases; admins can
    # override the full ruleset here.
    "engine_router": {
        "enabled":        True,                                                     # safe default — uses defaults
        "default_engine": "single",                                                 # fallback when no rule matches
        "rules":          [],                                                       # empty = use DEFAULT_RULES
    },
    # ── Industrialization program (2026-07-23) ─────────────────────────────
    # Phase 0 guardrails for the 100+-concurrent-user / 3k+-file-island
    # productionization roadmap (docs/industrialization_plan_2026_07_23.md).
    # EVERY flag defaults OFF: flag OFF == byte-for-byte today's behavior.
    # The ONE read chokepoint is core.industrialization.flags.is_enabled()
    # — it applies the master switch, the per-flag value, AND the fleet-mode
    # Postgres gate (fleet features refuse to arm on SQLite/Oracle metadata
    # stores and log why, once).  Do NOT read these keys directly elsewhere.
    "industrialization": {
        "enabled":                      False,  # MASTER kill-switch for the whole program
        # Phase 1 — identity + RLS boundary (SECURITY — the shared-work gate)
        "rls_boundary_enabled":         False,
        # Phase 2 — PG job queue substrate (API/executor role split)
        "queue_mode":                   False,
        # Phase 3 — Query Passport + DB-only enumeration + fleet syncer
        "passport_enabled":             False,
        "db_only_enumeration":          False,
        "fleet_syncer_enabled":         False,
        # Phase 4 — coverage-triggered within-island supplement build
        "supplement_on_zero_coverage":  False,
        # Phase 5 — fleet admission + fairness + single-flight
        "fleet_admission":              False,
        "single_flight":                False,
        # Phase 6 — Arrow result artifacts in object store
        "result_artifacts":             False,
        # Phase 7 — adaptive DuckDB degree/caps/spill + forkserver template
        "adaptive_duckdb":              False,
        "forkserver":                   False,
        # Phase 8 — materialized read-optimized islands (derived mirror)
        "materialized_islands":         False,
        # Phase 9 — cost-based routing + calibration
        "cost_routing":                 False,
        # Phase 10 — on-prem immutable file cache + prefetch
        "local_file_cache":             False,
    },
    # ── Industrialization Phase 2 — job-queue TUNING (not flags) ───────────
    # These knobs only matter once industrialization.queue_mode is armed;
    # with the flag OFF nothing reads them on the hot path.  Kept as their
    # own section so the industrialization block stays flags-only (the
    # is_enabled() chokepoint contract).
    "jobqueue": {
        "lease_seconds":        120,   # DB-time lease TTL (executor claim)
        "heartbeat_seconds":     20,   # lease renewed every N s (grace = lease/heartbeat >= 3x)
        "poll_interval_seconds":  1.0, # executor idle poll cadence
        "reap_interval_seconds": 30,   # orphan-reaper cadence (runs inside executor loop; N reapers safe)
        "max_attempts":           2,   # poison-job quarantine bound (terminal FAILED after this many claims)
        "submit_wait_seconds":   30,   # API waits this long for executor pickup, then fails OPEN to inline
        "run_timeout_seconds": 7200,   # executor-side bound watching one execution to terminal state
        # 2026-10-31 (query pods phase 2) -- DRAIN on SIGTERM: the executor
        # claims nothing new and its running jobs get this long (seconds) to
        # finish before the process exits.  0 = derive from the pod's
        # QS_TERMINATION_GRACE_SECONDS (the chart's terminationGracePeriodSeconds)
        # minus 15 s of headroom; neither set = 60.
        "drain_seconds":           0,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "stranded_after_seconds":    300,
    },
    # ── Industrialization Phase 5 — admission/fairness/single-flight TUNING ─
    # These knobs only matter once industrialization.fleet_admission /
    # single_flight are armed; with the flags OFF nothing reads them on the
    # hot path.  Own section, same contract as "jobqueue" above (the
    # industrialization block stays flags-only).
    "industrialization_fairness": {
        "user_max_running":        2,     # per-user concurrency cap (live-lease jobs; rest stay queued)
        "fleet_memory_budget_mb":  0,     # fleet-wide inflight budget (0 = unlimited); empty fleet always admits one
        "lane_promote_seconds":  120,     # starvation bound: a queued job gains one lane rank per N seconds of age
        "default_cost_mb":      2048,     # admission price when no passport history exists (UNKNOWN → worst-case-ish)
        "min_cost_mb":           256,     # floor for passport-priced jobs
        "single_flight_max_leader_age_seconds": 300,  # only attach to leaders younger than this (snapshot-staleness bound)
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "fleet_slot_breaker_cooldown_seconds":    5.0,
        "fleet_slot_lease_seconds":               120.0,
        "fleet_slot_poll_seconds":                0.25,
        "fleet_slot_renew_seconds":               30.0,
        "fleet_slot_sweep_interval_seconds":      10.0,
        "fleet_slot_waiter_ttl_seconds":          90.0,
    },
    # ── Industrialization Phase 3 — fleet-syncer / db-only-enum TUNING ─────
    # These knobs only matter once industrialization.fleet_syncer_enabled /
    # db_only_enumeration are armed; with the flags OFF nothing reads them
    # on the hot path.  Own section, same contract as "jobqueue" above (the
    # industrialization block stays flags-only).
    "industrialization_syncer": {
        "interval_seconds":                  60,    # leader tick cadence
        "max_tables_per_tick":               50,    # watched tables per tick (recency-biased)
        "behind_alarm_min_interval_seconds": 300,   # per-table rate limit on the "syncer behind" ERROR log (counters always rise)
    },
    # ── Industrialization Phase 6 — result-artifact TUNING (not flags) ─────
    # These knobs only matter once industrialization.result_artifacts is
    # armed; with the flag OFF nothing reads them on the hot path.  Own
    # section, same contract as "jobqueue" above (the industrialization
    # block stays flags-only).
    "industrialization_artifacts": {
        "backend":               "local",   # "local" (on-prem/dev — NFS-safe) | "s3" (QS-owned prefix)
        "local_root":            "",        # empty → <data_dir>/result_artifacts
        "spool_dir":             "",        # empty → <data_dir>/artifact_spool (S3 read-side spool cache)
        "inline_threshold_bytes": 5242880,  # results at/below this stay INLINE (today's path — no artifact)
        "ipc_batch_rows":        32768,     # rows per Arrow record batch (the page/range read granule)
        "ttl_seconds":           86400,     # artifact TTL; GC unpublishes after this
        "reader_grace_seconds":  600,       # reader-lease grace — GC never deletes inside a live reader's lease
        "orphan_min_age_seconds": 3600,     # min age before an artifact with no job+execution rows is orphan-reaped
        "gc_interval_seconds":   300,       # GC sweep cadence (runs on the executor/reaper loop)
        "s3_bucket_override":    "",        # empty → app-wide S3 bucket
        "s3_prefix":             "querystudio/artifacts/",  # QS-owned key prefix for result artifacts
    },
    # ── Industrialization Phase 7 — adaptive DuckDB TUNING (not flags) ──────
    # These knobs only matter once industrialization.adaptive_duckdb /
    # industrialization.forkserver are armed; with both flags OFF nothing
    # reads them on the hot path.  Own section, same contract as "jobqueue"
    # above (the industrialization block stays flags-only).
    "industrialization_duckdb": {
        # ── Part 1: adaptive degree off the fleet running-count ────────────
        "quiet_max_running":        2,     # <= this many running -> latency mode (split allowed, wide threads)
        "busy_min_running":         8,     # >= this many running -> throughput mode (no split, narrow threads) — also the top of the hysteresis dead-zone above quiet_max_running
        "latency_threads_cap":      4,     # ceiling on duckdb threads/subprocess when quiet
        "throughput_threads":       2,     # ceiling on duckdb threads/subprocess when busy
        "default_max_workers":      4,     # multi-worker fan-out cap when quiet (latency mode)
        # ── Part 2: hard caps ───────────────────────────────────────────────
        "max_concurrent_subprocesses": 0,  # 0 = unlimited (today).  Per-pod cap on live DuckDB child processes.
        "subprocess_slot_wait_seconds": 30,  # bounded wait for a free slot before proceeding anyway (fail-open — never deadlocks)
        "passport_mem_floor_mb":    512,   # floor for passport-priced memory_limit
        "passport_mem_ceiling_mb":  8192,  # ceiling for passport-priced memory_limit
        # ── Part 3: forkserver template ─────────────────────────────────────
        "forkserver_max_forks":     200,   # recycle the template after this many forks
        "forkserver_max_age_s":     1800,  # ...or after this many seconds, whichever first
        "forkserver_extensions":    ["httpfs"],  # extensions the template pre-loads
        "forkserver_restart_alarm_threshold": 3,  # consecutive boot failures before an ERROR-level alarm log
        # ── Part 4: per-query spill budget ──────────────────────────────────
        "spill_fraction_per_query": 0.25,  # fraction of the pod's resolved spill quota priced to ONE query
        "spill_floor_mb":           256,   # floor for the priced per-query spill quota
    },
    # ── Spill admission (2026-08-04) ────────────────────────────────────────
    # Compares a plan's PROJECTED working set against memory_limit + spill
    # quota BEFORE the child is spawned, so a query that cannot fit is refused
    # with numbers an operator can act on instead of dying tens of GB later on
    # `OutOfMemoryException: failed to offload data block`.
    #
    # Listed here because the previous generation of this knob
    # (scheduler.cleanup_temp_files_seconds) existed only as a Python default
    # with no entry in this block, so operators could not discover it at all.
    #
    #   mode  off      — compute nothing.
    #         observe  — compute + log the verdict; NEVER alters execution.
    #         enforce  — refuse before spawn.
    # Default `observe` for the reason the pruning gate uses: a verifier that
    # is off catches nothing, and observing cannot change a result.  Promote
    # to `enforce` once the logged verdicts are trusted on real traffic.
    "spill_admission": {
        "mode":             "observe",
        # 2026-08-04 — when a BLOCKING plan cannot fit its budget, try to
        # COMPLETE it instead of only refusing: external merge sort for
        # ORDER BY (bounded sorted runs + a k-way streaming merge),
        # partial aggregation for GROUP BY, chunked DISTINCT.  Measured:
        # a 900-col ORDER BY that OOMs single-shot in 2.9 s completes via
        # the route with a row-for-row identical result.
        #
        # Default FALSE: this is new EXECUTION machinery, not a guard, so
        # it stays off until exercised on real traffic — and admission
        # itself is only in `observe`, so nothing reaches it yet anyway.
        # Listed here because a knob absent from _DEFAULTS is one an
        # operator cannot discover (the mistake this file already made
        # with scheduler.cleanup_temp_files_seconds).
        "completion_route": False,
        # Parquet is stored compressed/encoded; a blocking operator holds it
        # DECODED.  Measured 4-12x on this product's data.  Too LOW
        # over-refuses work that would have succeeded — the unforgivable
        # direction — so the default sits mid-range rather than tight.
        "expansion_factor": 8.0,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "completion_chunk_fill":         0.4,
        "completion_max_runs":           128,
        "completion_merge_budget_mb":    256,
    },
    # ── Industrialization Phase 8 — materialized island TUNING (not flags) ──
    # These knobs only matter once industrialization.materialized_islands is
    # armed; with the flag OFF nothing reads them on the hot path (a single
    # is_enabled() read in the reader chokepoint).  Own section, same
    # contract as "jobqueue" above (the industrialization block stays
    # flags-only).  Reuses the Phase-6 artifact-store backend convention
    # ("local" | "s3") so operators configure ONE mental model for both.
    "industrialization_materialized_islands": {
        "backend":                "local",  # "local" (on-prem/dev — NFS-safe) | "s3" (QS-owned prefix)
        "local_root":             "",       # empty → <data_dir>/materialized_islands
        "s3_bucket_override":     "",       # empty → app-wide S3 bucket
        "s3_prefix":              "querystudio/materialized_islands/",
        "min_island_files":       500,      # on-miss heuristic: island must have >= this many raw files to be worth compacting
        "max_build_source_files": 20000,    # hard cap protecting the background build from a runaway island
        "max_build_source_bytes": 107374182400,  # 100 GiB cap
        # FB-48 (2026-09-20): "target_file_mb" REMOVED.  Its own comment said
        # "informational", and it was: the island compactor never read it, so
        # an operator setting it changed no file size anywhere.
        "gc_interval_seconds":    600,      # island GC cadence (rides the executor/reaper loop)
        "stale_grace_seconds":    3600,     # grace after a mirror's snapshot stops being current before bytes are deleted
        "verify_on_route":        True,     # cheap per-file length reconcile before serving a mirror
        "targets":                [],       # manual target list: [{"bucket":.., "table_prefix":.., "partition_tuple":{...}, "connection_id":..}]
    },
    # ── Industrialization Phase 9 — cost-based routing TUNING (not flags) ───
    # These knobs only matter once industrialization.cost_routing is armed;
    # with the flag OFF nothing reads them on the hot path (a single
    # is_enabled() read in core.industrialization.cost_router).  Own section,
    # same contract as "jobqueue" above (the industrialization block stays
    # flags-only).  Policy: small island -> DuckDB single; medium -> DuckDB
    # multi-worker; large (files/bytes over threshold, or footprint over a
    # fraction of the pod RAM budget) -> Spark Connect.  dead_band_pct +
    # dwell_seconds are the hysteresis (a query near a boundary must not
    # flap venues call-to-call); LOW-confidence estimates and over-budget
    # footprints escalate ONE tier toward Spark (fail toward Spark, not OOM).
    "industrialization_cost_routing": {
        "small_max_files":         50,          # island files <= this AND bytes <= small_max_bytes -> DuckDB single
        "small_max_bytes":         536870912,   # 512 MiB
        "large_min_files":         2000,        # island files >= this OR bytes >= large_min_bytes -> Spark Connect
        "large_min_bytes":         21474836480, # 20 GiB
        "dead_band_pct":           0.15,        # +/- 15% band around each threshold pair (hysteresis)
        "dwell_seconds":           120,         # sticky window: keep the prior venue this long inside the dead band
        "pod_budget_fraction":     0.5,         # island bytes >= this fraction of pod RAM total -> forced large/Spark
        # ── calibration loop (estimate vs actual bytes scanned) ────────────
        "calibration_min_samples": 5,           # EMA reaches full influence at this many folded samples
        "calibration_ema_alpha":   0.3,         # EMA smoothing factor (higher = more reactive to recent samples)
        "calibration_min_ratio":   0.125,       # actual/estimate ratios outside [min,max] are outliers -- NOT folded
        "calibration_max_ratio":   8.0,
    },
    # ── Industrialization Phase 9 — partition-bloat view TUNING (not flags) ─
    # Only read by the read-only admin bloat endpoint / Phase-8 work-queue
    # signal; zero cost on the query hot path either way.
    "industrialization_bloat_view": {
        "file_count_threshold":     500,         # partition file_count >= this -> flagged bloated
        "avg_size_threshold_bytes": 33554432,    # partition avg file size <= this (32 MiB) -> flagged bloated
        "max_tables_per_scan":      25,          # cap when bucket/table_prefix is omitted (iterate watched tables)
    },
    # ── Industrialization Phase 10 — on-prem immutable file cache TUNING ────
    # Only read once industrialization.local_file_cache is armed; with the
    # flag OFF nothing reads them on the hot path (a single is_enabled()
    # read in core.onprem_file_cache.cached_download / prefetch).  Own
    # section, same contract as "jobqueue" above (the industrialization
    # block stays flags-only).  Files here are immutable Iceberg data
    # files -- the cache never invalidates on TTL, only LRU-evicts by
    # budget (bytes + entry count).
    "industrialization_onprem_cache": {
        "cache_dir":              "",     # empty -> <data_dir>/onprem_file_cache
        "max_size_gb":            50,     # total on-disk budget
        "max_entries":            200000, # entry-count budget (belt+suspenders vs. tiny-file blowup)
        "max_file_pct_of_budget": 0.25,   # single entry > this fraction of max_size_gb is admitted but marked lowest LRU priority (self-corrects next eviction pass)
        "lock_timeout_seconds":   30,     # cross-process file-lock wait before proceeding lock-free (never deadlocks)
        "inflight_wait_seconds":  120,    # in-process single-flight: waiter timeout before taking over as new owner
        "pin_ttl_seconds":        900,    # soft read-protection window (self-expiring -- bounds any leaked pin)
        "prefetch_enabled":       True,   # sub-toggle under the master flag
        "prefetch_workers":       8,      # bounded background fan-out concurrency
        "prefetch_max_files":     0,      # 0 = no cap (worker pool already bounds concurrency)
    },
    "iceberg": {
        "metadata_cache_ttl_seconds": 60,   # cache resolved metadata key per table (0=disabled). Avoids repeated full scans of metadata/ prefix.
        # 2026-09-06 -- BRAIN OBSERVATIONS.  When true (default) a query
        # that reads an iceberg table records what its scan decided:
        # the per-WHERE-clause prune-support breakdown, the pruning-IQ
        # verdict, a `query_pruning_history` row and the unified scan
        # plan.  That table is the ONLY input `brain_cost_model` (needs
        # >=10 rows) and `brain_skew_detector` (>=5) have; until this key
        # existed the write site sat behind a `keys_only` short-circuit no
        # query could pass, so it held ZERO rows and both were cold
        # forever.  Cost measured on the wire rig: ~0.6 ms of CPU on the
        # request thread, no S3, no synchronous DB -- the insert is a
        # queue.put_nowait drained by a daemon writer.  Set false only to
        # silence the telemetry; routing then stays threshold-based.
        "record_query_observations":      True,
        # 2026-09-06 -- LAZY FRESHNESS TRIGGER, default FALSE.  When true,
        # each iceberg query asks brain_freshness whether the snapshot has
        # rolled past what the supplement/bloom scanners last covered and
        # dispatches a delta scan if so.  Only the SCAN is backgrounded:
        # ensure_fresh first builds an S3 client, calls
        # get_iceberg_snapshot_id_only and runs 3 DB queries ON THE
        # REQUEST THREAD -- measured at +1 S3 GET per iceberg query on
        # the wire rig, spent re-deriving a snapshot id the reader is
        # already holding.  The manifest watcher and the cron scanner keep
        # coverage fresh without that per-query toll, so this is off by
        # default and belongs on only where neither daemon runs.
        "lazy_freshness_on_query":        False,
        # 2026-09-06 -- DURABLE SCAN PLAN, default FALSE.  When true, each
        # iceberg table read inside a query writes its unified PruneContext
        # to query_scan_plans with a synchronous SELECT + INSERT/UPDATE +
        # COMMIT.  Measured at query cadence on local sqlite: p50 3.1 ms,
        # max 30 ms per table per query -- roughly 200x the rest of the
        # observation combined, and it feeds the scan-plan SCREEN, not the
        # routing brain.  /api/admin/queries/scan-plan reads the in-memory
        # context first, so with this off an operator still gets the plan
        # for a query that just ran; only survival across a pod restart is
        # lost.  Turn it on where durable plans are worth a synchronous DB
        # write inside the query path.
        "persist_scan_plan_on_query":     False,
        # 2026-07-13 — column-stats storage GRAIN.  The v2 supplement stores
        # ONE ROW PER (file × column); a 3000-file table with 40 columns =>
        # ~120,000 rows.  The per-file grain (v3) mirrors the Iceberg-native /
        # Starburst encoding: ONE ROW PER FILE with every column's min/max/null
        # packed in a JSON map => 3000 rows.  The FULL v3 read+write path is
        # implemented, parity-tested vs v2, and fail-CLOSED (empty/incomplete
        # v3 for a snapshot → S3 manifest walk, so results stay correct).
        # DEFAULT "v3": every column-stats reader routes through the single
        # grain chokepoint (get_col_stats_for_snapshot_via_store) which reads
        # the per-file table.  ALL read paths FAIL-CLOSED to the S3 manifest
        # walk when v3 is empty/incomplete for a snapshot, so a not-yet-scanned
        # table stays CORRECT (just not brain-accelerated until the scan or
        # DatabaseManager.iceberg_file_stats_backfill_from_v2() fills it — and
        # the BF-547 on-demand scanner auto-populates v3 on first use).
        #   "v3"   (default): write + read the per-file iceberg_file_stats_v3.
        #   "both": write BOTH, READ v2 (validation).
        #   "v2":   legacy (file × column) write + read (emergency rollback).
        "file_stats_grain":               "v3",
        # ISLAND-FIRST partition pushdown (2026-07): carve the partition island
        # in SQL (partition_values[col] IN ...) instead of loading the whole
        # table's per-file stats and filtering in Python.  off | shadow | on.
        #   "on"     (default): engage for identity string/date eq/IN partition
        #            predicates when the DB holds the full snapshot; fail-open
        #            superset (NULL/un-captured rows always kept) → never loss.
        #   "shadow": dual-load, assert island ⊆ ocean + alarm on mismatch,
        #            SERVE the ocean result (rollout validation, no perf gain).
        #   "off":   hard kill switch — always the whole-table load.
        "partition_island":               "on",
        # NO-OCEAN-SCAN CONTROL (2026-07): when true, a query that would
        # full-scan a PARTITIONED iceberg table is REFUSED (fail closed) instead
        # of silently reading the whole ocean.  Fires on either shape: (A) a
        # WHERE predicate on a partition column that couldn't be matched to the
        # spec (detection failure), or (B) no partition filter at all on a
        # partitioned table.  An engaged partition filter that legitimately keeps
        # every file (single partition) is NEVER blocked.  Default "false" =
        # observe-only (logs a PARTITION-PRUNING ALARM + stamps
        # _out_meta["partition_pruning_alarm"]); flip to "true" once the alarm
        # telemetry is clean to guarantee no query ever dives into the ocean.
        "require_partition_pruning":       "false",
        # 2026-08-03 — ACCIDENTAL ocean dives only.  Refuses a scan when a
        # partition predicate WAS supplied but the engine failed to use it
        # (case A / identity-resolution failure) — an engine defect, and the
        # shape that silently turned a ~10-file island read into a 14552-file
        # ocean scan in production.  It deliberately does NOT refuse case B
        # (a query with no partition filter at all), because a full scan is
        # the CORRECT answer there; conflating the two is why
        # require_partition_pruning could never be switched on.
        "block_accidental_ocean_dive":     "true",
        # Refuse an accidental dive only once it is big enough to hurt.  A
        # detection failure on a small table costs nothing; on 14552 files it
        # OOM-killed a pod.  Threshold on when to REFUSE — never a cap on
        # pruning, which is always attempted at any size.
        "accidental_ocean_dive_min_files":  1000,
        # BF-503 (2026-05-28) — when True, even cache HITS perform a
        # cheap version-hint.text GET (~5-10ms per S3 round-trip) to
        # verify that the live Iceberg pointer hasn't advanced since
        # the cache was populated.  If it has, the cache entry is
        # invalidated and we re-resolve the latest metadata key.
        # User complaint that prompted this: "should not rely 100%
        # on local cache...go n verify s3 iceberg metadata also".
        # Default True for correctness; set False if the per-query
        # latency cost (one S3 GET per table) is unacceptable in
        # high-throughput environments where 1-minute staleness is OK.
        "cache_pointer_verification":     True,
        # Smart-brain (2026-06-23) — trust window for the BF-299
        # watcher.  When the watcher reconciled a (bucket, prefix)
        # within this many seconds, the metadata-key cache layers
        # SKIP the per-query version-hint.text S3 GET.  Watcher's
        # entire job is to be the authoritative refresh path;
        # verifying its work on every query was the "low IQ brain"
        # pathology — N iceberg tables = N S3 round-trips per BQB
        # query.  Stale tick (older than window) falls back to live
        # verify automatically.  Set 0 to disable trust entirely
        # (every cache hit pays for verify).
        "cache_trust_window_seconds":     300,
        # Smart-brain co-access learning (2026-06-23) — the brain
        # learns which tables get accessed together (BQB joins,
        # cross-source primary, published-view multi-source) and
        # uses that signal so when a snapshot ADVANCES on table A,
        # frequent-pair neighbours have their tick removed (forcing
        # next-query re-verification because joined tables' data
        # often co-evolves).  Per-pod, in-memory, LRU-bounded.
        "co_access_max_pairs":            5000,
        "co_access_decay_half_life_seconds": 86400,  # 1 day
        "co_access_min_count":            2,         # ignore one-off queries
        # BF-510 (2026-05-28) — when True, ``get_iceberg_data_files``
        # delegates manifest walk + pruning to the official Apache
        # ``pyiceberg`` library instead of the hand-rolled path.  Closes
        # the BF-498..509 bug class by routing date/timestamp/bucket/
        # truncate/spec-evolution handling through pyiceberg's native
        # ``Transform.project`` + ``BoundPredicate.eval``.  Caching +
        # snapshot-pointer freshness (BF-503/507) and S3 client wiring
        # (portal STS / VPC endpoint / proxy bypass) stay on our side
        # via a custom FileIO bridge (core/iceberg_fileio.py).
        # Default False during rollout; flip to True after operator
        # validation in staging.  On equality-delete (v2) tables that
        # pyiceberg 0.11.1 doesn't yet support (apache/iceberg-python#1210),
        # we fail-open to the hand-rolled path automatically.
        "use_pyiceberg":                  False,
        # 2026-06-03 — manifest-read failure policy.  Default False
        # preserves the existing fail-open behaviour (any one manifest
        # that fails returns ``[]`` for that manifest; the aggregate file
        # list is partial; caller may over- or under-scan).  Set True in
        # production so that an S3 / proxy / credential failure during
        # the cache-miss → S3 fallback path becomes a LOUD query error
        # instead of a silent partial result.  Recommended once S3
        # connectivity is stable enough that a manifest failure is a
        # genuine incident, not an everyday hiccup.  Reads with this
        # flag will return _out_meta["iceberg_cache_diagnostic"] with
        # the cache state + per-call S3 counts so operators can see
        # whether a given query went through cache or fell to S3.
        "manifest_read_strict_mode":      False,
        # F1 (2026-08-22, design_s3_speed §6) — cold manifest fetch width.
        # Was a hard-coded ``min(8, len)`` against a 64-slot shared S3 pool:
        # ⌈M/8⌉ RTT waves on exactly the path a corporate proxy makes slow
        # (a 500-manifest table = 63 waves ≈ 9.5 s at proxy RTT).  Default 32
        # — footer capture already runs 32 workers against the same pool.
        # Clamped in code to the shared pool size (64); values <= 0 are
        # INVALID and fall back to the documented pre-knob width of 8
        # (0 does NOT mean unlimited).  A THROTTLE, never a gate: every
        # manifest is still fetched at any width.
        "manifest_fetch_parallelism":     32,
        # 2026-07-15 column-stats pruning self-audit (opt-in, default OFF,
        # fail-open).  Answers "with column-stats pruning ON, is it dropping
        # files correctly on MY data?" without disabling the feature.
        #   pruning_audit_enabled — per-query TRACE of which files the
        #     supplement layer dropped + the bound/filter that caused each
        #     (free, no extra S3).  Surfaced in the log + _out_meta.
        #   pruning_audit_verify_footers — additionally re-read a SAMPLE of the
        #     dropped files' real parquet-footer min/max and re-run the pruner;
        #     if the verdict flips drop→keep, the cached supplement bounds are
        #     STALE/WRONG and silently lost rows → logged at WARNING.  Costs one
        #     footer GET per sampled file, so it is bounded by pruning_audit_sample.
        #   pruning_audit_sample — max dropped files footer-verified per query.
        "pruning_audit_enabled":              False,
        "pruning_audit_verify_footers":       False,
        "pruning_audit_sample":               20,
        "metadata_count_warn_threshold": 5000,
        # BF-316: hard cap on files per query (after pruning).  When the
        # WHERE narrows to MORE files than this, the engine raises an
        # actionable error instead of silently downloading thousands of
        # parquets.  0 = no cap (default).  Set to e.g. 200 in production
        # so accidental "scan everything" queries get rejected with a
        # clear message about which filter columns lack min/max stats.
        # ICEBERG'S OWN CEILING — a GATE, and separate on purpose.
        # 2026-09-21 (FB-55): this comment used to read "log WARNING when
        # file count exceeds this".  READ THE CODE, NOT THE DOCSTRING —
        # core/iceberg_reader.py RAISES a ValueError on it (BF-316) and
        # always has, so the description sent every reader (me included)
        # to the wrong conclusion about what ships enforcing.
        #
        # It is deliberately NOT unified with s3.max_files_per_query: the
        # number it judges comes from a MANIFEST that already knows which
        # files a predicate needs, not from an S3 listing, so the two are
        # not the same quantity and one knob cannot honestly mean both.
        # 0 = off; above it, ops should run expire_snapshots.
        "max_files_per_query": 0,
        # BF-296: snapshot-keyed metadata cache.  Avoids the 10-15 min
        # manifest walk through corporate proxy by storing the file list
        # keyed on the immutable snapshot_id.  L1 pointer TTL bounds how
        # long we'll serve a stale snapshot_id before re-checking
        # metadata.json (admins can also click "Refresh now").
        "snapshot_cache_enabled":      True,
        # 2026-07-22: the L2 (DB) iceberg_file_cache is per-CONNECTION and
        # redundant with the bucket+table_prefix-scoped db-first stats + snapshot
        # cache.  OFF by default to remove per-connection fragmentation + the
        # same-bucket-different-table mix-up risk.  L1 (per-pod) is unaffected.
        "l2_file_cache_enabled":       False,
        "snapshot_pointer_ttl_hours":  3,   # 0 < this <= 24 reasonable
        # 2026-07-22 — SIZE CAP for the snapshot contents cache
        # (iceberg_snapshot_cache.files_data).  A huge table's file list is
        # hundreds of MB of JSON; Postgres refuses a single value near its ~1 GB
        # limit ("invalid memory alloc request size").  Over EITHER cap the DB
        # write is skipped (fail-open — the manifest walk re-runs; db-first
        # per-file stats is the right store for a table this large).
        "snapshot_cache_max_files":    200000,      # skip DB cache above this many files
        "snapshot_cache_max_bytes":    268435456,   # 256 MB serialized ceiling
        # R10: the L1 (in-memory) store is gated INDEPENDENTLY of the DB caps
        # above — by BYTES, not file count — so a large-file-count but modest-
        # size snapshot still caches in L1 (repeat queries skip the manifest
        # walk) while a truly enormous blob is excluded to protect the pod from
        # OOM.  Only the DB write honours snapshot_cache_max_files.
        "snapshot_cache_l1_max_bytes": 67108864,    # 64 MB per-entry L1 ceiling
        # 2026-07 PER-FILE snapshot store: when true, the snapshot's file
        # enumeration is stored as PER-FILE ROWS (iceberg_snapshot_files) that
        # support partition-island reads, instead of the single 538 MB
        # files_data JSON blob.  Fail-open: on any miss the reader falls back
        # blob → manifest walk, so flipping it can never lose data.
        #
        # 2026-08-19 — FLIPPED TO TRUE.  The line above said "flip to true
        # after a soak", and three things now make that the correct default:
        #
        #  1. It is the ONLY path that stores anything for a big table.  The
        #     blob write is skipped outright above snapshot_cache_max_files
        #     (200,000) because one Postgres JSON value cannot hold it — so on
        #     exactly the tables where enumeration hurts most, the blob store
        #     was a no-op and every query re-walked the manifests.
        #  2. Partition pruning cannot use the blob.  The island carve, and
        #     the indexed partition seek added today
        #     (iceberg_file_partition_index), both read per-file ROWS.  With
        #     this false the seek has no rows to seek, so the whole
        #     partition-first path was dormant — built, measured, unreachable.
        #  3. Reuse is fail-CLOSED where it matters.  A narrowed island load
        #     is served only when _rows_store_proven_complete passes: the
        #     'rows' header marker written LAST, COUNT(rows) == header count,
        #     and header count <= the snapshot's declared total.  Anything
        #     short of that refuses and falls back.
        #
        # Revert by setting this false in config.json; the blob path is
        # untouched and still the fallback on any rows-store error.
        "snapshot_cache_per_file_rows": True,
        # ── 2026-08-21 — BOOTSTRAP THE FILE INDEX FROM THE QUERY PATH ─────
        # The per-file index is produced by the background metadata sync
        # (which reads UNFILTERED and so enumerates completely).  When that is
        # not running the index can never populate: storing needs a COMPLETE
        # enumeration, complete needs every manifest, and a filtered query
        # reads only the ones bounds-pruning kept.  A closed loop.
        # On discovering the gap the reader warms the missing manifests in the
        # BACKGROUND so the NEXT read can store a complete enumeration — after
        # which file lookup is a database seek instead of an S3 walk.
        # Above this many missing manifests it refuses and says the sync is
        # needed, rather than turning a query into a bulk download.
        # (Duplicated as an inline fallback in iceberg_reader — keep in step.)
        "bootstrap_max_manifests":        200,
        # ── 2026-08-21 FOOTER CAPTURE ON THE QUERY PATH ───────────────────
        # When files survive partition pruning but no column bounds exist for
        # a filter column, the funnel fails OPEN and keeps them — correct, but
        # it means reading the data to answer a question a footer could have
        # answered.  Operator's run: 3,001 undecidable files -> 2,880 kept
        # unjudged -> 32.2 GB / 204M rows to DuckDB.
        #
        # A parquet footer is 1 HEAD + 1-2 ranged GETs, ~16-256 KB REGARDLESS
        # of file size, so 3,001 footers is ~300 MB against 32.2 GB of data.
        # Read them, prune for real, and PERSIST the bounds so the next query
        # on that island pays nothing.
        #
        # These values are duplicated as inline fallbacks at the call site;
        # they MUST stay identical.  A declared value that differs from its
        # fallback silently changes behaviour the moment the key is declared.
        "footer_capture_on_query":        True,
        # Above this many undecidable files, don't try — log loudly instead.
        "footer_capture_max_files":       5000,
        # Below this many, not worth the round-trip.
        "footer_capture_min_files":       25,
        # Hard wall-clock bound; the capture is cancelled and the funnel's
        # survivor list stands unchanged.
        "footer_capture_deadline_seconds": 25,
        "footer_capture_workers":         32,
        # ── Phase 2 (2026-08-22, design_s3_speed §4) — snapshot-arrival
        # indexer: on a watched table's snapshot advance, backfill the
        # partition-seek index and footer-capture the query-history-ranked
        # columns OFF the query path, so the first query after an advance
        # no longer pays the synchronous capture deadline.
        "snapshot_indexer_enabled":       False,  # 2026-08-23 REVERTED TO OFF — shipping this ON was a P0: it writes
        # up to snapshot_indexer_max_capture_files x capture_top_columns
        # rows into the supplement store PER SNAPSHOT, and the read path
        # does a SNAPSHOT-AGNOSTIC lookup.  An operator's 70s query became
        # 700s: 13,787 supplement rows fetched (125s of a 154s scan) to
        # eliminate ZERO files.  A background job that FILLS a store must
        # not default ON while any reader of that store is unbounded.
        # Re-enable per-deployment AFTER canarying the read path.
        # Per-table min seconds between builds.  A THROTTLE: a build that
        # arrives early stays QUEUED and runs later — never skipped.
        "snapshot_indexer_min_interval_seconds":  120,
        # Files one build may footer-scan (scan_files_to_supplement
        # max_to_scan — remaining files drain on later builds/queries).
        "snapshot_indexer_max_capture_files":     5000,
        # How many demand-ranked columns to capture per build.
        "snapshot_indexer_capture_top_columns":   8,
        # BF-299: background metadata sync.  When enabled, a periodic
        # task downloads + reconciles iceberg metadata for every table
        # ever queried so the user's first query never waits.  The
        # sync uses BF-298 per-manifest caching so it only fetches
        # what's actually changed since the last run.
        "metadata_sync_enabled":          True,
        # BF-MGD-BG-JOBS-OPT-IN: admin opts in via /admin/background-jobs
        # → Start.  When this is false the job is REGISTERED (visible in
        # admin UI) but does NOT run until admin clicks Start.  Pause/start
        # state then persists across restarts via background_job_states.
        #
        # 2026-08-19 — FLIPPED TO TRUE.  The opt-in existed because this sync
        # used to run inside the API pod, where an unattended background job
        # competes with query memory; making an admin press Start was the
        # consent gate for that.  With the pod-role split the job runs on the
        # scheduler pod and is declined on any pod stamped QS_POD_ROLE=api, so
        # the thing the gate protected against can no longer happen.
        #
        # Leaving it false has a real cost: this sync is what populates the
        # column-stats supplement, and the supplement is what db-first island
        # reads and supplement-bounds pruning consume.  Off, those stages are
        # permanently dark on a cold deployment — the "smart" pruning that
        # never appeared to do anything.
        #
        # Admin pause still wins: a paused job stays paused across restarts
        # via background_job_states, so this changes the DEFAULT, not the
        # operator's explicit choice.
        "metadata_sync_autostart":        True,
        "metadata_sync_startup_delay_seconds": 15,
        "metadata_sync_interval_minutes": 5,    # how often to reconcile
        "metadata_sync_max_per_cycle":    25,   # bound load per tick
        # 2026-09-27 — WATCH-AND-WARM ON REGISTER (core/iceberg_watch_registry.py,
        # core/iceberg_warm_on_commit.py).  Registering an Iceberg table on a
        # connection adds it to watched_iceberg_tables (unregistering removes
        # it; the scheduler pod reconciles every registered table at boot),
        # and a new snapshot warms the file list, manifests, per-file store,
        # partition index and the bloom sidecars for the table's DECLARED
        # bloom_columns, so the first query after a load pays no cold cost.
        # Warming is best-effort and fail-open; it never blocks a query.
        "watch_registered_tables":        True,
        "warm_on_commit_enabled":         True,
        # Bloom reads a column chunk per file; this bounds ONE warm.  0 =
        # unbounded.  Files beyond the cap are left to the adaptive prefetch.
        "warm_on_commit_bloom_max_files": 5000,
        # BF-301: pre-download top-N data files into BF-257 NFS cache
        # during sync so a user's first query reads from local disk
        # instead of S3.  Only takes effect when s3_local_cache.enabled
        # is also true.  Default off — opt-in because it consumes disk.
        "metadata_sync_predownload_enabled":   False,
        "metadata_sync_predownload_max_files": 50,    # per table per tick
        "metadata_sync_predownload_max_gb":    5,     # per table per tick
        # BF-COL-STATS: extract per-file column min/max bounds from parquet
        # footers and cache them in iceberg_column_stats_supplement so the
        # pruning path can use them when the Iceberg writer didn't track
        # bounds for a filter column.  ~16-256 KB per file (footer only),
        # so a 4000-file table = ~50-1000 MB of S3 transfer one-time per
        # snapshot.  Disabled by default — admin opt-in once disk + bandwidth
        # budget is confirmed.  When ON, runs as part of metadata_sync_loop
        # AFTER the predownload step.
        # 2026-06-10 Phase 147.2 — flipped False → True so the supplement
        # scanner runs by default.  Was the single biggest gap in today's
        # pruning: most operators didn't know to flip the switch, and
        # non-partition WHERE clauses pruned at the row-group level only
        # (DuckDB's job) but never at the file level (pruner's job).
        # Operators with slow storage / proxy / VPN can opt back out via
        # iceberg.column_stats_sync_enabled=false in config.json.
        "column_stats_sync_enabled":          True,
        "column_stats_sync_workers":          32,    # parallel boto3 footer reads
        # 2026-06-10 Phase 147.2 — lowered 5000 → 1000 so the first sync
        # after the default flip warms up gradually rather than spiking
        # I/O.  Operators with fast S3 can raise it back via
        # iceberg.column_stats_sync_max_files_per_tick in config.json.
        "column_stats_sync_max_files_per_tick": 1000, # 0 = unlimited
        "column_stats_max_workers_cap":       128,   # admin-API per-request cap
        # BF-iceberg-cache-lru — max rows kept in IcebergSnapshotCache /
        # IcebergManifestCache before LRU eviction.  Scheduler runs every
        # 6h to drop the least-recently-accessed entries beyond these caps.
        # Without this the tables grow unbounded as the writer commits new
        # snapshots over months / years.  Sized for a typical deployment:
        # 200 snapshots × 1 KB each = 200 KB; 5000 manifests × 5 KB each = 25 MB.
        # Raise if you query many distinct tables; lower to save DB space.
        "snapshot_cache_max_entries":         200,
        "manifest_cache_max_entries":         5000,
        # 2026-06-04 — L1 (in-process) caps for the same two caches.
        # Previously hard-coded as ``_MANIFEST_L1_MAX = 500`` /
        # ``_CONTENTS_L1_MAX = 50`` in iceberg_snapshot_cache.py.  On
        # multi-tenant pods a single manifest's decoded Avro entries
        # can be 5-50 MB; 500 of them resident at once explained the
        # "RAM hits 99 %" reports.  Module defaults were lowered to
        # 100 / 30 respectively; these two settings let admins
        # override at runtime without redeploying when a particular
        # workload needs more or less.  Leave at ``null`` (the default
        # below) to honour the module-side default.  L2 (DB) caps
        # above are unchanged — disk is cheap, RAM is not.
        "manifest_l1_max_entries":            None,
        "snapshot_contents_l1_max_entries":   None,
        # BF-547 (2026-05-28) — auto-trigger column-stats supplement scan
        # when a query needs file-level pruning on columns whose bounds
        # are missing from both the manifest AND the supplement.  Fire-
        # and-forget background thread: the CURRENT query keeps the
        # degraded pruning (DuckDB still skips row groups via parquet
        # footer stats), but the NEXT query benefits from a populated
        # supplement.  Throttled 10 min per (bucket, prefix) so a stream
        # of queries doesn't kick off N concurrent scans.  Set false to
        # disable — operator gets the pre-existing "run column-stats
        # scan from admin UI" log line instead.
        # 2026-07-22: OFF.  The API pod must NOT run heavy S3 file-scans (bloom
        # or column-stats builds) — even on a daemon thread they burn the API
        # pod's S3 connections / CPU and compete with request serving (a cause
        # of query hangs + pod restarts).  Those builds belong on the SEPARATE
        # background job / worker pods (adaptive-prefetch daemon + the isolated
        # admin scan endpoint).  The API pod only CONSUMES the artifacts.
        "auto_supplement_on_query_miss":      False,
        "auto_bloom_on_query_miss":           False,
        # PROBE-SAFETY caps for the inline self-heal.  Above auto_bloom_max_files
        # the reader does NOT scan on the query pod (would risk starving the
        # liveness probe -> pod restart); it logs "run the offline admin scan"
        # instead.  auto_bloom_workers keeps the piggy-backed scan gentle.
        # 2026-07-22: 1500 → 10000.  A single COB partition is commonly ~2k
        # files; the old 1500 cap made the background bloom self-heal SILENTLY
        # SKIP for exactly the partitions that need it, so system_id IN (...)
        # kept scanning every file forever.  The build is a low-concurrency
        # (2-worker) background thread and fail-open, so 10000 gives real
        # partitions room while still deferring a pathological whole-table
        # build to the offline admin scan (POST /api/admin/iceberg/bloom/scan).
        "auto_bloom_max_files":               10000,
        "auto_bloom_workers":                 2,
        # ── Phase 4 (industrialization, 2026-07-23) — within-island
        # supplement build knobs.  The FEATURE gate lives in
        # industrialization.supplement_on_zero_coverage (default OFF,
        # master-switched); these only TUNE an armed build.  Builds run on
        # a background daemon thread, single-flighted per (table, snapshot,
        # column) via the iceberg_supplement_build_v1 marker, with bounded
        # workers + a per-build file cap (a capped build finishes 'partial'
        # and DRAINS across successive queries — same posture as the
        # column-stats sync per-tick cap), so an armed pod stays gentle
        # (the 2026-07-22 "API pod must not run heavy scans" lesson).
        "within_island_supplement_max_workers":            4,
        "within_island_supplement_max_files_per_build":    4000,
        # 0.0 = schedule only on EXACT zero coverage (manifest + supplement
        # both empty for the column over the island survivors).  Set e.g.
        # 0.5 to also heal columns covered on fewer than half the files.
        "within_island_supplement_min_coverage_fraction":  0.0,
        # Stale-'running' marker re-claim TTL (crashed builder) + retry
        # cooldown after a hard 'failed' build.
        "within_island_supplement_running_ttl_seconds":    1800,
        "within_island_supplement_retry_seconds":          3600,
        # Per-pod decision cache so a query storm on the same cold column
        # doesn't re-ask the DB marker on every query.
        "within_island_supplement_decision_cache_seconds": 60,
        # BF-548 (2026-05-29) — S3-side bloom filter pre-skip.
        # When True, the iceberg reader issues a 256 KB suffix-range
        # GET per file to read its parquet bloom filter footer, then
        # SKIPS the file entirely when bloom proves absence for any
        # equality predicate.  Fail-OPEN at every step -- bloom can
        # never produce false negatives, so this is safe to enable
        # for correctness; only the latency cost is workload-
        # dependent.
        # 2026-06-24 -- flipped from False to True.  Operator
        # directive: "by default whatever required should be on and
        # executed via background jobs".  The bloom sidecar builder
        # (bloom_enabled=True) populates sidecars on the background
        # daemon; this flag is the gate that lets the READ PATH
        # consume them.  Without it, the brain gathers bloom data
        # but never uses it -- the very issue the operator pushed
        # back on with "is bloom filter really working".  Extra
        # latency cost (one suffix-GET per file with eq predicates)
        # is bounded by the partition-pruning + supplement filters
        # that run BEFORE bloom in the pipeline, so the check fires
        # on a small, already-pruned file set.
        # 2026-07-15 DATA-LOSS FIX: default back to False.  The native S3
        # bloom check probes ``bloom.find(raw_filter_value)`` — but the filter
        # value arrives as a STRING (e.g. '2025-09-30', '5'), while the parquet
        # bloom for a DATE/INT column is built on the physical int encoding.
        # A type-mismatched find() returns False (wrong-encoding hash miss)
        # INDISTINGUISHABLE from a true "absent", so the file is silently
        # skipped even though it contains matching rows (observed: 210M→78M on
        # a business_close_date='2025-09-30' scan).  The read path now has a
        # physical-type parity gate (parquet_pruning._bloom_value_type_matches)
        # so a mismatch fails OPEN, but keep the feature OFF by default — it is
        # a pure optimisation and net-negative on non-selective / large file
        # sets (one 256 KB suffix-GET per file).  Enable per-table only when
        # the equality column is a genuine STRING high-cardinality id.
        "s3_bloom_check_enabled":             False,
        # BF-511 (2026-05-28) — hard ceiling on how long a row in
        # IcebergMetadataKeyCache may serve without S3 corroboration.
        # The cache row is verified against version-hint.text on every
        # hit; if verification SUCCEEDS, the row is served regardless
        # of age.  If verification FAILS (V1 table, transient S3 error,
        # or cache_pointer_verification disabled), the row is served
        # ONLY if it is younger than this max-age — older rows fall
        # through to a fresh Layer-3 resolve.  Caps blast radius of
        # stale-DB rows even when version-hint.text is unavailable.
        # Set 0 to disable the DB cache layer entirely (every in-memory
        # miss resolves from S3).  User mental model: "if manifest is
        # recently updated in an hour then only local db cache should
        # be used".
        "metadata_key_db_cache_max_age_seconds": 3600,
        # 2026-10-07 -- THE staleness bound (core/iceberg_freshness_bound.py).
        # A cached metadata pointer may answer a query WITHOUT a live probe
        # only when it was last CONFIRMED newest less than this many seconds
        # ago; past it a probe is paid (version-hint GET, or for catalogs
        # that write no hint -- Trino/Glue/JDBC -- one LIST of the NEXT
        # metadata version), and a probe that FAILS re-resolves from S3.
        # Caps every older knob that used to decide this on its own (the
        # trust window, the DB max-age, the stale layer, the watcher
        # certificate).  cache_strategy bypass/refresh run with 0.
        "max_snapshot_staleness_seconds": 60,
        # BF-512 (2026-05-28) — proactive background sweep that
        # re-resolves every non-sentinel IcebergMetadataKeyCache row
        # against S3 on the configured interval, independent of query
        # traffic.  Closes the freshness loop in the OTHER direction:
        # BF-511 hardens the on-demand read path; BF-512 ensures rows
        # touched by NO queries still get refreshed.
        # Set false to disable the job entirely (rows then refresh
        # on-demand only; BF-511's hard max-age still caps stale-row
        # blast radius).  Interval is read at scheduler init — changes
        # require a restart.
        "metadata_key_background_refresh_enabled":          True,
        "metadata_key_background_refresh_interval_minutes": 30,
        # Cap rows processed per tick (0 = unlimited).  Useful when the
        # cache holds thousands of rows and the admin wants bounded
        # per-tick S3 cost.  Rows are sorted oldest-first so stale-risk
        # is processed before fresh rows.
        "metadata_key_background_refresh_batch_size":       0,
        # ── 2026-08-04 discoverability — keys long read via inline get()
        # defaults but previously invisible here.  Each value below is a
        # byte-copy of its read-site inline default (NOT of config.json), so
        # deployments that never set the key keep identical behaviour.
        # Adaptive Freshness master switch (iceberg_reader._adaptive_freshness_enabled, default True).
        "adaptive_freshness_enabled": True,
        # Bloom sidecar READ side (iceberg_reader consume loop + the
        # brain_pruning_memo key fingerprint; both inline fallbacks are
        # pinned to this value by test_config_defaults_discoverability).
        # 2026-09-27: ON.  The write side (warm-on-commit for declared
        # bloom_columns, adaptive_prefetch for history-ranked columns) has
        # built sidecars by default since 2026-09-26/27 for a reader that
        # was off -- built for nobody.  The 2026-07-15 210M->78M loss (a
        # STRING probe pruning a DATE-built bloom) is closed by the
        # probe-encoding parity gate; the 2026-07-22 objection (the gate
        # cannot see a bitset built by another encoder) is closed by
        # verifying the row's recorded BUILD-side type as well, at ONE
        # chokepoint: iceberg_bloom_sidecar.probe_parity_proven.  Proof by
        # the pruning-brain discipline (row multiset, aggregates, files
        # handed to read_parquet, adversarial probes, per-file FP rate,
        # gate mutation): tests/test_bloom_read_on_proof_2026_09_27.py.
        # PENDING (owner): live proof on the Docker rig -- ice_trades on
        # connection 1, `id` and `region` lookups, counts against Trino
        # (qs-trino), scan_economics.pruned_by_stage.bloom_sidecar > 0.
        # Set false to return to the reader-off posture; the sidecar keeps
        # being built either way.
        "bloom_sidecar_enabled": True,
        # Cross-check version-hint against newest LISTed metadata.json (iceberg_reader._cross_check_newest_metadata, default False).
        "cross_check_newest_metadata": False,
        # ── 2026-08-24 watcher freshness certificate ────────────────────
        # The manifest watcher already LISTs metadata/ on a cadence and
        # learns which metadata.json is newest.  It now PUBLISHES that
        # (iceberg_watcher_certificate table); the query path consults it
        # instead of re-running the same capped LIST in its own foreground.
        # Trust is granted only on positive proof: fresh certificate,
        # status ok, and its snapshot equal to the one the query resolved.
        # Turning this OFF restores the per-query LIST byte-for-byte.
        "watcher_certificate_trust": True,
        # How many watcher intervals old a certificate may be before the
        # query stops believing it.  At the default cadence (1800 s) and
        # multiplier 2.0 a certificate survives exactly one missed tick,
        # so a stopped or crash-looping watcher restores full validation
        # on its own within ~1 hour -- no operator action, no flag to
        # remember.  This is a CORRECTNESS window, not a throttle: it must
        # expire, so values <= 1.0 are clamped to 1.0 at the read site.
        "watcher_certificate_grace_multiplier": 2.0,
        # ── 2026-08-23 evidence-fetch scoping + island-exact short-circuit ──
        # Every value below is a BYTE-COPY of its read-site inline default in
        # iceberg_reader — declared here for discoverability only (the 08-20
        # round-3 lesson: declaring a knob with a value that differs from its
        # inline fallback silently moves behaviour).
        # Hive-island scoping of the supplement/bloom DB fetches (2026-08-03).
        "metadata_load_island_scope": True,
        "metadata_load_island_scope_max_paths": 2000,
        # Enumeration-bounding of the same fetches when the island scope
        # stands down (2026-08-23) — the fetch scales with THIS snapshot's
        # file list instead of the whole snapshot-agnostic store.
        "metadata_load_enum_scope": True,
        "metadata_load_enum_scope_max_paths": 20000,
        # Island-exact short-circuit: when every WHERE predicate is consumed
        # by the partition island (eq/IN on identity partition columns) and
        # every enumerated entry carries an exactly-decidable partition
        # value, the supplement/bloom/prunability/footer-capture evidence
        # stages are skipped — they provably have nothing left to narrow.
        "island_exact_shortcircuit": True,
        # Prunability profiler (iceberg_reader, default True) + its gates (module constants 0.5 / 64).
        "prunability_profile_enabled": True,
        "prunability_overlap_threshold": 0.5,
        "prunability_min_files": 64,
        # Column-stats sync pacing (iceberg_metadata_sync, defaults 30.0s target tick / 100-file floor).
        "column_stats_target_tick_seconds": 30.0,
        "column_stats_sync_min_files_per_tick": 100,
        # Adaptive prefetcher knobs read from this subsection (query_history_prefetcher).
        "adaptive_prefetch": {
            "benefit_ranking": True,        # occurrence × files × (1 − drop ratio) ranking (default True)
            "max_files_per_target": 2000,   # per-target file cap per tick (default 2000)
            # ── Declared 2026-10-07 ─────────────────────────────────────
            # Read by query_history_prefetcher through the sub-dict
            # (``get_section("iceberg")["adaptive_prefetch"].get(...)``),
            # which the declared-config guard could not see until today.
            # Every value is VERBATIM from its read site's fallback.
            "enabled":            True,     # init_prefetch_scheduler / get_prefetch_status
            "interval_hours":     1,        # resolve_interval_hours (the ONE cadence; 149.10)
            "lookback_hours":     168,      # prefetch_daemon_tick / get_prefetch_status
            "top_n":              20,
            "min_occurrence":     3,
            "dry_run":            False,
            "snapshot_aware":     True,
            "daily_budget_bytes": 5368709120,  # _DEFAULT_DAILY_BUDGET_BYTES (5 GiB); explicit 0 = unlimited
        },
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "adaptive_freshness_anomaly_window_seconds":    86400.0,
        "adaptive_freshness_cadence_floor_seconds":     600.0,
        "adaptive_freshness_cadence_multiplier":        4.0,
        "adaptive_freshness_scan_ttl_seconds":          60,
        "cold_table_fair_slots":                        None,
        "db_first_enabled":                             True,
        "manifest_l1_entries_cap":                      0,
        "metadata_content_cache_max_entries":           5000,
        "metadata_scan_max_pages":                      500,
        "pruning_gate_file_sample_rate":                1.0,
        "pruning_gate_max_detail":                      50,
        "pruning_gate_mode":                            "observe",
        "pruning_gate_reprobe_bloom":                   False,
        "pruning_gate_sample_rate":                     1.0,
        # Declared 2026-10-07 -- read through aliased getters
        # (``_cfg_get_jb`` in iceberg_reader) the guard did not admit.
        "join_bloom_max_distinct":                      50000,
        "prune_null_partition_values":                  True,
        "snapshot_contents_l1_max_total_bytes":         268435456,
        "snapshot_pointer_coherence_ttl_seconds":       60,
    },
    # ── 2026-07-16 DATA-COMPLETENESS CONTROL (core.completeness_control) ──
    # Makes silent pruning-brain data-loss DETECTABLE without paying a full
    # scan.  CHEAP by default: the metadata receipt is ~free and ON; the
    # async shadow sampler and per-table full_scan are OPT-IN only.  Every
    # knob is fail-open — a completeness-check failure NEVER alters or blocks
    # a query result.
    # 2026-08-19 -- DECLARED so validate_config() stops reporting it as an
    # "unknown config section (typo?)".  It is not a typo: the section name
    # genuinely contains a dot, and core/iceberg_mirror.py::_cfg reads it via
    # get_section("iceberg.mirror") on purpose.  That helper accepts BOTH
    # shapes -- this dotted top-level section, and a flat "mirror.<key>" under
    # "iceberg" -- because on 2026-06-10 the shipped config.json used one
    # shape while the code read the other, so the master toggle stayed False
    # even with "enabled": true in the file.
    #
    # Values below MIRROR the inline fallbacks in iceberg_mirror._cfg exactly,
    # so behaviour is unchanged; declaring them just makes _DEFAULTS the
    # documented source of truth instead of ~19 scattered literals.
    # 2026-08-20 -- the COST note moved here from config.example.json when
    # that file was deleted.  It has to live next to the value, or the next
    # person to consider flipping it does not see what it buys:
    # a mirror writes a COPY of consolidated parquet into a separate internal
    # bucket -- 2x storage per table -- for a read speedup the pruning brain
    # already delivers (bloom + column-stats supplement + manifest stats)
    # WITHOUT any duplicate data.  KEPT OFF per operator directive, first
    # given 2026-06-24 and restated 2026-08-19.  Pinned by
    # tests/test_mirrors_stay_off_2026_08_19.py.
    "iceberg.mirror": {
        "enabled":                               False,
        "routing_enabled":                       False,
        "cron_enabled":                          True,
        "cron_interval_hours":                   6,
        "big_query_min_files":                   100,
        "max_build_source_files":                5000,
        "max_build_source_bytes":                50 * 1024 * 1024 * 1024,
        "max_builds_per_tick":                   5,
        "dual_run_canary_percent":               1.0,
        "dual_run_max_divergences":              1,
        "dual_run_retention_per_mirror":         200,
        "stale_retention_days":                  7,
        "auto_promote_enabled":                  False,
        "auto_promote_min_samples":              50,
        "auto_promote_min_days_zero_divergence": 7,
        "partition_by_threshold_files":          2000,
        "internal_bucket":                       "qs-internal",
        "internal_prefix":                       "iceberg-mirror",
        "default_sort_by":                       [],
    },
    "completeness": {
        # Tier 1 — always-on metadata receipt + verdict (~free, no data scan).
        "metadata_check_enabled":        True,
        "tolerance_rows":                0,      # absolute row slack
        "tolerance_ratio":               0.0,    # fractional row slack
        "prune_receipt_max":             200,    # cap on prune-receipt entries
        # Tier 2 — per-table trust level.  full_scan is the ONLY thing that
        # forces a full scan, and it is opt-in per table.
        "default_mode":                  "fast",  # fast | audited | full_scan
        "table_modes":                   {},      # {table_prefix: mode}
        # Tier 3 — async shadow sampler (the wrong-prune catcher). OFF here.
        "shadow_sample_rate":            0.0,     # 0.0 = OFF
        "shadow_tables":                 [],      # opt-in prefixes (always sample)
        "shadow_max_concurrent":         2,
        "auto_quarantine_on_divergence": True,
        # R1 (2026-07-22): when a table the Sentinel auto-escalated to SUSPECT is
        # lifted fast→audited, the reader runs a full unfiltered file-integrity
        # COUNT over EVERY kept S3 file, synchronously, on every subsequent
        # query.  The escalation trigger fires on nearly every table once the
        # auto-supplement self-heal is off, so honouring it is a guaranteed
        # latency cliff.  OBSERVATIONAL by default: the escalation is recorded +
        # surfaced in the verdict but does NOT force the mode.  Operators opt a
        # SPECIFIC table into audited via table_modes; that pin is honoured.
        "sentinel_audited_forces_mode":  False,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "audited_file_integrity_count_enabled":    True,
        "quarantine_forces_full_scan":             False,
    },
    # ── 2026-07-16 COMPLETENESS SENTINEL (core.completeness_sentinel) ─────
    # The autonomous pruning-TRUST agent.  It fuses signals the brain
    # already computes (completeness verdict, scan-ledger verdict, stats
    # coverage, adaptive-freshness, prunability overlap, shadow-sample
    # divergence) and DECIDES per-table when pruning is untrustworthy —
    # then auto-escalates THAT table's trust mode (fast→audited→full_scan)
    # and ALERTS with evidence + probable cause.  The user configures
    # NOTHING per table; the Sentinel decides on evidence.
    #
    # SAFETY BY CONSTRUCTION: the Sentinel only ever makes a table MORE
    # inclusive.  The escalation MODE changes are OBSERVATIONAL by default
    # (completeness.sentinel_audited_forces_mode=False,
    # quarantine_forces_full_scan=False) so an auto-escalation never silently
    # turns a fast partition-pruned query into a per-query full COUNT / full
    # scan; it is recorded + surfaced in the verdict and alerted, and operators
    # opt a specific table into audited/full_scan via completeness.table_modes.
    # Every path is fail-open: a Sentinel error is logged + dropped and the
    # query result + current mode are untouched.
    "completeness_sentinel": {
        "enabled":                          True,
        # R2/R3 (2026-07-22): a query that observes low stats-coverage can nudge
        # the watcher to reconcile that table (S3 manifest walk + per-file footer
        # scan).  OFF by default — the query path must never trigger heavy S3
        # background work (on a hybrid/misconfigured pod it couples live query
        # latency to a reconcile scan and hammers the connection pool).  The
        # scheduled metadata-sync daemon (worker/hybrid pod) refreshes per-file
        # stats on its own tick, so this only changes WHEN stats recover, never
        # WHETHER.  Single-pod embedded installs can opt in.
        "query_triggered_resync_enabled":   False,
        # SOFT signals (pruning INEFFECTIVE / unverifiable — not proof of
        # loss).  Require N occurrences in the window before → SUSPECT
        # (audited).  A one-off blip never escalates.
        "stats_coverage_min":               0.5,    # below → soft "ineffective"
        "overlap_max":                      0.9,    # bounds-overlap above → soft
        "soft_window_seconds":              3600,
        "soft_count":                       3,      # N-in-window → SUSPECT
        # HARD signals (genuine EVIDENCE of loss) escalate immediately to
        # PROVEN_RISK (full_scan) + alert.  No count/window — one is enough.
        # (completeness INCOMPLETE/over, scan_ledger over_count, shadow
        #  divergence.  These are hard-coded semantics, not knobs.)
        #
        # AUTO-RECOVERY (the guarded full_scan→fast downgrade).
        "recovery_cooldown_seconds":        1800,   # sustained-health window
        "min_quarantine_seconds":           900,    # never downgrade before this
        "require_shadow_verify_to_recover": True,   # re-run must MATCH to recover
    },
    # ── 2026-07-17 COMPLETENESS CERTIFICATE (core.completeness_certificate) ──
    # A FAIL-CLOSED, OBSERVATIONAL trust artifact.  Fuses the signals the
    # platform already emits (completeness receipt, scan-ledger, snapshot,
    # adaptive-freshness, reconciliation, Sentinel state) into ONE
    # provable-completeness verdict — COMPLETE | INCOMPLETE | UNVERIFIED —
    # for a report delivery, an ETL load, or an ad-hoc query.  It is the ONE
    # place that deliberately breaks the platform's fail-OPEN reflex:
    # COMPLETE is emitted ONLY when EVERY required signal affirmatively proves
    # it; any missing / ambiguous evidence yields UNVERIFIED (never COMPLETE),
    # because a completeness stamp that lies is worse than none.  Observational
    # only — it reads collected signals and returns a certificate; it never
    # executes a query, opens S3, alters a result, or blocks anything.
    # enabled defaults True precisely because it is read-only and cannot lose
    # data.  (Phase 1: model + builder + renderers; not yet wired to a live
    # delivery/execution path.)
    "completeness_certificate": {
        "enabled":                          True,
        # Max data age (seconds) tolerated before freshness is treated as
        # stale WHEN an explicit age is supplied.  None = rely solely on the
        # adaptive-freshness trigger/refreshed signal.  Stale freshness only
        # degrades COMPLETE→UNVERIFIED — it is never a hard-negative.
        "default_freshness_bound_seconds":  None,
        # Reconciliation (feed/ETL) source-vs-dest tolerance before a break is
        # a hard-negative.  0/0.0 = exact match required.
        "reconciliation_tolerance_rows":    0,
        "reconciliation_tolerance_ratio":   0.0,
    },
    # BF-516 (2026-05-28) — Zombie-run scanner.  Sweeps feed_runs +
    # dataflow_runs rows that have been stuck in status='running' beyond
    # the per-table max-runtime threshold (worker pod crash / OOM) and
    # flips them to 'failed' with a clear zombie marker.  Without this
    # the dashboards mis-report active load forever after a crash.
    #
    # All four knobs are admin-controlled:
    #   enabled                              — turn the job off if the
    #                                          operator runs their own
    #                                          zombie-recovery pipeline.
    #   interval_minutes                     — how often the sweep fires.
    #   feed_run_max_runtime_seconds         — feed runs older than this
    #                                          while still 'running' are
    #                                          marked failed.  4h default
    #                                          covers most enterprise feeds.
    #   dataflow_run_max_runtime_seconds     — same idea for DataFlow.
    "zombie_scanner": {
        "enabled":                              True,
        "interval_minutes":                     15,
        "feed_run_max_runtime_seconds":         14400,
        "dataflow_run_max_runtime_seconds":     14400,
    },
    # BF-524 (2026-05-28) — SLA tracker admin-pause primitive.  When True
    # the sweep returns immediately without firing breach alerts.  Use
    # during planned outage windows so already-late feeds don't trigger
    # cascading false-positive alerts that page on-call for known-down
    # systems.  Clearing the flag resumes the next sweep — no scheduler
    # restart needed.  Each sweep reads this fresh.
    "sla_tracker": {
        "paused":                                False,
    },
    # BF-312 — admin-defined custom periodic jobs (cron-scheduled)
    "custom_jobs": {
        "enabled":   True,
        # BF-MGD-BG-JOBS-OPT-IN: admin opts in via /admin/background-jobs.
        # Pause/start state persists across restarts.
        "autostart": False,
        "tick_seconds": 30,    # how often the scheduler polls the DB
    },
    # BF-MGD-BG-JOBS-OPT-IN — per-job autostart flags so admin can flip
    # via Helm OR runtime /admin/app-config without code changes.  Each
    # job reads its <name>.autostart value at registration time; if false
    # the job appears in /admin/background-jobs as registered-but-not-
    # running and admin clicks Start to begin.  Pause state then
    # persists across pod restarts via background_job_states.
    "background_jobs_autostart": {
        "dq_monitor":            False,
        "spark_connect_cleanup": False,
        # Defaults true to preserve historical behaviour — set false to
        # keep a job registered-but-stopped at boot.  Admin can flip via
        # POST /api/admin/background-jobs/{name}/start at any time.
        "user_drafts_cleanup":   True,
        "notification_poller":   True,
        "stale_query_cancel":    True,
    },
    # BF-273: Iceberg merge-on-read (V2 delete files).  When the table has
    # equality / position delete files, queries must read them and exclude
    # the matching rows.  Default false preserves the historical "skip
    # deletes" behaviour suitable for append-only ETL pipelines — but
    # COUNT(DISTINCT), aggregations, and any user-facing read on a table
    # with deletes will return STALE rows when this is off.  Was previously
    # read via fallback in iceberg_mor.is_mor_enabled() with no _DEFAULTS
    # entry (invisible in config.json + admin UI).  Now surfaced.
    "iceberg_mor": {
        # 2026-06-24 -- flipped from False to True per operator
        # directive "enable all".  Merge-on-read is fail-SAFE: if
        # the table has NO V2 delete files (the common case), the
        # reader checks ``snapshot.delete_files`` and finds none,
        # falling through to the regular append-only read with zero
        # extra cost.  When deletes ARE present, the reader applies
        # them and serves the correct post-delete row set.  Without
        # this flip, queries against tables with UPDATE/DELETE/MERGE
        # silently serve stale pre-delete rows -- WRONG ANSWERS, not
        # slow queries.  Operators with iceberg-V1-only tables can
        # flip off via ``iceberg_mor.enabled=false`` in config.json
        # if they want to skip the cheap delete-file check.
        "enabled": True,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "allow_stale_reads":    False,
    },
    # Phase 150 — Output Gateway: S3-backed extension of result_cache.
    # When a query scans >= min_files_threshold files post-prune, the
    # consolidated result parquet uploads to qs-internal S3 instead of
    # the per-pod local L2 cache.  Cross-pod hit-rate without growing
    # local disk.  Mutually exclusive with local L2: threshold IS the
    # routing decision.  Both kill switches default OFF.
    "output_gateway": {
        "enabled":              False,
        "serve_enabled":        False,
        "min_files_threshold":  1000,
        "retention_days":       7,
        "max_result_mb":        500,
        "default_ttl_seconds":  86400,
        # Bucket defaults to iceberg.mirror.internal_bucket when unset
        # so operators reuse one qs-internal bucket for all sidecars.
        # Set explicitly when output gateway needs a separate lifecycle
        # policy or IAM scope.
        "internal_bucket":      "",
        "internal_prefix":      "outputgateway",
        "cron_interval_hours":  6,
    },
    # Phase 151 — plain-parquet brain.  Extends the pruning brain to
    # plain-parquet S3 tables (NOT iceberg-registered) via supplement,
    # bloom, and mirror — same shape as the iceberg side but flag-
    # gated default OFF so SHADOW posture ships safely.  Every key
    # here is optional; the catalog + sync default ON, the read-path
    # drops + the mirror default OFF.
    "plain_parquet": {
        # Catalog: per-pod cached S3 ListObjectsV2.  Always-on; safe.
        "enabled":                           True,
        "catalog_cache_ttl_seconds":         300,
        "max_files_per_table":               50_000,
        # ── 2026-08-21 — A TRUNCATED LISTING CANNOT BE PARTITION-FILTERED ──
        # The S3 listing is capped in LEXICOGRAPHIC order.  When a partition
        # filter is then applied to that capped list, a partition sorting
        # after the cap is invisible: the filter matches nothing and the feed
        # reports "completed" having delivered ZERO rows.  We cannot know what
        # the cap excluded, so we refuse rather than return a subset.
        # Set false ONLY to restore the old silent behaviour; it does not make
        # the answer correct, it makes the wrongness quiet again.
        # (Value duplicated as an inline fallback in duckdb_views — keep both
        # in step; a declared value that differs silently changes behaviour.)
        "fail_on_truncated_partition_scan":  True,
        # Supplement sync daemon — populates column-stats supplement
        # rows tagged format='parquet' so the read path can drop
        # files via min/max bounds.
        "sync_enabled":                      True,
        "sync_interval_minutes":             15,
        "sync_max_tables_per_tick":          25,
        "sync_workers":                      8,
        # Bloom scanner — manual admin trigger + adaptive-prefetcher
        # auto-fires on query-frequency.  Heavier per file than
        # supplement (column-chunk read, not just footer).
        "bloom_enabled":                     True,
        "bloom_target_fp_rate":              0.01,
        # Read-path drops (supplement + bloom) in the duckdb_views
        # parquet branch.
        # 2026-06-24 -- flipped from False to True.  Operator
        # directive: "by default whatever required should be on and
        # executed via background jobs".  The sync daemon
        # (sync_enabled=True, runs every 15 min) populates the
        # supplement table; this flag is the gate that lets the
        # READ PATH consume those stats.  Without it, the brain
        # gathers knowledge but never uses it.  Fail-OPEN: if a
        # supplement row is missing or wrong, the read path keeps
        # the file (false-positive scan, no false-negative result).
        # All file-scan work that POPULATES the stats stays on the
        # background daemon -- the read path does cheap DB lookups
        # only.
        "brain_enabled":                     True,
        # Mirror engine — consolidates many small parquet files into
        # a hive-partitioned mirror in the QS-internal bucket.
        # 2026-06-24 -- KEPT OFF per operator directive: "whats
        # mirror... we dont want copy files... no duplicates right".
        # Mirror writes a COPY of consolidated parquet to a separate
        # internal bucket, doubling storage cost for the table.
        # The smart-brain still gets the small-file win via
        # pruning (bloom + supplement) + threshold-gated
        # union_by_name -- those don't duplicate data.  Operators
        # who explicitly want the 10-20x read speedup at 2x storage
        # cost flip these to True.  Daemon is registered regardless
        # (no-ops at every tick when disabled, so a runtime flip
        # takes effect without restart).
        "mirror": {
            "enabled":                       False,
            "routing_enabled":               False,
            # 2026-08-20 -- DECLARED.  Read by plain_parquet_mirror.
            # default_sort_by() with an inline [];  its sibling under
            # "iceberg.mirror" was declared and this one was not, so the
            # deleted example was the only place it appeared.
            "default_sort_by":               [],
            "cron_enabled":                  True,
            "cron_interval_hours":           6,
            "min_source_files":              100,
            "max_builds_per_tick":           3,
            "stale_after_hours":             72,
            "internal_bucket":               "qs-internal",
            "internal_prefix":               "parquet-mirror",
            # Internal-bucket creds for DuckDB COPY.  Without these,
            # consolidation falls back to logical-manifest mode
            # (mirror row created, but route_files keeps source
            # files — same safe baseline).
            "internal_aws_access_key_id":     "",
            "internal_aws_secret_access_key": "",
            "internal_aws_session_token":     "",
            "internal_region":                "",
            "internal_endpoint_url":          "",
        },
    },
    # BF-274: parquet writer row-group sizing — Snowflake-class micro-partitions.
    # Smaller row groups mean finer min/max bounds in the footer, which means
    # the existing s3_footer_stats / parquet_pruning / iceberg_reader read paths
    # can skip more data on selective queries.  Default ~1 M rows = ~16 MB
    # compressed, matching Snowflake's micro-partition target.  Set 0 to fall
    # back to pyarrow's built-in default (~1 048 576 rows; rarely produces more
    # than one row group per file in practice).
    "parquet_writer": {
        "target_rows_per_row_group": 1_000_000,   # 0 = use pyarrow default
    },
    # BF-275 / Tier 2: per-Iceberg-table sort columns applied at INSERT time.
    # When a table has an entry here, iceberg_writer.append() sorts the arrow
    # batch by these columns BEFORE writing.  Result: parquet files end up
    # with non-overlapping min/max ranges across files for the sort key, so
    # range queries (WHERE col = X) prune from thousands of files to dozens.
    # Most useful for SECONDARY hot filters — columns that aren't already the
    # partition (sorting by the partition column inside a partition is a no-op
    # because every row in a partition file already has the same value).
    # Format: {"table_name": ["col1", "col2"]} — table name is matched
    # case-insensitively against the last segment of table_prefix.
    "iceberg_sort_orders": {},
    "s3_results": {
        "enabled": False,                     # upload large results to S3 (requires S3_BUCKET_NAME env)
        "storage_mode": "local",              # "local" = always local, "s3" = always S3, "auto" = S3 above threshold
        "size_threshold_mb": 10,              # results larger than this get uploaded to S3 (auto mode only)
        "prefix": "querystudio/results/",     # S3 key prefix for result files
        "delete_local_after_upload": False,    # remove local parquet after S3 upload
        "bucket_override": "",                # use a different bucket for results (empty = use default S3 bucket)
    },
    # BF-411.3 — Audit log retention.  Without this, audit_log grows
    # unbounded (millions of rows per year on a busy deploy).  Daily sweep
    # at 02:30 deletes rows older than retention_days in batches.
    "audit": {
        "retention_days": 90,         # 0 = keep forever (not recommended)
        "cleanup_batch_size": 10000,  # rows per DELETE transaction
    },
    "scheduler": {
        # 2026-08-04 — AUTHORITATIVE cutoff for the orphan spill/staging
        # sweep (_cleanup_subprocess_temp_dirs).  BF-545 default: 15 min.
        # This key used to exist only in the sweeper's code (documented
        # nowhere); the legacy `cleanup_temp_files_hours` below was
        # documented but read by nothing.  Precedence (2026-08-04): an
        # EXPLICITLY-configured seconds value wins; else an EXPLICITLY-
        # configured hours value (config.json/env presence counts, even at
        # its default of 1 — production ships exactly that with a "1-hour
        # window" comment) or one tuned away from 1; else this 900 s
        # default.  The live-query floor (scheduler._live_query_floor_
        # seconds) is applied ON TOP in every case.
        "cleanup_temp_files_seconds": 900,
        "cleanup_temp_files_hours": 1,   # LEGACY — see …_seconds above
        "max_missed_jobs": 3,
        "execution_retention_days": 30,   # delete execution history older than N days
        "mode": "embedded",               # "embedded" (in-process) | "external" (separate worker)
        "worker_port": 8001,              # internal API port for scheduler_worker.py
        "worker_host": "127.0.0.1",       # bind address for scheduler_worker.py
        "notification_poll_interval": 1.5, # seconds between DB notification polls
        # Max concurrent APScheduler jobs.  2026-08-09 (metadata-scale audit
        # finding 4): now ACTUALLY drives the executor thread-pool width in
        # core/scheduler.py (it used to be heartbeat-reporting only while
        # the executor hardcoded 4 — docs/heartbeat claimed 20, reality 4).
        # Changes only how many scheduled jobs run at once, never when they
        # fire.  Also reported in the scheduler-worker heartbeat.
        "job_pool_size": 20,
        # BF-410.4 — Leader election via DB lease.  When multiple scheduler
        # pods exist (rolling upgrade overlap, or replicaCount>1), only the
        # lease holder fires APScheduler jobs; the rest poll for the lease.
        # Set to false ONLY in single-pod deployments where the overhead
        # of the lease check isn't worth it.
        "leader_election_enabled": True,
        # When false, APScheduler is registered but never started at boot.
        # Admin must hit POST /api/admin/scheduler/resume to start it.
        # Useful for: maintenance windows, blue/green cutovers, debugging
        # a stuck scheduled job in production without rolling back code.
        # Default true preserves historical behaviour.
        "autostart": True,
        # Defence-in-depth backstop (core/job_singleton.py): a per-job
        # PostgreSQL advisory lock applied at the executor chokepoint so no
        # cron tick can double-run across pods even if leader election is
        # off.  No-op on SQLite / single-pod (always acquires) and fail-safe
        # (runs anyway on lock error).  Cheap — default on.  Set false to
        # revert to pure leader-gating.
        "job_singleton_lock_enabled": True,
        # 2026-08-23 (Phase 4) — misfire grace for USER schedules only.
        # The scheduler-wide job_default is 30 s, which is right for daemon
        # sweeps (a missed cache cleanup reruns 30 min later anyway) but it
        # silently SKIPPED a user's daily 08:00 download when a deploy
        # overlapped the fire time: last_run stayed at yesterday with no
        # error anywhere — a job that silently never ran.  User schedules
        # (core.scheduler.add_schedule) now carry this per-job grace:
        # a fire missed by less than this many seconds runs late, and
        # coalesce=True still collapses multiple missed fires into ONE.
        # Daemon jobs keep the 30 s default.
        "user_schedule_misfire_grace_seconds": 3600,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "lock_retry_seconds":    20,
    },
    "storage": {
        "max_cache_size_mb":     2048,    # LRU-evict cache when total exceeds this
        "max_downloads_size_mb": 10240,   # warn/evict downloads when total exceeds this
        "downloads_expiry_days": 7,       # default download file TTL
        # 2026-08-30 — ceiling on a REQUESTER-chosen retention.  Report
        # exports register in the Download Centre and let the requester
        # ask for a longer keep (?retain_days=); this is the operator
        # maximum that request is clamped to.  Declared at the SAME value
        # the reader falls back to, so declaring it moves nothing.
        "downloads_retain_max_days": 30,  # max requester-chosen retention
        # 2026-08-30 — WHICH POD reclaims expired downloads.  Splitting the
        # Download Centre onto its own pod made this a question with a
        # wrong answer available: sweeping on BOTH pods is two pods doing
        # half a job, and on NEITHER fills the volume until quota eviction
        # destroys data by accident instead of by policy.  "scheduler" is
        # the historical owner and the default, so nothing changes for a
        # deployment that has not split the pod out; "downloads" hands it
        # to the pod that serves the files.  Declared at the reader's own
        # fallback, so declaring it moves nothing.
        "downloads_cleanup_owner": "scheduler",
    },
    "cors": {
        "allow_origins": ["*"],
        "allow_methods": ["*"],
        "allow_headers": ["*"],
        # BF-404 — suffix-based origin allowlist for OpenShift / K8s route
        # families.  Each entry matches ANY host that ends with the suffix
        # (e.g. ".apps.cluster.example.com" → accepts both
        # "qs-api.apps.cluster.example.com" and
        # "qs-ui.apps.cluster.example.com" without listing each route).
        # Empty list = disabled.  Suffix matching is exact: the host MUST
        # end with the literal suffix (including the leading "." if you
        # want subdomain-only matches — bare "example.com" would ALSO
        # match "fake-example.com", so always prefix with ".").
        "allow_origin_suffixes": [],
        # BF-404 — when true, additionally echo the request's exact Origin
        # header back on the Access-Control-Allow-Origin response.  Use
        # this in environments where the exact origin set is hard to know
        # ahead of time (e.g. preview/PR deploys getting random URLs).
        # Default false — explicit allowlist preferred.
        "echo_request_origin": False,
    },
    "email": {
        "host": "",
        "port": 587,
        "user": "",
        "password": "",
        "from_address": "",
        "use_tls": True,
    },
    "cache": {
        "enabled":             True,
        "ttl_seconds":         3600,
        "max_size_mb":         2048,
        "download_ttl_seconds": 604800,   # 7 days — download file retention (Phase 102-H)
        # Phase 104 — Partition-aware cache invalidation
        "partition_aware_invalidation": True,  # master toggle for staleness checks
        "snapshot_check_ttl_seconds":   300,   # L1 TTL — how often to re-check per table (5 min)
        "snapshot_sweep_interval_hours": 2,    # background sweep frequency
        "parquet_file_list_check":      True,  # track plain-parquet file count/hash changes
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "coherence_poll_seconds":    5,
    },
    "worker_pool": {
        "total_workers":               40,
        "drain_timeout_seconds":       15,
        "interactive_max_concurrent":  30,
        "interactive_default_timeout": 1800,
        "interactive_max_queue":       100,
        "report_max_concurrent":       10,
        "report_default_timeout":      3600,
        "report_max_queue":            20,
        "scheduled_max_concurrent":    5,
        "scheduled_default_timeout":   7200,
        "scheduled_max_queue":         50,
        "export_max_concurrent":       8,
        "export_default_timeout":      900,
        "export_max_queue":            30,
        "system_max_concurrent":       10,
        "system_default_timeout":      300,
        "system_max_queue":            50,
        # PUBLISHED_API was tunable (config.WorkerPool.published_api_*) but
        # absent from this defaults block, so the key name was undiscoverable
        # and the 50 lived only in worker_pool.DEFAULT_TYPE_CONFIGS.  Listed
        # here at its EXISTING values — no behaviour change — because it is
        # the largest cap AND the one driven by traffic you do not control.
        "published_api_max_concurrent":  50,
        "published_api_default_timeout": 1800,
        "published_api_max_queue":       200,
        #
        # ── SIZING NOTE (measured 2026-08-02) ─────────────────────────────
        # These caps are PER POD and sum to ~103 admissible concurrent tasks
        # (30 + 50 + 10 + 8 + 5).  That total assumes each work type has its
        # own pod.  In SINGLE/standalone mode every class shares one cgroup
        # alongside the background daemon fleet, and the measured cost per
        # query is ~384 MB (narrow) / ~1539 MB (900-column), so a 16 GiB pod
        # genuinely fits ~15-20 concurrent — not 103.
        #
        # Nothing breaks if you leave these: the per-query memory divisor
        # shrinks each share and over-budget queries spill.  But "everything
        # spills" is a poor operating point when the real fix is to admit
        # fewer and run them properly.  For a single 16 GiB pod, caps summing
        # to ~20 are honest (e.g. interactive 10 / published_api 6 /
        # report 3 / export 2 / scheduled 2).  SYSTEM starts no DuckDB engine
        # and does not count toward that budget.
    },
    "limits": {
        "max_stream_files":            200,     # max S3 parquet files per streaming query
        # BF-579 (2026-05-29): hard cap on file count for the
        # non-streaming registered-views path (BQB / feed / report).
        # Was hardcoded 5000 inside duckdb_views.py with no config
        # key — meaning a 5000-file table dumped every file into
        # ``read_parquet([...])`` causing DuckDB to open every
        # footer before the query started.  Lower default + actual
        # config key.  Streaming path uses ``max_stream_files``
        # (lower, since streaming is for small result UIs).
        # 2026-06-04 — raised 1000 → 5000.  Operators repeatedly hit
        # "registered files exceeds cap" on legitimate 3000-file
        # Iceberg scans (BQB on a year's worth of daily partitions);
        # 1000 was a Phase-100-era guardrail before the registered-
        # views path had multi-worker + auto-throttle + pruning.  With
        # the current pipeline (column-stats supplement + iceberg
        # pruning + scan_strategist + query_admission auto-throttle)
        # 5000 is the safe upper bound that lets day-to-day workloads
        # complete without admin intervention.  Beyond 5000 the
        # registered-views path opens too many parquet footers; route
        # those to Spark Connect or feed-gen instead.
        "max_registered_files":        5000,    # BQB / feed Iceberg registered-views
        "stream_query_limit_default":  500,     # default row limit for stream queries
        "stream_query_limit_max":      5000,    # max row limit for stream queries
        "stream_page_size_default":    100,     # default page size for stream pagination
        "stream_page_size_max":        5000,    # max page size for stream pagination
        "stream_chart_top_n":          50,      # max rows for streaming chart aggregation
        "stream_chart_max_series":     10,      # max series in multi-series streaming chart
        "max_upload_size_mb":          1024,    # max file upload size in MB (1 GB)
        "max_display_cols":            50,      # default visible columns in grid (user can add/remove)
        "col_auto_project":            50,      # query builder auto-select threshold for wide tables
        "default_query_limit":         1000,    # default query result row limit
        "streaming_default_on":        False,   # default state of streaming toggle
        "stream_bg_download_default":  True,    # default state of background download toggle
        "error_message_max_length":    300,     # truncate long error strings (Phase 102-H)
        "metadata_cache_ttl":          7200,    # data_grid metadata cache TTL (Phase 102-H)
        # BF-290: hard query budget — auto-cancel queries exceeding this
        # many seconds, with an actionable error to the user.
        # 2026-06-24 -- DISABLED BY DEFAULT (was 1800 = 30 min) per
        # operator directive: "actually it should not cancel...4000+
        # files may take time right" + "user can alwzy see resultss".
        # The smart-cancel loop (smart_cancel.client_stale_seconds +
        # engine_progress_grace_seconds) already protects against
        # GENUINELY stuck queries by requiring BOTH the client
        # heartbeat AND the engine progress to go quiet -- a query
        # actively scanning 4000 files keeps engine progress fresh
        # and survives.  The hard ceiling here would kill those
        # legitimate scans at exactly 30min regardless of progress,
        # which is what the operator pushed back on.  Set this to a
        # positive number (e.g. 14400 = 4 h) in config.json if you
        # want a deployment-wide hard ceiling.
        "hard_query_budget_seconds":   0,
    },
    "query_guardrails": {
        "enabled":                      True,       # master toggle for all guardrails
        # 2026-06-04 — raised warn 50 → 500 and block 200 → 5000.
        # The old defaults were Phase-107 guardrails calibrated for
        # the pre-pruning era when every file in the count meant a
        # real footer open; with iceberg manifest pruning + column-
        # stats supplement most "3000 files" queries actually scan
        # 12-50 after prune.  Old defaults turned a legitimate
        # year-of-daily-partitions BQB query into a hard "blocked"
        # error before the pruner even ran.  Operator directive
        # 2026-06-24: "no refuse" -- so the BLOCK threshold stays
        # generous (5000); the brain's job is to MAKE pruning work
        # better, not to refuse queries.  Warning chip at 500 still
        # alerts operators to investigate why pruning didn't help.
        "max_files_warn":               500,        # show warning if file count exceeds this
        "max_files_block":              5000,       # block execution if file count exceeds this (0=no limit)
        "max_rows_warn":                10000000,   # 10M rows — show warning
        "max_rows_block":               100000000,  # 100M rows — block execution (0=no limit)
        "require_partition_filter":     True,       # block if partitioned table has no partition selected
        "warn_no_partition":            True,       # warn if partitions available but none selected
        "warn_no_limit":                True,       # warn if no LIMIT set
        "default_limit_suggestion":     1000,       # suggested LIMIT value shown in warning
        # 2026-06-10 Phase 147.1 — pre-flight pruning-hostile filter
        # warnings.  When true, the BQB / CQB classify-filters call
        # surfaces an inline chip / pre-run modal when one of the
        # selected operators would defeat manifest-level pruning (LIKE
        # without prefix, DATE() wrap, function-wrapped column, BUCKET-
        # incompatible op, etc.).  Default ON — the chip is dismissible
        # and never blocks; set false to disable the endpoint entirely.
        "warn_pruning_hostile_filters": True,
        # 2026-06-10 Phase 147.1 D (deferred — opt-in only).  When true,
        # rewrites with classifier confidence==1.0 are applied silently
        # at submission; user sees a small "auto-fixed" chip post-run
        # instead of a pre-run modal.  Default OFF — wait for Phase C
        # acceptance metrics before flipping.
        # 2026-06-24 -- flipped from False to True per operator
        # directive "enable all".  When classifier confidence == 1.0
        # (deterministic pruning-hostile rewrites like
        # ``CAST(date_col AS TEXT) = '2025-01-01'`` ->
        # ``date_col = DATE '2025-01-01'``), the rewrite is applied
        # silently at submission and the user sees a small
        # "auto-fixed" chip on the result page.  Lower-confidence
        # rewrites still surface the pre-run modal (Phase 147 UX).
        # Brain DETECTS today; this flag makes the brain ACT.
        "auto_rewrite_pruning_hostile_ops": True,
        # ── Phase 107-B: detection-first S3 partition pruning ──
        # 2026-09-07 — MOVED here from ``pruning_health``, where they had
        # been declared since Phase 148 while every reader asked
        # ``query_guardrails``.  An operator following the declaration
        # set ``pruning_health.*`` and got NOTHING; one who guessed
        # ``query_guardrails.*`` got an effect from a key declared
        # nowhere — and QUERYSTUDIO_QUERY_GUARDRAILS_S3_FULL_SCAN_ACTION
        # could not work at all, because _apply_env only writes fields
        # that already exist in the merged config.
        #
        # THE VALUES ARE THE ACCESSORS' INLINE FALLBACKS, VERBATIM, so
        # declaring them moves nothing: measured before and after, the
        # effective values are "block" / 50 / True either way
        # (tests/test_config_env_and_ghost_knobs_2026_09_07.py pins it,
        # comparing the accessor against this declaration rather than
        # this declaration against itself).
        #
        # "block" IS the shipped behaviour and this change does not
        # touch it — but note that TWO other places state a different
        # intent for the same feature: core/query_guardrails.py's
        # ``(_qg.s3_full_scan_action or "log")`` (an arm the accessor's
        # own ``or "block"`` makes unreachable) and
        # api/execute_stream_api.py's "Default action is 'log'".
        # Both are stale prose about a value that is "block"; changing
        # the EFFECTIVE value is a product decision, not a cleanup, so
        # it is deliberately NOT made here.
        "s3_full_scan_action":          "block",    # "log" | "warn" | "block" — block prevents full S3 scans
        "s3_full_scan_min_files":       50,         # post-exec: only flag if scanned files exceeds this
        "post_exec_detection":          True,       # also log inside register_s3_views() after the fact
    },
    # 2026-06-10 Phase 148 — pruning observability defaults.
    "pruning_health": {
        # In-pod LRU TTL for the cluster snapshot (the heavy aggregation
        # the dashboard polls).  60s default matches typical 30s
        # dashboard refresh so two refreshes share one DB read.
        "snapshot_cache_seconds":     60,
        # A table is flagged as degrading when its avg prune % drops
        # more than this between consecutive windows of the same length.
        "degradation_threshold_pct":  20.0,
        # When false, per-day trend series + sparklines are omitted
        # from the table card response (saves a sort + grouping pass
        # under heavy dashboard load).
        "show_trends":                True,
        # A table card requires at least this many rows in the window
        # to render numerically.  Below this the UI shows
        # "Not enough data yet".
        "min_queries_for_card":       5,
        # ── Phase 107-B keys MOVED OUT 2026-09-07 ──
        # ``s3_full_scan_action`` / ``s3_full_scan_min_files`` /
        # ``post_exec_detection`` were declared HERE and read from
        # ``query_guardrails`` (core/config _QueryGuardrailsCfg,
        # core/query_guardrails.py).  Nothing has ever read them from
        # ``pruning_health`` — core/pruning_health.py reads only the four
        # keys above — so the declaration was inert and the operator who
        # followed it set a key with no consumer, while the effective
        # value came from an accessor fallback declared nowhere.  They
        # now sit in ``query_guardrails``, where they are read.
        # 2026-08-04 discoverability — degradation alert dispatch (core/pruning_alerts.py reads this subsection; values = its inline defaults).
        "alerts": {
            "enabled":              False,  # master switch — OFF until ops configure a webhook
            "webhook_url":          "",     # generic JSON POST endpoint; empty disables channel
            "slack_webhook_url":    "",     # Slack incoming webhook; empty disables channel
            "dedup_window_hours":   24,     # same (bucket, prefix) won't refire inside this window
            "max_alerts_per_tick":  10,     # hard cap per dispatch
            "cron_interval_minutes": 30,    # dispatch cadence (floored at 5 in code)
            # 2026-09-07 — the durable sink's retention.  Every alert that
            # clears the threshold writes a ``pruning_alert_events`` row,
            # delivered or not, so the table needs a bound; 0 = keep forever.
            "event_retention_days": 30,
            # 2026-09-07 — knobs ``core.pruning_alerts`` has always READ and
            # that were declared NOWHERE, which makes any guard on them
            # vacuous.  Each is declared at EXACTLY the default the code
            # already used, so declaring them moves no value.
            "webhook_timeout_seconds": 5.0,
            "compaction_file_count_threshold": 1000,
            "compaction_median_size_threshold_bytes": 1048576,   # 1 MiB
            # ``min_delta_pct_points`` is DELIBERATELY not declared here: its
            # default is not a literal, it is ``pruning_health.
            # degradation_threshold_pct`` read at call time.  Pinning a
            # literal would silently decouple the alert threshold from the
            # dashboard's, which is the "declaring a ghost knob MOVES a
            # value" trap.
        },
    },
    "materialized_views": {
        "storage_dir":              "/usr/local/querystudioapi/nfs/data/materialized",
        "max_size_mb":              10240,       # 10 GB total for all MVs
        "max_views":                50,
        "refresh_timeout_seconds":  3600,        # 1 hour max refresh time
        "chunk_size":               500000,      # rows per output parquet file
    },
    "federation_views": {
        "storage_dir":              "/usr/local/querystudioapi/nfs/data/federation_views",
        "max_nesting_depth":        3,           # max view-to-view reference depth
        "materialization_timeout":  1800,        # 30 min max
        "auto_cache_schema":        True,        # cache schema after materialize/preview
        "chunk_size":               500000,      # rows per output parquet file
    },
    "local_tables": {
        "storage_dir":              "/usr/local/querystudioapi/nfs/data/local_tables",
        "max_size_mb":              10240,       # 10 GB total for all local tables
        "max_tables":               100,
        "auto_discard_days":        10,          # discard public tables unused for N days
        "max_upload_size_mb":       1024,        # 1 GB max upload
        "cleanup_interval_hours":   6,           # run cleanup every N hours
    },
    "queue": {
        "backend":        "sqlite",        # "sqlite" (default) | "redis"
        "redis_url":      "redis://localhost:6379/0",
        "redis_password": "",
        "redis_db":       0,
        "redis_ssl":      False,
        "key_prefix":     "qs",            # namespace prefix for Redis keys
        "task_ttl_hours":  24,             # auto-expire completed tasks in Redis
        # 2026-10-03 -- WHERE core.rate_limiter keeps its counters.
        #   "shared"  (default) the metadata database every pod already uses
        #             (table rate_limit_windows, one atomic upsert per check):
        #             a 300/minute key is 300/minute across every pod and
        #             every uvicorn worker.  With backend="redis" Redis is the
        #             shared store instead.  A database error falls back,
        #             FAIL-CLOSED, to the in-process counter at this process's
        #             share of the limit (WARNING logged).
        #   "process" the old per-process counter: N pods x M workers each
        #             admit the full limit.  An escape hatch only.
        "rate_limit_store": "shared",
        # Seconds a finished window is kept before the retention sweep
        # rate_limit_window_cleanup deletes it (0 = keep forever).
        "rate_limit_window_retention_seconds": 3600,
    },
    "executor": {
        "mode":                        "embedded",  # "embedded" (in-process) | "external" (separate worker)
        "worker_port":                 8002,
        "worker_host":                 "127.0.0.1",
        "poll_interval":               1.0,         # seconds between claim polls (executor side)
        "notification_poll_interval":  1.0,         # seconds between completion polls (FastAPI side)
        "max_concurrent":              10,          # max simultaneous tasks in executor
        "stale_timeout_seconds":       600,         # re-claim stuck tasks after N seconds
        "cleanup_interval_hours":      1,           # cleanup old completed tasks every N hours
        "task_retention_hours":        24,          # keep completed/failed tasks for N hours
        "max_memory_per_task_gb":      4,           # DuckDB memory limit per task (GB, 0=unlimited)
    },
    "anomaly_detection": {
        "enabled": True,
        "z_score_threshold": 2.5,
        "min_history_runs": 5,
        "window_size": 20,
    },
    "features": {
        "streaming_mode":              "all",   # "all" | "stream_only" | "download_only"
        "streaming_enabled_roles":     "admin,analyst,viewer",
        "export_enabled_roles":        "admin,analyst,viewer",
        "sql_editor_enabled_roles":    "admin,analyst",
        "scheduler_enabled_roles":     "admin,analyst",
        "connections_enabled_roles":   "admin,analyst",
        "upload_enabled_roles":        "admin,analyst",
        "max_query_limit_by_role":     "",      # "viewer:1000,analyst:10000" (0=unlimited)
    },
    "circuit_breaker": {
        # ── Declared 2026-10-07 ─────────────────────────────────────
        # Read by production through an idiom the declared-config guard
        # could not see (an aliased getter, a 3-arg forwarding wrapper,
        # or a get_section sub-dict chain).  VERBATIM from the read site.
        "system_account_fallback_enabled": True,   # core/connectors/__init__.py
        "enabled":           True,
        "failure_threshold": 3,        # consecutive failures before opening circuit
        "cooldown_seconds":  60,       # seconds before attempting a probe request
        # 2026-08-20 — CEILING on the exponential backoff (BF-552), because the
        # thing waiting is a PERSON running a query, not a daemon.
        #
        # The backoff doubles per failed probe up to 32x, so with a 60s base a
        # user could be refused for 32 MINUTES with no way to ask for a retry:
        # the only override is POST /api/admin/circuit-breakers/{id}/reset,
        # which an ordinary user cannot call.  Backing off still matters (it is
        # what stops a dead service being hammered and the log flooded), but it
        # must not turn a recovered service into a half-hour outage for
        # whoever happens to be looking at the screen.
        #
        # 300s keeps a real ladder — 60s, 120s, 240s, 300s, 300s ... — while
        # bounding the worst case a user can experience at five minutes.
        "max_cooldown_seconds": 300,
    },
    "connection_pool": {
        "enabled":              True,
        "max_size":             5,        # max connectors per connection
        "idle_timeout_seconds": 300,      # close idle connectors after 5 min
    },
    "lineage": {
        "auto_extract":                True,   # extract table refs on query save/execute
        "fallback_regex":              True,   # use regex extractor when sqlglot fails
        "max_reparse_batch":           500,    # max queries to re-parse in one /reparse call
        # Phase 52 — snapshots & freshness
        "snapshots_enabled":           True,   # capture lineage snapshot on each execution
        "freshness_enabled":           True,   # track data freshness per table
        "snapshot_retention_days":     30,     # auto-delete snapshots older than N days
        "default_stale_threshold_hours": 24,   # hours before a table is considered stale
    },
    "semantic_layer": {
        "enabled":                     True,    # enable/disable semantic layer features
        "auto_detect_column_types":    True,    # auto-classify columns as dimension/measure on create
        "max_columns_per_dataset":     500,     # cap to prevent oversized datasets
        "max_datasets":                100,     # total number of datasets allowed
        "max_datasets_per_user":       10,      # self-service CAP: datasets a non-admin may own (0 = unlimited); throttles with HTTP 409 + "ask an admin", never a silent failure
        "cascading_prompts_enabled":   True,    # enable cascading filter LOVs in report builder
        "drill_hierarchies_enabled":   True,    # enable drill-down in business reports
        "aggregation_awareness_enabled": True,  # enable smart routing to pre-agg tables
        "default_row_limit":           10000,   # default max rows for business report execution
        "synonym_matching_enabled":    True,    # match NL queries against column synonyms
        "max_metrics_per_dataset":     50,      # Phase 101: max calculated metrics per dataset
        "metric_validation_enabled":   True,    # Phase 101: validate metric expression on create
        # 2026-08-22 dataset UNION: how many datasets one /api/datasets/
        # federation/union request may combine.  A CAP that THROTTLES with a
        # clear 422 naming the knob — never a silent trim of the side list.
        "max_union_datasets":          10,
    },
    "federation": {
        # ── Declared 2026-10-07 ─────────────────────────────────────
        # Read by production through an idiom the declared-config guard
        # could not see (an aliased getter, a 3-arg forwarding wrapper,
        # or a get_section sub-dict chain).  VERBATIM from the read site.
        "join_pruner_enabled":               True,      # federation_engine.py
        "synth_filter_max_primary_rows":     1000000,   # 149.5 cost gates, federation_engine.py
        "synth_filter_in_list_max_rows":     2000,
        "synth_filter_in_list_max_distinct": 200,
        "enabled":                     True,    # enable/disable federation execution
        "max_concurrent_executions":   5,       # max parallel federation queries
        "execution_timeout_seconds":   600,     # 10 min timeout per execution
        # 2026-08-09 caps-throttle-not-refuse: engine-level result bound.
        # A disclosed, configurable THROTTLE — never a refusal and never an
        # invisible cut (house rule 2026-08-08: caps throttle, gates fail).
        # HISTORY (why the number moved twice).  It began as a real memory
        # ceiling: every federation path materialised the result as ONE
        # pandas DataFrame in this pod before the parquet write, so 100K was
        # raised to 500K to stop the engine undercutting
        # business_reports.default_row_limit by 5x.  Then the WRITE was
        # streamed, then the EXECUTION was, and the justification evaporated.
        # When a caller asks for more the limit is clamped WITH a WARN log
        # and the result is stamped
        # row_limit/truncated/unstable_truncation (never a silent cut).
        # <= 0 disables the engine clamp entirely (the caller's own LIMIT
        # still applies — generated SQL always carries one).
        # 2026-08-11 — THIS IS NO LONGER A MEMORY GUARD, and it is no longer
        # applied to the DuckDB routes.  Read this before changing it.
        #
        # A row cap as a memory guard is not how enterprise engines behave:
        # Power BI, Tableau/Hyper, Trino and Snowflake all SPILL TO DISK and
        # complete; none silently returns fewer rows than asked for.  DuckDB
        # spills too, and this pod already configures it to
        # (core/duckdb_factory.py sets memory_limit + temp_directory, the same
        # policy core/reports/microcube.py uses).  Measured: a 4M-row
        # high-cardinality GROUP BY under memory_limit=256MB COMPLETES at
        # 255 MB peak RSS with a byte-identical checksum to the same query at
        # a 4 GB limit.  The cap was never what protected that route.
        #
        # 2026-08-11 (second pass) — the LAST capped route is gone too.  The
        # hybrid S3+connector query no longer merges in pandas: its connector
        # side is streamed to parquet and the join runs in DuckDB, which
        # spills like every other route (federation_engine.
        # _execute_hybrid_to_parquet).  ``_engine_cannot_spill`` is therefore
        # always False and there is no route left that a row cap protects.
        #
        # So this SHIPS DISABLED (0).  It survives only as an operator
        # GOVERNANCE knob: an admin who wants a house limit on federated
        # result size can set it, it then applies to EVERY route uniformly,
        # and the cut is DISCLOSED (row_limit / truncated /
        # unstable_truncation) — never silent.  It is NOT a memory guard;
        # do not reintroduce it as one.  Memory is bounded by
        # query_engine.duckdb_memory_limit_mb + the spill directory.
        #
        # Callers that pass this value as their own bound (agg_cache cube
        # builds) therefore pass 0, which federation_engine reads as
        # UNLIMITED — a cube silently built from a fraction of its rows and
        # then served as complete is worse than any truncated query.
        "max_result_rows":             0,
        "named_secrets_enabled":       True,    # use DuckDB CREATE SECRET for multi-S3
        "fallback_to_pragmas":         True,    # fallback to SET pragmas if secrets fail
        "execution_history_retention_days": 30, # auto-prune old execution records
        "merge_max_datasets":          5,       # max datasets in a single merged query
        "preview_row_limit":           100,     # rows for quick preview
        "distinct_values_limit":       500,     # max LOV values for cascading prompts
        # 2026-09-21 -- 15000 -> 30000.  The value is MILLISECONDS and was
        # passed verbatim to DuckDB's http_timeout, which is SECONDS: the
        # federation connection ran with a 15,000-SECOND (4h10m) timeout.
        # 30000ms = 30s = DuckDB's own default for the setting, so the
        # repair is the engine's number rather than one invented here.
        "http_timeout_ms":             30000,   # DuckDB http_timeout for REST federation (Phase 102-H)
    },
    "agg_cache": {
        "enabled":                          True,     # master toggle for aggregation cache
        "storage_dir":                      "/usr/local/querystudioapi/nfs/data/agg_cache",  # directory for rollup parquets
        "max_storage_mb":                   5120,     # 5 GB total storage quota
        "max_entries_per_dataset":          20,       # max rollup definitions per dataset
        "default_ttl_hours":                24,       # soft expiry → stale
        "hard_expiry_hours":                72,       # hard expiry → cannot serve, must rebuild
        "stale_serve_enabled":              True,     # serve stale data while triggering background refresh
        # 2026-06-24 -- flipped from False to True per operator
        # directive "enable all".  Without this, agg_cache only
        # populates when admin manually defines rules.  With it,
        # hot dashboard queries auto-build their own rollups on
        # first miss; subsequent queries serve from cache (ms not s).
        # suggestion_enabled=True already finds the patterns; this
        # closes the write-side loop.  Build runs in background
        # (refresh_timeout_seconds=1800 max); the LIVE query gets
        # the slow path on the miss + the fast path on every repeat.
        "write_through_enabled":            True,
        "refresh_timeout_seconds":          1800,     # 30 min max build time
        "cleanup_interval_hours":           6,        # periodic cleanup of expired entries
        "suggestion_enabled":               True,     # auto-suggest cache rules from usage patterns
        "suggestion_min_queries":           5,        # min query occurrences before suggesting
        "suggestion_analysis_window_days":  7,        # analyze last N days of execution history
        "incremental_default":              False,    # default incremental_enabled on new entries
        # Phase 5 RLS-aware cubes (2026-08-09, target architecture §3.3):
        # OFF = today's behaviour byte-for-byte (RLS-scoped callers skip the
        # agg cache entirely).  ON = cubes are built with policy-referenced
        # security-dimension columns in their grain + SUM/COUNT pairs for
        # avg, and RLS-scoped callers are served through the fail-closed
        # eligibility gate (core.agg_cache.check_cache_hit_rls) with their
        # resolved predicates applied as a DuckDB WHERE over the cube.
        # This flag is an access WIDENER — it ships OFF and its unreadable-
        # config fail mode is OFF.
        "rls_serving_enabled":              False,
        # ── 2026-08-09 reports rewire Phase 7 — AggregationAwareness ────────
        # Route a measure to a CUSTOMER-OWNED pre-aggregated table.  The
        # numbers then come from a table QueryStudio does not control and
        # cannot verify by construction, so this is a NUMBERS widener and
        # ships OFF, same posture as rls_serving_enabled above.  A mapping
        # never serves until a probe has POSITIVELY passed (agg-table total
        # vs the same total computed live from raw); mismatch persists
        # is_enabled=False.  Re-verification is a CAP — a stale verdict just
        # means "prove it again before serving", never a wrong number.
        "agg_awareness_serving_enabled":    False,
        "agg_awareness_reverify_hours":     24,
        "agg_awareness_tolerance":          1e-6,     # float compare epsilon
        # ── Phase 6 — cube adoption ─────────────────────────────────────────
        # Recommendations are ADVICE.  auto_adopt builds them unattended, so
        # it ships OFF: an operator should not discover new disk usage and
        # refresh load they never asked for.  The explicit adopt endpoint is
        # a human action and works regardless of this flag.
        "auto_adopt_enabled":               False,
        "auto_adopt_max_per_run":           3,
        "auto_adopt_interval_hours":        24,
        # How much execution history the ranking may read.  Was an accidental
        # hardcoded 50 — enough to rank only the most recent handful.
        "recommendation_history_limit":     2000,
    },
    "business_reports": {
        "enabled":                      True,     # master toggle for business report builder
        "max_reports_per_user":         50,       # max saved reports per user
        "max_sections_per_report":      10,       # max break/section definitions
        "max_parameters_per_report":    20,       # max cascading prompt parameters
        "max_running_calcs_per_report": 15,       # max running calculation columns
        # 2026-10-25 (the owner: "no more cap -- data comes in pagination ways"):
        # 0 = a report runs EVERY row; the engine streams + spills to disk, the
        # result is stored once and READ BY PAGE (viewer, published API).  A
        # report may still set its own row_limit; delivery / PDF / Excel keep
        # their own document bounds.  Was 500000 -- a silent ceiling on any
        # report bigger than that (disclosed as truncated, but still a cut).
        "default_row_limit":            0,        # 0 = unlimited (was 500,000)
        # 2026-10-31 the canvas detail popup: the rows the popup READS of a clicked
        # row's detail (a CAP -- it says "showing the first N of M"; every download
        # holds all M rows).  core/reports/canvas_actions.py::popup_max_rows
        "detail_popup_max_rows":        10000,
        # 2026-08-09 caps-throttle-not-refuse: pdf_row_limit / excel_row_limit
        # are DEFAULT execution bounds for the export endpoints, not refusals.
        # The old behaviour (HTTP 413 ROW_LIMIT_EXCEEDED after the report had
        # already executed) is gone: exports always deliver the rows they
        # fetched, disclose truncation ON THE DOCUMENT (PDF banner / Excel
        # info line) and in the X-QS-* headers, and a caller-supplied ?limit=
        # overrides these defaults.  Excel continues past the 1,048,576-row
        # sheet FORMAT limit by spilling onto additional sheets.
        # 2026-10-04 -- 50,000 -> 5,000.  MEASURED (WeasyPrint 70, the API
        # image, a 5-column detail report): peak RSS ~60 MB + ~97 KB per
        # row -- 1k rows 156 MB, 5k 545 MB, 20k 2.0 GB (and 267 s).  The old
        # 50,000 default was ~5 GB: the live download-pdf of a 5M-row report
        # OOM-KILLED the 2 GB API container with that cap applied exactly as
        # configured.  pdf_max_rows below is the ceiling an explicit ?limit=
        # cannot pass.
        "pdf_row_limit":                5000,     # default rows fetched for PDF export
        # 2026-10-04 -- the PDF MEMORY CEILING.  Every PDF document (the
        # report route, share/embed links, subscription delivery) carries at
        # most this many rows -- an explicit ?limit= included -- and says so
        # ON the document, pointing at the CSV export for every row.  <= 0
        # disables the cut; the render's memory budget
        # (pdf_render_memory_mb) still refuses a document too big to render.
        "pdf_max_rows":                 5000,
        # 2026-10-04 -- WHERE a PDF is rendered.  "subprocess" (default): a
        # child process with a memory budget, so a document too large for
        # the pod is REFUSED (422 naming the limit) instead of OOM-killing
        # the API for everyone.  "inprocess" is the escape hatch (the old
        # behaviour).  core/reports/pdf_engine.py::render_pdf is THE door.
        "pdf_render_isolation":         "subprocess",
        # The render child's resident-memory budget, MB.  The effective
        # budget is min(this, 70% of the container limit / the concurrency
        # below) -- see pdf_engine.render_budget_bytes.
        "pdf_render_memory_mb":         1024,
        "pdf_render_timeout_seconds":   600,
        # Renders at once per process; a further render WAITS for a slot.
        "pdf_render_max_concurrent":    2,
        "excel_row_limit":              1000000,  # default rows fetched for Excel export
        # 2026-10-04 -- the default CSV row bound.  0 = EVERY row: CSV is the
        # escape hatch for large results and it streams from the artifact
        # in record batches (core/reports/export_stream.py), so its memory
        # does not grow with the result.  Was excel_row_limit (1,000,000).
        "csv_row_limit":                0,
        # 2026-10-04 -- the largest result Excel renders through the styled
        # object model (stripes, per-cell styles, banded sections).  MEASURED
        # ~2 KB of heap per 5-column row there (100k rows 198 MB, 200k
        # 418 MB; 1M ~2 GB -- the live 309 s / near-OOM export).  Above it
        # the workbook is STREAMED from the artifact in write-only mode
        # (measured flat ~65 MB at 1M rows), spilling onto a new sheet every
        # 1,048,575 data rows; cosmetics drop, data does not.
        "excel_styled_max_rows":        50000,
        # SCALE-1 (2026-08-22): the HARD ceiling on how many rows a single
        # SYNCHRONOUS export request materialises into the API pod's Python
        # heap (list-of-dicts).  This is an OOM GATE, not the row-limit
        # throttle: a caller may still raise ?limit= at will (caps throttle,
        # not refuse), but the engine wrote those rows to a parquet artifact,
        # and reading ALL of them back into Python OOM-kills the single-replica
        # API pod (?limit=50000000 was honoured verbatim).  When an artifact
        # exceeds this, the export delivers the first N, DISCLOSES the cut on
        # the document + X-QS-* headers, and points at the background download
        # (Download Centre) for the complete result.  <=0 disables the guard.
        "export_materialize_cap":       1000000,  # max rows a sync export pulls into RAM
        "embed_row_limit":              100000,   # max rows in embedded report (100K)
        "cascade_lov_limit":            500,      # max LOV values for parameter dropdowns
        # 2026-10-24 -- how long a column's value list is kept
        # (core/column_value_cache.py: the query builder's picker AND report
        # parameters read ONE cache)
        "lov_cache_seconds":            300,
        "page_size":                    200,      # default rows per page (server-side pagination)
        "max_page_size":                10000,    # hard cap on page_size query param
        "auto_save_interval_seconds":   30,       # wizard auto-save interval
        # 2026-09-15 -- DECLARED, DISPLAYED, ENFORCED NOWHERE, and drifted
        # from the surface it names.  There are nine business-report download
        # routes (pdf / excel / csv, each for owner, shared token and
        # embedded token) and no json one, so ["csv", "json"] described a
        # deployment that does not exist: it named a format that is never
        # served and omitted two that are.  Removing "csv" from it did not
        # stop one CSV download.  Now enforced in business_reports_api
        # (_enforce_export_format) on all nine routes, and the default names
        # what is actually served -- so the EFFECTIVE set is unchanged
        # (everything was allowed, everything still is) until an operator
        # narrows it, which is the point of the key.  An EMPTY list fails
        # OPEN with an ERROR: "nothing allowed" and "cleared by accident"
        # are indistinguishable, and reading it as refuse-everything turns a
        # typo into a total export outage.
        "export_formats":               ["pdf", "excel", "csv"],
        # 2026-08-30 — rendered-export size at/above which the response
        # streams FROM THE REGISTERED FILE instead of a second in-memory
        # buffer.  Body bytes are identical either way; <=0 always
        # inlines.  Declared at the reader's own fallback (10 MiB).
        "export_inline_max_bytes":      10485760,  # 10 MiB
        # 2026-09-27 -- PROGRESSIVE SERVING FOR A REPORT WITH NO PARTITION
        # PLAN.  The pure-SQL-connector route streams the source cursor into
        # a PARTS dataset (core/connector_to_parquet.execute_sql_to_parts)
        # instead of one parquet, so the paged reader can serve page 1 from
        # the durable parts while the drain continues, then consolidates to
        # the single artifact every other reader opens.  The final multiset
        # is the canonical run's (proven by value in
        # tests/test_report_progressive_stream_parts_2026_09_27.py).  Ships
        # OFF: the part size is feed_generation.parts_rows_per_part (5M rows
        # by default), so a deployment turns this on together with a part
        # size that makes the first page arrive early.
        "progressive_stream_parts":     False,
        "async_execution_ttl_seconds":  3600,     # in-memory async execution TTL (1 hour)
        # 2026-08-09 cross-pod completion #3 — how long an execution artifact
        # ({execution_id}.parquet in the shared downloads dir) that is still
        # REFERENCED by a federation_executions / br_async_jobs row stays
        # protected from the temp-file cleaner (scheduler._cleanup_temp_files).
        # A CAP (disk), not a gate: the cleaner throttles reclamation, it
        # never refuses an execution.  Floored at 1 h and at
        # async_execution_ttl_seconds by the cleaner.  Instance-referenced
        # artifacts are governed by instance_max_age_seconds instead.
        "artifact_retention_seconds":   21600,    # 6 h
        "pdf_page_size":                "A4 landscape",   # WeasyPrint @page size
        "pdf_primary_color":            "#1976d2",        # PDF header background color
        "enable_published_view_source": True,             # Phase 100: allow PV as data source
        # 2026-08-09 reports rewire Phase 1 — microcube (/cube endpoint) DuckDB
        # resource posture.  CAPS that throttle (spill via temp_directory),
        # never refuse.  Defaults = the settings the reference numbers were
        # measured at (core/reports/microcube.py module docstring).
        "microcube_threads":            4,        # SET threads per /cube query
        "microcube_memory_limit":       "2GB",    # SET memory_limit per /cube query
        # 2026-08-09 reports rewire Phase 3 — client/server engine switchover.
        # At or below this row count the BROWSER engine (useReportEngine.ts)
        # keeps rendering, byte-identical to today; above it the viewer drives
        # /cube.  A CAP, not a gate: 0 or negative forces every report back to
        # the client engine, which is the instant rollback.  50_000 x the
        # measured 2072 B/row is ~104 MB of JS heap — 5-6x under the observed
        # 250-300K-row cliff.
        "client_engine_max_rows":       50000,
        # 2026-08-09 reports rewire Phase 2 — report-instance serving (§5).
        # instance_serving_enabled: ON since 2026-09-26 (owner decision); off, every execute
        # path is byte-identical to today (no write-through, no serve).
        # Flipping it is a deliberate, coordinated one-line act.  The other
        # two are CAPS: retention keeps the newest N instances per serve
        # key (BO latest-N).
        #
        # instance_max_age_seconds is the ONE instance-age knob and governs
        # BOTH ends of instance lifetime (D4, 2026-08-09 cross-feature
        # review — the two must not drift):
        #   * serving — a serve past this age is STALE (still served, WITH
        #     "as of" disclosure + background refresh — never refused);
        #   * artifact protection — the temp-file cleaner
        #     (scheduler._cleanup_temp_files) exempts an instance's
        #     artifact bytes for this window (floored at 1 h when
        #     positive).
        # 0 disables age-out for BOTH: instances never go stale by age AND
        # their artifacts stay exempt from the cleaner for as long as a
        # live ready/stale instance row references them (row-lifetime
        # bounds — instance_retention_count pruning, expires_at, status
        # demotion — still reclaim the bytes once the row dies).
        # 2026-09-26: switched ON by default (owner decision; coded, wired and
        # tested since 2026-08-09, held off only for a staging soak).
        "instance_serving_enabled":     True,     # serve-from-instance + write-through
        "instance_retention_count":     3,        # newest N instances kept per serve key
        "instance_max_age_seconds":     86400,    # instance age window: staleness cap + cleaner artifact exemption; 0 = never age out (both)
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "async_running_stale_after_seconds":    3600,
        # 2026-09-28: how long an ASYNC report run that the REPORT gate has
        # already accepted waits for the pod's global query capacity
        # (query_engine.max_concurrent_global, a counter the SQL editor lanes
        # hold) before its job fails with the capacity reason plus the time
        # waited.  The async path is the one where the user chose to wait
        # (the UI polls; a completion notification exists), so it waits
        # with bounded backoff (0.5 s -> 5 s, jittered) rather than failing
        # the moment the SQL editor is busy.  0 = the pre-2026-09-28
        # behaviour: fail at once.  The SYNC routes never wait (503 +
        # Retry-After is right while the caller holds a connection).
        "async_capacity_wait_seconds":          120,
        "share_export_enabled":                 True,
        "share_export_row_limit":               10000,
        "token_request_window_seconds":         60,
        "token_requests_per_window":            30,
    },
    "pivot_reports": {
        "enabled":              True,      # master toggle for pivot report builder
        "max_row_dimensions":   3,         # max dimension columns in row headers
        "max_col_dimensions":   2,         # max dimension columns in column headers
        "max_measures":         5,         # max measure/value fields
        "max_row_groups":       500,       # max distinct row groups in result
        "max_col_groups":       50,        # max distinct column groups (pivot columns)
        "default_aggregation":  "sum",     # default agg when dragging measure to Values
    },
    "aws_portal": {
        "enabled":              False,       # enable AWS portal credential provider
        "portal_base_url":      "",          # base URL (e.g. https://awsportal.company.com) — derives jwt/roles/creds endpoints
        "jwt_url":              "",          # override: POST endpoint for JWT token (default: {portal_base_url}/v1/jwttoken)
        "creds_url_template":   "",          # legacy: direct credential GET URL template (skips role lookup)
        "account_id":           "",          # AWS account ID — used to match the correct role ARN
        "role_name":            "",          # IAM role search term (e.g. "app-NormalAppRole")
        "sf_ref_no":            "",          # service first number — passed to credential endpoint
        "service_username":     "",          # DEPRECATED 2026-10-30, NOT READ for any login: the default login is ONLY service_system_account_id (aws_portal_auth.global_service_login); a saved value with no account chosen makes the Admin page / status / a relying connection say TYPED_PAIR_NOT_USED.  Kept declared so an old config.json still loads.
        "service_password":     "",          # DEPRECATED 2026-10-30, NOT READ for any login (see service_username)
        "service_system_account_id": 0,      # THE default (global) portal login: a System Account (AWS Portal / AD, Vault or its own password); 0 = none (2026-10-30: the only one -- the typed pair above is no longer used)
        "proxy_url":            "",          # corporate proxy URL (e.g. http://user:pass@proxy:8080) — used if proxy_host is empty
        "proxy_host":           "",          # corporate proxy hostname (e.g. proxy.corp.com) — auto-builds proxy URL
        "proxy_port":           8080,        # corporate proxy port
        "proxy_username":       "",          # proxy authentication username
        "proxy_password":       "",          # proxy authentication password
        "verify_ssl":           False,       # verify SSL certs for portal requests (False for on-prem)
        "creds_ttl_seconds":    3300,        # cache TTL (55 min, STS default is 1hr)
        "timeout_seconds":      30,          # HTTP request timeout
        "auto_retry_on_expiry": True,        # auto-refresh portal creds on TokenExpiredError
        "max_retry_attempts":   1,           # max retries per request on token expiry
        "system_account_fallback": True,     # DEPRECATED 2026-10-30, read by NOTHING (it named a fall back to the typed config.json pair, which is gone).  What replaced it: the default login is the chosen System Account (service_system_account_id); a chosen account that cannot log in is None, never another login.  Kept declared so an old config.json still loads.
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "password_vault_ttl_seconds":        28800,
        "preflight_min_lifetime_seconds":    600,
    },
    "proxy": {
        "enabled":          False,     # enable global proxy for outbound connections
        "url":              "",        # full proxy URL (e.g. http://proxy:8080) — used when host is empty
        "host":             "",        # proxy hostname — auto-builds http://host:port if url is empty
        "port":             8080,      # proxy port
        "system_account":   "",        # system account name for proxy auth (encrypted in DB, managed via Admin > System Accounts)
        "no_proxy":         "",        # comma-separated bypass list (e.g. "localhost,169.254.169.254,.internal.com")
        # When true (default), boto3 / DuckDB / subprocess proxy code paths
        # automatically bypass the corporate proxy for any S3 connection
        # whose ``endpoint_url`` hostname is NOT an AWS-owned domain
        # (``*.amazonaws.com`` / ``*.amazonaws.com.cn``).  Rationale: a
        # corporate egress proxy is sized + routed for outbound public-
        # internet S3 traffic.  Any custom endpoint_url is on-prem /
        # in-network — sending it through the egress proxy either fails
        # (proxy can't resolve internal hostname) or forwards to the
        # wrong public-internet server.
        # Set false ONLY if you genuinely route on-prem S3 traffic
        # through your corporate proxy (rare).  Explicit ``no_proxy``
        # entries still win over either default.
        "auto_bypass_custom_endpoint": True,
        "apply_to_boto3":   True,      # inject proxy into boto3/botocore clients
        "apply_to_duckdb":  True,      # SET http_proxy in DuckDB httpfs connections
        "apply_to_httpx":   True,      # inject proxy into httpx Client/AsyncClient
    },
    "chatbot": {
        # ── Declared 2026-09-02.  BOTH were LIVE and UNDECLARED: the
        # accessors read get("chatbot", "faq"/"glossary", {}) and real
        # consumers use them (suggest_api serves the FAQ map; the glossary
        # is applied before NL-to-SQL pattern matching).  Missing from
        # _DEFAULTS they were invisible three ways at once ---
        # scripts/init_config.py generates config.json FROM _DEFAULTS, so a
        # fresh deployment had neither key and no way to discover them; the
        # startup validator reported an operator who DID set one as a typo
        # ("unknown config key"); and the declared-vs-fallback drift guard
        # could not see them.  Declared as {} == the accessors' own
        # fallback, so nothing moves for anyone.
        "faq":       {},
        "glossary":  {},
        # Column classification patterns for the AI Assistant chip suggestions.
        # Patterns are matched case-insensitively as substrings of column names.
        # Add your organisation's column names or partial patterns to extend detection.
        "numeric_patterns": [
            "amount", "amt", "notional", "exposure", "pnl", "balance", "debit", "credit", "payment", "charge",
            "revenue", "income", "expense", "cost", "price", "fee", "tax",
            "profit", "margin", "discount", "interest", "principal", "penalty",
            "salary", "wage", "bonus", "commission",
            "total", "subtotal", "value", "rate", "ratio", "percentage", "percent",
            "qty", "quantity", "count", "number", "num", "volume", "weight", "size",
            "score", "rank", "metric", "measure", "kpi",
        ],
        "category_patterns": [
            "status", "state", "flag", "indicator", "active", "enabled",
            "type", "category", "class", "kind", "level", "tier", "grade", "segment",
            "dept", "department", "division", "team", "group", "unit", "branch",
            "entity", "company", "organisation", "organization", "business",
            "country", "region", "city", "zone", "area", "location", "site",
            "currency", "ccy", "source", "channel", "product",
            "brand", "vendor", "supplier", "customer", "client",
        ],
        "date_patterns": [
            "date", "dt", "time", "ts", "timestamp",
            "period", "month", "year", "day", "week", "quarter",
            "fiscal", "posted", "effective", "settlement", "maturity", "created",
            "updated", "modified", "processed", "received", "booked",
        ],
        "id_patterns": [
            "_id", "_key", "_ref", "_uuid", "_guid", "_code", "_num", "_no",
            "_hash", "_token", "_seq", "id_", "key_", "ref_", "uuid_",
        ],
        # Phase 57 — Enhanced NL Chatbot
        "semantic_context_enabled":    True,    # use semantic layer / schema_cache for NL enrichment
        "time_intelligence_enabled":   True,    # enable YTD/MTD/SPLY/PoP/moving-avg patterns
        "max_pattern_alternatives":    3,       # max alternative SQL variants returned
    },
    "suggestion_corrections": {
        "enabled":                  True,    # master toggle for suggestion learning
        "max_corrections":          1000,    # cap total stored corrections
        "agg_pattern_priority":     True,    # pattern rules first, corrections override
        "join_correction_priority": True,    # prefer learned join keys over heuristic
        "retention_days":           365,     # auto-prune corrections older than N days
        # FB-48 (2026-09-20): "chart_feedback_enabled" and
        # "pivot_feedback_enabled" REMOVED.  They gated a chart/pivot preset
        # like-dislike feature that does not exist in this product -- there
        # is no feedback route, no table and no writer, so the flags could
        # only ever have been true-about-nothing.  If the feature is built,
        # declare the flag WITH it.
        "nl_feedback_lookup_enabled":       True,   # wire NL→SQL feedback into generation
        "nl_feedback_min_similarity":       0.8,    # min Jaccard token overlap for match
        "nl_feedback_auto_return_threshold": 0.9,   # similarity above which to auto-return cached SQL
    },
    # 2026-09-15 — per-query log FILES.  core/execution_stage.py writes one
    # log file per execution and its cleanup_old_query_logs() has carried
    # the instruction "Call from a scheduled job" since it was written, with
    # no job calling it: a filesystem leak no table-retention sweep would
    # ever notice.  Now swept daily by retention_daemons' query_log_cleanup.
    # Both values equal cleanup_old_query_logs' own signature defaults, so
    # the declaration, the fallback and the function agree.  0 = keep
    # forever.
    "query_logs": {
        "retention_days":   7,
        "max_files":        1000,   # newest N kept regardless of age
    },
    # Phase 60 — Delivery & Alerts
    "delivery": {
        "enabled":                          True,
        "max_subscriptions_per_user":       50,
        "max_recipients_per_subscription":  20,
        "retry_max_attempts":               3,
        # ``retry_backoff_minutes`` was REMOVED on 2026-09-15, not wired.
        # It described a retry model this code deliberately does not use.
        # core/delivery_engine.py::_apply_failure_ladder (F-P3A-09) advances
        # a failed subscription's next_send_at to its NEXT CRON SLOT -- the
        # docstring's words are "a failing subscription retries on its own
        # schedule, never on every tick" -- and a 5-minute backoff is the
        # every-tick behaviour that rule exists to prevent.  So the honest
        # options were to delete the key or to contradict the design; there
        # was no version of "wire it" that left the product coherent.
        # Nothing read it: no engine, no route, no admin screen, no
        # frontend.  A knob whose only effect is to make an operator believe
        # in a mechanism is worse than no knob.
        # 2026-10-13 -- the owner: "we should keep all audit ... run history
        # n all everything".  0 = keep forever; a deployment that must purge
        # sets a number.
        "delivery_history_retention_days":  0,
        "max_pdf_rows":                     10000,
        "unsubscribe_token_expiry_days":    365,
        "batch_size":                       20,
        "check_interval_minutes":           5,
        # Delivery-audience policy (core.reports.authorization): comma-separated
        # list of e-mail domains subscription recipients must belong to.
        # Empty (default) = allow all domains (syntax check only).
        "allowed_recipient_domains":        "",
    },
    "rest_api": {
        "enabled":                    True,
        "max_response_size_mb":       50,
        # 0 = UNLIMITED (product-wide rule).  Was a hard 100000 that silently
        # truncated: a 250k-row REST/SAP endpoint delivered 100k and reported
        # SUCCESS.  Default flipped to 0 on 2026-08-17 -- an operator who wants
        # a governor sets one explicitly.
        "max_rows_per_query":         0,
        # Runaway-pagination guard.  NOT a row cap: exhausting it now RAISES
        # (a broken cursor that never terminates must fail loudly, not return
        # a silent partial).  0 = no page guard.
        "max_pages":                  500,
        "default_timeout_seconds":    30,
        "max_timeout_seconds":        300,
        "oauth2_token_cache_seconds": 3500,
        "flatten_max_depth":          5,
        # 2026-08-20 -- RATIONALE RECOVERED FROM THE DELETED EXAMPLE.
        # config.example.json set this TRUE with the note: "Set TRUE for
        # on-prem deployments where REST connections (SAP, Trino portal,
        # Starburst portal, internal SOAP) target internal hostnames that
        # resolve to RFC1918 IPs."  That is this deployment, and the true
        # value now lives only in the gitignored config.json -- so without
        # this comment the reason was unrecoverable from the repo and a
        # fresh install would block every internal REST connection with no
        # hint why.  The CODE default stays False: allowing private IPs is
        # the SSRF guard being relaxed, and that has to be an explicit,
        # per-deployment opt-in rather than something a default hands out.
        "allow_private_ips":          False,
    },
    "horizontal_workers": {
        "registry_backend":            "auto",   # "auto" | "redis" | "sqlite"
        "heartbeat_interval_seconds":  15,
        "heartbeat_ttl_seconds":       45,        # 3x interval — miss 3 heartbeats → dead
        "worker_eviction_seconds":     120,       # remove from registry after this
        "max_workers_per_host":        10,
        "enable_load_aware_claiming":  True,
        "memory_threshold_pct":        85,        # skip claiming if memory usage > this
        "cpu_threshold_pct":           90,        # skip claiming if CPU > this
        "metrics_retention_hours":     24,
    },
    "streaming": {
        "cancel_enabled":              True,
        "max_active_streams":          50,        # max concurrent streaming queries
        "cancel_check_interval_rows":  5000,      # check cancel every N rows processed
        # ── 2026-08-21 — SQL-CONNECTOR BROWSING FROM A LIVE CURSOR ────────
        # An interactive Starburst query used to materialise its ENTIRE result
        # to a local parquet before the grid showed anything (measured: a 1 GB
        # file for a query the engine answers in 7s, into an unmanaged
        # data/parquet holding 11 GB with no code that deletes from it).  The
        # grid is now fed straight from a forward cursor and NOTHING is
        # written; a user who wants the whole result asks for the background
        # download, which lands in the Download Centre.
        #
        # Memory is bounded by ROWS RETAINED, not by result size, so scrolling
        # 200M rows costs the same as scrolling 1,000.  Rows falling off the
        # front are what makes a BACKWARD jump re-execute instead of OOM.
        # (All three are duplicated as inline fallbacks in
        # core/stream_cursor_session.py — keep them in step.)
        "max_buffered_rows":           50_000,
        # A live session pins one query on the source.  Idle sessions are
        # reaped and their cursors cancelled AT THE SOURCE.
        "session_idle_timeout_seconds": 300,
        # Concurrent browsing sessions; at capacity the least-recently-used is
        # evicted and its query cancelled rather than left running.
        "max_sessions":                32,
        # How far ONE request may fast-forward a cursor.  `page` has no
        # ceiling on the wire, so page=1000000 would otherwise drain an entire
        # fact table through the pod to return rows nobody asked for.  This
        # bounds WORK PER REQUEST, not reachable data: scrolling advances one
        # page at a time and never approaches it.
        "max_fast_forward_rows":       2_000_000,
    },
    "presigned_url": {
        "expiry_seconds":              900,       # 15 min default
        "retry_enabled":               True,
        "max_retries":                 2,
        "retry_on_403":                True,      # re-generate URL on 403 (expired signature)
        "retry_delay_seconds":         1,
        "download_timeout_seconds":    120,       # Phase 78G — configurable download timeout
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "vpc_expiry_seconds":    21600,
    },
    # Phase 79 — DuckDB Resilience
    "duckdb": {
        "circuit_breaker_enabled":      True,   # trip breaker after N engine crashes
        "retry_on_engine_error":        True,   # retry once on subprocess crash (not timeout/bad SQL)
        "retry_max_attempts":           1,      # max retries (0 = no retry)
        "retry_delay_seconds":          1,      # seconds to wait before retry
        # ── Spill quota (core/duckdb_resource_limits.py) ──────────────────
        # 2026-08-20 -- DECLARED.  All four are live config knobs read by
        # duckdb_resource_limits with inline fallbacks, and every one of them
        # was documented ONLY in config.example.json.  When that file was
        # deleted they became undiscoverable: the `duckdb` section exists, so
        # validate_config()'s unknown-SECTION check never mentions them, and
        # nothing else in the repo lists them.  Values are the inline
        # fallbacks verbatim -- declaring them changes no behaviour.
        #
        # Each also has an env override, which WINS over config:
        #   DUCKDB_SPILL_QUOTA_GB / QS_SPILL_POD_COUNT /
        #   QS_SPILL_DIR_SHARED / QS_SPILL_DIR_CAPACITY_GB
        "spill_quota_gb":               0,      # 0 = derive from memory_limit (4x ratio, floored at the historical default)
        "spill_pod_count":              "",     # blank = auto-detect; set when several pods share one spill volume
        "spill_dir_shared":             None,   # None = auto-detect whether the spill dir is shared across pods
        "spill_dir_capacity_gb":        "",     # blank = read from the chart's emptyDir sizeLimit
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "hybrid_reserve_pct":    '',
    },
    # Phase 78 — S3 Production Hardening
    "s3_validation": {
        "bucket_name_regex_aws":                   r"^[a-z0-9]([a-z0-9\-]{1,61}[a-z0-9])?$",
        "bucket_name_regex_onprem":                r"^[a-zA-Z0-9][a-zA-Z0-9\-_\.]{0,253}[a-zA-Z0-9]$",
        "validate_bucket_on_create":               True,
        "validate_arn_format":                     True,
        "arn_regex":                               r"^arn:(aws|aws-cn|aws-us-gov):iam::\d{12}:role\/[\w+=,.@\-\/]{1,256}$",
        "root_prefix_test_on_create":              True,
        "warn_unsupported_partition_ops":          True,
        "max_folder_browser_items":                500,
        "partition_refresh_mutex_timeout_seconds": 30,
        "file_list_max_files":                     5000,
    },
    # Phase 130 hotfix-13 — Role configuration.
    # Generic role-name configuration so admins can rename the "support"
    # role to match local conventions (e.g. "operator", "l1_support",
    # "platform_ops") via the admin UI without changing code.
    "roles": {
        "support_role_name": "support",
    },
    # Phase 76 — Feed File Generation
    "feed_generation": {
        "enabled":                     True,
        # 2026-10-25 -- the data-entitlement switch of a feed whose own switch
        # nobody SET (feed_configs.entitlement_mode NULL), read live per run
        # (core/row_security/entitlement.py::effective_mode).  off = the
        # feed's dimensions do not apply (its stored row policies and its
        # fail-closed principal still do); apply = the OWNER GROUP's values --
        # a feed with no owner group is then REFUSED at run, so set owner
        # groups before turning this to apply.
        "default_entitlement_mode":    "off",
        "max_concurrent_native":       3,
        # 2026-10-14 -- the memory ONE native feed run may need (a 460-column
        # query, its parquet batches and the CSV writer's processes).  The
        # pod runs at most  cgroup memory / this  feeds at once, never more
        # than max_concurrent_native: found live when three 460-column feeds
        # were started together in a 2 GB scheduler and the kernel killed it,
        # losing all three.  The production feed worker (8 GiB) keeps its 3.
        # 0 = no memory bound.
        "native_memory_per_run_mb":    2048,
        # 2026-10-26 -- a run put back on the queue because the worker running
        # it was STOPPED (restarted, or killed for memory) is tried again at
        # most this many times; the next stop fails it for good, in plain
        # words (core/feed/run_reclaim.py).  The owner's 2M x 600-column feed
        # "restarted 10 times and never completed": every reclaim re-queued it
        # and nothing counted.  0 = never tried again by itself.
        "max_run_reclaims":            1,
        # 2026-10-14 -- a worker shutting down (a deploy, a restart) waits this
        # long for its runs to finish, then closes the publish gate and hands
        # the rest back to the queue (core/feed/run_lifecycle.py).  Inside the
        # pod's grace period (Kubernetes 30 s; the charts give 60 s).
        "shutdown_drain_seconds":      20,
        # 2026-10-14 -- a running feed that has not reported progress for
        # this long is SHOWN as "no progress for N min" (core/feed/
        # run_progress.py).  Visibility, not a gate: nothing is failed by it.
        "progress_stale_seconds":      300,
        # 2026-10-24 -- "TEST AS FEED" (core/feed/test_as_feed.py): an editor
        # runs the feed's source query under the feed's OWN principal, bounded
        # -- at most this many rows shown (a request above the module's
        # ceiling is refused), and the whole preview stopped after this many
        # seconds.  Nothing is delivered; no run row is written.
        "test_as_feed_max_rows":       100,
        "test_as_feed_timeout_seconds": 60,
        # 2026-10-14 -- a run past its job budget keeps going while it is
        # MOVING (its counters changed within this many seconds); a run that
        # stops moving is stopped (core/feed/run_progress.still_progressing)
        "progress_stall_seconds":      1800,
        "output_dir":                  "/usr/local/querystudioapi/nfs/data/feeds",
        # 2026-08-13 -- WAS 1000000, which SILENTLY TRUNCATED every larger
        # feed.  A 70M-row feed produced a 1M-row file and reported success:
        # the connector path breaks out of its stream at the cap and the
        # DuckDB path appends LIMIT, neither disclosing anything.  Worse,
        # ``limit: 0`` -- the spelling that means UNLIMITED everywhere else
        # in this product -- was coerced BACK to the cap by
        # ``if max_rows <= 0: max_rows = max_output_rows``.
        #
        # Same posture as federation.max_result_rows above: 0 = UNLIMITED,
        # kept only as OPERATOR GOVERNANCE, never as a memory guard.  Both
        # feed routes STREAM (connector: execute_query_streaming -> chunked
        # ParquetWriter; DuckDB: to_arrow_reader -> ParquetWriter), so memory
        # is O(one chunk) regardless of row count -- the cap was never what
        # kept the pod alive.  When a cap IS set and it bites, the run now
        # says so loudly rather than shipping a short file.
        "max_output_rows":             0,
        # 2026-09-15 -- max_file_size_mb had been DECLARATION ONLY since it
        # shipped: displayed in two admin screens, read by no code, so a
        # 20 GB file delivered and certified while the operator believed a
        # 500 MB ceiling was in force.  Now checked in feed_engine after the
        # format stage and before the first delivery hop.  0 = unlimited.
        "max_file_size_mb":            500,
        # What to DO when the ceiling is exceeded: "warn" (deliver, but log
        # at ERROR and record the verdict on the run) or "fail" (refuse
        # before delivery).  Default warn, deliberately: the rows are
        # already written so there is nothing to throttle, and defaulting to
        # refuse would start failing live feeds against a number that has
        # never done anything and so has never been calibrated.  An operator
        # who wants the ceiling to bite sets "fail".
        "max_file_size_action":        "warn",
        "default_output_format":       "csv",
        "filename_template":           "{name}_{date}.{ext}",
        "auto_route_threshold_rows":   500000,
        # 2026-10-26 -- a WIDE run weighs rows x columns / this many columns
        # in the size tiers (core/feed/run_size.py::width_weighted_rows).
        "auto_route_width_base_columns": 100,
        # 2026-10-26 -- a run with NO size (no admin estimate, no upstream
        # ROW_COUNT, no previous run) is COUNTED on the source before the
        # engine is chosen (core/feed/size_probe.py); a count still running
        # after the timeout sizes the run as large.
        "size_probe_enabled":          True,
        "size_probe_timeout_seconds":  30,
        "retry_max_attempts":          2,
        "retry_delay_seconds":         60,
        # 2026-10-13 -- the owner: "keep all audit ... run history n all
        # everything".  A feed's executions (every delivery, its rows, its
        # certification) are its audit trail: 0 = keep forever.  A
        # deployment that must purge sets a number (legal holds still win).
        "execution_history_retention_days": 0,
        # 2026-09-03 — how long a feed DELIVERABLE stays downloadable
        # from the Download Centre.  Deliberately NOT the same knob as
        # execution_history_retention_days: a run RECORD is metadata and
        # cheap to keep, a delivered FILE is the counterparty's data and
        # its lifetime is a data-retention decision, not a housekeeping
        # one.  0 means the registration never expires — the operator
        # decides when it goes, which is the right default for an
        # artifact somebody may have to produce at audit.
        "download_retention_days":     0,
        "cleanup_interval_hours":      6,
        "chunk_size":                  100000,
        # 2026-10-11 -- a CAP, in CELLS (rows x columns), on what ONE stage
        # of ONE native run holds as Python objects at once: the rung-3
        # stream's fetched + queued batches, and a renderer's pandas frame
        # (core/feed/batch_budget.py).  Both sized their batches in ROWS
        # (100,000), so memory grew with a feed's WIDTH: the owner's
        # 75-column query took the scheduler 945 -> 2,031 MiB in 25 s with
        # three concurrent 1M-row runs (OOM-killed), and one render peaked
        # at 1,436 MiB (13,333 rows: 647 MiB, same 25 s).  A 460-column
        # query would need several GB per run.  0 = no cap.  A throttle,
        # never a gate: it changes how rows are batched, never which rows
        # are written.
        "max_cells_in_memory":         1_000_000,
        # 2026-10-13 (the owner: "very important") -- a large CSV is
        # rendered by several PROCESSES, each a run of the source's row
        # groups, joined in order: the same bytes one process writes
        # (core/feed/csv_parallel.py).  The owner's 1M x 460 month end spent
        # 377 s of 643 s writing CSV on one core.  0 = one worker per CPU
        # the pod may use (cgroup quota, not the host's cores); 1 = off.
        # The cell budget above is SHARED by the workers.  A throttle,
        # never a gate.
        "csv_parallel_workers":        0,
        # fewer rows than this are written by one process (starting workers
        # costs more than it saves)
        "csv_parallel_min_rows":       200_000,
        # 2026-10-14 -- the memory ONE CSV worker process may use (measured:
        # ~490 MB on the owner's 460-column month end).  Workers are started
        # only for the memory the pod has FREE (cgroup limit - in use -
        # margin); too little = one process.  Found live: four workers on a
        # 2 GB scheduler already using 1.7 GB -- the kernel killed the pod
        # and the run.  0 = no memory bound.
        "csv_parallel_worker_mb":      512,
        # 2026-10-12 (owner R2) -- the user_groups NAME whose members may
        # RELEASE or REJECT a file the row-count check held
        # (core/feed/variance_hold.py).  Configuration, not code: a group
        # that does not exist means NOBODY may release, said on the screen
        # and in the 409 -- never "everybody".
        # 2026-10-12 (owner: "can't just hardcode") -- empty by default:
        # approvers are DATA (feed_hold_approvers, mapped from the Variance
        # holds popup); a deployment may still name a global group here.
        "variance_hold_release_group": "",
        # 2026-10-12 (owner R5) -- the SLA board's "at risk" window: a run not
        # yet delivered whose deadline is this close (core/feed/sla_board.py).
        "sla_at_risk_minutes": 30,
        # ── Disk-space preflight (2026-08-22, design_starburst_140m bug #5).
        # DECLARED by the Phase-0 Starburst agent under the ownership
        # exception (config.py otherwise untouched) — an undeclared key
        # read via getattr(..., default) is how a whole Spark branch
        # stayed dead here for months.  A 140M-row native feed needs
        # 5-40 GB of pod disk and used to discover ENOSPC hours in.  The
        # preflight refuses BEFORE work starts, and only when even the
        # most OPTIMISTIC size estimate (min_bytes_per_row is deliberately
        # the zstd-parquet floor, NOT a mean) cannot fit in free disk;
        # every uncertainty — no row estimate, statvfs failure, knob off —
        # fails OPEN and the run proceeds as before.
        # FR-DEL-06 (2026-09-02) — delivery suppression per feed and per
        # ENVIRONMENT, without editing the feed definition.  Needed for
        # backfills (re-sending 20 days of files to a counterparty
        # because someone re-ran a month is a serious incident), for
        # non-production environments, and for an acceptance run that
        # must produce a real file and send it nowhere.
        # Shape — matches core.feed.delivery_hops.is_delivery_suppressed,
        # which is the ONLY reader; a comment describing any other shape
        # would have an operator configure a suppression that silently
        # never fires:
        #   {"all":   ["dev", "uat"],           # whole environments
        #    "feeds": {"GL_EXTRACT": ["uat"],   # one feed, some envs
        #              "risk_daily": ["*"]}}    # one feed, everywhere
        # Empty suppresses nothing — today's behaviour.
        # H1 (2026-09-02) — WHERE delivery happens on the Spark lane.
        # True (today): the job delivers itself, then reports.  A job
        # that delivered over SFTP and died before its webhook landed
        # presents as FAILED and the resubmit delivers AGAIN — the retry
        # unit (the pod) CONTAINS the non-idempotent act, so no failure
        # classification can prevent it.
        # False: the job writes artifacts + a manifest ONLY, and
        # QueryStudio delivers from the webhook.  The pod becomes
        # retry-safe by construction.
        #
        # ONE flag governs both sides deliberately.  Two flags — or two
        # deploys — create a window where the pod and QS both deliver
        # (the counterparty gets it twice) or neither does (the feed
        # reports success having sent nothing).  Both are worse than the
        # hazard.  The job reports what it ACTUALLY did, so a stale image
        # cannot desynchronise the two.
        # FR-CMP-01/07 (2026-09-02) — what the completeness verdict DOES.
        #   "record"  : compute it and store it on the run; the run's
        #               status is unchanged.  DEFAULT, so this deploys
        #               as a no-op on an estate that has never had a
        #               verdict — flipping it on blind would mark
        #               perfectly good runs unverifiable overnight,
        #               because most of them cannot yet ASSERT that no
        #               row cap was applied.
        #   "enforce" : a run reaches 'completed' ONLY when the verdict
        #               allows it.  This is what FR-CMP-01 actually
        #               requires — "a comparison that fails must change
        #               the run's status" — and §21 requires it ON
        #               before a feed is accepted into production.
        # Record first, enforce once the verdicts have been read: an
        # unread gate is how a correctness control becomes a nuisance
        # someone switches off.
        "completeness_gate":          "record",
        "pod_side_delivery":          True,
        "delivery_suppression":       {},
        "disk_preflight_enabled":      True,
        "disk_preflight_min_bytes_per_row": 32,
        # ── Write ladder (2026-08-22, design_starburst_140m §4.2) ──
        # DECLARED here per the standing rule: a key read only via
        # getattr(..., default) is how a whole branch stays dead.
        #
        # engine_write_enabled — global kill switch for rung 1 (engine-
        # side CTAS unload).  Rung 1 additionally requires the PER-
        # CONNECTION declaration (unload_scratch_catalog/schema +
        # unload_s3_location on the Trino/Starburst connection config);
        # this knob only turns the whole rung off fleet-wide.
        "engine_write_enabled":        True,
        # parts_rows_per_part — rung 3 part rotation threshold.  An
        # output SHAPE knob, not a cap: no value drops rows.  0 means
        # NEVER ROTATE (single file — the pre-2026-08-22 behaviour),
        # declared semantic.  Feeds whose result fits in one part
        # produce the identical single-file artifact either way.
        "parts_rows_per_part":         5000000,
        # union_pushdown_enabled — same-cluster UNION feeds rewritten to
        # ONE federated statement (§4.3 step 1).  Refusals are declared
        # per-run in files_metadata.union_pushdown regardless.
        "union_pushdown_enabled":      True,
        # cross_union_zero_copy — different-engine UNION combine via a
        # parts manifest instead of a third DuckDB copy (§4.3 step 3).
        # Schema-unify failures fall back to the DuckDB combine, logged.
        "cross_union_zero_copy":       True,
        # DEPRECATED 2026-11-05: read by nothing.  Its sweeper's query named a column that does not
        # exist, so it never failed a run; a stuck run is ended by the heartbeat reapers
        # (reset_stale_feed_executions, reap_orphaned_feed_runs / _executions).  A hard limit by
        # age alone would fail a healthy long feed (FR-RUN-08).  Kept so an old config file loads.
        "execution_timeout_seconds":   3600,
        # Phase 130 hotfix-13 — backend failover.  When set, overrides
        # every feed's per-feed execution_backend AND the size-based
        # auto-router.  Values:
        #   "auto"          — no override; honour per-feed + auto-router
        #   "native_only"   — force all feeds to native DuckDB
        #   "airflow_only"  — force all feeds to Airflow (requires airflow.enabled)
        #   "halt"          — block all new executions; the queue holds pending rows
        # Settable at runtime via POST /api/admin/feed-generation/backend-override.
        # Auto-set by the failover agent (see failover_agent_* keys below).
        "backend_override":            "auto",
        # When an Airflow-PINNED feed's circuit breaker is open: true = the
        # operator's DECLARED permission for such a run to move to native
        # (recorded in the run's reason, naming this key); false = the pin
        # stands and the run FAILS with the reason (airflow_breaker_open).
        # Default FALSE since 2026-10-07 (feed lane contract K3): a pin is
        # an operator's statement of intent and is never moved unless the
        # operator declared it may be.  Only the per-FEED airflow pin reads
        # it; a per-run override is never moved.
        "airflow_failover_to_native":  False,
        # Failover agent — background job that probes Airflow + native worker
        # health and flips backend_override automatically.
        "failover_agent_enabled":      False,
        "failover_agent_interval_seconds":          30,
        "failover_agent_unhealthy_streak_required": 3,   # ticks before flipping
        "failover_agent_healthy_streak_required":   3,   # ticks before reverting
        # Native worker health — how many seconds without a successful queue
        # poll tick before native is considered unhealthy.
        "native_worker_stale_after_seconds": 180,
        # Phase 130 hotfix-13 — when true, the API + scheduler pods SKIP
        # registering their in-process queue worker, expecting a dedicated
        # feed_worker.py pod to handle polling.  Default false (single-pod
        # / scheduler-pod-only deployments still work).  When you flip to
        # true, deploy at least one feed_worker pod OR feeds won't run.
        "worker_pod_only": False,
        # Phase 130 hotfix-13 sharding rescue — reset status='running'
        # rows whose claiming pod hasn't transitioned them within this
        # many seconds.  Default 1 h = 2× typical big-feed duration;
        # tune higher when expected feeds exceed an hour.  Set to 0 to
        # disable the reclamation sweeper entirely.
        "stale_running_reclaim_seconds": 3600,
        # How often to scan for stale rows (in seconds).
        "stale_running_reclaim_interval_seconds": 300,
        # HMAC secret for /api/webhooks/feed-complete (the detached Spark
        # job signs its completion callback with it).  Had an accessor but
        # no declaration since feed-seam 2026-07-16 — declared 2026-08-22
        # with the SAME empty-string fallback the accessor always used
        # (empty ⇒ the webhook receiver refuses all calls with 503).
        "webhook_secret":              "",
        "airflow": {
            "enabled":                 False,
            "base_url":                "http://airflow:8080",
            "auth_type":               "basic",
            "username":                "",
            "password":                "",
            "default_dag_id":          "querystudio_feed",
            # "output_s3_bucket" / "output_s3_prefix" REMOVED 2026-10-08
            # (feed lane contract, ONE Airflow road): they named where the
            # conf-driven DAG's job wrote its staging output, which the
            # engine then handed to the native renderer as a path it could
            # never read.  The Airflow lane now dispatches the execution to
            # the factory DAG, which submits it through /spark-submit; a
            # job's output goes to its destination or to the declared
            # artifact store (spark_k8s.artifact_bucket).  Recorded in
            # _REMOVED_KEYS.
            "poll_interval_seconds":   10,
            "poll_timeout_seconds":    3600,
            # "use_callback_webhook" REMOVED 2026-09-02 — it claimed the
            # engine would send Airflow a callback URL instead of polling,
            # but NOTHING ever read it and the engine has no knob for its
            # own externally-reachable base URL, so there is no URL to
            # send.  The /api/webhooks/feed-complete receiver works
            # WITHOUT it (the DAG is given the URL on the Airflow side).
            # Do not re-add without building the callback path end to end.
        },
        "oracle_defaults": {
            "batch_size":              5000,
            "timeout_seconds":         3600,
        },
        "sftp": {
            "connect_timeout_seconds": 30,
            # "upload_timeout_seconds" (was 300) REMOVED 2026-09-02 — it
            # was never read: today an SFTP upload has NO timeout at all
            # (only the connect socket has one, plus 30s keepalives), and
            # init_config.py-generated config.json files already persist
            # the inert 300.  Wiring the key would therefore give every
            # such deployment a 5-minute stall timeout it never asked
            # for, killing any transfer whose server legitimately blocks
            # >300s on one op (e.g. a slow close on a multi-GB file).  If
            # stall protection is wanted, add it as a NEW opt-in key
            # (default 0 = off) that no persisted config carries.
        },
        # 2026-08-04 discoverability — allow-list of roots for destination_type=local (config.py local_destination_allowed_roots, default []).
        "local_destination_allowed_roots": [],
        # ── 2026-08-23 (Phase 4) — GHOST KEYS DECLARED ──────────────────
        # Every key below was read by a typed accessor (config.py
        # feed_generation class) via get(..., default) but declared
        # nowhere, so validate_config() reported a legitimately
        # configured SOD/queue/SLA deployment as "unknown config key
        # (typo?)".  Values are IDENTICAL to the accessor defaults —
        # declaring them moves nothing (the audit-round-3 lesson).
        "sod_enabled":                 False,       # daily SOD task generator
        "sod_cron":                    "0 0 * * *", # when SOD runs (UTC)
        # 2026-10-11 -- the owner's monthly case (core/feed/sod_generator.py).
        # sod_catchup_days: a DUE date the pass finds with NO run row within
        # this many days before the run day gets its run created now
        # (triggered_by sod_catchup) -- a month-end missed because the
        # scheduler was down at the cron time used to be lost silently.
        # 0 = off.  sod_gap_scan_days: how far back a pass looks for DUE
        # dates with no run; one beyond the catch-up window is a GAP RECORD
        # (feed_sod_gaps, GET /api/admin/feeds/sod/gaps, an ERROR line),
        # never created and never silent.  Clamped to >= sod_catchup_days.
        # sod_run_now_sync_max_feeds: a run-now over more feeds than this
        # answers 202 with a pollable JOB (GET .../sod/run-now/{job_id})
        # instead of holding the request; ?background=true forces it.
        "sod_catchup_days":            7,
        "sod_gap_scan_days":           45,
        "sod_run_now_sync_max_feeds":  100,
        "sla_tracker_enabled":         False,       # SLA breach sweep
        "sla_check_interval_seconds":  60,
        "queue_worker_enabled":        False,       # pending feed_runs poller
        "queue_poll_interval_seconds": 30,
        # 2026-10-10 -- a run that finishes and frees a slot asks the worker
        # to poll AGAIN at once while the last poll saw a backlog, instead of
        # leaving the slot idle until the next tick (50 one-second feeds
        # released together took 514 s = 17 rounds x 30 s; at 4,000 month-end
        # feeds ~11 h).  The kill switch; the refill is poll_once itself.
        "queue_refill_on_completion":  True,
        # 2026-09-27 -- the ETL-dependency poller (WAIT -> RUN when a run's
        # dependencies arrive).  It read these ONLY from the DB settings
        # table (admin App Config), so a deployment could not switch it on
        # from config.json or QUERYSTUDIO_FEED_GENERATION_* env vars -- found
        # on the Docker rig proving the Iceberg-commit dependency.  Values
        # are IDENTICAL to core/feed/etl_dependency.py::load_config's
        # fallbacks; the DB setting still overrides.
        # 2026-09-27 (later) -- ON by default: a run held on a declared
        # dependency is released by this poller and nothing else, and with
        # it off every declared dependency is NOT ENFORCED (a warning per
        # run).  The scheduler chart sets the same value explicitly.
        "etl_dep_check_enabled":          True,
        "etl_dep_check_interval_seconds": 60,
        "etl_dep_sla_hours":              2,
        "etl_dep_check_leader_only":      True,
        "etl_dep_wait_escalation_hours":  48,
        # 2026-10-10 -- the poller walks EVERY governed pending run per tick
        # in pages of ``etl_dep_poll_page_size`` (keyset on id), up to
        # ``etl_dep_poll_max_rows`` (a ceiling that is logged when hit, so
        # 4,000 month-end feeds released by one message flip in one tick
        # rather than 500 per claim cycle).
        "etl_dep_poll_page_size":         500,
        "etl_dep_poll_max_rows":          20000,
        # 2026-09-27 -- the DAILY CLOSE-OUT DIGEST (core/feed/close_out_digest
        # .py): one e-mail per feed group per business day, sent once the
        # configured UTC time has passed.  On by default; a no-op (that says
        # so) without a mail relay.  The tick interval is how often the
        # daemon checks whether the digest is due, not how often it sends.
        "close_out_digest_enabled":                True,
        "close_out_digest_time_utc":               "18:00",
        "close_out_digest_check_interval_seconds": 300,
        # 2026-09-28 -- feed CONSUMER notices (core/feed/consumer_notices.py):
        # a consumer's "notify me" on delivered / late / failed, sent ONCE
        # per event through the bell, e-mail and the socket.  The late
        # watcher is a tick every consumer_late_check_interval_seconds that
        # evaluates the runs of the last consumer_late_lookback_days
        # against the feed's SLA.  consumer_receipt_window_days is the My
        # Feeds page's default window.
        "consumer_notices_enabled":                True,
        "consumer_late_check_interval_seconds":    300,
        "consumer_late_lookback_days":             3,
        "consumer_receipt_window_days":            7,
        "allow_external_triggers":     False,       # POST /api/v1/feeds/{id}/trigger
        # 2026-09-11 -- the DEPLOYMENT-wide allow-list for that route: api_key
        # ids that may trigger any feed carrying no per-feed list of its own
        # (``backend_config.external_trigger_api_key_ids``).  An EMPTY list
        # admits nobody; the legacy "no list = any valid key" hole is closed.
        "external_trigger_api_key_ids": [],
        "default_weekend_days":        [6, 7],      # Mon=1 … Sun=7
        # 2026-09-28 -- the business calendar a BARE calendar token
        # (``prev_business_day``, ``business_month_end``, ``business_day_n:3``)
        # in a report parameter, saved-query or dashboard filter resolves
        # on.  Empty = undeclared: a bare token then REFUSES naming this key
        # -- it never falls back to plain calendar days.  A token may name
        # its own calendar (``prev_business_day:LDN``); the name must be an
        # ACTIVE feed_calendars row.  See core/business_calendar_tokens.py.
        "default_calendar":            "",
        "control_file_style":          "key_value", # key_value | delimited
        "control_file_delimiter":      "|",
        # ── 2026-08-23 (Phase 4) — feed-schedule reconciler ─────────────
        # The scheduler-side sweep that makes feed_configs the single
        # source of truth for per-feed cron jobs.  Before it existed,
        # POST /api/feeds registered the APScheduler job ONLY into the
        # pod that handled the request: on a non-leader pod (or with
        # scheduler.mode=external) the create returned 200, the UI showed
        # the schedule enabled, and the feed NEVER fired.  The reconciler
        # runs on whichever pod owns the scheduler and converges jobs to
        # DB truth every interval.  0 is refused (clamped to 15).
        "schedule_reconcile_interval_seconds": 60,
        # How many days back (in addition to today) the queue worker
        # polls for still-pending feed_runs.  0 = today only (the
        # pre-2026-08-23 behaviour, which silently ABANDONED any row
        # still pending at midnight — e.g. an ETL-dependency WAIT row
        # whose deps became ready at 00:01).  A cap on how far back the
        # worker looks, never on whether a row within the window runs.
        "queue_lookback_days":         3,
        # Grace after a cron-owned feed's scheduled fire time before the
        # queue worker may claim its still-pending SOD row as a missed-
        # fire safety net.  Gives the cron path (misfire grace 300 s)
        # first claim; the atomic pending->running claim makes the race
        # safe regardless of this value.
        "queue_cron_grace_seconds":    600,
        # ── 2026-09-02 (Step 8, BRD §15) — change control / governance ──
        # git-backed, JIRA-linked definitions.  Read by
        # core/feed/governance.py + core/feed/jira_link.py +
        # api/governance_api.py — every key here IS read (a guard on an
        # undeclared key is vacuous).
        "governance": {
            # Master gate for the DEPLOY endpoint only.  Export and the
            # drift report stay available regardless — §20 Step 8 wants
            # export "in shadow first" so the YAML diff quality is
            # discovered before hundreds of definitions exist.
            "enabled":                 False,
            # shadow | enforced — recorded posture; deploys work in both
            # (trialling the deploy path IS what shadow is for).
            "mode":                    "shadow",
            # Which environment THIS deployment is (dev/uat/prod...).
            "environment":             "dev",
            # Environments where git is the SOURCE OF TRUTH (§15.2):
            # there, a DB object with no deploy record is reported as
            # "unmanaged" drift.  Everywhere else DB-first is legitimate.
            "git_truth_environments":  ["prod"],
            "jira": {
                # JIRA validates the CHANGE, never the run (§15.2).
                "enabled":             False,
                # 2026-10-31 -- THE Jira connection (core/feed/jira_client.py),
                # used by the change check AND by alerts.  base_url = the site
                # root (https://jira.example.com or https://x.atlassian.net).
                "base_url":            "",
                # bearer = Jira Server / Data Center personal access token;
                # basic  = Jira Cloud (the account's e-mail + an API token).
                "auth":                "bearer",
                # The System Account holding the login (Admin -> System
                # Accounts; Vault when the account uses Vault): bearer reads
                # its password as the token; basic its username + password.
                # Never a token in this file.
                "system_account":      "",
                "timeout_seconds":     10,
                # 2026-10-31 -- Jira as a channel of the alert road: an alert
                # kind with to_jira opens ONE issue per alert (a repeat
                # comments + re-opens it, a clear comments + transitions it).
                # Sent by core/feed/jira_sender.py on the scheduler pod, never
                # on a run's path; an outage waits and retries.
                "alerts": {
                    "enabled":               False,
                    "project":               "",        # the project KEY, e.g. OPS
                    "issue_type":            "Task",
                    # OMNIbus severity (0-5) -> Jira priority NAME; a
                    # severity not listed sends no priority (Jira's default)
                    "priority_by_severity":  {"5": "Highest", "4": "High", "3": "Medium",
                                              "2": "Low", "1": "Lowest"},
                    "labels":                ["querystudio"],
                    # transition NAMES (as on the issue's workflow buttons);
                    # "" = comment only
                    "resolve_transition":    "Done",
                    "reopen_transition":     "Reopen",
                    "poll_interval_seconds": 15,
                    "batch_size":            50,
                    "max_attempts":          6,
                    "retry_backoff_seconds": 60,
                },
                "allowed_statuses":    ["Approved", "Ready for Deployment",
                                        "In Progress"],
                # allow | block — what a tracker OUTAGE means for a
                # CHANGE.  Default allow: a change-control system that
                # can halt deploys when a third-party tracker is down
                # has become an availability risk.  Outages are always
                # recorded on the deploy record.
                "outage_policy":       "allow",
            },
            # ── 2026-10-17 -- configuration RELEASES (core/release/engine.py,
            # docs/RELEASE_CONFIG_DESIGN_2026_10_17.html).  Every key read
            # by engine.release_cfg().
            "release": {
                # Environments where the approver must differ from the
                # uploader (four-eyes).  A rollback waives it, recorded.
                "four_eyes_environments":    ["prod"],
                # Environments where approving needs a JIRA ticket (validated
                # when governance.jira.enabled; an outage follows its policy).
                "require_ticket_environments": ["prod"],
                # hold | rollback -- what a FAILED post-apply verification does.
                # hold (default): the release stays applied_unverified, loud;
                # rollback: the snapshot is re-applied by the system.
                "verify":                    {"on_failure": "hold"},
                # The first release of an object that already exists in the
                # target has no base: false = every difference is a conflict
                # the reviewer decides; true = the package wins.
                "first_release_overwrites":  False,
                # Upload cap for one package file.
                "max_package_mb":            64,
            },
        },
        # ── 2026-09-02 (Step 6, BRD §7.1) — the FEED DEPENDENCY Kafka
        # consumer (core/feed/kafka_arrivals.py).  Distinct from
        # published_views.kafka_* (Phase 98-I cache invalidation) on
        # purpose: that consumer deletes cache files; this one LANDS
        # dependency-arrival messages into the kafka_messages table.
        # Every key here IS read by kafka_arrivals.load_config() — a
        # guard on an undeclared key is vacuous.
        "dependency_kafka": {
            # Master switch.  False is a legitimate deployment state, but
            # it is stated AT INFO with the reason (FR-DEP-04): "no
            # messages arriving" and "no consumer running" are opposite
            # investigations, and the predecessor consumer was dark by
            # construction (debug-level refusal + optional dependency).
            "enabled":              False,
            "bootstrap_servers":    "",
            # Topics to subscribe.  Empty + enabled=true is a stated
            # refusal, never a silent no-op.
            "topics":               [],
            "consumer_group":       "querystudio_feed_dependency_arrivals",
            # earliest: a consumer group seeing a topic for the FIRST
            # time starts from the oldest retained message, so a consumer
            # deployed after the upstream started publishing still lands
            # the backlog (the table's unique key absorbs re-reads).
            "auto_offset_reset":    "earliest",
            "poll_timeout_seconds": 1.0,
            # Sleep between passes when a pass drained nothing.
            "idle_sleep_seconds":   5.0,
            "resolver_batch_size":  200,
            # FR-DEP-02 — message -> dependency mapping is CONFIGURATION,
            # not code: a new upstream system is a rule here, never a
            # deployment.  Shape (matches kafka_arrivals.rules_from_config,
            # the ONLY reader — a comment describing any other shape would
            # have an operator configure a rule that silently never fires):
            #   {"topic": "entity_load",                   # required
            #    "dependency_name": "ENTITY_LOAD",         # required
            #    "business_date_field": "business_date",   # required
            #    "business_date_format": "%Y-%m-%d",       # optional
            #    "identity_fields": ["topic", "partition", "offset"],
            #    "match": {"status": "COMPLETE"}}          # optional filter
            # Two rules may name the SAME dependency (2026-10-08): a
            # dependency that declares {"kind": "kafka", "topic": T} for
            # each of two topics waits for BOTH messages (require_mode
            # all) or either (any); each arrival is recorded with
            # source_key "kafka:<topic>" so the two are told apart.
            # ONE rule may serve THOUSANDS of dependencies (2026-10-10):
            # "dependency_name" may carry {field} placeholders rendered
            # from the message's payload --
            #   {"topic": "tetb.partition.ready",
            #    "dependency_name": "TETB_{SYSTEM_ENTITY}_{EventCode}",
            #    "business_date_field": "business_date"}
            # routes {"business_date": "2026-09-30", "SYSTEM_ENTITY":
            # "GB01", "EventCode": "EOM"} to dependency TETB_GB01_EOM.  A
            # rendered name no active feed declares is recorded as
            # 'unmatched' (GET /api/admin/feeds/kafka-arrivals/unmatched),
            # never dropped; a missing field is unresolvable (poison).
            #
            # BY ENVIRONMENT this whole block is ONE JSON object:
            #   QUERYSTUDIO_FEED_GENERATION_DEPENDENCY_KAFKA='{"enabled":
            #   true, "bootstrap_servers": "...", "topics": [...],
            #   "resolver_rules": [...]}'
            # (env_var_target is two levels deep by design, so
            # ..._DEPENDENCY_KAFKA_ENABLED reaches nothing; omitted keys
            # keep kafka_arrivals.load_config's defaults).  Set it on EVERY
            # pod that evaluates the gate (api + scheduler), not only where
            # the consumer runs: producer_health reads consumer_refusal
            # from the calling pod's own config.  The Docker rig's
            # scripts/docker_proof/compose/kafka.override.yml is the
            # worked example.
            "resolver_rules":       [],
        },
        # ── 2026-09-27 — the ICEBERG-COMMIT arrival source
        # (core/feed/iceberg_commit_source.py).  When a watched, registered
        # Iceberg table's snapshot rolls, the source PROVES from the
        # snapshot's own manifests which dates it holds in the dependency's
        # declared date column and records an arrival per proved date in
        # dependency_events (source 'iceberg_commit') -- the same ledger the
        # Kafka resolver writes; the one gate reads it back.
        "dependency_iceberg_commit": {
            "enabled":             True,
            # Only dates within this many days before today (and one after)
            # are recorded as arrivals per snapshot -- a table holding three
            # years of daily partitions must not write a thousand arrivals
            # per commit.  A backfill run further back than this reports
            # NOT MET with that reason; widen it or assert.
            "lookback_days":       14,
            # An inspection walks the snapshot's live data files; above this
            # count it REFUSES (recorded as unreadable -> COULD NOT TELL)
            # rather than run unbounded on a listener thread.
            "max_files_inspected": 200000,
        },
        # ── 2026-10-07 — the FILE arrival source
        # (core/feed/file_arrival_source.py).  The ``file`` kind was in the
        # vocabulary with NO producer: a feed waiting on a file dependency
        # waited 48 h and failed.  The watcher (daemon
        # feed_dependency_file_watch, scheduler-owned) lists each declared
        # location for every WAIT run in the window and records an arrival
        # in dependency_events (source 'file') once the files -- and the
        # control file, when declared -- are there.  Every key is read by
        # file_arrival_source.load_config().
        "dependency_file": {
            "enabled":          True,
            # The tick: one bounded LIST per declared source per waiting run.
            "interval_seconds": 60,
            # Only WAIT runs whose business date is within this many days
            # before today (and one after) are watched; an older run reports
            # NOT MET with that reason -- widen it or skip the dependency.
            "lookback_days":    7,
            # Keys one LIST may return.  A listing that stops here before the
            # requirement is met is COULD NOT TELL, never "absent".
            "max_keys":         1000,
        },
        # -- 2026-10-25 -- when a not-yet-arrived dependency reads DELAYED
        # (core/feed/acting_time.py::delay_view; the owner: "can be waiting,
        # arrived or delayed (based on average time arrival) ... if no sla
        # defined").  With an SLA on the feed: delayed after the decision
        # deadline (the SLA minus the feed's runtime).  With NO SLA: delayed
        # after the dependency's usual arrival time from its own history --
        # usual_percentile of its first arrival per business date (p50 = the
        # typical arrival; p90 / p95 / max are stricter), once it has
        # min_observations dates of history -- plus grace_minutes.  The
        # watcher's overdue ALERT (p95, high confidence) is a separate rule.
        "dependency_delay": {
            "usual_percentile":   "p50",
            "min_observations":   5,
            "grace_minutes":      0,
        },
        # -- 2026-10-25 -- the MESSAGE TRACKER (core/feed/message_tracker.py;
        # the owner: "group by code first ... then datasource ... 1 message
        # will have all steps processing -> complete or processing -> failed
        # ... how many times the same message came ... per business close
        # date").  Every landed upstream message (both roads) is read ONCE at
        # landing into indexed columns by these field names (matched
        # case-insensitively); a message = the identity_fields' values, its
        # flow = the state_field's values in arrival order.
        "message_tracker": {
            "business_date_field":   "BUSINESS_DATE",
            # the RUN DATE of a message = the day this field says the upstream
            # created it (else the day it landed) -- the tracker's "Run date" view
            "created_field":         "CREATED_AT",
            # tried in order; an ISO timestamp also reads as its date
            "business_date_formats": ["%Y-%m-%d", "%d-%b-%y", "%d-%b-%Y", "%Y%m%d", "%d/%m/%Y"],
            "state_field":           "VERSION_STATE",
            "complete_states":       ["COMPLETE", "COMPLETED", "SUCCESS"],
            "failed_states":         ["FAILED", "FAILURE", "ERROR"],
            # the two levels of the tree, in order
            "group_fields":          ["CODE", "DATA_SOURCE"],
            # what makes two arrivals THE SAME message
            "identity_fields":       ["DATA_SOURCE", "CODE", "BUSINESS_EVENT", "CLOUD_COMPLIANT", "SNAP_VERSION"],
            # identity fields that say WHICH VERSION of one load a message is
            # (a re-sent load = a new version of the same message)
            "version_fields":        ["SNAP_VERSION"],
            # shown beside a message, not part of its identity
            "detail_fields":         ["ROW_COUNT", "VERSION_NUMBER", "DATA_STORE"],
            # a message still not COMPLETE/FAILED this long after its last
            # arrival is STUCK (0 = never)
            "stuck_after_minutes":   120,
            # codes (groups) per page
            "page_size":             25,
        },
        # -- 2026-10-11 -- the ORACLE-TABLE arrival source
        # (core/feed/oracle_table_source.py).  The owner's OG system lands
        # every "partition ready" Kafka message in an Oracle table
        # (QS_KAFKA_MESSAGE); the watcher (daemon
        # feed_dependency_oracle_table_watch, scheduler-owned) reads each
        # configured table's NEW rows above a watermark, resolves every row
        # through the SAME resolver-rule vocabulary as dependency_kafka
        # (templated dependency_name with field_values maps,
        # business_date_field, match, row_count_field) and records an
        # arrival in dependency_events (source 'oracle_table').  Each row is
        # landed in kafka_messages under the pseudo-topic
        # oracle_table:<connection_id>/<TABLE> (partition 0, offset = the
        # row's id) with its resolution, so the dedupe, the unmatched state
        # and the admin route are the Kafka path's.  Every key is read by
        # oracle_table_source.load_config().  BY ENVIRONMENT this whole
        # block is ONE JSON object, set on EVERY pod that evaluates the
        # gate (api + scheduler):
        #   QUERYSTUDIO_FEED_GENERATION_DEPENDENCY_ORACLE_TABLE='{"enabled":
        #   true, "tables": [{"connection": "oracle-otg", "table":
        #   "QS_KAFKA_MESSAGE", "id_column": "ID", "resolver_rules": [
        #   {"dependency_name": "{DATA_SOURCE}_{CODE}_{BUSINESS_EVENT}_
        #   {CLOUD_COMPLIANT}", "business_date_field": "BUSINESS_DATE",
        #   "match": {"VERSION_STATE": "COMPLETE"}, "row_count_field":
        #   "ROW_COUNT", "field_values": {"CLOUD_COMPLIANT": {"true":
        #   "CLOUD", "false": "ONPREM"}}}]}]}'
        "dependency_oracle_table": {
            "enabled":               True,
            # The tick: one bounded SELECT per watched table.
            "interval_seconds":      15,
            # Rows one SELECT may return (ORDER BY id FETCH FIRST n ROWS).
            "batch_rows":            500,
            # Each tick re-reads from (watermark - rescan_rows): a row that
            # committed late with a lower id is still caught; the landing
            # dedupe keeps the re-read free.  Further back is missed (stated).
            "rescan_rows":           200,
            # On FIRST sight of a table the watermark starts at MAX(id) minus
            # this: 0 = only rows inserted after the watcher first ran.
            "initial_lookback_rows": 0,
            # [{"connection": <id or name>, "table": "[SCHEMA.]TABLE",
            #   "id_column": "ID", "resolver_rules": [<dependency_kafka
            #   rule shape, minus topic>]}] -- shape: oracle_table_source.
            #   load_config, the ONLY reader.
            # 2026-10-28 -- connection "querystudio" = QueryStudio's OWN database:
            # the owner's Kafka service INSERTs into qs_kafka_message (the OG
            # QS_KAFKA_MESSAGE columns); watched by default with the OG rule.
            "tables":                [{
                "connection": "querystudio", "table": "QS_KAFKA_MESSAGE", "id_column": "ID",
                "resolver_rules": [{
                    "dependency_name": "{DATA_SOURCE}_{CODE}_{BUSINESS_EVENT}_{CLOUD_COMPLIANT}",
                    "business_date_field": "BUSINESS_DATE",
                    "match": {"VERSION_STATE": "COMPLETE"},
                    "row_count_field": "ROW_COUNT",
                    "field_values": {"CLOUD_COMPLIANT": {"true": "CLOUD", "false": "ONPREM"}}}],
            }],
        },
        # ── 2026-09-02 (BRD §8, §12) — the SLA WATCHER
        # (core/feed/sla_watcher.py): evaluates acting time for every run
        # still waiting on a dependency, groups BY DEPENDENCY so one
        # overdue upstream blocking 34 feeds is ONE alert, and CLEARS what
        # it raised.  Declared because the cadence was HARDCODED at 60s:
        # every sibling daemon here has a configurable poll interval, and
        # an operator on a large fleet had no way to slow this one down
        # short of a code change.  Both keys ARE read by
        # sla_watcher.load_config() — a guard on an undeclared key is
        # vacuous.
        # ── 2026-09-03 — FEED STEP DISCOVERY (core/feed/steps).
        # A source kind or delivery target is a "step" filling a "role";
        # builtins ship in the wheel, and this knob points at an OPTIONAL
        # directory of operator-supplied ones.
        #
        # DEFAULT EMPTY = DISCOVERY OFF.  Declared here because an
        # undeclared key is a vacuous knob in this codebase: scripts/
        # init_config.py generates config.json FROM _DEFAULTS, so an
        # undeclared key is absent on every fresh deployment, and the
        # startup validator reports an operator who DID set it as a typo.
        #
        # The danger is not a MISSING directory (that fails loudly) but a
        # FOREIGN-BUT-PRESENT one — another environment's steps, running a
        # vocabulary that is wrong here and reporting success.  Hence the
        # root must carry a marker file naming the platform and the
        # environment, and a contradicting environment refuses the WHOLE
        # root while boot continues on builtins.  Discovered steps are
        # in-process Python and are RCE-equivalent by design: the ACL on
        # this directory IS the security boundary.
        "steps_dir":                   "",
        # Which environment a discovery root must declare to be loadable
        # (core/feed/steps/__init__.py ``platform_environment``).  Ghost
        # key until 2026-09-07: it was read and declared nowhere, so
        # ``our_env`` was "" on every deployment and the FOREIGN-ROOT
        # guard -- the one that refuses another environment's step
        # vocabulary -- could never fire.  Default "" is the value it
        # already had; leaving it blank now falls back to
        # ``app.environment`` rather than disarming the guard.
        "environment":                 "",
        "sla_watcher": {
            # false stops the pass and SAYS SO at INFO.  Never a silent
            # no-op: "no alerts firing" and "nothing is evaluating them"
            # are opposite findings that look identical from outside.
            "enabled":          True,
            # Seconds between passes.  Floored at
            # sla_watcher.MIN_INTERVAL_SECONDS by safe_interval -- 0 would
            # busy-loop the pod, which is never what anyone typing 0 into
            # a config meant.
            "interval_seconds": 60,
            # 2026-09-28 -- how many business dates BEFORE today a pass
            # also evaluates.  The watcher used to build its blocking
            # index for TODAY only, so a run for yesterday still held in
            # WAIT after midnight, past its SLA, raised no alert -- only
            # the 48 h escalation eventually failed it.  Every date in
            # [today - lookback_days, today] that still has a WAIT run is
            # evaluated; the Netcool Identifier already carries the date
            # (BRD §12.2), so two dates never collide and each clears
            # on its own.  3 days covers the escalation horizon
            # (etl_dep_wait_escalation_hours, 48 h) with a weekend to
            # spare: no run can still be in WAIT and outside the window
            # unless escalation was widened -- widen this with it.  0 =
            # today only (the pre-2026-09-28 behaviour).
            "lookback_days":    3,
        },
        # ── 2026-09-02 (BRD §12.4, FR-ALT-03..07) — the NETCOOL SENDER
        # (core/feed/netcool_sender.py): drains {"kind": "netcool_event"}
        # rows from pending_notifications and posts them to the event
        # console.  Every key here IS read by netcool_sender.load_config()
        # — a guard on an undeclared key is vacuous.
        "netcool": {
            # none | rest.  ("eif" and "snmp" are recognised names that
            # REFUSE until an implementation ships — the site standard,
            # endpoint and credentials are §18 inputs owed by the Netcool
            # team.)  "none" is a stated refusal at INFO, never a silent
            # no-op: events still enqueue durably and the queue remains
            # the audit (FR-ALT-05).
            "transport":                  "none",
            # 2026-10-25 -- what an event NO netcool_rules row matches does:
            # "send" (every event, as before) or "suppress" (only what a rule
            # sends).  Rules: core/feed/netcool_rules.py, admin Settings.
            "default_action":             "send",
            # REST gateway URL in front of ObjectServer (§18 input).
            "endpoint":                   "",
            "poll_interval_seconds":      5.0,
            "batch_size":                 50,
            # FR-ALT-06 — bounded retry: TOTAL delivery attempts per event
            # before it moves to the dead letter and raises the local
            # alarm.  Clamped to >= 1 by the reader (0 attempts would be
            # a sender that dead-letters everything it touches).
            "max_attempts":               5,
            "retry_backoff_seconds":      30.0,
            # FR-ALT-07 — heartbeat cadence.  <= 0 disables, stated at
            # INFO.  The heartbeat event carries ExpireTime=900 s, so
            # keep this well under 900 or the console's absence rule
            # fires between healthy beats.
            "heartbeat_interval_seconds": 300.0,
            # Per-request transport timeout.
            "timeout_seconds":            10.0,
        },
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "date_formats":    {},
    },
    # Spark Connect — zero-download distributed query engine for large S3 datasets.
    # When enabled, queries above row_threshold are routed to a Spark Connect server
    # instead of pre-downloading S3 files to the FastAPI pod.
    # Spark reads s3a:// paths in-place; only result Arrow batches come back.
    # Feature gate: set enabled=true only after deploying the Spark Connect server
    # (see k8s/spark-connect/ for K8s manifests).
    "spark_connect": {
        "enabled":                          False,
        # Spark Connect URL.  Format:
        #   sc://host:port                              — in-cluster, no TLS
        #   sc://host:port/;use_ssl=true                — in-cluster TLS / mTLS
        #   sc://route.apps.cluster:443/;use_ssl=true   — OpenShift Route + TLS passthrough
        # Append ;token=... for bearer auth (or leave blank and set
        # ``system_account`` below to pull the token from the encrypted
        # System Account store — same pattern proxy / aws_portal use).
        "server_url":                       "sc://spark-connect-server:15002",
        # BF-267: optional bearer token for ;token= param.  Either set
        # `token` directly (plain text — dev only) OR set `system_account`
        # to the name of a System Account whose `token` field carries the
        # secret.  When both are blank we don't append ;token= so Spark
        # Connect uses its default (none / mTLS / k8s SA token).
        "token":                            "",
        "system_account":                   "",
        "row_threshold":                    10000000,   # rows ≥ this → Spark Connect
        "timeout_seconds":                  600,        # per-query deadline
        # 2026-08-22 -- THIS KEY WAS NEVER DECLARED.  _iter_result_batches has
        # read `stream_via_local_iterator` since it was written, but the
        # attribute existed on no config object, so `getattr(..., False)` was
        # always False and the streaming branch was unreachable code.  Every
        # Spark Connect result therefore went through `df.toArrow()`, which
        # materialises the WHOLE table in the pod before the first batch is
        # written -- while the comment on max_result_rows below justified
        # 0=unlimited on the grounds that this route "ALREADY STREAMS ... so
        # memory is O(one batch)".  It did not.  A 70M-row feed OOM-killed the
        # pod and every other user's session with it.
        #
        # Defaults ON: toLocalIterator pulls one partition at a time, so
        # memory is bounded by the largest partition rather than by the whole
        # result -- which is the property the uncapped default depends on.
        "stream_via_local_iterator":        True,
        # 2026-08-13 -- WAS 5000000 with "truncate result if exceeded", on a
        # route that ALREADY STREAMS Arrow batches to parquet
        # (spark_connect_executor: _iter_result_batches -> pq_writer.
        # write_batch), so memory is O(one batch) and the cap was never what
        # kept the pod alive.  Its only effect was to refuse work: the router
        # sends rows >= row_threshold (10M) TO Spark Connect, and feed_engine
        # then REFUSES to deliver a truncated feed ("Truncation is NOT
        # completion") -- so a 70M-row feed was routed to Spark and then
        # failed outright.  0 = UNLIMITED, same posture as
        # federation.max_result_rows and feed_generation.max_output_rows.
        "max_result_rows":                  0,
        "session_idle_timeout_minutes":     30,         # evict unused sessions
        "max_sessions_per_user":            2,          # quota: concurrent sessions/user
        "max_concurrent_queries":           20,         # global connection-level quota
        "circuit_breaker_failure_threshold": 3,         # open after N failures
        "circuit_breaker_cooldown_seconds":  120,       # retry after cooldown
        "executor_memory":                  "8g",
        "executor_cores":                   4,
        "min_executors":                    1,
        "max_executors":                    8,
        # Phase 151 follow-up — config-driven routing rules.  Operator
        # policies that override the global row_threshold gate per
        # table / pattern / SQL contents.  Rules are tried in order;
        # first match wins.  Each rule shape:
        #   {name?, match_table_name?, match_table_pattern?,
        #    match_sql_contains?, match_sql_regex?, min_files?,
        #    max_files?, min_rows?, max_rows?,
        #    engine: "spark"|"duckdb"|"auto", reason?}
        # See backend/core/spark_routing_rules.py for full semantics.
        # (config.example.json, which used to carry worked examples,
        # was deleted 2026-08-20 -- config.json is the only config.)
        "routing_rules":                    [],
    },
    # ── spark_k8s — QueryStudio-owned Spark-on-Kubernetes backend ─────
    # 2026-08-22, operator directive: "query studio should be able to spin
    # the pods just like how airflow does".  QueryStudio submits
    # SparkApplication CRs (spark-operator) running generic_feed.py itself
    # and supervises them with its own reconciler (core/spark_k8s/).
    # EVERY key is declared here — an undeclared key read via
    # getattr(..., default) is how the Spark streaming branch stayed dead
    # for months.  Feature-gated OFF: enabling requires the spark-operator
    # CRD + the RBAC in k8s/querystudioapi-helm/*/templates/
    # rbac-spark-k8s.yaml; the availability ladder
    # (core/spark_k8s/availability.py) refuses with a named reason when
    # any prerequisite is missing.
    "spark_k8s": {
        "enabled":                      False,
        # ── submit_mode (2026-09-03) ─────────────────────────────────
        # HOW QueryStudio creates the Spark workload:
        #
        #   "spark_application" — POST a SparkApplication CR and let
        #        spark-operator turn it into a driver pod.  Requires the
        #        sparkoperator.k8s.io/v1beta2 CRD.
        #   "driver_pod"        — POST the DRIVER POD directly.  Spark's
        #        own Kubernetes cluster manager (running IN that pod)
        #        then creates the executors.  Requires NO operator: this
        #        is exactly what `spark-submit --deploy-mode cluster`
        #        does, minus the CLI.
        #
        # A cluster that already runs Spark does not need spark-operator
        # — it is a convenience wrapper around the same driver pod.  The
        # refusal message for a missing CRD used to say "install
        # spark-operator", which sends an operator to install a
        # component they do not need.
        #
        #   "auto" (default since 2026-09-14) — probe at SUBMIT: the
        #        SparkApplication CRD served -> "spark_application";
        #        404 -> "driver_pod"; a 403 or an unreachable cluster is
        #        UNKNOWN and the submit is REFUSED with that reason, never
        #        guessed.  The resolved shape is stored on the execution
        #        row (feed_executions.submit_mode) and every later verb
        #        reads it from there, so a run keeps its shape even if
        #        the operator is installed or removed mid-flight.
        #
        # The trade-off an operator chooses between:
        #   * with spark-operator: the CR is a managed object -- the
        #     operator's own status/attempts, its webhook-driven pod
        #     features (volumes, tolerations, affinity via the CR),
        #     `kubectl get sparkapplications`, and its restart policy.
        #   * without: a plain driver Pod QueryStudio posts itself --
        #     NO operator-managed retries or CR-level features; the pod
        #     runs `spark-submit` in client mode inside itself and Spark
        #     creates the executors.  QueryStudio's OWN reconciler
        #     supervises both shapes identically (timeouts, its bounded
        #     retries, reaping), so supervision is not what changes.
        # The deployment needs nothing manual either way: the helm chart
        # ships the driver ServiceAccount + RBAC the pod shape needs.
        "submit_mode":                  "auto",
        # The Kubernetes master as Spark addresses it.  In-cluster this
        # is the API service; it is a DECLARED key rather than a literal
        # because an operator on a non-default service domain has no
        # other way to correct it.
        "master_url":                   "k8s://https://kubernetes.default.svc:443",
        # Registry pull secrets for the driver pod (and, via Spark's own
        # conf, the executors).  Empty = none.  A private registry
        # without this yields ImagePullBackOff, which the classifier
        # correctly calls NON_RETRYABLE — terminal, for a cause that was
        # configurable.
        "image_pull_secrets":           [],
        # 2026-10-17: the JDBC driver CLASSES the deployed job image carries
        # (the submit preflight, core/spark_k8s/jdbc.py::assert_driver_on_classpath,
        # refuses a feed whose driver the image lacks BEFORE a pod is born).
        # Empty = the pinned image's five (PINNED_IMAGE_DRIVER_CLASSES);
        # ["*"] = an image whose jar list is unknown (preflight skipped,
        # said in the log).  A CUSTOM image (the Airflow-based one) declares
        # its own list here -- there was no key, so it could not.
        "image_driver_classes":         [],
        # OpenShift SCC: "" means DO NOT SET runAsUser and let the SCC
        # assign a UID from the project range.  Pinning a UID outside
        # that range is rejected at admission, and this repo's own charts
        # disagree with each other (185 vs 45646345) — so the safe
        # default is to say nothing.
        "driver_run_as_user":           "",
        # K8s namespace the SparkApplication CRs + per-execution
        # credential Secrets live in (the Spark driver/executor pods too).
        "namespace":                    "spark",
        # The generic_feed.py job image (spark/Dockerfile).
        "image":                        "querystudio/spark-etl:latest",
        "image_pull_policy":            "Always",
        # ServiceAccount for the DRIVER pod (needs the spark-operator
        # driver RBAC to create executor pods).
        "service_account":              "spark",
        # Base URL the DRIVER pod uses to reach the QS API for its signed
        # completion webhook (in-cluster service DNS).
        "callback_base_url":            "http://querystudio-api:8000",
        # 2026-10-14 -- how often the job reports where it is (Spark's task
        # counters + its new log lines) to /api/webhooks/feed-progress.
        # 0 = never (the job then reports only at the end, as before).
        "progress_interval_seconds":    30,
        # 2026-10-14 -- the ABSOLUTE ceiling of a run that is still moving
        # past its job_timeout_seconds budget (0 = the budget is final)
        "job_ceiling_seconds":          43200,
        # E-cred: credentials travel via a per-attempt K8s Secret
        # (secretKeyRef), never on the driver command line.  There is NO
        # inline fallback when Secret creation fails — that would be a
        # silent credential-posture downgrade; the submit fails loudly.
        "creds_via_secret":             True,
        # Default pod sizing; per-feed backend_config.spark_* overrides.
        "driver_cores":                 1,
        "driver_memory":                "4g",
        "executor_cores":               4,
        "executor_memory":              "8g",
        "num_executors":                4,
        # Extra sparkConf merged into every job (per-feed
        # backend_config.spark_extra_conf wins on key conflicts).
        "spark_conf":                   {},
        # ── Lifecycle (the reconciler's knobs) ────────────────────────
        # Bounded retries per execution, resubmitted by the reconciler
        # ONLY for failures classified retryable (image-pull, bad JDBC
        # URL, OOM and auth failures are declared non-retryable — see
        # reconciler.NON_RETRYABLE_MARKERS).  0 = ZERO retries, never
        # unlimited.  Default 1 = parity with the Airflow DAG's
        # retries=1.
        "max_retries":                  1,
        # Delay before a retry attempt is resubmitted (Airflow parity:
        # retry_delay=5min).
        "retry_backoff_seconds":        300,
        # Correctness gate against the forever-hung execution: a CR still
        # non-terminal after this many seconds is deleted and the row
        # FAILED with a timeout message.  0 disables the gate (declared
        # governance-off, NOT recommended).
        "job_timeout_seconds":          7200,
        # H2 (2026-09-02) — a GLOBAL timeout cannot serve both a 40k-row
        # feed and a 160M-row month-end.  With JDBC partition bounds unset
        # Spark performs a SINGLE-PARTITION read: 160M rows down one
        # connection at fetchsize=10000 is roughly 1-1.5h of pure pull,
        # which sits JUST INSIDE 7200s -- so a month-end that runs long is
        # killed and retried once into the same wall.
        #
        # A feed selects a size class; the class sets the timeout.  Per-feed
        # backend_config.spark_job_timeout_seconds overrides both.  An
        # unknown class name falls back to job_timeout_seconds and says so
        # (never silently, or a typo becomes a 2h cap on a 6h feed).
        "size_classes": {
            "small":  {"job_timeout_seconds":  1800},
            "medium": {"job_timeout_seconds":  7200},
            "large":  {"job_timeout_seconds": 21600},
            "xl":     {"job_timeout_seconds": 43200},
        },
        # H2 (2026-09-02) — size classes whose JDBC feeds are REFUSED at
        # submit without full partition bounds (backend_config.
        # spark_partition_column/lower_bound/upper_bound/num_partitions).
        # With bounds unset Spark performs a SINGLE-PARTITION read: the
        # 160M month-end down one connection, killed by the timeout and
        # retried into the same wall.  A partial set is refused for EVERY
        # class (the job silently degrades it to single-partition).
        "require_partition_bounds_for_size_classes": ["large", "xl"],
        # FR-SRC-03 (2026-09-02) — per-environment Iceberg catalog
        # FALLBACK for heavy-lane feeds.  BRD §18 owes connection records
        # that carry catalog_uri + warehouse; until they do, an
        # environment declares its catalog ONCE here.  Values on the
        # connection record / feed always win.  catalog_type: rest | glue
        # | hive (the grammar proven in ETL/steps/s3/s3_base_step.py).
        # A missing catalog_uri (rest/hive) or warehouse is refused
        # LOUDLY at plan time, never inside the detached Spark pod.
        "iceberg": {
            "catalog_type":  "",
            "catalog_name":  "iceberg_catalog",
            "catalog_uri":   "",
            "warehouse":     "",
        },
        # D9 (2026-09-02) — a pod that NEVER STARTS is its own failure, not
        # a slow one.  Quota exhausted or an image pull failing leaves the
        # CR in SUBMITTED with no driver; the only gate was
        # job_timeout_seconds, so a 02:00 quota problem surfaced at 06:00.
        # 0 disables the gate.
        "pending_timeout_seconds":      900,
        # D10 (2026-09-02) — how long a TEMPORARY credential (one
        # carrying a session token) is expected to stay valid.  3600s
        # is the AWS STS AssumeRole default.  A run whose BUDGET
        # exceeds this is refused AT SUBMIT: a 90-minute read that
        # outlives its token returns 403s, which classify as retryable,
        # so the resubmit hits the same TTL and the feed burns its
        # retries against a clock.  0 disables the check.
        "session_token_expected_ttl_seconds": 3600,
        # A COMPLETED CR whose row is still 'running' after this grace
        # window is finalized by the reconciler with completeness
        # UNVERIFIED (the webhook is the rich path; this is the floor).
        "webhook_grace_seconds":        120,
        # A running row with NO CR on the cluster gets this grace (the
        # submitter may be mid-create on another pod) before the
        # reconciler treats the CR as lost.
        "adoption_grace_seconds":       120,
        # Reconcile poll interval.  Floor of 5s is enforced in the loop —
        # 0 must never busy-spin.
        "reconcile_interval_seconds":   15,
        # Terminal CRs / driver pods are deleted this many seconds after
        # termination -- the window in which the DRIVER LOG can be read.
        # The run's credential Secret does NOT wait for it (2026-10-07):
        # it is deleted the moment the execution row is terminal (the
        # reconciler's terminal sweep; the webhook sooner).  A Secret that
        # outlives its job is a credential left lying around.
        "completed_cr_ttl_seconds":     3600,
        # The dispatching coroutine's row-poll cadence + overall budget
        # (the reconciler keeps supervising past this budget; the budget
        # only bounds the awaiting coroutine).
        "status_poll_interval_seconds": 10,
        "poll_timeout_seconds":         7200,
        # Availability probe TTL (0 = probe on every routing decision;
        # never means cache-forever).
        "availability_cache_seconds":   60,
        # ── Classifier vocabulary extensions (2026-08-22 closeout) ────
        # The retry classifier's marker/state tables are DATA
        # (core/spark_k8s/classifier.py) built from spark-operator
        # conventions, not observed CRs.  When a real cluster shows a
        # spelling the tables did not predict, declare it HERE — no code
        # change.  Each marker entry is {"marker": <lowercase substring
        # of "STATE errorMessage">, "verdict": "non_retryable"|
        # "retryable", "reason": <why — REQUIRED>}; operator entries are
        # checked before the built-ins, so redeclaring a built-in marker
        # overrides its verdict.  Invalid entries are ERROR-logged and
        # ignored (the valid rest still applies).
        "classifier_markers":           [],
        # CR applicationState names per lifecycle bucket:
        # {"success": [...], "failure": [...], "in_flight": [...]}.
        # Additive over the built-ins; redeclaring a known state moves it
        # (observed cluster outranks the convention).  A state the merged
        # table still does not know is DECLARED "unknown, treated
        # conservatively": supervised like in-flight (job_timeout still
        # bounds it), never reaped, WARNING-logged once with this key's
        # name.
        "cr_states":                    {},
        # One-shot-per-process (then daily) cleanup of PRE-UPGRADE
        # SparkApplications/Secrets created unlabeled by the old Airflow
        # factory (feed-* / feed-creds-*) and therefore invisible to the
        # label-selected reaper.  Never touches a CR whose execution row
        # is live; see core/spark_k8s/preupgrade.py.
        "preupgrade_sweep_enabled":     True,
        # ── artifact store (2026-10-07) ─────────────────────────────
        # Where a job that does NOT deliver (a backfill launched without
        # delivery, a declared delivery chain, pod_side_delivery=false)
        # writes its parts + manifest.json: QueryStudio's OWN S3 bucket,
        # written by the job over s3a (the image ships hadoop-aws) and
        # read back by the backend (webhook-side delivery, the kept
        # download copy).  EMPTY = no store: such a run is REFUSED
        # spark_k8s at routing (K6, 2026-10-07; reason no_artifact_store)
        # -- the Spark pods mount no shared volume, and a pod-local file
        # is gone with the pod.
        "artifact_bucket":              "",
        "artifact_prefix":              "querystudio/spark-artifacts",
        # The S3 CONNECTION whose endpoint / region / credentials both sides
        # use for that bucket (K6, 2026-10-07): the job applies them to the
        # artifact bucket only (fs.s3a.bucket.<bucket>.*, carried in the
        # per-run Secret), the backend reads the parts back with them.
        # 0 = none: both sides use their ambient identity (an IRSA role,
        # an instance profile, s3a keys in spark_k8s.spark_conf).  A run
        # that needs the store (suppressed / delivered from the webhook)
        # is REFUSED spark_k8s when the bucket is empty or this names no
        # s3 connection -- auto-routed runs go native, pinned runs fail.
        "artifact_connection_id":       0,
    },
    # Phase 127 — ETL Pipeline Integration (Airflow + Spark)
    "etl_pipelines": {
        "enabled":                          False,
        "max_concurrent_pipelines":         5,
        # BF-582 (2026-05-29): cluster-wide concurrent cap.  Counts
        # running+pending executions across all pods via DB lookup.
        # 0 = disabled (legacy: per-pod semaphore only).  Default 25
        # gives headroom = 5 pods × 5 per-pod for typical deployments.
        "max_concurrent_pipelines_cluster": 25,
        "default_dag_id":                   "querystudio_etl",
        "execution_history_retention_days": 90,
        "cleanup_interval_hours":           12,
        # BF-582: was hardcoded 60 in main.py; now config-driven so
        # legitimately long pipelines aren't mid-flight reset.
        "stale_execution_minutes":          60,
        # BF-582: periodic scheduler tick for trigger_type=schedule.
        # 0 disables the scheduler entirely.  Default 60s.
        "scheduler_tick_seconds":           60,
        "poll_interval_seconds":            15,
        # FB-48 (2026-09-20): "airflow_dag_cache_ttl" REMOVED.  Declared
        # 2026-09-07 for discoverability, and nothing read it -- there is no
        # DAG-list cache.  AirflowClient.list_dags() calls GET /dags on
        # every request.  A TTL for a cache that does not exist reads as a
        # working knob; if the cache is built, declare its TTL WITH it.
        "size_thresholds": {
            "native_max_rows":              500000,
            "spark_submit_max_rows":        10000000,
        },
        "spark_defaults": {
            "driver_memory":    "4g",
            "executor_memory":  "8g",
            "executor_cores":   4,
            "num_executors":    4,
            "spark_conf":       {"spark.sql.parquet.compression.codec": "snappy"},
        },
        "native_defaults": {
            "duckdb_memory_limit":  "2g",
            "duckdb_threads":       4,
            "max_rows_warning":     1000000,
        },
        "on_complete": {
            "invalidate_cache":     True,
            "refresh_partitions":   True,
            "run_dq_checks":        True,
            "broadcast_ws":         True,
            "update_lineage":       True,
            "trigger_dependents":   True,
        },
        "sla": {
            "enabled":                  True,
            "default_notify_channels":  ["ws", "webhook"],
        },
        "dead_letter": {
            "enabled":              True,
            "max_retries":          3,
            "capture_bad_records":  True,
        },
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "webhook_secret":    '',
    },
    # Phase 77 — Smart Predictions (charts, pivots, data profiling)
    "smart_predictions": {
        "enabled":                  True,
        "max_chart_suggestions":    5,
        "max_pivot_suggestions":    4,
        "profile_max_top_values":   10,
        "outlier_method":           "iqr",       # "iqr" | "zscore"
        "outlier_iqr_multiplier":   1.5,
        "profile_sample_limit":     100000,
        "inline_chart_enabled":     True,
    },
    # Phase 95 — Local Transformer Semantic Intelligence
    "local_llm": {
        "enabled":                      False,      # master toggle — opt-in only
        "model_path":                   "cssupport/t5-small-awesome-text-to-sql",  # HuggingFace model ID or local path
        "model_name":                   "",          # display name for admin UI
        "n_ctx":                        512,         # max input token length (512 for T5-small)
        "n_gpu_layers":                 0,           # 0 = CPU only, -1 = auto GPU
        "max_tokens":                   256,         # max generation tokens
        "temperature":                  0.1,         # low = deterministic SQL
        "embedder_model":               "all-MiniLM-L6-v2",  # sentence-transformers model name
        "embedder_enabled":             True,        # enable semantic similarity (sentence-transformers)
        "sql_generation_enabled":       True,        # enable SQL generation (HuggingFace transformers)
        "startup_preload":              True,        # pre-load models at startup
        "generation_timeout_seconds":   30,          # timeout per generation call
        "finance_domain_hints":         True,        # include SAP/finance context in prompts
    },
    # Phase 99 — Data Quality Monitoring
    "data_quality": {
        "enabled":                      True,       # master toggle
        "schedule_interval_minutes":    60,         # default APScheduler interval for DQ checks
        "execution_timeout_seconds":    300,        # timeout per rule execution
        "result_retention_days":        90,         # auto-cleanup old results
        "max_rules":                    200,        # max DQ rules total
        "max_concurrent_checks":        5,          # max parallel rule executions
        "notify_on_failure":            True,       # send WS notification on rule failure
        "notify_severity_threshold":    "warning",  # "info" | "warning" | "critical"
        "cleanup_interval_hours":       6,          # cleanup daemon interval
        "alert_channels":               [],         # [{"type":"email","smtp_host":...}, {"type":"webhook","url":...}, {"type":"slack","webhook_url":...}]
        "alert_cooldown_minutes":       60,         # min minutes between SENT alerts per rule (0 = alert on every failure)
    },
    # Phase 100 — Onboarding / Guided Tours
    "onboarding": {
        "enabled":                      True,       # master toggle
        "auto_show_on_first_login":     True,       # auto-start tour for new users
        "available_tours":              ["getting_started", "query_builder",
                                         "business_reports", "data_quality",
                                         "published_views"],
        "default_tour":                 "getting_started",
    },
    # Phase 114 — Report Collaboration
    "collaboration": {
        "enabled":                      True,
        "max_comments_per_report":     500,
        "change_log_retention_days":   365,
        "mentions_enabled":            True,
    },
    # Phase 75 — Published Views API (external data access)
    "published_views": {
        "enabled":                     True,
        "max_concurrent":              50,         # dedicated concurrency pool (separate from main queries)
        "default_cache_ttl_seconds":   300,        # 5 min default response cache per view+filter combo
        "max_cache_size_mb":           2048,       # 2 GB max for published view response cache
        "cache_dir":                   "/usr/local/querystudioapi/nfs/data/published_cache",
        "default_rate_limit":          "60/minute",   # per-API-key rate limit
        "max_rate_limit":              "300/minute",  # hard cap on per-key limit
        # ── Row limits ───────────────────────────────────────────────────
        # MEASURED 2026-08-20 (5M-row x 5-col parquet, fresh process, RSS
        # sampled at 2ms).  max_limit bounds the page Arrow table AND the
        # per-request encode cost; it is NOT the bound on dataset-scaled
        # memory -- that is dataset_row_cap.  Numbers, unsorted + streamed:
        #   limit 1,000 -> 31MB    limit 50,000 -> 33MB
        #   limit 1M    -> 92MB (+108MB streamed JSON encode)
        # With stream_results OFF a 1M-row JSON page costs 777MB, so max_limit
        # is the ONLY bound in that configuration.  The dataset-scaled risk is
        # the ?sort path: envelope.read_page does pq.read_table over the WHOLE
        # file (a global sort cannot be evaluated from a prefix) -- measured
        # 803MB for a limit=1000 sorted page on 5M rows, i.e. limit is
        # irrelevant there and dataset_row_cap is the actual OOM guard.
        #
        # 2026-08-20 -- THREE OF THESE WERE GHOSTS: read by code with an
        # inline fallback, declared nowhere, so no admin route could set
        # them and no reader could discover them.  Values below are the
        # inline fallbacks verbatim -- declaring them changes nothing.
        "default_limit":               1000,       # NULL default_limit on a published_views row resolves here (helpers.resolve_view_limits)
        "max_limit":                   50000,      # NULL max_limit on the row resolves here (a page = one in-memory Arrow table, so this is a MEMORY bound)
        "dataset_row_cap":             1000000,    # the ACTUAL ceiling on an "unlimited" /data response (envelope.py); disclosed via total_mode=at_least
        # 2026-09-15 -- a paged /data MISS materialises offset+limit+1 rows
        # (regrown geometrically for sequential pagers, capped at
        # dataset_row_cap) instead of the whole dataset; a bounded
        # materialisation is disclosed as total_mode=at_least.  False =
        # every miss materialises the full capped dataset (the old cost, the
        # old exact total).  Read by helpers._pv_bounded_page_scan_enabled.
        "bounded_page_scan":           True,
        # 2026-09-27 -- SCHEMA-DRIFT NOTICES (core/published_view_schema.py).
        # When a view's columns change (a republish, a query update, or an
        # auto-detect on the dataset behind a report-sourced view) a schema
        # version is recorded and the owners of the API keys that can call
        # the view are emailed.  Usernames are not addresses: an owner whose
        # ``created_by`` already contains '@' is written to as-is; otherwise
        # this domain is appended ("alice" -> "alice@corp.example").  Empty
        # = no address can be derived, and the version row records the
        # owners as UNROUTED (they still get an in-app notification).
        "notify_email_domain":         "",
        # 2026-08-20 -- NOT WIRED, and deliberately left that way.  This is
        # displayed, persisted and audit-logged by the admin screen and read
        # by NOTHING.  Wiring it is not a one-liner: it would have to become
        # the fallback for `default_limit` above, taking every NULL-row view
        # from 1,000 to 100,000 rows per page by default -- a 100x change in
        # peak memory for every published-view consumer, which is an operator
        # decision, not a tidy-up.  Flagged rather than flipped; the same
        # mistake in the other direction is what 2c86f510 made with
        # max_row_limit.  Pinned by test_admin_knobs_are_wired_2026_08_20.py.
        "default_row_limit":           100000,     # INERT -- see above
        # 2026-08-20 -- SCOPE CORRECTED.  This was documented as a "hard cap
        # on rows per request", which it is not: it TIGHTENS caps that exist
        # (any positive per-view max, and any NULL row resolving to max_limit
        # above) but it does not INVENT one, so a view published with
        # max_limit=0 is not bounded by it.  See f37eebcc -- treating 0 as
        # "no cap declared" silently truncated unlimited views at this value.
        "max_row_limit":               1000000,    # ceiling applied to caps that exist (NOT to explicitly-unlimited views)
        "api_key_prefix":              "qs_",      # prefix for generated API keys
        "access_log_retention_days":   90,
        "cleanup_interval_hours":      6,
        "param_substitution_enabled":  True,   # Phase 80: enable {{param}} substitution in query configs
        "dedup_timeout_seconds":       60,     # Phase 80: max seconds to wait for an in-flight duplicate request
        "ad_group_fetch_fail_mode":    "deny", # Phase 83H: "deny"|"allow" — what to do when AD group fetch fails
        # 2026-10-25 -- THE data-policy switch a NEW published API starts with
        # (published_views.entitlement_mode, read as "data policies on this
        # API": off = an API key reads the API's data with no row policy and
        # no entitlement dimension applied; apply = the key is the resolved
        # principal api_key:<id> -- its own bindings and values, FB-45's
        # composition for what it holds nothing of).  A signed-in person is
        # governed as a person whatever the switch.  The owner (2026-10-25):
        # "if no AD groups it should work ... no one should get 403 ... config
        # will decide which published API should have data policies on it."
        # 2026-10-25 (security review + the owner: "everything should be
        # based on config"): an API whose switch nobody SET follows THIS key
        # live, on every request (core/row_security/entitlement.py::
        # effective_mode) -- changing it moves every such API, not only new
        # ones.  Default APPLY: a key holding nothing on a governed table reads
        # zero rows (200, disclosed), never a 403; an ungoverned table reads
        # the same either way.  An API's own switch is set by the roles in
        # row_security.data_policy_switch_roles.
        "default_data_policy_mode":    "apply",
        "large_result_threshold":       50000,  # rows above which JSON responses include large_result_warning
        "max_concurrent_per_key":       10,     # max concurrent requests per API key (0 = unlimited)
        "cache_eviction_interval_hours": 4,     # how often LRU cache eviction job runs
        "execution_timeout_seconds":    300,    # Phase 133-C: max seconds per view execution (5 min)
        # ── Bulk export (2026-08) — true incremental streaming ────────────
        # These govern /api/v1/views/{slug}/bulk ONLY.  The paged /data
        # contract above is untouched: its max_limit is a MEMORY bound
        # (a page becomes one in-memory Arrow table), whereas the bulk
        # reader never materializes a table, so its row count can be
        # unbounded without changing peak RSS.
        "bulk_enabled":                True,   # master switch for bulk endpoints
        "bulk_batch_rows":             65536,  # rows per streamed batch — THE memory bound
        "bulk_max_rows":               0,      # rows per bulk response (0 = UNBOUNDED)
        "bulk_dataset_row_cap":        0,      # bulk materialization cap (0 = UNBOUNDED; writes to DISK)
        "bulk_max_concurrent":         4,      # concurrent bulk streams per pod (isolation lever)
        "bulk_max_per_key":            2,      # concurrent bulk streams one API key may hold (0 = unlimited)
        "bulk_stall_timeout_seconds":  300,    # abort after N seconds with NO bytes produced
        "bulk_build_timeout_seconds":  1800,   # max seconds for the materialization phase (0 = none)
        # ── Background bulk builds (2026-08-22, design_starburst_140m §4.4).
        # DECLARED by the Phase-0 Starburst agent under the ownership
        # exception (an undeclared key read via a getattr default is a
        # branch that never runs).  POST /bulk/prepare materialises the
        # dataset OFF the request path under THIS budget — the inline
        # /bulk build keeps bulk_build_timeout_seconds (1800), which a
        # 140M-row Starburst materialisation (1-2.5 h) cannot meet: the
        # request 504'd and every retry restarted the build from zero.
        # 0 = no budget (the build runs to completion or failure).
        "bulk_prepare_timeout_seconds": 14400,
        # ── Signed part download (2026-08-22, §4.4) — lifetime of the
        # HMAC-signed per-part URLs returned by GET /bulk/download.  The
        # dataset behind them is already materialised and immutable; the
        # TTL only bounds how long a leaked link stays live.
        "bulk_download_url_ttl_seconds": 900,
        # Bulk datasets live in their OWN cache slot (v{id}_bulk_{key}.parquet)
        # and therefore need their OWN budget.  Billing a 20 GB export against
        # max_cache_size_mb (2 GB) made the LRU evictor delete every paged
        # entry in the cache, still fail to get under budget, and repeat every
        # 4 h — dropping all /data consumers to a permanent MISS because of one
        # bulk pull.  0 = no bulk budget (never evict bulk datasets by size).
        "bulk_cache_size_mb":          16384,  # 16 GB for materialized bulk datasets
        # In-flight streams read their dataset for as long as the pull takes,
        # and a resuming cursor needs the same file to still be there.  Never
        # size-evict a bulk dataset younger than this.
        "bulk_cache_min_retain_minutes": 60,
        # Phase 98-I: Kafka-driven cache invalidation (disabled by default)
        "kafka_enabled":               False,
        "kafka_bootstrap_servers":     "localhost:9092",
        "kafka_topic_pattern":         "{table}_{partition_col}",
        "kafka_consumer_group":        "querystudio_cache_invalidation",
        "kafka_auto_offset_reset":     "latest",
        "kafka_session_timeout_ms":    30000,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "allow_anonymous_when_auth_disabled": False,
        "api_key_cache_enabled":             True,
        "api_key_cache_ttl_seconds":         30,
        "api_key_touch_throttle_seconds":    30,
        "cache_ttl":                         300,
        "empty_scope_master_key":            False,
        "kafka_known_partition_cols":        ['business_date', 'event', 'code'],
        "rate_limit_ad_users":               False,
        "rate_limit_fallback_per_minute":    60,
        "require_key_approval":              True,
        "stream_batch_rows":                 10000,
        "stream_results":                    True,
        "warmup_enabled":                    False,
        "warmup_interval_minutes":           5,
        "warmup_max_concurrent":             3,
        # 2026-10-03 -- the access-log row of every published-API call is
        # QUEUED and written in batches off the request
        # (core/access_log_batcher.py): one multi-row INSERT per flush
        # interval or per ``access_log_batch_rows`` rows; a full queue drops
        # the new row and says so at ERROR (counted).  "sync" = one INSERT
        # per request, as before.
        "access_log_mode":                   "batched",
        "access_log_flush_seconds":          1.0,
        "access_log_batch_rows":             500,
        "access_log_queue_max":              10000,
        # 2026-10-04 -- the per-WORKER memory guard (core/process_memory.py).
        # Measured live: after 4 x 10M-row /bulk?format=csv the 2-worker
        # published-api container sat at 1.63 of 2 GiB idle, and the next
        # uncached /data on a big view OOM-killed a worker, dropping every
        # request in flight on it.  New LARGE work (every /bulk stream, a
        # /bulk/prepare build, an uncached /data materialisation) is now
        # refused with 503 + Retry-After while this process's RSS is at or
        # above memory_guard_fraction x its share of the pod limit (limit /
        # server processes), or the pod's cgroup working set is at or above
        # memory_guard_fraction x the limit -- measured after one give-back
        # of retained memory.  Cached pages are always served.
        # memory_guard_pod_limit_mb: 0 = the cgroup memory.max (what the OOM
        # killer enforces); off-cgroup with 0 the guard is INERT and says so.
        "memory_guard_enabled":              True,
        "memory_guard_fraction":             0.75,
        "memory_guard_retry_after_seconds":  15,
        "memory_guard_pod_limit_mb":         0,
        # Rows per ENCODE slice when /bulk writes jsonl / csv / json
        # (api/published_views/bulk.py -> bulk_text.py, columnar since
        # 2026-10-04).  The decode batch stays bulk_batch_rows; the slice
        # bounds the encoder's transient memory (it was 163 MiB traced per
        # 1M-row CSV stream when a whole 65,536-row batch became Python
        # dicts, pages the allocators then KEPT as RSS).
        "bulk_encode_rows":                  8192,
        # 2026-10-04 -- ONE cold materialisation per dataset across every
        # process and pod (api/published_views/cold_flight.py, table
        # pv_materialise_flights).  Concurrent identical /data MISSes: the
        # first leads, the rest wait (at most dedup_timeout_seconds) and are
        # served the cache file it publishes; a leader whose heartbeat is
        # older than cold_flight_stale_seconds is dead and taken over.
        "cold_flight_enabled":               True,
        "cold_flight_stale_seconds":         15,
        # 2026-10-17 -- the published-API INVENTORY + LIFECYCLE
        # (core/published_api/; docs/PUBLISHED_API_INVENTORY_DASHBOARD_DESIGN_2026_10_17.html).
        # lifecycle_retired_status: what a RETIRED API answers a consumer (410 Gone,
        #   the default -- "gone, deliberately"; 404 is the other spelling an estate
        #   may want).  lifecycle_sunset_notice_days: how many days before a
        #   deprecated API's sunset its consumers are told once more.
        #   inventory_idle_days_default: the "no calls in N days" tile's N.
        "lifecycle_retired_status":          410,
        "lifecycle_sunset_notice_days":      7,
        "inventory_idle_days_default":       30,
        # The ROLLUP (core/published_api/rollup.py; daemon published_api_rollup on
        # the scheduler pod): raw call rows folded into hourly / daily buckets with
        # a log-spaced latency histogram.  interval = the tick; lag_minutes = how
        # far back each tick re-rolls (late batches); retention per grain (0 =
        # keep); the bin ratio is recorded on the state row and may not change
        # while rows exist; exact percentiles only for ONE API under this many raw
        # rows (else the histogram, resolution stated).
        "rollup_enabled":                    True,
        "rollup_interval_seconds":           60,
        "rollup_lag_minutes":                10,
        "rollup_hourly_retention_days":      400,
        "rollup_daily_retention_days":       0,
        "rollup_latency_bin_ratio":          1.5,
        "metrics_exact_percentile_max_rows": 200000,
        # ALERTS (core/published_api/alerts.py; design §3.8).  Thresholds are
        # ROWS (published_api_alert_thresholds); alerts_enabled gates the pass
        # that rides the rollup tick (thresholds, dependency-broken, sunsets).
        # alert_group is the Netcool AlertGroup the six API alert kinds are
        # SEEDED with -- a member of core/feed/netcool.py::ALERT_GROUPS (the
        # console routes BY GROUP; the console team must map it); the
        # feed_alert_kinds rows are the truth afterwards (the kind editor).
        "alerts_enabled":                    True,
        "alert_group":                       "PUBLISHED_API",
        # The access-log writers' heartbeat rows (published_api_ingest_health)
        # are judged by component health's silence rule and ITS keys
        # (component_health.pod_down_after_seconds / pod_retire_after_seconds):
        # one rule, one place -- core/published_api/ingest_health.py.
    },
    # Phase 122 — SQL Partition Intelligence
    "sql_partition_intelligence": {
        "enabled":                     True,
        "fallback_to_sql_parsing":     True,   # parse raw SQL when config filters empty
        "max_sql_length":              50000,   # skip parsing for very large SQL
    },
    # Phase 122C — SQL File Management
    # ── Declared 2026-10-07 ─────────────────────────────────────────────
    # Two sections read by production and declared nowhere: ``pod.role``
    # (core/pod_role.py reads ``get_section("pod")["role"]`` -- the env var
    # QS_POD_ROLE still wins; "" = not set) and ``fleet.enforce_
    # preconditions`` (core/fleet_safety.py; False = log unmet preconditions,
    # True = refuse to start).  Verbatim.
    # 2026-11-02 -- VALUE LISTS (core/value_lists.py): the dropdown-list FILL.
    "value_lists": {
        # the most values a stored list may hold.  The cap is pushed INTO the
        # source query (SELECT * FROM (<sql>) LIMIT cap+1), so a high-
        # cardinality column (a book, a trade id, a counterparty) never ships
        # millions of rows or scans every file; a list over it is recorded as
        # too_big in plain words and the dropdown searches the source as you type.
        "max_items": 50000,
        # a failed fill waits a DOUBLING time before the next try (5 min, 10, 20,
        # ...), capped here -- never every tick for ever.
        "retry_backoff_max_seconds": 21600,
    },
    "pod": {
        "role": "",
    },
    "fleet": {
        "enforce_preconditions": False,
    },
    "sql_files": {
        "storage_dir":                 "/usr/local/querystudioapi/nfs/data/sql_files",
        "max_file_size":               1048576,    # 1MB max per .sql file
        # FB-48 (2026-09-20) -- NOW ENFORCED at POST /api/sql-files.  It was
        # declared and read by nothing while ``max_file_size`` beside it was
        # enforced, so a per-user cap an operator set was silently absent.
        "max_files_per_user":          500,
        "versioning":                  True,
    },
    # Phase 123 — Automated Database Backup
    "backup": {
        "enabled":          False,
        "schedule_hours":   24,
        "backup_dir":       "./data/backups",
        "retention_count":  7,
        # 2026-09-13 security-hotspot triage (ruff S607, partial executable
        # path).  "" = resolve pg_dump on PATH at backup time.  Set an
        # ABSOLUTE path to pin the binary on a host whose PATH is not under
        # the operator's sole control.  core/backup.py resolves this once
        # and LOGS the absolute path it is about to run, so an audit can
        # answer "which pg_dump made this file?" from the log alone --
        # which a bare "pg_dump" argv could never answer.
        "pg_dump_path":     "",
    },
    # Health probe configuration — controls K8s liveness/readiness behaviour
    "health": {
        "liveness_db_check":    True,   # Include DB connectivity in liveness probe
        "failure_threshold":    3,      # Consecutive DB failures before liveness returns 503
        "enable_write_test":    False,  # If True, also run PRAGMA wal_checkpoint in probe
        # 2026-07-13 — hard timeout (seconds) for each probe's DB/disk/redis
        # sub-check, run on a DEDICATED probe thread pool.  Keep it BELOW the
        # K8s probe timeoutSeconds (default 5) so the endpoint always answers
        # within the probe window.  On timeout the check is treated as "busy":
        # liveness stays alive, readiness → not_ready — never a client-timeout
        # restart.  Set lower on tiny pods, higher only if the DB is genuinely
        # slow AND probe timeoutSeconds was raised to match.
        "probe_timeout_seconds": 3.0,
    },
    # 2026-10-17 -- component health, one place (core/component_health/,
    # docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html).  Every threshold the
    # reporter, the fleet watcher and the page apply is DECLARED here; a
    # reader goes through core.config.component_health (properties), never a
    # raw dict.
    "component_health": {
        "enabled":                           True,
        # the per-pod reporter's cycle, and the dependency probe round on the
        # scheduler-lock holder
        "report_interval_seconds":           15,
        "dependency_probe_interval_seconds": 30,
        # a probe's budget (ceiling 10 s), the dedicated pool, probes per
        # watcher tick, and the latency past which a healthy probe is "slow"
        "probe_timeout_seconds":             3.0,
        "probe_pool_size":                   4,
        "max_probes_per_cycle":              20,
        "slow_probe_ms":                     2000,
        # silence: unknown after stale_after, a pod DOWN after pod_down_after;
        # a daemon with no tick for N x its interval is degraded
        "stale_after_seconds":               45,
        "pod_down_after_seconds":            90,
        "daemon_silent_intervals":           3,
        # alerting: a transition is confirmed after N consecutive
        # observations; unknown alerts after this long; a clear needs N
        # healthy cycles
        "unknown_alert_after_seconds":       300,
        "transition_confirmations":          2,
        "clear_after_cycles":                2,
        "alerts_enabled":                    True,
        "alert_group":                       "PLATFORM",
        # retention: confirmed transitions, rows of a pod that stopped
        # reporting, a drain that nobody renewed
        "events_retention_days":             30,
        # a silent pod is RETIRED (rows gone, history kept, no alert) once a
        # newer pod of its role reports, or after this long; a ROLE with no
        # live pod is what is down (the pod:role:<role> fleet row)
        "pod_retire_after_seconds":          600,
        "dead_pod_retention_hours":          24,
        "intent_default_expiry_minutes":     120,
        # the page: an in-process cache of the one SELECT (the reporters write
        # every 15 s; 5 s keeps 100 pollers on a 2-CPU pod off the executor)
        "page_cache_seconds":                5,
        # which connections the fleet watcher probes: active | feeds_only |
        # none; types never probed (a probe on a paid source costs money)
        "probe_connections": {
            "mode":          "active",
            "exclude_types": ["snowflake"],
        },
        # processes with no reporter of their own, probed by URL
        # (name -> url): the ui Service, Clockwork, OG's polling service
        "external_pods":                     {},
        # the encryption-key sweep (a count of unreadable secrets) cadence
        "key_sweep_interval_seconds":        300,
        # a TEST SEAM for the Docker proof (C11): POST /api/admin/component-
        # health/plant-slow-probe registers a dependency whose probe sleeps,
        # so the bounded pool is proven on the running system.  404 unless
        # true; the rig's overlay sets it; never in a production values file.
        "planted_probe_enabled":             False,
    },
    # Phase 120 — Self-Healing Agents
    "agents": {
        "enabled":              True,       # master switch — enabled Phase 121
        "decision_engine":      "rules",    # "rules" (default, no deps) or "llm" (requires API key)
        "llm_provider":         "",         # "claude", "openai", or "" — only used when decision_engine="llm"
        "llm_api_key":          "",         # API key for LLM provider
        "llm_model":            "claude-sonnet-4-20250514",
        "llm_system_account":   "",         # system account name for encrypted LLM API key
        "llm_max_calls_per_hour": 100,      # Phase 125: rate limit LLM API calls per hour
        "llm_timeout_seconds":  10,         # Phase 125: per-call timeout for LLM requests
        # 2026-11-01 -- insight stories (core/reports/insight_story.py): the assistant writes at most
        # this many stories per person and per report an hour; the newest N stories kept per report
        "story_calls_per_hour_per_user":   30,
        "story_calls_per_hour_per_report": 200,
        "story_rows_per_report":           500,
        "llm_rules_first":      True,       # Phase 125: skip LLM when rules engine matches
        "max_decision_log_days": 30,        # auto-cleanup agent decision audit trail
        "query_resilience": {
            "enabled":                      True,
            "max_retries":                  2,
            "backoff_seconds":              5,
            "auto_add_partition_filter":    True,
            "auto_refresh_credentials":    True,
            "auto_reinstall_extensions":   True,
            "auto_reduce_memory":          True,
            "cte_partition_analysis":      True,   # Phase 122D: analyze CTE base tables for partition needs
            "auto_retry_enabled":          True,   # Phase 125: actually re-execute queries after agent fix
            "auto_retry_strategies": [              # Phase 125: which strategies trigger auto-retry
                "refresh_credentials", "reduce_memory", "reinstall_extension",
                "retry_with_backoff", "refresh_schema",
            ],
        },
        "dq_monitor": {
            "enabled":                     True,
            "schedule_minutes":            60,
            "null_threshold":              0.5,
            "row_count_spike_threshold":   3.0,
            "row_count_drop_threshold":    0.3,
            "freshness_hours":             48,
            "connections":                 [],
            "webhooks_enabled":            True,    # Phase 125: fire webhooks on DQ alerts
            "notify_admins":               True,    # Phase 125: enqueue in-app notifications
        },
        "data_pipeline": {
            "enabled":                     True,
            "auto_profile_uploads":        True,
            "suggest_type_fixes":          True,
        },
    },
    # Phase 160 (2026-07-01) — brain DuckDB store.  Columnar mirror of
    # brain metadata sitting in front of the primary transactional DB
    # for fast repeat lookups.  One writer (mirror daemon on the
    # scheduler-elect pod), N readers (every API pod, read-only).  See
    # core/brain_duckdb_store.py + core/brain_duckdb_mirror.py.
    # Brain defaults ON per operator directive
    # (feedback_brain_on_by_default): read path is fail-open — any
    # store error / miss falls through to primary DB automatically, so
    # enabling this cannot make the brain worse, only faster.
    "brain_store": {
        "enabled":                       True,
        # Empty string = derive from paths.data_dir.  Set to an
        # absolute path (e.g. shared NFS mount) to override.
        "dir":                           "",
        # Mirror daemon: pulls from primary DB every N seconds into the
        # columnar store.  DEFAULT OFF (2026-07-04) -- the mirror
        # DUPLICATES metadata (col_stats / snapshot pointers / hot
        # rollups) into a separate DuckDB file; per operator direction we
        # do not duplicate data unless an admin explicitly opts in.
        # Readers fail-open to the primary DB when the store is empty, so
        # OFF costs nothing but the columnar speedup.  Enable at runtime
        # via POST /api/admin/brain/mirror-enabled (SystemSetting) or set
        # this to true.  When enabled it runs on exactly one writer (the
        # dedicated scheduler pod / SchedulerLease holder).
        "mirror_enabled":                False,
        "mirror_interval_seconds":       300,
        # "Recently active" window for the col_stats mirror — any
        # (bucket, prefix) queried within this many hours is mirrored
        # on the next tick.  Bounds cross-tick work.
        "mirror_hot_lookback_hours":     24,
        # Ceiling on hot (bucket, prefix) pairs touched per tick.
        "mirror_hot_top_k":              500,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "advisor_avg_file_size_cap":     32 * 1024 * 1024,
        "advisor_min_files":             200,
        "advisor_min_queries_7d":        20,
        "advisor_min_time_budget_s":     60,
        "advisor_storage_multiplier":    3.0,
        "advisor_top_k":                 50,
    },
    # Phase 168 — warm DuckDB subprocess pool.  DEFAULT ON since
    # 2026-08-22 (design_s3_speed §4 Phase 3): the per-query subprocess
    # was the ONLY reason DuckDB's HTTP-metadata / parquet-footer caches
    # died with every query — at the operator's measured scale that was
    # ~108 s of survivor footer re-GETs per warm repeat.  Isolation is by
    # construction: each request runs on a FRESH cursor (session) and the
    # persistent instance (see db_instance_reuse) is wiped + VERIFIED
    # empty between requests, stashed only per connection fingerprint.
    # Env kill-switch: QS_DUCKDB_POOL=off.
    # ── 2026-09-27 -- PROGRESSIVE RESULTS (core/progressive_results.py).
    # Rows are delivered while a long query runs: the COPY is retargeted
    # to a segments directory so DuckDB emits sequentially-finalised parts.
    # Default ON since 2026-08-02, and since addendum 8b (2026-09-25) it
    # rides the warm pool.  It was READ by production for eight weeks and
    # DECLARED nowhere, so its kill switch was unreachable from config.json
    # and from QUERYSTUDIO_PROGRESSIVE_RESULTS_ENABLED, absent from
    # init_config's output and from every admin screen -- and the
    # declared-key guard passed, because its section-bound-wrapper survey
    # only recognised a wrapper whose section was ALREADY declared
    # (docs/PROD_CONFIG_DEPLOYMENT_PLAN_2026_09_27.html, P1).  Every value
    # below is the reader's own fallback, VERBATIM (the 2026-08-20 rule).
    # ``null`` = "not set": first_segment_rows derives from the column
    # count, spool_dir from paths.download_temp_dir.
    "progressive_results": {
        "enabled":              True,
        "rows_per_segment":     50000,      # floored at 100 by the reader
        "first_segment_rows":   None,
        "arrow_stream":         True,
        "copy_file_size_bytes": 33554432,   # 32 MiB; floored at 1 MB
        "orphan_ttl_hours":     24,
        "spool_dir":            None,
    },
    # ── 2026-09-27 -- ISLAND PREFIX LISTING (core/island_prefix_planner.py):
    # the level-by-level S3 LIST walk that narrows a hive-partitioned prefix
    # to the islands a query needs before any object is listed.  Found by
    # the declared-key guard the day its wrapper blind spot was closed
    # (same commit as progressive_results): read for months, declared
    # nowhere.  Values are the reader's own constants, verbatim.
    "island_listing": {
        "enabled":      True,
        "max_prefixes": 128,   # frontier width at which the walk stops REFINING
        "max_depth":    16,
    },
    "duckdb_pool": {
        "enabled":                       True,
        # Workers per pod; 0 means "auto" = min(4, cpu-2).
        "size":                          0,
        "max_requests_per_worker":       200,
        "max_worker_rss_mb":             4096,
        "worker_idle_ttl_seconds":       300,
        # If no worker is free within this window, fall through to the
        # legacy per-query Popen path -- never block the query.
        "checkout_timeout_seconds":      5,
        # Phase 3 (2026-08-22) — keep ONE DuckDB DatabaseInstance alive
        # inside each pool worker across requests of the SAME connection
        # fingerprint (native-S3 plans only).  This is what lets the
        # external-file / parquet-metadata caches outlive one query and
        # collapse the per-survivor footer re-GETs.  Each request still
        # runs on a fresh cursor; the shared catalog is wiped and PROVEN
        # empty before the instance may be reused — an unverifiable wipe
        # drops the instance (perf cost, never an isolation cost).
        "db_instance_reuse":             True,
        # Metadata-cache trust policy for the reused instance:
        #   "revalidate" — never serve cached file bytes without ONE HEAD
        #                  proving the object unchanged (ETag; DuckDB
        #                  validate_external_file_cache=VALIDATE_ALL).
        #                  Measured: 3 GETs/file → 1 HEAD/file on repeats.
        #   "auto"       — "full" when the parent PROVES every registered
        #                  table on the request is Iceberg (data files are
        #                  immutable-by-format), else "revalidate".
        #   "full"       — always trust cached HTTP metadata + parsed
        #                  footers (0 requests/file on repeats; a file
        #                  overwritten in place fails LOUDLY, never stale).
        "metadata_cache_mode":           "auto",
        # Hard age bound on a reused instance: whatever the cache mode,
        # the instance (and every cache in it) is dropped after this many
        # seconds.  A throttle on staleness exposure, not a gate;
        # <=0 is INVALID and falls back to the default (never "forever").
        "db_instance_max_age_seconds":   3600,
    },
    # ═══ 2026-08-04 discoverability sweep ═══════════════════════════════
    # The sections below were set in deployment config.json and READ by
    # code via inline get()/section-.get() defaults, but had no entry here
    # — operators could not discover them and validate_config() flagged
    # them as "unknown config section (typo?)".  Every value is a byte-copy
    # of its read-site inline default, so behaviour is unchanged for any
    # deployment that does not set the key.  Read sites cited per section.
    "websocket": {
        # main.py /ws identify handler (default False — flip true once all clients send the session token).
        "require_auth": False,
    },
    "smart_cancel": {
        # Phase 141 stale-execution auto-cancel loop (main.py reads all three).
        "check_interval_seconds":         30,   # scan cadence
        "client_stale_seconds":           180,  # no client heartbeat for this long AND …
        "engine_progress_grace_seconds":  120,  # … no engine progress for this long → cancel
    },
    # ── Declared 2026-10-07 ─────────────────────────────────────────────
    # core/brain_cleanup_daemon.py reads these through a THREE-ARGUMENT
    # forwarding wrapper (``_cfg(section, key, fallback)`` -> ``get``), which
    # the declared-config guard could not see.  Values VERBATIM from the
    # read sites.  The daemon floors the two TTLs at 1 (a 0 would wipe the
    # table); 0 is therefore not "keep forever" here.
    "brain_cleanup": {
        "interval_hours": 6,                # cron_interval_hours()
    },
    "brain_prewarm": {
        # core/brain_prewarm.py (section-bound wrapper over an aliased
        # getter); verbatim, declared 2026-10-07.
        "enabled":                  True,
        "throttle_seconds":         15,
        "top_n":                    3,
    },
    "brain_pruning_memo": {
        "cleanup_ttl_hours": 72,            # cleanup_tick(): memo rows older than this are evicted
        # core/brain_pruning_memo.py accessors (verbatim, 2026-10-07).
        "enabled":                  True,
        "in_process_max_entries":   1000,
        "in_process_ttl_seconds":   600,
        "max_survivor_files":       200000,
    },
    "brain_route_history": {
        "cleanup_ttl_days": 30,             # cleanup_tick(): brain_route_outcome rows older than this
        # core/brain_route_history.py accessors (verbatim, 2026-10-07).
        "enabled":                  True,
        "ema_alpha":                0.3,
        "flip_savings_factor":      1.5,
        "min_samples_for_decision": 3,
    },
    "brain_router": {
        # core/brain_router.py accessors (verbatim, 2026-10-07).  The two
        # ``None`` are "honour the module-side default" -- the read is
        # ``_cfg(key, None)`` and the module decides from None.
        "enabled":                      True,
        "small_file_threshold":         None,
        "spark_cost_model_enabled":     False,
        "spark_cost_model_min_samples": None,
        "spark_route_savings_factor":   1.5,
        "spark_route_threshold_seconds": 5.0,
    },
    "brain_coordinator": {
        # core/brain_coordinator.py accessors.
        "enabled":                              True,
        "cron_interval_minutes":                5,
        "pressure_threshold_seconds_per_file":  0.5,
    },
    "brain_cost_model": {
        # ── Declared 2026-10-07 ─────────────────────────────────────
        # Read by production through an idiom the declared-config guard
        # could not see (an aliased getter, a 3-arg forwarding wrapper,
        # or a get_section sub-dict chain).  VERBATIM from the read site.
        "assumed_mirror_speedup":           2.0,    # core/brain_cost_model.py
        # core/brain_cost_model.py accessors.
        "enabled":                          True,
        "lookback_hours":                   168,
        "stats_cache_seconds":              300,
        "min_observations_for_prediction":  10,
        "mirror_routing_overhead_seconds":  0.05,
        "gateway_lookup_overhead_seconds":  0.10,
    },
    "brain_forecaster": {
        # core/brain_forecaster.py accessors.
        "enabled":                     True,
        "lookback_days":               28,
        "min_observations_per_table":  20,
        "spike_multiplier_threshold":  3.0,
        "max_lookahead_hours":         24,
    },
    "brain_skew_detector": {
        # core/brain_skew_detector.py accessors.
        "enabled":                   True,
        "lookback_hours":            168,
        "skew_divergence_threshold": 5.0,
        "min_queries_for_signal":    5,
    },
    "business_portal": {
        # config.py business-portal accessor block.
        "enabled":                  True,
        "welcome_message":          "Welcome to QueryStudio",
        "welcome_subtitle":         "Your enterprise data platform",
        "recent_reports_limit":     8,
        "favorites_limit":          12,
        "certified_templates_limit": 6,
        "recent_activity_limit":    10,
        "quick_actions_enabled":    True,
        "kpi_cards_enabled":        True,
    },
    "join_pruner": {
        # core/join_pruner.py (module mirrors these in its own _DEFAULTS + .get inline defaults).
        "enabled":                       True,
        "runtime_dynamic_filter":        True,
        "runtime_in_list_max":           10000,
        "runtime_scan_max_anchor_files": 2000,
    },
    "partition_cache": {
        # config.py partition-cache accessor block.
        "l1_ttl_seconds":  300,
        "l2_ttl_seconds":  18000,
        "l1_max_entries":  100,
    },
    "portal_cred_prewarmer": {
        # core/portal_cred_prewarmer.py accessors.
        "enabled":                  True,
        "interval_minutes":         8,
        "cache_ttl_seconds":        600,
        "max_parallel_resolutions": 4,
    },
    # 2026-08-20 -- DECLARED, because the admin screen already writes them.
    #
    # `secrets` was the sharpest case in the product: PUT
    # /api/admin/vault-config PERSISTS a `secrets` block into config.json,
    # and validate_config() then reported "[secrets] unknown config section
    # (typo?)" -- the validator accusing the operator of a typo for output
    # the product itself wrote.  Verified by execution before this change.
    #
    # Values mirror the accessor fallbacks in this module, so declaring them
    # changes NO behaviour; it makes them discoverable, settable through the
    # documented path, and visible to the new unknown-key check.
    # FB-48 (2026-09-20) -- THIRTEEN keys REMOVED from this section:
    # vault_addr, vault_namespace, vault_token, vault_role_id,
    # vault_secret_id, vault_mount, vault_path_prefix, vault_verify_ssl,
    # vault_ca_file, vault_timeout_seconds, cache_max_entries, fail_open,
    # auth_method.  Not one had a reader, and the shape of the harm was
    # specific: an operator who filled in ``vault_addr`` configured
    # NOTHING and had every reason to think otherwise, because the
    # section beside it is live.  The resolver
    # (core/qs_credentials/resolver.py) takes the Vault addresses, role
    # names and URLs from the ``system_accounts`` ROW, per account --
    # which is the right place for them, since different accounts use
    # different Vault roles -- and its transport knobs from the env vars
    # named in core/qs_credentials/vault/*.  What remains below is
    # exactly the set _SecretsCfg exposes and PUT /api/admin/vault-config
    # writes.  They are listed in _REMOVED_KEYS so a config.json that
    # still carries one is told what happened and when, not accused of a
    # typo.
    "secrets": {
        "enabled":                 False,
        # 2026-11-05 (owner): a shared connection holds no typed secret; a private one may.
        "shared_connection_needs_vault": True,
        # 2026-08-20 CORRECTED: the accessor falls back to 900, and
        # declaring 300 SILENTLY CUT the vault credential cache TTL from
        # 15 minutes to 5 while the commit claimed nothing moved.
        "cache_ttl_seconds":       900,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "app_name":                  'querystudio',
        "cred_refresh_hours":        24,
        "daemon_force":              False,
        "disk_cache_enabled":        True,
        "disk_cache_key_env":        'QS_SECRETS_KEY',
        "disk_cache_path":           '/tmp/.qs_secrets.enc',
        "disk_cache_ttl_seconds":    86400,
        "legacy_ciphers":            False,
        "machine":                   'openshift',
        "timeout_seconds":           3.0,
        "token_method":              'JWT',
        "token_path":                '',
        "verify_ssl":                False,
    },
    # `admin_governance` is admin-settable AND enforced (api/deps.py, the
    # connections and data-grid routes) while being declared nowhere -- the
    # accessor fallbacks were the only source of truth for a set of rate
    # limits and per-user quotas.
    "admin_governance": {
        "rate_limit_admin":            120,
        # FB-48 (2026-09-20) -- NOW ENFORCED.  It had zero readers, which
        # meant an admin switching rate limiting OFF got rate limiting,
        # and that is the direction someone reaches mid-incident: it
        # failed to RELEASE.  Scope is the two GOVERNANCE limiters (query
        # execute, export); the admin_sensitive limiter in api/deps.py is
        # a security control, not a throttle, and is deliberately NOT
        # reachable from the governance screen.
        "rate_limit_enabled":          True,
        # 2026-08-20 CORRECTED: the accessor falls back to 20.  Declaring
        # 0 here read as "unlimited" to _enforce_user_quota
        # (`if cap <= 0: return`), so the per-user connection cap went
        # from 20 to UNLIMITED for every non-admin -- a governance
        # RELAXATION introduced by a change that claimed to be inert.
        "max_connections_per_user":    20,
        # FB-48 -- NOW ENFORCED, through the same per-user resource quota
        # chokepoint that already enforces connections/schedules/views.
        "max_saved_queries_per_user":  0,      # 0 = unlimited
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "audit_log_max_results":            1000,
        "daily_quota_admin":                0,
        "daily_quota_analyst":              1000,
        "daily_quota_cache_ttl_seconds":    60,
        "daily_quota_viewer":               200,
        "enabled":                          True,
        "export_formats_admin":             'csv,excel,json,pdf',
        "export_formats_analyst":           'csv,excel,json',
        "export_formats_viewer":            'csv',
        "export_rate_limit_per_minute":     10,
        "max_published_views_per_user":     20,
        "max_schedules_per_user":           10,
        "rate_limit_analyst":               60,
        "rate_limit_viewer":                30,
    },
    "published_api": {
        # 2026-08-20 -- DECLARED.  Read at helpers.py via an inline
        # get("published_api", "max_result_rows", 0) and declared nowhere, so
        # no admin route could set it and no reader could find it -- the same
        # ghost class fixed for three published_views keys the same day.
        # 0 = no cap (ships off).  When armed it truncates WITH disclosure
        # (truncated flag + truncation_cap + X-QueryStudio-Truncated header).
        #
        # PARQUET IS EXEMPT ON PURPOSE, and the reason is mechanical, not a
        # loophole: the parquet branch serves ``result["_page_table"]`` -- the
        # already-bounded PAGE -- not ``result["data"]``, which is what this
        # cap trims.  Removing the exemption would set truncated=true and the
        # header on a file that was never truncated, i.e. a FALSE disclosure,
        # which is worse than no disclosure.  Parquet is not unbounded: it is
        # bounded by max_limit (the page) and dataset_row_cap (the dataset),
        # both disclosed.
        "max_result_rows":             0,
        # config.py published-API accessor block.  NOTE: base_url is set in
        # config.json but read by NO code path today — deliberately absent here.
        "max_concurrent":  50,
        "default_timeout": 1800,
        "max_queue":       200,
    },
    "column_catalog": {
        # LOCAL COLUMN CATALOG (core/schema_catalog.py) — 2026-08-22
        # operator-reported "could not read any columns" fix.  Every knob
        # is read via schema_catalog._positive_int_knob: values <= 0 are
        # INVALID (no 0==unlimited folds) and fall back to these defaults
        # with a WARNING.
        #
        # Staleness is ADVISORY: columns older than this are served with
        # stale:true + timestamp, never refused.  A cap throttles; only a
        # correctness gate fails, and old columns are not a correctness
        # failure.
        "stale_after_seconds":        86400,
        # Background top-up (schema_catalog.topup_connection): at most
        # this many missing tables refreshed per run, and at most one run
        # per connection per min-interval.  Bounds the source load a
        # catalog miss can generate; the backfill script passes force=True
        # and its own bound.
        "topup_max_tables_per_run":   25,
        "topup_min_interval_seconds": 300,
        # Explicit POST /api/catalog/columns/refresh: per-table live-read
        # budget, and how many tables one call may name.
        "refresh_timeout_seconds":    30,
        "refresh_max_tables_per_call": 50,
    },
    "report_catalog": {
        # config.py report-catalog accessor block.
        "enabled":                     True,
        "certification_enabled":       True,
        "template_gallery_enabled":    True,
        "sharing_enabled":             True,
        "embed_enabled":               True,
        "max_shares_per_report":       10,
        "max_embed_tokens_per_report": 5,
        "share_default_expiry_hours":  720,
        "embed_default_expiry_days":   90,
        "template_categories": ["Sales", "Finance", "HR", "Operations",
                                "Marketing", "Custom"],
    },
    "row_security": {
        # config.py row-security accessor block.
        # 2026-09-26 (owner decision, F0 of docs/FABLE_BRIEF_2026_09_26.html):
        # ON by default, enforcement ``rewrite``.  A table with NO policy
        # authored on it behaves exactly as before (results and caches
        # identical; the cache key still folds the policy fingerprint so
        # authoring a policy later invalidates it).  A table WITH a grant
        # policy filters every principal; a policy set that cannot be read
        # fails CLOSED (the query is refused, never widened).  An unknown
        # ``default_mode`` also falls back to ``rewrite``, not audit_only.
        "enabled":                            True,
        "default_mode":                       "rewrite",
        "fail_open":                          False,
        "audit_retention_days":               30,
        "cache_resolver_seconds":             30,
        "lake_formation_sync_enabled":        False,
        "lake_formation_sync_interval_hours": 6,
        "materialize_views_enabled":          False,
        "max_filter_sql_chars":               4000,
        # FB-45 (2026-09-20) -- the class a row policy takes when authored
        # WITHOUT one.  permissive = grants union (Lake Formation, BI tools);
        # restrictive = ceilings intersect (Oracle VPD, SQL Server, and this
        # engine before FB-45); per_policy = every policy must declare.
        # Applied at authoring time and stored on the policy: changing this
        # later moves NO existing policy.  Policies that predate classes are
        # stamped restrictive at startup so an upgrade changes no result.
        "policy_composition":                 "permissive",
        # 2026-10-24 -- data entitlement by column
        # (core/row_security/entitlement.py).  The kill switch; the most
        # values ONE principal's filter may inline (more REFUSES, never
        # truncates); the most rows one upload may carry.
        "entitlement_enabled":                True,
        # 2026-10-25 -- who may SET a published API's or a feed's own
        # data-policy switch (entitlement_mode), pinning it against the
        # config default; "admin" = admin and super_admin.  Everyone else
        # gets the config default (published_views.default_data_policy_mode,
        # feed_generation.default_entitlement_mode).
        "data_policy_switch_roles":           ["admin"],
        "entitlement_inline_max_values":      1000,
        "entitlement_upload_max_rows":        100000,
    },
    "connection_validation": {
        # 2026-10-07 -- the login sweep's verdict cache
        # (core/connection_verdicts.py).  A sign-in no longer probes the
        # source of every visible connection: an ``ok`` is served for
        # ok_ttl_seconds; a failure is re-asked at a doubling backoff from
        # fail_backoff_seconds up to fail_backoff_max_seconds.  An explicit
        # Test always probes.
        "ok_ttl_seconds":            900,
        "fail_backoff_seconds":      60,
        "fail_backoff_max_seconds":  1800,
    },
    "user_drafts": {
        # config.py user-drafts accessor block.
        "enabled":                True,
        "retention_days":         30,
        "per_draft_max_mb":       5,
        "per_user_max_mb":        50,
        "cleanup_interval_hours": 24,
    },
    "writer_advisor": {
        # core/writer_advisor.py accessors.
        "cardinality_bucket_threshold":     10000,  # declared 2026-10-07, verbatim
        "default_bucket_count":             64,     # declared 2026-10-07, verbatim
        "enabled":                          True,
        "lookback_hours":                   168,
        "min_queries_for_recommendation":   5,
        "min_avg_files_for_recommendation": 200,
        "dismissal_ttl_days":               30,
        "auto_apply_enabled":               False,
        "auto_apply_min_leverage_pct":      80.0,
        "auto_apply_min_queries":           20,
        # Declared 2026-10-07 -- read through the section-bound wrapper
        # ``_cfg(key, fallback)`` -> ``_g("writer_advisor", ...)`` (an
        # ALIASED getter the guard did not admit).  Verbatim: 60.
        "auto_apply_cron_minutes":          60,
    },
    # ══════════════════════════════════════════════════════════════════
    # 2026-09-07 — EIGHT SECTIONS THAT WERE READ BUT NEVER DECLARED
    # ══════════════════════════════════════════════════════════════════
    #
    # A sweep of every ``config.get(section, key, default)`` call site found
    # 19 keys across 8 sections with NO ``_DEFAULTS`` entry at all — not a
    # misplaced key, a missing SECTION.  Three consequences, and only the
    # first is cosmetic:
    #
    #   * they are invisible to an operator reading _DEFAULTS or the file
    #     ``scripts/init_config.py`` generates from it;
    #   * ``validate_config()`` calls the section "unknown (typo?)" if the
    #     operator writes it into config.json anyway;
    #   * and ``QUERYSTUDIO_<SECTION>_<KEY>`` DOES NOTHING, because
    #     ``_apply_env`` only writes fields that already exist in the merged
    #     config.  That is the exact mechanism that made
    #     ``QUERYSTUDIO_APP_ENVIRONMENT`` inert on every pod.
    #
    # EVERY VALUE BELOW IS COPIED FROM ITS READ SITE'S OWN INLINE FALLBACK,
    # named in the comment beside it.  Nothing here is a judgement about
    # what the default OUGHT to be: declaring a ghost knob has twice
    # silently MOVED a live value in this repo (a vault cache TTL 900→300,
    # and ``max_connections_per_user`` 20→0, which ``_enforce_user_quota``
    # reads as UNLIMITED), and both times the mistake was writing the
    # sensible number instead of the one the code was already using.
    # tests/test_config_env_and_ghost_knobs_2026_09_07.py compares each
    # entry against the read site — the accessor with the key deleted where
    # there is one, the call site's AST literal where there is not — so the
    # two sources have to agree and neither is asserted against itself.
    # Measured: all 19 effective values identical before and after.

    "business_query_builder": {
        # core/config.py _BusinessQueryBuilderCfg accessors (Phase 130).
        "enabled":                   True,   # accessor :7932
        "max_tables_per_query":      10,     # accessor :7934
        "default_row_limit":         5000,   # accessor :7936
        "custom_abbreviations":      {},     # accessor :7939
        # FB-48 (2026-09-20): "custom_strip_prefixes" and "category_order"
        # REMOVED.  Both had an accessor and the accessor had no caller: the
        # BQB's naming and categorisation never consulted config, so a
        # prefix list or a category order set here did nothing at all.
        "custom_category_patterns":  {},     # accessor :7947
    },
    "clockwork": {
        # core/clockwork/notifier.py -- the alert NOTIFIER (2026-09-10).
        # ``clockwork_alerts`` rows are facts the dispatcher writes; this
        # daemon is what tells a person.  Deployment-level FALLBACK
        # recipients receive an alert on a job with no owner / owner group
        # (and every CRITICAL alert), so an unowned job's failure is never
        # dropped; comma-separated.  Empty + an unowned job = the ledger row
        # says ``unrouted`` and the log says so at ERROR, once.
        "notify_enabled":            True,
        "notify_poll_seconds":       60,
        "notify_fallback_emails":    "",
        "notify_fallback_usernames": "",
        # delivery attempts per alert identity before the ledger says
        # ``exhausted`` (a dead SMTP must not be retried forever)
        "notify_max_attempts":       5,
        # core/clockwork/silence.py -- the DEAD-POD half of the watchdog.
        # A Clockwork pod alarms about its OWN stalled tick loop; a pod that
        # DIED, or never started, raises nothing at all.  Only an outside
        # reader of ``clockwork_deployments.last_tick_at`` can see that, and
        # this is it.  0 disables the check (and says so at startup).
        "deployment_silent_seconds": 600,
        # ── Declared 2026-09-15 ─────────────────────────────────────
        # Read by production code, absent from _DEFAULTS: not settable by
        # environment variable, not generated into config.json, and shown on
        # no admin screen.  Every value here is TAKEN VERBATIM from the inline
        # fallback at its read site -- declaring a DIFFERENT value is the
        # 2026-08-20 P0 (a vault TTL 900->300, a quota 20->0 that read as
        # UNLIMITED), not a fix.  Equality is proved by snapshotting every
        # accessor and every resolved key before and after.
        "notify_allowed_email_domains":    '',
    },
    "dataflows": {
        # Read by core/daemon_registry.py and, for three of them, a SECOND
        # time by main.py:3922-3925 through ``_cfg.get("dataflows", {})``.
        # The two sites AGREE on all three fallbacks (30 / 8 / False) — the
        # duplication is worth knowing about but it is not a live defect.
        "scheduler_autostart":   False,  # daemon_registry :608, main :3925
        "scheduler_poll_seconds": 30,    # daemon_registry :617, main :3923
        "max_concurrent_runs":    8,     # daemon_registry :619, main :3924
        "sla_scan_seconds":       60,    # daemon_registry :554
        # api/dataflow_api.py:_run_starter (2026-09-10) -- the ONE machine
        # path into POST /api/dataflows/{name}/runs: Clockwork's qs_api
        # task calls it with X-API-Key.  Both must be set: the switch, and
        # the api_keys ids admitted.  An EMPTY list admits nobody (never
        # "any valid key", the feed trigger's legacy hole).
        "allow_external_triggers":     False,
        "external_trigger_api_key_ids": [],
        # api/dataflow_api.py:1748 — separation of duties on an approval
        # gate.  False = a requester may NOT approve their own gate.  It is
        # a CORRECTNESS gate, so the default fails rather than throttles;
        # declared here at that same value so a one-admin install can open
        # it deliberately from a manifest instead of not at all.
        "allow_self_approval":    False,
    },
    "iceberg_writer": {
        "enabled":         False,  # core/iceberg_writer.py :40
        "zorder_enabled":  False,  # core/zorder.py :132
    },
    "cancel_watcher": {
        # main.py:5045 — cross-pod cancel-flag poll interval.
        "poll_interval_seconds": 5,
    },
    "checkpoint": {
        # core/checkpoint.py:117.  Age past which ANOTHER pod's checkpoint
        # is presumed orphaned; must exceed the longest legitimate query
        # (SCHEDULED timeout is 7200s) or a slow job on a sibling pod is
        # marked failed underneath it.  9000 = that plus a margin.
        "foreign_stale_seconds": 9000,
        # 2026-10-29: every process stamps the runs it holds this often; a run
        # whose stamp has been silent heartbeat_stale_seconds (at least 3 beats)
        # is failed "the server restarted" -- rows without a stamp keep the
        # foreign_stale_seconds rule above.
        "heartbeat_seconds": 30,
        "heartbeat_stale_seconds": 150,
    },
    "query_pods": {
        # 2026-10-29 -- core/query_pods/: query pods by SIZE, scaled on the
        # runs each size holds.  ONE source for both scalers: env/<env>.yaml
        # `querystudio.query_pods` renders the query-pods chart's Deployments
        # and KEDA ScaledObjects AND this pod's config.json.
        # classes: {} = no query pods (the default; nothing is scaled).
        #   {"m": {"memory_gi": 16, "min": 2, "max": 6, "runs_per_pod": 4}}
        "classes": {},
        # keda = KEDA scales (QueryStudio watches and alerts; takes over a size
        # only when NOTHING owns it); builtin = QueryStudio scales.
        "scaler": "keda",
        # Deployment name = deployment_prefix + size (the chart's naming)
        "deployment_prefix": "querystudio-query-pods-",
        # "" = this pod's own namespace (in-cluster), else the kube context's
        "namespace": "",
        "tick_seconds": 60,
        # a size is shrunk only after its demand stayed lower this long
        # (KEDA: the HPA scale-down stabilization window -- the same value)
        "cooldown_seconds": 600,
        # runs waiting this long while KEDA keeps a size at its minimum = alert
        "wait_alert_seconds": 120,
        # 2026-10-31 -- the PRICE before a run and a pod's memory BUDGET
        # (core/query_pods/price.py, core/query_pods/budget.py; design §5.2 /
        # §5.3).  All read only while classes are configured.
        # history price = the plan's measured peak x this margin
        "price_safety_margin": 1.3,
        # no price is below this (MB)
        "min_price_mb": 256,
        # the price of a run nothing is known about (MB); 0 = the smallest
        # size's whole budget (one small pod to itself) -- never zero
        "unknown_price_mb": 0,
        # what a query pod keeps for its own process (MB): a size's budget for
        # runs = memory_gi - this, at pricing AND on the pod
        "pod_reserve_mb": 1024,
        # the pod's memory limit when the cgroup cannot be read (MB); 0 = read
        # the cgroup, else take the size's memory_gi
        "pod_memory_override_mb": 0,
        # 2026-10-31 (phase 2) -- WHERE A RUN GOES (design §5.1,
        # core/jobqueue/execute_bridge.py::decide_route).  A run priced under
        # this (MB) is SMALL: it runs where it does today (the API pod), no
        # queue hop.  0 = every priced run goes to a query pod.
        "small_run_mb": 512,
        # a query pod counts as alive while its heartbeat row is younger than
        # this (seconds; core/query_pods/presence.py)
        "pod_seen_within_seconds": 90,
        # a sized run queued this long (seconds) while NO pod of its size is
        # alive is failed with the reason -- never left to wait silently
        # (phase 3's scaler normally brings a pod up well inside this)
        "no_pod_fail_seconds": 600,
        # 2026-11-03 (phase 4, core/jobqueue/report_bridge.py) -- business
        # REPORT runs (POST .../execute-async) and report-backed PUBLISHED API
        # runs go to the query pods too.  False (the default) = they run where
        # they do today (the reports / published-api pod).  Read only while
        # classes are configured and queue mode is armed; WHERE a run goes is
        # the one decision above (small_run_mb = it stays in the pod).
        "reports_lane": False,
    },
    "query": {
        # api/execute_api.py:10928 — the outer submission budget.  0 = OFF,
        # which is the SHIPPED behaviour: it was a sync-blocking-regression
        # detector that false-tripped legitimate slow submissions into a
        # 504, and the inner per-operation timeouts still bound each step.
        # Set a positive number to re-arm the detector.
        "submission_budget_seconds": 0,
    },
    "report_usage": {
        # core/reports/usage_store.py:315.  0 or negative = keep forever.
        "retention_days": 180,
    },
    "sap": {
        # core/config.py _SapCfg :6941, enforced in
        # core/sap_passthrough.py ``_enforce_sap_url_safety``.
        #
        # SECURITY-RELEVANT, AND DECLARED AT WHAT IT ALREADY IS.  This is
        # the SAP-passthrough SSRF allow-list, and [] does NOT mean "allow
        # nothing" — ``_enforce_sap_url_safety`` returns early when the
        # list is empty, leaving only ``core.url_safety.validate_url_safety``
        # (which blocks cloud-metadata unconditionally and private/loopback
        # unless ``rest_api.allow_private_ips`` is true).  So on an on-prem
        # deployment that sets allow_private_ips, an empty list means any
        # reachable intranet host is a legal SAP target.
        #
        # That is a fail-open default and it is stated here so it can be
        # DECIDED, not so it can be changed as a side effect: the whole
        # point of this pass is that a declaration must not move a live
        # value, and tightening the default to a non-empty list here would
        # break every existing deployment's SAP passthrough at the next
        # restart.  The reason the key needed declaring at all is that
        # ``QUERYSTUDIO_SAP_ALLOWED_HOSTS`` was silently discarded — an
        # operator could not set the allow-list from a Deployment manifest,
        # which is precisely the mitigation this fail-open default assumes
        # they would apply.  It is now settable, as a comma-separated list
        # or a JSON array.
        "allowed_hosts": [],
    },
}


# 2026-07-15 fail-closed-auth flag.  True when an EXPECTED config.json was
# missing or unparseable, so the process is running on built-in DEFAULTS —
# which set auth.type='none' → guest-ADMIN.  A config that didn't reach the pod
# (ConfigMap not mounted, corrupt edit, wrong QUERYSTUDIO_CONFIG) must NOT
# silently become an open-admin deployment; the auth surfaces read this flag and
# fail CLOSED (force login) instead of granting guest.  Genuine local-dev
# quickstart (no config.json, not in a container) is NOT flagged — guest stays.
_config_load_failed = False


def _running_in_container() -> bool:
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


def config_load_failed() -> bool:
    """True when an EXPECTED config file was missing/unparseable so the process
    is on built-in defaults.  Auth fails CLOSED on this (no guest-admin)."""
    return _config_load_failed


#: A value an ENVIRONMENT must supply (2026-09-27, prod config deployment).
#: ``k8s/querystudioapi-helm/env/<env>.yaml`` ships it wherever a hostname,
#: an AD group or a URL is that environment's own data.  Three readers refuse
#: it, each at its own stage: the chart will not RENDER a config.json that
#: still carries it (``*/templates/_helpers.tpl``), ``scripts/
#: verify_prod_config.py`` will not PASS a profile derived from it, and this
#: loader treats a file that still carries it as NOT LOADED -- fail closed,
#: exactly like a parse error -- because a pod must never run on a config
#: whose author wrote "fill this in".  One spelling, three gates.
CONFIG_PLACEHOLDER = "__SET_PER_ENV__"

#: What ``_load_file`` last did, for the ONE startup line and for the
#: per-pod fact the checker asserts (``/health`` ``config`` and ``python -m
#: querystudio config show`` ``_source`` both read :func:`config_source`).
_config_source: dict = {
    "config_file": str(_CONFIG_FILE), "config_file_exists": False,
    "config_file_load_failed": False, "config_file_via": "default",
    "config_file_error": None, "config_file_sections": 0,
    "config_file_placeholders": [],
}


def placeholder_paths(node: Any, prefix: str = "") -> list:
    """Dotted paths of every leaf in *node* that IS :data:`CONFIG_PLACEHOLDER`
    (``section.key``; a list element as ``section.key[]``)."""
    found: list = []
    if isinstance(node, dict):
        for k, v in node.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            found.extend(placeholder_paths(v, p))
    elif isinstance(node, list):
        if any(isinstance(v, str) and v == CONFIG_PLACEHOLDER for v in node):
            found.append(f"{prefix}[]")
        for v in node:
            if isinstance(v, dict):
                found.extend(placeholder_paths(v, prefix))
    elif isinstance(node, str) and node == CONFIG_PLACEHOLDER:
        found.append(prefix)
    return found


def config_source() -> dict:
    """Which config FILE this process loaded and whether it loaded: the fact
    a deployment must be able to check per pod.  Same keys wherever it is
    shown -- the startup line, ``/health``, ``config show``'s ``_source``."""
    return dict(_config_source)


def log_config_source(log: Optional[logging.Logger] = None) -> str:
    """Emit the ONE line every pod logs at startup naming its config file.

    Import-time logging is exactly what nobody sees (the loader runs before
    ``main.py`` configures logging), so each entry point calls this once it
    has a logger.  ERROR when the file did not load, INFO otherwise; the
    text is returned so a caller can print it too."""
    s = _config_source
    line = (
        f"[config] file={s['config_file']} exists={s['config_file_exists']} "
        f"load_ok={not s['config_file_load_failed'] and s['config_file_exists']} "
        f"via={s['config_file_via']} sections={s['config_file_sections']}"
        + (f" error={s['config_file_error']}" if s["config_file_error"] else "")
    )
    (log or logger).log(logging.ERROR if s["config_file_load_failed"] else logging.INFO, line)
    return line


def _load_file() -> dict:
    global _config_load_failed, _config_source
    # Allow tests / container deployments to override the config file path
    env_override = os.environ.get("QUERYSTUDIO_CONFIG")
    file_to_load = Path(env_override) if env_override else _CONFIG_FILE
    src = {
        "config_file": str(file_to_load),
        "config_file_exists": file_to_load.exists(),
        "config_file_load_failed": False,
        "config_file_via": "env:QUERYSTUDIO_CONFIG" if env_override else "default",
        "config_file_error": None, "config_file_sections": 0,
        "config_file_placeholders": [],
    }
    _config_source = src
    if file_to_load.exists():
        try:
            with open(file_to_load, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            # Corrupt config must NOT silently fall back to defaults (auth.type
            # ='none' → guest-admin).  Mark failed so the auth surfaces fail closed.
            _config_load_failed = True
            src["config_file_load_failed"] = True
            src["config_file_error"] = f"{type(e).__name__}: {e}"
            logger.error(
                "Failed to parse %s: %s — config NOT applied; running on DEFAULTS "
                "and auth will FAIL CLOSED (no guest-admin).  Fix the file and "
                "restart.", file_to_load, e,
            )
            return {}
        holes = placeholder_paths(data) if isinstance(data, dict) else []
        if holes:
            # The environment's overlay still says "fill this in".  Running on
            # the rest of the file would be running on a config nobody
            # finished; fail closed like a parse error and NAME the keys.
            _config_load_failed = True
            src["config_file_load_failed"] = True
            src["config_file_placeholders"] = holes
            src["config_file_error"] = (
                f"placeholder {CONFIG_PLACEHOLDER} at {', '.join(holes)}")
            logger.error(
                "%s still carries the placeholder %s at %s — config NOT applied; "
                "running on DEFAULTS and auth will FAIL CLOSED (no guest-admin).  "
                "The environment must supply these values (env/<env>.yaml or the "
                "site override file).", file_to_load, CONFIG_PLACEHOLDER,
                ", ".join(holes),
            )
            return {}
        src["config_file_sections"] = len(data) if isinstance(data, dict) else 0
        logger.info("Loaded config from %s", file_to_load)
        return data
    # File not present.
    if env_override:
        # Operator explicitly pointed at a file that isn't there → broken deploy.
        _config_load_failed = True
        src["config_file_load_failed"] = True
        src["config_file_error"] = "QUERYSTUDIO_CONFIG names a file that does not exist"
        logger.error(
            "QUERYSTUDIO_CONFIG=%s does not exist — config NOT applied; running on "
            "DEFAULTS and auth will FAIL CLOSED (no guest-admin).", file_to_load,
        )
    elif _running_in_container():
        # Container with no mounted config.json → the ConfigMap almost certainly
        # isn't applied.  Fail closed rather than boot as an open-admin instance.
        _config_load_failed = True
        src["config_file_load_failed"] = True
        src["config_file_error"] = "no config file inside a container (ConfigMap not mounted?)"
        logger.error(
            "config.json not found at %s inside a container — ConfigMap not "
            "mounted?  Running on DEFAULTS; auth will FAIL CLOSED (no guest-admin).",
            _CONFIG_FILE,
        )
    # else: genuine local-dev quickstart, no config.json → defaults + guest OK.
    return {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (override wins).

    2026-08-20 -- DEEP copy, not shallow.  ``dict(base)`` copied only the top
    level, so every section the config FILE did not override kept a reference
    to the very same dict object inside ``_DEFAULTS`` -- 57 of 111 sections.
    A runtime ``config.set()`` (and every admin PUT that reaches it) then
    wrote THROUGH the merged view into the code defaults:

        _DEFAULTS['jobqueue']['__probe__']  before set(): <absent>
        _DEFAULTS['jobqueue']['__probe__']  after  set(): 'polluted'

    That destroys the only baseline the product has for "what does an
    UNCONFIGURED deployment do".  Everything that compares a file value
    against a code default -- the pruning-stage guards, the example-vs-
    defaults reasoning, reload() merging a file back over _DEFAULTS -- is
    measuring against a moving target once any set() has run, and an
    operator-set value survives being removed from the file.
    """
    import copy as _copy

    result = _copy.deepcopy(base)
    for k, v in override.items():
        if k.startswith("_comment"):
            continue
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


#: Env-var overlays this process REFUSED, as ``(env_var, section, field,
#: reason)``.  Rebuilt on every ``_apply_env`` call (import, ``reload()``,
#: ``set(..., None)``).  ``validate_config()`` reports it so a refusal
#: reaches the operator at startup rather than dying in a log line.
_env_rejections: tuple = ()


def env_var_target(cfg: dict, env_key: str,
                   prefix: str = "QUERYSTUDIO") -> Optional[tuple]:
    """``(section, field)`` in *cfg* that ``env_key`` overlays, or ``None``.

    THE one definition of "can this env var reach this config field".
    ``_apply_env`` resolves every ``os.environ`` key through it and
    ``env_var_names()`` inverts it, so the writer and every enumerator of
    the env surface (the test sandbox's ``deploy_env_vars_for`` is one)
    cannot drift apart: the enumerator only lists a name this resolver
    actually accepts.  Before this was factored out the sandbox carried a
    hand-reasoned COPY of the rule -- and its copy was wrong; see the
    container note in ``_coerce_env_value``.

    Multi-word section names (``rest_api``, ``query_engine``,
    ``s3_local_cache``, ...) are matched by the LONGEST section prefix
    present in *cfg*, not by splitting on the first underscore.

    2026-09-07 -- SHADOWED FIELDS.  This used to stop at the longest
    matching SECTION and return nothing when that section had no such
    field, which left three DECLARED fields permanently unreachable from
    the environment because a longer section name matched first:

        QUERYSTUDIO_COMPLETENESS_SENTINEL_AUDITED_FORCES_MODE
            -> section ``completeness_sentinel``, no such field -> dead,
               while ``completeness.sentinel_audited_forces_mode`` exists
        QUERYSTUDIO_INDUSTRIALIZATION_COST_ROUTING          (same shape)
        QUERYSTUDIO_INDUSTRIALIZATION_MATERIALIZED_ISLANDS  (same shape)

    The collision is structural, not a typo: ``industrialization.<flag>``
    is a master toggle and ``industrialization_<flag>.*`` is that flag's
    own section, so the two spellings keep colliding as flags are added.

    So the walk now CONTINUES to the next-longest section instead of
    giving up.  Measured over all 1191 derivable names BEFORE changing
    anything: 0 names are ambiguous, 0 names that resolve today change
    target, and exactly those 3 gain a resolution.  The change is purely
    ADDITIVE -- it cannot move a value, because every name that already
    resolves still resolves to the same field.

    Length still breaks a tie, exactly as before, so nothing that works
    today is re-pointed.  An ambiguity would have to be INTRODUCED by a
    future section name; that case is LOGGED rather than silently picked,
    because "which of two knobs did the operator mean" is not a question
    this function may answer quietly.
    """
    if not env_key.upper().startswith(prefix.upper() + "_"):
        return None
    tail = env_key[len(prefix) + 1:].lower()   # e.g. "rest_api_allow_private_ips"
    matches = []
    for cand in sorted(cfg.keys(), key=len, reverse=True):
        if tail == cand or tail.startswith(cand + "_"):
            field = tail[len(cand) + 1:] if tail != cand else ""
            body = cfg.get(cand)
            if field and isinstance(body, dict) and field in body:
                matches.append((cand, field))
    if not matches:
        return None
    if len(matches) > 1:
        logger.warning(
            "env var %s could denote %s -- taking the longest section "
            "(%s.%s) as it always has; rename one of the colliding "
            "sections, or set the key in config.json to be unambiguous.",
            env_key, matches, matches[0][0], matches[0][1])
    return matches[0]


def env_var_names(cfg: dict, *sections: str,
                  prefix: str = "QUERYSTUDIO") -> tuple:
    """Every ``QUERYSTUDIO_*`` name ``_apply_env`` will act on for *sections*.

    Named sections only, or all of *cfg* when none are named.  Each
    candidate is round-tripped through :func:`env_var_target`, so a field
    no env var can actually reach (shadowed by a longer section name that
    also matches) is NOT listed -- the list states what the resolver does,
    not what a naming convention suggests.
    """
    out = []
    for section in (sections or tuple(cfg.keys())):
        body = cfg.get(section)
        if not isinstance(body, dict):
            continue
        for field in body:
            name = f"{prefix}_{section}_{field}".upper()
            if env_var_target(cfg, name, prefix) == (section, field):
                out.append(name)
    return tuple(out)


def _coerce_env_value(original, raw: str):
    """Cast an env string to the type the DECLARATION promises.

    Returns ``(ok, value, reason)``.  ``ok=False`` means REFUSE: the
    declared value stays and the refusal is reported.

    2026-09-07 -- CONTAINERS.  The final ``else`` used to assign the raw
    string to any field that was not bool/int/float/list, so::

        QUERYSTUDIO_FEED_GENERATION_DELIVERY_SUPPRESSION={"all":["prod"]}

    made ``feed_generation.delivery_suppression`` a **str**.  Every
    consumer of that key is typed for a Mapping; the accessor's
    ``dict(v) if isinstance(v, dict) else {}`` turned the str into ``{}``,
    which is the "suppresses nothing" policy -- so an operator who
    suppressed PROD deliveries through the documented env route got the
    deliveries anyway, with no error anywhere.  33 dict-valued fields have
    that shape.

    PARSE, DO NOT REFUSE, and the choice is deliberate.  Refusing every
    dict-valued env var is defensible in isolation, but it would make 33
    declared fields unreachable from a Deployment manifest -- including
    ``pruning_health.alerts`` (webhook URLs), ``feed_generation.airflow``
    (a password) and ``spark_k8s.spark_conf``.  Those belong in a k8s
    Secret, and a Secret is env-shaped; forcing them into config.json is
    the worse deploy.  JSON is the only unambiguous text encoding for a
    nested mapping, and it is the SAME text the operator would write in
    config.json, so there is nothing new to learn.  What IS refused is a
    value that cannot BE the declared type -- refused loudly, leaving the
    declared value in place, because a consumer must never receive a type
    the declaration does not promise.

    Lists get the same treatment plus element typing: JSON first (so
    ``[6,7]`` works), comma-split otherwise (so the long-standing
    ``a,b,c`` spelling keeps working), then every element cast to the
    declared list's element type when that type is unambiguous.
    ``QUERYSTUDIO_FEED_GENERATION_DEFAULT_WEEKEND_DAYS=6,7`` used to
    produce ``["6", "7"]`` against a declaration of ``[6, 7]``, and the
    ISO weekday of a Saturday is never the string "6".

    ``None`` declarations are left as the raw string ON PURPOSE.  ``None``
    there means UNSET, not "of type NoneType" -- every reader of the six
    such fields normalises with ``int()`` / ``float()`` / ``str()`` around
    a ``None`` check, so a string is exactly what they are written for,
    and JSON-parsing them would move live values for no stated gain.
    """
    if isinstance(original, bool):
        return True, raw.lower() in ("1", "true", "yes"), ""
    if isinstance(original, int):
        try:
            return True, int(raw), ""
        except ValueError:
            return False, None, "not an integer"
    if isinstance(original, float):
        try:
            return True, float(raw), ""
        except ValueError:
            return False, None, "not a number"
    if isinstance(original, dict):
        try:
            parsed = json.loads(raw)
        except (ValueError, TypeError):
            return False, None, (
                "not JSON -- a dict-valued key must be given as a JSON "
                "object, e.g. {\"all\": [\"prod\"]}")
        if not isinstance(parsed, dict):
            return False, None, (
                f"JSON {type(parsed).__name__}, but this key is declared "
                f"as an object")
        return True, parsed, ""
    if isinstance(original, list):
        try:
            parsed = json.loads(raw)
        except (ValueError, TypeError):
            parsed = None
        items = parsed if isinstance(parsed, list) else [
            v.strip() for v in raw.split(",")]
        elem_types = {type(x) for x in original}
        if len(elem_types) == 1:
            (elem_t,) = elem_types
            if elem_t is bool:
                items = [v if isinstance(v, bool)
                         else str(v).strip().lower() in ("1", "true", "yes")
                         for v in items]
            elif elem_t in (int, float, str):
                try:
                    items = [elem_t(v) for v in items]
                except (ValueError, TypeError):
                    return False, None, (
                        f"not a list of {elem_t.__name__} values")
        return True, items, ""
    # str, None and anything else: the raw string, exactly as before.
    return True, raw, ""


def _apply_env(cfg: dict, prefix: str = "QUERYSTUDIO") -> dict:
    """
    Override config values from environment variables.

    Mapping:  QUERYSTUDIO_SERVER_PORT=9000  ->  cfg["server"]["port"] = 9000
              QUERYSTUDIO_PATHS_DATA_DIR=/mnt/data  ->  cfg["paths"]["data_dir"] = "/mnt/data"
              QUERYSTUDIO_REST_API_ALLOW_PRIVATE_IPS=true -> cfg["rest_api"]["allow_private_ips"]
              QUERYSTUDIO_FEED_GENERATION_DELIVERY_SUPPRESSION={"all":["prod"]}
                  -> cfg["feed_generation"]["delivery_suppression"] = {"all": ["prod"]}

    Which env var reaches which field is :func:`env_var_target`; how the
    string becomes the declared TYPE is :func:`_coerce_env_value`.  A
    value that cannot be the declared type is refused, left at the
    declared value, logged at ERROR and recorded in ``_env_rejections``
    for ``validate_config()`` to report at startup.

    Only fields that ALREADY EXIST in the merged config are writable --
    a key declared nowhere cannot be set from the environment at all.
    That is why ``QUERYSTUDIO_APP_ENVIRONMENT`` once did nothing, and it
    is why a ghost knob is a deploy defect and not only a doc gap.
    """
    global _env_rejections
    rejected = []
    for key, raw in os.environ.items():
        target = env_var_target(cfg, key, prefix)
        if target is None:
            continue
        section, field = target
        ok, value, reason = _coerce_env_value(cfg[section][field], raw)
        if not ok:
            rejected.append((key, section, field, reason))
            logger.error(
                "REFUSED env override %s=%r for %s.%s -- %s.  The declared "
                "value (%r) is unchanged; a consumer must never receive a "
                "type the declaration does not promise.",
                key, raw, section, field, reason, cfg[section][field])
            continue
        cfg[section][field] = value
    _env_rejections = tuple(rejected)
    return cfg


# ── Build the merged config once at import time ──────────────────────────────
_file_cfg = _load_file()
_merged   = _deep_merge(_DEFAULTS, _file_cfg)
_cfg      = _apply_env(_merged)


# ── Startup Validation ────────────────────────────────────────────────────────

#: FB-48 (2026-09-20) -- keys that WERE declared and are now gone, with the
#: reason.  A generated config.json on a deployed pod still carries them, and
#: the unknown-key check would otherwise accuse the operator of a typo for a
#: key this product itself wrote.  Keeping the record here means a removal is
#: explained at the only moment anyone asks: startup, naming the key.
_REMOVED_KEYS: dict[tuple[str, str], str] = {
    **{("feed_generation.airflow", k): (
        "removed 2026-10-08 (feed lane contract, ONE Airflow road): it named "
        "the staging S3 location of the conf-driven Airflow DAG run, a road "
        "that shipped no JDBC credentials and handed the native renderer a "
        "remote path.  The Airflow lane now dispatches the execution to the "
        "factory DAG, which submits it through POST /spark-submit; a job's "
        "output goes to its destination or to spark_k8s.artifact_bucket.  "
        "Delete it from config.json -- it configures nothing."
    ) for k in ("output_s3_bucket", "output_s3_prefix")},
    **{("secrets", k): (
        "removed 2026-09-20 (FB-48): nothing read it. Vault addresses, role "
        "names and URLs come from the system_accounts ROW (per account); the "
        "transport knobs come from the QS_VAULT_* env vars. Delete it from "
        "config.json -- it configured nothing."
    ) for k in (
        "vault_addr", "vault_namespace", "vault_token", "vault_role_id",
        "vault_secret_id", "vault_mount", "vault_path_prefix",
        "vault_verify_ssl", "vault_ca_file", "vault_timeout_seconds",
        "cache_max_entries", "fail_open", "auth_method",
    )},
    ("report_catalog", "embed_max_row_limit"): (
        "removed 2026-09-26 (FB-60): its only reader was the classic embed "
        "surface of the decommissioned parametric reports. A finance report's "
        "embed is capped by business_reports.embed_row_limit. Delete it from "
        "config.json -- it configures nothing."
    ),
    ("admin_governance", "daily_query_quota"): (
        "removed 2026-09-20 (FB-48): nothing read it, and the per-ROLE daily "
        "quota (daily_quota_admin/analyst/viewer) already answers this and IS "
        "enforced. Set the role quota instead."
    ),
    ("admin_governance", "daily_export_quota"): (
        "removed 2026-09-20 (FB-48): nothing read it, and it cannot be "
        "honestly enforced -- this product has no single export chokepoint "
        "(grid exports, the nine business-report download routes, published "
        "views, dataflows and feed delivery are separate paths). A cap that "
        "stops one of them is worse than none."
    ),
    ("admin_governance", "export_enabled"): (
        "removed 2026-09-20 (FB-48): nothing read it. To stop a role "
        "exporting, set its export_formats_<role> to an empty string -- that "
        "IS enforced, on the execution-grid path."
    ),
    ("admin_governance", "export_max_rows"): (
        "removed 2026-09-20 (FB-48): nothing read it. Same reason as "
        "daily_export_quota, plus a row cap on an export is a truncation and "
        "would need disclosure on every path that can produce a file."
    ),
    ("suggestion_corrections", "chart_feedback_enabled"): (
        "removed 2026-09-20 (FB-48): it gated a chart-preset like/dislike "
        "feature that does not exist -- no route, no table, no writer."
    ),
    ("suggestion_corrections", "pivot_feedback_enabled"): (
        "removed 2026-09-20 (FB-48): it gated a pivot-preset like/dislike "
        "feature that does not exist -- no route, no table, no writer."
    ),
    ("etl_pipelines", "airflow_dag_cache_ttl"): (
        "removed 2026-09-20 (FB-48): there is no DAG-list cache. "
        "AirflowClient.list_dags() calls GET /dags every time."
    ),
    ("industrialization_materialized_islands", "target_file_mb"): (
        "removed 2026-09-20 (FB-48): its own comment said 'informational' "
        "and it was -- the island compactor never read it."
    ),
    ("business_query_builder", "custom_strip_prefixes"): (
        "removed 2026-09-20 (FB-48): the accessor existed and had no caller "
        "-- the BQB's naming never consulted config."
    ),
    ("business_query_builder", "category_order"): (
        "removed 2026-09-20 (FB-48): the accessor existed and had no caller "
        "-- the BQB's categorisation never consulted config."
    ),
    ("admin_governance", "export_max_file_size_mb"): (
        "removed 2026-09-20 (FB-48): nothing read it -- the admin screen "
        "accepted it and discarded it. Same missing chokepoint as "
        "daily_export_quota; the control was removed with the key."
    ),
}


def validate_config() -> list[str]:
    """Validate critical config values on startup. Returns list of warnings/errors.

    Called by main.py at app init. Logs warnings for non-critical issues,
    raises on fatal misconfigurations.
    """
    issues: list[str] = []

    # ── Env overrides this process REFUSED ────────────────────────────
    # A refused overlay means the deployment ASKED for something and did
    # not get it.  It is reported here rather than only logged because a
    # log line at import time is exactly what nobody reads: the operator
    # who typed the var learns at startup, naming the var and the reason.
    for _ev, _sec, _fld, _why in _env_rejections:
        issues.append(
            f"[{_sec}.{_fld}] env override {_ev} REFUSED ({_why}) — the "
            f"declared value is in force; the deployment's value is NOT")

    def _check_type(section: str, key: str, expected: type, label: str = ""):
        val = _cfg.get(section, {}).get(key)
        if val is not None and not isinstance(val, expected):
            try:
                expected(val)  # try coercion
            except (ValueError, TypeError):
                issues.append(f"[{section}.{key}] expected {expected.__name__}, got {type(val).__name__}: {val!r}")

    def _check_range(section: str, key: str, lo: float = 0, hi: float = float('inf'), label: str = ""):
        val = _cfg.get(section, {}).get(key)
        if val is not None:
            try:
                n = float(val)
                if n < lo or n > hi:
                    issues.append(f"[{section}.{key}] value {val} out of range [{lo}, {hi}]")
            except (ValueError, TypeError):
                pass  # type check handles this

    def _check_enum(section: str, key: str, allowed: set, label: str = ""):
        val = _cfg.get(section, {}).get(key)
        if val is not None and val != "" and val not in allowed:
            issues.append(f"[{section}.{key}] value {val!r} not in {sorted(allowed)}")

    # ── Critical type/enum checks ──
    _check_enum("database", "type", {"sqlite", "postgresql", "oracle"})
    _check_enum("auth", "type", {"none", "ad", "local"})
    _check_enum("auth", "login_plaintext_fallback", {"allow", "refuse"})
    _check_enum("row_security", "policy_composition",
                {"permissive", "restrictive", "per_policy"})
    _check_enum("server", "log_level", {"debug", "info", "warning", "error", "critical"})
    _check_enum("server", "log_format", {"json", "text"})
    # 2026-10-03 -- only an exact "process" opts out of the shared limiter;
    # anything else is treated as "shared" and named here.
    _check_enum("queue", "rate_limit_store", {"shared", "process"})

    # ── 2026-07-15: LOUD auth-not-configured warning ──────────────────────────
    # A config.json that loads fine but is MISSING the auth section (or auth.type)
    # silently falls through to the default 'none' → every user becomes guest-ADMIN
    # with no login screen.  Before this, that produced ZERO logs — an operator
    # whose auth section didn't make it into the deployed config had no signal at
    # all (the DB still worked via env, masking it).  Make it impossible to miss:
    # warn loudly whenever auth resolves to 'none' WITHOUT being explicitly set in
    # the config FILE or via QUERYSTUDIO_AUTH_TYPE — that combination almost always
    # means a broken/incomplete config, not a deliberate no-auth deployment.
    try:
        _auth_type = str((_cfg.get("auth") or {}).get("type", "") or "").strip().lower()
        if not _auth_type:
            # 2026-10-18: unset is LOGIN REQUIRED (_AuthCfg.type), never guest admin
            logger.warning(
                "LOGIN REQUIRED but NOT CONFIGURED: auth.type is unset (missing from "
                "config.json AND QUERYSTUDIO_AUTH_TYPE is unset).  Nobody is let in "
                "anonymously; only the DB-backed super_admin can sign in until it is "
                "set.  Fix: QUERYSTUDIO_AUTH_TYPE=ad (+ QUERYSTUDIO_AUTH_AD_SERVER / "
                "AD_DOMAIN / AD_BASE_DN / AD_*_GROUPS) or auth.type=local + "
                "auth.local_users.  auth.type=none (every caller a guest ADMIN) only "
                "for a private dev machine, and only when set on purpose."
            )
            issues.append(
                "auth.type not configured (missing from file + env) -- login required, "
                "nobody can sign in but a super_admin; set QUERYSTUDIO_AUTH_TYPE"
            )
        elif _auth_type == "none":
            logger.warning("auth.type='none' SET ON PURPOSE -- NO LOGIN: every caller is a "
                           "guest ADMIN.  Never on a shared or production deployment.")
        else:
            logger.info("auth.type='%s' — login required.", _auth_type)
    except Exception as _auth_warn_exc:
        logger.debug("auth-config startup check skipped: %s", _auth_warn_exc)

    # ── Port/numeric range checks ──
    _check_range("server", "port", 1, 65535)
    _check_range("server", "workers", 1, 32)
    _check_range("server", "worker_healthcheck_timeout_seconds", 1, 600)
    _check_range("query_engine", "chunk_size", 1000, 10_000_000)
    _check_range("query_engine", "query_timeout_seconds", 0, 86400)
    _check_range("limits", "max_download_size_mb", 1, 100_000)
    _check_range("limits", "max_concurrent_queries", 1, 1000)
    _check_range("cache", "max_entries", 1, 100_000)
    _check_range("cache", "ttl_seconds", 0, 604_800)  # max 7 days
    _check_range("database", "postgresql_pool_size", 1, 200)
    _check_range("database", "postgresql_max_overflow", 0, 200)
    _check_range("database", "postgresql_pool_timeout", 1, 300)

    # ── Boolean type checks ──
    for section, key in [
        ("auth", "ad_use_ssl"), ("auth", "ad_tls_validate"),
        ("features", "enable_streaming"), ("features", "enable_cache"),
        ("lineage", "auto_extract"), ("lineage", "snapshots_enabled"),
        ("chatbot", "semantic_context_enabled"),
        ("local_llm", "enabled"),
        ("local_llm", "embedder_enabled"),
        ("local_llm", "sql_generation_enabled"),
        ("local_llm", "startup_preload"),
        ("local_llm", "finance_domain_hints"),
    ]:
        val = _cfg.get(section, {}).get(key)
        if val is not None and not isinstance(val, bool):
            if str(val).lower() not in ("true", "false", "0", "1"):
                issues.append(f"[{section}.{key}] expected boolean, got {type(val).__name__}: {val!r}")

    # ── Spark Connect: SSRF-safe server_url when feature is enabled ──
    _sc_cfg = _cfg.get("spark_connect", {})
    if _sc_cfg.get("enabled", False):
        _sc_url = _sc_cfg.get("server_url", "")
        if _sc_url:
            try:
                from core.url_safety import validate_url_safety as _sc_ssrf
                # sc:// scheme — validate the host portion by rewriting to http://
                # so the SSRF validator can resolve + check the IP.
                from urllib.parse import urlparse as _sc_urlparse
                _sc_parsed = _sc_urlparse(_sc_url)
                if _sc_parsed.hostname:
                    _sc_ssrf(f"http://{_sc_parsed.netloc or _sc_parsed.path}")
            except ValueError as _sc_ssrf_err:
                issues.append(
                    f"[spark_connect.server_url] SSRF risk: {_sc_ssrf_err}. "
                    "Set spark_connect.enabled=false or change server_url."
                )
            except Exception:
                pass  # DNS unavailable at startup — validate again on first use

    # ── Warn about unknown top-level sections ──
    known_sections = frozenset(_DEFAULTS.keys())
    for section in _cfg:
        if section not in known_sections:
            issues.append(f"[{section}] unknown config section (typo?)")

    # ── Warn about unknown KEYS inside a known section ──────────────────
    #
    # 2026-08-20 -- THE SECTION CHECK CAUGHT A TYPO'D SECTION AND NOTHING
    # ELSE.  Measured: `published_viewz` was reported, and
    # `published_views.max_row_limt` was accepted in silence -- persisted to
    # config.json, echoed back by the admin GET, and enforcing nothing.  That
    # is exactly the failure mode of the max_row_limit bug: an operator sets
    # a value, sees it saved, and the behaviour never changes.
    #
    # Several admin PUT routes accept a free-form `body: dict` into a section
    # with no whitelist, so a typo'd key is not hypothetical -- it is one
    # keystroke on an admin screen.
    #
    # Keys beginning with "_" are prose (_comment / _example) and are skipped.
    # A key that is genuinely live but undeclared is a GHOST, and this is
    # precisely how it becomes visible instead of staying folklore.
    for section, values in _cfg.items():
        if not isinstance(values, dict):
            continue
        declared = _DEFAULTS.get(section)
        if not isinstance(declared, dict):
            continue                      # unknown section already reported
        for key in values:
            if str(key).startswith("_"):
                continue
            if key not in declared:
                _why = _REMOVED_KEYS.get((section, str(key)))
                if _why:
                    issues.append(f"[{section}.{key}] {_why}")
                else:
                    issues.append(
                        f"[{section}.{key}] unknown config key (typo?) -- it is "
                        f"persisted and read by nothing, or it is a live knob "
                        f"missing from _DEFAULTS"
                    )

    # ── Production safety warnings (non-blocking) ──
    _cors_origins = _cfg.get("cors", {}).get("allow_origins", ["*"])
    _auth_type = _cfg.get("auth", {}).get("type", "none")
    if _cors_origins == ["*"] and _auth_type != "none":
        logger.warning(
            "Config: CORS allow_origins is ['*'] with auth enabled — "
            "restrict to specific domains in production"
        )

    # Multi-pod safety checks
    _replicas = 1
    try:
        _replicas = int(os.environ.get("QUERYSTUDIO_REPLICAS", "1"))
    except (ValueError, TypeError):
        pass
    if _replicas > 1:
        _db_type = _cfg.get("database", {}).get("type", "sqlite")
        _queue_backend = _cfg.get("queue", {}).get("backend", "database")
        if _db_type == "sqlite":
            logger.warning(
                "Config: database.type='sqlite' with %d replicas — "
                "SQLite WILL cause write contention and possible data corruption with multiple pods. "
                "Set database.type=postgresql and database.postgresql_url in config.json for multi-pod deployments.",
                _replicas,
            )
        if _queue_backend != "redis":
            logger.warning(
                "Config: queue.backend='%s' with %d replicas — "
                "rate limiting and task dedup are per-pod; consider Redis",
                _queue_backend, _replicas,
            )
        logger.info(
            "Config: %d replicas detected — in-memory caches are "
            "process-local (data may be duplicated across pods)",
            _replicas,
        )

    # ── 2026-08-09 cross-pod completion #4: Postgres is a HARD precondition
    # for the split-pod modes.  QUERYSTUDIO_REPORTS_MODE /
    # QUERYSTUDIO_PUBLISHED_API_MODE mean execution and retrieval genuinely
    # happen in different processes sharing ONE database — the exact
    # scenario the SQLite warning above describes (write contention, file
    # corruption), plus the cross-pod WS relay needs PG NOTIFY.  This is a
    # CORRECTNESS gate, not a resource cap, so it FAILS LOUDLY AT BOOT
    # (raise → startup aborts) instead of corrupting a database at 3am.
    # Single-pod SQLite dev (no mode env) is untouched.  Dev/CI smoke runs
    # of a split pod on SQLite must opt in EXPLICITLY via
    # QUERYSTUDIO_ALLOW_SQLITE_MULTIPOD=1, which downgrades the refusal to
    # an unmissable CRITICAL banner.
    _truthy = ("true", "1", "yes")
    _reports_mode = os.environ.get(
        "QUERYSTUDIO_REPORTS_MODE", "").lower() in _truthy
    _published_mode = os.environ.get(
        "QUERYSTUDIO_PUBLISHED_API_MODE", "").lower() in _truthy
    if _reports_mode or _published_mode:
        # Effective DB type: env override first (what the charts set),
        # then config.json — same resolution as core.config.database.type.
        _eff_db_type = (os.environ.get("QUERYSTUDIO_DATABASE_TYPE", "")
                        .strip().lower()
                        or str(_cfg.get("database", {}).get("type", "sqlite")).lower())
        if _eff_db_type == "sqlite":
            _mode_name = "reports" if _reports_mode else "published-api"
            _msg = (
                f"REFUSING TO START: QUERYSTUDIO_{'REPORTS' if _reports_mode else 'PUBLISHED_API'}"
                f"_MODE implies a multi-pod deployment (the {_mode_name} pod "
                "shares its database with at least the main API pod), but "
                "database.type is 'sqlite'. Multiple pods writing one SQLite "
                "file WILL corrupt it, and the cross-pod WS relay requires "
                "Postgres NOTIFY. Set database.type=postgresql (+ "
                "database.postgresql_url) or QUERYSTUDIO_DATABASE_TYPE="
                "postgresql. Dev/CI smoke runs may set "
                "QUERYSTUDIO_ALLOW_SQLITE_MULTIPOD=1 to downgrade this "
                "refusal to a CRITICAL warning."
            )
            if os.environ.get("QUERYSTUDIO_ALLOW_SQLITE_MULTIPOD",
                              "").lower() in _truthy:
                logger.critical(
                    "SQLite + %s pod mode allowed ONLY because "
                    "QUERYSTUDIO_ALLOW_SQLITE_MULTIPOD is set — NEVER run "
                    "this way in production: %s", _mode_name, _msg)
                issues.append(
                    f"[database.type] sqlite with {_mode_name} pod mode "
                    "(allowed by QUERYSTUDIO_ALLOW_SQLITE_MULTIPOD)")
            else:
                logger.critical(_msg)
                raise RuntimeError(_msg)

    # Log results
    for issue in issues:
        logger.warning("Config validation: %s", issue)

    if issues:
        logger.warning("Config validation found %d issue(s) — review config.json", len(issues))

    return issues


# ── Cross-pod runtime config overrides (2026-08-09 cross-pod completion #1) ──
#
# ``set()`` used to mutate ``_cfg`` in-process ONLY: an admin PUT landed on
# one pod and the API / reports / published-api pods disagreed on runtime
# caps until restart (documented un-fixed in 734a5675).  Now every ``set()``
# WRITES THROUGH to the ``system_settings`` table under the key
# ``config.{section}.{key}``, and ``get()`` consults a process-local overlay
# of those rows that is refreshed from the DB at most every
# ``_RUNTIME_OVERLAY_TTL_S`` seconds.
#
# Guarantees (documented, tested in tests/test_cross_pod_completion_2026_08_09.py):
#   * A cap written on pod A is visible on pod B within at most
#     ``_RUNTIME_OVERLAY_TTL_S`` (5 s) + one in-flight request.
#   * DB WRITE failure: the request does NOT fail — the value still applies
#     in-process (pre-change behaviour) and an ERROR log announces that other
#     pods keep the OLD value.  Never silent.
#   * DB READ failure: reads serve the last-loaded overlay + local config
#     (bounded staleness, fail-open) and an ERROR log (rate-limited to one
#     per 60 s) announces that this pod may be serving STALE caps.
#   * ``_db_manager_ref`` unset (unit tests / import time / standalone
#     tools): ``set()``/``get()`` behave exactly as before — in-process only.
#
# The DB namespace is prefixed ``config.`` so it cannot collide with the
# pre-existing ``_db_setting_or`` keys (``feed_generation.*`` etc.), which
# keep their own accessor-level semantics unchanged.
import time as _time_mod  # noqa: E402
import threading as _threading_mod  # noqa: E402

_db_manager_ref = None            # wired by init_db_settings() from main.py
_RUNTIME_OVERRIDE_PREFIX = "config."
_RUNTIME_OVERLAY_TTL_S = 5.0      # THE bounded cross-pod visibility interval
_OVERLAY_MISS = object()
_runtime_overlay: Dict[Any, Any] = {}          # {(section, key): value}
_runtime_overlay_loaded_monotonic: Optional[float] = None  # None = never loaded
_runtime_overlay_lock = _threading_mod.Lock()
_runtime_overlay_fail_logged_monotonic = 0.0


def _runtime_overlay_refresh_if_stale() -> None:
    """Reload the overlay from ``system_settings`` when older than
    ``_RUNTIME_OVERLAY_TTL_S``.  Non-blocking: concurrent callers (and
    re-entrant calls from inside the DB layer itself) serve the current
    overlay rather than waiting — the lock is only ever try-acquired."""
    now = _time_mod.monotonic()
    loaded = _runtime_overlay_loaded_monotonic
    if loaded is not None and (now - loaded) < _RUNTIME_OVERLAY_TTL_S:
        return
    if not _runtime_overlay_lock.acquire(blocking=False):
        return  # another thread (or this one, re-entrantly) is refreshing
    # 2026-10-07: a caller ON THE EVENT LOOP never runs the DB read itself --
    # any config.get() past the 5 s mark did, inline, and under load a pool
    # checkout there stalls every request on the pod (measured in-process).
    # Once an overlay has been loaded, the loop serves it and the refresh
    # runs on the ``config`` lane; the lock (taken above) is released there.
    # The very first load stays synchronous: there is nothing to serve yet.
    if loaded is not None and _on_event_loop_thread():
        try:
            from core.interactive_lanes import submit_to_lane
            submit_to_lane("config", _runtime_overlay_refresh_locked, now)
            return
        except Exception:
            pass                       # no lane: refresh inline, as before
    _runtime_overlay_refresh_locked(now)


def _on_event_loop_thread() -> bool:
    try:
        import asyncio as _asyncio_mod
        return _asyncio_mod._get_running_loop() is not None
    except Exception:
        return False


def _runtime_overlay_refresh_locked(now: float) -> None:
    """The DB read of :func:`_runtime_overlay_refresh_if_stale`; the caller
    holds ``_runtime_overlay_lock`` and this releases it."""
    global _runtime_overlay, _runtime_overlay_loaded_monotonic, \
        _runtime_overlay_fail_logged_monotonic
    try:
        rows = _db_manager_ref.list_system_settings(
            prefix=_RUNTIME_OVERRIDE_PREFIX)
        fresh: Dict[Any, Any] = {}
        for r in rows or []:
            k = (r.get("key") or "")[len(_RUNTIME_OVERRIDE_PREFIX):]
            sec, _, kk = k.partition(".")
            if sec and kk:
                fresh[(sec, kk)] = r.get("value")
        _runtime_overlay = fresh
        _runtime_overlay_loaded_monotonic = _time_mod.monotonic()
    except Exception as exc:
        # Fail-open for READS (keep serving the last overlay + local config)
        # but NEVER silently: a pod serving stale caps must be visible.
        # Stamp loaded_monotonic so a down DB is retried once per TTL, not
        # on every get().
        _runtime_overlay_loaded_monotonic = _time_mod.monotonic()
        if (now - _runtime_overlay_fail_logged_monotonic) > 60.0:
            _runtime_overlay_fail_logged_monotonic = now
            logger.error(
                "Runtime-config overlay refresh FAILED — this pod may serve "
                "STALE admin caps (writes from other pods invisible until "
                "the DB recovers): %s", exc)
    finally:
        _runtime_overlay_lock.release()


def _runtime_overlay_lookup(section: str, key: str) -> Any:
    """Return the cross-pod override for (section, key), or
    ``_OVERLAY_MISS``.  A stored JSON null means 'no override'."""
    _runtime_overlay_refresh_if_stale()
    val = _runtime_overlay.get((section, key), _OVERLAY_MISS)
    if val is None:
        return _OVERLAY_MISS
    return val


def get(section: str, key: str, fallback: Any = None) -> Any:
    """Return a config value. Falls back to `fallback` if not found.

    2026-08-09: when the DB-backed runtime settings are wired
    (``init_db_settings``), values persisted by ``set()`` on ANY pod are
    consulted first (bounded staleness — see the overlay block above)."""
    if _db_manager_ref is not None:
        ov = _runtime_overlay_lookup(section, key)
        if ov is not _OVERLAY_MISS:
            return ov
    return _cfg.get(section, {}).get(key, fallback)


#: Where :func:`deploy_environment` looks, in order.  CONFIG BEFORE ENV
#: VARS on purpose: ``$ENVIRONMENT`` is a generic name that base images,
#: CI runners and shells set for their own reasons, and an inherited one
#: silently relabelling every production alert is exactly the
#: FOREIGN-BUT-PRESENT failure this codebase has already paid for.  An
#: explicit config value must win over an ambient one.
_DEPLOY_ENV_CONFIG_KEYS = (("app", "environment"),
                           ("app", "env"),
                           ("deployment", "environment"))
#: Raw process env vars, consulted last.  ``QUERYSTUDIO_APP_ENVIRONMENT``
#: is NOT listed here — it reaches this resolver through the normal
#: ``_apply_env`` path as ``app.environment``, which is the declared route.
_DEPLOY_ENV_VARS = ("QUERYSTUDIO_ENV", "ENVIRONMENT")


def deploy_environment_signals() -> tuple[tuple[str, str], ...]:
    """EVERY source that declares an environment, in precedence order.

    ``((value, source), ...)``; empty when nothing declares one.  This is
    THE enumeration of where a deployment's environment can come from.
    :func:`deploy_environment_source` takes the first entry — "which label
    wins" — and a security gate asks a DIFFERENT question of the same list
    ("does any source say production": see
    ``core.row_security.api.deployment_is_production``).

    Two questions, one enumeration, on purpose.  A fifth hand-copy of this
    list is exactly what left the RLS fail-open switch armed in production
    on a deployment that declared PROD only through ``$ENVIRONMENT``
    (2026-09-07): the copy consulted the three config keys and not the two
    env vars, so the gate and the resolver disagreed about the same fact.
    A caller needing a different PREDICATE must never need a different
    LIST.

    Never raises: alerting must never delay or fail a feed, so an
    unreadable config contributes no signal rather than an exception.
    """
    signals: list[tuple[str, str]] = []
    for section, key in _DEPLOY_ENV_CONFIG_KEYS:
        try:
            val = get(section, key, "")
        except Exception:                      # noqa: BLE001
            val = ""
        if not isinstance(val, str):
            val = str(val) if val else ""
        if val.strip():
            signals.append((val.strip(), f"config:{section}.{key}"))
    for var in _DEPLOY_ENV_VARS:
        raw = os.environ.get(var) or ""
        if raw.strip():
            signals.append((raw.strip(), f"env:{var}"))
    return tuple(signals)


def deploy_environment_source() -> tuple[str, str]:
    """The deployment's environment name AND where it came from.

    Returns ``("", "unset")`` when nothing declares one.  The SOURCE is
    returned, not just the value, because "which env does this pod think
    it is, and why" is the question an operator actually has when a pod
    sitting in PROD reports UAT — and answering it by reading precedence
    rules off a wiki is how a misconfiguration survives.

    The precedence — config BEFORE the ambient env vars — is a LABELLING
    decision and is deliberately not the right rule for every consumer;
    see :func:`deploy_environment_signals`.

    Never raises: alerting must never delay or fail a feed, so an
    unreadable config yields ``("", "unset")`` — which every caller
    treats as a stated refusal, never as a licence to guess.
    """
    signals = deploy_environment_signals()
    return signals[0] if signals else ("", "unset")


def deploy_environment() -> str:
    """Which environment THIS deployment is (e.g. ``UAT``, ``PROD``).

    THE one resolver — four hand-copied versions of this lookup existed
    before 2026-09-07, and a decision made four times is free to give four
    answers.  Empty when nothing declares one: an invented name keys every
    alert under a Node nobody routes, which is worse than no alert because
    it looks like the integration is working.

    NOT validated against an allow-list.  The environment vocabulary is the
    deployment's to choose (it changed from "DEV/PROD" to "UAT/PROD" inside
    one conversation); a set baked into code would refuse the site's real
    name and turn a naming difference into an alerting outage.
    """
    return deploy_environment_source()[0]


def iceberg_file_stats_grain() -> str:
    """2026-07-13 — CANONICAL accessor for the column-stats storage grain
    ('v2' | 'both' | 'v3').  Single source of truth so a writer and a reader
    can never split-brain on divergent hardcoded fallbacks: every component
    (scanner, db-first brain, read chokepoint, freshness, prefetch, admin)
    resolves the grain through THIS function.  Fallback is the current
    default ('v3') so a config-read hiccup can't silently downgrade one
    component to v2 while another stays v3."""
    try:
        return str(get("iceberg", "file_stats_grain", "v3") or "v3").lower()
    except Exception:
        return "v3"


_SECTION_MISS = object()  # sentinel: distinguishes "section absent" from falsy


def get_section(section: str, fallback: Any = None) -> Any:
    """BF-275: return the full value for a config section.

    Useful when the section IS the value (e.g. ``iceberg_sort_orders`` is
    a dict of ``{table_name: [cols]}`` — the whole dict is what callers
    want, not individual keys).  Returns ``fallback`` (default ``None``)
    if the section is missing.

    2026-08-20: returns a DEEP COPY, never the live ``_cfg`` sub-object.
    Handing out the live reference meant any caller mutation wrote through
    into the process-wide config (same aliasing class as the `_deep_merge`
    shallow-copy fixed for ``_DEFAULTS``; one caller —
    multi_worker_dispatcher's auto_throttle override — actually did mutate
    it in place).  Measured cost on the largest real section (``chatbot``,
    ~3.2KB): ~32µs per call vs ~0.04µs for the raw reference; every call
    site is per-query / per-tick, not per-row, so correctness wins.
    The ``fallback`` is returned AS-IS (it is the caller's own object,
    not part of ``_cfg`` — copying it would break sentinel identity checks).

    2026-09-27: consults the cross-pod DB overlay like ``get()`` does.  It
    used to read ``_cfg`` alone, so a section-shaped reader
    (``engine_router``, ``result_cache``, ``multi_pod`` -- and the admin
    GET routes for those sections) saw an admin's write only on the pod
    that took it; every other pod served the file value until restart.
    The overlay rows for the section are laid over the file+env copy,
    and a section that exists ONLY in the overlay is returned from it.
    """
    val = _cfg.get(section, _SECTION_MISS)
    if isinstance(val, (dict, list)):
        val = _copy_mod.deepcopy(val)
    if _db_manager_ref is not None:
        _runtime_overlay_refresh_if_stale()
        overlay = {k: v for (s, k), v in _runtime_overlay.items()
                   if s == section and v is not None}
        if overlay:
            if val is _SECTION_MISS or not isinstance(val, dict):
                val = {}
            val.update(overlay)
    if val is _SECTION_MISS:
        return fallback
    return val


#: What ``set()`` reports about where the value now lives.
SET_PERSISTED_DB = "db"                 # system_settings row written: every pod converges
SET_IN_PROCESS_ONLY = "in_process"      # no DB wired (unit tests / standalone tools)
SET_DB_WRITE_FAILED = "db_write_failed"  # applied here, NOT persisted: other pods keep the old value


def set(section: str, key: str, value: Any) -> str:  # noqa: A001
    """Set a runtime config value.

    Never persisted to config.json.  2026-08-09 (cross-pod completion #1):
    when the DB is wired via ``init_db_settings``, the value is ALSO written
    through to ``system_settings`` under ``config.{section}.{key}`` so every
    pod converges on it within ``_RUNTIME_OVERLAY_TTL_S`` seconds (see the
    overlay block above ``get()``).  ``value=None`` deletes the override
    (restores the config.json/default value everywhere).

    A DB write failure never fails the caller's request — the value still
    applies in-process — but it is logged at ERROR because the other pods
    will keep the OLD value (visible, never silent)."""
    try:
        _old = _copy_mod.deepcopy(get(section, key))
    except Exception:                                   # noqa: BLE001 -- the audit then says unknown
        _old = "<unreadable>"
    result = _set(section, key, value)
    _audit_change(section, key, _old, value, result)
    return result


def _audit_change(section: str, key: str, old: Any, new: Any, result: str) -> None:
    """2026-10-13 -- the owner: "who modified config when?".  EVERY runtime
    change (41 admin routes reach config through ``set``) leaves one audit row:
    who (the signed-in user of the request, else ``system``), the key, the
    value before and after (a secret is never written: ``***``) and whether
    every pod got it.  Never fails the change."""
    if _db_manager_ref is None or old == new:
        return
    try:
        from core.crypto import SENSITIVE_FIELDS
        from core.user_context import get_current_username
        secret = key in SENSITIVE_FIELDS

        def _shown(v):
            return "***" if secret and v not in (None, "") else v
        _db_manager_ref.audit(get_current_username() or "system", "config_change",
                              resource_type="config", resource_id=f"{section}.{key}",
                              details={"section": section, "key": key, "from": _shown(old),
                                       "to": _shown(new), "applied": result})
    except Exception as exc:                            # noqa: BLE001 -- an audit never blocks
        logger.warning("config.set(%s.%s): audit row not written: %s", section, key, exc)


def _set(section: str, key: str, value: Any) -> str:
    if value is None:
        # 2026-09-02 — value=None DELETES the override, in-process too.
        # This branch used to delete only the DB row while STORING a
        # literal None locally, so get() returned None instead of the
        # fallback and str-typed accessors read the string "None" — the
        # pod that cleared an override was the one pod it stayed broken
        # on.  Restore the pristine defaults+config.json+env value by
        # recomputing the merge (deletes are rare admin actions; the
        # recompute cost is irrelevant).
        pristine = _apply_env(_deep_merge(_DEFAULTS, _file_cfg))
        pristine_section = pristine.get(section)
        if isinstance(_cfg.get(section), dict):
            if isinstance(pristine_section, dict) and key in pristine_section:
                _cfg[section][key] = pristine_section[key]
            else:
                _cfg[section].pop(key, None)
    else:
        if section not in _cfg:
            _cfg[section] = {}
        _cfg[section][key] = value
    if _db_manager_ref is None:
        # unit tests / standalone tools — in-process only, as before
        return SET_IN_PROCESS_ONLY
    db_key = f"{_RUNTIME_OVERRIDE_PREFIX}{section}.{key}"
    try:
        if value is None:
            _db_manager_ref.delete_system_setting(db_key)
            _runtime_overlay.pop((section, key), None)
        else:
            _db_manager_ref.set_system_setting(
                db_key, value,
                description="runtime config override (config.set write-through)")
            # Immediate local visibility — do not wait for the next refresh.
            _runtime_overlay[(section, key)] = value
        return SET_PERSISTED_DB
    except Exception as exc:
        # Drop any stale overlay entry so local reads fall back to the
        # in-process value we just applied above.
        _runtime_overlay.pop((section, key), None)
        logger.error(
            "config.set(%s.%s) applied IN-PROCESS but was NOT persisted to "
            "system_settings — other pods keep the OLD value until the write "
            "succeeds or they restart: %s", section, key, exc)
        return SET_DB_WRITE_FAILED


# ── DB-backed runtime settings (Phase 130 hotfix-13) ────────────────
#
# Some config knobs must be admin-tunable AT RUNTIME from the UI and
# must survive pod restarts (and apply across multi-pod deployments).
# Those are stored in the ``system_settings`` DB table and read here
# via ``_db_setting_or()`` — which checks the DB first, falls back
# to the static config.json value when the DB has no row.
#
# Short-TTL in-process cache (default 5 s) keeps the per-feed-execution
# overhead negligible while still picking up admin changes promptly.
# (``_time_mod`` and ``_db_manager_ref`` now live above ``get()`` — shared
# with the cross-pod runtime overlay.)

_db_setting_cache: Dict[str, Any] = {}
_db_setting_cache_expiry: Dict[str, float] = {}
_DB_SETTING_TTL_S = 5.0


def init_db_settings(db_manager) -> None:
    """Called from main.py at startup to wire the DB manager so the
    runtime-settings accessors can read from ``system_settings``.
    Safe to call multiple times — last write wins."""
    global _db_manager_ref, _runtime_overlay, _runtime_overlay_loaded_monotonic
    _db_manager_ref = db_manager
    _db_setting_cache.clear()
    _db_setting_cache_expiry.clear()
    # Cross-pod runtime overlay: force a fresh load from the (possibly new)
    # DB on the next get().
    _runtime_overlay = {}
    _runtime_overlay_loaded_monotonic = None


#: Cache marker for "the DB has no row for this key".
_DB_SETTING_ABSENT = object()


def _db_setting_or(key: str, fallback: Any) -> Any:
    """Return the DB-persisted value for ``key`` if present, else
    ``fallback``.  Caches each lookup for ``_DB_SETTING_TTL_S`` seconds.
    Fails open: any exception (DB unavailable / migration not yet run)
    returns the fallback so the engine never breaks because the runtime
    settings table is missing."""
    if _db_manager_ref is None:
        return fallback
    now = _time_mod.monotonic()
    expiry = _db_setting_cache_expiry.get(key, 0.0)
    if now < expiry and key in _db_setting_cache:
        cached = _db_setting_cache[key]
        return fallback if cached is _DB_SETTING_ABSENT else cached
    # 2026-10-07: an EXPIRED entry asked for ON THE EVENT LOOP is served as
    # it stands while the lane re-reads it (measured in-process:
    # ``roles.support_role_name`` re-read its row inline on the loop).  A key
    # never read (or just invalidated by an admin write) is still read
    # inline -- there is nothing to serve, and an admin write must show.
    if key in _db_setting_cache and _on_event_loop_thread():
        _db_setting_refresh_soon(key)
        cached = _db_setting_cache[key]
        return fallback if cached is _DB_SETTING_ABSENT else cached
    try:
        val = _db_manager_ref.get_system_setting(key, default=None)
    except Exception:
        # Don't poison the cache on transient failures.
        return fallback
    # Cache what the DB SAID -- including "no row" -- never the caller's
    # fallback: callers pass different fallbacks for one key (a declared
    # config value, a literal), and caching the first one served it to
    # every other caller for the TTL (2026-09-27).
    _db_setting_cache[key] = _DB_SETTING_ABSENT if val is None else val
    _db_setting_cache_expiry[key] = now + _DB_SETTING_TTL_S
    return fallback if val is None else val


#: keys with a refresh in flight (a dict: this module's own ``set`` is the
#: config writer, not the builtin)
_db_setting_refreshing: Dict[str, bool] = {}
_db_setting_refresh_lock = _threading_mod.Lock()


def _db_setting_refresh_soon(key: str) -> None:
    """Re-read ``key`` on the ``config`` lane, at most one read per key in
    flight.  A failed read keeps the cached value (fail-open, as above)."""
    with _db_setting_refresh_lock:
        if key in _db_setting_refreshing:
            return
        _db_setting_refreshing[key] = True

    def _refresh() -> None:
        try:
            val = _db_manager_ref.get_system_setting(key, default=None)
            _db_setting_cache[key] = _DB_SETTING_ABSENT if val is None else val
            _db_setting_cache_expiry[key] = _time_mod.monotonic() + _DB_SETTING_TTL_S
        except Exception:
            pass
        finally:
            with _db_setting_refresh_lock:
                _db_setting_refreshing.pop(key, None)

    try:
        from core.interactive_lanes import submit_to_lane
        submit_to_lane("config", _refresh)
    except Exception:
        with _db_setting_refresh_lock:
            _db_setting_refreshing.pop(key, None)


def drop_db_setting(key: str) -> None:
    """For a DECISION GATE that reads ``key`` once per run: drop the cached copy,
    fresh or expired, so the read that follows fetches the row.  An admin's change
    happens on another pod, and no copy here can know it.  2026-11-02: an EXPIRED
    copy was served on the event loop, so every run saw the value from before the
    last change.  2026-11-05 (release-check, spark_pods_proof S5): a copy read by
    the previous run less than the TTL ago beat the change too, and a feed went to
    a Spark pod after native_only had answered 200.  Cost: one primary-key read per run."""
    _db_setting_cache.pop(key, None)
    _db_setting_cache_expiry.pop(key, None)


def invalidate_db_setting_cache(key: Optional[str] = None) -> None:
    """Drop one cache entry (or all of them) so the next read fetches
    fresh.  Called by the admin update endpoint right after a write
    so the new value is observable immediately."""
    global _runtime_overlay_loaded_monotonic
    # Cross-pod runtime overlay refreshes on the next get() as well.
    _runtime_overlay_loaded_monotonic = None
    if key is None:
        _db_setting_cache.clear()
        _db_setting_cache_expiry.clear()
        return
    _db_setting_cache.pop(key, None)
    _db_setting_cache_expiry.pop(key, None)


# ── Convenience accessors ─────────────────────────────────────────────────────

class _ServerCfg:
    host:       str = property(lambda self: get("server", "host"))        # type: ignore[assignment]
    port:       int = property(lambda self: get("server", "port"))        # type: ignore[assignment]
    log_level:  str = property(lambda self: get("server", "log_level"))   # type: ignore[assignment]
    log_format:    str = property(lambda self: get("server", "log_format", "json"))    # type: ignore[assignment]
    log_file:          str = property(lambda self: str(get("server", "log_file", "")))           # type: ignore[assignment]
    log_retention_days: int = property(lambda self: int(get("server", "log_retention_days") or 14)) # type: ignore[assignment]
    # BF-574: ``or 25`` guards against ``"log_max_mb": null`` in config.json
    # which would otherwise raise ``TypeError: int(None)`` and silently
    # disable file logging via the main.py except branch.
    log_max_mb:        int = property(lambda self: int(get("server", "log_max_mb") or 25))         # type: ignore[assignment]
    log_compress:      bool = property(lambda self: bool(get("server", "log_compress", True) if get("server", "log_compress", True) is not None else True))   # type: ignore[assignment]
    shutdown_drain_seconds: int = property(lambda self: int(get("server", "shutdown_drain_seconds", 25)))  # type: ignore[assignment]
    log_async:     bool = property(lambda self: get("server", "log_async", True) is not False)  # type: ignore[assignment]
    otel_endpoint: str = property(lambda self: get("server", "otel_endpoint", ""))    # type: ignore[assignment]
    workers:       int = property(lambda self: get("server", "workers"))               # type: ignore[assignment]
    # 2026-10-10: the uvicorn supervisor's patience with a silent worker (see _DEFAULTS).
    worker_healthcheck_timeout_seconds: int = property(lambda self: int(get("server", "worker_healthcheck_timeout_seconds", 30) or 30))  # type: ignore[assignment]
    ssl_certfile:         str  = property(lambda self: str(get("server", "ssl_certfile", "")))          # type: ignore[assignment]
    ssl_keyfile:          str  = property(lambda self: str(get("server", "ssl_keyfile", "")))           # type: ignore[assignment]
    ssl_keyfile_password: str  = property(lambda self: str(get("server", "ssl_keyfile_password", "")))  # type: ignore[assignment]
    https_redirect:       bool = property(lambda self: bool(get("server", "https_redirect", False)))    # type: ignore[assignment]
    # 2026-09-29: the proxies whose X-Forwarded-* uvicorn believes (see _DEFAULTS).
    forwarded_allow_ips:  str  = property(lambda self: str(get("server", "forwarded_allow_ips", "127.0.0.1")))  # type: ignore[assignment]

_HERE = Path(__file__).resolve().parent.parent  # backend/


def _resolve(rel: str) -> Path:
    """Resolve a path that may be relative (to backend/) or absolute."""
    p = Path(rel)
    return p if p.is_absolute() else (_HERE / p)


class _PathsCfg:
    @property
    def data_dir(self)        -> Path: return _resolve(get("paths", "data_dir"))
    @property
    def parquet_dir(self)     -> Path: return _resolve(get("paths", "parquet_dir"))
    @property
    def downloads_dir(self)   -> Path: return _resolve(get("paths", "downloads_dir"))
    @property
    def db_file(self)         -> Path: return _resolve(get("paths", "db_file"))
    @property
    def secret_key_file(self) -> Path: return _resolve(get("paths", "secret_key_file"))
    @property
    def upload_dir(self)      -> Path: return _resolve(get("paths", "upload_dir"))
    @property
    def duckdb_temp_dir(self) -> Path: return _resolve(get("paths", "duckdb_temp_dir"))
    @property
    def duckdb_extension_dir(self) -> Path: return _resolve(get("paths", "duckdb_extension_dir"))
    @property
    def download_temp_dir(self) -> Path: return _resolve(get("paths", "download_temp_dir"))
    @property
    def db_url(self)          -> str:
        return "sqlite:///" + self.db_file.as_posix()


class _QueryEngineCfg:
    @property
    def chunk_size(self)  -> int: return int(get("query_engine", "chunk_size"))
    @property
    def max_workers(self) -> int:
        w = int(get("query_engine", "max_workers"))
        return w if w > 0 else min(32, (os.cpu_count() or 4) + 4)
    @property
    def query_timeout_seconds(self) -> int:
        return int(get("query_engine", "query_timeout_seconds", 1800))
    @property
    def max_concurrent_per_user(self) -> int:
        # BF-584 (2026-05-29): 10 → 50
        # BF-600-M5 (2026-05-31): 50 → 5.  Pruning-audit cross-cut: 100
        # concurrent users × 50 = 5000 in-flight queries was the worst-
        # case scenario behind the 100-user OOM concern in
        # openshift-scale-guide.html.  5 is generous for interactive use
        # (a user clicking through BQB tabs rarely runs >2 simultaneously);
        # batch/scheduled callers (feed_gen, scheduler) bypass this gate
        # via their own slot manager.  Operators wanting more can override
        # in config.json — the env-driven `get()` honours overrides.
        return int(get("query_engine", "max_concurrent_per_user", 5))
    @property
    def max_concurrent_global(self) -> int:
        # BF-584: 50 → 200
        return int(get("query_engine", "max_concurrent_global", 200))
    @property
    def max_queue_size(self) -> int:
        # BF-584: 100 → 200, now actually wired
        return int(get("query_engine", "max_queue_size", 200))
    @property
    def global_queue_size(self) -> int:
        """2026-10-07: places in the pod-wide fair queue at the global cap
        (0 = refuse at once).  Read by core/query_queue.py."""
        return max(0, int(get("query_engine", "global_queue_size", 200) or 0))
    @property
    def queue_wait_timeout_seconds(self) -> int:
        """BF-584: how long a queued query waits for a slot before
        giving up with 503.  0 disables queueing (legacy 429 behaviour)."""
        return int(get("query_engine", "queue_wait_timeout_seconds", 60))
    @property
    def duckdb_threads_per_query(self) -> int:
        """Max DuckDB threads per connection.

        BF-255: previous default (4) artificially throttled DuckDB to 1/5 of
        a typical 20-core box.  DuckDB's own scheduler shares threads across
        concurrent queries efficiently, so giving each query the full CPU
        count is the right default for power-user single-query latency.
        Multi-tenant deployments with high concurrency can tune down via
        config (e.g. ``duckdb_threads_per_query: 4``).

        ``0`` = auto (use all cores).  Positive integer = explicit cap.
        """
        v = int(get("query_engine", "duckdb_threads_per_query", 0))
        if v > 0:
            return v
        # Auto: use all available cores — matches DuckDB's own default and
        # Trino/Spark "use all CPU" posture.  DuckDB's task scheduler shares
        # threads across simultaneous queries.
        cpus = os.cpu_count() or 4
        return max(2, cpus)
    @property
    def duckdb_memory_limit_mb(self) -> int:
        """Per-connection DuckDB memory limit in MB. 0 = unlimited. Default 2GB."""
        return int(get("query_engine", "duckdb_memory_limit_mb", 2048))


class _S3Cfg:
    @property
    def default_region(self) -> str: return get("s3", "default_region")
    @property
    def handler_cache_ttl_seconds(self) -> int: return int(get("s3", "handler_cache_ttl_seconds", 60))
    @property
    def default_onprem_access_mode(self) -> str:
        # Env override lets operators flip on-prem S3 from pre-download
        # (presigned) to streaming (native) without a config.json edit.
        # Use case: BQB/CQB queries pre-downloading large parquet files
        # when the on-prem S3 server actually supports streaming fine.
        env = os.environ.get("QUERYSTUDIO_S3_DEFAULT_ONPREM_ACCESS_MODE", "").strip().lower()
        if env in ("native", "presigned"):
            return env
        return str(get("s3", "default_onprem_access_mode", "presigned"))
    @property
    def parallel_download_workers(self) -> int: return int(get("s3", "parallel_download_workers", 32))
    @property
    def force_boto3_for_vpc(self) -> bool:  # noqa: D401 -- accessor
        # 2026-06-24 -- default flipped to False.  See ``s3`` config
        # defaults docstring above for the operator-verified rationale.
        """2026-06-18 master switch for the VPC-endpoint -> boto3
        pre-download forcing.  See config.py defaults docstring for
        the trade-off."""
        return bool(get("s3", "force_boto3_for_vpc", False))
    @property
    def workers_per_cpu(self) -> float:
        """Oversubscription multiplier for the parallel-download worker
        ceiling.  0 (default) = no ceiling -- honour
        parallel_download_workers literally."""
        return float(get("s3", "workers_per_cpu", 0) or 0)
    @property
    def workers_per_cpu_min(self) -> int:
        return int(get("s3", "workers_per_cpu_min", 2) or 2)
    @property
    def download_retries(self) -> int: return int(get("s3", "download_retries", 3))
    @property
    def download_timeout_seconds(self) -> int: return int(get("s3", "download_timeout_seconds", 120))
    @property
    def min_free_disk_gb(self) -> float: return float(get("s3", "min_free_disk_gb", 1.0))
    # ── BF-416: pre-download disk cap + small-query skip threshold ──
    @property
    def predownload_max_disk_gb(self) -> float:
        """BF-416 — refuse pre-download when projected total bytes exceeds this
        cap.  0 (default) = no cap (legacy behaviour).  Replaces the old
        run-out-of-disk-mid-query failure mode with a clear up-front error."""
        # BF-578: default raised from 0.0 (uncapped) to 20 GB — single
        # query can no longer fill the PVC.  Admin can still set 0 to
        # disable for the legacy uncapped behaviour.
        return float(get("s3", "predownload_max_disk_gb", 20.0))
    @property
    def predownload_skip_threshold(self) -> int:
        """BF-416 — when post-pruning file count is <= this, skip pre-download
        and let DuckDB httpfs read directly through the proxy.  0 (default)
        means always pre-download (legacy behaviour)."""
        # BF-578: default raised from 0 (always pre-download) to 10.
        # For tiny scans the pre-download detour costs more than
        # the direct httpfs read it replaces.
        return int(get("s3", "predownload_skip_threshold", 10))
    @property
    def predownload_warn_mb(self) -> float:
        """BF-466 (2026-05-19) — log WARNING when a single pre-download call
        exceeds this many MB.  Lets admins spot full-scan queries in prod
        logs without trawling.  0 disables the warning.  Default 1024 (1 GB).
        Pair with ``predownload_max_disk_gb`` to also CAP the transfer."""
        return float(get("s3", "predownload_warn_mb", 1024.0))
    # ── Phase 134: Column pruning download strategy ──
    @property
    def column_pruning_download(self) -> str: return str(get("s3", "column_pruning_download", "auto"))
    # ── BF-PRUNE-PERF: union_by_name in CREATE VIEW ──
    # When True, DuckDB reads the parquet footer of EVERY file in the view
    # to compute the column union — expensive for views with 1000+ files
    # (50-100s extra setup time per query).
    # Defaults are FALSE because:
    #   - Iceberg writers project every file to the table schema (Iceberg
    #     guarantees this).
    #   - Plain parquet tables in QueryStudio's S3 paths are typically
    #     emitted by one writer with a stable schema per partition prefix.
    # Set to True only if you have a heterogeneous parquet directory where
    # files genuinely have different column sets (rare, usually a bug).
    @property
    def duckdb_union_by_name_iceberg(self) -> bool:
        return bool(get("s3", "duckdb_union_by_name_iceberg", False))
    @property
    def union_by_name_max_files(self) -> int:
        """2026-06-24 -- file-count threshold for the
        schema-evolution -> union_by_name=true auto-enable.

        When iceberg metadata reports schema evolution AND the
        pruned file set is <= this threshold, ``union_by_name=true``
        is auto-applied so files written under older schemas don't
        cause "Column not found" failures on read.

        Above this threshold, the per-file footer scan
        ``union_by_name=true`` triggers becomes prohibitively
        expensive (200-350s for thousands of S3 parquet files), so
        the admin's ``duckdb_union_by_name_iceberg`` flag wins.

        Default 200 -- partition-pruned queries typically land
        well under (e.g. 1-10 partitions of <100 files each),
        full-table scans on evolved tables exceed.  Operators with
        evolved tables that routinely run unfiltered scans should
        raise this if they accept the setup penalty, OR add
        partition filters to their queries."""
        return int(get("s3", "union_by_name_max_files", 200))
    @property
    def duckdb_union_by_name_parquet(self) -> bool:
        return bool(get("s3", "duckdb_union_by_name_parquet", False))
    # ── Phase 134-A: Footer stats pruning ──
    @property
    def footer_stats_enabled(self) -> bool: return bool(get("s3", "footer_stats_enabled", True))
    @property
    def footer_stats_dir(self) -> str: return str(get("s3", "footer_stats_dir", "/usr/local/querystudioapi/nfs/data/s3_footer_stats"))
    @property
    def footer_stats_ttl_hours(self) -> int: return int(get("s3", "footer_stats_ttl_hours", 24))
    @property
    def footer_stats_min_files_threshold(self) -> int:
        # Phase 139 (Tier 1.1): lowered from 100 → 8 so footer-stats pruning
        # activates for typical user tables (most tables are 10-100 files).
        return int(get("s3", "footer_stats_min_files_threshold", 8))
    # ── Phase 134-B: Scan budget ──
    @property
    def scan_budget_soft(self) -> int: return int(get("s3", "scan_budget_soft", 500))
    @property
    def scan_budget_hard(self) -> int:
        # DEPRECATED ALIAS (2026-09-21, FB-55) — see the _DEFAULTS entry
        # for why the 1000 is gone.  Read it through
        # ``core/scan_budget.resolve_scan_budget`` rather than here: this
        # accessor answers "what is the alias set to", not "what is the
        # ceiling", and the two are only the same when the primary key is
        # off.  The inline fallback used to say 1000 while _DEFAULTS said
        # 1000 as well — one number declared twice, which is how the two
        # halves of a default drift apart.
        return int(get("s3", "scan_budget_hard", 0))
    @property
    def suggest_partitions(self) -> bool: return bool(get("s3", "suggest_partitions", True))
    # ── Phase 134-D: File cache ──
    @property
    def file_cache_enabled(self) -> bool: return bool(get("s3", "file_cache_enabled", True))
    @property
    def file_cache_dir(self) -> str: return str(get("s3", "file_cache_dir", "/usr/local/querystudioapi/nfs/data/s3_file_cache"))
    @property
    def file_cache_max_gb(self) -> int: return int(get("s3", "file_cache_max_gb", 20))
    @property
    def file_cache_ttl_hours(self) -> int: return int(get("s3", "file_cache_ttl_hours", 8))
    @property
    def file_cache_validate_etag(self) -> bool: return bool(get("s3", "file_cache_validate_etag", True))
    @property
    def file_cache_eviction_interval_hours(self) -> int: return int(get("s3", "file_cache_eviction_interval_hours", 1))
    @property
    def cache_atomic_writes(self) -> bool: return bool(get("s3", "cache_atomic_writes", True))
    # ── Phase 134-G1: Pre-execution estimate ──
    @property
    def estimate_enabled(self) -> bool: return bool(get("s3", "estimate_enabled", True))
    @property
    def estimate_threshold(self) -> int: return int(get("s3", "estimate_threshold", 200))
    @property
    def estimate_mode(self) -> str: return str(get("s3", "estimate_mode", "threshold"))
    # ── Phase 134-G2: Per-user scan quotas ──
    @property
    def scan_quotas_enabled(self) -> bool: return bool(get("s3", "scan_quotas_enabled", False))
    @property
    def scan_quota_admin(self) -> int: return int(get("s3", "scan_quota_admin", 0))
    @property
    def scan_quota_analyst_hourly(self) -> int: return int(get("s3", "scan_quota_analyst_hourly", 10000))
    @property
    def scan_quota_analyst_daily(self) -> int: return int(get("s3", "scan_quota_analyst_daily", 50000))
    @property
    def scan_quota_viewer_hourly(self) -> int: return int(get("s3", "scan_quota_viewer_hourly", 2000))
    @property
    def scan_quota_viewer_daily(self) -> int: return int(get("s3", "scan_quota_viewer_daily", 10000))
    @property
    def scan_quota_api_key_hourly(self) -> int: return int(get("s3", "scan_quota_api_key_hourly", 5000))
    @property
    def scan_quota_api_key_daily(self) -> int: return int(get("s3", "scan_quota_api_key_daily", 25000))
    # ── Phase 134-G3: Perf audit ──
    @property
    def perf_audit_enabled(self) -> bool: return bool(get("s3", "perf_audit_enabled", True))
    @property
    def perf_audit_retention_days(self) -> int: return int(get("s3", "perf_audit_retention_days", 90))
    # ── Phase 134-G5: Cache encryption ──
    @property
    def cache_encryption_enabled(self) -> bool: return bool(get("s3", "cache_encryption_enabled", False))
    @property
    def cache_encryption_key_source(self) -> str: return str(get("s3", "cache_encryption_key_source", "config"))
    # ── Phase 134-G6: Circuit breaker ──
    @property
    def circuit_breaker_enabled(self) -> bool: return bool(get("s3", "circuit_breaker_enabled", True))
    @property
    def circuit_breaker_threshold(self) -> int: return int(get("s3", "circuit_breaker_threshold", 5))
    @property
    def circuit_breaker_window_seconds(self) -> int: return int(get("s3", "circuit_breaker_window_seconds", 60))
    @property
    def circuit_breaker_cooldown_seconds(self) -> int: return int(get("s3", "circuit_breaker_cooldown_seconds", 30))
    # ── Phase 134-G7: Graceful degradation ──
    @property
    def graceful_degradation_enabled(self) -> bool: return bool(get("s3", "graceful_degradation_enabled", True))
    @property
    def allow_stale_list_on_failure(self) -> bool: return bool(get("s3", "allow_stale_list_on_failure", True))
    @property
    def allow_partial_results(self) -> bool: return bool(get("s3", "allow_partial_results", True))
    @property
    def partial_result_threshold(self) -> float: return float(get("s3", "partial_result_threshold", 0.8))


class _S3LocalCacheCfg:
    """BF-257 — persistent S3 file cache config.

    Iceberg data files are immutable, so caching by s3://bucket/key path is
    safe — same path always = same content.  Re-queries on the same files
    skip the S3 download entirely.  This is QueryStudio's compaction-
    equivalent at the read side: the source data is unchanged, but our
    effective read cost drops to local-NFS speed.
    """
    @property
    def enabled(self) -> bool: return bool(get("s3_local_cache", "enabled", False))
    @property
    def cache_dir(self) -> str: return str(get("s3_local_cache", "cache_dir",
                                                 "/usr/local/querystudioapi/nfs/data/s3_cache"))
    @property
    def max_size_gb(self) -> int: return int(get("s3_local_cache", "max_size_gb", 100))
    @property
    def evict_interval_minutes(self) -> int: return int(get("s3_local_cache", "evict_interval_minutes", 30))
    @property
    def min_free_disk_gb(self) -> float: return float(get("s3_local_cache", "min_free_disk_gb", 5.0))


class _S3ResultsCfg:
    @property
    def enabled(self) -> bool: return bool(get("s3_results", "enabled", False))
    @property
    def storage_mode(self) -> str: return str(get("s3_results", "storage_mode", "local"))  # "local" | "s3" | "auto"
    @property
    def size_threshold_mb(self) -> int: return int(get("s3_results", "size_threshold_mb", 10))
    @property
    def size_threshold_bytes(self) -> int: return self.size_threshold_mb * 1024 * 1024
    @property
    def prefix(self) -> str: return str(get("s3_results", "prefix", "querystudio/results/"))
    @property
    def delete_local_after_upload(self) -> bool: return bool(get("s3_results", "delete_local_after_upload", False))
    @property
    def bucket_override(self) -> str: return str(get("s3_results", "bucket_override", ""))


class _StorageCfg:
    @property
    def max_cache_size_mb(self)     -> int: return int(get("storage", "max_cache_size_mb", 2048))
    @property
    def max_downloads_size_mb(self) -> int: return int(get("storage", "max_downloads_size_mb", 10240))
    @property
    def downloads_expiry_days(self) -> int: return int(get("storage", "downloads_expiry_days", 7))


class _SchedulerCfg:
    @property
    def leader_election_enabled(self)    -> bool: return bool(get("scheduler", "leader_election_enabled", True))
    @property
    def autostart(self)                  -> bool: return bool(get("scheduler", "autostart", True))
    @property
    def job_singleton_lock_enabled(self) -> bool: return bool(get("scheduler", "job_singleton_lock_enabled", True))
    @property
    def cleanup_temp_files_seconds(self) -> int: return int(get("scheduler", "cleanup_temp_files_seconds", 900))
    @property
    def cleanup_temp_files_hours(self)   -> int: return int(get("scheduler", "cleanup_temp_files_hours"))
    @property
    def max_missed_jobs(self)            -> int: return int(get("scheduler", "max_missed_jobs"))
    @property
    def execution_retention_days(self)   -> int: return int(get("scheduler", "execution_retention_days", 30))
    @property
    def mode(self)                       -> str:   return get("scheduler", "mode", "embedded")
    @property
    def worker_port(self)                -> int:   return int(get("scheduler", "worker_port", 8001))
    @property
    def worker_host(self)                -> str:   return get("scheduler", "worker_host", "127.0.0.1")
    @property
    def notification_poll_interval(self) -> float: return float(get("scheduler", "notification_poll_interval", 1.5))
    @property
    def job_pool_size(self)              -> int:   return int(get("scheduler", "job_pool_size", 20))
    @property
    def worker_url(self)                 -> str:   return f"http://{self.worker_host}:{self.worker_port}"

    @property
    def user_schedule_misfire_grace_seconds(self) -> int:
        """Per-job misfire grace for USER schedules (see _DEFAULTS note).
        Floor 30 — never let a config typo make user schedules MORE
        skippable than the daemon default."""
        try:
            v = int(get("scheduler", "user_schedule_misfire_grace_seconds", 3600))
        except (TypeError, ValueError):
            v = 3600
        return max(30, v)


class _CorsCfg:
    @property
    def allow_origins(self) -> list: return get("cors", "allow_origins")
    @property
    def allow_methods(self) -> list: return get("cors", "allow_methods")
    @property
    def allow_headers(self) -> list: return get("cors", "allow_headers")
    # BF-404 — suffix allowlist + echo-origin escape hatch
    @property
    def allow_origin_suffixes(self) -> list:
        return get("cors", "allow_origin_suffixes", []) or []
    @property
    def echo_request_origin(self) -> bool:
        return bool(get("cors", "echo_request_origin", False))


class _DatabaseCfg:
    @property
    def type(self) -> str:
        env = os.environ.get("QUERYSTUDIO_DATABASE_TYPE", "").strip().lower()
        if env:
            return env
        return get("database", "type", "sqlite").lower()

    @property
    def postgresql_url(self) -> str:
        return get("database", "postgresql_url", "")

    @property
    def postgresql_pool_size(self) -> int:
        env = os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_POOL_SIZE", "").strip()
        if env:
            return int(env)
        return int(get("database", "postgresql_pool_size", 20))

    @property
    def postgresql_max_overflow(self) -> int:
        env = os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_MAX_OVERFLOW", "").strip()
        if env:
            return int(env)
        return int(get("database", "postgresql_max_overflow", 30))

    @property
    def postgresql_pool_timeout(self) -> int:
        env = os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_POOL_TIMEOUT", "").strip()
        if env:
            return int(env)
        return int(get("database", "postgresql_pool_timeout", 30))

    @property
    def postgresql_ssl_mode(self) -> str:
        env = os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_SSL_MODE", "").strip()
        if env:
            return env
        return get("database", "postgresql_ssl_mode", "prefer")

    # ── Read replica properties (Phase 43) ──
    @property
    def replica_urls(self) -> list:
        val = get("database", "replica_urls", [])
        if isinstance(val, str):
            return [u.strip() for u in val.split(",") if u.strip()] if val else []
        return list(val) if val else []

    @property
    def read_preference(self) -> str:
        return get("database", "read_preference", "replica")

    @property
    def replica_pool_size(self) -> int:
        return int(get("database", "replica_pool_size", 10))

    @property
    def replica_max_overflow(self) -> int:
        return int(get("database", "replica_max_overflow", 15))

    @property
    def replica_pool_timeout(self) -> int:
        return int(get("database", "replica_pool_timeout", 20))

    @property
    def replica_health_interval_seconds(self) -> int:
        return int(get("database", "replica_health_interval_seconds", 30))

    @property
    def replica_max_lag_seconds(self) -> int:
        return int(get("database", "replica_max_lag_seconds", 5))

    # BF-408 — SQLite-on-PVC corruption mitigation
    @property
    def sqlite_journal_mode(self) -> str:
        return str(get("database", "sqlite_journal_mode", "WAL")).upper()
    @property
    def sqlite_synchronous(self) -> str:
        return str(get("database", "sqlite_synchronous", "NORMAL")).upper()
    @property
    def sqlite_integrity_check_on_startup(self) -> bool:
        return bool(get("database", "sqlite_integrity_check_on_startup", True))

    # BF-409 — Schema isolation (Postgres only)
    @property
    def postgresql_schema(self) -> str:
        """Postgres schema for the metadata tables.  Empty = use default
        (usually 'public').  When set, the engine `SET search_path` is
        configured on every connection and the auto-create logic also
        creates the schema if missing."""
        return str(get("database", "postgresql_schema", "") or "").strip()

    @property
    def db_url(self) -> str:
        """Return the SQLAlchemy DB URL for the metadata store.

        BF-409 — Airflow-style env-var resolution ladder for PostgreSQL.
        Order (first non-empty wins):

          1. QUERYSTUDIO_DATABASE_URL            (raw URL — like
             AIRFLOW__DATABASE__SQL_ALCHEMY_CONN)
          2. QUERYSTUDIO_DATABASE_URL_CMD        (shell command whose stdout
             is the URL — like Airflow's `_cmd` pattern; lets you fetch
             from `vault kv get ...`, `aws secretsmanager get-secret-value`,
             etc.)
          3. QUERYSTUDIO_DATABASE_URL_SECRET     (path to a file containing
             the URL — for K8s secrets mounted as files; trimmed of
             trailing newline)
          4. config.json `database.postgresql_url`
          5. Built from `database.postgresql_user/password/host/port/db`
             individual fields (also each env-var-overridable) if all set.

        After resolution, ``database.postgresql_ssl_mode`` is appended as
        a query parameter if non-empty and not already present.

        The same ladder is honoured regardless of `database.type`, so
        secret-manager-driven deploys can still set type=postgresql in
        config.json and never touch the URL there.
        """
        # 2026-09-13 -- FOUND BY RUNNING THE APP, not by a test.
        # QUERYSTUDIO_DATABASE_URL=postgresql://... was set and the app
        # silently opened SQLITE, because the ladder below is only
        # CONSULTED when type is already postgresql.  It logged
        # "SQLite DB path resolved" at INFO and served /api/health 200.
        #
        # In a cluster that is data loss wearing a green probe: the pod
        # writes to an EPHEMERAL local file and every row dies with it,
        # while the operator believes they pointed it at Postgres.
        #
        # An operator instruction that is PRESENT and DISCARDED is the
        # foreign-but-present class this codebase already has scars from.
        # So it refuses, naming both values -- it does NOT quietly adopt
        # the URL either, because a deploy that meant to stay on SQLite
        # must not be switched by an env var nobody re-read.
        if self.type != "postgresql":
            _env_url = self._resolve_postgresql_url_from_env()
            if _env_url.strip().lower().startswith(("postgresql:", "postgres:")):
                raise ValueError(
                    f"database.type is {self.type!r} but a PostgreSQL URL is set in "
                    f"the environment (QUERYSTUDIO_DATABASE_URL / _CMD / _SECRET).  "
                    f"Refusing to start rather than silently using {self.type}: a pod "
                    f"that ignores the database you handed it writes to the wrong place "
                    f"and reports healthy.  Either set database.type=postgresql, or "
                    f"unset the environment variable."
                )
        if self.type == "postgresql":
            url = self._resolve_postgresql_url_from_env() or self.postgresql_url
            if not url:
                # Try individual fields (also env-var-overridable)
                url = self._compose_postgresql_url_from_parts()
            if url:
                return self._append_postgresql_ssl_mode(url)
            raise ValueError(
                "database.type=postgresql but no URL configured.  Set one of:\n"
                "  - env QUERYSTUDIO_DATABASE_URL=postgresql://user:pass@host/db\n"
                "  - env QUERYSTUDIO_DATABASE_URL_CMD='vault kv get -field=url qs/pg'\n"
                "  - env QUERYSTUDIO_DATABASE_URL_SECRET=/var/run/secrets/db-url\n"
                "  - config.json database.postgresql_url\n"
                "  - config.json database.postgresql_{user,password,host,port,db}"
            )
        if self.type == "oracle":
            user = get("database", "oracle_user") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_USER", "")
            pwd  = get("database", "oracle_password") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_PASSWORD", "")
            dsn  = get("database", "oracle_dsn") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_DSN", "")
            if not (user and pwd and dsn):
                raise ValueError(
                    "database.type=oracle requires oracle_user, oracle_password, and oracle_dsn "
                    "in config.json or QUERYSTUDIO_DATABASE_ORACLE_* env vars."
                )
            return f"oracle+oracledb://{user}:{pwd}@{dsn}"
        # Default: SQLite
        return "sqlite:///" + _PathsCfg().db_file.as_posix()

    # ── BF-409 helpers ────────────────────────────────────────────────────

    @staticmethod
    def _resolve_postgresql_url_from_env() -> str:
        """Airflow-style env-var ladder: URL → URL_CMD → URL_SECRET."""
        import logging as _logging
        _l = _logging.getLogger(__name__)

        # 1. Raw env var
        raw = os.environ.get("QUERYSTUDIO_DATABASE_URL", "").strip()
        if raw:
            return raw

        # 2. _CMD — shell command whose stdout is the URL
        cmd = os.environ.get("QUERYSTUDIO_DATABASE_URL_CMD", "").strip()
        if cmd:
            try:
                import subprocess
                # REVIEWED 2026-09-13 (ruff S602 / Sonar "OS command from a
                # variable").  shell=True is CORRECT here and stays.
                #
                # What the variable is: QUERYSTUDIO_DATABASE_URL_CMD, a
                # process environment variable, set at deploy time by
                # whoever writes the Deployment/Helm values.  It is never
                # read from a request, a database row, a config file the
                # app can write, or any authenticated user's input -- this
                # ladder runs before the app can serve anything.
                #
                # Why shell=True rather than a list: the whole point of the
                # _CMD convention (copied from Airflow's
                # *_CMD/*_SECRET ladder, which operators already know) is
                # that the value is a SHELL LINE -- "vault read -field=url
                # secret/db", pipes and all.  Splitting it
                # with shlex would break every pipeline an operator writes
                # and would not add safety, because the string is trusted
                # in full either way.
                #
                # Threat model: an attacker who can set this env var can
                # already set the image, the command, and the service
                # account of the pod. There is no privilege boundary
                # between "set QUERYSTUDIO_DATABASE_URL_CMD" and "run code
                # in this container", so shell=True crosses nothing.
                #
                # Bounded: timeout=30, and any failure is logged and falls
                # through to the _SECRET rung rather than raising.
                out = subprocess.check_output(cmd, shell=True, timeout=30)
                resolved = out.decode("utf-8", errors="replace").strip()
                if resolved:
                    _l.info("[db-url] resolved from QUERYSTUDIO_DATABASE_URL_CMD")
                    return resolved
            except Exception as exc:
                _l.error("[db-url] QUERYSTUDIO_DATABASE_URL_CMD failed: %s", exc)

        # 3. _SECRET — read from file path
        secret_path = os.environ.get("QUERYSTUDIO_DATABASE_URL_SECRET", "").strip()
        if secret_path:
            try:
                with open(secret_path, "r", encoding="utf-8") as f:
                    val = f.read().strip()
                if val:
                    _l.info("[db-url] resolved from QUERYSTUDIO_DATABASE_URL_SECRET=%s",
                            secret_path)
                    return val
            except Exception as exc:
                _l.error(
                    "[db-url] could not read QUERYSTUDIO_DATABASE_URL_SECRET=%s: %s",
                    secret_path, exc,
                )

        return ""

    @staticmethod
    def _compose_postgresql_url_from_parts() -> str:
        """Build the URL from `postgresql_{user,password,host,port,db}`
        config keys (each env-var-overridable).  Returns "" if any are
        missing.  Useful for K8s deployments that mount secrets as
        individual env vars rather than a complete URL."""
        user = (get("database", "postgresql_user", "") or
                os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_USER", "")).strip()
        pwd  = (get("database", "postgresql_password", "") or
                os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_PASSWORD", "")).strip()
        host = (get("database", "postgresql_host", "") or
                os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_HOST", "")).strip()
        port = (str(get("database", "postgresql_port", "") or
                    os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_PORT", "")) or "5432").strip()
        db   = (get("database", "postgresql_db", "") or
                os.environ.get("QUERYSTUDIO_DATABASE_POSTGRESQL_DB", "")).strip()
        if not (user and host and db):
            return ""
        from urllib.parse import quote_plus
        # URL-encode user/password to survive special chars
        return (
            f"postgresql://{quote_plus(user)}:{quote_plus(pwd)}"
            f"@{host}:{port or '5432'}/{db}"
        )

    def _append_postgresql_ssl_mode(self, url: str) -> str:
        """Append `?sslmode=...` to the URL if the config has it set and
        the URL doesn't already specify one.  Previously dead code — the
        config value was read but never wired through."""
        mode = (self.postgresql_ssl_mode or "").strip().lower()
        if not mode or mode == "prefer":
            # libpq default is `prefer`; no need to clutter the URL
            return url
        # Don't override an explicit sslmode already in the URL
        if "sslmode=" in url:
            return url
        sep = "&" if "?" in url else "?"
        return f"{url}{sep}sslmode={mode}"


#: the attributes that continue a DN after its CN ("CN=x,OU=y,DC=z")
_DN_TAIL_ATTRS = ("ou", "dc", "o", "c", "l", "st")


def _dn_pieces(text: str) -> list:
    """``text`` cut at every UNESCAPED comma (RFC 4514: a backslash-comma is
    part of the value -- "CN=Smith<backslash>, John" is one piece), each
    piece stripped."""
    pieces, cur, i = [], [], 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text):
            cur.append(text[i:i + 2])
            i += 2
            continue
        if ch == ",":
            pieces.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    pieces.append("".join(cur).strip())
    return [p for p in pieces if p]


def _rdn(piece: str) -> str:
    """One "attr=value" piece, lower case, no spaces around the '='."""
    attr, _, value = piece.partition("=")
    return f"{attr.strip().lower()}={value.strip().lower()}"


def normalize_dn(dn: str) -> str:
    """A DN in the one spelling the role decision compares: lower case, no
    spaces around '=' or ',', escapes kept ("CN=QS-Admins, OU=Groups" ->
    "cn=qs-admins,ou=groups")."""
    return ",".join(_rdn(p) for p in _dn_pieces(str(dn)) if "=" in p)


def dn_common_name(dn: str) -> str:
    """The CN of a DN's FIRST piece, unescaped ("CN=Smith<backslash>, John,OU=G"
    -> "Smith, John"); a value with no '=' is returned as it is."""
    pieces = _dn_pieces(str(dn))
    if not pieces:
        return ""
    attr, sep, value = pieces[0].partition("=")
    if not sep:
        return pieces[0]
    if attr.strip().lower() != "cn":
        return ""
    return re.sub(r"\\(.)", r"\1", value.strip())


def _ad_group_names(raw) -> list:
    """An ``auth.ad_*_groups`` value as the entries the login compares.

    A group may be written two ways (2026-10-28):

    * its full DN ("CN=QS-Admins,OU=Groups,DC=x") -> kept WHOLE, normalised
      (``normalize_dn``), and matched only against the user's full
      ``memberOf`` DN -- never by its CN, or a same-named group in another
      OU would be granted the role;
    * a bare name ("QS-Admins") -> lower case, matched against the CN of
      any of the user's groups (as it always was).

    Entries are separated by ';', a new line, or a comma; a comma INSIDE a
    DN is part of it (an "OU=" / "DC=" ... piece continues the DN before
    it) and an escaped (backslash) comma is part of a value.  A DN tail with
    no DN before it, or a piece naming another attribute, is REFUSED
    (logged), never read as a group name.  Before 2026-10-28 every comma
    split, so a DN matched nobody and every AD user was a viewer.
    """
    if not raw:
        return []
    items = raw if isinstance(raw, (list, tuple)) else [raw]
    out: list = []
    for item in items:
        for chunk in re.split(r"[;\n]", str(item)):
            current = None          # the DN being assembled
            for piece in _dn_pieces(chunk):
                attr = piece.partition("=")[0].strip().lower() if "=" in piece else ""
                if attr == "cn":
                    if current:
                        out.append(",".join(current))
                    current = [_rdn(piece)]
                elif attr in _DN_TAIL_ATTRS:
                    if current is None:
                        logger.warning("auth: AD group setting piece %r has no CN= before it -- ignored", piece)
                        continue
                    current.append(_rdn(piece))
                elif attr:
                    logger.warning("auth: AD group setting piece %r is not a group -- ignored", piece)
                else:
                    if current:
                        out.append(",".join(current))
                        current = None
                    out.append(piece.lower())
            if current:
                out.append(",".join(current))
    return list(dict.fromkeys(out))


class _AuthCfg:
    @property
    def configured_type(self) -> str:
        """What the deployment SET (config file, QUERYSTUDIO_AUTH_TYPE, a runtime
        setting); '' when nobody did."""
        return str(get("auth", "type", "") or "").strip().lower()

    @property
    def configured(self) -> bool:
        """A login type was chosen on purpose and the config file loaded."""
        return bool(self.configured_type) and not config_load_failed()

    @property
    def type(self) -> str:
        """THE effective login type every gate reads.  'none' (guest admin) only
        when it was chosen on purpose; unset, or 'none' left by a config that
        failed to load, is 'local' -- login REQUIRED: anonymous callers get 401
        and the SPA shows the login page (the DB-backed super_admin break-glass
        login still works).  2026-10-18: an OpenShift deployment with no auth
        settings served every visitor as a guest ADMIN (connections, data)."""
        t = self.configured_type
        if not t or (t == "none" and config_load_failed()):
            return "local"
        return t

    # ── /auth/login limiter (2026-09-29; see _DEFAULTS["auth"]) ──
    @property
    def login_rate_limit_per_account_per_minute(self) -> int:
        """Attempts per minute per (client address, normalised username)."""
        return int(get("auth", "login_rate_limit_per_account_per_minute", 10))

    @property
    def login_rate_limit_per_ip_per_minute(self) -> int:
        """Attempts per minute per client address across every username."""
        return int(get("auth", "login_rate_limit_per_ip_per_minute", 300))

    @property
    def login_plaintext_fallback(self) -> str:
        """``"allow"`` or ``"refuse"`` -- what /auth/login does with a
        plaintext password (see _DEFAULTS).  Normalised: only an exact
        ``allow`` (case/whitespace-insensitive) allows; any other value,
        including a misspelling, REFUSES -- a typo must not open the
        plaintext arm, and ``validate_config`` names it at startup."""
        raw = str(get("auth", "login_plaintext_fallback", "allow") or "").strip().lower()
        return "allow" if raw == "allow" else "refuse"

    # ── Local auth ──
    @property
    def local_users(self) -> dict:
        """Parse 'user1:pass1,user2:pass2' into {user1: pass1, ...}"""
        raw = get("auth", "local_users", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                u, p = pair.split(":", 1)
                result[u.strip()] = p.strip()
        return result

    @property
    def user_roles(self) -> dict:
        """Parse 'user1:admin,user2:analyst' into {user1: admin, ...}"""
        raw = get("auth", "user_roles", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                u, r = pair.split(":", 1)
                result[u.strip().lower()] = r.strip().lower()
        return result

    # ── AD config ──
    @property
    def ad_server(self) -> str:         return get("auth", "ad_server", "")
    @property
    def ad_domain(self) -> str:         return get("auth", "ad_domain", "")
    @property
    def ad_base_dn(self) -> str:        return get("auth", "ad_base_dn", "")
    @property
    def ad_user_search_filter(self) -> str:
        return get("auth", "ad_user_search_filter", "(sAMAccountName={username})")
    @property
    def ad_group_attribute(self) -> str: return get("auth", "ad_group_attribute", "memberOf")
    @property
    def ad_admin_groups(self) -> list:
        return _ad_group_names(get("auth", "ad_admin_groups", ""))
    @property
    def ad_analyst_groups(self) -> list:
        return _ad_group_names(get("auth", "ad_analyst_groups", ""))
    @property
    def ad_viewer_groups(self) -> list:
        return _ad_group_names(get("auth", "ad_viewer_groups", ""))
    @property
    def ad_service_account(self) -> str: return get("auth", "ad_service_account", "")
    @property
    def ad_service_password(self) -> str: return get("auth", "ad_service_password", "")
    @property
    def ad_connect_timeout(self) -> int: return int(get("auth", "ad_connect_timeout", 3))
    @property
    def ad_receive_timeout(self) -> int: return int(get("auth", "ad_receive_timeout", 10))
    @property
    def ad_use_ssl(self) -> bool: return bool(get("auth", "ad_use_ssl", False))
    @property
    def ad_tls_validate(self) -> bool: return bool(get("auth", "ad_tls_validate", True))
    @property
    def ad_tls_check_hostname(self) -> bool: return bool(get("auth", "ad_tls_check_hostname", False))
    @property
    def ad_tls_ca_file(self) -> str: return str(get("auth", "ad_tls_ca_file", "") or "")


class _EmailCfg:
    @property
    def host(self) -> str:         return get("email", "host", "")
    @property
    def port(self) -> int:         return int(get("email", "port", 587))
    @property
    def user(self) -> str:         return get("email", "user", "")
    @property
    def password(self) -> str:     return get("email", "password", "")
    @property
    def from_address(self) -> str: return get("email", "from_address", "")
    @property
    def use_tls(self) -> bool:     return bool(get("email", "use_tls", True))
    @property
    def enabled(self) -> bool:     return bool(self.host)


class _CacheCfg:
    @property
    def enabled(self)     -> bool: return bool(get("cache", "enabled", True))
    @property
    def ttl_seconds(self) -> int:  return int(get("cache", "ttl_seconds", 3600))
    @property
    def max_size_mb(self) -> int:  return int(get("cache", "max_size_mb", 2048))
    @property
    def download_ttl_seconds(self) -> int:
        return int(get("cache", "download_ttl_seconds", 7 * 24 * 3600))
    # Phase 104 — partition-aware cache invalidation
    @property
    def partition_aware_invalidation(self) -> bool:
        return bool(get("cache", "partition_aware_invalidation", True))
    @property
    def snapshot_check_ttl_seconds(self) -> int:
        return int(get("cache", "snapshot_check_ttl_seconds", 300))
    @property
    def snapshot_sweep_interval_hours(self) -> int:
        return int(get("cache", "snapshot_sweep_interval_hours", 2))
    @property
    def parquet_file_list_check(self) -> bool:
        return bool(get("cache", "parquet_file_list_check", True))


# ── Admission caps derived from the pod's ACTUAL CPU (2026-08-04) ───────────
#
# The shipped constants admitted 30+10+5+8+10+50 = 113 concurrent DuckDB
# engines.  On the 4-CPU pod this product runs on, that is not a limit — it is
# the absence of one, and it was the last "NOT READY" item on the pre-test
# preflight.  Each admitted engine is a CPU-bound process; 113 of them on 4
# cores does not run 113 queries, it thrashes.
#
# Two sources disagreed on the replacement: the 2026-08-03 audit said
# interactive=3 (sized for 30 GiB / 4 CPU / replicas=1), RELEASE_PLAN_OPENSHIFT
# says 25.  Both are right FOR THEIR OWN POD.  Picking either constant makes
# the product wrong on the other, which is how it got a constant that was
# wrong everywhere.  So the cap is DERIVED from the cgroup CPU quota instead,
# and both recommendations fall out as special cases:
#
#     4 CPU  -> interactive 3, published_api 2, report/export/scheduled 1
#               (exactly the audit's numbers)
#    32 CPU  -> interactive 24, published_api 16, report/export/scheduled 8
#               (the RELEASE_PLAN shape)
#
# An EXPLICIT value in config.json or the environment always wins — this only
# replaces the hardcoded fallback.  Reads the same cgroup quota the DuckDB
# thread resolver uses, so admission and execution agree about the machine.
_CAP_SHARE_OF_CPU = {
    "interactive":   0.75,   # user is waiting; largest share
    "published_api": 0.50,   # external traffic we do not control
    "report":        0.25,
    "export":        0.25,
    "scheduled":     0.25,
    "system":        0.25,   # internal maintenance; must never crowd out users
}


def _usable_cpu_for_admission() -> int:
    """CPU count for sizing admission.  Never raises, never returns < 1."""
    try:
        from core.duckdb_resource_limits import _read_cgroup_cpu_quota
        q = _read_cgroup_cpu_quota()
        if q and q > 0:
            return max(1, int(round(q)))
    except Exception as exc:
        # Falling back to os.cpu_count() on a CONTAINER means sizing against
        # the HOST's cores, which over-admits — worth a log line, because the
        # symptom (thrashing under load) is nowhere near the cause.
        logger.debug(
            "worker-pool admission: cgroup CPU read failed (%s) — "
            "falling back to os.cpu_count(), which sees HOST cores in a "
            "container and may over-admit", exc)
    try:
        return max(1, int(os.cpu_count() or 1))
    except Exception as exc:
        logger.debug("worker-pool admission: os.cpu_count() failed (%s) — "
                     "assuming 1 CPU", exc)
        return 1


def _worker_pool_key_explicitly_set(key: str) -> bool:
    """True when the operator actually set ``worker_pool.<key>``.

    ``get()`` merges _DEFAULTS, so a plain read can never distinguish "the
    operator chose 30" from "30 is the shipped constant" — the same trap that
    made scheduler.cleanup_temp_files_hours undetectable.  Presence in the
    loaded config.json (``_file_cfg``, pre-merge) or a QUERYSTUDIO_WORKER_POOL_*
    env var is what counts as a choice.  Mirrors the auth.type check in
    validate_config().
    """
    try:
        if key in ((globals().get("_file_cfg") or {}).get("worker_pool") or {}):
            return True
    except Exception as exc:
        # Unreadable file config means we cannot tell a deliberate setting
        # from the shipped constant, so the derivation wins — say so, because
        # the operator's value silently not applying is exactly the class of
        # bug this function exists to prevent.
        logger.debug(
            "worker-pool admission: could not inspect file config for %r "
            "(%s) — treating as UNSET, so the derived cap applies even if "
            "config.json sets it", key, exc)
    return bool(os.environ.get(
        f"QUERYSTUDIO_WORKER_POOL_{key.upper()}", "").strip())


def _derived_max_concurrent(prefix: str, shipped_default: int) -> int:
    """Derived admission cap for ``prefix``, floored at 1.

    Falls back to the shipped constant if the prefix is unknown, so a new
    work type cannot accidentally get an unbounded cap by omission.
    """
    share = _CAP_SHARE_OF_CPU.get(prefix)
    if share is None:
        return shipped_default
    return max(1, int(round(_usable_cpu_for_admission() * share)))


class _WorkerPoolCfg:
    @property
    def total_workers(self) -> int:
        return int(get("worker_pool", "total_workers", 40))
    @property
    def drain_timeout_seconds(self) -> int:
        return int(get("worker_pool", "drain_timeout_seconds", 15))

    # Per-type settings (interactive, report, scheduled, export, system)
    def _type_int(self, prefix: str, suffix: str, default: int) -> int:
        # max_concurrent is the one knob whose right value depends on the
        # machine, so when it is not set explicitly it is DERIVED rather than
        # constant.  Everything else keeps its shipped default.
        key = f"{prefix}_{suffix}"
        if suffix == "max_concurrent" and not _worker_pool_key_explicitly_set(key):
            return _derived_max_concurrent(prefix, default)
        return int(get("worker_pool", key, default))

    @property
    def interactive_max_concurrent(self) -> int: return self._type_int("interactive", "max_concurrent", 30)
    @property
    def interactive_default_timeout(self) -> int: return self._type_int("interactive", "default_timeout", 1800)
    @property
    def interactive_max_queue(self) -> int: return self._type_int("interactive", "max_queue", 100)

    @property
    def report_max_concurrent(self) -> int: return self._type_int("report", "max_concurrent", 10)
    @property
    def report_default_timeout(self) -> int: return self._type_int("report", "default_timeout", 3600)
    @property
    def report_max_queue(self) -> int: return self._type_int("report", "max_queue", 20)

    @property
    def scheduled_max_concurrent(self) -> int: return self._type_int("scheduled", "max_concurrent", 5)
    @property
    def scheduled_default_timeout(self) -> int: return self._type_int("scheduled", "default_timeout", 7200)
    @property
    def scheduled_max_queue(self) -> int: return self._type_int("scheduled", "max_queue", 50)

    @property
    def export_max_concurrent(self) -> int: return self._type_int("export", "max_concurrent", 8)
    @property
    def export_default_timeout(self) -> int: return self._type_int("export", "default_timeout", 900)
    @property
    def export_max_queue(self) -> int: return self._type_int("export", "max_queue", 30)

    @property
    def system_max_concurrent(self) -> int: return self._type_int("system", "max_concurrent", 10)
    @property
    def system_default_timeout(self) -> int: return self._type_int("system", "default_timeout", 300)
    @property
    def system_max_queue(self) -> int: return self._type_int("system", "max_queue", 50)

    # Phase 98-A: Published Views API worker pool
    @property
    def published_api_max_concurrent(self) -> int: return self._type_int("published_api", "max_concurrent", 50)
    @property
    def published_api_default_timeout(self) -> int: return self._type_int("published_api", "default_timeout", 1800)
    @property
    def published_api_max_queue(self) -> int: return self._type_int("published_api", "max_queue", 200)

    # Phase 142+: Result-size safety cap.  When > 0, Published API endpoints
    # truncate result sets to this many rows + return a `truncated: true`
    # flag in the response.  Protects against memory exhaustion on cross-
    # connection JOINs that produce 10M+ rows.  Default 0 = no cap (preserves
    # existing consumer behavior).  Recommended for prod: 100_000-1_000_000.
    @property
    def published_api_max_result_rows(self) -> int:
        return self._type_int("published_api", "max_result_rows", 0)

    def build_type_configs(self) -> dict:
        """Build a WorkType → TypeConfig dict for WorkerPool init."""
        from core.worker_pool import WorkType, TypeConfig
        return {
            WorkType.INTERACTIVE:   TypeConfig(self.interactive_max_concurrent,   self.interactive_default_timeout,   self.interactive_max_queue),
            WorkType.REPORT:        TypeConfig(self.report_max_concurrent,        self.report_default_timeout,        self.report_max_queue),
            WorkType.SCHEDULED:     TypeConfig(self.scheduled_max_concurrent,     self.scheduled_default_timeout,     self.scheduled_max_queue),
            WorkType.EXPORT:        TypeConfig(self.export_max_concurrent,        self.export_default_timeout,        self.export_max_queue),
            WorkType.SYSTEM:        TypeConfig(self.system_max_concurrent,        self.system_default_timeout,        self.system_max_queue),
            WorkType.PUBLISHED_API: TypeConfig(self.published_api_max_concurrent, self.published_api_default_timeout, self.published_api_max_queue),
        }


class _LimitsCfg:
    @property
    def max_stream_files(self) -> int:
        return int(get("limits", "max_stream_files", 200))
    @property
    def max_registered_files(self) -> int:
        # BF-579 (2026-05-29): hard cap on file count for the
        # non-streaming BQB/feed Iceberg registered-views path.
        # 2026-06-04 — default 1000 → 5000 (see _DEFAULTS for full
        # reasoning).  Set 0 to disable (legacy uncapped behaviour).
        return int(get("limits", "max_registered_files", 5000))
    @property
    def stream_query_limit_default(self) -> int:
        return int(get("limits", "stream_query_limit_default", 500))
    @property
    def stream_query_limit_max(self) -> int:
        return int(get("limits", "stream_query_limit_max", 5000))
    @property
    def stream_page_size_default(self) -> int:
        return int(get("limits", "stream_page_size_default", 100))
    @property
    def stream_page_size_max(self) -> int:
        return int(get("limits", "stream_page_size_max", 5000))
    @property
    def stream_chart_top_n(self) -> int:
        return int(get("limits", "stream_chart_top_n", 50))
    @property
    def stream_chart_max_series(self) -> int:
        return int(get("limits", "stream_chart_max_series", 10))
    @property
    def max_upload_size_bytes(self) -> int:
        return int(get("limits", "max_upload_size_mb", 1024)) * 1024 * 1024
    @property
    def max_display_cols(self) -> int:
        return int(get("limits", "max_display_cols", 50))
    @property
    def col_auto_project(self) -> int:
        return int(get("limits", "col_auto_project", 50))
    @property
    def default_query_limit(self) -> int:
        return int(get("limits", "default_query_limit", 1000))
    @property
    def streaming_default_on(self) -> bool:
        return bool(get("limits", "streaming_default_on", False))
    @property
    def stream_bg_download_default(self) -> bool:
        return bool(get("limits", "stream_bg_download_default", True))
    @property
    def error_message_max_length(self) -> int:
        return int(get("limits", "error_message_max_length", 300))
    @property
    def metadata_cache_ttl(self) -> int:
        return int(get("limits", "metadata_cache_ttl", 7200))


class _QueryGuardrailsCfg:
    """Typed accessors for the ``query_guardrails`` config section."""
    @property
    def enabled(self) -> bool: return bool(get("query_guardrails", "enabled", True))
    @property
    def max_files_warn(self) -> int: return int(get("query_guardrails", "max_files_warn", 500))
    @property
    def max_files_block(self) -> int: return int(get("query_guardrails", "max_files_block", 5000))
    @property
    def max_rows_warn(self) -> int: return int(get("query_guardrails", "max_rows_warn", 10_000_000))
    @property
    def max_rows_block(self) -> int: return int(get("query_guardrails", "max_rows_block", 100_000_000))
    @property
    def require_partition_filter(self) -> bool: return bool(get("query_guardrails", "require_partition_filter", True))
    @property
    def warn_no_partition(self) -> bool: return bool(get("query_guardrails", "warn_no_partition", True))
    @property
    def warn_no_limit(self) -> bool: return bool(get("query_guardrails", "warn_no_limit", True))
    @property
    def default_limit_suggestion(self) -> int: return int(get("query_guardrails", "default_limit_suggestion", 1000))
    # ── Phase 107-B: detection-first S3 partition pruning ──
    @property
    def s3_full_scan_action(self) -> str:
        v = str(get("query_guardrails", "s3_full_scan_action", "block") or "block").lower()
        return v if v in ("log", "warn", "block") else "block"
    @property
    def s3_full_scan_min_files(self) -> int: return int(get("query_guardrails", "s3_full_scan_min_files", 50))
    @property
    def post_exec_detection(self) -> bool: return bool(get("query_guardrails", "post_exec_detection", True))


query_guardrails = _QueryGuardrailsCfg()


class _FeaturesCfg:
    @property
    def streaming_mode(self) -> str:
        return get("features", "streaming_mode", "all")

    def _parse_roles(self, key: str, default: str) -> list:
        raw = get("features", key, default)
        return [r.strip().lower() for r in raw.split(",") if r.strip()]

    @property
    def streaming_enabled_roles(self) -> list:
        return self._parse_roles("streaming_enabled_roles", "admin,analyst,viewer")
    @property
    def export_enabled_roles(self) -> list:
        return self._parse_roles("export_enabled_roles", "admin,analyst,viewer")
    @property
    def sql_editor_enabled_roles(self) -> list:
        return self._parse_roles("sql_editor_enabled_roles", "admin,analyst")
    @property
    def scheduler_enabled_roles(self) -> list:
        return self._parse_roles("scheduler_enabled_roles", "admin,analyst")
    @property
    def connections_enabled_roles(self) -> list:
        return self._parse_roles("connections_enabled_roles", "admin,analyst")
    @property
    def upload_enabled_roles(self) -> list:
        return self._parse_roles("upload_enabled_roles", "admin,analyst")
    @property
    def max_query_limit_by_role(self) -> dict:
        raw = get("features", "max_query_limit_by_role", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                r, v = pair.split(":", 1)
                try:
                    result[r.strip().lower()] = int(v.strip())
                except ValueError:
                    pass
        return result


class _CircuitBreakerCfg:
    @property
    def enabled(self) -> bool: return bool(get("circuit_breaker", "enabled", True))
    @property
    def failure_threshold(self) -> int: return int(get("circuit_breaker", "failure_threshold", 3))
    @property
    def cooldown_seconds(self) -> int: return int(get("circuit_breaker", "cooldown_seconds", 60))
    @property
    def max_cooldown_seconds(self) -> int: return int(get("circuit_breaker", "max_cooldown_seconds", 300))


class _ConnectionPoolCfg:
    @property
    def enabled(self) -> bool: return bool(get("connection_pool", "enabled", True))
    @property
    def max_size(self) -> int: return int(get("connection_pool", "max_size", 5))
    @property
    def idle_timeout_seconds(self) -> int: return int(get("connection_pool", "idle_timeout_seconds", 300))


class _LocalTablesCfg:
    @property
    def storage_dir(self) -> str:
        return str(get("local_tables", "storage_dir", "/usr/local/querystudioapi/nfs/data/local_tables"))
    @property
    def max_size_mb(self) -> int:
        return int(get("local_tables", "max_size_mb", 10240))
    @property
    def max_tables(self) -> int:
        return int(get("local_tables", "max_tables", 100))
    @property
    def auto_discard_days(self) -> int:
        return int(get("local_tables", "auto_discard_days", 10))
    @property
    def max_upload_size_mb(self) -> int:
        return int(get("local_tables", "max_upload_size_mb", 1024))
    @property
    def max_upload_size_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024
    @property
    def cleanup_interval_hours(self) -> int:
        return int(get("local_tables", "cleanup_interval_hours", 6))


class _MaterializedViewsCfg:
    @property
    def storage_dir(self) -> str:
        return str(get("materialized_views", "storage_dir", "/usr/local/querystudioapi/nfs/data/materialized"))
    @property
    def max_size_mb(self) -> int:
        return int(get("materialized_views", "max_size_mb", 10240))
    @property
    def max_views(self) -> int:
        return int(get("materialized_views", "max_views", 50))
    @property
    def refresh_timeout_seconds(self) -> int:
        return int(get("materialized_views", "refresh_timeout_seconds", 3600))
    @property
    def chunk_size(self) -> int:
        return int(get("materialized_views", "chunk_size", 500000))


class _FederationViewsCfg:
    """Typed accessors for the ``federation_views`` config section (Phase 97)."""
    @property
    def storage_dir(self) -> str:
        return str(get("federation_views", "storage_dir", "/usr/local/querystudioapi/nfs/data/federation_views"))
    @property
    def max_nesting_depth(self) -> int:
        return int(get("federation_views", "max_nesting_depth", 3))
    @property
    def materialization_timeout(self) -> int:
        return int(get("federation_views", "materialization_timeout", 1800))
    @property
    def auto_cache_schema(self) -> bool:
        return bool(get("federation_views", "auto_cache_schema", True))
    @property
    def chunk_size(self) -> int:
        return int(get("federation_views", "chunk_size", 500000))


federation_views_cfg = _FederationViewsCfg()


class _DataQualityCfg:
    """Typed accessors for the ``data_quality`` config section (Phase 99)."""
    @property
    def enabled(self) -> bool: return bool(get("data_quality", "enabled", True))
    @property
    def schedule_interval_minutes(self) -> int: return int(get("data_quality", "schedule_interval_minutes", 60))
    @property
    def execution_timeout_seconds(self) -> int: return int(get("data_quality", "execution_timeout_seconds", 300))
    @property
    def result_retention_days(self) -> int: return int(get("data_quality", "result_retention_days", 90))
    @property
    def max_rules(self) -> int: return int(get("data_quality", "max_rules", 200))
    @property
    def max_concurrent_checks(self) -> int: return int(get("data_quality", "max_concurrent_checks", 5))
    @property
    def notify_on_failure(self) -> bool: return bool(get("data_quality", "notify_on_failure", True))
    @property
    def notify_severity_threshold(self) -> str: return str(get("data_quality", "notify_severity_threshold", "warning"))
    @property
    def cleanup_interval_hours(self) -> int: return int(get("data_quality", "cleanup_interval_hours", 6))
    @property
    def alert_channels(self) -> list: return list(get("data_quality", "alert_channels", []))
    @property
    def alert_cooldown_minutes(self) -> int: return int(get("data_quality", "alert_cooldown_minutes", 60))


data_quality = _DataQualityCfg()


class _CollaborationCfg:
    """Typed accessors for the ``collaboration`` config section (Phase 114)."""
    @property
    def enabled(self) -> bool: return bool(get("collaboration", "enabled", True))
    @property
    def max_comments_per_report(self) -> int: return int(get("collaboration", "max_comments_per_report", 500))
    @property
    def change_log_retention_days(self) -> int: return int(get("collaboration", "change_log_retention_days", 365))
    @property
    def mentions_enabled(self) -> bool: return bool(get("collaboration", "mentions_enabled", True))


collaboration = _CollaborationCfg()


class _QueueCfg:
    @property
    def backend(self) -> str:
        return str(get("queue", "backend", "sqlite")).lower()
    @property
    def redis_url(self) -> str:
        return str(get("queue", "redis_url", "redis://localhost:6379/0"))
    @property
    def redis_password(self) -> str:
        return str(get("queue", "redis_password", ""))
    @property
    def redis_db(self) -> int:
        return int(get("queue", "redis_db", 0))
    @property
    def redis_ssl(self) -> bool:
        v = get("queue", "redis_ssl", False)
        if isinstance(v, str):
            return v.lower() in ("true", "1", "yes")
        return bool(v)
    @property
    def key_prefix(self) -> str:
        return str(get("queue", "key_prefix", "qs"))
    @property
    def task_ttl_hours(self) -> int:
        return int(get("queue", "task_ttl_hours", 24))
    @property
    def rate_limit_store(self) -> str:
        return str(get("queue", "rate_limit_store", "shared") or "shared").strip().lower()
    @property
    def rate_limit_window_retention_seconds(self) -> int:
        return int(get("queue", "rate_limit_window_retention_seconds", 3600) or 0)


class _ExecutorCfg:
    @property
    def mode(self) -> str:
        return str(get("executor", "mode", "embedded"))
    @property
    def worker_port(self) -> int:
        return int(get("executor", "worker_port", 8002))
    @property
    def worker_host(self) -> str:
        return str(get("executor", "worker_host", "127.0.0.1"))
    @property
    def poll_interval(self) -> float:
        return float(get("executor", "poll_interval", 1.0))
    @property
    def notification_poll_interval(self) -> float:
        return float(get("executor", "notification_poll_interval", 1.0))
    @property
    def max_concurrent(self) -> int:
        return int(get("executor", "max_concurrent", 10))
    @property
    def stale_timeout_seconds(self) -> int:
        return int(get("executor", "stale_timeout_seconds", 600))
    @property
    def cleanup_interval_hours(self) -> int:
        return int(get("executor", "cleanup_interval_hours", 1))
    @property
    def task_retention_hours(self) -> int:
        return int(get("executor", "task_retention_hours", 24))
    @property
    def max_memory_per_task_gb(self) -> int:
        return int(get("executor", "max_memory_per_task_gb", 4))
    @property
    def worker_url(self) -> str:
        return f"http://{self.worker_host}:{self.worker_port}"


class _AnomalyDetectionCfg:
    @property
    def enabled(self) -> bool: return bool(get("anomaly_detection", "enabled", True))
    @property
    def z_score_threshold(self) -> float: return float(get("anomaly_detection", "z_score_threshold", 2.5))
    @property
    def min_history_runs(self) -> int: return int(get("anomaly_detection", "min_history_runs", 5))
    @property
    def window_size(self) -> int: return int(get("anomaly_detection", "window_size", 20))


class _LineageCfg:
    @property
    def auto_extract(self) -> bool: return bool(get("lineage", "auto_extract", True))
    @property
    def fallback_regex(self) -> bool: return bool(get("lineage", "fallback_regex", True))
    @property
    def max_reparse_batch(self) -> int: return int(get("lineage", "max_reparse_batch", 500))
    @property
    def snapshots_enabled(self) -> bool: return bool(get("lineage", "snapshots_enabled", True))
    @property
    def freshness_enabled(self) -> bool: return bool(get("lineage", "freshness_enabled", True))
    @property
    def snapshot_retention_days(self) -> int: return int(get("lineage", "snapshot_retention_days", 30))
    @property
    def default_stale_threshold_hours(self) -> int: return int(get("lineage", "default_stale_threshold_hours", 24))


class _SemanticLayerCfg:
    @property
    def enabled(self) -> bool: return bool(get("semantic_layer", "enabled", True))
    @property
    def auto_detect_column_types(self) -> bool: return bool(get("semantic_layer", "auto_detect_column_types", True))
    @property
    def max_columns_per_dataset(self) -> int: return int(get("semantic_layer", "max_columns_per_dataset", 500))
    @property
    def max_datasets(self) -> int: return int(get("semantic_layer", "max_datasets", 100))
    @property
    def max_datasets_per_user(self) -> int: return int(get("semantic_layer", "max_datasets_per_user", 10))
    @property
    def cascading_prompts_enabled(self) -> bool: return bool(get("semantic_layer", "cascading_prompts_enabled", True))
    @property
    def drill_hierarchies_enabled(self) -> bool: return bool(get("semantic_layer", "drill_hierarchies_enabled", True))
    @property
    def aggregation_awareness_enabled(self) -> bool: return bool(get("semantic_layer", "aggregation_awareness_enabled", True))
    @property
    def default_row_limit(self) -> int: return int(get("semantic_layer", "default_row_limit", 10000))
    @property
    def synonym_matching_enabled(self) -> bool: return bool(get("semantic_layer", "synonym_matching_enabled", True))
    @property
    def max_metrics_per_dataset(self) -> int: return int(get("semantic_layer", "max_metrics_per_dataset", 50))
    @property
    def metric_validation_enabled(self) -> bool: return bool(get("semantic_layer", "metric_validation_enabled", True))
    @property
    def max_union_datasets(self) -> int: return int(get("semantic_layer", "max_union_datasets", 10))


class _ChatbotCfg:
    """Column classification patterns for the AI Assistant chip suggestions."""

    @property
    def numeric_patterns(self) -> list:
        v = get("chatbot", "numeric_patterns", [])
        return v if isinstance(v, list) else [s.strip() for s in str(v).split(",") if s.strip()]

    @property
    def category_patterns(self) -> list:
        v = get("chatbot", "category_patterns", [])
        return v if isinstance(v, list) else [s.strip() for s in str(v).split(",") if s.strip()]

    @property
    def date_patterns(self) -> list:
        v = get("chatbot", "date_patterns", [])
        return v if isinstance(v, list) else [s.strip() for s in str(v).split(",") if s.strip()]

    @property
    def id_patterns(self) -> list:
        v = get("chatbot", "id_patterns", [])
        return v if isinstance(v, list) else [s.strip() for s in str(v).split(",") if s.strip()]

    @property
    def faq(self) -> dict:
        """Keyword→answer map for the AI Assistant chatbot."""
        v = get("chatbot", "faq", {})
        return {k: v2 for k, v2 in v.items() if not k.startswith("_comment")} if isinstance(v, dict) else {}

    @property
    def glossary(self) -> dict:
        """Business term→SQL fragment map applied before NL-to-SQL pattern matching."""
        v = get("chatbot", "glossary", {})
        return {k: v2 for k, v2 in v.items() if not k.startswith("_comment")} if isinstance(v, dict) else {}

    # Phase 57 — Enhanced NL Chatbot
    @property
    def semantic_context_enabled(self) -> bool:
        return bool(get("chatbot", "semantic_context_enabled", True))

    @property
    def time_intelligence_enabled(self) -> bool:
        return bool(get("chatbot", "time_intelligence_enabled", True))

    @property
    def max_pattern_alternatives(self) -> int:
        return int(get("chatbot", "max_pattern_alternatives", 3))


class _SuggestionCorrectionsCfg:
    """Typed accessors for the ``suggestion_corrections`` config section."""
    @property
    def enabled(self) -> bool: return bool(get("suggestion_corrections", "enabled", True))
    @property
    def max_corrections(self) -> int: return int(get("suggestion_corrections", "max_corrections", 1000))
    @property
    def agg_pattern_priority(self) -> bool: return bool(get("suggestion_corrections", "agg_pattern_priority", True))
    @property
    def join_correction_priority(self) -> bool: return bool(get("suggestion_corrections", "join_correction_priority", True))
    @property
    def retention_days(self) -> int: return int(get("suggestion_corrections", "retention_days", 365))
    @property
    def nl_feedback_lookup_enabled(self) -> bool: return bool(get("suggestion_corrections", "nl_feedback_lookup_enabled", True))
    @property
    def nl_feedback_min_similarity(self) -> float: return float(get("suggestion_corrections", "nl_feedback_min_similarity", 0.8))
    @property
    def nl_feedback_auto_return_threshold(self) -> float: return float(get("suggestion_corrections", "nl_feedback_auto_return_threshold", 0.9))


def reload():
    """Reload config from disk — called after admin changes config.json."""
    global _file_cfg, _merged, _cfg
    _file_cfg = _load_file()
    _merged = _deep_merge(_DEFAULTS, _file_cfg)
    _cfg = _apply_env(_merged)
    logger.info("Config reloaded from %s", _CONFIG_FILE)


server        = _ServerCfg()
paths         = _PathsCfg()
database      = _DatabaseCfg()
auth          = _AuthCfg()
query_engine  = _QueryEngineCfg()
s3            = _S3Cfg()
s3_local_cache = _S3LocalCacheCfg()
s3_results    = _S3ResultsCfg()
scheduler     = _SchedulerCfg()
cors          = _CorsCfg()
email         = _EmailCfg()
cache         = _CacheCfg()
storage       = _StorageCfg()
worker_pool   = _WorkerPoolCfg()
limits        = _LimitsCfg()
features      = _FeaturesCfg()
circuit_breaker = _CircuitBreakerCfg()
connection_pool = _ConnectionPoolCfg()
materialized_views = _MaterializedViewsCfg()
local_tables  = _LocalTablesCfg()
queue         = _QueueCfg()
executor      = _ExecutorCfg()
anomaly_detection = _AnomalyDetectionCfg()
lineage       = _LineageCfg()
semantic_layer = _SemanticLayerCfg()


class _FederationCfg:
    """Typed accessors for the ``federation`` config section."""
    @property
    def enabled(self) -> bool: return bool(get("federation", "enabled", True))
    @property
    def max_concurrent_executions(self) -> int: return int(get("federation", "max_concurrent_executions", 5))
    @property
    def execution_timeout_seconds(self) -> int: return int(get("federation", "execution_timeout_seconds", 600))
    @property
    def max_result_rows(self) -> int: return int(get("federation", "max_result_rows", 0))   # 2026-08-20: fallback was 500000 while _DEFAULTS declares 0 -- inert while declared, an instant SILENT cap if the declaration is ever removed
    @property
    def named_secrets_enabled(self) -> bool: return bool(get("federation", "named_secrets_enabled", True))
    @property
    def fallback_to_pragmas(self) -> bool: return bool(get("federation", "fallback_to_pragmas", True))
    @property
    def execution_history_retention_days(self) -> int: return int(get("federation", "execution_history_retention_days", 30))
    @property
    def merge_max_datasets(self) -> int: return int(get("federation", "merge_max_datasets", 5))
    @property
    def preview_row_limit(self) -> int: return int(get("federation", "preview_row_limit", 100))
    @property
    def distinct_values_limit(self) -> int: return int(get("federation", "distinct_values_limit", 500))
    @property
    def http_timeout_ms(self) -> int: return int(get("federation", "http_timeout_ms", 30000))

    @property
    def http_timeout_seconds(self) -> int:
        """``http_timeout_ms`` in the unit DuckDB actually reads.

        2026-09-21 -- DuckDB's ``http_timeout`` is documented and measured
        as SECONDS ("HTTP timeout read/write/connection/retry (in
        seconds)", default 30).  Two call sites passed the MILLISECOND
        value straight through, so ``SET http_timeout=15000`` asked for
        15,000 seconds -- FOUR HOURS AND TEN MINUTES -- and a hung read
        effectively never timed out.  Confirmed on the shipped image:
        after SET 15000, duckdb_settings() reports 15000.

        The declared default moves 15000 -> 30000 deliberately, and the
        number is not invented: 30s is DuckDB's OWN default for this
        setting.  Honouring the old 15000 as 15s would have been tighter
        than the engine ships, which is a regression risk on a slow S3
        read that nothing here can measure.  Finite and equal to the
        engine default is the conservative repair.

        Floors at 1s: a sub-second ms value must not round down to 0,
        which DuckDB would read as 'no timeout' -- the bug again.
        """
        return max(1, round(self.http_timeout_ms / 1000))


federation = _FederationCfg()


class _AggCacheCfg:
    """Typed accessors for the ``agg_cache`` config section."""
    @property
    def enabled(self) -> bool: return bool(get("agg_cache", "enabled", True))
    @property
    def storage_dir(self) -> str: return str(get("agg_cache", "storage_dir", "/usr/local/querystudioapi/nfs/data/agg_cache"))
    @property
    def max_storage_mb(self) -> int: return int(get("agg_cache", "max_storage_mb", 5120))
    @property
    def max_entries_per_dataset(self) -> int: return int(get("agg_cache", "max_entries_per_dataset", 20))
    @property
    def default_ttl_hours(self) -> int: return int(get("agg_cache", "default_ttl_hours", 24))
    @property
    def hard_expiry_hours(self) -> int: return int(get("agg_cache", "hard_expiry_hours", 72))
    @property
    def stale_serve_enabled(self) -> bool: return bool(get("agg_cache", "stale_serve_enabled", True))
    @property
    def write_through_enabled(self) -> bool: return bool(get("agg_cache", "write_through_enabled", True))  # 2026-09-15: fallback aligned to the DECLARED default.  They must stay identical (core/config.py:1262) -- a fallback that differs is a behaviour flip waiting for the key to be dropped, which is exactly how the iceberg snapshot indexer could re-arm itself.
    @property
    def refresh_timeout_seconds(self) -> int: return int(get("agg_cache", "refresh_timeout_seconds", 1800))
    @property
    def cleanup_interval_hours(self) -> int: return int(get("agg_cache", "cleanup_interval_hours", 6))
    @property
    def suggestion_enabled(self) -> bool: return bool(get("agg_cache", "suggestion_enabled", True))
    @property
    def suggestion_min_queries(self) -> int: return int(get("agg_cache", "suggestion_min_queries", 5))
    @property
    def suggestion_analysis_window_days(self) -> int: return int(get("agg_cache", "suggestion_analysis_window_days", 7))
    @property
    def incremental_default(self) -> bool: return bool(get("agg_cache", "incremental_default", False))
    @property
    def rls_serving_enabled(self) -> bool: return bool(get("agg_cache", "rls_serving_enabled", False))
    # Phase 7 — AggregationAwareness (customer pre-agg tables).  LOCKSTEP:
    # these fallbacks MUST match _DEFAULTS exactly (class docstring rule).
    @property
    def agg_awareness_serving_enabled(self) -> bool: return bool(get("agg_cache", "agg_awareness_serving_enabled", False))
    @property
    def agg_awareness_reverify_hours(self) -> int: return int(get("agg_cache", "agg_awareness_reverify_hours", 24))
    @property
    def agg_awareness_tolerance(self) -> float: return float(get("agg_cache", "agg_awareness_tolerance", 1e-6))
    # Phase 6 — cube adoption.
    @property
    def auto_adopt_enabled(self) -> bool: return bool(get("agg_cache", "auto_adopt_enabled", False))
    @property
    def auto_adopt_max_per_run(self) -> int: return int(get("agg_cache", "auto_adopt_max_per_run", 3))
    @property
    def auto_adopt_interval_hours(self) -> int: return int(get("agg_cache", "auto_adopt_interval_hours", 24))
    @property
    def recommendation_history_limit(self) -> int: return int(get("agg_cache", "recommendation_history_limit", 2000))


agg_cache = _AggCacheCfg()


class _AWSPortalCfg:
    """Typed accessors for the ``aws_portal`` config section."""
    @property
    def enabled(self) -> bool: return bool(get("aws_portal", "enabled", False))
    @property
    def portal_base_url(self) -> str: return str(get("aws_portal", "portal_base_url", ""))
    @property
    def jwt_url(self) -> str: return str(get("aws_portal", "jwt_url", ""))
    @property
    def creds_url_template(self) -> str: return str(get("aws_portal", "creds_url_template", ""))
    @property
    def account_id(self) -> str: return str(get("aws_portal", "account_id", ""))
    @property
    def role_name(self) -> str: return str(get("aws_portal", "role_name", ""))
    @property
    def sf_ref_no(self) -> str: return str(get("aws_portal", "sf_ref_no", ""))
    @property
    def service_username(self) -> str: return str(get("aws_portal", "service_username", ""))
    @property
    def service_password(self) -> str: return str(get("aws_portal", "service_password", ""))
    @property
    def service_system_account_id(self) -> int: return int(get("aws_portal", "service_system_account_id", 0) or 0)
    @property
    def proxy_url(self) -> str: return str(get("aws_portal", "proxy_url", ""))
    @property
    def proxy_host(self) -> str: return str(get("aws_portal", "proxy_host", ""))
    @property
    def proxy_port(self) -> int: return int(get("aws_portal", "proxy_port", 8080))
    @property
    def proxy_username(self) -> str: return str(get("aws_portal", "proxy_username", ""))
    @property
    def proxy_password(self) -> str: return str(get("aws_portal", "proxy_password", ""))
    @property
    def proxy_url_resolved(self) -> str:
        """Build proxy URL from separate fields, or fall back to proxy_url."""
        host = self.proxy_host
        if host:
            user = self.proxy_username
            passwd = self.proxy_password
            port = self.proxy_port
            if user:
                # 2026-10-28: encoded.  A password holding @ : or / was put in
                # the URL as typed, so the parser read part of it as the HOST
                # ("failed to resolve") -- the Admin reachability probe encoded
                # it and passed.  unquote first: a value already %-encoded is
                # not encoded twice.
                from urllib.parse import quote, unquote
                user = quote(unquote(str(user)), safe="")
                passwd = quote(unquote(str(passwd or "")), safe="")
                return f"http://{user}:{passwd}@{host}:{port}"
            return f"http://{host}:{port}"
        return self.proxy_url
    @property
    def verify_ssl(self) -> bool: return bool(get("aws_portal", "verify_ssl", False))
    @property
    def creds_ttl_seconds(self) -> int: return int(get("aws_portal", "creds_ttl_seconds", 3300))
    @property
    def timeout_seconds(self) -> int: return int(get("aws_portal", "timeout_seconds", 30))
    @property
    def auto_retry_on_expiry(self) -> bool: return bool(get("aws_portal", "auto_retry_on_expiry", True))
    @property
    def max_retry_attempts(self) -> int: return int(get("aws_portal", "max_retry_attempts", 1))
    @property
    def system_account_fallback(self) -> bool: return bool(get("aws_portal", "system_account_fallback", True))
    @property
    def preflight_min_lifetime_seconds(self) -> int:
        """BF-461 (2026-05-19) — preflight refresh threshold.

        Long-running operations (feed gen, cross-source, raw-SQL streaming,
        Published Views, federation materialization) pass this value to
        ``resolve_s3_for_consumer(..., min_lifetime_seconds=...)`` so the
        cache returns ``None`` for creds within this window of expiry,
        forcing a fresh ~1h-TTL session BEFORE the operation begins.

        Default 600 seconds (10 minutes) — leaves headroom for the slowest
        expected feed run.  Set to 0 to disable preflight refresh.
        """
        return int(get("aws_portal", "preflight_min_lifetime_seconds", 600))


aws_portal = _AWSPortalCfg()


class _ProxyCfg:
    """Typed accessors for the ``proxy`` config section (Phase 119).

    Controls corporate proxy injection for boto3, DuckDB httpfs, httpx,
    and requests.  On-prem deployments leave ``enabled=False`` (the default)
    so nothing changes.  AWS-connected OpenShift pods set ``enabled=True``
    plus the proxy URL/host fields.
    """
    @property
    def enabled(self) -> bool: return bool(get("proxy", "enabled", False))
    @property
    def url(self) -> str: return str(get("proxy", "url", ""))
    @property
    def host(self) -> str: return str(get("proxy", "host", ""))
    @property
    def port(self) -> int: return int(get("proxy", "port", 8080))
    @property
    def system_account(self) -> str: return str(get("proxy", "system_account", ""))
    @property
    def no_proxy(self) -> str: return str(get("proxy", "no_proxy", ""))
    @property
    def auto_bypass_custom_endpoint(self) -> bool:
        return bool(get("proxy", "auto_bypass_custom_endpoint", True))
    @property
    def apply_to_boto3(self) -> bool: return bool(get("proxy", "apply_to_boto3", True))
    @property
    def apply_to_duckdb(self) -> bool: return bool(get("proxy", "apply_to_duckdb", True))
    @property
    def apply_to_httpx(self) -> bool: return bool(get("proxy", "apply_to_httpx", True))

    @property
    def url_resolved(self) -> str:
        """Return base proxy URL — from ``url`` field, or built from ``host:port``.

        For authenticated proxies, set ``system_account`` to a system account name
        (Admin > System Accounts, type ``proxy``).  Credentials are encrypted in DB
        and injected at runtime by ``proxy_utils._resolve_proxy_url()``.
        """
        host = self.host
        if host:
            return f"http://{host}:{self.port}"
        return self.url


proxy_cfg = _ProxyCfg()


class _BusinessReportsCfg:
    """Typed accessors for the ``business_reports`` config section (Phase 81 extended).

    2026-08-09: every key below exists in ``_DEFAULTS``, so ``get()`` always
    resolves from the merged dict and the per-property fallback is DEAD CODE —
    but it must still MATCH ``_DEFAULTS`` or a reader chasing the property
    sees a phantom limit (the 500000-vs-50000 ``default_row_limit`` case,
    docs/reports_audit_exec_scale_2026_08_08.md §3).  The documented stale
    pairs are aligned; keep both sides in lockstep when editing either.
    (``share_export_*`` fallbacks are LIVE — those keys are not in
    ``_DEFAULTS``.)
    """
    @property
    def enabled(self) -> bool: return bool(get("business_reports", "enabled", True))
    @property
    def max_reports_per_user(self) -> int: return int(get("business_reports", "max_reports_per_user", 50))
    @property
    def max_sections_per_report(self) -> int: return int(get("business_reports", "max_sections_per_report", 10))
    @property
    def max_parameters_per_report(self) -> int: return int(get("business_reports", "max_parameters_per_report", 20))
    @property
    def max_running_calcs_per_report(self) -> int: return int(get("business_reports", "max_running_calcs_per_report", 15))
    @property
    def default_row_limit(self) -> int: return int(get("business_reports", "default_row_limit", 0))
    @property
    def pdf_row_limit(self) -> int: return int(get("business_reports", "pdf_row_limit", 5000))
    # 2026-10-04 PDF memory ceiling + render isolation (LOCKSTEP with _DEFAULTS).
    @property
    def pdf_max_rows(self) -> int: return int(get("business_reports", "pdf_max_rows", 5000))
    @property
    def pdf_render_isolation(self) -> str: return str(get("business_reports", "pdf_render_isolation", "subprocess"))
    @property
    def pdf_render_memory_mb(self) -> int: return int(get("business_reports", "pdf_render_memory_mb", 1024))
    @property
    def pdf_render_timeout_seconds(self) -> int: return int(get("business_reports", "pdf_render_timeout_seconds", 600))
    @property
    def pdf_render_max_concurrent(self) -> int: return int(get("business_reports", "pdf_render_max_concurrent", 2))
    @property
    def excel_row_limit(self) -> int: return int(get("business_reports", "excel_row_limit", 1000000))
    @property
    def csv_row_limit(self) -> int: return int(get("business_reports", "csv_row_limit", 0))
    @property
    def excel_styled_max_rows(self) -> int: return int(get("business_reports", "excel_styled_max_rows", 50000))
    @property
    def export_materialize_cap(self) -> int: return int(get("business_reports", "export_materialize_cap", 1000000))
    @property
    def embed_row_limit(self) -> int: return int(get("business_reports", "embed_row_limit", 100000))
    @property
    def cascade_lov_limit(self) -> int: return int(get("business_reports", "cascade_lov_limit", 500))
    @property
    def lov_cache_seconds(self) -> int: return int(get("business_reports", "lov_cache_seconds", 300))
    @property
    def page_size(self) -> int: return int(get("business_reports", "page_size", 200))
    @property
    def max_page_size(self) -> int: return int(get("business_reports", "max_page_size", 10000))
    @property
    def auto_save_interval_seconds(self) -> int: return int(get("business_reports", "auto_save_interval_seconds", 30))
    @property
    def export_formats(self) -> list:
        # Fallback MUST equal the declared default (core/config.py:1262):
        # a fallback that differs silently changes behaviour the moment the
        # key is dropped.  The old pair agreed on ["csv", "json"] and both
        # were wrong about the surface; they now agree on what is served.
        return list(get("business_reports", "export_formats",
                        ["pdf", "excel", "csv"]))
    @property
    def async_execution_ttl_seconds(self) -> int: return int(get("business_reports", "async_execution_ttl_seconds", 3600))
    # 2026-09-28: the async run's wait for global capacity (LOCKSTEP with _DEFAULTS: 120).
    @property
    def async_capacity_wait_seconds(self) -> int: return int(get("business_reports", "async_capacity_wait_seconds", 120))
    # 2026-08-09 cross-pod completion #3 — referenced-artifact retention CAP
    # for the temp-file cleaner (LOCKSTEP with _DEFAULTS: 21600 = 6 h).
    @property
    def artifact_retention_seconds(self) -> int: return int(get("business_reports", "artifact_retention_seconds", 21600))
    @property
    def pdf_page_size(self) -> str: return str(get("business_reports", "pdf_page_size", "A4 landscape"))
    @property
    def pdf_primary_color(self) -> str: return str(get("business_reports", "pdf_primary_color", "#1976d2"))
    @property
    def enable_published_view_source(self) -> bool: return bool(get("business_reports", "enable_published_view_source", True))
    @property
    def share_export_enabled(self) -> bool: return bool(get("business_reports", "share_export_enabled", True))
    @property
    def share_export_row_limit(self) -> int: return int(get("business_reports", "share_export_row_limit", 10000))
    # 2026-08-09 reports rewire Phase 1 — microcube resource CAPS (throttle,
    # never refuse; invalid values fall back inside microcube._connect).
    @property
    def microcube_threads(self) -> int: return int(get("business_reports", "microcube_threads", 4))
    @property
    def microcube_memory_limit(self) -> str: return str(get("business_reports", "microcube_memory_limit", "2GB"))
    @property
    def client_engine_max_rows(self) -> int: return int(get("business_reports", "client_engine_max_rows", 50000))
    # 2026-08-09 reports rewire Phase 2 — instance serving (ships OFF).
    # LOCKSTEP RULE (class docstring): the fallbacks below MUST match
    # _DEFAULTS exactly.
    @property
    def progressive_stream_parts(self) -> bool: return bool(get("business_reports", "progressive_stream_parts", False))
    @property
    def instance_serving_enabled(self) -> bool: return bool(get("business_reports", "instance_serving_enabled", True))
    @property
    def instance_retention_count(self) -> int: return int(get("business_reports", "instance_retention_count", 3))
    @property
    def instance_max_age_seconds(self) -> int: return int(get("business_reports", "instance_max_age_seconds", 86400))


class _PivotReportsCfg:
    """Typed accessors for the ``pivot_reports`` config section (Phase 106)."""
    @property
    def enabled(self) -> bool: return bool(get("pivot_reports", "enabled", True))
    @property
    def max_row_dimensions(self) -> int: return int(get("pivot_reports", "max_row_dimensions", 3))
    @property
    def max_col_dimensions(self) -> int: return int(get("pivot_reports", "max_col_dimensions", 2))
    @property
    def max_measures(self) -> int: return int(get("pivot_reports", "max_measures", 5))
    @property
    def max_row_groups(self) -> int: return int(get("pivot_reports", "max_row_groups", 500))
    @property
    def max_col_groups(self) -> int: return int(get("pivot_reports", "max_col_groups", 50))
    @property
    def default_aggregation(self) -> str: return str(get("pivot_reports", "default_aggregation", "sum"))


class _PartitionCacheCfg:
    """Typed accessors for the ``partition_cache`` config section."""
    @property
    def l1_ttl_seconds(self) -> int: return int(get("partition_cache", "l1_ttl_seconds", 300))
    @property
    def l2_ttl_seconds(self) -> int: return int(get("partition_cache", "l2_ttl_seconds", 18000))
    @property
    def l1_max_entries(self) -> int: return int(get("partition_cache", "l1_max_entries", 100))


class _ReportCatalogCfg:
    """Typed accessors for the ``report_catalog`` config section (Phase 58)."""
    @property
    def enabled(self) -> bool: return bool(get("report_catalog", "enabled", True))
    @property
    def certification_enabled(self) -> bool: return bool(get("report_catalog", "certification_enabled", True))
    @property
    def template_gallery_enabled(self) -> bool: return bool(get("report_catalog", "template_gallery_enabled", True))
    @property
    def sharing_enabled(self) -> bool: return bool(get("report_catalog", "sharing_enabled", True))
    @property
    def embed_enabled(self) -> bool: return bool(get("report_catalog", "embed_enabled", True))
    @property
    def max_shares_per_report(self) -> int: return int(get("report_catalog", "max_shares_per_report", 10))
    @property
    def max_embed_tokens_per_report(self) -> int: return int(get("report_catalog", "max_embed_tokens_per_report", 5))
    @property
    def share_default_expiry_hours(self) -> int: return int(get("report_catalog", "share_default_expiry_hours", 720))
    @property
    def embed_default_expiry_days(self) -> int: return int(get("report_catalog", "embed_default_expiry_days", 90))
    @property
    def template_categories(self) -> list: return list(get("report_catalog", "template_categories",
                                                           ["Sales", "Finance", "HR", "Operations", "Marketing", "Custom"]))


class _BusinessPortalCfg:
    """Typed accessors for the ``business_portal`` config section (Phase 59)."""
    @property
    def enabled(self) -> bool: return bool(get("business_portal", "enabled", True))
    @property
    def welcome_message(self) -> str: return str(get("business_portal", "welcome_message", "Welcome to QueryStudio"))
    @property
    def welcome_subtitle(self) -> str: return str(get("business_portal", "welcome_subtitle", "Your enterprise data platform"))
    @property
    def recent_reports_limit(self) -> int: return int(get("business_portal", "recent_reports_limit", 8))
    @property
    def favorites_limit(self) -> int: return int(get("business_portal", "favorites_limit", 12))
    @property
    def certified_templates_limit(self) -> int: return int(get("business_portal", "certified_templates_limit", 6))
    @property
    def recent_activity_limit(self) -> int: return int(get("business_portal", "recent_activity_limit", 10))
    @property
    def quick_actions_enabled(self) -> bool: return bool(get("business_portal", "quick_actions_enabled", True))
    @property
    def kpi_cards_enabled(self) -> bool: return bool(get("business_portal", "kpi_cards_enabled", True))


business_reports = _BusinessReportsCfg()


class _QueryPodsCfg:
    """Typed accessors for the ``query_pods`` section (2026-11-03).  The
    numeric knobs are read by ``core/query_pods/budget.py::cfg_number`` and the
    sizes by ``core/query_pods/classes.py::parse``; these two are read by the
    lane (``report_bridge.lane_enabled``) and the route decision
    (``execute_bridge.small_run_bytes``).  LOCKSTEP with ``_DEFAULTS["query_pods"]``."""
    @property
    def reports_lane(self) -> bool: return bool(get("query_pods", "reports_lane", False))
    @property
    def small_run_mb(self) -> int: return int(get("query_pods", "small_run_mb", 512))


query_pods = _QueryPodsCfg()
pivot_reports = _PivotReportsCfg()
chatbot       = _ChatbotCfg()
suggestion_corrections = _SuggestionCorrectionsCfg()
partition_cache = _PartitionCacheCfg()
report_catalog = _ReportCatalogCfg()
business_portal = _BusinessPortalCfg()


class _DeliveryCfg:
    """Typed accessors for the ``delivery`` config section (Phase 60)."""
    @property
    def enabled(self) -> bool: return bool(get("delivery", "enabled", True))
    @property
    def max_subscriptions_per_user(self) -> int: return int(get("delivery", "max_subscriptions_per_user", 50))
    @property
    def max_recipients_per_subscription(self) -> int: return int(get("delivery", "max_recipients_per_subscription", 20))
    @property
    def retry_max_attempts(self) -> int: return int(get("delivery", "retry_max_attempts", 3))
    # retry_backoff_minutes was removed here on 2026-09-15 — see _DEFAULTS.
    @property
    def delivery_history_retention_days(self) -> int: return int(get("delivery", "delivery_history_retention_days", 0))
    @property
    def max_pdf_rows(self) -> int: return int(get("delivery", "max_pdf_rows", 10000))
    @property
    def unsubscribe_token_expiry_days(self) -> int: return int(get("delivery", "unsubscribe_token_expiry_days", 365))
    @property
    def batch_size(self) -> int: return int(get("delivery", "batch_size", 20))
    @property
    def check_interval_minutes(self) -> int: return int(get("delivery", "check_interval_minutes", 5))
    @property
    def allowed_recipient_domains(self) -> list:
        """Recipient-domain allowlist (empty = allow all). Accepts CSV string or list."""
        raw = get("delivery", "allowed_recipient_domains", "")
        if isinstance(raw, (list, tuple)):
            return [str(d).strip() for d in raw if str(d).strip()]
        return [d.strip() for d in str(raw or "").split(",") if d.strip()]


delivery = _DeliveryCfg()


class _RestApiCfg:
    """Typed accessors for the ``rest_api`` config section (Phase 61)."""
    @property
    def enabled(self) -> bool: return bool(get("rest_api", "enabled", True))
    @property
    def max_response_size_mb(self) -> int: return int(get("rest_api", "max_response_size_mb", 50))
    @property
    def max_rows_per_query(self) -> int: return int(get("rest_api", "max_rows_per_query", 0))   # 2026-08-20: fallback was 100000 vs declared 0 -- same landmine, and this one truncates a feed
    @property
    def default_timeout_seconds(self) -> int: return int(get("rest_api", "default_timeout_seconds", 30))
    @property
    def max_timeout_seconds(self) -> int: return int(get("rest_api", "max_timeout_seconds", 300))
    @property
    def oauth2_token_cache_seconds(self) -> int: return int(get("rest_api", "oauth2_token_cache_seconds", 3500))
    @property
    def flatten_max_depth(self) -> int: return int(get("rest_api", "flatten_max_depth", 5))
    @property
    def allow_private_ips(self) -> bool: return bool(get("rest_api", "allow_private_ips", False))


rest_api = _RestApiCfg()


class _SapCfg:
    """Typed accessors for the ``sap`` config section (Phase 134-K).

    Drives the SAP-passthrough SSRF allowlist.  When ``allowed_hosts``
    is empty (default), the passthrough engine relies solely on
    ``core.url_safety.validate_url_safety`` (which already blocks
    cloud-metadata + private/loopback unless ``rest_api.allow_private_ips``
    is true).  When ``allowed_hosts`` is non-empty, the SAP URL's host
    must match one entry exactly OR end with ``.entry`` — a host-suffix
    allowlist.  Defence-in-depth against a Connection row that points
    at a non-SAP internal endpoint.
    """
    @property
    def allowed_hosts(self) -> List[str]:
        v = get("sap", "allowed_hosts", []) or []
        if isinstance(v, str):
            # Allow comma-separated env-var override
            return [h.strip() for h in v.split(",") if h.strip()]
        return [str(h).strip() for h in v if str(h).strip()]


sap = _SapCfg()


class _BackupCfg:
    """Typed accessors for the ``backup`` config section (Phase 123)."""
    @property
    def enabled(self) -> bool: return bool(get("backup", "enabled", False))
    @property
    def schedule_hours(self) -> int: return int(get("backup", "schedule_hours", 24))
    @property
    def backup_dir(self) -> str: return get("backup", "backup_dir", "./data/backups")
    @property
    def retention_count(self) -> int: return int(get("backup", "retention_count", 7))
    @property
    def pg_dump_path(self) -> str: return str(get("backup", "pg_dump_path", "") or "")


backup = _BackupCfg()


class _RowSecurityCfg:
    """Phase 141 — Row & column level security (Lake Formation equivalent).

    Master switch + behaviour knobs.  2026-09-26 (owner decision, F0):
    the feature is ON and ``default_mode`` is ``rewrite``.  An operator who
    wants a dry run sets ``default_mode: audit_only`` explicitly; an
    UNKNOWN mode falls back to ``rewrite`` (fail closed -- a misspelt mode
    must never turn enforcement into logging).
    """
    @property
    def enabled(self) -> bool:
        return bool(get("row_security", "enabled", True))

    @property
    def default_mode(self) -> str:
        """One of: rewrite | view | native_lf | audit_only.

        Used when a policy row has no explicit ``enforcement`` value.
        ``audit_only`` logs decisions but does not modify SQL; it must be
        asked for by name -- the fallback for a missing or unknown value is
        ``rewrite``.
        """
        m = str(get("row_security", "default_mode", "rewrite")).lower()
        return m if m in ("rewrite", "view", "native_lf", "audit_only") else "rewrite"

    @property
    def fail_open(self) -> bool:
        """If a rewrite raises (parse error, unknown construct), fall back to
        the ORIGINAL sql.  Default false = fail-closed: refuse to execute.
        """
        return bool(get("row_security", "fail_open", False))

    @property
    def audit_retention_days(self) -> int:
        return int(get("row_security", "audit_retention_days", 30))

    @property
    def cache_resolver_seconds(self) -> int:
        """How long to cache (principal, connection, table) → policies lookup.
        Lower bound 0 = no cache; default 30 s balances responsiveness vs DB load.
        """
        return int(get("row_security", "cache_resolver_seconds", 30))

    @property
    def lake_formation_sync_enabled(self) -> bool:
        return bool(get("row_security", "lake_formation_sync_enabled", False))

    @property
    def lake_formation_sync_interval_hours(self) -> int:
        return int(get("row_security", "lake_formation_sync_interval_hours", 6))

    @property
    def materialize_views_enabled(self) -> bool:
        """Option B — eager view materialisation at session start."""
        return bool(get("row_security", "materialize_views_enabled", False))

    @property
    def max_filter_sql_chars(self) -> int:
        return int(get("row_security", "max_filter_sql_chars", 4000))

    @property
    def policy_composition(self) -> str:
        """FB-45 -- ``permissive`` (default) | ``restrictive`` | ``per_policy``.

        The DEFAULT CLASS a row policy receives when authored without one;
        see core/row_security/composition.py for the model and the
        migration rule.  An unknown value falls back to ``permissive`` and
        ``validate_config`` names it at startup.
        """
        m = str(get("row_security", "policy_composition", "permissive")).strip().lower()
        return m if m in ("permissive", "restrictive", "per_policy") else "permissive"

    @property
    def entitlement_enabled(self) -> bool:
        return bool(get("row_security", "entitlement_enabled", True))

    @property
    def entitlement_inline_max_values(self) -> int:
        return max(1, int(get("row_security", "entitlement_inline_max_values", 1000)))

    @property
    def entitlement_upload_max_rows(self) -> int:
        return max(1, int(get("row_security", "entitlement_upload_max_rows", 100000)))


row_security = _RowSecurityCfg()


class _UserDraftsCfg:
    """Phase 142 — Server-side draft persistence (replaces localStorage)."""
    @property
    def enabled(self) -> bool:
        return bool(get("user_drafts", "enabled", True))

    @property
    def retention_days(self) -> int:
        """Daily cleanup deletes drafts older than this.  0 = keep forever."""
        return int(get("user_drafts", "retention_days", 30))

    @property
    def per_draft_max_mb(self) -> int:
        """Reject PUTs whose serialised content exceeds this many MB."""
        return int(get("user_drafts", "per_draft_max_mb", 5))

    @property
    def per_user_max_mb(self) -> int:
        """Reject PUTs whose total per-user size would exceed this many MB."""
        return int(get("user_drafts", "per_user_max_mb", 50))

    @property
    def cleanup_interval_hours(self) -> int:
        """How often the cleanup scheduler runs (default 24 = daily)."""
        return int(get("user_drafts", "cleanup_interval_hours", 24))


user_drafts = _UserDraftsCfg()


class _ConnectionValidationCfg:
    """2026-10-07 -- the login sweep's per-connection verdict cache
    (core/connection_verdicts.py)."""
    @property
    def ok_ttl_seconds(self) -> int:
        """How long a successful probe is served instead of re-probing."""
        return max(0, int(get("connection_validation", "ok_ttl_seconds", 900)))

    @property
    def fail_backoff_seconds(self) -> int:
        """First re-probe delay after a failed probe; doubles per failure."""
        return max(0, int(get("connection_validation", "fail_backoff_seconds", 60)))

    @property
    def fail_backoff_max_seconds(self) -> int:
        """Ceiling of the doubling failure backoff."""
        return max(0, int(get("connection_validation", "fail_backoff_max_seconds", 1800)))


connection_validation = _ConnectionValidationCfg()


class _HealthCfg:
    """Typed accessors for the ``health`` config section — K8s probe behaviour."""
    @property
    def liveness_db_check(self) -> bool: return bool(get("health", "liveness_db_check", True))
    @property
    def probe_timeout_seconds(self) -> float: return float(get("health", "probe_timeout_seconds", 3.0) or 3.0)
    @property
    def failure_threshold(self) -> int: return int(get("health", "failure_threshold", 3))
    @property
    def enable_write_test(self) -> bool: return bool(get("health", "enable_write_test", False))


health = _HealthCfg()


class _ComponentHealthCfg:
    """Typed accessors for the ``component_health`` section (2026-10-17).
    Every key the reporter, the fleet watcher and the page read is a
    PROPERTY here -- a key added only to _DEFAULTS raises AttributeError
    (qs-platform: "a key in the DEFAULTS dict is not a key on the object")."""
    @property
    def enabled(self) -> bool: return bool(get("component_health", "enabled", True))
    @property
    def report_interval_seconds(self) -> int: return max(3, int(get("component_health", "report_interval_seconds", 15)))
    @property
    def dependency_probe_interval_seconds(self) -> int: return max(5, int(get("component_health", "dependency_probe_interval_seconds", 30)))
    @property
    def probe_timeout_seconds(self) -> float: return float(get("component_health", "probe_timeout_seconds", 3.0) or 3.0)
    @property
    def probe_pool_size(self) -> int: return max(1, int(get("component_health", "probe_pool_size", 4)))
    @property
    def max_probes_per_cycle(self) -> int: return max(1, int(get("component_health", "max_probes_per_cycle", 20)))
    @property
    def slow_probe_ms(self) -> int: return int(get("component_health", "slow_probe_ms", 2000))
    @property
    def stale_after_seconds(self) -> int: return int(get("component_health", "stale_after_seconds", 45))
    @property
    def pod_down_after_seconds(self) -> int: return int(get("component_health", "pod_down_after_seconds", 90))
    @property
    def daemon_silent_intervals(self) -> int: return max(1, int(get("component_health", "daemon_silent_intervals", 3)))
    @property
    def unknown_alert_after_seconds(self) -> int: return int(get("component_health", "unknown_alert_after_seconds", 300))
    @property
    def transition_confirmations(self) -> int: return max(1, int(get("component_health", "transition_confirmations", 2)))
    @property
    def clear_after_cycles(self) -> int: return max(1, int(get("component_health", "clear_after_cycles", 2)))
    @property
    def alerts_enabled(self) -> bool: return bool(get("component_health", "alerts_enabled", True))
    @property
    def alert_group(self) -> str: return str(get("component_health", "alert_group", "PLATFORM") or "PLATFORM")
    @property
    def events_retention_days(self) -> int: return int(get("component_health", "events_retention_days", 30))
    @property
    def dead_pod_retention_hours(self) -> int: return int(get("component_health", "dead_pod_retention_hours", 24))
    @property
    def pod_retire_after_seconds(self) -> int: return int(get("component_health", "pod_retire_after_seconds", 600))
    @property
    def intent_default_expiry_minutes(self) -> int: return int(get("component_health", "intent_default_expiry_minutes", 120))
    @property
    def page_cache_seconds(self) -> float: return float(get("component_health", "page_cache_seconds", 5) or 0)
    @property
    def probe_connections(self) -> dict:
        v = get("component_health", "probe_connections", {}) or {}
        return dict(v) if isinstance(v, dict) else {}
    @property
    def external_pods(self) -> dict:
        v = get("component_health", "external_pods", {}) or {}
        return dict(v) if isinstance(v, dict) else {}
    @property
    def key_sweep_interval_seconds(self) -> int: return int(get("component_health", "key_sweep_interval_seconds", 300))
    @property
    def planted_probe_enabled(self) -> bool: return bool(get("component_health", "planted_probe_enabled", False))


component_health = _ComponentHealthCfg()


class _HorizontalWorkersCfg:
    """Typed accessors for the ``horizontal_workers`` config section (Phase 45)."""
    @property
    def registry_backend(self) -> str: return get("horizontal_workers", "registry_backend", "auto")
    @property
    def heartbeat_interval_seconds(self) -> int: return int(get("horizontal_workers", "heartbeat_interval_seconds", 15))
    @property
    def heartbeat_ttl_seconds(self) -> int: return int(get("horizontal_workers", "heartbeat_ttl_seconds", 45))
    @property
    def worker_eviction_seconds(self) -> int: return int(get("horizontal_workers", "worker_eviction_seconds", 120))
    @property
    def max_workers_per_host(self) -> int: return int(get("horizontal_workers", "max_workers_per_host", 10))
    @property
    def enable_load_aware_claiming(self) -> bool: return bool(get("horizontal_workers", "enable_load_aware_claiming", True))
    @property
    def memory_threshold_pct(self) -> int: return int(get("horizontal_workers", "memory_threshold_pct", 85))
    @property
    def cpu_threshold_pct(self) -> int: return int(get("horizontal_workers", "cpu_threshold_pct", 90))
    @property
    def metrics_retention_hours(self) -> int: return int(get("horizontal_workers", "metrics_retention_hours", 24))


horizontal_workers = _HorizontalWorkersCfg()


class _StreamingCfg:
    """Typed accessors for the ``streaming`` config section (Phase 72)."""
    @property
    def cancel_enabled(self) -> bool: return bool(get("streaming", "cancel_enabled", True))
    @property
    def max_active_streams(self) -> int: return int(get("streaming", "max_active_streams", 50))
    @property
    def cancel_check_interval_rows(self) -> int: return int(get("streaming", "cancel_check_interval_rows", 5000))


streaming = _StreamingCfg()


class _PresignedUrlCfg:
    """Typed accessors for the ``presigned_url`` config section (Phase 74)."""
    @property
    def expiry_seconds(self) -> int: return int(get("presigned_url", "expiry_seconds", 900))
    @property
    def retry_enabled(self) -> bool: return bool(get("presigned_url", "retry_enabled", True))
    @property
    def max_retries(self) -> int: return int(get("presigned_url", "max_retries", 2))
    @property
    def retry_on_403(self) -> bool: return bool(get("presigned_url", "retry_on_403", True))
    @property
    def retry_delay_seconds(self) -> int: return int(get("presigned_url", "retry_delay_seconds", 1))
    @property
    def download_timeout_seconds(self) -> int: return int(get("presigned_url", "download_timeout_seconds", 120))


presigned_url = _PresignedUrlCfg()


class _S3ValidationCfg:
    """Typed accessors for the ``s3_validation`` config section (Phase 78)."""
    @property
    def bucket_name_regex_aws(self) -> str:
        return str(get("s3_validation", "bucket_name_regex_aws", r"^[a-z0-9]([a-z0-9\-]{1,61}[a-z0-9])?$"))
    @property
    def bucket_name_regex_onprem(self) -> str:
        return str(get("s3_validation", "bucket_name_regex_onprem", r"^[a-zA-Z0-9][a-zA-Z0-9\-_\.]{0,253}[a-zA-Z0-9]$"))
    @property
    def validate_bucket_on_create(self) -> bool:
        return bool(get("s3_validation", "validate_bucket_on_create", True))
    @property
    def validate_arn_format(self) -> bool:
        return bool(get("s3_validation", "validate_arn_format", True))
    @property
    def arn_regex(self) -> str:
        return str(get("s3_validation", "arn_regex", r"^arn:(aws|aws-cn|aws-us-gov):iam::\d{12}:role\/[\w+=,.@\-\/]{1,256}$"))
    @property
    def root_prefix_test_on_create(self) -> bool:
        return bool(get("s3_validation", "root_prefix_test_on_create", True))
    @property
    def warn_unsupported_partition_ops(self) -> bool:
        return bool(get("s3_validation", "warn_unsupported_partition_ops", True))
    @property
    def max_folder_browser_items(self) -> int:
        return int(get("s3_validation", "max_folder_browser_items", 500))
    @property
    def partition_refresh_mutex_timeout_seconds(self) -> int:
        return int(get("s3_validation", "partition_refresh_mutex_timeout_seconds", 30))
    @property
    def file_list_max_files(self) -> int:
        return int(get("s3_validation", "file_list_max_files", 5000))


s3_validation = _S3ValidationCfg()


class _DuckDBCfg:
    """Typed accessors for the ``duckdb`` config section (Phase 79)."""
    @property
    def circuit_breaker_enabled(self) -> bool:
        return bool(get("duckdb", "circuit_breaker_enabled", True))
    @property
    def retry_on_engine_error(self) -> bool:
        return bool(get("duckdb", "retry_on_engine_error", True))
    @property
    def retry_max_attempts(self) -> int:
        return int(get("duckdb", "retry_max_attempts", 1))
    @property
    def retry_delay_seconds(self) -> float:
        return float(get("duckdb", "retry_delay_seconds", 1))


duckdb_cfg = _DuckDBCfg()


class _FeedGenerationAirflowCfg:
    """Typed accessors for ``feed_generation.airflow`` sub-section."""
    @property
    def enabled(self) -> bool: return bool(get("feed_generation", "airflow", {}).get("enabled", False))
    @property
    def base_url(self) -> str: return str(get("feed_generation", "airflow", {}).get("base_url", "http://airflow:8080"))
    @property
    def auth_type(self) -> str: return str(get("feed_generation", "airflow", {}).get("auth_type", "basic"))
    @property
    def username(self) -> str: return str(get("feed_generation", "airflow", {}).get("username", ""))
    @property
    def password(self) -> str: return str(get("feed_generation", "airflow", {}).get("password", ""))
    @property
    def default_dag_id(self) -> str: return str(get("feed_generation", "airflow", {}).get("default_dag_id", "querystudio_feed"))
    # output_s3_bucket / output_s3_prefix accessors REMOVED 2026-10-08 --
    # the conf-driven Airflow road that read them is gone (ONE road: the
    # factory DAG -> /spark-submit; see _DEFAULTS and _REMOVED_KEYS).
    @property
    def poll_interval_seconds(self) -> int: return int(get("feed_generation", "airflow", {}).get("poll_interval_seconds", 10))
    @property
    def poll_timeout_seconds(self) -> int: return int(get("feed_generation", "airflow", {}).get("poll_timeout_seconds", 3600))
    # use_callback_webhook accessor REMOVED 2026-09-02 — a ghost knob no
    # code ever read (see the _DEFAULTS airflow block for the full story).


class _FeedGenerationOracleCfg:
    """Typed accessors for ``feed_generation.oracle_defaults`` sub-section."""
    @property
    def batch_size(self) -> int: return int(get("feed_generation", "oracle_defaults", {}).get("batch_size", 5000))
    @property
    def timeout_seconds(self) -> int: return int(get("feed_generation", "oracle_defaults", {}).get("timeout_seconds", 3600))


class _FeedGenerationSftpCfg:
    """Typed accessors for ``feed_generation.sftp`` sub-section."""
    @property
    def connect_timeout_seconds(self) -> int: return int(get("feed_generation", "sftp", {}).get("connect_timeout_seconds", 30))
    # upload_timeout_seconds accessor REMOVED 2026-09-02 — a ghost knob no
    # code ever read; today's uploads have NO timeout, and persisted
    # configs carry the inert 300, so wiring it would move production
    # behaviour (see the _DEFAULTS sftp block for the full story).


class _RolesCfg:
    """Typed accessors for the ``roles`` config section (Phase 130 hotfix-13).
    All role names are DB-overridable so the admin UI can rename the
    'support' role to match local conventions without code changes."""

    @property
    def support_role_name(self) -> str:
        val = _db_setting_or("roles.support_role_name",
                              get("roles", "support_role_name", "support"))
        return str(val or "support").lower()


roles = _RolesCfg()


class _FeedGenerationCfg:
    """Typed accessors for the ``feed_generation`` config section (Phase 76)."""
    airflow = _FeedGenerationAirflowCfg()
    oracle = _FeedGenerationOracleCfg()
    sftp = _FeedGenerationSftpCfg()

    @property
    def enabled(self) -> bool: return bool(get("feed_generation", "enabled", True))
    @property
    def max_concurrent_native(self) -> int: return int(get("feed_generation", "max_concurrent_native", 3))
    @property
    def native_memory_per_run_mb(self) -> int: return int(get("feed_generation", "native_memory_per_run_mb", 2048))
    @property
    def max_run_reclaims(self) -> int: return int(get("feed_generation", "max_run_reclaims", 1))
    @property
    def shutdown_drain_seconds(self) -> int: return int(get("feed_generation", "shutdown_drain_seconds", 20))
    @property
    def progress_stale_seconds(self) -> int: return int(get("feed_generation", "progress_stale_seconds", 300))
    @property
    def progress_stall_seconds(self) -> int: return int(get("feed_generation", "progress_stall_seconds", 1800))
    @property
    def test_as_feed_max_rows(self) -> int: return int(get("feed_generation", "test_as_feed_max_rows", 100))
    @property
    def test_as_feed_timeout_seconds(self) -> int: return int(get("feed_generation", "test_as_feed_timeout_seconds", 60))
    @property
    def output_dir(self) -> str: return str(get("feed_generation", "output_dir", "/usr/local/querystudioapi/nfs/data/feeds"))
    @property
    def max_output_rows(self) -> int: return int(get("feed_generation", "max_output_rows", 0))   # 2026-09-02: fallback was 1000000 while _DEFAULTS declares 0 (= UNLIMITED, changed 2026-08-13 because 1M silently truncated a 70M-row feed and reported success) -- inert while declared, an instant SILENT re-truncation if the declaration is ever removed. Same correction federation.max_result_rows got on 2026-08-20; this was the sibling that was missed.
    @property
    def max_file_size_mb(self) -> int: return int(get("feed_generation", "max_file_size_mb", 500))
    @property
    def max_file_size_action(self) -> str:
        """warn | fail -- see _DEFAULTS.  An unrecognised value reads as
        "warn": a typo in a governance knob must not silently start
        refusing deliveries."""
        v = str(get("feed_generation", "max_file_size_action", "warn")).lower()
        return v if v in ("warn", "fail") else "warn"
    @property
    def default_output_format(self) -> str: return str(get("feed_generation", "default_output_format", "csv"))
    @property
    def filename_template(self) -> str: return str(get("feed_generation", "filename_template", "{name}_{date}.{ext}"))
    @property
    def auto_route_threshold_rows(self) -> int: return int(get("feed_generation", "auto_route_threshold_rows", 500000))
    @property
    def auto_route_width_base_columns(self) -> int: return int(get("feed_generation", "auto_route_width_base_columns", 100))
    @property
    def size_probe_enabled(self) -> bool: return bool(get("feed_generation", "size_probe_enabled", True))
    @property
    def size_probe_timeout_seconds(self) -> float: return float(get("feed_generation", "size_probe_timeout_seconds", 30))
    @property
    def retry_max_attempts(self) -> int: return int(get("feed_generation", "retry_max_attempts", 2))
    @property
    def retry_delay_seconds(self) -> int: return int(get("feed_generation", "retry_delay_seconds", 60))
    @property
    def execution_history_retention_days(self) -> int: return int(get("feed_generation", "execution_history_retention_days", 0))
    @property
    def download_retention_days(self) -> int: return int(get("feed_generation", "download_retention_days", 0))
    @property
    def cleanup_interval_hours(self) -> int: return int(get("feed_generation", "cleanup_interval_hours", 6))
    @property
    def chunk_size(self) -> int: return int(get("feed_generation", "chunk_size", 100000))
    @property
    def completeness_gate(self) -> str:
        """FR-CMP-01 — "record" (default) or "enforce".  An unknown
        value reads as "record": a typo must never silently start
        failing runs, nor silently stop enforcing once someone has
        turned enforcement on."""
        val = str(get("feed_generation", "completeness_gate",
                      "record") or "record").strip().lower()
        return val if val in ("record", "enforce") else "record"
    @property
    def pod_side_delivery(self) -> bool:
        """H1 — True: the Spark job delivers itself (today).  False: it
        writes artifacts only and QueryStudio delivers from the webhook."""
        return bool(get("feed_generation", "pod_side_delivery", True))
    @property
    def delivery_suppression(self) -> dict:
        """FR-DEL-06 — suppression policy; {} suppresses nothing."""
        v = get("feed_generation", "delivery_suppression", {})
        return dict(v) if isinstance(v, dict) else {}
    @property
    def disk_preflight_enabled(self) -> bool:
        # 2026-08-22 disk preflight (design_starburst_140m bug #5)
        return bool(get("feed_generation", "disk_preflight_enabled", True))
    @property
    def disk_preflight_min_bytes_per_row(self) -> int:
        return int(get("feed_generation", "disk_preflight_min_bytes_per_row", 32))
    # ── Write ladder (2026-08-22) — see _DEFAULTS for semantics ──
    @property
    def engine_write_enabled(self) -> bool:
        return bool(get("feed_generation", "engine_write_enabled", True))
    @property
    def max_cells_in_memory(self) -> int:
        # core/feed/batch_budget.py -- cells one stage of one native run
        # holds as Python objects at once (0 = no cap).  Declared in the
        # defaults on 2026-10-11 WITHOUT this property: the budget silently
        # ran on batch_budget's built-in default and an operator's value was
        # never read.
        return int(get("feed_generation", "max_cells_in_memory", 1_000_000))
    @property
    def csv_parallel_workers(self) -> int:
        # core/feed/csv_parallel.py -- 0 = the pod's CPU quota, 1 = off
        return int(get("feed_generation", "csv_parallel_workers", 0))
    @property
    def csv_parallel_min_rows(self) -> int:
        return int(get("feed_generation", "csv_parallel_min_rows", 200_000))
    @property
    def csv_parallel_worker_mb(self) -> int:
        return int(get("feed_generation", "csv_parallel_worker_mb", 512))
    @property
    def sla_at_risk_minutes(self) -> int:
        # core/feed/sla_board.py -- "at risk" = undelivered, deadline this close.
        return int(get("feed_generation", "sla_at_risk_minutes", 30))
    @property
    def variance_hold_release_group(self) -> str:
        # core/feed/variance_hold.py -- who may release a held file.
        return str(get("feed_generation", "variance_hold_release_group", "") or "").strip()
    @property
    def parts_rows_per_part(self) -> int:
        # 0 = never rotate (single file) — a declared shape semantic,
        # not a 0==unlimited fold; no value of this knob drops rows.
        return int(get("feed_generation", "parts_rows_per_part", 5000000))
    @property
    def union_pushdown_enabled(self) -> bool:
        return bool(get("feed_generation", "union_pushdown_enabled", True))
    @property
    def cross_union_zero_copy(self) -> bool:
        return bool(get("feed_generation", "cross_union_zero_copy", True))
    @property
    def execution_timeout_seconds(self) -> int:
        # DEPRECATED 2026-11-05, read by nothing: see _DEFAULTS.
        return int(get("feed_generation", "execution_timeout_seconds", 3600))
    @property
    def airflow_enabled(self) -> bool: return self.airflow.enabled
    @property
    def oracle_batch_size(self) -> int: return self.oracle.batch_size
    @property
    def webhook_secret(self) -> str: return str(get("feed_generation", "webhook_secret", ""))

    # ── Phase 130 hotfix-13 — backend failover (DB-overridable) ──────
    # These accessors prefer the DB-persisted SystemSetting (admin-set
    # at runtime via the admin UI) and fall back to config.json.  This
    # lets admins flip the failover behaviour without a pod restart and
    # survives across pods (multi-pod deployments).

    @property
    def backend_override(self) -> str:
        """Global override: 'auto' | 'native_only' | 'airflow_only' | 'halt'."""
        val = _db_setting_or("feed_generation.backend_override",
                              get("feed_generation", "backend_override", "auto"))
        return str(val or "auto").lower()

    @property
    def airflow_failover_to_native(self) -> bool:
        val = _db_setting_or("feed_generation.airflow_failover_to_native",
                              get("feed_generation", "airflow_failover_to_native", False))
        return bool(val)

    @property
    def failover_agent_enabled(self) -> bool:
        val = _db_setting_or("feed_generation.failover_agent_enabled",
                              get("feed_generation", "failover_agent_enabled", False))
        return bool(val)

    @property
    def failover_agent_interval_seconds(self) -> int:
        val = _db_setting_or("feed_generation.failover_agent_interval_seconds",
                              get("feed_generation", "failover_agent_interval_seconds", 30))
        return int(val)

    @property
    def failover_agent_unhealthy_streak_required(self) -> int:
        val = _db_setting_or("feed_generation.failover_agent_unhealthy_streak_required",
                              get("feed_generation", "failover_agent_unhealthy_streak_required", 3))
        return int(val)

    @property
    def failover_agent_healthy_streak_required(self) -> int:
        val = _db_setting_or("feed_generation.failover_agent_healthy_streak_required",
                              get("feed_generation", "failover_agent_healthy_streak_required", 3))
        return int(val)

    @property
    def native_worker_stale_after_seconds(self) -> int:
        val = _db_setting_or("feed_generation.native_worker_stale_after_seconds",
                              get("feed_generation", "native_worker_stale_after_seconds", 180))
        return int(val)

    @property
    def worker_pod_only(self) -> bool:
        val = _db_setting_or("feed_generation.worker_pod_only",
                              get("feed_generation", "worker_pod_only", False))
        return bool(val)

    @property
    def stale_running_reclaim_seconds(self) -> int:
        val = _db_setting_or("feed_generation.stale_running_reclaim_seconds",
                              get("feed_generation", "stale_running_reclaim_seconds", 3600))
        return int(val)

    @property
    def stale_running_reclaim_interval_seconds(self) -> int:
        val = _db_setting_or("feed_generation.stale_running_reclaim_interval_seconds",
                              get("feed_generation", "stale_running_reclaim_interval_seconds", 300))
        return int(val)

    # ── Phase 130 — enterprise feed framework activation flags ─────────
    # All default false so production behaviour stays unchanged until
    # admin opts in.

    @property
    def sod_enabled(self) -> bool:
        """Daily SOD task generator on/off."""
        return bool(get("feed_generation", "sod_enabled", False))

    @property
    def sod_cron(self) -> str:
        """When the SOD generator runs.  Default 00:00 UTC ("0 0 * * *")."""
        return str(get("feed_generation", "sod_cron", "0 0 * * *"))

    @property
    def sod_catchup_days(self) -> int:
        """2026-10-11 -- missed DUE dates within this many days before the
        run day are created by the pass (triggered_by sod_catchup); 0 = off."""
        return max(0, int(get("feed_generation", "sod_catchup_days", 7)))

    @property
    def sod_gap_scan_days(self) -> int:
        """2026-10-11 -- how far back a pass looks for DUE dates with no run;
        beyond the catch-up window they become gap records, never runs."""
        return max(0, int(get("feed_generation", "sod_gap_scan_days", 45)))

    @property
    def sod_run_now_sync_max_feeds(self) -> int:
        """2026-10-11 -- a run-now over more feeds than this is a background
        JOB (202 + a pollable status) rather than one HTTP request."""
        return max(0, int(get("feed_generation", "sod_run_now_sync_max_feeds", 100)))

    @property
    def sla_tracker_enabled(self) -> bool:
        """SLA breach detection job on/off."""
        return bool(get("feed_generation", "sla_tracker_enabled", False))

    @property
    def sla_check_interval_seconds(self) -> int:
        return int(get("feed_generation", "sla_check_interval_seconds", 60))

    # ── Phase 130 hotfix-11 — Queue worker for pending feed_runs ─────
    @property
    def queue_worker_enabled(self) -> bool:
        """Polling-based worker that picks pending feed_runs and
        dispatches execute_feed.  Complements per-feed cron — only
        fires for SOD-created rows whose feed has no cron set.
        Default false so production behaviour stays unchanged."""
        return bool(get("feed_generation", "queue_worker_enabled", False))

    @property
    def queue_poll_interval_seconds(self) -> int:
        """How often the queue worker polls feed_runs(pending)."""
        return int(get("feed_generation", "queue_poll_interval_seconds", 30))

    @property
    def queue_refill_on_completion(self) -> bool:
        """2026-10-10 -- a completed run that freed a slot wakes an
        immediate refill poll while the last poll saw a backlog (see
        core/feed/queue_worker.py::_request_refill).  Read on every
        completion, so the DB overlay makes it a live kill switch."""
        return bool(get("feed_generation", "queue_refill_on_completion", True))

    @property
    def allow_external_triggers(self) -> bool:
        """External-trigger API (``POST /api/v1/feeds/{id}/trigger``)."""
        return bool(get("feed_generation", "allow_external_triggers", False))

    @property
    def external_trigger_api_key_ids(self) -> Any:
        """The deployment-wide allow-list for that route, AS STORED (the
        route reads its shape and refuses one it cannot read)."""
        return get("feed_generation", "external_trigger_api_key_ids", [])

    @property
    def default_weekend_days(self) -> list:
        """System-wide weekend fallback when a feed_calendars row has
        no weekend_days set.  Mon=1 … Sun=7.  Default = Sat/Sun.
        Operators change this in config.json — no code edit needed."""
        v = get("feed_generation", "default_weekend_days", [6, 7])
        return list(v) if isinstance(v, (list, tuple)) else [6, 7]

    @property
    def control_file_style(self) -> str:
        """Default control-file rendering style — 'key_value' or 'delimited'."""
        return str(get("feed_generation", "control_file_style", "key_value"))

    @property
    def control_file_delimiter(self) -> str:
        return str(get("feed_generation", "control_file_delimiter", "|"))

    @property
    def local_destination_allowed_roots(self) -> list:
        """BF-415 — explicit allowlist of filesystem roots a feed's local
        destination may write under.  ``feeds.output_dir`` is always
        permitted; this list adds extras (e.g. ``/data/exports``).  Empty
        list (the default) means only ``output_dir`` is allowed.

        Phase 131 hotfix-1: now DB-overridable via system_settings so
        operators can adjust the allow-list from the admin UI without
        a pod restart.
        """
        v = _db_setting_or(
            "feed_generation.local_destination_allowed_roots",
            get("feed_generation", "local_destination_allowed_roots", []),
        )
        return list(v) if isinstance(v, (list, tuple)) else []

    # ── 2026-08-23 (Phase 4) — feed-schedule reconciler + queue window ──

    @property
    def schedule_reconcile_interval_seconds(self) -> int:
        """How often the scheduler-side reconciler converges per-feed
        APScheduler cron jobs to feed_configs DB truth.  Floor 15 —
        0/negative would mean 'never reconcile', which re-opens the
        registered-on-the-wrong-pod hole this exists to close."""
        try:
            v = int(get("feed_generation", "schedule_reconcile_interval_seconds", 60))
        except (TypeError, ValueError):
            v = 60
        return max(15, v)

    @property
    def queue_lookback_days(self) -> int:
        """Days BEFORE today the queue worker also polls for pending
        feed_runs.  0 = today only (legacy).  Negative folds to 0."""
        try:
            v = int(get("feed_generation", "queue_lookback_days", 3))
        except (TypeError, ValueError):
            v = 3
        return max(0, v)

    @property
    def queue_cron_grace_seconds(self) -> int:
        """Grace after a cron-owned feed's fire time before the queue
        worker may claim its pending row (missed-fire safety net)."""
        try:
            v = int(get("feed_generation", "queue_cron_grace_seconds", 600))
        except (TypeError, ValueError):
            v = 600
        return max(0, v)


feed_generation = _FeedGenerationCfg()


class _EtlSizeThresholdsCfg:
    """Typed accessors for etl_pipelines.size_thresholds."""
    @property
    def native_max_rows(self) -> int: return int(get("etl_pipelines", "size_thresholds", {}).get("native_max_rows", 500000))
    @property
    def spark_submit_max_rows(self) -> int: return int(get("etl_pipelines", "size_thresholds", {}).get("spark_submit_max_rows", 10000000))

class _EtlSparkDefaultsCfg:
    """Typed accessors for etl_pipelines.spark_defaults."""
    @property
    def driver_memory(self) -> str: return str(get("etl_pipelines", "spark_defaults", {}).get("driver_memory", "4g"))
    @property
    def executor_memory(self) -> str: return str(get("etl_pipelines", "spark_defaults", {}).get("executor_memory", "8g"))
    @property
    def executor_cores(self) -> int: return int(get("etl_pipelines", "spark_defaults", {}).get("executor_cores", 4))
    @property
    def num_executors(self) -> int: return int(get("etl_pipelines", "spark_defaults", {}).get("num_executors", 4))
    @property
    def spark_conf(self) -> dict: return get("etl_pipelines", "spark_defaults", {}).get("spark_conf", {})

class _EtlNativeDefaultsCfg:
    """Typed accessors for etl_pipelines.native_defaults."""
    @property
    def duckdb_memory_limit(self) -> str: return str(get("etl_pipelines", "native_defaults", {}).get("duckdb_memory_limit", "2g"))
    @property
    def duckdb_threads(self) -> int: return int(get("etl_pipelines", "native_defaults", {}).get("duckdb_threads", 4))
    @property
    def max_rows_warning(self) -> int: return int(get("etl_pipelines", "native_defaults", {}).get("max_rows_warning", 1000000))

class _EtlOnCompleteCfg:
    """Typed accessors for etl_pipelines.on_complete."""
    @property
    def invalidate_cache(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("invalidate_cache", True))
    @property
    def refresh_partitions(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("refresh_partitions", True))
    @property
    def run_dq_checks(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("run_dq_checks", True))
    @property
    def broadcast_ws(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("broadcast_ws", True))
    @property
    def update_lineage(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("update_lineage", True))
    @property
    def trigger_dependents(self) -> bool: return bool(get("etl_pipelines", "on_complete", {}).get("trigger_dependents", True))

class _EtlSlaCfg:
    """Typed accessors for etl_pipelines.sla."""
    @property
    def enabled(self) -> bool: return bool(get("etl_pipelines", "sla", {}).get("enabled", True))
    @property
    def default_notify_channels(self) -> list: return get("etl_pipelines", "sla", {}).get("default_notify_channels", ["ws", "webhook"])

class _EtlDeadLetterCfg:
    """Typed accessors for etl_pipelines.dead_letter."""
    @property
    def enabled(self) -> bool: return bool(get("etl_pipelines", "dead_letter", {}).get("enabled", True))
    @property
    def max_retries(self) -> int: return int(get("etl_pipelines", "dead_letter", {}).get("max_retries", 3))
    @property
    def capture_bad_records(self) -> bool: return bool(get("etl_pipelines", "dead_letter", {}).get("capture_bad_records", True))

class _EtlPipelinesCfg:
    """Typed accessors for the ``etl_pipelines`` config section (Phase 127)."""
    def __init__(self):
        self.size_thresholds = _EtlSizeThresholdsCfg()
        self.spark_defaults = _EtlSparkDefaultsCfg()
        self.native_defaults = _EtlNativeDefaultsCfg()
        self.on_complete = _EtlOnCompleteCfg()
        self.sla = _EtlSlaCfg()
        self.dead_letter = _EtlDeadLetterCfg()
    @property
    def enabled(self) -> bool: return bool(get("etl_pipelines", "enabled", False))
    @property
    def max_concurrent_pipelines(self) -> int: return int(get("etl_pipelines", "max_concurrent_pipelines", 5))
    @property
    def max_concurrent_pipelines_cluster(self) -> int:
        """BF-582: cluster-wide concurrency cap.  Counts running+pending
        executions across all pods via DB lookup.  0 = disabled."""
        return int(get("etl_pipelines", "max_concurrent_pipelines_cluster", 25))
    @property
    def stale_execution_minutes(self) -> int:
        """BF-582: was hardcoded 60 in main.py.  Pipelines that legitimately
        run longer than this would get marked stale and reset mid-flight."""
        return int(get("etl_pipelines", "stale_execution_minutes", 60))
    @property
    def scheduler_tick_seconds(self) -> int:
        """BF-582: how often the periodic scheduler scans for
        trigger_type=schedule pipelines due to fire.  0 disables."""
        return int(get("etl_pipelines", "scheduler_tick_seconds", 60))
    @property
    def default_dag_id(self) -> str: return str(get("etl_pipelines", "default_dag_id", "querystudio_etl"))
    @property
    def execution_history_retention_days(self) -> int: return int(get("etl_pipelines", "execution_history_retention_days", 90))
    @property
    def cleanup_interval_hours(self) -> int: return int(get("etl_pipelines", "cleanup_interval_hours", 12))
    @property
    def poll_interval_seconds(self) -> int: return int(get("etl_pipelines", "poll_interval_seconds", 15))
    @property
    def webhook_secret(self) -> str: return str(get("etl_pipelines", "webhook_secret", ""))

etl_pipelines = _EtlPipelinesCfg()


class _PublishedViewsCfg:
    """Typed accessors for the ``published_views`` config section (Phase 75)."""
    @property
    def enabled(self) -> bool: return bool(get("published_views", "enabled", True))
    @property
    def max_concurrent(self) -> int: return int(get("published_views", "max_concurrent", 50))
    @property
    def notify_email_domain(self) -> str: return str(get("published_views", "notify_email_domain", "") or "")
    @property
    def default_cache_ttl_seconds(self) -> int: return int(get("published_views", "default_cache_ttl_seconds", 300))
    @property
    def max_cache_size_mb(self) -> int: return int(get("published_views", "max_cache_size_mb", 2048))
    @property
    def cache_dir(self) -> str: return str(get("published_views", "cache_dir", "/usr/local/querystudioapi/nfs/data/published_cache"))
    @property
    def default_rate_limit(self) -> str: return str(get("published_views", "default_rate_limit", "60/minute"))
    @property
    def max_rate_limit(self) -> str: return str(get("published_views", "max_rate_limit", "300/minute"))
    @property
    def default_row_limit(self) -> int: return int(get("published_views", "default_row_limit", 100000))
    @property
    def max_row_limit(self) -> int: return int(get("published_views", "max_row_limit", 1000000))
    @property
    def api_key_prefix(self) -> str: return str(get("published_views", "api_key_prefix", "qs_"))
    @property
    def access_log_retention_days(self) -> int: return int(get("published_views", "access_log_retention_days", 90))
    @property
    def cleanup_interval_hours(self) -> int: return int(get("published_views", "cleanup_interval_hours", 6))

    param_substitution_enabled: bool = property(lambda self: bool(get("published_views", "param_substitution_enabled", True)))   # type: ignore[assignment]
    dedup_timeout_seconds:       int  = property(lambda self: int(get("published_views", "dedup_timeout_seconds", 60)))           # type: ignore[assignment]

    @property
    def large_result_threshold(self) -> int:
        """Row count above which JSON responses include a large_result_warning."""
        return int(get("published_views", "large_result_threshold", 50000))

    @property
    def max_concurrent_per_key(self) -> int:
        """Max concurrent requests per API key (0 = unlimited)."""
        return int(get("published_views", "max_concurrent_per_key", 10))

    @property
    def cache_eviction_interval_hours(self) -> int:
        """How often the LRU cache eviction job runs."""
        return int(get("published_views", "cache_eviction_interval_hours", 4))

    @property
    def bulk_cache_size_mb(self) -> int:
        """Budget for materialized BULK datasets (0 = never size-evict them).

        Separate from ``max_cache_size_mb`` on purpose: one bulk export can be
        larger than the entire paged cache budget, and billing it there makes
        the evictor destroy every paged entry without ever getting under
        budget."""
        return int(get("published_views", "bulk_cache_size_mb", 16384))

    @property
    def bulk_cache_min_retain_minutes(self) -> int:
        """Never size-evict a bulk dataset younger than this (in-flight pulls
        and outstanding resume cursors are still reading it)."""
        return int(get("published_views", "bulk_cache_min_retain_minutes", 60))

    @property
    def execution_timeout_seconds(self) -> int:
        """Phase 133-C: Max seconds per view execution (default 5 min)."""
        return int(get("published_views", "execution_timeout_seconds", 300))

    @property
    def ad_group_fetch_fail_mode(self) -> str:
        """Phase 83H: 'deny' | 'allow' — what to do when AD group fetch fails."""
        return str(get("published_views", "ad_group_fetch_fail_mode", "deny"))

    @property
    def default_data_policy_mode(self) -> str:
        """2026-10-25: the data-policy switch of every published API whose own
        switch nobody set, ``off`` | ``apply``.  Anything else reads as
        ``apply`` -- the side that never widens a governed table (and, since
        an API key is a resolved principal, never a 403 either)."""
        v = str(get("published_views", "default_data_policy_mode", "apply") or "apply").strip().lower()
        return v if v in ("off", "apply") else "apply"

    @property
    def allow_anonymous_when_auth_disabled(self) -> bool:
        """Serve /api/v1 to a caller with NO credential when auth.type='none'.

        2026-09-17 -- DEFAULT FLIPPED TO FALSE, and the default is the fix.

        Measured live: with ``auth.type='none'`` a caller presenting no
        credential at all received 3,000 real rows from the published DATA
        surface -- the paid one.  The branch is deliberate dev-mode
        convenience, and its own comment cites the PV Test dialog and the API
        Explorer as the journeys that need it.  Both were read: the Explorer
        sends either a pasted ``X-API-Key`` or a Bearer session through
        ``safeFetch``, and NEITHER is a credential-less call.  The branch is
        not required by the journeys it was added for.

        It matters more here than on the authoring surface because an API key
        on ``/api/v1`` is not only identity -- it carries the per-view SCOPE
        and the metering.  Skipping it skips authorization, not just login.
        And ``docker-compose.production.yml`` ships ``auth.type=none``, so
        "this is only dev behaviour" is not a property of the deployment.

        Set True to restore the old behaviour deliberately, per deployment.
        A Bearer session and an X-API-Key are unaffected either way.
        """
        return bool(get("published_views",
                        "allow_anonymous_when_auth_disabled", False))

    # ── Self-service API key approval ──
    @property
    def require_key_approval(self) -> bool:
        """When True (default), API key requests go through admin approval. When False, keys are auto-generated."""
        return bool(get("published_views", "require_key_approval", True))

    # ── Phase 134-E: PV warm-up ──
    @property
    def warmup_enabled(self) -> bool: return bool(get("published_views", "warmup_enabled", False))
    @property
    def warmup_interval_minutes(self) -> int: return int(get("published_views", "warmup_interval_minutes", 5))
    @property
    def warmup_max_concurrent(self) -> int: return int(get("published_views", "warmup_max_concurrent", 3))

    @property
    def kafka(self) -> "_KafkaCfg":
        """Phase 98-I: Kafka-driven cache invalidation config sub-section."""
        return _KafkaCfg()

    # 2026-10-23 -- these accessors were written INSIDE _KafkaCfg (2026-10-17), so
    # config.published_views had none of them: /api/published-apis/idle crashed
    # (500) without ?days=, and the rollup interval reader's try/except fell back to
    # 60 whatever was configured.  Guard: test_published_views_cfg_accessors_2026_10_23.
    # 2026-10-17 -- the inventory + lifecycle (core/published_api/)
    @property
    def lifecycle_retired_status(self) -> int:
        """What a RETIRED API answers: 410 (default) or 404."""
        return int(get("published_views", "lifecycle_retired_status", 410))

    @property
    def lifecycle_sunset_notice_days(self) -> int:
        """Days before a deprecated API's sunset its consumers are told once more."""
        return int(get("published_views", "lifecycle_sunset_notice_days", 7))

    @property
    def inventory_idle_days_default(self) -> int:
        """The inventory's "no calls in N days" default N (retirement candidates)."""
        return int(get("published_views", "inventory_idle_days_default", 30))

    # the rollup (core/published_api/rollup.py)
    @property
    def rollup_enabled(self) -> bool: return bool(get("published_views", "rollup_enabled", True))
    @property
    def rollup_interval_seconds(self) -> int: return int(get("published_views", "rollup_interval_seconds", 60))
    @property
    def rollup_lag_minutes(self) -> int: return int(get("published_views", "rollup_lag_minutes", 10))
    @property
    def rollup_hourly_retention_days(self) -> int: return int(get("published_views", "rollup_hourly_retention_days", 400))
    @property
    def rollup_daily_retention_days(self) -> int: return int(get("published_views", "rollup_daily_retention_days", 0))
    @property
    def rollup_latency_bin_ratio(self) -> float: return float(get("published_views", "rollup_latency_bin_ratio", 1.5))
    @property
    def metrics_exact_percentile_max_rows(self) -> int: return int(get("published_views", "metrics_exact_percentile_max_rows", 200000))

    # the alerts (core/published_api/alerts.py)
    @property
    def alerts_enabled(self) -> bool: return bool(get("published_views", "alerts_enabled", True))
    @property
    def alert_group(self) -> str:
        """The Netcool AlertGroup the API alert kinds are seeded with (a member of netcool.ALERT_GROUPS)."""
        return str(get("published_views", "alert_group", "PUBLISHED_API") or "PUBLISHED_API")


class _KafkaCfg:
    """Typed accessors for published_views.kafka sub-section (Phase 98-I)."""
    @property
    def enabled(self) -> bool: return bool(get("published_views", "kafka_enabled", False))
    @property
    def bootstrap_servers(self) -> str: return str(get("published_views", "kafka_bootstrap_servers", "localhost:9092"))
    @property
    def topic_pattern(self) -> str: return str(get("published_views", "kafka_topic_pattern", "{table}_{partition_col}"))
    @property
    def consumer_group(self) -> str: return str(get("published_views", "kafka_consumer_group", "querystudio_cache_invalidation"))
    @property
    def auto_offset_reset(self) -> str: return str(get("published_views", "kafka_auto_offset_reset", "latest"))
    @property
    def session_timeout_ms(self) -> int: return int(get("published_views", "kafka_session_timeout_ms", 30000))
    @property
    def known_partition_cols(self) -> list:
        # Suffix list used by _parse_topic to split a topic like
        # "<table>_<partition_col>" back into the source table name +
        # partition column.  Site-configurable so deployments with
        # different naming conventions don't have to patch code.
        v = get("published_views", "kafka_known_partition_cols",
                ["business_date", "event", "code"])
        if isinstance(v, list):
            return [str(x) for x in v if x]
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        return ["business_date", "event", "code"]


published_views = _PublishedViewsCfg()


class _SmartPredictionsCfg:
    """Typed accessors for the ``smart_predictions`` config section (Phase 77)."""
    @property
    def enabled(self) -> bool: return bool(get("smart_predictions", "enabled", True))
    @property
    def max_chart_suggestions(self) -> int: return int(get("smart_predictions", "max_chart_suggestions", 5))
    @property
    def max_pivot_suggestions(self) -> int: return int(get("smart_predictions", "max_pivot_suggestions", 4))
    @property
    def profile_max_top_values(self) -> int: return int(get("smart_predictions", "profile_max_top_values", 10))
    @property
    def outlier_method(self) -> str: return str(get("smart_predictions", "outlier_method", "iqr"))
    @property
    def outlier_iqr_multiplier(self) -> float: return float(get("smart_predictions", "outlier_iqr_multiplier", 1.5))
    @property
    def profile_sample_limit(self) -> int: return int(get("smart_predictions", "profile_sample_limit", 100000))
    @property
    def inline_chart_enabled(self) -> bool: return bool(get("smart_predictions", "inline_chart_enabled", True))


smart_predictions = _SmartPredictionsCfg()


class _LocalLLMCfg:
    """Typed accessors for the ``local_llm`` config section (Phase 95)."""
    @property
    def enabled(self) -> bool: return bool(get("local_llm", "enabled", False))
    @property
    def model_path(self) -> str: return str(get("local_llm", "model_path", ""))
    @property
    def model_name(self) -> str: return str(get("local_llm", "model_name", ""))
    @property
    def n_ctx(self) -> int: return int(get("local_llm", "n_ctx", 512))  # 2026-09-15: fallback aligned to the DECLARED default.  They must stay identical (core/config.py:1262) -- a fallback that differs is a behaviour flip waiting for the key to be dropped, which is exactly how the iceberg snapshot indexer could re-arm itself.
    @property
    def n_gpu_layers(self) -> int: return int(get("local_llm", "n_gpu_layers", 0))
    @property
    def max_tokens(self) -> int: return int(get("local_llm", "max_tokens", 256))
    @property
    def temperature(self) -> float: return float(get("local_llm", "temperature", 0.1))
    @property
    def embedder_model(self) -> str: return str(get("local_llm", "embedder_model", "all-MiniLM-L6-v2"))
    @property
    def embedder_enabled(self) -> bool: return bool(get("local_llm", "embedder_enabled", True))
    @property
    def sql_generation_enabled(self) -> bool: return bool(get("local_llm", "sql_generation_enabled", True))
    @property
    def startup_preload(self) -> bool: return bool(get("local_llm", "startup_preload", True))
    @property
    def generation_timeout_seconds(self) -> int: return int(get("local_llm", "generation_timeout_seconds", 30))
    @property
    def finance_domain_hints(self) -> bool: return bool(get("local_llm", "finance_domain_hints", True))


local_llm = _LocalLLMCfg()


class _OnboardingCfg:
    """Typed accessors for the ``onboarding`` config section (Phase 100)."""
    @property
    def enabled(self) -> bool: return bool(get("onboarding", "enabled", True))
    @property
    def auto_show_on_first_login(self) -> bool: return bool(get("onboarding", "auto_show_on_first_login", True))
    @property
    def available_tours(self) -> list:
        # 2026-09-15: the fallback listed ONE tour while five are declared,
        # so dropping the key would silently hide four of them.
        return list(get("onboarding", "available_tours",
                        ["getting_started", "query_builder",
                         "business_reports", "data_quality",
                         "published_views"]))
    @property
    def default_tour(self) -> str: return str(get("onboarding", "default_tour", "getting_started"))


onboarding = _OnboardingCfg()


class _AdminGovernanceCfg:
    """Typed accessors for the ``admin_governance`` config section (Phase 102).

    Controls per-role rate limits, daily query quotas, export restrictions,
    and per-user resource caps. Admins can tune all values via the Governance
    tab without redeployment — values are read fresh on every request, so
    changes take effect instantly.
    """

    # ── Master kill switch ─────────────────────────────────────────────────
    @property
    def enabled(self) -> bool:
        return bool(get("admin_governance", "enabled", True))

    # ── Rate limiting on/off (FB-48, 2026-09-20) ───────────────────────────
    @property
    def rate_limit_enabled(self) -> bool:
        """Master switch for the GOVERNANCE rate limiters.

        Until 2026-09-20 this key had no reader at all: an admin who set it
        false to switch limiting OFF got limiting anyway.  That is the
        direction someone reaches mid-incident -- it failed to RELEASE, not
        merely to restrict, which is the worse half.

        Scope, deliberately: the per-role QUERY limiter (api/execute_api)
        and the EXPORT limiter (api/data_grid_api).  NOT the
        ``admin_sensitive`` limiter in api/deps.py -- that one guards admin
        routes against brute force and is a security control, so it is not
        reachable from a governance screen.

        Independent of ``enabled``: turning the whole section off must not
        be the only way to lift a rate limit, because it would take the
        daily quotas and the per-user caps with it.
        """
        return bool(get("admin_governance", "rate_limit_enabled", True))

    # ── Per-role rate limits (queries/min) ─────────────────────────────────
    @property
    def rate_limit_admin(self) -> int:
        return int(get("admin_governance", "rate_limit_admin", 120))

    @property
    def rate_limit_analyst(self) -> int:
        return int(get("admin_governance", "rate_limit_analyst", 60))

    @property
    def rate_limit_viewer(self) -> int:
        return int(get("admin_governance", "rate_limit_viewer", 30))

    # ── Daily query quotas (0 = unlimited) ─────────────────────────────────
    @property
    def daily_quota_admin(self) -> int:
        return int(get("admin_governance", "daily_quota_admin", 0))

    @property
    def daily_quota_analyst(self) -> int:
        return int(get("admin_governance", "daily_quota_analyst", 1000))

    @property
    def daily_quota_viewer(self) -> int:
        return int(get("admin_governance", "daily_quota_viewer", 200))

    # ── Export format restrictions (CSV list per role) ─────────────────────
    @property
    def export_formats_admin(self) -> str:
        return str(get("admin_governance", "export_formats_admin", "csv,excel,json,pdf"))

    @property
    def export_formats_analyst(self) -> str:
        return str(get("admin_governance", "export_formats_analyst", "csv,excel,json"))

    @property
    def export_formats_viewer(self) -> str:
        return str(get("admin_governance", "export_formats_viewer", "csv"))

    @property
    def export_rate_limit_per_minute(self) -> int:
        return int(get("admin_governance", "export_rate_limit_per_minute", 10))

    # ── Per-user resource caps (0 = unlimited) ─────────────────────────────
    @property
    def max_connections_per_user(self) -> int:
        return int(get("admin_governance", "max_connections_per_user", 20))

    @property
    def max_saved_queries_per_user(self) -> int:
        """FB-48 (2026-09-20) -- now read, by the same per-user resource
        quota chokepoint that enforces connections / schedules / published
        views.  0 = unlimited, which is the shipped default, so wiring it
        changed nothing until an admin sets it."""
        return int(get("admin_governance", "max_saved_queries_per_user", 0))

    @property
    def max_schedules_per_user(self) -> int:
        return int(get("admin_governance", "max_schedules_per_user", 10))

    @property
    def max_published_views_per_user(self) -> int:
        return int(get("admin_governance", "max_published_views_per_user", 20))

    # ── Misc tuning ────────────────────────────────────────────────────────
    @property
    def audit_log_max_results(self) -> int:
        return int(get("admin_governance", "audit_log_max_results", 1000))

    @property
    def daily_quota_cache_ttl_seconds(self) -> int:
        """TTL for the per-user daily-quota counter cache — avoids DB hit per request."""
        return int(get("admin_governance", "daily_quota_cache_ttl_seconds", 60))

    # ── Helpers — role-based lookup ────────────────────────────────────────
    # Phase 107-F: ``super_admin`` is mapped to ``admin`` for all governance
    # lookups (rate limits, quotas, export formats) — break-glass role inherits
    # the highest tier of every limit.
    def rate_limit_for_role(self, role: str) -> int:
        """Return the per-minute rate limit for a given role name."""
        role = (role or "viewer").lower()
        if role in ADMIN_TIER_ROLES:
            return self.rate_limit_admin
        if role == "analyst":
            return self.rate_limit_analyst
        return self.rate_limit_viewer

    def daily_quota_for_role(self, role: str) -> int:
        """Return the daily query quota for a role (0 = unlimited)."""
        role = (role or "viewer").lower()
        if role in ADMIN_TIER_ROLES:
            return self.daily_quota_admin
        if role == "analyst":
            return self.daily_quota_analyst
        return self.daily_quota_viewer

    def export_formats_for_role(self, role: str) -> set:
        """Return the set of allowed export formats for a role."""
        role = (role or "viewer").lower()
        if role in ADMIN_TIER_ROLES:
            raw = self.export_formats_admin
        elif role == "analyst":
            raw = self.export_formats_analyst
        else:
            raw = self.export_formats_viewer
        return {fmt.strip().lower() for fmt in raw.split(",") if fmt.strip()}


admin_governance = _AdminGovernanceCfg()


class _BusinessQueryBuilderCfg:
    """Typed accessors for the ``business_query_builder`` config section (Phase 130)."""
    @property
    def enabled(self) -> bool: return bool(get("business_query_builder", "enabled", True))
    @property
    def max_tables_per_query(self) -> int: return int(get("business_query_builder", "max_tables_per_query", 10))
    @property
    def default_row_limit(self) -> int: return int(get("business_query_builder", "default_row_limit", 5000))
    @property
    def custom_abbreviations(self) -> dict:
        raw = get("business_query_builder", "custom_abbreviations", {})
        return raw if isinstance(raw, dict) else {}
    @property
    def custom_category_patterns(self) -> dict:
        raw = get("business_query_builder", "custom_category_patterns", {})
        return raw if isinstance(raw, dict) else {}


business_query_builder = _BusinessQueryBuilderCfg()


class _SparkConnectCfg:
    """Typed accessors for the ``spark_connect`` config section.

    Zero-download distributed query engine — routes large S3 queries to a
    Spark Connect server instead of pre-downloading files to the FastAPI pod.
    All properties are read fresh from ``_cfg`` on every access so runtime
    config updates (via PUT /api/admin/spark-connect/config) take effect
    without restart.
    """
    @property
    def enabled(self) -> bool: return bool(get("spark_connect", "enabled", False))
    @property
    def server_url(self) -> str: return str(get("spark_connect", "server_url", "sc://spark-connect-server:15002"))
    @property
    def token(self) -> str:
        """Bearer token literal for the ;token= URL param (dev/test only)."""
        return str(get("spark_connect", "token", "") or "")
    @property
    def system_account(self) -> str:
        """Name of a System Account whose `token` field carries the bearer
        token (production pattern — encrypted at rest in DB)."""
        return str(get("spark_connect", "system_account", "") or "")
    @property
    def row_threshold(self) -> int: return int(get("spark_connect", "row_threshold", 10_000_000))
    @property
    def timeout_seconds(self) -> int: return int(get("spark_connect", "timeout_seconds", 600))
    @property
    def max_result_rows(self) -> int: return int(get("spark_connect", "max_result_rows", 0))
    @property
    def stream_via_local_iterator(self) -> bool:
        return bool(get("spark_connect", "stream_via_local_iterator", True))
    @property
    def session_idle_timeout_minutes(self) -> int: return int(get("spark_connect", "session_idle_timeout_minutes", 30))
    @property
    def max_sessions_per_user(self) -> int: return int(get("spark_connect", "max_sessions_per_user", 2))
    @property
    def max_concurrent_queries(self) -> int: return int(get("spark_connect", "max_concurrent_queries", 20))
    @property
    def circuit_breaker_failure_threshold(self) -> int: return int(get("spark_connect", "circuit_breaker_failure_threshold", 3))
    @property
    def circuit_breaker_cooldown_seconds(self) -> int: return int(get("spark_connect", "circuit_breaker_cooldown_seconds", 120))
    @property
    def executor_memory(self) -> str: return str(get("spark_connect", "executor_memory", "8g"))
    @property
    def executor_cores(self) -> int: return int(get("spark_connect", "executor_cores", 4))
    @property
    def min_executors(self) -> int: return int(get("spark_connect", "min_executors", 1))
    @property
    def max_executors(self) -> int: return int(get("spark_connect", "max_executors", 8))


spark_connect = _SparkConnectCfg()


class _SparkK8sCfg:
    """Typed accessors for the ``spark_k8s`` section (2026-08-22) — the
    QueryStudio-owned Spark-on-Kubernetes backend.  Every property maps to
    a key DECLARED in ``_DEFAULTS['spark_k8s']``."""
    @property
    def enabled(self) -> bool:
        return bool(get("spark_k8s", "enabled", False))
    @property
    def namespace(self) -> str:
        return str(get("spark_k8s", "namespace", "spark"))
    @property
    def submit_mode(self) -> str:
        """"auto" (default: probe at submit, store the shape on the row) |
        "spark_application" (CR + operator) | "driver_pod" (direct).

        An unknown value is REFUSED at settings build, not defaulted:
        silently falling back to the CR path on a cluster with no
        operator would turn a typo into "the heavy lane is unavailable"
        with a reason that names the wrong cause.
        """
        return str(get("spark_k8s", "submit_mode", "auto"))
    @property
    def master_url(self) -> str:
        return str(get("spark_k8s", "master_url",
                       "k8s://https://kubernetes.default.svc:443"))
    @property
    def image_pull_secrets(self) -> list:
        v = get("spark_k8s", "image_pull_secrets", []) or []
        return [str(x) for x in v if str(x or "").strip()]
    @property
    def image_driver_classes(self) -> list:
        """Declared JDBC driver classes of the job image ([] = the pinned five)."""
        v = get("spark_k8s", "image_driver_classes", []) or []
        if isinstance(v, str):
            v = [s for s in v.split(",")]
        return [str(x).strip() for x in v if str(x or "").strip()]
    @property
    def driver_run_as_user(self) -> str:
        return str(get("spark_k8s", "driver_run_as_user", "") or "")
    @property
    def image(self) -> str:
        return str(get("spark_k8s", "image", "querystudio/spark-etl:latest"))
    @property
    def image_pull_policy(self) -> str:
        return str(get("spark_k8s", "image_pull_policy", "Always"))
    @property
    def service_account(self) -> str:
        return str(get("spark_k8s", "service_account", "spark"))
    @property
    def callback_base_url(self) -> str:
        return str(get("spark_k8s", "callback_base_url",
                       "http://querystudio-api:8000"))
    @property
    def progress_interval_seconds(self) -> int:
        return int(get("spark_k8s", "progress_interval_seconds", 30))
    @property
    def job_ceiling_seconds(self) -> int:
        return int(get("spark_k8s", "job_ceiling_seconds", 43200))
    @property
    def creds_via_secret(self) -> bool:
        return bool(get("spark_k8s", "creds_via_secret", True))
    @property
    def driver_cores(self) -> int:
        return int(get("spark_k8s", "driver_cores", 1))
    @property
    def driver_memory(self) -> str:
        return str(get("spark_k8s", "driver_memory", "4g"))
    @property
    def executor_cores(self) -> int:
        return int(get("spark_k8s", "executor_cores", 4))
    @property
    def executor_memory(self) -> str:
        return str(get("spark_k8s", "executor_memory", "8g"))
    @property
    def num_executors(self) -> int:
        return int(get("spark_k8s", "num_executors", 4))
    @property
    def spark_conf(self) -> dict:
        v = get("spark_k8s", "spark_conf", {})
        return dict(v) if isinstance(v, dict) else {}
    @property
    def max_retries(self) -> int:
        return int(get("spark_k8s", "max_retries", 1))
    @property
    def retry_backoff_seconds(self) -> int:
        return int(get("spark_k8s", "retry_backoff_seconds", 300))
    @property
    def size_classes(self) -> dict:
        """H2 — named execution profiles: ``{name: {job_timeout_seconds: n}}``."""
        v = get("spark_k8s", "size_classes", {})
        return dict(v) if isinstance(v, dict) else {}
    @property
    def session_token_expected_ttl_seconds(self) -> int:
        """D10 — expected life of a temporary credential.  0 disables."""
        return int(get("spark_k8s",
                       "session_token_expected_ttl_seconds", 3600))
    @property
    def pending_timeout_seconds(self) -> int:
        """D9 — a CR still SUBMITTED (no driver pod) after this many
        seconds is a NEVER-STARTED failure, not a slow one.  0 disables."""
        return int(get("spark_k8s", "pending_timeout_seconds", 900))
    @property
    def job_timeout_seconds(self) -> int:
        return int(get("spark_k8s", "job_timeout_seconds", 7200))
    @property
    def webhook_grace_seconds(self) -> int:
        return int(get("spark_k8s", "webhook_grace_seconds", 120))
    @property
    def adoption_grace_seconds(self) -> int:
        return int(get("spark_k8s", "adoption_grace_seconds", 120))
    @property
    def reconcile_interval_seconds(self) -> int:
        return int(get("spark_k8s", "reconcile_interval_seconds", 15))
    @property
    def completed_cr_ttl_seconds(self) -> int:
        return int(get("spark_k8s", "completed_cr_ttl_seconds", 3600))
    @property
    def status_poll_interval_seconds(self) -> int:
        return int(get("spark_k8s", "status_poll_interval_seconds", 10))
    @property
    def poll_timeout_seconds(self) -> int:
        return int(get("spark_k8s", "poll_timeout_seconds", 7200))
    @property
    def availability_cache_seconds(self) -> int:
        return int(get("spark_k8s", "availability_cache_seconds", 60))
    @property
    def classifier_markers(self) -> list:
        v = get("spark_k8s", "classifier_markers", [])
        return list(v) if isinstance(v, (list, tuple)) else []
    @property
    def cr_states(self) -> dict:
        v = get("spark_k8s", "cr_states", {})
        return dict(v) if isinstance(v, dict) else {}
    @property
    def preupgrade_sweep_enabled(self) -> bool:
        return bool(get("spark_k8s", "preupgrade_sweep_enabled", True))
    @property
    def artifact_bucket(self) -> str:
        return str(get("spark_k8s", "artifact_bucket", "") or "")
    @property
    def artifact_prefix(self) -> str:
        return str(get("spark_k8s", "artifact_prefix",
                       "querystudio/spark-artifacts") or "")
    @property
    def artifact_connection_id(self) -> int:
        try:
            return int(get("spark_k8s", "artifact_connection_id", 0) or 0)
        except (TypeError, ValueError):
            return 0


spark_k8s = _SparkK8sCfg()


# BF-428 — Pluggable S3 reader strategies.  See core/s3_readers/__init__.py
# for the architecture.  This config selects the default strategy + per-
# connection overrides.
class _S3ReadersCfg:
    """Typed accessors for the ``s3_readers`` config section."""
    @property
    def default(self) -> str:
        """Default reader name when no per-query override and no per-
        connection pin.  Special value ``"auto"`` triggers heuristic
        selection (preserves pre-BF-428 behaviour in Phase A; full
        cost model in Phase F).  Concrete reader names ship in later
        phases: ``direct_httpfs``, ``full_predownload``,
        ``pyarrow_s3fs``, ``smart_predownload``, ``s3_select``,
        ``athena``."""
        return str(get("s3_readers", "default", "auto") or "auto")
    @property
    def per_connection(self) -> dict:
        """Map connection_id -> reader_name.  Lets the admin pin a
        specific reader to a connection (e.g. "use Athena for the
        warehouse connection, PyArrow for everything else").  Phase G
        wires the connection_id through the call path.

        BF-428J Round 2 MED-R2-4 — values are now whitelist-validated
        against the same regex as forced_reader.  Bad values are dropped
        with a WARN log so an admin typo doesn't silently make every
        query on that connection fall through to the default.

        BF-428J Round 3 LOW-4 — regex sourced from
        ``core.s3_readers.READER_NAME_RE`` (single source of truth)."""
        v = get("s3_readers", "per_connection", {}) or {}
        if not isinstance(v, dict):
            return {}
        try:
            from core.s3_readers import READER_NAME_RE as _name_re
        except Exception:
            import re as _re
            _name_re = _re.compile(r"^[a-z][a-z0-9_]{0,31}$")
        clean: dict = {}
        for k, val in v.items():
            if not isinstance(val, str) or not _name_re.match(val):
                logger.warning("[s3_readers] per_connection[%r]=%r is not a "
                               "valid reader name — dropping", k, val)
                continue
            clean[k] = val
        return clean

    # ── BF-428J Round 2 MED-R2-3 — positive-int helper ─────────────────
    @staticmethod
    def _positive_int(raw, default: int, name: str) -> int:
        """Coerce + validate a config value to a positive int.  Negative
        or non-numeric values warn + fall back to ``default``."""
        try:
            v = int(raw)
        except (TypeError, ValueError):
            logger.warning("[s3_readers] %s=%r is not int — using default %d",
                           name, raw, default)
            return default
        if v <= 0:
            logger.warning("[s3_readers] %s=%d must be positive — using "
                           "default %d", name, v, default)
            return default
        return v

    @staticmethod
    def _positive_float(raw, default: float, name: str) -> float:
        try:
            v = float(raw)
        except (TypeError, ValueError):
            logger.warning("[s3_readers] %s=%r is not numeric — using "
                           "default %s", name, raw, default)
            return default
        if v <= 0:
            logger.warning("[s3_readers] %s=%s must be positive — using "
                           "default %s", name, v, default)
            return default
        return v
    @property
    def auto_route_enabled(self) -> bool:
        """Phase F kill-switch.  When False, ``"auto"`` falls back to
        the simple proxy-on/off heuristic instead of the cost model.
        Useful if the cost model misroutes in a specific deployment."""
        return bool(get("s3_readers", "auto_route_enabled", True))
    # Per-strategy timeouts (Phase E uses these heavily for Athena polling)
    @property
    def athena_workgroup(self) -> str:
        return str(get("s3_readers", "athena_workgroup", "primary") or "primary")
    @property
    def athena_database(self) -> str:
        return str(get("s3_readers", "athena_database", "") or "")
    @property
    def athena_output_location(self) -> str:
        return str(get("s3_readers", "athena_output_location", "") or "")
    @property
    def athena_poll_interval_seconds(self) -> float:
        return _S3ReadersCfg._positive_float(
            get("s3_readers", "athena_poll_interval_seconds", 1.0),
            1.0, "athena_poll_interval_seconds")
    @property
    def athena_timeout_seconds(self) -> int:
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "athena_timeout_seconds", 300),
            300, "athena_timeout_seconds")
    @property
    def s3_select_max_file_bytes(self) -> int:
        """S3 Select limit.  Files above this are NOT routed to S3
        Select even when otherwise eligible — the API will reject."""
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "s3_select_max_file_bytes",
                5 * 1024 * 1024 * 1024),
            5 * 1024 * 1024 * 1024, "s3_select_max_file_bytes")
    # smart_predownload_footer_bytes was scoped to a feature not built
    # (footer-only smart variant — current SmartPredownloadReader uses
    # PyArrow which manages the footer fetch internally).  Removed in
    # BF-428J audit LOW-8.  If/when the footer-only variant lands,
    # re-add the accessor + JSON default.
    @property
    def pyarrow_max_rows(self) -> int:
        """Memory guardrail for the in-process Arrow Table built by
        PyArrowS3FsReader.  When exceeded the read truncates and
        ``ReadResult.extra.row_cap_hit = True`` so the auto-router
        (Phase F) avoids this reader for the same query shape next
        time."""
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "pyarrow_max_rows", 50_000_000),
            50_000_000, "pyarrow_max_rows")
    @property
    def pyarrow_default_region(self) -> str:
        """Region used when the boto3 client doesn't expose one (some
        on-prem S3 backends).  Falls back to ``us-east-1`` per AWS
        SDK convention."""
        return str(get("s3_readers", "pyarrow_default_region", "us-east-1")
                   or "us-east-1")
    @property
    def integration_enabled(self) -> bool:
        """BF-428G master switch.  When False (default), the legacy
        binary pre-download path runs unchanged (Phases A-F shipped
        but inert at the call site).  When True, ``duckdb_views.
        setup_registered_views`` consults the router to pick a reader
        per query.  Operators flip this on after smoke-testing the
        new readers in their environment."""
        return bool(get("s3_readers", "integration_enabled", False))
    @property
    def presigned_router_enabled(self) -> bool:
        """BF-429 master switch for the on-prem presigned-URL path.
        Independent of ``integration_enabled`` so on-prem operators
        can opt in separately.  When False (default), the on-prem
        ``_presigned_to_local`` legacy path runs unchanged (zero risk
        to existing on-prem deployments).  When True, the 4 presigned
        branches in ``duckdb_views`` consult the router; eligible
        readers are DirectHttpfs / FullPredownload / SmartPredownload.
        AWS-only readers (PyArrow+S3FS, S3 Select, Athena) decline
        via ``can_handle`` when the request carries a presigner."""
        return bool(get("s3_readers", "presigned_router_enabled", False))

    @property
    def onprem_pyarrow_enabled(self) -> bool:
        """Master opt-in for the ON-PREM PROJECTED read path (pyarrow +
        s3fs over the on-prem boto3 endpoint).  Default False.

        When False (default), the on-prem presigned path behaves exactly
        as before: the ``pyarrow_s3fs`` reader declines presigned mode and
        the legacy ``_presigned_to_local`` whole-file predownload runs.

        When True AND ``presigned_router_enabled`` is also True AND the
        connection is an on-prem boto3 endpoint (``endpoint_url`` set),
        the presigned bridge TRIES a column/row-group projected read via
        pyarrow+s3fs (boto3 underneath — so the libcurl SigV4/self-signed
        blocker does NOT apply) and materialises an in-memory Arrow table,
        transferring only footer + surviving row-group column chunks.

        SAFETY: any failure (TLS handshake, s3fs error, untranslatable
        filter, OOM/row-cap, missing column) FALLS OPEN to the existing
        predownload path and returns a byte-identical correct result.
        Independent of ``integration_enabled`` (AWS path)."""
        return bool(get("s3_readers", "onprem_pyarrow_enabled", False))

    # ── BF-428J — knobs the audit found hardcoded ────────────────────────
    @property
    def enabled_readers(self) -> list:
        """Allowlist of reader names ``register_default_readers`` will
        register.  ``["*"]`` (default) registers every shipped reader.
        Air-gapped or AWS-free deployments can pin to a subset
        (e.g. ``["direct_httpfs", "full_predownload", "pyarrow_s3fs"]``)
        so the admin dropdown / per-query chip don't show options that
        will never work in their environment.

        BF-428J audit LOW-9 — type-coerce silent → now WARNs so an
        admin who set ``enabled_readers: "athena"`` (string, not list)
        sees the cause."""
        v = get("s3_readers", "enabled_readers", ["*"])
        if not isinstance(v, list):
            logger.warning("[s3_readers] config enabled_readers must be a "
                           "list, got %s; falling back to [\"*\"]",
                           type(v).__name__)
            return ["*"]
        return v

    @property
    def fallback_when_proxy_active(self) -> str:
        """Reader the simple (non-cost) auto-select picks when proxy/
        cache/parallel-predownload is active.  Default preserves
        pre-BF-428 behaviour (full_predownload).  Operators can pin
        to ``pyarrow_s3fs`` to start saving bandwidth before flipping
        the cost-router on."""
        return str(get("s3_readers", "fallback_when_proxy_active",
                        "full_predownload") or "full_predownload")

    @property
    def fallback_when_proxy_off(self) -> str:
        """Reader the simple auto-select picks when proxy/cache/parallel
        are all off.  Default ``direct_httpfs`` (DuckDB native)."""
        return str(get("s3_readers", "fallback_when_proxy_off",
                        "direct_httpfs") or "direct_httpfs")

    # Cost-model overrides — admin tunes per-deployment via JSON config
    @property
    def cost_overrides(self) -> dict:
        """``{reader_name: {setup_cost: float, per_byte: float, per_file:
        float}}`` overrides for the cost-based auto-router.  Operators
        with unusual deployments (very fast NFS, slow Athena workgroup,
        etc.) tune coefficients here without code changes."""
        v = get("s3_readers", "cost_overrides", {}) or {}
        return v if isinstance(v, dict) else {}

    @property
    def byte_fraction_overrides(self) -> dict:
        """``{reader_name: float}`` overrides for the cost-router's
        "fraction of file bytes that transit our process" estimates.
        Default fractions are calibrated for typical analytical
        queries; deployments with wide/narrow projections may differ."""
        v = get("s3_readers", "byte_fraction_overrides", {}) or {}
        return v if isinstance(v, dict) else {}

    @property
    def estimated_default_file_bytes(self) -> int:
        """When the cost-router has no real size estimate, assume this
        many bytes per file.  Default 100 MiB matches typical Iceberg
        target file size (128-512 MiB common range, 100 conservative
        toward picking smaller-bytes-through-proxy strategies)."""
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "estimated_default_file_bytes",
                100 * 1024 * 1024),
            100 * 1024 * 1024, "estimated_default_file_bytes")

    # Athena (additional knobs the audit found hardcoded)
    @property
    def athena_fetch_batch_size(self) -> int:
        """Rows per ``cursor.fetchmany()`` call when reading Athena
        results.  Memory-vs-latency trade-off; 1000 is balanced."""
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "athena_fetch_batch_size", 1000),
            1000, "athena_fetch_batch_size")

    # PyArrow + s3fs HTTP timeouts (audit M14 — were missing entirely!)
    @property
    def pyarrow_connect_timeout_seconds(self) -> int:
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "pyarrow_connect_timeout_seconds", 10),
            10, "pyarrow_connect_timeout_seconds")

    @property
    def pyarrow_read_timeout_seconds(self) -> int:
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "pyarrow_read_timeout_seconds", 60),
            60, "pyarrow_read_timeout_seconds")

    @property
    def pyarrow_max_attempts(self) -> int:
        return _S3ReadersCfg._positive_int(
            get("s3_readers", "pyarrow_max_attempts", 3),
            3, "pyarrow_max_attempts")

    @property
    def pyarrow_sts_refresh_attempts(self) -> int:
        """How many times to rebuild s3fs with refreshed STS creds when
        an ExpiredToken bubbles up mid-read.  Default 1 retry.  0 is
        valid (= no retries) so this knob uses a non-negative validator
        instead of strict-positive.

        BF-428J Round 3 LOW-1 — TypeError/ValueError now WARN (was
        silent) for diagnostic parity with ``_positive_int``."""
        raw = get("s3_readers", "pyarrow_sts_refresh_attempts", 1)
        try:
            v = int(raw)
        except (TypeError, ValueError):
            logger.warning("[s3_readers] pyarrow_sts_refresh_attempts="
                           "%r is not int — using default 1", raw)
            return 1
        if v < 0:
            logger.warning("[s3_readers] pyarrow_sts_refresh_attempts="
                           "%d must be >= 0 — using default 1", v)
            return 1
        return v

    # Smart pre-download
    @property
    def smart_cache_namespace(self) -> str:
        """Sub-bucket under cache_backend for SmartPredownloadReader.
        Lets ops route smart-cache to a separate physical storage
        (e.g. faster NFS share) by changing the namespace."""
        return str(get("s3_readers", "smart_cache_namespace", "smart")
                    or "smart")

    @property
    def cache_parquet_compression(self) -> str:
        """Compression codec used when reading writers (Smart pre-down,
        arrow→parquet materialisation).  ``snappy`` is fast + universal.
        ``zstd`` cuts ~30% bytes at small CPU cost; ``none`` for fastest
        write at largest disk.

        BF-428J audit MEDIUM-6 — unknown value silently coerces to
        snappy; now WARNs once so an admin typo (e.g. ``"znappy"``) is
        debuggable."""
        raw = str(get("s3_readers", "cache_parquet_compression", "snappy")
                   or "snappy")
        v = raw.lower()
        if v not in ("snappy", "gzip", "zstd", "lz4", "brotli", "none"):
            logger.warning("[s3_readers] unknown cache_parquet_compression="
                           "%r — falling back to snappy", raw)
            return "snappy"
        return v

    @property
    def arrow_temp_prefix(self) -> str:
        """File-name prefix for arrow-table → temp-parquet
        materialisation (when no DuckDB con is available for
        in-process registration).  Mirrors the deployment-naming
        convention the rest of QueryStudio uses for traceability.

        BF-428J audit LOW-10 — validated against a safe-filename regex
        so an admin can't set ``"../etc/"`` or other path-traversal
        attempts that would let mkstemp escape its tmp directory."""
        import re as _re
        v = str(get("s3_readers", "arrow_temp_prefix", "qs_arrow_")
                 or "qs_arrow_")
        # Conservative whitelist: alphanumeric, underscore, hyphen, dot
        if not _re.match(r"^[a-zA-Z0-9_.\-]+$", v):
            logger.warning("[s3_readers] arrow_temp_prefix=%r contains "
                           "unsafe characters — falling back to "
                           "'qs_arrow_'", v)
            return "qs_arrow_"
        return v


s3_readers = _S3ReadersCfg()


class _SecretsCfg:
    """Phase 154 (2026-06-25) -- typed accessors for the ``secrets``
    config block consumed by ``core.qs_credentials`` (the QueryStudio
    twin of ETL/qs_credentials/resolver.py).

    Three-layer toggle for vault resolution (env var > per-account
    flag > this block.enabled).  Cache TTL + key env mirrors the ETL
    pattern so the same prod secret lands in a comparable cache
    shape across both pods.
    """
    @property
    def shared_connection_needs_vault(self) -> bool:
        """A connection others use logs in through Vault (core/shared_connection_vault.py)."""
        return bool(get("secrets", "shared_connection_needs_vault", True))

    @property
    def enabled(self) -> bool:
        """Global vault-resolution enable.  Default False (dev-safe);
        prod flips True via config.json or QS_USE_VAULT env var."""
        return bool(get("secrets", "enabled", False))

    @property
    def machine(self) -> str:
        return str(get("secrets", "machine", "openshift") or "openshift")

    @property
    def token_method(self) -> str:
        return str(get("secrets", "token_method", "JWT") or "JWT")

    @property
    def cache_ttl_seconds(self) -> int:
        """In-process TTL cache; default 15 min (matches ETL)."""
        return int(get("secrets", "cache_ttl_seconds", 900) or 0)

    @property
    def disk_cache_enabled(self) -> bool:
        return bool(get("secrets", "disk_cache_enabled", True))

    @property
    def disk_cache_path(self) -> str:
        return str(get("secrets", "disk_cache_path",
                        "/tmp/.qs_secrets.enc")
                    or "/tmp/.qs_secrets.enc")

    @property
    def disk_cache_ttl_seconds(self) -> int:
        return int(get("secrets", "disk_cache_ttl_seconds", 86400) or 0)

    @property
    def disk_cache_key_env(self) -> str:
        return str(get("secrets", "disk_cache_key_env", "QS_SECRETS_KEY")
                    or "QS_SECRETS_KEY")

    # ── Phase 158 R10 (2026-06-28) -- runtime knobs that used to be
    # env-only.  Surfaced through config so the admin UI can edit them
    # without a pod restart.  Resolution order at every call site:
    #     env var (if set)  ->  this config value  ->  hardcoded default
    # so existing env-var-based prod overrides keep winning.

    @property
    def verify_ssl(self) -> bool:
        """TLS verification for vault HTTP calls.  Default OFF for
        back-compat with corp self-signed Vault behind a private CA."""
        return bool(get("secrets", "verify_ssl", False))

    @property
    def timeout_seconds(self) -> float:
        """Per-request HTTP timeout for vault calls (seconds)."""
        return float(get("secrets", "timeout_seconds", 3.0) or 3.0)

    @property
    def legacy_ciphers(self) -> bool:
        """Wire SECLEVEL=1 into the per-pool ssl_context (scoped to
        vault calls only).  For legacy Vault with weak ciphers."""
        return bool(get("secrets", "legacy_ciphers", False))

    @property
    def app_name(self) -> str:
        """``appName`` query param used in the test-mode machine-token
        URL.  Defaults to ``querystudio``."""
        return str(get("secrets", "app_name", "querystudio")
                    or "querystudio")

    @property
    def cred_refresh_hours(self) -> float:
        """Hours between full cache invalidation (bounds rotation
        propagation).  Set 0 to disable the daemon."""
        return float(get("secrets", "cred_refresh_hours", 24) or 24)

    @property
    def daemon_force(self) -> bool:
        """Force the periodic-refresh daemon to start even in Spark
        contexts (where ephemeral pods make it pointless by default)."""
        return bool(get("secrets", "daemon_force", False))

    @property
    def token_path(self) -> str:
        """Explicit override for the K8s SA machine-token path.  Empty
        string means: probe the standard locations in order."""
        return str(get("secrets", "token_path", "") or "")


secrets = _SecretsCfg()


class _BrainStoreCfg:
    """Phase 160 (2026-07-01) — typed accessors for the
    ``brain_store`` section.  Consumed by
    :mod:`core.brain_duckdb_store` (readers) and
    :mod:`core.brain_duckdb_mirror` (writer daemon).

    All keys are optional; brain defaults ON per the operator
    directive (feedback_brain_on_by_default) because the read path
    is fail-open and a disabled store falls straight through to the
    primary DB.  Set ``enabled=false`` in config.json for a full
    kill-switch or via the ``QS_BRAIN_STORE_ENABLED=false`` env var.
    """

    @property
    def enabled(self) -> bool:
        return bool(get("brain_store", "enabled", True))

    @property
    def dir(self) -> str:
        """Empty string = derive from ``paths.data_dir/brain_store``."""
        return str(get("brain_store", "dir", "") or "")

    @property
    def mirror_enabled(self) -> bool:
        # DEFAULT OFF -- mirror duplicates metadata; admin opts in.
        return bool(get("brain_store", "mirror_enabled", False))

    @property
    def mirror_interval_seconds(self) -> int:
        return int(get("brain_store", "mirror_interval_seconds", 300) or 300)

    @property
    def mirror_hot_lookback_hours(self) -> int:
        return int(get("brain_store", "mirror_hot_lookback_hours", 24) or 24)

    @property
    def mirror_hot_top_k(self) -> int:
        return int(get("brain_store", "mirror_hot_top_k", 500) or 500)


brain_store = _BrainStoreCfg()


class _DuckdbPoolCfg:
    """Phase 168 — warm DuckDB subprocess pool knobs.  DEFAULT ON since
    2026-08-22 (soaked; see PHASE_168_WARM_POOL_DESIGN.md).

    Reused workers cross query boundaries -- isolation is by construction
    (a fresh connection per request).  Env kill-switch
    ``QS_DUCKDB_POOL=off`` forces it off regardless of config.
    """

    @property
    def enabled(self) -> bool:
        _env = (os.environ.get("QS_DUCKDB_POOL", "") or "").strip().lower()
        if _env in ("off", "0", "false", "no"):
            return False
        if _env in ("on", "1", "true", "yes"):
            return True
        # 2026-09-15: aligned to the declared default (True).
        return bool(get("duckdb_pool", "enabled", True))

    @property
    def size(self) -> int:
        return int(get("duckdb_pool", "size", 0) or 0)

    @property
    def max_requests_per_worker(self) -> int:
        return int(get("duckdb_pool", "max_requests_per_worker", 200) or 200)

    @property
    def max_worker_rss_mb(self) -> int:
        return int(get("duckdb_pool", "max_worker_rss_mb", 4096) or 4096)

    @property
    def worker_idle_ttl_seconds(self) -> int:
        return int(get("duckdb_pool", "worker_idle_ttl_seconds", 300) or 300)

    @property
    def checkout_timeout_seconds(self) -> float:
        return float(get("duckdb_pool", "checkout_timeout_seconds", 5) or 5)

    @property
    def db_instance_reuse(self) -> bool:
        return bool(get("duckdb_pool", "db_instance_reuse", True))

    @property
    def metadata_cache_mode(self) -> str:
        _m = str(get("duckdb_pool", "metadata_cache_mode", "auto") or "auto").strip().lower()
        # An unknown mode must degrade toward SAFETY (revalidate), never
        # toward trust — a typo cannot silently become "full".
        return _m if _m in ("auto", "revalidate", "full") else "revalidate"

    @property
    def db_instance_max_age_seconds(self) -> int:
        try:
            _v = int(get("duckdb_pool", "db_instance_max_age_seconds", 3600))
        except (TypeError, ValueError):
            return 3600
        # <=0 is INVALID (0 must never mean "unlimited") -> default.
        return _v if _v > 0 else 3600


duckdb_pool = _DuckdbPoolCfg()
