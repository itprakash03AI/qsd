"""A connection other people use logs in through Vault (owner, 2026-11-05).

"Only a Vault based connection can be shared; no private password."  So an admin
may keep a typed password on a PRIVATE connection.  A shared one holds no typed
secret, any System Account it names reads Vault, a person's own AWS portal
password is not allowed on it, and a source that logs in by password must name a
Vault account.  What has no password to hold passes: an IAM role, Kerberos, a
local folder, a portal connection using the default System Account.

A later admin flag to disable private connections altogether is planned, not built.

Asked when a connection is saved or granted to someone, and when a System
Account is taken off Vault.  It is NOT asked when a query runs: a connection
already saved keeps working, so a deploy cannot stop feeds overnight; it is
listed (GET /api/admin/connections/shared-without-vault) until it is moved, and
scripts/feed_readiness_check.py fails on that list.

Switch: ``secrets.shared_connection_needs_vault`` (on by default).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.crypto import _map_sensitive


def enforced() -> bool:
    from core.config import secrets
    return secrets.shared_connection_needs_vault


def typed_secrets(config: Any) -> List[str]:
    """The secret fields this config holds a value in, at any depth.  A masked
    ``***`` or an ``enc::`` value is a held secret too."""
    held: List[str] = []

    def _note(field: str, value: Any) -> Any:
        if value not in (None, ""):
            held.append(field)
        return value

    _map_sensitive(config or {}, _note)
    return sorted(set(held))


def account_ref(config: Dict[str, Any]) -> Any:
    """The same three spellings ``credential_resolver`` reads, in its order."""
    cfg = config or {}
    return cfg.get("system_account_id") or cfg.get("system_account_name") or cfg.get("system_account")


def _account(ref: Any, db: Any) -> Optional[Dict[str, Any]]:
    try:
        return db.get_system_account(int(ref))
    except (TypeError, ValueError):
        return db.get_system_account_by_name(str(ref))


def _logs_in_by_password(connection_type: Optional[str]) -> bool:
    """A SQL source, except Athena, which signs with AWS keys or a role."""
    from core.connectors import SQL_CONNECTOR_TYPES
    kind = str(connection_type or "").lower()
    return kind in SQL_CONNECTOR_TYPES and kind != "athena"


#: The same spellings connectors/__init__.py reads as a password login.
_PASSWORD_AUTH = {"", "basic", "password", "snowflake", "userpass"}


def _uses_a_persons_password(config: Dict[str, Any]) -> bool:
    cfg = config or {}
    if str(cfg.get("auth_mode") or "").lower() != "portal":
        return False
    return str(cfg.get("credential_source") or "").lower() in ("personal", "hybrid")


def why_not_vault(config: Dict[str, Any], db: Any, connection_type: Optional[str] = None) -> Optional[str]:
    """In plain words, what stands between this config and Vault; None = nothing."""
    cfg = config or {}
    held = typed_secrets(cfg)
    if held:
        return f"it holds a typed secret ({', '.join(held)})"
    if _uses_a_persons_password(cfg):
        return "it logs in with each person's own password"
    ref = account_ref(cfg)
    if ref in (None, "", 0):
        auth = str(cfg.get("auth_type") or cfg.get("authenticator") or "").strip().lower()
        if _logs_in_by_password(connection_type) and auth in _PASSWORD_AUTH:
            return "it names no Vault System Account"
        return None
    account = _account(ref, db)
    if not account:
        return f"its System Account ({ref}) does not exist"
    if not account.get("use_vault"):
        return f"its System Account {account.get('name')} uses its own password, not Vault"
    return None


def refusal(config: Dict[str, Any], is_shared: bool, db: Any,
            connection_type: Optional[str] = None) -> Optional[str]:
    """The sentence a save of this connection is refused with; None = allowed."""
    if not is_shared or not enforced():
        return None
    why = why_not_vault(config, db, connection_type)
    if not why:
        return None
    return (f"A shared connection must log in through Vault, and {why}. Choose a Vault System "
            "Account and clear the typed value, or make the connection private.")


def counts_as_shared(connection: Dict[str, Any], granted_ids: set) -> bool:
    """Who else can use it: shared, granted, or a legacy row with no owner
    (``_user_can_see_connection`` shows those to everyone)."""
    return bool(connection.get("is_shared") or not connection.get("created_by")
                or connection.get("id") in granted_ids)


def not_on_vault(connections: List[Dict[str, Any]], granted_ids: set, db: Any) -> List[Dict[str, Any]]:
    """Every connection others can use that has not moved to Vault yet."""
    out = []
    for conn in connections or []:
        if not counts_as_shared(conn, granted_ids):
            continue
        reason = why_not_vault(conn.get("config") or {}, db, conn.get("connection_type"))
        if reason:
            out.append({"id": conn.get("id"), "name": conn.get("name"),
                        "connection_type": conn.get("connection_type"), "why": reason})
    return out


def account_leaving_vault_refusal(account: Dict[str, Any], connections: List[Dict[str, Any]],
                                  granted_ids: set) -> Optional[str]:
    """A System Account cannot leave Vault while a connection others use names it."""
    if not enforced():
        return None
    names = [c.get("name") for c in connections or []
             if counts_as_shared(c, granted_ids)
             and str(account_ref(c.get("config") or {})) in (str(account.get("id")), str(account.get("name")))]
    if not names:
        return None
    return (f"System Account {account.get('name')} must stay on Vault: these shared connections "
            f"log in with it: {', '.join(sorted(str(n) for n in names))}.")
