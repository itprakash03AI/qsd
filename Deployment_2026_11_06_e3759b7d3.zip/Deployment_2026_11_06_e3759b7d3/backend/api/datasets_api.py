"""
Semantic Layer — Business Datasets API (Phase 53)

Provides CRUD for business datasets, columns, classes, relationships,
drill hierarchies, pre-defined conditions, and aggregation awareness rules.

2026-08-09 dataset SELF-SERVICE: modeling is no longer admin-only.
Analysts create PRIVATE datasets over connections they are already
entitled to use, and mutate only what they own (owner / owner-group /
admin — resolved by the shared ``core.entitlements`` policy, the same
resolver business reports and feeds trust).  What stays privileged:

  * PUBLISHING (org-wide visibility) — toggle_publish is admin-only.
    Creating a private dataset and broadcasting it to every user are
    different acts; the publish gate is what keeps self-service from
    becoming ungoverned model sprawl.
  * CERTIFICATION — admin-only quality signal (few certified shared
    models, many private ones — the Power BI / Tableau governance shape).
  * Aggregation awareness / agg cache / merged dimensions / config —
    infrastructure that changes NUMBERS or serves other owners' data.

Every connection-touching route enforces the connection entitlement
rule (own / shared / legacy-unowned / ACL-granted — the exact
GET /api/connections visibility rule), FAIL-CLOSED: a dataset over a
connection you cannot see would be a data leak.

Endpoint summary:
  GET    /api/datasets                      list datasets (published + own + group-owned for non-admin)
  POST   /api/datasets                      create dataset (admin/analyst; quota CAP; connection-entitled)
  GET    /api/datasets/{id}                 get dataset with all children (published or owner/group/admin)
  PUT    /api/datasets/{id}                 update dataset (owner/group/admin; publish+owner change stay admin)
  DELETE /api/datasets/{id}                 delete dataset + cascade (owner/group/admin)
  POST   /api/datasets/{id}/publish         toggle publish state (ADMIN — governed line)
  POST   /api/datasets/{id}/certify         toggle certification (ADMIN — governed line)
  POST   /api/datasets/preview-columns       preview auto-classified columns (any user entitled to the connection)
  POST   /api/datasets/{id}/auto-detect     auto-detect columns from connection schema (owner/group/admin)

  GET    /api/datasets/{id}/classes         list classes
  POST   /api/datasets/{id}/classes         create class (owner/group/admin)
  PUT    /api/datasets/classes/{cid}        update class (owner/group/admin)
  DELETE /api/datasets/classes/{cid}        delete class (owner/group/admin)

  GET    /api/datasets/{id}/columns         list columns (filtered by role)
  POST   /api/datasets/{id}/columns         create column (owner/group/admin)
  POST   /api/datasets/{id}/columns/bulk    bulk create columns (owner/group/admin)
  PUT    /api/datasets/columns/{cid}        update column (owner/group/admin)
  DELETE /api/datasets/columns/{cid}        delete column (owner/group/admin)

  GET    /api/datasets/{id}/relationships   list relationships
  POST   /api/datasets/{id}/relationships   create relationship (owner/group/admin)
  PUT    /api/datasets/relationships/{rid}  update relationship (owner/group/admin)
  DELETE /api/datasets/relationships/{rid}  delete relationship (owner/group/admin)

  GET    /api/datasets/{id}/hierarchies     list drill hierarchies
  POST   /api/datasets/{id}/hierarchies     create hierarchy (owner/group/admin)
  PUT    /api/datasets/hierarchies/{hid}    update hierarchy (owner/group/admin)
  DELETE /api/datasets/hierarchies/{hid}    delete hierarchy (owner/group/admin)

  GET    /api/datasets/{id}/conditions      list pre-defined conditions
  POST   /api/datasets/{id}/conditions      create condition (owner/group/admin)
  PUT    /api/datasets/conditions/{cid}     update condition (owner/group/admin)
  DELETE /api/datasets/conditions/{cid}     delete condition (owner/group/admin)

  GET    /api/datasets/{id}/agg-awareness   list aggregation awareness rules
  POST   /api/datasets/{id}/agg-awareness   create rule (admin — routing changes numbers)
  DELETE /api/datasets/agg-awareness/{aid}  delete rule (admin)

  GET    /api/admin/semantic-layer/config   get config
  PUT    /api/admin/semantic-layer/config   update config (admin)
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from pathlib import Path
from typing import Any, Dict, List, NamedTuple, Optional

from api.strict_request import StrictRequestModel
from api.models.query_models import CLIENT_REQUEST_ID_PATTERN
from fastapi import APIRouter, Depends, HTTPException, Query as FastQuery
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin, require_role
from api.connector_errors import (
    raise_if_self_clearing, refusal_status, source_unavailable_503,
)
from core.db_errors import is_unique_violation
from core.config_active import NameHeld
from core.connectors.base import SourceUnavailableError
from core.audit import audit_event
from core.json_utils import sanitize_for_json
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


async def _run_engine_off_loop(engine_fn, *, db, execution_id: str,
                               username: str, client_request_id: Optional[str] = None,
                               **engine_kwargs):
    """FB-24 (2026-09-19): run a blocking federation-engine call OFF the
    event loop, through the INTERACTIVE admission gate.

    The engine call keeps its own ``execution_id`` (the gate consumes a
    kwarg of the same name, hence the partial).  A refusal (global load
    shed or a full typed queue) is recorded on the execution row and raised
    as the 503 + Retry-After that /api/execute answers -- a refused run is
    a failed execution with a reason, never a hang and never a 200.

    H1 (2026-10-07): ``client_request_id`` -- the caller's correlation id --
    rides the queued events while the run waits for a slot, and is the
    handle its cancel names.  A wait the caller cancelled is recorded as
    CANCELLED (not failed) and answered 409 ``cancelled_while_queued``.
    """
    import functools as _functools
    from core.reports.admission import ReportAdmissionRefused, run_admitted
    from core.worker_pool import WorkType
    bound = _functools.partial(engine_fn, execution_id=execution_id, **engine_kwargs)
    try:
        # 2026-10-07: an interactive preview waits, fairly and bounded, in
        # the pod-wide queue when the pod is at its global cap.
        from core.reports.admission import interactive_global_wait
        return await run_admitted(WorkType.INTERACTIVE, bound,
                                  execution_id=execution_id, username=username,
                                  global_wait=interactive_global_wait(),
                                  client_request_id=client_request_id)
    except ReportAdmissionRefused as ref:
        try:
            await _adb(db.update_federation_execution, execution_id,
                       status=("cancelled" if ref.kind == "cancelled" else "failed"),
                       error_message=ref.reason)
        except Exception:                                # noqa: BLE001
            logger.warning("execution %s: could not record admission refusal",
                           execution_id)
        raise ref.as_http()

_db_manager = None


def set_datasets_dependencies(db_manager):
    """Called once from main.py startup."""
    global _db_manager
    _db_manager = db_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _ensure_dataset_exists(dataset_id: int) -> Dict[str, Any]:
    ds = _require_db().get_dataset(dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_id} not found")
    return ds


def _filter_columns_by_role(columns: List[Dict[str, Any]], role: str,
                            user: Optional[dict] = None) -> List[Dict[str, Any]]:
    """THE column role_whitelist predicate — if whitelist is empty, all
    roles see the column.  2026-08-23: the glossary used to carry its own
    inline copy of this check (the same fact resolved two ways); it now
    calls here.  When ``user`` is provided, admin-tier callers
    (``is_admin_like``) bypass the whitelist — the documented 2026-08-22
    glossary rule ("admins see everything").  Callers that pass only
    ``role`` keep the historical strict behaviour unchanged; whether
    get_dataset/list_columns should also grant the admin bypass is an
    open intent question logged in the plan ledger, not decided here."""
    if user is not None and is_admin_like(user):
        return list(columns)
    return [
        c for c in columns
        if not c.get("role_whitelist") or role in c["role_whitelist"]
    ]


# ═══════════════════════════════════════════════════════════════════════════════
# 2026-08-09 dataset self-service — authorization helpers
#
# The DECISION policy lives in core.entitlements (the resolver business
# reports / feeds already trust); these helpers only resolve rows and map
# denials to HTTP.  Everything fails CLOSED.
# ═══════════════════════════════════════════════════════════════════════════════


def _ds_can_view(ds: Dict[str, Any], user: dict) -> bool:
    from core.entitlements import dataset_can_view
    return dataset_can_view(ds, user, db=_require_db())


def _ds_can_edit(ds: Dict[str, Any], user: dict) -> bool:
    from core.entitlements import dataset_can_edit
    return dataset_can_edit(ds, user, db=_require_db())


def _require_dataset_view(dataset_id: int, user: dict) -> Dict[str, Any]:
    """404 when missing, 403 when the caller may not see it."""
    ds = _ensure_dataset_exists(dataset_id)
    if not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to view this dataset (it is not published "
                   "and you are not its owner)")
    return ds


def _require_dataset_edit(dataset_id: int, user: dict) -> Dict[str, Any]:
    """404 when missing, 403 when the caller may not mutate it."""
    ds = _ensure_dataset_exists(dataset_id)
    if not _ds_can_edit(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to modify this dataset — only its owner, "
                   "the owner group, or an admin can. Ask the owner (see the "
                   "dataset's Owner field) or an admin for access.")
    return ds


def _require_child_edit(child: Optional[Dict[str, Any]], user: dict,
                        not_found_detail: str) -> Dict[str, Any]:
    """Authorize a child-row mutation against its OWNING dataset.
    404 when the child is missing; otherwise same policy as
    ``_require_dataset_edit`` on the parent."""
    if not child:
        raise HTTPException(status_code=404, detail=not_found_detail)
    _require_dataset_edit(int(child["dataset_id"]), user)
    return child


def _collect_connection_ids(connection_ids: Optional[List[Any]] = None,
                            source_tables: Optional[List[Dict[str, Any]]] = None) -> List[int]:
    """Every connection id a dataset definition touches (deduplicated)."""
    ids: set = set()
    for cid in connection_ids or []:
        if cid is not None:
            try:
                ids.add(int(cid))
            except (TypeError, ValueError):
                continue
    for st in source_tables or []:
        cid = (st or {}).get("connection_id")
        if cid is not None:
            try:
                ids.add(int(cid))
            except (TypeError, ValueError):
                continue
    return sorted(ids)


def _assert_connection_entitlement(user: dict, connection_ids: List[int]) -> None:
    """★ THE LEAK GATE — a dataset over a connection the caller cannot use
    is a data leak, so this FAILS CLOSED at every edge.

    2026-08-23: the DECISION moved to ``core.entitlements.
    denied_connection_ids`` so Data Quality rules (which also execute SQL
    against a caller-supplied connection_id) resolve the SAME fact through
    the SAME code instead of growing a twin.  This wrapper only maps the
    decision to HTTP 403."""
    from core.entitlements import denied_connection_ids
    denied = denied_connection_ids(user, connection_ids, db=_require_db())
    if denied:
        cid = denied[0]
        raise HTTPException(
            status_code=403,
            detail=f"You are not entitled to use connection {cid}. "
                   "A dataset can only be built over connections you can "
                   "already access — ask an admin to share the connection "
                   "or grant you access to it.")

def _enforce_dataset_quota(user: dict) -> None:
    """Per-user dataset CAP — a THROTTLE, never a silent failure.

    Refuses politely (HTTP 409, matching the Phase 102-F
    ``enforce_user_resource_quota`` contract) with the route to request
    more.  Admins bypass; ``max_datasets_per_user <= 0`` = unlimited.
    """
    if is_admin_like(user):
        return
    from core import config
    try:
        cap = int(config.semantic_layer.max_datasets_per_user)
    except Exception:
        return  # unreadable cap must not block creation (cap, not gate)
    if cap <= 0:
        return
    username = str((user or {}).get("username", "") or "")
    if not username:
        return
    try:
        current = _require_db().count_user_datasets(username)
    except Exception as exc:
        logger.warning("dataset quota count failed for %s (skipping cap): %s",
                       username, exc)
        return
    if current >= cap:
        raise HTTPException(
            status_code=409,
            detail=(f"Dataset limit reached: you already own {current}/{cap} "
                    "datasets. Delete one you no longer need, or ask an admin "
                    "to raise the per-user limit "
                    "(semantic_layer.max_datasets_per_user)."))


def _assert_owner_group_membership(user: dict, owner_group_id: Optional[int]) -> None:
    """A non-admin may only assign a dataset to a group THEY belong to —
    otherwise ownership could be handed to (or hidden inside) an arbitrary
    group.  Fail-closed on lookup errors."""
    if owner_group_id is None or is_admin_like(user):
        return
    username = str((user or {}).get("username", "") or "")
    ok = False
    try:
        db = _require_db()
        ok = username and int(owner_group_id) in {
            int(g) for g in (db.user_groups_for_username(username) or [])}
    except Exception as exc:
        logger.warning("owner_group membership lookup failed (fail-closed): %s", exc)
        ok = False
    if not ok:
        raise HTTPException(
            status_code=403,
            detail="You can only assign a dataset to a group you are a member of")


# ═══════════════════════════════════════════════════════════════════════════════
# Dataset-from-query source resolution (2026-08-22)
# ═══════════════════════════════════════════════════════════════════════════════
#
# SNAPSHOT vs LIVE-REFERENCE — the deliberate choice, stated:
#
# A dataset built from a saved query stores a SNAPSHOT of the resolved SQL in
# ``base_query`` plus provenance (source_type/source_id/sha256/timestamp) in
# ``source_tables[0]``.  When the underlying query later changes, the dataset
# KEEPS RUNNING THE SNAPSHOT; the drift is made VISIBLE (``source_ref.drift``
# on GET /api/datasets/{id}) and re-snapshotting is an explicit owner act
# (POST /api/datasets/{id}/refresh-source).
#
# Why snapshot: the reports subsystem answered this exact question on
# 2026-08-18 — publish is a VERSION SNAPSHOT; consumers read it, authors edit
# a draft.  A dataset is the same shape of artifact: its columns were
# classified against a SPECIFIC output shape, and reports/agg-cache cubes sit
# on top of those columns.  A live reference would let an edit to the saved
# query silently invalidate every column mapping (a renamed output column =
# binder error at best, silently different numbers at worst).  Snapshot +
# visible drift + explicit refresh fails safe; refresh also invalidates the
# dataset's agg-cache entries.  (Feeds resolve live per run — a feed re-reads
# its source each execution and has no column model to break; the analogy
# that matters here is the report, not the feed.)

_DATASET_SOURCE_TYPES = ("saved_query", "sql_file", "published_view")


def _sha256_text(s: str) -> str:
    import hashlib
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()


def _get_active_source_record(db, source_type: str,
                              source_id: int) -> Optional[Dict[str, Any]]:
    """The live, ACTIVE record behind a source ref, or None.

    One lookup shared by the entitlement gate and the drift check — the
    feed resolver only enforces is_active for sql_file, so a soft-deleted
    saved query would otherwise read as alive here."""
    if source_type == "saved_query":
        rec = db.get_query(int(source_id))
    elif source_type == "sql_file":
        rec = db.get_sql_file(int(source_id))
    elif source_type == "published_view":
        rec = db.get_published_view(int(source_id))
    else:
        return None
    if not rec or not rec.get("is_active", True):
        return None
    return rec


def _assert_source_read_entitlement(db, source_type: str, source_id: int,
                                    user: dict) -> Dict[str, Any]:
    """Fail-closed read gate on the underlying source artifact.

    saved_query / sql_file: owner OR shared OR admin — the exact rule
    ``queries_api._require_query_view`` / the sql-files list apply.  404 (not
    403) so this is not an existence oracle, matching queries_api.
    published_view: must exist and be active — it is the org-published
    surface by definition.
    """
    from api.deps import is_owner_or_shared
    if source_type not in _DATASET_SOURCE_TYPES:
        raise HTTPException(status_code=422,
                            detail=f"Unsupported dataset source_type: {source_type}")
    rec = _get_active_source_record(db, source_type, source_id)
    if not rec or (source_type in ("saved_query", "sql_file")
                   and not is_owner_or_shared(rec, user)):
        _label = {"saved_query": "Saved query", "sql_file": "SQL file",
                  "published_view": "Published view"}[source_type]
        raise HTTPException(status_code=404,
                            detail=f"{_label} {source_id} not found")
    return rec


def _resolve_dataset_source(db, source: "DatasetSourceRef",
                            user: dict) -> Dict[str, Any]:
    """Resolve a DatasetSourceRef to executable SQL + provenance.

    Resolution goes through ``core.feed_sql_resolver.resolve_feed_sql`` —
    the SAME function the feed preview path uses (which itself routes
    through ``core.feed.source_plan`` exactly like the feed RUN path, and
    through the same ``query_config → raw_sql | build_query_sql`` chain the
    Published API uses).  NOT a second resolver: a twin resolver is this
    codebase's dominant defect class.

    Returns ``{"sql", "connection_ids", "provenance", "resolved"}``.
    Raises HTTPException 404/422 — never a silent empty.
    """
    _assert_source_read_entitlement(db, source.source_type, source.source_id, user)

    from core.feed_sql_resolver import resolve_feed_sql
    resolved = resolve_feed_sql(db, {
        "source_type": source.source_type,
        "source_id": source.source_id,
        "connection_id": source.connection_id,
        "query_params": None,
    })

    status = resolved.get("source_status") or "empty"
    sql = (resolved.get("sql") or "").strip()
    if status != "ok" or not sql:
        raise HTTPException(
            status_code=422,
            detail=f"Cannot build a dataset from {source.source_type} "
                   f"{source.source_id}: {status} — "
                   f"{resolved.get('source_message') or 'source has no SQL'}")

    # A cross-source artifact (secondary side + combine mode) is TWO queries
    # on TWO connections; a dataset is ONE queryable relation.  Refuse with
    # the working alternative named — never run half the source silently
    # (the exact defect class source_plan.py exists to prevent for feeds).
    if resolved.get("secondary_sql") or resolved.get("combine_mode"):
        raise HTTPException(
            status_code=422,
            detail=f"{source.source_type} {source.source_id} is a CROSS-SOURCE "
                   f"artifact (combine_mode="
                   f"{resolved.get('combine_mode') or 'set'}). A dataset wraps "
                   f"ONE query on ONE connection — create one dataset per side "
                   f"and combine them with POST /api/datasets/federation/union "
                   f"(UNION ALL BY NAME) or /api/datasets/federation/execute "
                   f"(merge/join).")

    conn_ids: List[int] = []
    if resolved.get("connection_id"):
        conn_ids.append(int(resolved["connection_id"]))

    from datetime import datetime, timezone
    provenance = {
        "source_type": source.source_type,
        "source_id": int(source.source_id),
        "source_name": resolved.get("source_name") or "",
        "connection_id": (int(resolved["connection_id"])
                          if resolved.get("connection_id") else None),
        "ref_mode": "snapshot",
        "source_sql_sha256": _sha256_text(sql),
        "snapshotted_at": datetime.now(timezone.utc).isoformat(),
        "dialect": resolved.get("dialect") or "",
    }
    return {"sql": sql, "connection_ids": conn_ids,
            "provenance": provenance, "resolved": resolved}


def _carry_scan_config(ds: Dict[str, Any],
                       provenance: Dict[str, Any]) -> Dict[str, Any]:
    """Re-snapshotting a source must not silently DELETE the scan knob.

    2026-09-05.  A query-sourced dataset stores its whole definition in
    ``source_tables[0]``, and both re-binding (``PUT`` with ``source``) and
    re-snapshotting (``POST /refresh-source``) REPLACE that list with a
    freshly built provenance dict.  ``partition_config`` -- the operator's
    progressive-partition-scan declaration, read at execution time by
    ``core.federation_engine.dataset_partition_config`` -- lives on that
    same entry, so without this it would vanish on the next refresh: set,
    working, then gone, with a 200 and no message.  That is the defect class
    this repo hit twice on 2026-09-05 alone (``flow_id``,
    ``partition_config``), and once is enough.

    ONE expression used by BOTH call sites, so the two cannot drift into
    different answers about what a re-snapshot preserves.  It carries HOW to
    scan, never WHAT to scan: the provenance fields (source id, sha256,
    connection) always come from the fresh resolution, and a partition
    column the new SQL does not expose is REFUSED by name at plan time and
    the query runs whole.

    2026-09-05 round 2 -- it used to read the knob through
    ``_source_ref_of``, whose docstring says "the provenance entry of a
    QUERY-sourced dataset".  A TABLE-sourced dataset has no such entry, so
    there was nothing to carry and its declaration was dropped just as
    silently -- the same defect, one entry type along.  It now looks for
    the knob wherever it is declared.

    A DISAGREEMENT CARRIES NOTHING.  If the previous entries declare
    different configs the dataset was already in a refusing state
    (``dataset_partition_config`` runs the query whole and says which knob
    disagreed).  Collapsing them onto the single rebuilt provenance entry
    would RESOLVE that conflict by position -- silently turning a refusal
    into whichever declaration happened to be first, which is the exact
    bug fixed in ``dataset_partition_config`` the same day.
    """
    out = dict(provenance)

    import json as _json
    declared = [st.get("partition_config") for st in (ds.get("source_tables") or [])
                if isinstance(st, dict) and isinstance(st.get("partition_config"), dict)
                and st.get("partition_config")]
    if not declared:
        return out
    try:
        distinct = {_json.dumps(p, sort_keys=True, default=str) for p in declared}
    except Exception:                       # noqa: BLE001
        distinct = {repr(p) for p in declared}
    if len(distinct) > 1:
        logger.warning(
            "dataset %s declares %d DIFFERENT partition configs; carrying "
            "none across the source change rather than picking one by "
            "position", ds.get("id"), len(distinct))
        return out
    out["partition_config"] = dict(declared[0])
    return out


def _validate_partition_config(part: Any, where: str) -> None:
    """Judge ONE ``partition_config`` document, or return quietly.

    2026-09-05.  Extracted from ``_validate_partition_configs`` when the
    declaration gained a second HOME (the dataset-level column, which is
    the only home a SQL-mode dataset has -- it has no ``source_tables``
    entries at all).  Extracted rather than copied: two validators would
    be two answers to "what is a legal declaration", and the whole reason
    ``PartitionConfigModel`` exists is that there was one answer.

    ``where`` names the thing the author would go and edit, and is
    rendered verbatim into the 422, because "invalid partition_config"
    with no location sends them looking through a document.

    ``None`` (not declared) and ``{}`` (declared empty, which every
    reader treats as not declared) both pass -- a refusal that fires on a
    legitimate input is a defect too.
    """
    if part is None:
        return
    from pydantic import ValidationError
    from api.models.query_models import PartitionConfigModel

    if not isinstance(part, dict):
        raise HTTPException(
            status_code=422,
            detail=f"{where}: 'partition_config' must be an object, not "
                   f"{type(part).__name__}.")
    if not part:
        return
    try:
        PartitionConfigModel.model_validate(part)
    except ValidationError as exc:
        problems = []
        for err in exc.errors():
            key = ".".join(str(p) for p in err.get("loc") or ()) or "(root)"
            why = err.get("msg") or "is invalid"
            if err.get("type") == "extra_forbidden":
                why = ("is not a partition_config setting -- check the "
                       "spelling; unknown keys are refused rather than "
                       "dropped, because a dropped key looks like it "
                       "was applied")
            problems.append(f"'{key}' {why}")
        raise HTTPException(
            status_code=422,
            detail=(f"{where}: invalid 'partition_config' -- "
                    + "; ".join(problems)))


def _assert_source_tables_renderable(db, source_tables: Any) -> None:
    """Refuse, at SAVE, a table name the engine could not render at RUN.

    2026-09-15.  ``OTG.OTG.QS_SPARK_DEMO`` -- the name the catalog browser
    hands the picker for an Oracle table -- was accepted here, auto-detect
    found its columns (the schema read ignores the catalog on Oracle), and
    the first execute died with ORA-03048 on ``"OTG"."OTG"."QS_SPARK_DEMO"``.
    Two paths answered "what table is this" differently.  Both now call
    ``core.connection_manager.resolve_table_address``; this gate calls it
    too, on the connection's real type, so what is admitted is exactly what
    will render.  The name is stored as sent -- resolution is the engine's,
    not a rewrite of the author's input.

    Only what the CALLER sent is judged (same posture as
    ``_validate_partition_configs``).  A connection that cannot be loaded is
    not judged here: the entitlement gate owns "does this connection exist",
    and the resolver refuses again at execute with the same reason.
    """
    from core.connection_manager import (
        TableAddressNotRenderable, _is_sql_connector_type,
        resolve_table_address,
    )
    if not isinstance(source_tables, list):
        return
    for st in source_tables:
        if not isinstance(st, dict):
            continue
        cid, table = st.get("connection_id"), st.get("table")
        if not cid or not table:
            continue
        try:
            conn = db.get_connection_raw(int(cid))
        except Exception as exc:                          # noqa: BLE001
            logger.info("source table %r on connection %s not judged at "
                        "admission (connection lookup failed: %s)",
                        table, cid, exc)
            continue
        if not conn or not _is_sql_connector_type(conn.get("connection_type")):
            continue
        cfg = conn.get("config") or {}
        try:
            resolve_table_address(
                str(table), conn.get("connection_type") or "",
                default_catalog=cfg.get("catalog", "") or "",
                default_schema=cfg.get("schema", "") or "")
        except TableAddressNotRenderable as exc:
            raise HTTPException(
                status_code=422,
                detail=f"source_tables: {exc} The dataset would be saved "
                       f"and fail at its first run, so it is refused now.")


def _validate_partition_configs(source_tables: Any) -> None:
    """Refuse a malformed ``partition_config`` AT THE DOOR, by name.

    2026-09-05 round 2.  ``PartitionConfigModel`` was added this morning for
    the published-view lane with an explicit argument: a raw dict would
    round-trip an author's ``max_bucket`` typo as silently as pydantic had
    dropped the whole field, and the planner would then use its default
    while the artifact showed the author's number nowhere.  The DATASET lane
    rides ``source_tables: List[Dict[str, Any]]`` -- which is what makes the
    key SURVIVE the save (see ``_carry_scan_config``) and, until this
    function, also what let ``max_bucket``, ``max_buckets: -5`` and
    ``bucket_strategy: "auto "`` be stored and then silently defaulted.

    ONE validator, not a second one: the same model both lanes use, so the
    two cannot answer differently about what a legal declaration is.  The
    model is ``extra="forbid"``, so an unknown key is a 422 that NAMES it
    rather than a shrug -- ``flow_id`` and ``partition_config`` were both
    silently-dropped keys in this repo within one day, and a third would be
    a habit.

    Validation only: the caller's dict is stored VERBATIM, never the
    model's dump.  Storing the dump would write every default into the
    dataset, so a later change to a default could not reach a dataset saved
    before it, and the round-trip an operator reads back would not be the
    document they sent.
    """
    if not isinstance(source_tables, list):
        return
    for idx, st in enumerate(source_tables):
        if not isinstance(st, dict):
            continue
        where = (str(st.get("table") or st.get("alias")
                     or st.get("source_name") or "").strip()
                 or f"#{idx}")
        _validate_partition_config(st.get("partition_config"),
                                   f"source table {where}")


def _source_ref_of(ds: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The provenance entry of a query-sourced dataset, or None."""
    for st in (ds.get("source_tables") or []):
        if isinstance(st, dict) and st.get("source_type") in _DATASET_SOURCE_TYPES \
                and st.get("source_id"):
            return st
    return None


def _compute_source_drift(db, ds: Dict[str, Any],
                          sref: Dict[str, Any]) -> Dict[str, Any]:
    """Compare the snapshot against what the source resolves to TODAY.

    Read-only and DB/disk-local (resolve_feed_sql never touches S3 or a
    connector).  Never raises — GET /api/datasets/{id} must not 500 because
    a source was deleted; that is exactly what this field is FOR.
    """
    try:
        # The feed resolver only enforces is_active for sql_file — check
        # activity OURSELVES so a soft-deleted saved query reads as deleted,
        # not in_sync.
        if _get_active_source_record(db, sref.get("source_type"),
                                     sref.get("source_id")) is None:
            return {"status": "source_deleted",
                    "message": f"The {sref.get('source_type')} this dataset "
                               f"was built from no longer exists (or was "
                               f"deactivated). The dataset keeps running its "
                               f"snapshot."}
        from core.feed_sql_resolver import resolve_feed_sql
        resolved = resolve_feed_sql(db, {
            "source_type": sref.get("source_type"),
            "source_id": sref.get("source_id"),
            "connection_id": sref.get("connection_id"),
            "query_params": None,
        })
        status = resolved.get("source_status") or "empty"
        if status == "not_found":
            return {"status": "source_deleted",
                    "message": f"The {sref.get('source_type')} this dataset "
                               f"was built from no longer exists. The dataset "
                               f"keeps running its snapshot."}
        if status != "ok" or not (resolved.get("sql") or "").strip():
            return {"status": "source_error",
                    "message": resolved.get("source_message")
                    or f"Source resolves with status '{status}'."}
        current_sha = _sha256_text((resolved.get("sql") or "").strip())
        if current_sha == sref.get("source_sql_sha256"):
            return {"status": "in_sync", "message": ""}
        return {"status": "drifted",
                "message": "The source query has changed since this dataset "
                           "snapshotted it. The dataset keeps running the "
                           "snapshot; POST /api/datasets/{id}/refresh-source "
                           "to re-snapshot deliberately."}
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("source drift check failed for dataset %s: %s",
                       ds.get("id"), exc)
        return {"status": "source_error",
                "message": f"Drift check failed: {exc}"}


# ═══════════════════════════════════════════════════════════════════════════════
# Request / Response Models (Pydantic v2)
# ═══════════════════════════════════════════════════════════════════════════════

class DatasetSourceRef(BaseModel):
    """2026-08-22 — a dataset built FROM an existing query artifact.

    The operator's report: *"no option select saved query...its biggest
    issues...why we are allowing to select table to create dataset"*.  A
    saved query (which is also how Business Query Builder queries persist —
    BQB saves into ``saved_queries``), a SQL file, or a published view is
    the thing the user already built, tested and shares; Published API and
    Feed Generation both accept exactly this vocabulary
    (``feed_api.FeedConfigCreate.source_type``), resolved through
    ``core.feed_sql_resolver.resolve_feed_sql`` — and dataset creation now
    resolves through THE SAME function, never a second resolver.

    ``connection_id`` — optional override: run the SAME query against a
    different connection (that is how one saved query becomes N datasets on
    N sources, unioned via POST /api/datasets/federation/union).
    """
    source_type: str = Field(..., pattern=r"^(saved_query|sql_file|published_view)$")
    source_id: int
    connection_id: Optional[int] = None


class DatasetCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    subject: str = Field(..., min_length=1, max_length=100)
    description: str = ""
    connection_ids: List[int] = []
    source_tables: List[Dict[str, Any]] = []
    base_query: str = ""
    is_published: bool = False
    # 2026-08-09 self-service: optional group ownership (must be one of the
    # caller's own groups unless admin).
    owner_group_id: Optional[int] = None
    # 2026-08-22: build the dataset FROM a saved query / SQL file /
    # published view (see DatasetSourceRef).  Mutually exclusive with
    # base_query / source_tables — two competing definitions of "where the
    # data comes from" is refused loudly, never merged by guesswork.
    source: Optional[DatasetSourceRef] = None
    # 2026-09-05 — the dataset-level progressive-scan declaration.
    #
    # A SQL-mode dataset produces a ``base_query`` and an EMPTY
    # ``source_tables``, so the per-entry home the table lane uses does
    # not exist for it: a custom-SQL dataset over a huge Starburst table
    # -- exactly the case progressive loading exists for -- could not
    # declare a partition column at all.  It is declared HERE, on the
    # dataset, which is also what the refusal rule has always said the
    # scope is: "one dataset has one partition plan".
    #
    # Typed ``Dict[str, Any]`` and NOT ``PartitionConfigModel``, on
    # purpose: the caller's document is stored VERBATIM (a model dump
    # would write every default into the dataset, so a later change to a
    # default could not reach a dataset saved before it).  It is judged
    # by that same model in ``_validate_partition_config``, so a typo is
    # a 422 that NAMES the key rather than a 200 that stored a setting
    # nothing reads.
    partition_config: Optional[Dict[str, Any]] = None


class DatasetUpdate(BaseModel):
    name: Optional[str] = None
    subject: Optional[str] = None
    description: Optional[str] = None
    connection_ids: Optional[List[int]] = None
    source_tables: Optional[List[Dict[str, Any]]] = None
    base_query: Optional[str] = None
    is_published: Optional[bool] = None
    owner_group_id: Optional[int] = None
    # 2026-08-22: (re)bind the dataset to a query source — same exclusivity
    # rule as DatasetCreate.
    source: Optional[DatasetSourceRef] = None
    # 2026-09-05 — see DatasetCreate.partition_config.  ``None`` means
    # "not sent" (this handler drops None fields), so the way to REMOVE a
    # declaration is to send ``{}``: empty is not a declaration, which is
    # the same reading ``dataset_partition_config`` and
    # ``_carry_scan_config`` already give it.
    partition_config: Optional[Dict[str, Any]] = None


class DetectColumnsRequest(BaseModel):
    connection_id: int
    sql: str = Field(..., min_length=1)


class PreviewColumnsRequest(BaseModel):
    connection_id: int
    table_path: str = Field(..., min_length=1)


class ClassCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    label: str = ""
    icon: str = ""
    sort_order: int = 0


class ClassUpdate(BaseModel):
    name: Optional[str] = None
    label: Optional[str] = None
    icon: Optional[str] = None
    sort_order: Optional[int] = None


class ColumnCreate(BaseModel):
    physical_name: str = Field(..., min_length=1, max_length=300)
    friendly_name: str = Field(..., min_length=1, max_length=300)
    column_type: str = Field("dimension", pattern=r"^(dimension|measure|detail|kpi)$")
    data_type: str = Field("string", pattern=r"^(string|number|date|boolean)$")
    aggregation: str = ""
    format_pattern: str = ""
    description: str = ""
    synonyms: List[str] = []
    role_whitelist: List[str] = []
    class_id: Optional[int] = None
    sort_order: int = 0
    is_hidden: bool = False


class ColumnUpdate(BaseModel):
    physical_name: Optional[str] = None
    friendly_name: Optional[str] = None
    column_type: Optional[str] = None
    data_type: Optional[str] = None
    aggregation: Optional[str] = None
    format_pattern: Optional[str] = None
    description: Optional[str] = None
    synonyms: Optional[List[str]] = None
    role_whitelist: Optional[List[str]] = None
    class_id: Optional[int] = None
    sort_order: Optional[int] = None
    is_hidden: Optional[bool] = None


class BulkColumnCreate(BaseModel):
    columns: List[ColumnCreate]


class RelationshipCreate(BaseModel):
    left_table: str = Field(..., min_length=1)
    right_table: str = Field(..., min_length=1)
    join_keys: List[Dict[str, str]]  # [{"left":"id","right":"order_id"}]
    join_type: str = Field("inner", pattern=r"^(inner|left|right|full)$")
    cardinality: str = Field("many_to_one", pattern=r"^(one_to_one|one_to_many|many_to_one|many_to_many)$")


class RelationshipUpdate(BaseModel):
    left_table: Optional[str] = None
    right_table: Optional[str] = None
    join_keys: Optional[List[Dict[str, str]]] = None
    join_type: Optional[str] = None
    cardinality: Optional[str] = None


class HierarchyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    levels: List[Dict[str, Any]]  # [{"column_id":1,"label":"Year"},{"column_id":2,"label":"Quarter"}]


class HierarchyUpdate(BaseModel):
    name: Optional[str] = None
    levels: Optional[List[Dict[str, Any]]] = None


class ConditionCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    where_clause: str = Field(..., min_length=1)
    label: str = ""
    description: str = ""
    sort_order: int = 0


class ConditionUpdate(BaseModel):
    name: Optional[str] = None
    where_clause: Optional[str] = None
    label: Optional[str] = None
    description: Optional[str] = None
    sort_order: Optional[int] = None


class AggAwarenessCreate(BaseModel):
    measure_col_id: int
    agg_table: str = Field(..., min_length=1)
    agg_dimensions: List[str] = []
    connection_id: Optional[int] = None
    is_enabled: bool = True


class AggAwarenessUpdate(BaseModel):
    # Phase 7 (2026-08-09): editing a mapping or re-enabling a disabled one
    # invalidates its verification verdict — it will not serve again until
    # the probe re-passes.
    measure_col_id: Optional[int] = None
    agg_table: Optional[str] = Field(None, min_length=1)
    agg_dimensions: Optional[List[str]] = None
    connection_id: Optional[int] = None
    is_enabled: Optional[bool] = None


class MetricCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    expression: str = Field(..., min_length=1)
    description: str = ""
    format_pattern: str = ""
    data_type: str = Field("number", pattern=r"^(number|string|date)$")
    depends_on: List[str] = []
    is_active: bool = True


class MetricUpdate(BaseModel):
    name: Optional[str] = None
    expression: Optional[str] = None
    description: Optional[str] = None
    format_pattern: Optional[str] = None
    data_type: Optional[str] = None
    depends_on: Optional[List[str]] = None
    is_active: Optional[bool] = None


def _column_limit_detail(have: int, adding: int, limit: int) -> str:
    """The refusal when a dataset would pass its column cap -- with the numbers,
    the setting and the way out.  2026-10-03: a 1,000-column Snowflake query
    answered only "Would exceed column limit (500)"."""
    return (f"This would give the dataset {have + adding} columns; a dataset holds at most "
            f"{limit} (semantic_layer.max_columns_per_dataset). Select only the columns you "
            f"need in the dataset's SQL instead of SELECT *, or ask an admin to raise the "
            f"limit (Admin > Semantic layer, or PUT /api/admin/semantic-layer/config).")


class SemanticLayerConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    auto_detect_column_types: Optional[bool] = None
    max_columns_per_dataset: Optional[int] = None
    max_datasets: Optional[int] = None
    cascading_prompts_enabled: Optional[bool] = None
    drill_hierarchies_enabled: Optional[bool] = None
    aggregation_awareness_enabled: Optional[bool] = None
    default_row_limit: Optional[int] = None
    synonym_matching_enabled: Optional[bool] = None
    max_metrics_per_dataset: Optional[int] = None
    metric_validation_enabled: Optional[bool] = None


# ═══════════════════════════════════════════════════════════════════════════════
# Dataset CRUD
# ═══════════════════════════════════════════════════════════════════════════════

async def _visible_datasets(user: dict, subject: Optional[str] = None) -> List[Dict[str, Any]]:
    """★ THE dataset-visibility rule — one resolver for every surface that
    lists datasets (GET /api/datasets AND the glossary; 2026-08-23).

    Admins (``is_admin_like``) and the observe-only support role see all;
    everyone else sees published datasets + their OWN drafts + drafts owned
    by a group they belong to (2026-08-09 self-service).  Before this
    helper the glossary carried an inline copy that silently omitted the
    support arm — the same visibility fact resolved two ways."""
    db = _require_db()
    from core.entitlements import is_support
    if is_admin_like(user) or is_support(user):
        return await _adb(db.list_datasets, subject=subject, published_only=False)
    username = str(user.get("username", "") or "")
    group_ids = []
    try:
        group_ids = await _adb(db.user_groups_for_username, username)
    except Exception as exc:
        logger.debug("dataset list group lookup failed (own+published only): %s", exc)
    return await _adb(db.list_datasets_visible, username=username,
                      group_ids=group_ids or [], subject=subject)


@router.get("/api/datasets", tags=["semantic-layer"])
async def list_datasets(
    subject: Optional[str] = None,
    user: dict = Depends(require_capability("datasets.view")),
):
    """List datasets visible to the caller — see ``_visible_datasets``."""
    return await _visible_datasets(user, subject=subject)


@router.post("/api/datasets", tags=["semantic-layer"])
async def create_dataset(body: DatasetCreate,
                         user: dict = Depends(require_capability("datasets.create"))):
    """2026-08-09 SELF-SERVICE: analysts create their own PRIVATE datasets.

    Kept governed here:
      * connection entitlement — fail-closed leak gate;
      * per-user quota — a CAP that throttles with a clear 409, never 500s;
      * publish-at-create — org-wide visibility stays an admin act, so a
        non-admin sending is_published=true is refused loudly (create it
        private, then request publication).
    """
    db = _require_db()
    from core import config
    # ── Governed line: creation is self-service, PUBLICATION is not. ──
    if body.is_published and not is_admin_like(user):
        raise HTTPException(
            status_code=403,
            detail="Publishing a dataset org-wide requires an admin. Create "
                   "it private first, then ask an admin to publish it.")
    await _adb(_assert_owner_group_membership, user, body.owner_group_id)

    # ── 2026-08-22: dataset FROM a saved query / sql_file / published view ──
    connection_ids = list(body.connection_ids or [])
    source_tables = list(body.source_tables or [])
    base_query = body.base_query or ""
    # A malformed scan declaration is refused HERE, before it is stored --
    # see ``_validate_partition_configs``.  Only what the CALLER sent is
    # checked; a config carried forward from an existing dataset is not
    # re-judged by a rule that may have tightened since it was written.
    _validate_partition_configs(source_tables)
    # ...and the dataset-level declaration, through the SAME model.  A
    # second validator would be a second answer to one question.
    _validate_partition_config(body.partition_config, "the dataset")
    # A table name the engine cannot render is refused HERE, with the
    # reason, by the same resolver that renders it at run time.
    await _adb(_assert_source_tables_renderable, db, source_tables)
    if body.source is not None:
        if base_query.strip() or source_tables:
            raise HTTPException(
                status_code=422,
                detail="Provide either 'source' OR base_query/source_tables, "
                       "not both — two competing definitions of where the "
                       "data comes from would be resolved by guesswork.")
        res = await _adb(_resolve_dataset_source, db, body.source, user)
        base_query = res["sql"]
        source_tables = [res["provenance"]]
        for cid in res["connection_ids"]:
            if cid not in connection_ids:
                connection_ids.append(cid)

    # ── Every connection the definition touches: resolved ONCE. ──
    #
    # 2026-09-04.  This was computed for the entitlement gate and then
    # THROWN AWAY -- ``create_dataset`` was handed the caller's raw
    # ``connection_ids``, which is empty whenever the caller describes the
    # source purely as ``source_tables`` (a table picked from a catalog,
    # and any API client that does the obvious thing).
    #
    # The consequence is not a missing field, it is the report running
    # against the WRONG ENGINE.  ``_resolve_connections`` reads the stored
    # ``connection_ids``; with none, the federation engine never learns the
    # dataset is backed by a SQL connector, skips the branch that quotes a
    # qualified name part-by-part, and emits::
    #
    #     FROM "hive.sales.t"      -- ONE identifier containing dots
    #
    # then executes it on the LOCAL DuckDB, which answers "Table with name
    # hive.sales.t does not exist".  A Starburst dataset built from a table
    # could not run, and the error named the table rather than the cause.
    #
    # The gate had the right answer all along.  Store what was gated: the
    # set that was authorised is the set the dataset uses, and they cannot
    # drift because there is only one of them.
    connection_ids = _collect_connection_ids(connection_ids, source_tables)
    _assert_connection_entitlement(user, connection_ids)
    # ── CAPs (both throttle politely — resource limits, not data gates). ──
    await _adb(_enforce_dataset_quota, user)
    if len(await _adb(db.list_datasets)) >= config.semantic_layer.max_datasets:
        raise HTTPException(status_code=400, detail=f"Maximum {config.semantic_layer.max_datasets} datasets allowed")
    try:
        result = await _adb(db.create_dataset,
            name=body.name, subject=body.subject, description=body.description,
            owner=user.get("username", "admin"), connection_ids=connection_ids,
            source_tables=source_tables, base_query=base_query,
            is_published=body.is_published,
            owner_group_id=body.owner_group_id,
            partition_config=body.partition_config,
        )
        logger.info("Dataset created: %s (id=%s) by %s", body.name, result["id"], user.get("username"))
        # 2026-08-31 — a query-sourced dataset with no columns is a 200 that
        # is useless to every consumer.  Detect them here, and report the
        # outcome either way: "columns: []" must never again be the only
        # thing the caller is told.
        # 2026-08-31 -- deliberately NOT auto-populating columns here.
        # Tried it; the suite caught why it is wrong.  Every caller that
        # supplies a definition also creates its own columns straight
        # afterwards (the creation wizard, DatasetManagerPage, and the
        # documented source+explicit-columns API pattern), so creating them
        # here too collides and 409s on the duplicate.  Detection belongs at
        # the point where columns are found to be MISSING -- see
        # /auto-detect (which now reads the SQL and needs no live source)
        # and /refresh-source (which heals a column-less dataset).
        return result
    except NameHeld:
        # 2026-10-30 -- a SWITCHED-OFF dataset keeps its name: say how to
        # switch it back on rather than "already exists" (nobody can see it)
        raise
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409, detail=f"Dataset name '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static path /api/datasets/glossary MUST appear before /{dataset_id} (BF-78 pattern)
@router.get("/api/datasets/glossary", tags=["semantic-layer"])
async def search_glossary(
    search: str = "",
    dataset_id: Optional[int] = None,
    column_type: Optional[str] = None,
    limit: int = FastQuery(default=100, ge=1, le=1000),
    user: dict = Depends(require_capability("datasets.view")),
):
    """Search across all visible datasets' columns + calculated metrics.

    2026-08-22: visibility matches GET /api/datasets — 2026-08-23 it is now
    the SAME resolver (``_visible_datasets``), not a copy, so the support
    role and any future visibility change stay in lockstep.  Column
    role_whitelist goes through ``_filter_columns_by_role`` (the canonical
    predicate) with the admin-tier bypass.  ``limit`` is validated (a
    negative slice used to silently DROP entries) and the response says
    when it truncated instead of quietly returning a subset."""
    db = _require_db()
    role = user.get("role", "viewer")
    datasets = await _visible_datasets(user)
    q = search.lower().strip()

    entries: List[Dict[str, Any]] = []
    for ds in datasets:
        if dataset_id and ds["id"] != dataset_id:
            continue
        ds_name = ds["name"]
        ds_id = ds["id"]
        # FB-49 (2026-09-20) -- the glossary LINKS to /datasets/<slug>/query.
        # Without the slug on the row the link would carry the id and be
        # canonicalised only after the page loads; carrying it here means the
        # address is right from the click.  ``None`` for a row the backfill
        # could not slug -- the UI falls back to the id, which resolves.
        ds_slug = ds.get("slug")

        # Columns — canonical whitelist predicate, then glossary-only skips.
        cols = _filter_columns_by_role(
            await _adb(db.list_dataset_columns, ds_id), role, user=user)
        for col in cols:
            if col.get("is_hidden"):
                continue
            if column_type and col.get("column_type") != column_type:
                continue
            if q:
                searchable = " ".join([
                    col.get("physical_name", ""),
                    col.get("friendly_name", ""),
                    col.get("description", ""),
                    " ".join(col.get("synonyms") or []),
                ]).lower()
                if q not in searchable:
                    continue
            entries.append({
                "entry_type": "column",
                "dataset_id": ds_id,
                "dataset_slug": ds_slug,
                "dataset_name": ds_name,
                "id": col["id"],
                "physical_name": col["physical_name"],
                "friendly_name": col["friendly_name"],
                "column_type": col.get("column_type", "dimension"),
                "data_type": col.get("data_type", "string"),
                "aggregation": col.get("aggregation", ""),
                "format_pattern": col.get("format_pattern", ""),
                "description": col.get("description", ""),
                "synonyms": col.get("synonyms") or [],
            })

        # Calculated Metrics
        metrics = await _adb(db.list_calculated_metrics, ds_id, active_only=True)
        for m in metrics:
            if column_type and column_type != "metric":
                continue
            if q:
                searchable = " ".join([
                    m.get("name", ""),
                    m.get("description", ""),
                    m.get("expression", ""),
                ]).lower()
                if q not in searchable:
                    continue
            entries.append({
                "entry_type": "metric",
                "dataset_id": ds_id,
                "dataset_slug": ds_slug,
                "dataset_name": ds_name,
                "id": m["id"],
                "physical_name": m["name"],
                "friendly_name": m["name"],
                "column_type": "metric",
                "data_type": m.get("data_type", "number"),
                "aggregation": "",
                "format_pattern": m.get("format_pattern", ""),
                "description": m.get("description", ""),
                "synonyms": [],
                "expression": m.get("expression", ""),
            })

    return {
        "entries": entries[:limit],
        "total": len(entries),
        # 2026-08-23: a capped answer must SAY it capped — the UI shows
        # "first {limit} of {total}" instead of silently paginating a subset.
        "truncated": len(entries) > limit,
    }


@router.get("/api/datasets/by-slug/{slug}", tags=["semantic-layer"])
async def get_dataset_by_slug(slug: str, user: dict = Depends(require_capability("datasets.view"))):
    """The dataset behind a browser URL (/datasets/<slug>/query) -- the ONE
    way the UI resolves a dataset token; the payload is exactly GET
    /{dataset_id}'s, including its visibility refusal.

    FB-49 (2026-09-20).  The REST API keeps numeric ids everywhere else: a
    report stores ``dataset_id``, every other dataset route takes one, and
    external consumers hold them.  A purely NUMERIC token is resolved by id
    by the same route -- that is what keeps every /datasets/<id>/query URL
    anyone has bookmarked working, and it is also the fallback for a legacy
    row the backfill could not slug.
    """
    db = _require_db()
    ds = await _adb(db.get_dataset_by_slug, slug)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return await get_dataset(int(ds["id"]), user)


@router.get("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def get_dataset(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    db = _require_db()
    ds = await _adb(db.get_dataset_full, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    # Published, or owner/group/admin/support (2026-08-09 self-service).
    if not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to view this dataset (it is not published "
                   "and you are not its owner)")
    # Filter columns by role
    role = user.get("role", "viewer")
    ds["columns"] = _filter_columns_by_role(ds.get("columns", []), role)
    # 2026-08-22: query-sourced dataset — surface WHICH artifact it came
    # from and whether that artifact has changed since the snapshot (the
    # snapshot-vs-live contract, made VISIBLE — see the module block above
    # _resolve_dataset_source).
    sref = _source_ref_of(ds)
    if sref:
        ds["source_ref"] = {
            **sref,
            "drift": await _adb(_compute_source_drift, db, ds, sref),
        }
    return ds


@router.put("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def update_dataset(dataset_id: int, body: DatasetUpdate,
                         user: dict = Depends(require_capability("datasets.edit"))):
    """2026-08-09 self-service: owner / owner-group / admin may edit.
    Still privileged inside the edit:
      * ``is_published`` — publish/unpublish stays an admin act;
      * ``owner_group_id`` — non-admins may only hand it to a group they
        belong to;
      * changed connections re-run the fail-closed entitlement gate (an
        owner must not repoint their dataset onto a connection they cannot
        see — same leak as at create time)."""
    db = _require_db()
    # Kept: the stored definition is needed to resolve which connections the
    # dataset touches when a PATCH sends only one half of the pair.
    ds = await _adb(_require_dataset_edit, dataset_id, user)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    # 2026-11-04: a report on a dataset naming a deleted connection is refused and says to fix it
    # on the Source tab, whose list cannot show a connection that is gone; the save lets go of it.
    if updates.get("connection_ids"):
        _kept = [c for c in updates["connection_ids"] if await _adb(db.get_connection_raw, c)]
        if len(_kept) != len(updates["connection_ids"]):
            logger.info("Dataset %s: removed connection(s) that no longer exist: %s", dataset_id,
                        sorted(set(updates["connection_ids"]) - set(_kept)))
        updates["connection_ids"] = _kept
    # 2026-11-04: emptying the connection of a query that names no source tables runs it on
    # the local engine, on nothing.  The Source tab did exactly that on every save.
    if updates.get("connection_ids") == [] and ds.get("connection_ids") \
            and str(updates.get("base_query", ds.get("base_query")) or "").strip() \
            and not updates.get("source_tables", ds.get("source_tables")):
        raise HTTPException(status_code=422, detail="This dataset's query needs a connection to run on. "
                                                    "Choose one, or remove the query.")
    # Same door, same validator, same model as create and as the published
    # view lane.  Deliberately BEFORE the ``source`` rebind below, so it
    # judges the caller's own source_tables and never the list
    # ``_carry_scan_config`` rebuilds from a previously stored config.
    if "source_tables" in updates:
        _validate_partition_configs(updates["source_tables"])
        await _adb(_assert_source_tables_renderable, db,
                   updates["source_tables"])
    if "partition_config" in updates:
        _validate_partition_config(updates["partition_config"], "the dataset")
    # 2026-08-22: (re)bind to a query source — resolves through the SAME
    # feed_sql_resolver chokepoint as create; mutually exclusive with an
    # explicit base_query/source_tables in the same request.
    if "source" in updates:
        if "base_query" in updates or "source_tables" in updates:
            raise HTTPException(
                status_code=422,
                detail="Provide either 'source' OR base_query/source_tables, "
                       "not both — two competing definitions of where the "
                       "data comes from would be resolved by guesswork.")
        res = await _adb(_resolve_dataset_source, db,
                         DatasetSourceRef(**updates.pop("source")), user)
        updates["base_query"] = res["sql"]
        updates["source_tables"] = [
            _carry_scan_config(ds, res["provenance"])]
        _new_conn_ids = list(updates.get("connection_ids") or [])
        for cid in res["connection_ids"]:
            if cid not in _new_conn_ids:
                _new_conn_ids.append(cid)
        updates["connection_ids"] = _new_conn_ids
    if "is_published" in updates and not is_admin_like(user):
        raise HTTPException(
            status_code=403,
            detail="Publishing or unpublishing a dataset requires an admin — "
                   "use POST /api/datasets/{id}/publish (admin) instead.")
    if "owner_group_id" in updates:
        await _adb(_assert_owner_group_membership, user, updates["owner_group_id"])
    if "connection_ids" in updates or "source_tables" in updates:
        # 2026-09-04 — same resolution as create, and for the same reason.
        # Editing a dataset to point at a different table used to leave the
        # OLD connection_ids in place: the entitlement gate was applied to
        # the new source and execution went on using the old connection.
        #
        # The effective set is what the caller sent, unioned with the
        # connections its source_tables name.  Fields the caller did not
        # send keep their stored value, so a PATCH that touches only one of
        # the two still resolves against the other.
        _eff_conn = (updates.get("connection_ids")
                     if "connection_ids" in updates
                     else ds.get("connection_ids"))
        _eff_tables = (updates.get("source_tables")
                       if "source_tables" in updates
                       else ds.get("source_tables"))
        updates["connection_ids"] = _collect_connection_ids(
            _eff_conn, _eff_tables)
        # Gate the set that will actually be STORED, not a different one.
        # Two authz predicates that disagree converge on the stricter.
        _assert_connection_entitlement(user, updates["connection_ids"])
    result = await _adb(db.update_dataset, dataset_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Dataset not found")
    # Invalidate agg cache entries when dataset definition changes
    try:
        from core.agg_cache import invalidate_by_dataset
        invalidate_by_dataset(dataset_id)
    except Exception:
        pass
    logger.info("Dataset %s updated by %s: %s", dataset_id, user.get("username"), list(updates.keys()))
    return result


@router.delete("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def delete_dataset(dataset_id: int, acknowledge_dependents: bool = False,
                         user: dict = Depends(require_capability("datasets.edit"))):
    """2026-10-17 -- refused (409) while a PUBLISHED API rests on this
    dataset (a report-sourced view, a token-served report;
    core/published_api/impact.py); ``acknowledge_dependents=true`` deletes
    anyway and audits the APIs."""
    db = _require_db()
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin

    async def _refuse_if_reports_use_it():
        # 2026-10-29 (owner: "do we have option to delete datasets if not needed")
        # -- a dataset reports are built on is NOT deleted from under them: the
        # cascade below took its columns, and every such report failed later with
        # no word of why.  Refused, naming them (an admin sees every name; anyone
        # else their own and a count), whatever acknowledge_dependents says --
        # there is no report a dataset-less report could still run.
        _users = await _adb(db.reports_using_dataset, dataset_id)
        if _users:
            _mine = [r for r in _users if is_admin_like(user) or r.get("owner") == user.get("username")]
            _named = ", ".join(f"{r['name']!r} (id {r['id']})" for r in _mine[:10])
            _others = len(_users) - len(_mine)
            raise HTTPException(
                status_code=409,
                detail=(f"This dataset is used by {len(_users)} report(s)"
                        + (f": {_named}" + (" ..." if len(_mine) > 10 else "") if _mine else "")
                        + (f"{' and' if _mine else ':'} {_others} report(s) owned by others" if _others else "")
                        + ".  Delete those reports first, then "
                          "delete the dataset."))

    from api.published_api_api import refuse_if_apis_depend_async
    # the published-API refusal names the APIs and their consumers, so it is
    # the answer when nothing is acknowledged; with acknowledge_dependents the
    # report check runs FIRST, so the audit "deleted despite its APIs" is never
    # written for a delete that is then refused
    if not acknowledge_dependents:
        await refuse_if_apis_depend_async(db, "dataset", dataset_id,
                                          acknowledged=False, actor=user)
        await _refuse_if_reports_use_it()
    else:
        await _refuse_if_reports_use_it()
        await refuse_if_apis_depend_async(db, "dataset", dataset_id,
                                          acknowledged=True, actor=user)
    # Invalidate agg cache entries before deleting
    try:
        from core.agg_cache import invalidate_by_dataset
        invalidate_by_dataset(dataset_id)
    except Exception:
        pass
    # 2026-10-30 (owner) -- SWITCHED OFF, not erased: its columns, metrics and
    # relationships stay; Admin -> Switched off brings the whole dataset back
    success = await _adb(db.delete_dataset, dataset_id)
    if not success:
        raise HTTPException(status_code=404, detail="Dataset not found")
    logger.info("Dataset %s switched off by %s", dataset_id, user.get("username"))
    audit_event(_db_manager, user, None, "delete_dataset", "dataset", dataset_id)
    return {"detail": "Dataset deleted", "id": dataset_id, "switched_off": True}


@router.post("/api/datasets/{dataset_id}/publish", tags=["semantic-layer"])
async def toggle_publish(dataset_id: int, user: dict = Depends(require_capability("datasets.manage"))):
    """DELIBERATELY still admin-only (2026-08-09 self-service kept the
    governed line HERE): creating a private dataset is self-service, but
    publishing makes it visible — and executable — org-wide.  That is a
    governance act (the §4 anti-sprawl lever), not a modeling act."""
    db = _require_db()
    ds = await _adb(_ensure_dataset_exists, dataset_id)
    new_state = not ds.get("is_published", False)
    result = await _adb(db.update_dataset, dataset_id, is_published=new_state)
    logger.info("Dataset %s %s by %s", dataset_id,
                "published" if new_state else "unpublished", user.get("username"))
    return result


@router.post("/api/datasets/{dataset_id}/certify", tags=["semantic-layer"])
async def toggle_certify(dataset_id: int, user: dict = Depends(require_capability("datasets.manage"))):
    """ADMIN-only certification toggle (2026-08-09) — mirrors the
    BusinessReport is_certified governance signal: many private datasets,
    FEW certified shared models."""
    from datetime import datetime, timezone
    db = _require_db()
    ds = await _adb(_ensure_dataset_exists, dataset_id)
    new_state = not ds.get("is_certified", False)
    result = await _adb(
        db.update_dataset, dataset_id,
        is_certified=new_state,
        certified_by=user.get("username", "admin") if new_state else None,
        certified_at=datetime.now(timezone.utc) if new_state else None,
    )
    audit_event(_db_manager, user, None,
                "certify_dataset" if new_state else "decertify_dataset",
                "dataset", dataset_id)
    logger.info("Dataset %s %s by %s", dataset_id,
                "certified" if new_state else "decertified", user.get("username"))
    return result


# ── Dataset-from-query endpoints (2026-08-22) ────────────────────────────────

@router.post("/api/datasets/resolve-source", tags=["semantic-layer"])
async def resolve_dataset_source_endpoint(
    body: DatasetSourceRef,
    user: dict = Depends(require_capability("datasets.view")),
):
    """Dry-run: what SQL would this source snapshot into a dataset?

    Lets the creation wizard show the resolved SQL, dialect and connection
    BEFORE committing — resolution and entitlement rules are byte-identical
    to POST /api/datasets with ``source`` because both call
    ``_resolve_dataset_source`` (which calls the shared
    ``core.feed_sql_resolver.resolve_feed_sql``)."""
    db = _require_db()
    res = await _adb(_resolve_dataset_source, db, body, user)
    if res["connection_ids"]:
        _assert_connection_entitlement(user, res["connection_ids"])
    resolved = res["resolved"]
    return {
        "sql": res["sql"],
        "dialect": resolved.get("dialect"),
        "source_type": body.source_type,
        "source_id": body.source_id,
        "source_name": resolved.get("source_name"),
        "connection_id": resolved.get("connection_id"),
        "connection_name": resolved.get("connection_name"),
        "connection_type": resolved.get("connection_type"),
        "source_sql_sha256": res["provenance"]["source_sql_sha256"],
        "ref_mode": "snapshot",
    }


@router.post("/api/datasets/{dataset_id}/refresh-source", tags=["semantic-layer"])
async def refresh_dataset_source(dataset_id: int,
                                 user: dict = Depends(require_capability("datasets.view"))):
    """Re-snapshot a query-sourced dataset from its source — the EXPLICIT
    author act the snapshot contract requires (owner/group/admin).

    Entitlements are re-checked AT USE TIME (source read + connection), the
    same rule auto-detect applies: a grant revoked after the dataset was
    created must stop working here too.  The dataset's agg-cache entries are
    invalidated — its definition changed."""
    db = _require_db()
    ds = await _adb(_require_dataset_edit, dataset_id, user)
    sref = _source_ref_of(ds)
    if not sref:
        raise HTTPException(
            status_code=400,
            detail="This dataset is not bound to a query source — nothing to "
                   "refresh. Bind one via PUT /api/datasets/{id} with "
                   "'source'.")
    # Keep the dataset pinned to ITS resolved connection: the connection
    # binding is part of the dataset, so a connection change on the source
    # query does not silently repoint this dataset.
    source = DatasetSourceRef(
        source_type=sref["source_type"],
        source_id=int(sref["source_id"]),
        connection_id=sref.get("connection_id"),
    )
    res = await _adb(_resolve_dataset_source, db, source, user)
    if res["connection_ids"]:
        _assert_connection_entitlement(user, res["connection_ids"])

    old_sha = sref.get("source_sql_sha256") or ""
    new_sha = res["provenance"]["source_sql_sha256"]
    changed = old_sha != new_sha
    await _adb(db.update_dataset, dataset_id,
               base_query=res["sql"],
               source_tables=[
                   _carry_scan_config(ds, res["provenance"])],
               connection_ids=(res["connection_ids"]
                               or ds.get("connection_ids") or []))
    if changed:
        try:
            from core.agg_cache import invalidate_by_dataset
            invalidate_by_dataset(dataset_id)
        except Exception as exc:
            logger.warning("agg-cache invalidation failed for dataset %s "
                           "after source refresh: %s", dataset_id, exc)
    # 2026-08-31 — self-heal a column-less dataset.  Refresh is the action a
    # user reaches for when a dataset shows no columns, and it used to
    # re-snapshot the SQL while leaving the column list empty, so it looked
    # like it had done nothing.  Every dataset created before column
    # auto-population is in exactly that state.
    #
    # ONLY when there are no columns at all: existing columns carry
    # friendly names, classes, formats and role whitelists the author set
    # by hand, and silently regenerating those would destroy work the
    # snapshot contract has no business touching.
    detection = None
    try:
        existing = await _adb(db.list_dataset_columns, dataset_id)
    except Exception as exc:
        # Healing is a convenience this endpoint gained late; re-snapshotting
        # is its actual job and must still succeed.  Degrade -- but SAY so in
        # the response, because a heal that quietly did not happen is how a
        # dataset stays empty while every call reports success.
        logger.warning("Dataset %s: could not check for existing columns "
                       "during refresh, skipping column healing: %s",
                       dataset_id, exc)
        existing = None
        detection = {"status": "skipped", "created": 0, "source": None,
                     "message": f"Could not check whether this dataset has "
                                f"columns, so none were detected: {exc}"}
    if existing == []:
        detection = await _populate_columns_from_query(
            db, dataset_id, res["sql"],
            (res["connection_ids"][0] if res["connection_ids"] else None))
    audit_event(_db_manager, user, None, "refresh_dataset_source",
                "dataset", dataset_id)
    logger.info("Dataset %s source re-snapshotted by %s (changed=%s)",
                dataset_id, user.get("username"), changed)
    return {"dataset_id": dataset_id, "changed": changed,
            "old_sql_sha256": old_sha, "new_sql_sha256": new_sha,
            "snapshotted_at": res["provenance"]["snapshotted_at"],
            "column_detection": detection}


# ── Column auto-classification helpers (shared by preview + auto-detect) ─────

#: THE numeric/date/boolean type vocabulary — one copy, because this file
#: had two and they disagreed.
#:
#: 2026-09-15: ``_classify_column`` matched ("int","float","double","decimal",
#: "numeric","bigint") while ``_infer_data_type`` (further down this same file)
#: matched those PLUS "number" and "real".  Oracle names its numeric type
#: ``NUMBER``, and "numeric" does not contain "number" — so every Oracle NUMBER
#: column auto-detected as ``data_type: "string"``.  Equality filters still
#: worked (Oracle implicitly converts '3' to 3), which is why a live audit
#: passed on ``BUCKET eq 3``; a RANGE filter or a sort compares as TEXT.
#: An unrecognised spelling and a deliberate refusal are indistinguishable
#: when the fallback is silent — so the vocabulary lives in ONE place.
_NUMBER_TYPE_TOKENS = frozenset({
    "int", "integer", "float", "double", "decimal", "numeric", "real",
    "number", "bigint", "smallint", "tinyint", "int64", "float64", "int32",
    "long", "money",
})
_NUMBER_TYPE_SUBSTRINGS = ("int", "float", "decimal", "numeric", "number",
                           "double", "real")
_DATE_TYPE_TOKENS = frozenset({"date", "timestamp", "datetime", "time"})
_BOOL_TYPE_TOKENS = frozenset({"boolean", "bool"})


def _base_type_token(raw_type: str) -> str:
    """The engine's type name with any precision/scale stripped.

    ``NUMBER(10,2)`` -> ``number``; ``VARCHAR2(50)`` -> ``varchar2``.
    """
    return (raw_type or "").lower().split("(")[0].strip()


def _is_numeric_type(raw_type: str) -> bool:
    """Does this engine type name denote a number?  One answer, every caller."""
    t = _base_type_token(raw_type)
    if not t:
        return False
    return t in _NUMBER_TYPE_TOKENS or any(
        tok in t for tok in _NUMBER_TYPE_SUBSTRINGS)


def _is_decimal_type(raw_type: str) -> bool:
    """Does this engine type hold fractions?  ``NUMBER(18,2)``, ``DECIMAL``, ``FLOAT``: yes.
    ``NUMBER(38,0)`` and a bare ``NUMBER``: no, those may be ids or years."""
    t = str(raw_type or "").strip().lower()
    base = _base_type_token(t)
    if not base or not _is_numeric_type(t) or "int" in base:
        return False
    if "(" in t:
        if "," not in t:
            return False            # DECIMAL(10): a scale left out is a scale of 0
        try:
            return int(t.split(",", 1)[1].split(")")[0].strip()) > 0
        except ValueError:
            return False
    return base not in ("number", "numeric", "long")


_KEY_WORDS = {"id", "key", "no", "num", "nbr", "code", "sk", "ref"}
#: Words ending in "id" that are not identifiers.
_NOT_AN_ID = {"valid", "invalid", "unpaid", "prepaid", "liquid", "solid", "hybrid", "avoid", "rapid", "fluid"}


def _is_whole_number_type(raw_type: str) -> bool:
    """A type that can hold no fraction: BIGINT, NUMBER(38,0), DECIMAL(10).  A bare NUMBER is not
    one: Oracle reports amounts that way, and its scale is unknown."""
    t = str(raw_type or "").strip().lower()
    base = _base_type_token(t)
    if not base or not _is_numeric_type(t):
        return False
    if "int" in base:
        return True
    if "(" not in t:
        return False
    if "," not in t:
        return True
    try:
        return int(t.split(",", 1)[1].split(")")[0].strip()) == 0
    except ValueError:
        return False


def _names_a_key(col_name: str) -> bool:
    """Does the column's LAST WORD say it is a key?  ``ACCOUNT_ID``, ``customerId``: yes.
    ``NOTIONAL_AMOUNT``, ``VALID``: no; the name patterns are substrings and would say yes."""
    import re
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(col_name or ""))
    words = [w for w in re.split(r"[^a-z0-9]+", spaced.lower()) if w]
    if not words:
        return False
    last = words[-1]
    return last in _KEY_WORDS or (len(last) >= 5 and last.endswith("id") and last not in _NOT_AN_ID)


def _looks_like_an_id(lower: str, id_pats: list) -> bool:
    """``_id`` is a suffix, ``id_`` a prefix, and either alone is the whole name.  Reading ``_no`` as
    the prefix "no" hid NOTIONAL and NOTES; reading ``_num`` as "num" hid NUM_TRADES."""
    return any(lower.endswith(p) or lower == p.strip("_") or (p.endswith("_") and lower.startswith(p))
               for p in id_pats)


def _classify_column(col_name: str, col_type_str: str) -> tuple:
    """Classify a column by name/type patterns. Returns (column_type, data_type, is_hidden)."""
    from core import config as cfg
    numeric_pats = [p.lower() for p in cfg.chatbot.numeric_patterns]
    date_pats = [p.lower() for p in cfg.chatbot.date_patterns]
    id_pats = [p.lower() for p in cfg.chatbot.id_patterns]

    lower = col_name.lower()
    type_lower = col_type_str.lower() if col_type_str else ""
    # 2026-10-29 -- the declared type outranks the NAME for dates too (FB-26
    # below did it for numbers).  The owner's JOIN writes BUSINESS_CLOSE_DATE
    # as text (UPPER(DATE_FORMAT(.., '%d-%b-%y')) AS "Business Date") and the
    # name patterns are substrings: "ts" in "Trade Comments", "settlement" in
    # "Settlement System" -- each became a DATE, so a date parameter on it
    # compared 2025-09-30 with '30-SEP-25' and found nothing.
    _declared_early = _driver_data_type(col_type_str)
    if _declared_early in ("string", "boolean"):
        if _looks_like_an_id(lower, id_pats):
            return "dimension", "string", True
        return "dimension", _declared_early, False
    # 2026-11-04 (the owner: "all decimal column ... these should be measure"): the name
    # patterns are substrings and prefixes.  "ts" made SETTLEMENT_AMOUNT and TOTAL_ASSETS a
    # date; the prefix "no" made NOTIONAL_AMOUNT a hidden string.  A DECLARED decimal is a
    # number to add up, whatever it is called.  A type with no scale to read (DECIMAL as
    # Databricks reports it, a FLOAT id from a file) proves less, so a key-shaped name goes on
    # to the rules below and stays what it always was.
    if _is_decimal_type(col_type_str) and ("," in str(col_type_str) or not _names_a_key(col_name)):
        return "measure", "number", False
    # Date detection
    if any(p in lower for p in date_pats) or "date" in type_lower or "timestamp" in type_lower:
        return "dimension", "date", False
    # ID columns → hidden dimension
    if _looks_like_an_id(lower, id_pats):
        return "dimension", "string", True
    # FB-26 (2026-09-19): THE DRIVER OUTRANKS THE NAME.  ``counterparty`` is
    # a varchar, and ``"count" in "counterparty"`` made it a SUM measure --
    # so every SELECT of it emitted SUM(counterparty), which no engine
    # accepts (Trino: FUNCTION_NOT_FOUND "Unexpected parameters (varchar)
    # for function sum"), and the repeated failures tripped the source's
    # circuit breaker for everyone.  A type the driver DECLARED as text or
    # boolean can never be a measure, whatever the name looks like; the
    # name heuristic decides only when the type is unknown or numeric.
    _declared = _driver_data_type(col_type_str)
    if _declared in ("string", "boolean"):
        return "dimension", _declared, False
    # 2026-11-04 (the owner: HIERARCHYID came out summed, "measure also bigger problem"): a number
    # named as a key is a key; "_id" above needs the underscore, HIERARCHYID has none.
    if _is_numeric_type(col_type_str) and _names_a_key(col_name):
        return "dimension", "number", False
    # Numeric measures
    if any(p in lower for p in numeric_pats):
        return "measure", "number", False
    # A whole number is added up only when its name says it is a quantity (above).  Summing a code
    # gives a number that looks right and means nothing.
    if _is_whole_number_type(col_type_str):
        return "dimension", "number", False
    # Type-based numeric — the SHARED vocabulary, so this path and
    # ``_infer_data_type`` cannot answer "is this a number?" differently.
    if _is_numeric_type(col_type_str):
        return "measure", "number", False
    return "dimension", "string", False


def _friendly_name(col_name: str) -> str:
    """Convert snake_case/camelCase to Title Case, stripping ETL/DW type prefixes and suffixes.

    Strips warehouse naming prefixes (dn_=decimal, dw_, etl_, raw_, stg_, fk_, dim_, ref_, src_)
    and equivalent suffixes so physical names like 'dn_amount' display as 'Amount'.
    The physical column name is never changed — only the display label is affected.
    """
    import re
    s = re.sub(r'^(fk_|ref_|src_|dim_|dn_|dw_|etl_|raw_|stg_)', '', col_name, flags=re.IGNORECASE)
    s = re.sub(r'_(dn|dw|etl|raw|stg|fk|ref|src|dim)$', '', s, flags=re.IGNORECASE)
    s = re.sub(r'([a-z])([A-Z])', r'\1_\2', s)
    return s.replace("_", " ").strip().title() or col_name.replace("_", " ").strip().title()


async def _read_connection_schema(db, conn_id: int, table_path: str,
                                    username: str = "",
                                    refresh: bool = False) -> dict:
    """Read schema from a connection's table/file.

    Step 2 of the OOP refactor (REFACTOR_PLAN_SCHEMA_READER.md): this
    function is now a **thin shim** that delegates to
    ``core.schema_reader.SchemaReader``.  All caching, credential
    resolution, prefix expansion, error handling, AND stale-while-
    revalidate fallback live in that single class — this shim only
    converts the typed ``SchemaResult`` back to the legacy dict shape
    the four callers in this module already expect.

    ``username`` — the REAL logged-in user (or empty string for
    batch / non-interactive contexts).  Never a synthetic tag.
    Empty string routes the credential resolver to the
    system_account / config service fallback chain.

    ``refresh`` — when True, bypass L1+L2 cache and force a fresh
    live S3 read.  Matches the ``?refresh=true`` semantic the CQB
    schema endpoint already supports.  If the live read fails AND a
    cached entry exists, SchemaReader returns the cached entry with
    a warning rather than crashing (stale-while-revalidate).

    Returns the same dict shape as before — every caller stays
    untouched.  Raises ``HTTPException`` with the same status codes
    as before (404 for unknown connection, 500 for read failure).
    """
    from core.connection_manager import ConnectionManager
    from core.schema_reader import (
        SchemaReader, SchemaReadError, ConnectionNotFoundError,
    )

    reader = SchemaReader(db, ConnectionManager(db))
    try:
        result = await reader.read(
            conn_id, table_path, username=username, refresh=refresh,
        )
    except ConnectionNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SchemaReadError as exc:
        # Preserve the legacy 500 error contract — message keeps the
        # "Failed to read schema: …" prefix the frontend already
        # surfaces in the BQB / dataset UI.
        raise HTTPException(status_code=500, detail=f"Failed to read schema: {exc}") from exc

    if not result.columns:
        raise HTTPException(status_code=500, detail="No columns found in schema")

    return result.to_dict()


def _classify_schema_columns(schema_info: dict) -> List[Dict[str, Any]]:
    """Classify all columns in a schema dict. Returns list of column dicts.

    If schema_info contains a ``partition_columns`` list (populated by
    ``safe_read_parquet_schema`` for S3 hive-partitioned data), those columns
    are forced to ``dimension`` type so they can be used as report parameters /
    LOV sources regardless of their inferred data type.
    """
    partition_cols = {c.lower() for c in (schema_info.get("partition_columns") or [])}
    columns = []
    for idx, col in enumerate(schema_info["columns"]):
        col_name = col.get("name", col.get("column_name", ""))
        col_type_str = col.get("type", col.get("data_type", ""))
        if not col_name:
            continue
        c_type, d_type, is_hidden = _classify_column(col_name, col_type_str)
        # Partition columns are always dimensions (used for filtering / LOV)
        if col_name.lower() in partition_cols:
            c_type = "dimension"
            is_hidden = False
        columns.append({
            "physical_name": col_name,
            "friendly_name": _friendly_name(col_name),
            "column_type": c_type,
            "data_type": d_type,
            "aggregation": "sum" if c_type == "measure" else "",
            "is_hidden": is_hidden,
            "sort_order": idx,
        })
    return columns


def _declared_types(schema_info: dict) -> Dict[str, str]:
    """FB-42: ``{physical_name: product type}`` for every column whose
    DECLARED type (the catalog's / driver's spelling) we recognise.

    A SIDE CHANNEL beside the column dicts, deliberately: the column dict
    is a public contract (preview-columns serves it, two create paths
    insert it, a guard pins its keys), and a first cut that stamped a
    ``_declared_type`` key on it leaked an internal field into
    /api/datasets/preview-columns.  Reconcile re-types a stored column only
    from this map -- never from the name heuristic, which is how the FB-26
    defect was made.  Unknown spellings are absent: unknown is not text.
    """
    out: Dict[str, str] = {}
    for col in (schema_info or {}).get("columns") or []:
        if not isinstance(col, dict):
            continue
        name = col.get("name", col.get("column_name", ""))
        mapped = _driver_data_type(col.get("type", col.get("data_type", "")))
        if name and mapped:
            out[str(name)] = mapped
    return out


def _declared_decimals(schema_info: dict) -> List[str]:
    """The columns whose declared type holds fractions; the same side channel as above."""
    return [str(col.get("name", col.get("column_name", "")))
            for col in (schema_info or {}).get("columns") or []
            if isinstance(col, dict) and col.get("name", col.get("column_name", ""))
            and _is_decimal_type(col.get("type", col.get("data_type", "")))]


# ── Column catalog contract (2026-08-22) ─────────────────────────────────────
#
# Registered-table column metadata is served through ONE chokepoint:
# ``_read_connection_schema`` → ``core.schema_reader.SchemaReader`` (L1/L2
# cache, L3 live) — the module the catalog work owns.  This wrapper maps its
# answer onto the catalog CONTRACT shape
# (GET /api/catalog/columns: columns/source/message/last_refreshed_at) and,
# critically, turns "could not read any columns" into an HONEST payload:
# ``source:"none"`` + WHY + a refresh action — never an empty list and
# silence, and never a bare 500 the wizard can only render as a spinner.

def _refresh_action(connection_id: int, table: str) -> Dict[str, Any]:
    return {"method": "POST", "endpoint": "/api/catalog/columns/refresh",
            "body": {"connection_id": connection_id, "table": table}}


async def _columns_with_provenance(db, connection_id: int, table_path: str,
                                   username: str = "",
                                   refresh: bool = False) -> Dict[str, Any]:
    """Contract-shaped column read for a registered table.

    ``source`` mapping: SchemaReader cache layers L1/L2 = served from stored
    catalog metadata → ``"catalog"``; L3 = live read → ``"source"``; any
    failure → ``"none"`` with the reason and a refresh action.
    """
    try:
        schema_info = await _read_connection_schema(
            db, connection_id, table_path, username=username, refresh=refresh)
    except HTTPException as exc:
        return {
            "columns": [], "schema_info": None,
            "source": "none", "stale": False, "last_refreshed_at": None,
            "message": str(exc.detail),
            "refresh": _refresh_action(connection_id, table_path),
        }
    layer = schema_info.get("cache") or "L3"
    return {
        "columns": schema_info.get("columns", []),
        "schema_info": schema_info,
        "source": "catalog" if layer in ("L1", "L2") else "source",
        "stale": False,
        "last_refreshed_at": schema_info.get("cached_at"),
        "message": "",
        "refresh": _refresh_action(connection_id, table_path),
    }


#: FB-42 (2026-09-19): the driver-type vocabulary now lives in
#: ``core.source_types`` (the federation engine needs it and may not import
#: api/); these are its old names, kept so nothing here or in tests moves.
from core.source_types import (  # noqa: E402
    DRIVER_TYPE_HINTS as _DRIVER_TYPE_HINTS,
    NON_NUMERIC_DATA_TYPES,
    driver_data_type as _driver_data_type,
)


def _column_names_and_types(columns: Any) -> tuple:
    """Split a driver's column list into (names, {name: driver_type}).

    2026-09-01 -- THE STARBURST COLUMN BUG.  ``SqlConnector.execute_query``
    returns ``columns`` as ``[{"name": ..., "type": ...}]``; the DuckDB
    branch a few lines below returns plain strings.  Every consumer here
    assumed strings, so with ANY SQL connector -- Starburst, Trino,
    Snowflake, Oracle, Databricks, Athena -- ``r.get(name)`` was called with
    a dict and raised ``TypeError: cannot use 'dict' as a dict key``.  With
    no sample rows it did not raise at all: it stored the DICT as
    ``physical_name``, and the wizard rendered an object where the column
    name belongs.

    Both shapes are legitimate; assuming one of them was the defect.
    """
    names: list = []
    types: Dict[str, str] = {}
    for c in (columns or []):
        if isinstance(c, dict):
            n = c.get("name") or c.get("physical_name")
            if n is None:
                continue
            n = str(n)
            raw_t = c.get("type")
            if raw_t:
                types[n] = str(raw_t)
        else:
            n = str(c)
        names.append(n)
    return names, types


async def _derive_columns_from_sql(db, connection_id: Optional[int],
                                   sql: str, sample_limit: int = 100
                                   ) -> Dict[str, Any]:
    """Column detection for a QUERY-sourced dataset.

    A query's output shape exists nowhere in the table catalog BY
    CONSTRUCTION — the only authority is the query itself.  Sample the
    first ``sample_limit`` rows through ``ConnectionManager.execute_query``
    (the same execution path the wizard's /api/datasets/preview uses) and
    infer name + data type from the sampled values.  DISCLOSED as
    ``source: "query_sample"`` — a sample-based type can be wrong on a
    column whose first rows are all NULL (typed as string).
    """
    import asyncio as _asyncio
    from core.connection_manager import ConnectionManager
    safe_sql = (sql or "").strip().rstrip(";")
    if connection_id:
        # 2026-08-25 — this was the TWIN of the dead call at the preview
        # endpoint: ConnectionManager.execute_query does not exist, so this
        # raised AttributeError on every call and the only caller
        # (auto_detect_columns) turned it into a 422. The documented recovery
        # for a zero-column dataset was therefore dead too — just with a
        # different status code, which is why it read as "auto-detect doesn't
        # work" rather than as a crash. Same chokepoint as the preview path.
        #
        # The author's statement as written; the CONNECTOR renders the
        # sample cap in its own grammar.  Until 2026-09-15 this shipped
        # ``SELECT * FROM (...) __detect__ LIMIT n`` -- ORA-00911 then
        # ORA-00933 on Oracle -- and the failure was swallowed by the
        # caller, so an Oracle custom-SQL dataset silently got every
        # column typed 'string'.
        loop = _asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, lambda: _run_preview_sql(db, connection_id, safe_sql,
                                           limit=int(sample_limit)))
        if isinstance(result, dict):
            columns = list(result.get("columns") or [])
            rows = list(result.get("rows") or [])
        elif hasattr(result, "columns") and hasattr(result, "rows"):
            columns = list(result.columns)
            rows = [dict(zip(result.columns, r)) for r in result.rows]
        else:
            rows = list(result) if result else []
            columns = list(rows[0].keys()) if rows else []
    else:
        # No connection: the snapshot is self-contained SQL — plain DuckDB,
        # which has no connector to cap for it, so the cap is rendered here
        # in DuckDB's own grammar.
        probe = (f"SELECT * FROM ({safe_sql}) AS qs_detect "
                 f"LIMIT {int(sample_limit)}")

        def _duck():
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                cur = con.execute(probe)
                cols = [d[0] for d in cur.description]
                return cols, [dict(zip(cols, r)) for r in cur.fetchall()]
        columns, rows = await _adb(_duck)

    def _value_type(v: Any) -> Optional[str]:
        import decimal
        if v is None:
            return None
        if isinstance(v, bool):
            return "boolean"
        # Decimal explicitly: DuckDB (and most drivers) hand DECIMAL
        # columns back as decimal.Decimal, which is neither int nor float.
        if isinstance(v, (int, float, decimal.Decimal)):
            return "number"
        s = str(type(v).__name__).lower()
        if "date" in s or "time" in s:
            return "date"
        return "string"

    # A SQL connector reports dicts, DuckDB reports strings — normalise
    # before anything indexes a row with one of these.
    columns, driver_types = _column_names_and_types(columns)

    out = []
    declared_types: Dict[str, str] = {}
    for idx, name in enumerate(columns):
        sampled = None
        for r in rows:
            sampled = _value_type(r.get(name) if isinstance(r, dict) else None)
            if sampled:
                break
        # The DRIVER outranks the sample: it describes the column, while a
        # sample describes the first non-null value it happened to find --
        # and on an all-NULL first page there is no sample at all.  Sampling
        # remains the fallback for a spelling we do not recognise.
        _declared = _driver_data_type(driver_types.get(name)) or sampled
        if _declared:
            declared_types[name] = _declared        # FB-42 side channel
        d_type = _declared or "string"
        c_type, _dt_by_name, is_hidden = _classify_column(name, driver_types.get(name) or d_type)
        # The SAMPLED type outranks the name heuristic for the data type;
        # the name heuristic still decides dimension/measure/hidden.
        if d_type != "number" and c_type == "measure":
            c_type = "dimension"
        out.append({
            "physical_name": name,
            "friendly_name": _friendly_name(name),
            "column_type": c_type,
            "data_type": d_type,
            "aggregation": "sum" if c_type == "measure" else "",
            "is_hidden": is_hidden,
            "sort_order": idx,
        })
    return {"columns": out, "sampled_rows": len(rows),
            "source": "query_sample",
            "declared_types": declared_types,       # FB-42, see _declared_types
            "declared_decimals": [n for n in columns if _is_decimal_type(driver_types.get(n) or "")]}


# 2026-09-01 — the parser now lives in core/sql_output_columns.py so the
# query SAVE path can use it too.  Re-exported under the original name:
# this module has callers and tests that name it, and a second copy is
# exactly what moving it was meant to prevent.
from core.sql_output_columns import (  # noqa: E402
    derive_columns_from_sql_text as _derive_columns_from_sql_text,
)


async def _reconcile_detected_columns(db, dataset_id: int,
                                      detected: List[Dict[str, Any]],
                                      declared_types: Optional[Dict[str, str]] = None,
                                      declared_decimals: Optional[List[str]] = None,
                                      ) -> Dict[str, Any]:
    """Apply detection to a dataset that may ALREADY have columns.

    2026-09-04.  Auto-detect used to call ``bulk_create_dataset_columns``
    unconditionally, which INSERTS.  On a dataset that already had columns
    that is wrong twice over:

      * running it again gave the dataset a SECOND copy of every column,
        and
      * a column whose stored spelling was wrong stayed wrong, because
        nothing ever updates an existing row.

    The second one is what made the identifier-folding fix only half a
    fix.  Trino/Starburst FOLDS unquoted identifiers to lower case, so a
    dataset created before that fix stored ``TradeDate`` for a column the
    engine calls ``tradedate``, and every report on it died with
    ``Referenced column "TradeDate" not found in FROM clause``.  Detection
    now derives the right spelling — but a dataset created yesterday still
    holds the wrong one, and re-running auto-detect merely added the right
    name beside it while every report went on pointing at the old id.

    So reconcile instead of append.  A column's IDENTITY is its id; its
    physical_name is a property of it that can be corrected.  Renaming in
    place is what lets an existing dataset be healed WITHOUT touching the
    reports, filters, parameters and metrics that reference the column by
    id — recreating the column would break all of them.

    Matching is case-insensitive because that is exactly the difference
    being repaired.  Nothing is ever DELETED here: a column that detection
    no longer sees may still be referenced by a report, and silently
    removing it would break that report to fix a cosmetic mismatch.  It is
    reported instead, and removing it stays the author's decision.
    """
    existing = await _adb(db.list_dataset_columns, dataset_id)
    by_folded = {}
    for col in existing:
        by_folded.setdefault((col.get("physical_name") or "").casefold(), col)

    # FB-42: the declared types ride a SIDE CHANNEL (see _declared_types),
    # keyed by the name the source returns; matched case-insensitively
    # like everything else here.
    _declared_folded = {str(k).casefold(): v
                        for k, v in (declared_types or {}).items() if v}
    _decimals_folded = {str(n).casefold() for n in (declared_decimals or [])}
    to_create, renamed, retyped, unchanged = [], [], [], 0
    summed_keys: List[str] = []
    for col in detected:
        phys = col.get("physical_name") or ""
        declared = _declared_folded.get(phys.casefold())
        match = by_folded.get(phys.casefold())
        if match is None:
            to_create.append(col)
            continue
        touched = False
        if match.get("physical_name") != phys:
            await _adb(db.update_dataset_column, match["id"],
                       physical_name=phys)
            renamed.append({"column_id": match["id"],
                            "from": match.get("physical_name"), "to": phys})
            logger.info(
                "Dataset %s column %s renamed %r -> %r: the source returns "
                "it under that name (identifier folding), and every report "
                "referencing this column keeps working because its id did "
                "not change.",
                dataset_id, match["id"], match.get("physical_name"), phys)
            touched = True
        # FB-42 (2026-09-19): a stored TYPE that contradicts what the source
        # DECLARES is corrected in place -- the FB-26 defect ("count" in
        # "counterparty" typed a varchar as number/SUM) was fixed in
        # detection only, so every dataset created before it kept the
        # wrong type and auto-detect reported it "unchanged" while holding
        # the catalog's answer.  Only a type the source declared is
        # trusted (never the name heuristic); a SUM/AVG over a column that
        # is now text/boolean/date cannot run anywhere, so the aggregation
        # is dropped and a measure becomes a dimension.  The column id --
        # what every report references -- does not change, and the change
        # is REPORTED, never folded into "unchanged".
        _from_type = match.get("data_type")
        if declared and declared != _from_type:
            _upd = {"data_type": declared}
            _rec = {"column_id": match["id"], "physical_name": phys,
                    "data_type": {"from": _from_type, "to": declared}}
            _agg = (match.get("aggregation") or "").lower()
            # 2026-11-04: a DECIMAL stored as a string was a failed guess, nobody's choice, so it
            # takes the whole detected answer; retyping alone left it a dimension, and a hidden
            # one stayed out of the report builder.  Only a decimal: an integer may be a code
            # (BOOK BIGINT), and summing it would change every report that groups by it.
            if (phys.casefold() in _decimals_folded and col.get("column_type") in ("measure", "kpi")
                    and (match.get("column_type") or "") not in ("measure", "kpi")):
                _upd["column_type"] = col["column_type"]
                _upd["aggregation"] = col.get("aggregation") or "sum"
                _upd["is_hidden"] = bool(col.get("is_hidden"))
                _rec["column_type"] = {"from": match.get("column_type"), "to": col["column_type"]}
            if declared in NON_NUMERIC_DATA_TYPES and _agg in ("sum", "avg"):
                _upd["aggregation"] = ""
                _rec["aggregation"] = {"from": match.get("aggregation"), "to": ""}
                if (match.get("column_type") or "") in ("measure", "kpi"):
                    _upd["column_type"] = "dimension"
                    _rec["column_type"] = {"from": match.get("column_type"),
                                           "to": "dimension"}
            await _adb(db.update_dataset_column, match["id"], **_upd)
            retyped.append(_rec)
            logger.info(
                "Dataset %s column %s (%s) re-typed %r -> %r from the "
                "source's declared type%s; the column id is unchanged so "
                "reports keep referencing it.",
                dataset_id, match["id"], phys, _from_type, declared,
                (" and its %s aggregation dropped" % _agg)
                if "aggregation" in _upd else "")
            touched = True
        # 2026-11-04: an old guess and an author's choice look alike in the row, so a stored measure
        # is never changed here.  It is named, so a person can look.
        if (_declared_folded.get(phys.casefold()) == "number" and col.get("column_type") == "dimension"
                and (match.get("column_type") or "") in ("measure", "kpi")):
            summed_keys.append(phys)
        if not touched:
            unchanged += 1

    created = []
    if to_create:
        created = await _adb(db.bulk_create_dataset_columns, dataset_id,
                             to_create)

    detected_folded = {(c.get("physical_name") or "").casefold()
                       for c in detected}
    stale = [c.get("physical_name") for c in existing
             if (c.get("physical_name") or "").casefold()
             not in detected_folded]
    if stale:
        logger.info(
            "Dataset %s has %d column(s) the source no longer reports: %s. "
            "They are KEPT — a report may still reference them — and "
            "removing one is the author's decision.",
            dataset_id, len(stale), sorted(stale))

    return {"columns": created, "created": len(created),
            "renamed": renamed, "retyped": retyped,
            "unchanged": unchanged, "stale": stale, "summed_keys": summed_keys}


async def _detect_columns(db, connection_id: Optional[int], sql: str
                          ) -> Dict[str, Any]:
    """THE column-detection decision for a query-sourced dataset.

    2026-08-31.  Two authorities, used for what each is actually good at:

      * the SQL knows the NAMES, offline, always.  Parsing cannot fail
        because a warehouse is down, and names are the part whose absence
        breaks the product -- an empty column list empties the report
        builder's Columns step AND its filter dropdown.
      * a SAMPLE knows the TYPES better.  `TRUE AS active` is a boolean;
        no amount of staring at the name "active" reveals that.

    So: parse first, then enrich types from a sample IF the source answers.
    A sample that fails, or that disagrees about which columns exist, is
    discarded and the parsed answer stands -- detection degrades to
    "slightly worse types", never to "no columns".

    Both callers (auto-detect and the refresh heal) come through here, so
    they cannot drift into disagreeing about a query's shape.
    """
    parsed = _derive_columns_from_sql_text(sql)
    if not parsed:
        # Only SELECT * (or unparseable SQL) gets here -- the one case where
        # the source is the ONLY authority, because only it knows what the
        # star expands to.  Let the caller handle a failure: at this point
        # there is no answer to degrade to.
        derived = await _derive_columns_from_sql(db, connection_id, sql)
        return {"columns": derived["columns"], "source": derived["source"],
                "declared_types": derived.get("declared_types") or {},
                "declared_decimals": derived.get("declared_decimals") or []}

    try:
        sampled = await _derive_columns_from_sql(db, connection_id, sql)
        by_name = {c["physical_name"]: c for c in (sampled.get("columns") or [])}
    except Exception as exc:
        logger.warning("Column types could not be sampled (keeping the types "
                       "inferred from the column names): %s", exc)
        return {"columns": parsed, "source": "sql_parse",
                "types_problem": "The column types could not be read from the source, so they were "
                                 "guessed from the column names. Check Type on the Columns tab, or "
                                 f"run Detect columns again once the source answers. ({exc})"}

    parsed_names = {c["physical_name"] for c in parsed}
    if set(by_name) != parsed_names:
        # ── IDENTIFIER FOLDING, not disagreement ─────────────────────
        #
        # Most engines FOLD unquoted identifiers: Trino/Starburst and
        # Postgres lower-case them, Oracle upper-cases them.  So a query
        # written ``SELECT TradeDate FROM t`` parses as "TradeDate" and
        # RETURNS "tradedate" from Trino.  The two sets differ, and the
        # rule here used to be "trust the SQL: it is the definition, the
        # sample is an observation" -- which is right about WHICH columns
        # exist and wrong about what they are NAMED.
        #
        # The name is not the query's to decide.  The federation engine
        # wraps the snapshot as ``WITH _base AS (<sql>) SELECT
        # "<physical_name>" FROM _base`` and sends the whole thing to the
        # SAME engine, where the reference is quoted and therefore
        # case-SENSITIVE.  Recording "TradeDate" for a column the engine
        # calls "tradedate" makes every run die with
        #
        #     Referenced column "TradeDate" not found in FROM clause
        #
        # which is why Starburst datasets failed hardest: unquoted
        # identifiers are the norm there.  The sample is not an
        # observation about names -- for names it IS the authority,
        # because it is literally what the engine returns.
        #
        # So: if the two agree case-INSENSITIVELY, this is folding, and
        # the ENGINE's spelling wins.  A genuine structural difference
        # (different columns, not different case) keeps the previous
        # behaviour: trust the SQL and say so.
        folded = {n.casefold(): n for n in by_name}
        if set(folded) == {n.casefold() for n in parsed_names}:
            for col in parsed:
                engine_name = folded[col["physical_name"].casefold()]
                if engine_name != col["physical_name"]:
                    logger.info(
                        "Column %r is returned by the source as %r "
                        "(identifier folding); recording the name the "
                        "engine actually emits.",
                        col["physical_name"], engine_name)
                    col["physical_name"] = engine_name
        else:
            logger.warning("Column sample disagreed with the parsed SQL "
                           "(parsed=%s sampled=%s); keeping the parsed "
                           "columns.",
                           sorted(parsed_names), sorted(by_name))
            # 2026-11-04: ONE column the two disagree on threw away the source's types for
            # EVERY column, and each decimal became a string.  Every column both know keeps
            # the type the source gave; only the ones it did not return stay guessed.
            matched = 0
            for col in parsed:
                s_col = folded.get(col["physical_name"].casefold())
                if s_col is None:
                    continue
                s_col = by_name[s_col]
                col["physical_name"] = s_col["physical_name"]
                for key in ("data_type", "column_type", "aggregation", "is_hidden"):
                    col[key] = s_col[key]
                matched += 1
            unmatched = sorted(n for n in parsed_names if n.casefold() not in folded)
            out = {"columns": parsed, "source": "sql_parse",
                   "declared_types": sampled.get("declared_types") or {},
                   "declared_decimals": sampled.get("declared_decimals") or []}
            if unmatched:
                out["types_problem"] = ("The source did not return these columns under these names, so "
                                        f"their types were guessed: {', '.join(unmatched)}. Add an alias "
                                        f"with AS to each one, then run Detect columns again.")
            logger.info("%d column(s) typed from the sample, %d guessed.", matched, len(unmatched))
            return out

    for col in parsed:
        s_col = by_name[col["physical_name"]]
        col["data_type"] = s_col["data_type"]
        col["column_type"] = s_col["column_type"]
        col["aggregation"] = s_col["aggregation"]
        col["is_hidden"] = s_col["is_hidden"]
    return {"columns": parsed, "source": "query_sample",
            "declared_types": sampled.get("declared_types") or {},
            "declared_decimals": sampled.get("declared_decimals") or []}


async def _populate_columns_from_query(db, dataset_id: int, base_query: str,
                                       connection_id: Optional[int],
                                       ) -> Dict[str, Any]:
    """Derive and persist a query-sourced dataset's columns.

    2026-08-31 — creating a dataset FROM a saved query snapshotted the SQL,
    the provenance and the connection, and created ZERO columns.  The
    request returned 200, GET /api/datasets/{id} returned
    ``"columns": []``, and every consumer downstream read that as "this
    dataset has no columns" rather than "nobody ever detected them": the
    report builder's column picker was empty, and so was the FILTER column
    dropdown, which is why authors resorted to typing column names by hand.

    The detection capability already existed
    (POST /api/datasets/{id}/auto-detect) and NOTHING called it — not this
    endpoint, and not the UI.  A capability with no caller is indistinguishable
    from a missing feature, and this is the second time that shape has bitten
    this codebase.

    Derivation goes through ``_derive_columns_from_sql`` — the same function
    auto-detect uses, deliberately, so the two paths cannot drift into
    disagreeing about a query's shape.

    NEVER raises.  Creating a dataset must not fail because a source was
    momentarily unreachable, but the caller must be TOLD, so the outcome is
    returned as a status the response carries and the UI can act on.
    """
    from core import config as _cfg
    # THE QUERY ITSELF IS THE AUTHORITY, and it is available offline.
    # Reading the shape by running a probe against the source means a
    # source that is down, slow or unentitled yields NO columns -- which
    # is how "auto-detect doesn't work" and "I connected the source and it
    # still fails" are the same complaint.  A query that names its output
    # columns already tells us the shape; parsing costs nothing and cannot
    # fail because a warehouse is unreachable.  Sampling stays as the
    # fallback for the one case parsing genuinely cannot answer -- SELECT *,
    # where only the source knows what the star expands to.
    derived = {"source": "sql_parse"}
    cols = []
    if True:
        try:
            derived = await _detect_columns(db, connection_id, base_query or "")
            cols = derived.get("columns") or []
        except Exception as exc:
            logger.warning("Dataset %s: the query could not be parsed for its "
                           "output columns and sampling the source failed "
                           "too: %s", dataset_id, exc)
            return {"status": "failed", "created": 0, "source": None,
                    "message": f"The query uses SELECT * (so its columns "
                               f"cannot be read from the SQL alone) and "
                               f"sampling the source failed: {exc}. Name the "
                               f"columns explicitly in the query instead of "
                               f"SELECT *, or fix the source and run POST "
                               f"/api/datasets/{dataset_id}/auto-detect."}

    if not cols:
        return {"status": "no_columns", "created": 0,
                "source": derived.get("source"),
                "message": "The source query returned no columns, so none "
                           "were created."}
    limit = _cfg.semantic_layer.max_columns_per_dataset
    truncated = False
    if len(cols) > limit:
        cols = cols[:limit]
        truncated = True
    try:
        created = await _adb(db.bulk_create_dataset_columns, dataset_id, cols)
    except Exception as exc:
        logger.warning("Dataset %s: column detection sampled %d columns but "
                       "persisting them failed: %s", dataset_id, len(cols), exc)
        return {"status": "failed", "created": 0,
                "source": derived.get("source"),
                "message": f"Detected {len(cols)} column(s) but could not "
                           f"save them: {exc}."}
    msg = f"Detected {len(created)} column(s) from the source query."
    if derived.get("types_problem"):
        msg += " " + derived["types_problem"]
    if truncated:
        # Say it out loud: a silent cap reads as "that is all there was".
        msg += (f" The query returned more than the {limit}-column limit, so "
                f"the list was TRUNCATED.")
    logger.info("Dataset %s: auto-populated %d column(s) at creation "
                "(source=%s)%s", dataset_id, len(created),
                derived.get("source"), " [TRUNCATED]" if truncated else "")
    return {"status": "truncated" if truncated else "ok",
            "created": len(created), "source": derived.get("source"),
            "message": msg}


@router.post("/api/datasets/detect-columns", tags=["semantic-layer"])
async def detect_columns(body: DetectColumnsRequest, user: dict = Depends(require_capability("datasets.create"))):
    """The columns of a query, before a dataset exists, through THE detection auto-detect uses
    (`_detect_columns`): names, types, what each is, and the reason when the types could not be
    read.  2026-11-05: the wizard typed a saved query's columns, and any failed sample, by NAME in
    the browser, so nearly every column arrived as string.  No rows leave this route."""
    _assert_connection_entitlement(user, [body.connection_id])
    sql = body.sql.strip().rstrip(";")
    if ";" in sql:
        raise HTTPException(status_code=422, detail="SQL must be a single statement.")
    found = await _detect_columns(_require_db(), body.connection_id, sql)
    return {"columns": found.get("columns") or [], "source": found.get("source"),
            "types_problem": found.get("types_problem")}


@router.post("/api/datasets/preview-columns", tags=["semantic-layer"])
async def preview_columns(body: PreviewColumnsRequest, user: dict = Depends(require_capability("datasets.view"))):
    """Preview auto-classified columns from a connection's table schema WITHOUT saving.
    Use this to show users what columns will be created before committing.

    2026-08-09 self-service: opened from require_admin to any authenticated
    user WHO IS ENTITLED TO THE CONNECTION — it exposes column names/types
    (schema inspection, no rows, no mutation), which is exactly what the
    connection entitlement already lets that user see through the schema
    endpoints.  The fail-closed gate below is what makes opening it safe."""
    db = _require_db()
    _assert_connection_entitlement(user, [body.connection_id])
    # 2026-08-22: through the catalog-contract seam — a failed read returns
    # the HONEST empty (source:"none" + why + refresh action), never a bare
    # 500 the wizard can only render as silence.
    prov = await _columns_with_provenance(
        db, body.connection_id, body.table_path,
        username=(user or {}).get("username", ""))
    if prov["source"] == "none" or not prov["columns"]:
        logger.info("Preview-columns: NO columns for conn %d / %s by %s: %s",
                    body.connection_id, body.table_path,
                    user.get("username"), prov["message"])
        return {
            "columns": [],
            "summary": {"total": 0, "dimensions": 0, "measures": 0,
                        "dates": 0, "hidden": 0},
            "source": "none",
            "message": prov["message"] or "No columns available for this table.",
            "refresh": prov["refresh"],
        }
    columns = _classify_schema_columns(prov["schema_info"])
    dims = sum(1 for c in columns if c["column_type"] == "dimension" and c["data_type"] != "date")
    measures = sum(1 for c in columns if c["column_type"] == "measure")
    dates = sum(1 for c in columns if c["data_type"] == "date")
    hidden = sum(1 for c in columns if c["is_hidden"])
    logger.info("Preview-columns: %d cols (%d dim, %d measure, %d date, %d hidden) from conn %d / %s by %s",
                len(columns), dims, measures, dates, hidden,
                body.connection_id, body.table_path, user.get("username"))
    return {
        "columns": columns,
        "summary": {"total": len(columns), "dimensions": dims, "measures": measures, "dates": dates, "hidden": hidden},
        "source": prov["source"],
        "last_refreshed_at": prov["last_refreshed_at"],
        "stale": prov["stale"],
        "message": prov["message"],
        "refresh": prov["refresh"],
    }


async def _source_columns_for_dataset(db, ds: Dict[str, Any],
                                      user: dict) -> Dict[str, Any]:
    """The columns the dataset's SOURCE reports, without writing anything.

    2026-09-04.  Extracted from ``auto_detect_columns`` because a second
    caller needed the same answer: the column editor, so an author PICKS a
    column name from the source instead of typing one.

    Operator: *"user should not enter columns name as free text...columns
    should come from schema...we have table n everything we are caching
    so...any sources"*.  The caching is real — this resolves through the
    catalog seam (L1 memory / L2 stored metadata / L3 live read) for a
    registered table, and through the SQL parse + optional sample for a
    query-sourced dataset.  What was missing was a way to ASK without
    mutating: auto-detect is the only thing that resolved this, and it
    writes.  So the editor had nothing to offer and offered a text box.

    Extracted rather than copied.  The fork between "this dataset is a
    query" and "this dataset is a registered table" is exactly the kind of
    decision that drifts when it exists twice — and it decides which
    columns the whole product believes in.

    Returns ``{"columns": [...], "source": str}``; raises ``HTTPException``
    with the same status codes and messages as before.
    """
    from core import config as cfg
    source_tables = ds.get("source_tables", [])
    sref = _source_ref_of(ds)
    detect_source = "catalog"

    if sref is not None or (ds.get("base_query") or "").strip():
        # 2026-08-22: QUERY-sourced (or custom-SQL) dataset — its output
        # shape exists only in the query itself, so detection samples the
        # snapshot SQL (see _derive_columns_from_sql; disclosed as
        # source="query_sample").
        conn_id = (sref or {}).get("connection_id") or next(
            (st.get("connection_id") for st in source_tables
             if isinstance(st, dict) and st.get("connection_id")), None)
        if not conn_id and len(ds.get("connection_ids") or []) == 1:
            # 2026-10-02 -- a custom-SQL dataset keeps its connection in
            # connection_ids (it has no source_tables), which is where the
            # federation engine reads it at run time.  Without this, detection
            # ran with NO connection -- plain DuckDB, so an S3 registered table
            # was "does not exist" -- and the entitlement re-check below was
            # skipped for exactly these datasets.  refresh-source already did
            # this; auto-detect was the one road that did not.
            conn_id = int(ds["connection_ids"][0])
        _base_sql = ds.get("base_query") or ""
        # 2026-08-31 — READ THE QUERY BEFORE TOUCHING THE SOURCE.  This
        # sampled the warehouse first, so auto-detect failed for exactly the
        # datasets people ran it on: the ones whose source was not answering.
        # A query that names its projections states its own shape offline.
        # The entitlement re-check stays UNCONDITIONAL and ahead of any
        # derivation: "a grant revoked after the dataset was created must
        # stop working here too" is a rule about who may act on this
        # dataset, not an incidental side effect of which code path happens
        # to touch the connection.  Making it depend on the derivation
        # route would have quietly deleted it for parseable SQL.
        if conn_id:
            _assert_connection_entitlement(user, [conn_id])
        try:
            derived = await _detect_columns(db, conn_id, _base_sql)
        except HTTPException:
            raise
        except Exception as exc:
            # 2026-10-04 -- say what HAPPENED.  This branch told every author
            # "your query uses SELECT *" whatever the cause; a query that
            # names its columns and that the source REJECTED (an invalid
            # identifier) was sent off to rename columns it had named.
            # 2026-10-10 -- in the SOURCE's words (core.error_sanitizer
            # .describe_exception: the cluster's "Access Denied: Cannot
            # select ..." rather than the driver's TrinoUserError(...) repr)
            # and at the verdict's status: a refused RIGHT is 403
            # (api.connector_errors.refusal_status), else this route's 422.
            from core.error_sanitizer import describe_exception
            _why = describe_exception(exc)
            _status = refusal_status(exc, 422)
            if _derive_columns_from_sql_text(_base_sql):
                raise HTTPException(
                    status_code=_status,
                    detail=f"The source rejected the dataset's query, so its "
                           f"columns could not be confirmed: {_why}. Fix the "
                           f"query and detect again.")
            raise HTTPException(
                status_code=_status,
                detail=f"The query does not name its output columns (it "
                       f"uses SELECT *), so they can only come from the "
                       f"source — and sampling it failed: {_why}. Name the "
                       f"columns explicitly in the query to make detection "
                       f"work without the source being reachable.")
        columns_to_create = derived["columns"]
        detect_source = derived["source"]
        declared_types = derived.get("declared_types") or {}
        declared_decimals = derived.get("declared_decimals") or []
        if not columns_to_create:
            raise HTTPException(
                status_code=422,
                detail="The source query returned no columns — nothing to "
                       "auto-detect. Check the snapshot SQL via GET "
                       "/api/datasets/{id} (base_query).")
    else:
        if not source_tables:
            raise HTTPException(status_code=400, detail="Dataset has no source_tables defined")

        first_source = source_tables[0]
        conn_id = first_source.get("connection_id")
        table_path = first_source.get("table", "")
        if not conn_id or not table_path:
            raise HTTPException(status_code=400, detail="First source table missing connection_id or table path")
        _assert_connection_entitlement(user, [conn_id])

        # 2026-08-22: through the catalog-contract seam.  A mutation
        # endpoint that cannot get columns REFUSES with the reason and the
        # refresh action — creating zero columns silently is exactly the
        # "empty list and silence" failure the contract forbids.
        prov = await _columns_with_provenance(
            db, conn_id, table_path,
            username=(user or {}).get("username", ""))
        if prov["source"] == "none" or not prov["columns"]:
            raise HTTPException(
                status_code=422,
                detail=f"Could not read any columns for '{table_path}' on "
                       f"connection {conn_id}: "
                       f"{prov['message'] or 'no columns available'}. "
                       f"Refresh the column catalog "
                       f"(POST /api/catalog/columns/refresh with "
                       f"{{'connection_id': {conn_id}, 'table': '{table_path}'}}) "
                       f"and retry.")
        detect_source = prov["source"]
        columns_to_create = _classify_schema_columns(prov["schema_info"])
        declared_types = _declared_types(prov["schema_info"])
        declared_decimals = _declared_decimals(prov["schema_info"])

    return {"columns": columns_to_create, "source": detect_source,
            "declared_types": declared_types, "declared_decimals": declared_decimals}



@router.get("/api/datasets/{dataset_id}/source-columns", tags=["semantic-layer"])
async def get_source_columns(dataset_id: int,
                             user: dict = Depends(require_capability("datasets.view"))):
    """What columns does this dataset's SOURCE have?  Read-only.

    2026-09-04.  Operator: *"user should not enter columns name as free
    text...columns should come from schema...we have table n everything we
    are caching so...any sources"*.

    The column editor asked the author to TYPE a physical name
    ("e.g. cust_rev_net_usd").  A name that does not exist in the source is
    accepted, stored, and then fails at query time as *column not found* —
    on Starburst, where identifiers are folded and case-sensitive when
    quoted, a plausible-looking typo is the norm rather than the exception.

    The columns were never unknown.  What was missing was a way to ASK
    without mutating: ``auto-detect`` resolved exactly this and WRITES, so
    an editor that only wanted to offer choices had nothing to call.

    Works for ANY source because it goes through the same resolution
    auto-detect uses — the catalog seam (L1 memory / L2 stored metadata /
    L3 live read) for a registered table, the SQL parse plus an optional
    sample for a query-sourced one.  Each column is marked with whether
    the dataset already maps it, so an editor can offer what is missing
    without the caller re-deriving that comparison (which is where
    "already mapped" and "actually mapped" drift apart).

    A source that cannot answer is reported honestly — ``source: "none"``
    with the reason and a refresh action — never as an empty list, which
    reads as "this table has no columns".
    """
    db = _require_db()
    ds = await _adb(_require_dataset_view, dataset_id, user)
    try:
        resolved = await _source_columns_for_dataset(db, ds, user)
    except HTTPException as exc:
        # The same honest-empty contract the catalog seam uses: the editor
        # must be able to tell "could not read" from "has no columns", and
        # must stay usable either way.
        return {"columns": [], "source": "none",
                "message": str(exc.detail),
                "already_mapped": []}

    existing = await _adb(db.list_dataset_columns, dataset_id)
    mapped = {(c.get("physical_name") or "").casefold() for c in existing}
    cols = []
    for c in resolved["columns"]:
        phys = c.get("physical_name") or ""
        cols.append({**c, "already_mapped": phys.casefold() in mapped})
    return {
        "columns": cols,
        "source": resolved["source"],
        "message": "",
        "already_mapped": sorted(
            c["physical_name"] for c in cols if c["already_mapped"]),
    }


@router.post("/api/datasets/{dataset_id}/auto-detect", tags=["semantic-layer"])
async def auto_detect_columns(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    """Auto-detect columns from the dataset's source tables by reading connection schema.
    Uses chatbot classification patterns to auto-classify as dimension/measure/date.

    2026-08-09 self-service: owner/group/admin (it mutates the dataset), and
    the source connection entitlement is RE-CHECKED at use time — a grant
    revoked after the dataset was created must stop working here too."""
    db = _require_db()
    ds = await _adb(_require_dataset_edit, dataset_id, user)
    from core import config as cfg

    resolved = await _source_columns_for_dataset(db, ds, user)
    columns_to_create = resolved["columns"]
    detect_source = resolved["source"]

    # Check limit.  Counted against what reconciliation would actually
    # ADD: a re-run that renames or leaves columns alone adds nothing, and
    # refusing it for "exceeding" a limit it does not move made the heal
    # path unreachable on any dataset near the cap.
    existing = await _adb(db.list_dataset_columns, dataset_id)
    _folded = {(c.get("physical_name") or "").casefold() for c in existing}
    _new = [c for c in columns_to_create
            if (c.get("physical_name") or "").casefold() not in _folded]
    if len(existing) + len(_new) > cfg.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=_column_limit_detail(len(existing), len(_new),
                                                        cfg.semantic_layer.max_columns_per_dataset))

    outcome = await _reconcile_detected_columns(db, dataset_id,
                                                columns_to_create,
                                                resolved.get("declared_types"),
                                                resolved.get("declared_decimals"))
    logger.info("Auto-detect on dataset %s by %s (source=%s): %d created, "
                "%d renamed, %d retyped, %d unchanged",
                dataset_id, user.get("username"), detect_source,
                outcome["created"], len(outcome["renamed"]),
                len(outcome["retyped"]), outcome["unchanged"])
    # 2026-09-27 -- a published view over a report on this dataset serves
    # these columns to API-key consumers.  A rename / add / re-type here is
    # a schema change THERE, so the view's schema version is re-recorded
    # and its key owners told (core/published_view_schema.py).  Only when
    # something moved; fail-open, never the reason auto-detect fails.
    _pv_versions: list = []
    if outcome["created"] or outcome["renamed"] or outcome["retyped"]:
        try:
            from core.published_view_schema import note_dataset_columns_changed
            _pv_versions = await _adb(note_dataset_columns_changed, db, dataset_id,
                                      changed_by=user.get("username"))
        except Exception as _pv_exc:                         # noqa: BLE001
            logger.warning("auto-detect on dataset %s: published-view schema "
                           "notice skipped (fail-open): %s", dataset_id, _pv_exc)
    return {"created": outcome["created"], "columns": outcome["columns"],
            # the views whose consumers were told, by slug + new version
            "published_view_schema_versions": [
                {"view_id": v.get("view_id"), "version_no": v.get("version_no")}
                for v in _pv_versions],
            "source": detect_source,
            # Reported, not just done: a rename changes what every report
            # on this dataset sends to the engine, so the author is told.
            "renamed": outcome["renamed"],
            "retyped": outcome["retyped"],          # FB-42
            "summed_keys": outcome["summed_keys"],
            "types_problem": resolved.get("types_problem"),
            "unchanged": outcome["unchanged"],
            "stale": outcome["stale"]}


# ═══════════════════════════════════════════════════════════════════════════════
# Classes CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/classes", tags=["semantic-layer"])
async def list_classes(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_dataset_classes, dataset_id)


@router.post("/api/datasets/{dataset_id}/classes", tags=["semantic-layer"])
async def create_class(dataset_id: int, body: ClassCreate,
                       user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    try:
        return await _adb(_require_db().create_dataset_class, dataset_id, name=body.name, label=body.label,
            icon=body.icon, sort_order=body.sort_order)
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409, detail=f"Class '{body.name}' already exists in dataset")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/classes/{class_id}", tags=["semantic-layer"])
async def update_class(class_id: int, body: ClassUpdate,
                       user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_class, class_id), user,
                        "Class not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_dataset_class, class_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Class not found")
    return result


@router.delete("/api/datasets/classes/{class_id}", tags=["semantic-layer"])
async def delete_class(class_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_class, class_id), user,
                        "Class not found")
    if not await _adb(_require_db().delete_dataset_class, class_id):
        raise HTTPException(status_code=404, detail="Class not found")
    audit_event(_db_manager, user, None, "delete_class", "dataset_class", class_id)
    return {"detail": "Class deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Columns CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/columns", tags=["semantic-layer"])
async def list_columns(dataset_id: int,
                       column_type: Optional[str] = None,
                       include_hidden: bool = False,
                       user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    cols = await _adb(_require_db().list_dataset_columns, dataset_id, column_type=column_type, include_hidden=include_hidden or user.get("is_admin", False))
    role = user.get("role", "viewer")
    return _filter_columns_by_role(cols, role)


@router.post("/api/datasets/{dataset_id}/columns", tags=["semantic-layer"])
async def create_column(dataset_id: int, body: ColumnCreate,
                        user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    from core import config
    existing = len(await _adb(_require_db().list_dataset_columns, dataset_id))
    if existing >= config.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=_column_limit_detail(existing, 1,
                                                        config.semantic_layer.max_columns_per_dataset))
    try:
        return await _adb(_require_db().create_dataset_column, dataset_id, **body.model_dump())
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409,
                                detail=f"Column '{body.physical_name}' already exists in dataset")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/datasets/{dataset_id}/columns/bulk", tags=["semantic-layer"])
async def bulk_create_columns(dataset_id: int, body: BulkColumnCreate,
                              user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    from core import config
    existing = len(await _adb(_require_db().list_dataset_columns, dataset_id))
    if existing + len(body.columns) > config.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=_column_limit_detail(existing, len(body.columns),
                                                        config.semantic_layer.max_columns_per_dataset))
    cols = [c.model_dump() for c in body.columns]
    results = await _adb(_require_db().bulk_create_dataset_columns, dataset_id, cols)
    return {"created": len(results), "columns": results}


@router.put("/api/datasets/columns/{column_id}", tags=["semantic-layer"])
async def update_column(column_id: int, body: ColumnUpdate,
                        user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_column, column_id), user,
                        "Column not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_dataset_column, column_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Column not found")
    return result


@router.delete("/api/datasets/columns/{column_id}", tags=["semantic-layer"])
async def delete_column(column_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_column, column_id), user,
                        "Column not found")
    if not await _adb(_require_db().delete_dataset_column, column_id):
        raise HTTPException(status_code=404, detail="Column not found")
    audit_event(_db_manager, user, None, "delete_column", "dataset_column", column_id)
    return {"detail": "Column deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Relationships CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/relationships", tags=["semantic-layer"])
async def list_relationships(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_dataset_relationships, dataset_id)


@router.post("/api/datasets/{dataset_id}/relationships", tags=["semantic-layer"])
async def create_relationship(dataset_id: int, body: RelationshipCreate,
                              user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    return await _adb(_require_db().create_dataset_relationship, dataset_id, left_table=body.left_table, right_table=body.right_table,
        join_keys=[jk for jk in body.join_keys], join_type=body.join_type,
        cardinality=body.cardinality)


@router.put("/api/datasets/relationships/{rel_id}", tags=["semantic-layer"])
async def update_relationship(rel_id: int, body: RelationshipUpdate,
                              user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_relationship, rel_id), user,
                        "Relationship not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_dataset_relationship, rel_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Relationship not found")
    return result


@router.delete("/api/datasets/relationships/{rel_id}", tags=["semantic-layer"])
async def delete_relationship(rel_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_dataset_relationship, rel_id), user,
                        "Relationship not found")
    if not await _adb(_require_db().delete_dataset_relationship, rel_id):
        raise HTTPException(status_code=404, detail="Relationship not found")
    audit_event(_db_manager, user, None, "delete_relationship", "dataset_relationship", rel_id)
    return {"detail": "Relationship deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Drill Hierarchies CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/hierarchies", tags=["semantic-layer"])
async def list_hierarchies(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_drill_hierarchies, dataset_id)


@router.post("/api/datasets/{dataset_id}/hierarchies", tags=["semantic-layer"])
async def create_hierarchy(dataset_id: int, body: HierarchyCreate,
                           user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    try:
        return await _adb(_require_db().create_drill_hierarchy, dataset_id, name=body.name, levels=body.levels)
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409, detail=f"Hierarchy '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/hierarchies/{hierarchy_id}", tags=["semantic-layer"])
async def update_hierarchy(hierarchy_id: int, body: HierarchyUpdate,
                           user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_drill_hierarchy, hierarchy_id), user,
                        "Hierarchy not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_drill_hierarchy, hierarchy_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Hierarchy not found")
    return result


@router.delete("/api/datasets/hierarchies/{hierarchy_id}", tags=["semantic-layer"])
async def delete_hierarchy(hierarchy_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_drill_hierarchy, hierarchy_id), user,
                        "Hierarchy not found")
    if not await _adb(_require_db().delete_drill_hierarchy, hierarchy_id):
        raise HTTPException(status_code=404, detail="Hierarchy not found")
    audit_event(_db_manager, user, None, "delete_hierarchy", "drill_hierarchy", hierarchy_id)
    return {"detail": "Hierarchy deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Pre-Defined Conditions CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/conditions", tags=["semantic-layer"])
async def list_conditions(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_predefined_conditions, dataset_id)


@router.post("/api/datasets/{dataset_id}/conditions", tags=["semantic-layer"])
async def create_condition(dataset_id: int, body: ConditionCreate,
                           user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    try:
        return await _adb(_require_db().create_predefined_condition, dataset_id, name=body.name, where_clause=body.where_clause,
            label=body.label, description=body.description, sort_order=body.sort_order)
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409, detail=f"Condition '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/conditions/{condition_id}", tags=["semantic-layer"])
async def update_condition(condition_id: int, body: ConditionUpdate,
                           user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_predefined_condition, condition_id), user,
                        "Condition not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_predefined_condition, condition_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Condition not found")
    return result


@router.delete("/api/datasets/conditions/{condition_id}", tags=["semantic-layer"])
async def delete_condition(condition_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_predefined_condition, condition_id), user,
                        "Condition not found")
    if not await _adb(_require_db().delete_predefined_condition, condition_id):
        raise HTTPException(status_code=404, detail="Condition not found")
    audit_event(_db_manager, user, None, "delete_condition", "predefined_condition", condition_id)
    return {"detail": "Condition deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Aggregation Awareness CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/agg-awareness", tags=["semantic-layer"])
async def list_agg_awareness(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_aggregation_awareness, dataset_id)


@router.post("/api/datasets/{dataset_id}/agg-awareness", tags=["semantic-layer"])
async def create_agg_awareness(dataset_id: int, body: AggAwarenessCreate,
                               user: dict = Depends(require_capability("datasets.manage"))):
    await _adb(_ensure_dataset_exists, dataset_id)
    row = await _adb(
        _require_db().create_aggregation_awareness,
        dataset_id, measure_col_id=body.measure_col_id, agg_table=body.agg_table,
        agg_dimensions=body.agg_dimensions, connection_id=body.connection_id,
        is_enabled=body.is_enabled,
    )
    # Phase 7 (2026-08-09) — ★ registration-time verification GATE.  The
    # numbers come from a table QueryStudio does not control: the mapping
    # NEVER serves until this probe positively passes, and a MISMATCH
    # disables it on the spot (the response carries the verdict so the
    # admin sees it immediately).  A probe error leaves the row configured
    # but unserved (re-probed on the schedule / next routing touch).
    verification: dict = {"status": "error", "detail": "verification unavailable"}
    try:
        from core.agg_cache import verify_agg_awareness
        verification = await _adb(verify_agg_awareness, row["id"])
    except Exception as exc:
        logger.warning("agg-awareness %s registration verification failed: %s",
                       row.get("id"), exc)
    fresh = await _adb(_require_db().get_aggregation_awareness, row["id"])
    out = dict(fresh or row)
    out["verification"] = verification
    return out


@router.put("/api/datasets/agg-awareness/{agg_id}", tags=["semantic-layer"])
async def update_agg_awareness(agg_id: int, body: AggAwarenessUpdate,
                               user: dict = Depends(require_capability("datasets.manage"))):
    db = _require_db()
    existing = await _adb(db.get_aggregation_awareness, agg_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Aggregation awareness rule not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    row = await _adb(db.update_aggregation_awareness, agg_id, **updates)
    # Any edit (or re-enable) re-runs the verification gate; an edited
    # definition also changes the fingerprint, so a stale positive verdict
    # can never carry over.
    verification: dict = {"status": "error", "detail": "verification unavailable"}
    try:
        from core.agg_cache import verify_agg_awareness
        verification = await _adb(verify_agg_awareness, agg_id)
    except Exception as exc:
        logger.warning("agg-awareness %d update verification failed: %s",
                       agg_id, exc)
    fresh = await _adb(db.get_aggregation_awareness, agg_id)
    audit_event(_db_manager, user, None, "update_agg_awareness", "agg_awareness", agg_id)
    out = dict(fresh or row)
    out["verification"] = verification
    return out


@router.post("/api/datasets/agg-awareness/{agg_id}/verify", tags=["semantic-layer"])
async def verify_agg_awareness_endpoint(agg_id: int,
                                        user: dict = Depends(require_capability("datasets.manage"))):
    if not await _adb(_require_db().get_aggregation_awareness, agg_id):
        raise HTTPException(status_code=404, detail="Aggregation awareness rule not found")
    from core.agg_cache import verify_agg_awareness
    verdict = await _adb(verify_agg_awareness, agg_id)
    return verdict


@router.get("/api/datasets/{dataset_id}/agg-awareness/status", tags=["semantic-layer"])
async def get_agg_awareness_status_endpoint(dataset_id: int,
                                            user: dict = Depends(require_capability("datasets.manage"))):
    await _adb(_ensure_dataset_exists, dataset_id)
    from core.agg_cache import get_agg_awareness_status
    return await _adb(get_agg_awareness_status, dataset_id)


@router.delete("/api/datasets/agg-awareness/{agg_id}", tags=["semantic-layer"])
async def delete_agg_awareness(agg_id: int, user: dict = Depends(require_capability("datasets.manage"))):
    if not await _adb(_require_db().delete_aggregation_awareness, agg_id):
        raise HTTPException(status_code=404, detail="Aggregation awareness rule not found")
    audit_event(_db_manager, user, None, "delete_agg_awareness", "agg_awareness", agg_id)
    return {"detail": "Aggregation awareness rule deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Calculated Metrics CRUD (Phase 101)
# ═══════════════════════════════════════════════════════════════════════════════

def _extract_depends_on(expression: str, dataset_id: int) -> List[str]:
    """Auto-extract column names referenced in a metric expression."""
    import re
    _SQL_KEYWORDS = {
        "SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "NULL", "AS", "CASE",
        "WHEN", "THEN", "ELSE", "END", "LIKE", "IN", "BETWEEN", "IS", "TRUE",
        "FALSE", "SUM", "AVG", "COUNT", "MIN", "MAX", "DISTINCT", "OVER",
        "PARTITION", "BY", "ORDER", "ASC", "DESC", "ROWS", "RANGE", "CURRENT",
        "ROW", "UNBOUNDED", "PRECEDING", "FOLLOWING", "CAST", "COALESCE",
        "NULLIF", "IF", "IIF", "ABS", "ROUND", "FLOOR", "CEIL", "UPPER",
        "LOWER", "TRIM", "LENGTH", "SUBSTR", "REPLACE", "CONCAT",
    }
    tokens = re.findall(r'\b([a-zA-Z_]\w*)\b', expression)
    known_cols = set()
    db = _require_db()
    for col in db.list_dataset_columns(dataset_id):
        known_cols.add(col["physical_name"])
    return sorted({t for t in tokens if t.upper() not in _SQL_KEYWORDS and t in known_cols})


@router.get("/api/datasets/{dataset_id}/metrics", tags=["semantic-layer"])
async def list_metrics(dataset_id: int,
                       active_only: bool = False,
                       user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_calculated_metrics, dataset_id, active_only=active_only)


@router.post("/api/datasets/{dataset_id}/metrics", tags=["semantic-layer"])
async def create_metric(dataset_id: int, body: MetricCreate,
                        user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_dataset_edit, dataset_id, user)  # 2026-08-09: owner/group/admin
    db = _require_db()
    from core import config
    existing = len(await _adb(db.list_calculated_metrics, dataset_id))
    if existing >= config.semantic_layer.max_metrics_per_dataset:
        raise HTTPException(status_code=400,
                            detail=f"Metric limit reached ({config.semantic_layer.max_metrics_per_dataset})")
    data = body.model_dump()
    # Auto-populate depends_on if not provided and validation is enabled
    if not data.get("depends_on") and config.semantic_layer.metric_validation_enabled:
        data["depends_on"] = await _adb(_extract_depends_on, data["expression"], dataset_id)
    data["owner"] = user.get("username", "admin")
    try:
        return await _adb(db.create_calculated_metric, dataset_id, **data)
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409,
                                detail=f"Metric '{body.name}' already exists in dataset")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/metrics/{metric_id}", tags=["semantic-layer"])
async def update_metric(metric_id: int, body: MetricUpdate,
                        user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_calculated_metric, metric_id), user,
                        "Metric not found")
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_calculated_metric, metric_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Metric not found")
    return result


@router.delete("/api/datasets/metrics/{metric_id}", tags=["semantic-layer"])
async def delete_metric(metric_id: int, user: dict = Depends(require_capability("datasets.edit"))):
    await _adb(_require_child_edit, await _adb(_require_db().get_calculated_metric, metric_id), user,
                        "Metric not found")
    if not await _adb(_require_db().delete_calculated_metric, metric_id):
        raise HTTPException(status_code=404, detail="Metric not found")
    audit_event(_db_manager, user, None, "delete_metric", "calculated_metric", metric_id)
    return {"detail": "Metric deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Admin Config
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/admin/semantic-layer/config", tags=["semantic-layer"])
async def get_semantic_layer_config(user: dict = Depends(require_capability("datasets.manage"))):
    from core import config
    return {
        "enabled":                       config.semantic_layer.enabled,
        "auto_detect_column_types":      config.semantic_layer.auto_detect_column_types,
        "max_columns_per_dataset":       config.semantic_layer.max_columns_per_dataset,
        "max_datasets":                  config.semantic_layer.max_datasets,
        "cascading_prompts_enabled":     config.semantic_layer.cascading_prompts_enabled,
        "drill_hierarchies_enabled":     config.semantic_layer.drill_hierarchies_enabled,
        "aggregation_awareness_enabled": config.semantic_layer.aggregation_awareness_enabled,
        "default_row_limit":             config.semantic_layer.default_row_limit,
        "synonym_matching_enabled":      config.semantic_layer.synonym_matching_enabled,
        "max_metrics_per_dataset":       config.semantic_layer.max_metrics_per_dataset,
        "metric_validation_enabled":     config.semantic_layer.metric_validation_enabled,
    }


@router.put("/api/admin/semantic-layer/config", tags=["semantic-layer"])
async def update_semantic_layer_config(body: SemanticLayerConfigUpdate,
                                       user: dict = Depends(require_capability("datasets.manage"))):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("semantic_layer", k, v)
    logger.info("Semantic layer config updated by %s: %s", user.get("username"), list(updates.keys()))
    return await get_semantic_layer_config(user=user)


# ═══════════════════════════════════════════════════════════════════════════════
# Federation Config (admin)
# ═══════════════════════════════════════════════════════════════════════════════

class FederationConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    max_concurrent_executions: Optional[int] = None
    execution_timeout_seconds: Optional[int] = None
    max_result_rows: Optional[int] = None
    named_secrets_enabled: Optional[bool] = None
    fallback_to_pragmas: Optional[bool] = None
    execution_history_retention_days: Optional[int] = None
    merge_max_datasets: Optional[int] = None
    preview_row_limit: Optional[int] = None
    distinct_values_limit: Optional[int] = None


@router.get("/api/admin/federation/config", tags=["federation"])
async def get_federation_config(user: dict = Depends(require_capability("datasets.manage"))):
    from core import config
    return {
        "enabled":                       config.federation.enabled,
        "max_concurrent_executions":     config.federation.max_concurrent_executions,
        "execution_timeout_seconds":     config.federation.execution_timeout_seconds,
        "max_result_rows":               config.federation.max_result_rows,
        "named_secrets_enabled":         config.federation.named_secrets_enabled,
        "fallback_to_pragmas":           config.federation.fallback_to_pragmas,
        "execution_history_retention_days": config.federation.execution_history_retention_days,
        "merge_max_datasets":            config.federation.merge_max_datasets,
        "preview_row_limit":             config.federation.preview_row_limit,
        "distinct_values_limit":         config.federation.distinct_values_limit,
    }


@router.put("/api/admin/federation/config", tags=["federation"])
async def update_federation_config(body: FederationConfigUpdate,
                                    user: dict = Depends(require_capability("datasets.manage"))):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("federation", k, v)
    logger.info("Federation config updated by %s: %s", user.get("username"), list(updates.keys()))
    return await get_federation_config(user=user)


# ═══════════════════════════════════════════════════════════════════════════════
# Dataset Execution (Phase 54 — Federation Engine)
# ═══════════════════════════════════════════════════════════════════════════════

_federation_engine = None


def set_federation_dependencies(federation_engine):
    """Called from main.py startup to inject the FederationEngine instance."""
    global _federation_engine
    _federation_engine = federation_engine


def _require_federation():
    if _federation_engine is None:
        raise RuntimeError("Federation engine not initialised — call set_federation_dependencies() first")
    return _federation_engine


class DatasetExecuteRequest(StrictRequestModel):
    """Request body for executing a dataset query."""
    column_ids: List[int] = Field(..., min_length=1)
    metric_ids: List[int] = []             # Phase 101: CalculatedMetric IDs to inject
    filters: List[Dict[str, Any]] = []
    condition_ids: List[int] = []
    order_by: List[Dict[str, Any]] = []   # [{column_id, direction}]
    limit: Optional[int] = None
    #: 2026-09-17 — buckets of one axis, side by side, plus derived columns.
    #: ``{axis, buckets[], measures[], derived[], on_missing}`` — see
    #: core/comparison.py.  Validated there, and an unusable spec REFUSES
    #: with the field named rather than quietly producing a report without
    #: the comparison columns someone asked for.
    comparison: Optional[Dict[str, Any]] = None
    #: 2026-09-17 - {hierarchy_id, level}.  Drills the DIMENSIONS to the
    #: hierarchy's levels 0..level while keeping the selected measures.
    drill: Optional[Dict[str, Any]] = None
    #: H1 (2026-10-07): the client's correlation id for this run -- carried by
    #: every execution_queued event while the request waits for a slot in the
    #: pod-wide fair queue, and the handle POST /api/execute/queued/cancel
    #: ends that wait by.
    client_request_id: Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)


class DatasetMergeRequest(StrictRequestModel):
    """Request body for merged (multi-dataset) query execution."""
    primary_dataset_id: int
    secondary_dataset_id: int
    primary_column_ids: List[int] = Field(..., min_length=1)
    secondary_column_ids: List[int] = Field(..., min_length=1)
    merge_keys: List[Dict[str, str]] = Field(..., min_length=1)  # [{"left":"col","right":"col"}]
    merge_type: str = Field("inner", pattern=r"^(inner|left|right|full|outer)$")  # "outer" == "full" (cross_source_combine.normalise_join_how)
    primary_filters: List[Dict[str, Any]] = []
    secondary_filters: List[Dict[str, Any]] = []
    primary_condition_ids: List[int] = []
    secondary_condition_ids: List[int] = []
    limit: Optional[int] = None
    #: H1 (2026-10-07): the client's correlation id for this run -- carried by
    #: every execution_queued event while the request waits for a slot in the
    #: pod-wide fair queue, and the handle POST /api/execute/queued/cancel
    #: ends that wait by.
    client_request_id: Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)


class DatasetUnionSide(BaseModel):
    """One side of a dataset UNION — the same vocabulary as a single
    execute: which columns, which filters, which pre-defined conditions."""
    dataset_id: int
    column_ids: List[int] = Field(..., min_length=1)
    filters: List[Dict[str, Any]] = []
    condition_ids: List[int] = []


class DatasetUnionRequest(BaseModel):
    """Request body for UNIONing 2+ datasets (cross-source by construction —
    each dataset executes on its own connection(s) through the single
    dataset door, then the sides are combined UNION ALL BY NAME)."""
    datasets: List[DatasetUnionSide] = Field(..., min_length=2)
    limit: Optional[int] = None
    #: H1 (2026-10-07): the client's correlation id for this run -- carried by
    #: every execution_queued event while the request waits for a slot in the
    #: pod-wide fair queue, and the handle POST /api/execute/queued/cancel
    #: ends that wait by.
    client_request_id: Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)
    # pad_nulls (default): a column one side lacks is NULL-padded BY NAME
    # and DISCLOSED in the response's union_report.  fail: any column-set
    # difference refuses the union with the per-side missing lists.
    on_mismatch: str = Field("pad_nulls", pattern=r"^(pad_nulls|fail)$")


class MergedDimensionCreate(BaseModel):
    primary_dataset_id: int
    secondary_dataset_id: int
    name: str = Field(..., min_length=1, max_length=200)
    merge_keys: List[Dict[str, str]] = Field(..., min_length=1)
    merge_type: str = Field("inner", pattern=r"^(inner|left|right|full|outer)$")  # "outer" == "full" (cross_source_combine.normalise_join_how)
    is_active: bool = True


class MergedDimensionUpdate(BaseModel):
    name: Optional[str] = None
    merge_keys: Optional[List[Dict[str, str]]] = None
    merge_type: Optional[str] = Field(None, pattern=r"^(inner|left|right|full)$")
    is_active: Optional[bool] = None


class ColumnValuesRequest(BaseModel):
    column_id: int
    parent_filters: List[Dict[str, Any]] = []
    limit: int = 500
    # 2026-10-03 -- ask for the column's MIN..MAX too.  A date picker offers
    # only the dates that exist; when the list is CUT it says which range
    # the data covers instead of hiding the dates past the cap.  A whole
    # list is its own range, so the source is asked only for a cut one.
    include_range: bool = False
    # 2026-10-23 -- "metadata": a PARTITION column's values from the table's
    # metadata (no data scan), by THE rule (core/reports/param_values.py) --
    # what a report author captures as a parameter's saved list.  Default:
    # the data, as before.
    source: Optional[str] = None


@router.post("/api/datasets/{dataset_id}/execute", tags=["federation"])
async def execute_dataset(dataset_id: int, body: DatasetExecuteRequest,
                           user: dict = Depends(require_capability("datasets.view"))):
    """Execute a semantic layer query against a single dataset."""
    from core import config
    if not config.federation.enabled:
        raise HTTPException(status_code=403, detail="Federation execution is disabled")

    db = _require_db()
    ds = await _adb(_ensure_dataset_exists, dataset_id)
    # 2026-08-09 self-service: published, OR owner/group/admin — an owner
    # must be able to run their own draft (the build-test loop).
    if not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to execute this dataset (it is not "
                   "published and you are not its owner)")

    engine = _require_federation()
    execution_id = str(uuid.uuid4())
    user_role = user.get("role", "viewer")
    username = user.get("username", "anonymous")

    # Create execution record
    await _adb(db.create_federation_execution, 
        execution_id=execution_id, dataset_id=dataset_id,
        sql_generated="", column_ids=body.column_ids,
        filters=body.filters, condition_ids=body.condition_ids,
        executed_by=username,
    )

    try:
        # FB-24 (2026-09-19): this ran the engine SYNCHRONOUSLY ON THE EVENT
        # LOOP.  Every S3 LIST, presign and DuckDB scan inside it blocked the
        # one thread that serves every other request in the process --
        # measured: an unfiltered scan of the 7,300-file corpus took the API
        # down for 202 s (/api/business-reports?limit=1 timed out at 25 s,
        # twice).  Six other call sites in this file were already off-loop;
        # the hottest path in the product was not one of them.  It now runs
        # through the same admission gate the report routes use (a typed,
        # bounded pool slot on a wp- thread -- not the default executor
        # every adb() call shares), so a long scan costs a slot, never the
        # loop.  A refusal is the same 503 + Retry-After /api/execute gives.
        result = await _run_engine_off_loop(
            engine.execute_dataset_query,
            db=db, execution_id=execution_id, username=username,
            client_request_id=body.client_request_id,
            dataset_id=dataset_id,
            column_ids=body.column_ids,
            metric_ids=body.metric_ids,
            filters=body.filters,
            condition_ids=body.condition_ids,
            order_by=body.order_by,
            limit=body.limit,
            comparison=body.comparison,
            drill=body.drill,
            user_role=user_role,
            # 2026-08-09 self-service RLS: thread the REAL principal so
            # secure_sql applies row/column policies — the same user_ctx the
            # business-report execute path (business_reports_api) and this
            # module's preview/LOV endpoints (Phase 131 deep-dive #13)
            # already pass.  Without it a self-served dataset would be a
            # direct row-security bypass (the federation engine's
            # _warn_if_rls_policies_skipped safety net flags exactly this).
            # Admins are bypassed inside secure_sql, so admin behaviour is
            # unchanged.
            user_ctx=user,
        )
        # Update execution record
        await _adb(db.update_federation_execution, execution_id,
            status="completed", output_path=result.output_path,
            total_rows=result.total_rows, duration_seconds=result.duration_seconds,
            sql_generated=result.sql_generated, sources_used=result.sources_used,
        )
        logger.info("Dataset %d executed by %s: %d rows (exec=%s)",
                     dataset_id, username, result.total_rows, execution_id)
        return result.to_dict()

    except SourceUnavailableError as exc:
        # FB-39 (2026-09-19): the source could not be REACHED (open
        # breaker, refused connect, DNS, timeout) -- not a refusal of the
        # statement.  503 + Retry-After, the reason recorded, never the
        # 422 below that blames the request.
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        # Engine REFUSALS (unknown/forbidden columns, unrenderable filter,
        # RLS enforcement failure) are actionable client errors — a generic
        # 500 hid the reason the engine took care to state.
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        logger.warning("Dataset %d execution refused: %s", dataset_id, exc)
        # 2026-10-10: a verdict on the caller's RIGHT at the source is 403
        # (api.connector_errors.refusal_status); every other refusal 422.
        raise HTTPException(status_code=refusal_status(exc, 422), detail=str(exc))
    except HTTPException:
        # FB-24: an admission REFUSAL (503 + Retry-After) raised by the
        # off-loop seam is an HTTPException; the generic handler below
        # would rewrite it into a 500 "Execution failed" (the FB-33 class).
        raise
    except Exception as exc:
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        logger.error("Dataset %d execution failed: %s", dataset_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Execution failed")


@router.post("/api/datasets/federation/execute", tags=["federation"])
async def execute_merged_datasets(body: DatasetMergeRequest,
                                   user: dict = Depends(require_capability("datasets.view"))):
    """Execute a merged query across two datasets (BO multiple data providers)."""
    from core import config
    if not config.federation.enabled:
        raise HTTPException(status_code=403, detail="Federation execution is disabled")

    db = _require_db()
    engine = _require_federation()
    execution_id = str(uuid.uuid4())
    user_role = user.get("role", "viewer")
    username = user.get("username", "anonymous")

    # Validate both datasets exist and are accessible (2026-08-09
    # self-service: published OR owner/group/admin — same rule as single
    # execute; the caller needs view on BOTH sides of the merge).
    for ds_id in (body.primary_dataset_id, body.secondary_dataset_id):
        ds = await _adb(_ensure_dataset_exists, ds_id)
        if not _ds_can_view(ds, user):
            raise HTTPException(
                status_code=403,
                detail=f"Not authorized to execute dataset {ds_id} (it is "
                       "not published and you are not its owner)")

    # Create execution record
    await _adb(db.create_federation_execution, 
        execution_id=execution_id, dataset_id=body.primary_dataset_id,
        merged_dataset_id=body.secondary_dataset_id,
        column_ids=body.primary_column_ids + body.secondary_column_ids,
        filters=body.primary_filters + body.secondary_filters,
        condition_ids=body.primary_condition_ids + body.secondary_condition_ids,
        executed_by=username,
    )

    try:
        result = await _run_engine_off_loop(                # FB-24
            engine.execute_merged_query,
            db=db, execution_id=execution_id, username=username,
            client_request_id=body.client_request_id,
            primary_dataset_id=body.primary_dataset_id,
            secondary_dataset_id=body.secondary_dataset_id,
            primary_column_ids=body.primary_column_ids,
            secondary_column_ids=body.secondary_column_ids,
            merge_keys=body.merge_keys,
            merge_type=body.merge_type,
            primary_filters=body.primary_filters,
            secondary_filters=body.secondary_filters,
            primary_condition_ids=body.primary_condition_ids,
            secondary_condition_ids=body.secondary_condition_ids,
            limit=body.limit,
            user_role=user_role,
            # 2026-08-09 self-service RLS — same user_ctx threading as the
            # single-dataset execute above (and as the BR merged path).
            user_ctx=user,
        )
        await _adb(db.update_federation_execution, execution_id,
            status="completed", output_path=result.output_path,
            total_rows=result.total_rows, duration_seconds=result.duration_seconds,
            sql_generated=result.sql_generated, sources_used=result.sources_used,
        )
        logger.info("Merged execution %s+%s by %s: %d rows",
                     body.primary_dataset_id, body.secondary_dataset_id,
                     username, result.total_rows)
        return result.to_dict()

    except SourceUnavailableError as exc:
        # FB-39 (2026-09-19): the source could not be REACHED (open
        # breaker, refused connect, DNS, timeout) -- not a refusal of the
        # statement.  503 + Retry-After, the reason recorded, never the
        # 422 below that blames the request.
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        # Engine REFUSALS (unknown/forbidden columns, unrenderable filter,
        # invalid merge type, RLS enforcement failure) are actionable client
        # errors — surfacing them as a generic 500 hid the reason.
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        logger.warning("Merged execution refused: %s", exc)
        raise HTTPException(status_code=refusal_status(exc, 422), detail=str(exc))
    except HTTPException:
        # FB-24: an admission REFUSAL (503 + Retry-After) raised by the
        # off-loop seam is an HTTPException; the generic handler below
        # would rewrite it into a 500 "Execution failed" (the FB-33 class).
        raise
    except Exception as exc:
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        logger.error("Merged execution failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Execution failed")


@router.post("/api/datasets/federation/union", tags=["federation"])
async def execute_union_datasets(body: DatasetUnionRequest,
                                 user: dict = Depends(require_capability("datasets.view"))):
    """UNION 2+ datasets — the answer to the operator's *"how same query
    will be executed cross sources n unioned the datasets"*.

    Each side executes through the ONE dataset door
    (``FederationEngine.execute_dataset_query`` — RLS, role visibility,
    connection routing, per-source dialect transpile all apply), then the
    parquet sides combine via the cross-source ``UNION ALL BY NAME``
    chokepoint (``core.executors.cross_source_combine``).  Alignment is BY
    NAME with typed NULL padding, disclosed per side in ``union_report`` —
    never a silent drop.  Sides may live on entirely different connections:
    that is what makes the union cross-source."""
    from core import config
    if not config.federation.enabled:
        raise HTTPException(status_code=403, detail="Federation execution is disabled")

    max_sides = config.semantic_layer.max_union_datasets
    if len(body.datasets) > max_sides:
        raise HTTPException(
            status_code=422,
            detail=f"Union of {len(body.datasets)} datasets exceeds the cap "
                   f"of {max_sides} (semantic_layer.max_union_datasets).")

    db = _require_db()
    engine = _require_federation()
    execution_id = str(uuid.uuid4())
    username = user.get("username", "anonymous")

    # View access on EVERY side (published OR owner/group/admin) — same rule
    # as single execute and merge.
    for side in body.datasets:
        ds = await _adb(_ensure_dataset_exists, side.dataset_id)
        if not _ds_can_view(ds, user):
            raise HTTPException(
                status_code=403,
                detail=f"Not authorized to execute dataset {side.dataset_id} "
                       "(it is not published and you are not its owner)")

    await _adb(db.create_federation_execution,
        execution_id=execution_id, dataset_id=body.datasets[0].dataset_id,
        merged_dataset_id=(body.datasets[1].dataset_id
                           if len(body.datasets) == 2 else None),
        column_ids=[cid for s in body.datasets for cid in s.column_ids],
        filters=[f for s in body.datasets for f in s.filters],
        condition_ids=[c for s in body.datasets for c in s.condition_ids],
        executed_by=username,
    )

    try:
        result = await _run_engine_off_loop(                # FB-24
            engine.execute_union_query,
            db=db, execution_id=execution_id, username=username,
            client_request_id=body.client_request_id,
            datasets=[s.model_dump() for s in body.datasets],
            limit=body.limit,
            on_mismatch=body.on_mismatch,
            user_role=user.get("role", "viewer"),
            # RLS: the REAL principal, threaded exactly as the single and
            # merged execute paths do — the union is not a new door.
            user_ctx=user,
        )
        await _adb(db.update_federation_execution, execution_id,
            status="completed", output_path=result.output_path,
            total_rows=result.total_rows, duration_seconds=result.duration_seconds,
            sql_generated=result.sql_generated, sources_used=result.sources_used,
        )
        logger.info("Union execution %s (%s) by %s: %d rows",
                    execution_id, [s.dataset_id for s in body.datasets],
                    username, result.total_rows)
        return result.to_dict()

    except SourceUnavailableError as exc:
        # FB-39 (2026-09-19): the source could not be REACHED (open
        # breaker, refused connect, DNS, timeout) -- not a refusal of the
        # statement.  503 + Retry-After, the reason recorded, never the
        # 422 below that blames the request.
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        logger.warning("Union execution refused: %s", exc)
        raise HTTPException(status_code=refusal_status(exc, 422), detail=str(exc))
    except HTTPException:
        # FB-24: an admission REFUSAL (503 + Retry-After) raised by the
        # off-loop seam is an HTTPException; the generic handler below
        # would rewrite it into a 500 "Execution failed" (the FB-33 class).
        raise
    except Exception as exc:
        await _adb(db.update_federation_execution, execution_id,
            status="failed", error_message=str(exc),
        )
        raise_if_self_clearing(exc)   # a source that cannot be reached RIGHT NOW: 503 + Retry-After, not "contact support"
        logger.error("Union execution failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Execution failed")


@router.get("/api/datasets/{dataset_id}/preview", tags=["federation"])
async def preview_dataset(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    """Quick preview of first N rows from a dataset."""
    from core import config
    db = _require_db()
    ds = await _adb(_ensure_dataset_exists, dataset_id)
    # 2026-08-09 self-service: published OR owner/group/admin.
    if not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to preview this dataset (it is not "
                   "published and you are not its owner)")

    engine = _require_federation()
    try:
        return engine.preview_dataset(
            dataset_id=dataset_id,
            limit=config.federation.preview_row_limit,
            user_role=user.get("role", "viewer"),
            user_ctx=user,  # Phase 131 deep-dive #13: RLS on preview
        )
    except SourceUnavailableError as exc:
        # FB-39: the source could not be reached -- 503 + Retry-After.
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        # Engine refusals and the source's own verdict (SourceStatementError)
        # -- actionable, already sanitised, and hidden behind "contact
        # support" if sent as a 500.
        logger.warning("Preview refused for dataset %d: %s", dataset_id, exc)
        raise HTTPException(status_code=refusal_status(exc, 422), detail=str(exc))
    except Exception as exc:
        logger.error("Preview failed for dataset %d: %s", dataset_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Preview failed: {exc}")


async def column_value_range(engine, *, dataset_id: int, column_id: int,
                             parent_filters: Optional[List[Dict[str, Any]]],
                             values: list, truncated: bool,
                             user: Optional[dict]) -> Dict[str, Any]:
    """``{"range": {"min", "max"}}`` for a value list, or why it is unknown.

    2026-10-03.  A WHOLE list is its own range (no second scan).  A CUT list
    asks the source for MIN/MAX over the same scope (parent filters, row
    security -- ``FederationEngine.get_column_value_range``).  A failure is
    SAID (``range_error``) and never fails the list: unknown is not empty,
    and the values already read are still right.  Shared with the report
    parameter LOV route, so the two lists answer "which dates exist" alike.
    """
    if not truncated:
        present = [v for v in values if v is not None]
        if not present:
            return {"range": None}
        try:
            return {"range": {"min": min(present), "max": max(present)}}
        except TypeError:                     # mixed types: no order to state
            return {"range": None}
    try:
        lo, hi = await asyncio.to_thread(
            engine.get_column_value_range,
            dataset_id=dataset_id, column_id=column_id,
            parent_filters=parent_filters or None, user_ctx=user)
        return {"range": {"min": lo, "max": hi}}
    except Exception as exc:                  # noqa: BLE001
        logger.warning("Column range unreadable (dataset %s col %s): %s",
                       dataset_id, column_id, exc)
        return {"range": None, "range_error": str(exc)}


@router.post("/api/datasets/{dataset_id}/column-values", tags=["federation"])
async def get_column_values(dataset_id: int, body: ColumnValuesRequest,
                             user: dict = Depends(require_capability("datasets.view"))):
    """Get distinct values for a column (cascading prompts / LOV)."""
    from core import config
    db = _require_db()
    ds = await _adb(_ensure_dataset_exists, dataset_id)
    # 2026-08-09 self-service: published OR owner/group/admin.
    if not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to query this dataset (it is not "
                   "published and you are not its owner)")

    engine = _require_federation()
    max_limit = config.federation.distinct_values_limit
    cap = min(body.limit, max_limit)
    _note = None
    if (body.source or "").strip().lower() == "metadata":
        from core.reports import param_values as _pv
        _allowed, _why = _pv.metadata_allowed(db, user)
        if body.parent_filters:
            _note = "Narrowed by other filters, so the values are read from the data."
        elif not _allowed:
            _note = _why
        else:
            _lk = await _pv.partition_values(db, dataset_id=dataset_id, column_id=body.column_id,
                                             user=user)
            if _lk.is_partition:
                vals = list(_lk.values or [])
                return {"column_id": body.column_id, "values": vals[:cap],
                        "count": min(len(vals), cap),
                        "truncated": _lk.truncated or len(vals) > cap, "limit": cap,
                        "source": "metadata", "table": _lk.table}
            return {"column_id": body.column_id, "values": [], "count": 0,
                    "truncated": False, "limit": cap, "source": "metadata",
                    "reason": _lk.reason or "No partition values could be read."}
    try:
        # One value MORE than the cap is asked for, so the answer can say
        # whether the list was cut (2026-10-02): a capped list that looks
        # complete makes a date the author needs look like it has no data.
        values = await asyncio.to_thread(                   # FB-24: off-loop
            engine.get_column_distinct_values,
            dataset_id=dataset_id,
            column_id=body.column_id,
            parent_filters=body.parent_filters,
            limit=cap + 1,
            user_ctx=user,  # Phase 131 deep-dive #13: RLS on LOV
        )
        truncated = len(values) > cap
        values = values[:cap]
        out = {"column_id": body.column_id, "values": values, "count": len(values),
               "truncated": truncated, "limit": cap, "source": "data"}
        if _note:
            out["source_note"] = _note
        if body.include_range:
            out.update(await column_value_range(
                engine, dataset_id=dataset_id, column_id=body.column_id,
                parent_filters=body.parent_filters, values=values,
                truncated=truncated, user=user))
        return out
    except SourceUnavailableError as exc:
        # FB-39: the source could not be reached -- 503 + Retry-After.
        raise source_unavailable_503(exc) from None
    except ValueError as exc:
        # The source's own verdict / an engine refusal: actionable and
        # already sanitised.  As a 500 it was replaced by "contact support"
        # and the filter's value list just looked empty.
        logger.warning("Column values refused (dataset %d col %s): %s",
                       dataset_id, body.column_id, exc)
        raise HTTPException(status_code=refusal_status(exc, 422), detail=str(exc))
    except Exception as exc:
        logger.error("Column values failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get values: {exc}")


# ── Execution History ─────────────────────────────────────────────────────────

def _check_dataset_access(dataset_id: int, user: dict) -> None:
    """Verify user can access a dataset (published or owner/group/admin —
    2026-08-09 self-service, same rule as execute/preview)."""
    ds = _require_db().get_dataset(dataset_id)
    if ds and not _ds_can_view(ds, user):
        raise HTTPException(
            status_code=403,
            detail="Not authorized to view this dataset (it is not published "
                   "and you are not its owner)")


def _check_execution_access(fe: dict, user: dict) -> None:
    """Authorize reading a federation EXECUTION (its SQL, and its result rows).

    SECURITY 2026-08-22: the old body was ``if fe.get("dataset_id"):
    _check_dataset_access(...)`` -- two fail-open holes made this a cross-user
    IDOR (the exact class ``_check_async_exec_access`` /
    ``_check_result_access`` in business_reports_api were written to close):

      * a row whose ``dataset_id`` was falsy skipped the check entirely; and
      * ``_check_dataset_access`` is a dataset gate, so ANY viewer of a
        *published* dataset could read ANOTHER user's execution rows.

    An execution belongs to the principal who ran it.  Access = the executor,
    an admin/support, or a user with EDIT authority over the parent dataset
    (owner/admin auditing their own dataset's runs).  A mere viewer of the
    dataset is not enough.  Fail closed on an unknown/absent parent.
    """
    from core.entitlements import is_support
    if is_admin_like(user) or is_support(user):
        return
    username = (user or {}).get("username")
    executed_by = (fe.get("executed_by") or "").strip()
    if executed_by and username and executed_by == username:
        return
    ds_id = fe.get("dataset_id")
    ds = _require_db().get_dataset(ds_id) if ds_id else None
    if ds is not None and _ds_can_edit(ds, user):
        return
    raise HTTPException(
        status_code=403,
        detail="Not authorized for this execution")


@router.get("/api/datasets/{dataset_id}/executions", tags=["federation"])
async def list_dataset_executions(dataset_id: int,
                                   limit: int = FastQuery(50, ge=1, le=200),
                                   user: dict = Depends(require_capability("datasets.view"))):
    """List recent executions for a dataset."""
    await _adb(_ensure_dataset_exists, dataset_id)
    await _adb(_check_dataset_access, dataset_id, user)
    return await _adb(_require_db().list_federation_executions, dataset_id=dataset_id, limit=limit)


@router.get("/api/datasets/executions/{execution_id}", tags=["federation"])
async def get_execution_detail(execution_id: str, user: dict = Depends(require_capability("datasets.view"))):
    """Get execution detail including generated SQL, and the scan verdict.

    2026-09-05.  ``scan_plan`` / ``scan_completeness`` are stamped on the
    execution by ``FederationEngine._note_scan_diagnostic``, and until now
    the only route that read them back was the ADMIN diagnose endpoint.
    The author who declared a partition column and got a whole-query run
    therefore could not learn the reason, though the planner had produced
    a named refusal with a remedy.

    THIS ROUTE, NOT THE LIST ROUTE.  ``GET /api/datasets/{id}/executions``
    is gated by ``_check_dataset_access`` -- any VIEWER of a published
    dataset passes it.  This one is gated by ``_check_execution_access``:
    the principal who ran it, someone with EDIT authority over the parent
    dataset, or an admin/support.  Attaching the diagnostic here rides an
    existing, stricter gate; attaching it to the list would have WIDENED
    who can read a diagnostic, which is not what was asked for.

    Absent stays absent: an execution that stamped nothing gets no key,
    because ``{}`` would say "the planner ran and said nothing" -- a third
    answer distinct from both "nothing was recorded" and "it declined".
    """
    result = await _adb(_require_db().get_federation_execution, execution_id)
    if not result:
        raise HTTPException(status_code=404, detail="Execution not found")
    await _adb(_check_execution_access, result, user)
    # Strictly AFTER the gate, and only ever after one.
    try:
        if isinstance(result, dict):
            from core.reports.scan_verdict import scan_verdict_keys
            result.update(scan_verdict_keys(execution_id))
    except Exception as _scan_exc:                        # noqa: BLE001
        logger.debug("scan verdict surface skipped (fail-open): %s",
                     _scan_exc)
    return result


@router.get("/api/datasets/executions/{execution_id}/results", tags=["federation"])
async def get_execution_results(execution_id: str,
                                 offset: int = FastQuery(0, ge=0),
                                 limit: int = FastQuery(500, ge=1, le=10000),
                                 user: dict = Depends(require_capability("datasets.view"))):
    """Read paginated results from a completed execution's parquet file.

    2026-10-25 -- ONE page is read, through THE artifact page reader the
    report results route uses (``core.reports.pagination.read_artifact_page``:
    DuckDB does the count and the LIMIT / OFFSET, Python receives the page's
    rows).  Until then this route ``pd.read_parquet``-ed the WHOLE result into
    a DataFrame on EVERY page request and sliced it in pandas -- a 2M-row
    result paged 500 rows at a time materialised 2M rows per click, once per
    user, on the API pod (measured in
    tests/test_api_hot_routes_off_the_loop_2026_10_25.py: the whole-file
    read gone, rows identical, total exact).
    """
    fe = await _adb(_require_db().get_federation_execution, execution_id)
    if not fe:
        raise HTTPException(status_code=404, detail="Execution not found")
    await _adb(_check_execution_access, fe, user)
    if fe.get("status") != "completed":
        raise HTTPException(status_code=400, detail=f"Execution status: {fe.get('status')}")
    output_path = fe.get("output_path", "")
    if not output_path or not Path(output_path).exists():
        raise HTTPException(status_code=404, detail="Result file not found")

    from core.reports.pagination import read_artifact_page
    records, columns, total = await asyncio.to_thread(
        read_artifact_page, Path(output_path), offset=offset, limit=limit)
    return {
        "rows": sanitize_for_json(records),
        "total_rows": total,
        "offset": offset,
        "limit": limit,
        "columns": list(columns),
    }


# ── Merged Dimensions CRUD ───────────────────────────────────────────────────

@router.get("/api/datasets/{dataset_id}/merged-dimensions", tags=["federation"])
async def list_merged_dimensions(dataset_id: int, user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    return await _adb(_require_db().list_merged_dimensions, dataset_id=dataset_id)


@router.post("/api/datasets/merged-dimensions", tags=["federation"])
async def create_merged_dimension(body: MergedDimensionCreate,
                                   user: dict = Depends(require_capability("datasets.manage"))):
    if body.primary_dataset_id == body.secondary_dataset_id:
        raise HTTPException(status_code=400, detail="Cannot merge a dataset with itself")
    await _adb(_ensure_dataset_exists, body.primary_dataset_id)
    await _adb(_ensure_dataset_exists, body.secondary_dataset_id)
    try:
        return await _adb(_require_db().create_merged_dimension, primary_dataset_id=body.primary_dataset_id,
            secondary_dataset_id=body.secondary_dataset_id,
            name=body.name, merge_keys=body.merge_keys,
            merge_type=body.merge_type, is_active=body.is_active)
    except Exception as e:
        if is_unique_violation(e):
            raise HTTPException(status_code=409, detail="Merged dimension already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/merged-dimensions/{md_id}", tags=["federation"])
async def update_merged_dimension(md_id: int, body: MergedDimensionUpdate,
                                   user: dict = Depends(require_capability("datasets.manage"))):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_require_db().update_merged_dimension, md_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Merged dimension not found")
    return result


@router.delete("/api/datasets/merged-dimensions/{md_id}", tags=["federation"])
async def delete_merged_dimension(md_id: int, user: dict = Depends(require_capability("datasets.manage"))):
    if not await _adb(_require_db().delete_merged_dimension, md_id):
        raise HTTPException(status_code=404, detail="Merged dimension not found")
    return {"detail": "Merged dimension deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 55 — Aggregation Cache Endpoints
# ═══════════════════════════════════════════════════════════════════════════════

class AggCacheCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    dimension_col_ids: List[int] = Field(default_factory=list)
    measure_col_ids: List[int] = Field(default_factory=list)
    grain_label: str = Field("custom",
                             pattern=r"^(yearly|quarterly|monthly|weekly|daily|custom)$")
    condition_ids: List[int] = Field(default_factory=list)
    schedule_config: Optional[Dict[str, Any]] = None
    is_enabled: bool = True
    incremental_enabled: bool = False
    incremental_column: Optional[str] = None


class AggCacheUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    dimension_col_ids: Optional[List[int]] = None
    measure_col_ids: Optional[List[int]] = None
    grain_label: Optional[str] = Field(
        None, pattern=r"^(yearly|quarterly|monthly|weekly|daily|custom)$")
    condition_ids: Optional[List[int]] = None
    schedule_config: Optional[Dict[str, Any]] = None
    is_enabled: Optional[bool] = None
    incremental_enabled: Optional[bool] = None
    incremental_column: Optional[str] = None


class AggCacheConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    max_storage_mb: Optional[int] = Field(None, ge=100)
    max_entries_per_dataset: Optional[int] = Field(None, ge=1)
    default_ttl_hours: Optional[int] = Field(None, ge=1)
    hard_expiry_hours: Optional[int] = Field(None, ge=1)
    stale_serve_enabled: Optional[bool] = None
    write_through_enabled: Optional[bool] = None
    refresh_timeout_seconds: Optional[int] = Field(None, ge=60)
    cleanup_interval_hours: Optional[int] = Field(None, ge=1)
    suggestion_enabled: Optional[bool] = None
    suggestion_min_queries: Optional[int] = Field(None, ge=1)
    suggestion_analysis_window_days: Optional[int] = Field(None, ge=1)
    # Phase 6/7 (2026-08-09) — both feature flags ship OFF.
    recommendation_history_limit: Optional[int] = Field(None, ge=50)
    auto_adopt_enabled: Optional[bool] = None
    auto_adopt_max_per_run: Optional[int] = Field(None, ge=1)
    agg_awareness_serving_enabled: Optional[bool] = None
    agg_awareness_reverify_hours: Optional[int] = Field(None, ge=1)


# ── Agg Cache CRUD (per dataset) ─────────────────────────────────────────────

@router.get("/api/datasets/{dataset_id}/agg-cache", tags=["agg-cache"])
async def list_agg_cache_entries(dataset_id: int,
                                  user: dict = Depends(require_capability("datasets.view"))):
    await _adb(_require_dataset_view, dataset_id, user)  # SECURITY 2026-08-17: was an existence probe only
    entries = await _adb(_require_db().list_agg_cache_entries, dataset_id=dataset_id)
    return {"entries": entries, "total": len(entries)}


@router.post("/api/datasets/{dataset_id}/agg-cache", tags=["agg-cache"])
async def create_agg_cache_entry(dataset_id: int, body: AggCacheCreate,
                                  user: dict = Depends(require_capability("datasets.manage"))):
    from core import config
    db = _require_db()
    await _adb(_ensure_dataset_exists, dataset_id)

    # Validate quota
    existing = await _adb(db.list_agg_cache_entries, dataset_id=dataset_id)
    if len(existing) >= config.agg_cache.max_entries_per_dataset:
        raise HTTPException(
            status_code=400,
            detail=f"Max {config.agg_cache.max_entries_per_dataset} cache entries per dataset")

    # Validate column IDs belong to dataset
    all_cols = await _adb(db.list_dataset_columns, dataset_id)
    valid_ids = {c["id"] for c in all_cols}
    for cid in body.dimension_col_ids + body.measure_col_ids:
        if cid not in valid_ids:
            raise HTTPException(status_code=400,
                                detail=f"Column {cid} not found in dataset")

    try:
        entry = await _adb(db.create_agg_cache_entry, 
            dataset_id=dataset_id,
            name=body.name,
            description=body.description,
            dimension_col_ids=body.dimension_col_ids,
            measure_col_ids=body.measure_col_ids,
            grain_label=body.grain_label,
            condition_ids=body.condition_ids,
            schedule_config=body.schedule_config,
            is_enabled=body.is_enabled,
            incremental_enabled=body.incremental_enabled,
            incremental_column=body.incremental_column,
            created_by=user.get("username", "admin"),
        )
    except Exception as exc:
        if is_unique_violation(exc):
            raise HTTPException(status_code=409,
                                detail="Cache entry with this name already exists")
        raise HTTPException(status_code=500, detail="Failed to create cache entry")

    # Register schedule if provided
    if body.schedule_config:
        try:
            from core.agg_cache import register_cache_entry_schedule
            from core.scheduler import _scheduler
            if _scheduler:
                register_cache_entry_schedule(_scheduler, entry["id"])
        except Exception as e:
            logger.warning("Failed to schedule cache entry %d for dataset %d: %s", entry["id"], dataset_id, e)

    logger.info("Agg cache entry %d created for dataset %d by %s",
                entry["id"], dataset_id, user.get("username"))
    return entry


@router.get("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def get_agg_cache_entry(entry_id: int,
                               user: dict = Depends(require_capability("datasets.view"))):
    entry = await _adb(_require_db().get_agg_cache_entry, entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")
    # SECURITY 2026-08-17: the entry carries its dataset_id -- gate on the
    # OWNING dataset, or this route reads the cube definition (dimension and
    # measure columns) of a dataset the caller may not see.
    await _adb(_require_dataset_view, entry["dataset_id"], user)
    return entry


@router.put("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def update_agg_cache_entry(entry_id: int, body: AggCacheUpdate,
                                  user: dict = Depends(require_capability("datasets.manage"))):
    db = _require_db()
    existing = await _adb(db.get_agg_cache_entry, entry_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Validate column IDs if changed
    ds_id = existing["dataset_id"]
    if "dimension_col_ids" in updates or "measure_col_ids" in updates:
        all_cols = await _adb(db.list_dataset_columns, ds_id)
        valid_ids = {c["id"] for c in all_cols}
        for cid in (updates.get("dimension_col_ids") or []) + (updates.get("measure_col_ids") or []):
            if cid not in valid_ids:
                raise HTTPException(status_code=400,
                                    detail=f"Column {cid} not found in dataset")
        # Invalidate current cache when columns change
        updates["status"] = "pending"
        updates["file_path"] = None
        updates["file_size_bytes"] = 0
        updates["row_count"] = 0

    result = await _adb(db.update_agg_cache_entry, entry_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    # Update schedule if changed
    if "schedule_config" in updates:
        try:
            from core.agg_cache import register_cache_entry_schedule, unregister_cache_entry_schedule
            from core.scheduler import _scheduler
            if _scheduler:
                if updates["schedule_config"]:
                    register_cache_entry_schedule(_scheduler, entry_id)
                else:
                    unregister_cache_entry_schedule(_scheduler, entry_id)
        except Exception as e:
            logger.warning("Failed to update scheduler for cache entry %d: %s", entry_id, e)

    logger.info("Agg cache entry %d updated by %s", entry_id, user.get("username"))
    return result


@router.delete("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def delete_agg_cache_entry(entry_id: int,
                                  user: dict = Depends(require_capability("datasets.manage"))):
    db = _require_db()
    entry = await _adb(db.get_agg_cache_entry, entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    # Remove parquet file
    fp = entry.get("file_path")
    if fp:
        import os
        if os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError:
                pass

    # Unregister schedule
    try:
        from core.agg_cache import unregister_cache_entry_schedule
        from core.scheduler import _scheduler
        if _scheduler:
            unregister_cache_entry_schedule(_scheduler, entry_id)
    except Exception:
        pass

    await _adb(db.delete_agg_cache_entry, entry_id)
    logger.info("Agg cache entry %d deleted by %s", entry_id, user.get("username"))
    return {"detail": "Cache entry deleted"}


@router.post("/api/datasets/agg-cache/{entry_id}/build", tags=["agg-cache"])
async def trigger_agg_cache_build(entry_id: int,
                                   user: dict = Depends(require_capability("datasets.manage"))):
    entry = await _adb(_require_db().get_agg_cache_entry, entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    import asyncio
    from core.agg_cache import build_cache_entry
    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, build_cache_entry, entry_id, True)

    return {"detail": f"Build triggered for cache entry {entry_id}",
            "entry_id": entry_id}


# ── Agg Cache Stats ──────────────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/stats", tags=["agg-cache"])
async def get_agg_cache_stats(user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import get_cache_stats
    return get_cache_stats()


@router.get("/api/admin/agg-cache/stats/{dataset_id}", tags=["agg-cache"])
async def get_agg_cache_dataset_stats(dataset_id: int,
                                       user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import get_cache_stats
    return get_cache_stats(dataset_id=dataset_id)


# ── Agg Cache Suggestions ────────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/suggestions", tags=["agg-cache"])
async def list_agg_cache_suggestions(user: dict = Depends(require_capability("brain.manage"))):
    suggestions = await _adb(_require_db().list_agg_cache_suggestions)
    return {"suggestions": suggestions, "total": len(suggestions)}


@router.post("/api/admin/agg-cache/analyze", tags=["agg-cache"])
async def trigger_usage_analysis(user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import analyze_usage_patterns
    new_suggestions = analyze_usage_patterns()
    return {"detail": f"Analysis complete: {len(new_suggestions)} new suggestions",
            "suggestions": new_suggestions}


@router.post("/api/admin/agg-cache/suggestions/{suggestion_id}/approve",
             tags=["agg-cache"])
async def approve_agg_cache_suggestion(suggestion_id: int,
                                        user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import approve_suggestion
    entry = approve_suggestion(suggestion_id,
                               created_by=user.get("username", "admin"))
    if not entry:
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion approved and cache entry created", "entry": entry}


@router.post("/api/admin/agg-cache/suggestions/{suggestion_id}/reject",
             tags=["agg-cache"])
async def reject_agg_cache_suggestion(suggestion_id: int,
                                       user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import reject_suggestion
    result = reject_suggestion(suggestion_id,
                               reviewed_by=user.get("username", "admin"))
    if not result:
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion rejected"}


@router.delete("/api/admin/agg-cache/suggestions/{suggestion_id}",
               tags=["agg-cache"])
async def delete_agg_cache_suggestion(suggestion_id: int,
                                       user: dict = Depends(require_capability("brain.manage"))):
    if not await _adb(_require_db().delete_agg_cache_suggestion, suggestion_id):
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion deleted"}


# ── Agg Cache Recommendations (Phase 6, 2026-08-09) ──────────────────────────
# The adoption surface: benefit-RANKED recommendations derived from real
# FederationExecution history, each carrying the suggestion_id that makes it
# acceptable in ONE call (POST .../suggestions/{id}/approve), plus the
# hit-rate stats that show whether adopted cubes are earning their keep.

@router.get("/api/admin/agg-cache/recommendations", tags=["agg-cache"])
async def get_agg_cache_recommendations(dataset_id: Optional[int] = None,
                                        user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import get_cube_recommendations
    return await _adb(get_cube_recommendations, dataset_id)


@router.post("/api/admin/agg-cache/adopt", tags=["agg-cache"])
async def adopt_agg_cache_recommendations(max_new: int = 3,
                                          user: dict = Depends(require_capability("brain.manage"))):
    """Accept the top-N ranked recommendations in one explicit admin
    action (entry created + build triggered per accepted suggestion).
    Distinct from the `agg_cache.auto_adopt_enabled` flag, which gates only
    the UNATTENDED scheduled adoption and ships OFF."""
    from core.agg_cache import auto_adopt_recommendations
    if max_new < 1 or max_new > 20:
        raise HTTPException(status_code=400, detail="max_new must be 1-20")
    adopted = await _adb(auto_adopt_recommendations, max_new,
                         user.get("username", "admin"))
    logger.info("Agg cache adopt: %d entries created by %s",
                len(adopted), user.get("username"))
    return {"detail": f"Adopted {len(adopted)} recommendation(s)",
            "entries": adopted}


# ── Agg Cache Config (admin) ─────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/config", tags=["agg-cache"])
async def get_agg_cache_config(user: dict = Depends(require_capability("brain.manage"))):
    from core import config
    return {
        "enabled": config.agg_cache.enabled,
        "storage_dir": config.agg_cache.storage_dir,
        "max_storage_mb": config.agg_cache.max_storage_mb,
        "max_entries_per_dataset": config.agg_cache.max_entries_per_dataset,
        "default_ttl_hours": config.agg_cache.default_ttl_hours,
        "hard_expiry_hours": config.agg_cache.hard_expiry_hours,
        "stale_serve_enabled": config.agg_cache.stale_serve_enabled,
        "write_through_enabled": config.agg_cache.write_through_enabled,
        "refresh_timeout_seconds": config.agg_cache.refresh_timeout_seconds,
        "suggestion_enabled": config.agg_cache.suggestion_enabled,
        "suggestion_min_queries": config.agg_cache.suggestion_min_queries,
        "suggestion_analysis_window_days": config.agg_cache.suggestion_analysis_window_days,
        # Phase 6/7 (2026-08-09) — read via config.get (typed accessors are
        # owned by core/config.py; defaults here are the shipped OFF/safe
        # values either way).
        "recommendation_history_limit": int(config.get(
            "agg_cache", "recommendation_history_limit", 2000)),
        "auto_adopt_enabled": bool(config.get(
            "agg_cache", "auto_adopt_enabled", False)),
        "auto_adopt_max_per_run": int(config.get(
            "agg_cache", "auto_adopt_max_per_run", 3)),
        "agg_awareness_serving_enabled": bool(config.get(
            "agg_cache", "agg_awareness_serving_enabled", False)),
        "agg_awareness_reverify_hours": int(config.get(
            "agg_cache", "agg_awareness_reverify_hours", 24)),
    }


@router.put("/api/admin/agg-cache/config", tags=["agg-cache"])
async def update_agg_cache_config(body: AggCacheConfigUpdate,
                                   user: dict = Depends(require_capability("brain.manage"))):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("agg_cache", k, v)
    logger.info("Agg cache config updated by %s: %s",
                user.get("username"), list(updates.keys()))
    return await get_agg_cache_config(user=user)


# ── Agg Cache Maintenance (admin) ────────────────────────────────────────────

@router.post("/api/admin/agg-cache/cleanup", tags=["agg-cache"])
async def trigger_agg_cache_cleanup(user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import cleanup_expired, enforce_storage_quota
    expired = cleanup_expired()
    evicted = enforce_storage_quota()
    return {"detail": f"Cleanup complete: {expired} expired, {evicted} evicted"}


@router.post("/api/admin/agg-cache/invalidate/{dataset_id}", tags=["agg-cache"])
async def invalidate_dataset_agg_cache(dataset_id: int,
                                        user: dict = Depends(require_capability("brain.manage"))):
    from core.agg_cache import invalidate_by_dataset
    count = invalidate_by_dataset(dataset_id)
    return {"detail": f"Invalidated {count} cache entries for dataset {dataset_id}"}


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 85E — Dataset Preview & Schema Inference
# ═══════════════════════════════════════════════════════════════════════════════

class DatasetPreviewRequest(BaseModel):
    """Phase 85E-1: Request body for the /api/datasets/preview endpoint."""
    connection_id: int
    table_name: Optional[str] = None
    sql: Optional[str] = None
    columns: Optional[List[str]] = None   # None → SELECT *
    limit: int = Field(default=10, ge=1, le=500)


# Storage connections whose SQL QueryStudio runs on its own DuckDB engine.
_STORAGE_SQL_TYPES = {"s3", "s3_minio", "s3_compatible"}


class _PreviewNeedsNoSql(Exception):
    """The preview cannot be answered by running SQL, so it must be answered
    from what is already known rather than refused.  Carries the connection
    type so the caller can name it, and -- when SQL WAS run on a storage
    connection and failed (2026-10-02) -- the run's ``reason``, so the
    answer says why the rows are absent.  ``reason`` None means the
    connection was never asked."""

    def __init__(self, conn_type: str, reason: Optional[str] = None):
        super().__init__(conn_type)
        self.conn_type = conn_type
        self.reason = reason


def _table_preview_statement(conn: Dict[str, Any], table_name: str,
                             columns: Optional[List[str]]) -> str:
    """``SELECT <cols> FROM <address>`` for a registered table, rendered the
    way the federation engine renders the same table: the address through
    ``resolve_table_address`` (so Oracle's pseudo-catalog is dropped and an
    unrenderable name is REFUSED with its reason), each part through the
    engine's identifier renderer, then the whole statement through the ONE
    transpile gate.  No row cap here -- that is the connector's.

    Until 2026-09-15 this was ``SELECT * FROM "{table}" LIMIT n``: ONE
    quoted identifier containing dots (the 2026-09-04 report defect, in a
    second place) plus a LIMIT Oracle has never had (ORA-00933).  The
    wizard's Preview step never returned a row for any Oracle table.
    """
    from core.connection_manager import resolve_table_address
    from core.federation_engine import FederationEngine
    from core.sql_connector_dialect import transpile_for_connector

    conn_type = conn.get("connection_type") or ""
    cfg = conn.get("config") or {}
    catalog, schema, table = resolve_table_address(
        table_name, conn_type,
        default_catalog=cfg.get("catalog", "") or "",
        default_schema=cfg.get("schema", "") or "")
    if not table:
        raise ValueError(f"Cannot determine a table name from {table_name!r}")
    address = ".".join(FederationEngine._quote_ident(p)
                       for p in (catalog, schema, table) if p)
    col_part = "*"
    if columns:
        col_part = ", ".join(FederationEngine._quote_ident(c) for c in columns)
    return transpile_for_connector(
        f"SELECT {col_part} FROM {address}", conn_type,
        context="datasets/preview")


def _secure_preview_sql(sql: str, conn_type: Optional[str], connection_id: int,
                        user_ctx: Optional[Dict[str, Any]]) -> str:
    """Row security on a preview statement -- THE chokepoint the SQL editor
    uses (``core.row_security.secure_sql``), in the connection's own dialect.

    2026-10-02, found on the login-ON rig: ``POST /api/datasets/preview`` ran
    the author's SQL with NO row security -- an analyst bound to
    ``region = 'EUROPE'`` saw all five regions through the dataset wizard
    while the query builder showed EUROPE only.  A rewrite that cannot
    complete REFUSES (403); it never degrades to the unfiltered statement.
    ``user_ctx`` None is the internal column-detection road, which returns
    no rows to anyone."""
    if user_ctx is None:
        return sql
    from core.row_security import secure_sql
    from core.sql_filter_wrapper import dialect_for_connection_type
    try:
        return secure_sql(sql, dialect=dialect_for_connection_type(conn_type),
                          user_ctx=user_ctx, connection_id=int(connection_id))
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=403,
                            detail=f"Row-security policy enforcement failed: {exc}")


def _run_preview_sql(db, connection_id: int, sql: Optional[str] = None, *,
                     table_name: Optional[str] = None,
                     columns: Optional[List[str]] = None,
                     limit: Optional[int] = None,
                     user_ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Execute a read-only SELECT against a connection and return its rows.

    2026-09-15 -- THREE things changed, all for Oracle, none Oracle-specific:

    * The row cap is passed to ``connector.execute_query(sql, limit=...)``
      and rendered by the CONNECTOR -- ``_apply_limit`` (LIMIT) on the ANSI
      engines, the ROWNUM wrap on Oracle, both already detecting a window
      the statement carries.  Callers used to append ``LIMIT n`` themselves,
      which is a second row-capping vocabulary and ORA-00933 on Oracle.
    * ``sql`` is the author's statement, in the source's own dialect, sent
      as written (a trailing ``;`` stripped).  It is NOT wrapped in
      ``SELECT * FROM (...) __preview__``: the alias was ORA-00911 and the
      wrap added nothing the connector's cap does not do.
    * ``table_name`` builds its statement through
      :func:`_table_preview_statement` -- the federation engine's address
      resolution and the one transpile gate -- instead of quoting the
      dotted name as a single identifier.

    A failure the SOURCE reports (a driver error) is re-raised as
    ``SourceStatementError`` -- a ValueError carrying the engine's sanitised
    text -- so the routes answer 422 with the ORA/Trino line rather than a
    500 the app replaces with "contact support".

    2026-08-25 -- replaces ``ConnectionManager.execute_query``, a method that has
    never existed. The old call raised AttributeError on every request, which
    the caller re-raised as a 500 carrying the Python error text, so
    ``POST /api/datasets/preview`` had never returned a row for any connection
    of any type. The dataset wizard's Preview step and its Custom-SQL column
    detection both depended on it, which is why a dataset built from SQL always
    came out with zero columns.

    2026-08-25 — replaces ``ConnectionManager.execute_query``, a method that has
    never existed. The old call raised AttributeError on every request, which
    the caller re-raised as a 500 carrying the Python error text, so
    ``POST /api/datasets/preview`` had never returned a row for any connection
    of any type. The dataset wizard's Preview step and its Custom-SQL column
    detection both depended on it, which is why a dataset built from SQL always
    came out with zero columns.

    Uses the same construction every other caller uses for "run SQL against a
    connection" (connections_api.py:868): resolve the connection with decrypted
    credentials, build the connector for its type, execute, always close.

    ``SqlConnector.execute_query`` already returns
    ``{"columns": [...], "rows": [...], "total_rows": n}`` — the shape this
    endpoint documents — so the result is passed through unreshaped.

    Non-SQL connections (s3 / local parquet) raise a 422 that names the reason.
    They were never previewable through this path; the change is that the
    refusal is now actionable instead of an internal error.
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES

    conn = db.get_connection_raw(int(connection_id))
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")

    conn_type = conn.get("connection_type")
    if sql is not None and str(conn_type or "").lower() in _STORAGE_SQL_TYPES:
        # 2026-10-02 -- a storage connection's SQL RUNS: QueryStudio's own
        # DuckDB engine executes it, with the connection's registered tables
        # bound as views -- the road every custom-SQL dataset over this
        # connection takes at report time (FederationEngine.preview_storage_sql).
        # Answering from the SQL's text alone made ``SELECT * FROM t``
        # unpreviewable and refused the dataset the query builder had just run.
        # When the run FAILS (no credentials on this pod, a table that is not
        # registered) the 2026-09-01 answer still applies -- the columns the
        # statement states, rows absent -- but now the response says WHY the
        # rows are absent, in the source's words, instead of "storage cannot
        # run SQL".
        from core.federation_engine import FederationEngine
        from core.connectors.base import wrap_source_failure
        # Row security FIRST, outside the try: a refusal is a 403, never the
        # "answer from the SQL's text" fallback below.
        sql = _secure_preview_sql(str(sql).strip().rstrip(";"), conn_type,
                                  connection_id, user_ctx)
        try:
            return FederationEngine(db).preview_storage_sql(
                str(sql), int(connection_id), limit=int(limit or 10))
        except HTTPException:
            raise
        except Exception as exc:
            reason = exc if isinstance(exc, ValueError) else wrap_source_failure(
                exc, conn_type,
                subject="The preview statement run on the {conn_type} "
                        "connection")
            logger.info("Dataset preview: running the SQL on %s connection %s "
                        "failed, answering from its text: %s",
                        conn_type, connection_id, reason)
            raise _PreviewNeedsNoSql(conn_type, reason=str(reason)) from exc
    if conn_type not in SQL_CONNECTOR_TYPES:
        # 2026-09-01 — this used to REFUSE, which broke dataset creation from
        # an S3 connection outright: the SQL preview, the 10-row preview and
        # COLUMN detection all route through here, so all three failed with
        # "point it at a SQL connection" — for a connection type the product
        # reads perfectly well everywhere else.
        #
        # The refusal was unnecessary for the case that matters most.  Column
        # detection does not need the source AT ALL: a registered table
        # already has its schema stored, and a SQL statement states its own
        # output columns.  Answer with the COLUMNS and no rows, and say
        # plainly that the rows are absent rather than failing the request.
        raise _PreviewNeedsNoSql(conn_type)

    if sql is None:
        if not table_name:
            raise ValueError("Provide either sql or table_name")
        sql = _table_preview_statement(conn, table_name, columns)
    else:
        sql = str(sql).strip().rstrip(";")
    sql = _secure_preview_sql(sql, conn_type, connection_id, user_ctx)

    from core.connectors.base import wrap_source_failure
    connector = get_connector(conn_type, conn.get("config") or {})
    try:
        try:
            if limit is None:
                return connector.execute_query(sql)
            return connector.execute_query(sql, limit=int(limit))
        except (ValueError, HTTPException):
            raise
        except Exception as exc:
            raise wrap_source_failure(
                exc, conn_type,
                subject="The preview statement sent to the {conn_type} "
                        "source") from exc
    finally:
        try:
            connector.close()
        except Exception:
            pass          # a failed close must not mask a successful preview


@router.post("/api/datasets/preview", tags=["semantic-layer"])
async def preview_dataset_source(
    body: DatasetPreviewRequest,
    # 2026-10-02 -- the dataset AUTHORING roles, as create_dataset.  It was
    # get_current_user: a VIEWER, whom the SQL editor refuses, could run
    # arbitrary SQL on any shared connection through this route.
    user: dict = Depends(require_capability("datasets.create")),
):
    """Phase 85E-1: Execute a quick SELECT against a connection and return
    the first N rows + column names.  Used by the Dataset Creation Wizard
    to show a live data preview before committing.

    Accepts either:
      • table_name — SELECT {cols} FROM <address>, the address resolved and
        rendered exactly as the federation engine renders that table, then
        transpiled to the connection's dialect;
      • sql        — the author's statement, sent as written.

    In both cases the row cap (``limit``) is applied by the CONNECTOR in its
    own grammar -- there is no LIMIT in the text this route builds.  Until
    2026-09-15 it built ``SELECT * FROM (...) __preview__ LIMIT n`` and
    ``SELECT * FROM "{table}" LIMIT n``: dead on Oracle (ORA-00911 /
    ORA-00933, and a dotted name quoted as ONE identifier), which killed the
    wizard's Preview step and its SQL-mode column detection for every
    Oracle input.

    Returns: { "columns": [...], "rows": [{...}, ...] }
    """
    db = _require_db()

    # 2026-08-09 leak gate: this endpoint EXECUTES SQL against the target
    # connection — it must honour the same connection entitlement rule as
    # every other dataset route (fail-closed).
    _assert_connection_entitlement(user, [body.connection_id])

    # ── Validate SQL safety: reject obvious multi-statement injections ────────
    if body.sql:
        # Reject anything containing a semicolon that terminates a statement
        # (legitimate SQL may contain ; in string literals, but we keep it simple)
        stripped = body.sql.strip().rstrip(';')
        if ';' in stripped:
            raise HTTPException(
                status_code=422,
                detail="SQL must be a single statement. Semicolons inside the query are not allowed."
            )

    if not body.table_name and not body.sql:
        raise HTTPException(status_code=422, detail="Provide either table_name or sql")

    # ── Execute against the connection ────────────────────────────────────────
    # The statement is built INSIDE the runner, which knows the connection's
    # dialect; the cap is the connector's.  See _run_preview_sql.
    safe_sql = body.sql.strip().rstrip(';') if body.sql else None
    try:
        import asyncio
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            lambda: _run_preview_sql(
                db, body.connection_id, safe_sql,
                table_name=body.table_name, columns=body.columns,
                limit=body.limit, user_ctx=user),
        )
    except _PreviewNeedsNoSql as need:
        # 2026-09-01 — the connection cannot run SQL (s3 / local parquet).
        # Answer with the COLUMNS, which need no source access at all, and
        # disclose that the sample rows are missing.  Refusing outright
        # broke dataset creation from S3 entirely: this one endpoint backs
        # the SQL preview, the row preview AND the wizard's column
        # detection.
        columns, how = [], ""
        if body.sql:
            # A statement states its own output columns — the same offline
            # parser dataset column detection uses (sqlglot, no execution).
            columns = [c["physical_name"]
                       for c in _derive_columns_from_sql_text(body.sql)]
            how = "parsed from the SQL"
        elif body.table_name:
            # A registered table already has its schema STORED — serve that.
            # The lookup falls through its cache layers to a live read on a
            # miss, and that read needs credentials this pod may not have;
            # the exception used to escape as a 500 "NoCredentialsError",
            # which tells the author nothing they can act on.  A cache miss
            # is a known state, not a crash.
            prov = {}
            try:
                prov = await _columns_with_provenance(
                    db, body.connection_id, body.table_name,
                    username=(user or {}).get("username", ""))
            except Exception as prov_exc:
                logger.info("Dataset preview: no cached columns for %r on "
                            "connection %s and the live read failed: %s",
                            body.table_name, body.connection_id, prov_exc)
            columns = [c.get("name") or c.get("physical_name")
                       for c in (prov.get("columns") or [])]
            columns = [c for c in columns if c]
            how = f"from the stored catalog ({prov.get('source') or 'cache'})"
        if not columns and need.reason:
            raise HTTPException(
                status_code=422,
                detail=(f"The statement could not be run on the "
                        f"'{need.conn_type}' connection ({need.reason}), and "
                        f"its columns cannot be read from its text (SELECT *). "
                        f"Fix the statement, or name the columns explicitly "
                        f"to define the dataset without a sample."))
        if not columns:
            raise HTTPException(
                status_code=422,
                detail=(f"A '{need.conn_type}' connection cannot run SQL, and "
                        f"the columns are not in the catalog either — nothing "
                        f"is cached for this source yet. Refresh the column "
                        f"catalog for the table (POST /api/catalog/columns/"
                        f"refresh), or, for SQL, name the columns explicitly "
                        f"instead of SELECT *."))
        logger.info("Dataset preview: conn=%s answered with %d column(s) %s, "
                    "no sample rows (%s cannot run SQL)",
                    body.connection_id, len(columns), how, need.conn_type)
        return {
            "columns": columns,
            "rows": [],
            "row_count": 0,
            "rows_unavailable": (
                f"Sample rows could not be read from the '{need.conn_type}' "
                f"storage connection: {need.reason}. The columns above are "
                f"{how} and are what the dataset will use."
                if need.reason else
                f"Sample rows need a SQL engine; a '{need.conn_type}' "
                f"connection is storage. The columns above are {how} and are "
                f"what the dataset will use."),
        }
    except HTTPException:
        raise
    except SourceUnavailableError as e:
        # FB-39: the source could not be reached -- 503 + Retry-After.
        raise source_unavailable_503(e) from None
    except ValueError as e:
        # The source's verdict (SourceStatementError), an unrenderable table
        # name (TableAddressNotRenderable) or a transpile refusal: each names
        # what the author must change, and each is already scrubbed of
        # credentials and paths.  A 500 here is replaced by the app's 5xx
        # chokepoint with "contact support" -- a preview that cannot run
        # must say why.
        logger.warning("Dataset preview refused (conn=%s): %s",
                       body.connection_id, e)
        raise HTTPException(status_code=refusal_status(e, 422), detail=str(e))
    except Exception as e:
        # 2026-09-15 — the ValueError branch above states the rule ("a preview
        # that cannot run must say why") and this branch still broke it: the
        # 5xx chokepoint replaced this explain_failure text with "contact
        # support", so the half of previews that fail by any OTHER exception
        # said nothing.  ``explain_failure`` is the sanitising renderer, so the
        # message is safe to return; answer with the same 422 the sibling
        # branch uses and keep the full traceback in the log for real bugs.
        from core.error_sanitizer import explain_failure
        logger.error("Dataset preview failed (conn=%s): %s",
                     body.connection_id, e, exc_info=True)
        raise HTTPException(
            status_code=422,
            detail=explain_failure(e, subject="Preview execution"))

    # ── Normalise result ──────────────────────────────────────────────────────
    if isinstance(result, dict):
        columns = result.get("columns", [])
        rows = result.get("rows", [])
    elif hasattr(result, "columns") and hasattr(result, "rows"):
        columns = list(result.columns)
        rows = [dict(zip(result.columns, r)) for r in result.rows]
    else:
        rows = list(result) if result else []
        columns = list(rows[0].keys()) if rows else []

    # 2026-09-01 -- ONE SHAPE OUT OF ONE ENDPOINT.
    #
    # A SQL connector's execute_query returns ``columns`` as
    # ``[{"name","type"}]`` and this route passed it straight through, while
    # the no-SQL branch above (and every caller in the wizard) uses plain
    # names: ``res.columns.map((col: string) => ({name: col}))``.  So with a
    # Starburst / Trino / Snowflake / Oracle connection the wizard bound an
    # OBJECT where the column name goes -- which is the "error at columns"
    # this route produces for exactly those sources, and never for parquet.
    #
    # Names are what the contract has always been, so names are what it
    # returns.  The driver's types are not thrown away: they go in a
    # separate field, which is additive and cannot break a caller that does
    # not know about it.
    columns, driver_types = _column_names_and_types(columns)

    logger.info("Dataset preview: conn=%s rows=%d cols=%d by %s",
                body.connection_id, len(rows), len(columns),
                user.get("username"))
    return {"columns": columns, "rows": rows,
            "column_types": driver_types}


@router.get("/api/datasets/connections/{connection_id}/schema/{table_name:path}",
            tags=["semantic-layer"])
async def get_dataset_table_schema(
    connection_id: int,
    table_name: str,
    user: dict = Depends(require_capability("datasets.view")),
):
    """Phase 85E-2: Return inferred schema (column name + classified data type)
    for a specific table/file in a connection.

    The response includes a "classified" list of columns with:
      physical_name, friendly_name, column_type, data_type, aggregation, is_hidden

    If a schema endpoint for registered tables already provides this information,
    this endpoint serves as a semantic-layer-aware alternative that uses the same
    classification heuristics as auto-detect (85D: see _classify_column).
    """
    db = _require_db()
    # 2026-08-09 leak gate: schema inspection is limited to connections the
    # caller is entitled to (fail-closed).
    _assert_connection_entitlement(user, [connection_id])
    # 2026-08-23: a connection that DOES NOT EXIST is not a connection with
    # no columns.  The catalog seam below answers the honest empty for a real
    # connection whose columns are unknown; letting a bogus id take that path
    # reports absence-of-the-resource as absence-of-data, which is exactly
    # the unknown-vs-empty conflation the catalog was built to remove.
    if not await _adb(db.get_connection, connection_id):
        raise HTTPException(status_code=404,
                            detail=f"Connection {connection_id} not found")
    # 2026-08-22: through the catalog-contract seam — failure is an honest
    # source:"none" + reason + refresh action, not a bare 500.
    prov = await _columns_with_provenance(
        db, connection_id, table_name,
        username=(user or {}).get("username", ""))
    if prov["source"] == "none" or not prov["columns"]:
        return {
            "table_name": table_name,
            "connection_id": connection_id,
            "columns": [],
            "raw_columns": [],
            "source": "none",
            "message": prov["message"] or "No columns available for this table.",
            "refresh": prov["refresh"],
        }
    raw_cols = prov["columns"]
    classified = _classify_schema_columns(prov["schema_info"])

    logger.info("Dataset table schema: conn=%s table=%s cols=%d by %s",
                connection_id, table_name, len(classified), user.get("username"))
    return {
        "table_name": table_name,
        "connection_id": connection_id,
        "columns": classified,
        "raw_columns": raw_cols,
        "source": prov["source"],
        "last_refreshed_at": prov["last_refreshed_at"],
        "stale": prov["stale"],
        "message": prov["message"],
        "refresh": prov["refresh"],
    }


# ── Phase 130: Business Query Builder — Column Auto-Map ─────────────────────

class AutoMapRequest(BaseModel):
    """Request body for the auto-map columns endpoint."""
    connection_id: int
    table_paths: List[str] = Field(..., min_length=1)
    include_partitions: bool = True
    # When true, bypass L1+L2 cache and force a fresh live S3 read.
    # Matches the ``?refresh=true`` knob the CQB ``schema/refresh``
    # endpoint already exposes — BQB users can now invoke the same
    # refresh path without leaving the page.  Stale-while-revalidate:
    # if the live read fails (S3 503, etc) the previous cached entry
    # is returned with a warning rather than crashing the request.
    refresh: bool = False


class ColumnOverrideRequest(BaseModel):
    """Save a user correction to a column's friendly name."""
    physical_name: str = Field(..., min_length=1)
    friendly_name: str = Field(..., min_length=1)
    category: Optional[str] = None


@router.post("/api/columns/auto-map", tags=["business-query-builder"])
async def auto_map_columns_endpoint(
    body: AutoMapRequest,
    user: dict = Depends(require_capability("datasets.create")),
):
    """Auto-map raw column names to business-friendly names with categories.

    Merges columns from all requested tables, deduplicates by physical name,
    applies pattern-based mapping + known overrides + user corrections.
    """
    db = _require_db()
    # 2026-08-09 leak gate: same connection entitlement rule as the other
    # schema-reading endpoints in this module (fail-closed).
    _assert_connection_entitlement(user, [body.connection_id])
    from core import config as cfg

    # 1. Read schema for each table — _read_connection_schema has L1/L2/L3 cache
    #    Local tables (__local__: or __lt__ prefix) use schema_json from local_tables DB record.
    all_columns: List[Dict[str, Any]] = []
    for table_path in body.table_paths[:cfg.business_query_builder.max_tables_per_query]:
        try:
            if table_path.startswith("__local__:") or table_path.startswith("__lt__"):
                # Local table — read schema from DB record
                lt_name = table_path.replace("__local__:", "").replace("__lt__", "")
                lt_record = await _adb(db.get_local_table_by_name, lt_name)
                if lt_record and lt_record.get("schema_json"):
                    schema_cols = lt_record["schema_json"] if isinstance(lt_record["schema_json"], list) else []
                    for col in schema_cols:
                        col_name = col.get("name", col.get("column_name", ""))
                        col_type = col.get("type", col.get("data_type", ""))
                        if col_name:
                            all_columns.append({
                                "name": col_name,
                                "type": col_type,
                                "is_partition": False,
                                "source_table": table_path,
                            })
                else:
                    logger.warning("auto-map: local table '%s' not found or no schema", lt_name)
            elif table_path.startswith("__materialized__:"):
                # 2026-10-02 -- a materialized view had NO branch here: it fell
                # to the connection schema read, which looked for an S3 prefix
                # named "__materialized__:x" and answered 500, so ticking an MV
                # in the query builder showed "contact support" and no columns.
                # Its columns are the parquet file the query path reads --
                # resolved by THE resolver the query path uses.
                from core.local_parquet_road import resolve_local_ref
                import pyarrow.parquet as _pq
                mv_path, _ = resolve_local_ref(table_path, db, where="auto-map")
                for fld in _pq.read_schema(mv_path):
                    all_columns.append({
                        "name": fld.name,
                        "type": str(fld.type),
                        "is_partition": False,
                        "source_table": table_path,
                    })
            else:
                schema_info = await _read_connection_schema(
                    db, body.connection_id, table_path,
                    username=(user or {}).get("username", ""),
                    refresh=body.refresh,
                )
                partition_cols = {c.lower() for c in (schema_info.get("partition_columns") or [])}
                for col in schema_info.get("columns", []):
                    col_name = col.get("name", col.get("column_name", ""))
                    col_type = col.get("type", col.get("data_type", ""))
                    if col_name:
                        all_columns.append({
                            "name": col_name,
                            "type": col_type,
                            "is_partition": col_name.lower() in partition_cols,
                            "source_table": table_path,
                        })
        except HTTPException as exc:
            logger.warning("auto-map: HTTP error reading schema for %s: %s", table_path, exc.detail)
            # Propagate first table error to user so they know what failed
            if not all_columns:
                raise
        except Exception as exc:
            logger.warning("auto-map: failed to read schema for %s: %s", table_path, exc)
            # Propagate first table error to user so they know what failed
            if not all_columns:
                raise HTTPException(status_code=500, detail=f"Failed to read columns for {table_path}: {exc}")

    # 2. Deduplicate by physical name (keep first occurrence)
    seen: set = set()
    unique_columns: List[Dict[str, Any]] = []
    for col in all_columns:
        key = col["name"].lower()
        if key not in seen:
            seen.add(key)
            unique_columns.append(col)

    # 3. Load user overrides (correction_type="friendly_name") — manual renames saved by users
    overrides: Dict[str, Dict[str, str]] = {}
    try:
        corrections = await _adb(db.get_suggestion_corrections, "friendly_name", limit=2000)
        for c in corrections:
            overrides[c["context_key"]] = {
                "friendly_name": c.get("corrected_value", ""),
                "category": c.get("context_extra", ""),
            }
    except Exception as exc:
        logger.warning("auto-map: failed to load overrides: %s", exc)

    # 4. Build column list — use original physical name as display name.
    #    User-saved overrides (from POST /api/columns/override) are still honoured.
    def _infer_data_type(raw_type: str) -> str:
        # The module-level vocabulary — this used to carry its own copy, which
        # drifted from ``_classify_column``'s (see _NUMBER_TYPE_TOKENS).
        t = _base_type_token(raw_type)
        if _is_numeric_type(raw_type):
            return "number"
        if t in _DATE_TYPE_TOKENS or "timestamp" in t or "date" in t:
            return "date"
        if t in _BOOL_TYPE_TOKENS:
            return "boolean"
        return "string"

    mapped: List[Dict[str, Any]] = []
    for i, col in enumerate(unique_columns):
        phy = col["name"]
        override = overrides.get(phy.lower(), {})
        dt = _infer_data_type(col.get("type", ""))
        mapped.append({
            "physical_name": phy,
            "friendly_name": override.get("friendly_name") or _friendly_name(phy),
            "category": override.get("category") or "All",
            "column_type": "measure" if dt == "number" else "dimension",
            "data_type": dt,
            "aggregation": "sum" if dt == "number" else "count_distinct",
            "is_partition": col.get("is_partition", False),
            "description": "",
            "source_table": col.get("source_table", ""),
            "sort_order": i,
        })

    categories = [{"name": "All", "count": len(mapped), "sort_order": 0}]

    partition_columns = [c["physical_name"] for c in mapped if c.get("is_partition")]

    logger.info("auto-map: conn=%d tables=%d cols=%d→%d categories=%d by=%s",
                body.connection_id, len(body.table_paths), len(all_columns),
                len(mapped), len(categories), user.get("username", "?"))

    return {
        "columns": mapped,
        "categories": categories,
        "partition_columns": partition_columns,
    }


@router.post("/api/columns/override", tags=["business-query-builder"])
async def save_column_override(
    body: ColumnOverrideRequest,
    user: dict = Depends(require_capability("datasets.create")),
):
    """Save a user correction to a column's friendly name.

    Uses the existing SuggestionCorrection model with correction_type='friendly_name'.
    """
    db = _require_db()
    result = await _adb(db.save_suggestion_correction, 
        correction_type="friendly_name",
        context_key=body.physical_name.lower(),
        original_value=body.physical_name,
        corrected_value=body.friendly_name,
        context_extra=body.category or "",
        username=user.get("username", ""),
    )
    logger.info("Column override saved: %s → %s by %s",
                body.physical_name, body.friendly_name, user.get("username", "?"))
    return {"status": "saved", "correction": result}


# ═══════════════════════════════════════════════════════════════════════════════
# 2026-08-31 — PARTITION COLUMNS FOR A DATASET
#
# A report that runs without a predicate on the partition column reads the
# whole table.  Published views already solve this: POST
# /api/published-views/detect-partitions inspects the source and returns
# suggested params with required=true, and the publish dialog turns those into
# mandatory prompts — so a published view cannot be opened without a fixed
# WHERE clause.  Business reports had no equivalent, so the same query behind
# a report scanned everything.
#
# This is the SAME detector, not a second one.  A twin partition detector is
# exactly the divergence that has bitten this codebase repeatedly (four literal
# SQL builders, three literal renderers, two dependency checks): the day
# Iceberg partition detection changes, a copy here would keep answering the old
# way and nobody would notice, because both answers look plausible.
# ═══════════════════════════════════════════════════════════════════════════════

class DatasetPartitions(NamedTuple):
    """What the source says partitions a dataset: the partition column NAMES,
    each one's TABLE and its CONNECTION (lower-cased name -> (the table label
    the detector keyed it under, that table's connection id)), whether
    detection ran, its warnings, and the dataset's first connection."""
    names: List[str]
    tables_by_name: Dict[str, tuple]
    detected: bool
    warnings: List[str]
    connection_id: Optional[int]


def _s3_tables_in_query(conn_id: int, sql: str):
    """The S3 connection's REGISTERED tables a dataset's custom SQL reads, as
    the detector's ``__registered__:<name>`` refs -- ``([], None)`` when the
    connection is not S3.  The detector reads an S3 table's partitions only
    from those refs, so a custom-SQL dataset over ``jq_tetb`` said "detected,
    no partitions" for a table partitioned on three columns (rig 2026-10-24,
    the owner's fact_tetb on AWS S3).  A query that cannot be read, or names
    no registered table, says so (unknown is not "has none")."""
    conn = _db_manager.get_connection_raw(int(conn_id)) if _db_manager else None
    if not conn or str(conn.get("connection_type") or "").lower() != "s3":
        return [], None
    cfg = conn.get("config") or {}
    names = {str(t.get("name") or "").lower(): str(t.get("name"))
             for t in (cfg.get("registered_tables") or []) if isinstance(t, dict) and t.get("name")}
    from core.value_lists import source_tables
    refs = source_tables(sql, str(cfg.get("sql_dialect") or "").strip().lower() or "duckdb")
    if refs is None:
        return [], "The dataset's query could not be read, so its tables' partitions are unknown."
    hits = []
    for r in refs:
        name = names.get(str(r).split(".")[-1].strip('"').lower())
        if name and f"__registered__:{name}" not in hits:
            hits.append(f"__registered__:{name}")
    if not hits:
        return [], "The dataset's query names no table registered on its S3 connection."
    return hits, None


async def dataset_partition_detection(ds: Dict[str, Any], user: dict) -> DatasetPartitions:
    """THE partition detection of a dataset -- the route below (after its
    view gate) and a report parameter's value list (core/reports/
    param_values.py, after the REPORT's view rule: a report's consumer may
    not view its dataset) both read it.  Fail-open: ``detected`` False with
    the reason in ``warnings`` when it could not tell (2026-10-23, split out
    of the route unchanged)."""
    base_query = (ds.get("base_query") or "").strip()
    conn_id = None
    for cid in (ds.get("connection_ids") or []):
        conn_id = int(cid)
        break
    if conn_id is None:
        for st in (ds.get("source_tables") or []):
            if isinstance(st, dict) and st.get("connection_id"):
                conn_id = int(st["connection_id"])
                break

    # The detector speaks query_config.  A dataset's definition is either a
    # snapshotted query (base_query) or registered tables (source_tables);
    # both shapes are what the detector already handles for published views.
    query_config: Dict[str, Any] = {"connection_id": conn_id}
    if base_query:
        query_config["raw_sql"] = base_query
    _files = [st.get("table") for st in (ds.get("source_tables") or [])
              if isinstance(st, dict) and st.get("table")]
    _s3_note = None
    if base_query and conn_id and not _files:
        _files, _s3_note = await asyncio.to_thread(_s3_tables_in_query, conn_id, base_query)
    if _files:
        query_config["files"] = _files

    if not base_query and not _files:
        return DatasetPartitions([], {}, False,
                                 ["This dataset has neither a snapshotted query nor "
                                  "source tables, so its partitions cannot be "
                                  "determined."], conn_id)

    warnings: List[str] = [_s3_note] if _s3_note else []
    partition_names: List[str] = []
    tables_by_name: Dict[str, tuple] = {}
    detected = False
    try:
        from api.published_views.management import detect_partitions
        from api.published_views.models import DetectPartitionsRequest
        result = await detect_partitions(
            DetectPartitionsRequest(query_config=query_config,
                                    connection_id=conn_id),
            user=user,
        )
        warnings += list(result.get("warnings") or [])
        _table_conns = result.get("table_connection_ids") or {}
        for table, cols in (result.get("partition_columns") or {}).items():
            for c in (cols or []):
                if c and c not in partition_names:
                    partition_names.append(str(c))
                if c:
                    tables_by_name.setdefault(
                        str(c).lower(), (str(table), _table_conns.get(table, conn_id)))
        detected = True
    except HTTPException as exc:
        warnings.append(f"Partition detection refused: {exc.detail}")
    except Exception as exc:
        # Fail OPEN: a cold catalog must not stop someone authoring a report.
        logger.info("Dataset %s: partition detection unavailable: %s",
                    ds.get("id"), exc)
        warnings.append(f"Could not determine partition columns: {exc}")
    return DatasetPartitions(partition_names, tables_by_name, detected, warnings, conn_id)


@router.get("/api/datasets/{dataset_id}/source-filters", tags=["semantic-layer"])
async def dataset_source_filters(dataset_id: int,
                                 user: dict = Depends(require_capability("datasets.view"))):
    """The conditions of the dataset's own SQL WHERE a report may FILTER AT
    THE SOURCE (2026-10-29; core/source_filters.py, docs/REPORT_SOURCE_
    FILTERS_2026_10_29.html)::

        {"filters": [{key, column, qualifier, table, table_ref, op, values,
                      value_kind, is_date, parameter_type, values_source,
                      offered, sql, words}],
         "declined": [{sql, reason}], "reason"?: str, "dialect": str | null}

    DERIVED from the SQL every time (memoised by its digest), never stored:
    the SQL stays ONE text and the literal in it is the parameter's default.
    A table dataset, or a SQL with no WHERE, says so in ``reason`` -- never
    an empty list that reads as "has none"."""
    from core import source_filters as _sf
    ds = await _adb(_require_dataset_view, dataset_id, user)
    fed = _require_federation()
    dialect = await _adb(fed.dataset_sql_dialect, ds)
    disc = _sf.discover_cached(ds.get("base_query") or "", dialect)
    return {**disc.to_dict(), "dialect": dialect}


@router.get("/api/datasets/{dataset_id}/partition-columns", tags=["semantic-layer"])
async def dataset_partition_columns(dataset_id: int,
                                    user: dict = Depends(require_capability("datasets.view"))):
    """The dataset's partition columns, mapped onto its own column ids.

    Returns::

        {"partition_columns": [{"name", "column_id", "friendly_name", "table"}],
         "detected": bool, "warnings": [str]}

    ``detected`` is the honest part.  An empty list means one of two very
    different things — this source genuinely has no partitions, or nobody
    could tell (the catalog was cold, the warehouse unreachable, the SQL
    unparseable) — and a caller that cannot distinguish them will silently
    stop enforcing a partition predicate on exactly the days the source is
    unhealthy.  ``detected=False`` with the reason in ``warnings`` says
    "could not tell"; ``detected=True`` with an empty list says "none".

    Advisory and FAIL-OPEN: detection never blocks authoring.  The
    enforcement is the required PARAMETER the builder creates from this, not
    a refusal here.
    """
    db = _require_db()
    await _adb(_require_dataset_view, dataset_id, user)      # 404 / 403 first
    # get_dataset() is the SHALLOW row; the columns are what a caller binds a
    # parameter to, so read the full record.  Using the view-check's return
    # value produced an empty column map, and every detected partition was
    # then reported as "not one of this dataset's columns" — plausible-looking
    # and wrong.  The mapping test caught it.
    ds = await _adb(db.get_dataset_full, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # no names -> the mapping below returns [] with the detector's warnings
    _det = await dataset_partition_detection(ds, user)
    partition_names, detected, warnings = list(_det.names), _det.detected, list(_det.warnings)

    # Map the detected NAMES onto this dataset's own columns, because that is
    # what a caller can bind a parameter to.  A partition column the dataset
    # does not expose cannot be prompted for, and saying so is more useful
    # than dropping it silently.
    by_name = {str(c.get("physical_name") or "").lower(): c
               for c in (ds.get("columns") or [])}
    out: List[Dict[str, Any]] = []
    for name in partition_names:
        col = by_name.get(name.lower())
        if col is None:
            warnings.append(
                f"'{name}' partitions the source but is not one of this "
                f"dataset's columns, so it cannot be prompted for. Add it to "
                f"the dataset to filter on it.")
            continue
        out.append({
            "name": col.get("physical_name"),
            "column_id": col.get("id"),
            "friendly_name": col.get("friendly_name") or col.get("physical_name"),
            "data_type": col.get("data_type"),
        })

    logger.info("Dataset %s: %d partition column(s) %s (detected=%s)",
                dataset_id, len(out), [c["name"] for c in out], detected)
    return {"partition_columns": out, "detected": detected,
            "warnings": warnings}
