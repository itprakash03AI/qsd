/**
 * Shared parameter utilities — date macro resolution + default value handling.
 * Extracted from BusinessReportViewer to be shared across all report viewers/builders.
 */

import { isBusinessCalendarToken, splitDateToken } from './dateTokens';

/** Resolve @TODAY, @YESTERDAY, @MONTH_START etc. to ISO date strings */
export function resolveClientDateMacro(val: string): string {
  if (!val || !val.startsWith('@')) return val;
  const today = new Date();
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  const map: Record<string, () => string> = {
    '@TODAY': () => iso(today),
    '@YESTERDAY': () => iso(new Date(today.getTime() - 86400000)),
    '@MONTH_START': () => iso(new Date(today.getFullYear(), today.getMonth(), 1)),
    '@MONTH_END': () => {
      const d = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      return iso(d);
    },
    '@YEAR_START': () => iso(new Date(today.getFullYear(), 0, 1)),
    '@YEAR_END': () => iso(new Date(today.getFullYear(), 11, 31)),
    '@LAST_7_DAYS': () => iso(new Date(today.getTime() - 7 * 86400000)),
    '@LAST_30_DAYS': () => iso(new Date(today.getTime() - 30 * 86400000)),
    '@LAST_90_DAYS': () => iso(new Date(today.getTime() - 90 * 86400000)),
    '@QUARTER_START': () => {
      const qm = Math.floor(today.getMonth() / 3) * 3;
      return iso(new Date(today.getFullYear(), qm, 1));
    },
    '@QUARTER_END': () => {
      const qm = Math.floor(today.getMonth() / 3) * 3 + 3;
      return iso(new Date(today.getFullYear(), qm, 0));
    },
    '@THIS_WEEK_START': () => {
      const d = new Date(today);
      // ISO-8601: Monday = start of week (getDay() returns 0=Sun, so shift by (day+6)%7)
      d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
      return iso(d);
    },
  };
  const fn = map[val.toUpperCase()];
  return fn ? fn() : val;
}

/** The separator of a date-range default's two sides: `FROM..TO` (either may be empty). */
export const RANGE_SEPARATOR = '..';

/**
 * A raw value (a default, a URL value) in the shape its parameter kind takes --
 * the mirror of the backend's `core/reports/param_model.py::normalize_value`
 * (2026-10-30).  A date_range is `{from, to}` (`"A..B"`, a JSON object, or one
 * value meaning that one day); a multi_select is a list (a JSON list, or one
 * value).  A comma is never a separator.  Anything already in shape is kept.
 */
export function normalizeParamValue(param: any, raw: any): any {
  if (raw == null) return raw;
  const kind = String(param?.parameter_type || '').toLowerCase();
  if (kind === 'date_range') {
    if (Array.isArray(raw) && raw.length === 2) return { from: raw[0] || '', to: raw[1] || '' };
    if (typeof raw !== 'string') return raw;
    const text = raw.trim();
    if (!text) return raw;
    if (text.startsWith('{')) {
      try {
        const o = JSON.parse(text);
        if (o && typeof o === 'object' && !Array.isArray(o)) return { from: o.from || '', to: o.to || '' };
      } catch { /* not JSON: read below */ }
    }
    const at = text.indexOf(RANGE_SEPARATOR);
    if (at >= 0) return { from: text.slice(0, at).trim(), to: text.slice(at + RANGE_SEPARATOR.length).trim() };
    return { from: text, to: text };
  }
  if (kind === 'multi_select') {
    if (Array.isArray(raw)) return raw;
    if (typeof raw !== 'string') return [raw];
    const text = raw.trim();
    if (!text) return [];
    if (text.startsWith('[')) {
      try {
        const l = JSON.parse(text);
        if (Array.isArray(l)) return l;
      } catch { /* one value */ }
    }
    return [raw];
  }
  return raw;
}

/** A stored date-range default's two sides (`FROM..TO`; one value = that day). */
export function rangeDefaultSides(dv: any): { from: string; to: string } {
  const r = normalizeParamValue({ parameter_type: 'date_range' }, dv ?? '');
  if (r && typeof r === 'object' && !Array.isArray(r)) return { from: String(r.from || ''), to: String(r.to || '') };
  return { from: '', to: '' };
}

/** The stored text of a date-range default from its two sides ('' when both are empty). */
export function joinRangeDefault(from: string, to: string): string {
  const f = (from || '').trim();
  const t = (to || '').trim();
  return f || t ? `${f}${RANGE_SEPARATOR}${t}` : '';
}

/** 2026-11-01 -- two dates to compare in ONE shape ({a, b}; the server's param_model.normalize_value):
 *  a stored default may be '@A..@B', a JSON text, a pair or already an object.  {} = nothing. */
/** The value a link gives a parameter: `?p_<name>=value`.  A multi-select may repeat it
 *  (`?p_book=A&p_book=B`) -- reading only the first dropped B and showed fewer rows with no word
 *  (2026-11-05).  null = the link says nothing about this parameter. */
export function linkParamValue(searchParams: URLSearchParams, p: any): any {
  const all = searchParams.getAll(`p_${p?.name}`);
  if (all.length === 0) return null;
  return p?.parameter_type === 'multi_select' && all.length > 1 ? all : all[0];
}

/** The value a SHARE / EMBED page pre-selects for a parameter (2026-11-02, the owner: "no full
 *  reports should be shared, or embedded"): the server's rule default resolved for the report's
 *  owner (the latest date with data, ...) first, else the written default; undefined = none. */
export function tokenParamDefault(p: any): any {
  if (p?.effective_default !== undefined && p.effective_default !== null && p.effective_default !== '') {
    return p.parameter_type === 'cob_compare' ? normalizeCompareValue(p.effective_default) : p.effective_default;
  }
  return p?.default_value != null ? p.default_value : undefined;
}

export function normalizeCompareValue(raw: any): { a: string; b: string } | Record<string, never> {
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) return { a: String(raw.a || ''), b: String(raw.b || '') };
  if (Array.isArray(raw) && raw.length === 2) return { a: String(raw[0] || ''), b: String(raw[1] || '') };
  if (typeof raw === 'string' && raw.trim()) {
    const t = raw.trim();
    if (t.startsWith('{')) {
      try { const o = JSON.parse(t); return { a: String(o?.a || ''), b: String(o?.b || '') }; } catch { /* below */ }
    }
    if (t.includes(RANGE_SEPARATOR)) { const [a, b] = t.split(RANGE_SEPARATOR); return { a: a.trim(), b: b.trim() }; }
  }
  return {};
}

/** Resolve default value for a parameter — handles @macros for date types */
export function resolveParamDefault(param: any): any {
  const dv = param.default_value;
  if (dv == null || dv === '') return '';
  if (param.parameter_type === 'cob_compare') {
    const c = normalizeCompareValue(dv) as any;
    return c.a || c.b ? { a: resolveClientDateMacro(c.a || ''), b: resolveClientDateMacro(c.b || '') } : {};
  }
  if (param.parameter_type === 'date_range') {
    const r = normalizeParamValue(param, dv);
    if (r && typeof r === 'object' && !Array.isArray(r)) {
      return { from: resolveClientDateMacro(r.from || ''), to: resolveClientDateMacro(r.to || '') };
    }
    return r;
  }
  if (param.parameter_type === 'date' && typeof dv === 'string' && dv.startsWith('@')) {
    return resolveClientDateMacro(dv);
  }
  if (param.parameter_type === 'multi_select') return normalizeParamValue(param, dv);
  return dv;
}

/** A default only the SERVER can resolve: a business-calendar token
 *  (@PREV_BUSINESS_DAY[:CAL], @BUSINESS_DAY_N:3[:CAL], ...).  The client has
 *  no calendar, so it never guesses one (2026-09-28). */
export function isServerResolvedDateMacro(v: any): boolean {
  return typeof v === 'string' && v.trim().startsWith('@')
    && isBusinessCalendarToken(splitDateToken(v).base);
}

/**
 * The default values for a report's parameters: client macros resolved
 * here (as before), business-calendar tokens resolved by the server through
 * `preview` (GET /api/date-tokens/preview -- the same resolver a run uses).
 * A token the server refuses is kept AS THE TOKEN, so the run refuses with
 * the server's reason instead of running on a guessed date.
 */
export async function resolveParamDefaults(
  params: any[],
  preview: (value: string) => Promise<{ resolved: string | null; refused?: string | null }>,
): Promise<Record<string, any>> {
  const out: Record<string, any> = {};
  const viaServer = async (v: string): Promise<string> => {
    if (!isServerResolvedDateMacro(v)) return resolveClientDateMacro(v);
    try {
      const r = await preview(v);
      return r.resolved ?? v;
    } catch {
      return v;
    }
  };
  for (const p of (params || [])) {
    // 2026-11-01 -- a default RULE resolved by the server for THIS viewer (latest with data,
    // the entitled value, the last pick) wins over the written default
    if (p.effective_default !== undefined && p.effective_default !== null && p.effective_default !== '') {
      // (rig 2026-11-02) two dates to compare arrive as "A..B": the band reads {a, b} ("... vs ..." otherwise)
      out[p.name] = p.parameter_type === 'cob_compare' ? normalizeCompareValue(p.effective_default) : p.effective_default;
      continue;
    }
    const dv = p.default_value;
    if (p.parameter_type === 'cob_compare' && dv != null && dv !== '') {
      // (rig 2026-11-01) the A / B boxes showed "mm/dd/yyyy" while the run used the default: the
      // default is resolved here like a range's two sides, so the control shows the value in force
      const c = normalizeCompareValue(dv) as any;
      out[p.name] = c.a || c.b ? { a: c.a ? await viaServer(c.a) : '', b: c.b ? await viaServer(c.b) : '' } : {};
    } else if (p.parameter_type === 'date_range' && typeof dv === 'string' && dv.trim()) {
      // 2026-10-30 -- a range default is `FROM..TO`; each side may be a token
      const r = normalizeParamValue(p, dv);
      out[p.name] = (r && typeof r === 'object' && !Array.isArray(r))
        ? { from: r.from ? await viaServer(r.from) : '', to: r.to ? await viaServer(r.to) : '' } : r;
    } else if (['date', 'date_range'].includes(p.parameter_type) && isServerResolvedDateMacro(dv)) {
      try {
        const r = await preview(dv);
        out[p.name] = r.resolved ?? dv;
      } catch {
        out[p.name] = dv;
      }
    } else {
      out[p.name] = resolveParamDefault(p);
    }
  }
  return out;
}
