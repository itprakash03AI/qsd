/**
 * Browser URLs for reports -- 2026-09-20.
 *
 * The browser URL is /finance-reports/<slug>; the REST API keeps
 * /api/business-reports/<id> untouched (embed tokens, share links,
 * published views and external consumers hold numeric ids).  Every UI
 * path is built HERE: a hand-written `/business-reports/${id}` anywhere
 * else is the old URL coming back (a vitest guard walks src/ for it).
 *
 * Resolution is ONE way: a route element (UnifiedReportViewer /
 * UnifiedReportBuilder) asks GET /api/business-reports/by-slug/<slug>,
 * then publishes {id, slug} through ReportIdentityContext; the inner
 * viewers and builders take the numeric id from the context and fall
 * back to a numeric route param only when mounted alone (tests).  A
 * report whose slug is missing (a legacy row the backfill could not
 * slug) links by id; the by-slug route resolves a numeric token by id.
 */
import { createContext, useContext } from 'react';
import { useParams } from 'react-router-dom';

export const REPORTS_PATH = '/finance-reports';
export const NEW_REPORT_PATH = `${REPORTS_PATH}/new`;
/** 2026-11-02 -- a report started from a design (NewReportFromTemplate) */
export const NEW_REPORT_FROM_TEMPLATE_PATH = `${REPORTS_PATH}/new/template`;

/** 2026-10-23 -- the owner: "once create data set not option to create
 *  report...process flow is breaking".  A new report started FROM a dataset:
 *  the type picker keeps the query string, and the tabular / pivot builders
 *  open with that dataset chosen, on the Columns step. */
export const START_DATASET_PARAM = 'dataset_id';

export function newReportForDatasetPath(datasetId: number | string): string {
  // 2026-11-05 -- the owner: "once u save dataset, create report still follows old routes".  It opens
  // the canvas builder with this dataset chosen; the older type picker stays at NEW_REPORT_PATH.
  return `${REPORTS_PATH}/new/canvas?dataset=${encodeURIComponent(String(datasetId))}`;
}

/** The dataset a NEW report was started from (`?dataset_id=N`), or null. */
export function startDatasetIdFrom(search: string): number | null {
  const raw = new URLSearchParams(search || '').get(START_DATASET_PARAM);
  const n = raw != null && /^\d+$/.test(raw.trim()) ? Number(raw.trim()) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
}

/** The token the URL carries for a report: its slug, or its id when it has none. */
export function reportToken(r: { id: number | string; slug?: string | null } | number | string): string {
  if (typeof r === 'number' || typeof r === 'string') return String(r);
  return r.slug ? r.slug : String(r.id);
}

export function reportPath(r: { id: number | string; slug?: string | null } | number | string): string {
  return `${REPORTS_PATH}/${reportToken(r)}`;
}

/** The ONE editor (2026-11-01, the owner: "edit report doesn't have option
 *  to design report tiles"): /design with tabs Data · Parameters · Design ·
 *  Look · Actions · Settings (ReportStudioPage).  /edit and /canvas redirect
 *  into it; nothing links to them any more. */
export type StudioTab = 'data' | 'parameters' | 'design' | 'look' | 'actions' | 'settings';
export const STUDIO_TABS: StudioTab[] = ['data', 'parameters', 'design', 'look', 'actions', 'settings'];

export function reportEditPath(r: { id: number | string; slug?: string | null } | number | string,
                               tab?: StudioTab): string {
  return `${reportPath(r)}/design${tab ? `?tab=${tab}` : ''}`;
}

export interface ReportIdentity {
  id: number;
  slug: string | null;
}

export const ReportIdentityContext = createContext<ReportIdentity | null>(null);

/**
 * The numeric report id for the component being rendered: from the
 * identity a route element resolved, else from a numeric :id param
 * (the shape the component tests mount), else NaN.
 */
export function useResolvedReportId(): number {
  const ctx = useContext(ReportIdentityContext);
  const params = useParams<{ id?: string; slug?: string }>();
  if (ctx && Number.isFinite(ctx.id)) return ctx.id;
  const raw = params.id ?? params.slug;
  return raw !== undefined && /^\d+$/.test(raw) ? Number(raw) : NaN;
}
