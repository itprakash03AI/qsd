/**
 * Does a statement filter on any of a table's partition columns?
 * (2026-10-07, F3 of the BQB audit.)
 *
 * The query builder's partition-pruning guide (the "Partition cols" row and
 * its popover) offered chips but never said the one thing a user needs before
 * pressing Execute on a 2,688-file table: THIS statement filters on none of
 * them, so it reads every file.  This answers that question for the guide;
 * it decides nothing about the run (the server prunes from the statement).
 *
 * Conservative in the QUIET direction: comments and string literals are
 * removed first, so `WHERE note = 'business_close_date'` is no filter, and a
 * partition column named anywhere after the first WHERE counts as filtered
 * (a false "filtered" hides a hint; a false "not filtered" would nag).
 */

/** The statement with its comments and string literals removed, in ONE pass (2026-11-05, the
 *  owner: "no partition filter message totally wrong").  Two separate replaces read `--` or a
 *  slash-star inside a LITERAL as a comment: `WHERE x LIKE '%--%' AND dt = ...` lost its whole
 *  WHERE, and the guide said the query had no filter.  A line may end in a lone CR (pasted text). */
const stripCommentsAndLiterals = (sql: string): string => {
  const s = String(sql || '');
  let out = '';
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    const two = s.slice(i, i + 2);
    if (two === '--') {
      while (i < s.length && s[i] !== '\n' && s[i] !== '\r') i += 1;
      out += ' ';
    } else if (two === '/*') {
      const end = s.indexOf('*/', i + 2);
      i = end < 0 ? s.length : end + 2;
      out += ' ';
    } else if (c === "'" || c === '"') {
      // a doubled quote stays inside; an identifier is kept, a literal is not
      let j = i + 1;
      while (j < s.length) {
        if (s[j] !== c) { j += 1; continue; }
        if (s[j + 1] === c) { j += 2; continue; }
        break;
      }
      out += c === '"' ? s.slice(i, j + 1) : "''";
      i = j + 1;
    } else {
      out += c;
      i += 1;
    }
  }
  return out;
};

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** The partition columns the statement's WHERE (or a JOIN's ON) names. */
export function partitionColumnsFiltered(sql: string, partitionColumns: string[]): string[] {
  const code = stripCommentsAndLiterals(sql);
  const m = code.match(/\b(where|on)\b([\s\S]*)$/i);
  if (!m) return [];
  const tail = m[2];
  return partitionColumns.filter(col => {
    const c = escapeRe(col);
    const re = new RegExp(`(^|[^A-Za-z0-9_])("${c}"|${c})(?=[^A-Za-z0-9_]|$)`, 'i');
    return re.test(tail);
  });
}

/** Does the statement read any of these tables?  The partition columns belong to the tables ticked
 *  in the tree, and a typed statement may read another table altogether. */
export function statementReadsAnyTable(sql: string, tableNames: string[]): boolean {
  const code = stripCommentsAndLiterals(sql);
  return tableNames.some(name => {
    const n = escapeRe(name);
    return new RegExp(`(^|[^A-Za-z0-9_])("${n}"|${n})(?=[^A-Za-z0-9_]|$)`, 'i').test(code);
  });
}

/** The guide's sentence when the statement filters on NO partition column,
 *  else null.  `files` is the pre-flight estimate's file count (0 / unknown
 *  leaves it out).  `tableNames` are the tables the columns came from: a
 *  statement that reads none of them gets no sentence about them. */
export function noPartitionFilterHint(
  sql: string, partitionColumns: string[], files?: number | null, tableNames?: string[],
): string | null {
  if (!partitionColumns.length || !String(sql || '').trim()) return null;
  if (partitionColumnsFiltered(sql, partitionColumns).length > 0) return null;
  if (tableNames?.length && !statementReadsAnyTable(sql, tableNames)) return null;
  const list = partitionColumns.length === 1
    ? partitionColumns[0]
    : `${partitionColumns.slice(0, -1).join(', ')} or ${partitionColumns[partitionColumns.length - 1]}`;
  const where = files && files > 0 ? `every file (~${files.toLocaleString()} files)` : 'every file of the table';
  return `No partition filter: this query reads ${where}. Filter on ${list} to read only the partitions you need.`;
}
