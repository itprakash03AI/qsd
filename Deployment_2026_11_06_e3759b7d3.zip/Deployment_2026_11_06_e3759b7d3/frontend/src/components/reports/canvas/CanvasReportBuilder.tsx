/**
 * The canvas report builder (2026-10-26; owner-approved design
 * docs/REPORT_CANVAS_DESIGN_2026_10_25.html).
 *
 *   top      name · parameters asked when the report runs (chips, "+ Ask for
 *            a value") · fixed filters (chips) · Preview with values · Save
 *   left     the dataset's fields, searchable; drag one onto the canvas (a new
 *            tile), onto a tile (adds it), or click "+" (adds it to the
 *            selected tile, else makes one)
 *   middle   the canvas -- the SAME component the viewer shows
 *   right    the selected tile: kind, title, fields, how each value is added
 *            up (only the ways that are exact for this report), series, sort,
 *            how many to draw; delete
 *
 * Every check is the model's ``canvasProblems`` (the server applies the same
 * on save): each problem is shown on its tile and Save stays off until there
 * are none.  The report runs ONE query whose columns are every field the
 * canvas uses; Preview runs the saved report with the draft's columns and the
 * chosen parameter values, without saving.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Autocomplete, Box, Button, Chip, CircularProgress, Divider, IconButton, InputAdornment, List, ListItemButton, ListItemText, MenuItem,
  Paper, Stack, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../../common/AppDialog';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import SearchIcon from '@mui/icons-material/Search';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayIcon from '@mui/icons-material/PlayArrow';
import SaveIcon from '@mui/icons-material/Save';
import api from '../../../services/api';
import { SourceFilter, askedParameter, sourceParameter } from '../../../utils/reportFilters';
import { reportPath, REPORTS_PATH } from '../../../utils/reportUrls';
import ReportParamControl from '../ReportParamControl';
import ReportCanvasView, { FIELD_MIME } from './ReportCanvasView';
import { CanvasLinksSwitch, TileLinkedSwitch, setCanvasLinks, setTileLinked } from './CanvasLinkChips';
import { FormControlLabel, Switch } from '@mui/material';
import { CanvasActionsEditor } from './canvasActions';
import { CanvasThemeContext, resolveTheme } from './canvasTheme';
import { DrillSettings } from './canvasDrill';
import { CanvasCompareContext, CompareSettings, compareFrom } from './canvasCompare';
import {
  AGG_LABEL, Aggregation, allowedAggregations, CanvasColumn, canvasColumnIds, CanvasPage, canvasProblems, CanvasTile, pageOfTile,
  defaultAggregation, effectiveCanvas, isChart, isMeasureColumn, KIND_LABEL, makeTile, maxPointsOf,
  MAX_SERIES_VALUES, ONE_VALUE_CHARTS, ReportCanvas, rowsAreGrouped, SERIES_CHARTS, SUM_ONLY,
  TileKind, tileName, TileLayout,
} from './canvasModel';
import { CanvasBandContext } from './CanvasOutlineTile';
import { BandTileSettings, KpiTileSettings, OutlineTileSettings, TileFormatSettings } from './CanvasOutlineSettings';
import { LABEL_KINDS, LABEL_MODES, LABEL_WORDS, OVERLAY_KINDS, PERCENT_KINDS, type LabelMode } from './canvasChartOptions';
import { addFieldToOutline, MAX_REPORT_CODE, newOutlineFields } from './canvasOutline';
import { addFieldToInsight, insightColumnIds, newInsight } from './canvasInsights';
import InsightTileEditor from './InsightTileEditor';

const ADDABLE: TileKind[] = ['number', 'bar', 'line', 'pie', 'table', 'pivot', 'outline', 'band', 'insight', 'report'];
/** every kind a tile can be switched to (the "Show as" menu) */
const SHOW_AS: TileKind[] = ['number', 'table', 'pivot', 'heatmap', 'bar', 'hbar', 'stacked_bar', 'line', 'area',
  'stacked_area', 'combo', 'radar', 'pie', 'donut', 'treemap', 'funnel', 'waterfall', 'scatter', 'bubble'];

/** How many values a kind of tile takes. */
export function valueLimit(kind: TileKind): number {
  if (kind === 'number' || ONE_VALUE_CHARTS.includes(kind) || kind === 'heatmap') return 1;
  if (kind === 'scatter') return 2;
  if (kind === 'bubble') return 3;
  if (SERIES_CHARTS.includes(kind) || kind === 'combo') return MAX_SERIES_VALUES;
  return 50;
}

const toCol = (c: any): CanvasColumn => ({
  id: Number(c.id), physical_name: c.physical_name, label: c.friendly_name || c.physical_name,
  data_type: c.data_type, column_type: c.column_type, aggregation: c.aggregation,
  format_pattern: c.format_pattern,
} as CanvasColumn);

/** Put a field on a tile in the place that kind of tile uses it. */
export function addFieldToTile(t: CanvasTile, col: CanvasColumn, grouped: boolean): CanvasTile {
  const measure = isMeasureColumn(col);
  const asValue = { column_id: col.id, aggregation: defaultAggregation(col, grouped) };
  const has = t.dimensions.includes(col.id) || t.measures.some(m => m.column_id === col.id) || t.series === col.id;
  if (has) return t;
  switch (t.kind) {
    case 'outline': return addFieldToOutline(t, col, asValue.aggregation);
    case 'band': return t;
    case 'insight':
      return { ...t, insight: addFieldToInsight(t.insight ?? newInsight('explain_change'), col) };
    case 'number':
      return { ...t, dimensions: [], measures: [asValue] };
    case 'heatmap':
      if (measure) return { ...t, measures: [asValue] };
      if (t.dimensions.length === 0) return { ...t, dimensions: [col.id] };
      return t.series == null ? { ...t, series: col.id } : t;
    case 'pivot':
      if (measure) return { ...t, measures: [...t.measures, asValue] };
      if (t.series == null && t.dimensions.length > 0) return { ...t, series: col.id };
      return { ...t, dimensions: [...t.dimensions, col.id] };
    case 'table':
      return measure ? { ...t, measures: [...t.measures, asValue] } : { ...t, dimensions: [...t.dimensions, col.id] };
    default: {
      if (!isChart(t.kind)) return t;
      if (!measure) {
        if (t.dimensions.length === 0) return { ...t, dimensions: [col.id] };
        if (SERIES_CHARTS.includes(t.kind) && t.series == null && t.measures.length <= 1) return { ...t, series: col.id };
        return t;
      }
      const limit = valueLimit(t.kind);
      const v = SUM_ONLY.includes(t.kind) ? { ...asValue, aggregation: 'sum' as Aggregation } : asValue;
      if (limit === 1) return { ...t, measures: [v] };
      if (t.measures.length >= limit) return t;
      return { ...t, measures: [...t.measures, v], series: t.measures.length >= 1 ? null : t.series };
    }
  }
}

/** A new tile for a field dropped on the empty canvas. */
export function tileForField(col: CanvasColumn, tiles: CanvasTile[], grouped: boolean): CanvasTile {
  if (isMeasureColumn(col)) {
    return makeTile('number', { measures: [{ column_id: col.id, aggregation: defaultAggregation(col, grouped) }] }, tiles);
  }
  return makeTile('table', { dimensions: [col.id] }, tiles);
}

/** Switch a tile's kind, keeping every field that still fits. */
export function changeKind(t: CanvasTile, kind: TileKind): CanvasTile {
  const fields = { dimensions: t.dimensions, measures: t.measures, series: t.series };
  let next: CanvasTile = { ...t, kind };
  if (kind === 'number') next = { ...next, dimensions: [], series: null, measures: fields.measures.slice(0, 1), top_n: null, sort: null };
  if (isChart(kind)) {
    const limit = valueLimit(kind);
    const ordered = ['line', 'area', 'stacked_area', 'waterfall', 'scatter', 'bubble'].includes(kind);
    next = { ...next, dimensions: fields.dimensions.slice(0, 1), measures: fields.measures.slice(0, limit),
             series: SERIES_CHARTS.includes(kind) && fields.measures.length <= 1 ? fields.series : null,
             top_n: t.top_n ?? 25,
             sort: ordered ? null : (t.sort ?? { by: 'measure', dir: 'desc' }) };
    if (SUM_ONLY.includes(kind)) next = { ...next, measures: next.measures.map(m => ({ ...m, aggregation: 'sum' as Aggregation })) };
  }
  if (kind === 'heatmap') {
    next = { ...next, dimensions: fields.dimensions.slice(0, 1), measures: fields.measures.slice(0, 1),
             series: fields.series ?? (fields.dimensions[1] ?? null), top_n: null, sort: null };
  }
  if (kind === 'pivot' && next.series == null && next.dimensions.length > 1) {
    next = { ...next, series: next.dimensions[next.dimensions.length - 1], dimensions: next.dimensions.slice(0, -1) };
  }
  if (kind === 'table' || kind === 'pivot') next = { ...next, top_n: null };
  if (kind === 'table') next = { ...next, dimensions: [...next.dimensions, ...(next.series != null ? [next.series] : [])], series: null };
  if (kind === 'report') next = { ...next, dimensions: [], measures: [], series: null, top_n: null, sort: null };
  return next;
}

interface ParamDraft {
  id?: number;
  name: string;
  label: string;
  parameter_type: string;
  lov_column_id?: number | null;
  is_required?: boolean;
  default_value?: any;
  [k: string]: any;
}

/** The owner, 2026-11-05: "Fields doesnt come full name".  A long column name has no spaces, so it
 *  breaks anywhere rather than being cut; the mouse says it in full too. */
const FULL_FIELD_NAME = { overflowWrap: 'anywhere' } as const;

export function fieldHoverText(c: { label: string; physical_name: string }, target: string): string {
  const name = c.physical_name !== c.label ? `${c.label} (${c.physical_name})` : c.label;
  return `${name}\nDrag onto the canvas or a tile -- or click to add it to ${target}`;
}

export default function CanvasReportBuilder() {
  const { id: routeId } = useParams<{ id: string }>();
  // the one editor's Actions tab: ?focus=actions scrolls the actions editor into view
  const actionsRef = useRef<HTMLDivElement | null>(null);
  const [focusParams] = useSearchParams();
  const focusParam = focusParams.get('focus');
  useEffect(() => {
    if (focusParam === 'actions') setTimeout(() => actionsRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'start' }), 300);
  }, [focusParam]);
  const [search] = useSearchParams();
  const navigate = useNavigate();
  const isNew = !routeId || routeId === 'new';

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [report, setReport] = useState<any>(null);
  const [viewersMayRearrange, setViewersMayRearrange] = useState(false);
  const [datasets, setDatasets] = useState<any[]>([]);
  const [datasetId, setDatasetId] = useState<number | null>(Number(search.get('dataset')) || null);
  const [columns, setColumns] = useState<CanvasColumn[]>([]);
  const [hasMetrics, setHasMetrics] = useState(false);
  const [name, setName] = useState('');
  const [canvas, setCanvas] = useState<ReportCanvas>({ version: 1, tiles: [] });
  const [reportTableCols, setReportTableCols] = useState<number[]>([]);
  const [params, setParams] = useState<ParamDraft[]>([]);
  const [paramsDirty, setParamsDirty] = useState(false);
  // 2026-10-29 -- the conditions of the dataset's own SQL WHERE a parameter
  // may fill ("Filter at the source", backend core/source_filters.py)
  const [sourceFilters, setSourceFilters] = useState<SourceFilter[]>([]);
  const [filters, setFilters] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [fieldQuery, setFieldQuery] = useState('');
  const [askOpen, setAskOpen] = useState(false);
  const [askCol, setAskCol] = useState<CanvasColumn | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  // the preview run and the fields it ran WITH: a tile added or changed
  // afterwards says "press Preview again" instead of failing (2026-10-26)
  const [previewExec, setPreviewExec] = useState<{ id: string; total: number | null; truncated: boolean; fields: number[] } | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ kind: 'error' | 'success' | 'info'; text: string } | null>(null);
  const [serverProblems, setServerProblems] = useState<Record<string, string[]>>({});

  // ── load ────────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true); setLoadError('');
      try {
        if (isNew) {
          const ds = await api.listDatasets();
          if (!cancelled) {
            const list = Array.isArray(ds) ? ds : (ds?.items || ds?.datasets || []);
            setDatasets(list);
            setCanvas({ version: 1, tiles: [] });
          }
        } else {
          const r = /^\d+$/.test(routeId!) ? await api.getBusinessReport(Number(routeId)) : await api.getBusinessReportBySlug(routeId!);
          if (cancelled) return;
          setReport(r);
          setViewersMayRearrange(!!r?.layout_config?.viewers_may_rearrange);
          setName(r.name || '');
          setDatasetId(r.dataset_id ?? null);
          setFilters(Array.isArray(r.filter_specs) ? r.filter_specs : []);
          setParams((r.parameters || []).map((p: any) => ({ ...p })));
          // every report is a canvas: one with none stored opens as ONE tile, its own table
          setCanvas(effectiveCanvas(r.layout_config));
          setReportTableCols((r.column_ids || []).map(Number));
        }
      } catch (e: any) {
        if (!cancelled) setLoadError(e?.message || 'The report could not be loaded.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [isNew, routeId]);

  useEffect(() => {
    if (!datasetId) { setColumns([]); return; }
    let cancelled = false;
    (async () => {
      try {
        const ds = await api.getDataset(datasetId);
        if (cancelled) return;
        // (rig 2026-11-01) a hidden column stays in the data -- a tile counting `id` is not "no longer in the
        // data"; it is kept for the check and left out of the field list
        setColumns((ds?.columns || []).map((c: any) => ({ ...toCol(c), hidden: !!c.is_hidden })));
        api.getDatasetSourceFilters(datasetId)
          .then((r: any) => { if (!cancelled) setSourceFilters((r?.filters || []).filter((f: any) => f.offered)); })
          .catch(() => { if (!cancelled) setSourceFilters([]); });
        // a calculated metric makes the stored rows grouped (the server's rule)
        const metrics = ds?.calculated_metrics ?? ds?.metrics;
        setHasMetrics(Array.isArray(metrics) ? metrics.length > 0 : false);
      } catch (e: any) {
        if (!cancelled) setLoadError(e?.message || 'The dataset could not be loaded.');
      }
    })();
    return () => { cancelled = true; };
  }, [datasetId]);

  const cols = useMemo(() => new Map(columns.map(c => [c.id, c])), [columns]);
  const grouped = useMemo(() => rowsAreGrouped(columns, hasMetrics), [columns, hasMetrics]);
  const hasReportTile = canvas.tiles.some(t => t.kind === 'report');
  /** the report's ONE query returns every field the canvas uses (+ its own table's columns) */
  const unionIds = useMemo(() => {
    const ids = new Set<number>(canvasColumnIds(canvas));
    if (hasReportTile) reportTableCols.forEach(i => ids.add(i));
    return [...ids].filter(i => cols.has(i));
  }, [canvas, hasReportTile, reportTableCols, cols]);

  const problems = useMemo(() => canvasProblems(canvas, columns, { grouped, selected: unionIds }), [canvas, columns, grouped, unionIds]);
  const problemsByTile = useMemo(() => {
    const out: Record<string, string[]> = {};
    for (const p of problems) if (p.tileId) (out[p.tileId] ||= []).push(p.message);
    for (const [k, v] of Object.entries(serverProblems)) (out[k] ||= []).push(...v);
    return out;
  }, [problems, serverProblems]);
  const pageProblems = problems.filter(p => !p.tileId).map(p => p.message);
  if (hasReportTile && unionIds.length === 0) pageProblems.push("The report's table has no columns. Pick at least one on its tile.");
  if (!name.trim()) pageProblems.push('Give the report a name.');
  if (!datasetId) pageProblems.push('Pick the data the report is built on.');
  const canSave = problems.length === 0 && pageProblems.length === 0 && !saving;

  const staleFields = useMemo(() => {
    if (!previewExec) return {} as Record<string, string[]>;
    const ran = new Set(previewExec.fields);
    const out: Record<string, string[]> = {};
    for (const t of canvas.tiles) {
      if (t.kind === 'report') continue;
      const need = [...t.dimensions, ...t.measures.map(m => m.column_id), ...(t.series != null ? [t.series] : []), ...(t.levels ?? []),
        ...insightColumnIds(t.insight)];
      const missing = [...new Set(need.filter(i => !ran.has(i)))].map(i => cols.get(i)?.label ?? `column #${i}`);
      if (missing.length) out[t.id] = missing;
    }
    return out;
  }, [previewExec, canvas, cols]);
  const previewIsStale = Object.keys(staleFields).length > 0;

  const selected = canvas.tiles.find(t => t.id === selectedId) ?? null;
  const updateTile = useCallback((id: string, f: (t: CanvasTile) => CanvasTile) => {
    setCanvas(c => ({ ...c, tiles: c.tiles.map(t => t.id === id ? f(t) : t) }));
    setServerProblems({});
  }, []);

  const addTile = (kind: TileKind) => {
    if (kind === 'report' && hasReportTile) { setMessage({ kind: 'info', text: "The report's table is already on the page." }); return; }
    const t = makeTile(kind, kind === 'report' ? { id: 'report' } : kind === 'insight' ? { insight: newInsight('explain_change') } : newOutlineFields(kind), canvas.tiles);
    setCanvas(c => ({ ...c, tiles: [...c.tiles, t] }));
    setSelectedId(t.id);
  };
  const onDropField = (columnId: number, tileId: string | null) => {
    const col = cols.get(columnId);
    if (!col) return;
    if (tileId) {
      const t = canvas.tiles.find(x => x.id === tileId);
      if (t?.kind === 'report') { setReportTableCols(r => r.includes(columnId) ? r : [...r, columnId]); return; }
      updateTile(tileId, x => addFieldToTile(x, col, grouped));
      setSelectedId(tileId);
    } else {
      const t = tileForField(col, canvas.tiles, grouped);
      setCanvas(c => ({ ...c, tiles: [...c.tiles, t] }));
      setSelectedId(t.id);
    }
  };
  const onLayout = (layouts: Record<string, TileLayout>) => {
    setCanvas(c => {
      let changed = false;
      const tiles = c.tiles.map(t => {
        const l = layouts[t.id];
        if (l && (l.x !== t.layout.x || l.y !== t.layout.y || l.w !== t.layout.w || l.h !== t.layout.h)) { changed = true; return { ...t, layout: l }; }
        return t;
      });
      return changed ? { ...c, tiles } : c;
    });
  };

  // ── parameters asked when the report runs ───────────────────────────────
  const addAsked = (col: CanvasColumn) => {
    const p = askedParameter({ column_id: col.id, operator: 'eq' } as any,
      { id: col.id, friendly_name: col.label, physical_name: col.physical_name, data_type: col.data_type || '' });
    if (params.some(x => x.name === p.name)) { setMessage({ kind: 'info', text: `${col.label} is already asked when the report runs.` }); return; }
    setParams(ps => [...ps, { ...p, is_required: false, default_value: '' }]);
    setParamsDirty(true);
  };
  /** 2026-10-29 -- a condition of the dataset's query asked when the report
   *  runs: the value goes INTO the condition (filter at the source). */
  const addSourceAsked = (sf: SourceFilter) => {
    if (params.some(p => p.source_column === sf.key)) { setMessage({ kind: 'info', text: `${sf.column} is already asked when the report runs.` }); return; }
    const p = sourceParameter(sf);
    setParams(ps => [...ps, { ...p, name: ps.some(x => x.name === p.name) ? `${p.name}_source` : p.name }]);
    setParamsDirty(true);
  };
  const removeParam = (name: string) => { setParams(ps => ps.filter(p => p.name !== name)); setParamsDirty(true); };

  // ── save ────────────────────────────────────────────────────────────────
  const save = async () => {
    setSaving(true); setMessage(null); setServerProblems({});
    try {
      let saved: any;
      if (isNew || !report) {
        saved = await api.createBusinessReport({
          name: name.trim(), dataset_id: datasetId, data_source_type: 'saved_query', column_ids: unionIds,
          filter_specs: filters, layout_config: { report_type: 'table', canvas, viewers_may_rearrange: viewersMayRearrange },
        });
      } else {
        // PUT replaces layout_config: send the stored object with the canvas
        // merged in, from a FRESH read, and only if nobody saved since we loaded
        const fresh = await api.getBusinessReport(report.id);
        if (String(fresh.updated_at) !== String(report.updated_at)) {
          setMessage({ kind: 'error', text: `Someone saved this report after you opened it${fresh.updated_by ? ` (${fresh.updated_by})` : ''}. Your changes were not saved. Reload to see theirs, then make your changes again.` });
          return;
        }
        saved = await api.updateBusinessReport(report.id, {
          name: name.trim(), column_ids: unionIds, filter_specs: filters,
          layout_config: { ...(fresh.layout_config || {}), canvas, viewers_may_rearrange: viewersMayRearrange },
          expected_updated_at: report.updated_at,
        });
      }
      const rid = saved?.id ?? report?.id;
      if (paramsDirty && rid) {
        await api.batchSaveBusinessReportParams(rid, params.map(p => ({ ...p })));
        setParamsDirty(false);
      }
      const reread = await api.getBusinessReport(rid);
      setReport(reread);
      setParams((reread.parameters || []).map((p: any) => ({ ...p })));
      setMessage({ kind: 'success', text: 'Saved.' });
      if (isNew) navigate(`/finance-reports/${reread.slug || reread.id}/canvas`, { replace: true });
    } catch (e: any) {
      const detail = e?.detail ?? e?.body?.detail;
      if (detail?.problems) {
        const byTile: Record<string, string[]> = {};
        for (const p of detail.problems) if (p.tile_id) (byTile[p.tile_id] ||= []).push(p.message);
        setServerProblems(byTile);
      }
      setMessage({ kind: 'error', text: detail?.message || e?.message || 'The report could not be saved.' });
    } finally {
      setSaving(false);
    }
  };

  // ── preview ─────────────────────────────────────────────────────────────
  const preview = async () => {
    if (!report) return;
    setPreviewing(true); setMessage(null);
    try {
      const res: any = await api.executeBusinessReport(report.id, {
        parameter_values: paramValues, override_column_ids: unionIds,
      });
      const id = res?.execution_id;
      if (!id) throw new Error('The preview run did not return a result to show.');
      setPreviewExec({ id, total: typeof res.total_rows === 'number' ? res.total_rows : null, truncated: !!res.truncated,
                       fields: [...unionIds] });
      setPreviewOpen(false);
    } catch (e: any) {
      setMessage({ kind: 'error', text: e?.message || 'The preview could not run.' });
    } finally {
      setPreviewing(false);
    }
  };

  const fields = columns.filter(c => !c.hidden).filter(c => !fieldQuery.trim() || c.label.toLowerCase().includes(fieldQuery.toLowerCase())
    || c.physical_name.toLowerCase().includes(fieldQuery.toLowerCase()));
  const dims = fields.filter(c => !isMeasureColumn(c));
  const meas = fields.filter(c => isMeasureColumn(c));

  if (loading) return <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>;
  if (loadError) return <Alert severity="error" sx={{ m: 3 }}>{loadError}</Alert>;

  const fieldItem = (c: CanvasColumn) => (
    <ListItemButton key={c.id} dense draggable data-testid={`field-${c.physical_name}`}
      onDragStart={e => { e.dataTransfer.setData(FIELD_MIME, String(c.id)); e.dataTransfer.effectAllowed = 'copy'; }}
      onClick={() => onDropField(c.id, selectedId)}
      title={fieldHoverText(c, selected ? 'the selected tile' : 'a new tile')}>
      <ListItemText primary={c.label} secondary={c.physical_name !== c.label ? c.physical_name : undefined}
        primaryTypographyProps={{ variant: 'body2', sx: FULL_FIELD_NAME }} secondaryTypographyProps={{ variant: 'caption', sx: FULL_FIELD_NAME }} />
      <AddIcon fontSize="small" color="action" />
    </ListItemButton>
  );

  return (
    <Box sx={{ p: 2 }} data-testid="canvas-builder">
      {/* top bar */}
      <Paper variant="outlined" sx={{ p: 1.5, mb: 1.5 }}>
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
          <IconButton aria-label="Back" onClick={() => navigate(report ? reportPath(report) : REPORTS_PATH)}><ArrowBackIcon /></IconButton>
          <TextField size="small" label="Report name" value={name} onChange={e => setName(e.target.value)}
            sx={{ minWidth: 260 }} inputProps={{ 'data-testid': 'canvas-name' }} />
          <TextField size="small" label="Report code" value={canvas.report_code ?? ''} sx={{ width: 150 }}
            title="Shown top right of the header band, e.g. PLEXPRA-04"
            onChange={e => { const v = e.target.value.slice(0, MAX_REPORT_CODE); setCanvas(c => ({ ...c, report_code: v || undefined })); }}
            inputProps={{ 'data-testid': 'canvas-report-code' }} />
          {isNew && (
            <TextField select size="small" label="Data" value={datasetId ?? ''} sx={{ minWidth: 220 }}
              onChange={e => { setDatasetId(Number(e.target.value) || null); setCanvas({ version: 1, tiles: [] }); setReportTableCols([]); }}
              SelectProps={{ native: false }} inputProps={{ 'data-testid': 'canvas-dataset' }}>
              {datasets.map((d: any) => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
            </TextField>
          )}
          <Box sx={{ flex: 1 }} />
          <Tooltip title={report ? 'Run the saved report with this canvas and chosen values -- nothing is saved' : 'Save the report once to preview it'}>
            <span>
              <Button variant="outlined" startIcon={previewing ? <CircularProgress size={14} /> : <PlayIcon />}
                disabled={!report || previewing || problems.length > 0} onClick={() => params.some(p => p.id) ? setPreviewOpen(true) : preview()}
                data-testid="canvas-preview">Preview with values…</Button>
            </span>
          </Tooltip>
          <Tooltip title={canSave ? '' : [...pageProblems, ...problems.map(p => p.message)].slice(0, 3).join(' ')}>
            <span>
              <Button variant="contained" startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon />}
                disabled={!canSave} onClick={save} data-testid="canvas-save">Save</Button>
            </span>
          </Tooltip>
        </Stack>
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 1 }}
          data-testid="canvas-param-bar"
          onDragOver={e => { if (e.dataTransfer.types.includes(FIELD_MIME)) e.preventDefault(); }}
          onDrop={e => { const c = cols.get(Number(e.dataTransfer.getData(FIELD_MIME))); if (c) { e.preventDefault(); addAsked(c); } }}>
          <Typography variant="body2" color="text.secondary">Asked when the report runs:</Typography>
          {params.length === 0 && <Typography variant="caption" color="text.secondary">nothing -- drag a field here</Typography>}
          {params.map(p => (
            <Chip key={p.name} size="small"
              label={`${p.label || p.name}: ${p.source_column ? 'as in the query' : 'all'}`}
              title={p.source_column ? 'Filters at the source: the value goes into the dataset\'s own query' : 'Filters the results'}
              onDelete={() => removeParam(p.name)}
              data-testid={`canvas-param-${p.name}`} color={p.id ? 'default' : 'primary'} variant={p.id ? 'filled' : 'outlined'} />
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={() => { setAskCol(null); setAskOpen(true); }}
            data-testid="canvas-ask">Ask for a value</Button>
          {/* 2026-10-29 -- the dataset's own conditions, each one click from being asked (filter at the source) */}
          {sourceFilters.filter(sf => !params.some(p => p.source_column === sf.key)).map(sf => (
            <Tooltip key={sf.key} title={`${sf.words}. Runs at the source.`}>
              <Chip size="small" variant="outlined" icon={<AddIcon />} clickable onClick={() => addSourceAsked(sf)}
                label={`${sf.column} (at the source)`} data-testid={`canvas-source-${sf.key}`} />
            </Tooltip>
          ))}
          <Box sx={{ flex: 1 }} />
          {filters.length > 0 && <Typography variant="body2" color="text.secondary">Fixed filters:</Typography>}
          {filters.map((f, i) => {
            const c = cols.get(Number(f.column_id));
            const v = Array.isArray(f.value) ? f.value.join(', ') : f.value;
            return (
              <Chip key={i} size="small" variant="outlined" data-testid={`canvas-filter-${i}`}
                label={`${c?.label ?? `#${f.column_id}`} ${f.operator || '='} ${v ?? ''}${f.value2 != null ? ` and ${f.value2}` : ''}`}
                onDelete={() => setFilters(fs => fs.filter((_, j) => j !== i))} />
            );
          })}
        </Stack>
        {paramsDirty && <Typography variant="caption" color="text.secondary">New questions are added when you save.</Typography>}
      </Paper>

      {message && <Alert severity={message.kind} sx={{ mb: 1.5 }} onClose={() => setMessage(null)} data-testid="canvas-message">{message.text}</Alert>}
      {pageProblems.length > 0 && canvas.tiles.length > 0 && (
        <Alert severity="warning" sx={{ mb: 1.5 }} data-testid="canvas-page-problems">{pageProblems.join(' ')}</Alert>
      )}
      {previewExec && (
        <Alert severity="info" sx={{ mb: 1.5 }} onClose={() => setPreviewExec(null)} data-testid="canvas-previewing">
          Showing a preview run{previewExec.total != null ? ` (${previewExec.total.toLocaleString()} rows)` : ''}. Nothing has been saved by the preview.
          {previewIsStale && <strong> The canvas changed since -- press Preview again to see every tile.</strong>}
        </Alert>
      )}

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '260px 1fr 280px' }, gap: 1.5, alignItems: 'start' }}>
        {/* fields */}
        <Paper variant="outlined" sx={{ p: 1, maxHeight: '75vh', overflow: 'auto' }} data-testid="canvas-fields">
          <TextField size="small" fullWidth placeholder="Search fields" value={fieldQuery} onChange={e => setFieldQuery(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
          {!datasetId && <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>Pick the data first.</Typography>}
          {dims.length > 0 && <Typography variant="overline" color="text.secondary">Fields</Typography>}
          <List dense disablePadding>{dims.map(fieldItem)}</List>
          {meas.length > 0 && <Typography variant="overline" color="text.secondary">Measures</Typography>}
          <List dense disablePadding>{meas.map(fieldItem)}</List>
          {datasetId && fields.length === 0 && <Typography variant="body2" color="text.secondary">No field matches.</Typography>}
        </Paper>

        {/* canvas */}
        <Box>
          <CanvasThemeContext.Provider value={resolveTheme(report?.layout_config)}>
          <CanvasCompareContext.Provider value={compareFrom(canvas, params.map(p => ({ name: p.name, value: paramValues[p.name], label: p.label })), params)}>
          <CanvasBandContext.Provider value={{
            reportName: name, reportCode: canvas.report_code ?? null,
            parameters: previewExec ? params.filter(p => p.id).map(p => ({ name: p.name, label: p.label || p.name, value: paramValues[p.name] })) : null,
          }}>
          <ReportCanvasView canvas={canvas} reportId={report?.id ?? null} cols={cols} grouped={grouped} editable
            selectedId={selectedId} onSelect={setSelectedId} onLayout={onLayout} onDropField={onDropField}
            onPagesChange={pages => setCanvas(c => { const { pages: _p, ...rest } = c; return pages && pages.length ? { ...rest, pages } : rest; })}
            problems={problemsByTile} staleFields={staleFields}
            reportTable={<Typography variant="body2" color="text.secondary">
              The report&apos;s own table: {reportTableCols.filter(i => cols.has(i)).map(i => cols.get(i)!.label).join(', ') || 'no columns yet'}.
              It pages through every row when the report runs.
            </Typography>}
            run={{ executionId: previewExec?.id ?? null, totalRows: previewExec?.total ?? null, truncated: previewExec?.truncated ?? false }} />
          </CanvasBandContext.Provider>
          </CanvasCompareContext.Provider>
          </CanvasThemeContext.Provider>
        </Box>

        {/* properties */}
        <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="canvas-properties">
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Add a tile</Typography>
          <Stack direction="row" flexWrap="wrap" gap={0.5} sx={{ mb: 1.5 }}>
            {ADDABLE.map(k => (
              <Button key={k} size="small" variant="outlined" onClick={() => addTile(k)} data-testid={`canvas-add-${k}`}
                disabled={k === 'report' && hasReportTile}>{KIND_LABEL[k]}</Button>
            ))}
          </Stack>
          <CanvasLinksSwitch canvas={canvas} onChange={v => setCanvas(c => setCanvasLinks(c, v))} />
          <DrillSettings canvas={canvas} columns={columns} onChange={setCanvas} />
          <FormControlLabel sx={{ mt: 1 }} control={<Switch checked={viewersMayRearrange} onChange={e => setViewersMayRearrange(e.target.checked)}
            slotProps={{ input: { 'data-testid': 'viewers-may-rearrange' } as any }} />}
            label="Viewers may rearrange the tiles and pick their fields (from the approved fields above); each keeps their own layout" />
          <CompareSettings canvas={canvas} params={params} onChange={setCanvas} />
          <Divider sx={{ mb: 1.5 }} />
          {!selected ? (
            <Typography variant="body2" color="text.secondary">Click a tile to change it.</Typography>
          ) : (
            <TileProperties tile={selected} cols={cols} columns={columns} grouped={grouped}
              extra={{ datasetId, paramNames: params.map(p => ({ name: p.name, label: p.label || p.name, type: p.parameter_type })), hasCompare: !!canvas.compare,
                       pages: canvas.pages, pageOf: (id: string) => pageOfTile(canvas, id),
                       movePage: (id: string, k: number) => setCanvas(c => ({ ...c, pages: (c.pages ?? []).map((p, i) => ({ ...p, tiles: i === k ? [...p.tiles.filter(x => x !== id), id] : p.tiles.filter(x => x !== id) })) })) }}
              reportTableCols={reportTableCols} setReportTableCols={setReportTableCols}
              onChange={f => updateTile(selected.id, f)}
              onDelete={() => { setCanvas(c => ({ ...c, tiles: c.tiles.filter(t => t.id !== selected.id) })); setSelectedId(null); }}
              problems={problemsByTile[selected.id] ?? []} />
          )}
          <Divider sx={{ my: 1.5 }} /><Box ref={actionsRef} />
          <CanvasActionsEditor reportId={report?.id ?? null} canvas={canvas} setCanvas={setCanvas} cols={cols} parameters={params} reportCode={report?.layout_config?.report_code}
            reportDatasetId={report?.dataset_id ?? null} />
        </Paper>
      </Box>

      {/* + Ask for a value */}
      <AppDialog open={askOpen}
        onClose={() => setAskOpen(false)}
        size="xs"
        title="Ask for a value when the report runs"
        actions={<>
          <Button onClick={() => setAskOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!askCol} onClick={() => { if (askCol) addAsked(askCol); setAskOpen(false); }}>Add</Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            The person running the report picks the value from the data -- a date field takes any date on a
            calendar. Left empty, the report shows every value.
          </Typography>
          <Autocomplete options={columns} value={askCol} onChange={(_, v) => setAskCol(v)}
            getOptionLabel={c => c.label} renderInput={p => <TextField {...p} label="Field" autoFocus />} />
      </AppDialog>

      {/* Preview with values */}
      <AppDialog open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        size="sm"
        title="Preview with values"
        actions={<>
          <Button onClick={() => setPreviewOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={preview} disabled={previewing} data-testid="canvas-preview-run">Run preview</Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            Choose values for the saved questions (empty = every value). The preview runs the saved report with this canvas; nothing is saved.
          </Typography>
          <Stack spacing={1.5}>
            {params.filter(p => p.id).map(p => (
              <ReportParamControl key={p.id} param={p} params={params.filter(x => x.id)} values={paramValues}
                onValues={setParamValues}
                fetchValues={(body: any) => api.getBusinessReportParamValues(report.id, body)}
                showRequiredError={false} />
            ))}
          </Stack>
      </AppDialog>
    </Box>
  );
}

function TileProperties({ tile, cols, columns, grouped, reportTableCols, setReportTableCols, onChange, onDelete, problems, extra }: {
  tile: CanvasTile; cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; grouped: boolean;
  extra?: { datasetId: number | null; paramNames: { name: string; label: string; type?: string }[]; hasCompare?: boolean;
            pages?: CanvasPage[]; pageOf?: (id: string) => number; movePage?: (id: string, k: number) => void };
  reportTableCols: number[]; setReportTableCols: (f: (r: number[]) => number[]) => void;
  onChange: (f: (t: CanvasTile) => CanvasTile) => void; onDelete: () => void; problems: string[];
}) {
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const fieldPicker = (value: number | null, set: (v: number | null) => void, lab: string, testid: string, allowNone = true) => (
    <TextField select size="small" fullWidth label={lab} value={value ?? ''} onChange={e => set(e.target.value === '' ? null : Number(e.target.value))}
      inputProps={{ 'data-testid': testid }}>
      {allowNone && <MenuItem value="">None</MenuItem>}
      {columns.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
    </TextField>
  );
  return (
    <Stack spacing={1.25} data-testid="tile-properties">
      <Stack direction="row" alignItems="center">
        <Typography variant="subtitle2" sx={{ flex: 1 }}>{tileName(tile, cols)}</Typography>
        <Tooltip title="Remove this tile"><IconButton size="small" onClick={onDelete} aria-label="Remove this tile" data-testid="tile-delete"><DeleteIcon fontSize="small" /></IconButton></Tooltip>
      </Stack>
      {problems.map((p, i) => <Alert key={i} severity="error" sx={{ py: 0 }}>{p}</Alert>)}
      {!['report', 'outline', 'band', 'insight'].includes(tile.kind) && (
        <TextField select size="small" label="Show as" value={tile.kind} onChange={e => onChange(t => changeKind(t, e.target.value as TileKind))}
          inputProps={{ 'data-testid': 'tile-kind' }}>
          {SHOW_AS.map(k => <MenuItem key={k} value={k}>{KIND_LABEL[k]}</MenuItem>)}
        </TextField>
      )}
      <TextField size="small" label="Title" placeholder={tileName({ ...tile, title: '' }, cols)} value={tile.title}
        onChange={e => onChange(t => ({ ...t, title: e.target.value.slice(0, 200) }))} inputProps={{ 'data-testid': 'tile-title' }} />
      <TileLinkedSwitch tile={tile} onChange={v => onChange(t => setTileLinked(t, v))} />
      {(extra?.pages?.length ?? 0) > 0 && (
        <TextField select size="small" label="On page" value={extra!.pageOf(tile.id)} inputProps={{ 'data-testid': 'tile-page' }}
          onChange={e => extra!.movePage(tile.id, Number(e.target.value))}>
          {extra!.pages!.map((p, i) => <MenuItem key={p.id} value={i}>{p.title || `Page ${i + 1}`}</MenuItem>)}
        </TextField>
      )}

      {tile.kind === 'report' && (
        <>
          <Typography variant="caption" color="text.secondary">The report&apos;s own table pages through every row of the report. When a value is clicked on another tile, it shows only the matching rows.</Typography>
          <Autocomplete multiple size="small" options={columns.map(c => c.id)} value={reportTableCols.filter(i => cols.has(i))}
            getOptionLabel={i => label(i)} onChange={(_, v) => setReportTableCols(() => v)}
            renderInput={p => <TextField {...p} label="Its columns" />} />
        </>
      )}

      {(tile.kind === 'table' || tile.kind === 'pivot') && (
        <Autocomplete multiple size="small" options={columns.filter(c => !isMeasureColumn(c)).map(c => c.id)}
          value={tile.dimensions} getOptionLabel={i => label(i)}
          onChange={(_, v) => onChange(t => ({ ...t, dimensions: v }))}
          renderInput={p => <TextField {...p} label={tile.kind === 'pivot' ? 'Rows' : 'Columns'} />} />
      )}
      {(isChart(tile.kind) || tile.kind === 'heatmap') &&
        fieldPicker(tile.dimensions[0] ?? null, v => onChange(t => ({ ...t, dimensions: v == null ? [] : [v] })),
          tile.kind === 'heatmap' ? 'Rows' : tile.kind === 'scatter' || tile.kind === 'bubble' ? 'Each point is a' : 'Category',
          'tile-category', false)}
      {(tile.kind === 'pivot' || tile.kind === 'heatmap') &&
        fieldPicker(tile.series, v => onChange(t => ({ ...t, series: v })), 'Spread across (columns)', 'tile-series')}
      {SERIES_CHARTS.includes(tile.kind) && tile.measures.length <= 1 &&
        fieldPicker(tile.series, v => onChange(t => ({ ...t, series: v })), 'Split into series (optional)', 'tile-series')}

      {tile.kind === 'outline' && <OutlineTileSettings tile={tile} cols={cols} columns={columns} datasetId={extra?.datasetId ?? null} onChange={onChange} />}
      {tile.kind === 'band' && <BandTileSettings tile={tile} paramNames={extra?.paramNames ?? []} onChange={onChange} />}
      {tile.kind === 'insight' && <InsightTileEditor tile={tile} columns={columns} cols={cols} grouped={grouped} onChange={onChange} />}
      {tile.kind !== 'report' && tile.kind !== 'band' && tile.kind !== 'insight' && (
        <Box>
          <Typography variant="caption" color="text.secondary">{tile.kind === 'number' ? 'Value' : 'Values'}</Typography>
          {tile.measures.map((m, i) => {
            const allowed = allowedAggregations(cols.get(m.column_id), grouped);
            return (
              <Stack key={i} direction="row" spacing={0.5} alignItems="center" sx={{ mt: 0.5 }}>
                <Typography variant="body2" sx={{ flex: 1 }} noWrap title={label(m.column_id)}>{label(m.column_id)}</Typography>
                <TextField size="small" label="Shown as" value={m.label ?? ''} sx={{ width: 130 }} placeholder={label(m.column_id)}
                  onChange={e => onChange(t => ({ ...t, measures: t.measures.map((x, j) => j === i ? { ...x, label: e.target.value || undefined } : x) }))}
                  inputProps={{ 'data-testid': `tile-measure-label-${i}`, maxLength: 60 }} />
                <TextField select size="small" label="Add up as" value={m.aggregation} sx={{ width: 150 }}
                  onChange={e => onChange(t => ({ ...t, measures: t.measures.map((x, j) => j === i ? { ...x, aggregation: e.target.value as Aggregation } : x) }))}
                  inputProps={{ 'data-testid': `tile-agg-${i}` }}>
                  {(allowed.includes(m.aggregation) ? allowed : [m.aggregation, ...allowed]).map(a => (
                    <MenuItem key={a} value={a} disabled={!allowed.includes(a)}>{AGG_LABEL[a] ?? a}</MenuItem>
                  ))}
                </TextField>
                <IconButton size="small" aria-label={`Remove ${label(m.column_id)}`}
                  onClick={() => onChange(t => ({ ...t, measures: t.measures.filter((_, j) => j !== i) }))}><DeleteIcon fontSize="small" /></IconButton>
              </Stack>
            );
          })}
          {tile.measures.length < valueLimit(tile.kind) && (
            <TextField select size="small" fullWidth value="" sx={{ mt: 1 }}
              label={tile.kind === 'scatter' || tile.kind === 'bubble'
                ? ['Across (x)', 'Up (y)', 'Bubble size'][tile.measures.length] : tile.kind === 'combo' && tile.measures.length > 0
                ? 'Add a line' : 'Add a value'}
              onChange={e => {
                const c = cols.get(Number(e.target.value));
                if (!c) return;
                const v = { column_id: c.id, aggregation: (SUM_ONLY.includes(tile.kind) ? 'sum' : defaultAggregation(c, grouped)) as Aggregation };
                onChange(t => ({ ...t, measures: valueLimit(t.kind) === 1 ? [v] : [...t.measures, v],
                                 series: t.measures.length >= 1 && SERIES_CHARTS.includes(t.kind) ? null : t.series }));
              }}
              inputProps={{ 'data-testid': 'tile-add-value' }}>
              {columns.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
            </TextField>
          )}
          {grouped && (
            <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 0.5 }}>
              This report&apos;s rows are already added up, so only the exact ways to add them up again are offered.
            </Typography>
          )}
        </Box>
      )}

      {tile.kind === 'number' && <KpiTileSettings tile={tile} cols={cols} columns={columns} grouped={grouped} hasCompareParameter={!!extra?.hasCompare} onChange={onChange} />}
      {tile.kind !== 'report' && tile.kind !== 'band' && <TileFormatSettings tile={tile} cols={cols} onChange={onChange} />}
      {isChart(tile.kind) && (
        <>
          <TextField select size="small" label="Order" value={tile.sort ? `${tile.sort.by}:${tile.sort.dir}` : 'category'}
            onChange={e => {
              const v = e.target.value;
              onChange(t => ({ ...t, sort: v === 'category' ? null : { by: 'measure', dir: v.endsWith('asc') ? 'asc' : 'desc' } }));
            }} inputProps={{ 'data-testid': 'tile-sort' }}>
            <MenuItem value="measure:desc">Largest first</MenuItem>
            <MenuItem value="measure:asc">Smallest first</MenuItem>
            <MenuItem value="category">By category</MenuItem>
          </TextField>
          {['line', 'area', 'bar', 'column', 'table'].includes(tile.kind) && (extra?.paramNames ?? []).length > 0 && (
            <TextField select size="small" fullWidth sx={{ mt: 1 }} label="Trend over the period parameter" value={tile.trend_of ?? ''}
              onChange={e => onChange(t => ({ ...t, trend_of: e.target.value || undefined }))} inputProps={{ 'data-testid': 'tile-trend-of' }}
              helperText="The tile follows the period the viewer picks (a month of days, 12 month-ends, 3 year-ends) and says so">
              <MenuItem value="">No</MenuItem>
              {(extra?.paramNames ?? []).map((p: any) => <MenuItem key={p.name} value={p.name}>{p.label}</MenuItem>)}
            </TextField>
          )}
          {LABEL_KINDS.includes(tile.kind) && (
            <TextField select size="small" fullWidth sx={{ mt: 1 }} label="Words on the marks" value={tile.labels ?? 'none'} inputProps={{ 'data-testid': 'tile-labels' }}
              onChange={e => onChange(t => { const { labels: _l, ...rest } = t; return e.target.value === 'none' ? rest : { ...rest, labels: e.target.value as LabelMode }; })}>
              {LABEL_MODES.filter(m => m !== 'percent' || PERCENT_KINDS.includes(tile.kind)).map(m => <MenuItem key={m} value={m}>{LABEL_WORDS[m]}</MenuItem>)}
            </TextField>
          )}
          {tile.kind === 'donut' && (
            <FormControlLabel sx={{ mt: 0.5 }} control={<Switch size="small" checked={tile.centre === 'total'} slotProps={{ input: { 'data-testid': 'tile-centre' } as any }}
              onChange={e => onChange(t => { const { centre: _c, ...rest } = t; return e.target.checked ? { ...rest, centre: 'total' } : rest; })} />}
              label="Show the total in the centre" />
          )}
          {OVERLAY_KINDS.includes(tile.kind) && tile.series == null && !!extra?.hasCompare && (
            <FormControlLabel sx={{ mt: 0.5 }} control={<Switch size="small" checked={tile.compare_overlay === true} slotProps={{ input: { 'data-testid': 'tile-overlay' } as any }}
              onChange={e => onChange(t => { const { compare_overlay: _o, ...rest } = t; return e.target.checked ? { ...rest, compare_overlay: true } : rest; })} />}
              label="Draw the two dates: B as the marks, A as a dotted line" />
          )}
          {['pie', 'donut', 'treemap'].includes(tile.kind) && (
            <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
              <TextField select size="small" label="The rest" value={tile.other_mode ?? 'fold'} sx={{ flex: 1 }}
                onChange={e => onChange(t => ({ ...t, other_mode: e.target.value as any }))} inputProps={{ 'data-testid': 'tile-other-mode' }}>
                <MenuItem value="fold">One muted part, "Everything else"</MenuItem>
                <MenuItem value="none">Not drawn (the top N only)</MenuItem>
              </TextField>
              <TextField size="small" type="number" label="At most, of the picture (%)" value={Math.round((tile.other_max_share ?? 0.25) * 100)} sx={{ width: 170 }}
                disabled={(tile.other_mode ?? 'fold') === 'none'} inputProps={{ min: 5, max: 90, 'data-testid': 'tile-other-share' }}
                onChange={e => onChange(t => ({ ...t, other_max_share: Math.min(90, Math.max(5, Number(e.target.value) || 25)) / 100 }))} />
            </Stack>
          )}
          <TextField size="small" type="number" label="How many to draw" value={tile.top_n ?? 25}
            inputProps={{ min: 1, max: maxPointsOf(tile.kind, tile.series), 'data-testid': 'tile-topn' }}
            helperText={`1 to ${maxPointsOf(tile.kind, tile.series).toLocaleString('en-US')}. The rest are counted and said under the chart.`}
            onChange={e => onChange(t => ({ ...t, top_n: Math.max(1, Math.min(maxPointsOf(t.kind, t.series), Math.floor(Number(e.target.value) || 1))) }))} />
        </>
      )}
    </Stack>
  );
}
