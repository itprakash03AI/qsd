/**
 * QueryTabManager — Tabbed query editor wrapper (like Starburst / Oracle Toad).
 * Each tab is an independent CompleteQueryBuilder instance.
 *
 * Phase 142 — tab list + active tab + per-tab snapshots persist to the
 * SERVER (not just sessionStorage), so tabs come back after refresh,
 * device switch, cookie clear, or pod restart.
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Chip, IconButton, Tooltip, TextField, Menu, MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  Close as CloseIcon,
  Edit as EditIcon,
  FiberManualRecord as DotIcon,
} from '@mui/icons-material';
import CompleteQueryBuilder from './CompleteQueryBuilder';
import { useServerDraft } from '../hooks/useServerDraft';
import { clickable } from '../utils/clickable';

// ── Types ────────────────────────────────────────────────────────────────────

interface TabSnapshot {
  connectionId: number | null;
  queryConfig: any;
  queryMode: 'visual' | 'sql';
  rawSql: string;
  enableStreaming: boolean;
  streamBgDownload: boolean;
  editingQueryId: string | null;
  editingQueryName: string;
  resultsExecutionId: string | null;
  streamingSource: any;
}

interface TabState {
  id: string;
  name: string;
  dirty: boolean;
  snapshot: TabSnapshot | null;
}

const STORAGE_KEY = 'qs_query_tabs';   // legacy sessionStorage key — used for migration only
const MAX_TABS = 10;
const _TABS_DRAFT_KEY = 'cqb.tabs';     // server-side draft key

const makeId = () => `tab-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

const defaultTab = (): TabState => ({
  id: makeId(),
  name: 'New Query',
  dirty: false,
  snapshot: null,
});

// ── Component ────────────────────────────────────────────────────────────────

const QueryTabManager = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Phase 142 — server-side draft replaces sessionStorage.  Tabs come back
  // after refresh / device switch / cookie clear.  Fallback to in-memory
  // only when /api/user/drafts is disabled or unreachable.
  type TabsBundle = { tabs: TabState[]; activeTabId: string | null };
  const [tabsBundle, setTabsBundle, tabsMeta] =
    useServerDraft<TabsBundle>(_TABS_DRAFT_KEY, { tabs: [], activeTabId: null });
  const tabs = tabsBundle.tabs;
  const activeTabId = tabsBundle.activeTabId;
  const setTabs = useCallback((next: TabState[] | ((prev: TabState[]) => TabState[])) => {
    setTabsBundle(prev => ({
      ...prev,
      tabs: typeof next === 'function' ? (next as (p: TabState[]) => TabState[])(prev.tabs) : next,
    }));
  }, [setTabsBundle]);
  const setActiveTabId = useCallback((id: string | null) => {
    setTabsBundle(prev => ({ ...prev, activeTabId: id }));
  }, [setTabsBundle]);

  const [renameTabId, setRenameTabId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [contextMenu, setContextMenu] = useState<{ anchorEl: HTMLElement; tabId: string } | null>(null);
  const initialized = useRef(false);
  const snapshotRef = useRef<Record<string, TabSnapshot | null>>({});

  // ── Initialize: wait for server-side draft load, then either restore
  //    or open a default tab.  Falls back to legacy sessionStorage for
  //    seamless migration from pre-Phase-142 sessions.
  useEffect(() => {
    if (initialized.current) return;
    if (tabsMeta.loading) return;
    initialized.current = true;

    // 1. Server-side draft restored already by useServerDraft?
    if (tabsBundle.tabs.length > 0) {
      for (const t of tabsBundle.tabs) {
        snapshotRef.current[t.id] = t.snapshot;
      }
      if (!tabsBundle.activeTabId) {
        setActiveTabId(tabsBundle.tabs[0].id);
      }
      return;
    }

    // 2. Migration: legacy sessionStorage from previous releases
    try {
      const saved = sessionStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.tabs?.length > 0) {
          setTabsBundle({
            tabs: parsed.tabs,
            activeTabId: parsed.activeTabId || parsed.tabs[0].id,
          });
          for (const t of parsed.tabs) {
            snapshotRef.current[t.id] = t.snapshot;
          }
          sessionStorage.removeItem(STORAGE_KEY);
          return;
        }
      }
    } catch { /* legacy parse error */ }

    // 3. First-run: one empty tab
    const tab = defaultTab();
    setTabsBundle({ tabs: [tab], activeTabId: tab.id });
  }, [tabsBundle.tabs, tabsBundle.activeTabId, tabsMeta.loading, setActiveTabId, setTabsBundle]);

  // ── Sync snapshots into the bundle so server-side persistence captures them ──
  useEffect(() => {
    if (tabs.length === 0) return;
    // Merge snapshots BY ID into the LATEST bundle (2026-09-29).  This used to
    // replace the list with one computed from this render, so a tab added in
    // between was dropped while activeTabId still named it -- a blank builder.
    setTabsBundle(prev => {
      let changed = false;
      const merged = prev.tabs.map(t => {
        const snap = snapshotRef.current[t.id] ?? t.snapshot;
        if (snap === t.snapshot) return t;
        changed = true;
        return { ...t, snapshot: snap };
      });
      return changed ? { ...prev, tabs: merged } : prev;
    });
  }, [tabs, setTabsBundle]);

  // 2026-09-29 -- an activeTabId that names NO tab hid every tab: the builder
  // rendered blank, and (server-side draft) stayed blank for that user on every
  // visit.  Render the first tab in that case, and store the repair.
  useEffect(() => {
    if (tabsMeta.loading || tabs.length === 0) return;
    if (!tabs.some(t => t.id === activeTabId)) setActiveTabId(tabs[0].id);
  }, [tabs, activeTabId, tabsMeta.loading, setActiveTabId]);

  // ── Handle openLocalTable navigation from LocalTablesPage ────────────
  useEffect(() => {
    const tableName = location.state?.openLocalTable;
    if (!tableName) return;
    const path = `__local__:${tableName}`;
    // Check if a tab already has this local table open
    const existing = tabs.find(t =>
      (t.snapshot?.queryConfig?.files || []).includes(path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: tableName,
      dirty: false,
      snapshot: {
        connectionId: null,
        queryConfig: { files: [path], joins: [], columns: [], filters: [], filter_logic: 'AND' },
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: null,
        editingQueryName: '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.openLocalTable]); // eslint-disable-line

  // ── Handle openMaterializedView navigation from MaterializedViewsPage ─
  useEffect(() => {
    const mvName = location.state?.openMaterializedView;
    if (!mvName) return;
    const path = `__materialized__:${mvName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.queryConfig?.files || []).includes(path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: mvName,
      dirty: false,
      snapshot: {
        connectionId: null,
        queryConfig: { files: [path], joins: [], columns: [], filters: [], filter_logic: 'AND' },
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: null,
        editingQueryName: '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.openMaterializedView]); // eslint-disable-line

  // ── Handle loadQuery from SavedQueries navigation ─────────────────────
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    // Check if this query is already open in a tab
    const existing = tabs.find(t =>
      t.snapshot?.editingQueryId === loadQuery.id ||
      t.snapshot?.editingQueryId === String(loadQuery.id)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    // Open in a new tab
    const newTab: TabState = {
      id: makeId(),
      name: loadQuery.name || 'Loaded Query',
      dirty: false,
      snapshot: {
        connectionId: loadQuery.query_config?.connection_id || null,
        queryConfig: loadQuery.query_config,
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: String(loadQuery.id),
        editingQueryName: loadQuery.name || '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.loadQuery]); // eslint-disable-line

  // ── Tab operations ────────────────────────────────────────────────────
  // The tab list and the active id change in ONE update, so no interleaving
  // can leave the active id naming a tab the list no longer has.
  const createTab = useCallback(() => {
    if (tabs.length >= MAX_TABS) return;
    const tab = defaultTab();
    setTabsBundle(prev => ({ tabs: [...prev.tabs, tab], activeTabId: tab.id }));
  }, [tabs.length, setTabsBundle]);

  const closeTab = useCallback((id: string) => {
    setTabsBundle(prev => {
      const next = prev.tabs.filter(t => t.id !== id);
      let active = prev.activeTabId;
      if (next.length === 0) {
        const tab = defaultTab();
        next.push(tab);
        active = tab.id;
      } else if (active === id || !next.some(t => t.id === active)) {
        // Activate the adjacent tab
        const idx = prev.tabs.findIndex(t => t.id === id);
        active = (next[idx > 0 ? idx - 1 : 0] || next[0]).id;
      }
      return { tabs: next, activeTabId: active };
    });
    delete snapshotRef.current[id];
  }, [setTabsBundle]);

  const switchTab = useCallback((id: string) => {
    if (id === activeTabId) return;
    setActiveTabId(id);
  }, [activeTabId]);

  const renameTab = useCallback((id: string, name: string) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, name: name || 'Untitled' } : t));
  }, []);

  // ── Callbacks from CompleteQueryBuilder ────────────────────────────────
  const handleSnapshotChange = useCallback((tabId: string, snapshot: TabSnapshot) => {
    snapshotRef.current[tabId] = snapshot;
  }, []);

  const handleDirtyChange = useCallback((tabId: string, dirty: boolean) => {
    setTabs(prev => prev.map(t => t.id === tabId ? { ...t, dirty } : t));
  }, []);

  const handleNameChange = useCallback((tabId: string, name: string) => {
    if (name) setTabs(prev => prev.map(t => t.id === tabId ? { ...t, name } : t));
  }, []);

  // ── Render ────────────────────────────────────────────────────────────
  const shownTabId = tabs.some(t => t.id === activeTabId) ? activeTabId : (tabs[0]?.id ?? null);
  const activeTab = tabs.find(t => t.id === shownTabId);

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* ── Tab Bar ── */}
      <Box sx={{
        display: 'flex', alignItems: 'center', gap: 0,
        borderBottom: 1, borderColor: 'divider',
        bgcolor: 'background.paper', px: 0.5, minHeight: 34,
        overflowX: 'auto', flexShrink: 0,
        '&::-webkit-scrollbar': { height: 3 },
        '&::-webkit-scrollbar-thumb': { bgcolor: 'divider', borderRadius: 2 },
      }}>
        {tabs.map(tab => (
          <Box
            key={tab.id}
            onContextMenu={(e) => { e.preventDefault(); setContextMenu({ anchorEl: e.currentTarget, tabId: tab.id }); }}
            sx={{
              display: 'flex', alignItems: 'center', gap: 0.3,
              px: 1.2, py: 0.4, cursor: 'pointer', userSelect: 'none',
              borderBottom: tab.id === activeTabId ? '2px solid' : '2px solid transparent',
              borderBottomColor: tab.id === activeTabId ? 'primary.main' : 'transparent',
              bgcolor: tab.id === activeTabId ? 'action.selected' : 'transparent',
              '&:hover': { bgcolor: 'action.hover' },
              borderRight: 1, borderRightColor: 'divider',
              minWidth: 'fit-content', maxWidth: 200,
              transition: 'background-color 0.15s',
            }}
            {...clickable(() => switchTab(tab.id), { label: tab.name, pressed: tab.id === activeTabId })}
          >
            {tab.dirty && (
              <DotIcon sx={{ fontSize: 8, color: 'warning.main', mr: 0.3 }} />
            )}
            {renameTabId === tab.id ? (
              <TextField
                size="small" variant="standard" autoFocus
                value={renameValue}
                onChange={e => setRenameValue(e.target.value)}
                onBlur={() => { renameTab(tab.id, renameValue); setRenameTabId(null); }}
                onKeyDown={e => {
                  if (e.key === 'Enter') { renameTab(tab.id, renameValue); setRenameTabId(null); }
                  if (e.key === 'Escape') setRenameTabId(null);
                }}
                inputProps={{ style: { fontSize: 12, padding: '0 4px', width: 100 } }}
                sx={{ '& .MuiInput-underline:before': { borderBottom: 'none' } }}
              />
            ) : (
              <Typography
                variant="caption" noWrap
                sx={{
                  fontSize: 12, fontWeight: tab.id === activeTabId ? 600 : 400,
                  color: tab.id === activeTabId ? 'text.primary' : 'text.secondary',
                  maxWidth: 150,
                }}
                onDoubleClick={() => { setRenameTabId(tab.id); setRenameValue(tab.name); }}
              >
                {tab.name}
              </Typography>
            )}
            {tabs.length > 1 && (
              <IconButton
                size="small"
                aria-label={`Close tab ${tab.name}`}
                onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                sx={{ p: 0.15, ml: 0.3, opacity: 0.5, '&:hover': { opacity: 1 } }}
              >
                <CloseIcon sx={{ fontSize: 13 }} />
              </IconButton>
            )}
          </Box>
        ))}

        {/* Add tab button */}
        <Tooltip title={tabs.length >= MAX_TABS ? `Max ${MAX_TABS} tabs` : 'New query tab'}>
          <span>
            <IconButton size="small" onClick={createTab} disabled={tabs.length >= MAX_TABS}
              aria-label="New query tab"
              sx={{ mx: 0.5, p: 0.3 }}>
              <AddIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </span>
        </Tooltip>
      </Box>

      {/* ── Context Menu ── */}
      <Menu
        open={!!contextMenu}
        onClose={() => setContextMenu(null)}
        anchorEl={contextMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => {
          if (contextMenu) { setRenameTabId(contextMenu.tabId); setRenameValue(tabs.find(t => t.id === contextMenu.tabId)?.name || ''); }
          setContextMenu(null);
        }}>
          <EditIcon sx={{ fontSize: 14, mr: 1 }} /> Rename
        </MenuItem>
        <MenuItem dense onClick={() => { createTab(); setContextMenu(null); }}>
          <AddIcon sx={{ fontSize: 14, mr: 1 }} /> New Tab
        </MenuItem>
        {tabs.length > 1 && (
          <MenuItem dense onClick={() => { if (contextMenu) closeTab(contextMenu.tabId); setContextMenu(null); }}>
            <CloseIcon sx={{ fontSize: 14, mr: 1 }} /> Close
          </MenuItem>
        )}
      </Menu>

      {/* ── All Tab Contents (kept mounted, stacked via absolute positioning) ── */}
      {/* visibility: hidden (not display: none) keeps full dimensions so             @tanstack/react-virtual can measure rows correctly in hidden tabs */}
      <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {tabs.map(tab => {
          const active = tab.id === shownTabId;
          return (
            <Box
              key={tab.id}
              sx={{
                position: 'absolute',
                top: 0, left: 0, right: 0, bottom: 0,
                visibility: active ? 'visible' : 'hidden',
                zIndex: active ? 1 : 0,
              }}
            >
              <CompleteQueryBuilder
                tabId={tab.id}
                isActive={active}
                initialSnapshot={tab.snapshot || snapshotRef.current[tab.id]}
                onSnapshotChange={(snapshot) => handleSnapshotChange(tab.id, snapshot)}
                onDirtyChange={(dirty) => handleDirtyChange(tab.id, dirty)}
                onNameChange={(name) => handleNameChange(tab.id, name)}
              />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default QueryTabManager;
