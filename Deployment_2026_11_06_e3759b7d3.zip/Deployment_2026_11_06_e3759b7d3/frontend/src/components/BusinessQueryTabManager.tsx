/**
 * BusinessQueryTabManager — Tabbed wrapper for BusinessQueryBuilder.
 * Mirrors QueryTabManager (CQB) but wraps BQB instances.
 *
 * Phase 133-I round 24 — tabs persist in localStorage (was
 * sessionStorage).  sessionStorage gets wiped on browser-close, so
 * loaded queries vanished on next login.  localStorage survives
 * logout/login and browser restarts — the user expects their work
 * to still be there when they come back.
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, IconButton, Tooltip, TextField, Menu, MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  Close as CloseIcon,
  Edit as EditIcon,
  FiberManualRecord as DotIcon,
} from '@mui/icons-material';
import BusinessQueryBuilder from './BusinessQueryBuilder';
import type { BqbTabSnapshot } from './business-query/types';
import { safeStringify } from './business-query/utils';
import { clickable } from '../utils/clickable';

export type { BqbTabSnapshot };

interface TabState {
  id: string;
  name: string;
  dirty: boolean;
  snapshot: BqbTabSnapshot | null;
}

const STORAGE_KEY = 'qs_bqb_tabs';
const MAX_TABS = 10;

const makeId = () => `bqb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

/**
 * 2026-10-07 (F6, the BQB audit) -- every new tab read "New Query", so two
 * open queries were indistinguishable in the tab bar.  A new tab is named
 * `Query N`, N the first number no open tab already uses.
 */
const DEFAULT_TAB_NAME_RE = /^(New Query|Query \d+)$/;

export const nextQueryTabName = (names: string[]): string => {
  const taken = new Set(names);
  let n = names.length + 1;
  while (taken.has(`Query ${n}`)) n++;
  return `Query ${n}`;
};

/** Tabs restored from storage (written before the rule) may carry the same
 *  DEFAULT name twice; the later ones are renumbered.  A name the user gave
 *  is never touched. */
export const uniqueDefaultTabNames = <T extends { name: string }>(tabs: T[]): T[] => {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const t of tabs) {
    if (DEFAULT_TAB_NAME_RE.test(t.name) && seen.has(t.name)) {
      const name = nextQueryTabName([...new Set([...tabs.map(x => x.name), ...out.map(x => x.name)])]);
      seen.add(name);
      out.push({ ...t, name });
    } else {
      seen.add(t.name);
      out.push(t);
    }
  }
  return out;
};

const defaultTab = (existingNames: string[] = []): TabState => ({
  id: makeId(),
  name: nextQueryTabName(existingNames),
  dirty: false,
  snapshot: null,
});

// ── Component ────────────────────────────────────────────────────────────────

const BusinessQueryTabManager = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [tabs, setTabs] = useState<TabState[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [renameTabId, setRenameTabId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [contextMenu, setContextMenu] = useState<{ anchorEl: HTMLElement; tabId: string } | null>(null);
  const initialized = useRef(false);
  const snapshotRef = useRef<Record<string, BqbTabSnapshot | null>>({});

  // ── Initialize from localStorage ────────────────────────────────────
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    // Phase 133-I round 24 — one-shot migration from the old
    // sessionStorage key so existing users don't lose open tabs on
    // first login after upgrade.
    try {
      const legacy = sessionStorage.getItem(STORAGE_KEY);
      if (legacy && !localStorage.getItem(STORAGE_KEY)) {
        localStorage.setItem(STORAGE_KEY, legacy);
      }
      if (legacy) sessionStorage.removeItem(STORAGE_KEY);
    } catch { /* migration is best-effort */ }
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.tabs?.length > 0) {
          setTabs(uniqueDefaultTabNames(parsed.tabs as TabState[]));
          setActiveTabId(parsed.activeTabId || parsed.tabs[0].id);
          for (const t of parsed.tabs) {
            snapshotRef.current[t.id] = t.snapshot;
          }
          return;
        }
      }
    } catch { /* ignore */ }
    const tab = defaultTab();
    setTabs([tab]);
    setActiveTabId(tab.id);
  }, []);

  // ── Persist to localStorage ─────────────────────────────────────────
  useEffect(() => {
    if (tabs.length === 0) return;
    const tabsWithSnapshots = tabs.map(t => ({
      ...t,
      snapshot: snapshotRef.current[t.id] ?? t.snapshot,
    }));
    // BF-426: safeStringify defends against accidentally captured DOM/Window
    // refs in snapshot fields (e.g., a child setter called with `e` instead of
    // `e.target.value`) — would otherwise throw "Converting circular structure
    // to JSON" and lose the entire tab state.
    try {
      localStorage.setItem(STORAGE_KEY, safeStringify({
        tabs: tabsWithSnapshots,
        activeTabId,
      }));
    } catch {
      // localStorage may be disabled or full — survival over persistence
    }
  }, [tabs, activeTabId]);

  // 2026-09-29 -- an activeTabId that names NO tab hid every tab: the builder
  // rendered blank, and (server-side draft) stayed blank for that user on every
  // visit.  Render the first tab in that case, and store the repair.
  useEffect(() => {
    if (tabs.length === 0) return;
    if (!tabs.some(t => t.id === activeTabId)) setActiveTabId(tabs[0].id);
  }, [tabs, activeTabId]);

  // ── Handle openLocalTable navigation ──────────────────────────────────
  useEffect(() => {
    const tableName = location.state?.openLocalTable;
    if (!tableName) return;
    const path = `__local__:${tableName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.selectedTables || []).some((st: any) => st.path === path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: tableName,
      dirty: false,
      snapshot: {
        selectedConnId: null,
        selectedTables: [{ name: tableName, path }],
        selectedCrossTables: [],
        selectedPhysical: [],
        columnAggregations: {},
        columnTransforms: {},
        filters: [],
        sortColumns: [],
        joinConfig: null,
        queryLimit: 5000,
        sqlText: '',
        executionId: null,
        savedQueryId: null,
        savedQueryName: '',
        cacheStrategy: 'auto',
        showCrossConn: false,
        crossConnId: null,
        crossConnMode: 'union',
        crossJoinHow: 'inner',
        crossJoinLeftOn: '',
        crossJoinRightOn: '',
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
        // A brand-new tab is not a loaded saved query: it has no partition
        // declaration to carry, which is a different fact from a forgotten one.
        loadedPartitionConfig: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.openLocalTable]); // eslint-disable-line

  // ── Handle openMaterializedView navigation ────────────────────────────
  useEffect(() => {
    const mvName = location.state?.openMaterializedView;
    if (!mvName) return;
    const path = `__materialized__:${mvName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.selectedTables || []).some((st: any) => st.path === path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: mvName,
      dirty: false,
      snapshot: {
        selectedConnId: null,
        selectedTables: [{ name: mvName, path }],
        selectedCrossTables: [],
        selectedPhysical: [],
        columnAggregations: {},
        columnTransforms: {},
        filters: [],
        sortColumns: [],
        joinConfig: null,
        queryLimit: 5000,
        sqlText: '',
        executionId: null,
        savedQueryId: null,
        savedQueryName: '',
        cacheStrategy: 'auto',
        showCrossConn: false,
        crossConnId: null,
        crossConnMode: 'union',
        crossJoinHow: 'inner',
        crossJoinLeftOn: '',
        crossJoinRightOn: '',
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
        // A brand-new tab is not a loaded saved query: it has no partition
        // declaration to carry, which is a different fact from a forgotten one.
        loadedPartitionConfig: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.openMaterializedView]); // eslint-disable-line

  // ── Back from Create Dataset / Create Feed (utils/returnTo.ts) ─────────
  // Bring the tab holding that saved query to the front; the tab itself
  // re-opens its "What next" dialog and clears the router state.  No tab
  // holds it any more (closed meanwhile): drop the state, land on the page.
  // Waits for the tabs to be RESTORED: on mount `tabs` is still [] and
  // "no tab holds it" would be decided before the tabs exist (found by the
  // Docker browser proof -- the state was dropped every time).
  useEffect(() => {
    const wn = location.state?.whatNext;
    if (!wn || tabs.length === 0) return;
    const sid = (t: TabState) => snapshotRef.current[t.id]?.savedQueryId ?? t.snapshot?.savedQueryId;
    const holder = tabs.find(t => Number(sid(t)) === Number(wn.savedQueryId));
    if (holder) setActiveTabId(holder.id);
    else navigate(location.pathname, { replace: true, state: {} });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state?.whatNext, tabs]);

  // ── Handle loadQuery from SavedQueries ────────────────────────────────
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    const existing = tabs.find(t =>
      t.snapshot?.savedQueryId === loadQuery.id ||
      t.snapshot?.savedQueryId === Number(loadQuery.id)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    // A SQL query (raw_sql) opens as SQL ONLY -- the way the builder's own
    // open path does (BusinessQueryBuilder, 2026-08-25).  Its `files` and
    // `columns` are what the save RECORDED from the SQL, not a visual
    // selection: restored as one, the visual auto-generator rebuilt the SQL
    // from them and replaced the author's statement (an empty editor for
    // "table chosen, no columns"; a WHERE-less SELECT when columns were
    // recorded).  Found by the Docker browser proof, 2026-10-02.
    const qc = loadQuery.query_config || {};
    const rawSql: string = qc.raw_sql || qc.custom_sql || loadQuery.raw_sql || '';
    const isSql = !!rawSql.trim();
    // 2026-10-07 (F8 cross-source): a cross-source query opens AS
    // cross-source -- its connections, combine and BOTH statements.  The
    // builder composes the labelled pair (it knows the connection names);
    // it used to open single-source and run the primary alone.
    const crossPair = isSql && qc.secondary_connection_id
      && String(qc.secondary_raw_sql || '').trim()
      ? { primary: rawSql, secondary: String(qc.secondary_raw_sql) } : null;
    const jc = (qc.join_config || {}) as { how?: string; left_on?: string; right_on?: string };
    const newTab: TabState = {
      id: makeId(),
      name: loadQuery.name || 'Loaded Query',
      dirty: false,
      snapshot: {
        selectedConnId: qc.connection_id || null,
        selectedTables: isSql ? [] : (qc.files || []).map((f: string) => ({
          name: f.replace(/^__\w+__:/, ''),
          path: f,
        })),
        selectedCrossTables: [],
        selectedPhysical: isSql ? [] : (qc.columns || []),
        columnAggregations: {},
        columnTransforms: {},
        filters: isSql ? [] : (qc.filters || []),
        sortColumns: [],
        joinConfig: null,
        queryLimit: qc.limit || 5000,
        // The SQL lives in query_config (the saved row has no top-level
        // raw_sql): reading only the top level opened every saved SQL
        // query with an EMPTY editor (2026-10-02, Docker browser proof).
        // A cross-source pair is composed by the builder (pendingCrossPair).
        sqlText: crossPair ? '' : rawSql,
        executionId: null,
        savedQueryId: Number(loadQuery.id),
        savedQueryName: loadQuery.name || '',
        cacheStrategy: 'auto',
        showCrossConn: !!crossPair,
        crossConnId: crossPair ? Number(qc.secondary_connection_id) : null,
        crossConnMode: crossPair && qc.combine_mode === 'join' ? 'join' : 'union',
        crossJoinHow: (crossPair && jc.how) || 'inner',
        crossJoinLeftOn: (crossPair && jc.left_on) || '',
        crossJoinRightOn: (crossPair && jc.right_on) || '',
        pendingCrossPair: crossPair,
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
        // 2026-09-05 -- CARRIED, because this snapshot carries savedQueryId:
        // the tab opens in *Update* mode, and an Update writes query_config
        // wholesale.  Rebuilding the config without the partition
        // declaration deletes it behind a 200, and nothing in the builder
        // can reconstruct it.  Null means the query has none.
        loadedPartitionConfig: loadQuery.query_config?.partition_config ?? null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.loadQuery]); // eslint-disable-line

  // ── Tab operations ────────────────────────────────────────────────────
  const createTab = useCallback(() => {
    if (tabs.length >= MAX_TABS) return;
    const tab = defaultTab(tabs.map(t => t.name));
    setTabs(prev => [...prev, tab]);
    setActiveTabId(tab.id);
  }, [tabs]);

  const closeTab = useCallback((id: string) => {
    setTabs(prev => {
      const next = prev.filter(t => t.id !== id);
      if (next.length === 0) {
        const tab = defaultTab();
        next.push(tab);
        setActiveTabId(tab.id);
      } else if (activeTabId === id) {
        const idx = prev.findIndex(t => t.id === id);
        const newIdx = idx > 0 ? idx - 1 : 0;
        setActiveTabId(next[newIdx]?.id || next[0].id);
      }
      delete snapshotRef.current[id];
      return next;
    });
  }, [activeTabId]);

  const switchTab = useCallback((id: string) => {
    if (id === activeTabId) return;
    setActiveTabId(id);
  }, [activeTabId]);

  const renameTab = useCallback((id: string, name: string) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, name: name || 'Untitled' } : t));
  }, []);

  // ── Callbacks from BusinessQueryBuilder ────────────────────────────────
  const handleSnapshotChange = useCallback((tabId: string, snapshot: BqbTabSnapshot) => {
    snapshotRef.current[tabId] = snapshot;
  }, []);

  const handleDirtyChange = useCallback((tabId: string, dirty: boolean) => {
    setTabs(prev => prev.map(t => t.id === tabId ? { ...t, dirty } : t));
  }, []);

  const handleNameChange = useCallback((tabId: string, name: string) => {
    if (name) setTabs(prev => prev.map(t => t.id === tabId ? { ...t, name } : t));
  }, []);

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* ── Tab Bar ── */}
      <Box sx={{
        display: 'flex', alignItems: 'center', gap: 0,
        borderBottom: 1, borderColor: 'divider',
        bgcolor: 'background.paper', px: 0.5, minHeight: 34,
        overflowX: 'auto', flexShrink: 0,
        '&::-webkit-scrollbar': { height: 3 },
        '&::-webkit-scrollbar-thumb': { bgcolor: 'divider', borderRadius: 2 },
      }}>
        {tabs.map(tab => (
          <Box
            key={tab.id}
            onContextMenu={(e) => { e.preventDefault(); setContextMenu({ anchorEl: e.currentTarget as HTMLElement, tabId: tab.id }); }}
            sx={{
              display: 'flex', alignItems: 'center', gap: 0.3,
              px: 1.2, py: 0.4, cursor: 'pointer', userSelect: 'none',
              borderBottom: tab.id === activeTabId ? '2px solid' : '2px solid transparent',
              borderBottomColor: tab.id === activeTabId ? 'primary.main' : 'transparent',
              bgcolor: tab.id === activeTabId ? 'action.selected' : 'transparent',
              '&:hover': { bgcolor: 'action.hover' },
              borderRight: 1, borderRightColor: 'divider',
              minWidth: 'fit-content', maxWidth: 200,
              transition: 'background-color 0.15s',
            }}
            {...clickable(() => switchTab(tab.id), { label: tab.name, pressed: tab.id === activeTabId })}
          >
            {tab.dirty && (
              <DotIcon sx={{ fontSize: 8, color: 'warning.main', mr: 0.3 }} />
            )}
            {renameTabId === tab.id ? (
              <TextField
                size="small" variant="standard" autoFocus
                value={renameValue}
                onChange={e => setRenameValue(e.target.value)}
                onBlur={() => { renameTab(tab.id, renameValue); setRenameTabId(null); }}
                onKeyDown={e => {
                  if (e.key === 'Enter') { renameTab(tab.id, renameValue); setRenameTabId(null); }
                  if (e.key === 'Escape') setRenameTabId(null);
                }}
                inputProps={{ style: { fontSize: 12, padding: '0 4px', width: 100 } }}
                sx={{ '& .MuiInput-underline:before': { borderBottom: 'none' } }}
              />
            ) : (
              <Typography
                variant="caption" noWrap
                sx={{
                  fontSize: 12, fontWeight: tab.id === activeTabId ? 600 : 400,
                  color: tab.id === activeTabId ? 'text.primary' : 'text.secondary',
                  maxWidth: 150,
                }}
                onDoubleClick={() => { setRenameTabId(tab.id); setRenameValue(tab.name); }}
              >
                {tab.name}
              </Typography>
            )}
            {tabs.length > 1 && (
              <IconButton aria-label="Close"
                size="small"
                onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                sx={{ p: 0.15, ml: 0.3, opacity: 0.5, '&:hover': { opacity: 1 } }}
              >
                <CloseIcon sx={{ fontSize: 13 }} />
              </IconButton>
            )}
          </Box>
        ))}

        <Tooltip title={tabs.length >= MAX_TABS ? `Max ${MAX_TABS} tabs` : 'New query tab'}>
          <span>
            <IconButton size="small" aria-label="New query tab" onClick={createTab} disabled={tabs.length >= MAX_TABS}
              sx={{ mx: 0.5, p: 0.3 }}>
              <AddIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </span>
        </Tooltip>
      </Box>

      {/* ── Context Menu ── */}
      <Menu
        open={!!contextMenu}
        onClose={() => setContextMenu(null)}
        anchorEl={contextMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => {
          if (contextMenu) { setRenameTabId(contextMenu.tabId); setRenameValue(tabs.find(t => t.id === contextMenu.tabId)?.name || ''); }
          setContextMenu(null);
        }}>
          <EditIcon sx={{ fontSize: 14, mr: 1 }} /> Rename
        </MenuItem>
        <MenuItem dense onClick={() => { createTab(); setContextMenu(null); }}>
          <AddIcon sx={{ fontSize: 14, mr: 1 }} /> New Tab
        </MenuItem>
        {tabs.length > 1 && (
          <MenuItem dense onClick={() => { if (contextMenu) closeTab(contextMenu.tabId); setContextMenu(null); }}>
            <CloseIcon sx={{ fontSize: 14, mr: 1 }} /> Close
          </MenuItem>
        )}
      </Menu>

      {/* ── Tab Contents (kept mounted via visibility) ── */}
      <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {tabs.map(tab => {
          const active = tab.id === (tabs.some(t => t.id === activeTabId) ? activeTabId : tabs[0]?.id);
          return (
            <Box
              key={tab.id}
              sx={{
                position: 'absolute',
                top: 0, left: 0, right: 0, bottom: 0,
                visibility: active ? 'visible' : 'hidden',
                zIndex: active ? 1 : 0,
              }}
            >
              <BusinessQueryBuilder
                tabId={tab.id}
                isActive={active}
                initialSnapshot={tab.snapshot || snapshotRef.current[tab.id]}
                onSnapshotChange={(snapshot) => handleSnapshotChange(tab.id, snapshot)}
                onDirtyChange={(dirty) => handleDirtyChange(tab.id, dirty)}
                onNameChange={(name) => handleNameChange(tab.id, name)}
              />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default BusinessQueryTabManager;
