/**
 * Phase 130-E — Top toolbar extracted from BusinessQueryBuilder.
 * Phase 134  — Advanced dropdown (HAVING, Computed, CASE, Window, DISTINCT).
 * Phase 142  — UI parity with CompleteQueryBuilder:
 *               • Save ▾ menu (Save query / Save .sql / Load / Publish)
 *               • Run options ▾ menu (3-state cache strategy + EXPLAIN)
 *               • Limit dropdown (presets) instead of free numeric input
 *               • Streaming menu for S3 (Off / Stream / Stream + Download)
 *               • Cost estimate chip (rows + files preview)
 *               • Tooltips on every actionable element
 */
import React, { useState } from 'react';
import {
  Paper, Button, Select, MenuItem, FormControl, InputLabel,
  Chip, Divider, Box, Typography, CircularProgress,
  Tooltip, SelectChangeEvent, TextField,
  Menu, ListItemIcon, ListItemText,
} from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import StopIcon from '@mui/icons-material/Stop';
import SaveIcon from '@mui/icons-material/Save';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import PublishIcon from '@mui/icons-material/Publish';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FilterListIcon from '@mui/icons-material/FilterList';
import FunctionsIcon from '@mui/icons-material/Functions';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import WindowIcon from '@mui/icons-material/Window';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CachedIcon from '@mui/icons-material/Cached';
import CloudOffIcon from '@mui/icons-material/CloudOff';
import CloudSyncIcon from '@mui/icons-material/CloudSync';
import StreamIcon from '@mui/icons-material/Stream';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import RssFeedIcon from '@mui/icons-material/RssFeed';
import SchemaIcon from '@mui/icons-material/Schema';
import CodeIcon from '@mui/icons-material/Code';
import LibraryBooksIcon from '@mui/icons-material/LibraryBooks';
import type { ConnectionOption } from './types';

export interface QueryToolbarProps {
  connections: ConnectionOption[];
  selectedConnId: number | null;
  onConnChange: (id: number | null) => void;
  executing: boolean;
  sqlText: string;
  onExecute: () => void;
  /** Why Execute cannot run what the editor shows (2026-10-07, F8
   *  cross-source): Execute is disabled and its tooltip says this.  null /
   *  undefined = no block. */
  executeBlockedReason?: string | null;
  onSave: () => void;
  onSaveSqlFile?: () => void;  // BF-271: parity with CQB — save raw SQL as a .sql file
  onLoad: () => void;
  /** Optional — omitted when the `business_query_builder.publish` sub-feature
   * is admin-hidden for this role (visibility declutter, not a permission). */
  onPublish?: () => void;
  /** Open the FeedConfigs page with the current source pre-selected.
   * No-op when neither ``savedQueryId`` nor ``loadedSqlFileId`` is set
   * — at least one save destination must exist for a feed to point at. */
  onCreateFeed?: () => void;
  /** Open the Semantic Layer page with the current source pre-selected as a
   * new dataset.  Same enable gate as Publish / Create-Feed: a saved query
   * or a saved ``.sql`` file must back the SQL. */
  onCreateDataset?: () => void;
  savedQueryId: number | null;
  savedQueryName: string;
  /** When the user has loaded (or freshly saved) a ``.sql`` file, its
   * id is held here so Publish + Create-Feed can target it.  Either
   * this OR ``savedQueryId`` is enough to enable those actions. */
  loadedSqlFileId?: number | null;
  onClearSaved: () => void;
  cacheStrategy: string;
  /** Optional — omitted when the `business_query_builder.cache_controls`
   * sub-feature is admin-hidden; the whole "Run options" menu is then not
   * rendered and the default cache strategy applies. */
  onCacheChange?: (v: string) => void;
  queryLimit: number;
  onLimitChange: (v: number) => void;
  // Phase 134 — Advanced features
  onOpenTemplates?: () => void;
  distinct?: boolean;
  onDistinctChange?: (v: boolean) => void;
  onOpenHaving?: () => void;
  onOpenComputed?: () => void;
  onOpenCase?: () => void;
  onOpenWindow?: () => void;
  havingCount?: number;
  computedCount?: number;
  caseCount?: number;
  windowCount?: number;
  // Phase 138: Cancel mid-execute — when provided AND executing=true,
  // the Execute button morphs into a Cancel button.
  onCancel?: () => void;
  /** Phase 138: opens the visual EXPLAIN dialog */
  onExplain?: () => void;
  /** Round 12 (2026-06-02): proactive validate-and-fix.  Calls
   *  /api/sql/auto-fix on the current SQL WITHOUT running the query.
   *  When the backend returns ``fixed: true``, parent updates the
   *  editor + shows a banner.  When ``fixed: false`` parent shows
   *  "SQL looks valid".  Replaces the previous reactive-only flow
   *  where the user had to fail a query before seeing the fix. */
  onValidateAndFix?: () => void;
  validating?: boolean;
  // Phase 142 — Streaming controls (S3 connections only — caller passes
  // null/undefined to hide the menu entirely on non-S3 connections).
  streamingSupported?: boolean;
  enableStreaming?: boolean;
  onEnableStreamingChange?: (v: boolean) => void;
  streamBgDownload?: boolean;
  onStreamBgDownloadChange?: (v: boolean) => void;
  // Phase 142 — Cost estimate chip (caller fetches from /estimate endpoint)
  costEstimate?: {
    estimated_rows: number;
    estimated_files: number;
    pushdown_warning?: { warn: boolean; hint: string };
  } | null;
  estimating?: boolean;
}

// Limit presets — match CQB so users see the same values everywhere
const LIMIT_PRESETS = [100, 500, 1000, 5000, 10000, 50000, 100000];

// 2026-11-05 -- the owner: "query header took so much space".  With the sidebar open a laptop
// wrapped the toolbar to two rows; below this width the same controls say less and fit on one.
const ON_A_LAPTOP = '@media (max-width:1499px)';

const QueryToolbar: React.FC<QueryToolbarProps> = ({
  connections, selectedConnId, onConnChange,
  executing, sqlText, onExecute, executeBlockedReason = null, onSave, onSaveSqlFile, onLoad, onPublish,
  onCreateFeed, onCreateDataset, loadedSqlFileId = null,
  savedQueryId, savedQueryName, onClearSaved,
  cacheStrategy, onCacheChange,
  queryLimit, onLimitChange,
  onOpenTemplates,
  distinct = false, onDistinctChange,
  onOpenHaving, onOpenComputed, onOpenCase, onOpenWindow,
  havingCount = 0, computedCount = 0, caseCount = 0, windowCount = 0,
  onCancel, onExplain, onValidateAndFix, validating,
  streamingSupported = false,
  enableStreaming = false, onEnableStreamingChange,
  streamBgDownload = false, onStreamBgDownloadChange,
  costEstimate, estimating = false,
}) => {
  const [advancedAnchor, setAdvancedAnchor] = useState<HTMLElement | null>(null);
  const [saveAnchor, setSaveAnchor] = useState<HTMLElement | null>(null);
  const [runOptsAnchor, setRunOptsAnchor] = useState<HTMLElement | null>(null);
  const [streamingAnchor, setStreamingAnchor] = useState<HTMLElement | null>(null);

  const advancedTotal = havingCount + computedCount + caseCount + windowCount + (distinct ? 1 : 0);

  // Streaming mode derived from boolean state (UI shows 3 distinct states)
  const streamingMode = !enableStreaming ? 'off'
    : streamBgDownload ? 'stream_dl' : 'stream';
  const streamingLabel = streamingMode === 'off' ? 'No streaming'
    : streamingMode === 'stream' ? 'Stream' : 'Stream + Download';
  const streamingColor: 'default' | 'info' | 'warning' = streamingMode === 'off' ? 'default'
    : streamingMode === 'stream' ? 'info' : 'warning';

  // Phase 142: split into Header (Row 1: context) + Action bar (Row 2: actions).
  // Header carries connection picker + status, saved-query identity, cost estimate.
  // Action bar carries every clickable thing: Save, Advanced, Limit, Streaming,
  // Run options, Execute.  Visual hierarchy makes the page scan-able in one glance.
  const selectedConn = connections.find(c => c.id === selectedConnId);
  const connTypeLabel = selectedConn?.connection_type
    ? selectedConn.connection_type.toUpperCase()
    : '';
  // 2026-10-03 -- whose plan EXPLAIN shows: a SQL connection's own engine
  // (the backend sends EXPLAIN there), else the local DuckDB engine.  It said
  // "DuckDB" on a Snowflake connection.
  const SOURCE_ENGINES: Record<string, string> = {
    snowflake: 'Snowflake', trino: 'Trino', starburst: 'Starburst', databricks: 'Databricks',
    athena: 'Athena', oracle: 'Oracle',
  };
  const explainEngine = SOURCE_ENGINES[String(selectedConn?.connection_type || '').toLowerCase()] || 'DuckDB';

  return (
    <Paper elevation={1} sx={{
      px: 1.5, py: 0.75, display: 'flex', alignItems: 'flex-start', gap: 1, flexShrink: 0,
      borderBottom: '2px solid', borderColor: 'primary.main', flexWrap: 'nowrap',
    }}>
      {/* 2026-10-07 (F6, the BQB audit): on a Trino connection at 1600 px the
          one wrapping row dropped Execute to a SECOND row.  Everything but the
          primary action wraps INSIDE this group; Execute / Cancel sit in their
          own non-shrinking slot at the end of the FIRST row, at every width. */}
      <Box data-testid="bqb-toolbar-controls" sx={{
        display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap',
        flex: '1 1 auto', minWidth: 0,
      }}>
      {/* Title removed — Layout.tsx already shows "Query Editor" in the page header.
          Connection picker is now the leading element of the action toolbar. */}
      <FormControl size="small" sx={{ minWidth: 200, [ON_A_LAPTOP]: { minWidth: 170 }, '& .MuiInputBase-root': { height: 32 } }}>
        <InputLabel id="sel-querytoolbar-connection">Connection</InputLabel>
        <Select labelId="sel-querytoolbar-connection"
          value={selectedConnId || ''} label="Connection"
          onChange={(e: SelectChangeEvent<number | string>) => {
            const v = Number(e.target.value);
            onConnChange(v || null);
          }}
          sx={{ '& .MuiSelect-select': { py: 0.5, fontSize: '0.8rem' } }}
        >
          {connections.map(c => (
            <MenuItem key={c.id} value={c.id}>
              {c.name}
              <Typography component="span" variant="caption" sx={{ ml: 1, color: 'text.disabled' }}>
                ({c.connection_type})
              </Typography>
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {selectedConn && (
        <Tooltip title={`Connection type: ${connTypeLabel}`}>
          <Chip
            label={connTypeLabel}
            size="small"
            variant="outlined"
            sx={{ fontFamily: 'monospace', fontWeight: 700, fontSize: '0.65rem', height: 22, [ON_A_LAPTOP]: { display: 'none' } }}
          />
        </Tooltip>
      )}

      {savedQueryName && (
        <Tooltip title="Clear saved-query association">
          <Chip
            label={savedQueryName}
            size="small"
            variant="outlined"
            color="primary"
            onDelete={onClearSaved}
            sx={{ fontWeight: 600 }}
          />
        </Tooltip>
      )}

      <Divider orientation="vertical" flexItem />

      {/* Phase 142: Save ▾ — consolidates Save query / Save .sql / Load / Publish into one menu.
          Symmetry: outlined variant + 32px height matches Advanced + Run options + Streaming. */}
      {/* Phase 134-N — the outer menu button used to disable when
          ``!sqlText.trim() && !savedQueryId``, which blocked the user
          from BROWSING saved queries because the Load action lives
          inside this menu.  The inner Save / Save-as-.sql items still
          carry their own ``disabled={!sqlText.trim()}`` guards, so the
          unsafe actions are still gated — only the menu itself opens
          freely. */}
      <Tooltip title="Save / Load / Publish actions">
        <span>
          <Button
            size="small"
            variant="outlined"
            startIcon={<SaveIcon />}
            endIcon={<ExpandMoreIcon />}
            onClick={(e) => setSaveAnchor(e.currentTarget)}
            sx={{ textTransform: 'none', fontSize: '0.75rem', height: 32 }}
          >
            Save / Load
          </Button>
        </span>
      </Tooltip>
      <Menu
        anchorEl={saveAnchor}
        open={!!saveAnchor}
        onClose={() => setSaveAnchor(null)}
        MenuListProps={{ dense: true }}
        PaperProps={{ sx: { minWidth: 280 } }}
      >
        <MenuItem
          disabled={!sqlText.trim()}
          onClick={() => { onSave(); setSaveAnchor(null); }}
        >
          <ListItemIcon><SaveIcon fontSize="small" /></ListItemIcon>
          <ListItemText
            primary={savedQueryId ? `Update saved query #${savedQueryId}` : 'Save query'}
            secondary={savedQueryId ? 'Persist changes to this query' : 'Persist as a named saved query'}
            secondaryTypographyProps={{ fontSize: 11 }}
          />
        </MenuItem>
        {onSaveSqlFile && (
          <MenuItem
            disabled={!sqlText.trim()}
            onClick={() => { onSaveSqlFile(); setSaveAnchor(null); }}
          >
            <ListItemIcon><SaveIcon fontSize="small" /></ListItemIcon>
            <ListItemText
              primary="Save as .sql file…"
              secondary="Loadable later via the Load action"
              secondaryTypographyProps={{ fontSize: 11 }}
            />
          </MenuItem>
        )}
        <MenuItem onClick={() => { onLoad(); setSaveAnchor(null); }}>
          <ListItemIcon><FolderOpenIcon fontSize="small" /></ListItemIcon>
          <ListItemText
            primary="Load saved query…"
            secondary="Browse and open a previously saved query"
            secondaryTypographyProps={{ fontSize: 11 }}
          />
        </MenuItem>
        {(onPublish || onCreateFeed || onCreateDataset) && <Divider />}
        {/* Publish + Feed enable when EITHER a saved query OR a saved
            .sql file backs the current SQL.  Single gate keeps both
            actions in sync — user can't accidentally publish from one
            source and feed-generate from another.
            Each item renders only when its callback is provided — the host
            omits it when the sub-feature is admin-hidden (declutter, not a
            permission: publishing/feeds stay available from their pages). */}
        {onPublish && (
          <MenuItem
            disabled={!savedQueryId && !loadedSqlFileId}
            onClick={() => { onPublish(); setSaveAnchor(null); }}
          >
            <ListItemIcon><PublishIcon fontSize="small" color={(savedQueryId || loadedSqlFileId) ? 'secondary' : undefined} /></ListItemIcon>
            <ListItemText
              primary="Publish API…"
              secondary={
                savedQueryId
                  ? 'Expose this saved query as a Published View'
                  : loadedSqlFileId
                    ? 'Expose this .sql file as a Published View'
                    : 'Save the query (or save as .sql) first'
              }
              secondaryTypographyProps={{ fontSize: 11 }}
            />
          </MenuItem>
        )}
        {onCreateFeed && (
          <MenuItem
            disabled={!savedQueryId && !loadedSqlFileId}
            onClick={() => { onCreateFeed(); setSaveAnchor(null); }}
          >
            <ListItemIcon><RssFeedIcon fontSize="small" color={(savedQueryId || loadedSqlFileId) ? 'secondary' : undefined} /></ListItemIcon>
            <ListItemText
              primary="Create Feed…"
              secondary={
                savedQueryId || loadedSqlFileId
                  ? 'Schedule recurring output (CSV / Parquet / SFTP / S3)'
                  : 'Save the query (or save as .sql) first'
              }
              secondaryTypographyProps={{ fontSize: 11 }}
            />
          </MenuItem>
        )}
        {onCreateDataset && (
          <MenuItem
            disabled={!savedQueryId && !loadedSqlFileId}
            onClick={() => { onCreateDataset(); setSaveAnchor(null); }}
          >
            <ListItemIcon><SchemaIcon fontSize="small" color={(savedQueryId || loadedSqlFileId) ? 'secondary' : undefined} /></ListItemIcon>
            <ListItemText
              primary="Create Dataset…"
              secondary={
                savedQueryId || loadedSqlFileId
                  ? 'Model this query as a Semantic Layer dataset'
                  : 'Save the query (or save as .sql) first'
              }
              secondaryTypographyProps={{ fontSize: 11 }}
            />
          </MenuItem>
        )}
        {onOpenTemplates && (
          <>
            <Divider />
            <MenuItem onClick={() => { onOpenTemplates(); setSaveAnchor(null); }}>
              <ListItemIcon><LibraryBooksIcon fontSize="small" /></ListItemIcon>
              <ListItemText
                primary="Templates"
                secondary="Pre-built query patterns"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
          </>
        )}
      </Menu>

      {/* Advanced dropdown */}
      {onOpenHaving && (
        <>
          <Divider orientation="vertical" flexItem />
          <Tooltip title="Advanced SQL: HAVING, Computed columns, CASE, Window functions, DISTINCT">
            <Button
              size="small"
              variant="outlined"
              endIcon={<ExpandMoreIcon />}
              onClick={e => setAdvancedAnchor(e.currentTarget)}
              color={advancedTotal > 0 ? 'secondary' : 'inherit'}
              sx={{ textTransform: 'none', fontSize: '0.75rem', height: 32 }}
            >
              Advanced
              {advancedTotal > 0 && (
                <Chip label={advancedTotal} size="small" color="secondary"
                  sx={{ height: 16, fontSize: '0.6rem', ml: 0.5 }} />
              )}
            </Button>
          </Tooltip>
          <Menu
            anchorEl={advancedAnchor}
            open={!!advancedAnchor}
            onClose={() => setAdvancedAnchor(null)}
          >
            <MenuItem dense onClick={() => { onOpenHaving?.(); setAdvancedAnchor(null); }}>
              <ListItemIcon><FilterListIcon fontSize="small" /></ListItemIcon>
              <ListItemText>HAVING</ListItemText>
              {havingCount > 0 && <Chip label={havingCount} size="small" sx={{ height: 16, fontSize: '0.6rem' }} />}
            </MenuItem>
            <MenuItem dense onClick={() => { onOpenComputed?.(); setAdvancedAnchor(null); }}>
              <ListItemIcon><FunctionsIcon fontSize="small" /></ListItemIcon>
              <ListItemText>Computed Columns</ListItemText>
              {computedCount > 0 && <Chip label={computedCount} size="small" sx={{ height: 16, fontSize: '0.6rem' }} />}
            </MenuItem>
            <MenuItem dense onClick={() => { onOpenCase?.(); setAdvancedAnchor(null); }}>
              <ListItemIcon><AccountTreeIcon fontSize="small" /></ListItemIcon>
              <ListItemText>CASE Expressions</ListItemText>
              {caseCount > 0 && <Chip label={caseCount} size="small" sx={{ height: 16, fontSize: '0.6rem' }} />}
            </MenuItem>
            <MenuItem dense onClick={() => { onOpenWindow?.(); setAdvancedAnchor(null); }}>
              <ListItemIcon><WindowIcon fontSize="small" /></ListItemIcon>
              <ListItemText>Window Functions</ListItemText>
              {windowCount > 0 && <Chip label={windowCount} size="small" sx={{ height: 16, fontSize: '0.6rem' }} />}
            </MenuItem>
            <Divider />
            <MenuItem dense onClick={() => { onDistinctChange?.(!distinct); setAdvancedAnchor(null); }}>
              <ListItemIcon>
                {distinct ? <CheckBoxIcon fontSize="small" color="primary" /> : <CheckBoxOutlineBlankIcon fontSize="small" />}
              </ListItemIcon>
              <ListItemText>DISTINCT</ListItemText>
            </MenuItem>
          </Menu>
        </>
      )}

      <Box sx={{ flexGrow: 1 }} />

      {/* Phase 142: Cost estimate (status display) — sits before action controls */}
      {estimating && (
        <Chip
          size="small"
          label="Estimating…"
          variant="outlined"
          icon={<CircularProgress size={10} />}
          sx={{ height: 24, fontSize: '0.7rem' }}
        />
      )}
      {!estimating && costEstimate && costEstimate.estimated_rows >= 0 && (
        <Tooltip title={
          costEstimate.pushdown_warning?.warn
            ? `Pushdown warning: ${costEstimate.pushdown_warning.hint}`
            : `Pre-flight estimate · safer to run when row count is reasonable`
        }>
          <Chip
            size="small"
            variant="outlined"
            color={
              costEstimate.estimated_rows > 50_000_000 ? 'error'
              : costEstimate.estimated_rows > 10_000_000 ? 'warning'
              : 'default'
            }
            // Files only where files are what is read (storage); a SQL
            // source has none, and "· 0 files" read as an error.
            label={`~${costEstimate.estimated_rows.toLocaleString()} rows${costEstimate.estimated_files > 0
              ? ` · ${costEstimate.estimated_files} file${costEstimate.estimated_files !== 1 ? 's' : ''}` : ''}`}
            sx={{ height: 24, fontSize: '0.7rem', fontWeight: 600 }}
          />
        </Tooltip>
      )}

      {/* Phase 142: Streaming menu — S3 connections only */}
      {streamingSupported && onEnableStreamingChange && (
        <>
          <Tooltip title="Streaming mode for S3 queries — preview rows as they arrive">
            <Chip
              icon={<StreamIcon sx={{ fontSize: 16 }} />}
              label={streamingLabel}
              size="small"
              variant={streamingMode === 'off' ? 'outlined' : 'filled'}
              color={streamingColor}
              onClick={(e) => setStreamingAnchor(e.currentTarget)}
              onDelete={(e) => { e.stopPropagation(); setStreamingAnchor(e.currentTarget as any); }}
              deleteIcon={<ExpandMoreIcon sx={{ fontSize: 16 }} />}
              sx={{ cursor: 'pointer', fontWeight: streamingMode !== 'off' ? 700 : 400, height: 32, fontSize: '0.75rem' }}
            />
          </Tooltip>
          <Menu
            anchorEl={streamingAnchor}
            open={!!streamingAnchor}
            onClose={() => setStreamingAnchor(null)}
            MenuListProps={{ dense: true }}
            PaperProps={{ sx: { minWidth: 320 } }}
          >
            <MenuItem
              selected={streamingMode === 'off'}
              onClick={() => {
                onEnableStreamingChange(false);
                onStreamBgDownloadChange?.(false);
                setStreamingAnchor(null);
              }}
            >
              <ListItemText
                primary="No streaming"
                secondary="Wait for full query to complete; all columns returned"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
            <MenuItem
              selected={streamingMode === 'stream'}
              onClick={() => {
                onEnableStreamingChange(true);
                onStreamBgDownloadChange?.(false);
                setStreamingAnchor(null);
              }}
            >
              <ListItemIcon><StreamIcon fontSize="small" sx={{ color: 'info.main' }} /></ListItemIcon>
              <ListItemText
                primary="Stream only"
                secondary="Preview rows from S3 as they arrive · no local file"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
            <MenuItem
              selected={streamingMode === 'stream_dl'}
              onClick={() => {
                onEnableStreamingChange(true);
                onStreamBgDownloadChange?.(true);
                setStreamingAnchor(null);
              }}
            >
              <ListItemIcon><CloudDownloadIcon fontSize="small" sx={{ color: 'warning.main' }} /></ListItemIcon>
              <ListItemText
                primary="Stream + Download"
                secondary="Stream preview AND save full results for export/history"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
          </Menu>
        </>
      )}

      {/* Phase 142: Limit dropdown — replaces free-form numeric input */}
      <Tooltip title="Maximum rows returned · large limits scan more S3 files">
        <TextField
          select
          size="small"
          label="Limit"
          value={LIMIT_PRESETS.includes(queryLimit) ? String(queryLimit) : 'custom'}
          onChange={e => {
            const v = e.target.value;
            if (v === 'custom') return; // do nothing — user keeps their custom value
            onLimitChange(parseInt(v, 10));
          }}
          sx={{
            width: 130,
            [ON_A_LAPTOP]: { width: 96 },
            '& .MuiInputBase-root': { height: 32 },
            '& input, & .MuiSelect-select': { py: 0.5, fontSize: '0.75rem' },
          }}
          SelectProps={{ native: true }}
        >
          {LIMIT_PRESETS.map(n => (
            <option key={n} value={n}>{n.toLocaleString()}</option>
          ))}
          {!LIMIT_PRESETS.includes(queryLimit) && (
            <option value="custom">{queryLimit.toLocaleString()}</option>
          )}
        </TextField>
      </Tooltip>

      {/* Phase 142: Run options ▾ — 3-state cache + EXPLAIN.  Rendered only
          when the host provides onCacheChange; omitted when the
          cache_controls sub-feature is admin-hidden (declutter — the default
          cache strategy still applies, this is not a permission). */}
      {onCacheChange && (
        <>
          <Tooltip title="Run options: cache strategy, EXPLAIN plan">
            <Button
              variant="outlined"
              size="small"
              endIcon={<ExpandMoreIcon />}
              onClick={(e) => setRunOptsAnchor(e.currentTarget)}
              color={cacheStrategy !== 'auto' ? 'warning' : 'inherit'}
              startIcon={
                cacheStrategy === 'auto' ? <CachedIcon fontSize="small" /> :
                cacheStrategy === 'bypass' ? <CloudOffIcon fontSize="small" /> :
                <CloudSyncIcon fontSize="small" />
              }
              aria-label="Run options"
              sx={{ textTransform: 'none', fontSize: '0.75rem', height: 32 }}
            >
              <Box component="span" sx={{ [ON_A_LAPTOP]: { display: 'none' } }}>Run options</Box>
              <Box component="span" sx={{ display: 'none', [ON_A_LAPTOP]: { display: 'inline' } }}>Options</Box>
              {cacheStrategy !== 'auto' && (
                <Chip
                  label={cacheStrategy === 'bypass' ? 'skip cache' : 'refresh'}
                  size="small"
                  color="warning"
                  sx={{ ml: 0.75, height: 18, fontSize: 10 }}
                />
              )}
            </Button>
          </Tooltip>
          <Menu
            anchorEl={runOptsAnchor}
            open={!!runOptsAnchor}
            onClose={() => setRunOptsAnchor(null)}
            MenuListProps={{ dense: true }}
            PaperProps={{ sx: { minWidth: 320 } }}
          >
            <Typography variant="caption" sx={{ px: 2, pt: 1, color: 'text.secondary', fontWeight: 700, display: 'block' }}>
              CACHE STRATEGY
            </Typography>
            <MenuItem
              selected={cacheStrategy === 'auto'}
              onClick={() => onCacheChange('auto')}
            >
              <ListItemIcon><CachedIcon fontSize="small" /></ListItemIcon>
              <ListItemText
                primary="Use cache"
                secondary="Serve cached result if available"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
            <MenuItem
              selected={cacheStrategy === 'bypass'}
              onClick={() => onCacheChange('bypass')}
            >
              <ListItemIcon><CloudOffIcon fontSize="small" sx={{ color: 'warning.main' }} /></ListItemIcon>
              <ListItemText
                primary="Skip cache"
                secondary="Fresh from source, bypass all caches"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
            <MenuItem
              selected={cacheStrategy === 'refresh'}
              onClick={() => onCacheChange('refresh')}
            >
              <ListItemIcon><CloudSyncIcon fontSize="small" sx={{ color: 'success.main' }} /></ListItemIcon>
              <ListItemText
                primary="Refresh cache"
                secondary="Query fresh and update cache"
                secondaryTypographyProps={{ fontSize: 11 }}
              />
            </MenuItem>
            {onExplain && (
              <>
                <Divider />
                <MenuItem
                  disabled={executing || !sqlText.trim()}
                  onClick={() => { setRunOptsAnchor(null); onExplain(); }}
                >
                  <ListItemIcon><CodeIcon fontSize="small" /></ListItemIcon>
                  <ListItemText
                    primary="EXPLAIN query plan"
                    secondary={`${explainEngine} query plan${explainEngine === 'DuckDB' || explainEngine === 'Trino' || explainEngine === 'Starburst' ? ' / ANALYZE' : ''}`}
                    secondaryTypographyProps={{ fontSize: 11 }}
                  />
                </MenuItem>
              </>
            )}
          </Menu>
        </>
      )}

      {/* BF-395 — Standalone EXPLAIN button.  Previously EXPLAIN was only
          reachable inside the "Run options ▾" menu, which made it hard to
          discover from BQB.  Surfacing it as a top-level button on the
          toolbar (when the host passes onExplain) brings BQB to parity
          with CompleteQueryBuilder's inline EXPLAIN affordance. */}
      {onExplain && (
        <Tooltip title={!sqlText.trim() ? 'Build or type a query first' : `Show the ${explainEngine} query plan (EXPLAIN)`}>
          <span>
            <Button
              size="small"
              variant="outlined"
              startIcon={<CodeIcon />}
              onClick={onExplain}
              disabled={executing || !sqlText.trim()}
              aria-label="EXPLAIN"
              sx={{
                minWidth: 96, height: 32, textTransform: 'none', fontSize: '0.75rem',
                [ON_A_LAPTOP]: { minWidth: 40, px: 1, '& .MuiButton-startIcon': { m: 0 } },
              }}
            >
              <Box component="span" sx={{ [ON_A_LAPTOP]: { display: 'none' } }}>EXPLAIN</Box>
            </Button>
          </span>
        </Tooltip>
      )}

      {/* Round 12 (2026-06-02): proactive Validate & Fix button.  Calls
          /api/sql/auto-fix without running the query so the user can
          spot + apply fixes BEFORE incurring execution cost.  Disabled
          while a query is running or while validate is already in
          flight. */}
      {onValidateAndFix && (
        <Tooltip
          title={
            !sqlText.trim()
              ? 'Build or type a query first'
              : validating
                ? 'Validating…'
                : 'Validate the SQL and auto-fix common issues (GROUP BY, ambiguous columns, …)'
          }
        >
          <span>
            <Button
              size="small"
              variant="outlined"
              color="info"
              onClick={onValidateAndFix}
              disabled={executing || validating || !sqlText.trim()}
              aria-label={validating ? 'Validating…' : '✨ Validate & Fix'}
              sx={{
                minWidth: 124, height: 32, textTransform: 'none', fontSize: '0.75rem',
                [ON_A_LAPTOP]: { minWidth: 40, px: 1 },
              }}
            >
              {validating ? 'Validating…' : (
                <>✨<Box component="span" sx={{ [ON_A_LAPTOP]: { display: 'none' } }}>&nbsp;Validate &amp; Fix</Box></>
              )}
            </Button>
          </span>
        </Tooltip>
      )}

      </Box>

      {/* Execute / Cancel — primary action, slightly taller (36px) than menu
          triggers (32px) for visual emphasis as the call-to-action. */}
      <Box data-testid="bqb-execute-slot" sx={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
      {executing && onCancel ? (
        <Tooltip title="Cancel the running query">
          <Button
            size="small"
            variant="contained" color="error"
            startIcon={<StopIcon />}
            onClick={onCancel}
            sx={{ minWidth: 110, height: 36, fontWeight: 700 }}
          >
            Cancel
          </Button>
        </Tooltip>
      ) : (
        <Tooltip title={!sqlText.trim() ? 'Enter SQL or build a query first'
          : executeBlockedReason || 'Run the query'}>
          <span>
            <Button
              size="small"
              variant="contained" color="primary" data-bqb-execute
              startIcon={executing ? <CircularProgress size={18} color="inherit" /> : <PlayArrowIcon />}
              onClick={onExecute}
              disabled={executing || !sqlText.trim() || !!executeBlockedReason}
              sx={{ minWidth: 110, height: 36, fontWeight: 700 }}>
              Execute
            </Button>
          </span>
        </Tooltip>
      )}
      </Box>
    </Paper>
  );
};

export default QueryToolbar;
