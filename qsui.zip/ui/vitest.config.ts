/// <reference types="vitest" />
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    // happy-dom rather than jsdom — jsdom shadows Node's native
    // AbortController/AbortSignal with its own classes, which fail MSW
    // interceptors' `signal instanceof AbortSignal` webidl check and
    // hang every safeFetch() call in tests forever.
    environment: 'happy-dom',
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
    css: false,
    // Phase 133-G deep-dive — interactive tests using ``userEvent.type``
    // simulate real keystrokes (~50ms per char) plus React state
    // updates.  At 5s default several legitimate tests (UserGroups
    // per-user view, FeedFailover, CustomJobs dialog) fail with
    // "Test timed out in 5000ms" under parallel CPU contention.
    // 15s gives them headroom without masking real hangs.
    testTimeout: 15000,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
