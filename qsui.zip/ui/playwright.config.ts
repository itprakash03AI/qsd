import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright E2E test configuration for QueryStudio.
 *
 * Runs against the backend serving the built frontend (localhost:8000).
 * Use `reuseExistingServer: true` to test against a running dev server,
 * or let Playwright start one automatically.
 */
export default defineConfig({
  testDir: './e2e',
  timeout: 30_000,
  expect: { timeout: 5_000 },
  fullyParallel: false,
  retries: 1,
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:8000',
    screenshot: 'only-on-failure',
    trace: 'on-first-retry',
  },
  webServer: {
    command: 'cd ../backend && python -m querystudio standalone',
    url: 'http://localhost:8000/health',
    reuseExistingServer: true,
    timeout: 30_000,
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
});
