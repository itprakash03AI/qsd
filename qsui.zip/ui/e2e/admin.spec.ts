import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Admin API', () => {
  test('should return health status', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/health`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.status).toBe('healthy');
  });

  test('should return database status', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/database/status`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.type).toBe('sqlite');
    expect(body.is_healthy).toBe(true);
  });

  test('should return REST API config', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/rest-api/config`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.enabled).toBe(true);
    expect(body.max_rows_per_query).toBeGreaterThan(0);
  });

  test('admin page should load', async ({ page }) => {
    await page.goto('/admin');
    // Look for admin-specific content
    const heading = page.getByText('Admin', { exact: false });
    await expect(heading.first()).toBeVisible({ timeout: 10_000 });
  });
});
