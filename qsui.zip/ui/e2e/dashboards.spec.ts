/**
 * Phase 71B — Dashboard E2E workflow tests.
 * Tests: create dashboard → add widget → list → update → delete.
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Dashboard Workflow', () => {
  let dashId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (dashId) {
      await page.request.delete(`${BASE}/api/dashboards/${dashId}`).catch(() => {});
      dashId = null;
    }
  });

  test('should create a dashboard', async ({ page }) => {
    const resp = await page.request.post(`${BASE}/api/dashboards`, {
      data: {
        name: 'E2E Test Dashboard',
        description: 'Created by E2E test',
      },
    });
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.id).toBeTruthy();
    expect(body.name).toBe('E2E Test Dashboard');
    dashId = body.id;
  });

  test('should list dashboards', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/dashboards`, {
      data: { name: 'E2E List Dashboard' },
    });
    const created = await createResp.json();
    dashId = created.id;

    const listResp = await page.request.get(`${BASE}/api/dashboards`);
    expect(listResp.ok()).toBeTruthy();
    const dashboards = await listResp.json();
    expect(dashboards.length).toBeGreaterThan(0);
    const found = dashboards.find((d: any) => d.id === dashId);
    expect(found).toBeTruthy();
  });

  test('should update a dashboard', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/dashboards`, {
      data: { name: 'E2E Update Dashboard' },
    });
    const created = await createResp.json();
    dashId = created.id;

    const updateResp = await page.request.put(`${BASE}/api/dashboards/${dashId}`, {
      data: { name: 'Updated Dashboard Name', description: 'Updated' },
    });
    expect(updateResp.ok()).toBeTruthy();

    const getResp = await page.request.get(`${BASE}/api/dashboards/${dashId}`);
    const updated = await getResp.json();
    expect(updated.name).toBe('Updated Dashboard Name');
  });

  test('should add a widget to a dashboard', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/dashboards`, {
      data: { name: 'E2E Widget Dashboard' },
    });
    const created = await createResp.json();
    dashId = created.id;

    const widgetResp = await page.request.post(`${BASE}/api/dashboards/${dashId}/widgets`, {
      data: {
        title: 'Test Widget',
        widget_type: 'chart',
        config: { chart_type: 'bar' },
        x: 0, y: 0, w: 6, h: 4,
      },
    });
    expect(widgetResp.ok()).toBeTruthy();
    const widget = await widgetResp.json();
    expect(widget.title).toBe('Test Widget');
  });

  test('should delete a dashboard', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/dashboards`, {
      data: { name: 'E2E Delete Dashboard' },
    });
    const created = await createResp.json();

    const delResp = await page.request.delete(`${BASE}/api/dashboards/${created.id}`);
    expect(delResp.ok()).toBeTruthy();
    dashId = null;
  });
});
