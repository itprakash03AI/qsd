import { test, expect } from '@playwright/test';

test.describe('Authentication (auth=none mode)', () => {
  test('should load the app and show navigation', async ({ page }) => {
    await page.goto('/');
    // In auth=none mode, app should load without a login screen
    await expect(page).toHaveURL(/\//);
    // Sidebar navigation should be visible
    const sidebar = page.locator('nav, [role="navigation"], .MuiDrawer-root');
    await expect(sidebar.first()).toBeVisible({ timeout: 10_000 });
  });

  test('should display Guest user in auth=none mode', async ({ page }) => {
    await page.goto('/');
    // Look for "Guest" text somewhere in the layout
    const guestText = page.getByText('Guest', { exact: false });
    await expect(guestText.first()).toBeVisible({ timeout: 10_000 });
  });

  test('should have key navigation items', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);
    // Check for essential nav items
    for (const label of ['Connections', 'Admin']) {
      const item = page.getByText(label, { exact: false });
      await expect(item.first()).toBeVisible({ timeout: 5_000 });
    }
  });
});
