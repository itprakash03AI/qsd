// Runtime config — synchronously loaded by index.html BEFORE the
// React bundle parses.  Production: this file is replaced by a Helm
// ConfigMap mount per environment.  Local dev: this file is served
// as-is by Vite.
//
// apiUrl:
//   - Empty string "" → fetches are relative; same-origin assumed
//     (works with Vite dev proxy locally OR nginx/ingress routing in prod).
//   - Absolute "http(s)://host:port" → fetches go to that origin directly.
//
// publishedApiUrl:
//   - Empty string "" → published API uses the same origin as apiUrl.
//   - Absolute URL  → published-views API on a separate pod / route.
//
// Helm chart in production should template this file from values.yaml,
// e.g.:
//   data:
//     config.js: |
//       window.APP_CONFIG = {
//         apiUrl: "{{ .Values.frontend.apiUrl }}",
//         publishedApiUrl: "{{ .Values.frontend.publishedApiUrl | default "" }}"
//       };
window.APP_CONFIG = {
  apiUrl: "",
  publishedApiUrl: ""
};
