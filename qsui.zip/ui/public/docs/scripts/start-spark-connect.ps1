# Start Spark Connect server inside your existing Spark Docker container.
#
# Spark Connect is BUILT INTO Spark 3.4+ — not a separate install.
# This script just `docker exec`s into your running Spark container and
# starts the bundled connect server.
#
# Usage:
#   .\start-spark-connect.ps1 -Container my-spark        # default port 15002
#   .\start-spark-connect.ps1 -Container my-spark -Port 15003
#
# After it starts, from your laptop:
#   curl -v telnet://localhost:15002 2>&1 | Select-String Connected
#
# Then in QueryStudio backend\config.json:
#   "spark_connect": { "enabled": true, "server_url": "sc://localhost:15002" }
#
# Make sure the container exposes port 15002:
#   docker run ... -p 15002:15002 apache/spark:3.5.0

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$Container,

    [int]$Port = 15002,

    [string]$SparkHome = "/opt/spark",

    [string]$ScalaVer = "2.12",

    [string]$AwsS3Endpoint = "https://s3.amazonaws.com"
)

$ErrorActionPreference = "Stop"

# Verify container exists and is running
Write-Host "Checking container '$Container'..." -ForegroundColor Cyan
$state = docker inspect -f '{{.State.Running}}' $Container 2>$null
if ($state -ne "true") {
    Write-Error "Container '$Container' is not running. Start it first with 'docker start $Container'."
    exit 1
}

# Verify Spark Connect script exists inside the container
Write-Host "Verifying Spark version inside container..." -ForegroundColor Cyan
$verOutput = docker exec $Container bash -c "$SparkHome/bin/spark-submit --version 2>&1 | grep -oE 'version [0-9]+\.[0-9]+\.[0-9]+' | head -1 | awk '{print `$2}'" 2>&1
$sparkVer = "$verOutput".Trim()

if (-not $sparkVer) {
    Write-Error "Could not detect Spark version. Is SparkHome correct? ($SparkHome)"
    exit 1
}

Write-Host "Spark version: $sparkVer" -ForegroundColor Green

$major, $minor = $sparkVer.Split('.')[0..1]
if ([int]$major -lt 3 -or ([int]$major -eq 3 -and [int]$minor -lt 4)) {
    Write-Error "Spark Connect requires 3.4+. Detected $sparkVer. Pull apache/spark:3.5.0 instead."
    exit 1
}

# Build the start command
$connectPkg = "org.apache.spark:spark-connect_${ScalaVer}:${sparkVer}"
$hadoopAws  = "org.apache.hadoop:hadoop-aws:3.3.4"
$packages   = "$connectPkg,$hadoopAws"

Write-Host ""
Write-Host "Starting Spark Connect server on port $Port..." -ForegroundColor Cyan
Write-Host "  Container       = $Container"
Write-Host "  Packages        = $packages"
Write-Host "  AWS S3 endpoint = $AwsS3Endpoint"
Write-Host ""

$cmd = @"
$SparkHome/sbin/start-connect-server.sh \
  --packages '$packages' \
  --conf 'spark.driver.bindAddress=0.0.0.0' \
  --conf 'spark.connect.grpc.binding.port=$Port' \
  --conf 'spark.hadoop.fs.s3a.endpoint=$AwsS3Endpoint' \
  --conf 'spark.hadoop.fs.s3a.aws.credentials.provider=com.amazonaws.auth.DefaultAWSCredentialsProviderChain' \
  --conf 'spark.hadoop.fs.s3a.path.style.access=true' \
  --conf 'spark.sql.parquet.compression.codec=snappy'
"@

docker exec -d $Container bash -c $cmd

# Give it a few seconds to bind the port
Start-Sleep -Seconds 8

Write-Host "Tail of Spark Connect log:" -ForegroundColor Cyan
docker exec $Container bash -c "ls -t $SparkHome/logs/spark-*connect*.out 2>/dev/null | head -1 | xargs tail -20" 2>$null

Write-Host ""
Write-Host "Done. Verify from your laptop:" -ForegroundColor Green
Write-Host "  curl -v telnet://localhost:$Port 2>&1 | Select-String Connected"
Write-Host ""
Write-Host "Then update QueryStudio backend\config.json:" -ForegroundColor Yellow
Write-Host '  "spark_connect": {'
Write-Host '    "enabled":      true,'
Write-Host "    `"server_url`":   `"sc://localhost:$Port`","
Write-Host '    "row_threshold": 1'
Write-Host '  }'
Write-Host "and restart the backend." -ForegroundColor Yellow
