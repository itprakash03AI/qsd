#!/usr/bin/env bash
# Start Spark Connect server on an existing Spark 3.4+ installation.
#
# Spark Connect is NOT a separate install — it's a feature built into Apache Spark
# 3.4 and later.  This script just starts the bundled connect server process.
#
# Run this:
#   - inside your Spark Docker container, OR
#   - inside your OpenShift Spark pod, OR
#   - on a host with $SPARK_HOME set
#
# Usage:
#   ./start-spark-connect.sh                    # default port 15002, no auth
#   PORT=15003 ./start-spark-connect.sh         # custom port
#   AWS_S3_ENDPOINT=https://s3.us-east-1.amazonaws.com ./start-spark-connect.sh
#
# After it starts, verify:
#   nc -zv localhost ${PORT:-15002}
#   tail -f /opt/spark/logs/spark-*org.apache.spark.sql.connect.service*.out
#
# Then point QueryStudio at it via config.json:
#   "spark_connect": { "enabled": true, "server_url": "sc://<host>:${PORT:-15002}" }

set -euo pipefail

# ── Resolve SPARK_HOME ─────────────────────────────────────────────────────
SPARK_HOME="${SPARK_HOME:-/opt/spark}"
if [[ ! -x "$SPARK_HOME/sbin/start-connect-server.sh" ]]; then
  echo "ERROR: $SPARK_HOME/sbin/start-connect-server.sh not found." >&2
  echo "       Check SPARK_HOME or upgrade to Spark 3.4+ (apache/spark:3.5.0)." >&2
  exit 1
fi

# ── Version check (Spark Connect requires 3.4+) ────────────────────────────
SPARK_VER=$("$SPARK_HOME/bin/spark-submit" --version 2>&1 | grep -oE "version [0-9]+\.[0-9]+\.[0-9]+" | head -1 | awk '{print $2}')
echo "Spark version detected: $SPARK_VER"
MAJOR=${SPARK_VER%%.*}
MINOR=$(echo "$SPARK_VER" | cut -d. -f2)
if (( MAJOR < 3 || (MAJOR == 3 && MINOR < 4) )); then
  echo "ERROR: Spark Connect requires 3.4+, found $SPARK_VER." >&2
  echo "       Use apache/spark:3.5.0 Docker image, or upgrade your Spark install." >&2
  exit 1
fi

# ── Resolve port + dependencies ────────────────────────────────────────────
PORT="${PORT:-15002}"
SCALA_VER="${SCALA_VER:-2.12}"
SPARK_MAJOR_MINOR="${SPARK_VER%.*}"

# Maven coordinates for the Connect package + hadoop-aws (for s3a://).
# Spark Connect is bundled in 3.4+ but the package coordinate is still needed
# so the executor classpath picks up the connect server jars.
CONNECT_PKG="org.apache.spark:spark-connect_${SCALA_VER}:${SPARK_VER}"
HADOOP_AWS_PKG="org.apache.hadoop:hadoop-aws:3.3.4"
PACKAGES="${CONNECT_PKG},${HADOOP_AWS_PKG}"

# ── AWS S3 endpoint (optional override) ────────────────────────────────────
AWS_S3_ENDPOINT="${AWS_S3_ENDPOINT:-https://s3.amazonaws.com}"

# ── Start the server ───────────────────────────────────────────────────────
echo "Starting Spark Connect server on port $PORT..."
echo "  SPARK_HOME       = $SPARK_HOME"
echo "  Packages         = $PACKAGES"
echo "  AWS_S3_ENDPOINT  = $AWS_S3_ENDPOINT"
echo

exec "$SPARK_HOME/sbin/start-connect-server.sh" \
  --packages "$PACKAGES" \
  --conf "spark.driver.bindAddress=0.0.0.0" \
  --conf "spark.connect.grpc.binding.port=$PORT" \
  --conf "spark.hadoop.fs.s3a.endpoint=$AWS_S3_ENDPOINT" \
  --conf "spark.hadoop.fs.s3a.aws.credentials.provider=com.amazonaws.auth.DefaultAWSCredentialsProviderChain" \
  --conf "spark.hadoop.fs.s3a.path.style.access=true" \
  --conf "spark.sql.parquet.compression.codec=snappy"
