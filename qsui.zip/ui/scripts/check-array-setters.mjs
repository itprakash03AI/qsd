#!/usr/bin/env node
/**
 * BF-428Q — Lint guard for the ".map is not a function" crash class.
 *
 * Why: BF-428P fixed 8 instances of this React anti-pattern across the
 * codebase, after the user reported one of them in production
 * (SystemHealthSection's circuit-breakers).  TypeScript can't catch it
 * because `useState<T[]>([])` accepts ANY value at the setter call
 * (the API response is typed `Promise<unknown>` or `any`).
 *
 * The pattern that crashes:
 *
 *   const [items, setItems] = useState<Item[]>([]);
 *   const data = await api.listItems();
 *   setItems(data);            // crashes if data = {items: [...]}
 *   // ...
 *   {items.map(...)}           // "items.map is not a function"
 *
 * The fix:
 *
 *   setItems(toArray(data));   // safe — extracts wrapper or returns []
 *
 * Heuristic — to keep false positives low, this guard only flags the
 * two narrow forms that ACTUALLY cause the crash:
 *
 *   FORM 1 (then-callback):    .then(setX)
 *                              .then(setX).catch(...)
 *
 *   FORM 2 (await-direct):     setX(await api.X(...))
 *                              setX(await safeFetch(...))
 *
 * Other "bare-name" forms (setX(rows), setX(items)) are NOT flagged —
 * those are usually preceded by validation/transform/filter that the
 * heuristic can't see through.  We accept that the guard catches only
 * the obvious crash patterns rather than chasing every theoretical
 * case (which generates noise and gets disabled).
 *
 * Allowed patterns (skipped):
 *   - .then((d) => setX(toArray(d)))     — explicit normaliser
 *   - .then(d => setX(d || []))          — falsy fallback
 *   - .then(d => setX(d ?? []))          — nullish fallback
 *   - lines with "// lint-allow-array" trailing comment
 *
 * To allow a line that the heuristic flags but is genuinely safe, add
 * the trailing comment:  // lint-allow-array
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..');
const SRC = join(ROOT, 'src');

// Directories to scan
const SCAN_DIRS = [
  join(SRC, 'components'),
  join(SRC, 'pages'),
];

const EXTS = new Set(['.tsx', '.jsx']);
const SKIP_DIRS = new Set([
  'node_modules', 'dist', 'build', '.vite', '.next', 'coverage',
  '__snapshots__', '__mocks__', '__tests__',
]);

const findings = [];

// ── Per-file scanner ─────────────────────────────────────────────────────

function scanFile(file) {
  let text;
  try { text = readFileSync(file, 'utf8'); } catch { return; }

  // Step 1: collect array-state setter names from useState declarations.
  const setters = new Set();
  // Form: const [items, setItems] = useState<Item[]>(...)
  // Form: const [items, setItems] = useState<Item[] | null>(...)
  // Form: const [items, setItems] = useState([])
  const declTyped = /const\s+\[\s*[\w$]+\s*,\s*(set[\w$]+)\s*\]\s*=\s*useState\s*<\s*[\w\s|&[\],<>{}().?:]*\[\s*\]\s*[\w\s|&[\],<>{}().?:]*>\s*\(/g;
  const declEmpty = /const\s+\[\s*[\w$]+\s*,\s*(set[\w$]+)\s*\]\s*=\s*useState\s*\(\s*\[\s*\]\s*\)/g;

  let m;
  while ((m = declTyped.exec(text)) !== null) setters.add(m[1]);
  while ((m = declEmpty.exec(text)) !== null) setters.add(m[1]);

  if (setters.size === 0) return;

  // Step 2: walk lines, flag two narrow forms.
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('// lint-allow-array')) continue;
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('*')) continue;

    for (const setter of setters) {
      // FORM 1: .then(setX) or .then(setX).catch(...) — passed as
      // raw callback with no transform.
      const thenRe = new RegExp(
        `\\.then\\s*\\(\\s*${setter}\\s*\\)`, 'g'
      );
      if (thenRe.test(line)) {
        findings.push({
          file: relative(ROOT, file).replace(/\\/g, '/'),
          line: i + 1,
          setter,
          form: 'then-callback',
          snippet: trimmed.slice(0, 120),
        });
      }

      // FORM 2: setX(await api.X(...))  or  setX(await safeFetch(...))
      // Direct assignment of awaited API result with no normaliser.
      const awaitRe = new RegExp(
        `\\b${setter}\\s*\\(\\s*await\\s+(?:api\\.|safeFetch\\b)`, 'g'
      );
      if (awaitRe.test(line)) {
        findings.push({
          file: relative(ROOT, file).replace(/\\/g, '/'),
          line: i + 1,
          setter,
          form: 'await-direct',
          snippet: trimmed.slice(0, 120),
        });
      }
    }
  }
}

// ── Walk + run ──────────────────────────────────────────────────────────

function walk(dir) {
  let entries;
  try { entries = readdirSync(dir); } catch { return; }
  for (const name of entries) {
    if (SKIP_DIRS.has(name)) continue;
    const full = join(dir, name);
    let st;
    try { st = statSync(full); } catch { continue; }
    if (st.isDirectory()) { walk(full); continue; }
    const dot = name.lastIndexOf('.');
    if (dot < 0 || !EXTS.has(name.slice(dot))) continue;
    scanFile(full);
  }
}

for (const d of SCAN_DIRS) walk(d);

if (findings.length === 0) {
  console.log('[check-array-setters] OK — scanned components/ + pages/, '
    + 'zero unguarded array-state setter assignments.');
  process.exit(0);
}

console.error(`[check-array-setters] FAIL — ${findings.length} unguarded `
  + `array-state setter assignment(s).\n`
  + `These will crash with "X.map is not a function" when the API `
  + `returns a wrapper object, null, or an error response.\n`);

for (const f of findings) {
  console.error(`  ${f.file}:${f.line}`);
  console.error(`    setter:  ${f.setter} (${f.form})`);
  console.error(`    snippet: ${f.snippet}`);
  console.error();
}

console.error(`Fix:`);
console.error(`  import { toArray } from '../utils/toArray';`);
console.error(`  setX(toArray(await api.X()));   // wraps response, never crashes`);
console.error(`  // or for .then form:`);
console.error(`  api.X().then(d => setX(toArray(d)));`);
console.error();
console.error(`If the call site is genuinely safe (data is statically a`);
console.error(`known array, type-narrowed by tsc), add a trailing comment:`);
console.error(`  // lint-allow-array`);
process.exit(1);
