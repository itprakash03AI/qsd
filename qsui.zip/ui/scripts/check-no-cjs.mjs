#!/usr/bin/env node
/**
 * BF-427 — Zero-dep lint guard banning CommonJS + eval in src/.
 *
 * Why: BF-426 #1 (CompleteQueryBuilder.tsx:395) was a CommonJS `require()` in
 * a Vite/ESM browser context — at runtime the browser threw "require is not
 * defined" and the polling effect dropped silently, so query results never
 * appeared.  TypeScript can't catch this (it accepts `require` as a global).
 *
 * This guard runs as part of `npm run lint`.  It walks src/, fails on any
 * banned pattern (CommonJS require/module.exports, raw eval), and exits
 * non-zero so CI catches the regression instantly.
 *
 * Patterns banned in src/:
 *   - require(...)         — CJS in ESM bundle is a runtime crash
 *   - module.exports = ... — same
 *   - exports.X = ...      — same
 *   - eval(...)            — security + breaks Vite's bundler
 *
 * To allow a specific line (e.g., a string literal mentioning "require"),
 * add an inline comment:  // lint-allow-cjs
 *
 * Vite config + scripts/ directory are NOT scanned (Node-side code).
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..');
const SRC = join(ROOT, 'src');

// File extensions we scan
const EXTS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);

// Directories we skip (build artefacts, deps, generated)
const SKIP_DIRS = new Set([
  'node_modules', 'dist', 'build', '.vite', '.next', 'coverage',
  '__snapshots__', '__mocks__',
]);

// Patterns banned in src/.  Each entry is { name, re, severity? }.
const BANNED = [
  {
    name: 'CommonJS require()',
    // \brequire\s*\(  — match the call form, not "requires" or "required"
    re: /\brequire\s*\(/,
    why: 'CommonJS require() throws "require is not defined" in Vite/ESM browser bundle. Use `import` instead.',
  },
  {
    name: 'CommonJS module.exports',
    re: /\bmodule\.exports\b/,
    why: 'CommonJS module.exports is silently ignored by Vite/ESM. Use `export` instead.',
  },
  {
    name: 'CommonJS exports.X',
    re: /^[\s]*exports\.\w+\s*=/m,
    why: 'CommonJS `exports.foo =` is silently ignored by Vite/ESM. Use `export const foo` instead.',
  },
  {
    name: 'eval()',
    re: /\beval\s*\(/,
    why: 'eval() is a security risk + breaks Vite\'s static analysis. Use a typed alternative.',
  },
];

// Test files are scanned but `require()` is OK in test mocks (vi.mock returns
// a factory that may use require for cyclic deps).  Detect by path segment.
const isTestFile = (p) =>
  p.includes(`${sep}__tests__${sep}`) ||
  p.endsWith('.test.ts') || p.endsWith('.test.tsx') ||
  p.endsWith('.spec.ts') || p.endsWith('.spec.tsx');

const findings = [];

const walk = (dir) => {
  let entries;
  try { entries = readdirSync(dir); } catch { return; }
  for (const name of entries) {
    if (SKIP_DIRS.has(name)) continue;
    const full = join(dir, name);
    let st;
    try { st = statSync(full); } catch { continue; }
    if (st.isDirectory()) { walk(full); continue; }
    const dot = name.lastIndexOf('.');
    if (dot < 0 || !EXTS.has(name.slice(dot))) continue;
    scan(full);
  }
};

const scan = (file) => {
  let text;
  try { text = readFileSync(file, 'utf8'); } catch { return; }
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Skip lines with explicit allow marker
    if (line.includes('// lint-allow-cjs')) continue;
    // Skip lines that are entirely comments
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('*')) continue;
    for (const rule of BANNED) {
      // Test files may legitimately use require in vi.mock factories
      if (isTestFile(file) && rule.name.startsWith('CommonJS require')) continue;
      if (rule.re.test(line)) {
        findings.push({
          file: relative(ROOT, file).replace(/\\/g, '/'),
          line: i + 1,
          rule: rule.name,
          why: rule.why,
          snippet: trimmed.slice(0, 120),
        });
      }
    }
  }
};

walk(SRC);

if (findings.length === 0) {
  console.log(`[check-no-cjs] OK — scanned src/, zero banned patterns.`);
  process.exit(0);
}

console.error(`[check-no-cjs] FAIL — ${findings.length} banned pattern(s) in src/:\n`);
for (const f of findings) {
  console.error(`  ${f.file}:${f.line}`);
  console.error(`    rule:    ${f.rule}`);
  console.error(`    why:     ${f.why}`);
  console.error(`    snippet: ${f.snippet}`);
  console.error();
}
console.error(`To allow a specific line (e.g. a string literal containing "require"),`);
console.error(`add this trailing comment:  // lint-allow-cjs`);
process.exit(1);
