/**
 * Phase 100 — Guided Tour step definitions.
 *
 * Each tour is a named array of steps. Steps target elements via CSS selectors
 * (typically `[data-tour="<name>"]` attributes added to Layout/App components).
 */

export interface TourStep {
  target: string;        // CSS selector (e.g., '[data-tour="sidebar"]')
  title: string;
  description: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

export interface TourDefinition {
  id: string;
  name: string;
  description: string;
  steps: TourStep[];
}

const tourDefinitions: TourDefinition[] = [
  {
    id: 'getting_started',
    name: 'Getting Started',
    description: 'A quick overview of QueryStudio\'s main features.',
    steps: [
      {
        target: '[data-tour="sidebar"]',
        title: 'Navigation Sidebar',
        description: 'Use the sidebar to navigate between QueryStudio\'s main areas: queries, reports, dashboards, and admin tools.',
        position: 'right',
      },
      {
        target: '[data-tour="query-builder"]',
        title: 'Query Builder',
        description: 'Build data queries visually by selecting connections, tables, and columns without writing SQL.',
        position: 'right',
      },
      {
        target: '[data-tour="assistant"]',
        title: 'AI Assistant',
        description: 'Ask questions in plain English and get SQL queries, data insights, or help with the tool.',
        position: 'left',
      },
      {
        target: '[data-tour="help-menu"]',
        title: 'Help & Tours',
        description: 'Access help documentation and restart guided tours anytime from this menu.',
        position: 'bottom',
      },
      {
        target: '[data-tour="home"]',
        title: 'Home Dashboard',
        description: 'Your starting point. View recent activity, pinned reports, and quick actions.',
        position: 'bottom',
      },
    ],
  },
  {
    id: 'query_builder',
    name: 'Query Builder',
    description: 'Learn how to build and run data queries.',
    steps: [
      {
        target: '[data-tour="connection-select"]',
        title: 'Select Connection',
        description: 'Start by picking a data connection (S3 bucket, database, or local files).',
        position: 'bottom',
      },
      {
        target: '[data-tour="table-select"]',
        title: 'Choose Tables',
        description: 'Browse and select tables or files from your data source.',
        position: 'bottom',
      },
      {
        target: '[data-tour="column-picker"]',
        title: 'Pick Columns',
        description: 'Select which columns to include. Drag to reorder them.',
        position: 'right',
      },
      {
        target: '[data-tour="filter-panel"]',
        title: 'Add Filters',
        description: 'Narrow your results by adding column filters and conditions.',
        position: 'right',
      },
      {
        target: '[data-tour="run-query"]',
        title: 'Run Query',
        description: 'Click Run to execute your query and see results in the grid below.',
        position: 'bottom',
      },
      {
        target: '[data-tour="results-grid"]',
        title: 'Results Grid',
        description: 'View, sort, filter, and export your query results. Switch to chart or pivot view.',
        position: 'top',
      },
    ],
  },
  {
    id: 'business_reports',
    name: 'Business Reports',
    description: 'Create parameterized, scheduled business reports.',
    steps: [
      {
        target: '[data-tour="reports-nav"]',
        title: 'Reports Section',
        description: 'Navigate here to create, manage, and view business reports.',
        position: 'right',
      },
      {
        target: '[data-tour="report-create"]',
        title: 'Create Report',
        description: 'Use the wizard to select a dataset or published view, pick columns, set filters, and configure parameters.',
        position: 'bottom',
      },
      {
        target: '[data-tour="report-params"]',
        title: 'Report Parameters',
        description: 'Add dropdown, date, or text parameters that users fill in before running the report.',
        position: 'right',
      },
      {
        target: '[data-tour="report-layout"]',
        title: 'Layout & Sections',
        description: 'Define break columns, running calculations, and drill-down hierarchies.',
        position: 'right',
      },
      {
        target: '[data-tour="report-execute"]',
        title: 'Execute Report',
        description: 'Fill in parameter values and run. Results support pagination, sorting, and export.',
        position: 'bottom',
      },
    ],
  },
  {
    id: 'data_quality',
    name: 'Data Quality',
    description: 'Monitor data freshness, schema, and anomalies.',
    steps: [
      {
        target: '[data-tour="dq-nav"]',
        title: 'Data Quality',
        description: 'Access data quality monitoring to track freshness, null rates, and schema changes.',
        position: 'right',
      },
      {
        target: '[data-tour="dq-create-rule"]',
        title: 'Create Rule',
        description: 'Define rules like freshness checks, null rate thresholds, row count ranges, or custom SQL assertions.',
        position: 'bottom',
      },
      {
        target: '[data-tour="dq-run"]',
        title: 'Run Checks',
        description: 'Execute rules manually or let the scheduler run them automatically.',
        position: 'bottom',
      },
      {
        target: '[data-tour="dq-results"]',
        title: 'View Results',
        description: 'See pass/fail status, metric values, and historical trends for each rule.',
        position: 'top',
      },
    ],
  },
  {
    id: 'published_views',
    name: 'Published Views',
    description: 'Share cached data via external APIs.',
    steps: [
      {
        target: '[data-tour="pv-nav"]',
        title: 'Published Views',
        description: 'Create external API endpoints that serve cached query results with authentication.',
        position: 'right',
      },
      {
        target: '[data-tour="pv-create"]',
        title: 'Create View',
        description: 'Freeze a query configuration and assign a slug (URL-friendly name) for external access.',
        position: 'bottom',
      },
      {
        target: '[data-tour="pv-test"]',
        title: 'Test Endpoint',
        description: 'Preview the API response and verify filters, parameters, and caching behavior.',
        position: 'bottom',
      },
      {
        target: '[data-tour="pv-share"]',
        title: 'Share URL',
        description: 'Copy the API URL and key. External consumers can fetch data with 8-hour cache and ETag support.',
        position: 'left',
      },
    ],
  },
];

export default tourDefinitions;
