import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useParams } from 'react-router-dom';
import { ThemeContextProvider } from './context/ThemeContext';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import CloudOffIcon from '@mui/icons-material/CloudOff';
import RefreshIcon from '@mui/icons-material/Refresh';
import Layout from './components/Layout';
import LoginPage from './components/LoginPage';
import QueryTabManager from './components/QueryTabManager';
import SavedQueries from './components/SavedQueries';
import Downloads from './components/Downloads';
import ExecutionHistory from './components/ExecutionHistory';
import ReportPage from './components/ReportPage';
import ConnectionManager from './components/ConnectionManager';
// Phase 111: ReportsManagerPage removed — /report-manager now redirects to /business-reports
import ReportConnectorsPage from './components/ReportConnectorsPage';
import FilePreviewPage from './components/FilePreviewPage';
import DashboardPage from './components/DashboardPage';
import SharedQueryPage from './components/SharedQueryPage';
import SharedDashboardPage from './components/SharedDashboardPage';
import EmbeddedReportPage from './components/EmbeddedReportPage';
import SharedBusinessReportPage from './components/SharedBusinessReportPage';
import EmbeddedBusinessReportPage from './components/EmbeddedBusinessReportPage';
import ErrorBoundary from './components/ErrorBoundary';
import PortalPasswordHost from './components/PortalPasswordHost';
import ReauthModal from './components/ReauthModal';
import ConnectionBanner from './components/ConnectionBanner';

// Lazy-loaded heavy pages — split into separate chunks to reduce initial bundle size
const AdminPage = lazy(() => import('./components/AdminPage'));
const SystemAccountsPage = lazy(() => import('./components/SystemAccountsPage'));
const LineagePage = lazy(() => import('./components/LineagePage'));
const ReportCatalogPage = lazy(() => import('./components/ReportCatalogPage'));
const DatasetManagerPage = lazy(() => import('./components/DatasetManagerPage'));
const DatasetQueryPanel = lazy(() => import('./components/DatasetQueryPanel'));
const BusinessGlossary = lazy(() => import('./components/BusinessGlossary'));
const BusinessReportBuilder = lazy(() => import('./components/BusinessReportBuilder'));
const BusinessReportViewer = lazy(() => import('./components/BusinessReportViewer'));
const PivotReportBuilder = lazy(() => import('./components/PivotReportBuilder'));
const PivotReportViewer = lazy(() => import('./components/PivotReportViewer'));
const ReportsListPage = lazy(() => import('./components/ReportsListPage'));
const UnifiedReportBuilder = lazy(() => import('./components/UnifiedReportBuilder'));
const UnifiedReportViewer = lazy(() => import('./components/UnifiedReportViewer'));
const BusinessPortalPage = lazy(() => import('./components/BusinessPortalPage'));
const SqlQueryPage = lazy(() => import('./components/SqlQueryPage'));
const SchedulesPage = lazy(() => import('./components/SchedulesPage'));
const MaterializedViewsPage = lazy(() => import('./components/MaterializedViewsPage'));
const LocalTablesPage = lazy(() => import('./components/LocalTablesPage'));
const PublishedViewsPage = lazy(() => import('./components/PublishedViewsPage'));
const ApiKeysPage = lazy(() => import('./components/ApiKeysPage'));
const FeedConfigsPage = lazy(() => import('./components/FeedConfigsPage'));
const FeedTodayPage = lazy(() => import('./components/FeedTodayPage'));
// Phase 133 — Source-vs-destination reconciliation reports
const ReconciliationPage = lazy(() => import('./components/ReconciliationPage'));
// Phase 132 — DataFlow engine UI
const DataFlowDashboardPage = lazy(() => import('./components/DataFlowDashboardPage'));
const DataFlowsPage = lazy(() => import('./components/DataFlowsPage'));
const DataFlowBuilderPage = lazy(() => import('./components/DataFlowBuilderPage'));
const DataFlowSimpleJobPage = lazy(() => import('./components/DataFlowSimpleJobPage'));
const DataFlowRunsPage = lazy(() => import('./components/DataFlowRunsPage'));
const DataFlowRunDetailPage = lazy(() => import('./components/DataFlowRunDetailPage'));
const DataFlowSchedulesPage = lazy(() => import('./components/DataFlowSchedulesPage'));
const DataFlowApprovalsPage = lazy(() => import('./components/DataFlowApprovalsPage'));
const DataFlowStageCatalogPage = lazy(() => import('./components/DataFlowStageCatalogPage'));
const DataFlowCustomStagesPage = lazy(() => import('./components/DataFlowCustomStagesPage'));
const DataFlowOpsPage = lazy(() => import('./components/DataFlowOpsPage'));
const DataFlowNotificationPoliciesPage = lazy(() => import('./components/DataFlowNotificationPoliciesPage'));
const DataFlowVariablesPage = lazy(() => import('./components/DataFlowVariablesPage'));
const DataFlowWebhooksPage = lazy(() => import('./components/DataFlowWebhooksPage'));
const FeedSodOnDemandPage = lazy(() => import('./components/FeedSodOnDemandPage'));
const FeedCalendarsPage = lazy(() => import('./components/FeedCalendarsPage'));
const MyGroupsPage = lazy(() => import('./components/MyGroupsPage'));
const FeedControlFileFormatsPage = lazy(() => import('./components/FeedControlFileFormatsPage'));
const UserGroupsPage = lazy(() => import('./components/UserGroupsPage'));
const FederationViewsPage = lazy(() => import('./components/FederationViewsPage'));
const MetadataCatalogPage = lazy(() => import('./components/MetadataCatalogPage'));
const ApiExplorerPage = lazy(() => import('./components/ApiExplorerPage'));
const DataQualityPage = lazy(() => import('./components/DataQualityPage'));
const BusinessQueryTabManager = lazy(() => import('./components/BusinessQueryTabManager'));
import { WebSocketProvider } from './context/WebSocketContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppSettingsProvider } from './context/AppSettingsContext';
import { WorkspaceProvider } from './context/WorkspaceContext';
import { AssistantContextProvider } from './context/AssistantContext';
import { UIVisibilityProvider, useComponentVisible } from './context/UIVisibilityContext';
import { TourProvider } from './context/TourContext';
import GuidedTour from './components/GuidedTour';
import NotificationCenter from './components/NotificationCenter';
import './App.css';

// Shown to logged-in AD users who lack the required role
const AccessDenied = () => {
  const { user, logout } = useAuth();
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 2 }}>
      <LockOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
      <Typography variant="h5" fontWeight={600}>Access Denied</Typography>
      <Typography color="text.secondary">
        Your account (<strong>{user?.display_name || user?.username}</strong>) does not have permission to access QueryStudio.
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Contact your administrator to be added to an authorised AD group.
      </Typography>
      <Button variant="outlined" onClick={logout}>Sign Out</Button>
    </Box>
  );
};

// Role guard — restricts route access based on RBAC role
const RoleGuard = ({ roles, children }: { roles: string[], children: React.ReactNode }) => {
  const { user, authEnabled } = useAuth();
  if (!authEnabled) return <>{children}</>;
  const role = (user as any)?.role || 'viewer';
  // Phase 107-I: super_admin bypasses all role-based route guards.
  if (role === 'super_admin') return <>{children}</>;
  if (!roles.includes(role)) return <AccessDenied />;
  return <>{children}</>;
};

// Component visibility guard — hides routes disabled by admin for the current role
const ComponentDisabledGuard = ({ componentKey, children }: { componentKey: string, children: React.ReactNode }) => {
  const visible = useComponentVisible(componentKey);
  if (!visible) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 2 }}>
        <LockOutlinedIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
        <Typography variant="h6" color="text.secondary">This feature is not available for your role.</Typography>
      </Box>
    );
  }
  return <>{children}</>;
};

// Phase 111: redirect helper that preserves :id param in the URL
const RedirectWithId = ({ basePath }: { basePath: string }) => {
  const { id } = useParams<{ id: string }>();
  return <Navigate to={id ? `${basePath}/${id}` : basePath} replace />;
};

const AppRoutes = () => {
  const { authEnabled, user, isLoading, apiOnline, retryConnection } = useAuth();
  const location = useLocation();

  // BF-468 (2026-05-19) — WebSocketProvider hoisted ABOVE the
  // conditional returns so it stays mounted regardless of
  // isLoading / authEnabled / user state changes.
  //
  // Previous shape was:
  //    if (isLoading)        return <Spinner />;       // WS not mounted
  //    if (!user)            return <LoginPage />;     // WS not mounted
  //    return <...WebSocketProvider>...               // WS mounted
  // → Any toggle of those flags unmounted WebSocketProvider, fired
  //   the cleanup's ws.close() (code 1000), and remounted on the
  //   next render → reconnect.  Repeated toggles (e.g. cross-tab
  //   storage events, transient /me failures) created a storm of
  //   close/reconnect cycles that BF-467's watchdog-removal alone
  //   could not stop, because the unmount cleanup is still the
  //   legitimate close path.
  //
  // New shape: WebSocketProvider wraps EVERYTHING.  The conditional
  // returns now sit INSIDE it, so the WS stays alive across:
  //   - Initial /me probe (isLoading false → true → false)
  //   - Login / logout (user null ↔ realUser)
  //   - Cross-tab auth sync events
  //   - Any future conditional render added to AppRoutes
  //
  // Connecting before login means the WS is anonymous until the user
  // logs in — harmless, server-routed broadcasts simply find no
  // matching user and drop.  Re-identification fires when AuthContext
  // writes qs_ws_username (BF-464v2 CustomEvent path).
  return (
    <WebSocketProvider>
      <AppRoutesInner
        authEnabled={authEnabled}
        user={user}
        isLoading={isLoading}
        apiOnline={apiOnline}
        retryConnection={retryConnection}
        location={location}
      />
    </WebSocketProvider>
  );
};

interface AppRoutesInnerProps {
  authEnabled: boolean;
  user: ReturnType<typeof useAuth>['user'];
  isLoading: boolean;
  apiOnline: boolean;
  retryConnection: () => void;
  location: ReturnType<typeof useLocation>;
}

const AppRoutesInner: React.FC<AppRoutesInnerProps> = ({
  authEnabled, user, isLoading, apiOnline, retryConnection, location,
}) => {
  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Phase 141 honest-fix: NEVER nuke the app on a network blip.  The
  // previous behaviour replaced the entire React tree with a "Backend
  // API Unavailable" screen when /health failed 5 times — destroying
  // in-flight queries, typed SQL, open tabs.  Now we render normally
  // and let the ConnectionBanner (mounted below in the main tree) show
  // a non-intrusive top banner instead.  Critical: user context is
  // preserved across transient backend hiccups.

  // Auth enabled but not logged in → login screen
  if (authEnabled && !user) {
    return <LoginPage />;
  }

  return (
    <AppSettingsProvider>
    <UIVisibilityProvider>
    <TourProvider>
    <AssistantContextProvider>
    <WorkspaceProvider>
      <NotificationProvider>
        <Layout>
          <GuidedTour />
          <NotificationCenter />
          {/* BF-285: global AWS portal password prompt — listens for
              the 'portal-password-required' CustomEvent and pops the
              modal.  Single mount point so any feature can trigger it. */}
          <PortalPasswordHost />
          {/* BF-403: global re-auth modal — overlays the app when a 401
              triggers mid-session.  Never unmounts BQB/CQB/admin pages so
              in-flight queries, typed SQL, and tabs survive re-auth. */}
          <ReauthModal />
          {/* Phase 141: non-intrusive top banner shown when the backend is
              briefly unreachable.  Replaces the old full-screen takeover
              that destroyed user context on every network blip. */}
          <ConnectionBanner />
          <ErrorBoundary resetKey={location.pathname}>
            <Suspense fallback={<Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress /></Box>}>
              <Routes>
                <Route path="/connections"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="connections"><ConnectionManager /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/materialized-views" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="materialized_views"><MaterializedViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/local-tables"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="local_tables"><LocalTablesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/lineage"            element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="lineage"><LineagePage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/datasets"          element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="semantic_layer"><DatasetManagerPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/glossary"          element={<ComponentDisabledGuard componentKey="glossary"><BusinessGlossary /></ComponentDisabledGuard>} />
                <Route path="/datasets/:id/query" element={<ComponentDisabledGuard componentKey="semantic_layer"><DatasetQueryPanel /></ComponentDisabledGuard>} />
                {/* Phase 111 — Unified Reports (all report types under one URL) */}
                <Route path="/business-reports"        element={<ComponentDisabledGuard componentKey="business_reports"><ReportsListPage /></ComponentDisabledGuard>} />
                <Route path="/business-reports/new"    element={<ComponentDisabledGuard componentKey="business_reports"><UnifiedReportBuilder /></ComponentDisabledGuard>} />
                <Route path="/business-reports/:id"    element={<ComponentDisabledGuard componentKey="business_reports"><UnifiedReportViewer /></ComponentDisabledGuard>} />
                <Route path="/business-reports/:id/edit" element={<ComponentDisabledGuard componentKey="business_reports"><UnifiedReportBuilder /></ComponentDisabledGuard>} />
                {/* Phase 111 — Legacy pivot routes redirect to unified (preserving :id) */}
                <Route path="/pivot-reports/new"      element={<Navigate to="/business-reports/new" replace />} />
                <Route path="/pivot-reports/:id"      element={<RedirectWithId basePath="/business-reports" />} />
                <Route path="/pivot-reports/:id/edit" element={<RedirectWithId basePath="/business-reports" />} />
                <Route path="/"                  element={<ComponentDisabledGuard componentKey="business_portal"><BusinessPortalPage /></ComponentDisabledGuard>} />
                <Route path="/query-builder"     element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="query_builder"><QueryTabManager /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 111 — /reports list redirects to unified; /reports/:id still works for legacy bookmarks */}
                <Route path="/reports"           element={<Navigate to="/business-reports" replace />} />
                <Route path="/reports/:reportId" element={<ComponentDisabledGuard componentKey="reports"><ReportPage /></ComponentDisabledGuard>} />
                <Route path="/saved-queries"     element={<ComponentDisabledGuard componentKey="saved_queries"><SavedQueries /></ComponentDisabledGuard>} />
                <Route path="/executions"        element={<ComponentDisabledGuard componentKey="executions"><ExecutionHistory /></ComponentDisabledGuard>} />
                <Route path="/downloads"         element={<ComponentDisabledGuard componentKey="downloads"><Downloads /></ComponentDisabledGuard>} />
                <Route path="/sql"               element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="sql_editor"><SqlQueryPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/smart-query"      element={<ComponentDisabledGuard componentKey="business_query_builder"><BusinessQueryTabManager /></ComponentDisabledGuard>} />
                {/* Phase 111 — Parametric Reports Manager redirects to unified Reports list */}
                <Route path="/report-manager"    element={<Navigate to="/business-reports" replace />} />
                <Route path="/report-catalog"    element={<ComponentDisabledGuard componentKey="report_catalog"><ReportCatalogPage /></ComponentDisabledGuard>} />
                <Route path="/report-connectors" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="report_connectors"><ReportConnectorsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/schedules"         element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="schedules"><SchedulesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/file-preview"      element={<ComponentDisabledGuard componentKey="file_preview"><FilePreviewPage /></ComponentDisabledGuard>} />
                <Route path="/dashboards"        element={<ComponentDisabledGuard componentKey="dashboards"><DashboardPage /></ComponentDisabledGuard>} />
                <Route path="/admin"             element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="admin"><AdminPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/system-accounts"  element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="system_accounts"><SystemAccountsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/published-views"  element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="published_views"><PublishedViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/api-keys"         element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="api_keys"><ApiKeysPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/feeds"           element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedConfigsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 133 — Reconciliation reports */}
                <Route path="/reconciliation"  element={<RoleGuard roles={['admin','analyst']}><ReconciliationPage /></RoleGuard>} />
                <Route path="/feeds/today"     element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="feeds"><FeedTodayPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* End-user on-demand SOD — any authenticated user (idempotent backend) */}
                <Route path="/feeds/sod"       element={<ComponentDisabledGuard componentKey="feeds"><FeedSodOnDemandPage /></ComponentDisabledGuard>} />
                <Route path="/feeds/calendars" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="feeds"><FeedCalendarsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/feeds/control-file-formats" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="feeds"><FeedControlFileFormatsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/admin/user-groups" element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="admin"><UserGroupsPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 130 hotfix-13 — end-user My Groups (any authenticated user) */}
                <Route path="/my-groups"         element={<MyGroupsPage />} />
                <Route path="/federation-views" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="federation_views"><FederationViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/catalog"        element={<ComponentDisabledGuard componentKey="data_catalog"><MetadataCatalogPage /></ComponentDisabledGuard>} />
                <Route path="/api-explorer"  element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="api_explorer"><ApiExplorerPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/data-quality" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="data_quality"><DataQualityPage /></ComponentDisabledGuard></RoleGuard>} />
                {/* Phase 132 — DataFlow engine routes (admin) */}
                <Route path="/dataflows"                  element={<RoleGuard roles={['admin','analyst']}><DataFlowDashboardPage /></RoleGuard>} />
                <Route path="/dataflows/list"             element={<RoleGuard roles={['admin','analyst']}><DataFlowsPage /></RoleGuard>} />
                {/* /dataflows/new defaults to the Simple Job builder; the
                    Advanced DAG editor is at /dataflows/new/advanced.
                    Both write into the same DataFlow rows. */}
                <Route path="/dataflows/new"              element={<RoleGuard roles={['admin']}><DataFlowSimpleJobPage /></RoleGuard>} />
                <Route path="/dataflows/new/advanced"     element={<RoleGuard roles={['admin']}><DataFlowBuilderPage /></RoleGuard>} />
                <Route path="/dataflows/simple/:id"       element={<RoleGuard roles={['admin','analyst']}><DataFlowSimpleJobPage /></RoleGuard>} />
                <Route path="/dataflows/runs"             element={<RoleGuard roles={['admin','analyst']}><DataFlowRunsPage /></RoleGuard>} />
                <Route path="/dataflows/ops"              element={<RoleGuard roles={['admin','analyst']}><DataFlowOpsPage /></RoleGuard>} />
                <Route path="/dataflows/notification-policies" element={<RoleGuard roles={['admin']}><DataFlowNotificationPoliciesPage /></RoleGuard>} />
                <Route path="/dataflows/variables"        element={<RoleGuard roles={['admin']}><DataFlowVariablesPage /></RoleGuard>} />
                <Route path="/dataflows/webhooks"         element={<RoleGuard roles={['admin']}><DataFlowWebhooksPage /></RoleGuard>} />
                <Route path="/dataflows/runs/:id"         element={<RoleGuard roles={['admin','analyst']}><DataFlowRunDetailPage /></RoleGuard>} />
                <Route path="/dataflows/schedules"        element={<RoleGuard roles={['admin']}><DataFlowSchedulesPage /></RoleGuard>} />
                <Route path="/dataflows/approvals"        element={<RoleGuard roles={['admin']}><DataFlowApprovalsPage /></RoleGuard>} />
                <Route path="/dataflows/stages"           element={<RoleGuard roles={['admin','analyst']}><DataFlowStageCatalogPage /></RoleGuard>} />
                <Route path="/dataflows/custom-stages"    element={<RoleGuard roles={['admin']}><DataFlowCustomStagesPage /></RoleGuard>} />
                <Route path="/dataflows/:id"              element={<RoleGuard roles={['admin','analyst']}><DataFlowBuilderPage /></RoleGuard>} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </Layout>
      </NotificationProvider>
    </WorkspaceProvider>
    </AssistantContextProvider>
    </TourProvider>
    </UIVisibilityProvider>
    </AppSettingsProvider>
  );
};

function App() {
  return (
    <ThemeContextProvider>
      <Router>
        {/* Public routes — no auth required */}
        <Routes>
          <Route path="/shared/:token" element={<SharedQueryPage />} />
          <Route path="/shared-dashboard/:token" element={<SharedDashboardPage />} />
          <Route path="/shared-business-report/:token" element={<SharedBusinessReportPage />} />
          <Route path="/embed/:token" element={<EmbeddedReportPage />} />
          <Route path="/embedded-business-report/:token" element={<EmbeddedBusinessReportPage />} />
          <Route path="/*" element={
            <AuthProvider>
              <AppRoutes />
            </AuthProvider>
          } />
        </Routes>
      </Router>
    </ThemeContextProvider>
  );
}

export default App;
