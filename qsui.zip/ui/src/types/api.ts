/**
 * Phase 117 — Shared TypeScript interfaces for API responses.
 * Replaces scattered `any` types across the codebase.
 */

// ── Connections ──────────────────────────────────────────────────────────────

export interface Connection {
  id: number;
  name: string;
  connection_type: 's3' | 'snowflake' | 'databricks' | 'trino' | 'starburst' | 'oracle' | 'athena' | 'rest_api' | 'postgresql' | 'local' | 'upload';
  config: Record<string, unknown>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  created_by?: string;
}

// ── Tables & Files ───────────────────────────────────────────────────────────

export interface TableFile {
  key: string;
  path: string;
  name: string;
  size?: number;
  last_modified?: string;
  is_folder?: boolean;
  is_partition?: boolean;
  partition_column?: string;
  partition_value?: string;
  file_count?: number;
}

export interface Column {
  name: string;
  type: string;
  nullable?: boolean;
  description?: string;
  is_partition?: boolean;
  friendly_name?: string;
  format_pattern?: string;
  column_type?: 'dimension' | 'measure' | 'detail' | 'kpi';
  aggregation?: string;
}

// ── Query Building ───────────────────────────────────────────────────────────

export interface Filter {
  column: string;
  operator: string;
  value: string | string[];
  _partition?: boolean;
}

export interface Join {
  left_file: string;
  right_file: string;
  left_on: string[];
  right_on: string[];
  how: 'inner' | 'left' | 'right' | 'cross';
  right_suffix?: string;
}

export interface Aggregation {
  column: string;
  function: 'SUM' | 'AVG' | 'COUNT' | 'MIN' | 'MAX' | 'COUNT_DISTINCT';
  alias: string;
  distinct?: boolean;
}

export interface OrderBy {
  column: string;
  direction: 'ASC' | 'DESC';
}

export interface QueryConfig {
  connection_id: number;
  files: string[];
  columns?: string[];
  joins?: Join[];
  filters?: Filter[];
  order_by?: OrderBy[];
  limit?: number | null;
  aggregations?: Aggregation[];
  distinct?: boolean;
  filter_logic?: 'AND' | 'OR';
}

// ── Query Results ────────────────────────────────────────────────────────────

export interface QueryResult {
  execution_id: string;
  status: 'completed' | 'failed' | 'processing' | 'queued';
  columns: string[];
  rows: any[][];
  row_count: number;
  execution_time_ms: number;
  cache_hit?: boolean;
  error?: string;
}

// ── Users & Auth ─────────────────────────────────────────────────────────────

export interface User {
  username: string;
  role: 'admin' | 'analyst' | 'viewer' | 'super_admin';
  is_admin?: boolean;
  display_name?: string;
  email?: string;
  created_at?: string;
  last_login_at?: string;
}

// ── Audit ────────────────────────────────────────────────────────────────────

export interface AuditEntry {
  id: number;
  timestamp: string;
  username: string;
  action: string;
  resource_type?: string;
  resource_id?: string;
  ip_address?: string;
  details?: Record<string, unknown>;
}

// ── Cache ────────────────────────────────────────────────────────────────────

export interface CacheEntry {
  cache_key: string;
  connection_id: number;
  created_at: string;
  expires_at: string;
  row_count: number;
  size_bytes: number;
  hit_count: number;
  source_fingerprint?: string;
  is_stale?: boolean;
}

// ── Business Reports ─────────────────────────────────────────────────────────

export interface BusinessReport {
  id: number;
  name: string;
  description?: string;
  data_source_type: 'dataset' | 'raw_sql' | 'published_view' | 'pivot';
  dataset_id?: number;
  published_view_id?: number;
  layout_config: Record<string, unknown>;
  owner: string;
  is_published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface ReportParameter {
  id: number;
  report_id: number;
  param_name: string;
  param_type: 'text' | 'number' | 'date' | 'select' | 'multi_select' | 'date_range';
  default_value?: string;
  lov_source?: string;
  lov_dataset_id?: number;
  required?: boolean;
  display_order?: number;
}

// ── Pivot Config ─────────────────────────────────────────────────────────────

export interface PivotValueField {
  column_id: number;
  aggregation: string;
  alias?: string;
}

export interface PivotConfig {
  row_field_ids: number[];
  col_field_ids: number[];
  value_fields: PivotValueField[];
  show_row_totals?: boolean;
  show_col_totals?: boolean;
  show_grand_total?: boolean;
}

// ── Style Config ─────────────────────────────────────────────────────────────

export interface StyleConfig {
  header_bg?: string;
  header_fg?: string;
  row_alt_bg?: string;
  negative_color?: string;
  negative_format?: 'minus' | 'parentheses' | 'red' | 'red_parentheses';
}

// ── Published Views ──────────────────────────────────────────────────────────

export interface PublishedView {
  id: number;
  name: string;
  slug: string;
  description?: string;
  dataset_id: number;
  query_config: QueryConfig;
  param_definitions?: Record<string, unknown>[];
  cache_ttl: number;
  version: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// ── Data Quality ─────────────────────────────────────────────────────────────

export interface DataQualityRule {
  id: number;
  name: string;
  rule_type: 'freshness' | 'schema_drift' | 'null_rate' | 'row_count' | 'custom_sql';
  connection_id: number;
  table_name: string;
  config: Record<string, unknown>;
  severity: 'info' | 'warning' | 'critical';
  is_active: boolean;
  last_result?: 'pass' | 'fail' | null;
}

// ── Health ────────────────────────────────────────────────────────────────────

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  database: { ok: boolean };
  s3: { status: string };
  disk: { free_gb: number; used_pct: number; warning: boolean };
  queries: {
    active: number;
    max_concurrent_global: number;
    per_user_limit: number;
    queue_waiting: number;
  };
}
