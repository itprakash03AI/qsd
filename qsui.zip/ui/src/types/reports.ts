/**
 * Phase 117 — Report-specific TypeScript interfaces.
 */
import type { StyleConfig, PivotConfig, ReportParameter } from './api';

export interface ReportLayoutConfig {
  report_type?: 'standard' | 'pivot' | 'raw_sql';
  pivot_config?: PivotConfig;
  style_config?: StyleConfig;
  column_order?: string[];
  viewer_prefs?: Record<string, unknown>;
  sections?: ReportSection[];
  measures?: ReportMeasure[];
}

export interface ReportSection {
  id: string;
  label: string;
  break_column?: string;
  sort_column?: string;
  sort_direction?: 'ASC' | 'DESC';
  children?: ReportSection[];
}

export interface ReportMeasure {
  column: string;
  aggregation: string;
  alias: string;
  format_pattern?: string;
}

export interface ReportExecution {
  id: number;
  report_id: number;
  execution_id: string;
  status: 'completed' | 'failed' | 'running';
  row_count?: number;
  execution_time_ms?: number;
  executed_by: string;
  executed_at: string;
  error?: string;
}

export interface ReportComment {
  id: number;
  report_id: number;
  parent_id?: number;
  username: string;
  content: string;
  mentions?: string[];
  is_resolved?: boolean;
  created_at: string;
  updated_at?: string;
  replies?: ReportComment[];
}

export interface ReportChangeLogEntry {
  id: number;
  report_id: number;
  action: string;
  changed_by: string;
  changed_at: string;
  field_changes?: Record<string, { old: unknown; new: unknown }>;
}

export type { StyleConfig, PivotConfig, ReportParameter };
