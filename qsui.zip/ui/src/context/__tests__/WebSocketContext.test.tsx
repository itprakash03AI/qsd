/**
 * BF-469 (2026-05-19) — WebSocket lives outside React.
 *
 * Source-level contract tests that lock in the architecture:
 *   1. The actual WebSocket lives at module scope in
 *      services/wsService.ts (NOT in WebSocketContext.tsx).
 *   2. WebSocketContext.tsx is now a THIN wrapper that only
 *      subscribes/unsubscribes — it does NOT call new WebSocket()
 *      or ws.close() at any point.
 *   3. wsService auto-starts on module import (start() called at
 *      module bottom) so the WS is alive BEFORE any React mount.
 *   4. wsService still has reconnect with circuit breaker for
 *      genuine network instability.
 *   5. There is no `setInterval` calling close() — watchdog stays
 *      forbidden.
 *   6. WebSocketProvider must still be mounted above conditional
 *      returns in AppRoutes (legacy BF-468 guarantee, though now
 *      less critical since the WS itself is outside React).
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';

const CTX_PATH  = path.resolve(__dirname, '..', 'WebSocketContext.tsx');
const SVC_PATH  = path.resolve(__dirname, '..', '..', 'services', 'wsService.ts');
const APP_PATH  = path.resolve(__dirname, '..', '..', 'App.tsx');

describe('BF-471 — isolation + debounced visual state + stable method refs', () => {
  const ctxSrc = fs.readFileSync(CTX_PATH, 'utf-8');
  const svcSrc = fs.readFileSync(SVC_PATH, 'utf-8');

  it('wsService debounces isConnected → false (brief reconnects do NOT flip Offline)', () => {
    // The visual flag must be debounced so quick close/reconnect
    // cycles don't show "Offline" in the Layout chip.
    expect(svcSrc).toMatch(/visualConnectedFlag/);
    expect(svcSrc).toMatch(/DEBOUNCE_OFFLINE_MS/);
    expect(svcSrc).toMatch(/updateVisualConnected/);
  });

  it('wsService exposes raw socket state separately for code that needs truth', () => {
    // ``isConnected`` getter returns DEBOUNCED visual; ``rawIsConnected``
    // returns the raw socket flag (used by send() readyState check).
    expect(svcSrc).toMatch(/get isConnected[\s\S]*?visualConnectedFlag/);
    expect(svcSrc).toMatch(/get rawIsConnected/);
  });

  it('Context method refs are MODULE-LEVEL stable (not re-created per render)', () => {
    // BF-471 — sendMessage / addListener / registerExecutionHeartbeat
    // are defined as a single _delegated object at module scope, so
    // their identity never changes.  Consumers using only methods
    // (e.g. <AddListenerOnly>) retain stable useEffect deps.
    expect(ctxSrc).toMatch(/_delegated\s*=\s*\{/);
    expect(ctxSrc).toMatch(/sendMessage:\s*_delegated\.sendMessage/);
    expect(ctxSrc).toMatch(/addListener:\s*_delegated\.addListener/);
    expect(ctxSrc).toMatch(/registerExecutionHeartbeat:\s*_delegated\.registerExecutionHeartbeat/);
  });

  it('HTTP services (api/core) do NOT import useWebSocket — WS failure cannot block HTTP', () => {
    // Architectural invariant: HTTP transport is independent of WS.
    // safeFetch must succeed regardless of WS state.
    const apiCorePath = path.resolve(__dirname, '..', '..', 'services', 'api', 'core.ts');
    if (fs.existsSync(apiCorePath)) {
      const apiSrc = fs.readFileSync(apiCorePath, 'utf-8');
      expect(apiSrc).not.toMatch(/useWebSocket|wsService/);
    }
  });
});

describe('WebSocket architecture (BF-469)', () => {
  const ctxSrc = fs.readFileSync(CTX_PATH, 'utf-8');
  const svcSrc = fs.readFileSync(SVC_PATH, 'utf-8');

  it('the actual WebSocket is constructed in wsService.ts, NOT in WebSocketContext.tsx', () => {
    // WebSocketContext must not directly construct a WebSocket — that
    // would put a long-lived connection back under React's lifecycle.
    expect(ctxSrc).not.toMatch(/new WebSocket\(/);
    // The construction must live in wsService.
    expect(svcSrc).toMatch(/new WebSocket\(/);
  });

  it('WebSocketContext.tsx does NOT call ws.close()', () => {
    // The whole point of moving the WS out of React: cleanup paths
    // must not close the connection.  No ws.close() in the React
    // context anywhere.
    expect(ctxSrc).not.toMatch(/\.close\(\)/);
  });

  it('wsService auto-starts on module import', () => {
    // The singleton must connect when the bundle loads, BEFORE any
    // React tree mounts.  Locked by a top-level call to
    // wsService.start() near module bottom.
    expect(svcSrc).toMatch(/wsService\.start\(\)/);
    expect(svcSrc).toMatch(/export const wsService = new WsService/);
  });

  it('wsService preserves the BF-467 forbidden-pattern guard', () => {
    // No setInterval body containing sinceLastPing AND close() —
    // the watchdog stays banned.
    const hasWatchdog = /setInterval[\s\S]*?sinceLastPing[\s\S]*?\.close\(\)/.test(svcSrc);
    expect(hasWatchdog).toBe(false);
  });

  it('wsService has the circuit breaker for storm bursts', () => {
    expect(svcSrc).toMatch(/STORM_THRESHOLD/);
    expect(svcSrc).toMatch(/STORM_COOLDOWN_MS/);
  });

  it('wsService has exponential backoff reconnect path', () => {
    expect(svcSrc).toMatch(/Math\.pow\(2,\s*this\.reconnectAttempts/);
  });

  it('wsService schedules reconnect on construction failure (deep-dive gap #1)', () => {
    // Without this, a transient WS construction failure at boot
    // (malformed URL, browser policy) would leave the service
    // permanently broken.
    expect(svcSrc).toMatch(/construction failed/);
    // Find the slice of source FROM the construction-failed log
    // through the next ~500 chars and assert setTimeout reconnect
    // path is present in that slice.
    const idx = svcSrc.indexOf('construction failed');
    expect(idx).toBeGreaterThan(-1);
    const tail = svcSrc.slice(idx, idx + 500);
    expect(tail).toMatch(/setTimeout/);
    expect(tail).toMatch(/Math\.pow\(2,/);
  });

  it('wsService has tab-visibility recovery (deep-dive gap #2)', () => {
    // Mobile / desktop browsers close idle WS in background tabs.
    // When the user returns, we forceReconnect immediately instead
    // of waiting for the next backoff tick (which may have given up).
    expect(svcSrc).toMatch(/visibilitychange/);
    expect(svcSrc).toMatch(/forceReconnect/);
  });

  it('wsService has HMR cleanup hook (deep-dive gap #3)', () => {
    // In Vite dev, hot-replacing this module would orphan the old
    // singleton's WS + timers, leaking on every save.  import.meta.hot
    // .dispose closes them before the replacement loads.
    expect(svcSrc).toMatch(/import\.meta\.hot/);
    expect(svcSrc).toMatch(/dispose/);
  });

  it('App.tsx still mounts WebSocketProvider above conditional returns (defense in depth)', () => {
    // Even though the WS now lives at module scope, keeping
    // WebSocketProvider above conditional returns means the
    // CONTEXT (and thus useWebSocket consumers) stays available
    // for all branches — login screen too.  Locked by the BF-468
    // contract.
    const appSrc = fs.readFileSync(APP_PATH, 'utf-8');
    const appRoutesMatch = appSrc.match(/const AppRoutes = \(\) => \{([\s\S]*?)^\};/m);
    expect(appRoutesMatch).not.toBeNull();
    const body = appRoutesMatch![1];
    const firstReturnIdx = body.search(/^\s*return\s+\(/m);
    expect(firstReturnIdx).toBeGreaterThan(-1);
    const firstReturnBlock = body.slice(firstReturnIdx, firstReturnIdx + 500);
    expect(firstReturnBlock).toMatch(/<WebSocketProvider>/);
  });
});
