/**
 * UIVisibilityContext — provides useComponentVisible(key) hook.
 *
 * A component is considered "enabled" unless there is an explicit false entry
 * for the current user's role in component_visibility (from /api/app-settings).
 * Defaults to true for any key not present in the map (safe default = show).
 *
 * Phase 107-I additions:
 *   1. super_admin bypass — role === "super_admin" → always returns true.
 *      Backend already returns {} for super_admin, but we double-guard here.
 *   2. Sub-feature parent cascade — if a key contains a dot ("pivot_reports.builder"),
 *      we ALSO check the parent ("pivot_reports") and return false if the parent
 *      is disabled. Mirrors the backend cascade so dynamic sub-features stay
 *      hidden when their parent is gated.
 */
import React, { createContext, useContext } from 'react';
import { useAppSettings } from './AppSettingsContext';

interface UIVisibilityContextValue {
  isVisible: (componentKey: string) => boolean;
}

const UIVisibilityContext = createContext<UIVisibilityContextValue>({
  isVisible: () => true,
});

export const useComponentVisible = (componentKey: string): boolean => {
  const { isVisible } = useContext(UIVisibilityContext);
  return isVisible(componentKey);
};

export const UIVisibilityProvider = ({ children }: { children: React.ReactNode }) => {
  const settings = useAppSettings();

  const isVisible = (componentKey: string): boolean => {
    if (!settings.loaded) return true; // default show until settings load

    // Phase 107-I: super_admin sees everything
    if (settings.role === 'super_admin') return true;

    const vis = settings.component_visibility;

    // Phase 107-I: parent cascade for dot-notation sub-features
    if (componentKey.includes('.')) {
      const parent = componentKey.split('.', 1)[0];
      if (vis && Object.prototype.hasOwnProperty.call(vis, parent) && vis[parent] === false) {
        return false;
      }
    }

    if (vis && Object.prototype.hasOwnProperty.call(vis, componentKey)) {
      return vis[componentKey] !== false;
    }
    return true; // not explicitly disabled → show
  };

  return (
    <UIVisibilityContext.Provider value={{ isVisible }}>
      {children}
    </UIVisibilityContext.Provider>
  );
};
