/**
 * AssistantContext — shares the current page's connection/schema context
 * with GlobalAssistantPanel so it can produce smarter NL→SQL and schema
 * answers without needing an LLM.
 *
 * Usage (in any page component):
 *   const { setAssistantCtx } = useAssistantContext();
 *   useEffect(() => { setAssistantCtx({ connectionId: 3, tables: ['orders', 'customers'] }); }, []);
 */
import React, { createContext, useContext, useState } from 'react';

export interface AssistantCtxValue {
  connectionId?: number;
  connectionType?: string;   // e.g. 'duckdb', 'snowflake', 'trino'
  tables: string[];
  columns: Record<string, string[]>;   // table → column list
  pageName?: string;                   // e.g. 'sql', 'query-builder'
  // Active result grid context (set by DataGridViewer when results load)
  executionId?: string;
  fileId?: string;                     // download file id (S3 / uploaded file)
  resultColumns?: string[];            // column names from the current grid result
  resultData?: Record<string, any>[];  // first N rows of data (for column classification)
  columnTypes?: Record<string, string>; // column name → DuckDB type (for classification)
  // Phase 57 — Semantic dataset context
  datasetId?: number;
  datasetName?: string;
  // Chart push: chatbot → DataGridViewer (triggers chart tab + rendering)
  chartPush?: {
    chartType: string;   // 'bar' | 'line' | 'area' | 'pie' | 'scatter'
    xCol: string;
    yCol: string;
    agg?: string;        // 'sum' | 'avg' | 'count' | 'max' | 'min'
    title?: string;      // chart title (from presets)
    ts: number;          // timestamp to detect new requests (even same config)
  };
  // Pivot push: chatbot → DataGridViewer (triggers pivot tab + rendering)
  pivotPush?: {
    rowFields?: string[];
    colField?: string;
    values?: { column: string; function: string }[];
    label?: string;
    ts: number;
  };
  setAssistantCtx: (update: Partial<Omit<AssistantCtxValue, 'setAssistantCtx'>>) => void;
}

const AssistantContext = createContext<AssistantCtxValue>({
  tables: [],
  columns: {},
  setAssistantCtx: () => {},
});

export const AssistantContextProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<Omit<AssistantCtxValue, 'setAssistantCtx'>>({
    tables: [],
    columns: {},
  });
  return (
    <AssistantContext.Provider
      value={{
        ...state,
        setAssistantCtx: (update) => setState(prev => ({ ...prev, ...update })),
      }}
    >
      {children}
    </AssistantContext.Provider>
  );
};

export const useAssistantContext = () => useContext(AssistantContext);
