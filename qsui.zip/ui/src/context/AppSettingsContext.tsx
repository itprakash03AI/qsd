import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { safeFetch } from '../services/api/core';

export interface AppLimits {
  col_auto_project: number;
  default_query_limit: number;
  streaming_default_on: boolean;
  stream_bg_download_default: boolean;
  max_display_cols: number;
  stream_query_limit_max: number;
  max_stream_files: number;
}

export interface AppFeatures {
  streaming_mode: string;
  streaming_enabled: boolean;
  export_enabled: boolean;
  sql_editor_enabled: boolean;
  scheduler_enabled: boolean;
  connections_enabled: boolean;
  upload_enabled: boolean;
  max_query_limit: number;
}

export interface QueryGuardrails {
  enabled: boolean;
  max_files_warn: number;
  max_files_block: number;
  max_rows_warn: number;
  max_rows_block: number;
  require_partition_filter: boolean;
  warn_no_partition: boolean;
  warn_no_limit: boolean;
  default_limit_suggestion: number;
}

export interface WorkspaceInfo {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  member_count?: number;
}

export interface AppSettings {
  limits: AppLimits;
  features: AppFeatures;
  query_guardrails: QueryGuardrails;
  role: string;
  loaded: boolean;
  component_visibility: Record<string, boolean>;
  active_connection_profile?: { id: number; name: string } | null;
  workspaces?: WorkspaceInfo[];
}

const DEFAULTS: AppSettings = {
  limits: {
    col_auto_project: 50,
    default_query_limit: 1000,
    streaming_default_on: false,
    stream_bg_download_default: true,
    max_display_cols: 50,
    stream_query_limit_max: 5000,
    max_stream_files: 200,
  },
  features: {
    streaming_mode: 'all',
    streaming_enabled: true,
    export_enabled: true,
    sql_editor_enabled: true,
    scheduler_enabled: true,
    connections_enabled: true,
    upload_enabled: true,
    max_query_limit: 0,
  },
  query_guardrails: {
    enabled: true,
    // 2026-06-04 — defaults raised so 3000-file Iceberg BQB scans
    // don't get blocked before the pruner runs.  Backend mirrors.
    max_files_warn: 500,
    max_files_block: 5000,
    max_rows_warn: 10000000,
    max_rows_block: 100000000,
    require_partition_filter: false,
    warn_no_partition: true,
    warn_no_limit: true,
    default_limit_suggestion: 1000,
  },
  role: 'admin',
  loaded: false,
  component_visibility: {},
};

const AppSettingsContext = createContext<AppSettings>(DEFAULTS);
const AppSettingsRefreshContext = createContext<() => void>(() => {});

export const useAppSettings = () => useContext(AppSettingsContext);
export const useAppSettingsRefresh = () => useContext(AppSettingsRefreshContext);

export const AppSettingsProvider = ({ children }: { children: ReactNode }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULTS);

  const fetchSettings = useCallback(async () => {
    try {
      const data = await safeFetch('/api/app-settings');
      setSettings({ ...data, loaded: true });
    } catch {
      // Use defaults if fetch fails
    }
  }, []);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  return (
    <AppSettingsContext.Provider value={settings}>
      <AppSettingsRefreshContext.Provider value={fetchSettings}>
        {children}
      </AppSettingsRefreshContext.Provider>
    </AppSettingsContext.Provider>
  );
};
