/**
 * Phase 100 — Tour Context.
 *
 * Manages guided tour state: which tour is active, current step, completion tracking.
 * Persists to localStorage (immediate) and backend user-preferences (cross-device).
 */
import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import tourDefinitions, { TourDefinition, TourStep } from '../config/tourDefinitions';
import api from '../services/api';

interface TourState {
  activeTourId: string | null;
  currentStep: number;
  completedTours: Set<string>;
  dismissedTours: Set<string>;
}

interface TourContextValue {
  activeTour: TourDefinition | null;
  currentStep: number;
  currentStepData: TourStep | null;
  totalSteps: number;
  startTour: (tourId: string) => void;
  nextStep: () => void;
  prevStep: () => void;
  dismissTour: () => void;
  completeTour: () => void;
  isTourCompleted: (tourId: string) => boolean;
  isTourDismissed: (tourId: string) => boolean;
  availableTours: TourDefinition[];
}

const TourContext = createContext<TourContextValue | null>(null);

const LS_KEY = 'qs_tour_state';

function loadFromStorage(): { completed: string[]; dismissed: string[] } {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { completed: [], dismissed: [] };
}

function saveToStorage(completed: string[], dismissed: string[]) {
  localStorage.setItem(LS_KEY, JSON.stringify({ completed, dismissed }));
}

export const TourProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<TourState>(() => {
    const stored = loadFromStorage();
    return {
      activeTourId: null,
      currentStep: 0,
      completedTours: new Set(stored.completed),
      dismissedTours: new Set(stored.dismissed),
    };
  });

  const syncedRef = useRef(false);

  // Load from backend on mount (cross-device sync)
  useEffect(() => {
    if (syncedRef.current) return;
    syncedRef.current = true;
    api.getUserPreference('tours_completed').then((res: any) => {
      if (res?.value) {
        try {
          const backendCompleted: string[] = JSON.parse(res.value);
          setState(prev => {
            const merged = new Set([...prev.completedTours, ...backendCompleted]);
            saveToStorage([...merged], [...prev.dismissedTours]);
            return { ...prev, completedTours: merged };
          });
        } catch { /* ignore */ }
      }
    }).catch(() => { /* 404 = no prefs yet */ });
  }, []);

  const persistToBackend = useCallback((completed: Set<string>) => {
    api.setUserPreference('tours_completed', JSON.stringify([...completed])).catch(() => {});
  }, []);

  const startTour = useCallback((tourId: string) => {
    const tour = tourDefinitions.find(t => t.id === tourId);
    if (!tour) return;
    setState(prev => ({ ...prev, activeTourId: tourId, currentStep: 0 }));
  }, []);

  // Listen for qs:start-tour events from assistant panel
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.tourId) startTour(detail.tourId);
    };
    window.addEventListener('qs:start-tour', handler);
    return () => window.removeEventListener('qs:start-tour', handler);
  }, [startTour]);

  const nextStep = useCallback(() => {
    setState(prev => {
      const tour = tourDefinitions.find(t => t.id === prev.activeTourId);
      if (!tour) return prev;
      if (prev.currentStep >= tour.steps.length - 1) {
        // Complete the tour
        const newCompleted = new Set([...prev.completedTours, prev.activeTourId!]);
        saveToStorage([...newCompleted], [...prev.dismissedTours]);
        persistToBackend(newCompleted);
        return { ...prev, activeTourId: null, currentStep: 0, completedTours: newCompleted };
      }
      return { ...prev, currentStep: prev.currentStep + 1 };
    });
  }, [persistToBackend]);

  const prevStep = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentStep: Math.max(0, prev.currentStep - 1),
    }));
  }, []);

  const dismissTour = useCallback(() => {
    setState(prev => {
      if (!prev.activeTourId) return prev;
      const newDismissed = new Set([...prev.dismissedTours, prev.activeTourId]);
      saveToStorage([...prev.completedTours], [...newDismissed]);
      return { ...prev, activeTourId: null, currentStep: 0, dismissedTours: newDismissed };
    });
  }, []);

  const completeTour = useCallback(() => {
    setState(prev => {
      if (!prev.activeTourId) return prev;
      const newCompleted = new Set([...prev.completedTours, prev.activeTourId]);
      saveToStorage([...newCompleted], [...prev.dismissedTours]);
      persistToBackend(newCompleted);
      return { ...prev, activeTourId: null, currentStep: 0, completedTours: newCompleted };
    });
  }, [persistToBackend]);

  const isTourCompleted = useCallback((tourId: string) => state.completedTours.has(tourId), [state.completedTours]);
  const isTourDismissed = useCallback((tourId: string) => state.dismissedTours.has(tourId), [state.dismissedTours]);

  const activeTour = state.activeTourId ? tourDefinitions.find(t => t.id === state.activeTourId) || null : null;
  const currentStepData = activeTour ? activeTour.steps[state.currentStep] || null : null;

  const value: TourContextValue = {
    activeTour,
    currentStep: state.currentStep,
    currentStepData,
    totalSteps: activeTour ? activeTour.steps.length : 0,
    startTour,
    nextStep,
    prevStep,
    dismissTour,
    completeTour,
    isTourCompleted,
    isTourDismissed,
    availableTours: tourDefinitions,
  };

  return <TourContext.Provider value={value}>{children}</TourContext.Provider>;
};

export const useTour = (): TourContextValue => {
  const ctx = useContext(TourContext);
  if (!ctx) throw new Error('useTour must be used within TourProvider');
  return ctx;
};

export default TourContext;
