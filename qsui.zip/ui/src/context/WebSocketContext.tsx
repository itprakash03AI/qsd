/**
 * BF-469 (2026-05-19) — WebSocketContext is now a THIN React wrapper
 * over the module-level wsService singleton.  The actual WebSocket
 * lives at module scope (services/wsService.ts) and is unaffected by
 * any React component lifecycle event — mount, unmount, conditional
 * return, error boundary, route change, StrictMode double-invoke,
 * etc.
 *
 * The full story:
 *   - BF-467 removed the client-side heartbeat watchdog (was tearing
 *     down healthy WS on event-loop blocks).
 *   - BF-468 hoisted <WebSocketProvider> above AppRoutes' conditional
 *     returns (was tearing down WS when isLoading or user state
 *     toggled).
 *   - BF-469 moved the WS connection out of React ENTIRELY so no
 *     future restructuring can re-introduce the close/reconnect bugs.
 *
 * Public API (unchanged from prior versions for consumer compat):
 *   useWebSocket() → { isConnected, lastMessage, connectionError,
 *                      sendMessage, addListener,
 *                      registerExecutionHeartbeat }
 */
import React, { createContext, useContext, useEffect, useMemo, useState, ReactNode } from 'react';
import { wsService, type WsMessage, type WsState } from '../services/wsService';

// BF-471 — module-level stable delegates so the Context value can
// reference them without recomputing on each render.  Components
// that destructure only methods (addListener, sendMessage, etc.)
// retain stable identity for their useEffect deps.
const _delegated = {
  sendMessage: (msg: object) => wsService.send(msg),
  addListener: (cb: (m: WsMessage) => void) => wsService.addListener(cb),
  registerExecutionHeartbeat: (eid: string) => wsService.registerExecutionHeartbeat(eid),
};

interface WebSocketContextValue {
  isConnected: boolean;
  lastMessage: WsMessage | null;
  connectionError: string | null;
  sendMessage: (message: object) => void;
  addListener: (callback: (message: WsMessage) => void) => () => void;
  registerExecutionHeartbeat: (executionId: string) => () => void;
}

const WebSocketContext = createContext<WebSocketContextValue | null>(null);

export const useWebSocket = (): WebSocketContextValue => {
  const ctx = useContext(WebSocketContext);
  if (!ctx) throw new Error('useWebSocket must be used within WebSocketProvider');
  return ctx;
};

/** WebSocketProvider — thin wrapper.  Does NOT own the WS connection.
 *  Subscribes to wsService state and re-renders consumers when it
 *  changes.  Mounting / unmounting this provider does NOT affect the
 *  underlying connection (which is started on module import). */
export const WebSocketProvider = ({ children }: { children: ReactNode }) => {
  const [state, setState] = useState<WsState>({
    isConnected: wsService.isConnected,
    lastMessage: wsService.currentLastMessage,
    connectionError: wsService.currentError,
  });

  useEffect(() => {
    // Subscribe to wsService state changes.  The cleanup ONLY removes
    // our subscription — it does NOT close the WebSocket.  That's the
    // whole point: WebSocketProvider unmount = stop reacting, NOT
    // disconnect.  The WS persists for the browser tab lifetime.
    return wsService.subscribeToState(setState);
  }, []);

  const value = useMemo<WebSocketContextValue>(() => ({
    isConnected: state.isConnected,
    lastMessage: state.lastMessage,
    connectionError: state.connectionError,
    // BF-471 — module-level stable delegates (defined above).
    // Identity never changes across renders → consumers using only
    // methods retain stable useEffect dependencies.
    sendMessage: _delegated.sendMessage,
    addListener: _delegated.addListener,
    registerExecutionHeartbeat: _delegated.registerExecutionHeartbeat,
  }), [state.isConnected, state.lastMessage, state.connectionError]);

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
};
