/**
 * Phase 101 — Semantic Layer Format Pattern Rendering
 *
 * Memoized formatters for applying format_pattern from DatasetColumn metadata.
 * Patterns follow Excel-like conventions:
 *   "$#,##0.00"   → currency  ($1,234.56)
 *   "#,##0"       → integer   (1,234)
 *   "0.00%"       → percent   (12.34%)
 *   "YYYY-MM-DD"  → date      (2024-01-15)
 */

// ── Formatter cache (one instance per unique pattern) ─────────────────────────

const _numCache = new Map<string, Intl.NumberFormat>();
const _dateCache = new Map<string, Intl.DateTimeFormat>();

function _getNumFormatter(pattern: string): Intl.NumberFormat {
  if (!_numCache.has(pattern)) {
    _numCache.set(pattern, _parseNumPattern(pattern));
  }
  return _numCache.get(pattern)!;
}

function _parseDatePattern(pattern: string): Intl.DateTimeFormat {
  if (!_dateCache.has(pattern)) {
    const opts: Intl.DateTimeFormatOptions = {};
    if (pattern.includes('YYYY')) opts.year = 'numeric';
    if (pattern.includes('MM')) opts.month = '2-digit';
    if (pattern.includes('DD')) opts.day = '2-digit';
    if (pattern.includes('HH')) opts.hour = '2-digit';
    if (pattern.includes('mm')) opts.minute = '2-digit';
    if (pattern.includes('ss')) opts.second = '2-digit';
    _dateCache.set(pattern, new Intl.DateTimeFormat(undefined, opts));
  }
  return _dateCache.get(pattern)!;
}

function _parseNumPattern(pattern: string): Intl.NumberFormat {
  // Currency patterns: starts with $ or ends with currency symbol
  if (pattern.startsWith('$') || pattern.startsWith('USD')) {
    const decimals = (pattern.match(/0+$/) || [''])[0].length || 2;
    return new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  }

  // Percentage patterns: ends with %
  if (pattern.endsWith('%')) {
    const decimals = (pattern.replace('%', '').match(/\.0+$/) || [''])[0].replace('.', '').length || 0;
    return new Intl.NumberFormat(undefined, {
      style: 'percent',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  }

  // Decimal patterns: count digits after decimal
  const decMatch = pattern.match(/\.(0+|#+)/);
  const decimals = decMatch ? decMatch[1].length : 0;
  const useGrouping = pattern.includes(',');
  return new Intl.NumberFormat(undefined, {
    useGrouping,
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}


// ── Public API ────────────────────────────────────────────────────────────────

export interface ColumnMetadata {
  friendly_name?: string;
  format_pattern?: string;
  column_type?: string;
  aggregation?: string;
  description?: string;
  data_type?: string;
}

/**
 * Apply a format pattern to a value.
 * Returns formatted string or null if no pattern or value is null/undefined.
 */
export function applyFormatPattern(
  value: unknown,
  pattern: string,
  dataType?: string,
): string | null {
  if (value === null || value === undefined || !pattern) return null;

  // Date patterns
  if (dataType === 'date' || /YYYY|MM|DD/.test(pattern)) {
    try {
      const d = value instanceof Date ? value : new Date(String(value));
      if (!isNaN(d.getTime())) {
        return _parseDatePattern(pattern).format(d);
      }
    } catch {
      // fall through
    }
    return String(value);
  }

  // Numeric patterns
  const num = typeof value === 'number' ? value : parseFloat(String(value));
  if (isNaN(num)) return String(value);

  // Percent patterns expect raw decimal (0.1234 → 12.34%)
  if (pattern.endsWith('%')) {
    const fmt = _getNumFormatter(pattern);
    return fmt.format(num);
  }

  return _getNumFormatter(pattern).format(num);
}

/**
 * Get the display name for a column (friendly_name or physical_name).
 */
export function getDisplayName(
  physicalName: string,
  metadata?: Record<string, ColumnMetadata>,
): string {
  if (!metadata) return physicalName;
  const meta = metadata[physicalName];
  return meta?.friendly_name || physicalName;
}

/**
 * Format a cell value using column metadata.
 * Returns formatted string or null (caller should fall back to default rendering).
 */
export function formatWithMetadata(
  value: unknown,
  columnName: string,
  metadata?: Record<string, ColumnMetadata>,
): string | null {
  if (!metadata) return null;
  const meta = metadata[columnName];
  if (!meta?.format_pattern) return null;
  return applyFormatPattern(value, meta.format_pattern, meta.data_type);
}

/**
 * Format a number in accounting style: negatives in brackets, positives plain.
 * e.g. -1234.56 → "(1,234.56)",  1234.56 → "1,234.56"
 */
export function formatAccounting(value: number, decimals = 2): string {
  const abs = Math.abs(value);
  const fmt = abs.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return value < 0 ? `(${fmt})` : fmt;
}


/**
 * Human-friendly elapsed-time formatter.  Used by the BQB / CQB live
 * worker grid + execution-progress chip so long-running queries are
 * easier to read at a glance.
 *
 *   formatElapsed(0.0)     → "0.0s"
 *   formatElapsed(12.7)    → "12.7s"
 *   formatElapsed(59.9)    → "59.9s"
 *   formatElapsed(60)      → "1m 0s"
 *   formatElapsed(1201)    → "20m 1s"
 *   formatElapsed(3725)    → "1h 2m 5s"
 *   formatElapsed(null)    → "—"
 *
 * Why minutes once ≥60s: at the 3000-file feed-scan scale the previous
 * "1201.0s" formatting forced users to do mental math.  Switch to
 * "20m 1s" once it crosses the minute boundary; pop to hours past 1h.
 */
export function formatElapsed(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined || isNaN(seconds as number)) {
    return '—';
  }
  const s = Math.max(0, Number(seconds));
  if (s < 60) return `${s.toFixed(1)}s`;
  if (s < 3600) {
    const m = Math.floor(s / 60);
    const rem = Math.round(s - m * 60);
    return `${m}m ${rem}s`;
  }
  const h = Math.floor(s / 3600);
  const remMin = Math.floor((s - h * 3600) / 60);
  const remSec = Math.round(s - h * 3600 - remMin * 60);
  return `${h}h ${remMin}m ${remSec}s`;
}


/**
 * Counts of workers in each state — used to render a single summary
 * chip ("12/16 running · 3 setup · 1 done") instead of forcing the
 * user to scan the per-worker grid for every status check.
 *
 * States are taken verbatim from the backend ``multi_worker_progress``
 * WS event: starting | setup | running | completed | failed | cancelled.
 *
 * Returns ``null`` when there are no workers to summarise so the caller
 * can skip rendering entirely.
 */
export interface WorkerStateCounts {
  total: number;
  starting: number;
  setup: number;
  running: number;
  completed: number;
  failed: number;
  cancelled: number;
}

export function summariseWorkerStates(
  workers: Array<{ state?: string }>,
): WorkerStateCounts | null {
  if (!workers || workers.length === 0) return null;
  const counts: WorkerStateCounts = {
    total: workers.length,
    starting: 0, setup: 0, running: 0,
    completed: 0, failed: 0, cancelled: 0,
  };
  for (const w of workers) {
    const s = (w?.state || '').toLowerCase();
    if (s === 'starting')  counts.starting++;
    else if (s === 'setup')     counts.setup++;
    else if (s === 'running')   counts.running++;
    else if (s === 'completed') counts.completed++;
    else if (s === 'failed')    counts.failed++;
    else if (s === 'cancelled') counts.cancelled++;
  }
  return counts;
}


/**
 * Renderable summary string for the worker-state chip.
 * ``12/16 running · 3 setup · 1 done`` — only non-zero buckets shown.
 *
 * Pure formatter (no JSX) so it's testable + reusable across BQB / CQB
 * / Feed Today / any future surface.
 */
export function formatWorkerSummary(counts: WorkerStateCounts): string {
  const parts: string[] = [];
  if (counts.running > 0)   parts.push(`${counts.running}/${counts.total} running`);
  if (counts.setup > 0)     parts.push(`${counts.setup} setup`);
  if (counts.starting > 0)  parts.push(`${counts.starting} starting`);
  if (counts.completed > 0) parts.push(`${counts.completed} done`);
  if (counts.failed > 0)    parts.push(`${counts.failed} failed`);
  if (counts.cancelled > 0) parts.push(`${counts.cancelled} cancelled`);
  return parts.join(' · ') || `${counts.total} workers`;
}
