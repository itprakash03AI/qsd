import { describe, it, expect } from 'vitest';
import {
  formatElapsed, summariseWorkerStates, formatWorkerSummary,
} from '../formatters';

describe('formatElapsed', () => {
  it('renders sub-minute as decimal seconds', () => {
    expect(formatElapsed(0)).toBe('0.0s');
    expect(formatElapsed(12.7)).toBe('12.7s');
    expect(formatElapsed(59.94)).toBe('59.9s');
  });

  it('renders one-minute-plus as Nm Ms', () => {
    expect(formatElapsed(60)).toBe('1m 0s');
    expect(formatElapsed(125)).toBe('2m 5s');
    // The exact user-reported scenario: 1201s should NOT show as "1201.0s".
    expect(formatElapsed(1201)).toBe('20m 1s');
  });

  it('renders one-hour-plus as Nh Mm Ss', () => {
    expect(formatElapsed(3600)).toBe('1h 0m 0s');
    expect(formatElapsed(3725)).toBe('1h 2m 5s');
  });

  it('handles null / undefined / NaN', () => {
    expect(formatElapsed(null)).toBe('—');
    expect(formatElapsed(undefined)).toBe('—');
    expect(formatElapsed(NaN)).toBe('—');
  });

  it('clamps negative to zero', () => {
    expect(formatElapsed(-5)).toBe('0.0s');
  });
});

describe('summariseWorkerStates', () => {
  it('returns null for empty list', () => {
    expect(summariseWorkerStates([])).toBeNull();
  });

  it('counts each state bucket', () => {
    const out = summariseWorkerStates([
      { state: 'running' }, { state: 'running' }, { state: 'running' },
      { state: 'setup' }, { state: 'setup' },
      { state: 'completed' },
      { state: 'failed' },
      { state: 'starting' },
    ]);
    expect(out).toEqual({
      total: 8,
      starting: 1,
      setup: 2,
      running: 3,
      completed: 1,
      failed: 1,
      cancelled: 0,
    });
  });

  it('is case-insensitive on state', () => {
    const out = summariseWorkerStates([
      { state: 'RUNNING' }, { state: 'Running' },
    ]);
    expect(out?.running).toBe(2);
  });
});

describe('formatWorkerSummary', () => {
  it('renders only non-zero buckets joined by middot', () => {
    expect(formatWorkerSummary({
      total: 16, starting: 0, setup: 3, running: 12,
      completed: 1, failed: 0, cancelled: 0,
    })).toBe('12/16 running · 3 setup · 1 done');
  });

  it('renders "all done" when only completed is non-zero', () => {
    expect(formatWorkerSummary({
      total: 8, starting: 0, setup: 0, running: 0,
      completed: 8, failed: 0, cancelled: 0,
    })).toBe('8 done');
  });

  it('falls back to "N workers" when every bucket is zero', () => {
    expect(formatWorkerSummary({
      total: 4, starting: 0, setup: 0, running: 0,
      completed: 0, failed: 0, cancelled: 0,
    })).toBe('4 workers');
  });

  it('surfaces failures prominently', () => {
    expect(formatWorkerSummary({
      total: 5, starting: 0, setup: 0, running: 0,
      completed: 4, failed: 1, cancelled: 0,
    })).toBe('4 done · 1 failed');
  });
});
