/**
 * BF-427 — Tests for the promoted safeStringify utility.
 * (BF-426 added the same tests against the old business-query/utils path;
 * these mirror them at the new src/utils/ home so the contract is pinned
 * to the single source of truth.)
 */
import { describe, it, expect } from 'vitest';
import { safeStringify } from '../safeStringify';

describe('safeStringify', () => {
  it('serializes plain objects identically to JSON.stringify', () => {
    const obj = { a: 1, b: 'two', c: [1, 2, 3], d: { nested: true } };
    expect(safeStringify(obj)).toBe(JSON.stringify(obj));
  });

  it('replaces window with [Window]', () => {
    if (typeof window === 'undefined') return;
    const obj = { name: 'tab1', leak: window };
    expect(safeStringify(obj)).toContain('[Window]');
  });

  it('breaks circular cycles with [Circular]', () => {
    const a: any = { name: 'a' };
    a.self = a;
    expect(() => safeStringify(a)).not.toThrow();
    expect(safeStringify(a)).toContain('[Circular]');
  });

  it('drops function values', () => {
    const obj = { name: 'x', cb: () => 'hi', value: 42 };
    const parsed = JSON.parse(safeStringify(obj));
    expect(parsed.cb).toBeUndefined();
    expect(parsed.value).toBe(42);
  });

  it('replaces DOM nodes with [DOM]', () => {
    if (typeof document === 'undefined') return;
    const div = document.createElement('div');
    expect(safeStringify({ el: div })).toContain('[DOM]');
  });

  it('replaces Event instances with [Event]', () => {
    if (typeof Event === 'undefined') return;
    expect(safeStringify({ evt: new Event('click') })).toContain('[Event]');
  });

  it('replaces React-style SyntheticEvent with [SyntheticEvent]', () => {
    const fake = {
      nativeEvent: { type: 'click' },
      target: { value: 'x' },
      preventDefault: () => {},
    };
    expect(safeStringify({ field: fake })).toContain('[SyntheticEvent]');
  });

  it('preserves null and primitive values', () => {
    expect(safeStringify(null)).toBe('null');
    expect(safeStringify(0)).toBe('0');
    expect(safeStringify(false)).toBe('false');
    expect(safeStringify('hello')).toBe('"hello"');
  });

  it('respects the space argument like JSON.stringify', () => {
    expect(safeStringify({ a: 1 }, 2)).toBe('{\n  "a": 1\n}');
  });

  it('handles deeply nested structures without stack overflow', () => {
    let nested: any = { value: 'leaf' };
    for (let i = 0; i < 50; i++) nested = { child: nested };
    expect(() => safeStringify(nested)).not.toThrow();
    expect(safeStringify(nested)).toContain('"value":"leaf"');
  });

  it('back-compat: same export still works via business-query/utils', async () => {
    const bqu = await import('../../components/business-query/utils');
    expect(bqu.safeStringify).toBe(safeStringify);
  });
});
