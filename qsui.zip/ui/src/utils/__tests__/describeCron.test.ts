import { describe, it, expect } from 'vitest';
import { describeCron } from '../describeCron';

describe('describeCron', () => {
  it('returns null for empty / blank input', () => {
    expect(describeCron('')).toBeNull();
    expect(describeCron('   ')).toBeNull();
  });

  it('returns null when the field count is wrong', () => {
    expect(describeCron('0 6 *')).toBeNull();
    expect(describeCron('0 6 * * * *')).toBeNull();
  });

  it('recognises every minute', () => {
    expect(describeCron('* * * * *')).toBe('Every minute');
    expect(describeCron('*/1 * * * *')).toBe('Every minute');
  });

  it('recognises every N minutes', () => {
    expect(describeCron('*/5 * * * *')).toBe('Every 5 minutes');
    expect(describeCron('*/15 * * * *')).toBe('Every 15 minutes');
  });

  it('recognises hourly patterns', () => {
    expect(describeCron('0 * * * *')).toBe('Every hour (on the hour)');
    expect(describeCron('30 * * * *')).toBe('Every hour at :30');
  });

  it('recognises daily-at-time patterns', () => {
    expect(describeCron('0 6 * * *')).toBe('Daily at 06:00');
    expect(describeCron('30 22 * * *')).toBe('Daily at 22:30');
  });

  it('recognises weekly day-of-week patterns', () => {
    expect(describeCron('0 9 * * 1')).toBe('Weekly on Monday at 09:00');
    expect(describeCron('0 9 * * 0')).toBe('Weekly on Sunday at 09:00');
    expect(describeCron('30 17 * * 5')).toBe('Weekly on Friday at 17:30');
  });

  it('recognises monthly day-of-month patterns', () => {
    expect(describeCron('0 2 1 * *')).toBe('Monthly on the 1st at 02:00');
    expect(describeCron('15 3 15 * *')).toBe('Monthly on the 15th at 03:15');
  });

  it('returns null for patterns it cannot parse', () => {
    // Weekday range — common but our minimal parser doesn't claim full coverage
    expect(describeCron('0 9 * * 1-5')).toBeNull();
    // Multiple specific hours
    expect(describeCron('0 6,18 * * *')).toBeNull();
  });
});
