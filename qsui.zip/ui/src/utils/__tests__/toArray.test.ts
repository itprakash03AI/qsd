/**
 * BF-428P — Tests for the toArray() shared helper.
 */
import { describe, it, expect, vi } from 'vitest';
import { toArray, safeArraySetter } from '../toArray';

describe('toArray', () => {
  it('returns array unchanged', () => {
    expect(toArray([1, 2, 3])).toEqual([1, 2, 3]);
    expect(toArray<string>(['a', 'b'])).toEqual(['a', 'b']);
  });

  it('returns [] for null / undefined', () => {
    expect(toArray(null)).toEqual([]);
    expect(toArray(undefined)).toEqual([]);
  });

  it('returns [] for primitives', () => {
    expect(toArray('string')).toEqual([]);
    expect(toArray(42)).toEqual([]);
    expect(toArray(true)).toEqual([]);
  });

  it('extracts via caller-supplied key', () => {
    expect(toArray({ circuit_breakers: [1, 2] }, 'circuit_breakers')).toEqual([1, 2]);
    expect(toArray({ items: [{ a: 1 }] }, { key: 'items' })).toEqual([{ a: 1 }]);
  });

  it('extracts via conventional wrapper keys', () => {
    expect(toArray({ items:   [1, 2] })).toEqual([1, 2]);
    expect(toArray({ results: [3, 4] })).toEqual([3, 4]);
    expect(toArray({ data:    [5] })).toEqual([5]);
    expect(toArray({ rows:    [6] })).toEqual([6]);
    expect(toArray({ list:    [7] })).toEqual([7]);
    expect(toArray({ records: [8] })).toEqual([8]);
  });

  it('caller key takes precedence over conventional', () => {
    const v = { items: [1, 2], custom: [9, 9, 9] };
    expect(toArray(v, 'custom')).toEqual([9, 9, 9]);
  });

  it('returns [] for object without recognised key', () => {
    expect(toArray({ unrelated: 'value' })).toEqual([]);
    expect(toArray({})).toEqual([]);
  });

  it('flattens dict-of-objects when mapValueObjects=true', () => {
    const v = {
      conn1: { state: 'closed', failures: 0 },
      conn2: { state: 'open',   failures: 5 },
    };
    expect(toArray(v, { mapValueObjects: true })).toEqual([
      { key: 'conn1', state: 'closed', failures: 0 },
      { key: 'conn2', state: 'open',   failures: 5 },
    ]);
  });

  it('flattens dict-of-objects under a wrapper key', () => {
    const v = {
      circuit_breakers: {
        conn1: { state: 'closed' },
        conn2: { state: 'open' },
      },
    };
    expect(toArray(v, { key: 'circuit_breakers', mapValueObjects: true })).toEqual([
      { key: 'conn1', state: 'closed' },
      { key: 'conn2', state: 'open' },
    ]);
  });

  it('expectArray=true logs warn on miss', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    toArray('not-an-array', { expectArray: true });
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });

  it('expectArray=false stays silent', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    toArray('not-an-array');
    expect(warn).not.toHaveBeenCalled();
    warn.mockRestore();
  });

  it('handles the SystemHealthSection circuit-breakers shape', () => {
    // Backend returns {circuit_breakers: {conn_id: {state, ...}}}
    const v = {
      circuit_breakers: {
        '7': { state: 'open', connection_name: 'snowflake-prod' },
        '8': { state: 'closed' },
      },
    };
    const out = toArray<any>(v, {
      key: 'circuit_breakers',
      mapValueObjects: true,
    });
    expect(out).toHaveLength(2);
    expect(out[0]).toMatchObject({ key: '7', state: 'open' });
    expect(out[1]).toMatchObject({ key: '8', state: 'closed' });
  });
});

describe('safeArraySetter', () => {
  it('passes array unchanged to setter', () => {
    const setter = vi.fn();
    safeArraySetter(setter)([1, 2, 3]);
    expect(setter).toHaveBeenCalledWith([1, 2, 3]);
  });

  it('extracts via key option', () => {
    const setter = vi.fn();
    safeArraySetter(setter, 'items')({ items: ['a', 'b'] });
    expect(setter).toHaveBeenCalledWith(['a', 'b']);
  });

  it('falls back to [] for non-array input', () => {
    const setter = vi.fn();
    safeArraySetter(setter)(null);
    expect(setter).toHaveBeenCalledWith([]);
    safeArraySetter(setter)('string');
    expect(setter).toHaveBeenLastCalledWith([]);
  });
});
