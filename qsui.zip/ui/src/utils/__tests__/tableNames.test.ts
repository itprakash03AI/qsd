import { describe, it, expect } from 'vitest';
import { displayTableName, shortLabel, fullDisplayPath } from '../tableNames';

describe('displayTableName', () => {
  it('strips __registered__: prefix', () => {
    expect(displayTableName('__registered__:orders')).toBe('orders');
  });

  it('strips __local__: prefix', () => {
    expect(displayTableName('__local__:my_upload')).toBe('my_upload');
  });

  it('strips __materialized__: / __federation__: / __iceberg__:', () => {
    expect(displayTableName('__materialized__:summary_2024')).toBe('summary_2024');
    expect(displayTableName('__federation__:cross_region')).toBe('cross_region');
    expect(displayTableName('__iceberg__:my_table')).toBe('my_table');
  });

  it('returns last segment of file path + drops parquet ext', () => {
    expect(displayTableName('s3://bucket/key/data.parquet')).toBe('data');
    expect(displayTableName('folder/sub/data.csv')).toBe('data');
  });

  it('shortens 3-part SQL connector path to last segment', () => {
    expect(displayTableName('iceberg.fact_sales.orders_2024')).toBe('orders_2024');
    expect(displayTableName('hive.public.users')).toBe('users');
  });

  it('shortens 2-part schema.table form', () => {
    expect(displayTableName('public.products')).toBe('products');
  });

  it('handles empty path', () => {
    expect(displayTableName('')).toBe('');
  });

  it('does not double-strip prefixed SQL paths', () => {
    expect(displayTableName('__registered__:hive.public.orders')).toBe('orders');
  });

  it('preserves single-segment paths with no dots', () => {
    expect(displayTableName('orders')).toBe('orders');
  });

  it('treats unknown extension dotted single-segment as SQL form', () => {
    // 'foo.bar' has no slash, has dots, ext 'bar' isn't known → treat as SQL
    expect(displayTableName('foo.bar')).toBe('bar');
  });

  it('keeps file extension drop for tsv/json/xlsx', () => {
    expect(displayTableName('a/b/data.json')).toBe('data');
    expect(displayTableName('a/b/data.xlsx')).toBe('data');
    expect(displayTableName('a/b/data.tsv')).toBe('data');
  });
});

describe('shortLabel', () => {
  it('returns full name when under maxLen', () => {
    expect(shortLabel('orders', 28)).toBe('orders');
  });

  it('truncates with ellipsis when over maxLen', () => {
    const long = 'a_very_long_table_name_with_lots_of_underscores';
    const out = shortLabel(long, 12);
    expect(out.length).toBeLessThanOrEqual(12);
    expect(out).toContain('…');
    expect(out.startsWith('a_very')).toBe(true);
  });
});

describe('fullDisplayPath', () => {
  it('strips QueryStudio prefix but keeps full SQL path', () => {
    expect(fullDisplayPath('__registered__:hive.public.orders')).toBe('hive.public.orders');
    expect(fullDisplayPath('hive.public.orders')).toBe('hive.public.orders');
  });
});
