/**
 * BF-428P — toArray() shared helper.
 *
 * React state declared as `useState<T[]>([])` and populated from an API
 * response is a recurring crash class: when the backend returns
 * `{items: [...]}` (or any wrapper) instead of a bare array, downstream
 * `.map()` / `.filter()` / `.length` calls throw "X.map is not a function".
 *
 * Just-fixed example (`SystemHealthSection.tsx`): backend
 * `/api/admin/circuit-breakers` returns `{circuit_breakers: [...]}`
 * but the consumer was assigning the wrapper object directly.
 *
 * Use `toArray()` at the API-response → state boundary to normalise:
 *   - already an array  → returned unchanged
 *   - object with one of the conventional list keys (items/results/data/
 *     rows/list, plus any caller-supplied key) → that array
 *   - object whose values are themselves an array → those values as a
 *     flat array (handles dict-of-lists shape)
 *   - anything else → empty array
 *
 * Optional `mapValueObjects` lets a dict-of-objects (e.g.,
 * `{conn_id: {state: "open", ...}}`) be flattened to an array of
 * `{key, ...value}` records — used by SystemHealthSection.
 *
 * Standards (per BF-413..427):
 *   - never throws — failure mode is `[]`, NOT a crash
 *   - no console.error on the happy path (silent normalisation)
 *   - WARN-logs to console only when `expectArray` is true and we
 *     fell back to `[]` (so devs catch contract drift)
 */

export interface ToArrayOptions {
  /** Caller-supplied wrapper key, e.g. ``"circuit_breakers"``.  Tried
   *  before the conventional list of keys. */
  key?: string;
  /** When the value at the resolved key is a dict-of-objects, flatten
   *  to ``[{key, ...value}]``.  Default false. */
  mapValueObjects?: boolean;
  /** When true and we couldn't find an array, log a WARN (helps catch
   *  backend contract drift in dev).  Default false. */
  expectArray?: boolean;
}

const _CONVENTIONAL_LIST_KEYS = [
  'items', 'results', 'data', 'rows', 'list', 'records',
] as const;

export function toArray<T = unknown>(
  v: unknown,
  options: ToArrayOptions | string = {},
): T[] {
  // Allow the common "just give me the key" form: toArray(resp, "items")
  const opts: ToArrayOptions =
    typeof options === 'string' ? { key: options } : options;

  // 1. Already an array
  if (Array.isArray(v)) return v as T[];

  // 2. Null / undefined / primitive — nothing to extract
  if (v === null || v === undefined || typeof v !== 'object') {
    if (opts.expectArray) {
      // Guarded log so test environments stay quiet
      // eslint-disable-next-line no-console
      console.warn('[toArray] expected array, got', typeof v, v);
    }
    return [];
  }

  const obj = v as Record<string, unknown>;

  // 3. Caller-supplied key first
  if (opts.key && Array.isArray(obj[opts.key])) {
    return obj[opts.key] as T[];
  }
  // 4. Dict-of-objects under the supplied key → flatten
  if (opts.key && opts.mapValueObjects
      && obj[opts.key] && typeof obj[opts.key] === 'object'
      && !Array.isArray(obj[opts.key])) {
    return _flattenDict<T>(obj[opts.key] as Record<string, unknown>);
  }

  // 5. Conventional wrapper keys
  for (const k of _CONVENTIONAL_LIST_KEYS) {
    if (Array.isArray(obj[k])) return obj[k] as T[];
  }

  // 6. Top-level dict-of-objects flatten (only if explicitly requested)
  if (opts.mapValueObjects) {
    return _flattenDict<T>(obj);
  }

  if (opts.expectArray) {
    // eslint-disable-next-line no-console
    console.warn('[toArray] expected array, got object with keys',
                  Object.keys(obj));
  }
  return [];
}

function _flattenDict<T>(d: Record<string, unknown>): T[] {
  const out: T[] = [];
  for (const [k, v] of Object.entries(d)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      out.push({ key: k, ...(v as object) } as T);
    } else {
      out.push({ key: k, value: v } as T);
    }
  }
  return out;
}

/** Convenience: ensure a state setter never receives a non-array.
 *  ``setState(safeArraySetter(setState, key)(apiResponse))`` */
export function safeArraySetter<T>(
  setter: (v: T[]) => void,
  options: ToArrayOptions | string = {},
): (v: unknown) => void {
  return (v: unknown) => setter(toArray<T>(v, options));
}
