/**
 * BF-426 / BF-427 — Shared safe-serialization utility.
 *
 * Native JSON.stringify throws "Converting circular structure to JSON" when
 * state accidentally captures a DOM/Window/SyntheticEvent reference (e.g., a
 * setter called with `e` instead of `e.target.value`).  In an enterprise
 * product where dozens of forms, modals and persistence layers feed into
 * sessionStorage / localStorage / API request bodies, a single misrouted
 * setter can crash the page AND corrupt the saved state for the next load.
 *
 * `safeStringify` is a drop-in replacement that:
 *   - replaces window/Node/Event/SyntheticEvent values with readable sentinel
 *     strings (`[Window]`, `[DOM]`, `[Event]`, `[SyntheticEvent]`) so the
 *     serializer never throws AND the bug remains greppable in saved storage
 *   - breaks circular cycles via a WeakSet (`[Circular]`)
 *   - drops function values (matches native JSON.stringify behavior)
 *
 * Use this everywhere a payload might come from loosely-typed state:
 *   - storage writes (localStorage / sessionStorage / IndexedDB)
 *   - error message formatting (`setError(safeStringify(err))`)
 *   - autosave / draft systems
 *   - request body serialization at the API layer
 *
 * Centralized at `src/utils/safeStringify.ts` so a single hardening pass
 * protects the whole product.  Re-exported from `business-query/utils` for
 * back-compat with BF-426 callers.
 */
export const safeStringify = (v: unknown, space?: number): string => {
  const seen = new WeakSet<object>();
  return JSON.stringify(v, (_key, val) => {
    if (val === null || val === undefined) return val;
    const t = typeof val;
    if (t === 'function') return undefined;        // drop functions
    if (t !== 'object') return val;                 // primitives pass through
    if (seen.has(val as object)) return '[Circular]';
    seen.add(val as object);
    // Browser-only checks — guarded so this runs in Node / jsdom too.
    if (typeof window !== 'undefined' && val === window) return '[Window]';
    if (typeof Node !== 'undefined' && val instanceof Node) return '[DOM]';
    if (typeof Event !== 'undefined' && val instanceof Event) return '[Event]';
    // React SyntheticEvent — has nativeEvent + preventDefault
    const obj = val as Record<string, unknown>;
    if (obj.nativeEvent && typeof obj.preventDefault === 'function') {
      return '[SyntheticEvent]';
    }
    return val;
  }, space);
};
