/**
 * BF-360 — table name display helpers used across BQB / CQB / pivot UI.
 *
 * Path conventions in this app:
 *   "__registered__:<name>"      registered (S3 prefix or registered table)
 *   "__local__:<name>"           uploaded local table
 *   "__materialized__:<name>"    materialised view
 *   "__federation__:<name>"      federation view
 *   "__iceberg__:<name>"         Iceberg-via-DuckDB
 *   "<bucket>/<key>.parquet"     S3 file path
 *   "<catalog>.<schema>.<table>" SQL connector (Trino, Snowflake, etc.)
 *   "<schema>.<table>"           SQL connector with default catalog
 *
 * The 3-part SQL paths are too long to display in chips / lists / column
 * headers; admins reading a query don't need the catalog repeated for
 * every column.  Use ``displayTableName`` for UI rendering and
 * ``shortLabel`` for chips/headers where space is tight.
 */

const SPECIAL_PREFIXES: { prefix: string; len: number }[] = [
  { prefix: '__registered__:',  len: 15 },
  { prefix: '__local__:',       len: 10 },
  { prefix: '__materialized__:', len: 17 },
  { prefix: '__federation__:',  len: 15 },
  { prefix: '__iceberg__:',     len: 12 },
];

/** Strip the QueryStudio "__kind__:" prefix if present.  No effect when absent. */
function stripPrefix(path: string): string {
  for (const { prefix, len } of SPECIAL_PREFIXES) {
    if (path.startsWith(prefix)) return path.slice(len);
  }
  return path;
}

/** True when the path looks like a SQL connector "cat.schema.table" form
 *  (no slashes, has dots, isn't a known file extension). */
function isSqlConnectorPath(path: string): boolean {
  if (path.includes('/')) return false;            // file path, not SQL
  if (!path.includes('.')) return false;            // single-segment
  // Last segment looks like a file extension → still file-like
  const lastDot = path.lastIndexOf('.');
  const ext = path.slice(lastDot + 1).toLowerCase();
  if (['parquet', 'csv', 'json', 'xlsx', 'xls', 'txt', 'tsv'].includes(ext)) return false;
  return true;
}

/**
 * Friendly table name for UI display.  Strips QueryStudio prefixes and
 * shortens SQL connector paths to just the table name.
 *
 * Examples:
 *   __registered__:orders                  → orders
 *   s3://b/k/data.parquet                  → data
 *   iceberg.sales.orders_2024              → orders_2024
 *   sales.orders_2024                      → orders_2024
 */
export function displayTableName(path: string): string {
  if (!path) return '';
  const stripped = stripPrefix(path);

  // SQL connector "catalog.schema.table" form — return last segment only
  if (isSqlConnectorPath(stripped)) {
    const parts = stripped.split('.');
    return parts[parts.length - 1] || stripped;
  }

  // File path — last segment, drop common file extension
  const fileSegment = stripped.split('/').pop() || stripped;
  return fileSegment.replace(/\.(parquet|csv|json|xlsx?|tsv|txt)$/i, '');
}

/**
 * Compact chip label — same as displayTableName but with optional length cap.
 * When over ``maxLen``, returns "<head>…<tail>" so both ends of the name
 * remain readable (helpful for cat.schema.LONG_TABLE_NAME_FOR_2024_FY).
 */
export function shortLabel(path: string, maxLen: number = 28): string {
  const name = displayTableName(path);
  if (name.length <= maxLen) return name;
  const head = Math.ceil((maxLen - 1) / 2);
  const tail = Math.floor((maxLen - 1) / 2);
  return `${name.slice(0, head)}…${name.slice(-tail)}`;
}

/**
 * Full path for tooltips — original form, just stripped of QueryStudio
 * prefixes so the user sees what they'd type in SQL.
 */
export function fullDisplayPath(path: string): string {
  if (!path) return '';
  return stripPrefix(path);
}
