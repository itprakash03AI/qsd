/**
 * Phase 64 — User-friendly error message mapping.
 *
 * Translates raw API / DuckDB / network errors into actionable messages
 * that non-technical users can understand.
 */

// Common technical → user-friendly mappings
const ERROR_PATTERNS: Array<{ pattern: RegExp; message: string }> = [
  // S3 / presigned URL errors (more specific — must come before generic 403)
  { pattern: /presigned.*expired|URL.*expired|presigned.*403/i,
    message: 'The S3 download link expired. Try running the query again.' },
  { pattern: /Access Denied.*s3|presigned.*access denied|S3AccessDenied/i,
    message: 'S3 access was denied. The link may have expired — try the query again.' },
  { pattern: /S3_ACCESS_DENIED/i,
    message: 'S3 access was denied. Check IAM permissions for this S3 bucket.' },
  { pattern: /REFRESH_IN_PROGRESS/i,
    message: 'Partition refresh already in progress. Try again in a few seconds.' },

  // DuckDB engine / circuit breaker (Phase 79 — must come before generic 503)
  { pattern: /CIRCUIT_OPEN|circuit breaker.*open|circuit.*open/i,
    message: 'The query engine is temporarily unavailable (circuit breaker open). Please wait a moment and try again.' },
  { pattern: /CONNECTION_UNAVAILABLE|connection unavailable/i,
    message: 'The data connection is unavailable. Use the Run button (background query) to get the last cached result.' },
  { pattern: /DuckDB engine circuit|duckdb.*circuit/i,
    message: 'The DuckDB query engine is temporarily circuit-broken. Please wait and retry.' },

  // HTTP status codes
  { pattern: /\b401\b|Unauthorized/i, message: 'Your session has expired. Please log in again.' },
  { pattern: /\b403\b|Forbidden|Access denied/i, message: 'You do not have permission to perform this action.' },
  { pattern: /\b404\b|[Nn]ot [Ff]ound/, message: 'The requested resource was not found.' },
  { pattern: /\b409\b|[Cc]onflict/, message: 'A conflict occurred. The resource may have been modified by another user.' },
  { pattern: /\b5\d{2}\b|Internal Server Error/i, message: 'A server error occurred. Please try again or contact your administrator.' },

  // Network
  { pattern: /Failed to fetch|NetworkError|ERR_CONNECTION/i, message: 'Network connection failed. Please check your connection and try again.' },
  { pattern: /timeout|ETIMEDOUT|ECONNABORTED/i, message: 'The request timed out. Try again or reduce the data range.' },

  // DuckDB errors (may leak through in some paths)
  { pattern: /Binder Error/i, message: 'Query column reference error. A column may have been renamed or removed.' },
  { pattern: /Catalog Error/i, message: 'Data source not found. The table or view may not be registered.' },
  { pattern: /IO Error.*S3|SignatureDoesNotMatch/i, message: 'S3 storage access error. Check connection credentials.' },
  { pattern: /Parser Error/i, message: 'Invalid query syntax. Please review your query and try again.' },

  // S3 / storage
  { pattern: /TOKEN_EXPIRED|ExpiredToken/i, message: 'Storage credentials have expired. Please refresh the connection.' },
  { pattern: /NoSuchBucket|NoSuchKey/i, message: 'The requested file or bucket was not found in storage.' },

  // Generic
  { pattern: /ENOSPC|disk.*full/i, message: 'Server disk is full. Please contact your administrator.' },
  { pattern: /ENOMEM|out of memory/i, message: 'The server ran out of memory. Try reducing the data range.' },
];

/**
 * Convert a raw error into a user-friendly message.
 * Falls back to a cleaned version of the original message if no pattern matches.
 */
export function getUserFriendlyError(error: unknown, fallback = 'An unexpected error occurred.'): string {
  const raw = error instanceof Error
    ? error.message
    : typeof error === 'string'
      ? error
      : (error as any)?.detail || (error as any)?.message || String(error ?? '');

  if (!raw) return fallback;

  for (const { pattern, message } of ERROR_PATTERNS) {
    if (pattern.test(raw)) return message;
  }

  // Strip long stack traces / technical prefixes
  const cleaned = raw
    .replace(/^(Error|RuntimeError|HTTPException|DuckDB query error):\s*/i, '')
    .replace(/\n[\s\S]*/, '')  // remove everything after first line
    .trim();

  return cleaned || fallback;
}
