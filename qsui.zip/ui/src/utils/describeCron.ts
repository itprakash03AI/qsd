/**
 * describeCron — Tiny natural-language preview for standard 5-field cron
 * expressions ("min hour dom month dow").
 *
 * Covers the patterns FeedConfigs users actually type: every-minute,
 * every-N-minutes, hourly, daily-at-HH:MM, weekly-on-DAY-at-HH:MM,
 * monthly-on-N-at-HH:MM.  Anything we don't recognise returns ``null`` and
 * the caller falls back to showing the raw expression with no preview.
 *
 * Intentionally NOT a full cron parser — the goal is "the user can tell
 * at a glance whether they typed what they meant", not full RFC coverage.
 */

const DAY_NAMES = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday',
];

function _pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

function _timeLabel(hour: number, minute: number): string {
  // 24-hour clock — unambiguous for ops; "every X" doesn't translate to AM/PM.
  return `${_pad2(hour)}:${_pad2(minute)}`;
}

export function describeCron(expr: string): string | null {
  if (!expr) return null;
  const parts = expr.trim().split(/\s+/);
  if (parts.length !== 5) return null;
  const [min, hour, dom, month, dow] = parts;

  // Every N minutes — */N in minutes, * everywhere else
  const everyN = min.match(/^\*\/(\d+)$/);
  if (everyN && hour === '*' && dom === '*' && month === '*' && dow === '*') {
    const n = Number(everyN[1]);
    return n === 1 ? 'Every minute' : `Every ${n} minutes`;
  }

  // Every minute
  if (min === '*' && hour === '*' && dom === '*' && month === '*' && dow === '*') {
    return 'Every minute';
  }

  // Hourly at :MM
  if (/^\d+$/.test(min) && hour === '*' && dom === '*' && month === '*' && dow === '*') {
    const m = Number(min);
    return m === 0 ? 'Every hour (on the hour)' : `Every hour at :${_pad2(m)}`;
  }

  // Daily at HH:MM (no DOW restriction)
  if (/^\d+$/.test(min) && /^\d+$/.test(hour) && dom === '*' && month === '*' && dow === '*') {
    return `Daily at ${_timeLabel(Number(hour), Number(min))}`;
  }

  // Weekly on DAY at HH:MM
  if (/^\d+$/.test(min) && /^\d+$/.test(hour) && dom === '*' && month === '*' && /^[0-6]$/.test(dow)) {
    return `Weekly on ${DAY_NAMES[Number(dow)]} at ${_timeLabel(Number(hour), Number(min))}`;
  }

  // Monthly on day N at HH:MM
  if (/^\d+$/.test(min) && /^\d+$/.test(hour) && /^\d+$/.test(dom) && month === '*' && dow === '*') {
    const day = Number(dom);
    const ord = day === 1 ? '1st' : day === 2 ? '2nd' : day === 3 ? '3rd' : `${day}th`;
    return `Monthly on the ${ord} at ${_timeLabel(Number(hour), Number(min))}`;
  }

  return null;  // unrecognised pattern — caller will hide the preview
}
