/**
 * Shared parameter utilities — date macro resolution + default value handling.
 * Extracted from BusinessReportViewer to be shared across all report viewers/builders.
 */

/** Resolve @TODAY, @YESTERDAY, @MONTH_START etc. to ISO date strings */
export function resolveClientDateMacro(val: string): string {
  if (!val || !val.startsWith('@')) return val;
  const today = new Date();
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  const map: Record<string, () => string> = {
    '@TODAY': () => iso(today),
    '@YESTERDAY': () => iso(new Date(today.getTime() - 86400000)),
    '@MONTH_START': () => iso(new Date(today.getFullYear(), today.getMonth(), 1)),
    '@MONTH_END': () => {
      const d = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      return iso(d);
    },
    '@YEAR_START': () => iso(new Date(today.getFullYear(), 0, 1)),
    '@YEAR_END': () => iso(new Date(today.getFullYear(), 11, 31)),
    '@LAST_7_DAYS': () => iso(new Date(today.getTime() - 7 * 86400000)),
    '@LAST_30_DAYS': () => iso(new Date(today.getTime() - 30 * 86400000)),
    '@LAST_90_DAYS': () => iso(new Date(today.getTime() - 90 * 86400000)),
    '@QUARTER_START': () => {
      const qm = Math.floor(today.getMonth() / 3) * 3;
      return iso(new Date(today.getFullYear(), qm, 1));
    },
    '@QUARTER_END': () => {
      const qm = Math.floor(today.getMonth() / 3) * 3 + 3;
      return iso(new Date(today.getFullYear(), qm, 0));
    },
    '@THIS_WEEK_START': () => {
      const d = new Date(today);
      // ISO-8601: Monday = start of week (getDay() returns 0=Sun, so shift by (day+6)%7)
      d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
      return iso(d);
    },
  };
  const fn = map[val.toUpperCase()];
  return fn ? fn() : val;
}

/** Resolve default value for a parameter — handles @macros for date types */
export function resolveParamDefault(param: any): any {
  const dv = param.default_value;
  if (dv == null || dv === '') return '';
  if (['date', 'date_range'].includes(param.parameter_type) && typeof dv === 'string' && dv.startsWith('@')) {
    return resolveClientDateMacro(dv);
  }
  return dv;
}
