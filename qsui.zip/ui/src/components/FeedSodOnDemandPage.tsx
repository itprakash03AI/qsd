/**
 * End-user on-demand SOD page.
 *
 * Lets any authenticated user seed today's (or any chosen date's)
 * ``feed_runs`` rows without waiting for the scheduled cron.  Backed by
 * ``POST /api/feeds/sod/run-now`` which calls the same
 * ``SodTaskGenerator.run_for_date`` the admin endpoint uses, with the
 * same idempotency guarantees:
 *
 *   - Per-feed pre-check ``get_feed_run_by_feed_date`` skips when row exists
 *   - DB-level unique index ``ux_feed_runs_one_per_feed_per_date`` is the
 *     hard-stop guarantee against races
 *
 * Re-running for the same date is a no-op (already_existed counter
 * bumps; no duplicate rows created).
 *
 * Per user OOP preference (2026-05-18 memory note): state-and-behaviour
 * encapsulated in this single component.  No global stores, no scratch
 * dicts, no procedural helpers split across files for this feature.
 */
import { useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Stack, TextField, Button, Alert,
  Table, TableHead, TableRow, TableCell, TableBody, Chip,
  CircularProgress, Divider, Tooltip,
} from '@mui/material';
import {
  AccessTime as SodIcon, PlayArrow as RunIcon,
  Refresh as RefreshIcon, InfoOutlined as InfoIcon,
} from '@mui/icons-material';
import api from '../services/api';

interface SodResult {
  business_date: string;
  total_feeds: number;
  created: number;
  already_existed: number;
  skipped_window: number;
  skipped_by_condition: number;
  skipped_inactive: number;
  errors: number;
  error_details?: string[];
}

export default function FeedSodOnDemandPage() {
  // Default to today (UTC) in YYYY-MM-DD form so the picker auto-fills the
  // expected SOD target without the user having to type.
  const today = new Date().toISOString().slice(0, 10);
  const [businessDate, setBusinessDate] = useState<string>(today);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SodResult | null>(null);
  const [error, setError] = useState<string>('');

  const handleRun = useCallback(async () => {
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const url = `/api/feeds/sod/run-now${businessDate ? `?business_date=${encodeURIComponent(businessDate)}` : ''}`;
      const data: any = await api.post(url);
      setResult(data as SodResult);
    } catch (err: any) {
      setError(err?.detail || err?.message || 'SOD trigger failed');
    } finally {
      setLoading(false);
    }
  }, [businessDate]);

  return (
    <Box sx={{ p: 3, maxWidth: 900, mx: 'auto' }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <SodIcon color="primary" />
        <Typography variant="h5" component="h1">On-Demand SOD</Typography>
      </Stack>

      <Alert severity="info" icon={<InfoIcon />} sx={{ mb: 3 }}>
        <Typography variant="body2">
          Seeds today's (or any selected date's) <strong>feed_runs</strong> rows
          for all active feeds.  Use this when the scheduled SOD window slipped
          (network blip, backend restart) or you've just added a new feed
          mid-day and want it included.
        </Typography>
        <Typography variant="caption" sx={{ display: 'block', mt: 1, color: 'text.secondary' }}>
          <strong>Idempotent:</strong> re-running for the same date will <em>NOT</em> create
          duplicate rows.  Feeds that already have a row for this date are
          counted as <code>already_existed</code> and skipped.
        </Typography>
      </Alert>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Stack direction="row" spacing={2} alignItems="flex-end">
          <TextField
            type="date"
            label="Business date"
            value={businessDate}
            onChange={e => setBusinessDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            sx={{ flexShrink: 0 }}
            disabled={loading}
          />
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={handleRun}
            disabled={loading || !businessDate}
            startIcon={loading ? <CircularProgress size={18} color="inherit" /> : <RunIcon />}
          >
            {loading ? 'Running…' : 'Run SOD'}
          </Button>
          {result && (
            <Tooltip title="Clear result">
              <Button variant="outlined" onClick={() => setResult(null)}
                      startIcon={<RefreshIcon />}>
                Reset
              </Button>
            </Tooltip>
          )}
        </Stack>

        {error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}
      </Paper>

      {result && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" sx={{ mb: 1 }}>
            SOD run completed
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
            Business date: <strong>{result.business_date}</strong> ·
            Total active feeds evaluated: <strong>{result.total_feeds}</strong>
          </Typography>

          <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 2 }}>
            <ResultChip label="Created" value={result.created} color="success" />
            <ResultChip label="Already existed" value={result.already_existed} color="info" />
            <ResultChip label="Out of window" value={result.skipped_window} color="default" />
            <ResultChip label="Action='SKIP'" value={result.skipped_by_condition} color="default" />
            <ResultChip label="Inactive" value={result.skipped_inactive} color="default" />
            <ResultChip label="Errors" value={result.errors} color={result.errors > 0 ? 'error' : 'default'} />
          </Stack>

          {result.created > 0 && (
            <Alert severity="success" sx={{ mb: 2 }}>
              {result.created} new feed_run{result.created === 1 ? '' : 's'} created for{' '}
              <strong>{result.business_date}</strong>.  Visit the <a href="/feeds/today">Feed Dashboard</a> to
              watch them execute.
            </Alert>
          )}

          {result.already_existed > 0 && result.created === 0 && (
            <Alert severity="info" sx={{ mb: 2 }}>
              No new rows created — all {result.already_existed} eligible feed
              {result.already_existed === 1 ? '' : 's'} already had a row
              for <strong>{result.business_date}</strong>.  This is the expected behaviour when
              re-running SOD for a date that's already been processed.
            </Alert>
          )}

          {result.errors > 0 && result.error_details && result.error_details.length > 0 && (
            <>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" color="error" sx={{ mb: 1 }}>
                Error details ({result.errors})
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Feed</TableCell>
                    <TableCell>Error</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {result.error_details.map((msg, idx) => (
                    <TableRow key={idx}>
                      <TableCell colSpan={2} sx={{ fontSize: 12, fontFamily: 'monospace' }}>
                        {msg}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </>
          )}
        </Paper>
      )}
    </Box>
  );
}

function ResultChip({
  label, value, color,
}: { label: string; value: number; color: 'success' | 'info' | 'default' | 'error' }) {
  return (
    <Chip
      label={`${label}: ${value}`}
      color={value > 0 ? color : 'default'}
      variant={value > 0 ? 'filled' : 'outlined'}
      size="small"
      sx={{ fontWeight: 500 }}
    />
  );
}
