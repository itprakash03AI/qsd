/**
 * Phase 56 — Business Report Builder
 *
 * 6-step wizard for creating/editing business reports on top of the semantic layer.
 * Steps: Subject → Columns → Filters → Parameters → Layout → Review & Save
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Stepper, Step, StepLabel, Button, TextField,
  Chip, Checkbox, FormControlLabel, FormHelperText, Radio, RadioGroup, Select, MenuItem, InputLabel, FormControl,
  IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  Alert, CircularProgress, Divider, Tooltip, Switch, Grid,
  Table, TableBody, TableCell, TableHead, TableRow, Autocomplete,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  ArrowForward as ArrowForwardIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  DragIndicator as DragIcon,
  InfoOutlined as InfoOutlinedIcon,
  PlayArrow as PreviewReportIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors,
} from '@dnd-kit/core';
import {
  SortableContext, verticalListSortingStrategy, useSortable, arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import api from '../services/api';
import { useServerDraft } from '../hooks/useServerDraft';

// ── Constants ────────────────────────────────────────────────────────────────

const WIZARD_STEPS = ['Subject', 'Columns', 'Filters & Conditions', 'Parameters', 'Layout', 'Review & Save'];

// FIX 5 (Phase 81): Relative date macro options available as default values for date/date_range params
const RELATIVE_DATE_OPTIONS = [
  { value: '', label: 'No Default' },
  { value: '@TODAY', label: '@TODAY — today\'s date' },
  { value: '@YESTERDAY', label: '@YESTERDAY — yesterday' },
  { value: '@MONTH_START', label: '@MONTH_START — first day of this month' },
  { value: '@MONTH_END', label: '@MONTH_END — last day of this month' },
  { value: '@YEAR_START', label: '@YEAR_START — first day of this year' },
  { value: '@YEAR_END', label: '@YEAR_END — last day of this year' },
  { value: '@LAST_7_DAYS', label: '@LAST_7_DAYS — 7 days ago' },
  { value: '@LAST_30_DAYS', label: '@LAST_30_DAYS — 30 days ago' },
  { value: '@LAST_90_DAYS', label: '@LAST_90_DAYS — 90 days ago' },
  { value: '__custom__', label: 'Custom date...' },
];

const COLUMN_TYPE_COLORS: Record<string, string> = {
  dimension: '#2196f3',
  measure: '#4caf50',
  detail: '#ff9800',
  kpi: '#e91e63',
};

const FILTER_OPERATORS = [
  { value: 'eq', label: '= Equals' },
  { value: 'neq', label: '!= Not Equals' },
  { value: 'gt', label: '> Greater Than' },
  { value: 'gte', label: '>= Greater or Equal' },
  { value: 'lt', label: '< Less Than' },
  { value: 'lte', label: '<= Less or Equal' },
  { value: 'in', label: 'In List' },
  { value: 'not_in', label: 'Not In List' },
  { value: 'between', label: 'Between' },
  { value: 'like', label: 'Contains (LIKE)' },
  { value: 'not_like', label: 'Not Contains' },
  { value: 'starts_with', label: 'Starts With' },
  { value: 'ends_with', label: 'Ends With' },
  { value: 'is_null', label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

// Phase 85D-5: Running calculation types with descriptions for tooltips
const CALC_TYPES = [
  { value: 'running_sum', label: 'Running Sum', description: 'Cumulative sum from first row to current row' },
  { value: 'rank', label: 'Rank', description: 'Row rank by value (1 = highest)' },
  { value: 'percent_of_total', label: '% of Total', description: "This row's value ÷ column total × 100" },
  { value: 'previous_value', label: 'Previous Value', description: 'Value from the previous row for comparison' },
];

const PARAM_TYPES = [
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'multi_select', label: 'Multi-Select' },
  { value: 'text', label: 'Text Input' },
  { value: 'date', label: 'Date Picker' },
  { value: 'date_range', label: 'Date Range' },
  { value: 'numeric', label: 'Numeric Input' },
];

// ── Helper types ─────────────────────────────────────────────────────────────

interface FilterEntry {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
}

interface SectionDef {
  name: string;
  break_column_id: number;
  subtotal_measure_ids: number[];
  show_count: boolean;
}

interface RunningCalcDef {
  name: string;
  calc_type: string;
  measure_col_id: number;
  partition_col_id: number | null;
  format_pattern: string;
}

interface ParamDef {
  id?: number;
  name: string;
  label: string;
  parameter_type: string;
  lov_column_id: number | null;
  depends_on_param_id: number | null;
  cascade_filter_column_id: number | null;
  default_value: string;
  is_required: boolean;
  sort_order: number;
}

// ── Component ────────────────────────────────────────────────────────────────

const BusinessReportBuilder: React.FC = () => {
  const navigate = useNavigate();
  const { id: editId } = useParams<{ id: string }>();
  const isEdit = !!editId;

  // Wizard state
  const [activeStep, setActiveStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Step 0: Subject
  const [dataSourceType, setDataSourceType] = useState<'saved_query' | 'published_view'>('saved_query');
  const [datasets, setDatasets] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | null>(null);
  const [dataset, setDataset] = useState<any>(null);
  const [publishedViews, setPublishedViews] = useState<any[]>([]);
  const [selectedPvId, setSelectedPvId] = useState<number | null>(null);

  // Step 1: Columns
  const [allColumns, setAllColumns] = useState<any[]>([]);
  const [allClasses, setAllClasses] = useState<any[]>([]);
  const [selectedColumnIds, setSelectedColumnIds] = useState<number[]>([]);
  const [columnSearch, setColumnSearch] = useState('');

  // Step 2: Filters & Conditions
  const [filters, setFilters] = useState<FilterEntry[]>([]);
  const [conditions, setConditions] = useState<any[]>([]);
  const [selectedConditionIds, setSelectedConditionIds] = useState<number[]>([]);
  const [orderBy, setOrderBy] = useState<Array<{ column_id: number; direction: string }>>([]);
  const [rowLimit, setRowLimit] = useState(50000);

  // Step 3: Parameters
  const [params, setParams] = useState<ParamDef[]>([]);

  // Step 4: Layout
  const [sections, setSections] = useState<SectionDef[]>([]);
  const [runningCalcs, setRunningCalcs] = useState<RunningCalcDef[]>([]);
  const [slicerColumnIds, setSlicerColumnIds] = useState<number[]>([]);
  const [hierarchies, setHierarchies] = useState<any[]>([]);
  const [drillHierarchyId, setDrillHierarchyId] = useState<number | null>(null);

  // Step 4b: Report Style
  const [styleConfig, setStyleConfig] = useState({
    header_bg: '#1976D2',
    header_text: '#FFFFFF',
    accent_color: '#1565C0',
    negative_format: 'brackets' as 'brackets' | 'minus' | 'red',
    stripe_rows: true,
    subtotal_bg: '#F5F5F5',
    grand_total_bg: '#E8EAF6',
  });
  const updateStyle = (key: string, value: any) =>
    setStyleConfig(prev => ({ ...prev, [key]: value }));

  // Preserved layout_config from existing report (edit mode) — merged on save
  const [existingLayoutConfig, setExistingLayoutConfig] = useState<Record<string, any>>({});

  // Step 5: Review — Phase 142 persistence so user can come back to
  // a half-built report after refresh / pod restart.
  const [reportName, setReportName] = useServerDraft<string>('report.new.name', '');
  const [reportDescription, setReportDescription] = useServerDraft<string>('report.new.desc', '');
  // Phase 131 deep-dive #12 — group-based ownership (entitlement parity
  // with Report / FeedConfig / PublishedView).  Picker on Review step;
  // null = single-owner only (legacy behaviour preserved).
  const [ownerGroupId, setOwnerGroupId] = useState<number | ''>('');
  const [userGroups, setUserGroups] = useState<Array<{id: number; name: string; description?: string|null}>>([]);

  // Phase 85D-6: Preview report in review step
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [previewCols, setPreviewCols] = useState<string[]>([]);
  const [previewError, setPreviewError] = useState('');

  // ── Load datasets on mount ────────────────────────────────────────────────

  useEffect(() => {
    api.listDatasets().then((data: any) => {
      const published = (Array.isArray(data) ? data : []).filter((d: any) => d.is_published);
      setDatasets(published);
    }).catch(() => {});
    // Phase 100: load published views for PV data source option
    api.listPublishedViews().then((data: any) => {
      const active = (Array.isArray(data) ? data : []).filter((v: any) => v.is_active);
      setPublishedViews(active);
    }).catch(() => {});
    // Phase 131 deep-dive #12 — load user groups for the ownership
    // picker.  Same admin endpoint used by FeedConfigsPage.  Fails
    // silently for non-admin users (picker just stays empty).
    (api as any).listUserGroups?.({ is_active: true })
      .then((groups: any) => setUserGroups(Array.isArray(groups) ? groups : []))
      .catch(() => setUserGroups([]));
  }, []);

  // ── Load existing report for editing ──────────────────────────────────────

  useEffect(() => {
    if (!editId) return;
    setLoading(true);
    api.getBusinessReport(Number(editId)).then((report: any) => {
      // Phase 100: restore data source type and PV selection
      if (report.data_source_type === 'published_view') {
        setDataSourceType('published_view');
        setSelectedPvId(report.published_view_id || null);
      }
      setSelectedDatasetId(report.dataset_id);
      setSelectedColumnIds(report.column_ids || []);
      setFilters(report.filter_specs || []);
      setSelectedConditionIds(report.condition_ids || []);
      setOrderBy(report.order_by || []);
      setRowLimit(report.row_limit || 50000);
      setSections(report.section_definitions || []);
      setRunningCalcs(report.running_calculations || []);
      setSlicerColumnIds(report.slicer_column_ids || []);
      setDrillHierarchyId(report.drill_hierarchy_id);
      // Preserve full layout_config for merge on save (keeps column_order, report_type, etc.)
      if (report.layout_config) setExistingLayoutConfig(report.layout_config);
      const sc = report.layout_config?.style_config;
      if (sc) setStyleConfig(prev => ({ ...prev, ...sc }));
      setReportName(report.name || '');
      setReportDescription(report.description || '');
      // Phase 131 deep-dive #12 — hydrate group ownership on edit.
      setOwnerGroupId((report.owner_group_id ?? '') || '');
      if (report.parameters) {
        setParams(report.parameters.map((p: any) => ({
          id: p.id,
          name: p.name,
          label: p.label,
          parameter_type: p.parameter_type,
          lov_column_id: p.lov_column_id,
          depends_on_param_id: p.depends_on_param_id,
          cascade_filter_column_id: p.cascade_filter_column_id,
          default_value: p.default_value || '',
          is_required: p.is_required,
          sort_order: p.sort_order,
        })));
      }
    }).catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [editId]);

  // ── Load dataset detail when selected ─────────────────────────────────────

  useEffect(() => {
    if (!selectedDatasetId) return;
    api.getDataset(selectedDatasetId).then((ds: any) => {
      setDataset(ds);
      setAllColumns(ds.columns || []);
      setAllClasses(ds.classes || []);
      setConditions(ds.conditions || []);
      setHierarchies(ds.hierarchies || []);
    }).catch(() => setError('Failed to load dataset columns. Check if the dataset still exists.'));
  }, [selectedDatasetId]);

  // ── Column helpers ────────────────────────────────────────────────────────

  const dimensions = allColumns.filter((c: any) => c.column_type === 'dimension');
  const measures = allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');
  const selectedCols = allColumns.filter((c: any) => selectedColumnIds.includes(c.id));
  const selectedDims = selectedCols.filter((c: any) => c.column_type === 'dimension');
  const selectedMeasures = selectedCols.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');

  const getColName = (colId: number) => {
    const col = allColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  };

  // ── Toggle column selection ───────────────────────────────────────────────

  const toggleColumn = (colId: number) => {
    setSelectedColumnIds(prev =>
      prev.includes(colId) ? prev.filter(id => id !== colId) : [...prev, colId]
    );
  };

  // ── Filter management ─────────────────────────────────────────────────────

  const addFilter = () => {
    if (allColumns.length === 0) return;
    setFilters(prev => [...prev, { column_id: allColumns[0].id, operator: 'eq', value: '' }]);
  };

  const updateFilter = (idx: number, field: string, val: any) => {
    setFilters(prev => prev.map((f, i) => i === idx ? { ...f, [field]: val } : f));
  };

  const removeFilter = (idx: number) => {
    setFilters(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Parameter management ──────────────────────────────────────────────────

  const addParam = () => {
    setParams(prev => [...prev, {
      name: `param_${prev.length + 1}`,
      label: `Parameter ${prev.length + 1}`,
      parameter_type: 'dropdown',
      lov_column_id: null,
      depends_on_param_id: null,
      cascade_filter_column_id: null,
      default_value: '',
      is_required: true,
      sort_order: prev.length,
    }]);
  };

  const updateParam = (idx: number, field: string, val: any) => {
    setParams(prev => prev.map((p, i) => i === idx ? { ...p, [field]: val } : p));
  };

  const removeParam = (idx: number) => {
    setParams(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Section management ────────────────────────────────────────────────────

  const addSection = () => {
    if (selectedDims.length === 0) return;
    setSections(prev => [...prev, {
      name: `Section ${prev.length + 1}`,
      break_column_id: selectedDims[0].id,
      subtotal_measure_ids: [],
      show_count: true,
    }]);
  };

  const updateSection = (idx: number, field: string, val: any) => {
    setSections(prev => prev.map((s, i) => i === idx ? { ...s, [field]: val } : s));
  };

  const removeSection = (idx: number) => {
    setSections(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Running calc management ───────────────────────────────────────────────

  const addRunningCalc = () => {
    if (selectedMeasures.length === 0) return;
    setRunningCalcs(prev => [...prev, {
      name: `Calc ${prev.length + 1}`,
      calc_type: 'running_sum',
      measure_col_id: selectedMeasures[0].id,
      partition_col_id: null,
      format_pattern: '',
    }]);
  };

  const updateCalc = (idx: number, field: string, val: any) => {
    setRunningCalcs(prev => prev.map((c, i) => i === idx ? { ...c, [field]: val } : c));
  };

  const removeCalc = (idx: number) => {
    setRunningCalcs(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Save report ───────────────────────────────────────────────────────────

  const handleSave = async () => {
    if (!reportName.trim()) {
      setError('Report name is required');
      return;
    }
    // Phase 100: for PV source, skip dataset/column validation
    if (dataSourceType === 'saved_query') {
      if (!selectedDatasetId) {
        setError('Please select a dataset');
        return;
      }
      if (selectedColumnIds.length === 0) {
        setError('Please select at least one column');
        return;
      }
    } else if (dataSourceType === 'published_view') {
      if (!selectedPvId) {
        setError('Please select a published view');
        return;
      }
    }

    setSaving(true);
    setError('');

    const data: any = {
      name: reportName.trim(),
      description: reportDescription.trim(),
      dataset_id: selectedDatasetId || 0,
      data_source_type: dataSourceType,
      published_view_id: dataSourceType === 'published_view' ? selectedPvId : null,
      column_ids: selectedColumnIds,
      filter_specs: filters.map(f => {
        if (['in', 'not_in'].includes(f.operator) && typeof f.value === 'string') {
          return { ...f, value: f.value.split(',').map((v: string) => v.trim()).filter(Boolean) };
        }
        return f;
      }),
      condition_ids: selectedConditionIds,
      order_by: orderBy,
      row_limit: rowLimit,
      section_definitions: sections,
      running_calculations: runningCalcs,
      slicer_column_ids: slicerColumnIds,
      drill_hierarchy_id: drillHierarchyId,
      layout_config: { ...existingLayoutConfig, style_config: styleConfig },
      // Phase 131 deep-dive #12 — group ownership.  null clears it.
      owner_group_id: ownerGroupId === '' ? null : Number(ownerGroupId),
    };

    try {
      let report: any;
      if (isEdit) {
        report = await api.updateBusinessReport(Number(editId), data);
      } else {
        report = await api.createBusinessReport(data);
      }

      // Save parameters via atomic batch endpoint (replaces N+1 pattern)
      if (report && report.id) {
        // Pass 1: batch-create all params without cascade links
        const batchItems = params.map((p: any, i: number) => ({
          name: p.name,
          label: p.label,
          parameter_type: p.parameter_type,
          lov_column_id: p.lov_column_id || null,
          default_value: p.default_value || null,
          is_required: p.is_required ?? true,
          sort_order: i,
        }));
        const batchResult = await api.batchSaveBusinessReportParams(report.id, batchItems);
        const createdParams = batchResult.parameters || [];

        // Pass 2: set depends_on_param_id for cascade params (typically 0-2 calls)
        if (createdParams.length === params.length) {
          const oldIdToNewId: Record<number | string, number> = {};
          for (let i = 0; i < params.length; i++) {
            if (params[i].id) oldIdToNewId[params[i].id] = createdParams[i].id;
            oldIdToNewId[i] = createdParams[i].id;
          }
          for (let i = 0; i < params.length; i++) {
            const p = params[i];
            if (p.depends_on_param_id != null) {
              const realParentId = oldIdToNewId[p.depends_on_param_id];
              if (realParentId) {
                await api.updateBusinessReportParam(createdParams[i].id, {
                  depends_on_param_id: realParentId,
                  cascade_filter_column_id: p.cascade_filter_column_id || null,
                });
              }
            }
          }
        }
        navigate(`/business-reports/${report.id}`);
      }
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to save report');
    } finally {
      setSaving(false);
    }
  };

  // ── Step validation ───────────────────────────────────────────────────────

  const canProceed = (step: number): boolean => {
    switch (step) {
      case 0: return dataSourceType === 'published_view' ? selectedPvId !== null : (selectedDatasetId !== null && selectedDatasetId > 0);
      case 1: return dataSourceType === 'published_view' || selectedColumnIds.length > 0;
      case 5: return reportName.trim().length > 0;
      default: return true;
    }
  };

  const proceedHint = (step: number): string => {
    switch (step) {
      case 0:
        if (dataSourceType === 'published_view') return selectedPvId === null ? 'Select a published view to continue' : '';
        return selectedDatasetId === null ? 'Select a data source to continue' : '';
      case 1: return dataSourceType !== 'published_view' && selectedColumnIds.length === 0 ? 'Select at least one column' : '';
      case 5: return reportName.trim().length === 0 ? 'Enter a report name to save' : '';
      default: return '';
    }
  };

  // ── Render steps ──────────────────────────────────────────────────────────

  const renderStep0_Subject = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Select Data Source</Typography>

      {/* Phase 100: Data source type selector */}
      <RadioGroup row value={dataSourceType}
        onChange={e => {
          const newType = e.target.value as 'saved_query' | 'published_view';
          setDataSourceType(newType);
          if (newType === 'published_view') {
            setSelectedDatasetId(null); setDataset(null);
            setAllColumns([]); setSelectedColumnIds([]);
            setFilters([]); setSelectedConditionIds([]);
            setOrderBy([]); setSections([]); setRunningCalcs([]);
            setSlicerColumnIds([]); setDrillHierarchyId(null);
          } else {
            setSelectedPvId(null);
          }
        }}
        sx={{ mb: 2 }}>
        <FormControlLabel value="saved_query" control={<Radio size="small" />} label="Dataset (Query)" />
        <FormControlLabel value="published_view" control={<Radio size="small" />} label="Published View (Cached API)" />
      </RadioGroup>

      {dataSourceType === 'saved_query' ? (
        <>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Choose a published dataset as the data source for your report.
          </Typography>
          {datasets.length === 0 ? (
            <Alert severity="info">No published datasets available. Ask an admin to publish a dataset first.</Alert>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {datasets.map((ds: any) => (
                <Paper
                  key={ds.id}
                  elevation={selectedDatasetId === ds.id ? 4 : 1}
                  sx={{
                    p: 2, cursor: 'pointer',
                    border: selectedDatasetId === ds.id ? '2px solid #1976d2' : '2px solid transparent',
                    '&:hover': { bgcolor: 'action.hover' },
                  }}
                  onClick={() => setSelectedDatasetId(ds.id)}
                >
                  <Typography variant="subtitle1" fontWeight="bold">{ds.name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {ds.description || 'No description'} — {ds.subject || 'General'}
                  </Typography>
                </Paper>
              ))}
            </Box>
          )}
        </>
      ) : (
        <>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Choose a Published View. Reports using Published Views benefit from 8-hour cache, ETag support, and shared data across reports.
          </Typography>
          {publishedViews.length === 0 ? (
            <Alert severity="info">No active published views available.</Alert>
          ) : (
            <Autocomplete
              options={publishedViews}
              getOptionLabel={(v: any) => `${v.name} (${v.slug})`}
              value={publishedViews.find((v: any) => v.id === selectedPvId) || null}
              onChange={(_e, val) => setSelectedPvId(val ? val.id : null)}
              renderInput={(params) => <TextField {...params} label="Published View" placeholder="Search by name or slug..." />}
              sx={{ maxWidth: 500 }}
            />
          )}
          {selectedPvId && (
            <Alert severity="success" sx={{ mt: 2 }}>
              Published View selected. Columns and filters will be controlled by the view configuration.
              You can still add report parameters to pass to the view.
            </Alert>
          )}
        </>
      )}
    </Box>
  );

  // DnD sensors for column reorder
  const dndSensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  // Sortable column item for the reorder list
  const SortableColumnItem: React.FC<{ colId: number }> = ({ colId }) => {
    const col = allColumns.find((c: any) => c.id === colId);
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: String(colId) });
    return (
      <Box ref={setNodeRef}
        sx={{
          display: 'flex', alignItems: 'center', gap: 1, px: 1, py: 0.5,
          bgcolor: isDragging ? 'action.hover' : 'background.paper',
          border: '1px solid', borderColor: 'divider', borderRadius: 1,
          opacity: isDragging ? 0.5 : 1,
          transform: CSS.Transform.toString(transform), transition,
        }}
        {...attributes}
      >
        <Box {...listeners} sx={{ cursor: 'grab', display: 'flex', color: 'text.secondary' }}>
          <DragIcon fontSize="small" />
        </Box>
        <Chip size="small" label={col?.column_type || '?'}
          sx={{ bgcolor: COLUMN_TYPE_COLORS[col?.column_type] || '#999', color: '#fff', fontSize: 10, height: 20 }} />
        <Typography variant="body2" sx={{ flexGrow: 1 }}>
          {col?.friendly_name || col?.physical_name || `Col #${colId}`}
        </Typography>
        <Tooltip title="Remove column from report">
          <IconButton size="small" onClick={() => toggleColumn(colId)}><DeleteIcon fontSize="small" /></IconButton>
        </Tooltip>
      </Box>
    );
  };

  const renderStep1_Columns = () => {
    // PV mode: columns are controlled by the Published View
    if (dataSourceType === 'published_view') {
      return (
        <Box>
          <Typography variant="h6" sx={{ mb: 2 }}>Columns</Typography>
          <Alert severity="info" sx={{ mb: 2 }}>
            Column selection is controlled by the Published View configuration.
            Click Next to continue to filters and layout.
          </Alert>
        </Box>
      );
    }
    // Group columns by class
    const byClass: Record<string, any[]> = { 'Ungrouped': [] };
    for (const cls of allClasses) {
      byClass[cls.label || cls.name] = [];
    }
    for (const col of allColumns) {
      if (col.is_hidden) continue;
      const cls = allClasses.find((c: any) => c.id === col.class_id);
      const key = cls ? (cls.label || cls.name) : 'Ungrouped';
      if (!byClass[key]) byClass[key] = [];
      byClass[key].push(col);
    }

    // Filter columns by search term
    const searchLower = columnSearch.toLowerCase().trim();
    const filteredByClass: Record<string, any[]> = {};
    for (const [className, cols] of Object.entries(byClass)) {
      const filtered = searchLower
        ? cols.filter((c: any) =>
            (c.friendly_name || '').toLowerCase().includes(searchLower) ||
            (c.physical_name || '').toLowerCase().includes(searchLower))
        : cols;
      if (filtered.length > 0) filteredByClass[className] = filtered;
    }
    const visibleColIds = Object.values(filteredByClass).flat().map((c: any) => c.id);

    return (
      <Box>
        <Typography variant="h6" sx={{ mb: 1 }}>Select Columns</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Pick the dimensions and measures to include in your report. Drag to reorder below.
        </Typography>

        {/* Search + bulk actions */}
        <Box sx={{ display: 'flex', gap: 1, mb: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <TextField
            size="small" placeholder="Search columns..." value={columnSearch}
            onChange={e => setColumnSearch(e.target.value)}
            sx={{ minWidth: 240 }}
            InputProps={{
              startAdornment: <SearchIcon sx={{ mr: 0.5, fontSize: 18, color: 'text.secondary' }} />,
              endAdornment: columnSearch ? (
                <Tooltip title="Clear search"><IconButton size="small" onClick={() => setColumnSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton></Tooltip>
              ) : null,
            }}
          />
          <Chip label={`${selectedColumnIds.length} selected`} size="small" color="primary" />
          <Button size="small" variant="outlined"
            onClick={() => {
              const dims = allColumns.filter((c: any) => c.column_type === 'dimension').map((c: any) => c.id);
              setSelectedColumnIds(prev => [...new Set([...prev, ...dims])]);
            }}>All Dimensions</Button>
          <Button size="small" variant="outlined"
            onClick={() => {
              const meas = allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi').map((c: any) => c.id);
              setSelectedColumnIds(prev => [...new Set([...prev, ...meas])]);
            }}>All Measures</Button>
          {visibleColIds.length > 0 && searchLower && (
            <Button size="small" variant="outlined"
              onClick={() => setSelectedColumnIds(prev => [...new Set([...prev, ...visibleColIds])])}>
              Select Visible ({visibleColIds.length})
            </Button>
          )}
          {selectedColumnIds.length > 0 && (
            <Button size="small" color="error" onClick={() => setSelectedColumnIds([])}>Clear All</Button>
          )}
        </Box>

        {Object.entries(filteredByClass).map(([className, cols]) => (
          <Box key={className} sx={{ mb: 2 }}>
            <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 0.5 }}>
              {className} ({cols.length})
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {cols.map((col: any) => (
                <Chip
                  key={col.id}
                  label={col.friendly_name || col.physical_name}
                  size="small"
                  variant={selectedColumnIds.includes(col.id) ? 'filled' : 'outlined'}
                  onClick={() => toggleColumn(col.id)}
                  sx={{
                    borderColor: COLUMN_TYPE_COLORS[col.column_type] || '#999',
                    bgcolor: selectedColumnIds.includes(col.id)
                      ? COLUMN_TYPE_COLORS[col.column_type] || '#999' : 'transparent',
                    color: selectedColumnIds.includes(col.id) ? '#fff' : 'inherit',
                    '&:hover': { opacity: 0.85 },
                  }}
                />
              ))}
            </Box>
          </Box>
        ))}
        {searchLower && Object.keys(filteredByClass).length === 0 && (
          <Alert severity="info" sx={{ mt: 1 }}>No columns match "{columnSearch}"</Alert>
        )}

        {/* Column order — drag to reorder */}
        {selectedColumnIds.length > 0 && (
          <Box sx={{ mt: 3 }}>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Column Order (drag to reorder)</Typography>
            <DndContext sensors={dndSensors} collisionDetection={closestCenter}
              onDragEnd={(event) => {
                const { active, over } = event;
                if (over && active.id !== over.id) {
                  setSelectedColumnIds(prev => {
                    const oldIdx = prev.indexOf(Number(active.id));
                    const newIdx = prev.indexOf(Number(over.id));
                    return arrayMove(prev, oldIdx, newIdx);
                  });
                }
              }}>
              <SortableContext items={selectedColumnIds.map(String)} strategy={verticalListSortingStrategy}>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxWidth: 480 }}>
                  {selectedColumnIds.map(colId => (
                    <SortableColumnItem key={colId} colId={colId} />
                  ))}
                </Box>
              </SortableContext>
            </DndContext>
          </Box>
        )}
      </Box>
    );
  };

  const renderStep2_Filters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Filters & Conditions</Typography>

      {dataSourceType === 'published_view' && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Filters configured on the Published View will be applied automatically.
          You can add additional report-level filters below if needed.
        </Alert>
      )}

      {/* Static filters */}
      <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Default Filters</Typography>
      {filters.map((f, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select value={f.column_id} onChange={e => updateFilter(idx, 'column_id', e.target.value)}>
              {allColumns.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select value={f.operator} onChange={e => updateFilter(idx, 'operator', e.target.value)}>
              {FILTER_OPERATORS.map(op => (
                <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* Operator-specific value inputs */}
          {['is_null', 'is_not_null'].includes(f.operator) ? null
            : ['in', 'not_in'].includes(f.operator) ? (
              <Autocomplete
                multiple freeSolo size="small"
                options={[]}
                value={Array.isArray(f.value) ? f.value : (f.value || '').split(',').map((s: string) => s.trim()).filter(Boolean)}
                onChange={(_e, newVal: string[]) => updateFilter(idx, 'value', newVal)}
                renderInput={(params) => (
                  <TextField {...params} placeholder="Type a value and press Enter" size="small"
                    helperText="Press Enter to add each value" />
                )}
                sx={{ minWidth: 280 }}
              />
            ) : f.operator === 'between' ? (
              <>
                <TextField size="small" value={f.value || ''} onChange={e => updateFilter(idx, 'value', e.target.value)}
                  placeholder="From" sx={{ minWidth: 100 }} />
                <Typography variant="body2" sx={{ mx: 0.5 }}>and</Typography>
                <TextField size="small" value={f.value2 || ''} onChange={e => updateFilter(idx, 'value2', e.target.value)}
                  placeholder="To" sx={{ minWidth: 100 }} />
              </>
            ) : ['like', 'not_like', 'starts_with', 'ends_with'].includes(f.operator) ? (
              <TextField size="small" value={f.value || ''} onChange={e => updateFilter(idx, 'value', e.target.value)}
                placeholder={f.operator === 'starts_with' ? 'prefix...' : f.operator === 'ends_with' ? '...suffix' : 'search text'}
                sx={{ minWidth: 150 }} />
            ) : (
              <TextField size="small" value={f.value || ''} onChange={e => updateFilter(idx, 'value', e.target.value)}
                placeholder="Value" sx={{ minWidth: 120 }} />
            )
          }
          <Tooltip title="Remove this filter">
            <IconButton size="small" onClick={() => removeFilter(idx)}><DeleteIcon fontSize="small" /></IconButton>
          </Tooltip>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addFilter}>Add Filter</Button>

      {/* Pre-defined conditions */}
      {conditions.length > 0 && (
        <>
          <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Pre-defined Conditions</Typography>
          {conditions.map((c: any) => (
            <FormControlLabel
              key={c.id}
              control={
                <Checkbox
                  checked={selectedConditionIds.includes(c.id)}
                  onChange={() => {
                    setSelectedConditionIds(prev =>
                      prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
                    );
                  }}
                />
              }
              label={c.label || c.name}
            />
          ))}
        </>
      )}

      {/* Order by */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Sort Order</Typography>
      {orderBy.map((ob, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select value={ob.column_id} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], column_id: Number(e.target.value) };
              setOrderBy(newOb);
            }}>
              {selectedCols.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 100 }}>
            <Select value={ob.direction} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], direction: e.target.value };
              setOrderBy(newOb);
            }}>
              <MenuItem value="asc">Ascending</MenuItem>
              <MenuItem value="desc">Descending</MenuItem>
            </Select>
          </FormControl>
          <Tooltip title="Remove sort">
            <IconButton size="small" onClick={() => setOrderBy(prev => prev.filter((_, i) => i !== idx))}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={() => {
        if (selectedCols.length > 0)
          setOrderBy(prev => [...prev, { column_id: selectedCols[0].id, direction: 'asc' }]);
      }}>Add Sort</Button>

      {/* Row limit */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Row Limit</Typography>
      <TextField size="small" type="number" value={rowLimit}
        onChange={e => setRowLimit(Math.max(1, Number(e.target.value)))} sx={{ width: 150 }} />
    </Box>
  );

  const renderStep3_Parameters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Parameters (Cascading Prompts)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Define input controls that users fill in before running the report.
        Dropdown parameters can cascade (e.g., Country selection filters Region list).
      </Typography>

      {params.map((p, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 2, mb: 2 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={p.name}
              onChange={e => updateParam(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Label" value={p.label}
              onChange={e => updateParam(idx, 'label', e.target.value)} sx={{ width: 200 }} />
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>Type</InputLabel>
              <Select value={p.parameter_type} label="Type"
                onChange={e => updateParam(idx, 'parameter_type', e.target.value)}>
                {PARAM_TYPES.map(pt => (
                  <MenuItem key={pt.value} value={pt.value}>{pt.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            {['dropdown', 'multi_select'].includes(p.parameter_type) && (
              <FormControl size="small" sx={{ minWidth: 180 }}>
                <InputLabel>LOV Column</InputLabel>
                <Select value={p.lov_column_id || ''} label="LOV Column"
                  onChange={e => updateParam(idx, 'lov_column_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {allColumns.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {idx > 0 && ['dropdown', 'multi_select'].includes(p.parameter_type) && (
              <FormControl size="small" sx={{ minWidth: 160 }}>
                <InputLabel>Depends On</InputLabel>
                <Select value={p.depends_on_param_id || ''} label="Depends On"
                  onChange={e => updateParam(idx, 'depends_on_param_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {params.slice(0, idx).map((pp, pi) => (
                    <MenuItem key={pi} value={pp.id || pi}>{pp.label}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {p.depends_on_param_id != null && (
              <FormControl size="small" sx={{ minWidth: 160 }}>
                <InputLabel>Cascade Filter Col</InputLabel>
                <Select value={p.cascade_filter_column_id || ''} label="Cascade Filter Col"
                  onChange={e => updateParam(idx, 'cascade_filter_column_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {allColumns.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {/* FIX 5: date/date_range params get relative date macro dropdown */}
            {['date', 'date_range'].includes(p.parameter_type) ? (
              <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                <FormControl size="small" sx={{ minWidth: 200 }}>
                  <InputLabel>Default</InputLabel>
                  <Select
                    value={RELATIVE_DATE_OPTIONS.some(o => o.value === p.default_value && o.value !== '__custom__')
                      ? p.default_value
                      : (p.default_value ? '__custom__' : '')}
                    label="Default"
                    onChange={e => {
                      const v = e.target.value;
                      if (v !== '__custom__') updateParam(idx, 'default_value', v);
                    }}
                  >
                    {RELATIVE_DATE_OPTIONS.map(o => (
                      <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {/* Show custom text input when __custom__ is selected or value doesn't match presets */}
                {p.default_value && !RELATIVE_DATE_OPTIONS.some(o => o.value === p.default_value && o.value !== '__custom__') && (
                  <TextField size="small" label="Custom default"
                    value={p.default_value}
                    onChange={e => updateParam(idx, 'default_value', e.target.value)}
                    placeholder="YYYY-MM-DD"
                    sx={{ width: 130 }}
                  />
                )}
              </Box>
            ) : (
              <TextField size="small" label="Default" value={p.default_value}
                onChange={e => updateParam(idx, 'default_value', e.target.value)} sx={{ width: 120 }} />
            )}
            <FormControlLabel
              control={<Checkbox checked={p.is_required} onChange={e => updateParam(idx, 'is_required', e.target.checked)} />}
              label="Required"
            />
            <Tooltip title="Remove this parameter">
              <IconButton size="small" onClick={() => removeParam(idx)}><DeleteIcon fontSize="small" /></IconButton>
            </Tooltip>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addParam}>Add Parameter</Button>
    </Box>
  );

  const renderStep4_Layout = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Layout & Calculations</Typography>

      {dataSourceType === 'published_view' && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Layout options like section breaks, running calculations, and slicers are optional for
          Published View reports. They operate on the columns returned by the view.
        </Alert>
      )}

      {/* Section Breaks */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Section Breaks (Subtotals)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Group rows by a dimension with section headers and subtotals per group.
      </Typography>
      {sections.map((s, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Section Name" value={s.name}
              onChange={e => updateSection(idx, 'name', e.target.value)} sx={{ width: 160 }} />
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Break Column</InputLabel>
              <Select value={s.break_column_id} label="Break Column"
                onChange={e => updateSection(idx, 'break_column_id', e.target.value)}>
                {selectedDims.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Subtotal Measures</InputLabel>
              <Select multiple value={s.subtotal_measure_ids} label="Subtotal Measures"
                onChange={e => updateSection(idx, 'subtotal_measure_ids', e.target.value)}
                renderValue={(sel: number[]) => sel.map(id => getColName(id)).join(', ')}>
                {selectedMeasures.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControlLabel
              control={<Checkbox checked={s.show_count} onChange={e => updateSection(idx, 'show_count', e.target.checked)} />}
              label="Count"
            />
            <Tooltip title="Remove this section break"><IconButton size="small" onClick={() => removeSection(idx)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addSection}
        disabled={selectedDims.length === 0}>Add Section Break</Button>

      <Divider sx={{ my: 3 }} />

      {/* Running Calculations */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Running Calculations</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Post-query computed columns: running sum, rank, % of total, previous value.
      </Typography>
      {runningCalcs.map((c, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={c.name}
              onChange={e => updateCalc(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <FormControl size="small" sx={{ minWidth: 140 }}>
                <InputLabel>Type</InputLabel>
                <Select value={c.calc_type} label="Type"
                  onChange={e => updateCalc(idx, 'calc_type', e.target.value)}>
                  {CALC_TYPES.map(ct => (
                    <MenuItem key={ct.value} value={ct.value}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        {ct.label}
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {/* Phase 85D-5: Tooltip for selected calc type */}
              {(() => {
                const selectedCalcType = CALC_TYPES.find(ct => ct.value === c.calc_type);
                return selectedCalcType ? (
                  <Tooltip title={selectedCalcType.description} placement="top">
                    <InfoOutlinedIcon sx={{ fontSize: 16, color: 'info.main', cursor: 'help' }} />
                  </Tooltip>
                ) : null;
              })()}
            </Box>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Measure</InputLabel>
              <Select value={c.measure_col_id} label="Measure"
                onChange={e => updateCalc(idx, 'measure_col_id', e.target.value)}>
                {selectedMeasures.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Partition By</InputLabel>
              <Select value={c.partition_col_id || ''} label="Partition By"
                onChange={e => updateCalc(idx, 'partition_col_id', e.target.value || null)}>
                <MenuItem value="">None (Global)</MenuItem>
                {selectedDims.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <Tooltip title="Remove this calculation"><IconButton size="small" onClick={() => removeCalc(idx)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addRunningCalc}
        disabled={selectedMeasures.length === 0}>Add Calculation</Button>

      <Divider sx={{ my: 3 }} />

      {/* Slicer Columns */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Slicer Columns (Cross-Filter)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Viewers can filter report results instantly by selecting slicer values.
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
        {selectedDims.map((c: any) => (
          <Chip
            key={c.id}
            label={c.friendly_name || c.physical_name}
            size="small"
            variant={slicerColumnIds.includes(c.id) ? 'filled' : 'outlined'}
            color={slicerColumnIds.includes(c.id) ? 'primary' : 'default'}
            onClick={() => {
              setSlicerColumnIds(prev =>
                prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
              );
            }}
          />
        ))}
      </Box>

      <Divider sx={{ my: 3 }} />

      {/* Drill Hierarchy */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Drill Hierarchy</Typography>
      {hierarchies.length > 0 ? (
        <FormControl size="small" sx={{ minWidth: 250 }}>
          <InputLabel>Drill Hierarchy</InputLabel>
          <Select value={drillHierarchyId || ''} label="Drill Hierarchy"
            onChange={e => setDrillHierarchyId(e.target.value ? Number(e.target.value) : null)}>
            <MenuItem value="">None</MenuItem>
            {hierarchies.map((h: any) => (
              <MenuItem key={h.id} value={h.id}>{h.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
      ) : (
        <Typography variant="body2" color="text.secondary">
          No drill hierarchies defined for this dataset.
        </Typography>
      )}

      <Divider sx={{ my: 3 }} />

      {/* Report Style */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Report Style</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Customize colors and number formatting for the report viewer and exports.
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 2 }}>
        {/* Color pickers */}
        {([
          ['header_bg', 'Header Background'],
          ['header_text', 'Header Text'],
          ['accent_color', 'Section Header'],
          ['subtotal_bg', 'Subtotal Row'],
          ['grand_total_bg', 'Grand Total Row'],
        ] as [string, string][]).map(([key, label]) => (
          <Box key={key} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <input
              type="color"
              value={(styleConfig as any)[key]}
              onChange={e => updateStyle(key, e.target.value)}
              style={{ width: 32, height: 32, border: '1px solid #ccc', borderRadius: 4, cursor: 'pointer', padding: 0 }}
            />
            <TextField
              size="small"
              label={label}
              value={(styleConfig as any)[key]}
              onChange={e => updateStyle(key, e.target.value)}
              sx={{ width: 120 }}
              inputProps={{ style: { fontFamily: 'monospace', fontSize: 13 } }}
            />
          </Box>
        ))}
      </Box>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'center' }}>
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Negative Numbers</InputLabel>
          <Select value={styleConfig.negative_format} label="Negative Numbers"
            onChange={e => updateStyle('negative_format', e.target.value)}>
            <MenuItem value="brackets">Brackets (1,234)</MenuItem>
            <MenuItem value="minus">Minus Sign -1,234</MenuItem>
            <MenuItem value="red">Red Color Only</MenuItem>
          </Select>
        </FormControl>
        <FormControlLabel
          control={<Switch checked={styleConfig.stripe_rows} onChange={e => updateStyle('stripe_rows', e.target.checked)} />}
          label="Striped Rows"
        />
      </Box>
    </Box>
  );

  // Phase 85D-6: Preview report (only if already saved as edit)
  const handlePreviewReport = async () => {
    if (!editId) return;
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewRows([]);
    setPreviewCols([]);
    setPreviewDialogOpen(true);
    try {
      const result = await api.executeBusinessReport(Number(editId), {
        parameter_values: {},
        extra_filters: [],
        limit: 10,
      });
      const rows = result?.rows || [];
      const cols = result?.columns || (rows[0] ? Object.keys(rows[0]) : []);
      setPreviewRows(rows.slice(0, 10));
      setPreviewCols(cols);
    } catch (e: any) {
      setPreviewError(e.message || 'Preview failed');
    } finally {
      setPreviewLoading(false);
    }
  };

  const renderStep5_Review = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Review & Save</Typography>

      <TextField
        fullWidth label="Report Name" value={reportName}
        onChange={e => setReportName(e.target.value)}
        sx={{ mb: 2 }} required error={!reportName.trim()}
        helperText={!reportName.trim() ? 'Name is required' : ''}
      />
      <TextField
        fullWidth label="Description" value={reportDescription}
        onChange={e => setReportDescription(e.target.value)}
        multiline rows={2} sx={{ mb: 3 }}
      />

      {/* Phase 131 deep-dive #12 — group ownership.  Entitlement parity
          with FeedConfigsPage Step 4 + Report.owner_group_id.  Members
          of the picked group get rerun/edit access per their access
          level (read_only / read_write). */}
      <FormControl fullWidth size="small" sx={{ mb: 3 }}>
        <InputLabel id="br-owner-group-label">Owner Group (optional)</InputLabel>
        <Select
          labelId="br-owner-group-label"
          label="Owner Group (optional)"
          value={ownerGroupId === '' ? '' : String(ownerGroupId)}
          onChange={(e) => {
            const v = e.target.value;
            setOwnerGroupId(v === '' ? '' : Number(v));
          }}
        >
          <MenuItem value=""><em>No group — solo (only creator + admins)</em></MenuItem>
          {userGroups.map((g) => (
            <MenuItem key={g.id} value={String(g.id)}>
              {g.name}{g.description ? ` — ${g.description}` : ''}
            </MenuItem>
          ))}
        </Select>
        <FormHelperText>
          Group members get view/edit access per their access level (read_only vs read_write).
        </FormHelperText>
      </FormControl>

      <Divider sx={{ mb: 2 }} />

      {/* Phase 85D-6: Preview button (only for existing saved reports) */}
      {isEdit && (
        <Box sx={{ mb: 2 }}>
          <Button
            variant="outlined"
            size="small"
            startIcon={previewLoading ? <CircularProgress size={14} /> : <PreviewReportIcon />}
            onClick={handlePreviewReport}
            disabled={previewLoading}
          >
            Preview Report (10 rows)
          </Button>
        </Box>
      )}

      <Typography variant="subtitle2" gutterBottom>Summary</Typography>

      <Table size="small">
        <TableBody>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold', width: 180 }}>
              {dataSourceType === 'published_view' ? 'Published View' : 'Dataset'}
            </TableCell>
            <TableCell>
              {dataSourceType === 'published_view'
                ? (publishedViews.find((v: any) => v.id === selectedPvId)?.name || `PV #${selectedPvId}`)
                : (dataset?.name || selectedDatasetId)}
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Columns</TableCell>
            <TableCell>{selectedColumnIds.length} selected ({selectedDims.length} dims, {selectedMeasures.length} measures)</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Filters</TableCell>
            <TableCell>{filters.length} filters, {selectedConditionIds.length} conditions</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Parameters</TableCell>
            <TableCell>{params.length} input controls</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Section Breaks</TableCell>
            <TableCell>{sections.length} sections</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Running Calculations</TableCell>
            <TableCell>{runningCalcs.length} calculations</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Slicers</TableCell>
            <TableCell>{slicerColumnIds.length} slicer columns</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Drill Hierarchy</TableCell>
            <TableCell>{drillHierarchyId ? hierarchies.find((h: any) => h.id === drillHierarchyId)?.name || 'Selected' : 'None'}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Row Limit</TableCell>
            <TableCell>{rowLimit.toLocaleString()}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </Box>
  );

  // ── Main render ───────────────────────────────────────────────────────────

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  const stepRenderers = [
    renderStep0_Subject,
    renderStep1_Columns,
    renderStep2_Filters,
    renderStep3_Parameters,
    renderStep4_Layout,
    renderStep5_Review,
  ];

  return (
    <Box sx={{ maxWidth: 1000, mx: 'auto', p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <Tooltip title="Back to Business Reports list">
          <IconButton onClick={() => navigate('/business-reports')} sx={{ mr: 1 }}>
            <ArrowBackIcon />
          </IconButton>
        </Tooltip>
        <Typography variant="h5">{isEdit ? 'Edit Report' : 'New Business Report'}</Typography>
      </Box>

      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 3 }}>
        {WIZARD_STEPS.map(label => (
          <Step key={label}><StepLabel>{label}</StepLabel></Step>
        ))}
      </Stepper>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <Paper elevation={2} sx={{ p: 3, mb: 3, minHeight: 300 }}>
        {stepRenderers[activeStep]()}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Button
          disabled={activeStep === 0}
          startIcon={<ArrowBackIcon />}
          onClick={() => setActiveStep(prev => prev - 1)}
        >
          Back
        </Button>

        {activeStep < WIZARD_STEPS.length - 1 ? (
          <Tooltip title={proceedHint(activeStep)} placement="top">
            <span>
              <Button
                variant="contained"
                endIcon={<ArrowForwardIcon />}
                disabled={!canProceed(activeStep)}
                onClick={() => setActiveStep(prev => prev + 1)}
              >
                Next
              </Button>
            </span>
          </Tooltip>
        ) : (
          <Tooltip title={proceedHint(activeStep)} placement="top">
            <span>
              <Button
                variant="contained"
                color="primary"
                startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon />}
                disabled={saving || !canProceed(activeStep)}
                onClick={handleSave}
              >
                {saving ? 'Saving...' : (isEdit ? 'Update Report' : 'Create Report')}
              </Button>
            </span>
          </Tooltip>
        )}
      </Box>

      {/* Phase 85D-6: Preview Report Dialog */}
      <Dialog open={previewDialogOpen} onClose={() => setPreviewDialogOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle>Preview Report (10 rows)</DialogTitle>
        <DialogContent dividers>
          {previewLoading ? (
            <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
          ) : previewError ? (
            <Alert severity="error">{previewError}</Alert>
          ) : previewRows.length === 0 ? (
            <Typography color="text.secondary">No rows returned from preview.</Typography>
          ) : (
            <Box sx={{ overflowX: 'auto' }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {previewCols.map(col => (
                      <TableCell key={col} sx={{ fontWeight: 700, fontSize: 12, whiteSpace: 'nowrap' }}>{col}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {previewRows.map((row, idx) => (
                    <TableRow key={idx}>
                      {previewCols.map(col => (
                        <TableCell key={col} sx={{ fontSize: 12, whiteSpace: 'nowrap' }}>
                          {row[col] === null || row[col] === undefined
                            ? <span style={{ color: '#aaa' }}>null</span>
                            : String(row[col]).substring(0, 60)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default BusinessReportBuilder;
