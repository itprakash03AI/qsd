/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowRunsPage — global dashboard for all dataflow runs.
 * Live-updated via WebSocket workflow_run_started / workflow_run_completed events.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Chip, CircularProgress, IconButton, MenuItem, Paper, Select,
  Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Tooltip, Typography,
} from '@mui/material';
import {
  OpenInNew as OpenIcon, Refresh as RefreshIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import type { DataFlowRun } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const STATUS_COLOR: Record<string, any> = {
  pending: 'default',
  running: 'info',
  succeeded: 'success',
  failed: 'error',
  cancelled: 'warning',
  partial: 'warning',
};

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 19).replace('T', ' ') : '—';
const fmtDur = (s?: number | null) => s == null ? '—' : `${s.toFixed(1)}s`;

export default function DataFlowRunsPage() {
  const nav = useNavigate();
  const ws = useWebSocket();

  const [runs, setRuns] = useState<DataFlowRun[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.dataflows.listRuns(
        statusFilter ? { status: statusFilter, limit: 200 } : { limit: 200 },
      );
      setRuns(toArray<DataFlowRun>(list));
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  // Live update on dataflow run events
  useEffect(() => {
    if (!ws?.addListener) return;
    const handler = (msg: any) => {
      if (!msg) return;
      if (msg.event === 'workflow_run_started' ||
          msg.event === 'workflow_run_completed' ||
          msg.event === 'workflow_stage_completed') {
        load();
      }
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, load]);

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">DataFlow Runs</Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Select size="small" value={statusFilter} displayEmpty
                   onChange={e => setStatusFilter(e.target.value)}
                   sx={{ minWidth: 160 }}>
            <MenuItem value="">All statuses</MenuItem>
            <MenuItem value="pending">Pending</MenuItem>
            <MenuItem value="running">Running</MenuItem>
            <MenuItem value="succeeded">Succeeded</MenuItem>
            <MenuItem value="failed">Failed</MenuItem>
            <MenuItem value="cancelled">Cancelled</MenuItem>
            <MenuItem value="partial">Partial</MenuItem>
          </Select>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Run ID</TableCell>
              <TableCell>DataFlow</TableCell>
              <TableCell>Version</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Triggered by</TableCell>
              <TableCell>Started</TableCell>
              <TableCell>Duration</TableCell>
              <TableCell align="right">Open</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={8} align="center">
                <CircularProgress size={20} />
              </TableCell></TableRow>
            )}
            {!loading && runs.length === 0 && (
              <TableRow><TableCell colSpan={8} align="center">
                <Typography variant="body2" color="text.secondary">No runs.</Typography>
              </TableCell></TableRow>
            )}
            {runs.map(r => (
              <TableRow key={r.id} hover>
                <TableCell>#{r.id}</TableCell>
                <TableCell>{r.dataflow_name}</TableCell>
                <TableCell>v{r.dataflow_version}</TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5} alignItems="center">
                    <Chip label={r.status} size="small" color={STATUS_COLOR[r.status] || 'default'}
                           variant="outlined" sx={{ fontSize: 10 }} />
                    {r.sla_breached && (
                      <Tooltip title="Run exceeded its SLA budget (sla_breached flag set on completion)">
                        <Chip label="SLA" size="small" color="error" variant="filled"
                              sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
                <TableCell>
                  {r.triggered_by || '—'}
                  {r.run_as && r.run_as !== r.triggered_by && (
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                      as {r.run_as}
                    </Typography>
                  )}
                </TableCell>
                <TableCell sx={{ fontSize: 12 }}>{fmtDt(r.started_at)}</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{fmtDur(r.duration_seconds)}</TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => nav(`/dataflows/runs/${r.id}`)}>
                    <OpenIcon fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
