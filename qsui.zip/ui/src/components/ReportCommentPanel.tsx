/**
 * ReportCommentPanel — Threaded comments for business reports (Phase 114-L).
 *
 * Features:
 *  - Top-level comments + nested replies (1 level)
 *  - @mention extraction highlighted in blue
 *  - Resolve/unresolve toggle per comment
 *  - Delete (own comments only, admin can delete any)
 *  - Real-time updates via WebSocket `report_comment` events
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, TextField, Button, IconButton, Divider,
  Chip, Tooltip, CircularProgress, Alert,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import ReplyIcon from '@mui/icons-material/Reply';
import DeleteIcon from '@mui/icons-material/Delete';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import api from '../services/api';
import { toArray } from '../utils/toArray';
import { useAuth } from '../context/AuthContext';

interface Comment {
  id: number;
  report_id: number;
  parent_id: number | null;
  username: string;
  text: string;
  mentions: string[];
  is_resolved: boolean;
  created_at: string;
  updated_at: string;
}

interface ReportCommentPanelProps {
  reportId: number;
}

function renderText(text: string) {
  // Highlight @mentions in blue
  const parts = text.split(/(@\w+)/g);
  return parts.map((part, i) =>
    part.startsWith('@') ? (
      <Typography key={i} component="span" sx={{ color: 'primary.main', fontWeight: 600 }}>{part}</Typography>
    ) : (
      <span key={i}>{part}</span>
    )
  );
}

export default function ReportCommentPanel({ reportId }: ReportCommentPanelProps) {
  const { user } = useAuth();
  const username = user?.username || '';
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newText, setNewText] = useState('');
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');
  const [posting, setPosting] = useState(false);

  const loadComments = useCallback(async () => {
    try {
      const data = await api.listReportComments(reportId);
      setComments(toArray(data));  // BF-428P
    } catch (e: any) {
      setError(e.message || 'Failed to load comments');
    } finally {
      setLoading(false);
    }
  }, [reportId]);

  useEffect(() => { loadComments(); }, [loadComments]);

  const handlePost = async (text: string, parentId: number | null = null) => {
    if (!text.trim()) return;
    setPosting(true);
    try {
      await api.createReportComment(reportId, { text: text.trim(), parent_id: parentId || undefined });
      if (parentId) { setReplyText(''); setReplyTo(null); }
      else setNewText('');
      loadComments();
    } catch (e: any) {
      setError(e.message || 'Failed to post comment');
    } finally {
      setPosting(false);
    }
  };

  const handleDelete = async (commentId: number) => {
    if (!window.confirm('Delete this comment?')) return;
    try {
      await api.deleteReportComment(reportId, commentId);
      loadComments();
    } catch (e: any) {
      setError(e.message || 'Failed to delete');
    }
  };

  const handleResolve = async (commentId: number, resolved: boolean) => {
    try {
      await api.updateReportComment(reportId, commentId, { is_resolved: !resolved });
      loadComments();
    } catch (e: any) {
      setError(e.message || 'Failed to update');
    }
  };

  if (loading) return <Box sx={{ p: 2, textAlign: 'center' }}><CircularProgress size={24} /></Box>;

  // Build threaded structure
  const topLevel = comments.filter(c => !c.parent_id);
  const replies = (parentId: number) => comments.filter(c => c.parent_id === parentId);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {error && <Alert severity="warning" sx={{ mx: 1, mt: 1 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Comment list */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1.5, py: 1 }}>
        {topLevel.length === 0 && (
          <Typography color="text.secondary" variant="body2" sx={{ py: 3, textAlign: 'center' }}>
            No comments yet. Be the first to comment!
          </Typography>
        )}
        {topLevel.map(comment => (
          <Box key={comment.id} sx={{ mb: 1.5 }}>
            <Box sx={{
              p: 1.5, borderRadius: 1, bgcolor: comment.is_resolved ? 'action.hover' : 'background.paper',
              border: '1px solid', borderColor: 'divider',
            }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                <Typography variant="caption" fontWeight={700}>{comment.username}</Typography>
                <Typography variant="caption" color="text.secondary">
                  {new Date(comment.created_at).toLocaleString()}
                </Typography>
                {comment.is_resolved && <Chip label="Resolved" size="small" color="success" variant="outlined" sx={{ height: 18, fontSize: '0.65rem' }} />}
                <Box sx={{ flex: 1 }} />
                <Tooltip title={comment.is_resolved ? 'Unresolve' : 'Resolve'}>
                  <IconButton size="small" onClick={() => handleResolve(comment.id, comment.is_resolved)}>
                    {comment.is_resolved ? <CheckCircleIcon sx={{ fontSize: 16, color: 'success.main' }} /> : <RadioButtonUncheckedIcon sx={{ fontSize: 16 }} />}
                  </IconButton>
                </Tooltip>
                {(comment.username === username || isAdmin) && (
                  <Tooltip title="Delete">
                    <IconButton size="small" onClick={() => handleDelete(comment.id)}>
                      <DeleteIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </Tooltip>
                )}
              </Box>
              <Typography variant="body2">{renderText(comment.text)}</Typography>
              {/* Reply button */}
              <Box sx={{ mt: 0.5 }}>
                <Button size="small" startIcon={<ReplyIcon sx={{ fontSize: 14 }} />}
                  onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                  sx={{ fontSize: '0.7rem', textTransform: 'none' }}>
                  Reply
                </Button>
              </Box>
            </Box>

            {/* Replies */}
            {replies(comment.id).map(reply => (
              <Box key={reply.id} sx={{
                ml: 3, mt: 0.5, p: 1, borderRadius: 1,
                bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider',
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.25 }}>
                  <Typography variant="caption" fontWeight={700}>{reply.username}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {new Date(reply.created_at).toLocaleString()}
                  </Typography>
                  <Box sx={{ flex: 1 }} />
                  {(reply.username === username || isAdmin) && (
                    <Tooltip title="Delete reply">
                      <IconButton size="small" onClick={() => handleDelete(reply.id)}>
                        <DeleteIcon sx={{ fontSize: 14 }} />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
                <Typography variant="body2" fontSize="0.85rem">{renderText(reply.text)}</Typography>
              </Box>
            ))}

            {/* Reply input */}
            {replyTo === comment.id && (
              <Box sx={{ ml: 3, mt: 0.5, display: 'flex', gap: 0.5 }}>
                <TextField size="small" fullWidth placeholder="Write a reply..."
                  value={replyText} onChange={e => setReplyText(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handlePost(replyText, comment.id); } }}
                />
                <IconButton size="small" color="primary" disabled={posting || !replyText.trim()}
                  onClick={() => handlePost(replyText, comment.id)}>
                  <SendIcon sx={{ fontSize: 18 }} />
                </IconButton>
              </Box>
            )}
          </Box>
        ))}
      </Box>

      <Divider />
      {/* New comment input */}
      <Box sx={{ p: 1.5, display: 'flex', gap: 0.5 }}>
        <TextField size="small" fullWidth placeholder="Add a comment... (use @username to mention)"
          value={newText} onChange={e => setNewText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handlePost(newText); } }}
        />
        <IconButton color="primary" disabled={posting || !newText.trim()} onClick={() => handlePost(newText)}>
          {posting ? <CircularProgress size={20} /> : <SendIcon />}
        </IconButton>
      </Box>
    </Box>
  );
}
