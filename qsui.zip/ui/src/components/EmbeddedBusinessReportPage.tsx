/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * EmbeddedBusinessReportPage — iframe-safe embedded report viewer (no auth, minimal chrome).
 *
 * Route: /embedded-business-report/:token
 *
 * Features:
 *  - No navigation bar or header (iframe-friendly)
 *  - Auto-execute on load
 *  - Parameter override via URL search params
 *  - Compact results table
 *  - Respects embed row limit
 */
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { getUserFriendlyError } from '../utils/errorMessages';
import { useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Box, CircularProgress, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, TableContainer, Table, TableHead,
  TableRow, TableCell, TableBody, TablePagination, Typography, Tooltip,
} from '@mui/material';
import {
  GetApp as GetAppIcon,
  PictureAsPdf as PictureAsPdfIcon,
  TableView as TableViewIcon,
} from '@mui/icons-material';
import api from '../services/api';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

export default function EmbeddedBusinessReportPage() {
  const { token } = useParams<{ token: string }>();
  const [searchParams] = useSearchParams();

  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [result, setResult] = useState<any>(null);
  const [executing, setExecuting] = useState(false);
  const [execError, setExecError] = useState('');
  const [usedParams, setUsedParams] = useState<Record<string, any>>({});

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  const [exportError, setExportError] = useState('');

  // Load metadata + auto-execute
  useEffect(() => {
    if (!token) return;
    (async () => {
      setLoading(true);
      try {
        const res = await api.getEmbeddedBusinessReport(token);
        setReport(res.report);

        // FIX 4 (Phase 81): URL params with p_* prefix override defaults
        // e.g. /embedded-business-report/abc123?p_region=West
        const paramValues: Record<string, any> = {};
        (res.report.parameters || []).forEach((p: any) => {
          const urlVal = searchParams.get(`p_${p.name}`);
          if (urlVal != null) {
            paramValues[p.name] = urlVal;
          } else if (p.default_value != null) {
            paramValues[p.name] = p.default_value;
          }
        });

        // Auto-execute
        setUsedParams(paramValues);
        setExecuting(true);
        try {
          const execRes = await api.executeEmbeddedBusinessReport(token, {
            parameter_values: paramValues,
          });
          setResult(execRes);
        } catch (e: any) {
          setExecError(getUserFriendlyError(e, 'Execution failed'));
        } finally { setExecuting(false); }
      } catch (e: any) {
        setError(getUserFriendlyError(e, 'Embed token not found or expired'));
      } finally { setLoading(false); }
    })();
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  const columns = result?.columns || [];
  const allRows = result?.rows || [];
  const paginatedRows = allRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (loading || executing) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center',
        minHeight: '100vh', flexDirection: 'column', gap: 1 }}>
        <CircularProgress />
        <Typography variant="body2" color="text.secondary">
          {loading ? 'Loading report...' : 'Running report...'}
        </Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center',
        minHeight: '100vh', flexDirection: 'column', gap: 1, p: 2 }}>
        <Typography variant="h6" color="error">Embed Error</Typography>
        <Typography variant="body2" color="text.secondary">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Compact header */}
      <Box sx={{ px: 2, py: 1, bgcolor: 'grey.50', borderBottom: '1px solid', borderColor: 'divider',
        display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography variant="subtitle2" fontWeight={600} noWrap sx={{ flex: 1 }}>
          {report?.name}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {allRows.length} row{allRows.length !== 1 ? 's' : ''}
        </Typography>
        {allRows.length > 0 && (
          <>
            <Tooltip title="Download">
              <IconButton size="small" onClick={(e) => setExportAnchor(e.currentTarget)}>
                <GetAppIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
              onClose={() => setExportAnchor(null)}>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportExcel(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'Excel export failed'); } }}>
                <ListItemIcon><TableViewIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Excel</ListItemText>
              </MenuItem>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportPDF(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'PDF export failed'); } }}>
                <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
                <ListItemText>PDF</ListItemText>
              </MenuItem>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportCSV(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'CSV export failed'); } }}>
                <ListItemIcon><GetAppIcon fontSize="small" /></ListItemIcon>
                <ListItemText>CSV</ListItemText>
              </MenuItem>
            </Menu>
          </>
        )}
      </Box>

      {execError && <Alert severity="error" sx={{ mx: 2, mt: 1 }}>{execError}</Alert>}
      {exportError && <Alert severity="error" sx={{ mx: 2, mt: 1 }} onClose={() => setExportError('')}>{exportError}</Alert>}

      {/* Results table */}
      {result && (
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <TableContainer sx={{ flex: 1 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((col: string, i: number) => (
                    <TableCell key={i} sx={{
                      fontWeight: 600, bgcolor: '#00aeef', color: '#fff',
                      textTransform: 'uppercase', fontSize: 11,
                    }}>{col}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRows.map((row: any[], ri: number) => (
                  <TableRow key={ri} hover>
                    {row.map((v: any, ci: number) => (
                      <TableCell key={ci} sx={{ fontSize: 12 }}>
                        {v === null || v === undefined ? '' : String(v)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={allRows.length}
            page={page} onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
            sx={{ flexShrink: 0 }}
          />
        </Box>
      )}

      {/* Footer attribution */}
      <Box sx={{ px: 2, py: 0.5, bgcolor: 'grey.50', borderTop: '1px solid', borderColor: 'divider',
        textAlign: 'right' }}>
        <Typography variant="caption" color="text.disabled">Powered by QueryStudio</Typography>
      </Box>
    </Box>
  );
}
