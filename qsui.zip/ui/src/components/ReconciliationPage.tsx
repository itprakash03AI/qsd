/**
 * ReconciliationPage (Phase 133).
 *
 * Source-vs-Destination recon reports.  Two tabs:
 *   * Dashboard — table of all configured recon entities + status chips +
 *     "Check Now" / "Reload" actions + a break-details drawer.
 *   * Configuration — same table, but Edit / New buttons open the
 *     full config dialog.
 *
 * Each recon entity:
 *   * Picks 2 (or 3) connections via the connection manager
 *       — source (e.g. Starburst), dest (e.g. Oracle), etl (optional,
 *         Oracle — only required when this report needs the rerun
 *         PL/SQL package).
 *   * Supplies SQL via a saved .sql file (preferred) OR an inline
 *     query string OR a source/dest pair (for dialect differences).
 *   * Configures the comparison mode + key columns.
 *   * Decides whether the scheduled check + auto-reload-on-break is on.
 */
import {
  useCallback, useEffect, useMemo, useState,
} from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, Chip, IconButton, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, Tabs, Tab, Select,
  MenuItem, FormControl, InputLabel, FormControlLabel, Switch, Divider,
  CircularProgress, Autocomplete,
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  PlayArrow as RunIcon, Refresh as RefreshIcon,
  ReplayCircleFilled as ReloadIcon, History as HistoryIcon,
  CheckCircle as OkIcon, Error as BreakIcon, HelpOutline as UnknownIcon,
  Warning as WarnIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  ReconciliationEntity, ReconciliationRun,
  WhereClauseMappingRow,
} from '../services/api/reconciliation';
import WhereClausesEditor from './common/WhereClausesEditor';
import type { WhereClauseRow } from './common/WhereClausesEditor';
import { SqlColumnExtractor } from './common/extractSqlColumns';
import { fetchPartitionValueOptions } from './common/fetchPartitionValueOptions';
import DynamicWhereOverrideField from './common/DynamicWhereOverrideField';
import type { PartitionValueOptions } from './common/fetchPartitionValueOptions';
import { previewColumns, distinctValues } from './common/sqlPreviewApi';


// ── Helpers ─────────────────────────────────────────────────────────


function statusChip(status?: string | null) {
  if (status === 'ok') {
    return <Chip icon={<OkIcon />} label="OK" color="success" size="small" />;
  }
  if (status === 'break') {
    return <Chip icon={<BreakIcon />} label="BREAK" color="error" size="small" />;
  }
  if (status === 'error') {
    return <Chip icon={<WarnIcon />} label="ERROR" color="warning" size="small" />;
  }
  return <Chip icon={<UnknownIcon />} label="—" size="small" variant="outlined" />;
}


function relTime(iso?: string | null): string {
  if (!iso) return '—';
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return iso;
  const delta = Math.floor((Date.now() - t) / 1000);
  if (delta < 60) return `${delta}s ago`;
  if (delta < 3600) return `${Math.floor(delta / 60)}m ago`;
  if (delta < 86400) return `${Math.floor(delta / 3600)}h ago`;
  return `${Math.floor(delta / 86400)}d ago`;
}


// ── Component ───────────────────────────────────────────────────────


export default function ReconciliationPage() {
  // Top-level state
  const [tab, setTab] = useState<'dashboard' | 'config'>('dashboard');
  const [entities, setEntities] = useState<ReconciliationEntity[]>([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [info, setInfo]         = useState('');

  // Connections + sql files (for dropdowns inside the dialog)
  const [connections, setConnections] = useState<any[]>([]);
  const [sqlFiles, setSqlFiles] = useState<any[]>([]);

  // Dialog state — add / edit
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<ReconciliationEntity | null>(null);
  const [form, setForm] = useState<Partial<ReconciliationEntity>>({});

  // Per-row "busy" state so the action buttons can show a spinner
  const [busyId, setBusyId] = useState<number | null>(null);

  // Break-details / run-history drawer
  const [historyEntity, setHistoryEntity] = useState<ReconciliationEntity | null>(null);
  const [runs, setRuns] = useState<ReconciliationRun[]>([]);

  // Phase 133-E — per-trigger override dialog state.  Populated when
  // the user clicks "Check Now" on an entity that has Dynamic rows.
  const [overrideEntity, setOverrideEntity] =
    useState<ReconciliationEntity | null>(null);
  const [overrideValues, setOverrideValues] =
    useState<Record<string, any>>({});

  // Phase 133-F — partition values fetched from the source connection's
  // cache.  Drives the column dropdown's partition badges AND the
  // per-row value-picker autocomplete in the where-clauses editor.
  const [partitionInfo, setPartitionInfo] = useState<PartitionValueOptions>({
    valueOptionsByColumn: {}, partitionColumns: [],
  });

  // Refetch whenever the user changes the source connection — runs
  // best-effort, swallows errors silently, and stays empty for
  // connections that don't have partitioned tables.
  useEffect(() => {
    let cancelled = false;
    const cid = form.source_connection_id;
    if (!cid) {
      setPartitionInfo({ valueOptionsByColumn: {}, partitionColumns: [] });
      return () => { cancelled = true; };
    }
    fetchPartitionValueOptions(cid).then(p => {
      if (!cancelled) setPartitionInfo(p);
    });
    return () => { cancelled = true; };
  }, [form.source_connection_id]);

  // Phase 133-F deep-dive — load SQL content from any picked .sql file
  // so the column dropdown is non-empty in file-only mode too.
  // Without this the user picks "source.sql" + "dest.sql" and the
  // where-editor dropdown stays blank because the extractor was only
  // reading the inline-text form fields.
  const [sqlFileContent, setSqlFileContent] = useState<{
    primary: string; secondary: string; combined: string;
  } | null>(null);

  // Phase 133-G — sqlglot-based column list (handles CTEs / subqueries
  // that the browser regex misses) + extra distinct-value autocomplete
  // for columns that aren't S3 partitions.  Both are best-effort; null
  // / failure cleanly falls back to the regex-only result.
  const [serverColumns, setServerColumns] = useState<string[]>([]);
  const [serverTables, setServerTables] = useState<string[]>([]);
  const [serverValueOpts, setServerValueOpts] = useState<Record<string, string[]>>({});
  // Phase 133-H round 6 — full column catalogue per source table,
  // sourced from schema_cache (populated by every CQB / register call).
  // Lets the dropdown show EVERY column on the underlying tables, not
  // just the names that appeared in the SQL text.
  const [serverColumnsByTable, setServerColumnsByTable] =
    useState<Record<string, Array<{name: string; type?: string}>>>({});
  const [serverPartitionByTable, setServerPartitionByTable] =
    useState<Record<string, string[]>>({});
  useEffect(() => {
    let cancelled = false;
    const ids: number[] = [];
    if (form.source_sql_file_id) ids.push(form.source_sql_file_id);
    if (form.dest_sql_file_id)   ids.push(form.dest_sql_file_id);
    if (!ids.length && form.sql_file_id) ids.push(form.sql_file_id);
    if (!ids.length) {
      setSqlFileContent(null);
      return () => { cancelled = true; };
    }
    Promise.all(ids.map(id =>
      api.sqlFiles.get(id).catch(() => null) as Promise<any>,
    )).then(rows => {
      if (cancelled) return;
      const primary = (rows[0]?.content || '').trim();
      const secondary = (rows[1]?.content
                          || rows[0]?.secondary_content
                          || '').trim();
      setSqlFileContent({
        primary, secondary,
        combined: [primary, secondary].filter(Boolean).join('\n'),
      });
    });
    return () => { cancelled = true; };
  }, [form.source_sql_file_id, form.dest_sql_file_id, form.sql_file_id]);

  // Backend sqlglot column extract + distinct-value fetch.  Debounced
  // so each keystroke in the inline-query textareas doesn't fire a
  // POST.  Falls back silently to regex-only when the call fails.
  useEffect(() => {
    let cancelled = false;
    const sqlBlob = [
      form.query || '',
      form.source_query || '',
      form.dest_query || '',
      sqlFileContent?.combined || '',
    ].filter(Boolean).join('\n');
    if (!sqlBlob.trim()) {
      setServerColumns([]); setServerTables([]); setServerValueOpts({});
      return () => { cancelled = true; };
    }
    const handle = setTimeout(async () => {
      // Phase 133-H round 6 — pass the source connection so the
      // endpoint returns the full per-table column catalogue from
      // schema_cache (with list_columns() fallback on miss).
      const r = await previewColumns(
        sqlBlob, 'duckdb', form.source_connection_id ?? null,
      );
      if (cancelled || !r) return;
      const cols = (r.columns || []).map(c => c.name);
      setServerColumns(cols);
      setServerTables(r.tables || []);
      setServerColumnsByTable(r.columns_by_table || {});
      setServerPartitionByTable(r.partition_columns_by_table || {});

      // Fetch distinct values for each extracted column on the source
      // connection, capped to keep load reasonable.  Skips columns
      // already covered by partition cache (those are usually higher
      // quality / pre-warmed).
      const cid = form.source_connection_id;
      const partKeys = new Set(
        Object.keys(partitionInfo.valueOptionsByColumn)
          .map(k => k.toLowerCase()),
      );
      const tableHint = (r.tables || [])[0];   // best guess
      if (cid && tableHint) {
        const FETCH_CAP = 10;
        const targets = cols
          .filter(c => !partKeys.has(c.toLowerCase()))
          .slice(0, FETCH_CAP);
        const results = await Promise.all(targets.map(async col => {
          const v = await distinctValues(cid, tableHint, col, 100);
          return [col, v?.values || []] as const;
        }));
        if (cancelled) return;
        const next: Record<string, string[]> = {};
        for (const [col, vals] of results) {
          if (vals.length > 0) next[col] = vals;
        }
        setServerValueOpts(next);
      } else {
        setServerValueOpts({});
      }
    }, 600);
    return () => { cancelled = true; clearTimeout(handle); };
  }, [form.query, form.source_query, form.dest_query,
      sqlFileContent?.combined, form.source_connection_id,
      partitionInfo.valueOptionsByColumn]);

  // ── Data loaders ────────────────────────────────────────────────

  const loadAll = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const list = await api.reconciliation.list();
      setEntities(Array.isArray(list) ? list : []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load reconciliation entities');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadLookups = useCallback(async () => {
    try {
      const [conns, files] = await Promise.all([
        api.listConnections?.() ?? Promise.resolve([]),
        api.sqlFiles?.list?.() ?? Promise.resolve([]),
      ]);
      setConnections(Array.isArray(conns) ? conns : []);
      setSqlFiles(Array.isArray(files) ? files : []);
    } catch {
      // Non-fatal — the dialog just shows empty dropdowns.
    }
  }, []);

  useEffect(() => { loadAll(); loadLookups(); }, [loadAll, loadLookups]);

  // ── Action handlers ─────────────────────────────────────────────

  /** Phase 133-E — when the entity has any Dynamic where-clause rows,
   *  we open a per-row override dialog before triggering so the caller
   *  can supply this-run values.  Static rows always apply, so they're
   *  surfaced as read-only context.  Entities with NO Dynamic rows
   *  trigger immediately (the legacy fast-path).
   */
  const dynamicRows = useCallback((ent: ReconciliationEntity)
      : WhereClauseMappingRow[] => {
    return (ent.where_clauses_mapping || [])
      .filter(r => (r.mode || 'static') === 'dynamic');
  }, []);

  const runCheck = useCallback(async (
    ent: ReconciliationEntity,
    overrides?: Record<string, any>,
  ) => {
    setBusyId(ent.id); setError(''); setInfo('');
    try {
      const res = await api.reconciliation.checkNow(
        ent.id, undefined, overrides,
      );
      setInfo(
        res.break_detected
          ? `Break detected on "${ent.name}" — see details in the History drawer.`
          : `"${ent.name}" matched — no break.`,
      );
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Check failed');
    } finally {
      setBusyId(null);
    }
  }, [loadAll]);

  const handleCheckNow = useCallback(async (ent: ReconciliationEntity) => {
    if (dynamicRows(ent).length > 0) {
      // Open override dialog instead of running immediately.
      const seed: Record<string, any> = {};
      for (const r of dynamicRows(ent)) {
        if (r.column) seed[r.column] = r.value ?? '';
      }
      setOverrideEntity(ent);
      setOverrideValues(seed);
      return;
    }
    await runCheck(ent);
  }, [dynamicRows, runCheck]);

  const handleReload = useCallback(async (ent: ReconciliationEntity) => {
    if (!ent.etl_connection_id) {
      setError(`"${ent.name}" has no ETL connection configured for reload.`);
      return;
    }
    if (!window.confirm(
      `Fire the Oracle reload package for "${ent.name}"?  ` +
      `This kicks off the OG-ETL rerun for DAG ids ` +
      `[${(ent.dag_ids || []).join(', ')}].`,
    )) return;
    setBusyId(ent.id); setError(''); setInfo('');
    try {
      const res = await api.reconciliation.reloadNow(ent.id);
      setInfo(`Reload fired for "${ent.name}" (took ${res.elapsed_ms} ms).`);
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Reload failed');
    } finally {
      setBusyId(null);
    }
  }, [loadAll]);

  const handleHistory = useCallback(async (ent: ReconciliationEntity) => {
    setHistoryEntity(ent); setRuns([]);
    try {
      const rows = await api.reconciliation.runs(ent.id, 30);
      setRuns(rows);
    } catch (e: any) {
      setError(e?.message || 'Failed to load history');
    }
  }, []);

  const handleDelete = useCallback(async (ent: ReconciliationEntity) => {
    if (!window.confirm(`Deactivate "${ent.name}"?`)) return;
    try {
      await api.reconciliation.deactivate(ent.id);
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Delete failed');
    }
  }, [loadAll]);

  // ── Dialog (add / edit) ─────────────────────────────────────────

  const openNew = () => {
    setEditing(null);
    setForm({
      name: '', description: '',
      comparison_mode: 'row_by_row',
      key_columns: [], comparison_columns: [],
      tolerance: 0, tolerance_pct: 0,
      max_rows_compared: 50000,
      dag_ids: [],
      business_date_template: '{{business_date}}',
      auto_reload_on_break: false,
      schedule_enabled: true,
      check_interval_hours: 2,
      is_active: true,
      where_clauses_mapping: [],
    });
    setDialogOpen(true);
  };

  const openEdit = (ent: ReconciliationEntity) => {
    setEditing(ent);
    setForm({ ...ent });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.source_connection_id || !form.dest_connection_id) {
      setError('Name + source connection + dest connection are required.');
      return;
    }
    // Two-file mode: BOTH or NEITHER.  Catching only-one-picked here
    // prevents the silent "picker set but runner ignored it" footgun
    // — the backend runner only honours the two-file mode when BOTH
    // FK fields are non-null.
    if (!!form.source_sql_file_id !== !!form.dest_sql_file_id) {
      setError(
        'Two-file mode needs BOTH a source AND a destination .sql file. '
        + 'Pick the missing one or clear the other to use a different mode.',
      );
      return;
    }
    if (!form.sql_file_id
        && !(form.source_sql_file_id && form.dest_sql_file_id)
        && !form.query
        && !(form.source_query && form.dest_query)) {
      setError('Supply a SQL file (one or per-side), an inline query, or both source/dest queries.');
      return;
    }
    try {
      if (editing) {
        await api.reconciliation.update(editing.id, form);
        setInfo(`Updated "${form.name}".`);
      } else {
        await api.reconciliation.create(form);
        setInfo(`Created "${form.name}".`);
      }
      setDialogOpen(false);
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    }
  };

  // ── Computed ─────────────────────────────────────────────────────

  const counts = useMemo(() => {
    const c = { total: 0, ok: 0, break: 0, error: 0, never: 0 };
    entities.forEach(e => {
      c.total += 1;
      if (e.last_status === 'ok') c.ok += 1;
      else if (e.last_status === 'break') c.break += 1;
      else if (e.last_status === 'error') c.error += 1;
      else c.never += 1;
    });
    return c;
  }, [entities]);

  const oracleAndStarburstConns = useMemo(() => ({
    starburst: connections.filter(
      c => ['starburst', 'trino'].includes(String(c.connection_type || '').toLowerCase()),
    ),
    oracle: connections.filter(
      c => String(c.connection_type || '').toLowerCase() === 'oracle',
    ),
    all: connections,
  }), [connections]);

  // ── Render ───────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
        <Box>
          <Typography variant="h4">Reconciliation Reports</Typography>
          <Typography variant="body2" color="text.secondary">
            Source vs Destination break detection · {counts.total} report
            {counts.total === 1 ? '' : 's'} · {counts.break} break
            {counts.break === 1 ? '' : 's'} · {counts.error} error
            {counts.error === 1 ? '' : 's'}
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Tooltip title="Refresh">
            <IconButton onClick={() => { loadAll(); loadLookups(); }}>
              <RefreshIcon />
            </IconButton>
          </Tooltip>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openNew}>
            New Report
          </Button>
        </Stack>
      </Stack>

      {error && (
        <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      {info && (
        <Alert severity="info" onClose={() => setInfo('')} sx={{ mb: 2 }}>
          {info}
        </Alert>
      )}

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab value="dashboard" label="Dashboard" />
        <Tab value="config"    label="Configuration" />
      </Tabs>

      <Paper variant="outlined">
        {loading ? (
          <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
        ) : entities.length === 0 ? (
          <Box sx={{ p: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">
              No reconciliation reports yet — click "New Report" to add one.
            </Typography>
          </Box>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Source row count</TableCell>
                <TableCell>Dest row count</TableCell>
                <TableCell>Last checked</TableCell>
                <TableCell>Mode</TableCell>
                <TableCell>Schedule</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {entities.map(ent => (
                <TableRow key={ent.id} hover>
                  <TableCell>
                    <Typography variant="body2" fontWeight={600}>{ent.name}</Typography>
                    {ent.description && (
                      <Typography variant="caption" color="text.secondary">
                        {ent.description}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>{statusChip(ent.last_status)}</TableCell>
                  <TableCell>
                    {ent.last_source_row_count != null
                      ? ent.last_source_row_count.toLocaleString()
                      : '—'}
                  </TableCell>
                  <TableCell>
                    {ent.last_dest_row_count != null
                      ? ent.last_dest_row_count.toLocaleString()
                      : '—'}
                  </TableCell>
                  <TableCell>{relTime(ent.last_checked_at)}</TableCell>
                  <TableCell>
                    <Chip label={ent.comparison_mode} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell>
                    {ent.schedule_enabled
                      ? `every ${ent.check_interval_hours}h`
                      : 'manual'}
                  </TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <Tooltip title="Check now (runs both queries + compares)">
                        <span>
                          <IconButton size="small" color="primary"
                            disabled={busyId === ent.id}
                            onClick={() => handleCheckNow(ent)}>
                            {busyId === ent.id
                              ? <CircularProgress size={16} />
                              : <RunIcon fontSize="small" />}
                          </IconButton>
                        </span>
                      </Tooltip>
                      {ent.etl_connection_id && (ent.dag_ids?.length ?? 0) > 0 && (
                        <Tooltip title="Reload — fire Oracle ETL package">
                          <span>
                            <IconButton size="small" color="warning"
                              disabled={busyId === ent.id}
                              onClick={() => handleReload(ent)}>
                              <ReloadIcon fontSize="small" />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                      <Tooltip title="History + break details">
                        <IconButton size="small" onClick={() => handleHistory(ent)}>
                          <HistoryIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      {tab === 'config' && (
                        <>
                          <Tooltip title="Edit">
                            <IconButton size="small" onClick={() => openEdit(ent)}>
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Deactivate">
                            <IconButton size="small" color="error"
                              onClick={() => handleDelete(ent)}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </>
                      )}
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Paper>

      {/* ── Add / Edit dialog ───────────────────────────────────── */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}
        maxWidth="md" fullWidth>
        <DialogTitle>
          {editing ? `Edit Report: ${editing.name}` : 'New Reconciliation Report'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" required fullWidth size="small"
              value={form.name || ''}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            <TextField label="Description" fullWidth size="small" multiline
              minRows={2}
              value={form.description || ''}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />

            {/* Connections */}
            <Divider><Typography variant="caption">Connections</Typography></Divider>
            <Stack direction="row" spacing={2}>
              <FormControl fullWidth size="small">
                <InputLabel>Source connection (Starburst)</InputLabel>
                <Select
                  label="Source connection (Starburst)"
                  value={form.source_connection_id ?? ''}
                  onChange={e => setForm(f => ({
                    ...f, source_connection_id: Number(e.target.value),
                  }))}>
                  {(oracleAndStarburstConns.starburst.length > 0
                    ? oracleAndStarburstConns.starburst
                    : connections).map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>
                      {c.name} <Typography variant="caption" color="text.secondary"
                        sx={{ ml: 1 }}>({c.connection_type})</Typography>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <InputLabel>Destination connection (Oracle)</InputLabel>
                <Select
                  label="Destination connection (Oracle)"
                  value={form.dest_connection_id ?? ''}
                  onChange={e => setForm(f => ({
                    ...f, dest_connection_id: Number(e.target.value),
                  }))}>
                  {(oracleAndStarburstConns.oracle.length > 0
                    ? oracleAndStarburstConns.oracle
                    : connections).map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>
                      {c.name} <Typography variant="caption" color="text.secondary"
                        sx={{ ml: 1 }}>({c.connection_type})</Typography>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>

            {/* Query — three shapes, picker per side is the preferred one. */}
            <Divider><Typography variant="caption">Query (pick one mode)</Typography></Divider>
            <Typography variant="caption" color="text.secondary">
              Recommended: two independent .sql files — one per side.
              No PRIMARY/SECONDARY markers required.
            </Typography>
            <Stack direction="row" spacing={2}>
              <Autocomplete
                size="small" fullWidth
                options={sqlFiles}
                getOptionLabel={(o: any) => o.name || `#${o.id}`}
                value={sqlFiles.find((f: any) => f.id === form.source_sql_file_id) || null}
                onChange={(_, v: any) => setForm(f => ({
                  ...f, source_sql_file_id: v ? v.id : null,
                }))}
                renderInput={(p) => (
                  <TextField {...p} label="Source .sql file"
                    helperText="Runs on the SOURCE connection." />
                )}
              />
              <Autocomplete
                size="small" fullWidth
                options={sqlFiles}
                getOptionLabel={(o: any) => o.name || `#${o.id}`}
                value={sqlFiles.find((f: any) => f.id === form.dest_sql_file_id) || null}
                onChange={(_, v: any) => setForm(f => ({
                  ...f, dest_sql_file_id: v ? v.id : null,
                }))}
                renderInput={(p) => (
                  <TextField {...p} label="Destination .sql file"
                    helperText="Runs on the DESTINATION connection." />
                )}
              />
            </Stack>

            <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
              Or: a single .sql file with <code>-- PRIMARY</code> /
              {' '}<code>-- SECONDARY</code> markers.
            </Typography>
            <Autocomplete
              size="small"
              options={sqlFiles}
              getOptionLabel={(o: any) => o.name || `#${o.id}`}
              value={sqlFiles.find((f: any) => f.id === form.sql_file_id) || null}
              onChange={(_, v: any) => setForm(f => ({
                ...f, sql_file_id: v ? v.id : null,
              }))}
              disabled={!!(form.source_sql_file_id && form.dest_sql_file_id)}
              renderInput={(p) => (
                <TextField {...p} label="Single .sql file (PRIMARY/SECONDARY markers)"
                  helperText="Ignored when two-file mode above is set." />
              )}
            />

            <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
              Or: inline SQL (one for both sides, or one per side).
            </Typography>
            <TextField
              label="Inline query (used on both sides)"
              fullWidth size="small" multiline minRows={3}
              value={form.query || ''}
              onChange={e => setForm(f => ({ ...f, query: e.target.value }))}
              disabled={!!(form.source_sql_file_id && form.dest_sql_file_id) || !!form.sql_file_id}
              sx={{ fontFamily: 'monospace' }} />

            <Stack direction="row" spacing={2}>
              <TextField label="Source query (when dialects differ)" multiline
                minRows={3} fullWidth size="small"
                value={form.source_query || ''}
                onChange={e => setForm(f => ({ ...f, source_query: e.target.value }))}
                disabled={!!(form.source_sql_file_id && form.dest_sql_file_id) || !!form.sql_file_id}
                sx={{ fontFamily: 'monospace' }} />
              <TextField label="Dest query (when dialects differ)" multiline
                minRows={3} fullWidth size="small"
                value={form.dest_query || ''}
                onChange={e => setForm(f => ({ ...f, dest_query: e.target.value }))}
                disabled={!!(form.source_sql_file_id && form.dest_sql_file_id) || !!form.sql_file_id}
                sx={{ fontFamily: 'monospace' }} />
            </Stack>

            {/* Comparison */}
            <Divider><Typography variant="caption">Comparison</Typography></Divider>
            <Stack direction="row" spacing={2}>
              <FormControl size="small" sx={{ minWidth: 200 }}>
                <InputLabel>Mode</InputLabel>
                <Select label="Mode" value={form.comparison_mode || 'row_count'}
                  onChange={e => setForm(f => ({
                    ...f, comparison_mode: e.target.value as any,
                  }))}>
                  <MenuItem value="row_count">Row count only</MenuItem>
                  <MenuItem value="row_count_sum">Row count + sums</MenuItem>
                  <MenuItem value="row_by_row">Row-by-row (recon report)</MenuItem>
                </Select>
              </FormControl>
              {/* Phase 133-I round 25 — source key columns from
                  serverColumnsByTable so the user picks from the
                  actual schema instead of typing from memory. */}
              <Autocomplete multiple freeSolo size="small" fullWidth openOnFocus
                options={Object.values(serverColumnsByTable)
                  .flat()
                  .map(c => c.name)
                  .filter((v, i, a) => v && a.indexOf(v) === i)
                  .sort()}
                value={form.key_columns || []}
                onChange={(_, v) => setForm(f => ({ ...f, key_columns: v }))}
                renderInput={(p) => (
                  <TextField {...p} label="Key columns (for row_by_row)"
                    placeholder="Pick or type column names" />
                )} />
            </Stack>
            <Stack direction="row" spacing={2}>
              <TextField label="Tolerance (absolute)" type="number" size="small"
                value={form.tolerance ?? 0}
                onChange={e => setForm(f => ({ ...f, tolerance: Number(e.target.value) }))} />
              <TextField label="Tolerance (%)" type="number" size="small"
                value={form.tolerance_pct ?? 0}
                onChange={e => setForm(f => ({ ...f, tolerance_pct: Number(e.target.value) }))} />
              <TextField label="Max rows compared" type="number" size="small"
                value={form.max_rows_compared ?? 50000}
                onChange={e => setForm(f => ({
                  ...f, max_rows_compared: Number(e.target.value),
                }))} />
            </Stack>

            {/* Schedule */}
            <Divider><Typography variant="caption">Schedule</Typography></Divider>
            <Stack direction="row" spacing={2} alignItems="center">
              <FormControlLabel
                control={<Switch checked={!!form.schedule_enabled}
                  onChange={e => setForm(f => ({
                    ...f, schedule_enabled: e.target.checked,
                  }))} />}
                label="Scheduled" />
              <TextField label="Interval (hours)" type="number" size="small"
                value={form.check_interval_hours ?? 2}
                onChange={e => setForm(f => ({
                  ...f, check_interval_hours: Number(e.target.value),
                }))} />
              <TextField label="Business date template" size="small" fullWidth
                value={form.business_date_template || '{{business_date}}'}
                onChange={e => setForm(f => ({
                  ...f, business_date_template: e.target.value,
                }))} />
            </Stack>

            {/* Phase 133-E — dynamic parameterize (Static / Dynamic WHERE rows) */}
            <Divider><Typography variant="caption">
              Dynamic parameterize (optional)
            </Typography></Divider>
            {(() => {
              // Derive a real column dropdown from the SQL the user
              // typed — same UX every other editor in QueryStudio uses,
              // not a plain text field.  Partition columns we already
              // know about (from the connection's metadata cache) get
              // a partition badge so the publisher knows the wrap is
              // free.  No backend round-trip — extractor runs in the
              // browser as the SQL is edited.
              const sqlBlob = [
                form.query || '',
                form.source_query || '',
                form.dest_query || '',
                sqlFileContent?.combined || '',
              ].filter(Boolean).join('\n');
              // Merge regex extraction + server sqlglot extraction so
              // CTEs / subqueries (regex misses) AND simple queries
              // (server may not be reachable) both populate the
              // dropdown.  Server columns win order, regex fills gaps.
              const regexExtractor = new SqlColumnExtractor(
                sqlBlob,
                partitionInfo.partitionColumns,
                partitionInfo.valueOptionsByColumn,
              );
              const regexCols = regexExtractor.extractNames();
              const mergedColNames: string[] = [];
              const seen = new Set<string>();
              for (const src of [serverColumns, regexCols]) {
                for (const c of src) {
                  const k = c.toLowerCase();
                  if (!k || seen.has(k)) continue;
                  seen.add(k); mergedColNames.push(c);
                }
              }
              const partLookup = new Set(
                partitionInfo.partitionColumns.map(c => c.toLowerCase()),
              );
              // Phase 133-H round 6 — also mark partition cols
              // surfaced via /api/sql/preview-columns (schema_cache).
              Object.values(serverPartitionByTable).forEach(arr =>
                arr.forEach(c => partLookup.add(c.toLowerCase())),
              );
              const colOpts = mergedColNames.map(name => ({
                name, type: 'string',
                isPartition: partLookup.has(name.toLowerCase()),
              }));
              for (const pc of partitionInfo.partitionColumns) {
                if (!seen.has(pc.toLowerCase())) {
                  colOpts.push({ name: pc, type: 'string', isPartition: true });
                  seen.add(pc.toLowerCase());
                }
              }
              // Phase 133-H round 6 — fold in EVERY column from the
              // schema_cache so the dropdown lists all columns on the
              // underlying tables, not just the ones named in the SQL.
              // Phase 133-I round 22 — iterate WITH table key so options
              // carry tableSource (CQB-style per-table grouping).
              Object.entries(serverColumnsByTable).forEach(([tbl, cols]) => {
                const groupLabel = tbl.replace(/^.*:/, '') || 'Other';
                cols.forEach(c => {
                  const k = (c.name || '').toLowerCase();
                  if (!k || seen.has(k)) return;
                  seen.add(k);
                  colOpts.push({
                    name: c.name,
                    type: c.type || 'string',
                    isPartition: partLookup.has(k),
                    tableSource: groupLabel,
                  } as any);
                });
              });
              // Merge value-option sources: partition cache + per-column
              // distinct-value fetches.  Partition cache wins where
              // present (pre-warmed, typed).
              const valOpts: Record<string, string[]> = {
                ...serverValueOpts,
                ...partitionInfo.valueOptionsByColumn,
              };
              const valKnown = Object.keys(valOpts).length;
              // Phase 133-H — extract a table hint for the editor's
              // lazy distinct-values fetch.  Source-side connection
              // typically has the partitioned table the WHERE clause
              // narrows down.
              const _fromMatch = sqlBlob.match(
                /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
              );
              const _tableHint = _fromMatch
                ? _fromMatch[1].replace(/[\s"`\[\]]/g, '')
                : null;
              return (
                <WhereClausesEditor
                  value={((form.where_clauses_mapping || []) as WhereClauseMappingRow[])
                    .map(r => ({
                      column: r.column || '',
                      operator: r.operator || 'eq',
                      value: r.value,
                      mode: (r.mode || 'static') as 'static' | 'dynamic',
                    })) as WhereClauseRow[]}
                  onChange={(next) => setForm(f => ({
                    ...f,
                    where_clauses_mapping: next as WhereClauseMappingRow[],
                  }))}
                  columnOptions={colOpts}
                  valueOptionsByColumn={valOpts}
                  connectionId={form.source_connection_id ?? null}
                  distinctValuesTable={_tableHint}
                  classifyTable={_tableHint}
                  title="WHERE clause mapping"
                  hint={
                    'Static rows always apply.  Dynamic rows can be overridden ' +
                    'at trigger time via "Check Now" — and fall back to the value ' +
                    'set here when the scheduler runs unattended.  ' +
                    (colOpts.length === 0
                       ? 'Type the SQL above first; the column dropdown auto-populates from it.'
                       : `${colOpts.length} column(s) detected from your SQL`
                         + (valKnown > 0
                              ? `, ${valKnown} with known partition values.`
                              : '.'))
                  }
                  addLabel="Add WHERE row"
                />
              );
            })()}

            {/* Reload — opt-in */}
            <Divider><Typography variant="caption">
              ETL Reload (optional — only for reports that should retrigger the upstream batch)
            </Typography></Divider>
            <FormControl fullWidth size="small">
              <InputLabel>OG ETL Oracle connection (optional)</InputLabel>
              <Select label="OG ETL Oracle connection (optional)"
                value={form.etl_connection_id ?? ''}
                onChange={e => setForm(f => ({
                  ...f,
                  etl_connection_id: e.target.value ? Number(e.target.value) : null,
                }))}>
                <MenuItem value=""><em>none — this report has no reload action</em></MenuItem>
                {(oracleAndStarburstConns.oracle.length > 0
                  ? oracleAndStarburstConns.oracle
                  : connections).map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.name} ({c.connection_type})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Autocomplete multiple freeSolo size="small"
              options={[]}
              value={(form.dag_ids || []).map(String)}
              onChange={(_, v) => setForm(f => ({ ...f, dag_ids: v }))}
              renderInput={(p) => (
                <TextField {...p} label="DAG IDs (passed to PR_BULK_START_DAGS_WITH_DEPS)"
                  placeholder="Type DAG ID, Enter to add" />
              )} />
            <TextField
              label="Reload PL/SQL template (optional — override the default block)"
              multiline minRows={3} size="small"
              helperText={
                "Default block builds SYS.ODCINUMBERLIST from :dag_ids " +
                "and calls PKG_OTG_DEPENDENCY_RESOLUTION.PR_BULK_START_DAGS_WITH_DEPS. " +
                "Override this only if your package uses a different array type " +
                "(e.g. PKG_OTG.NUMBER_LIST).  Must reference :dag_ids, :biz_date, :run_date."
              }
              placeholder="DECLARE l_ids MY_PKG.NUMBER_LIST := ...; BEGIN MY_PKG.MY_PROC(p_dag_ids => l_ids, ...); END;"
              value={form.reload_package_template || ''}
              onChange={e => setForm(f => ({
                ...f, reload_package_template: e.target.value,
              }))}
              sx={{ fontFamily: 'monospace' }} />
            <FormControlLabel
              control={<Switch checked={!!form.auto_reload_on_break}
                onChange={e => setForm(f => ({
                  ...f, auto_reload_on_break: e.target.checked,
                }))} />}
              label="Auto-reload when scheduled check detects a break" />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave}>
            {editing ? 'Save changes' : 'Create report'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── History / Break-details drawer ─────────────────────── */}
      <Dialog open={!!historyEntity} onClose={() => setHistoryEntity(null)}
        maxWidth="lg" fullWidth>
        <DialogTitle>
          History — {historyEntity?.name}
        </DialogTitle>
        <DialogContent>
          {historyEntity?.last_break_details &&
           Object.keys(historyEntity.last_break_details).length > 0 && (
            <Alert severity={historyEntity.last_status === 'break' ? 'error' : 'info'}
              sx={{ mb: 2 }}>
              <Typography variant="subtitle2">Latest comparison</Typography>
              <pre style={{ margin: 0, fontSize: 12 }}>
                {JSON.stringify(historyEntity.last_break_details, null, 2)}
              </pre>
            </Alert>
          )}
          {runs.length === 0 ? (
            <Typography color="text.secondary">No history yet.</Typography>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Trigger</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Business date</TableCell>
                  <TableCell>Source rows</TableCell>
                  <TableCell>Dest rows</TableCell>
                  <TableCell>Break?</TableCell>
                  <TableCell>Reload?</TableCell>
                  <TableCell>Source ms</TableCell>
                  <TableCell>Dest ms</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {runs.map(r => (
                  <TableRow key={r.id}>
                    <TableCell>{r.started_at ? new Date(r.started_at).toLocaleString() : '—'}</TableCell>
                    <TableCell>{r.triggered_by}{r.triggered_by_user ? ` (${r.triggered_by_user})` : ''}</TableCell>
                    <TableCell>{r.status}</TableCell>
                    <TableCell>{r.business_date || '—'}</TableCell>
                    <TableCell>{r.source_row_count?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell>{r.dest_row_count?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell>
                      {r.break_detected
                        ? <Chip label="BREAK" color="error" size="small" />
                        : <Chip label="ok" size="small" variant="outlined" />}
                    </TableCell>
                    <TableCell>{r.reload_triggered ? '✓' : '—'}</TableCell>
                    <TableCell>{r.source_query_ms ?? '—'}</TableCell>
                    <TableCell>{r.dest_query_ms ?? '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setHistoryEntity(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* ── Per-trigger override dialog (Phase 133-E) ─────────────── */}
      <Dialog open={!!overrideEntity} onClose={() => setOverrideEntity(null)}
        maxWidth="sm" fullWidth>
        <DialogTitle>
          Check now — {overrideEntity?.name}
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            This recon has dynamic WHERE-clause rows.  Override the values
            for this run, or accept the publisher defaults.  Static rows
            always apply and aren't shown here.
          </Typography>
          {overrideEntity && (
            <Stack spacing={2}>
              {(() => {
                // Phase 133-H — table hint for the lazy distinct-values
                // lookup.  Pull from the entity's source query (the
                // partition-bearing side).
                const _src = overrideEntity.source_query
                  || overrideEntity.query
                  || '';
                const _fromMatch = _src.match(
                  /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
                );
                const _table = _fromMatch
                  ? _fromMatch[1].replace(/[\s"`\[\]]/g, '')
                  : null;
                return (overrideEntity.where_clauses_mapping || [])
                  .filter(r => (r.mode || 'static') === 'dynamic')
                  .map((r, i) => (
                    <DynamicWhereOverrideField
                      key={`${r.column}-${i}`}
                      column={r.column}
                      operator={r.operator || 'eq'}
                      publisherDefault={r.value}
                      value={overrideValues[r.column] ?? ''}
                      onChange={(next) => setOverrideValues(v => ({
                        ...v, [r.column]: next,
                      }))}
                      connectionId={overrideEntity.source_connection_id ?? null}
                      table={_table}
                    />
                  ));
              })()}
              {(overrideEntity.where_clauses_mapping || [])
                .filter(r => (r.mode || 'static') === 'static').length > 0 && (
                <Alert severity="info">
                  <Typography variant="caption">
                    Static rows applied automatically:{' '}
                    {(overrideEntity.where_clauses_mapping || [])
                      .filter(r => (r.mode || 'static') === 'static')
                      .map(r => `${r.column} ${r.operator || 'eq'} ${
                        JSON.stringify(r.value)}`)
                      .join(' · ')}
                  </Typography>
                </Alert>
              )}
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOverrideEntity(null)}>Cancel</Button>
          <Button variant="contained"
            onClick={async () => {
              const ent = overrideEntity!;
              const overrides = { ...overrideValues };
              // Strip empty-string overrides so the Dynamic row falls
              // back to the publisher's default (rather than forcing
              // a "" filter that would silently match nothing).
              for (const k of Object.keys(overrides)) {
                if (overrides[k] === '' || overrides[k] == null) {
                  delete overrides[k];
                }
              }
              setOverrideEntity(null);
              await runCheck(ent, overrides);
            }}>
            Run check
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
