/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowCustomStagesPage — register new ETL-bridge stage types via UI.
 *
 * Admins point at any ``ETL/steps/*`` Python class — the registry hot-
 * registers a bridge stage so it appears in the catalogue / Simple Job
 * picker / DAG canvas with NO code change and NO restart.
 *
 * Backed by ``/api/dataflows/custom-stage-types`` CRUD.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControlLabel, IconButton, MenuItem,
  Paper, Select, Stack, Switch, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { toArray } from '../utils/toArray';


interface CustomStage {
  id:           number;
  name:         string;
  category:     string;
  description?: string;
  etl_module:   string;
  etl_class:    string;
  config_schema?: Record<string, any>;
  idempotency:  string;
  is_active:    boolean;
  created_by?:  string;
  created_at?:  string;
  updated_at?:  string;
}


const CATEGORIES = [
  'source', 'transform', 'sink', 'pipeline',
  'control', 'quality', 'notify',
];

const IDEMPOTENCY_OPTIONS = ['safe', 'overwrite', 'configured', 'unsafe'];


const blankForm = (): CustomStage => ({
  id: 0,
  name: '',
  category: 'pipeline',
  description: '',
  etl_module: 'steps.',
  etl_class: '',
  config_schema: {},
  idempotency: 'configured',
  is_active: true,
});


export default function DataFlowCustomStagesPage() {
  const [rows, setRows] = useState<CustomStage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<CustomStage | null>(null);
  const [form, setForm] = useState<CustomStage>(blankForm());
  const [schemaText, setSchemaText] = useState('{}');

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const list = await api.dataflows.listCustomStageTypes();
      setRows(toArray<CustomStage>(list));
    } catch (e: any) {
      setError(e?.message || 'Failed to load custom stages');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(blankForm());
    setSchemaText('{}');
    setDialogOpen(true);
  };

  const openEdit = (row: CustomStage) => {
    setEditing(row);
    setForm({ ...row });
    setSchemaText(JSON.stringify(row.config_schema || {}, null, 2));
    setDialogOpen(true);
  };

  const onSave = async () => {
    setError(null);
    try {
      let schema = {};
      try { schema = JSON.parse(schemaText || '{}'); }
      catch { throw new Error('Config schema is not valid JSON'); }

      const body = {
        name:          form.name.trim(),
        category:      form.category,
        description:   form.description,
        etl_module:    form.etl_module.trim(),
        etl_class:     form.etl_class.trim(),
        config_schema: schema,
        idempotency:   form.idempotency,
        is_active:     form.is_active,
      };
      if (editing) {
        await api.dataflows.updateCustomStageType(editing.id, body);
      } else {
        await api.dataflows.createCustomStageType(body);
      }
      setDialogOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    }
  };

  const onDelete = async (row: CustomStage) => {
    if (!window.confirm(`Delete custom stage "${row.name}"?  ` +
                          `(Will deactivate instead if any DataFlow still uses it.)`)) return;
    try {
      await api.dataflows.deleteCustomStageType(row.id);
      await load();
    } catch (e: any) { setError(e?.message || 'Delete failed'); }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5">Custom Stage Types</Typography>
          <Typography variant="caption" color="text.secondary">
            Register new ETL bridge stages by pointing at any
            <code> ETL/steps/* </code>
            Python class.  Saved here, hot-registered immediately, visible
            in the DAG canvas + Simple Job picker without a code change.
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<AddIcon />} variant="contained" onClick={openCreate}>
            New Stage Type
          </Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>ETL Class Path</TableCell>
              <TableCell>Idempotency</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Created</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={7} align="center">
                <CircularProgress size={20} />
              </TableCell></TableRow>
            )}
            {!loading && rows.length === 0 && (
              <TableRow><TableCell colSpan={7} align="center">
                <Typography variant="body2" color="text.secondary" sx={{ py: 3 }}>
                  No custom stage types yet.  Click <strong>New Stage Type</strong>
                  to register one.
                </Typography>
              </TableCell></TableRow>
            )}
            {rows.map(r => (
              <TableRow key={r.id} hover>
                <TableCell>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>{r.name}</Typography>
                  {r.description && (
                    <Typography variant="caption" color="text.secondary"
                                  sx={{ display: 'block' }}>
                      {r.description}
                    </Typography>
                  )}
                </TableCell>
                <TableCell>
                  <Chip label={r.category} size="small" variant="outlined"
                         sx={{ fontSize: 10 }} />
                </TableCell>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                  {r.etl_module}.{r.etl_class}
                </TableCell>
                <TableCell sx={{ fontSize: 12 }}>{r.idempotency}</TableCell>
                <TableCell>
                  <Chip label={r.is_active ? 'on' : 'off'} size="small"
                         color={r.is_active ? 'success' : 'default'}
                         variant="outlined" sx={{ fontSize: 10 }} />
                </TableCell>
                <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                  {r.created_by || '—'}
                  <Typography variant="caption" sx={{ display: 'block', fontSize: 10 }}>
                    {r.created_at?.slice(0, 16).replace('T', ' ')}
                  </Typography>
                </TableCell>
                <TableCell align="right">
                  <Tooltip title="Edit">
                    <IconButton size="small" onClick={() => openEdit(r)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete / Deactivate">
                    <IconButton size="small" color="error" onClick={() => onDelete(r)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Create / Edit dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}
               maxWidth="md" fullWidth>
        <DialogTitle>
          {editing ? `Edit Custom Stage: ${editing.name}` : 'New Custom Stage Type'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Stack direction="row" spacing={2}>
              <TextField label="Name" required fullWidth value={form.name}
                          onChange={e => setForm({ ...form, name: e.target.value })}
                          helperText="snake_case identifier (e.g. oracle_to_kafka)" />
              <Select size="small" value={form.category} sx={{ minWidth: 160 }}
                       onChange={e => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map(c => (
                  <MenuItem key={c} value={c}>{c}</MenuItem>
                ))}
              </Select>
            </Stack>

            <TextField label="Description" fullWidth multiline minRows={2}
                        value={form.description || ''}
                        onChange={e => setForm({ ...form, description: e.target.value })} />

            <Stack direction="row" spacing={2}>
              <TextField label="ETL Module" required fullWidth value={form.etl_module}
                          onChange={e => setForm({ ...form, etl_module: e.target.value })}
                          helperText="Python module path, e.g. steps.oracle_to_kafka"
                          sx={{ fontFamily: 'monospace' }} />
              <TextField label="ETL Class" required value={form.etl_class}
                          onChange={e => setForm({ ...form, etl_class: e.target.value })}
                          helperText="e.g. OracleToKafka"
                          sx={{ minWidth: 240, fontFamily: 'monospace' }} />
            </Stack>

            <Stack direction="row" spacing={2} alignItems="center">
              <Select size="small" value={form.idempotency} sx={{ minWidth: 160 }}
                       onChange={e => setForm({ ...form, idempotency: e.target.value })}>
                {IDEMPOTENCY_OPTIONS.map(i => (
                  <MenuItem key={i} value={i}>idempotency: {i}</MenuItem>
                ))}
              </Select>
              <FormControlLabel
                control={<Switch checked={form.is_active}
                                  onChange={e => setForm({ ...form, is_active: e.target.checked })} />}
                label="Active" />
            </Stack>

            <Box>
              <Typography variant="caption" color="text.secondary"
                            sx={{ display: 'block', mb: 0.5 }}>
                Config schema (JSON object — each key becomes a form field in the
                DAG canvas side-drawer).  Example:
                <pre style={{ fontSize: 11, margin: '4px 0' }}>{`{
  "source_table": { "type": "string", "description": "Source table" },
  "kafka_topic":  { "type": "string", "description": "Target Kafka topic" },
  "batch_size":   { "type": "integer" }
}`}</pre>
              </Typography>
              <TextField fullWidth multiline minRows={6}
                          value={schemaText}
                          onChange={e => setSchemaText(e.target.value)}
                          sx={{ fontFamily: 'monospace', fontSize: 13 }} />
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained"
                   disabled={!form.name || !form.etl_module || !form.etl_class}
                   onClick={onSave}>
            {editing ? 'Save changes' : 'Register stage'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
