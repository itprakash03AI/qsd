/**
 * BF-285 — Global host for the AWS portal password modal.
 *
 * Listens for two trigger sources:
 *
 *   1. The reactive ``portal-password-required`` CustomEvent, dispatched
 *      from any component that received a 401 with detail.type =
 *      "portal_password_required".  The event payload carries an
 *      optional ``retry`` callback so we can re-run the failed query
 *      after the user enters their password.
 *
 *   2. (Optional) preemptive open via the `?awsPasswordPrompt=1` query
 *      string — used when an admin links a user to "please set up your
 *      AWS portal password" without forcing a query failure first.
 *
 * Mounted once at the app level (App.tsx, inside the auth provider),
 * so any feature can dispatch the event without owning the modal
 * lifecycle itself.
 */
import React, { useCallback, useEffect, useState } from 'react';
import PortalPasswordModal from './PortalPasswordModal';
import { useAuth } from '../context/AuthContext';

const PortalPasswordHost: React.FC = () => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState<string | undefined>(undefined);
  // BF-PORTAL-CONN-OVERRIDES: capture the connection_id from the failing
  // query so we can forward it to /api/aws-portal/authenticate.  The
  // backend uses it to resolve THAT connection's portal_base_url /
  // proxy_url / role_name overrides instead of the global defaults.
  const [connectionId, setConnectionId] = useState<number | undefined>(undefined);
  // Hold the retry callback in a ref-like state so it persists between
  // renders and we can fire it after the password modal closes.
  const [pendingRetry, setPendingRetry] = useState<(() => void) | null>(null);

  const handleEvent = useCallback((evt: Event) => {
    const ce = evt as CustomEvent<{ reason?: string; retry?: () => void; connection_id?: number }>;
    const reasonStr = ce?.detail?.reason
      || 'Your AWS credentials need to be refreshed.';
    setReason(reasonStr);
    setConnectionId(typeof ce?.detail?.connection_id === 'number' ? ce.detail.connection_id : undefined);
    setPendingRetry(() => ce?.detail?.retry || null);
    setOpen(true);
  }, []);

  useEffect(() => {
    window.addEventListener('portal-password-required', handleEvent as EventListener);
    return () => window.removeEventListener('portal-password-required', handleEvent as EventListener);
  }, [handleEvent]);

  const handleSuccess = useCallback(() => {
    if (pendingRetry) {
      try { pendingRetry(); } catch { /* swallow — retry is best-effort */ }
    }
    setPendingRetry(null);
  }, [pendingRetry]);

  const handleClose = useCallback(() => {
    setOpen(false);
    setReason(undefined);
    setConnectionId(undefined);
    setPendingRetry(null);
  }, []);

  return (
    <PortalPasswordModal
      open={open}
      username={user?.username}
      reason={reason}
      connectionId={connectionId}
      onClose={handleClose}
      onSuccess={handleSuccess}
    />
  );
};

export default PortalPasswordHost;
