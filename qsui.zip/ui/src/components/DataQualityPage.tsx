/**
 * DataQualityPage — Data Quality Monitoring Dashboard (Phase 99).
 *
 * CRUD for DQ rules (freshness, schema_drift, null_rate, row_count, custom_sql),
 * run checks on demand, view results, acknowledge failures.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Select, MenuItem, FormControl, InputLabel, Chip, Alert,
  CircularProgress, Tooltip, Switch, FormControlLabel, Divider,
  TableContainer, Card, CardContent, Grid,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import WarningIcon from '@mui/icons-material/Warning';
import InfoIcon from '@mui/icons-material/Info';
import RefreshIcon from '@mui/icons-material/Refresh';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import api from '../services/api';

interface DQRule {
  id: number;
  name: string;
  description: string;
  rule_type: string;
  target_type: string;
  target_id: number | null;
  target_table: string | null;
  column_name: string | null;
  config: Record<string, any>;
  schedule_cron: string | null;
  enabled: boolean;
  severity: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface DQResult {
  id: number;
  rule_id: number;
  passed: boolean;
  severity: string;
  metric_value: number | null;
  threshold_value: number | null;
  details: Record<string, any>;
  execution_ms: number;
  checked_at: string;
  acknowledged: boolean;
  acknowledged_by: string | null;
  acknowledged_at: string | null;
}

interface DQSummary {
  total_rules: number;
  passing: number;
  failing: number;
  no_data: number;
  health: string;
}

const RULE_TYPES = [
  { value: 'freshness', label: 'Freshness', desc: 'Check data recency' },
  { value: 'schema_drift', label: 'Schema Drift', desc: 'Detect column changes' },
  { value: 'null_rate', label: 'Null Rate', desc: 'Monitor null percentages' },
  { value: 'row_count', label: 'Row Count', desc: 'Validate row count ranges' },
  { value: 'custom_sql', label: 'Custom SQL', desc: 'Run SQL assertions' },
];

const SEVERITY_ICONS: Record<string, React.ReactNode> = {
  info: <InfoIcon fontSize="small" color="info" />,
  warning: <WarningIcon fontSize="small" color="warning" />,
  critical: <ErrorIcon fontSize="small" color="error" />,
};

const HEALTH_COLORS: Record<string, string> = {
  healthy: '#4caf50',
  degraded: '#ff9800',
  unhealthy: '#f44336',
};

const EMPTY_RULE: Partial<DQRule> = {
  name: '',
  description: '',
  rule_type: 'freshness',
  target_type: 'table',
  target_id: null,
  target_table: '',
  column_name: '',
  config: {},
  schedule_cron: '',
  enabled: true,
  severity: 'warning',
};

export default function DataQualityPage() {
  const [rules, setRules] = useState<DQRule[]>([]);
  const [results, setResults] = useState<DQResult[]>([]);
  const [summary, setSummary] = useState<DQSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editRule, setEditRule] = useState<Partial<DQRule>>(EMPTY_RULE);
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [runningRule, setRunningRule] = useState<number | null>(null);
  const [runningAll, setRunningAll] = useState(false);
  const [selectedRule, setSelectedRule] = useState<number | null>(null);
  const [resultsDialogOpen, setResultsDialogOpen] = useState(false);
  const [ruleResults, setRuleResults] = useState<DQResult[]>([]);
  const [configJson, setConfigJson] = useState('{}');
  const [trendDialogOpen, setTrendDialogOpen] = useState(false);
  const [trendRuleId, setTrendRuleId] = useState<number | null>(null);
  const [trendData, setTrendData] = useState<DQResult[]>([]);
  const [trendLoading, setTrendLoading] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [rulesData, resultsData, summaryData] = await Promise.all([
        api.listDQRules(),
        api.listDQResults({ limit: 50 }),
        api.getDQSummary(),
      ]);
      setRules(rulesData);
      setResults(resultsData);
      setSummary(summaryData);
    } catch (err: any) {
      setError(err.message || 'Failed to load data quality data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const openCreateDialog = () => {
    setEditRule({ ...EMPTY_RULE });
    setConfigJson('{}');
    setEditMode(false);
    setDialogOpen(true);
  };

  const openEditDialog = (rule: DQRule) => {
    setEditRule({ ...rule });
    setConfigJson(JSON.stringify(rule.config || {}, null, 2));
    setEditMode(true);
    setDialogOpen(true);
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      let parsedConfig = {};
      try {
        parsedConfig = JSON.parse(configJson);
      } catch {
        setError('Invalid JSON in config');
        setSaving(false);
        return;
      }

      const data = {
        ...editRule,
        config: parsedConfig,
      };

      if (editMode && editRule.id) {
        await api.updateDQRule(editRule.id, data);
      } else {
        await api.createDQRule(data as any);
      }
      setDialogOpen(false);
      loadData();
    } catch (err: any) {
      setError(err.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (ruleId: number) => {
    if (!window.confirm('Delete this DQ rule? This cannot be undone.')) return;
    try {
      await api.deleteDQRule(ruleId);
      loadData();
    } catch (err: any) {
      setError(err.message || 'Delete failed');
    }
  };

  const handleRunRule = async (ruleId: number) => {
    setRunningRule(ruleId);
    try {
      await api.runDQRule(ruleId);
      loadData();
    } catch (err: any) {
      setError(err.message || 'Run failed');
    } finally {
      setRunningRule(null);
    }
  };

  const handleRunAll = async () => {
    setRunningAll(true);
    try {
      const result = await api.runAllDQRules();
      setError('');
      loadData();
      if (result.failed > 0) {
        setError(`DQ check complete: ${result.failed}/${result.total} rules failed`);
      }
    } catch (err: any) {
      setError(err.message || 'Run all failed');
    } finally {
      setRunningAll(false);
    }
  };

  const handleViewResults = async (ruleId: number) => {
    setSelectedRule(ruleId);
    setResultsDialogOpen(true);
    try {
      const data = await api.listDQResults({ rule_id: ruleId, limit: 20 });
      setRuleResults(data);
    } catch {
      setRuleResults([]);
    }
  };

  const handleAcknowledge = async (resultId: number) => {
    try {
      await api.acknowledgeDQResult(resultId);
      // Refresh results for current rule
      if (selectedRule) {
        const data = await api.listDQResults({ rule_id: selectedRule, limit: 20 });
        setRuleResults(data);
      }
      loadData();
    } catch (err: any) {
      setError(err.message || 'Acknowledge failed');
    }
  };

  const handleViewTrend = async (ruleId: number) => {
    setTrendRuleId(ruleId);
    setTrendDialogOpen(true);
    setTrendLoading(true);
    try {
      const data = await api.getDQRuleTrend(ruleId, 30);
      setTrendData(data);
    } catch {
      setTrendData([]);
    } finally {
      setTrendLoading(false);
    }
  };

  const getLatestResult = (ruleId: number): DQResult | undefined => {
    return results.find(r => r.rule_id === ruleId);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5" fontWeight={600}>Data Quality Monitoring</Typography>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadData}>
            Refresh
          </Button>
          <Button
            variant="outlined"
            color="secondary"
            startIcon={runningAll ? <CircularProgress size={16} /> : <PlayArrowIcon />}
            onClick={handleRunAll}
            disabled={runningAll}
          >
            Run All Checks
          </Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreateDialog}>
            New Rule
          </Button>
        </Box>
      </Box>

      {error && <Alert severity="warning" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Summary Cards */}
      {summary && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="h4" fontWeight={700}>{summary.total_rules}</Typography>
                <Typography variant="body2" color="text.secondary">Total Rules</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="h4" fontWeight={700} color="success.main">{summary.passing}</Typography>
                <Typography variant="body2" color="text.secondary">Passing</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="h4" fontWeight={700} color="error.main">{summary.failing}</Typography>
                <Typography variant="body2" color="text.secondary">Failing</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Chip
                  label={summary.health.toUpperCase()}
                  sx={{
                    bgcolor: HEALTH_COLORS[summary.health] || '#9e9e9e',
                    color: '#fff',
                    fontWeight: 600,
                    fontSize: '1rem',
                    height: 36,
                  }}
                />
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>Health</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Rules Table */}
      <Paper sx={{ overflow: 'hidden' }}>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Target</TableCell>
                <TableCell>Severity</TableCell>
                <TableCell>Enabled</TableCell>
                <TableCell>Last Check</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rules.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                    <Typography color="text.secondary">No DQ rules configured. Click "New Rule" to get started.</Typography>
                  </TableCell>
                </TableRow>
              ) : (
                rules.map(rule => {
                  const latest = getLatestResult(rule.id);
                  return (
                    <TableRow key={rule.id} hover sx={{ cursor: 'pointer' }} onClick={() => handleViewResults(rule.id)}>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>{rule.name}</Typography>
                        {rule.description && (
                          <Typography variant="caption" color="text.secondary">{rule.description}</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip label={rule.rule_type.replace('_', ' ')} size="small" variant="outlined" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{rule.target_table || rule.target_type}</Typography>
                      </TableCell>
                      <TableCell>{SEVERITY_ICONS[rule.severity] || rule.severity}</TableCell>
                      <TableCell>
                        <Chip
                          label={rule.enabled ? 'ON' : 'OFF'}
                          size="small"
                          color={rule.enabled ? 'success' : 'default'}
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        {latest ? (
                          <Typography variant="caption">
                            {new Date(latest.checked_at).toLocaleString()}
                          </Typography>
                        ) : (
                          <Typography variant="caption" color="text.secondary">Never</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {latest ? (
                          latest.passed ? (
                            <Chip icon={<CheckCircleIcon />} label="Pass" size="small" color="success" variant="outlined" />
                          ) : (
                            <Chip icon={<ErrorIcon />} label="Fail" size="small" color="error" variant="outlined" />
                          )
                        ) : (
                          <Chip label="N/A" size="small" variant="outlined" />
                        )}
                      </TableCell>
                      <TableCell align="right" onClick={e => e.stopPropagation()}>
                        <Tooltip title="Trend">
                          <IconButton size="small" onClick={() => handleViewTrend(rule.id)}>
                            <TrendingUpIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Run check">
                          <IconButton
                            size="small"
                            onClick={() => handleRunRule(rule.id)}
                            disabled={runningRule === rule.id}
                          >
                            {runningRule === rule.id ? <CircularProgress size={16} /> : <PlayArrowIcon fontSize="small" />}
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => openEditDialog(rule)}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" color="error" onClick={() => handleDelete(rule.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Create/Edit Rule Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editMode ? 'Edit DQ Rule' : 'Create DQ Rule'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            <TextField
              label="Rule Name"
              value={editRule.name || ''}
              onChange={e => setEditRule(r => ({ ...r, name: e.target.value }))}
              fullWidth
              required
            />
            <TextField
              label="Description"
              value={editRule.description || ''}
              onChange={e => setEditRule(r => ({ ...r, description: e.target.value }))}
              fullWidth
              multiline
              rows={2}
            />
            <FormControl fullWidth>
              <InputLabel>Rule Type</InputLabel>
              <Select
                value={editRule.rule_type || 'freshness'}
                label="Rule Type"
                onChange={e => setEditRule(r => ({ ...r, rule_type: e.target.value }))}
              >
                {RULE_TYPES.map(t => (
                  <MenuItem key={t.value} value={t.value}>{t.label} — {t.desc}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth>
              <InputLabel>Target Type</InputLabel>
              <Select
                value={editRule.target_type || 'table'}
                label="Target Type"
                onChange={e => setEditRule(r => ({ ...r, target_type: e.target.value }))}
              >
                <MenuItem value="table">Table</MenuItem>
                <MenuItem value="connection">Connection</MenuItem>
                <MenuItem value="dataset">Dataset</MenuItem>
                <MenuItem value="query">Query</MenuItem>
              </Select>
            </FormControl>
            <TextField
              label="Target Table"
              value={editRule.target_table || ''}
              onChange={e => setEditRule(r => ({ ...r, target_table: e.target.value }))}
              fullWidth
              helperText="Table or file reference name"
            />
            <TextField
              label="Column Name"
              value={editRule.column_name || ''}
              onChange={e => setEditRule(r => ({ ...r, column_name: e.target.value }))}
              fullWidth
              helperText="For null_rate checks"
            />
            <FormControl fullWidth>
              <InputLabel>Severity</InputLabel>
              <Select
                value={editRule.severity || 'warning'}
                label="Severity"
                onChange={e => setEditRule(r => ({ ...r, severity: e.target.value }))}
              >
                <MenuItem value="info">Info</MenuItem>
                <MenuItem value="warning">Warning</MenuItem>
                <MenuItem value="critical">Critical</MenuItem>
              </Select>
            </FormControl>
            <TextField
              label="Schedule (cron)"
              value={editRule.schedule_cron || ''}
              onChange={e => setEditRule(r => ({ ...r, schedule_cron: e.target.value }))}
              fullWidth
              helperText="Optional cron expression, e.g. 0 */6 * * *"
            />
            <Divider />
            <Typography variant="subtitle2">Rule Config (JSON)</Typography>
            <TextField
              value={configJson}
              onChange={e => setConfigJson(e.target.value)}
              fullWidth
              multiline
              rows={6}
              sx={{ fontFamily: 'monospace' }}
              helperText={
                editRule.rule_type === 'freshness' ? 'Keys: connection_id, table_name, check_column, max_age_hours' :
                editRule.rule_type === 'schema_drift' ? 'Keys: connection_id, table_name, expected_columns[], strict' :
                editRule.rule_type === 'null_rate' ? 'Keys: connection_id, table_name, column_name, max_null_pct, sample_limit' :
                editRule.rule_type === 'row_count' ? 'Keys: connection_id, table_name, min_rows, max_rows, deviation_pct' :
                editRule.rule_type === 'custom_sql' ? 'Keys: connection_id, sql, expected_value' :
                'Rule-specific configuration'
              }
            />
            <FormControlLabel
              control={
                <Switch
                  checked={editRule.enabled !== false}
                  onChange={e => setEditRule(r => ({ ...r, enabled: e.target.checked }))}
                />
              }
              label="Enabled"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleSave}
            disabled={saving || !editRule.name}
          >
            {saving ? <CircularProgress size={20} /> : (editMode ? 'Update' : 'Create')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Trend Dialog (Phase 114-F) */}
      <Dialog open={trendDialogOpen} onClose={() => setTrendDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          Trend — {rules.find(r => r.id === trendRuleId)?.name || `Rule #${trendRuleId}`}
        </DialogTitle>
        <DialogContent>
          {trendLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress /></Box>
          ) : trendData.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
              No trend data yet. Run the check to generate results.
            </Typography>
          ) : (() => {
            const W = 600, H = 200, PAD = 40;
            const vals = trendData.map(d => d.metric_value ?? 0);
            const minV = Math.min(...vals);
            const maxV = Math.max(...vals);
            const range = maxV - minV || 1;
            const xStep = trendData.length > 1 ? (W - PAD * 2) / (trendData.length - 1) : 0;
            const toX = (i: number) => PAD + i * xStep;
            const toY = (v: number) => H - PAD - ((v - minV) / range) * (H - PAD * 2);
            const linePts = trendData.map((d, i) => `${toX(i)},${toY(d.metric_value ?? 0)}`).join(' ');
            // Threshold line (use first result's threshold if available)
            const thr = trendData.find(d => d.threshold_value != null)?.threshold_value;
            return (
              <Box sx={{ overflowX: 'auto' }}>
                <svg width={W} height={H} style={{ display: 'block', margin: '0 auto' }}>
                  {/* Y axis labels */}
                  <text x={PAD - 4} y={PAD} textAnchor="end" fontSize={10} fill="#666">{maxV.toFixed(1)}</text>
                  <text x={PAD - 4} y={H - PAD} textAnchor="end" fontSize={10} fill="#666">{minV.toFixed(1)}</text>
                  {/* Grid lines */}
                  <line x1={PAD} y1={PAD} x2={W - PAD} y2={PAD} stroke="#eee" />
                  <line x1={PAD} y1={H - PAD} x2={W - PAD} y2={H - PAD} stroke="#eee" />
                  {/* Threshold line */}
                  {thr != null && (
                    <line x1={PAD} y1={toY(thr)} x2={W - PAD} y2={toY(thr)} stroke="#ff9800" strokeDasharray="6 3" strokeWidth={1.5} />
                  )}
                  {/* Metric line */}
                  <polyline points={linePts} fill="none" stroke="#1976d2" strokeWidth={2} />
                  {/* Dots — pass=green, fail=red */}
                  {trendData.map((d, i) => (
                    <circle key={i} cx={toX(i)} cy={toY(d.metric_value ?? 0)} r={4}
                      fill={d.passed ? '#4caf50' : '#f44336'} stroke="#fff" strokeWidth={1} />
                  ))}
                  {/* X axis labels (first + last date) */}
                  <text x={PAD} y={H - 8} textAnchor="start" fontSize={9} fill="#999">
                    {new Date(trendData[0].checked_at).toLocaleDateString()}
                  </text>
                  <text x={W - PAD} y={H - 8} textAnchor="end" fontSize={9} fill="#999">
                    {new Date(trendData[trendData.length - 1].checked_at).toLocaleDateString()}
                  </text>
                </svg>
                {thr != null && (
                  <Typography variant="caption" color="text.secondary" sx={{ textAlign: 'center', display: 'block', mt: 0.5 }}>
                    Orange dashed line = threshold ({thr})
                  </Typography>
                )}
              </Box>
            );
          })()}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTrendDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Results History Dialog */}
      <Dialog open={resultsDialogOpen} onClose={() => setResultsDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          Check Results — {rules.find(r => r.id === selectedRule)?.name || `Rule #${selectedRule}`}
        </DialogTitle>
        <DialogContent>
          {ruleResults.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
              No results yet. Run the check to generate results.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Checked At</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Metric</TableCell>
                    <TableCell>Threshold</TableCell>
                    <TableCell>Duration</TableCell>
                    <TableCell>Acknowledged</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {ruleResults.map(r => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <Typography variant="caption">{new Date(r.checked_at).toLocaleString()}</Typography>
                      </TableCell>
                      <TableCell>
                        {r.passed ? (
                          <Chip icon={<CheckCircleIcon />} label="Pass" size="small" color="success" variant="outlined" />
                        ) : (
                          <Chip icon={<ErrorIcon />} label="Fail" size="small" color="error" variant="outlined" />
                        )}
                      </TableCell>
                      <TableCell>{r.metric_value != null ? r.metric_value.toFixed(2) : '—'}</TableCell>
                      <TableCell>{r.threshold_value != null ? r.threshold_value.toFixed(2) : '—'}</TableCell>
                      <TableCell>{r.execution_ms}ms</TableCell>
                      <TableCell>
                        {r.acknowledged ? (
                          <Tooltip title={`By ${r.acknowledged_by} at ${r.acknowledged_at}`}>
                            <Chip icon={<ThumbUpIcon />} label="ACK" size="small" color="info" variant="outlined" />
                          </Tooltip>
                        ) : (
                          <Typography variant="caption" color="text.secondary">—</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {!r.passed && !r.acknowledged && (
                          <Tooltip title="Acknowledge failure">
                            <IconButton size="small" onClick={() => handleAcknowledge(r.id)}>
                              <ThumbUpIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setResultsDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
