/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowVariablesPage — CRUD for project variables (Phase 132.22).
 *
 * Global vs per-DataFlow scope.  Secrets are stored encrypted and never
 * displayed in plaintext after creation.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControlLabel, IconButton, MenuItem,
  Paper, Select, Stack, Switch, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Refresh as RefreshIcon, Lock as LockIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { DataFlowDef } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

export default function DataFlowVariablesPage() {
  const [vars, setVars] = useState<any[]>([]);
  const [dataflows, setDataflows] = useState<DataFlowDef[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [scopeFilter, setScopeFilter] = useState<'all' | 'global' | 'per_dag'>('all');

  const blank = {
    name: '', value: '', dataflow_id: '' as string | number,
    description: '', is_secret: false,
  };
  const [form, setForm] = useState<any>(blank);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [v, w] = await Promise.all([
        api.dataflows.listVariables(),
        api.dataflows.listDataFlows(),
      ]);
      setVars(toArray(v));
      setDataflows(toArray<DataFlowDef>(w));
    } catch (e: any) {
      setError(e?.message || 'Failed to load variables');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = vars.filter(v => {
    if (scopeFilter === 'global') return v.dataflow_id == null;
    if (scopeFilter === 'per_dag') return v.dataflow_id != null;
    return true;
  });

  const openCreate = () => { setEditingId(null); setForm(blank); setDialogOpen(true); };

  const openEdit = (v: any) => {
    setEditingId(v.id);
    setForm({
      name: v.name,
      value: v.is_secret ? '' : (v.value ?? ''),
      dataflow_id: v.dataflow_id ?? '',
      description: v.description ?? '',
      is_secret: v.is_secret,
    });
    setDialogOpen(true);
  };

  const onSave = async () => {
    // Editing a secret + leaving the value blank means "keep the existing".
    // We send value: null in that case so the backend doesn't overwrite
    // the encrypted blob with an empty string.
    const isEditingSecretUnchanged =
      editingId && form.is_secret && (form.value ?? '') === '';
    const body: any = {
      name: form.name,
      value: isEditingSecretUnchanged ? null : form.value,
      dataflow_id: form.dataflow_id === '' ? null : Number(form.dataflow_id),
      description: form.description,
      is_secret: form.is_secret,
    };
    // On create, value is required
    if (!editingId && (form.value ?? '') === '') {
      setError('Value is required'); return;
    }
    try {
      if (editingId) await api.dataflows.updateVariable(editingId, body);
      else await api.dataflows.createVariable(body);
      setDialogOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    }
  };

  const onDelete = async (id: number, name: string) => {
    if (!window.confirm(`Delete variable "${name}"?`)) return;
    try { await api.dataflows.deleteVariable(id); await load(); }
    catch (e: any) { setError(e?.message || 'Delete failed'); }
  };

  const nameOf = (id: number | null) =>
    id == null ? '— (global)' : (dataflows.find(d => d.id === id)?.name || `#${id}`);

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">Project Variables</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<AddIcon />} variant="contained" onClick={openCreate}>New Variable</Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Reference variables in stage configs as <code>&#123;var.name&#125;</code>.
        Per-DataFlow scope overrides global with the same name.
        Secrets are encrypted at rest and never returned in plaintext.
      </Typography>

      <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
        <Select size="small" value={scopeFilter} onChange={e => setScopeFilter(e.target.value as any)} sx={{ minWidth: 180 }}>
          <MenuItem value="all">All</MenuItem>
          <MenuItem value="global">Global only</MenuItem>
          <MenuItem value="per_dag">Per-DataFlow only</MenuItem>
        </Select>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Value</TableCell>
              <TableCell>Scope</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Updated</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && <TableRow><TableCell colSpan={6} align="center"><CircularProgress size={20} /></TableCell></TableRow>}
            {!loading && filtered.length === 0 && (
              <TableRow><TableCell colSpan={6} align="center">
                <Typography variant="body2" color="text.secondary">No variables yet.</Typography>
              </TableCell></TableRow>
            )}
            {filtered.map(v => (
              <TableRow key={v.id} hover>
                <TableCell>
                  <Stack direction="row" spacing={0.5} alignItems="center">
                    <code>{v.name}</code>
                    {v.is_secret && <LockIcon fontSize="small" color="warning" />}
                  </Stack>
                </TableCell>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12,
                  maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {v.is_secret ? '****' : (v.value ?? '')}
                </TableCell>
                <TableCell>
                  <Chip label={nameOf(v.dataflow_id)} size="small" variant="outlined" sx={{ fontSize: 10 }} />
                </TableCell>
                <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>{v.description ?? ''}</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{v.updated_at?.slice(0, 16).replace('T', ' ')}</TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => openEdit(v)}><EditIcon fontSize="small" /></IconButton>
                  <IconButton size="small" onClick={() => onDelete(v.id, v.name)}><DeleteIcon fontSize="small" /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingId ? 'Edit' : 'New'} Variable</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" size="small" fullWidth value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              helperText="Letters/digits/underscore only. Reference as {var.name} in stage configs." />
            <TextField
              label={form.is_secret
                ? (editingId ? 'Secret value (blank = keep existing)' : 'Secret value (will be encrypted)')
                : 'Value'}
              size="small" fullWidth value={form.value}
              type={form.is_secret ? 'password' : 'text'}
              helperText={editingId && form.is_secret
                ? 'Leave blank to keep the existing encrypted value. Type a new value to replace.'
                : undefined}
              onChange={e => setForm({ ...form, value: e.target.value })} />
            <Select size="small" fullWidth displayEmpty value={form.dataflow_id}
              onChange={e => setForm({ ...form, dataflow_id: e.target.value })}>
              <MenuItem value="">— (global)</MenuItem>
              {dataflows.map(d => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
            </Select>
            <TextField label="Description (optional)" size="small" fullWidth multiline minRows={2}
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })} />
            <FormControlLabel control={<Switch checked={form.is_secret}
              onChange={e => setForm({ ...form, is_secret: e.target.checked })} />}
              label="Encrypt as secret (never shown in plaintext)" />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={onSave} disabled={!form.name}>
            {editingId ? 'Save' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
