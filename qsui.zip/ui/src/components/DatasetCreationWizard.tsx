/**
 * Phase 85A — Dataset Creation Wizard
 *
 * A 5-step stepper dialog for creating business datasets with column selection,
 * preview, metadata enrichment, and optional join configuration.
 *
 * Steps:
 *  1. Basic Info — Name, Subject, Description, Owner
 *  2. Source     — Connection + table/file selector OR custom SQL + 10-row preview
 *  3. Columns    — Checkbox column list with editable friendly name, type, aggregation
 *  4. Joins      — Optional secondary source + join key pickers
 *  5. Review     — Summary + final preview + Create button
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Stepper,
  Step, StepLabel, TextField, Box, Typography, FormControl, InputLabel,
  Select, MenuItem, Checkbox, Table, TableHead, TableRow, TableCell,
  TableBody, CircularProgress, Alert, Chip, Tooltip, IconButton,
  Stack, Divider, Paper,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  PlayArrow as PreviewIcon,
  SkipNext as SkipIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

// ── Constants ────────────────────────────────────────────────────────────────

const STEPS = ['Basic Info', 'Source', 'Columns', 'Joins (Optional)', 'Review & Create'];

const COLUMN_TYPES = ['dimension', 'measure', 'detail', 'kpi'] as const;
type ColumnType = typeof COLUMN_TYPES[number];

const AGGREGATIONS = ['', 'sum', 'avg', 'count', 'min', 'max', 'count_distinct'] as const;

const JOIN_TYPES = ['inner', 'left', 'right', 'full'] as const;

const DATA_TYPE_COLORS: Record<string, string> = {
  string: '#1976d2',
  number: '#388e3c',
  date: '#f57c00',
  boolean: '#7b1fa2',
};

// ── Interfaces ────────────────────────────────────────────────────────────────

interface WizardColumn {
  physical_name: string;
  friendly_name: string;
  column_type: ColumnType;
  data_type: string;
  aggregation: string;
  selected: boolean;
}

interface JoinConfig {
  connection_id: number | '';
  table_name: string;
  join_type: string;
  left_key: string;
  right_key: string;
}

interface PreviewResult {
  columns: string[];
  rows: Record<string, any>[];
}

interface DatasetCreationWizardProps {
  open: boolean;
  onClose: () => void;
  onCreated: (dataset: any) => void;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function inferDataType(colName: string, dbType: string): string {
  const lt = (dbType || '').toLowerCase();
  const ln = (colName || '').toLowerCase();
  if (/int|bigint|smallint|tinyint|numeric|decimal|float|double|real|number/.test(lt)) return 'number';
  if (/date|time|timestamp/.test(lt)) return 'date';
  if (/bool/.test(lt)) return 'boolean';
  // Name-based fallback
  if (/date|_at$|_on$|timestamp/.test(ln)) return 'date';
  if (/id$|count$|amount$|price$|qty$|quantity$|total$|revenue$/.test(ln)) return 'number';
  return 'string';
}

function inferColumnType(colName: string, dataType: string): ColumnType {
  const ln = colName.toLowerCase();
  if (dataType === 'number') {
    if (/id$|_id$/.test(ln)) return 'dimension';
    return 'measure';
  }
  if (dataType === 'date') return 'detail';
  return 'dimension';
}

function inferAggregation(colType: ColumnType): string {
  if (colType === 'measure') return 'sum';
  return '';
}

// ── Mini Preview Table ────────────────────────────────────────────────────────

const PreviewTable: React.FC<{ result: PreviewResult | null; loading: boolean; error: string }> = ({
  result, loading, error,
}) => {
  if (loading) return <Box sx={{ py: 2, textAlign: 'center' }}><CircularProgress size={24} /></Box>;
  if (error) return <Alert severity="warning" sx={{ mt: 1 }}>{error}</Alert>;
  if (!result) return null;
  return (
    <Box sx={{ overflowX: 'auto', mt: 1 }}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {result.columns.map(col => (
              <TableCell key={col} sx={{ fontWeight: 700, whiteSpace: 'nowrap', fontSize: 11 }}>{col}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {result.rows.slice(0, 10).map((row, idx) => (
            <TableRow key={idx}>
              {result.columns.map(col => (
                <TableCell key={col} sx={{ fontSize: 11, whiteSpace: 'nowrap' }}>
                  {row[col] === null || row[col] === undefined ? (
                    <span style={{ color: '#aaa' }}>null</span>
                  ) : String(row[col]).substring(0, 60)}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
        Preview (first {Math.min(result.rows.length, 10)} rows — table may contain more data)
      </Typography>
    </Box>
  );
};

// ── Main Component ────────────────────────────────────────────────────────────

const DatasetCreationWizard: React.FC<DatasetCreationWizardProps> = ({ open, onClose, onCreated }) => {
  const { user } = useAuth();

  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [globalError, setGlobalError] = useState('');

  // ── Step 1: Basic Info ───────────────────────────────────────────────────
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [owner, setOwner] = useState(user?.username || '');

  // ── Step 2: Source ───────────────────────────────────────────────────────
  const [connections, setConnections] = useState<any[]>([]);
  const [connectionsLoading, setConnectionsLoading] = useState(false);
  const [sourceMode, setSourceMode] = useState<'table' | 'sql'>('table');
  const [sourceConnectionId, setSourceConnectionId] = useState<number | ''>('');
  const [registeredTables, setRegisteredTables] = useState<any[]>([]);
  const [tablesLoading, setTablesLoading] = useState(false);
  const [selectedTable, setSelectedTable] = useState('');
  const [customSql, setCustomSql] = useState('');
  const [previewResult, setPreviewResult] = useState<PreviewResult | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState('');

  // ── Step 3: Columns ──────────────────────────────────────────────────────
  const [columns, setColumns] = useState<WizardColumn[]>([]);
  const [columnsLoading, setColumnsLoading] = useState(false);

  // ── Step 4: Joins ────────────────────────────────────────────────────────
  const [joins, setJoins] = useState<JoinConfig[]>([]);
  const [joinTables, setJoinTables] = useState<Record<number, any[]>>({});

  // ── Reset on open/close ───────────────────────────────────────────────────
  useEffect(() => {
    if (!open) return;
    setStep(0);
    setName('');
    setSubject('');
    setDescription('');
    setOwner(user?.username || '');
    setSourceMode('table');
    setSourceConnectionId('');
    setRegisteredTables([]);
    setSelectedTable('');
    setCustomSql('');
    setPreviewResult(null);
    setPreviewError('');
    setColumns([]);
    setJoins([]);
    setGlobalError('');
  }, [open, user?.username]);

  // ── Load connections on open ──────────────────────────────────────────────
  useEffect(() => {
    if (!open) return;
    setConnectionsLoading(true);
    api.listConnections(true)
      .then((data: any[]) => setConnections(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setConnectionsLoading(false));
  }, [open]);

  // ── Load registered tables when connection changes ────────────────────────
  useEffect(() => {
    if (!sourceConnectionId) { setRegisteredTables([]); setSelectedTable(''); return; }
    setTablesLoading(true);
    setSelectedTable('');
    setPreviewResult(null);
    api.listRegisteredTables(String(sourceConnectionId))
      .then((data: any) => {
        const tables = Array.isArray(data) ? data : (data?.tables || []);
        setRegisteredTables(tables);
      })
      .catch(() => setRegisteredTables([]))
      .finally(() => setTablesLoading(false));
  }, [sourceConnectionId]);

  // ── Preview source data ───────────────────────────────────────────────────
  const handlePreview = useCallback(async () => {
    if (!sourceConnectionId) return;
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewResult(null);
    try {
      let sql = '';
      if (sourceMode === 'sql' && customSql.trim()) {
        sql = `SELECT * FROM (${customSql.trim()}) __preview__ LIMIT 10`;
      } else if (selectedTable) {
        const tableName = selectedTable.startsWith('__registered__:')
          ? selectedTable.replace('__registered__:', '')
          : selectedTable;
        sql = `SELECT * FROM "${tableName}" LIMIT 10`;
      } else {
        setPreviewError('Select a table or enter SQL first');
        setPreviewLoading(false);
        return;
      }
      // Use dataset preview endpoint if available, otherwise fall back to execute
      const res = await api.previewDatasetSource({
        connection_id: Number(sourceConnectionId),
        sql,
        limit: 10,
      });
      setPreviewResult({ columns: res.columns || [], rows: res.rows || [] });
    } catch (e: any) {
      setPreviewError(e.message || 'Preview failed');
    } finally {
      setPreviewLoading(false);
    }
  }, [sourceConnectionId, sourceMode, customSql, selectedTable]);

  // ── Load columns from selected table ─────────────────────────────────────
  const loadColumnsFromTable = useCallback(async () => {
    if (!sourceConnectionId || (!selectedTable && sourceMode === 'table')) return;
    setColumnsLoading(true);
    try {
      let schemaData: any[] = [];
      if (sourceMode === 'table' && selectedTable) {
        const tableName = selectedTable.startsWith('__registered__:')
          ? selectedTable.replace('__registered__:', '')
          : selectedTable;
        try {
          const res = await api.getRegisteredTableSchema(String(sourceConnectionId), tableName);
          schemaData = Array.isArray(res) ? res : (res?.columns || res?.schema || []);
        } catch {
          // If schema endpoint fails, try preview-columns
          const res2 = await api.previewDatasetColumns(Number(sourceConnectionId), tableName);
          schemaData = res2?.columns || [];
        }
      } else if (sourceMode === 'sql' && customSql.trim()) {
        // Use preview-columns via a small SQL execution
        try {
          const res = await api.previewDatasetSource({
            connection_id: Number(sourceConnectionId),
            sql: `SELECT * FROM (${customSql.trim()}) __preview__ LIMIT 1`,
            limit: 1,
          });
          // Convert column names to schema-like objects
          schemaData = (res.columns || []).map((col: string) => ({ name: col, type: 'string' }));
        } catch {
          schemaData = [];
        }
      }

      // Build wizard columns
      const wizardCols: WizardColumn[] = schemaData.map((col: any, idx: number) => {
        const physName = col.physical_name || col.name || col.column_name || String(idx);
        const dbType = col.data_type || col.type || col.dtype || '';
        const dataType = inferDataType(physName, dbType);
        const colType = inferColumnType(physName, dataType);
        return {
          physical_name: physName,
          friendly_name: col.friendly_name || physName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
          column_type: colType,
          data_type: dataType,
          aggregation: inferAggregation(colType),
          selected: !col.is_hidden,
        };
      });
      setColumns(wizardCols);
    } catch (e: any) {
      setColumns([]);
    } finally {
      setColumnsLoading(false);
    }
  }, [sourceConnectionId, sourceMode, selectedTable, customSql]);

  // ── Step navigation ───────────────────────────────────────────────────────
  const handleNext = () => {
    if (step === 0) {
      // Validate basic info
      if (!name.trim() || !subject.trim()) {
        setGlobalError('Name and Subject are required');
        return;
      }
      setGlobalError('');
    }
    if (step === 1) {
      // Validate source
      if (!sourceConnectionId) {
        setGlobalError('Select a connection');
        return;
      }
      if (sourceMode === 'table' && !selectedTable) {
        setGlobalError('Select a table');
        return;
      }
      if (sourceMode === 'sql' && !customSql.trim()) {
        setGlobalError('Enter custom SQL');
        return;
      }
      setGlobalError('');
      // Auto-load columns for step 3
      loadColumnsFromTable();
    }
    setStep(s => s + 1);
  };

  const handleBack = () => {
    setGlobalError('');
    setStep(s => s - 1);
  };

  // ── Column updates ────────────────────────────────────────────────────────
  const updateColumn = (idx: number, field: keyof WizardColumn, value: any) => {
    setColumns(prev => prev.map((col, i) => {
      if (i !== idx) return col;
      const updated = { ...col, [field]: value };
      // Auto-set aggregation when type changes to measure
      if (field === 'column_type') {
        updated.aggregation = inferAggregation(value as ColumnType);
      }
      return updated;
    }));
  };

  const toggleAllColumns = (checked: boolean) => {
    setColumns(prev => prev.map(col => ({ ...col, selected: checked })));
  };

  // ── Join management ───────────────────────────────────────────────────────
  const addJoin = () => {
    setJoins(prev => [...prev, {
      connection_id: '',
      table_name: '',
      join_type: 'inner',
      left_key: '',
      right_key: '',
    }]);
  };

  const removeJoin = (idx: number) => {
    setJoins(prev => prev.filter((_, i) => i !== idx));
  };

  const updateJoin = (idx: number, field: keyof JoinConfig, value: any) => {
    setJoins(prev => prev.map((j, i) => i !== idx ? j : { ...j, [field]: value }));
    // Load tables for the join connection
    if (field === 'connection_id' && value) {
      api.listRegisteredTables(String(value))
        .then((data: any) => {
          const tables = Array.isArray(data) ? data : (data?.tables || []);
          setJoinTables(prev => ({ ...prev, [value as number]: tables }));
        })
        .catch(() => {});
    }
  };

  // ── Create dataset ────────────────────────────────────────────────────────
  const handleCreate = async () => {
    setSaving(true);
    setGlobalError('');
    try {
      const tableName = sourceMode === 'table' && selectedTable
        ? (selectedTable.startsWith('__registered__:')
            ? selectedTable.replace('__registered__:', '')
            : selectedTable)
        : '';

      // Build source_tables
      const sourceTables: any[] = [];
      if (sourceConnectionId && tableName) {
        sourceTables.push({
          connection_id: Number(sourceConnectionId),
          table: tableName,
          alias: 't1',
        });
      }

      // Build relationships from joins
      const relationships: any[] = joins
        .filter(j => j.connection_id && j.table_name && j.left_key && j.right_key)
        .map((j, idx) => ({
          left_table: tableName || 'main',
          right_table: j.table_name,
          join_keys: [{ left: j.left_key, right: j.right_key }],
          join_type: j.join_type,
          cardinality: 'many_to_one',
        }));

      // Create the dataset
      const dataset = await api.createDataset({
        name: name.trim(),
        subject: subject.trim(),
        description: description.trim(),
        connection_ids: sourceConnectionId ? [Number(sourceConnectionId)] : [],
        source_tables: sourceTables,
        base_query: sourceMode === 'sql' ? customSql.trim() : '',
        is_published: false,
      });

      const datasetId = dataset.id;

      // Bulk-create selected columns
      const selectedCols = columns.filter(c => c.selected);
      if (selectedCols.length > 0) {
        await api.bulkCreateDatasetColumns(datasetId, selectedCols.map((col, idx) => ({
          physical_name: col.physical_name,
          friendly_name: col.friendly_name,
          column_type: col.column_type,
          data_type: col.data_type,
          aggregation: col.aggregation || '',
          sort_order: idx,
          is_hidden: false,
        })));
      }

      // Create relationships
      for (const rel of relationships) {
        try {
          await api.createDatasetRelationship(datasetId, rel);
        } catch { /* ignore */ }
      }

      onCreated(dataset);
      onClose();
    } catch (e: any) {
      setGlobalError(e.message || 'Failed to create dataset');
    } finally {
      setSaving(false);
    }
  };

  // ── Step content renderers ────────────────────────────────────────────────

  const renderStep1 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      <TextField
        label="Dataset Name *"
        value={name}
        onChange={e => setName(e.target.value)}
        fullWidth size="small"
        placeholder="e.g., Sales Analytics"
        error={!!globalError && !name.trim()}
      />
      <TextField
        label="Subject / Domain *"
        value={subject}
        onChange={e => setSubject(e.target.value)}
        fullWidth size="small"
        placeholder="e.g., Finance, Sales, HR"
        error={!!globalError && !subject.trim()}
        helperText="Used to group datasets in the Business Portal"
      />
      <TextField
        label="Description"
        value={description}
        onChange={e => setDescription(e.target.value)}
        fullWidth size="small" multiline rows={3}
        placeholder="Describe what data this dataset contains and its purpose"
      />
      <TextField
        label="Owner"
        value={owner}
        onChange={e => setOwner(e.target.value)}
        fullWidth size="small"
        placeholder="username or team name"
      />
    </Stack>
  );

  const renderStep2 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      {/* Source mode toggle */}
      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button
          variant={sourceMode === 'table' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => { setSourceMode('table'); setPreviewResult(null); }}
        >
          Table / File
        </Button>
        <Button
          variant={sourceMode === 'sql' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => { setSourceMode('sql'); setPreviewResult(null); }}
        >
          Custom SQL
        </Button>
      </Box>

      {/* Connection selector */}
      <FormControl fullWidth size="small">
        <InputLabel>Connection *</InputLabel>
        <Select
          value={sourceConnectionId}
          label="Connection *"
          onChange={e => setSourceConnectionId(e.target.value as number)}
          disabled={connectionsLoading}
        >
          <MenuItem value="">— Select Connection —</MenuItem>
          {connections.map(c => (
            <MenuItem key={c.id} value={c.id}>
              {c.name} ({c.connection_type})
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Table selector */}
      {sourceMode === 'table' && sourceConnectionId && (
        <FormControl fullWidth size="small">
          <InputLabel>Table / File *</InputLabel>
          <Select
            value={selectedTable}
            label="Table / File *"
            onChange={e => { setSelectedTable(e.target.value); setPreviewResult(null); }}
            disabled={tablesLoading}
            endAdornment={tablesLoading ? <CircularProgress size={16} sx={{ mr: 2 }} /> : null}
          >
            <MenuItem value="">— Select Table —</MenuItem>
            {registeredTables.map((t: any) => {
              const key = `__registered__:${t.name || t.table_name}`;
              const label = t.name || t.table_name;
              return (
                <MenuItem key={key} value={key}>
                  {label}
                  {t.description && (
                    <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      {t.description}
                    </Typography>
                  )}
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      )}

      {/* Custom SQL editor */}
      {sourceMode === 'sql' && (
        <TextField
          label="SQL Query"
          value={customSql}
          onChange={e => setCustomSql(e.target.value)}
          fullWidth
          multiline
          rows={6}
          size="small"
          placeholder="SELECT * FROM my_table WHERE ..."
          InputProps={{ sx: { fontFamily: 'monospace', fontSize: 13 } }}
        />
      )}

      {/* Preview button */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Button
          variant="outlined"
          size="small"
          startIcon={previewLoading ? <CircularProgress size={14} /> : <PreviewIcon />}
          onClick={handlePreview}
          disabled={previewLoading || !sourceConnectionId || (sourceMode === 'table' && !selectedTable) || (sourceMode === 'sql' && !customSql.trim())}
        >
          Preview (10 rows)
        </Button>
        {previewResult && (
          <Chip size="small" color="success" label={`${previewResult.columns.length} columns, ${previewResult.rows.length} rows`} />
        )}
      </Box>

      <PreviewTable result={previewResult} loading={false} error={previewError} />
    </Stack>
  );

  const renderStep3 = () => (
    <Box>
      {columnsLoading ? (
        <Box sx={{ py: 3, textAlign: 'center' }}><CircularProgress /></Box>
      ) : columns.length === 0 ? (
        <Alert severity="info">
          No columns loaded. Go back and select a table or enter SQL, then come back.
        </Alert>
      ) : (
        <>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              {columns.filter(c => c.selected).length} of {columns.length} columns selected
            </Typography>
            <Button size="small" onClick={() => toggleAllColumns(true)}>Select All</Button>
            <Button size="small" onClick={() => toggleAllColumns(false)}>Deselect All</Button>
          </Box>
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell padding="checkbox" sx={{ bgcolor: 'grey.50' }}>
                    <Checkbox
                      size="small"
                      indeterminate={columns.some(c => c.selected) && !columns.every(c => c.selected)}
                      checked={columns.every(c => c.selected)}
                      onChange={e => toggleAllColumns(e.target.checked)}
                    />
                  </TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Column</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Friendly Name</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Type</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Aggregation</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {columns.map((col, idx) => (
                  <TableRow key={col.physical_name} hover sx={{ opacity: col.selected ? 1 : 0.5 }}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        size="small"
                        checked={col.selected}
                        onChange={e => updateColumn(idx, 'selected', e.target.checked)}
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Typography sx={{ fontFamily: 'monospace', fontSize: 12 }}>{col.physical_name}</Typography>
                        <Chip
                          label={col.data_type}
                          size="small"
                          sx={{
                            height: 16,
                            fontSize: 9,
                            bgcolor: DATA_TYPE_COLORS[col.data_type] || '#757575',
                            color: '#fff',
                            '& .MuiChip-label': { px: 0.5 },
                          }}
                        />
                      </Box>
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        value={col.friendly_name}
                        onChange={e => updateColumn(idx, 'friendly_name', e.target.value)}
                        sx={{ minWidth: 160 }}
                        inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      />
                    </TableCell>
                    <TableCell>
                      <FormControl size="small" sx={{ minWidth: 110 }}>
                        <Select
                          value={col.column_type}
                          onChange={e => updateColumn(idx, 'column_type', e.target.value)}
                          sx={{ fontSize: 12 }}
                        >
                          {COLUMN_TYPES.map(t => (
                            <MenuItem key={t} value={t} sx={{ fontSize: 12 }}>{t}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </TableCell>
                    <TableCell>
                      <FormControl size="small" sx={{ minWidth: 100 }}>
                        <Select
                          value={col.aggregation}
                          onChange={e => updateColumn(idx, 'aggregation', e.target.value)}
                          disabled={col.column_type !== 'measure'}
                          sx={{ fontSize: 12 }}
                        >
                          {AGGREGATIONS.map(a => (
                            <MenuItem key={a || 'none'} value={a} sx={{ fontSize: 12 }}>
                              {a || 'NONE'}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </>
      )}
    </Box>
  );

  const renderStep4 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      <Alert severity="info" sx={{ mb: 1 }}>
        Joins are optional. They link this dataset to another source on a matching key column.
        You can also add relationships later from the Dataset Manager.
      </Alert>

      {joins.map((join, idx) => (
        <Paper key={idx} variant="outlined" sx={{ p: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
            <Typography variant="subtitle2">Join #{idx + 1}</Typography>
            <IconButton size="small" color="error" onClick={() => removeJoin(idx)}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Box>
          <Stack spacing={1.5}>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <FormControl size="small" sx={{ flex: 1 }}>
                <InputLabel>Connection</InputLabel>
                <Select
                  value={join.connection_id}
                  label="Connection"
                  onChange={e => updateJoin(idx, 'connection_id', e.target.value)}
                >
                  <MenuItem value="">— Select —</MenuItem>
                  {connections.map(c => (
                    <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ minWidth: 100 }}>
                <InputLabel>Join Type</InputLabel>
                <Select
                  value={join.join_type}
                  label="Join Type"
                  onChange={e => updateJoin(idx, 'join_type', e.target.value)}
                >
                  {JOIN_TYPES.map(t => (
                    <MenuItem key={t} value={t}>{t.toUpperCase()}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            <FormControl fullWidth size="small">
              <InputLabel>Secondary Table</InputLabel>
              <Select
                value={join.table_name}
                label="Secondary Table"
                onChange={e => updateJoin(idx, 'table_name', e.target.value)}
                disabled={!join.connection_id}
              >
                <MenuItem value="">— Select Table —</MenuItem>
                {(joinTables[join.connection_id as number] || []).map((t: any) => (
                  <MenuItem key={t.name} value={t.name}>{t.name}</MenuItem>
                ))}
              </Select>
            </FormControl>

            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField
                size="small"
                label="Primary Key Column"
                value={join.left_key}
                onChange={e => updateJoin(idx, 'left_key', e.target.value)}
                sx={{ flex: 1 }}
                placeholder="e.g., customer_id"
              />
              <Typography variant="body2" color="text.secondary">=</Typography>
              <TextField
                size="small"
                label="Secondary Key Column"
                value={join.right_key}
                onChange={e => updateJoin(idx, 'right_key', e.target.value)}
                sx={{ flex: 1 }}
                placeholder="e.g., id"
              />
            </Box>
          </Stack>
        </Paper>
      ))}

      <Button
        variant="outlined"
        startIcon={<AddIcon />}
        onClick={addJoin}
        size="small"
        sx={{ alignSelf: 'flex-start' }}
      >
        Add Secondary Source
      </Button>
    </Stack>
  );

  const renderStep5 = () => {
    const selectedCols = columns.filter(c => c.selected);
    const dimensions = selectedCols.filter(c => c.column_type === 'dimension').length;
    const measures = selectedCols.filter(c => c.column_type === 'measure').length;
    const details = selectedCols.filter(c => ['detail', 'kpi'].includes(c.column_type)).length;
    const validJoins = joins.filter(j => j.connection_id && j.table_name && j.left_key && j.right_key);

    return (
      <Stack spacing={2} sx={{ mt: 1 }}>
        <Alert severity="success">
          Ready to create your dataset. Review the summary below, then click Create.
        </Alert>

        {/* Summary cards */}
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1.5 }}>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Source</Typography>
            <Typography variant="body2" fontWeight={600}>
              {connections.find(c => c.id === sourceConnectionId)?.name || '—'}
            </Typography>
            <Typography variant="caption">
              {sourceMode === 'sql' ? 'Custom SQL' : (
                selectedTable.replace('__registered__:', '')
              )}
            </Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Columns</Typography>
            <Typography variant="body2" fontWeight={600}>{selectedCols.length} selected</Typography>
            <Typography variant="caption">
              {dimensions} dim · {measures} measure · {details} other
            </Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Dataset</Typography>
            <Typography variant="body2" fontWeight={600}>{name}</Typography>
            <Typography variant="caption">{subject}</Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Joins</Typography>
            <Typography variant="body2" fontWeight={600}>{validJoins.length} configured</Typography>
            {validJoins.length > 0 && (
              <Typography variant="caption">
                {validJoins.map(j => j.table_name).join(', ')}
              </Typography>
            )}
          </Paper>
        </Box>

        {/* Editable name/description for last-minute changes */}
        <Divider />
        <TextField
          label="Name"
          value={name}
          onChange={e => setName(e.target.value)}
          fullWidth size="small"
        />
        <TextField
          label="Description"
          value={description}
          onChange={e => setDescription(e.target.value)}
          fullWidth size="small" multiline rows={2}
        />
      </Stack>
    );
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const stepContent: Record<number, () => React.ReactNode> = {
    0: renderStep1,
    1: renderStep2,
    2: renderStep3,
    3: renderStep4,
    4: renderStep5,
  };

  const canProceed = (): boolean => {
    if (step === 0) return !!(name.trim() && subject.trim());
    if (step === 1) {
      if (!sourceConnectionId) return false;
      if (sourceMode === 'table') return !!selectedTable;
      return !!customSql.trim();
    }
    return true;
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">Create Dataset</Typography>
          <Typography variant="caption" color="text.secondary">
            Step {step + 1} of {STEPS.length}
          </Typography>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        {/* Stepper */}
        <Stepper activeStep={step} sx={{ mb: 3 }} alternativeLabel>
          {STEPS.map((label, idx) => (
            <Step key={label} completed={idx < step}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {/* Global error */}
        {globalError && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setGlobalError('')}>
            {globalError}
          </Alert>
        )}

        {/* Step content */}
        {(stepContent[step] || renderStep1)()}
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose}>Cancel</Button>

        {step > 0 && (
          <Button onClick={handleBack}>Back</Button>
        )}

        {/* Skip button for optional steps */}
        {step === 3 && (
          <Tooltip title="Skip optional joins and go to Review">
            <Button
              variant="outlined"
              startIcon={<SkipIcon />}
              onClick={() => setStep(4)}
            >
              Skip Joins
            </Button>
          </Tooltip>
        )}

        <Box sx={{ flexGrow: 1 }} />

        {step < STEPS.length - 1 ? (
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={!canProceed()}
          >
            Next
          </Button>
        ) : (
          <Button
            variant="contained"
            color="success"
            onClick={handleCreate}
            disabled={saving || !name.trim() || !subject.trim()}
            startIcon={saving ? <CircularProgress size={16} color="inherit" /> : undefined}
          >
            {saving ? 'Creating...' : 'Create Dataset'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default DatasetCreationWizard;
