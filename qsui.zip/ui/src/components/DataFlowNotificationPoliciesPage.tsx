/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowNotificationPoliciesPage — CRUD for event-driven policies.
 * Phase 132.21 — fires email / webhook / ws on run lifecycle events.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControlLabel, IconButton, MenuItem,
  Paper, Select, Stack, Switch, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { DataFlowDef, DataFlowNotificationPolicy } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const EVENTS = [
  'run_failed', 'sla_breached', 'run_partial', 'run_cancelled',
  'run_succeeded', 'schedule_missed',
];
const CHANNELS = ['email', 'webhook', 'ws'];

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 16).replace('T', ' ') : '—';

export default function DataFlowNotificationPoliciesPage() {
  const [policies, setPolicies] = useState<DataFlowNotificationPolicy[]>([]);
  const [dataflows, setDataflows] = useState<DataFlowDef[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const blank = {
    name: '', event: 'run_failed', channel: 'email',
    dataflow_id: '' as string | number,
    tag: '',
    config_json: '{\n  "to": "ops@example.com"\n}',
    is_active: true,
    cooldown_seconds: 1800,
  };
  const [form, setForm] = useState<any>(blank);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [p, w, t] = await Promise.all([
        api.dataflows.listNotificationPolicies(),
        api.dataflows.listDataFlows(),
        api.dataflows.listAllTags(),
      ]);
      setPolicies(toArray<DataFlowNotificationPolicy>(p));
      setDataflows(toArray<DataFlowDef>(w));
      setTags(toArray<string>(t, 'tags'));
    } catch (e: any) {
      setError(e?.message || 'Failed to load policies');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditingId(null);
    setForm(blank);
    setDialogOpen(true);
  };

  const openEdit = (p: DataFlowNotificationPolicy) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      event: p.event,
      channel: p.channel,
      dataflow_id: p.dataflow_id ?? '',
      tag: p.tag ?? '',
      config_json: JSON.stringify(p.config || {}, null, 2),
      is_active: p.is_active,
      cooldown_seconds: p.cooldown_seconds ?? 0,
    });
    setDialogOpen(true);
  };

  const onSave = async () => {
    let config: any = {};
    try {
      config = JSON.parse(form.config_json || '{}');
    } catch (e: any) {
      setError('Channel config must be valid JSON'); return;
    }
    const body = {
      name: form.name,
      event: form.event,
      channel: form.channel,
      dataflow_id: form.dataflow_id === '' ? null : Number(form.dataflow_id),
      tag: form.tag || null,
      config,
      is_active: form.is_active,
      cooldown_seconds: Number(form.cooldown_seconds) || 0,
    };
    try {
      if (editingId) {
        await api.dataflows.updateNotificationPolicy(editingId, body);
      } else {
        await api.dataflows.createNotificationPolicy(body);
      }
      setDialogOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    }
  };

  const onDelete = async (id: number, name: string) => {
    if (!window.confirm(`Delete policy "${name}"?`)) return;
    try { await api.dataflows.deleteNotificationPolicy(id); await load(); }
    catch (e: any) { setError(e?.message || 'Delete failed'); }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">Notification Policies</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<AddIcon />} variant="contained" onClick={openCreate}>New Policy</Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Event-driven notifications. Scope by DataFlow id, tag, or leave both blank for global.
        Channels: email (SMTP via config.json), webhook (POST JSON), ws (broadcast to admin clients).
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Event</TableCell>
              <TableCell>Channel</TableCell>
              <TableCell>Scope</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Cooldown</TableCell>
              <TableCell>Last fired</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && <TableRow><TableCell colSpan={8} align="center"><CircularProgress size={20} /></TableCell></TableRow>}
            {!loading && policies.length === 0 && (
              <TableRow><TableCell colSpan={8} align="center">
                <Typography variant="body2" color="text.secondary">No policies yet — click "New Policy".</Typography>
              </TableCell></TableRow>
            )}
            {policies.map(p => (
              <TableRow key={p.id} hover>
                <TableCell>{p.name}</TableCell>
                <TableCell><Chip label={p.event} size="small" variant="outlined" sx={{ fontSize: 10 }} /></TableCell>
                <TableCell><Chip label={p.channel} size="small" sx={{ fontSize: 10 }} /></TableCell>
                <TableCell>
                  {p.dataflow_id ? <Chip label={`#${p.dataflow_id}`} size="small" variant="outlined" sx={{ fontSize: 10 }} /> :
                    p.tag ? <Chip label={`tag:${p.tag}`} size="small" variant="outlined" sx={{ fontSize: 10 }} /> :
                    <Chip label="global" size="small" color="info" variant="outlined" sx={{ fontSize: 10 }} />}
                </TableCell>
                <TableCell>{p.is_active ? <Chip label="active" size="small" color="success" sx={{ fontSize: 10 }} /> : <Chip label="off" size="small" sx={{ fontSize: 10 }} />}</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{p.cooldown_seconds}s</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{fmtDt(p.last_fired_at)}</TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => openEdit(p)}><EditIcon fontSize="small" /></IconButton>
                  <IconButton size="small" onClick={() => onDelete(p.id, p.name)}><DeleteIcon fontSize="small" /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editingId ? 'Edit' : 'New'} Notification Policy</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" size="small" fullWidth value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })} />

            <Stack direction="row" spacing={2}>
              <Select size="small" fullWidth value={form.event}
                onChange={e => setForm({ ...form, event: e.target.value })}>
                {EVENTS.map(ev => <MenuItem key={ev} value={ev}>{ev}</MenuItem>)}
              </Select>
              <Select size="small" fullWidth value={form.channel}
                onChange={e => setForm({ ...form, channel: e.target.value })}>
                {CHANNELS.map(ch => <MenuItem key={ch} value={ch}>{ch}</MenuItem>)}
              </Select>
            </Stack>

            <Stack direction="row" spacing={2}>
              <Select size="small" fullWidth displayEmpty value={form.dataflow_id}
                onChange={e => setForm({ ...form, dataflow_id: e.target.value })}>
                <MenuItem value="">— (any DataFlow)</MenuItem>
                {dataflows.map(d => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
              </Select>
              <Select size="small" fullWidth displayEmpty value={form.tag}
                onChange={e => setForm({ ...form, tag: e.target.value })}>
                <MenuItem value="">— (any tag)</MenuItem>
                {tags.map(t => <MenuItem key={t} value={t}>tag:{t}</MenuItem>)}
              </Select>
            </Stack>

            <Typography variant="caption" color="text.secondary">
              Channel config (JSON). Email: <code>&#123;"to": "ops@x.com", "subject": "...", "body": "..."&#125;</code>.
              Webhook: <code>&#123;"url": "https://...", "headers": &#123;...&#125;&#125;</code>. ws: <code>&#123;"severity": "warning"&#125;</code>.
              Supports <code>&#123;event&#125;</code>, <code>&#123;run_id&#125;</code>, <code>&#123;dataflow_name&#125;</code>, <code>&#123;status&#125;</code>, <code>&#123;error&#125;</code> in templates.
            </Typography>
            <TextField label="Channel config (JSON)" multiline minRows={6} value={form.config_json}
              onChange={e => setForm({ ...form, config_json: e.target.value })}
              sx={{ fontFamily: 'monospace' }} fullWidth />

            <Stack direction="row" spacing={2} alignItems="center">
              <TextField label="Cooldown (seconds)" type="number" size="small" sx={{ width: 200 }}
                value={form.cooldown_seconds}
                onChange={e => setForm({ ...form, cooldown_seconds: e.target.value })}
                helperText="0 = no cooldown" />
              <FormControlLabel control={<Switch checked={form.is_active}
                onChange={e => setForm({ ...form, is_active: e.target.checked })} />} label="Active" />
            </Stack>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={onSave} disabled={!form.name}>
            {editingId ? 'Save' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
