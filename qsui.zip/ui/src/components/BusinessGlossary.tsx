/**
 * Phase 101 — Business Glossary
 *
 * Search and browse all semantic layer columns + calculated metrics
 * across published datasets.
 */
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Box, Paper, Typography, TextField, InputAdornment, IconButton,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, CircularProgress, Alert, Select, MenuItem, FormControl, InputLabel,
  Tooltip, TablePagination,
} from '@mui/material';
import {
  Search as SearchIcon,
  Close as CloseIcon,
  Functions as MetricIcon,
  ViewColumn as ColumnIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { safeFetch } from '../services/api/core';

interface GlossaryEntry {
  entry_type: 'column' | 'metric';
  dataset_id: number;
  dataset_name: string;
  id: number;
  physical_name: string;
  friendly_name: string;
  column_type: string;
  data_type: string;
  aggregation: string;
  format_pattern: string;
  description: string;
  synonyms: string[];
  expression?: string;
}

const TYPE_COLORS: Record<string, string> = {
  dimension: '#1976d2',
  measure: '#2e7d32',
  detail: '#757575',
  kpi: '#e65100',
  metric: '#7b1fa2',
};

const BusinessGlossary: React.FC = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [datasetFilter, setDatasetFilter] = useState<number | ''>('');
  const [typeFilter, setTypeFilter] = useState('');
  const [entries, setEntries] = useState<GlossaryEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [datasets, setDatasets] = useState<{ id: number; name: string }[]>([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);

  // Load datasets for filter dropdown
  useEffect(() => {
    api.listDatasets().then((ds: any[]) => setDatasets(ds.map(d => ({ id: d.id, name: d.name })))).catch(() => {});
  }, []);

  // Search glossary
  const fetchGlossary = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params: Record<string, any> = { limit: 500 };
      if (search.trim()) params.search = search.trim();
      if (datasetFilter) params.dataset_id = datasetFilter;
      if (typeFilter) params.column_type = typeFilter;
      const qs = new URLSearchParams(params).toString();
      const data = await safeFetch(`/api/datasets/glossary?${qs}`);
      setEntries(data.entries || []);
      setTotal(data.total || 0);
      setPage(0);
    } catch (e: any) {
      setError(e.message || 'Failed to load glossary');
    } finally {
      setLoading(false);
    }
  }, [search, datasetFilter, typeFilter]);

  useEffect(() => {
    const timer = setTimeout(fetchGlossary, 300);
    return () => clearTimeout(timer);
  }, [fetchGlossary]);

  const pageEntries = useMemo(() =>
    entries.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
    [entries, page, rowsPerPage],
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>Business Glossary</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Browse and search all semantic layer columns and calculated metrics across published datasets.
      </Typography>

      {/* Filters */}
      <Paper sx={{ p: 2, mb: 2, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <TextField
          size="small"
          placeholder="Search by name, description, or synonym..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          sx={{ minWidth: 300, flex: 1 }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment>,
            endAdornment: search ? (
              <InputAdornment position="end">
                <IconButton size="small" onClick={() => setSearch('')}><CloseIcon fontSize="small" /></IconButton>
              </InputAdornment>
            ) : null,
          }}
        />
        <FormControl size="small" sx={{ minWidth: 180 }}>
          <InputLabel>Dataset</InputLabel>
          <Select value={datasetFilter} label="Dataset" onChange={(e) => setDatasetFilter(e.target.value as any)}>
            <MenuItem value="">All Datasets</MenuItem>
            {datasets.map(d => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 140 }}>
          <InputLabel>Type</InputLabel>
          <Select value={typeFilter} label="Type" onChange={(e) => setTypeFilter(e.target.value)}>
            <MenuItem value="">All Types</MenuItem>
            <MenuItem value="dimension">Dimension</MenuItem>
            <MenuItem value="measure">Measure</MenuItem>
            <MenuItem value="detail">Detail</MenuItem>
            <MenuItem value="kpi">KPI</MenuItem>
            <MenuItem value="metric">Metric</MenuItem>
          </Select>
        </FormControl>
        <Typography variant="caption" color="text.secondary">
          {total} entries
        </Typography>
      </Paper>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
      ) : entries.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            {search ? `No entries match "${search}"` : 'No glossary entries found. Create datasets with columns to populate the glossary.'}
          </Typography>
        </Paper>
      ) : (
        <Paper>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 320px)' }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, width: 40 }}></TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Friendly Name</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Physical Name</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Dataset</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Data Type</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Description</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Format</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Synonyms</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pageEntries.map((entry) => (
                  <TableRow
                    key={`${entry.entry_type}-${entry.id}`}
                    hover
                    sx={{ cursor: 'pointer' }}
                    onClick={() => navigate(`/datasets`)}
                  >
                    <TableCell>
                      <Tooltip title={entry.entry_type === 'metric' ? 'Calculated Metric' : 'Column'}>
                        {entry.entry_type === 'metric'
                          ? <MetricIcon sx={{ fontSize: 18, color: TYPE_COLORS.metric }} />
                          : <ColumnIcon sx={{ fontSize: 18, color: TYPE_COLORS[entry.column_type] || '#757575' }} />
                        }
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ fontWeight: 500 }}>{entry.friendly_name}</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{entry.physical_name}</TableCell>
                    <TableCell>{entry.dataset_name}</TableCell>
                    <TableCell>
                      <Chip
                        label={entry.column_type}
                        size="small"
                        sx={{
                          bgcolor: TYPE_COLORS[entry.column_type] || '#757575',
                          color: '#fff',
                          fontSize: 11,
                          height: 22,
                        }}
                      />
                    </TableCell>
                    <TableCell>{entry.data_type}</TableCell>
                    <TableCell sx={{ maxWidth: 250, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      <Tooltip title={entry.description || ''}><span>{entry.description || '—'}</span></Tooltip>
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>{entry.format_pattern || '—'}</TableCell>
                    <TableCell>
                      {(entry.synonyms || []).length > 0
                        ? entry.synonyms.slice(0, 3).map((s, i) => (
                          <Chip key={i} label={s} size="small" variant="outlined" sx={{ mr: 0.5, fontSize: 10, height: 20 }} />
                        ))
                        : '—'
                      }
                      {(entry.synonyms || []).length > 3 && (
                        <Tooltip title={entry.synonyms.join(', ')}>
                          <Chip label={`+${entry.synonyms.length - 3}`} size="small" sx={{ fontSize: 10, height: 20 }} />
                        </Tooltip>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div"
            count={entries.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={[25, 50, 100]}
          />
        </Paper>
      )}
    </Box>
  );
};

export default BusinessGlossary;
