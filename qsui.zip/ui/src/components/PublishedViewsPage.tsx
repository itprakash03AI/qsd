import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Autocomplete, FormControl, InputLabel, Select, MenuItem,
  RadioGroup, Radio, FormLabel, FormControlLabel, Divider,
} from '@mui/material';
import {
  Publish as PublishIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  ContentCopy as CopyIcon, Edit as EditIcon, Visibility as ViewIcon,
  BarChart as UsageIcon, PlayArrow as TestIcon, VpnKey as VpnKeyIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { API_BASE_URL, safeFetch } from '../services/api';
import { PUBLISHED_API_BASE_URL } from '../services/api/core';
import {
  distinctValues as fetchDistinctValues,
  previewColumns as fetchPreviewColumns,
} from './common/sqlPreviewApi';
// BF-488 — surface WHERE-clause editing in the Edit dialog so the
// publisher can change Static/Dynamic columns + values after publishing
// without having to delete + republish.  Backend's UpdateViewRequest
// already accepts ``where_clauses`` (re-applied to query_config on PUT).
import {
  WhereClausesEditor,
  type WhereClauseRow,
  type WhereColumnOption,
} from './common/WhereClausesEditor';

interface PublishedView {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  query_id: number;
  connection_id: number | null;
  allowed_filters: string[];
  allowed_ad_groups: string[];
  default_limit: number;
  max_limit: number;
  is_active: boolean;
  cache_ttl_seconds: number;
  param_definitions?: any[];   // Phase 86: runtime parameter definitions
  // Phase 133-J — publisher-time credential routing.  See PublishViewDialog.
  credential_mode?: 'consumer' | 'publisher' | 'shared';
  execution_connection_id?: number | null;
  publisher_username?: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
}

interface UsageLog {
  id: number;
  api_key_id: number | null;
  view_id: number;
  response_rows: number | null;
  response_ms: number | null;
  status_code: number | null;
  client_ip: string | null;
  created_at: string | null;
}

const PublishedViewsPage = () => {
  const [views, setViews] = useState<PublishedView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Edit dialog
  const [editView, setEditView] = useState<PublishedView | null>(null);
  const [editSlug, setEditSlug] = useState('');
  const [editName, setEditName] = useState('');
  const [editError, setEditError] = useState<string | null>(null);  // BF-564
  const [editDesc, setEditDesc] = useState('');
  const [editFilters, setEditFilters] = useState<string[]>([]);
  // Phase 133-I round 21 — column options for the Allowed Filters
  // Autocomplete in the edit dialog.  Was hardcoded to ``[]`` — user
  // had to type column names from memory.  Now fetched from
  // /api/sql/preview-columns when the dialog opens.
  const [editColumnOptions, setEditColumnOptions] = useState<string[]>([]);
  const [editDefaultLimit, setEditDefaultLimit] = useState(1000);
  const [editMaxLimit, setEditMaxLimit] = useState(50000);
  const [editCacheTtl, setEditCacheTtl] = useState(300);
  const [editAdGroupsInput, setEditAdGroupsInput] = useState('');
  // Phase 133-J — edit-time credential routing.  publisher_username is
  // immutable (backend strips it from update payload) but the publisher
  // can switch credential_mode and re-point execution_connection_id
  // after the fact (e.g. flip from 'consumer' to 'publisher' once they
  // realise curl callers are stuck on the password prompt).
  const [editCredentialMode, setEditCredentialMode] =
    useState<'consumer' | 'publisher' | 'shared'>('consumer');
  const [editExecConnId, setEditExecConnId] = useState<number | ''>('');
  const [editConnOptions, setEditConnOptions] = useState<
    { id: number; name: string; connection_type: string; is_shared?: boolean }[]
  >([]);
  // BF-488 — WHERE-clause editing.  Seeded from
  // ``pv.query_config._where_clauses_mapping`` (Phase 132.37 sentinel
  // key).  Empty list = no Static/Dynamic overlay (legacy PVs published
  // before WHERE mapping existed will start with [] and the publisher
  // can add rows).
  const [editWhereClauses, setEditWhereClauses] = useState<WhereClauseRow[]>([]);
  const [editColumnObjects, setEditColumnObjects] = useState<WhereColumnOption[]>([]);

  // Usage dialog
  const [usageView, setUsageView] = useState<PublishedView | null>(null);
  const [usageLogs, setUsageLogs] = useState<UsageLog[]>([]);
  const [usageLoading, setUsageLoading] = useState(false);

  // Phase 85C-3: Test dialog state
  const [testView, setTestView] = useState<PublishedView | null>(null);
  const [testFilters, setTestFilters] = useState<Record<string, string>>({});
  const [testParamValues, setTestParamValues] = useState<Record<string, string>>({});
  const [testLoading, setTestLoading] = useState(false);
  const [testError, setTestError] = useState('');
  const [testRows, setTestRows] = useState<any[]>([]);
  const [testColumns, setTestColumns] = useState<string[]>([]);
  // Phase 133-H round 11 — table hint + lazy distinct-values cache
  // for the Test dialog so Runtime Parameter + Filter inputs show
  // searchable dropdowns of cached schema values instead of plain
  // textboxes.
  const [testTableHint, setTestTableHint] = useState<string | null>(null);
  const [testValueOptions, setTestValueOptions] = useState<Record<string, string[]>>({});

  // API Key request dialog
  const [reqKeyView, setReqKeyView] = useState<PublishedView | null>(null);
  const [reqKeyName, setReqKeyName] = useState('');
  const [reqJustification, setReqJustification] = useState('');
  const [reqRateLimit, setReqRateLimit] = useState('');
  const [reqExpiresHours, setReqExpiresHours] = useState('');
  const [reqSubmitting, setReqSubmitting] = useState(false);
  const [reqSuccess, setReqSuccess] = useState('');

  // My Requests
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [myReqLoading, setMyReqLoading] = useState(false);
  const [revealedKeys, setRevealedKeys] = useState<Record<number, string>>({});

  const loadMyRequests = useCallback(async () => {
    setMyReqLoading(true);
    try {
      const data = await api.listApiKeyRequests();
      setMyRequests(Array.isArray(data) ? data : []);
    } catch {
      setMyRequests([]);
    } finally {
      setMyReqLoading(false);
    }
  }, []);

  const handleRevealKey = async (apiKeyId: number) => {
    try {
      const result = await api.revealApiKey(apiKeyId);
      setRevealedKeys(prev => ({ ...prev, [apiKeyId]: result.raw_key }));
    } catch (err: any) {
      setError(err.message || 'Failed to reveal key');
    }
  };

  const loadViews = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listPublishedViews();
      setViews(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadViews(); loadMyRequests(); }, [loadViews, loadMyRequests]);

  const handleDelete = async (id: number) => {
    if (!window.confirm('Deactivate this published view?')) return;
    try {
      await api.deletePublishedView(id);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleRepublish = async (id: number) => {
    try {
      await api.republishView(id);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const openEdit = (v: PublishedView) => {
    setEditView(v);
    setEditSlug(v.slug);
    setEditName(v.name);
    setEditDesc(v.description || '');
    setEditFilters(v.allowed_filters || []);
    setEditDefaultLimit(v.default_limit);
    setEditMaxLimit(v.max_limit);
    setEditCacheTtl(v.cache_ttl_seconds);
    setEditAdGroupsInput((v.allowed_ad_groups || []).join(', '));
    // Phase 133-J — seed credential mode + execution connection from the
    // PV record.  Default to 'consumer' for legacy rows that pre-date the
    // column (matches backend default).
    setEditCredentialMode((v.credential_mode as any) || 'consumer');
    setEditExecConnId(v.execution_connection_id ?? '');
    // BF-488 — seed WHERE-clause rows from the publisher's saved
    // _where_clauses_mapping (Phase 132.37 sentinel key on query_config).
    // Mirrors the FeedConfigsPage edit pattern so the same persisted
    // contract works on both surfaces.
    const _qcEdit = (v as any).query_config || {};
    const _wcm = Array.isArray(_qcEdit._where_clauses_mapping)
      ? _qcEdit._where_clauses_mapping
      : [];
    setEditWhereClauses(
      _wcm.map((r: any) => ({
        column: r?.column || '',
        operator: r?.operator || 'eq',
        value: r?.value ?? '',
        mode: (r?.mode === 'static' ? 'static' : 'dynamic') as 'static' | 'dynamic',
      })),
    );
    // Fetch connection list for the picker; silent failure → empty picker.
    api.listConnections(true).then((rows: any) => {
      const list = Array.isArray(rows) ? rows : [];
      setEditConnOptions(list.map((c: any) => ({
        id: c.id,
        name: c.name,
        connection_type: c.connection_type,
        is_shared: !!c.is_shared,
      })));
    }).catch(() => setEditConnOptions([]));
    // Phase 133-I round 21 — fetch columns from the PV's underlying
    // SQL so the Allowed Filters Autocomplete has real options instead
    // of an empty list.  Best-effort: connection_id missing → empty
    // dropdown (freeSolo lets user still type).
    // Phase 133-I round 30 — fetch columns for BOTH saved_query AND
    // sql_file PVs.  Round 21 covered only query_id; sql_file PVs
    // were left with an empty dropdown.
    setEditColumnOptions([]);
    // BF-491 follow-up — also reset the WhereColumnOption[] used by the
    // WHERE-clause editor.  Without this, switching from PV-A to PV-B
    // briefly shows PV-A's column dropdown until PV-B's
    // fetchPreviewColumns completes (~200-500ms).
    setEditColumnObjects([]);
    (async () => {
      try {
        // BF-495 (2026-05-28) — populate the column dropdown for ALL
        // source types, not just saved_query / sql_file.  Federation
        // PVs source columns from the FV's output_columns + schema_cache;
        // business_report PVs have no SQL surface so they stay empty
        // (user types from memory, freeSolo on the column field).
        const vAny = v as any;
        const qc = vAny.query_config || {};
        const srcType = (qc.source_type || vAny.source_type || 'saved_query').toLowerCase();
        let cols: string[] = [];
        let colObjs: WhereColumnOption[] = [];

        if (srcType === 'federation' && (qc.federation_view_id || vAny.federation_view_id)) {
          // Federation PV — fetch the FV record so we get its declared
          // output_columns (publisher's explicit column list) AND
          // schema_cache (post-materialize column metadata).  Prefer
          // schema_cache for richer type info.
          const fvId = qc.federation_view_id || vAny.federation_view_id;
          try {
            const fv: any = await api.getFederationView(Number(fvId));
            const sc: any[] = Array.isArray(fv?.schema_cache) ? fv.schema_cache : [];
            const oc: string[] = Array.isArray(fv?.output_columns) ? fv.output_columns : [];
            const seen = new Set<string>();
            sc.forEach((c: any) => {
              const nm = typeof c === 'string' ? c : (c?.name || '');
              if (!nm || seen.has(nm)) return;
              seen.add(nm);
              cols.push(nm);
              colObjs.push({
                name: nm,
                type: typeof c === 'string' ? undefined : (c?.type || undefined),
                tableSource: `federation:${fv?.name || fvId}`,
              });
            });
            oc.forEach((nm: string) => {
              if (!nm || seen.has(nm)) return;
              seen.add(nm);
              cols.push(nm);
              colObjs.push({ name: nm, tableSource: `federation:${fv?.name || fvId}` });
            });
          } catch { /* best-effort — empty dropdown, user types */ }
        } else if (v.connection_id) {
          // saved_query / sql_file / business_report-with-raw_sql paths.
          let sqlBlob = '';
          if (v.query_id) {
            const sq: any = await api.getSavedQuery(String(v.query_id));
            const sqc = sq?.query_config || {};
            sqlBlob = [sqc.raw_sql, sqc.custom_sql, sqc.secondary_raw_sql]
              .filter((s: any) => typeof s === 'string' && s.trim())
              .join('\n');
          } else {
            sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
              .filter((s: any) => typeof s === 'string' && s.trim())
              .join('\n');
          }
          if (sqlBlob) {
            const pc = await fetchPreviewColumns(sqlBlob, 'duckdb', v.connection_id);
            const seen = new Set<string>();
            Object.entries(pc?.columns_by_table || {}).forEach(([tbl, arr]) => {
              (arr as any[]).forEach((c: any) => {
                if (!c?.name) return;
                cols.push(c.name);
                if (seen.has(c.name)) return;
                seen.add(c.name);
                colObjs.push({
                  name: c.name,
                  type: c.type || undefined,
                  isPartition: !!c.is_partition,
                  tableSource: tbl,
                });
              });
            });
          }
        }

        if (cols.length > 0) setEditColumnOptions(Array.from(new Set(cols)).sort());
        if (colObjs.length > 0) setEditColumnObjects(colObjs);
      } catch { /* best-effort */ }
    })();
  };

  const handleSaveEdit = async () => {
    if (!editView) return;
    // BF-564 (2026-05-29): client-side required-field validation before
    // PUT so the user gets an actionable inline error instead of an
    // opaque backend 400.
    if (!editName.trim()) {
      setEditError('Name is required.');
      return;
    }
    if (!editSlug.trim()) {
      setEditError('Slug is required.');
      return;
    }
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(editSlug.trim())) {
      setEditError(
        'Slug must contain only letters, numbers, hyphens, and underscores ' +
        '(and start with a letter or number).'
      );
      return;
    }
    try {
      const allowed_ad_groups = editAdGroupsInput
        .split(',')
        .map(g => g.trim())
        .filter(g => g.length > 0);
      await api.updatePublishedView(editView.id, {
        slug: editSlug,
        name: editName,
        description: editDesc || null,
        allowed_filters: editFilters,
        default_limit: editDefaultLimit,
        max_limit: editMaxLimit,
        cache_ttl_seconds: editCacheTtl,
        allowed_ad_groups,
        // Phase 133-J — edit-time routing changes.  publisher_username
        // is server-side immutable; backend strips it from the payload.
        credential_mode: editCredentialMode,
        execution_connection_id: editExecConnId === '' ? null : Number(editExecConnId),
        // BF-488 — WHERE-clause mapping re-applied to query_config server-side.
        // Empty list clears all Static/Dynamic overlays.
        where_clauses: editWhereClauses,
      });
      setEditView(null);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const openUsage = async (v: PublishedView) => {
    setUsageView(v);
    setUsageLoading(true);
    try {
      const logs = await api.getPublishedViewUsage(v.id);
      setUsageLogs(Array.isArray(logs) ? logs : []);
    } catch {
      setUsageLogs([]);
    } finally {
      setUsageLoading(false);
    }
  };

  const openRequestKey = (v: PublishedView) => {
    setReqKeyView(v);
    setReqKeyName(`${v.slug}-key`);
    setReqJustification('');
    setReqRateLimit('');
    setReqExpiresHours('');
    setReqSuccess('');
  };

  const handleRequestKey = async () => {
    if (!reqKeyView || !reqKeyName.trim()) return;
    setReqSubmitting(true);
    try {
      const result = await api.requestApiKey({
        key_name: reqKeyName.trim(),
        scoped_view_ids: [reqKeyView.id],
        rate_limit: reqRateLimit.trim() || undefined,
        expires_hours: reqExpiresHours ? Number(reqExpiresHours) : undefined,
        justification: reqJustification.trim() || undefined,
      });
      if (result.auto_approved && result.raw_key) {
        setReqSuccess(`Key created: ${result.raw_key}`);
      } else {
        setReqSuccess('Request submitted! You will be notified when an admin reviews it.');
      }
      loadMyRequests();
    } catch (err: any) {
      setError(err.message || 'Failed to submit request');
      setReqKeyView(null);
    } finally {
      setReqSubmitting(false);
    }
  };

  // BF-124: Resolve view IDs to names for display
  const viewNameById = React.useMemo(() => {
    const map: Record<number, string> = {};
    views.forEach(v => { map[v.id] = v.name || v.slug; });
    return map;
  }, [views]);

  const resolveViewNames = (ids: number[]) =>
    ids.map(id => viewNameById[id] || `#${id}`).join(', ');

  // Use dedicated Published API URL if configured, otherwise fall back to main API
  const pubBase = PUBLISHED_API_BASE_URL || API_BASE_URL || window.location.origin;

  const copyEndpoint = (slug: string) => {
    const url = `${pubBase}/api/v1/views/${slug}/data`;
    navigator.clipboard.writeText(url);
  };

  // Phase 85C-3: Open test dialog
  const openTestDialog = async (v: PublishedView) => {
    setTestView(v);
    const initFilters: Record<string, string> = {};
    (v.allowed_filters || []).forEach(f => { initFilters[f] = ''; });
    setTestFilters(initFilters);
    // Phase 86: initialize param values from defaults
    const initParams: Record<string, string> = {};
    (v.param_definitions || []).forEach((p: any) => {
      initParams[p.name] = p.default != null ? String(p.default) : '';
    });
    setTestParamValues(initParams);
    setTestRows([]);
    setTestColumns([]);
    setTestError('');
    // Phase 133-H round 11 — resolve a table hint so the lazy
    // distinct-values lookup can target the right warehouse table.
    // Fetches the saved query (best-effort) to read the first FROM
    // target out of files[] or raw_sql.
    setTestTableHint(null);
    setTestValueOptions({});
    // Phase 133-I round 31 — also handle sql_file PVs (no query_id).
    // Use the PV's frozen query_config snapshot.  Same fallback chain
    // round 30's Edit dialog uses.
    try {
      let qc: any = null;
      if (v.query_id) {
        const sq: any = await api.getSavedQuery(String(v.query_id));
        qc = sq?.query_config || {};
      } else {
        qc = (v as any).query_config || {};
      }
      if (qc) {
        const files: any[] = qc.files || [];
        let table: string | null = null;
        for (const f of files) {
          const p = typeof f === 'string' ? f : (f?.path || '');
          if (p.startsWith('__registered__:')) { table = p.slice(15); break; }
          if (p.startsWith('__iceberg__:'))    { table = p.slice(12); break; }
        }
        if (!table) {
          const sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
            .filter((s: any) => typeof s === 'string' && s.trim())
            .join('\n');
          const m = sqlBlob.match(
            /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
          );
          if (m) table = m[1].replace(/[\s"`\[\]]/g, '');
        }
        if (table) setTestTableHint(table);
      }
    } catch { /* best-effort */ }
  };

  // Phase 133-H round 11 — lazy distinct-values fetcher for the test
  // dialog's Runtime Parameters + Filter inputs.  Same /api/sql/distinct-values
  // endpoint the publish editor uses; caches per (connection, table, column)
  // for 5 minutes on the backend.
  const fetchTestValues = useCallback(async (column: string) => {
    if (!testView?.connection_id || !testTableHint || !column) return;
    const colKey = column.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(testValueOptions, colKey)) return;
    setTestValueOptions(prev => ({ ...prev, [colKey]: [] }));  // sentinel
    try {
      const res = await fetchDistinctValues(
        Number(testView.connection_id), testTableHint, column,
      );
      const vals = (res?.values || []).map(String);
      if (vals.length > 0) {
        setTestValueOptions(prev => ({ ...prev, [colKey]: vals }));
      }
    } catch { /* best-effort */ }
  }, [testView?.connection_id, testTableHint, testValueOptions]);

  // Auto-prime values when the dialog opens.
  useEffect(() => {
    if (!testView) return;
    (testView.allowed_filters || []).forEach(c => fetchTestValues(c));
    (testView.param_definitions || []).forEach((p: any) => p?.name && fetchTestValues(p.name));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testView, testTableHint]);

  // Phase 85C-3: Send test request using the published view's data endpoint
  const handleTestRequest = async () => {
    if (!testView) return;
    setTestLoading(true);
    setTestError('');
    setTestRows([]);
    setTestColumns([]);
    try {
      // Build query string from non-empty filters.
      // Phase 132.36 — emit bare-form ?name=value where the name doesn't
      // collide with a framework-reserved key; bracketed form only for
      // reserved-name collisions.
      const RESERVED = new Set([
        'limit', 'offset', 'sort', 'columns', 'format', 'cache',
        'snapshot_id', 'as_of_timestamp', 'engine', 'filter',
      ]);
      const params = new URLSearchParams({ limit: '20', format: 'json' });
      Object.entries(testFilters).forEach(([col, val]) => {
        if (val.trim()) {
          // Explicit filter.col= form for op:value values; bare for scalars.
          if (/^(eq|ne|gt|gte|lt|lte|in|not_in|contains|between):/.test(val)) {
            params.set(`filter.${col}`, val.trim());
          } else {
            params.set(RESERVED.has(col) ? `filter.${col}` : col, val.trim());
          }
        }
      });
      Object.entries(testParamValues).forEach(([name, val]) => {
        if (val.trim()) {
          params.set(RESERVED.has(name) ? `param[${name}]` : name, val.trim());
        }
      });
      // Call the Published API endpoint — use dedicated pod URL if configured
      const testUrl = PUBLISHED_API_BASE_URL
        ? `${PUBLISHED_API_BASE_URL}/api/v1/views/${testView.slug}/data?${params.toString()}`
        : `/api/v1/views/${testView.slug}/data?${params.toString()}`;
      const result = await safeFetch(testUrl);
      // Phase 131 deep-dive #9: defensive normalisation.  If API returns
      // `{data: null}` (legacy / error path), prior code did
      // `Object.keys(null)` → TypeError.  Now coerce to [] explicitly.
      const rawRows = result?.rows ?? result?.data ?? (Array.isArray(result) ? result : null);
      const rows = Array.isArray(rawRows) ? rawRows : [];
      const cols = Array.isArray(result?.columns)
        ? result.columns
        : (rows.length > 0 && rows[0] && typeof rows[0] === 'object'
            ? Object.keys(rows[0])
            : []);
      setTestRows(rows.slice(0, 20));
      setTestColumns(cols);
    } catch (e: any) {
      setTestError(e.message || 'Request failed');
    } finally {
      setTestLoading(false);
    }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1200, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5" fontWeight={600}>Published Views</Typography>
        <Button startIcon={<RefreshIcon />} onClick={loadViews} size="small">Refresh</Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : views.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            No published views yet. Save a query and publish it as an API to get started.
          </Typography>
        </Paper>
      ) : (
        <Paper variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Name</strong></TableCell>
                <TableCell><strong>Slug</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
                <TableCell><strong>Cache TTL</strong></TableCell>
                <TableCell><strong>Limits</strong></TableCell>
                <TableCell><strong>Filters</strong></TableCell>
                <TableCell><strong>AD Groups</strong></TableCell>
                <TableCell><strong>Created</strong></TableCell>
                <TableCell align="right"><strong>Actions</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {views.map(v => (
                <TableRow key={v.id} sx={{ opacity: v.is_active ? 1 : 0.5 }}>
                  <TableCell>
                    <Typography variant="body2" fontWeight={500}>{v.name}</Typography>
                    {v.description && (
                      <Typography variant="caption" color="text.secondary">{v.description}</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <code style={{ fontSize: 12 }}>{v.slug}</code>
                      <Tooltip title="Copy API endpoint">
                        <IconButton size="small" onClick={() => copyEndpoint(v.slug)}>
                          <CopyIcon sx={{ fontSize: 14 }} />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={v.is_active ? 'Active' : 'Inactive'}
                      size="small"
                      color={v.is_active ? 'success' : 'default'}
                    />
                  </TableCell>
                  <TableCell>{v.cache_ttl_seconds}s</TableCell>
                  <TableCell>
                    <Typography variant="caption">{v.default_limit} / {v.max_limit}</Typography>
                  </TableCell>
                  <TableCell>
                    {(v.allowed_filters || []).length > 0
                      ? v.allowed_filters.map(f => <Chip key={f} label={f} size="small" sx={{ mr: 0.5, mb: 0.5 }} />)
                      : <Typography variant="caption" color="text.secondary">All</Typography>
                    }
                  </TableCell>
                  <TableCell>
                    {(v.allowed_ad_groups || []).length > 0
                      ? v.allowed_ad_groups.map(g => (
                          <Chip key={g} label={g} size="small" color="primary" variant="outlined" sx={{ mr: 0.5, mb: 0.5 }} />
                        ))
                      : <Chip label="All AD users" size="small" color="secondary" variant="outlined" />
                    }
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">
                      {v.created_at ? new Date(v.created_at).toLocaleDateString() : '-'}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end" alignItems="center">
                      {/* BF-488 — promoted from icon-only to a labeled button
                          so the "modify API" affordance is discoverable.
                          The icon row that follows handles less-frequent
                          actions (republish / usage / test / key / deactivate). */}
                      <Tooltip title="Edit settings, WHERE filters, AD groups, credentials">
                        <Button
                          size="small"
                          variant="outlined"
                          startIcon={<EditIcon fontSize="small" />}
                          onClick={() => openEdit(v)}
                          sx={{ minWidth: 0, px: 1 }}
                        >
                          Edit
                        </Button>
                      </Tooltip>
                      <Tooltip title="Republish (re-snapshot query)">
                        <IconButton size="small" onClick={() => handleRepublish(v.id)}>
                          <RefreshIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="View usage">
                        <IconButton size="small" onClick={() => openUsage(v)}>
                          <UsageIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      {/* Phase 85C-3: Test button */}
                      {v.is_active && (
                        <Tooltip title="Test this endpoint — send a live request and view response">
                          <IconButton size="small" color="success" onClick={() => openTestDialog(v)}>
                            <TestIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {v.is_active && (
                        <Tooltip title="Request API Key">
                          <IconButton size="small" color="primary" onClick={() => openRequestKey(v)}>
                            <VpnKeyIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {v.is_active && (
                        <Tooltip title="Deactivate">
                          <IconButton size="small" color="error" onClick={() => handleDelete(v.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}

      {/* Edit Dialog */}
      {/* BF-487 (2026-05-27) — widened to "md" so the inner dropdown
          poppers (capped at min(600px, 90vw)) fit inside the dialog. */}
      <Dialog open={!!editView} onClose={() => { setEditView(null); setEditError(null); }} maxWidth="md" fullWidth>
        <DialogTitle>Edit Published View</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            {/* BF-564 (2026-05-29): inline required-field validation
                error so the user sees the cause instead of a backend 400. */}
            {editError && (
              <Alert severity="error" onClose={() => setEditError(null)}>
                {editError}
              </Alert>
            )}
            <TextField label="Name" value={editName} onChange={e => setEditName(e.target.value)} fullWidth size="small" />
            <TextField label="Slug" value={editSlug} onChange={e => setEditSlug(e.target.value)} fullWidth size="small"
              helperText="URL-friendly identifier (lowercase, hyphens only)" />
            <TextField label="Description" value={editDesc} onChange={e => setEditDesc(e.target.value)} fullWidth size="small" multiline rows={2} />
            <Autocomplete
              multiple freeSolo size="small" openOnFocus
              options={editColumnOptions}
              value={editFilters}
              onChange={(_, v) => setEditFilters(v)}
              // BF-490 — popper auto-resize so long qualified column names
              // (e.g. "warehouse.dim_customer.email_domain") don't clip.
              slotProps={{
                popper: {
                  sx: {
                    width: 'auto !important',
                    minWidth: '100%',
                    maxWidth: 'min(600px, 90vw)',
                    '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                    '& .MuiAutocomplete-option': {
                      whiteSpace: 'normal',
                      wordBreak: 'break-word',
                    },
                  },
                },
              }}
              renderInput={params => (
                <TextField {...params}
                  label="Allowed Filters (columns)"
                  placeholder={editColumnOptions.length
                    ? 'Pick or type column name'
                    : 'Type column name...'}
                  helperText={editColumnOptions.length
                    ? `${editColumnOptions.length} columns available`
                    : 'Schema unavailable — type from memory'}
                />
              )}
            />
            <Stack direction="row" spacing={2}>
              <TextField label="Default Limit" type="number" value={editDefaultLimit}
                onChange={e => setEditDefaultLimit(Number(e.target.value))} size="small" sx={{ flex: 1 }} />
              <TextField label="Max Limit" type="number" value={editMaxLimit}
                onChange={e => setEditMaxLimit(Number(e.target.value))} size="small" sx={{ flex: 1 }} />
            </Stack>
            <TextField label="Cache TTL (seconds)" type="number" value={editCacheTtl}
              onChange={e => setEditCacheTtl(Number(e.target.value))} size="small"
              helperText="0 = always fresh" />
            <TextField
              label="Allowed AD Groups (optional)"
              value={editAdGroupsInput}
              onChange={e => setEditAdGroupsInput(e.target.value)}
              fullWidth size="small"
              placeholder="grp-analytics, grp-risk-team"
              helperText="Comma-separated LDAP group names. Leave empty to allow all authenticated AD users."
            />

            {/* BF-488 / BF-495 — WHERE-clause editing.  Same component
                the Publish dialog uses; persists into
                query_config._where_clauses_mapping via the backend's
                UpdateViewRequest.where_clauses field.  Heading + helper
                text make the section discoverable for users editing
                an existing PV. */}
            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
              WHERE Clauses
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              Click <strong>+ Add WHERE row</strong> to add a Static (locked) or
              Dynamic (consumer-overridable) filter.  Dynamic rows are
              auto-added to <code>param_definitions</code> + <code>allowed_filters</code> on save.
              {editColumnObjects.length === 0 && (
                <> Column dropdown is empty for this source — type column names directly.</>
              )}
            </Typography>
            <WhereClausesEditor
              value={editWhereClauses}
              onChange={setEditWhereClauses}
              columnOptions={editColumnObjects}
              title="Rows"
              addLabel="Add WHERE row"
              connectionId={editView?.connection_id ?? null}
            />

            {/* Phase 133-J — credential routing.  publisher_username is
                immutable (server strips it) but the publisher can change
                mode and re-point the execution connection. */}
            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2">
              Execution Connection & Credentials
            </Typography>
            <FormControl fullWidth size="small">
              <InputLabel id="edit-exec-conn-label">Execution Connection</InputLabel>
              <Select
                labelId="edit-exec-conn-label"
                label="Execution Connection"
                value={editExecConnId === '' ? '' : String(editExecConnId)}
                onChange={e => {
                  const v = e.target.value;
                  setEditExecConnId(v === '' ? '' : Number(v));
                }}
              >
                <MenuItem value="">
                  <em>Inherit from saved query / file (default)</em>
                </MenuItem>
                {editConnOptions.map(c => (
                  <MenuItem key={c.id} value={String(c.id)}>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2">{c.name}</Typography>
                      <Chip size="small" label={c.connection_type} variant="outlined" />
                      {c.is_shared && (
                        <Chip size="small" label="shared" color="info" variant="outlined" />
                      )}
                    </Stack>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel sx={{ fontSize: '0.85rem' }}>Credential Mode</FormLabel>
              <RadioGroup
                value={editCredentialMode}
                onChange={e => setEditCredentialMode(e.target.value as any)}
              >
                <FormControlLabel value="publisher" control={<Radio size="small" />}
                  label="Use my credentials (delegated trust — no consumer prompt)" />
                <FormControlLabel value="shared" control={<Radio size="small" />}
                  label="Use connection's shared credentials (system account)" />
                <FormControlLabel value="consumer" control={<Radio size="small" />}
                  label="Require consumer credentials (legacy, may 401 curl)" />
              </RadioGroup>
              {editView?.publisher_username && editCredentialMode === 'publisher' && (
                <Typography variant="caption" color="text.secondary">
                  Publisher (frozen at publish time): <code>{editView.publisher_username}</code>
                </Typography>
              )}
            </FormControl>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditView(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveEdit}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Phase 85C-3: Test Dialog */}
      <Dialog open={!!testView} onClose={() => setTestView(null)} maxWidth="md" fullWidth>
        <DialogTitle>Test Endpoint: {testView?.name}</DialogTitle>
        <DialogContent>
          {testView && (
            <Box>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                Endpoint: <code>{`${pubBase}/api/v1/views/${testView.slug}/data`}</code>
              </Typography>

              {/* Phase 86: Runtime Parameter inputs.
                  Phase 133-H round 11: Autocomplete with lazy distinct-
                  values lookup against the cached schema — searchable
                  dropdown instead of plain textbox. */}
              {(testView.param_definitions || []).length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Runtime Parameters</Typography>
                  <Stack spacing={1}>
                    {(testView.param_definitions || []).map((p: any) => {
                      const opts = testValueOptions[(p.name || '').toLowerCase()] || [];
                      return (
                        <Box key={p.name} sx={{ display: 'flex', gap: 1, mb: 1 }}>
                          <Autocomplete
                            size="small" freeSolo openOnFocus
                            options={opts}
                            value={testParamValues[p.name] || ''}
                            onChange={(_, v) => setTestParamValues(prev => ({
                              ...prev, [p.name]: (v ?? '') as string,
                            }))}
                            onInputChange={(_, v, reason) => {
                              if (reason === 'input') setTestParamValues(prev => ({
                                ...prev, [p.name]: v,
                              }));
                            }}
                            onFocus={() => fetchTestValues(p.name)}
                            sx={{ flex: 1 }}
                            slotProps={{
                              popper: {
                                sx: {
                                  width: 'auto !important',
                                  minWidth: '100%',
                                  maxWidth: 'min(600px, 90vw)',
                                  '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                  '& .MuiAutocomplete-option': {
                                    whiteSpace: 'normal', wordBreak: 'break-word',
                                  },
                                },
                              },
                            }}
                            renderInput={(rp) => (
                              <TextField {...rp}
                                label={`${p.name}${p.required ? ' *' : ''}`}
                                placeholder={p.default != null ? String(p.default) : (opts.length ? 'Pick or type' : p.type)}
                                helperText={p.description || `Type: ${p.type}${opts.length ? ` · ${opts.length} known values` : ''}`}
                              />
                            )}
                          />
                        </Box>
                      );
                    })}
                  </Stack>
                </Box>
              )}

              {/* Filter inputs */}
              {(testView.allowed_filters || []).length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Filter Parameters</Typography>
                  <Stack spacing={1}>
                    {(testView.allowed_filters || []).map(col => {
                      const opts = testValueOptions[col.toLowerCase()] || [];
                      return (
                        <Autocomplete
                          key={col}
                          size="small" freeSolo openOnFocus
                          options={opts}
                          value={testFilters[col] || ''}
                          onChange={(_, v) => setTestFilters(prev => ({
                            ...prev, [col]: (v ?? '') as string,
                          }))}
                          onInputChange={(_, v, reason) => {
                            if (reason === 'input') setTestFilters(prev => ({
                              ...prev, [col]: v,
                            }));
                          }}
                          onFocus={() => fetchTestValues(col)}
                          slotProps={{
                            popper: {
                              sx: {
                                width: 'auto !important',
                                minWidth: '100%',
                                maxWidth: 'min(600px, 90vw)',
                                '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                '& .MuiAutocomplete-option': {
                                  whiteSpace: 'normal', wordBreak: 'break-word',
                                },
                              },
                            },
                          }}
                          renderInput={(rp) => (
                            <TextField {...rp}
                              label={`filter[${col}]`}
                              placeholder={opts.length ? 'Pick or type — eq:val or val' : 'e.g., eq:2024 or 2024'}
                              helperText={opts.length ? `${opts.length} known values` : undefined}
                            />
                          )}
                        />
                      );
                    })}
                  </Stack>
                </Box>
              )}

              {testError && <Alert severity="error" sx={{ mb: 1 }}>{testError}</Alert>}

              {/* Results */}
              {testRows.length > 0 && (
                <Box sx={{ overflowX: 'auto', mt: 1 }}>
                  <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Response ({testRows.length} rows)</Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {testColumns.map(col => (
                          <TableCell key={col} sx={{ fontWeight: 700, fontSize: 11, whiteSpace: 'nowrap' }}>{col}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {testRows.map((row, idx) => (
                        <TableRow key={idx}>
                          {testColumns.map(col => (
                            <TableCell key={col} sx={{ fontSize: 11, whiteSpace: 'nowrap' }}>
                              {row[col] === null || row[col] === undefined ? (
                                <span style={{ color: '#aaa' }}>null</span>
                              ) : String(row[col]).substring(0, 60)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTestView(null)}>Close</Button>
          <Button
            variant="contained"
            color="success"
            startIcon={testLoading ? <CircularProgress size={14} /> : <TestIcon />}
            onClick={handleTestRequest}
            disabled={testLoading}
          >
            {testLoading ? 'Sending...' : 'Send Request'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Request API Key Dialog */}
      <Dialog open={!!reqKeyView} onClose={() => !reqSuccess && setReqKeyView(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Request API Key{reqKeyView ? `: ${reqKeyView.name}` : ''}</DialogTitle>
        <DialogContent>
          {reqSuccess ? (
            <Alert severity="success" sx={{ mt: 1 }}>{reqSuccess}</Alert>
          ) : (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="Key Name" value={reqKeyName} onChange={e => setReqKeyName(e.target.value)} fullWidth size="small" required />
              <TextField label="Justification (optional)" value={reqJustification} onChange={e => setReqJustification(e.target.value)} fullWidth size="small" multiline rows={2}
                placeholder="Why do you need this API key?" />
              <TextField label="Rate Limit (optional)" value={reqRateLimit} onChange={e => setReqRateLimit(e.target.value)} size="small"
                placeholder="e.g., 60/minute" helperText="Format: N/(second|minute|hour)" />
              <TextField label="Expiry Hours (optional)" value={reqExpiresHours} onChange={e => setReqExpiresHours(e.target.value)} type="number" size="small"
                placeholder="e.g., 720 (30 days)" />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReqKeyView(null)}>{reqSuccess ? 'Close' : 'Cancel'}</Button>
          {!reqSuccess && (
            <Button variant="contained" onClick={handleRequestKey} disabled={reqSubmitting || !reqKeyName.trim()}
              startIcon={reqSubmitting ? <CircularProgress size={14} /> : <VpnKeyIcon />}>
              {reqSubmitting ? 'Submitting...' : 'Request Key'}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* My API Key Requests */}
      {myRequests.length > 0 && (
        <Box sx={{ mt: 4 }}>
          <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>My API Key Requests</Typography>
          <Paper variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Key Name</strong></TableCell>
                  <TableCell><strong>Views</strong></TableCell>
                  <TableCell><strong>Status</strong></TableCell>
                  <TableCell><strong>Justification</strong></TableCell>
                  <TableCell><strong>Reviewed By</strong></TableCell>
                  <TableCell><strong>Requested</strong></TableCell>
                  <TableCell align="right"><strong>Actions</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {myRequests.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell>{r.key_name}</TableCell>
                    <TableCell>{resolveViewNames(r.scoped_view_ids || [])}</TableCell>
                    <TableCell>
                      <Chip label={r.status} size="small"
                        color={r.status === 'approved' ? 'success' : r.status === 'denied' ? 'error' : 'warning'} />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.justification || '-'}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.reviewed_by || '-'}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.created_at ? new Date(r.created_at).toLocaleDateString() : '-'}</Typography>
                    </TableCell>
                    <TableCell align="right">
                      {r.status === 'approved' && r.api_key_id && (
                        revealedKeys[r.api_key_id] ? (
                          <Tooltip title="Click to copy">
                            <Chip label={revealedKeys[r.api_key_id]} size="small" sx={{ fontFamily: 'monospace', fontSize: 10, maxWidth: 200 }}
                              onClick={() => navigator.clipboard.writeText(revealedKeys[r.api_key_id])} />
                          </Tooltip>
                        ) : (
                          <Button size="small" startIcon={<VpnKeyIcon />} onClick={() => handleRevealKey(r.api_key_id)}>
                            Reveal Key
                          </Button>
                        )
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Paper>
        </Box>
      )}

      {/* Usage Dialog */}
      <Dialog open={!!usageView} onClose={() => setUsageView(null)} maxWidth="md" fullWidth>
        <DialogTitle>Usage Logs: {usageView?.name}</DialogTitle>
        <DialogContent>
          {usageLoading ? (
            <Box sx={{ textAlign: 'center', py: 3 }}><CircularProgress size={24} /></Box>
          ) : usageLogs.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 2 }}>No access logs yet.</Typography>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Time</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Rows</TableCell>
                  <TableCell>Duration</TableCell>
                  <TableCell>Client IP</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {usageLogs.map(log => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <Typography variant="caption">
                        {log.created_at ? new Date(log.created_at).toLocaleString() : '-'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={log.status_code}
                        size="small"
                        color={log.status_code === 200 ? 'success' : 'error'}
                      />
                    </TableCell>
                    <TableCell>{log.response_rows ?? '-'}</TableCell>
                    <TableCell>{log.response_ms ? `${log.response_ms}ms` : '-'}</TableCell>
                    <TableCell><Typography variant="caption">{log.client_ip || '-'}</Typography></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUsageView(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PublishedViewsPage;
