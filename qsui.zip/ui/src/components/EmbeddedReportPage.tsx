import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import AssessmentIcon from '@mui/icons-material/Assessment';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import LinkOffIcon from '@mui/icons-material/LinkOff';

import { API_BASE_URL } from '../services/api/core';
const BASE_URL = API_BASE_URL.replace(/\/$/, '');

interface ReportParam {
  name: string;
  label?: string;
  type?: string;
  default_value?: string;
  required?: boolean;
}

interface ReportMeta {
  id: number;
  name: string;
  description?: string;
  parameters: ReportParam[];
}

interface ExecResult {
  columns: string[];
  rows: any[][];
  total_rows: number;
}

const fetchPublic = async (path: string, options?: RequestInit) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
  });
  if (res.status === 410) throw new Error('EXPIRED');
  if (res.status === 404) throw new Error('NOT_FOUND');
  if (!res.ok) throw new Error(await res.text());
  return res.json();
};

export default function EmbeddedReportPage() {
  const { token } = useParams<{ token: string }>();
  const [status, setStatus] = useState<'loading' | 'ready' | 'running' | 'done' | 'expired' | 'notfound' | 'error'>('loading');
  const [report, setReport] = useState<ReportMeta | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<ExecResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!token) { setStatus('notfound'); return; }
    fetchPublic(`/api/embedded-report/${token}`)
      .then(data => {
        setReport(data.report);
        const defaults: Record<string, string> = {};
        (data.report.parameters || []).forEach((p: ReportParam) => {
          if (p.default_value != null) defaults[p.name] = String(p.default_value);
        });
        setParamValues(defaults);
        setStatus('ready');
      })
      .catch(err => {
        if (err.message === 'EXPIRED') setStatus('expired');
        else if (err.message === 'NOT_FOUND') setStatus('notfound');
        else setStatus('error');
      });
  }, [token]);

  const handleRun = useCallback(async () => {
    if (!token) return;
    setStatus('running');
    setResult(null);
    try {
      const data = await fetchPublic(`/api/embedded-report/${token}/execute`, {
        method: 'POST',
        body: JSON.stringify({ param_values: paramValues, limit: 1000 }),
      });
      setResult(data);
      setStatus('done');
    } catch (err: any) {
      if (err.message === 'EXPIRED') setStatus('expired');
      else {
        setErrorMsg(err.message || 'Execution failed');
        setStatus('error');
      }
    }
  }, [token, paramValues]);

  // Auto-run if no parameters
  useEffect(() => {
    if (status === 'ready' && report && report.parameters.length === 0) {
      handleRun();
    }
  }, [status, report, handleRun]);

  // ── Error states ───────────────────────────────────────────────────────────
  if (status === 'expired') {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 2, p: 4 }}>
        <LinkOffIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
        <Typography variant="h5" fontWeight={600}>Embed Link Expired</Typography>
        <Typography color="text.secondary">This report link has expired. Contact the report owner to generate a new link.</Typography>
      </Box>
    );
  }
  if (status === 'notfound') {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 2, p: 4 }}>
        <ErrorOutlineIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
        <Typography variant="h5" fontWeight={600}>Report Not Found</Typography>
        <Typography color="text.secondary">This embed link is invalid or the report has been removed.</Typography>
      </Box>
    );
  }
  if (status === 'loading') {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh', bgcolor: 'background.default' }}>
      {/* Compact header */}
      <Box sx={{ px: 2, py: 1, bgcolor: 'primary.main', color: 'primary.contrastText', display: 'flex', alignItems: 'center', gap: 1 }}>
        <AssessmentIcon fontSize="small" />
        <Typography variant="subtitle1" fontWeight={600} sx={{ flex: 1 }}>{report?.name || 'Report'}</Typography>
        <Typography variant="caption" sx={{ opacity: 0.75 }}>Powered by QueryStudio</Typography>
      </Box>

      <Box sx={{ flex: 1, overflow: 'auto', p: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {report?.description && (
          <Typography variant="body2" color="text.secondary">{report.description}</Typography>
        )}

        {/* Parameter form */}
        {report && report.parameters.length > 0 && (
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="subtitle2" gutterBottom>Parameters</Typography>
            <Stack direction="row" flexWrap="wrap" gap={2} alignItems="flex-end">
              {report.parameters.map((p) => (
                <TextField
                  key={p.name}
                  label={p.label || p.name}
                  size="small"
                  value={paramValues[p.name] ?? ''}
                  onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                  required={p.required}
                  sx={{ minWidth: 160 }}
                />
              ))}
              <Button
                variant="contained"
                startIcon={<PlayArrowIcon />}
                onClick={handleRun}
                disabled={status === 'running'}
                size="small"
              >
                {status === 'running' ? 'Running…' : 'Run Report'}
              </Button>
            </Stack>
          </Paper>
        )}

        {status === 'running' && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={32} />
          </Box>
        )}

        {status === 'error' && (
          <Alert severity="error">{errorMsg || 'An error occurred running this report.'}</Alert>
        )}

        {/* Results table */}
        {result && (
          <Paper variant="outlined" sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ px: 2, py: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography variant="caption" color="text.secondary">
                {result.total_rows.toLocaleString()} row{result.total_rows !== 1 ? 's' : ''}
                {result.total_rows > 1000 ? ' (showing first 1,000)' : ''}
              </Typography>
            </Box>
            <Divider />
            <Box sx={{ flex: 1, overflow: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr>
                    {result.columns.map((col) => (
                      <th key={col} style={{ padding: '6px 12px', textAlign: 'left', borderBottom: '1px solid rgba(0,0,0,0.12)', background: 'rgba(0,0,0,0.04)', position: 'sticky', top: 0, whiteSpace: 'nowrap' }}>
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {result.rows.map((row, ri) => (
                    <tr key={ri} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                      {row.map((cell, ci) => (
                        <td key={ci} style={{ padding: '5px 12px', whiteSpace: 'nowrap' }}>
                          {cell == null ? '' : String(cell)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </Box>
          </Paper>
        )}
      </Box>
    </Box>
  );
}
