/**
 * Phase 111-H: Unified Report Viewer — auto-detects report type and delegates.
 *
 * Loads the business report by ID, checks data_source_type and layout_config,
 * then renders the appropriate viewer:
 *   - pivot (layout_config.report_type === 'pivot') → PivotReportViewer
 *   - raw_sql → inline viewer with parameter form + DataGridViewer
 *   - default (tabular) → BusinessReportViewer
 */
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, Alert, Chip, Skeleton,
  TextField, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TableSortLabel, Menu, MenuItem, ListItemIcon, ListItemText,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import EditIcon from '@mui/icons-material/Edit';
import GetAppIcon from '@mui/icons-material/GetApp';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableViewIcon from '@mui/icons-material/TableView';
import api from '../services/api';

const BusinessReportViewer = lazy(() => import('./BusinessReportViewer'));
const PivotReportViewer = lazy(() => import('./PivotReportViewer'));

const fallback = (
  <Box sx={{ p: 3 }}>
    <Skeleton variant="text" width={300} height={40} sx={{ mb: 2 }} />
    <Skeleton variant="rectangular" height={100} sx={{ mb: 2, borderRadius: 1 }} />
    <Skeleton variant="rectangular" height={300} sx={{ borderRadius: 1 }} />
  </Box>
);

const UnifiedReportViewer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.getBusinessReport(Number(id))
      .then((data: any) => setReport(data))
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return fallback;
  if (error) return <Alert severity="error" sx={{ m: 3 }}>{error}</Alert>;
  if (!report) return <Alert severity="warning" sx={{ m: 3 }}>Report not found</Alert>;

  const dst = report.data_source_type || 'saved_query';
  const lc = report.layout_config || {};

  // Pivot report → PivotReportViewer
  if (lc.report_type === 'pivot') {
    return (
      <Suspense fallback={fallback}>
        <PivotReportViewer />
      </Suspense>
    );
  }

  // Raw SQL report → inline viewer
  if (dst === 'raw_sql') {
    return <RawSqlReportViewer report={report} />;
  }

  // Default: tabular → BusinessReportViewer
  return (
    <Suspense fallback={fallback}>
      <BusinessReportViewer />
    </Suspense>
  );
};

// ── Inline Raw SQL Report Viewer ────────────────────────────────────────────

interface RawSqlViewerProps {
  report: any;
}

const RawSqlReportViewer: React.FC<RawSqlViewerProps> = ({ report }) => {
  const navigate = useNavigate();
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  const [resultData, setResultData] = useState<{ columns: string[]; rows: any[] } | null>(null);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  const handleExecuteRef = React.useRef<() => void>(() => {});
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [totalRows, setTotalRows] = useState(0);

  const params = report.raw_parameters_schema || [];

  // Initialize default values + auto-execute if no required params
  const autoExecuted = React.useRef(false);
  useEffect(() => {
    const defaults: Record<string, string> = {};
    for (const p of params) {
      if (p.default_value) defaults[p.name] = p.default_value;
    }
    setParamValues(defaults);
    autoExecuted.current = false;
  }, [report.id]);

  // Auto-execute on first load if there are no required params without defaults
  useEffect(() => {
    if (autoExecuted.current) return;
    const hasRequiredMissing = params.some(
      (p: any) => p.required && !p.default_value
    );
    if (!hasRequiredMissing) {
      autoExecuted.current = true;
      handleExecuteRef.current();
    }
  }, [paramValues]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadPage = React.useCallback(async (execId: string, pg: number, ps: number, sc?: string | null, sd?: string) => {
    try {
      const pageData = await api.getBusinessReportPagedResults(
        report.id, execId, pg + 1, ps, sc, sd
      );
      if (pageData?.columns && pageData?.rows) {
        setResultData(pageData);
        setTotalRows(pageData.total_rows ?? pageData.rows.length);
      }
    } catch {
      // Paged results may not be available
    }
  }, [report.id]);

  const handleExecute = React.useCallback(async () => {
    setExecuting(true);
    setError('');
    setResult(null);
    setResultData(null);
    setPage(0);
    try {
      const res = await api.executeBusinessReport(report.id, {
        parameter_values: paramValues,
      });
      setResult(res);
      setTotalRows(res?.total_rows ?? 0);

      if (res?.execution_id) {
        await loadPage(res.execution_id, 0, rowsPerPage, sortCol, sortDir);
      }
    } catch (err: any) {
      setError(err?.message || 'Execution failed');
    } finally {
      setExecuting(false);
    }
  }, [report.id, paramValues, rowsPerPage, sortCol, sortDir, loadPage]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep ref in sync for auto-execute
  handleExecuteRef.current = handleExecute;

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/business-reports')}>
          Back
        </Button>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>{report.name}</Typography>
        <Chip label="Raw SQL" size="small" color="info" />
        <Button size="small" startIcon={<EditIcon />}
          onClick={() => navigate(`/business-reports/${report.id}/edit`)}>
          Edit
        </Button>
        <Button variant="contained" startIcon={<PlayArrowIcon />}
          onClick={handleExecute} disabled={executing}>
          {executing ? 'Running...' : 'Execute'}
        </Button>
        <Button variant="outlined" size="small" startIcon={<GetAppIcon />}
          onClick={(e) => setExportAnchor(e.currentTarget)}
          disabled={!resultData}>Export</Button>
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
          onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportExcel(report.id, paramValues); } catch (e: any) { setError(e?.message || 'Excel export failed'); } }}>
            <ListItemIcon><TableViewIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Excel (formatted)</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportPDF(report.id, paramValues); } catch (e: any) { setError(e?.message || 'PDF export failed'); } }}>
            <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
            <ListItemText>PDF</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportCSV(report.id, paramValues); } catch (e: any) { setError(e?.message || 'CSV export failed'); } }}>
            <ListItemIcon><GetAppIcon fontSize="small" /></ListItemIcon>
            <ListItemText>CSV (raw data)</ListItemText>
          </MenuItem>
        </Menu>
      </Box>

      {report.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {report.description}
        </Typography>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Parameter form */}
      {params.length > 0 && (
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Parameters</Typography>
          <Grid container spacing={2}>
            {params.map((p: any) => (
              <Grid key={p.name} size={{ xs: 12, sm: 6, md: 4 }}>
                <TextField
                  label={p.label || p.name}
                  size="small"
                  fullWidth
                  type={p.type === 'number' ? 'number' : p.type === 'date' ? 'date' : 'text'}
                  value={paramValues[p.name] || ''}
                  onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                  required={p.required}
                  InputLabelProps={p.type === 'date' ? { shrink: true } : undefined}
                  helperText={p.description}
                />
              </Grid>
            ))}
          </Grid>
        </Paper>
      )}

      {/* Result summary */}
      {result && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2">Result</Typography>
          <Box sx={{ display: 'flex', gap: 3, mt: 1 }}>
            <Typography variant="body2">Rows: <strong>{result.total_rows ?? '-'}</strong></Typography>
            <Typography variant="body2">Duration: <strong>{result.duration_seconds ?? '-'}s</strong></Typography>
            <Typography variant="body2">Execution: <code>{result.execution_id?.slice(0, 8) || '-'}</code></Typography>
          </Box>
        </Paper>
      )}

      {/* Result data table with pagination */}
      {resultData && resultData.columns.length > 0 && (
        <Paper>
          <TableContainer sx={{ maxHeight: 500 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  {resultData.columns.map(col => (
                    <TableCell key={col} sx={{ fontWeight: 'bold', whiteSpace: 'nowrap' }}>
                      <TableSortLabel
                        active={sortCol === col}
                        direction={sortCol === col ? sortDir : 'asc'}
                        onClick={() => {
                          const newDir = sortCol === col && sortDir === 'asc' ? 'desc' : 'asc';
                          setSortCol(col);
                          setSortDir(newDir);
                          if (result?.execution_id) {
                            loadPage(result.execution_id, page, rowsPerPage, col, newDir);
                          }
                        }}
                      >
                        {col}
                      </TableSortLabel>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {resultData.rows.map((row: any, ri: number) => (
                  <TableRow key={ri} hover>
                    {resultData.columns.map(col => (
                      <TableCell key={col} sx={{ whiteSpace: 'nowrap' }}>
                        {row[col] ?? ''}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div"
            count={totalRows}
            page={page}
            onPageChange={(_, newPage) => {
              setPage(newPage);
              if (result?.execution_id) {
                loadPage(result.execution_id, newPage, rowsPerPage, sortCol, sortDir);
              }
            }}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              const newRpp = parseInt(e.target.value, 10);
              setRowsPerPage(newRpp);
              setPage(0);
              if (result?.execution_id) {
                loadPage(result.execution_id, 0, newRpp, sortCol, sortDir);
              }
            }}
            rowsPerPageOptions={[25, 50, 100, 200]}
          />
        </Paper>
      )}
    </Box>
  );
};

export default UnifiedReportViewer;
