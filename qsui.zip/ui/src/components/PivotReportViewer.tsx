/**
 * Phase 106 — Pivot Report Viewer
 *
 * Loads a BusinessReport with layout_config.report_type === "pivot",
 * prompts for parameters, executes the report (which returns flat grouped rows),
 * and renders a crosstab table client-side.
 */
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  CircularProgress, Alert, TextField, Select, MenuItem, FormControl, InputLabel,
  Collapse, Tooltip, Menu, ListItemIcon, ListItemText,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  PlayArrow as PlayIcon,
  Edit as EditIcon,
  GetApp as ExportIcon,
  PictureAsPdf as PdfIcon,
  TableView as ExcelIcon,
  ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon,
  TableChart as PivotIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { applyFormatPattern } from '../utils/formatters';
import { resolveParamDefault } from '../utils/parameterUtils';
import { useParamLovs } from '../hooks/useParamLovs';

// ── Types ────────────────────────────────────────────────────────────────────

interface PivotValueField {
  column_id: number;
  aggregation: string;
}

interface PivotConfig {
  row_field_ids: number[];
  col_field_ids: number[];
  value_fields: PivotValueField[];
  show_row_totals: boolean;
  show_col_totals: boolean;
  show_grand_total: boolean;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

const isNumber = (v: any): v is number =>
  typeof v === 'number' && !Number.isNaN(v);

const formatNumber = (v: any, formatPattern?: string, dataType?: string): string => {
  if (v === null || v === undefined || v === '') return '';
  if (formatPattern) {
    const formatted = applyFormatPattern(v, formatPattern, dataType);
    if (formatted !== null && formatted !== undefined) return String(formatted);
  }
  if (isNumber(v)) {
    return Number.isInteger(v) ? v.toLocaleString() : v.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  return String(v);
};

const aggregateValues = (vals: any[], agg: string): number | null => {
  const nums = vals.filter(isNumber) as number[];
  if (nums.length === 0) return null;
  switch (agg.toLowerCase()) {
    case 'sum':
      return nums.reduce((a, b) => a + b, 0);
    case 'avg':
      return nums.reduce((a, b) => a + b, 0) / nums.length;
    case 'min':
      return Math.min(...nums);
    case 'max':
      return Math.max(...nums);
    case 'count':
      return nums.length;
    case 'count_distinct':
      return new Set(nums).size;
    default:
      return nums.reduce((a, b) => a + b, 0);
  }
};

// ── Component ────────────────────────────────────────────────────────────────

const PivotReportViewer: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const reportId = Number(id);

  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [executing, setExecuting] = useState(false);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);

  const [rawRows, setRawRows] = useState<any[]>([]);
  const [resultColumns, setResultColumns] = useState<string[]>([]);
  const [pivotConfig, setPivotConfig] = useState<PivotConfig | null>(null);

  const [datasetColumns, setDatasetColumns] = useState<any[]>([]);
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  const [paramsPanelOpen, setParamsPanelOpen] = useState(true);

  // ── Load report ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (!reportId) return;
    setLoading(true);
    api.getBusinessReport(reportId)
      .then((r: any) => {
        setReport(r);
        // verify pivot type
        const lc = r.layout_config || {};
        if (lc.report_type !== 'pivot') {
          setError('This report is not a pivot report. Use the regular Business Report viewer.');
          return;
        }
        // initialise param defaults (resolve @TODAY macros via shared util)
        const defaults: Record<string, any> = {};
        for (const p of (r.parameters || [])) {
          defaults[p.name] = resolveParamDefault(p);
        }
        setParamValues(defaults);
        return api.getDataset(r.dataset_id);
      })
      .then((ds: any) => {
        if (ds) setDatasetColumns(ds.columns || []);
      })
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [reportId]);

  // ── Shared LOV hook (cascade-aware, parallel loading) ─────────────────────
  const paramLovs = useParamLovs({ reportId, parameters: report?.parameters, paramValues });

  // ── Column metadata helpers ───────────────────────────────────────────────

  const getColMeta = useCallback((colId: number) => {
    return datasetColumns.find((c: any) => c.id === colId);
  }, [datasetColumns]);

  const getColPhysicalName = useCallback((colId: number): string => {
    const c = getColMeta(colId);
    return c?.physical_name || `col_${colId}`;
  }, [getColMeta]);

  const getColDisplayName = useCallback((colId: number): string => {
    const c = getColMeta(colId);
    return c ? (c.friendly_name || c.physical_name) : `Col #${colId}`;
  }, [getColMeta]);

  // ── Execute report ────────────────────────────────────────────────────────

  const handleExecute = async () => {
    if (!report) return;
    setExecuting(true);
    setError('');

    try {
      const result = await api.executeBusinessReport(reportId, {
        parameter_values: paramValues,
        extra_filters: [],
      });

      // Backend returns FederationResult-shaped dict (rows + columns) or {data, columns}
      let rows: any[] = [];
      let cols: string[] = [];
      if (Array.isArray(result.rows)) {
        rows = result.rows;
        cols = (result.columns || []).map((c: any) => typeof c === 'string' ? c : (c.name || c.column_name || ''));
      } else if (Array.isArray(result.data)) {
        rows = result.data;
        cols = (result.columns || []).map((c: any) => typeof c === 'string' ? c : (c.name || c.column_name || ''));
      } else if (result.output_path) {
        // FederationResult with parquet output — fetch via paged endpoint
        const exec = result.execution_id || (result as any).execution_id;
        if (exec) {
          const paged = await api.getBusinessReportPagedResults(reportId, exec, 1, 50000);
          rows = paged.rows || [];
          cols = paged.columns || [];
        }
      }
      setRawRows(rows);
      setResultColumns(cols);
      // Pivot config comes back from execute response (Phase 106 dispatch)
      if (result.pivot_config) {
        setPivotConfig(result.pivot_config);
      } else {
        // Fall back to layout_config
        setPivotConfig(report.layout_config?.pivot_config || null);
      }
      setParamsPanelOpen(false);
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Execution failed');
    } finally {
      setExecuting(false);
    }
  };

  // ── Client-side pivot transform ───────────────────────────────────────────
  // Transforms flat grouped rows into a crosstab matrix.
  // Each row already has unique combination of (row_dims + col_dims) plus aggregated measures.

  const pivotMatrix = useMemo(() => {
    if (!pivotConfig || rawRows.length === 0) return null;

    const rowFieldNames = pivotConfig.row_field_ids.map(getColPhysicalName);
    const colFieldNames = pivotConfig.col_field_ids.map(getColPhysicalName);
    const valueFieldNames = pivotConfig.value_fields.map(vf => getColPhysicalName(vf.column_id));
    const valueFieldKeys = pivotConfig.value_fields.map(vf => `${getColPhysicalName(vf.column_id)}__${vf.aggregation}`);

    // Build unique row keys (tuple of row dim values) and column keys (tuple of col dim values)
    const rowKeyOf = (row: any): string =>
      rowFieldNames.map(n => String(row[n] ?? '∅')).join('||');
    const colKeyOf = (row: any): string =>
      colFieldNames.length === 0 ? '__total__' : colFieldNames.map(n => String(row[n] ?? '∅')).join('||');

    const rowKeys: string[] = [];
    const colKeys: string[] = [];
    const seenRow = new Set<string>();
    const seenCol = new Set<string>();
    const rowKeyToValues = new Map<string, any[]>();   // rowKey → array of row dim raw values (for header rendering)
    const colKeyToValues = new Map<string, any[]>();   // colKey → array of col dim raw values
    const cells = new Map<string, Map<string, Record<string, any>>>(); // rowKey → colKey → {valueField: value}

    for (const row of rawRows) {
      const rk = rowKeyOf(row);
      const ck = colKeyOf(row);
      if (!seenRow.has(rk)) {
        seenRow.add(rk);
        rowKeys.push(rk);
        rowKeyToValues.set(rk, rowFieldNames.map(n => row[n]));
      }
      if (!seenCol.has(ck)) {
        seenCol.add(ck);
        colKeys.push(ck);
        colKeyToValues.set(ck, colFieldNames.map(n => row[n]));
      }
      if (!cells.has(rk)) cells.set(rk, new Map());
      const rowMap = cells.get(rk)!;
      if (!rowMap.has(ck)) rowMap.set(ck, {});
      const cell = rowMap.get(ck)!;
      // Store each measure value (already aggregated by SQL — just take it as-is)
      // If the same (rk, ck) appears more than once (shouldn't with proper GROUP BY) we sum.
      for (let i = 0; i < pivotConfig.value_fields.length; i++) {
        const physName = valueFieldNames[i];
        const v = row[physName];
        if (cell[physName] === undefined) {
          cell[physName] = v;
        } else if (isNumber(cell[physName]) && isNumber(v)) {
          cell[physName] = cell[physName] + v;
        }
      }
    }

    // Sort row & col keys naturally by their first dimension value
    const naturalCmp = (a: any, b: any) => {
      if (a == null && b == null) return 0;
      if (a == null) return 1;
      if (b == null) return -1;
      if (typeof a === 'number' && typeof b === 'number') return a - b;
      return String(a).localeCompare(String(b));
    };
    rowKeys.sort((a, b) => {
      const av = rowKeyToValues.get(a) || [];
      const bv = rowKeyToValues.get(b) || [];
      for (let i = 0; i < av.length; i++) {
        const c = naturalCmp(av[i], bv[i]);
        if (c !== 0) return c;
      }
      return 0;
    });
    colKeys.sort((a, b) => {
      const av = colKeyToValues.get(a) || [];
      const bv = colKeyToValues.get(b) || [];
      for (let i = 0; i < av.length; i++) {
        const c = naturalCmp(av[i], bv[i]);
        if (c !== 0) return c;
      }
      return 0;
    });

    // Compute row totals (across all cols)
    const rowTotals = new Map<string, Record<string, number>>();
    if (pivotConfig.show_row_totals && colFieldNames.length > 0) {
      for (const rk of rowKeys) {
        const totals: Record<string, number> = {};
        for (const vf of pivotConfig.value_fields) {
          const physName = getColPhysicalName(vf.column_id);
          const vals: any[] = [];
          for (const ck of colKeys) {
            const cell = cells.get(rk)?.get(ck);
            if (cell && cell[physName] !== undefined) vals.push(cell[physName]);
          }
          const agg = aggregateValues(vals, vf.aggregation);
          if (agg !== null) totals[physName] = agg;
        }
        rowTotals.set(rk, totals);
      }
    }

    // Compute col totals (across all rows)
    const colTotals = new Map<string, Record<string, number>>();
    if (pivotConfig.show_col_totals) {
      for (const ck of colKeys) {
        const totals: Record<string, number> = {};
        for (const vf of pivotConfig.value_fields) {
          const physName = getColPhysicalName(vf.column_id);
          const vals: any[] = [];
          for (const rk of rowKeys) {
            const cell = cells.get(rk)?.get(ck);
            if (cell && cell[physName] !== undefined) vals.push(cell[physName]);
          }
          const agg = aggregateValues(vals, vf.aggregation);
          if (agg !== null) totals[physName] = agg;
        }
        colTotals.set(ck, totals);
      }
    }

    // Compute grand total
    const grandTotals: Record<string, number> = {};
    if (pivotConfig.show_grand_total) {
      for (const vf of pivotConfig.value_fields) {
        const physName = getColPhysicalName(vf.column_id);
        const allVals: any[] = [];
        for (const rk of rowKeys) {
          for (const ck of colKeys) {
            const cell = cells.get(rk)?.get(ck);
            if (cell && cell[physName] !== undefined) allVals.push(cell[physName]);
          }
        }
        const agg = aggregateValues(allVals, vf.aggregation);
        if (agg !== null) grandTotals[physName] = agg;
      }
    }

    return {
      rowFieldNames,
      colFieldNames,
      valueFieldNames,
      valueFieldKeys,
      rowKeys,
      colKeys,
      rowKeyToValues,
      colKeyToValues,
      cells,
      rowTotals,
      colTotals,
      grandTotals,
      hasColDims: colFieldNames.length > 0,
    };
  }, [rawRows, pivotConfig, getColPhysicalName]);

  // ── Format helper for measure cells ───────────────────────────────────────

  const formatMeasureCell = useCallback((colId: number, value: any): string => {
    const meta = getColMeta(colId);
    if (!meta) return formatNumber(value);
    return formatNumber(value, meta.format_pattern, meta.data_type);
  }, [getColMeta]);

  // ── CSV Export ────────────────────────────────────────────────────────────

  const handleExport = () => {
    if (!pivotMatrix || !pivotConfig) return;
    const lines: string[] = [];
    const m = pivotMatrix;

    // Header rows: col-dim values × value-fields
    if (m.hasColDims) {
      // First header row: col dim labels
      const topHeader = [...m.rowFieldNames.map(n => getDisplayNameByPhys(n))];
      for (const ck of m.colKeys) {
        const labels = m.colKeyToValues.get(ck) || [];
        const colHeader = labels.join(' / ');
        for (const vf of pivotConfig.value_fields) {
          topHeader.push(`${colHeader} — ${getColDisplayName(vf.column_id)} [${vf.aggregation.toUpperCase()}]`);
        }
      }
      if (pivotConfig.show_row_totals) {
        for (const vf of pivotConfig.value_fields) {
          topHeader.push(`Total ${getColDisplayName(vf.column_id)} [${vf.aggregation.toUpperCase()}]`);
        }
      }
      lines.push(topHeader.map(csvEscape).join(','));
    } else {
      const topHeader = [...m.rowFieldNames.map(n => getDisplayNameByPhys(n))];
      for (const vf of pivotConfig.value_fields) {
        topHeader.push(`${getColDisplayName(vf.column_id)} [${vf.aggregation.toUpperCase()}]`);
      }
      lines.push(topHeader.map(csvEscape).join(','));
    }

    // Data rows
    for (const rk of m.rowKeys) {
      const rowVals = m.rowKeyToValues.get(rk) || [];
      const cells: string[] = rowVals.map(v => v == null ? '' : String(v));
      if (m.hasColDims) {
        for (const ck of m.colKeys) {
          for (const vf of pivotConfig.value_fields) {
            const cell = m.cells.get(rk)?.get(ck);
            const v = cell?.[getColPhysicalName(vf.column_id)];
            cells.push(v == null ? '' : String(v));
          }
        }
        if (pivotConfig.show_row_totals) {
          const totals = m.rowTotals.get(rk) || {};
          for (const vf of pivotConfig.value_fields) {
            const v = totals[getColPhysicalName(vf.column_id)];
            cells.push(v == null ? '' : String(v));
          }
        }
      } else {
        const cell = m.cells.get(rk)?.get('__total__');
        for (const vf of pivotConfig.value_fields) {
          const v = cell?.[getColPhysicalName(vf.column_id)];
          cells.push(v == null ? '' : String(v));
        }
      }
      lines.push(cells.map(csvEscape).join(','));
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report?.name || 'pivot-report'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getColIdByName = (physName: string): number => {
    const c = datasetColumns.find((c: any) => c.physical_name === physName);
    return c?.id ?? -1;
  };

  const getDisplayNameByPhys = (physName: string): string => {
    const colId = getColIdByName(physName);
    return colId >= 0 ? getColDisplayName(colId) : physName;
  };

  // ── Render: Loading / Error ───────────────────────────────────────────────

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error && !report) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
        <Button onClick={() => navigate('/business-reports')} startIcon={<ArrowBackIcon />} sx={{ mt: 2 }}>
          Back to Reports
        </Button>
      </Box>
    );
  }

  if (!report) return null;

  const username = (api as any).currentUser?.username || '';
  const canEdit = !report.is_published || (report.owner === username);

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/business-reports')}>
          <ArrowBackIcon />
        </IconButton>
        <PivotIcon sx={{ ml: 1, mr: 1, color: '#1976d2' }} />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5">{report.name}</Typography>
          {report.description && (
            <Typography variant="body2" color="text.secondary">{report.description}</Typography>
          )}
        </Box>
        <Chip label="Pivot Report" size="small" color="primary" variant="outlined" sx={{ mr: 1 }} />
        {canEdit && (
          <Tooltip title="Edit pivot report">
            <IconButton onClick={() => navigate(`/pivot-reports/${reportId}/edit`)}>
              <EditIcon />
            </IconButton>
          </Tooltip>
        )}
        <Button variant="outlined" size="small" startIcon={<ExportIcon />}
          onClick={(e) => setExportAnchor(e.currentTarget)}
          disabled={!pivotMatrix || rawRows.length === 0}>Export</Button>
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
          onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportExcel(reportId, paramValues); } catch (e: any) { setError(e?.message || 'Excel export failed'); } }}>
            <ListItemIcon><ExcelIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Excel (formatted)</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportPDF(reportId, paramValues); } catch (e: any) { setError(e?.message || 'PDF export failed'); } }}>
            <ListItemIcon><PdfIcon fontSize="small" /></ListItemIcon>
            <ListItemText>PDF</ListItemText>
          </MenuItem>
          <MenuItem onClick={() => { setExportAnchor(null); handleExport(); }}>
            <ListItemIcon><ExportIcon fontSize="small" /></ListItemIcon>
            <ListItemText>CSV (client-side)</ListItemText>
          </MenuItem>
        </Menu>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Parameters panel */}
      {report.parameters && report.parameters.length > 0 && (
        <Paper elevation={1} sx={{ p: 2, mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
               onClick={() => setParamsPanelOpen(o => !o)}>
            <Typography variant="subtitle1" sx={{ flex: 1 }}>Parameters</Typography>
            <IconButton size="small">
              {paramsPanelOpen ? <CollapseIcon /> : <ExpandIcon />}
            </IconButton>
          </Box>
          <Collapse in={paramsPanelOpen}>
            <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              {report.parameters.map((p: any) => {
                const labelWithRequired = p.is_required ? `${p.label} *` : p.label;
                if (p.parameter_type === 'dropdown' || p.parameter_type === 'multi_select') {
                  const lovs = paramLovs[p.id] || [];
                  return (
                    <FormControl key={p.id} size="small" sx={{ minWidth: 200 }}>
                      <InputLabel>{labelWithRequired}</InputLabel>
                      <Select label={labelWithRequired}
                              value={paramValues[p.name] || (p.parameter_type === 'multi_select' ? [] : '')}
                              multiple={p.parameter_type === 'multi_select'}
                              onChange={e => {
                                const newVal = e.target.value;
                                setParamValues(prev => {
                                  const next = { ...prev, [p.name]: newVal };
                                  // Clear dependent children when parent changes
                                  for (const child of (report.parameters || [])) {
                                    if (child.depends_on_param_id === p.id) {
                                      next[child.name] = child.parameter_type === 'multi_select' ? [] : '';
                                    }
                                  }
                                  return next;
                                });
                              }}>
                        {!p.is_required && <MenuItem value=""><em>All</em></MenuItem>}
                        {lovs.map(v => <MenuItem key={String(v)} value={v}>{String(v)}</MenuItem>)}
                      </Select>
                    </FormControl>
                  );
                }
                if (p.parameter_type === 'date' || p.parameter_type === 'date_range') {
                  return (
                    <Box key={p.id} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                      <TextField size="small" type="date"
                        label={labelWithRequired + (p.parameter_type === 'date_range' ? ' From' : '')}
                        InputLabelProps={{ shrink: true }}
                        value={p.parameter_type === 'date_range' ? (paramValues[p.name]?.from || '') : (paramValues[p.name] || '')}
                        onChange={e => {
                          if (p.parameter_type === 'date_range') {
                            setParamValues(prev => ({
                              ...prev,
                              [p.name]: { ...(prev[p.name] || {}), from: e.target.value },
                            }));
                          } else {
                            setParamValues(prev => ({ ...prev, [p.name]: e.target.value }));
                          }
                        }}
                        sx={{ minWidth: 180 }} />
                      {p.parameter_type === 'date_range' && (
                        <TextField size="small" type="date"
                          label={labelWithRequired + ' To'}
                          InputLabelProps={{ shrink: true }}
                          value={paramValues[p.name]?.to || ''}
                          onChange={e => setParamValues(prev => ({
                            ...prev,
                            [p.name]: { ...(prev[p.name] || {}), to: e.target.value },
                          }))}
                          sx={{ minWidth: 180 }} />
                      )}
                    </Box>
                  );
                }
                return (
                  <TextField key={p.id} size="small"
                    label={labelWithRequired}
                    value={paramValues[p.name] || ''}
                    onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                    sx={{ minWidth: 180 }} />
                );
              })}
            </Box>
          </Collapse>
        </Paper>
      )}

      {/* Execute button */}
      <Box sx={{ mb: 2 }}>
        <Button variant="contained" startIcon={<PlayIcon />}
                onClick={handleExecute} disabled={executing}>
          {executing ? 'Executing…' : 'Run Pivot Report'}
        </Button>
        {rawRows.length > 0 && (
          <Chip
            label={`${rawRows.length.toLocaleString()} grouped rows`}
            size="small"
            sx={{ ml: 2 }}
          />
        )}
      </Box>

      {executing && <LinearLoading />}

      {/* Pivot Table */}
      {!executing && pivotMatrix && pivotConfig && (
        <Paper elevation={2} sx={{ overflow: 'auto', maxHeight: '70vh' }}>
          <TableContainer>
            <Table size="small" stickyHeader>
              <TableHead>
                {/* Header row 1: column-dimension headers */}
                {pivotMatrix.hasColDims && (
                  <TableRow>
                    {pivotMatrix.rowFieldNames.map((name, i) => (
                      <TableCell key={`rowdim-h1-${i}`}
                                 sx={{ position: 'sticky', left: 0, bgcolor: '#e3f2fd', fontWeight: 700, zIndex: 3 }}
                                 rowSpan={2}>
                        {getColDisplayName(pivotConfig.row_field_ids[i])}
                      </TableCell>
                    ))}
                    {pivotMatrix.colKeys.map((ck, ci) => {
                      const labels = pivotMatrix.colKeyToValues.get(ck) || [];
                      return (
                        <TableCell key={`colhdr-${ci}`}
                                   colSpan={pivotConfig.value_fields.length}
                                   sx={{ bgcolor: '#bbdefb', fontWeight: 700, textAlign: 'center', borderLeft: '1px solid #90caf9' }}>
                          {labels.map(v => v == null ? '∅' : String(v)).join(' / ')}
                        </TableCell>
                      );
                    })}
                    {pivotConfig.show_row_totals && (
                      <TableCell colSpan={pivotConfig.value_fields.length}
                                 sx={{ bgcolor: '#90caf9', fontWeight: 700, textAlign: 'center', borderLeft: '2px solid #1976d2' }}>
                        Total
                      </TableCell>
                    )}
                  </TableRow>
                )}
                {/* Header row 2: measure labels under each col-dim */}
                <TableRow>
                  {!pivotMatrix.hasColDims && pivotMatrix.rowFieldNames.map((name, i) => (
                    <TableCell key={`rowdim-h2-${i}`}
                               sx={{ position: 'sticky', left: 0, bgcolor: '#e3f2fd', fontWeight: 700, zIndex: 3 }}>
                      {getColDisplayName(pivotConfig.row_field_ids[i])}
                    </TableCell>
                  ))}
                  {pivotMatrix.hasColDims && pivotMatrix.colKeys.map((ck, ci) => (
                    pivotConfig.value_fields.map((vf, vi) => (
                      <TableCell key={`measureheader-${ci}-${vi}`}
                                 sx={{ bgcolor: '#e1f5fe', fontWeight: 600, textAlign: 'right',
                                       borderLeft: vi === 0 ? '1px solid #90caf9' : undefined }}>
                        {getColDisplayName(vf.column_id)}
                        <Typography component="span" variant="caption" sx={{ ml: 0.5, color: 'text.secondary' }}>
                          [{vf.aggregation.toUpperCase()}]
                        </Typography>
                      </TableCell>
                    ))
                  ))}
                  {!pivotMatrix.hasColDims && pivotConfig.value_fields.map((vf, vi) => (
                    <TableCell key={`measureheader-flat-${vi}`}
                               sx={{ bgcolor: '#e1f5fe', fontWeight: 600, textAlign: 'right' }}>
                      {getColDisplayName(vf.column_id)}
                      <Typography component="span" variant="caption" sx={{ ml: 0.5, color: 'text.secondary' }}>
                        [{vf.aggregation.toUpperCase()}]
                      </Typography>
                    </TableCell>
                  ))}
                  {pivotMatrix.hasColDims && pivotConfig.show_row_totals && pivotConfig.value_fields.map((vf, vi) => (
                    <TableCell key={`rowtotal-h-${vi}`}
                               sx={{ bgcolor: '#90caf9', fontWeight: 700, textAlign: 'right',
                                     borderLeft: vi === 0 ? '2px solid #1976d2' : undefined }}>
                      {getColDisplayName(vf.column_id)}
                      <Typography component="span" variant="caption" sx={{ ml: 0.5 }}>
                        [{vf.aggregation.toUpperCase()}]
                      </Typography>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {pivotMatrix.rowKeys.map((rk, ri) => {
                  const rowVals = pivotMatrix.rowKeyToValues.get(rk) || [];
                  return (
                    <TableRow key={`row-${ri}`} hover>
                      {rowVals.map((v, ci) => (
                        <TableCell key={`rk-${ri}-${ci}`}
                                   sx={{ position: 'sticky', left: 0, bgcolor: '#f5f5f5', fontWeight: 500, zIndex: 1 }}>
                          {v == null ? <span style={{ color: '#aaa' }}>—</span> : String(v)}
                        </TableCell>
                      ))}
                      {pivotMatrix.hasColDims ? (
                        pivotMatrix.colKeys.map((ck, ci) => {
                          const cell = pivotMatrix.cells.get(rk)?.get(ck);
                          return pivotConfig.value_fields.map((vf, vi) => {
                            const physName = getColPhysicalName(vf.column_id);
                            const v = cell?.[physName];
                            return (
                              <TableCell key={`cell-${ri}-${ci}-${vi}`}
                                         sx={{ textAlign: 'right',
                                               borderLeft: vi === 0 ? '1px solid #e0e0e0' : undefined }}>
                                {v == null ? <span style={{ color: '#aaa' }}>—</span>
                                          : formatMeasureCell(vf.column_id, v)}
                              </TableCell>
                            );
                          });
                        })
                      ) : (
                        // No col dims — flat grouped output
                        pivotConfig.value_fields.map((vf, vi) => {
                          const physName = getColPhysicalName(vf.column_id);
                          const cell = pivotMatrix.cells.get(rk)?.get('__total__');
                          const v = cell?.[physName];
                          return (
                            <TableCell key={`flatcell-${ri}-${vi}`} sx={{ textAlign: 'right' }}>
                              {v == null ? <span style={{ color: '#aaa' }}>—</span>
                                        : formatMeasureCell(vf.column_id, v)}
                            </TableCell>
                          );
                        })
                      )}
                      {pivotMatrix.hasColDims && pivotConfig.show_row_totals && (
                        pivotConfig.value_fields.map((vf, vi) => {
                          const physName = getColPhysicalName(vf.column_id);
                          const v = pivotMatrix.rowTotals.get(rk)?.[physName];
                          return (
                            <TableCell key={`rowtotal-${ri}-${vi}`}
                                       sx={{ textAlign: 'right', bgcolor: '#e3f2fd', fontWeight: 600,
                                             borderLeft: vi === 0 ? '2px solid #1976d2' : undefined }}>
                              {v == null ? '' : formatMeasureCell(vf.column_id, v)}
                            </TableCell>
                          );
                        })
                      )}
                    </TableRow>
                  );
                })}

                {/* Column totals row */}
                {pivotConfig.show_col_totals && pivotMatrix.hasColDims && (
                  <TableRow sx={{ bgcolor: '#e8eaf6' }}>
                    <TableCell colSpan={pivotMatrix.rowFieldNames.length}
                               sx={{ position: 'sticky', left: 0, bgcolor: '#e8eaf6', fontWeight: 700, zIndex: 1 }}>
                      Total
                    </TableCell>
                    {pivotMatrix.colKeys.map((ck, ci) => (
                      pivotConfig.value_fields.map((vf, vi) => {
                        const physName = getColPhysicalName(vf.column_id);
                        const v = pivotMatrix.colTotals.get(ck)?.[physName];
                        return (
                          <TableCell key={`coltotal-${ci}-${vi}`}
                                     sx={{ textAlign: 'right', fontWeight: 700,
                                           borderLeft: vi === 0 ? '1px solid #c5cae9' : undefined }}>
                            {v == null ? '' : formatMeasureCell(vf.column_id, v)}
                          </TableCell>
                        );
                      })
                    ))}
                    {pivotConfig.show_row_totals && pivotConfig.value_fields.map((vf, vi) => {
                      const physName = getColPhysicalName(vf.column_id);
                      const v = pivotMatrix.grandTotals[physName];
                      return (
                        <TableCell key={`grand-${vi}`}
                                   sx={{ textAlign: 'right', fontWeight: 800, bgcolor: '#c5cae9',
                                         borderLeft: vi === 0 ? '2px solid #1976d2' : undefined }}>
                          {v == null ? '' : formatMeasureCell(vf.column_id, v)}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                )}

                {/* Grand total when no col dims */}
                {!pivotMatrix.hasColDims && pivotConfig.show_grand_total && (
                  <TableRow sx={{ bgcolor: '#e8eaf6' }}>
                    <TableCell colSpan={pivotMatrix.rowFieldNames.length}
                               sx={{ position: 'sticky', left: 0, bgcolor: '#e8eaf6', fontWeight: 700, zIndex: 1 }}>
                      Grand Total
                    </TableCell>
                    {pivotConfig.value_fields.map((vf, vi) => {
                      const physName = getColPhysicalName(vf.column_id);
                      const v = pivotMatrix.grandTotals[physName];
                      return (
                        <TableCell key={`grand-flat-${vi}`}
                                   sx={{ textAlign: 'right', fontWeight: 800 }}>
                          {v == null ? '' : formatMeasureCell(vf.column_id, v)}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {!executing && rawRows.length === 0 && !pivotMatrix && (
        <Paper elevation={1} sx={{ p: 4, textAlign: 'center' }}>
          <PivotIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
          <Typography variant="body1" color="text.secondary">
            Click <strong>Run Pivot Report</strong> to execute.
          </Typography>
        </Paper>
      )}
    </Box>
  );
};

const LinearLoading: React.FC = () => (
  <Box sx={{ width: '100%', textAlign: 'center', py: 2 }}>
    <CircularProgress size={32} />
    <Typography variant="caption" display="block" color="text.secondary">
      Aggregating data…
    </Typography>
  </Box>
);

const csvEscape = (s: string): string => {
  if (s == null) return '';
  const str = String(s);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

export default PivotReportViewer;
