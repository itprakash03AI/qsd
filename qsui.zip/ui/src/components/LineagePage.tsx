/**
 * LineagePage.tsx
 * Data Lineage explorer for QueryStudio (Phase 26).
 * Shows a full graph of data lineage and lets users explore upstream/downstream trees
 * for any node (Connection, SQL Query, Parquet Query, Report, Dashboard, Schedule).
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  Box,
  Typography,
  Paper,
  Chip,
  TextField,
  InputAdornment,
  CircularProgress,
  Alert,
  Divider,
  IconButton,
  Tooltip,
  Stack,
  Tabs,
  Tab,
  Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ListAltIcon from '@mui/icons-material/ListAlt';
import HistoryIcon from '@mui/icons-material/History';
import WaterDropIcon from '@mui/icons-material/WaterDrop';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import LineageGraphView from './LineageGraphView';
import LineageDiffView from './LineageDiffView';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface LineageNode {
  type: string;
  id: number;
  name: string;
  upstream?: LineageNode[];
  downstream?: LineageNode[];
}

interface LineageTree {
  node: LineageNode;
  upstream: LineageNode[];
  downstream: LineageNode[];
}

interface GraphNode {
  id: string;
  type: string;
  label: string;
}

interface GraphEdge {
  source: string;
  target: string;
}

interface LineageGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const NODE_COLOURS: Record<string, string> = {
  connection: '#1976d2',
  table: '#e65100',
  sql_query: '#00897b',
  parquet_query: '#388e3c',
  report: '#f57c00',
  dashboard: '#7b1fa2',
  materialized_view: '#455a64',
  schedule: '#616161',
};

const TYPE_LABELS: Record<string, string> = {
  connection: 'Connection',
  table: 'Table',
  sql_query: 'SQL Query',
  parquet_query: 'Parquet Query',
  report: 'Report',
  dashboard: 'Dashboard',
  materialized_view: 'Materialized View',
  schedule: 'Schedule',
};

const FILTER_TYPES = [
  { key: 'all', label: 'All' },
  { key: 'connection', label: 'Connection' },
  { key: 'table', label: 'Table' },
  { key: 'sql_query', label: 'SQL Query' },
  { key: 'parquet_query', label: 'Parquet Query' },
  { key: 'report', label: 'Report' },
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'schedule', label: 'Schedule' },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const getColour = (type: string): string => NODE_COLOURS[type] ?? '#9e9e9e';

const getLabel = (type: string): string => TYPE_LABELS[type] ?? type;

/** Build a navigation path for a given node type + id. Returns null if no route. */
const getNavPath = (type: string, id: number): string | null => {
  switch (type) {
    case 'connection':
      return '/connections';
    case 'report':
      return `/report-manager?reportId=${id}`;
    case 'dashboard':
      return `/dashboards?dashboardId=${id}`;
    case 'schedule':
      return `/schedules?scheduleId=${id}`;
    case 'sql_query':
    case 'parquet_query':
      return `/query?queryId=${id}`;
    default:
      return null;
  }
};

/** Count all descendants of a given type in a node tree (recursive). */
const countDescendants = (nodes: LineageNode[], type: string): number => {
  let count = 0;
  for (const n of nodes) {
    if (n.type === type) count += 1;
    if (n.downstream && n.downstream.length > 0) {
      count += countDescendants(n.downstream, type);
    }
  }
  return count;
};

// ---------------------------------------------------------------------------
// TreeRow — renders a single expandable row in the lineage tree
// ---------------------------------------------------------------------------

interface TreeRowProps {
  node: LineageNode;
  depth: number;
  direction: 'upstream' | 'downstream';
}

const TreeRow: React.FC<TreeRowProps> = ({ node, depth, direction }) => {
  const navigate = useNavigate();
  const children = direction === 'upstream' ? node.upstream : node.downstream;
  const hasChildren = children && children.length > 0;
  const [expanded, setExpanded] = useState<boolean>(depth < 2);

  const colour = getColour(node.type);
  const navPath = getNavPath(node.type, node.id);

  return (
    <Box>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          pl: depth * 2.5 + 0.5,
          py: 0.4,
          '&:hover': { bgcolor: 'action.hover', borderRadius: 1 },
          cursor: hasChildren ? 'pointer' : 'default',
        }}
        onClick={() => hasChildren && setExpanded(prev => !prev)}
      >
        {/* Expand / collapse icon */}
        <Box sx={{ width: 20, display: 'flex', alignItems: 'center', flexShrink: 0 }}>
          {hasChildren ? (
            expanded ? (
              <ExpandMoreIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            ) : (
              <ChevronRightIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            )
          ) : null}
        </Box>

        {/* Type chip */}
        <Chip
          label={getLabel(node.type)}
          size="small"
          sx={{
            bgcolor: colour,
            color: '#fff',
            fontSize: '0.65rem',
            height: 18,
            mr: 1,
            flexShrink: 0,
            '& .MuiChip-label': { px: 0.8 },
          }}
        />

        {/* Node name */}
        <Typography variant="body2" sx={{ flexGrow: 1, fontSize: '0.82rem' }}>
          {node.name}
        </Typography>

        {/* Navigation link */}
        {navPath && (
          <Tooltip title={`Open in ${getLabel(node.type)}`}>
            <IconButton
              size="small"
              onClick={e => { e.stopPropagation(); navigate(navPath); }}
              sx={{ p: 0.25, ml: 0.5 }}
            >
              <OpenInNewIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
            </IconButton>
          </Tooltip>
        )}
      </Box>

      {/* Children */}
      {hasChildren && expanded && (
        <Box>
          {children!.map((child, idx) => (
            <TreeRow
              key={`${child.type}-${child.id}-${idx}`}
              node={child}
              depth={depth + 1}
              direction={direction}
            />
          ))}
        </Box>
      )}
    </Box>
  );
};

// ---------------------------------------------------------------------------
// DetailPanel — shows the lineage tree for the selected node
// ---------------------------------------------------------------------------

interface DetailPanelProps {
  graphNode: GraphNode;
}

const TRANSFORM_COLOURS: Record<string, string> = {
  direct: '#2e7d32',
  renamed: '#1565c0',
  computed: '#e65100',
  aggregated: '#6a1b9a',
  casted: '#00695c',
  star_expansion: '#616161',
};

const DetailPanel: React.FC<DetailPanelProps> = ({ graphNode }) => {
  const navigate = useNavigate();
  const [tree, setTree] = useState<LineageTree | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [colLineage, setColLineage] = useState<any[]>([]);
  const [colLoading, setColLoading] = useState(false);

  // Parse the composite graph-node id ("type:numeric_id")
  const [nodeType, nodeIdStr] = graphNode.id.split(':');
  const nodeId = parseInt(nodeIdStr, 10);

  const colour = getColour(nodeType);
  const navPath = !isNaN(nodeId) ? getNavPath(nodeType, nodeId) : null;

  const fetchTree = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let data: LineageTree;
      if (nodeType === 'table') {
        // Table nodes have composite FQN ids like "table:catalog.schema.name"
        const fqn = graphNode.id.replace('table:', '');
        const parts = fqn.split('.');
        if (parts.length >= 3) {
          const impact = await (api as any).getTableLineage(parts[0], parts[1], parts.slice(2).join('.'));
          // Convert impact analysis to tree format
          const upstream: any[] = [];
          const downstream: any[] = (impact.queries || []).map((q: any) => ({
            type: q.query_type, id: q.query_id, name: q.name || `${q.query_type}:${q.query_id}`, downstream: [],
          }));
          for (const r of impact.downstream_reports || []) {
            downstream.push({ type: 'report', id: r.id, name: r.name, downstream: [] });
          }
          for (const d of impact.downstream_dashboards || []) {
            downstream.push({ type: 'dashboard', id: d.id, name: d.name, downstream: [] });
          }
          data = { node: { type: 'table', id: 0, name: fqn }, upstream, downstream };
        } else {
          data = { node: { type: 'table', id: 0, name: fqn }, upstream: [], downstream: [] };
        }
      } else if (isNaN(nodeId)) {
        return;
      } else if (nodeType === 'connection') {
        data = await (api as any).getConnectionLineage(nodeId);
      } else if (nodeType === 'report') {
        data = await (api as any).getReportLineage(nodeId);
      } else if (nodeType === 'sql_query' || nodeType === 'parquet_query') {
        data = await (api as any).getQueryLineage(nodeId, nodeType === 'parquet_query' ? 'parquet' : 'sql');
      } else {
        // Fallback for dashboard / schedule / materialized_view
        data = await (api as any).getReportLineage(nodeId);
      }
      setTree(data);
    } catch (err: any) {
      setError(err?.message ?? 'Failed to load lineage tree.');
    } finally {
      setLoading(false);
    }
  }, [graphNode.id, nodeId, nodeType]);

  useEffect(() => {
    fetchTree();
  }, [fetchTree]);

  // Fetch column lineage for sql_query nodes (Phase 51)
  useEffect(() => {
    if (nodeType !== 'sql_query' || isNaN(nodeId)) {
      setColLineage([]);
      return;
    }
    setColLoading(true);
    (api as any).getQueryColumnLineage(nodeId, 'sql')
      .then((data: any) => setColLineage(data?.columns || []))
      .catch(() => setColLineage([]))
      .finally(() => setColLoading(false));
  }, [nodeId, nodeType]);

  // Impact summary counts derived from the tree
  const reportCount = tree ? countDescendants(tree.downstream, 'report') : 0;
  const scheduleCount = tree ? countDescendants(tree.downstream, 'schedule') : 0;

  return (
    <Paper
      elevation={2}
      sx={{
        p: 2.5,
        height: '100%',
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
      }}
    >
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
        <Chip
          label={getLabel(nodeType)}
          sx={{
            bgcolor: colour,
            color: '#fff',
            fontWeight: 600,
            fontSize: '0.75rem',
          }}
        />
        <Typography variant="h6" sx={{ fontWeight: 600, flexGrow: 1 }}>
          {graphNode.label}
        </Typography>
        {navPath && (
          <Tooltip title={`Open in ${getLabel(nodeType)}`}>
            <IconButton size="small" onClick={() => navigate(navPath)}>
              <OpenInNewIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
      </Box>

      <Divider />

      {/* Loading / error */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress size={28} />
        </Box>
      )}
      {!loading && error && (
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Tree */}
      {!loading && tree && (
        <>
          {/* Impact summary */}
          {(reportCount > 0 || scheduleCount > 0) && (
            <Box
              sx={{
                bgcolor: 'action.selected',
                borderRadius: 1,
                px: 1.5,
                py: 1,
                display: 'flex',
                gap: 1.5,
                flexWrap: 'wrap',
              }}
            >
              <Typography variant="caption" color="text.secondary" fontWeight={600}>
                IMPACT SUMMARY
              </Typography>
              {reportCount > 0 && (
                <Chip
                  label={`${reportCount} report${reportCount !== 1 ? 's' : ''} downstream`}
                  size="small"
                  sx={{ bgcolor: NODE_COLOURS.report, color: '#fff', fontSize: '0.7rem' }}
                />
              )}
              {scheduleCount > 0 && (
                <Chip
                  label={`${scheduleCount} schedule${scheduleCount !== 1 ? 's' : ''} downstream`}
                  size="small"
                  sx={{ bgcolor: NODE_COLOURS.schedule, color: '#fff', fontSize: '0.7rem' }}
                />
              )}
            </Box>
          )}

          {/* Upstream */}
          <Box>
            <Typography
              variant="overline"
              color="text.secondary"
              sx={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.08em' }}
            >
              Upstream ({tree.upstream.length})
            </Typography>
            {tree.upstream.length === 0 ? (
              <Typography variant="body2" color="text.disabled" sx={{ pl: 1, mt: 0.5 }}>
                No upstream dependencies
              </Typography>
            ) : (
              <Box sx={{ mt: 0.5 }}>
                {tree.upstream.map((n, idx) => (
                  <TreeRow
                    key={`up-${n.type}-${n.id}-${idx}`}
                    node={n}
                    depth={0}
                    direction="upstream"
                  />
                ))}
              </Box>
            )}
          </Box>

          <Divider />

          {/* Downstream */}
          <Box>
            <Typography
              variant="overline"
              color="text.secondary"
              sx={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.08em' }}
            >
              Downstream ({tree.downstream.length})
            </Typography>
            {tree.downstream.length === 0 ? (
              <Typography variant="body2" color="text.disabled" sx={{ pl: 1, mt: 0.5 }}>
                No downstream dependents
              </Typography>
            ) : (
              <Box sx={{ mt: 0.5 }}>
                {tree.downstream.map((n, idx) => (
                  <TreeRow
                    key={`dn-${n.type}-${n.id}-${idx}`}
                    node={n}
                    depth={0}
                    direction="downstream"
                  />
                ))}
              </Box>
            )}
          </Box>

          {/* Column Lineage — sql_query nodes only (Phase 51) */}
          {nodeType === 'sql_query' && (
            <>
              <Divider />
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                  <Typography
                    variant="overline"
                    color="text.secondary"
                    sx={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.08em' }}
                  >
                    Column Lineage
                  </Typography>
                  {colLoading && <CircularProgress size={12} />}
                </Box>
                {!colLoading && colLineage.length === 0 && (
                  <Typography variant="body2" color="text.disabled" sx={{ pl: 1 }}>
                    No column lineage data
                  </Typography>
                )}
                {!colLoading && colLineage.length > 0 && (
                  <Box sx={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.76rem' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid rgba(0,0,0,0.12)' }}>
                          <th style={{ textAlign: 'left', padding: '3px 6px', color: '#666', fontWeight: 600, fontSize: '0.7rem' }}>Source</th>
                          <th style={{ textAlign: 'center', padding: '3px 6px', color: '#666', fontWeight: 600, fontSize: '0.7rem' }}>Transform</th>
                          <th style={{ textAlign: 'left', padding: '3px 6px', color: '#666', fontWeight: 600, fontSize: '0.7rem' }}>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        {colLineage.map((r: any, i: number) => (
                          <tr key={i} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                            <td style={{ padding: '3px 6px', fontFamily: 'monospace', fontSize: '0.72rem' }}>
                              {r.source_table ? (
                                <><span style={{ color: '#888' }}>{r.source_table}.</span>{r.source_column || '?'}</>
                              ) : (
                                r.source_column || '?'
                              )}
                            </td>
                            <td style={{ padding: '3px 6px', textAlign: 'center' }}>
                              <Chip
                                label={r.transform_type || 'direct'}
                                size="small"
                                sx={{
                                  height: 16,
                                  fontSize: '0.62rem',
                                  bgcolor: TRANSFORM_COLOURS[r.transform_type] ?? '#9e9e9e',
                                  color: '#fff',
                                  '& .MuiChip-label': { px: 0.75 },
                                }}
                              />
                            </td>
                            <td style={{ padding: '3px 6px', fontFamily: 'monospace', fontSize: '0.72rem', fontWeight: 600 }}>
                              {r.target_column}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </Box>
                )}
              </Box>
            </>
          )}
        </>
      )}
    </Paper>
  );
};

// ---------------------------------------------------------------------------
// LineagePage — top-level page component
// ---------------------------------------------------------------------------

const LineagePage: React.FC = () => {
  const [graph, setGraph] = useState<LineageGraph | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [viewTab, setViewTab] = useState<'graph' | 'list' | 'history' | 'freshness'>('graph');
  // Phase 52 — freshness state
  const [staleCount, setStaleCount]   = useState(0);
  const [freshness, setFreshness]     = useState<any[]>([]);
  const [freshnessLoading, setFreshnessLoading] = useState(false);

  // Load full graph on mount
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const data: LineageGraph = await (api as any).getFullLineageGraph();
        if (!cancelled) setGraph(data);
      } catch (err: any) {
        if (!cancelled) setError(err?.message ?? 'Failed to load lineage graph.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, []);

  // Phase 52 — load freshness data
  const loadFreshness = useCallback(async () => {
    setFreshnessLoading(true);
    try {
      const r = await (api as any).getDataFreshness();
      const rows = r.tables || [];
      setFreshness(rows);
      setStaleCount(rows.filter((t: any) => t.freshness_status === 'stale').length);
    } catch (_) {
      // freshness is optional — swallow errors silently
    } finally {
      setFreshnessLoading(false);
    }
  }, []);

  useEffect(() => { loadFreshness(); }, [loadFreshness]);

  // Derive filtered node list
  const filteredNodes: GraphNode[] = graph
    ? graph.nodes.filter(n => {
        const matchesType = typeFilter === 'all' || n.type === typeFilter;
        const matchesSearch =
          searchQuery.trim() === '' ||
          n.label.toLowerCase().includes(searchQuery.trim().toLowerCase());
        return matchesType && matchesSearch;
      })
    : [];

  // When filters change, deselect if current selection no longer matches
  useEffect(() => {
    if (selectedNode && !filteredNodes.find(n => n.id === selectedNode.id)) {
      setSelectedNode(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchQuery, typeFilter]);

  return (
    <Box
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        p: { xs: 1.5, sm: 2.5 },
        gap: 2,
      }}
    >
      {/* Page header */}
      <Box>
        <Typography variant="h5" fontWeight={700}>
          Data Lineage
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Explore upstream dependencies and downstream impact across all data assets.
        </Typography>
      </Box>

      {/* Stale-data banner (Phase 52) */}
      {staleCount > 0 && (
        <Alert severity="warning" icon={<WarningAmberIcon />}
          action={<Button size="small" color="warning" onClick={() => setViewTab('freshness')}>View</Button>}
          sx={{ py: 0.5 }}>
          {staleCount} table{staleCount > 1 ? 's are' : ' is'} stale — data may be outdated.
        </Alert>
      )}

      {/* View toggle tabs */}
      <Tabs value={viewTab} onChange={(_, v) => setViewTab(v)} sx={{ minHeight: 36, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Tab value="graph" label="Graph View" icon={<AccountTreeIcon sx={{ fontSize: 16 }} />} iconPosition="start"
          sx={{ minHeight: 36, py: 0.5, fontSize: '0.82rem', textTransform: 'none' }} />
        <Tab value="list" label="List View" icon={<ListAltIcon sx={{ fontSize: 16 }} />} iconPosition="start"
          sx={{ minHeight: 36, py: 0.5, fontSize: '0.82rem', textTransform: 'none' }} />
        <Tab value="history" label="History" icon={<HistoryIcon sx={{ fontSize: 16 }} />} iconPosition="start"
          sx={{ minHeight: 36, py: 0.5, fontSize: '0.82rem', textTransform: 'none' }} />
        <Tab value="freshness"
          label={
            <Stack direction="row" spacing={0.5} alignItems="center">
              <WaterDropIcon sx={{ fontSize: 16 }} />
              <span>Freshness</span>
              {staleCount > 0 && (
                <Chip label={staleCount} size="small" color="warning"
                  sx={{ height: 16, fontSize: '0.68rem', '& .MuiChip-label': { px: 0.75 } }} />
              )}
            </Stack>
          }
          sx={{ minHeight: 36, py: 0.5, fontSize: '0.82rem', textTransform: 'none' }}
        />
      </Tabs>

      {/* Search + filter row — only for list view */}
      {viewTab === 'list' && <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} alignItems={{ sm: 'center' }}>
        <TextField
          size="small"
          placeholder="Search by name…"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
          sx={{ minWidth: 240 }}
        />
        <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
          {FILTER_TYPES.map(ft => {
            const active = typeFilter === ft.key;
            const colour = ft.key !== 'all' ? getColour(ft.key) : undefined;
            return (
              <Chip
                key={ft.key}
                label={ft.label}
                size="small"
                onClick={() => setTypeFilter(ft.key)}
                sx={{
                  cursor: 'pointer',
                  fontWeight: active ? 700 : 400,
                  bgcolor: active ? (colour ?? 'primary.main') : 'action.selected',
                  color: active ? '#fff' : 'text.primary',
                  border: active ? 'none' : '1px solid transparent',
                  '&:hover': {
                    bgcolor: active ? (colour ?? 'primary.dark') : 'action.hover',
                  },
                }}
              />
            );
          })}
        </Stack>
      </Stack>}

      {/* Global loading / error */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexGrow: 1 }}>
          <CircularProgress />
        </Box>
      )}
      {!loading && error && (
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Empty state — graph loaded but no assets exist yet */}
      {!loading && !error && graph && graph.nodes.length === 0 && viewTab === 'list' && (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexGrow: 1, gap: 1.5, py: 6 }}>
          <Typography variant="h6" color="text.disabled">No lineage data yet</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 480, textAlign: 'center' }}>
            The lineage graph is built automatically from your data assets. To see data here:
          </Typography>
          <Box component="ol" sx={{ pl: 2.5, mt: 0.5, maxWidth: 480 }}>
            <li><Typography variant="body2">Create a <strong>Connection</strong> (Data Sources → Connections)</Typography></li>
            <li><Typography variant="body2">Build a <strong>SQL Saved Query</strong> using that connection (SQL Editor → Save)</Typography></li>
            <li><Typography variant="body2">Create a <strong>Report</strong> from the SQL query (Parametric Reports → New)</Typography></li>
            <li><Typography variant="body2">Optionally add the report to a <strong>Dashboard</strong> or <strong>Schedule</strong></Typography></li>
          </Box>
          <Typography variant="caption" color="text.disabled">Refresh this page after creating assets to see the lineage graph.</Typography>
        </Box>
      )}

      {/* Main content — graph view or list + detail panel */}
      {!loading && !error && graph && graph.nodes.length > 0 && viewTab === 'graph' && (
        <Box sx={{ flexGrow: 1, overflow: 'hidden', minHeight: 400 }}>
          <LineageGraphView
            graphNodes={graph.nodes}
            graphEdges={graph.edges}
            onNodeSelect={node => setSelectedNode(node)}
          />
          {selectedNode && (
            <Box sx={{ position: 'absolute', right: 24, top: 180, zIndex: 10, width: 380, maxHeight: '70vh', overflowY: 'auto' }}>
              <Paper elevation={4} sx={{ p: 0 }}>
                <DetailPanel key={selectedNode.id} graphNode={selectedNode} />
              </Paper>
            </Box>
          )}
        </Box>
      )}

      {!loading && !error && graph && graph.nodes.length > 0 && viewTab === 'list' && (
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            flexGrow: 1,
            overflow: 'hidden',
            flexDirection: { xs: 'column', md: 'row' },
          }}
        >
          {/* Node list */}
          <Paper
            elevation={1}
            sx={{
              width: { xs: '100%', md: 320 },
              flexShrink: 0,
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            <Box sx={{ px: 1.5, py: 1, borderBottom: '1px solid', borderColor: 'divider' }}>
              <Typography variant="caption" color="text.secondary" fontWeight={600}>
                {filteredNodes.length} NODE{filteredNodes.length !== 1 ? 'S' : ''}
              </Typography>
            </Box>

            {filteredNodes.length === 0 ? (
              <Box sx={{ p: 3, textAlign: 'center' }}>
                <Typography variant="body2" color="text.disabled">
                  {searchQuery || typeFilter !== 'all' ? 'No nodes match your filter.' : 'No data assets found.'}
                </Typography>
              </Box>
            ) : (
              <Box sx={{ overflowY: 'auto', flexGrow: 1 }}>
                {filteredNodes.map(node => {
                  const isSelected = selectedNode?.id === node.id;
                  const colour = getColour(node.type);
                  return (
                    <Box
                      key={node.id}
                      onClick={() => setSelectedNode(isSelected ? null : node)}
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                        px: 1.5,
                        py: 0.9,
                        cursor: 'pointer',
                        bgcolor: isSelected ? 'action.selected' : 'transparent',
                        borderLeft: isSelected ? `3px solid ${colour}` : '3px solid transparent',
                        '&:hover': { bgcolor: 'action.hover' },
                        transition: 'background-color 0.15s',
                      }}
                    >
                      <Chip
                        label={getLabel(node.type)}
                        size="small"
                        sx={{
                          bgcolor: colour,
                          color: '#fff',
                          fontSize: '0.62rem',
                          height: 17,
                          flexShrink: 0,
                          '& .MuiChip-label': { px: 0.75 },
                        }}
                      />
                      <Typography
                        variant="body2"
                        sx={{
                          fontSize: '0.82rem',
                          fontWeight: isSelected ? 600 : 400,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {node.label}
                      </Typography>
                    </Box>
                  );
                })}
              </Box>
            )}
          </Paper>

          {/* Detail panel */}
          <Box sx={{ flexGrow: 1, overflow: 'hidden' }}>
            {selectedNode ? (
              <DetailPanel key={selectedNode.id} graphNode={selectedNode} />
            ) : (
              <Paper
                elevation={1}
                sx={{
                  height: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'column',
                  gap: 1,
                  color: 'text.disabled',
                }}
              >
                <SearchIcon sx={{ fontSize: 48, opacity: 0.3 }} />
                <Typography variant="body1" color="text.disabled">
                  Select a node to explore its lineage
                </Typography>
              </Paper>
            )}
          </Box>
        </Box>
      )}

      {/* ── History tab (Phase 52) ───────────────────────────────────────────── */}
      {viewTab === 'history' && (
        <Box sx={{ flexGrow: 1, overflow: 'auto', p: 1 }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
            Lineage Snapshot History
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            A snapshot is captured automatically after each successful query execution.
            Select two snapshots to compare tables and column flows.
          </Typography>
          <LineageDiffView />
        </Box>
      )}

      {/* ── Freshness tab (Phase 52) ─────────────────────────────────────────── */}
      {viewTab === 'freshness' && (
        <Box sx={{ flexGrow: 1, overflow: 'auto', p: 1 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
            <Typography variant="subtitle1" fontWeight={700}>Data Freshness</Typography>
            <Button size="small" onClick={loadFreshness} disabled={freshnessLoading}
              startIcon={freshnessLoading ? <CircularProgress size={14} /> : undefined}>
              Refresh
            </Button>
          </Stack>
          {freshness.length === 0 && !freshnessLoading && (
            <Alert severity="info">
              No freshness data yet. Tables are tracked automatically as queries execute.
            </Alert>
          )}
          {freshness.length > 0 && (
            <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
              <Box component="thead">
                <Box component="tr" sx={{ borderBottom: '2px solid', borderColor: 'divider' }}>
                  {['Status', 'Table', 'Last Observed', 'Threshold (h)', 'Last Refreshed'].map(h => (
                    <Box component="th" key={h}
                      sx={{ textAlign: 'left', p: '6px 10px', color: 'text.secondary', fontWeight: 600, fontSize: '0.75rem' }}>
                      {h}
                    </Box>
                  ))}
                </Box>
              </Box>
              <Box component="tbody">
                {freshness.map((row: any) => {
                  const statusColor = row.freshness_status === 'fresh' ? 'success'
                    : row.freshness_status === 'stale' ? 'error' : 'default';
                  return (
                    <Box component="tr" key={row.table_fqn}
                      sx={{ borderBottom: '1px solid', borderColor: 'divider',
                        '&:hover': { bgcolor: 'action.hover' } }}>
                      <Box component="td" sx={{ p: '6px 10px' }}>
                        <Chip label={row.freshness_status} size="small" color={statusColor as any}
                          sx={{ fontSize: '0.7rem', height: 18, '& .MuiChip-label': { px: 0.75 } }} />
                      </Box>
                      <Box component="td" sx={{ p: '6px 10px', fontFamily: 'monospace', fontSize: '0.78rem' }}>
                        {row.table_fqn}
                      </Box>
                      <Box component="td" sx={{ p: '6px 10px', color: 'text.secondary' }}>
                        {row.last_observed_at
                          ? new Date(row.last_observed_at).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })
                          : '—'}
                      </Box>
                      <Box component="td" sx={{ p: '6px 10px', color: 'text.secondary' }}>
                        {row.stale_threshold_hours}h
                      </Box>
                      <Box component="td" sx={{ p: '6px 10px', color: 'text.secondary' }}>
                        {row.last_refresh_at
                          ? new Date(row.last_refresh_at).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })
                          : '—'}
                      </Box>
                    </Box>
                  );
                })}
              </Box>
            </Box>
          )}
        </Box>
      )}
    </Box>
  );
};

export default LineagePage;
