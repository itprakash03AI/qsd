/**
 * MetadataCatalogPage — Phase 92 (Data Catalog v2)
 *
 * Features:
 * - Tabs: "All Tables" / "★ My Tables"
 * - Star/unfavorite button per table (persisted per user)
 * - Freshness badge (green/yellow/red) from S3 LastModified
 * - File health indicator (small-file warning)
 * - Admin-editable descriptions (inline edit with pencil icon)
 * - Data preview modal (top-20 rows via DuckDB)
 * - Iceberg: Schema+Partitions tab shows partition values as clickable chips
 *   (click a value → PartitionQueryDialog pre-populated with that value)
 * - Full metadata JSON tab for Iceberg tables
 * - Usage counter (preview_count)
 * - Search across table names, columns, descriptions, partitions, connections
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box, Typography, Button, Paper, TextField, InputAdornment,
  Chip, CircularProgress, Alert, Tooltip, IconButton, Stack,
  Accordion, AccordionSummary, AccordionDetails,
  Dialog, DialogTitle, DialogContent, DialogActions,
  Card, CardContent, CardActions, Divider, Grid,
  Autocomplete, Tab, Tabs,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Snackbar,
} from '@mui/material';
import {
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Storage as StorageIcon,
  TableChart as TableIcon,
  ExpandMore as ExpandMoreIcon,
  OpenInNew as OpenInNewIcon,
  FilterAlt as FilterIcon,
  FolderOpen as PrefixIcon,
  Close as CloseIcon,
  Code as CodeIcon,
  ContentCopy as CopyIcon,
  Schema as SchemaIcon,
  Star as StarIcon,
  StarBorder as StarBorderIcon,
  Visibility as PreviewIcon,
  Edit as EditIcon,
  Check as CheckIcon,
  Warning as WarningIcon,
  FiberManualRecord as DotIcon,
  QueryStats as StatsIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { safeStringify } from '../utils/safeStringify';

// ── Types ─────────────────────────────────────────────────────────────────────

interface Column {
  name: string;
  type: string;
  nullable?: boolean;
  field_id?: number;
}

interface CatalogTable {
  name: string;
  format: string;
  s3_prefix: string;
  description?: string;
  file_count: number;
  record_count: number | null;
  partition_columns: string[];
  sample_partition_values: Record<string, string[]>;
  columns: Column[];
  snapshot_id?: number | null;
  format_version?: number | null;
  // Phase 92
  last_updated_at?: string | null;
  avg_file_size_mb?: number | null;
  small_file_warning?: boolean;
  is_favorite?: boolean;
  preview_count?: number;
}

interface CatalogConnection {
  id: number;
  name: string;
  connection_type: string;
  tables: CatalogTable[];
}

interface CatalogResponse {
  connections: CatalogConnection[];
  total_tables: number;
  total_connections: number;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtCount(n: number | null | undefined): string {
  if (n === null || n === undefined) return '—';
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function getFreshness(lastUpdatedAt: string | null | undefined) {
  if (!lastUpdatedAt) return { label: 'Unknown', color: 'default' as const };
  const days = Math.floor((Date.now() - new Date(lastUpdatedAt).getTime()) / 86_400_000);
  if (days < 1) return { label: 'Today', color: 'success' as const };
  if (days < 7) return { label: `${days}d ago`, color: 'success' as const };
  if (days < 30) return { label: `${Math.ceil(days / 7)}w ago`, color: 'warning' as const };
  return { label: `${Math.ceil(days / 30)}mo ago`, color: 'error' as const };
}

// ── MetadataDialog — Schema/Partitions + full JSON ────────────────────────────

interface MetadataDialogProps {
  open: boolean;
  connectionId: number;
  table: CatalogTable | null;
  onClose: () => void;
  onQueryPartition: (initParts: Record<string, string[]>) => void;
}

const MetadataDialog: React.FC<MetadataDialogProps> = ({
  open, connectionId, table, onClose, onQueryPartition,
}) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [section, setSection] = useState<'schema' | 'json'>('schema');

  useEffect(() => {
    if (!open || !table) return;
    setData(null); setError(null); setLoading(true);
    api.getTableMetadata(connectionId, table.name)
      .then((d: any) => setData(d))
      .catch((e: any) => setError(e?.message || 'Failed to load metadata'))
      .finally(() => setLoading(false));
  }, [open, connectionId, table]);

  const jsonText = data ? JSON.stringify(data, null, 2) : '';
  const handleCopy = () => {
    navigator.clipboard.writeText(jsonText).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  };

  if (!table) return null;

  const schemaColumns: Column[] = data?.columns || table.columns || [];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, pb: 0.5 }}>
        <CodeIcon color="primary" />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h6">Table Metadata</Typography>
          <Typography variant="body2" color="text.secondary">
            {table.name} · {table.format.toUpperCase()}
            {data?.num_rows != null && ` · ${fmtCount(data.num_rows)} rows total`}
          </Typography>
        </Box>
        {section === 'json' && (
          <Tooltip title={copied ? 'Copied!' : 'Copy JSON'}>
            <IconButton onClick={handleCopy} disabled={!data} size="small"><CopyIcon fontSize="small" /></IconButton>
          </Tooltip>
        )}
        <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
      </DialogTitle>

      <Tabs value={section} onChange={(_, v) => setSection(v)} sx={{ px: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Tab value="schema" label="Schema &amp; Partitions" />
        <Tab value="json" label="Full JSON" />
      </Tabs>

      <DialogContent dividers sx={{ p: 0, minHeight: 280 }}>
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
            <CircularProgress />
          </Box>
        )}
        {error && !loading && <Alert severity="error" sx={{ m: 2 }}>{error}</Alert>}

        {/* SCHEMA + PARTITIONS TAB */}
        {!loading && section === 'schema' && (
          <Box sx={{ p: 2.5 }}>
            {/* Snapshot info */}
            {(data?.snapshot_id || data?.format_version) && (
              <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 2 }}>
                {data.snapshot_id && (
                  <Chip label={`Snapshot: ${data.snapshot_id}`} size="small" variant="outlined" />
                )}
                {data.format_version && (
                  <Chip label={`Format v${data.format_version}`} size="small" color="success" variant="outlined" />
                )}
                {data.num_rows != null && (
                  <Chip label={`${fmtCount(data.num_rows)} rows`} size="small" color="info" variant="outlined" />
                )}
              </Stack>
            )}

            {/* Partition columns with clickable value chips */}
            {table.partition_columns.length > 0 && (
              <Box sx={{ mb: 2.5 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Partition Columns ({table.partition_columns.length})
                </Typography>
                <Alert severity="info" sx={{ mb: 1.5, py: 0.5, fontSize: '0.8rem' }}>
                  Click a partition value chip below to open the Query Builder with it pre-selected.
                </Alert>
                {table.partition_columns.map(col => {
                  const vals = (table.sample_partition_values || {})[col] || [];
                  return (
                    <Box key={col} sx={{ mb: 1.5 }}>
                      <Typography variant="caption" color="text.secondary" fontWeight={700} sx={{ display: 'block', mb: 0.4 }}>
                        {col}
                      </Typography>
                      <Stack direction="row" spacing={0.5} flexWrap="wrap">
                        {vals.map(v => (
                          <Tooltip key={v} title={`Query where ${col} = '${v}'`} placement="top">
                            <Chip
                              label={v}
                              size="small"
                              color="warning"
                              variant="outlined"
                              onClick={() => { onQueryPartition({ [col]: [v] }); onClose(); }}
                              sx={{ cursor: 'pointer', '&:hover': { bgcolor: 'warning.light', color: 'warning.contrastText' } }}
                            />
                          </Tooltip>
                        ))}
                        {vals.length === 0 && (
                          <Typography variant="caption" color="text.disabled">No sample values available</Typography>
                        )}
                        {vals.length > 0 && (
                          <Tooltip title="Open Query Builder with custom partition selection">
                            <Chip
                              label="Select…"
                              size="small"
                              variant="filled"
                              onClick={() => { onQueryPartition({}); onClose(); }}
                              sx={{ cursor: 'pointer', bgcolor: 'action.selected' }}
                            />
                          </Tooltip>
                        )}
                      </Stack>
                    </Box>
                  );
                })}
              </Box>
            )}

            {/* Schema table */}
            {schemaColumns.length > 0 && (
              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  Schema ({schemaColumns.length} columns)
                </Typography>
                <TableContainer sx={{ maxHeight: 340, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Column</TableCell>
                        <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Type</TableCell>
                        <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Nullable</TableCell>
                        <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Field ID</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {schemaColumns.map((col) => (
                        <TableRow key={col.name} hover>
                          <TableCell sx={{ fontFamily: 'monospace', fontWeight: 600, fontSize: '0.8rem' }}>{col.name}</TableCell>
                          <TableCell sx={{ fontFamily: 'monospace', color: 'text.secondary', fontSize: '0.78rem' }}>{col.type}</TableCell>
                          <TableCell>
                            <Typography variant="caption" color={col.nullable === false ? 'error.main' : 'text.disabled'}>
                              {col.nullable === false ? 'required' : 'nullable'}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="caption" color="text.disabled">{col.field_id ?? '—'}</Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            )}

            {/* Non-Iceberg fallback */}
            {data?.message && <Alert severity="info" sx={{ mt: 1 }}>{data.message}</Alert>}

            {/* Empty fallback */}
            {!data && !loading && !error && (
              <Alert severity="warning">No metadata available for this table format.</Alert>
            )}
          </Box>
        )}

        {/* FULL JSON TAB */}
        {!loading && section === 'json' && data && (
          <Box
            component="pre"
            sx={{
              m: 0, p: 2.5,
              bgcolor: '#0d1117', color: '#e6edf3',
              fontSize: '0.78rem',
              fontFamily: 'Consolas, "Cascadia Code", monospace',
              overflowX: 'auto', overflowY: 'auto',
              maxHeight: '62vh',
              lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
            }}
          >
            {jsonText}
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ justifyContent: 'space-between', px: 2 }}>
        <Typography variant="caption" color="text.disabled">
          {table.partition_columns.length > 0
            ? `${table.partition_columns.length} partition column(s) — click a value chip to query`
            : 'No partition columns'}
        </Typography>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

// ── PreviewDialog ─────────────────────────────────────────────────────────────

interface PreviewDialogProps {
  open: boolean;
  connectionId: number;
  table: CatalogTable | null;
  onClose: () => void;
}

const PreviewDialog: React.FC<PreviewDialogProps> = ({ open, connectionId, table, onClose }) => {
  const [data, setData] = useState<{ columns: string[]; rows: any[]; error?: string } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !table) return;
    setData(null); setLoading(true);
    api.getTablePreview(connectionId, table.name, 20)
      .then((d: any) => setData(d))
      .catch((e: any) => setData({ columns: [], rows: [], error: e?.message || 'Preview failed' }))
      .finally(() => setLoading(false));
  }, [open, connectionId, table]);

  if (!table) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xl" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <PreviewIcon color="primary" />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h6">Data Preview — {table.name}</Typography>
          <Typography variant="body2" color="text.secondary">
            First 20 rows · sampled from up to 3 parquet files
          </Typography>
        </Box>
        <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
      </DialogTitle>
      <DialogContent dividers sx={{ p: 0 }}>
        {loading && (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 6, gap: 2 }}>
            <CircularProgress size={28} />
            <Typography variant="body2" color="text.secondary">Reading parquet files…</Typography>
          </Box>
        )}
        {data?.error && !loading && (
          <Alert severity="warning" sx={{ m: 2 }}>
            <strong>Preview unavailable:</strong> {data.error}
          </Alert>
        )}
        {data && !data.error && !loading && (
          <>
            {data.rows.length === 0 ? (
              <Alert severity="info" sx={{ m: 2 }}>No rows found in the sampled files.</Alert>
            ) : (
              <TableContainer sx={{ maxHeight: '65vh' }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ bgcolor: '#1e293b', color: '#94a3b8', fontSize: '0.68rem', fontWeight: 700, py: 0.75 }}>
                        #
                      </TableCell>
                      {data.columns.map(col => (
                        <TableCell
                          key={col}
                          sx={{
                            bgcolor: '#1e293b', color: '#e2e8f0',
                            fontSize: '0.7rem', fontWeight: 700,
                            fontFamily: 'monospace', py: 0.75, px: 1.5,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {col}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {data.rows.map((row, idx) => (
                      <TableRow key={idx} hover>
                        <TableCell sx={{ color: 'text.disabled', fontSize: '0.68rem', px: 1.5, py: 0.5 }}>
                          {idx + 1}
                        </TableCell>
                        {data.columns.map(col => (
                          <TableCell
                            key={col}
                            sx={{ fontSize: '0.78rem', fontFamily: 'monospace', maxWidth: 220, px: 1.5, py: 0.5 }}
                          >
                            <Tooltip title={row[col] == null ? 'NULL' : String(row[col])} placement="top">
                              <Box sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 200 }}>
                                {row[col] == null
                                  ? <Typography component="span" variant="caption" color="text.disabled" sx={{ fontStyle: 'italic' }}>NULL</Typography>
                                  : String(row[col])}
                              </Box>
                            </Tooltip>
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
            <Box sx={{ px: 2, py: 0.75, bgcolor: 'action.hover', borderTop: 1, borderColor: 'divider' }}>
              <Typography variant="caption" color="text.secondary">
                {data.rows.length} row{data.rows.length !== 1 ? 's' : ''} · {data.columns.length} column{data.columns.length !== 1 ? 's' : ''}
              </Typography>
            </Box>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

// ── PartitionQueryDialog ──────────────────────────────────────────────────────

interface PartitionQueryDialogProps {
  open: boolean;
  table: CatalogTable | null;
  connection: CatalogConnection | null;
  initialValues?: Record<string, string[]>;
  onClose: () => void;
}

const PartitionQueryDialog: React.FC<PartitionQueryDialogProps> = ({
  open, table, connection, initialValues, onClose,
}) => {
  const navigate = useNavigate();
  const [selectedValues, setSelectedValues] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (open && table) {
      const init: Record<string, string[]> = {};
      for (const col of table.partition_columns) {
        init[col] = initialValues?.[col] ?? [];
      }
      setSelectedValues(init);
    }
  }, [open, table, initialValues]);

  if (!table || !connection) return null;
  const hasPartitions = table.partition_columns.length > 0;
  const queryEnabled = !hasPartitions || Object.values(selectedValues).some(v => v.length > 0);

  const handleQuery = () => {
    const partitionFilters = Object.entries(selectedValues)
      .filter(([, v]) => v.length > 0)
      .map(([col, values]) => ({ column: col, values }));
    // BF-427: safeStringify defends partitionFilters against pollution from
    // value-picker handlers (loosely typed value: any[]).
    try {
      sessionStorage.setItem('catalogLoad', safeStringify({
        connectionId: connection.id,
        tablePath: `__registered__:${table.name}`,
        tableName: table.name,
        partitionFilters,
      }));
    } catch { /* sessionStorage may be disabled */ }
    navigate('/query-builder');
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h6">Select Partitions to Query</Typography>
          <Typography variant="body2" color="text.secondary">{table.name}</Typography>
        </Box>
        <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        {hasPartitions ? (
          <Stack spacing={2.5}>
            <Alert severity="warning" icon={<FilterIcon />}>
              Select at least one partition value to prevent full-table scans.
            </Alert>
            {table.partition_columns.map((col) => {
              const options = (table.sample_partition_values || {})[col] || [];
              return (
                <Autocomplete
                  key={col} multiple size="small"
                  options={options}
                  value={selectedValues[col] || []}
                  onChange={(_, newVal) => setSelectedValues(prev => ({ ...prev, [col]: newVal }))}
                  renderInput={(params) => (
                    <TextField {...params} label={col} placeholder={options.length ? 'Select value(s)...' : 'No sample values'} />
                  )}
                  renderTags={(val, getTagProps) =>
                    val.map((option, index) => (
                      <Chip key={option} label={option} size="small" {...getTagProps({ index })} />
                    ))
                  }
                  freeSolo={options.length === 0}
                  filterSelectedOptions
                />
              );
            })}
          </Stack>
        ) : (
          <Alert severity="info">No partition columns — a full scan will be performed.</Alert>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Tooltip title={hasPartitions && !queryEnabled ? 'Select at least one partition value' : ''} placement="top">
          <span>
            <Button variant="contained" startIcon={<OpenInNewIcon />} onClick={handleQuery} disabled={!queryEnabled}>
              Query Data
            </Button>
          </span>
        </Tooltip>
      </DialogActions>
    </Dialog>
  );
};

// ── Inline description editor ─────────────────────────────────────────────────

interface DescriptionEditorProps {
  connectionId: number;
  tableName: string;
  value: string;
  isAdmin: boolean;
  onChange: (desc: string) => void;
}

const DescriptionEditor: React.FC<DescriptionEditorProps> = ({
  connectionId, tableName, value, isAdmin, onChange,
}) => {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.updateTableDescription(connectionId, tableName, draft);
      onChange(draft);
    } catch { /* ignore */ } finally {
      setSaving(false); setEditing(false);
    }
  };

  if (!editing) {
    return (
      <Stack direction="row" alignItems="flex-start" spacing={0.5} sx={{ my: 0.5 }}>
        <Typography
          variant="body2"
          color={value ? 'text.primary' : 'text.disabled'}
          sx={{ flex: 1, fontSize: '0.79rem', fontStyle: value ? 'normal' : 'italic', lineHeight: 1.4 }}
        >
          {value || (isAdmin ? 'Click ✏ to add a description' : 'No description')}
        </Typography>
        {isAdmin && (
          <Tooltip title="Edit description">
            <IconButton size="small" onClick={() => { setDraft(value); setEditing(true); }} sx={{ p: 0.3, mt: -0.25 }}>
              <EditIcon sx={{ fontSize: 13 }} />
            </IconButton>
          </Tooltip>
        )}
      </Stack>
    );
  }

  return (
    <Stack direction="row" spacing={0.5} alignItems="flex-start" sx={{ my: 0.5 }}>
      <TextField
        size="small" fullWidth multiline maxRows={3}
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSave(); } }}
        autoFocus
        placeholder="Table description…"
        sx={{ '& .MuiInputBase-input': { fontSize: '0.79rem' } }}
      />
      <IconButton size="small" onClick={handleSave} disabled={saving} color="primary">
        {saving ? <CircularProgress size={13} /> : <CheckIcon sx={{ fontSize: 15 }} />}
      </IconButton>
      <IconButton size="small" onClick={() => setEditing(false)}>
        <CloseIcon sx={{ fontSize: 15 }} />
      </IconButton>
    </Stack>
  );
};

// ── TableCard ─────────────────────────────────────────────────────────────────

interface TableCardProps {
  table: CatalogTable;
  connection: CatalogConnection;
  isAdmin: boolean;
  onOpenMetadata: (conn: CatalogConnection, table: CatalogTable, initParts?: Record<string, string[]>) => void;
  onQueryData: (conn: CatalogConnection, table: CatalogTable, initParts?: Record<string, string[]>) => void;
  onPreview: (conn: CatalogConnection, table: CatalogTable) => void;
  onToggleFavorite: (connId: number, tableName: string) => void;
  onDescriptionChange: (connId: number, tableName: string, desc: string) => void;
}

const TableCard: React.FC<TableCardProps> = ({
  table, connection, isAdmin,
  onOpenMetadata, onQueryData, onPreview,
  onToggleFavorite, onDescriptionChange,
}) => {
  const isIceberg = table.format === 'iceberg';
  const hasPartitions = table.partition_columns.length > 0;
  const hasColumns = table.columns && table.columns.length > 0;
  const freshness = getFreshness(table.last_updated_at);
  const COLS_PREVIEW = 5;

  return (
    <Card variant="outlined" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardContent sx={{ pb: 0.5, flex: 1 }}>

        {/* Header: name + format + star */}
        <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mb: 0.5 }}>
          <TableIcon fontSize="small" color="action" />
          <Typography variant="subtitle1" fontWeight={700} sx={{ flex: 1, wordBreak: 'break-word', lineHeight: 1.3, fontSize: '0.95rem' }}>
            {table.name}
          </Typography>
          <Chip
            label={table.format.toUpperCase()}
            size="small"
            color={isIceberg ? 'success' : 'info'}
            variant="outlined"
            sx={{ fontWeight: 700, height: 20, fontSize: '0.62rem' }}
          />
          <Tooltip title={table.is_favorite ? 'Remove from favorites' : 'Add to favorites'}>
            <IconButton size="small" onClick={() => onToggleFavorite(connection.id, table.name)} sx={{ p: 0.3 }}>
              {table.is_favorite
                ? <StarIcon sx={{ fontSize: 17, color: 'warning.main' }} />
                : <StarBorderIcon sx={{ fontSize: 17, color: 'action.disabled' }} />}
            </IconButton>
          </Tooltip>
        </Stack>

        {/* Freshness + health chips */}
        <Stack direction="row" spacing={0.5} flexWrap="wrap" sx={{ mb: 0.75 }}>
          <Chip
            label={freshness.label}
            size="small"
            color={freshness.color}
            variant="filled"
            icon={<DotIcon sx={{ fontSize: '8px !important' }} />}
            sx={{ height: 17, fontSize: '0.62rem' }}
          />
          {table.small_file_warning && (
            <Tooltip title={`Small files detected — avg ${table.avg_file_size_mb?.toFixed(0) ?? '?'} MB. Consider running compaction.`}>
              <Chip
                label={`~${table.avg_file_size_mb?.toFixed(0) ?? '?'}MB avg`}
                size="small"
                color="warning"
                variant="outlined"
                icon={<WarningIcon sx={{ fontSize: '11px !important' }} />}
                sx={{ height: 17, fontSize: '0.62rem' }}
              />
            </Tooltip>
          )}
          {(table.preview_count ?? 0) > 0 && (
            <Chip
              label={`${table.preview_count} preview${table.preview_count !== 1 ? 's' : ''}`}
              size="small"
              variant="outlined"
              icon={<StatsIcon sx={{ fontSize: '11px !important' }} />}
              sx={{ height: 17, fontSize: '0.62rem' }}
            />
          )}
        </Stack>

        {/* S3 prefix */}
        <Tooltip title={table.s3_prefix || '(root)'} placement="top">
          <Stack direction="row" spacing={0.4} alignItems="center" sx={{ mb: 0.6 }}>
            <PrefixIcon sx={{ fontSize: 11, color: 'text.disabled', flexShrink: 0 }} />
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{ fontFamily: 'monospace', fontSize: '0.67rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
            >
              {table.s3_prefix || '(root)'}
            </Typography>
          </Stack>
        </Tooltip>

        {/* Description */}
        <DescriptionEditor
          connectionId={connection.id}
          tableName={table.name}
          value={table.description || ''}
          isAdmin={isAdmin}
          onChange={(desc) => onDescriptionChange(connection.id, table.name, desc)}
        />

        {/* Stats */}
        <Stack direction="row" spacing={1.5} flexWrap="wrap" sx={{ mb: 0.75, mt: 0.25 }}>
          <Stack direction="row" spacing={0.4} alignItems="center">
            <StorageIcon sx={{ fontSize: 11, color: 'text.disabled' }} />
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.72rem' }}>
              {table.file_count > 0 ? `${table.file_count}+ files` : 'no files'}
            </Typography>
          </Stack>
          <Stack direction="row" spacing={0.4} alignItems="center">
            <TableIcon sx={{ fontSize: 11, color: 'text.disabled' }} />
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.72rem' }}>
              {fmtCount(table.record_count)} rows
            </Typography>
          </Stack>
          {isIceberg && table.format_version != null && (
            <Chip
              label={`v${table.format_version}`}
              size="small" variant="filled"
              sx={{ height: 15, fontSize: '0.6rem', bgcolor: 'success.light', color: 'success.contrastText' }}
            />
          )}
        </Stack>

        {/* Partition columns — clickable values pre-populate the query dialog */}
        {hasPartitions && (
          <Box sx={{ mb: 0.75 }}>
            <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ display: 'block', mb: 0.3, fontSize: '0.7rem' }}>
              Partitioned by:
            </Typography>
            <Stack spacing={0.3}>
              {table.partition_columns.map(col => {
                const vals = (table.sample_partition_values || {})[col] || [];
                return (
                  <Stack key={col} direction="row" spacing={0.4} alignItems="center" flexWrap="wrap">
                    <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.62rem', flexShrink: 0 }}>
                      {col}:
                    </Typography>
                    {vals.slice(0, 4).map(v => (
                      <Tooltip key={v} title={`Query where ${col} = '${v}'`} placement="top">
                        <Chip
                          label={v}
                          size="small"
                          color="warning"
                          variant="outlined"
                          onClick={() => onQueryData(connection, table, { [col]: [v] })}
                          sx={{ height: 15, fontSize: '0.6rem', cursor: 'pointer' }}
                        />
                      </Tooltip>
                    ))}
                    {vals.length > 4 && (
                      <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.6rem' }}>
                        +{vals.length - 4} more
                      </Typography>
                    )}
                  </Stack>
                );
              })}
            </Stack>
          </Box>
        )}

        {/* Schema columns */}
        {hasColumns && (
          <Box sx={{ mb: 0.25 }}>
            <Stack direction="row" spacing={0.4} alignItems="center" sx={{ mb: 0.3 }}>
              <SchemaIcon sx={{ fontSize: 11, color: 'text.disabled' }} />
              <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ fontSize: '0.7rem' }}>
                {table.columns.length} columns
              </Typography>
            </Stack>
            <Stack direction="row" spacing={0.4} flexWrap="wrap">
              {table.columns.slice(0, COLS_PREVIEW).map(col => (
                <Chip
                  key={col.name}
                  label={`${col.name}: ${col.type}`}
                  size="small"
                  variant="outlined"
                  sx={{ fontSize: '0.6rem', maxWidth: 155, height: 17, overflow: 'hidden', textOverflow: 'ellipsis' }}
                />
              ))}
              {table.columns.length > COLS_PREVIEW && (
                <Chip
                  label={`+${table.columns.length - COLS_PREVIEW} more`}
                  size="small" variant="filled"
                  sx={{ fontSize: '0.6rem', bgcolor: 'action.hover', height: 17 }}
                />
              )}
            </Stack>
          </Box>
        )}
      </CardContent>

      <Divider />
      <CardActions sx={{ px: 1.5, py: 0.75, gap: 0.5, flexWrap: 'wrap' }}>
        <Button
          size="small" variant="outlined" startIcon={<PreviewIcon />}
          onClick={() => onPreview(connection, table)}
          sx={{ fontSize: '0.7rem', py: 0.4 }}
        >
          Preview
        </Button>
        <Button
          size="small" variant="outlined" startIcon={<CodeIcon />}
          onClick={() => onOpenMetadata(connection, table)}
          sx={{ fontSize: '0.7rem', py: 0.4 }}
        >
          {isIceberg ? 'Schema / JSON' : 'Schema'}
        </Button>
        <Button
          size="small" variant="contained" startIcon={<FilterIcon />}
          onClick={() => onQueryData(connection, table)}
          sx={{ fontSize: '0.7rem', py: 0.4 }}
        >
          Query Data
        </Button>
      </CardActions>
    </Card>
  );
};

// ── Main page ─────────────────────────────────────────────────────────────────

const MetadataCatalogPage: React.FC = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  const [catalog, setCatalog] = useState<CatalogResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState(0);
  const [expandedConnections, setExpandedConnections] = useState<Set<number>>(new Set());
  const [snack, setSnack] = useState<string | null>(null);

  // Dialog state
  const [metaDialog, setMetaDialog] = useState<{
    open: boolean; connId: number; table: CatalogTable | null;
    initParts?: Record<string, string[]>;
  }>({ open: false, connId: 0, table: null });

  const [previewDialog, setPreviewDialog] = useState<{
    open: boolean; connId: number; table: CatalogTable | null;
  }>({ open: false, connId: 0, table: null });

  const [queryDialog, setQueryDialog] = useState<{
    open: boolean; table: CatalogTable | null; connection: CatalogConnection | null;
    initParts?: Record<string, string[]>;
  }>({ open: false, table: null, connection: null });

  const loadCatalog = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getCatalogTables();
      setCatalog(data);
      const withTables = new Set<number>(
        (data.connections as CatalogConnection[])
          .filter((c: CatalogConnection) => c.tables.length > 0)
          .map((c: CatalogConnection) => c.id)
      );
      setExpandedConnections(withTables);
    } catch (e: any) {
      setError(e?.message || 'Failed to load catalog');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadCatalog(); }, [loadCatalog]);

  // Optimistic favorite toggle
  const handleToggleFavorite = useCallback(async (connId: number, tableName: string) => {
    setCatalog(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        connections: prev.connections.map(c =>
          c.id !== connId ? c : {
            ...c,
            tables: c.tables.map(t =>
              t.name !== tableName ? t : { ...t, is_favorite: !t.is_favorite }
            ),
          }
        ),
      };
    });
    try {
      await api.toggleCatalogFavorite(connId, tableName);
    } catch {
      // Revert on error
      setCatalog(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          connections: prev.connections.map(c =>
            c.id !== connId ? c : {
              ...c,
              tables: c.tables.map(t =>
                t.name !== tableName ? t : { ...t, is_favorite: !t.is_favorite }
              ),
            }
          ),
        };
      });
      setSnack('Failed to update favorite');
    }
  }, []);

  const handleDescriptionChange = useCallback((connId: number, tableName: string, desc: string) => {
    setCatalog(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        connections: prev.connections.map(c =>
          c.id !== connId ? c : {
            ...c,
            tables: c.tables.map(t =>
              t.name !== tableName ? t : { ...t, description: desc }
            ),
          }
        ),
      };
    });
    setSnack('Description saved');
  }, []);

  // Filtered connections (search + favorites tab)
  const filteredConnections = useMemo(() => {
    if (!catalog) return [];
    const q = search.toLowerCase().trim();
    let conns = catalog.connections;

    if (activeTab === 1) {
      conns = conns
        .map(c => ({ ...c, tables: c.tables.filter(t => t.is_favorite) }))
        .filter(c => c.tables.length > 0);
    }

    if (!q) return conns;
    return conns
      .map(conn => ({
        ...conn,
        tables: conn.tables.filter(t =>
          t.name.toLowerCase().includes(q) ||
          t.s3_prefix.toLowerCase().includes(q) ||
          (t.description || '').toLowerCase().includes(q) ||
          t.partition_columns.some(pc => pc.toLowerCase().includes(q)) ||
          (t.columns || []).some(c => c.name.toLowerCase().includes(q)) ||
          conn.name.toLowerCase().includes(q)
        ),
      }))
      .filter(conn => conn.tables.length > 0);
  }, [catalog, search, activeTab]);

  const toggleConnection = (connId: number) => {
    setExpandedConnections(prev => {
      const next = new Set(prev);
      if (next.has(connId)) next.delete(connId); else next.add(connId);
      return next;
    });
  };

  const stats = useMemo(() => {
    if (!catalog) return null;
    const all = catalog.connections.flatMap(c => c.tables);
    return {
      connections: catalog.total_connections,
      tables: catalog.total_tables,
      iceberg: all.filter(t => t.format === 'iceberg').length,
      favorites: all.filter(t => t.is_favorite).length,
      stale: all.filter(t => {
        if (!t.last_updated_at) return false;
        return (Date.now() - new Date(t.last_updated_at).getTime()) / 86_400_000 > 30;
      }).length,
    };
  }, [catalog]);

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <StorageIcon color="primary" sx={{ fontSize: 32 }} />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight={700}>Data Catalog</Typography>
          <Typography variant="body2" color="text.secondary">
            Registered S3 tables — schema, partitions, freshness, preview, health
          </Typography>
        </Box>
        <Tooltip title="Refresh catalog">
          <span>
            <IconButton onClick={loadCatalog} disabled={loading}><RefreshIcon /></IconButton>
          </span>
        </Tooltip>
      </Stack>

      {/* Stats bar */}
      {stats && (
        <Paper variant="outlined" sx={{ p: 1.5, mb: 2, display: 'flex', gap: 3, flexWrap: 'wrap', alignItems: 'center' }}>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" fontWeight={700}>{stats.connections}</Typography>
            <Typography variant="caption" color="text.secondary">Connections</Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" fontWeight={700}>{stats.tables}</Typography>
            <Typography variant="caption" color="text.secondary">Tables</Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" fontWeight={700} color="success.main">{stats.iceberg}</Typography>
            <Typography variant="caption" color="text.secondary">Iceberg</Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" fontWeight={700} color="warning.main">{stats.favorites}</Typography>
            <Typography variant="caption" color="text.secondary">Favorites</Typography>
          </Box>
          {stats.stale > 0 && (
            <Chip
              label={`${stats.stale} stale (>30d)`}
              size="small" color="error" variant="outlined"
              icon={<WarningIcon />}
            />
          )}
        </Paper>
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)} sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Tab label="All Tables" />
        <Tab
          label={
            <Stack direction="row" spacing={0.5} alignItems="center">
              <StarIcon sx={{ fontSize: 15, color: 'warning.main' }} />
              <span>My Favorites</span>
              {stats && stats.favorites > 0 && (
                <Chip label={stats.favorites} size="small" sx={{ height: 15, fontSize: '0.58rem', ml: 0.25 }} />
              )}
            </Stack>
          }
        />
      </Tabs>

      {/* Search */}
      <TextField
        fullWidth size="small"
        placeholder="Search by table, column, partition, description or connection name…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        InputProps={{
          startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" color="action" /></InputAdornment>,
          endAdornment: search
            ? <InputAdornment position="end"><IconButton size="small" onClick={() => setSearch('')}><CloseIcon fontSize="small" /></IconButton></InputAdornment>
            : null,
        }}
        sx={{ mb: 2 }}
      />

      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}><CircularProgress /></Box>
      )}

      {error && !loading && (
        <Alert severity="error" sx={{ mb: 2 }} action={
          <Button color="inherit" size="small" onClick={loadCatalog}>Retry</Button>
        }>{error}</Alert>
      )}

      {/* My Favorites empty */}
      {!loading && activeTab === 1 && filteredConnections.length === 0 && (
        <Paper variant="outlined" sx={{ p: 6, textAlign: 'center', borderStyle: 'dashed' }}>
          <StarBorderIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
          <Typography variant="h6" color="text.secondary">No favorites yet</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Click ★ on any table card to add it to your favorites.
          </Typography>
        </Paper>
      )}

      {/* All empty */}
      {!loading && !error && activeTab === 0 && catalog && catalog.total_connections === 0 && (
        <Paper variant="outlined" sx={{ p: 6, textAlign: 'center', borderStyle: 'dashed' }}>
          <StorageIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
          <Typography variant="h6" color="text.secondary">No S3 connections found</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Add an S3 connection and register tables to see them here.
          </Typography>
        </Paper>
      )}

      {/* Connection accordions */}
      {!loading && filteredConnections.map(conn => (
        <Accordion
          key={conn.id}
          expanded={expandedConnections.has(conn.id)}
          onChange={() => toggleConnection(conn.id)}
          variant="outlined"
          sx={{ mb: 1.5, '&:before': { display: 'none' } }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Stack direction="row" spacing={1.5} alignItems="center" sx={{ flex: 1, pr: 2 }}>
              <StorageIcon color="primary" fontSize="small" />
              <Typography variant="subtitle1" fontWeight={600}>{conn.name}</Typography>
              <Chip label={conn.connection_type.toUpperCase()} size="small" variant="outlined" sx={{ fontSize: 10, height: 18 }} />
              <Box sx={{ flex: 1 }} />
              <Chip
                label={`${conn.tables.length} table${conn.tables.length !== 1 ? 's' : ''}`}
                size="small"
                color={conn.tables.length > 0 ? 'primary' : 'default'}
                variant="filled"
              />
            </Stack>
          </AccordionSummary>
          <AccordionDetails sx={{ pt: 1 }}>
            {conn.tables.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
                No registered tables for this connection.
              </Typography>
            ) : (
              <Grid container spacing={2}>
                {conn.tables.map(table => (
                  <Grid key={table.name} size={{ xs: 12, md: 6, lg: 4 }}>
                    <TableCard
                      table={table}
                      connection={conn}
                      isAdmin={isAdmin}
                      onOpenMetadata={(c, t, ip) => setMetaDialog({ open: true, connId: c.id, table: t, initParts: ip })}
                      onQueryData={(c, t, ip) => setQueryDialog({ open: true, table: t, connection: c, initParts: ip })}
                      onPreview={(c, t) => setPreviewDialog({ open: true, connId: c.id, table: t })}
                      onToggleFavorite={handleToggleFavorite}
                      onDescriptionChange={handleDescriptionChange}
                    />
                  </Grid>
                ))}
              </Grid>
            )}
          </AccordionDetails>
        </Accordion>
      ))}

      {/* Search empty state */}
      {!loading && !error && catalog && catalog.total_tables > 0 && search && filteredConnections.length === 0 && (
        <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', borderStyle: 'dashed' }}>
          <Typography color="text.secondary">No tables match "<strong>{search}</strong>"</Typography>
        </Paper>
      )}

      {/* Metadata / Schema dialog */}
      <MetadataDialog
        open={metaDialog.open}
        connectionId={metaDialog.connId}
        table={metaDialog.table}
        onClose={() => setMetaDialog(d => ({ ...d, open: false }))}
        onQueryPartition={(initParts) => {
          const conn = catalog?.connections.find(c => c.id === metaDialog.connId) || null;
          setMetaDialog(d => ({ ...d, open: false }));
          setQueryDialog({ open: true, table: metaDialog.table, connection: conn, initParts });
        }}
      />

      {/* Preview dialog */}
      <PreviewDialog
        open={previewDialog.open}
        connectionId={previewDialog.connId}
        table={previewDialog.table}
        onClose={() => setPreviewDialog(d => ({ ...d, open: false }))}
      />

      {/* Partition Query dialog */}
      <PartitionQueryDialog
        open={queryDialog.open}
        table={queryDialog.table}
        connection={queryDialog.connection}
        initialValues={queryDialog.initParts}
        onClose={() => setQueryDialog(d => ({ ...d, open: false }))}
      />

      {/* Snackbar */}
      <Snackbar
        open={!!snack}
        autoHideDuration={2500}
        onClose={() => setSnack(null)}
        message={snack}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Box>
  );
};

export default MetadataCatalogPage;
