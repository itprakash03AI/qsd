/**
 * FeedCalendarsPage — Phase 130/5
 *
 * Admin UI for the named business calendars + per-calendar holiday list
 * that drive ACTION_CONDITION evaluation and filename rendering for
 * enterprise feeds.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Stack, Alert, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, FormControlLabel, Switch, Chip, Divider,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Refresh as RefreshIcon, Event as DateIcon,
} from '@mui/icons-material';
import api from '../services/api';

type FeedCalendar = {
  id: number;
  name: string;
  description?: string | null;
  weekend_days?: number[] | null;
  is_active: boolean;
  holidays?: FeedHoliday[];
  created_by?: string | null;
  created_at?: string | null;
};

type FeedHoliday = {
  id: number;
  calendar_id: number;
  holiday_date: string;
  holiday_name?: string | null;
  recurring: boolean;
};

const WEEKDAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const FeedCalendarsPage: React.FC = () => {
  const [calendars, setCalendars] = useState<FeedCalendar[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<FeedCalendar | null>(null);
  const [showCreate, setShowCreate] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list: any = await api.listFeedCalendars();
      const items: FeedCalendar[] = Array.isArray(list) ? list : (list?.items ?? []);
      // Hydrate each with its holidays so the table can show counts
      const hydrated = await Promise.all(items.map(async (c) => {
        try {
          const full: any = await api.getFeedCalendar(c.id);
          return { ...c, holidays: full?.holidays || [] };
        } catch { return c; }
      }));
      setCalendars(hydrated);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDeleteCalendar = async (id: number) => {
    if (!window.confirm(`Delete this calendar?  All holidays will be removed.`)) return;
    try {
      await api.deleteFeedCalendar(id);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Typography variant="h5">Business Calendars</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setShowCreate(true)}>
            New calendar
          </Button>
        </Stack>
      </Stack>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Weekend days</TableCell>
              <TableCell>Holidays</TableCell>
              <TableCell>Active</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow>
                <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                  <CircularProgress size={24} />
                </TableCell>
              </TableRow>
            )}
            {!loading && calendars.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  No calendars yet — create one to enable ACTION_CONDITION + COB_* tokens.
                </TableCell>
              </TableRow>
            )}
            {calendars.map(c => (
              <TableRow key={c.id} hover>
                <TableCell>{c.id}</TableCell>
                <TableCell><strong>{c.name}</strong></TableCell>
                <TableCell>
                  <Typography variant="caption">{c.description || '—'}</Typography>
                </TableCell>
                <TableCell>
                  {(c.weekend_days || []).map((d: number) => (
                    <Chip
                      key={d}
                      label={WEEKDAY_LABELS[Math.min(Math.max(d - 1, 0), 6)]}
                      size="small"
                      sx={{ mr: 0.5 }}
                    />
                  ))}
                  {(!c.weekend_days || c.weekend_days.length === 0) && (
                    <Typography variant="caption" color="text.secondary">system default</Typography>
                  )}
                </TableCell>
                <TableCell>
                  <Chip label={`${c.holidays?.length ?? 0}`} size="small" />
                </TableCell>
                <TableCell>
                  <Chip
                    label={c.is_active ? 'Active' : 'Inactive'}
                    color={c.is_active ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => setEditing(c)}>
                    <EditIcon fontSize="small" />
                  </IconButton>
                  <IconButton size="small" onClick={() => handleDeleteCalendar(c.id)}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>

      {showCreate && (
        <CalendarFormDialog
          onClose={() => setShowCreate(false)}
          onSaved={async () => { setShowCreate(false); await load(); }}
        />
      )}
      {editing && (
        <CalendarEditDialog
          calendar={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => { setEditing(null); await load(); }}
          onError={setError}
        />
      )}
    </Box>
  );
};


/* ── Create dialog ────────────────────────────────────────────────── */

const CalendarFormDialog: React.FC<{
  onClose: () => void;
  onSaved: () => void;
}> = ({ onClose, onSaved }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [weekendDays, setWeekendDays] = useState<number[]>([6, 7]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const toggleDay = (d: number) => {
    setWeekendDays(wd => wd.includes(d) ? wd.filter(x => x !== d) : [...wd, d]);
  };

  const handleSave = async () => {
    if (!name.trim()) { setErr('Name is required'); return; }
    setBusy(true); setErr(null);
    try {
      await api.createFeedCalendar({
        name: name.trim(),
        description: description.trim() || undefined,
        weekend_days: weekendDays,
        is_active: true,
      });
      onSaved();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>New business calendar</DialogTitle>
      <DialogContent>
        {err && <Alert severity="error" sx={{ mb: 2 }}>{err}</Alert>}
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Name"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="US_BANKING"
            autoFocus
            fullWidth
          />
          <TextField
            label="Description"
            value={description}
            onChange={e => setDescription(e.target.value)}
            multiline
            rows={2}
            fullWidth
          />
          <Box>
            <Typography variant="caption" color="text.secondary">Weekend days</Typography>
            <Stack direction="row" spacing={1} sx={{ mt: 0.5 }}>
              {WEEKDAY_LABELS.map((lbl, i) => {
                const d = i + 1;
                const on = weekendDays.includes(d);
                return (
                  <Chip
                    key={d}
                    label={lbl}
                    color={on ? 'primary' : 'default'}
                    variant={on ? 'filled' : 'outlined'}
                    onClick={() => toggleDay(d)}
                    size="small"
                  />
                );
              })}
            </Stack>
          </Box>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={busy}>
          {busy ? <CircularProgress size={16} /> : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};


/* ── Edit dialog (incl. holidays) ─────────────────────────────────── */

const CalendarEditDialog: React.FC<{
  calendar: FeedCalendar;
  onClose: () => void;
  onSaved: () => void;
  onError: (msg: string) => void;
}> = ({ calendar, onClose, onSaved, onError }) => {
  const [description, setDescription] = useState(calendar.description || '');
  const [weekendDays, setWeekendDays] = useState<number[]>(calendar.weekend_days || []);
  const [isActive, setIsActive] = useState(calendar.is_active);
  const [holidays, setHolidays] = useState<FeedHoliday[]>(calendar.holidays || []);
  const [newDate, setNewDate] = useState('');
  const [newName, setNewName] = useState('');
  const [newRecurring, setNewRecurring] = useState(false);
  const [busy, setBusy] = useState(false);

  const toggleDay = (d: number) => {
    setWeekendDays(wd => wd.includes(d) ? wd.filter(x => x !== d) : [...wd, d]);
  };

  const saveSettings = async () => {
    setBusy(true);
    try {
      await api.updateFeedCalendar(calendar.id, {
        description: description || null,
        weekend_days: weekendDays,
        is_active: isActive,
      });
      onSaved();
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const addHoliday = async () => {
    if (!newDate) return;
    setBusy(true);
    try {
      const row: any = await api.addFeedHoliday(calendar.id, {
        holiday_date: newDate,
        holiday_name: newName || undefined,
        recurring: newRecurring,
      });
      setHolidays(h => [...h, row].sort((a, b) =>
        a.holiday_date.localeCompare(b.holiday_date)));
      setNewDate(''); setNewName(''); setNewRecurring(false);
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const removeHoliday = async (id: number) => {
    setBusy(true);
    try {
      await api.deleteFeedHoliday(id);
      setHolidays(h => h.filter(x => x.id !== id));
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>{calendar.name}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Description"
            value={description}
            onChange={e => setDescription(e.target.value)}
            fullWidth
            multiline
            rows={2}
          />
          <Box>
            <Typography variant="caption" color="text.secondary">Weekend days</Typography>
            <Stack direction="row" spacing={1} sx={{ mt: 0.5 }}>
              {WEEKDAY_LABELS.map((lbl, i) => {
                const d = i + 1;
                const on = weekendDays.includes(d);
                return (
                  <Chip
                    key={d}
                    label={lbl}
                    color={on ? 'primary' : 'default'}
                    variant={on ? 'filled' : 'outlined'}
                    onClick={() => toggleDay(d)}
                    size="small"
                  />
                );
              })}
            </Stack>
          </Box>
          <FormControlLabel
            control={<Switch checked={isActive} onChange={e => setIsActive(e.target.checked)} />}
            label="Active"
          />
          <Button onClick={saveSettings} variant="outlined" disabled={busy}>Save settings</Button>

          <Divider />

          <Typography variant="subtitle1">Holidays</Typography>
          <Stack direction="row" spacing={1} alignItems="flex-end">
            <TextField
              type="date"
              label="Date"
              size="small"
              value={newDate}
              onChange={e => setNewDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              label="Name"
              size="small"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              placeholder="Christmas"
            />
            <FormControlLabel
              control={<Switch checked={newRecurring} onChange={e => setNewRecurring(e.target.checked)} />}
              label="Recurring"
            />
            <Button startIcon={<AddIcon />} onClick={addHoliday} disabled={busy || !newDate}>
              Add
            </Button>
          </Stack>

          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Recurring</TableCell>
                <TableCell align="right" />
              </TableRow>
            </TableHead>
            <TableBody>
              {holidays.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} align="center" sx={{ color: 'text.secondary' }}>
                    No holidays
                  </TableCell>
                </TableRow>
              )}
              {holidays.map(h => (
                <TableRow key={h.id}>
                  <TableCell>
                    <DateIcon sx={{ fontSize: 14, mr: 0.5, verticalAlign: 'middle' }} />
                    {h.holiday_date}
                  </TableCell>
                  <TableCell>{h.holiday_name || '—'}</TableCell>
                  <TableCell>{h.recurring ? <Chip label="yearly" size="small" /> : '—'}</TableCell>
                  <TableCell align="right">
                    <IconButton size="small" onClick={() => removeHoliday(h.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default FeedCalendarsPage;
