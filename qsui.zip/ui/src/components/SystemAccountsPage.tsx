/**
 * Phase 87 — System Accounts Management Page.
 * Admin CRUD for service/system accounts used for auto-credential fetching.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, IconButton, Chip, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Alert, CircularProgress, Tooltip, Stack,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  PlayArrow as TestIcon,
  Refresh as RefreshIcon,
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
} from '@mui/icons-material';
import api from '../services/api';

interface SystemAccount {
  id: number;
  name: string;
  account_type: string;
  username: string;
  password: string;
  config: any;
  is_active: boolean;
  last_used_at: string | null;
  last_status: string | null;
  last_error: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
}

const ACCOUNT_TYPES = [
  { value: 'aws_portal', label: 'AWS Portal (S3 Connections)' },
  { value: 'snowflake_sso', label: 'Snowflake SSO' },
];

const SystemAccountsPage: React.FC = () => {
  const [accounts, setAccounts] = useState<SystemAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: '', account_type: 'aws_portal', username: '', password: '', config: {} as any });
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<number | null>(null);
  const [testResult, setTestResult] = useState<{ id: number; success: boolean; message: string } | null>(null);
  const [error, setError] = useState('');

  const loadAccounts = useCallback(async () => {
    setLoading(true);
    try {
      const res: any = await api.get('/api/admin/system-accounts');
      setAccounts(res.accounts || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load system accounts');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      if (editingId) {
        const updates: any = {};
        if (form.name) updates.name = form.name;
        if (form.username) updates.username = form.username;
        if (form.password && form.password !== '***') updates.password = form.password;
        await api.put(`/api/admin/system-accounts/${editingId}`, updates);
      } else {
        await api.post('/api/admin/system-accounts', form);
      }
      setDialogOpen(false);
      loadAccounts();
    } catch (e: any) {
      setError(e?.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Delete this system account? Connections using it will lose credential access.')) return;
    try {
      await api.delete(`/api/admin/system-accounts/${id}`);
      loadAccounts();
    } catch (e: any) {
      setError(e?.message || 'Delete failed');
    }
  };

  const handleTest = async (id: number) => {
    setTesting(id);
    setTestResult(null);
    try {
      const res: any = await api.post(`/api/admin/system-accounts/${id}/test`);
      setTestResult({ id, success: res.success, message: res.message });
    } catch (e: any) {
      setTestResult({ id, success: false, message: e?.message || 'Test failed' });
    } finally {
      setTesting(null);
    }
  };

  const handleRefresh = async (id: number) => {
    setTesting(id);
    try {
      const res: any = await api.post(`/api/admin/system-accounts/${id}/refresh`);
      setTestResult({ id, success: res.success, message: res.message });
      loadAccounts();
    } catch (e: any) {
      setTestResult({ id, success: false, message: e?.message || 'Refresh failed' });
    } finally {
      setTesting(null);
    }
  };

  const openCreate = () => {
    setEditingId(null);
    setForm({ name: '', account_type: 'aws_portal', username: '', password: '', config: {} });
    setDialogOpen(true);
    setError('');
  };

  const openEdit = (acct: SystemAccount) => {
    setEditingId(acct.id);
    setForm({ name: acct.name, account_type: acct.account_type, username: acct.username, password: '***', config: acct.config || {} });
    setDialogOpen(true);
    setError('');
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1100, mx: 'auto' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h5" sx={{ fontWeight: 600 }}>System Accounts</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} size="small">
          Add System Account
        </Button>
      </Box>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Service accounts used for automatic credential fetching. Assign these to S3 or Snowflake
        connections using the "Auto (Portal SSO)" auth mode. Passwords are encrypted at rest.
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : accounts.length === 0 ? (
        <Alert severity="info">
          No system accounts configured. Click "Add System Account" to create one.
        </Alert>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Username</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Last Used</TableCell>
                <TableCell>Active</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {accounts.map(acct => (
                <TableRow key={acct.id}>
                  <TableCell><Typography variant="body2" fontWeight={600}>{acct.name}</Typography></TableCell>
                  <TableCell>
                    <Chip label={ACCOUNT_TYPES.find(t => t.value === acct.account_type)?.label || acct.account_type}
                          size="small" variant="outlined" />
                  </TableCell>
                  <TableCell>{acct.username}</TableCell>
                  <TableCell>
                    {acct.last_status === 'success' && <Chip icon={<SuccessIcon />} label="OK" size="small" color="success" variant="outlined" />}
                    {acct.last_status === 'failed' && (
                      <Tooltip title={acct.last_error || ''}>
                        <Chip icon={<ErrorIcon />} label="Failed" size="small" color="error" variant="outlined" />
                      </Tooltip>
                    )}
                    {!acct.last_status && <Chip label="Untested" size="small" variant="outlined" />}
                    {testResult?.id === acct.id && (
                      <Typography variant="caption" sx={{ ml: 1 }} color={testResult.success ? 'success.main' : 'error.main'}>
                        {testResult.message}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    {acct.last_used_at ? new Date(acct.last_used_at).toLocaleDateString() : '—'}
                  </TableCell>
                  <TableCell>
                    <Chip label={acct.is_active ? 'Active' : 'Inactive'} size="small"
                          color={acct.is_active ? 'success' : 'default'} variant="outlined" />
                  </TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0} justifyContent="flex-end">
                      <Tooltip title="Test credentials">
                        <IconButton size="small" onClick={() => handleTest(acct.id)}
                                    disabled={testing === acct.id}>
                          {testing === acct.id ? <CircularProgress size={16} /> : <TestIcon fontSize="small" />}
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Refresh cached credentials">
                        <IconButton size="small" onClick={() => handleRefresh(acct.id)}
                                    disabled={testing === acct.id}>
                          <RefreshIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => openEdit(acct)}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton size="small" color="error" onClick={() => handleDelete(acct.id)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingId ? 'Edit System Account' : 'Create System Account'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" required size="small" fullWidth
              value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="production-aws-portal"
              helperText="Unique identifier for this account"
            />
            <TextField select label="Account Type" required size="small" fullWidth
              value={form.account_type}
              onChange={e => setForm(f => ({ ...f, account_type: e.target.value }))}
              disabled={!!editingId}
            >
              {ACCOUNT_TYPES.map(t => (
                <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>
              ))}
            </TextField>
            <TextField label="Username" required size="small" fullWidth
              value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
              placeholder={form.account_type === 'aws_portal' ? 'svc-aws-reader' : 'SVC_SNOWFLAKE_USER'}
              helperText={form.account_type === 'aws_portal'
                ? 'Portal login username (AD/SSO service account)'
                : 'Snowflake service account username'}
            />
            <TextField label="Password" required size="small" fullWidth type="password"
              value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              helperText="Encrypted at rest. Enter new value to change."
            />
            {error && <Alert severity="error">{error}</Alert>}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving || !form.name || !form.username || !form.password}>
            {saving ? <CircularProgress size={20} /> : (editingId ? 'Save' : 'Create')}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SystemAccountsPage;
