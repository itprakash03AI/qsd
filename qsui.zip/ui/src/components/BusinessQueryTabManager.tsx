/**
 * BusinessQueryTabManager — Tabbed wrapper for BusinessQueryBuilder.
 * Mirrors QueryTabManager (CQB) but wraps BQB instances.
 *
 * Phase 133-I round 24 — tabs persist in localStorage (was
 * sessionStorage).  sessionStorage gets wiped on browser-close, so
 * loaded queries vanished on next login.  localStorage survives
 * logout/login and browser restarts — the user expects their work
 * to still be there when they come back.
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, IconButton, Tooltip, TextField, Menu, MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  Close as CloseIcon,
  Edit as EditIcon,
  FiberManualRecord as DotIcon,
} from '@mui/icons-material';
import BusinessQueryBuilder from './BusinessQueryBuilder';
import type { BqbTabSnapshot } from './business-query/types';
import { safeStringify } from './business-query/utils';

export type { BqbTabSnapshot };

interface TabState {
  id: string;
  name: string;
  dirty: boolean;
  snapshot: BqbTabSnapshot | null;
}

const STORAGE_KEY = 'qs_bqb_tabs';
const MAX_TABS = 10;

const makeId = () => `bqb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

const defaultTab = (): TabState => ({
  id: makeId(),
  name: 'New Query',
  dirty: false,
  snapshot: null,
});

// ── Component ────────────────────────────────────────────────────────────────

const BusinessQueryTabManager = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [tabs, setTabs] = useState<TabState[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [renameTabId, setRenameTabId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [contextMenu, setContextMenu] = useState<{ anchorEl: HTMLElement; tabId: string } | null>(null);
  const initialized = useRef(false);
  const snapshotRef = useRef<Record<string, BqbTabSnapshot | null>>({});

  // ── Initialize from localStorage ────────────────────────────────────
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    // Phase 133-I round 24 — one-shot migration from the old
    // sessionStorage key so existing users don't lose open tabs on
    // first login after upgrade.
    try {
      const legacy = sessionStorage.getItem(STORAGE_KEY);
      if (legacy && !localStorage.getItem(STORAGE_KEY)) {
        localStorage.setItem(STORAGE_KEY, legacy);
      }
      if (legacy) sessionStorage.removeItem(STORAGE_KEY);
    } catch { /* migration is best-effort */ }
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.tabs?.length > 0) {
          setTabs(parsed.tabs);
          setActiveTabId(parsed.activeTabId || parsed.tabs[0].id);
          for (const t of parsed.tabs) {
            snapshotRef.current[t.id] = t.snapshot;
          }
          return;
        }
      }
    } catch { /* ignore */ }
    const tab = defaultTab();
    setTabs([tab]);
    setActiveTabId(tab.id);
  }, []);

  // ── Persist to localStorage ─────────────────────────────────────────
  useEffect(() => {
    if (tabs.length === 0) return;
    const tabsWithSnapshots = tabs.map(t => ({
      ...t,
      snapshot: snapshotRef.current[t.id] ?? t.snapshot,
    }));
    // BF-426: safeStringify defends against accidentally captured DOM/Window
    // refs in snapshot fields (e.g., a child setter called with `e` instead of
    // `e.target.value`) — would otherwise throw "Converting circular structure
    // to JSON" and lose the entire tab state.
    try {
      localStorage.setItem(STORAGE_KEY, safeStringify({
        tabs: tabsWithSnapshots,
        activeTabId,
      }));
    } catch {
      // localStorage may be disabled or full — survival over persistence
    }
  }, [tabs, activeTabId]);

  // ── Handle openLocalTable navigation ──────────────────────────────────
  useEffect(() => {
    const tableName = location.state?.openLocalTable;
    if (!tableName) return;
    const path = `__local__:${tableName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.selectedTables || []).some((st: any) => st.path === path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: tableName,
      dirty: false,
      snapshot: {
        selectedConnId: null,
        selectedTables: [{ name: tableName, path }],
        selectedCrossTables: [],
        selectedPhysical: [],
        columnAggregations: {},
        columnTransforms: {},
        filters: [],
        sortColumns: [],
        joinConfig: null,
        queryLimit: 5000,
        sqlText: '',
        executionId: null,
        savedQueryId: null,
        savedQueryName: '',
        cacheStrategy: 'auto',
        showCrossConn: false,
        crossConnId: null,
        crossConnMode: 'union',
        crossJoinHow: 'inner',
        crossJoinLeftOn: '',
        crossJoinRightOn: '',
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.openLocalTable]); // eslint-disable-line

  // ── Handle openMaterializedView navigation ────────────────────────────
  useEffect(() => {
    const mvName = location.state?.openMaterializedView;
    if (!mvName) return;
    const path = `__materialized__:${mvName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.selectedTables || []).some((st: any) => st.path === path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: mvName,
      dirty: false,
      snapshot: {
        selectedConnId: null,
        selectedTables: [{ name: mvName, path }],
        selectedCrossTables: [],
        selectedPhysical: [],
        columnAggregations: {},
        columnTransforms: {},
        filters: [],
        sortColumns: [],
        joinConfig: null,
        queryLimit: 5000,
        sqlText: '',
        executionId: null,
        savedQueryId: null,
        savedQueryName: '',
        cacheStrategy: 'auto',
        showCrossConn: false,
        crossConnId: null,
        crossConnMode: 'union',
        crossJoinHow: 'inner',
        crossJoinLeftOn: '',
        crossJoinRightOn: '',
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.openMaterializedView]); // eslint-disable-line

  // ── Handle loadQuery from SavedQueries ────────────────────────────────
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    const existing = tabs.find(t =>
      t.snapshot?.savedQueryId === loadQuery.id ||
      t.snapshot?.savedQueryId === Number(loadQuery.id)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/smart-query', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: loadQuery.name || 'Loaded Query',
      dirty: false,
      snapshot: {
        selectedConnId: loadQuery.query_config?.connection_id || null,
        selectedTables: (loadQuery.query_config?.files || []).map((f: string) => ({
          name: f.replace(/^__\w+__:/, ''),
          path: f,
        })),
        selectedCrossTables: [],
        selectedPhysical: loadQuery.query_config?.columns || [],
        columnAggregations: {},
        columnTransforms: {},
        filters: loadQuery.query_config?.filters || [],
        sortColumns: [],
        joinConfig: null,
        queryLimit: loadQuery.query_config?.limit || 5000,
        sqlText: loadQuery.raw_sql || '',
        executionId: null,
        savedQueryId: Number(loadQuery.id),
        savedQueryName: loadQuery.name || '',
        cacheStrategy: 'auto',
        showCrossConn: false,
        crossConnId: null,
        crossConnMode: 'union',
        crossJoinHow: 'inner',
        crossJoinLeftOn: '',
        crossJoinRightOn: '',
        having: [],
        computedColumns: [],
        caseExpressions: [],
        windowFunctions: [],
        distinct: false,
        filterLogic: 'AND',
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/smart-query', { replace: true, state: {} });
  }, [location.state?.loadQuery]); // eslint-disable-line

  // ── Tab operations ────────────────────────────────────────────────────
  const createTab = useCallback(() => {
    if (tabs.length >= MAX_TABS) return;
    const tab = defaultTab();
    setTabs(prev => [...prev, tab]);
    setActiveTabId(tab.id);
  }, [tabs.length]);

  const closeTab = useCallback((id: string) => {
    setTabs(prev => {
      const next = prev.filter(t => t.id !== id);
      if (next.length === 0) {
        const tab = defaultTab();
        next.push(tab);
        setActiveTabId(tab.id);
      } else if (activeTabId === id) {
        const idx = prev.findIndex(t => t.id === id);
        const newIdx = idx > 0 ? idx - 1 : 0;
        setActiveTabId(next[newIdx]?.id || next[0].id);
      }
      delete snapshotRef.current[id];
      return next;
    });
  }, [activeTabId]);

  const switchTab = useCallback((id: string) => {
    if (id === activeTabId) return;
    setActiveTabId(id);
  }, [activeTabId]);

  const renameTab = useCallback((id: string, name: string) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, name: name || 'Untitled' } : t));
  }, []);

  // ── Callbacks from BusinessQueryBuilder ────────────────────────────────
  const handleSnapshotChange = useCallback((tabId: string, snapshot: BqbTabSnapshot) => {
    snapshotRef.current[tabId] = snapshot;
  }, []);

  const handleDirtyChange = useCallback((tabId: string, dirty: boolean) => {
    setTabs(prev => prev.map(t => t.id === tabId ? { ...t, dirty } : t));
  }, []);

  const handleNameChange = useCallback((tabId: string, name: string) => {
    if (name) setTabs(prev => prev.map(t => t.id === tabId ? { ...t, name } : t));
  }, []);

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', flexDirection: 'column' }}>
      {/* ── Tab Bar ── */}
      <Box sx={{
        display: 'flex', alignItems: 'center', gap: 0,
        borderBottom: 1, borderColor: 'divider',
        bgcolor: 'background.paper', px: 0.5, minHeight: 34,
        overflowX: 'auto', flexShrink: 0,
        '&::-webkit-scrollbar': { height: 3 },
        '&::-webkit-scrollbar-thumb': { bgcolor: 'divider', borderRadius: 2 },
      }}>
        {tabs.map(tab => (
          <Box
            key={tab.id}
            onContextMenu={(e) => { e.preventDefault(); setContextMenu({ anchorEl: e.currentTarget as HTMLElement, tabId: tab.id }); }}
            sx={{
              display: 'flex', alignItems: 'center', gap: 0.3,
              px: 1.2, py: 0.4, cursor: 'pointer', userSelect: 'none',
              borderBottom: tab.id === activeTabId ? '2px solid' : '2px solid transparent',
              borderBottomColor: tab.id === activeTabId ? 'primary.main' : 'transparent',
              bgcolor: tab.id === activeTabId ? 'action.selected' : 'transparent',
              '&:hover': { bgcolor: 'action.hover' },
              borderRight: 1, borderRightColor: 'divider',
              minWidth: 'fit-content', maxWidth: 200,
              transition: 'background-color 0.15s',
            }}
            onClick={() => switchTab(tab.id)}
          >
            {tab.dirty && (
              <DotIcon sx={{ fontSize: 8, color: 'warning.main', mr: 0.3 }} />
            )}
            {renameTabId === tab.id ? (
              <TextField
                size="small" variant="standard" autoFocus
                value={renameValue}
                onChange={e => setRenameValue(e.target.value)}
                onBlur={() => { renameTab(tab.id, renameValue); setRenameTabId(null); }}
                onKeyDown={e => {
                  if (e.key === 'Enter') { renameTab(tab.id, renameValue); setRenameTabId(null); }
                  if (e.key === 'Escape') setRenameTabId(null);
                }}
                inputProps={{ style: { fontSize: 12, padding: '0 4px', width: 100 } }}
                sx={{ '& .MuiInput-underline:before': { borderBottom: 'none' } }}
              />
            ) : (
              <Typography
                variant="caption" noWrap
                sx={{
                  fontSize: 12, fontWeight: tab.id === activeTabId ? 600 : 400,
                  color: tab.id === activeTabId ? 'text.primary' : 'text.secondary',
                  maxWidth: 150,
                }}
                onDoubleClick={() => { setRenameTabId(tab.id); setRenameValue(tab.name); }}
              >
                {tab.name}
              </Typography>
            )}
            {tabs.length > 1 && (
              <IconButton
                size="small"
                onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                sx={{ p: 0.15, ml: 0.3, opacity: 0.5, '&:hover': { opacity: 1 } }}
              >
                <CloseIcon sx={{ fontSize: 13 }} />
              </IconButton>
            )}
          </Box>
        ))}

        <Tooltip title={tabs.length >= MAX_TABS ? `Max ${MAX_TABS} tabs` : 'New query tab'}>
          <span>
            <IconButton size="small" onClick={createTab} disabled={tabs.length >= MAX_TABS}
              sx={{ mx: 0.5, p: 0.3 }}>
              <AddIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </span>
        </Tooltip>
      </Box>

      {/* ── Context Menu ── */}
      <Menu
        open={!!contextMenu}
        onClose={() => setContextMenu(null)}
        anchorEl={contextMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => {
          if (contextMenu) { setRenameTabId(contextMenu.tabId); setRenameValue(tabs.find(t => t.id === contextMenu.tabId)?.name || ''); }
          setContextMenu(null);
        }}>
          <EditIcon sx={{ fontSize: 14, mr: 1 }} /> Rename
        </MenuItem>
        <MenuItem dense onClick={() => { createTab(); setContextMenu(null); }}>
          <AddIcon sx={{ fontSize: 14, mr: 1 }} /> New Tab
        </MenuItem>
        {tabs.length > 1 && (
          <MenuItem dense onClick={() => { if (contextMenu) closeTab(contextMenu.tabId); setContextMenu(null); }}>
            <CloseIcon sx={{ fontSize: 14, mr: 1 }} /> Close
          </MenuItem>
        )}
      </Menu>

      {/* ── Tab Contents (kept mounted via visibility) ── */}
      <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {tabs.map(tab => {
          const active = tab.id === activeTabId;
          return (
            <Box
              key={tab.id}
              sx={{
                position: 'absolute',
                top: 0, left: 0, right: 0, bottom: 0,
                visibility: active ? 'visible' : 'hidden',
                zIndex: active ? 1 : 0,
              }}
            >
              <BusinessQueryBuilder
                tabId={tab.id}
                isActive={active}
                initialSnapshot={tab.snapshot || snapshotRef.current[tab.id]}
                onSnapshotChange={(snapshot) => handleSnapshotChange(tab.id, snapshot)}
                onDirtyChange={(dirty) => handleDirtyChange(tab.id, dirty)}
                onNameChange={(name) => handleNameChange(tab.id, name)}
              />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default BusinessQueryTabManager;
