/**
 * MyGroupsPage — Phase 130 hotfix-13.
 *
 * End-user page showing which entitlement groups the current user
 * belongs to and what their access level is in each one.
 *
 * Wired to /api/user-groups/my which returns:
 *   [{ id, name, description, notification_email, role_in_group,
 *      resource_access_level, added_at, ... }]
 *
 * Available to ANY authenticated user (not admin-gated) because
 * users need to understand their own entitlements without asking an
 * admin to fish through user_group_members for them.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Container,
  Divider,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import GroupIcon from '@mui/icons-material/Group';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import api from '../services/api';

interface MyGroupRow {
  id:                     number;
  name:                   string;
  description:            string | null;
  is_active:              boolean;
  notification_email:     string | null;
  role_in_group:          string;
  resource_access_level:  string;
  added_at:               string | null;
}

const accessChip = (level: string) => {
  if (level === 'read_write') {
    return (
      <Tooltip title="You can view AND edit (rerun, cancel, modify) feeds and reports owned by this group.">
        <Chip
          icon={<LockOpenIcon />}
          label="read-write"
          size="small"
          color="success"
          variant="filled"
        />
      </Tooltip>
    );
  }
  return (
    <Tooltip title="You can VIEW group-owned feeds and reports (and download their outputs) but cannot edit, rerun, or modify them.">
      <Chip
        icon={<LockIcon />}
        label="read-only"
        size="small"
        color="warning"
        variant="filled"
      />
    </Tooltip>
  );
};

const roleChip = (role: string) => {
  const color = role === 'owner' || role === 'admin' ? 'primary' : 'default';
  return (
    <Tooltip title={
      role === 'member'
        ? "You're a regular member — you have the resource access shown above, but you can't manage who else is in the group."
        : role === 'owner'
        ? "You're a group owner — you can add/remove members and edit group metadata."
        : "You're a group admin — same as owner; reserved for future fine-grained membership management."
    }>
      <Chip label={role} size="small" color={color} variant="outlined" />
    </Tooltip>
  );
};

const MyGroupsPage: React.FC = () => {
  const [groups, setGroups] = useState<MyGroupRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = (await (api as any).listMyUserGroups()) as MyGroupRow[];
      setGroups(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box mb={3}>
        <Typography variant="h5" gutterBottom>My Groups</Typography>
        <Typography variant="body2" color="text.secondary">
          Entitlement groups you belong to.  Group membership controls which
          feeds + reports you can view and edit — see your access level on
          each card.
        </Typography>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {loading ? (
        <Box display="flex" justifyContent="center" py={6}><CircularProgress /></Box>
      ) : groups.length === 0 ? (
        <Card variant="outlined">
          <CardContent>
            <Typography variant="body2" color="text.secondary">
              You're not in any entitlement groups yet.  Ask your admin to
              add you to a group if you need access to shared feeds or
              reports.  Feeds and reports you created yourself remain
              accessible regardless of group membership.
            </Typography>
          </CardContent>
        </Card>
      ) : (
        <Stack spacing={2}>
          {groups.map((g) => (
            <Card key={g.id} variant="outlined">
              <CardContent>
                <Stack direction="row" alignItems="flex-start" gap={2}>
                  <GroupIcon color="primary" sx={{ mt: 0.5 }} />
                  <Box flex={1}>
                    <Stack direction="row" alignItems="center" gap={1} mb={0.5}>
                      <Typography variant="h6">{g.name}</Typography>
                      {!g.is_active && (
                        <Chip label="inactive" size="small" color="default" />
                      )}
                    </Stack>
                    {g.description && (
                      <Typography variant="body2" color="text.secondary" mb={1}>
                        {g.description}
                      </Typography>
                    )}

                    <Stack direction="row" gap={1} flexWrap="wrap" mb={1}>
                      {accessChip(g.resource_access_level || 'read_write')}
                      {roleChip(g.role_in_group || 'member')}
                    </Stack>

                    {g.notification_email && (
                      <Stack direction="row" alignItems="center" gap={0.5}>
                        <EmailIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                        <Typography variant="caption" color="text.secondary">
                          Group alerts go to: <strong>{g.notification_email}</strong>
                        </Typography>
                      </Stack>
                    )}
                    {g.added_at && (
                      <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 0.5 }}>
                        Joined {new Date(g.added_at).toLocaleDateString()}
                      </Typography>
                    )}
                  </Box>
                </Stack>
              </CardContent>
            </Card>
          ))}
        </Stack>
      )}

      <Box mt={4}>
        <Divider sx={{ mb: 2 }} />
        <Typography variant="caption" color="text.secondary">
          Need a change?  Group memberships are managed by admins.  Ask your
          QueryStudio admin or the group owner — see the email address on each
          group card above when set.
        </Typography>
      </Box>
    </Container>
  );
};

export default MyGroupsPage;
