/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowsPage — list dataflow definitions + actions (promote / archive / new version / start run).
 *
 * Phase 132 — Generic DataFlow Engine.
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, IconButton, MenuItem, Paper, Select, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Archive as ArchiveIcon, PlayArrow as RunIcon,
  CheckCircle as PromoteIcon, OpenInNew as OpenIcon,
  Refresh as RefreshIcon, Upload as ImportIcon, Download as ExportIcon,
  ContentCopy as CloneIcon, ViewList as SimpleIcon,
  AccountTree as DagIcon, History as HistoryIcon,
  Pause as PauseIcon, PlayCircleOutline as ResumeIcon,
  Timer as SlaIcon, GridOn as GridIcon,
  Label as TagIcon, BugReport as DryRunIcon, Inventory as BundleIcon,
} from '@mui/icons-material';
import { Switch, FormControlLabel, Autocomplete, Divider } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import type {
  DataFlowDef, DataFlowTemplate, DynamicDataflowRow,
} from '../services/api/dataflows';
import { collectDataflowDynamicRows } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';
import {
  inspectDynamicRows, fireDataflowRun,
} from './dataflow/launchWithOverrides';
import DataflowOverrideDialog from './dataflow/DataflowOverrideDialog';
import DynamicWhereOverrideField from './common/DynamicWhereOverrideField';

const statusChip = (s: string) => {
  const color = s === 'active' ? 'success' : s === 'draft' ? 'info' : 'default';
  return <Chip label={s} size="small" color={color as any} variant="outlined" sx={{ fontSize: 10 }} />;
};

export default function DataFlowsPage() {
  const nav = useNavigate();
  const [dataflows, setWorkflows] = useState<DataFlowDef[]>([]);
  const [templates, setTemplates] = useState<DataFlowTemplate[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [templateName, setTemplateName] = useState<string>('');
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importJson, setImportJson] = useState<string>('');
  // Phase 132.20 — backfill + SLA dialog state
  const today = () => new Date().toISOString().slice(0, 10);
  const aWeekAgo = () => new Date(Date.now() - 7 * 24 * 3600 * 1000)
                            .toISOString().slice(0, 10);
  const [backfillFor, setBackfillFor] = useState<DataFlowDef | null>(null);
  const [bfStart, setBfStart] = useState(aWeekAgo());
  const [bfEnd,   setBfEnd]   = useState(today());
  const [bfSkipWeekends, setBfSkipWeekends] = useState(true);
  const [bfRunAs, setBfRunAs] = useState('');
  const [bfPacing, setBfPacing] = useState<number>(0);
  // Phase 132.38 deep-dive — per-batch Dynamic where-clause overrides
  // for backfill.  Keyed by column name; same channel manual runs use
  // (extra_context flows into each batched run's run_context).
  const [bfDynamicRows, setBfDynamicRows] = useState<DynamicDataflowRow[]>([]);
  const [bfOverrides, setBfOverrides] = useState<Record<string, any>>({});
  const [slaFor, setSlaFor] = useState<DataFlowDef | null>(null);
  const [slaSeconds, setSlaSeconds] = useState<string>('');
  // Phase 132.21/23 — tags editor + dry-run dialog
  const [tagsFor, setTagsFor] = useState<DataFlowDef | null>(null);
  const [tagsValue, setTagsValue] = useState<string[]>([]);
  const [tagSuggestions, setTagSuggestions] = useState<string[]>([]);
  const [tagFilter, setTagFilter] = useState<string>('');
  const [dryRunFor, setDryRunFor] = useState<{ open: boolean; name?: string; result?: any }>({ open: false });
  // Phase 132.28 — additional fields edited from the same dialog
  const [maxRunSecondsValue, setMaxRunSecondsValue] = useState<string>('');
  const [workspaceIdValue, setWorkspaceIdValue] = useState<string>('');
  const [workspaceOptions, setWorkspaceOptions] = useState<Array<{ id: number; name: string }>>([]);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const list = await api.dataflows.listDataFlows(
        filterStatus ? { status: filterStatus } : undefined,
      );
      setWorkflows(toArray<DataFlowDef>(list));
    } catch (e: any) {
      setError(e?.message || 'Failed to load dataflows');
    } finally {
      setLoading(false);
    }
  }, [filterStatus]);

  const loadTemplates = useCallback(async () => {
    try {
      const list = await api.dataflows.listTemplates();
      setTemplates(toArray<DataFlowTemplate>(list));
    } catch (e: any) {
      console.warn('Failed to load templates:', e?.message);
    }
  }, []);

  const loadTags = useCallback(async () => {
    try {
      const r = await api.dataflows.listAllTags();
      setTagSuggestions(toArray<string>(r, 'tags'));
    } catch { /* swallow */ }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadTemplates(); }, [loadTemplates]);
  useEffect(() => { loadTags(); }, [loadTags]);

  const onPromote = async (id: number) => {
    try { await api.dataflows.promoteDataFlow(id); await load(); }
    catch (e: any) { setError(e?.message || 'Promote failed'); }
  };
  const onArchive = async (id: number) => {
    if (!window.confirm('Archive this dataflow? Active schedules will be paused.')) return;
    try { await api.dataflows.archiveDataFlow(id); await load(); }
    catch (e: any) { setError(e?.message || 'Archive failed'); }
  };
  const onPause = async (id: number) => {
    try { await api.dataflows.pauseDataFlow(id); await load(); }
    catch (e: any) { setError(e?.message || 'Pause failed'); }
  };
  const onResume = async (id: number) => {
    try { await api.dataflows.resumeDataFlow(id); await load(); }
    catch (e: any) { setError(e?.message || 'Resume failed'); }
  };
  const openSlaDialog = (wf: DataFlowDef) => {
    setSlaFor(wf);
    setSlaSeconds(wf.sla_seconds != null ? String(wf.sla_seconds) : '');
  };
  const onSaveSla = async () => {
    if (!slaFor) return;
    const raw = slaSeconds.trim();
    const val = raw === '' ? null : Number(raw);
    if (val !== null && (!Number.isFinite(val) || val < 0)) {
      setError('SLA seconds must be a non-negative number or blank.'); return;
    }
    try {
      await api.dataflows.setDataFlowSla(slaFor.id, val as number | null);
      setSlaFor(null); setSlaSeconds('');
      await load();
    } catch (e: any) { setError(e?.message || 'SLA save failed'); }
  };

  const openTags = (wf: DataFlowDef) => {
    setTagsFor(wf);
    setTagsValue(wf.tags || []);
    setMaxRunSecondsValue(wf.max_run_seconds != null ? String(wf.max_run_seconds) : '');
    setWorkspaceIdValue(wf.workspace_id != null ? String(wf.workspace_id) : '');
    // Load workspaces lazily on first open
    if (workspaceOptions.length === 0) {
      (async () => {
        try {
          const r: any = await fetch('/api/workspaces').then(res => res.ok ? res.json() : []);
          setWorkspaceOptions((r || []).map((w: any) => ({ id: w.id, name: w.name })));
        } catch { /* swallow */ }
      })();
    }
  };
  const onSaveTags = async () => {
    if (!tagsFor) return;
    try {
      await api.dataflows.setDataFlowTags(tagsFor.id, tagsValue);
      // Phase 132.28 — also save max_run_seconds + workspace_id from
      // the same dialog so admins don't context-switch.
      const rawMrs = maxRunSecondsValue.trim();
      const newMrs = rawMrs === '' ? null : Number(rawMrs);
      if (newMrs !== null && (!Number.isFinite(newMrs) || newMrs < 0)) {
        setError('Max run seconds must be a non-negative number or blank.'); return;
      }
      if ((tagsFor.max_run_seconds ?? null) !== newMrs) {
        await api.dataflows.setDataFlowMaxRunSeconds(tagsFor.id, newMrs as number | null);
      }
      const newWs = workspaceIdValue === '' ? null : Number(workspaceIdValue);
      if ((tagsFor.workspace_id ?? null) !== newWs) {
        await fetch(`/api/dataflows/${tagsFor.id}/workspace`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ workspace_id: newWs }),
        });
      }
      setTagsFor(null);
      await load();
      await loadTags();
    } catch (e: any) { setError(e?.message || 'Save tags failed'); }
  };
  const onDryRun = async (wf: DataFlowDef) => {
    try {
      const r = await api.dataflows.dryRun(wf.id);
      setDryRunFor({ open: true, name: wf.name, result: r });
    } catch (e: any) { setError(e?.message || 'Dry-run failed'); }
  };
  const onExportBundle = async (wf: DataFlowDef) => {
    try {
      const b = await api.dataflows.exportBundle(wf.id);
      const blob = new Blob([JSON.stringify(b, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `dataflow-bundle-${wf.name}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (e: any) { setError(e?.message || 'Bundle export failed'); }
  };
  // Phase 132.38 deep-dive — quick-launch override dialog state.  When
  // the picked dataflow has any Dynamic rows we open this dialog
  // BEFORE firing the run; otherwise legacy fast-path (start
  // immediately with publisher defaults).
  const [launchPending, setLaunchPending] = useState<{
    name: string; rows: DynamicDataflowRow[];
  } | null>(null);
  const [launchOverrides, setLaunchOverrides] = useState<Record<string, any>>({});

  const onStartRun = async (wf: DataFlowDef) => {
    if (wf.status !== 'active') { setError('Only active dataflows can be started.'); return; }
    try {
      // Inline detail wf may not carry stages (list endpoint elides
      // them on some installs); inspect the FULL active version
      // before deciding whether to prompt.
      const dyn = wf.stages && wf.stages.length > 0
        ? collectDataflowDynamicRows(wf)
        : await inspectDynamicRows(wf.name);
      if (dyn.length > 0) {
        const seed: Record<string, any> = {};
        for (const r of dyn) {
          if (r.value !== null && r.value !== undefined && r.value !== '') {
            seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
          }
        }
        setLaunchOverrides(seed);
        setLaunchPending({ name: wf.name, rows: dyn });
        return;
      }
      const run = await fireDataflowRun(wf.name);
      nav(`/dataflows/runs/${run.id}`);
    } catch (e: any) { setError(e?.message || 'Start run failed'); }
  };
  const onExport = async (id: number, name: string) => {
    try {
      const def = await api.dataflows.exportDataFlow(id);
      const blob = new Blob([JSON.stringify(def, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `dataflow-${name}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (e: any) { setError(e?.message || 'Export failed'); }
  };

  const onClone = async (wf: DataFlowDef) => {
    const suggested = `${wf.name}_copy`;
    const requested = window.prompt(
      `Clone "${wf.name}" — choose a new name (will auto-suffix if taken):`,
      suggested,
    );
    if (!requested) return;
    try {
      const cloned = await api.dataflows.cloneDataFlow(wf.id, requested);
      await load();
      nav(`/dataflows/simple/${cloned.id}`);
    } catch (e: any) { setError(e?.message || 'Clone failed'); }
  };

  const openBackfill = (wf: DataFlowDef) => {
    if (wf.status !== 'active') {
      setError('Only active dataflows can be backfilled.'); return;
    }
    setBackfillFor(wf);
    setBfStart(aWeekAgo()); setBfEnd(today());
    setBfSkipWeekends(true); setBfRunAs(''); setBfPacing(0);
    // Surface any Dynamic where-clause rows so the user can override
    // them for THIS batch.  Seed inputs with the publisher's defaults.
    const dyn = collectDataflowDynamicRows(wf);
    setBfDynamicRows(dyn);
    const seed: Record<string, any> = {};
    for (const r of dyn) {
      if (r.value !== null && r.value !== undefined && r.value !== '') {
        seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
      }
    }
    setBfOverrides(seed);
  };
  const onConfirmBackfill = async () => {
    if (!backfillFor) return;
    try {
      // Phase 132.38 deep-dive — strip blanks so Dynamic rows fall
      // back to publisher defaults instead of forcing "" filters.
      const overrides: Record<string, any> = {};
      for (const [k, v] of Object.entries(bfOverrides)) {
        if (v !== '' && v !== null && v !== undefined) overrides[k] = v;
      }
      const extra_context = Object.keys(overrides).length > 0
        ? { _consumer_overrides: overrides }
        : undefined;
      const r = await api.dataflows.backfillDataFlow(backfillFor.name, {
        start_date: bfStart,
        end_date:   bfEnd,
        skip_weekends: bfSkipWeekends,
        pacing_seconds: bfPacing || 0,
        run_as: bfRunAs.trim() || null,
        ...(extra_context ? { extra_context } : {}),
      });
      setBackfillFor(null);
      alert(`Backfill queued ${r.runs_created} run(s) for "${backfillFor.name}" `
            + `(${bfStart} → ${bfEnd}). View them in the runs dashboard.`);
      nav('/dataflows/runs');
    } catch (e: any) { setError(e?.message || 'Backfill failed'); }
  };

  const onApplyTemplate = async () => {
    try {
      const wf = await api.dataflows.applyTemplate(selectedTemplate,
        templateName || undefined);
      setTemplateDialogOpen(false);
      setSelectedTemplate(''); setTemplateName('');
      nav(`/dataflows/${wf.id}`);
    } catch (e: any) { setError(e?.message || 'Apply template failed'); }
  };

  const onImport = async () => {
    try {
      const parsed = JSON.parse(importJson);
      const wf = await api.dataflows.importDataFlow(parsed);
      setImportDialogOpen(false);
      setImportJson('');
      nav(`/dataflows/${wf.id}`);
    } catch (e: any) { setError(e?.message || 'Import failed'); }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">DataFlows</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<AddIcon />} variant="contained"
                   onClick={() => nav('/dataflows/new')}>New (Simple)</Button>
          <Button startIcon={<DagIcon />} variant="outlined"
                   onClick={() => nav('/dataflows/new/advanced')}>New (DAG)</Button>
          <Button startIcon={<AddIcon />} variant="outlined"
                   onClick={() => setTemplateDialogOpen(true)}>From Template</Button>
          <Button startIcon={<ImportIcon />} variant="outlined"
                   onClick={() => setImportDialogOpen(true)}>Import JSON</Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      <Stack direction="row" spacing={2} sx={{ mb: 2 }} alignItems="center">
        <Select size="small" value={filterStatus}
                onChange={e => setFilterStatus(e.target.value)} displayEmpty
                sx={{ minWidth: 160 }}>
          <MenuItem value="">All statuses</MenuItem>
          <MenuItem value="draft">Draft</MenuItem>
          <MenuItem value="active">Active</MenuItem>
          <MenuItem value="archived">Archived</MenuItem>
        </Select>
        <Select size="small" displayEmpty value={tagFilter}
                onChange={e => setTagFilter(e.target.value)}
                sx={{ minWidth: 160 }}>
          <MenuItem value="">All tags</MenuItem>
          {tagSuggestions.map(t => <MenuItem key={t} value={t}>tag: {t}</MenuItem>)}
        </Select>
        <Button size="small" onClick={() => nav('/dataflows/runs')}>View All Runs</Button>
        <Button size="small" startIcon={<GridIcon />} onClick={() => nav('/dataflows/ops')}>
          Ops View
        </Button>
        <Button size="small" onClick={() => nav('/dataflows/schedules')}>Schedules</Button>
        <Button size="small" onClick={() => nav('/dataflows/notification-policies')}>Notifications</Button>
        <Button size="small" onClick={() => nav('/dataflows/variables')}>Variables</Button>
        <Button size="small" onClick={() => nav('/dataflows/webhooks')}>Webhooks</Button>
        <Button size="small" onClick={() => nav('/dataflows/approvals')}>Approvals</Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Version</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Trigger</TableCell>
              <TableCell>Stages</TableCell>
              <TableCell>Created</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={7} align="center">
                <CircularProgress size={20} />
              </TableCell></TableRow>
            )}
            {!loading && dataflows.length === 0 && (
              <TableRow><TableCell colSpan={7} align="center">
                <Typography variant="body2" color="text.secondary">
                  No dataflows yet. Click <strong>New</strong> or
                  <strong> From Template</strong> to create one.
                </Typography>
              </TableCell></TableRow>
            )}
            {dataflows
              .filter(wf => !tagFilter || (wf.tags || []).includes(tagFilter))
              .map(wf => (
              <TableRow key={`${wf.id}-${wf.version}`} hover>
                <TableCell>
                  <Button onClick={() => nav(`/dataflows/${wf.id}`)}
                           sx={{ textTransform: 'none' }}>{wf.name}</Button>
                </TableCell>
                <TableCell>v{wf.version}</TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5} alignItems="center">
                    {statusChip(wf.status)}
                    {wf.is_paused && (
                      <Tooltip title="Paused — schedules suspended, manual runs blocked">
                        <Chip label="paused" size="small" color="warning" variant="filled"
                              sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                    {wf.sla_seconds && wf.sla_seconds > 0 && (
                      <Tooltip title={`SLA: ${wf.sla_seconds}s wall-clock budget per run`}>
                        <Chip icon={<SlaIcon sx={{ fontSize: 12 }} />}
                              label={`${wf.sla_seconds}s`} size="small" variant="outlined"
                              color="info" sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                    {wf.max_run_seconds && wf.max_run_seconds > 0 && (
                      <Tooltip title={`Hard timeout: cancels run after ${wf.max_run_seconds}s`}>
                        <Chip label={`max ${wf.max_run_seconds}s`} size="small"
                              color="error" variant="outlined" sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                    {wf.workspace_id != null && (
                      <Tooltip title={`Workspace ${wf.workspace_id}`}>
                        <Chip label={`ws:${wf.workspace_id}`} size="small"
                              variant="outlined" sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5} flexWrap="wrap">
                    <Chip label={wf.trigger_type} size="small" variant="outlined" sx={{ fontSize: 10 }} />
                    {(wf.tags || []).map(t => (
                      <Chip key={t} label={t} size="small" color="primary" variant="outlined" sx={{ fontSize: 10 }} />
                    ))}
                    {wf.depends_on_previous && (
                      <Tooltip title="depends_on_previous: waits for prior run to succeed">
                        <Chip label="deps" size="small" color="warning" variant="outlined" sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
                <TableCell>{wf.stages?.length ?? 0}</TableCell>
                <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                  {wf.created_at?.slice(0, 16).replace('T', ' ')}
                </TableCell>
                <TableCell align="right">
                  <Tooltip title="Start a run">
                    <span>
                      <IconButton size="small" onClick={() => onStartRun(wf)}
                                   disabled={wf.status !== 'active'}>
                        <RunIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  {wf.status === 'draft' && (
                    <Tooltip title="Promote to active">
                      <IconButton size="small" onClick={() => onPromote(wf.id)}>
                        <PromoteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                  {wf.status === 'active' && !wf.is_paused && (
                    <Tooltip title="Pause — suspends schedule + blocks new runs">
                      <IconButton size="small" onClick={() => onPause(wf.id)}>
                        <PauseIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                  {wf.status === 'active' && wf.is_paused && (
                    <Tooltip title="Resume">
                      <IconButton size="small" onClick={() => onResume(wf.id)} color="warning">
                        <ResumeIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                  {wf.status === 'active' && (
                    <Tooltip title="Archive">
                      <IconButton size="small" onClick={() => onArchive(wf.id)}>
                        <ArchiveIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                  <Tooltip title="Set SLA budget (seconds per run)">
                    <IconButton size="small" onClick={() => openSlaDialog(wf)}>
                      <SlaIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Edit tags">
                    <IconButton size="small" onClick={() => openTags(wf)}>
                      <TagIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Dry-run (validate without executing)">
                    <IconButton size="small" onClick={() => onDryRun(wf)}>
                      <DryRunIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Export bundle (DAG + schedules + policies + vars)">
                    <IconButton size="small" onClick={() => onExportBundle(wf)}>
                      <BundleIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Backfill — run for a range of business dates">
                    <span>
                      <IconButton size="small" onClick={() => openBackfill(wf)}
                                   disabled={wf.status !== 'active'}>
                        <HistoryIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Clone — copy this dataflow with a new name">
                    <IconButton size="small" onClick={() => onClone(wf)}>
                      <CloneIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Export JSON">
                    <IconButton size="small" onClick={() => onExport(wf.id, wf.name)}>
                      <ExportIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Open in Simple view">
                    <IconButton size="small"
                                 onClick={() => nav(`/dataflows/simple/${wf.id}`)}>
                      <SimpleIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Open in DAG view">
                    <IconButton size="small" onClick={() => nav(`/dataflows/${wf.id}`)}>
                      <OpenIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Template picker dialog */}
      <Dialog open={templateDialogOpen} onClose={() => setTemplateDialogOpen(false)}
               maxWidth="sm" fullWidth>
        <DialogTitle>Apply Starter Template</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Select fullWidth value={selectedTemplate}
                    onChange={e => setSelectedTemplate(e.target.value)} displayEmpty>
              <MenuItem value="" disabled>Select a template…</MenuItem>
              {templates.map(t => (
                <MenuItem key={t.name} value={t.name}>
                  <Box>
                    <Typography variant="body2">{t.name}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {t.description} · {t.stage_count} stages · {t.trigger_type}
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
            </Select>
            <TextField fullWidth size="small" label="DataFlow name (optional)"
                        helperText="If blank, uses the template's name. Must be unique."
                        value={templateName}
                        onChange={e => setTemplateName(e.target.value)} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTemplateDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!selectedTemplate}
                   onClick={onApplyTemplate}>Apply</Button>
        </DialogActions>
      </Dialog>

      {/* Backfill dialog (Phase 132.20 — replaces window.prompt) */}
      <Dialog open={!!backfillFor} onClose={() => setBackfillFor(null)} maxWidth="xs" fullWidth>
        <DialogTitle>
          Backfill — {backfillFor?.name}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Start date" type="date" size="small" fullWidth
                        value={bfStart} onChange={e => setBfStart(e.target.value)}
                        InputLabelProps={{ shrink: true }} />
            <TextField label="End date (inclusive)" type="date" size="small" fullWidth
                        value={bfEnd} onChange={e => setBfEnd(e.target.value)}
                        InputLabelProps={{ shrink: true }} />
            <FormControlLabel
              control={<Switch checked={bfSkipWeekends}
                                 onChange={e => setBfSkipWeekends(e.target.checked)} />}
              label="Skip weekends" />
            <TextField label="Pacing (seconds between runs)" type="number" size="small" fullWidth
                        value={bfPacing}
                        onChange={e => setBfPacing(Number(e.target.value) || 0)}
                        inputProps={{ min: 0, max: 5, step: 0.5 }}
                        helperText="0 fires as fast as the dispatcher pool allows" />
            <TextField label="Run as (optional)" size="small" fullWidth
                        value={bfRunAs} onChange={e => setBfRunAs(e.target.value)}
                        placeholder="username for downstream auth/credentials"
                        helperText="Leave blank to run as yourself" />
            {bfDynamicRows.length > 0 && (
              <>
                <Divider />
                <Typography variant="caption" color="text.secondary">
                  Dynamic WHERE-clause overrides for this batch
                  (leave blank to use publisher defaults; Static rows
                  always apply):
                </Typography>
                {/* Phase 133-I round 26 — Backfill dialog override
                    fields use the shared DynamicWhereOverrideField
                    (searchable Autocomplete with lazy distinct-values)
                    instead of plain TextField — same UX as the
                    "Run with overrides" dialog. */}
                {bfDynamicRows.map((r, i) => (
                  <DynamicWhereOverrideField
                    key={`${r.stageAlias}-${r.column}-${i}`}
                    column={r.column}
                    operator={r.operator}
                    publisherDefault={r.value}
                    value={bfOverrides[r.column] ?? ''}
                    onChange={(next) => setBfOverrides(v => ({
                      ...v, [r.column]: next,
                    }))}
                    connectionId={r.connectionId ?? null}
                    table={r.table ?? null}
                    label={`${r.column} (${r.operator}) — stage "${r.stageAlias}"`}
                  />
                ))}
              </>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBackfillFor(null)}>Cancel</Button>
          <Button variant="contained" disabled={!bfStart || !bfEnd}
                   onClick={onConfirmBackfill}>Queue backfill</Button>
        </DialogActions>
      </Dialog>

      {/* Quick-launch override dialog (Phase 132.38 deep-dive) */}
      <DataflowOverrideDialog
        dataflowName={launchPending?.name || null}
        rows={launchPending?.rows || []}
        values={launchOverrides}
        onValuesChange={setLaunchOverrides}
        onCancel={() => setLaunchPending(null)}
        onConfirm={async () => {
          const cur = launchPending!;
          setLaunchPending(null);
          try {
            const run = await fireDataflowRun(cur.name, launchOverrides);
            nav(`/dataflows/runs/${run.id}`);
          } catch (e: any) { setError(e?.message || 'Start run failed'); }
        }}
        connectionIdByRow={(r) => r.connectionId ?? null}
        tableByRow={(r) => r.table ?? null}
      />

      {/* SLA dialog (Phase 132.20) */}
      <Dialog open={!!slaFor} onClose={() => setSlaFor(null)} maxWidth="xs" fullWidth>
        <DialogTitle>SLA — {slaFor?.name}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="SLA budget (seconds)" type="number" size="small" fullWidth
                        value={slaSeconds} onChange={e => setSlaSeconds(e.target.value)}
                        inputProps={{ min: 0 }}
                        helperText="Wall-clock budget per run. Runs over the budget are flagged sla_breached but not cancelled. Leave blank to clear." />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSlaFor(null)}>Cancel</Button>
          <Button variant="contained" onClick={onSaveSla}>Save SLA</Button>
        </DialogActions>
      </Dialog>

      {/* Tags + depends_on_previous dialog */}
      <Dialog open={!!tagsFor} onClose={() => setTagsFor(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Edit DataFlow — {tagsFor?.name}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Autocomplete multiple freeSolo options={tagSuggestions}
              value={tagsValue}
              onChange={(_, v) => setTagsValue(v as string[])}
              renderTags={(value: string[], getTagProps) =>
                value.map((option: string, index: number) => (
                  <Chip variant="outlined" label={option} {...getTagProps({ index })} key={option} />
                ))
              }
              renderInput={(params) => (
                <TextField {...params} label="Tags"
                  placeholder="Type and press Enter (e.g. sap, monthly, prod-critical)"
                  helperText="Tags are lowercased and deduped server-side. Used by notification policies + Ops Grid filter." />
              )}
            />
            <FormControlLabel control={
              <Switch checked={!!tagsFor?.depends_on_previous}
                onChange={async (e) => {
                  if (!tagsFor) return;
                  try {
                    await api.dataflows.setDependsOnPrevious(tagsFor.id, e.target.checked);
                    const refreshed = await api.dataflows.getDataFlow(tagsFor.id);
                    setTagsFor(refreshed);
                    await load();
                  } catch (err: any) { setError(err?.message || 'Update failed'); }
                }} />
            } label="depends_on_previous (block new runs until prior succeeds)" />
            <TextField label="Hard timeout (max_run_seconds)" size="small"
              type="number" fullWidth
              value={maxRunSecondsValue}
              onChange={e => setMaxRunSecondsValue(e.target.value)}
              inputProps={{ min: 0 }}
              helperText="Cancels the run when wall-clock exceeds this. Blank = no cap. Distinct from SLA (which only flags)." />
            <Select size="small" fullWidth displayEmpty
              value={workspaceIdValue}
              onChange={e => setWorkspaceIdValue(String(e.target.value))}>
              <MenuItem value=""> &mdash; Global (visible to everyone)</MenuItem>
              {workspaceOptions.map(w => (
                <MenuItem key={w.id} value={String(w.id)}>{w.name}</MenuItem>
              ))}
            </Select>
            <Typography variant="caption" color="text.secondary">
              Workspace scoping: blank = global. When set, only members of
              that workspace + super_admin see this DataFlow.
            </Typography>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTagsFor(null)}>Cancel</Button>
          <Button variant="contained" onClick={onSaveTags}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Dry-run report dialog */}
      <Dialog open={dryRunFor.open} onClose={() => setDryRunFor({ open: false })}
        maxWidth="md" fullWidth>
        <DialogTitle>Dry-run report — {dryRunFor.name}</DialogTitle>
        <DialogContent>
          {dryRunFor.result && (
            <>
              <Alert severity={dryRunFor.result.ok ? 'success' : 'error'} sx={{ mb: 2 }}>
                {dryRunFor.result.ok
                  ? `All ${dryRunFor.result.stage_count} stages would validate cleanly.`
                  : `Issues found in some stages — see below.`}
              </Alert>
              {(dryRunFor.result.stages || []).map((s: any) => (
                <Paper key={s.stage_alias} variant="outlined" sx={{ p: 1.5, mb: 1 }}>
                  <Stack direction="row" alignItems="center" spacing={1}>
                    <Chip label={s.ok ? 'ok' : 'fail'} size="small"
                      color={s.ok ? 'success' : 'error'} sx={{ fontSize: 10 }} />
                    <Typography variant="subtitle2">{s.stage_alias}</Typography>
                    <Chip label={s.stage_type} size="small" variant="outlined" sx={{ fontSize: 10 }} />
                  </Stack>
                  {s.issues?.length > 0 && (
                    <Box sx={{ mt: 1, pl: 2 }}>
                      {s.issues.map((iss: string, i: number) => (
                        <Typography key={i} variant="caption" component="div" sx={{ color: 'error.main' }}>
                          • {iss}
                        </Typography>
                      ))}
                    </Box>
                  )}
                </Paper>
              ))}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDryRunFor({ open: false })} variant="contained">Close</Button>
        </DialogActions>
      </Dialog>

      {/* Import JSON dialog */}
      <Dialog open={importDialogOpen} onClose={() => setImportDialogOpen(false)}
               maxWidth="md" fullWidth>
        <DialogTitle>Import DataFlow JSON</DialogTitle>
        <DialogContent>
          <TextField fullWidth multiline minRows={12} placeholder="Paste dataflow JSON…"
                      value={importJson} onChange={e => setImportJson(e.target.value)}
                      sx={{ fontFamily: 'monospace', mt: 1 }} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setImportDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!importJson.trim()}
                   onClick={onImport}>Import</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
