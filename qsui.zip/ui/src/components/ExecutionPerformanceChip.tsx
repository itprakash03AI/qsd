/**
 * BF-297 — Per-stage timing breakdown for a completed execution.
 *
 * Renders a small expandable chip in the data grid toolbar that fetches
 * /api/executions/{id} and shows files_metadata.stage_history as a
 * compact table.  Lets users see WHICH step of the query took the time
 * (metadata read, manifest walk, S3 download, DuckDB execute, etc.) so
 * they can decide where to optimise.
 */
import { useState, useEffect } from 'react';
import {
  Box, Chip, Popover, Table, TableBody, TableCell, TableHead,
  TableRow, Typography, CircularProgress, Tooltip,
} from '@mui/material';
import SpeedIcon from '@mui/icons-material/Speed';
import { rawFetch } from '../services/api/core';

interface StageEntry {
  stage: string;
  stage_label: string;
  duration_seconds: number;
  files_done?: number;
  bytes_done?: number;
  in_flight?: boolean;
}

interface StageHistory {
  stages: StageEntry[];
  extras?: Record<string, unknown>;
  total_seconds?: number;
}

interface LogLine {
  ts: number;       // unix timestamp (float seconds)
  level: string;    // INFO / WARNING / ERROR
  logger: string;
  msg: string;
  stage?: string | null;
}

interface Props {
  executionId: string;
}

export default function ExecutionPerformanceChip({ executionId }: Props) {
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [data, setData] = useState<StageHistory | null>(null);
  const [logLines, setLogLines] = useState<LogLine[]>([]);
  const [rowDuration, setRowDuration] = useState<number | null>(null);
  const [showLogs, setShowLogs] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // BF-561 (2026-05-29): consume the BF-546 freshness + BF-517 join-health
  // signals the backend writes into files_metadata.  Previously these
  // were dead code; now they render as compact badges next to the
  // perf chip.
  const [icebergFreshness, setIcebergFreshness] = useState<string>('');
  const [joinHealth, setJoinHealth] = useState<{ state: string; detail?: string }>({ state: '' });

  useEffect(() => {
    if (!executionId) return;
    let cancelled = false;
    setLoading(true);
    rawFetch(`/api/executions/${executionId}`)
      .then(r => r.json())
      .then(j => {
        if (cancelled) return;
        const fm = j?.files_metadata;
        const parsed: any = typeof fm === 'string' ? JSON.parse(fm) : fm;
        setData(parsed?.stage_history ?? null);
        // BF-562 (2026-05-29): cap log_lines tail to last 1000 to
        // prevent unbounded state growth on long-running queries.
        const rawLogs = Array.isArray(parsed?.log_lines) ? parsed.log_lines : [];
        setLogLines(rawLogs.length > 1000 ? rawLogs.slice(-1000) : rawLogs);
        const d = j?.duration_seconds;
        setRowDuration(typeof d === 'number' && isFinite(d) ? d : null);
        // BF-561: per-table freshness + join-health diagnostics.
        let _freshness = '';
        let _jh: { state: string; detail?: string } = { state: '' };
        try {
          if (parsed && typeof parsed === 'object') {
            for (const [k, v] of Object.entries(parsed)) {
              if (k.startsWith('__')) continue;
              if (v && typeof v === 'object') {
                const stats: any = v;
                if (stats.iceberg_freshness && !_freshness) {
                  _freshness = String(stats.iceberg_freshness);
                }
              }
            }
            if (parsed.join_health && parsed.join_health !== 'ok') {
              _jh = {
                state: String(parsed.join_health),
                detail: parsed.join_health_detail ? String(parsed.join_health_detail) : undefined,
              };
            }
          }
        } catch { /* fail-OPEN: badge just doesn't render */ }
        setIcebergFreshness(_freshness);
        setJoinHealth(_jh);
      })
      .catch(e => { if (!cancelled) setError(String(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [executionId]);

  if (loading) return <CircularProgress size={14} sx={{ mx: 1 }} />;

  // ALWAYS render the chip when an executionId is provided — even if the
  // backend hasn't (yet) persisted stage_history or log_lines.  Previous
  // behaviour was to silently return null, which made the chip look
  // "removed" when the user expected to see it.  Now: empty popover
  // shows a clear "no data yet" state instead of disappearing.
  const stageTotal = data?.total_seconds ?? 0;
  const stages = data?.stages ?? [];
  // Prefer the per-stage sum; fall back to the row-level duration_seconds
  // so the chip ALWAYS shows total query time, even when stage_history
  // wasn't captured (e.g. some streaming paths bypass the stage hooks).
  const total = stageTotal > 0 ? stageTotal : (rowDuration ?? 0);
  const slowest = stages.length > 0
    ? [...stages].sort((a, b) => (b.duration_seconds || 0) - (a.duration_seconds || 0))[0]
    : null;

  const stagePart = stages.length > 0
    ? `${total.toFixed(1)}s · ${stages.length} steps${
        slowest ? ` · ${slowest.stage_label}=${slowest.duration_seconds.toFixed(1)}s` : ''
      }`
    : (total > 0 ? `${total.toFixed(1)}s` : '');
  const logPart = logLines.length > 0 ? ` · ${logLines.length} logs` : '';
  const chipLabel = (stagePart + logPart) || (error ? 'perf (error)' : 'perf');

  const fmtTime = (ts: number) => {
    try { return new Date(ts * 1000).toLocaleTimeString(); } catch { return String(ts); }
  };
  const levelColor = (level: string) => {
    if (level === 'ERROR' || level === 'CRITICAL') return 'error.main';
    if (level === 'WARNING') return 'warning.main';
    return 'text.secondary';
  };

  // BF-561: freshness + join-health badge labels.
  const freshnessLabel = icebergFreshness === 'verified'
    ? { text: 'verified', color: 'success' as const, tip: 'Iceberg metadata pointer verified against S3' }
    : icebergFreshness === 'cached_unverified'
      ? { text: 'cached', color: 'warning' as const, tip: 'Cached pointer — unable to verify against S3 (V1 table or transient outage). May be stale.' }
      : icebergFreshness === 'fresh'
        ? { text: 'fresh', color: 'success' as const, tip: 'Read directly from S3 (no cache hit)' }
        : null;
  const joinHealthBadge = joinHealth.state === 'suspicious_empty'
    ? { text: 'suspicious 0 rows', color: 'warning' as const,
        tip: joinHealth.detail || 'JOIN returned 0 rows but both inputs had rows — verify your join predicate.' }
    : null;

  return (
    <>
      <Chip
        size="small"
        icon={<SpeedIcon sx={{ fontSize: 14 }} />}
        label={chipLabel}
        variant="outlined"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        sx={{ fontSize: 11, cursor: 'pointer' }}
      />
      {freshnessLabel && (
        <Tooltip title={freshnessLabel.tip} arrow>
          <Chip
            size="small"
            label={`Data: ${freshnessLabel.text}`}
            color={freshnessLabel.color}
            variant="outlined"
            sx={{ fontSize: 11, ml: 0.5 }}
          />
        </Tooltip>
      )}
      {joinHealthBadge && (
        <Tooltip title={joinHealthBadge.tip} arrow>
          <Chip
            size="small"
            label={joinHealthBadge.text}
            color={joinHealthBadge.color}
            variant="outlined"
            sx={{ fontSize: 11, ml: 0.5 }}
          />
        </Tooltip>
      )}
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Box sx={{ p: 2, minWidth: 380, maxWidth: 720 }}>
          {/* Empty state — shown when the backend hasn't (yet) persisted
              stage_history or log_lines for this execution.  Previously the
              entire chip vanished here; now we show a clear message so the
              user knows the data simply isn't available, not that the chip
              has been removed. */}
          {stages.length === 0 && logLines.length === 0 && (
            <Box sx={{ py: 1 }}>
              <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
                Query Performance{total > 0 ? ` · ${total.toFixed(2)}s total` : ''}
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                {error
                  ? `Could not load: ${error}`
                  : (total > 0
                      ? 'Per-stage breakdown not captured for this execution path, but total wall-clock duration is shown above.'
                      : 'No stage breakdown or logs persisted for this execution yet. They may appear once the query finishes.')}
              </Typography>
              <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 1, fontSize: 10 }}>
                execution_id: {executionId}
              </Typography>
            </Box>
          )}
          {stages.length > 0 && (
            <>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Query Performance · {total.toFixed(2)}s total
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Stage</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Duration</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">% of total</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {stages.map((s, i) => {
                    const pct = total > 0 ? (s.duration_seconds / total) * 100 : 0;
                    return (
                      <TableRow key={i}>
                        <TableCell sx={{ fontSize: 11 }}>
                          {s.stage_label || s.stage}
                          {s.in_flight && <em style={{ marginLeft: 4 }}>(running)</em>}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          {s.duration_seconds.toFixed(2)}s
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 1 }}>
                            <Box sx={{
                              width: 60, height: 6, bgcolor: 'grey.200', borderRadius: 1,
                              overflow: 'hidden',
                            }}>
                              <Box sx={{
                                width: `${Math.min(100, pct)}%`, height: '100%',
                                bgcolor: pct > 50 ? 'warning.main' : 'primary.main',
                              }} />
                            </Box>
                            <span>{pct.toFixed(0)}%</span>
                          </Box>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </>
          )}
          {data?.extras && Object.keys(data.extras).length > 0 && (
            <Box sx={{ mt: 1.5, pt: 1.5, borderTop: 1, borderColor: 'divider' }}>
              <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                Details
              </Typography>
              {Object.entries(data.extras).map(([k, v]) => (
                <Typography key={k} variant="caption" sx={{ fontSize: 10, display: 'block', color: 'text.secondary' }}>
                  {k}: {String(v)}
                </Typography>
              ))}
            </Box>
          )}
          {logLines.length > 0 && (
            <Box sx={{ mt: 1.5, pt: 1.5, borderTop: 1, borderColor: 'divider' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 600 }}>
                  Query logs ({logLines.length})
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontSize: 10, color: 'primary.main', cursor: 'pointer', userSelect: 'none' }}
                  onClick={() => setShowLogs(s => !s)}
                >
                  {showLogs ? 'hide' : 'show'}
                </Typography>
              </Box>
              {showLogs && (
                <Box
                  sx={{
                    maxHeight: 280, overflowY: 'auto',
                    fontFamily: 'JetBrains Mono, Menlo, monospace',
                    fontSize: 10, lineHeight: 1.5,
                    bgcolor: 'grey.50', p: 1, borderRadius: 1,
                    border: 1, borderColor: 'divider',
                  }}
                >
                  {logLines.map((l, i) => (
                    <Box key={i} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                      <Box sx={{ color: 'text.disabled', whiteSpace: 'nowrap', flex: '0 0 auto' }}>
                        {fmtTime(l.ts)}
                      </Box>
                      <Box sx={{ color: levelColor(l.level), fontWeight: 600, width: 60, flex: '0 0 60px' }}>
                        {l.level}
                      </Box>
                      {l.stage && (
                        <Box sx={{ color: 'text.secondary', flex: '0 0 110px' }}>
                          [{l.stage}]
                        </Box>
                      )}
                      <Box sx={{ flex: 1, wordBreak: 'break-word' }}>
                        {l.msg}
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </Box>
          )}
        </Box>
      </Popover>
    </>
  );
}
