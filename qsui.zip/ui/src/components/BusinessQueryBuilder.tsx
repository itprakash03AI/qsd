/**
 * Phase 130 — Business Query Builder.
 *
 * Toad/Starburst-style unified tree: tables expand to show columns underneath.
 * Always-editable SQL editor, Save/Load/Publish, cross-source UNION ALL.
 * Phase 130-D: Inline aggregation, transform, join, sort — visual SQL for business users.
 * Phase 130-E: Component split — JSX extracted to business-query/ sub-components.
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Box, Typography, Alert, CircularProgress, Stack,
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  List, ListItem, ListItemButton, ListItemText, Paper,
  Chip, IconButton, Tooltip, Popover, Divider,
  Tabs, Tab,
} from '@mui/material';
import TableChartIcon from '@mui/icons-material/TableChart';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

import api from '../services/api';
import { safeFetch } from '../services/api/core';
import { useServerDraft } from '../hooks/useServerDraft';
import { useWebSocket } from '../context/WebSocketContext';
import type { MappedColumn } from '../services/api/businessQueryBuilder';
import type { SqlFile } from '../services/api/sqlFiles';
import {
  QueryToolbar, TableTree, ConditionsBar, JoinBanner, SqlPreviewPanel, QueryTemplates,
} from './business-query';
import type {
  ConnectionOption, TableOption, BusinessFilter, SortDef, JoinConfig,
  BqbTabSnapshot, BqbTabProps,
} from './business-query';
import { buildExpr, qid, toAlias, buildWindowExpr, buildCaseExpr, trackColumnUse, getFrequentColumns, safeStringify } from './business-query';
import { displayTableName as dnUtil, shortLabel as shortLabelUtil } from '../utils/tableNames';
import { formatElapsed, summariseWorkerStates, formatWorkerSummary } from '../utils/formatters';
import AgentSuggestionInline from './AgentSuggestionInline';
import ExplainViewer from './ExplainViewer';

const DataGridViewer = React.lazy(() => import('./DataGridViewer'));
const SaveQueryModal = React.lazy(() => import('./query-builder/SaveQueryModal'));
const PublishViewDialog = React.lazy(() => import('./PublishViewDialog'));
const HavingBuilderModal = React.lazy(() => import('./query-builder/HavingBuilderModal'));
const ComputedColumnBuilderModal = React.lazy(() => import('./query-builder/ComputedColumnBuilderModal'));
const CaseExpressionBuilderModal = React.lazy(() => import('./query-builder/CaseExpressionBuilderModal'));
const WindowFunctionBuilderModal = React.lazy(() => import('./query-builder/WindowFunctionBuilderModal'));


// ── Helper: insert WHERE/AND before trailing LIMIT ─────────────────
// Auto-generated SQL ends with `\nLIMIT N;`. Naively appending
// "\nWHERE col = ''" produces `LIMIT N;\nWHERE col = ''` which is
// invalid SQL — sqlglot's parse_one() ignores everything after the
// first semicolon so partition pruning sees no WHERE clause.
// This helper strips LIMIT, inserts WHERE/AND, then re-appends LIMIT.
function insertPartitionWhere(prev: string, col: string): string {
  let sql = prev.trimEnd();
  const hasSemi = sql.endsWith(';');
  if (hasSemi) sql = sql.slice(0, -1).trimEnd();

  // Strip trailing LIMIT clause (produced by auto-gen)
  const limitMatch = sql.match(/(\n(?:LIMIT\s+\d+\s*))$/i);
  let limitSuffix = '';
  if (limitMatch) {
    limitSuffix = limitMatch[0];
    sql = sql.slice(0, sql.length - limitMatch[0].length).trimEnd();
  }

  const hasWhere = /\bWHERE\b/i.test(sql);
  const snippet = hasWhere ? `\n  AND ${col} = ''` : `\nWHERE ${col} = ''`;
  return sql + snippet + limitSuffix + (hasSemi ? ';' : '');
}

// BF-392: localStorage key for in-flight execution recovery — module-scope
// so it isn't re-allocated on every render.
const LS_KEY_INFLIGHT = 'qs.bqb.inflight';

// ── Main Component ──────────────────────────────────────────────────

const BusinessQueryBuilder: React.FC<BqbTabProps> = ({
  tabId, isActive = true, initialSnapshot, onSnapshotChange, onDirtyChange, onNameChange,
}) => {
  // ── Refs for tab management ──────────────────────────────────────
  const isActiveRef = useRef(isActive);
  isActiveRef.current = isActive;
  const restoredRef = useRef(false);
  const dirtyRef = useRef(false);
  // Track the last SQL we auto-generated so we can distinguish auto-gen
  // SQL from manually-edited SQL and avoid overwriting user edits.
  const lastAutoGenSqlRef = useRef('');
  // BQB-FIX: server-loaded drafts have ``lastAutoGenSqlRef === ''`` while
  // ``sqlText`` already contains content, which made the string-equality
  // heuristic in the autogen effect mistake every loaded draft for a
  // manual edit — so the editor refused to update on connection / table
  // change.  Track manual edits explicitly via the editor's onChange
  // instead.  Reset on connection switch and when the table set changes.
  const manuallyEditedRef = useRef(false);

  // ── WebSocket: turn off spinner when backend signals completion ───
  const { lastMessage: _wsMsg, registerExecutionHeartbeat, isConnected: _wsConnected } = useWebSocket();

  // ── Connection + Table state ────────────────────────────────────
  const [connections, setConnections] = useState<ConnectionOption[]>([]);
  const [selectedConnId, setSelectedConnId] = useState<number | null>(null);
  const [tables, setTables] = useState<TableOption[]>([]);
  const [selectedTables, setSelectedTables] = useState<TableOption[]>([]);
  const [tableSearch, setTableSearch] = useState('');

  // ── Cross-connection state ──────────────────────────────────────
  const [showCrossConn, setShowCrossConn] = useState(false);
  const [crossConnId, setCrossConnId] = useState<number | null>(null);
  const [crossTables, setCrossTables] = useState<TableOption[]>([]);
  const [selectedCrossTables, setSelectedCrossTables] = useState<TableOption[]>([]);
  const [crossConnMode, setCrossConnMode] = useState<'union' | 'join'>('union');
  const [crossJoinHow, setCrossJoinHow] = useState('inner');
  const [crossJoinLeftOn, setCrossJoinLeftOn] = useState('');
  const [crossJoinRightOn, setCrossJoinRightOn] = useState('');
  const [secondaryRawSql, setSecondaryRawSql] = useServerDraft<string>(
    `bqb.secondary_sql.${selectedConnId ?? 'none'}`, '',
  );

  // ── MV / FED / ICE / Favorites state ──────────────────────────
  const [materializedViews, setMaterializedViews] = useState<any[]>([]);
  const [federationViews, setFederationViews] = useState<any[]>([]);
  const [icebergTables, setIcebergTables] = useState<any[]>([]);
  const [tableFavorites, setTableFavorites] = useState<Set<string>>(new Set());
  const [tableTypeFilter, setTableTypeFilter] = useState<string>('all');

  // ── Column mapping state ────────────────────────────────────────
  const [mappedColumns, setMappedColumns] = useState<MappedColumn[]>([]);
  const [categories, setCategories] = useState<import('../services/api/businessQueryBuilder').ColumnCategory[]>([]);
  const [partitionColumns, setPartitionColumns] = useState<string[]>([]);
  const [selectedPhysical, setSelectedPhysical] = useState<Set<string>>(new Set());
  const [loadingColumns, setLoadingColumns] = useState(false);
  const [columnCache, setColumnCache] = useState<Record<string, { cols: MappedColumn[]; partCols: string[]; catOrders: Record<string, number> }>>({});

  // ── Filter state ────────────────────────────────────────────────
  const [filters, setFilters] = useState<BusinessFilter[]>([]);

  // ── Execution state ─────────────────────────────────────────────
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // BF-392: persist the in-flight executionId across UI refresh.  When the
  // tab reloads (manual refresh, browser crash, dev HMR), the in-memory
  // state is gone but the backend query is still running.  Without this,
  // the user has no way to find their query — they refresh, lose all state,
  // think the query is dead.  We:
  //   1. Stash executionId + timestamp in localStorage whenever it changes
  //   2. On mount, check localStorage for an entry < 2 hours old
  //   3. Fetch /status for it — if still 'processing', restore the
  //      executing state + executionId so polling resumes
  //   4. If terminal (completed/failed/cancelled), show the result and
  //      clear the storage entry

  // Persist whenever executionId changes
  useEffect(() => {
    try {
      if (executionId && executing) {
        // BF-426: safeStringify for defense-in-depth; payload is primitives
        // only today but the helper is cheap and matches the pattern used
        // for the larger snapshot persistence in BusinessQueryTabManager.
        localStorage.setItem(LS_KEY_INFLIGHT, safeStringify({
          executionId, timestamp: Date.now(),
        }));
      } else if (!executing) {
        localStorage.removeItem(LS_KEY_INFLIGHT);
      }
    } catch { /* localStorage may be disabled */ }
  }, [executionId, executing]);

  // Restore in-flight execution on mount (one-time)
  const restoreAttempted = useRef(false);
  useEffect(() => {
    if (restoreAttempted.current) return;
    restoreAttempted.current = true;
    (async () => {
      let savedId: string | null = null;
      let timestamp = 0;
      // 1. Try localStorage first (fastest, owns the executionId from this
      //    tab's last run)
      try {
        const raw = localStorage.getItem(LS_KEY_INFLIGHT);
        if (raw) {
          const parsed = JSON.parse(raw);
          savedId = parsed.executionId;
          timestamp = parsed.timestamp || 0;
        }
      } catch { /* JSON parse error */ }

      // 2. localStorage empty or stale (>2h) → ask backend for ANY active
      //    execution owned by this user.  Recovers from cleared
      //    localStorage / different tab / mobile browser state purge.
      if (!savedId || Date.now() - timestamp > 2 * 60 * 60 * 1000) {
        try {
          const active: any = await safeFetch('/api/executions/active');
          const list = (active?.executions || []) as any[];
          if (list.length > 0) {
            savedId = list[0].execution_id;   // newest
            timestamp = Date.now();
          }
        } catch { /* user has no active query — fine */ }
      }

      if (!savedId) {
        try { localStorage.removeItem(LS_KEY_INFLIGHT); } catch {}
        return;
      }

      // Probe backend for current status of the candidate executionId
      try {
        const resp: any = await safeFetch(
          `/api/executions/${encodeURIComponent(savedId)}/status`,
        );
        if (resp?.status === 'processing' || resp?.status === 'pending' || resp?.status === 'running') {
          // Re-attach — polling effect will pick it up
          setExecutionId(savedId);
          setExecuting(true);
          setProgressLog(`Resuming in-flight query ${savedId.slice(0, 8)}…`);
        } else if (resp?.status === 'completed') {
          setExecutionId(savedId);
          setExecuting(false);
          setShowResults(true);
          if (resp?.engine_meta) {
            const em = resp.engine_meta;
            if (em.from_cache || em.from_multi_worker || em.engine === 'multi_worker') {
              setExecutionBadge({
                fromCache: Boolean(em.from_cache),
                fromMultiWorker: Boolean(em.from_multi_worker || em.engine === 'multi_worker'),
                workerCount: em.worker_count,
                mergeStrategy: em.merge_strategy,
              });
            }
          }
          localStorage.removeItem(LS_KEY_INFLIGHT);
        } else if (resp?.status === 'failed') {
          setError(resp?.error_message || 'Query failed (recovered after refresh)');
          localStorage.removeItem(LS_KEY_INFLIGHT);
        } else {
          localStorage.removeItem(LS_KEY_INFLIGHT);
        }
      } catch {
        // 404 or network — clear the stale entry
        localStorage.removeItem(LS_KEY_INFLIGHT);
      }
    })();
  }, []);

  // Phase 139 honest-fix #1 — heartbeat the active execution so backend
  // auto-cancels if user closes the browser / navigates away.
  useEffect(() => {
    if (!executionId || !executing) return;
    const unsub = registerExecutionHeartbeat(executionId);
    return unsub;
  }, [executionId, executing, registerExecutionHeartbeat]);

  // ── SQL editor state ──────────────────────────────────────────
  // Phase 142 — server-side persistence: typed SQL survives refresh /
  // device switch / cookie clear / pod restart.  Keyed per connection.
  const [sqlText, setSqlText] = useServerDraft<string>(
    `bqb.sql.${selectedConnId ?? 'none'}`, '',
  );

  // BQB-DRAFT-PRESERVE (2026-05-18): the autogen effect overwrites
  // sqlText with builder-generated SQL UNLESS manuallyEditedRef is true.
  // After a page refresh, useServerDraft restores the last-executed SQL
  // BUT manuallyEditedRef is false (user hasn't typed YET this session),
  // so autogen silently nukes the restored draft.  Track whether we've
  // already "seen" a first non-empty sqlText load — if it arrives before
  // autogen ran (lastAutoGenSqlRef still empty), it MUST be from the
  // draft, so promote it to "manually edited" so autogen respects it.
  // Reset on connection switch (handleChangeConnection clears
  // sqlMarkedRef so the new connection's autogen can run fresh).
  const sqlMarkedRef = useRef(false);

  // Phase 142 — Visual builder state bundle: selected tables, chosen
  // columns, filter values, and cross-source join config.  Persisted
  // per-connection so each connection keeps its own in-progress build.
  // Tables and columns are stored by path/name; on restore we validate
  // against the CURRENT tables/columns API response so a dropped table
  // doesn't crash the UI.
  type BqbBuilderDraft = {
    selectedTablePaths: string[];
    selectedPhysicalArr: string[];
    filters: any[];
    showCrossConn: boolean;
    crossConnId: number | null;
    crossConnMode: 'union' | 'join';
    crossJoinHow: string;
    crossJoinLeftOn: string;
    crossJoinRightOn: string;
    selectedCrossTablePaths: string[];
  };
  const [builderDraft, setBuilderDraft] = useServerDraft<BqbBuilderDraft>(
    `bqb.builder.${selectedConnId ?? 'none'}`,
    {
      selectedTablePaths: [], selectedPhysicalArr: [], filters: [],
      showCrossConn: false, crossConnId: null, crossConnMode: 'union',
      crossJoinHow: 'inner', crossJoinLeftOn: '', crossJoinRightOn: '',
      selectedCrossTablePaths: [],
    },
  );

  // BQB-DRAFT-PRESERVE: when useServerDraft restores a non-empty sqlText
  // BEFORE autogen has run (lastAutoGenSqlRef still empty), the restored
  // value MUST be a user-authored draft from a previous session.  Promote
  // it to "manually edited" so the autogen effect at line ~1587 preserves
  // it rather than silently overwriting with builder-generated SQL.
  useEffect(() => {
    if (!sqlMarkedRef.current && sqlText && !lastAutoGenSqlRef.current) {
      sqlMarkedRef.current = true;
      manuallyEditedRef.current = true;
    }
  }, [sqlText]);
  // Sync individual useStates into the bundled draft (debounced via
  // useServerDraft's internal 2s debounce).
  const _restoreAttemptedRef = useRef(false);
  useEffect(() => {
    setBuilderDraft({
      selectedTablePaths: selectedTables.map(t => t.path),
      selectedPhysicalArr: Array.from(selectedPhysical),
      filters,
      showCrossConn,
      crossConnId,
      crossConnMode,
      crossJoinHow,
      crossJoinLeftOn,
      crossJoinRightOn,
      selectedCrossTablePaths: selectedCrossTables.map(t => t.path),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedTables, selectedPhysical, filters, showCrossConn,
    crossConnId, crossConnMode, crossJoinHow, crossJoinLeftOn,
    crossJoinRightOn, selectedCrossTables,
  ]);
  // Restore from draft AFTER the `tables` list is available so we can
  // validate selected tables against current schema.  Run once per
  // connection — controlled by a per-connection ref.
  useEffect(() => {
    if (!selectedConnId || tables.length === 0) return;
    if (_restoreAttemptedRef.current) return;
    _restoreAttemptedRef.current = true;
    const d = builderDraft;
    if (!d) return;
    if (d.selectedTablePaths?.length && selectedTables.length === 0) {
      const availPaths = new Set(tables.map(t => t.path));
      const validTables = tables.filter(t => d.selectedTablePaths.includes(t.path));
      const missing = d.selectedTablePaths.filter(p => !availPaths.has(p));
      if (validTables.length > 0) setSelectedTables(validTables);
      if (missing.length > 0) {
        // Bug-fix: warn user when persisted selections no longer exist
        // (table dropped / renamed / column removed since they last edited).
        // Previously silent — now they see exactly what was lost.
        // Dispatch via window event so we don't need the notifications
        // context in this lifecycle (BQB may not have it imported here).
        try {
          window.dispatchEvent(new CustomEvent('qs:notify', {
            detail: {
              type: 'warning',
              title: 'Some selections could not be restored',
              message: (
                `${missing.length} previously-selected table(s) are no longer ` +
                `available on this connection (likely renamed or dropped): ` +
                missing.slice(0, 3).join(', ') +
                (missing.length > 3 ? `, +${missing.length - 3} more` : '')
              ),
            },
          }));
        } catch { /* notifications optional */ }
        console.warn(`[bqb] ${missing.length} persisted table(s) no longer available:`,
                       missing);
      }
    }
    if (d.selectedPhysicalArr?.length && selectedPhysical.size === 0) {
      setSelectedPhysical(new Set(d.selectedPhysicalArr));
    }
    if (d.filters?.length && filters.length === 0) setFilters(d.filters);
    if (typeof d.showCrossConn === 'boolean') setShowCrossConn(d.showCrossConn);
    if (d.crossConnId != null) setCrossConnId(d.crossConnId);
    if (d.crossConnMode) setCrossConnMode(d.crossConnMode);
    if (d.crossJoinHow) setCrossJoinHow(d.crossJoinHow);
    if (d.crossJoinLeftOn) setCrossJoinLeftOn(d.crossJoinLeftOn);
    if (d.crossJoinRightOn) setCrossJoinRightOn(d.crossJoinRightOn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tables, selectedConnId, builderDraft]);
  // Reset the restore-attempted ref when connection changes so the next
  // connection gets its own restore pass
  useEffect(() => { _restoreAttemptedRef.current = false; }, [selectedConnId]);
  const [sqlError, setSqlError] = useState<string | null>(null);
  // Phase 136: Self-Healing Agent inline suggestion (rendered next to error)
  const [agentSuggestion, setAgentSuggestion] = useState<any>(null);
  // BF-571 (2026-05-29): agent format-string auto-fixes (cross-dialect
  // strftime/DATE_FORMAT specifiers DuckDB rejected — fixed in-flight
  // by the backend normaliser).  Each entry: { function, original_format,
  // repaired_format, specifiers_fixed[], function_rewritten, description }.
  const [agentFormatFixes, setAgentFormatFixes] = useState<any[]>([]);
  // Phase 138: Visual EXPLAIN dialog
  const [explainOpen, setExplainOpen] = useState(false);
  // BF-247: track the last estimate so a "broad scan" warning chip can render
  // in the toolbar before the user clicks Run.
  const BROAD_SCAN_THRESHOLD_ROWS = 10_000_000;
  const [lastEstimate, setLastEstimate] = useState<number | null>(null);
  // BF-250: live heartbeat / progress message from the backend so the user
  // can see "Query still running… 47s elapsed" instead of a silent spinner.
  const [progressLog, setProgressLog] = useState<string>('');
  // BF-585 (2026-05-29): queue position (null when not queued).
  // Drives a distinct chip in the executing row instead of relying
  // on progressLog text alone.
  const [queuePosition, setQueuePosition] = useState<number | null>(null);
  const [pruningHelpAnchor, setPruningHelpAnchor] = useState<HTMLElement | null>(null);

  // ── Save / Load / Publish state ───────────────────────────────
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [savedQueryId, setSavedQueryId] = useState<number | null>(null);
  const [savedQueryName, setSavedQueryName] = useState('');
  // BF-496 (2026-05-28) — auto-save-then-publish flag.  When the user
  // clicks Publish on an UNSAVED query, BQB prompts Save first (publish
  // snapshots query_config from the saved row, so unsaved queries
  // can't be published).  This flag tells handleSaved to flip
  // publishDialogOpen=true immediately after a successful save.  Works
  // for any source type including cross-connection (BQB already stores
  // secondary_connection_id in query_config on save).
  const [publishAfterSave, setPublishAfterSave] = useState(false);
  // Tracks the most recently saved / loaded ``.sql`` file so the
  // Publish + Create-Feed actions can target it even when there's no
  // saved_query backing the current SQL.  Cleared when the user
  // switches connection (handleConnChange) or starts a brand-new
  // query.  Either savedQueryId OR loadedSqlFileId is enough to
  // enable Publish + Feed in the Save menu.
  const [loadedSqlFileId, setLoadedSqlFileId] = useState<number | null>(null);
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  const [cacheStrategy, setCacheStrategy] = useState<'auto' | 'bypass' | 'refresh'>('auto');
  // BF-256: engine override per query.  'auto' uses threshold-based routing
  // (DuckDB for small, Spark Connect for >row_threshold rows).  'duckdb' /
  // 'spark' force one engine regardless of estimate.  Backend already accepts
  // engine_override in query_config; this just exposes the flag in the UI.
  const [engineOverride, setEngineOverride] = useState<'auto' | 'duckdb' | 'spark'>('auto');
  // BF-428I/K: per-query S3 reader override.  'auto' lets the router
  // pick (cost model in Phase F).  Reader list fetched from backend
  // metadata endpoint so adding a new reader doesn't require touching
  // BQB code (BF-428K MEDIUM-4 fix).  Validated server-side via the
  // forced_reader regex whitelist before being honoured.
  const [readerOverride, setReaderOverride] = useState<string>('auto');
  const [readerMetadata, setReaderMetadata] = useState<{name: string; label: string}[]>([]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { s3Readers } = await import('../services/api/s3Readers');
        const meta = await s3Readers.metadata();
        if (!cancelled) {
          setReaderMetadata(meta.map(m => ({ name: m.name, label: m.label })));
        }
      } catch {
        // Endpoint unavailable (admin auth, master switch off, etc.) —
        // hide the chip row.  No fallback to hardcoded list (drift risk).
      }
    })();
    return () => { cancelled = true; };
  }, []);
  // BF-266: mount-the-grid gate.  Mirrors CQB's `showResults` pattern —
  // the grid is hidden until execution_completed arrives via WS, otherwise
  // the user sees an empty grid that polls /results racing against the
  // backend's parquet writer.  CQB never has this problem because it never
  // mounts the grid until results are ready; BQB used to mount on
  // executionId alone.
  const [showResults, setShowResults] = useState(false);
  // BF-382/383 — surface result-cache hit / multi-worker dispatch info so
  // users can see WHY a query was fast (or that fan-out kicked in).  Cleared
  // on next execution start.
  const [executionBadge, setExecutionBadge] = useState<{
    fromCache?: boolean;
    fromMultiWorker?: boolean;
    workerCount?: number;
    mergeStrategy?: string;
    /** BF-414 — name of the engine that picked up the query.  Set as soon
     *  as dispatch decides so the chip renders during execution, not just
     *  at completion.  Values: 'single' | 'multi_worker' | 'spark_connect' |
     *  'multi_worker_broadcast_join' | 'sql_connector'. */
    engine?: string;
  } | null>(null);
  // SCAN-STRATEGY (2026-06-01): plan-decided snapshot from the
  // ``scan_plan_decided`` WS event.  Cleared on next execution start.
  // Lets the UI show "BULK_SCAN: 16 workers, largest-first, prewarm on"
  // so users see *why* they got the execution shape they did.
  const [mwScanPlan, setMwScanPlan] = useState<{
    profile?: string;
    file_order?: string;
    max_workers?: number;
    prewarm_footers?: boolean;
    prewarm_concurrency?: number;
    duckdb_threads?: number;
    boto3_max_pool_connections?: number;
    rationale?: string;
    file_count?: number;
    caller?: string;
    // 2026-06-04 — when query references multiple tables (JOIN/UNION
    // setup), backend re-emits scan_plan_decided with this map so the
    // chip tooltip can show "table_A: 3000 files · table_B: 5 files".
    // Absent on the single-table path.
    per_table_file_counts?: Record<string, number>;
  } | null>(null);
  // SCAN-STRATEGY round 9 (2026-06-01): prewarm-stage chip state.
  // Backend now broadcasts ``prewarm_stage`` WS events with structured
  // fields so the 30s-250s of HEAD storms shows as a distinct "Prewarming
  // 3030 files" chip instead of being lumped under "executing".
  // Stages: prewarm_footers (start) → prewarm_done (end), OR
  // prewarm_skipped_recent (when the 90s recent-cache short-circuits).
  const [prewarmStage, setPrewarmStage] = useState<{
    stage?: string;             // 'prewarm_footers' | 'prewarm_done' | 'prewarm_skipped_recent'
    files_total?: number;
    concurrency?: number;
    warmed?: number;
    errors?: number;
    timed_out?: number;
    elapsed_s?: number;
    from_recent_cache?: boolean;
    message?: string;
    _received_at?: number;  // Round 11: ms-epoch for self-timeout detection
  } | null>(null);
  // BF-599 (2026-05-30): live per-worker snapshots from the
  // multi_worker_progress WS event.  Keyed by chunk_index so a later
  // event for the same worker overwrites the prior state (setup → running
  // → completed).  Cleared on next execution start.
  const [mwWorkers, setMwWorkers] = useState<Record<number, {
    chunk_index: number;
    state: string;
    files_count?: number;
    setup_step?: number;
    setup_total?: number;
    setup_current?: string;
    // BF-599d: heartbeat-sampled stack frame ("iceberg_reader.py:412 fn")
    // and how long the SAME frame has been on top (stuck_s).  When a
    // worker is in state=running, this is the ONLY signal the UI has
    // about what the worker is actually doing.
    running_detail?: string;
    stuck_s?: number;
    rows?: number;
    elapsed_s?: number;
    error?: string;
    updated_at: number;
  }>>({});
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [savedQueries, setSavedQueries] = useState<SqlFile[]>([]);
  // Phase 134-N — Load dialog tracks BOTH saved queries (from the
  // ``saved_queries`` table) AND .sql files (from ``sql_files``).
  // Pre-fix BQB only listed sql_files, so users who saved a query via
  // "Save query" couldn't find it via "Load saved query…".
  const [savedQueryList, setSavedQueryList] = useState<any[]>([]);
  const [loadDialogTab, setLoadDialogTab] = useState<'queries' | 'files'>('queries');
  const [panelOpen, setPanelOpen] = useState(true);
  const [partitionValues, setPartitionValues] = useState<Record<string, string[]>>({});
  const [partitionData, setPartitionData] = useState<Record<string, any>>({});

  // ── Aggregation / Transform / Sort / Join state ─────────────────
  const [columnAggregations, setColumnAggregations] = useState<Record<string, string>>({});
  const [columnTransforms, setColumnTransforms] = useState<Record<string, string>>({});
  const [sortColumns, setSortColumns] = useState<SortDef[]>([]);
  const [joinConfig, setJoinConfig] = useState<JoinConfig | null>(null);
  const [queryLimit, setQueryLimit] = useState(5000);

  // Phase 142 — Streaming controls (S3 connections only).
  // Streaming source is set when the user runs with enableStreaming=true on
  // an S3 connection — DataGridViewer mounts in streaming mode and pulls
  // rows as they arrive from S3, instead of waiting for the full result.
  const [enableStreaming, setEnableStreaming] = useState(false);
  const [streamBgDownload, setStreamBgDownload] = useState(false);
  const [streamingSource, setStreamingSource] = useState<{
    connectionId: number;
    rawSql?: string;
    columns?: string[];
  } | null>(null);

  // Phase 142 — Cost estimate (debounced auto-fetch via /api/execute/estimate-sql)
  const [costEstimate, setCostEstimate] = useState<{
    estimated_rows: number;
    estimated_files: number;
    pushdown_warning?: { warn: boolean; hint: string };
  } | null>(null);
  const [estimating, setEstimating] = useState(false);
  // Round 12 (2026-06-02): proactive Validate & Fix.  ``validating``
  // disables the button while in flight; ``validateResult`` holds the
  // last result so the UI can show a "✓ Already valid" / "✓ Fixed N
  // issues" / "⚠ Could not auto-fix: ..." banner that persists until
  // the user edits the SQL.
  const [validating, setValidating] = useState(false);
  const [validateResult, setValidateResult] = useState<{
    kind: 'fixed' | 'clean' | 'error';
    message: string;
    applied_fixes?: string[];
    original_sql?: string;   // for the Undo affordance
    // Round 14: schema-aware column-existence validation results.  When
    // the backend's /api/sql/auto-fix detects column references that
    // don't exist in the table's schema cache, surface them with
    // "did you mean…" suggestions.
    column_issues?: Array<{
      table?: string | null;
      column: string;
      kind: 'not_in_table' | 'unknown_column';
      suggestions?: string[];
    }>;
  } | null>(null);
  const estimateTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // BF-417 — pre-execution result-cache visibility.  Polled alongside
  // the estimate so the user sees "⚡ Cached 2h 34m ago — Use cached /
  // Run fresh" before clicking Run.  null = no cache or not yet checked.
  const [cacheStatus, setCacheStatus] = useState<{
    cached: boolean;
    age_seconds?: number;
    age_human?: string;
    row_count?: number;
    hit_count?: number;
    ttl_remaining?: number | null;
    cache_key?: string;
  } | null>(null);
  const cacheStatusGenRef = useRef(0);

  // ── Advanced SQL state (Phase 134 Batch 2) ────────────────────
  const [having, setHaving] = useState<any[]>([]);
  const [computedColumns, setComputedColumns] = useState<any[]>([]);
  const [caseExpressions, setCaseExpressions] = useState<any[]>([]);
  const [windowFunctions, setWindowFunctions] = useState<any[]>([]);
  const [distinct, setDistinct] = useState(false);
  const [filterLogic, setFilterLogic] = useState<'AND' | 'OR'>('AND');

  // ── Advanced modal visibility ─────────────────────────────────
  const [showHavingModal, setShowHavingModal] = useState(false);
  const [showComputedModal, setShowComputedModal] = useState(false);
  const [showCaseModal, setShowCaseModal] = useState(false);
  const [showWindowModal, setShowWindowModal] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);

  // ── Snapshot build ─────────────────────────────────────────────
  const buildSnapshot = useCallback((): BqbTabSnapshot => ({
    selectedConnId,
    selectedTables,
    selectedCrossTables,
    selectedPhysical: Array.from(selectedPhysical),
    columnAggregations,
    columnTransforms,
    filters,
    sortColumns,
    joinConfig,
    queryLimit,
    sqlText,
    executionId,
    savedQueryId,
    savedQueryName,
    cacheStrategy,
    showCrossConn,
    crossConnId,
    crossConnMode,
    crossJoinHow,
    crossJoinLeftOn,
    crossJoinRightOn,
    having,
    computedColumns,
    caseExpressions,
    windowFunctions,
    distinct,
    filterLogic,
  }), [
    selectedConnId, selectedTables, selectedCrossTables, selectedPhysical,
    columnAggregations, columnTransforms, filters, sortColumns, joinConfig,
    queryLimit, sqlText, executionId, savedQueryId, savedQueryName,
    cacheStrategy, showCrossConn, crossConnId, crossConnMode, crossJoinHow, crossJoinLeftOn, crossJoinRightOn,
    having, computedColumns, caseExpressions, windowFunctions, distinct, filterLogic,
  ]);

  // ── Export snapshot on state changes ───────────────────────────
  useEffect(() => {
    if (!onSnapshotChange || !restoredRef.current) return;
    onSnapshotChange(buildSnapshot());
  }, [buildSnapshot, onSnapshotChange]);

  // ── WebSocket: stop spinner when backend signals completion ───────
  useEffect(() => {
    if (!_wsMsg || !executionId) return;
    const msg = _wsMsg as any;
    if (msg.execution_id !== executionId) return;
    // BF-584/585 (2026-05-29): queue notifications.  Render
    // "Queued — N ahead of you" via a dedicated state so the chip
    // can show a distinct visual (not just a progressLog string).
    // Position 0 means the slot was just acquired; subsequent
    // execution_progress events take over.
    if (msg.type === 'execution_queued' && msg.data) {
      const pos = Number(msg.data.queue_position ?? -1);
      const text = String(msg.data.message ?? '');
      if (pos > 0) {
        setQueuePosition(pos);
        setProgressLog(`Queued — ${pos} ahead of you`);
      } else {
        setQueuePosition(null);
        if (text) setProgressLog(text);
      }
      // executing flag stays true — query IS in flight, just waiting.
      return;
    }
    // BF-233 (BQB parity with BF-138): also reset spinner on execution_cancelled,
    // otherwise the user is stuck with a perpetual spinner after a cancel
    // because the failure/completion paths never fire.
    if (msg.type === 'execution_completed'
        || msg.type === 'execution_failed'
        || msg.type === 'execution_cancelled') {
      setExecuting(false);
      setProgressLog('');
      setQueuePosition(null);  // BF-585
      // BF-266: only mount the grid AFTER the engine signals completion
      // — same gate CQB uses.  On 'completed' we render the grid (which
      // immediately fetches /results from the now-finalised parquet).
      // On failed/cancelled we leave it hidden; the inline error shows.
      if (msg.type === 'execution_completed') {
        setShowResults(true);
      }
    }
    // BF-382/383 — pick up the cache-hit / multi-worker flags as soon as
    // they arrive so the badge renders even before execution_completed.
    if (msg.type === 'execution_progress' && msg.data) {
      const d = msg.data;
      // BF-414 — engine/worker info arrives via the same channel as soon as
      // dispatch decides (engine='single' for the default fallback path),
      // so the chip renders DURING execution, not only at completion.
      if (d.from_cache || d.from_multi_worker || d.engine || d.worker_count) {
        setExecutionBadge((prev) => ({
          ...(prev || {}),
          fromCache:       d.from_cache !== undefined ? Boolean(d.from_cache) : prev?.fromCache,
          fromMultiWorker: d.from_multi_worker !== undefined ? Boolean(d.from_multi_worker) : prev?.fromMultiWorker,
          workerCount:     d.worker_count ?? prev?.workerCount,
          mergeStrategy:   d.merge_strategy ?? prev?.mergeStrategy,
          engine:          d.engine ?? prev?.engine,
        }));
      }
    }
    // BF-599 (2026-05-30): live per-worker grid.  Backend pushes one
    // `multi_worker_progress` per worker-state-change (starting → setup
    // (step k/total) → running → completed/failed) via
    // `_broadcast_multi_worker_state` in execute_api.  Upsert by
    // chunk_index so each worker has at most one row.  Filtered to the
    // current execution to avoid stale events from a previous query.
    if (msg.type === 'multi_worker_progress' && msg.worker
        && (!executionId || msg.execution_id === executionId)) {
      const w = msg.worker;
      // BF-599g (round-2 audit): also reject negative + NaN chunk_index.
      // typeof NaN === 'number' is true in JS, so the prior check let
      // malformed payloads through.  Reject anything that's not a
      // finite non-negative integer.
      if (typeof w.chunk_index === 'number'
          && Number.isFinite(w.chunk_index)
          && w.chunk_index >= 0) {
        setMwWorkers((prev) => {
          const existing = prev[w.chunk_index];
          // BF-599d: heartbeat events arrive with state=null (field-only
          // updates) — keep the prior state in that case.  Also merge
          // optional fields so a heartbeat carrying only running_detail
          // doesn't wipe out the setup_step/rows captured earlier.
          // BF-599e (audit #8): whitelist allowed states — malformed
          // payloads with state="" or state="0" no longer pollute the
          // UI with "unknown".  Falls back to prior state, then
          // 'starting' as a safe default.
          const _ALLOWED_STATES = new Set([
            'starting', 'setup', 'running', 'completed', 'failed', 'cancelled',
          ]);
          const incoming = typeof w.state === 'string' && _ALLOWED_STATES.has(w.state)
            ? w.state
            : null;
          const nextState = incoming ?? existing?.state ?? 'starting';
          return {
            ...prev,
            [w.chunk_index]: {
              ...(existing || {}),
              chunk_index:   w.chunk_index,
              state:         nextState,
              files_count:   w.files_count    ?? existing?.files_count,
              setup_step:    w.setup_step     ?? existing?.setup_step,
              setup_total:   w.setup_total    ?? existing?.setup_total,
              setup_current: w.setup_current  ?? existing?.setup_current,
              running_detail: w.running_detail ?? existing?.running_detail,
              stuck_s:       typeof w.stuck_s === 'number' ? w.stuck_s : existing?.stuck_s,
              rows:          w.rows           ?? existing?.rows,
              elapsed_s:     w.elapsed_s      ?? existing?.elapsed_s,
              error:         w.error          ?? existing?.error,
              updated_at:    Date.now(),
            },
          };
        });
      }
    }
    // SCAN-STRATEGY (2026-06-01): plan-decided event — fires once per
    // query when the dispatcher's ScanStrategist commits to a profile.
    // Surfaces "BULK_SCAN: 16 workers, largest-first, prewarm on" so
    // users see why they got the execution shape they did, not just
    // a worker count.  Filtered to the current execution so stale
    // events from a previous query don't pollute the chip.
    if (msg.type === 'scan_plan_decided' && msg.plan
        && (!executionId || msg.execution_id === executionId)) {
      setMwScanPlan(msg.plan);
    }
    // Round 9 (2026-06-01) — prewarm stage events.  Backend fires
    // ``prewarm_stage`` with stage ∈ {prewarm_footers, prewarm_done,
    // prewarm_skipped_recent} so the UI can render a distinct chip
    // instead of lumping the HEAD-storm time under "executing".
    // Filtered to the current execution to avoid cross-pollution.
    if (msg.type === 'prewarm_stage'
        && (!executionId || msg.execution_id === executionId)) {
      setPrewarmStage({
        stage:             msg.stage,
        files_total:       msg.files_total,
        concurrency:       msg.concurrency,
        warmed:            msg.warmed,
        errors:            msg.errors,
        timed_out:         msg.timed_out,
        elapsed_s:         msg.elapsed_s,
        from_recent_cache: msg.from_recent_cache,
        message:           msg.message,
        // Round 11 (2026-06-02): timestamp so the self-timeout below
        // can detect a stale "Prewarming…" state when the WS
        // disconnects mid-prewarm and ``prewarm_done`` never arrives.
        _received_at:      Date.now(),
      } as any);
    }
    // BF-250: heartbeat / progress messages from the backend keep the user
    // informed during long blocking scans (COUNT DISTINCT etc.).
    if (msg.type === 'execution_progress' && msg.data?.log) {
      setProgressLog(String(msg.data.log));
      // BF-295: backend signals the engine is stalled after cancel; stop
      // showing the running spinner so the UI doesn't lie about state.
      if (msg.data?.status === 'stalled') {
        setExecuting(false);
        setError(String(msg.data.log));
      }
    }
    // Embed agent suggestion alongside the error so the user can act on it
    // without hunting through the notification panel.
    if (msg.type === 'execution_failed') {
      // Capture the error so BQB renders it (DataGridViewer also shows it
      // inside the grid boundary, but BQB needs it for the auto-fix button).
      if (msg.error) setError(String(msg.error));
      if (msg.agent_suggestion) {
        setAgentSuggestion(msg.agent_suggestion);
      } else if (msg.error) {
        // BF-243: agents may be disabled (agents.enabled defaults false), so
        // the backend's agent_suggestion is absent.  Synthesise one client-
        // side from well-known DuckDB error patterns so the auto-fix button
        // still appears.  Mirrors the patterns in QUERY_FIX_RULES.
        const errLower = String(msg.error).toLowerCase();
        if (/must appear in the group by clause|must be part of an aggregate function/.test(errLower)) {
          setAgentSuggestion({
            agent: 'sql_lint_local',
            strategy: 'add_group_by',
            reason: 'Aggregate function mixed with non-aggregated columns and no GROUP BY.',
          });
        } else if (/ambiguous (column|reference)|column\s+["`']?\w+["`']?\s+is\s+ambiguous/.test(errLower)) {
          // Round 12 — extend client-side synthesis to catch ambiguous-
          // column errors so the "Auto-fix SQL" button appears even when
          // backend agents are disabled.
          setAgentSuggestion({
            agent: 'sql_lint_local',
            strategy: 'qualify_ambiguous_columns',
            reason: 'A column reference exists in multiple FROM tables. Auto-fix prefixes it with the first table\'s alias.',
          });
        } else if (/column.*does not exist|referenced column.*not found/.test(errLower)) {
          // Round 12 — catch column-typo / schema-drift errors so the
          // user gets a refresh_schema fix suggestion instead of just
          // a raw error.
          setAgentSuggestion({
            agent: 'sql_lint_local',
            strategy: 'refresh_schema',
            reason: 'A column referenced in the query does not exist in the table — the schema may have changed since last load.',
          });
        }
      }
    }
  }, [_wsMsg, executionId]);

  // Round 11 (2026-06-02): prewarm chip self-timeout.  If the WS
  // disconnects between ``prewarm_footers`` and ``prewarm_done``, the
  // chip would otherwise stay at "Prewarming N files…" forever.
  // After 5 min in the "footers" stage with no done event, downgrade
  // the chip label so users know the state is stale (WS may have
  // dropped; query may still be running per the polling fallback).
  useEffect(() => {
    if (!prewarmStage || prewarmStage.stage !== 'prewarm_footers') return;
    const PREWARM_STALE_MS = 5 * 60 * 1000; // 5 min — bounded by per_head_timeout * files
    const receivedAt = prewarmStage._received_at ?? Date.now();
    const handle = setTimeout(() => {
      // Only mark stale if still in 'prewarm_footers' (not transitioned).
      setPrewarmStage((cur) => {
        if (!cur || cur.stage !== 'prewarm_footers') return cur;
        return { ...cur, stage: 'prewarm_stale' };
      });
    }, Math.max(0, PREWARM_STALE_MS - (Date.now() - receivedAt)));
    return () => clearTimeout(handle);
  }, [prewarmStage]);

  // ── BF-381 + BF-387: HTTP-poll status fallback when WebSocket disconnects ──
  // If the WS drops mid-query (90s idle prune, network blip, tab backgrounded),
  // the query continues server-side but the UI never sees the completion event.
  // This polls /api/executions/{id}/status every 3s while executing.
  //
  // BF-387: Also force-poll on document visibility change.  Browsers throttle
  // setInterval to 1/min in background tabs — without this hook, a user who
  // backgrounds the tab during a 12-second query could wait 5+ minutes to see
  // the result when they return.
  useEffect(() => {
    if (!executing || !executionId) return;
    const POLL_INTERVAL_MS = 3000;   // was 5000 — tighter for less perceived lag
    let cancelled = false;
    const tick = async () => {
      try {
        const resp: any = await safeFetch(
          `/api/executions/${encodeURIComponent(executionId)}/status`,
        );
        if (cancelled) return;
        // Surface live progress in the alert banner so user knows query
        // is still alive even when WS heartbeats stopped.
        if (resp?.message || resp?.stage) {
          const elapsed = resp?.stage_elapsed_seconds
            ? ` (${Math.round(resp.stage_elapsed_seconds)}s)`
            : '';
          const files = resp?.files_total
            ? ` · ${resp.files_done || 0}/${resp.files_total} files`
            : '';
          setProgressLog(`${resp.message || resp.stage}${files}${elapsed}`);
        }
        // BF-389: polling-fallback badge — if WS dropped, the original
        // execution_progress event with from_multi_worker is lost.  Read
        // the persisted engine_meta from the status endpoint and set the
        // badge state so the chip still renders.
        if (resp?.engine_meta) {
          const em = resp.engine_meta;
          if (em.from_cache || em.from_multi_worker || em.engine === 'multi_worker') {
            setExecutionBadge({
              fromCache:       Boolean(em.from_cache),
              fromMultiWorker: Boolean(em.from_multi_worker || em.engine === 'multi_worker'),
              workerCount:     em.worker_count,
              mergeStrategy:   em.merge_strategy,
            });
          }
        }
        // Terminal status → reset spinner + reveal results (same state
        // changes as the real WS completion handler).
        if (resp?.status === 'completed') {
          setExecuting(false);
          setProgressLog('');
          setShowResults(true);   // mount grid → grid fetches /results
        } else if (resp?.status === 'failed') {
          setExecuting(false);
          setProgressLog('');
          setError(resp?.error_message || 'Query failed');
        } else if (resp?.status === 'cancelled') {
          setExecuting(false);
          setProgressLog('');
        }
      } catch (e) {
        // 404 = unknown execution_id; stop polling
        // Other errors = transient; keep polling
        if (e && typeof e === 'object' && (e as any).status === 404) {
          cancelled = true;
        }
      }
    };
    // First tick immediately to update progress, then on interval
    tick();
    const id = setInterval(tick, POLL_INTERVAL_MS);

    // BF-387: when tab becomes visible after being backgrounded, browsers
    // resume setInterval but the FIRST throttled tick may be minutes off
    // schedule.  Force an immediate refresh on visibilitychange so a user
    // who switches back to the tab sees the latest status within 1 sec.
    const onVis = () => {
      if (document.visibilityState === 'visible' && !cancelled) {
        tick();
      }
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      cancelled = true;
      clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [executing, executionId]);

  // ── Restore from initialSnapshot once ─────────────────────────
  useEffect(() => {
    if (restoredRef.current || !initialSnapshot) {
      restoredRef.current = true;
      return;
    }
    restoredRef.current = true;
    const s = initialSnapshot;
    if (s.selectedConnId != null) setSelectedConnId(s.selectedConnId);
    if (s.selectedTables?.length) setSelectedTables(s.selectedTables);
    if (s.selectedCrossTables?.length) setSelectedCrossTables(s.selectedCrossTables);
    if (s.selectedPhysical?.length) setSelectedPhysical(new Set(s.selectedPhysical));
    if (s.columnAggregations) setColumnAggregations(s.columnAggregations);
    if (s.columnTransforms) setColumnTransforms(s.columnTransforms);
    if (s.filters?.length) setFilters(s.filters);
    if (s.sortColumns?.length) setSortColumns(s.sortColumns);
    if (s.joinConfig) setJoinConfig(s.joinConfig);
    if (s.queryLimit) setQueryLimit(s.queryLimit);
    if (s.sqlText) setSqlText(s.sqlText);
    if (s.executionId) {
      setExecutionId(s.executionId);
      // BF-266 follow-up: snapshot restore implies prior run already completed
      // (no live WS execution_completed will arrive for it), so mount the grid
      // immediately — otherwise the grid stays hidden behind the showResults
      // gate forever.
      setShowResults(true);
    }
    if (s.savedQueryId != null) setSavedQueryId(s.savedQueryId);
    if (s.savedQueryName) setSavedQueryName(s.savedQueryName);
    // BF-428Q — validate against union before restore.  A prior session
    // could have stored a polluted value (SyntheticEvent → "[SyntheticEvent]"
    // via safeStringify); accepting it via `as any` propagates the bad
    // value into the next executeQuery payload → backend 422.
    if (s.cacheStrategy && (s.cacheStrategy === 'auto' ||
        s.cacheStrategy === 'bypass' || s.cacheStrategy === 'refresh')) {
      setCacheStrategy(s.cacheStrategy);
    }
    if (s.showCrossConn) setShowCrossConn(s.showCrossConn);
    if (s.crossConnId != null) setCrossConnId(s.crossConnId);
    if (s.crossConnMode) setCrossConnMode(s.crossConnMode);
    if (s.crossJoinHow) setCrossJoinHow(s.crossJoinHow);
    if (s.crossJoinLeftOn) setCrossJoinLeftOn(s.crossJoinLeftOn);
    if (s.crossJoinRightOn) setCrossJoinRightOn(s.crossJoinRightOn);
    if (s.having?.length) setHaving(s.having);
    if (s.computedColumns?.length) setComputedColumns(s.computedColumns);
    if (s.caseExpressions?.length) setCaseExpressions(s.caseExpressions);
    if (s.windowFunctions?.length) setWindowFunctions(s.windowFunctions);
    if (s.distinct) setDistinct(s.distinct);
    if (s.filterLogic && s.filterLogic !== 'AND') setFilterLogic(s.filterLogic);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Dirty tracking ────────────────────────────────────────────
  useEffect(() => {
    if (!onDirtyChange) return;
    const dirty = selectedPhysical.size > 0 || sqlText.trim().length > 0;
    if (dirty !== dirtyRef.current) {
      dirtyRef.current = dirty;
      onDirtyChange(dirty);
    }
  }, [selectedPhysical, sqlText, onDirtyChange]);

  // ── Name change tracking ──────────────────────────────────────
  useEffect(() => {
    if (onNameChange && savedQueryName) onNameChange(savedQueryName);
  }, [savedQueryName, onNameChange]);

  // ── Keyboard shortcuts (active tab only) ──────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!isActiveRef.current) return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        document.querySelector<HTMLButtonElement>('[data-bqb-execute]')?.click();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        setShowSaveDialog(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // ── Load connections on mount ───────────────────────────────────
  useEffect(() => {
    api.listConnections(true).then((conns: any[]) => {
      setConnections(conns.map((c: any) => ({
        id: c.id, name: c.name, connection_type: c.connection_type,
        config: c.config,
      })));
    }).catch(() => {});
  }, []);

  // ── Load tables when connection changes ─────────────────────────
  useEffect(() => {
    // Always fetch local tables (uploaded parquet — no connection needed)
    const fetchLocal = api.listLocalTables().then((lts: any[]) =>
      (lts || []).filter((lt: any) => lt.status === 'ready').map((lt: any) => ({
        name: lt.table_name || lt.name,
        path: `__local__:${lt.table_name || lt.name}`,
        num_rows: lt.row_count,
        _type: 'local' as const,
      }))
    ).catch(() => [] as TableOption[]);

    // Fetch registered tables for the selected connection
    const fetchRegistered = selectedConnId
      ? api.listRegisteredTables(String(selectedConnId)).then((resp: any) => {
          const regTables = Array.isArray(resp) ? resp : (resp?.tables || []);
          return regTables.map((t: any) => ({
            name: t.name || t.table_name || t.path,
            path: t.path || `__registered__:${t.name || t.table_name}`,
            num_rows: t.num_rows,
            _type: 'registered' as const,
          }));
        }).catch(() => [] as TableOption[])
      : Promise.resolve([] as TableOption[]);

    // Fetch tables/files via listConnectionFiles.  BF-360: previously
    // filtered to .parquet ONLY which excluded SQL-connector tables
    // (Starburst, Snowflake, Trino, Databricks, Oracle, Athena) entirely.
    // For SQL connectors the backend returns ``table_type: 'TABLE'`` with
    // a ``cat.schema.table`` path — include those alongside parquet files.
    const fetchS3Files = selectedConnId
      ? api.listConnectionFiles(String(selectedConnId)).then((data: any) => {
          const items: any[] = Array.isArray(data) ? data : (data?.items || []);
          return items
            .filter((f: any) => {
              if (f.is_folder) return true;
              if (f.name?.toLowerCase().endsWith('.parquet')) return true;
              // SQL connector tables come back with table_type set
              if (f.table_type) return true;
              return false;
            })
            .map((f: any) => ({
              name: f.name || f.path,
              path: f.path || f.name,
              num_rows: f.num_rows,
              _type: f.table_type ? ('sql_table' as const) : ('s3file' as const),
            }));
        }).catch(() => [] as TableOption[])
      : Promise.resolve([] as TableOption[]);

    // Fetch materialized views (S3 connections only)
    const conn = connections.find(c => c.id === selectedConnId);
    const fetchMV = selectedConnId && conn?.connection_type === 's3'
      ? api.listMaterializedViews(selectedConnId).then((mvs: any[]) =>
          (mvs || []).filter((m: any) => m.status === 'ready').map((m: any) => ({
            name: m.view_name || m.name,
            path: `__materialized__:${m.view_name || m.name}`,
            num_rows: m.row_count,
            _type: 'materialized' as const,
          }))
        ).catch(() => [] as TableOption[])
      : Promise.resolve([] as TableOption[]);

    // Fetch federation views (global — not connection-specific)
    const fetchFED = api.listMaterializedFederationViews().then((fvs: any[]) =>
      (fvs || []).filter((f: any) => f.status === 'ready').map((f: any) => ({
        name: f.name || f.view_name,
        path: `__federation__:${f.name || f.view_name}`,
        num_rows: f.row_count,
        _type: 'federation' as const,
      }))
    ).catch(() => [] as TableOption[]);

    // Fetch iceberg tables (S3 with iceberg_warehouse_path)
    const warehousePath = conn?.config?.iceberg_warehouse_path;
    const fetchICE = selectedConnId && conn?.connection_type === 's3' && warehousePath
      ? api.listIcebergTables(String(selectedConnId), warehousePath).then((res: any) =>
          (res?.tables || []).map((t: any) => ({
            name: t.name || t.prefix,
            path: `__iceberg__:${t.name || t.prefix}`,
            num_rows: t.num_rows,
            _type: 'iceberg' as const,
          }))
        ).catch(() => [] as TableOption[])
      : Promise.resolve([] as TableOption[]);

    Promise.all([fetchRegistered, fetchS3Files, fetchLocal, fetchMV, fetchFED, fetchICE])
      .then(([reg, s3, local, mv, fed, ice]) => {
        // Deduplicate: registered tables take priority over raw file listing
        const regNames = new Set(reg.map(t => t.name));
        const uniqueS3 = s3.filter(f => !regNames.has(f.name));
        setTables([...reg, ...uniqueS3, ...local, ...mv, ...fed, ...ice]);
        setMaterializedViews(mv);
        setFederationViews(fed);
        setIcebergTables(ice);
      });

    // Fetch favorites
    api.listTableFavorites(selectedConnId || undefined).then((res: any) => {
      const favSet = new Set<string>((res?.favorites || []).map((f: any) => f.table_path));
      setTableFavorites(favSet);
    }).catch(() => {});
  }, [selectedConnId, connections]);

  // ── Load cross-connection tables ────────────────────────────────
  useEffect(() => {
    if (!crossConnId) { setCrossTables([]); return; }
    api.listRegisteredTables(String(crossConnId)).then((resp: any) => {
      const regTables = Array.isArray(resp) ? resp : (resp?.tables || []);
      setCrossTables(regTables.map((t: any) => ({
        name: t.name || t.table_name || t.path,
        path: t.path || `__registered__:${t.name || t.table_name}`,
        num_rows: t.num_rows,
      })));
    }).catch(() => setCrossTables([]));
  }, [crossConnId]);

  // ── Phase 142: Cost estimate — debounced auto-fetch ────────────────────────
  // Calls /api/execute/estimate-sql 800ms after the user stops typing.
  // Server returns rows + files + pushdown warning; UI shows the chip
  // in the toolbar.  Failure path is silent (chip just doesn't appear).
  //
  // Race protection: each effect run captures a generation number; only
  // the most-recent in-flight request is allowed to update state.  This
  // prevents a stale response (e.g. from before the user changed
  // connections) from overwriting a fresher one.
  const estimateGenRef = useRef(0);
  useEffect(() => {
    const sql = sqlText.trim();
    if (!sql || !selectedConnId) {
      setCostEstimate(null);
      return;
    }
    // Skip estimate for cross-conn — backend doesn't yet support raw_sql
    // estimate with secondary_query_config.  Falls through cleanly: just
    // no chip while cross-conn is active.
    if (showCrossConn && crossConnId) {
      setCostEstimate(null);
      return;
    }
    if (estimateTimerRef.current) clearTimeout(estimateTimerRef.current);
    const myGen = ++estimateGenRef.current;
    const cacheGen = ++cacheStatusGenRef.current;
    // BF-418 — blank the banner immediately when SQL or table set changes
    // so the user doesn't see "Cached 2h ago" for tables they no longer
    // have selected during the 800ms debounce window.  Re-population
    // happens once the new poll lands.
    setCacheStatus(null);
    estimateTimerRef.current = setTimeout(async () => {
      setEstimating(true);
      try {
        const est = await (api as any).estimateQuerySql(sql, selectedConnId);
        // Bail if a newer request was started while this one was in flight
        if (myGen !== estimateGenRef.current) return;
        if (est && typeof est.estimated_rows === 'number') {
          setCostEstimate(est);
        } else {
          setCostEstimate(null);
        }
      } catch {
        if (myGen === estimateGenRef.current) setCostEstimate(null);
      } finally {
        if (myGen === estimateGenRef.current) setEstimating(false);
      }

      // BF-417 — alongside the estimate, peek the result cache so the UI
      // can render "⚡ Cached 2h ago — Use cached / Run fresh".  Cheap
      // (single in-process map lookup); fail-open if not cacheable.
      try {
        const filesForCache = selectedTables.map(t => ({ path: t.path }));
        if (sql && filesForCache.length) {
          const cs = await (api as any).getCacheStatus({
            raw_sql: sql,
            files: filesForCache,
            connection_id: selectedConnId,
          });
          if (cacheGen === cacheStatusGenRef.current) {
            setCacheStatus(cs && cs.cached ? cs : null);
          }
        } else {
          if (cacheGen === cacheStatusGenRef.current) setCacheStatus(null);
        }
      } catch {
        if (cacheGen === cacheStatusGenRef.current) setCacheStatus(null);
      }
    }, 800);
    return () => {
      if (estimateTimerRef.current) clearTimeout(estimateTimerRef.current);
    };
  }, [sqlText, selectedConnId, showCrossConn, crossConnId, selectedTables]);

  // ── Schema-load helpers ─────────────────────────────────────────
  // Pure transformations live above the React-state code so they can
  // be unit-tested in isolation and the state-update path stays
  // single-responsibility.

  /** Turn the API response into per-table cache entries, indexed by
   * the requested table paths.  Pure — does not touch state. */
  const buildCacheEntriesFromResponse = (
    paths: string[],
    res: { columns: MappedColumn[]; categories: { name: string; sort_order: number }[]; partition_columns: string[] },
  ): typeof columnCache => {
    const catOrders: Record<string, number> = {};
    res.categories.forEach(cat => { catOrders[cat.name] = cat.sort_order; });

    const entries: typeof columnCache = {};
    paths.forEach(p => { entries[p] = { cols: [], partCols: [], catOrders }; });

    res.columns.forEach(col => {
      const key = col.source_table || paths[0];
      if (!entries[key]) entries[key] = { cols: [], partCols: [], catOrders };
      entries[key].cols.push(col);
    });

    res.partition_columns.forEach(pc => {
      paths.forEach(p => {
        if (entries[p]?.cols.some(c => c.physical_name === pc)) {
          entries[p].partCols.push(pc);
        }
      });
    });

    return entries;
  };

  /** Merge new cache entries into existing cache.  When ``refresh``
   * is true, the requested paths are dropped from the baseline first
   * so the new entries fully replace any prior values (otherwise
   * stale partCols / catOrders could survive a refresh that produced
   * the same column shape). */
  const mergeIntoCache = (
    prev: typeof columnCache,
    newEntries: typeof columnCache,
    refreshedPaths: string[],
    refresh: boolean,
  ): typeof columnCache => {
    if (!refresh) return { ...prev, ...newEntries };
    const baseline = Object.fromEntries(
      Object.entries(prev).filter(([k]) => !refreshedPaths.includes(k))
    );
    return { ...baseline, ...newEntries };
  };

  /** Recompute the displayed column list + categories + partition
   * columns from the canonical ``columnCache``.  Pure — caller
   * dispatches the resulting state updates. */
  const computeDisplayFromCache = (
    cache: typeof columnCache,
    paths: string[],
  ): { cols: MappedColumn[]; partCols: string[]; cats: { name: string; count: number; sort_order: number }[] } => {
    const cols: MappedColumn[] = [];
    const partCols: string[] = [];
    const orders: Record<string, number> = {};
    paths.forEach(p => {
      const entry = cache[p];
      if (!entry) return;
      cols.push(...entry.cols);
      partCols.push(...entry.partCols);
      Object.assign(orders, entry.catOrders);
    });
    const counts = new Map<string, number>();
    cols.forEach(c => {
      const cat = c.category || 'Other';
      counts.set(cat, (counts.get(cat) || 0) + 1);
    });
    const cats = Array.from(counts.entries()).map(([name, count]) => ({
      name, count, sort_order: orders[name] ?? 99,
    }));
    return { cols, partCols: Array.from(new Set(partCols)), cats };
  };

  /** Fetch schema for the given paths and refresh the displayed
   * column / category / partition state from the merged cache.
   *
   * Single entry point for both the auto-load effect (refresh=false)
   * and the user-clicked "Refresh schema" button (refresh=true).
   * When ``refresh=true`` the backend also bypasses its own L1/L2
   * cache; if the live S3 read fails, the backend's stale-while-
   * revalidate path returns the previous cached entry — UI does not
   * see an error, user can retry later when S3 recovers.
   */
  const loadColumnsForTables = useCallback(async (
    paths: string[],
    opts: { refresh?: boolean } = {},
  ): Promise<void> => {
    if (!selectedConnId || paths.length === 0) return;
    const refresh = opts.refresh === true;
    setLoadingColumns(true);
    try {
      const res = await api.businessQueryBuilder.autoMapColumns({
        connection_id: selectedConnId,
        table_paths: paths,
        refresh,
      });
      const newEntries = buildCacheEntriesFromResponse(paths, res);
      const selectedPaths = selectedTables.map(t => t.path);
      setColumnCache(prev => {
        const merged = mergeIntoCache(prev, newEntries, paths, refresh);
        const display = computeDisplayFromCache(merged, selectedPaths);
        setMappedColumns(display.cols);
        setPartitionColumns(display.partCols);
        setCategories(display.cats);
        return merged;
      });
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to load columns');
    } finally {
      setLoadingColumns(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedConnId, selectedTables]);

  /** User-triggered "Refresh schema" handler.  Mirrors CQB's
   * schema-refresh button — drops the per-table local cache for
   * every currently-selected table and forces a fresh live S3 read
   * via the backend's ``refresh=true`` path. */
  const handleRefreshSchema = useCallback(() => {
    if (!selectedConnId || selectedTables.length === 0) return;
    void loadColumnsForTables(selectedTables.map(t => t.path), { refresh: true });
  }, [selectedConnId, selectedTables, loadColumnsForTables]);

  // ── Auto-map columns when tables change (per-table caching) ─────
  useEffect(() => {
    if (!selectedConnId || selectedTables.length === 0) {
      setMappedColumns([]);
      setCategories([]);
      setPartitionColumns([]);
      return;
    }

    const allPaths = selectedTables.map(t => t.path);
    const newPaths = allPaths.filter(p => !columnCache[p]);

    // Helper: recompute merged columns from cache for selected tables
    const recomputeFromCache = (cache: typeof columnCache) => {
      const allCols: MappedColumn[] = [];
      const allPartCols: string[] = [];
      const mergedOrders: Record<string, number> = {};
      allPaths.forEach(p => {
        const entry = cache[p];
        if (entry) {
          allCols.push(...entry.cols);
          allPartCols.push(...entry.partCols);
          Object.assign(mergedOrders, entry.catOrders);
        }
      });
      setMappedColumns(allCols);
      setPartitionColumns([...new Set(allPartCols)]);
      // Rebuild categories from merged columns
      const catSet = new Map<string, number>();
      allCols.forEach(c => {
        if (!catSet.has(c.category)) catSet.set(c.category, 0);
        catSet.set(c.category, catSet.get(c.category)! + 1);
      });
      setCategories(Array.from(catSet.entries()).map(([name, count]) => ({
        name, count, sort_order: mergedOrders[name] ?? 99,
      })));
    };

    if (newPaths.length === 0) {
      // All tables already cached — instant recompute, no API call
      recomputeFromCache(columnCache);
      return;
    }

    // Auto-load NEW tables.  Routes through the same
    // ``loadColumnsForTables`` helper the manual Refresh button uses
    // so any future fix lands in one place.
    void loadColumnsForTables(newPaths);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedConnId, selectedTables]);

  // ── Fetch partition values for tables that have partition columns ──
  useEffect(() => {
    if (!selectedConnId || selectedTables.length === 0 || partitionColumns.length === 0) {
      setPartitionValues({});
      setPartitionData({});
      return;
    }
    // Only fetch for tables that actually have partition columns
    const tablesWithParts = selectedTables.filter(t => {
      const entry = columnCache[t.path];
      return entry && entry.partCols.length > 0;
    });
    if (tablesWithParts.length === 0) return;

    Promise.all(
      tablesWithParts.map(table =>
        api.getRegisteredTablePartitions(String(selectedConnId), table.name)
          .then((res: any) => ({ name: table.name, data: res }))
          .catch(() => ({ name: table.name, data: { values: {} } }))
      )
    ).then(results => {
      const merged: Record<string, string[]> = {};
      const fullData: Record<string, any> = {};
      for (const { name, data } of results) {
        fullData[name] = data;
        for (const [col, vals] of Object.entries(data.values || {})) {
          if (!merged[col]) merged[col] = [];
          for (const v of (vals as string[])) {
            if (!merged[col].includes(v)) merged[col].push(v);
          }
        }
      }
      setPartitionValues(merged);
      setPartitionData(fullData);
    });
  }, [selectedConnId, selectedTables, partitionColumns]);

  // ── Auto-detect join when 2+ tables selected ──────────────────
  useEffect(() => {
    if (selectedTables.length < 2 || mappedColumns.length === 0) {
      setJoinConfig(null);
      return;
    }
    const t1 = selectedTables[0].path;
    const t2 = selectedTables[1].path;
    const cols1 = mappedColumns.filter(c => c.source_table === t1).map(c => c.physical_name);
    const cols2 = mappedColumns.filter(c => c.source_table === t2).map(c => c.physical_name);
    const match = cols1.find(c => cols2.includes(c) && !partitionColumns.includes(c));
    if (match) {
      setJoinConfig({
        leftTable: t1, rightTable: t2,
        leftCol: match, rightCol: match,
        joinType: 'INNER',
      });
    } else {
      setJoinConfig(null);
    }
  }, [selectedTables, mappedColumns, partitionColumns]);

  // ── Table selection toggle ────────────────────────────────────
  const toggleTable = useCallback((table: TableOption) => {
    setSelectedTables(prev => {
      const exists = prev.some(t => t.path === table.path);
      if (exists) return prev.filter(t => t.path !== table.path);
      return [...prev, table];
    });
    setExecutionId(null);
    // BQB-FIX: visual-builder action → user expects autogen to rebuild
    // SQL.  Clearing the manual flag lets autogen replace stale SQL from
    // a previous table or a server-loaded draft.
    manuallyEditedRef.current = false;
  }, []);

  // ── Column selection helpers ────────────────────────────────────
  const toggleColumn = useCallback((physicalName: string) => {
    setSelectedPhysical(prev => {
      const next = new Set(prev);
      if (next.has(physicalName)) {
        next.delete(physicalName);
        // Clean up aggregation/transform when deselected
        setColumnAggregations(p => { const n = { ...p }; delete n[physicalName]; return n; });
        setColumnTransforms(p => { const n = { ...p }; delete n[physicalName]; return n; });
      } else {
        next.add(physicalName);
        // Track column usage for smart defaults
        if (selectedConnId) {
          const col = mappedColumns.find(c => c.physical_name === physicalName);
          if (col?.source_table) trackColumnUse(selectedConnId, col.source_table, physicalName);
        }
      }
      return next;
    });
  }, [mappedColumns, selectedConnId]);

  // Ref-backed selectedPhysical so toggleCategory has stable identity (no selectedPhysical dep).
  // ColumnsForTable is React.memo'd — a new function ref on every Set mutation caused a full
  // re-render cascade for every individual column tick, freezing the page on "select all".
  const selectedPhysicalRef = useRef(selectedPhysical);
  useEffect(() => { selectedPhysicalRef.current = selectedPhysical; }, [selectedPhysical]);

  const toggleCategory = useCallback((categoryName: string, columns: MappedColumn[]) => {
    // `columns` is already filtered to this category group by ColumnsForTable —
    // do NOT re-filter by c.category (breaks partition group whose stored category is 'All').
    const allSelected = columns.every(c => selectedPhysicalRef.current.has(c.physical_name));
    // Single setSelectedPhysical call — add or remove the whole batch at once
    setSelectedPhysical(prev => {
      const next = new Set(prev);
      if (allSelected) columns.forEach(c => next.delete(c.physical_name));
      else             columns.forEach(c => next.add(c.physical_name));
      return next;
    });
    // Clean up agg/transform when deselecting — one batch update per state, not per column
    if (allSelected) {
      setColumnAggregations(prev => {
        const next = { ...prev };
        columns.forEach(c => delete next[c.physical_name]);
        return next;
      });
      setColumnTransforms(prev => {
        const next = { ...prev };
        columns.forEach(c => delete next[c.physical_name]);
        return next;
      });
    }
  }, []); // stable — reads selectedPhysical via ref, writes via functional setters

  // ── Columns grouped by source_table then category ──────────────
  // Partition columns appear as a top-level "Partition" group.
  const columnsByTable = useMemo(() => {
    const byTable: Record<string, Record<string, MappedColumn[]>> = {};
    const q = tableSearch.trim().toLowerCase();
    const cols = q
      ? mappedColumns.filter(c =>
          c.friendly_name.toLowerCase().includes(q) ||
          c.physical_name.toLowerCase().includes(q) ||
          (c.source_table || '').toLowerCase().includes(q))
      : mappedColumns;
    cols.forEach(c => {
      const table = c.source_table || 'Unknown';
      if (!byTable[table]) byTable[table] = {};
      // Partition columns get their own group at the top
      if (c.is_partition) {
        const partCat = '\u26A1 Partition';
        if (!byTable[table][partCat]) byTable[table][partCat] = [];
        byTable[table][partCat].push(c);
      }
      // Also add to regular category
      const cat = c.category || 'Other';
      if (!byTable[table][cat]) byTable[table][cat] = [];
      byTable[table][cat].push(c);
    });
    return byTable;
  }, [mappedColumns, tableSearch]);

  // ── Filtered tables for search + type filter + favorites sort ──
  // BF-113: Also keep tables whose columns match the search query
  const filteredTables = useMemo(() => {
    let items = tables;
    if (tableTypeFilter !== 'all') {
      items = items.filter(t => t._type === tableTypeFilter);
    }
    if (tableSearch.trim()) {
      const q = tableSearch.toLowerCase();
      items = items.filter(t => {
        if (t.name.toLowerCase().includes(q)) return true;
        const catGroups = columnsByTable[t.path];
        if (catGroups) {
          for (const cols of Object.values(catGroups)) {
            if (cols.some(c =>
              c.physical_name.toLowerCase().includes(q) ||
              c.friendly_name.toLowerCase().includes(q)
            )) return true;
          }
        }
        return false;
      });
    }
    if (tableFavorites.size > 0) {
      items = [...items].sort((a, b) => {
        const aFav = tableFavorites.has(a.path) ? 0 : 1;
        const bFav = tableFavorites.has(b.path) ? 0 : 1;
        return aFav - bFav;
      });
    }
    return items;
  }, [tables, tableSearch, tableTypeFilter, tableFavorites, columnsByTable]);

  const filteredCrossTables = useMemo(() => {
    if (!tableSearch.trim()) return crossTables;
    const q = tableSearch.toLowerCase();
    return crossTables.filter(t => t.name.toLowerCase().includes(q));
  }, [crossTables, tableSearch]);

  // Helper: extract short table name from path
  const sqlTableName = useCallback((path: string) => {
    if (path.startsWith('__registered__:')) return qid(path.slice(15));
    if (path.startsWith('__local__:')) return qid(`__lt__${path.slice(10)}`);
    if (path.startsWith('__materialized__:')) return qid(path.slice(17));
    if (path.startsWith('__federation__:')) return qid(path.slice(15));
    if (path.startsWith('__iceberg__:')) return qid(path.slice(12));
    const parts = path.split('/');
    return qid(parts[parts.length - 1] || path);
  }, []);

  // BF-360: shared helper — also strips catalog.schema. prefix from SQL
  // connector paths (Starburst / Snowflake / etc.) so chips don't render
  // 'iceberg.fact_sales.orders_2024' when 'orders_2024' is enough.
  const displayTableName = useCallback((path: string) => dnUtil(path), []);
  const shortTableLabel = useCallback(
    (path: string, max = 28) => shortLabelUtil(path, max),
    [],
  );

  // ── Selected column objects ─────────────────────────────────────
  const selectedColumnObjects = useMemo(() =>
    mappedColumns.filter(c => selectedPhysical.has(c.physical_name)),
    [mappedColumns, selectedPhysical]
  );

  // ── Connection name lookup ──────────────────────────────────────
  const connName = useCallback((id: number | null) => {
    if (!id) return '';
    return connections.find(c => c.id === id)?.name || '';
  }, [connections]);

  // ── Frequent columns per table (smart defaults) ────────────────
  const frequentColumns = useMemo(() => {
    if (!selectedConnId) return {};
    const result: Record<string, Set<string>> = {};
    selectedTables.forEach(t => {
      result[t.path] = getFrequentColumns(selectedConnId, t.path);
    });
    return result;
  }, [selectedConnId, selectedTables]); // selectedPhysical removed — pure lookup, not affected by selection

  // ── SQL auto-generation from visual state ─────────────────────
  useEffect(() => {
    if (selectedTables.length === 0 || !selectedConnId) {
      // Only clear if the user hasn't manually edited.
      setSqlText(prev => {
        if (manuallyEditedRef.current && prev !== '') return prev;
        lastAutoGenSqlRef.current = '';
        return '';
      });
      return;
    }
    // No columns selected AND no active filters → nothing useful to show
    const hasActiveFilters = filters.some(f => f.value.trim().length > 0);
    if (selectedPhysical.size === 0 && !hasActiveFilters) {
      setSqlText(prev => {
        if (manuallyEditedRef.current && prev !== '') return prev;
        lastAutoGenSqlRef.current = '';
        return '';
      });
      return;
    }

    // Debounce — coalesces rapid column selections (e.g. "select all" of
    // 1000 columns) so CodeMirror doesn't re-parse on every individual
    // checkbox tick.  Phase 138: scale debounce with column count — large
    // column sets need more breathing room before SQL regeneration.
    const _debounceMs = selectedPhysical.size > 200 ? 250 : 80;
    const _timer = setTimeout(() => {

    const distinctKw = distinct ? 'DISTINCT ' : '';

    // SELECT columns with aggregation + transform
    // toAlias: SYSTEM_CODE → "System Code" for readable column headers
    // When no columns are explicitly checked, fall back to SELECT *
    const colParts = selectedColumnObjects.map(c => {
      const agg = columnAggregations[c.physical_name] || '';
      const transform = columnTransforms[c.physical_name] || '';
      const expr = buildExpr(c.physical_name, agg, transform);
      return `  ${expr} AS ${qid(toAlias(c.physical_name))}`;
    });

    // Computed columns (expression already a raw SQL string)
    computedColumns.forEach(cc => {
      if (cc.expression && cc.alias) colParts.push(`  ${cc.expression} AS ${qid(cc.alias)}`);
    });

    // CASE expressions — build from structured {alias, when_clauses, else_value}
    caseExpressions.forEach(ce => {
      const expr = buildCaseExpr(ce);
      if (expr) colParts.push(`  ${expr} AS ${qid(ce.alias)}`);
    });

    // Window functions — build from structured {function, column, partition_by, order_by, alias}
    windowFunctions.forEach(wf => {
      const expr = buildWindowExpr(wf);
      if (expr) colParts.push(`  ${expr} AS ${qid(wf.alias)}`);
    });

    // No columns explicitly checked → SELECT * so filters still produce valid SQL
    const cols = colParts.length > 0 ? colParts.join(',\n') : '*';

    // FROM clause — with optional JOIN
    // BF-261: when 2+ tables are selected without an explicit JOIN, the
    // previous build emitted ``FROM tableA, tableB`` (implicit cross join).
    // For tables that share column names (e.g. fact_table + fact_table_ext)
    // the SELECT against shared columns then fails with
    // "Ambiguous reference to column name X".  Switch to UNION ALL BY NAME
    // so the same column appears once across the combined source — same
    // shape backend uses internally for registered-view wrapping.
    let fromClause: string;
    if (joinConfig && selectedTables.length >= 2) {
      const leftName = sqlTableName(selectedTables[0].path);
      const rightName = sqlTableName(selectedTables[1].path);
      const prefix = showCrossConn && crossConnId ? `"${connName(selectedConnId)}".` : '';
      fromClause = `${prefix}${leftName}\n  ${joinConfig.joinType} JOIN ${prefix}${rightName} ON ${leftName}.${qid(joinConfig.leftCol)} = ${rightName}.${qid(joinConfig.rightCol)}`;
    } else if (selectedTables.length >= 2) {
      const prefix = showCrossConn && crossConnId ? `"${connName(selectedConnId)}".` : '';
      const unionParts = selectedTables.map(t =>
        `SELECT * FROM ${prefix}${sqlTableName(t.path)}`
      ).join('\n  UNION ALL BY NAME\n  ');
      fromClause = `(\n  ${unionParts}\n) AS t0`;
    } else {
      fromClause = selectedTables.map(t => {
        const name = sqlTableName(t.path);
        return showCrossConn && crossConnId ? `"${connName(selectedConnId)}".${name}` : name;
      }).join(', ');
    }

    // WHERE (supports AND/OR filter logic)
    const activeFilters = filters.filter(f => f.value.trim());
    let whereClause = '';
    if (activeFilters.length > 0) {
      const esc = (v: string) => v.replace(/'/g, "''");
      const conditions = activeFilters.map(f => {
        const col = qid(f.physical_name);
        const val = esc(f.value.trim());
        switch (f.operator) {
          case 'like': return `${col} LIKE '%${val}%'`;
          case 'in':   return `${col} IN (${val.split(',').map(v => `'${esc(v.trim())}'`).join(', ')})`;
          case 'neq':  return `${col} != '${val}'`;
          case 'gte':  return `${col} >= '${val}'`;
          case 'lte':  return `${col} <= '${val}'`;
          case 'gt':   return `${col} > '${val}'`;
          case 'lt':   return `${col} < '${val}'`;
          default:     return `${col} = '${val}'`;
        }
      });
      const joiner = filterLogic === 'OR' ? '\n  OR ' : '\n  AND ';
      whereClause = `\nWHERE ${conditions.join(joiner)}`;
    }

    // GROUP BY — auto: non-aggregated selected columns when any agg is active
    const hasAnyAgg = Object.values(columnAggregations).some(v => v);
    let groupByClause = '';
    if (hasAnyAgg) {
      const groupCols = selectedColumnObjects
        .filter(c => !columnAggregations[c.physical_name])
        .map(c => {
          const transform = columnTransforms[c.physical_name] || '';
          return buildExpr(c.physical_name, '', transform);
        });
      if (groupCols.length > 0) {
        groupByClause = `\nGROUP BY ${groupCols.join(', ')}`;
      }
    }

    // HAVING
    let havingClause = '';
    if (having.length > 0 && groupByClause) {
      const havingConds = having
        .filter((h: any) => h.expression)
        .map((h: any) => h.expression);
      if (havingConds.length > 0) {
        havingClause = `\nHAVING ${havingConds.join(' AND ')}`;
      }
    }

    // ORDER BY
    let orderByClause = '';
    if (sortColumns.length > 0) {
      orderByClause = `\nORDER BY ${sortColumns.map(s => `${qid(s.column)} ${s.direction}`).join(', ')}`;
    }

    // Cross-connection — generate separate primary + secondary SQL for backend execution
    let sql: string;
    if (showCrossConn && crossConnId && selectedCrossTables.length > 0) {
      // Primary-only FROM (no connection prefix — views have plain names)
      const primaryFrom = selectedTables.map(t => sqlTableName(t.path)).join(', ');
      const primarySql = `SELECT ${distinctKw}\n${cols}\nFROM ${primaryFrom}${whereClause}${groupByClause}${havingClause}${orderByClause}\nLIMIT ${queryLimit};`;

      // Secondary-only FROM (no connection prefix)
      const crossFrom = selectedCrossTables.map(t => sqlTableName(t.path)).join(', ');
      const crossCols = selectedColumnObjects.map(c => `  ${qid(c.physical_name)}`).join(',\n');
      const secSql = `SELECT ${distinctKw}\n${crossCols}\nFROM ${crossFrom}${whereClause}\nLIMIT ${queryLimit};`;
      setSecondaryRawSql(secSql);

      // Display SQL — shows combined view for user understanding
      const displayFrom = selectedTables.map(t => {
        const name = sqlTableName(t.path);
        return `"${connName(selectedConnId!)}".${name}`;
      }).join(', ');
      const displayCross = selectedCrossTables.map(t =>
        `"${connName(crossConnId)}".${sqlTableName(t.path)}`
      ).join(', ');
      if (crossConnMode === 'join') {
        sql = `-- Primary (${connName(selectedConnId!)})\n${primarySql}\n\n-- Secondary (${connName(crossConnId)}) — ${crossJoinHow.toUpperCase()} JOIN on ${crossJoinLeftOn || '?'} = ${crossJoinRightOn || '?'}\n${secSql}`;
      } else {
        sql = `SELECT ${distinctKw}* FROM (\n  SELECT\n${cols}\n  FROM ${displayFrom}${whereClause}${groupByClause}${havingClause}\n\n  UNION ALL\n\n  SELECT\n${crossCols}\n  FROM ${displayCross}${whereClause}\n) AS combined${orderByClause}\nLIMIT ${queryLimit};`;
      }
    } else {
      setSecondaryRawSql('');
      sql = `SELECT ${distinctKw}\n${cols}\nFROM ${fromClause}${whereClause}${groupByClause}${havingClause}${orderByClause}\nLIMIT ${queryLimit};`;
    }

    // Only overwrite if the user hasn't typed manually.  Server-loaded
    // drafts are treated as autogen (not "manual"), so a new connection
    // / table selection rebuilds the SQL cleanly.
    setSqlText(prev => {
      if (manuallyEditedRef.current && prev !== '') return prev;
      lastAutoGenSqlRef.current = sql;
      return sql;
    });
    setSqlError(null);
    }, _debounceMs); // end debounce
    return () => clearTimeout(_timer);
  }, [selectedPhysical, selectedTables, selectedColumnObjects, filters,
      selectedConnId, showCrossConn, crossConnId, selectedCrossTables,
      connName, sqlTableName, columnAggregations, columnTransforms,
      sortColumns, joinConfig, queryLimit,
      distinct, filterLogic, having, computedColumns, caseExpressions, windowFunctions,
      crossConnMode, crossJoinHow, crossJoinLeftOn, crossJoinRightOn]);

  // ── Filter helpers ──────────────────────────────────────────────
  const addFilter = useCallback(() => {
    if (mappedColumns.length === 0) return;
    // Prefer a partition column as the default; fall back to first available column.
    // Uses mappedColumns (all table columns) so filters work without selecting columns first.
    const col = mappedColumns.find(c => c.is_partition) || mappedColumns[0];
    setFilters(prev => [...prev, {
      id: crypto.randomUUID(),
      physical_name: col.physical_name,
      friendly_name: col.friendly_name,
      operator: 'eq', value: '',
      is_partition: col.is_partition,
    }]);
  }, [mappedColumns]);

  const updateFilter = useCallback((id: string, field: string, value: string) => {
    setFilters(prev => prev.map(f => {
      if (f.id !== id) return f;
      const updated = { ...f, [field]: value };
      if (field === 'physical_name') {
        const col = mappedColumns.find(c => c.physical_name === value);
        if (col) {
          updated.friendly_name = col.friendly_name;
          updated.is_partition = col.is_partition;
        }
      }
      return updated;
    }));
  }, [mappedColumns]);

  const removeFilter = useCallback((id: string) => {
    setFilters(prev => prev.filter(f => f.id !== id));
  }, []);

  const hasPartitionFilter = useMemo(() =>
    filters.some(f => f.is_partition && f.value.trim()),
    [filters]
  );

  // Auto-add partition columns as default filter rows when tables are selected
  const partColsKey = partitionColumns.join(',');
  React.useEffect(() => {
    if (partitionColumns.length === 0 || filters.length > 0) return;
    // Add up to 2 partition columns as pre-populated (empty value) filter rows
    const autoFilters: BusinessFilter[] = partitionColumns.slice(0, 2).map(pc => {
      const col = mappedColumns.find(c => c.physical_name === pc);
      return {
        id: crypto.randomUUID(),
        physical_name: pc,
        friendly_name: col?.friendly_name || pc,
        operator: 'eq',
        value: '',
        is_partition: true,
      };
    });
    if (autoFilters.length > 0) setFilters(autoFilters);
  }, [partColsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Sort helpers ────────────────────────────────────────────────
  const addSort = useCallback(() => {
    if (mappedColumns.length === 0) return;
    const col = mappedColumns.find(c => c.is_partition) || mappedColumns[0];
    setSortColumns(prev => [...prev, { column: col.physical_name, direction: 'ASC' }]);
  }, [mappedColumns]);

  // ── Phase 138: Drill-down from result grid cell → add filter ─────
  // Right-click in DataGridViewer → "Filter to value" / "Exclude value".
  // We map onto the same addFilter pipeline so the new filter shows up in
  // the ConditionsBar chip row.
  const handleCellDrilldown = useCallback((col: string, value: any, action: 'filter_eq' | 'filter_neq' | 'copy') => {
    if (action === 'copy') return;  // DataGridViewer already copies to clipboard
    // Resolve column metadata to find its physical_name + partition status
    const mc = mappedColumns.find(c => c.physical_name === col || c.friendly_name === col);
    const physical_name = mc?.physical_name || col;
    const friendly_name = mc?.friendly_name || col;
    const is_partition = !!mc?.is_partition;
    setFilters(prev => [
      ...prev,
      {
        id: `drill-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        physical_name, friendly_name,
        operator: action === 'filter_eq' ? 'eq' : 'neq',
        value: value === null || value === undefined ? '' : String(value),
        is_partition,
      },
    ]);
  }, [mappedColumns]);

  // ── Cancel running query ──────────────────────────────────────
  // Mirrors CompleteQueryBuilder's pattern: hits /api/executions/{id}/cancel
  // and immediately clears local executing/executionId state so the user
  // gets instant UI feedback even before the WS execution_cancelled fires.
  const cancelQuery = useCallback(async () => {
    if (executionId) {
      try { await api.cancelExecution(executionId); } catch { /* fail-open */ }
    }
    // BF-264: also clear executionId so the WS handler (filtered by
    // execution_id) stops processing late messages from the old run, the
    // grid unmounts, and the heartbeat-register effect tears down its
    // subscription.  Without this the spinner could re-appear after cancel
    // if a stray progress message arrived.
    setExecuting(false);
    setExecutionId(null);
    setProgressLog('');
    setAgentSuggestion(null);
  }, [executionId]);

  // ── Execute query ───────────────────────────────────────────────
  // BF-418 — accept an optional ``cacheStrategy`` argument.  Default
  // 'auto' preserves all existing call sites (Run button, retry hooks,
  // etc.).  The Run fresh button passes 'bypass' so the engine skips
  // ``maybe_serve_from_cache`` for this call — closes the gap where a
  // failed invalidate request would let the user see the stale cached
  // result thinking it was fresh.
  // Round 12 (2026-06-02): proactive Validate & Fix.  Calls
  // /api/sql/auto-fix on the current sqlText, applies the result to
  // the editor, and surfaces a banner the user can dismiss or undo.
  // Reactive flow (run → fail → fix banner) still works; this just
  // lets users catch fixable issues BEFORE paying execution cost.
  const handleValidateAndFix = useCallback(async () => {
    const sql = sqlText.trim();
    if (!sql) {
      setValidateResult({ kind: 'error', message: 'SQL editor is empty' });
      return;
    }
    // Round 13 deep-audit fix — stale-response race.  If user edits SQL
    // while validate is in flight, the late response can overwrite the
    // newer text with a fix derived from stale input.  Capture the SQL
    // we sent + the editor text we last saw; compare before applying.
    const _sent_sql = sqlText;
    setValidating(true);
    setValidateResult(null);
    try {
      const fix: any = await api.sqlAutoFix({
        raw_sql: sql,
        connection_id: selectedConnId ?? undefined,
      });
      // Stale-check: if the editor text has CHANGED since we fired the
      // request, refuse to overwrite the user's newer SQL.  Show a
      // friendly message so they know to re-validate.
      if (sqlText !== _sent_sql) {
        setValidateResult({
          kind: 'error',
          message: 'SQL changed during validation — re-run Validate & Fix on the new text.',
        });
        return;
      }
      if (fix?.fixed && fix.fixed_sql) {
        const original = sqlText;
        setSqlText(fix.fixed_sql);
        setValidateResult({
          kind: 'fixed',
          message: fix.explanation || 'Applied auto-fix',
          applied_fixes: fix.applied_fixes,
          original_sql: original,
          column_issues: fix.column_issues,
        });
      } else {
        // ``fixed: false`` is a clean SQL (no fix needed) OR an unknown
        // error path the backend recognised but can't auto-fix.  Reflect
        // the backend's explanation either way.
        const _msg = fix?.explanation || '';
        const _has_col_issues = Array.isArray(fix?.column_issues) && fix.column_issues.length > 0;
        const _looks_clean = !_has_col_issues && (
          !_msg || /no.*issues|no.*fix|already|looks?\s+valid/i.test(_msg)
        );
        setValidateResult({
          kind: _looks_clean ? 'clean' : (_has_col_issues ? 'error' : 'error'),
          message: _looks_clean
            ? 'SQL looks valid — no auto-fixable issues found.'
            : _msg || (_has_col_issues
                ? `Found ${fix.column_issues.length} column issue${fix.column_issues.length > 1 ? 's' : ''}`
                : 'Could not auto-fix'),
          column_issues: fix?.column_issues,
        });
      }
    } catch (err: any) {
      setValidateResult({
        kind: 'error',
        message: err?.message || 'Validate & Fix call failed',
      });
    } finally {
      setValidating(false);
    }
  }, [sqlText, selectedConnId]);

  const executeQuery = useCallback(async (cacheStrategy: 'auto' | 'bypass' | 'refresh' = 'auto') => {
    const sql = sqlText.trim();
    if (!selectedConnId) { setError('Select a connection first'); return; }
    if (!sql) { setError('SQL editor is empty'); return; }

    // BF-261: cancel the previous execution if one is still running.  Without
    // this, the user log shows old queries still alive at heartbeat #69
    // (1000+ s elapsed) hogging worker slots while new queries are submitted.
    // Fire-and-forget — backend handles the cancel; we don't await it so the
    // new query starts immediately.
    if (executionId && executing) {
      api.cancelExecution(executionId).catch(() => { /* fail-open */ });
    }

    // ── Phase 142: Streaming-only path ──────────────────────────────────
    // When enableStreaming is on, the connection is S3, and the user has
    // NOT requested the background download, mount the grid in streaming
    // mode and skip the normal /api/execute path entirely.  Rows arrive
    // as the engine reads them from S3 — first paint is sub-second on
    // wide tables instead of waiting for the full result.
    const selectedConn = connections.find(c => c.id === selectedConnId);
    const isS3Conn = selectedConn?.connection_type === 's3';
    const isCrossConn = showCrossConn && !!crossConnId;
    const streamOnly = enableStreaming && !streamBgDownload && isS3Conn && !isCrossConn;

    if (streamOnly) {
      // Set up streaming source — DataGridViewer reads rows from /api/stream
      // using the rawSql + connectionId.  No execution_id flow.
      setError(null); setSqlError(null); setAgentSuggestion(null);
      setExecutionId(null);
      setStreamingSource({
        connectionId: selectedConnId,
        rawSql: sql,
        columns: Array.from(selectedPhysical),
      });
      setShowResults(true);
      setExecuting(false);
      return;
    }
    // Otherwise clear any prior streaming source so the grid uses
    // executionId-based fetch.
    setStreamingSource(null);

    setExecuting(true); setError(null); setSqlError(null); setExecutionId(null); setAgentSuggestion(null);
    setExecutionBadge(null);   // clear cache/multi-worker badge from previous run
    setMwScanPlan(null);       // SCAN-STRATEGY: clear scan-plan chip for new run
    setPrewarmStage(null);     // Round 9: clear prewarm chip for new run
    setValidateResult(null);   // Round 12: clear stale validate banner
    setMwWorkers({});          // BF-599: clear per-worker grid for new run
    setProgressLog('');
    // BF-266: hide the previous grid before the new run starts so the
    // user sees the loading toolbar instead of stale results.  Will be
    // re-enabled by the WS execution_completed handler.
    setShowResults(false);
    // BF-264: clear lastEstimate so the broad-scan check + chip don't carry
    // numbers from the previous query.  The new estimate (or 'unknown' if it
    // races past 2 s) overwrites it shortly after.
    setLastEstimate(null);
    // anchor for cancellation — the WS handler will reset executing on
    // execution_cancelled (BF-233).
    let _gotExecutionId = false;

    try {
      const queryConfig: any = {
        files: selectedTables.map(t => t.path),
        columns: Array.from(selectedPhysical),
        filters: filters.filter(f => f.value.trim()).map(f => ({
          column: f.physical_name, operator: f.operator, value: f.value,
        })),
        limit: queryLimit, connection_id: selectedConnId,
        column_aliases: Object.fromEntries(
          selectedColumnObjects.map(c => [c.physical_name, toAlias(c.physical_name)])
        ),
      };

      // BF-120: For cross-conn, build primary-only SQL (not the combined display SQL)
      let execSql = sql;
      if (showCrossConn && crossConnId && selectedCrossTables.length > 0) {
        // Rebuild primary-only SQL without connection prefix for backend execution
        const primaryFrom = selectedTables.map(t => sqlTableName(t.path)).join(', ');
        const esc = (v: string) => v.replace(/'/g, "''");
        const activeFilters = filters.filter(f => f.value.trim());
        let where = '';
        if (activeFilters.length > 0) {
          const conds = activeFilters.map(f => {
            const col = qid(f.physical_name);
            const val = esc(f.value.trim());
            switch (f.operator) {
              case 'like': return `${col} LIKE '%${val}%'`;
              case 'in':   return `${col} IN (${val.split(',').map(v => `'${esc(v.trim())}'`).join(', ')})`;
              case 'neq':  return `${col} != '${val}'`;
              case 'gte':  return `${col} >= '${val}'`;
              case 'lte':  return `${col} <= '${val}'`;
              case 'gt':   return `${col} > '${val}'`;
              case 'lt':   return `${col} < '${val}'`;
              default:     return `${col} = '${val}'`;
            }
          });
          const joiner = filterLogic === 'OR' ? '\n  OR ' : '\n  AND ';
          where = `\nWHERE ${conds.join(joiner)}`;
        }
        const distinctKw = distinct ? 'DISTINCT ' : '';
        const colParts = selectedColumnObjects.map(c => {
          const agg = columnAggregations[c.physical_name] || '';
          const transform = columnTransforms[c.physical_name] || '';
          const expr = buildExpr(c.physical_name, agg, transform);
          return `  ${expr} AS ${qid(toAlias(c.physical_name))}`;
        });
        // Include computed columns, CASE expressions, window functions
        computedColumns.forEach(cc => {
          if (cc.expression && cc.alias) colParts.push(`  ${cc.expression} AS ${qid(cc.alias)}`);
        });
        caseExpressions.forEach(ce => {
          const expr = buildCaseExpr(ce);
          if (expr) colParts.push(`  ${expr} AS ${qid(ce.alias)}`);
        });
        windowFunctions.forEach(wf => {
          const expr = buildWindowExpr(wf);
          if (expr) colParts.push(`  ${expr} AS ${qid(wf.alias)}`);
        });
        // GROUP BY — auto: non-aggregated selected columns when any agg active
        const hasAgg = Object.values(columnAggregations).some(a => a);
        let groupBy = '';
        if (hasAgg) {
          const grpCols = selectedColumnObjects.filter(c => !columnAggregations[c.physical_name]).map(c => {
            const t = columnTransforms[c.physical_name] || '';
            return buildExpr(c.physical_name, '', t);
          });
          if (grpCols.length > 0) groupBy = `\nGROUP BY ${grpCols.join(', ')}`;
        }
        // BF-121: Include HAVING clause
        let havingStr = '';
        if (having.length > 0 && groupBy) {
          const havingConds = having.filter((h: any) => h.expression).map((h: any) => h.expression);
          if (havingConds.length > 0) havingStr = `\nHAVING ${havingConds.join(' AND ')}`;
        }
        let orderBy = '';
        if (sortColumns.length > 0) {
          orderBy = `\nORDER BY ${sortColumns.map(s => `${qid(s.column)} ${s.direction}`).join(', ')}`;
        }
        execSql = `SELECT ${distinctKw}\n${colParts.join(',\n')}\nFROM ${primaryFrom}${where}${groupBy}${havingStr}${orderBy}\nLIMIT ${queryLimit};`;
      }

      // Spark Connect routing hint — pre-flight estimate so the backend
      // routing gate sees a real row count.  Without this, BQB queries always
      // route to DuckDB ("below_threshold") even when Spark Connect would be
      // a better fit for >10M-row tables.  Cross-connection queries skip the
      // estimate (always routed to DuckDB anyway).
      // BF-246: race the estimate against a 2s timeout so users on large S3
      // tables don't wait for COUNT(*) to finish before their query starts.
      // The estimate is purely advisory — if it loses the race, the query
      // still runs (just routed to DuckDB by default).
      let _estimatedRows: number | undefined;
      if (!(showCrossConn && crossConnId && selectedCrossTables.length > 0)) {
        try {
          const est = await Promise.race([
            api.estimateQuery(queryConfig as any, selectedConnId),
            new Promise(resolve => setTimeout(() => resolve(null), 2000)),
          ]) as any;
          if (est && typeof est.estimated_rows === 'number') {
            _estimatedRows = est.estimated_rows;
          }
        } catch {
          // Fail-open: estimate is optional. If it fails, the query still runs
          // — it just defaults to DuckDB instead of auto-routing to Spark.
        }
      }
      if (typeof _estimatedRows === 'number' && _estimatedRows >= 0) {
        (queryConfig as any).estimated_rows = _estimatedRows;
        setLastEstimate(_estimatedRows);
      }
      // BF-256: pass per-query engine override to backend
      if (readerOverride !== 'auto') {
        (queryConfig as any).reader_override = readerOverride;
      }
      if (engineOverride !== 'auto') {
        (queryConfig as any).engine_override = engineOverride;
      }

      // BF-247: Broad-scan confirmation — when estimate is large AND no filter
      // references a partition column, ask the user to confirm before scanning.
      if (typeof _estimatedRows === 'number'
          && _estimatedRows >= BROAD_SCAN_THRESHOLD_ROWS
          && partitionColumns.length > 0) {
        const filterCols = new Set(filters.filter(f => f.value.trim()).map(f => f.physical_name));
        const hasPartitionFilter = partitionColumns.some(pc => filterCols.has(pc));
        if (!hasPartitionFilter) {
          const proceed = window.confirm(
            `This query is estimated to scan ~${_estimatedRows.toLocaleString()} rows ` +
            `across all partitions. Add a filter on one of [${partitionColumns.join(', ')}] ` +
            `to scope it.\n\nProceed with full scan?`
          );
          if (!proceed) {
            // BF-264: also clear progressLog + agent suggestion so the
            // toolbar fully resets after Cancel — was leaking stale state.
            setExecuting(false);
            setProgressLog('');
            setAgentSuggestion(null);
            return;
          }
        }
      }

      // BF-428Q — defensive validation of cache_strategy at the payload
      // boundary.  Even if state is somehow corrupted (e.g., a setter
      // accidentally captured an event), we never send a bad value to
      // the backend's strict regex validator.
      const safeCache: 'auto' | 'bypass' | 'refresh' =
        (cacheStrategy === 'auto' || cacheStrategy === 'bypass' ||
         cacheStrategy === 'refresh') ? cacheStrategy : 'auto';
      const payload: any = {
        query_config: queryConfig, connection_id: selectedConnId,
        raw_sql: execSql,
        output_format: 'json', cache_strategy: safeCache,
      };

      if (showCrossConn && crossConnId && selectedCrossTables.length > 0) {
        // BF-121: Validate JOIN key columns before sending
        if (crossConnMode === 'join' && (!crossJoinLeftOn || !crossJoinRightOn)) {
          setSqlError('JOIN mode requires both left and right key columns to be selected.');
          setError('JOIN mode requires both left and right key columns to be selected.');
          return;
        }
        payload.secondary_connection_id = crossConnId;
        payload.secondary_query_config = {
          files: selectedCrossTables.map(t => t.path),
          columns: Array.from(selectedPhysical),
          filters: queryConfig.filters, limit: queryLimit, connection_id: crossConnId,
        };
        payload.secondary_raw_sql = secondaryRawSql;
        payload.combine_mode = crossConnMode;
        if (crossConnMode === 'join' && crossJoinLeftOn && crossJoinRightOn) {
          payload.join_config = {
            how: crossJoinHow,
            left_on: crossJoinLeftOn,
            right_on: crossJoinRightOn,
            suffixes: ['_primary', '_secondary'],
          };
        }
      }

      // BF-418 — propagate cache_strategy so 'bypass' (Run fresh) skips
      // the engine's maybe_serve_from_cache for this single execution.
      // BF-428Q — use the validated `safeCache` instead of raw state.
      if (safeCache && safeCache !== 'auto') {
        (payload as any).cache_strategy = safeCache;
      }
      const response = await api.executeQuery(payload);
      setExecutionId(response.execution_id);
      _gotExecutionId = true;  // WebSocket effect will stop the spinner
      // BF-563 (2026-05-29): consume BF-522 pre_validate_status signal.
      // When the backend's pre-validate timed out, surface a clear
      // banner so the user knows their SQL wasn't binder-checked
      // upfront.  Without this, BF-522 was dead code.
      if (response.pre_validate_status === 'timed_out') {
        setError(
          'Schema validation skipped (cold metadata scan timed out at 5s). ' +
          'Any binder errors in your SQL will appear during execution. ' +
          'Retry once the table metadata is cached.'
        );
      }
      // BF-571 (2026-05-29): surface agent format-string auto-fixes so
      // the user knows what was repaired.  Each entry tells them
      // exactly which specifier was wrong + the DuckDB equivalent
      // we substituted.  Stored as state and rendered as an info
      // Alert above the results — non-blocking (query already ran).
      const _fmtFixes = (response as any).agent_format_fixes || [];
      if (Array.isArray(_fmtFixes) && _fmtFixes.length > 0) {
        setAgentFormatFixes(_fmtFixes);
      } else {
        setAgentFormatFixes([]);
      }
    } catch (err: any) {
      // BF-239: Pre-validation 400 errors carry a structured detail object
      // with an embedded agent_suggestion.  Surface it inline (same UI as
      // post-execution failures) instead of as a raw error string.
      const detail = err?.detail;
      if (detail && typeof detail === 'object' && detail.type === 'sql_pre_validation_failed') {
        const errorMsg = detail.error || 'SQL validation failed';
        setSqlError(errorMsg);
        setError(errorMsg);
        if (detail.agent_suggestion) {
          setAgentSuggestion(detail.agent_suggestion);
        }
      } else if (detail && typeof detail === 'object' && detail.type === 'portal_password_required') {
        // BF-285: backend says we need a fresh AWS portal password
        // (vault is empty / expired).  Open the global password modal
        // and let the user retry.  We dispatch a custom event so the
        // app-level <PortalPasswordModal/> picks it up — keeps this
        // component decoupled from the modal lifecycle.
        //
        // BF-PORTAL-CONN-OVERRIDES: forward the connection_id (echoed
        // back by the 401 detail, with selectedConnId as a fallback)
        // so the modal can pass it to /api/aws-portal/authenticate.
        // Without this the modal "succeeds" against the global portal
        // config, then the next query retry still fails because the
        // CONNECTION uses different portal_base_url/proxy settings —
        // hence the "SSL wrong version number" symptom.
        const reason = detail.message
          || 'AWS credentials need to be refreshed before this query can run.';
        const connectionId = (typeof detail.connection_id === 'number')
          ? detail.connection_id : selectedConnId;
        try {
          window.dispatchEvent(new CustomEvent('portal-password-required', {
            detail: { reason, retry: () => executeQuery(), connection_id: connectionId },
          }));
        } catch { /* CustomEvent unsupported in older browsers — fail-open */ }
        setError('AWS portal password required — please re-enter to continue.');
      } else {
        const msg = err?.detail || err?.message || 'Query execution failed';
        // BF-426: safeStringify here — err can be an axios/fetch error or a
        // SyntheticEvent that carries window references and would otherwise
        // throw "Converting circular structure to JSON" while rendering the
        // user-visible error message.
        const text = typeof msg === 'string' ? msg : safeStringify(msg);
        setSqlError(text);
        setError(text);
      }
    } finally {
      // Only stop spinner here on error — success path waits for WS execution_completed
      if (!_gotExecutionId) setExecuting(false);
    }
  // BF-141: Include having/computedColumns/caseExpressions/windowFunctions to
  // prevent stale closures in cross-connection SQL rebuild
  }, [sqlText, selectedConnId, selectedPhysical, selectedTables, filters,
      selectedColumnObjects, showCrossConn, crossConnId, selectedCrossTables,
      cacheStrategy, queryLimit, crossConnMode, crossJoinHow, crossJoinLeftOn,
      crossJoinRightOn, secondaryRawSql, sqlTableName, distinct, filterLogic,
      columnAggregations, columnTransforms, sortColumns,
      having, computedColumns, caseExpressions, windowFunctions,
      // BF-264: include engineOverride so toggling it before Run actually
      // sends the new value (was a stale-closure bug — old override leaked).
      engineOverride, readerOverride, partitionColumns, executing, executionId,
      // Phase 142: streaming controls — connections list needed to detect S3
      connections, enableStreaming, streamBgDownload]);

  // ── Grid column metadata: map physical names → readable aliases ──────────────
  // Passed to DataGridViewer so headers show friendly names regardless of which
  // backend execution path ran (raw_sql alias path OR query_config column_aliases path).
  const bqbColumnMetadata = useMemo(() =>
    Object.fromEntries(
      selectedColumnObjects.map(c => [c.physical_name, { friendly_name: toAlias(c.physical_name) }])
    ),
    [selectedColumnObjects]
  );

  // ── Save/Load/Publish helpers ─────────────────────────────────
  const buildQueryConfig = useCallback(() => ({
    files: selectedTables.map(t => t.path),
    columns: Array.from(selectedPhysical),
    filters: filters.filter(f => f.value.trim()).map(f => ({
      column: f.physical_name, operator: f.operator, value: f.value,
    })),
    limit: queryLimit, connection_id: selectedConnId,
    raw_sql: sqlText.trim(),
    column_aliases: Object.fromEntries(
      selectedColumnObjects.map(c => [c.physical_name, toAlias(c.physical_name)])
    ),
  }), [selectedTables, selectedPhysical, filters, selectedConnId, sqlText, selectedColumnObjects, queryLimit]);

  const handleSaved = useCallback((id: number, name: string) => {
    setSavedQueryId(id); setSavedQueryName(name); setShowSaveDialog(false);
    // BF-496 — if Publish was clicked on an unsaved query, open the
    // Publish dialog immediately after the save completes so the user
    // doesn't have to click Publish a second time.
    if (publishAfterSave) {
      setPublishAfterSave(false);
      setPublishDialogOpen(true);
    }
  }, [publishAfterSave]);

  const handleLoadSqlFile = useCallback(async (fileId: number) => {
    try {
      const file = await api.sqlFiles.get(fileId);
      if (file?.content != null) {
        setSqlText(file.content);
        setSavedQueryName(file.name || '');
        // Remember which .sql file is currently loaded so Publish + Feed
        // know what to publish/feed-generate from.
        setLoadedSqlFileId(fileId);
      }
      if (file?.connection_id) setSelectedConnId(file.connection_id);
      // BF-143: Restore cross-connection metadata from saved .sql file
      if (file?.secondary_connection_id) {
        setCrossConnId(file.secondary_connection_id);
        setShowCrossConn(true);
        if (file.combine_mode) setCrossConnMode(file.combine_mode as any);
        if (file.join_config) {
          const jc = file.join_config as { how?: string; left_on?: string; right_on?: string };
          setCrossJoinHow(jc.how || 'inner');
          if (jc.left_on) setCrossJoinLeftOn(jc.left_on);
          if (jc.right_on) setCrossJoinRightOn(jc.right_on);
        }
        if (file.secondary_content) setSecondaryRawSql(file.secondary_content);
      } else {
        // Clear stale cross-conn state when loading a non-cross-connection file
        setShowCrossConn(false);
        setCrossConnId(null);
        setSecondaryRawSql('');
      }
      setLoadDialogOpen(false);
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to load SQL file');
    }
  }, []);

  const openLoadDialog = useCallback(async () => {
    // Phase 134-N — fetch BOTH lists in parallel.  Pre-fix only the
    // sql_files table was queried, so anything saved via the "Save
    // query" path (which writes to the saved_queries table) was
    // invisible in the load dialog.  The dialog tabs let the user pick
    // which surface; we don't filter saved queries by connection_id
    // because the saved-query model carries the connection inside its
    // query_config — switching to a different connection on load is
    // fine and matches what handleLoadSqlFile already does.
    try {
      const [files, queries] = await Promise.all([
        api.sqlFiles.list({
          connection_id: selectedConnId || undefined,
          limit: 50,
        }).catch(() => []),
        api.listQueries(true).catch(() => []),
      ]);
      setSavedQueries(Array.isArray(files) ? files : []);
      setSavedQueryList(Array.isArray(queries) ? queries : []);
      // Default to whichever surface has at least one entry; if both
      // do, prefer "Saved Queries" (the surface that was previously
      // invisible — likely what the user was looking for).
      setLoadDialogTab(
        (Array.isArray(queries) && queries.length > 0) ? 'queries' : 'files',
      );
      setLoadDialogOpen(true);
    } catch {
      setError('Failed to load saved queries / SQL files');
    }
  }, [selectedConnId]);

  // Phase 134-N — Load a saved query (from the saved_queries table)
  // into the BQB editor.  Mirrors handleLoadSqlFile's contract for
  // raw_sql / connection_id / cross-connection restoration; visual
  // state (selected tables, filters, joins) restoration is deferred
  // because it requires applying every query_config field to the
  // matching BQB setState — that's a separate phase of work.  For now,
  // we set raw_sql + savedQueryId + name so the editor opens with the
  // SQL the user expects, and republish / re-save flows know which
  // saved-query row to update.
  const handleLoadSavedQuery = useCallback(async (id: number) => {
    try {
      const sq: any = await api.getSavedQuery(String(id));
      if (!sq) {
        setError('Saved query not found (it may have been deleted)');
        return;
      }
      const qc = sq.query_config || {};
      // SQL is in raw_sql for SQL-mode saved queries; for visual
      // queries the backend stores the structured config — we surface
      // whichever raw SQL field is present.  No SQL ⇒ inform the user
      // so they can open the saved query via the Saved Queries page
      // (which routes through the appropriate visual builder).
      const sql = qc.raw_sql || qc.custom_sql || '';
      if (!sql.trim()) {
        setError(
          `"${sq.name || '(unnamed)'}" is a visual saved query — open it from the ` +
          `Saved Queries page to restore the visual builder state.`,
        );
        return;
      }
      setSqlText(sql);
      setSavedQueryId(sq.id);
      setSavedQueryName(sq.name || '');
      // Clear loaded-sql-file so publish/feed actions route through the
      // saved_query path (NOT sql_file).
      setLoadedSqlFileId(null);
      if (qc.connection_id) setSelectedConnId(qc.connection_id);
      // Restore cross-connection metadata if present (mirrors sql_file
      // load contract from BF-143).
      if (qc.secondary_connection_id) {
        setCrossConnId(qc.secondary_connection_id);
        setShowCrossConn(true);
        if (qc.combine_mode) setCrossConnMode(qc.combine_mode as any);
        if (qc.join_config) {
          const jc = qc.join_config as { how?: string; left_on?: string; right_on?: string };
          setCrossJoinHow(jc.how || 'inner');
          if (jc.left_on) setCrossJoinLeftOn(jc.left_on);
          if (jc.right_on) setCrossJoinRightOn(jc.right_on);
        }
        if (qc.secondary_raw_sql) setSecondaryRawSql(qc.secondary_raw_sql);
      } else {
        setShowCrossConn(false);
        setCrossConnId(null);
        setSecondaryRawSql('');
      }
      setLoadDialogOpen(false);
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to load saved query');
    }
  }, []);

  // ── Connection change handler (resets all state) ───────────────
  const handleConnChange = useCallback((id: number | null) => {
    setSelectedConnId(id);
    setSelectedTables([]); setMappedColumns([]); setSelectedPhysical(new Set());
    setFilters([]); setExecutionId(null); setTableSearch('');
    setColumnAggregations({}); setColumnTransforms({});
    setSortColumns([]); setJoinConfig(null); setColumnCache({});
    setMaterializedViews([]); setFederationViews([]); setIcebergTables([]);
    setTableFavorites(new Set()); setTableTypeFilter('all');
    setHaving([]); setComputedColumns([]); setCaseExpressions([]);
    setWindowFunctions([]); setDistinct(false); setFilterLogic('AND');
    // BF-121: Reset cross-connection state
    setShowCrossConn(false); setCrossConnId(null);
    setCrossTables([]); setSelectedCrossTables([]);
    setCrossConnMode('union'); setCrossJoinHow('inner');
    setCrossJoinLeftOn(''); setCrossJoinRightOn('');
    setSecondaryRawSql('');
    // BQB-FIX: explicitly clear the SQL editor on connection switch.
    // useServerDraft's key changes via selectedConnId so it WILL load
    // the new key's draft (or 404 → fallback), but clearing now also
    // resets ``lastAutoGenSqlRef`` so the autogen pipeline can rebuild
    // SQL from scratch for the new connection — without this, the
    // previous connection's SELECT * FROM "<old_parquet>" sits in the
    // editor until the user explicitly retypes it.
    setSqlText('');
    lastAutoGenSqlRef.current = '';
    manuallyEditedRef.current = false;
    // BQB-DRAFT-PRESERVE: also reset the marker so the new connection's
    // draft (if any) gets re-promoted to "manually edited" when it loads.
    sqlMarkedRef.current = false;
    // Drop the loaded .sql file reference: switching connection means
    // the file's bound connection_id no longer matches this builder's
    // context, so Publish + Feed actions should disable until the user
    // saves or loads against the new connection.
    setLoadedSqlFileId(null);
    // BF-264: explicitly reset partition state.  Without this, switching
    // connections leaves stale partition values + columns in dropdowns
    // (the recompute effect runs on selectedTables=[]→returns early, so
    // old state never gets cleared).  Also reset estimate + progress so
    // the toolbar doesn't carry over the previous query's numbers.
    setPartitionColumns([]); setPartitionValues({}); setPartitionData({});
    setLastEstimate(null); setProgressLog('');
    setError(null); setSqlError(null); setAgentSuggestion(null);
    setShowResults(false);  // BF-266: hide previous grid on connection switch
  }, []);

  // ── Cross-table toggle ─────────────────────────────────────────
  const toggleCrossTable = useCallback((t: TableOption) => {
    setSelectedCrossTables(prev => {
      const exists = prev.some(x => x.path === t.path);
      if (exists) return prev.filter(x => x.path !== t.path);
      return [...prev, t];
    });
  }, []);

  // ── Template selection ───────────────────────────────────────
  const handleTemplateSelect = useCallback((template: any) => {
    // Replace the SQL text with the template skeleton
    if (template.sqlTemplate) {
      const tableName = selectedTables.length > 0 ? sqlTableName(selectedTables[0].path) : '{table}';
      let sql = template.sqlTemplate.replace(/\{table\}/g, tableName);
      // Replace placeholders with first matching column by type
      const measures = selectedColumnObjects.filter(c => c.column_type === 'measure');
      const dates = selectedColumnObjects.filter(c => c.data_type === 'date');
      const dims = selectedColumnObjects.filter(c => c.column_type === 'dimension' && c.data_type !== 'date');
      if (measures[0]) sql = sql.replace(/\{measure\}/g, qid(measures[0].physical_name));
      if (dates[0]) sql = sql.replace(/\{date_col\}/g, qid(dates[0].physical_name));
      if (dims[0]) {
        sql = sql.replace(/\{dimension\}/g, qid(dims[0].physical_name));
        sql = sql.replace(/\{dimensions\}/g, dims.slice(0, 3).map(d => qid(d.physical_name)).join(', '));
        sql = sql.replace(/\{id_col\}/g, qid(dims[0].physical_name));
      }
      sql = sql.replace(/\{N\}/g, String(queryLimit));
      sql = sql.replace(/\{current_start\}/g, "'2024-01-01'");
      setSqlText(sql);
    }
  }, [selectedTables, selectedColumnObjects, sqlTableName, queryLimit]);

  // ── Cross-connection change ────────────────────────────────────
  const handleCrossConnChange = useCallback((id: number | null) => {
    setCrossConnId(id);
    setSelectedCrossTables([]);
  }, []);

  // ══ Stable memoized props ─────────────────────────────────────
  // All inline .map() / Object.fromEntries() moved here so child components
  // (React.memo'd or not) receive stable references and skip unnecessary renders.

  /** Physical column names of currently-selected columns (for JOIN autocomplete) */
  const allColumnNames = useMemo(
    () => selectedColumnObjects.map(c => c.physical_name),
    [selectedColumnObjects]
  );

  /** SQL editor schema: table display name → column name list (for CodeMirror autocomplete) */
  const schemaForSql = useMemo(() =>
    Object.fromEntries(
      selectedTables.map(t => {
        const name = t.path.startsWith('__registered__:') ? t.path.slice(15)
          : t.path.startsWith('__local__:') ? t.path.slice(10)
          : t.path.split('/').pop()?.replace('.parquet', '') || t.path;
        return [name, mappedColumns.filter(c => c.source_table === t.path).map(c => c.physical_name)];
      })
    ),
    [selectedTables, mappedColumns]
  );

  /** Table list shape used by all four advanced SQL modals */
  const modalTableList = useMemo(
    () => selectedTables.map(t => ({ name: t.name, path: t.path })),
    [selectedTables]
  );

  /** Column schema used by all four advanced SQL modals */
  const modalSchemas = useMemo(() =>
    Object.fromEntries(selectedTables.map(t => [
      t.path,
      mappedColumns.filter(c => c.source_table === t.path).map(c => ({
        name: c.physical_name, type: c.data_type,
      })),
    ])),
    [selectedTables, mappedColumns]
  );

  /** Active aggregations for the HAVING modal */
  const havingAggregations = useMemo(
    () => selectedColumnObjects
      .filter(c => columnAggregations[c.physical_name])
      .map(c => ({ column: c.physical_name, function: columnAggregations[c.physical_name] })),
    [selectedColumnObjects, columnAggregations]
  );

  /** mappedColumns pre-sorted: partition cols first, then alphabetical.
   *  Passed to ConditionsBar so chip dropdowns surface partition cols first. */
  const sortedMappedColumns = useMemo(() =>
    [...mappedColumns].sort((a, b) => {
      if (a.is_partition !== b.is_partition) return a.is_partition ? -1 : 1;
      return (a.friendly_name || a.physical_name).localeCompare(b.friendly_name || b.physical_name);
    }),
    [mappedColumns]
  );

  // ══ Stable callbacks for child components ─────────────────────
  // Inline lambdas in JSX create a new function ref on every render, bypassing
  // React.memo on children. Extracted here with [] deps so refs never change.
  const handleSave            = useCallback(() => setShowSaveDialog(true), []);
  // BF-271: Save raw SQL as a .sql file (matches CQB's "Save .sql" button).
  // The existing "Save" button writes to the queries table — that's what
  // Publish uses, but the Load dialog reads from sql_files.  Without this
  // button, BQB users could not round-trip a query through Save → Load.
  const handleSaveSqlFile     = useCallback(async () => {
    const sql = (sqlText || '').trim();
    if (!sql) { setError('SQL editor is empty'); return; }
    if (!selectedConnId) { setError('Select a connection first'); return; }
    const name = window.prompt('SQL file name:', `${savedQueryName || 'query'}.sql`);
    if (!name) return;
    try {
      const payload: any = { name: name.trim(), sql, connection_id: selectedConnId };
      // Mirror CQB's Phase 124-D cross-connection metadata so BQB-saved
      // .sql files round-trip cleanly through the Load dialog.
      if (showCrossConn && crossConnId) {
        payload.secondary_connection_id = crossConnId;
        payload.secondary_sql           = secondaryRawSql || undefined;
        payload.combine_mode            = crossConnMode;
        if (crossConnMode === 'join' && crossJoinLeftOn.length > 0) {
          payload.join_config = {
            how:      crossJoinHow,
            left_on:  crossJoinLeftOn,
            right_on: crossJoinRightOn,
          };
        }
      }
      const created = await api.sqlFiles.create(payload);
      if (created && (created as any).id) {
        // Remember the id so the Publish + Create-Feed menu items can
        // target this .sql file even before the user reloads it.
        setLoadedSqlFileId((created as any).id);
      }
      setError(null);
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to save .sql file');
    }
  }, [sqlText, selectedConnId, savedQueryName, showCrossConn, crossConnId,
      secondaryRawSql, crossConnMode, crossJoinLeftOn, crossJoinHow, crossJoinRightOn]);
  const handlePublish         = useCallback(() => {
    // BF-496 — Publish snapshots query_config from a saved row.  If the
    // user hasn't saved yet (and isn't editing a loaded .sql file),
    // route them through Save FIRST then auto-open Publish.  This
    // closes the "ad-hoc cross-conn BQB publish" gap — cross-conn
    // queries get their secondary_connection_id snapshotted into
    // query_config on save, so the resulting PV correctly routes
    // through the federation engine on consume.
    if (!savedQueryId && !loadedSqlFileId) {
      setPublishAfterSave(true);
      setShowSaveDialog(true);
      return;
    }
    setPublishDialogOpen(true);
  }, [savedQueryId, loadedSqlFileId]);
  /** Open FeedConfigs page with the current source pre-filled.  Source
   * priority: saved query first (richer metadata), then loaded .sql
   * file.  Both are valid feed sources; whichever the user has
   * "primary" wins.  No-op when neither exists (the Save menu's
   * disabled gate prevents reaching this in normal use anyway). */
  const handleCreateFeed = useCallback(() => {
    const params = new URLSearchParams();
    if (savedQueryId) {
      params.set('source_type', 'saved_query');
      params.set('source_id', String(savedQueryId));
      if (savedQueryName) params.set('name', savedQueryName);
    } else if (loadedSqlFileId) {
      params.set('source_type', 'sql_file');
      params.set('source_id', String(loadedSqlFileId));
    } else {
      return;
    }
    window.location.href = `/feeds?${params.toString()}`;
  }, [savedQueryId, savedQueryName, loadedSqlFileId]);
  const handleClearSaved      = useCallback(() => {
    setSavedQueryId(null);
    setSavedQueryName('');
    setLoadedSqlFileId(null);
  }, []);
  const handleCacheChange     = useCallback((v: string) => setCacheStrategy(v as 'auto' | 'bypass' | 'refresh'), []);
  const handleOpenTemplates   = useCallback(() => setShowTemplates(true), []);
  const handleOpenHaving      = useCallback(() => setShowHavingModal(true), []);
  const handleOpenComputed    = useCallback(() => setShowComputedModal(true), []);
  const handleOpenCase        = useCallback(() => setShowCaseModal(true), []);
  const handleOpenWindow      = useCallback(() => setShowWindowModal(true), []);
  const handleCloseHaving     = useCallback(() => setShowHavingModal(false), []);
  const handleCloseComputed   = useCallback(() => setShowComputedModal(false), []);
  const handleCloseCase       = useCallback(() => setShowCaseModal(false), []);
  const handleCloseWindow     = useCallback(() => setShowWindowModal(false), []);
  const handleCloseTemplates  = useCallback(() => setShowTemplates(false), []);
  const handlePanelToggle     = useCallback(() => setPanelOpen(prev => !prev), []);
  const handleToggleCrossConn = useCallback(() => setShowCrossConn(prev => !prev), []);
  const handleAggChange       = useCallback((col: string, val: string) =>
    setColumnAggregations(prev => ({ ...prev, [col]: val })), []);
  const handleTransformChange = useCallback((col: string, val: string) =>
    setColumnTransforms(prev => ({ ...prev, [col]: val })), []);
  const handleSortRemove      = useCallback((idx: number) =>
    setSortColumns(prev => prev.filter((_, i) => i !== idx)), []);
  const handleSortChange      = useCallback((idx: number, field: string, value: string) =>
    setSortColumns(prev => prev.map((x, i) => i === idx ? { ...x, [field]: value } : x)), []);

  // ── Render ──────────────────────────────────────────────────────
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* ── Top Toolbar ──────────────────────────────────────────── */}
      <QueryToolbar
        connections={connections}
        selectedConnId={selectedConnId}
        onConnChange={handleConnChange}
        executing={executing}
        sqlText={sqlText}
        onExecute={executeQuery}
        onSave={handleSave}
        onSaveSqlFile={handleSaveSqlFile}
        onLoad={openLoadDialog}
        onPublish={handlePublish}
        onCreateFeed={handleCreateFeed}
        loadedSqlFileId={loadedSqlFileId}
        savedQueryId={savedQueryId}
        savedQueryName={savedQueryName}
        onClearSaved={handleClearSaved}
        cacheStrategy={cacheStrategy}
        onCacheChange={handleCacheChange}
        queryLimit={queryLimit}
        onLimitChange={setQueryLimit}
        onOpenTemplates={handleOpenTemplates}
        distinct={distinct}
        onDistinctChange={setDistinct}
        onOpenHaving={handleOpenHaving}
        onOpenComputed={handleOpenComputed}
        onOpenCase={handleOpenCase}
        onOpenWindow={handleOpenWindow}
        havingCount={having.length}
        computedCount={computedColumns.length}
        caseCount={caseExpressions.length}
        windowCount={windowFunctions.length}
        onCancel={cancelQuery}
        onExplain={() => setExplainOpen(true)}
        onValidateAndFix={handleValidateAndFix}
        validating={validating}
        streamingSupported={connections.find(c => c.id === selectedConnId)?.connection_type === 's3'}
        enableStreaming={enableStreaming}
        onEnableStreamingChange={setEnableStreaming}
        streamBgDownload={streamBgDownload}
        onStreamBgDownloadChange={setStreamBgDownload}
        costEstimate={costEstimate}
        estimating={estimating}
      />

      {/* ── Main content area ──────────────────────────────────────── */}
      <Box sx={{ display: 'flex', flexGrow: 1, overflow: 'hidden', mt: 0.5, gap: 0.5 }}>

        {/* ── Left Panel: Unified Object Tree ────────────────────── */}
        <TableTree
          tables={tables}
          selectedTables={selectedTables}
          onToggleTable={toggleTable}
          tableSearch={tableSearch}
          onTableSearchChange={setTableSearch}
          selectedConnId={selectedConnId}
          connName={connName}
          loadingColumns={loadingColumns}
          columnsByTable={columnsByTable}
          selectedPhysical={selectedPhysical}
          onToggleColumn={toggleColumn}
          onToggleCategory={toggleCategory}
          columnAggregations={columnAggregations}
          onAggChange={handleAggChange}
          columnTransforms={columnTransforms}
          onTransformChange={handleTransformChange}
          panelOpen={panelOpen}
          onPanelToggle={handlePanelToggle}
          showCrossConn={showCrossConn}
          onToggleCrossConn={handleToggleCrossConn}
          crossConnId={crossConnId}
          onCrossConnChange={handleCrossConnChange}
          connections={connections}
          crossTables={crossTables}
          selectedCrossTables={selectedCrossTables}
          onToggleCrossTable={toggleCrossTable}
          filteredTables={filteredTables}
          filteredCrossTables={filteredCrossTables}
          crossConnMode={crossConnMode}
          onCrossConnModeChange={setCrossConnMode}
          crossJoinHow={crossJoinHow}
          onCrossJoinHowChange={setCrossJoinHow}
          crossJoinLeftOn={crossJoinLeftOn}
          crossJoinRightOn={crossJoinRightOn}
          onCrossJoinLeftOnChange={setCrossJoinLeftOn}
          onCrossJoinRightOnChange={setCrossJoinRightOn}
          allColumnNames={allColumnNames}
          tableTypeFilter={tableTypeFilter}
          onTypeFilterChange={setTableTypeFilter}
          tableFavorites={tableFavorites}
          frequentColumns={frequentColumns}
          onRefreshSchema={handleRefreshSchema}
        />

        {/* ── Right Panel: SQL Editor + Filters + Results ──────────── */}
        <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', gap: 0.5 }}>

          {/* Re-open the Objects panel (only shown when collapsed).  Gives the
              user a one-click way back without leaving a 36px stub eating
              result-grid real estate. */}
          {!panelOpen && (
            <Box sx={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 0.5, px: 0.5, py: 0.25 }}>
              <Tooltip title="Show Objects panel">
                <IconButton size="small" onClick={handlePanelToggle} sx={{ border: '1px solid', borderColor: 'divider', p: 0.5 }} aria-label="Show Objects panel">
                  <ChevronRightIcon fontSize="small" />
                </IconButton>
              </Tooltip>
              <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.7rem' }}>
                Objects panel hidden — click to expand
              </Typography>
            </Box>
          )}

          {/* Join Banner */}
          {joinConfig && selectedTables.length >= 2 && (
            <JoinBanner
              joinConfig={joinConfig}
              onJoinConfigChange={setJoinConfig}
              mappedColumns={mappedColumns}
              displayTableName={displayTableName}
            />
          )}

          {/* Partition pruning hint row — shown only when partition columns are available */}
          {partitionColumns.length > 0 && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, px: 0.5, flexWrap: 'wrap' }}>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.7rem', whiteSpace: 'nowrap' }}>
                Partition cols:
              </Typography>
              {partitionColumns.map((col: string) => (
                <Chip
                  key={col}
                  label={col}
                  size="small"
                  clickable
                  onClick={() => {
                    setSqlText((prev: string) => insertPartitionWhere(prev, col));
                  }}
                  sx={{ height: 18, fontSize: 10, fontFamily: 'monospace', cursor: 'pointer' }}
                />
              ))}
              <Tooltip title="Partition pruning guide">
                <IconButton
                  size="small"
                  onClick={(e) => setPruningHelpAnchor(e.currentTarget)}
                  sx={{ ml: 'auto', color: 'primary.main', p: 0.25 }}
                >
                  <HelpOutlineIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Tooltip>
            </Box>
          )}

          <Popover
            open={Boolean(pruningHelpAnchor)}
            anchorEl={pruningHelpAnchor}
            onClose={() => setPruningHelpAnchor(null)}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            PaperProps={{ sx: { p: 2, maxWidth: 380, borderRadius: 2, boxShadow: 4 } }}
          >
            <Typography variant="subtitle2" fontWeight={700} gutterBottom>
              ⚡ Partition Pruning Guide
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5, fontSize: '0.78rem' }}>
              Add <code>WHERE</code> filters on partition columns to read only matching S3 files.
              Without these filters every file is scanned — even if you need just 1 day's data.
            </Typography>
            {partitionColumns.length > 0 && (
              <>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                  Click a column to insert a WHERE filter into the SQL editor:
                </Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 1 }}>
                  {partitionColumns.map((col: string) => (
                    <Chip
                      key={col}
                      label={col}
                      size="small"
                      clickable
                      onClick={() => {
                        setSqlText((prev: string) => insertPartitionWhere(prev, col));
                        setPruningHelpAnchor(null);
                      }}
                      sx={{ height: 20, fontSize: 10, fontFamily: 'monospace',
                            bgcolor: 'primary.50', cursor: 'pointer',
                            '&:hover': { bgcolor: 'primary.100' } }}
                    />
                  ))}
                </Box>
              </>
            )}
            <Divider sx={{ my: 1 }} />
            <Typography variant="caption" color="text.secondary">
              Example: <code>WHERE business_close_date = '2025-09-30'</code> reduces 645 files to ~1.
            </Typography>
          </Popover>

          {/* SQL Editor */}
          <Paper elevation={0} sx={{
            flexShrink: 0,
            display: 'flex', flexDirection: 'column', overflow: 'hidden',
            border: '1px solid', borderColor: sqlError ? 'error.main' : 'divider',
          }}>
            <SqlPreviewPanel
              sql={sqlText}
              onChange={val => {
                // BQB-FIX: user typed → mark as manual so autogen won't
                // clobber.  Autogen-driven `setSqlText` calls (and the
                // server-draft hydration path) don't go through this
                // onChange, so the flag stays false until the user
                // actually types in the editor.
                manuallyEditedRef.current = true;
                setSqlText(val);
                setSqlError(null);
              }}
              onCopy={() => { navigator.clipboard.writeText(sqlText); }}
              error={sqlError}
              placeholder="Select columns from the left panel, or type SQL directly..."
              schema={schemaForSql}
            />
          </Paper>

          {/* BF-254: COUNT(DISTINCT) is hash-table-bound — for 100M+ row scans
              it's the slowest aggregation in DuckDB.  Suggest the HLL variant
              one-click rewrite when the user types it; same answer ±1%, 10-100x
              faster.  Hidden when the SQL already uses APPROX_COUNT_DISTINCT
              or has no COUNT(DISTINCT) at all. */}
          {(() => {
            // BF-264: strip line comments + block comments + single-quoted
            // string literals before pattern-matching, so the suggestion
            // doesn't fire on `-- count(distinct ...)` inside a comment or
            // `'count(distinct ...'` inside a string literal.
            const _stripped = sqlText
              .replace(/--[^\n]*/g, '')             // line comments
              .replace(/\/\*[\s\S]*?\*\//g, '')     // block comments
              .replace(/'(?:[^'\\]|\\.)*'/g, "''"); // string literals
            const m = /count\s*\(\s*distinct\s+([a-zA-Z_][\w."]*)\s*\)/i.exec(_stripped);
            if (!m || /approx_count_distinct/i.test(_stripped)) return null;
            const colExpr = m[1];
            const replaceFn = () => {
              const rewritten = sqlText.replace(
                /count\s*\(\s*distinct\s+([a-zA-Z_][\w."]*)\s*\)/gi,
                (_full, c) => `approx_count_distinct(${c})`
              );
              setSqlText(rewritten);
            };
            return (
              <Alert
                severity="info"
                sx={{ flexShrink: 0, py: 0, fontSize: '0.75rem' }}
                action={
                  <Button size="small" color="inherit" onClick={replaceFn}>
                    Use APPROX_COUNT_DISTINCT
                  </Button>
                }
              >
                <strong>COUNT(DISTINCT {colExpr})</strong> is the slowest aggregation on
                large scans (one hash entry per distinct value). Replacing it with{' '}
                <strong>approx_count_distinct</strong> uses HyperLogLog — same answer ±1 %,
                10-100× faster on 100 M+ row tables.
              </Alert>
            );
          })()}

          {/* BF-417 — Cache visibility banner.  Renders only when the
              backend reports a cached result for the current SQL +
              file set.  "Use cached" is the default Run behaviour;
              "Run fresh" invalidates the cache key first so the next
              execution re-populates with new data. */}
          {cacheStatus && cacheStatus.cached && !executing && (
            <Alert
              severity="success"
              icon={<span aria-hidden>⚡</span>}
              sx={{ flexShrink: 0, py: 0, fontSize: '0.78rem' }}
              action={
                <Box sx={{ display: 'flex', gap: 0.5 }}>
                  <Button
                    size="small"
                    color="inherit"
                    variant="outlined"
                    onClick={() => executeQuery()}
                    title="Re-run the query and serve the cached result (no S3 round-trip)"
                  >
                    Use cached
                  </Button>
                  <Button
                    size="small"
                    color="inherit"
                    variant="outlined"
                    onClick={async () => {
                      // BF-417 — drop the cache entry then run.  The
                      // engine's existing maybe_store_in_cache hook
                      // re-populates with the fresh result automatically.
                      // BF-418 — even if the invalidate POST silently
                      // fails (network blip, backend bug), the
                      // executeQuery('bypass') below will still skip
                      // maybe_serve_from_cache and run against source.
                      // Without this, a failed invalidate would let the
                      // user see the stale cached result thinking it
                      // was fresh.
                      try {
                        const filesForCache = selectedTables.map(t => ({ path: t.path }));
                        await (api as any).invalidateCache({
                          raw_sql: sqlText,
                          files: filesForCache,
                          connection_id: selectedConnId,
                        });
                      } catch {
                        // Fail-open: cache_strategy='bypass' below is
                        // the actual guarantee that we don't serve stale.
                      }
                      setCacheStatus(null);  // dismiss the banner
                      executeQuery('bypass');
                    }}
                    title="Drop the cached result, re-run the query against the source, and refresh the cache"
                  >
                    Run fresh
                  </Button>
                </Box>
              }
            >
              <strong>Cached</strong>{' '}
              {cacheStatus.age_human || `${cacheStatus.age_seconds}s ago`}
              {typeof cacheStatus.row_count === 'number' && (
                <> — {cacheStatus.row_count.toLocaleString()} rows</>
              )}
              {typeof cacheStatus.hit_count === 'number' && cacheStatus.hit_count > 0 && (
                <> ({cacheStatus.hit_count} hit{cacheStatus.hit_count !== 1 ? 's' : ''})</>
              )}
            </Alert>
          )}

          {/* Round 12 (2026-06-02): Validate & Fix result banner.
              Shows AFTER user clicks the toolbar button.  Three states:
              clean (info, "no issues"), fixed (success, "Applied N
              fixes" + Undo), error (warning, explanation). */}
          {validateResult && (
            <Box sx={{ flexShrink: 0, mb: 0.5 }}>
              <Alert
                severity={
                  validateResult.kind === 'fixed' ? 'success' :
                  validateResult.kind === 'clean' ? 'info' :
                  'warning'
                }
                onClose={() => setValidateResult(null)}
                action={
                  validateResult.kind === 'fixed' && validateResult.original_sql
                    ? (
                      <Button
                        size="small"
                        color="inherit"
                        onClick={() => {
                          setSqlText(validateResult.original_sql!);
                          setValidateResult(null);
                        }}
                      >
                        Undo
                      </Button>
                    )
                    : null
                }
                sx={{ fontSize: 12, py: 0.5 }}
              >
                <Box>
                  {validateResult.kind === 'fixed' && validateResult.applied_fixes
                    ? `✨ ${validateResult.message} (${validateResult.applied_fixes.join(', ')})`
                    : validateResult.message}
                  {/* Round 14: schema-aware column-existence issues list.
                      Shows table + column + "did you mean…" suggestions. */}
                  {validateResult.column_issues && validateResult.column_issues.length > 0 && (
                    <Box sx={{ mt: 0.75 }}>
                      <Typography variant="caption" component="div" sx={{ fontWeight: 600, mb: 0.25 }}>
                        Column issues:
                      </Typography>
                      {validateResult.column_issues.slice(0, 10).map((issue, i) => (
                        <Typography
                          key={i}
                          variant="caption"
                          component="div"
                          sx={{ display: 'block', fontFamily: 'monospace', fontSize: 11 }}
                        >
                          {issue.kind === 'not_in_table'
                            ? `• ${issue.table}.${issue.column} — not in table`
                            : `• ${issue.column} — not found in any selected table`}
                          {issue.suggestions && issue.suggestions.length > 0 && (
                            <span style={{ color: '#666' }}>
                              {' — did you mean: '}
                              {issue.suggestions.join(', ')}
                              {'?'}
                            </span>
                          )}
                        </Typography>
                      ))}
                      {validateResult.column_issues.length > 10 && (
                        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                          (+{validateResult.column_issues.length - 10} more)
                        </Typography>
                      )}
                    </Box>
                  )}
                </Box>
              </Alert>
            </Box>
          )}

          {/* Phase 136: Inline Self-Healing Agent suggestion (when execution fails) */}
          {agentSuggestion && (
            <Box sx={{ flexShrink: 0 }}>
              <AgentSuggestionInline
                suggestion={agentSuggestion}
                onApply={async (s) => {
                  if (s.strategy === 'retry_with_backoff') {
                    // BF-414 — clear the prior banner+suggestion before retry
                    // so a successful retry doesn't leave stale "failed" UI on
                    // screen and the user can tell something is happening.
                    setAgentSuggestion(null);
                    setError(null);
                    executeQuery();
                  } else if (s.strategy === 'add_group_by'
                          || s.strategy === 'qualify_ambiguous_columns') {
                    // BF-237 / BF-277: backend rewrites the SQL — adds
                    // GROUP BY for missing aggregates, qualifies columns
                    // with table aliases for ambiguous references.  Both
                    // hit the same endpoint; the response says which fix
                    // was applied.
                    try {
                      const fix = await api.sqlAutoFix({
                        raw_sql:       sqlText,
                        connection_id: selectedConnId ?? undefined,
                      });
                      if (fix?.fixed && fix.fixed_sql) {
                        setSqlText(fix.fixed_sql);
                        setAgentSuggestion(null);  // dismiss after applying
                      } else {
                        setError(fix?.explanation || 'Could not auto-fix SQL');
                      }
                    } catch (err: any) {
                      setError(err?.message || 'Auto-fix failed');
                    }
                  } else if (s.strategy === 'add_partition_filter') {
                    // BF-414 — was a silent no-op.  We can't open the
                    // visual filter modal from BQB (SQL-first), so surface
                    // a notification telling the user which partition
                    // columns to add to their WHERE clause.
                    const cols = (s.retry_params?.partition_columns as string[] | undefined)
                              ?? partitionColumns;
                    const hint = cols && cols.length
                      ? `Add a WHERE clause filter on one of: ${cols.join(', ')}`
                      : 'Add a WHERE clause filter on a partition column';
                    setError(hint);
                    setAgentSuggestion(null);
                  } else if (s.strategy === 'refresh_credentials') {
                    // BF-414 — direct the user to the connections page
                    // where they can update the credential.  Connection ID
                    // is already known via selectedConnId.
                    setError(
                      `Connection credentials may be stale. Open the connection's `
                      + `Settings tab (Connections → edit ${selectedConnId ?? ''}) `
                      + `to refresh and re-test.`
                    );
                    setAgentSuggestion(null);
                  } else if (s.strategy === 'refresh_schema') {
                    // BF-414 — was a silent no-op.  Trigger backend schema
                    // cache invalidation by re-running the query (which
                    // hits the auto-retry path that calls _apply_agent_fix
                    // → schema cache delete) and clear UI state.
                    setAgentSuggestion(null);
                    setError(null);
                    executeQuery();
                  } else {
                    // Unknown strategy — at least let the user know nothing
                    // happened instead of pretending we acted.  Also dismiss
                    // the suggestion banner so the same broken click target
                    // doesn't stay on screen alongside the new error toast.
                    setAgentSuggestion(null);
                    setError(`Cannot apply strategy "${s.strategy}" automatically — please retry manually.`);
                  }
                }}
              />
            </Box>
          )}

          {/* Phase 138: Single-row filter+sort chip bar — saves ~50px vs the
              old two stacked Paper sections.  Each chip is clickable for
              inline editing; the partition-pruning hint floats below as a
              one-line Alert when relevant. */}
          <ConditionsBar
            filters={filters}
            onAddFilter={addFilter}
            onRemoveFilter={removeFilter}
            onFilterChange={updateFilter}
            partitionValues={partitionValues}
            partitionColumns={partitionColumns}
            hasPartitionFilter={hasPartitionFilter}
            hasSelectedColumns={selectedPhysical.size > 0}
            filterLogic={filterLogic}
            onFilterLogicChange={setFilterLogic}
            sortColumns={sortColumns}
            onAddSort={addSort}
            onRemoveSort={handleSortRemove}
            onSortChange={handleSortChange}
            mappedColumns={sortedMappedColumns}
          />


          {error && (
            <Alert severity="error" onClose={() => setError(null)} sx={{ flexShrink: 0, py: 0 }}>{error}</Alert>
          )}

          {/* BF-571 (2026-05-29): agent format-string auto-fixes.  Shown
              as info Alert above the results so the user sees exactly
              what was repaired (e.g. MySQL %i → DuckDB %M).  Dismissable;
              clears on next execute. */}
          {agentFormatFixes.length > 0 && (
            <Alert
              severity="info"
              onClose={() => setAgentFormatFixes([])}
              sx={{ flexShrink: 0, py: 0, fontSize: '0.8rem' }}
            >
              <strong>Agent auto-corrected {agentFormatFixes.length} format issue
                {agentFormatFixes.length === 1 ? '' : 's'} in your SQL:</strong>
              {' '}{agentFormatFixes.map((f: any, i: number) => (
                <span key={i}>
                  {i > 0 ? ' · ' : ''}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.original_format}
                  </code>
                  {' → '}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.repaired_format}
                  </code>
                  {f.function_rewritten && <em> (also DATE_FORMAT → STRFTIME)</em>}
                </span>
              ))}
            </Alert>
          )}

          {executing && !error && queuePosition !== null && queuePosition > 0 && (
            /* BF-585: distinct queued chip when waiting in the per-user
               concurrency queue.  Warning severity (yellow) makes it
               visually distinct from the "executing" info chip. */
            <Alert severity="warning" icon={<CircularProgress size={14} color="warning" />} sx={{ flexShrink: 0, py: 0, fontSize: '0.75rem' }}>
              <strong>Queued</strong> — {queuePosition} {queuePosition === 1 ? 'query' : 'queries'} ahead of you.
              Your query will start automatically when a slot frees.
            </Alert>
          )}
          {executing && !error && (queuePosition === null || queuePosition === 0) && (
            <Alert severity="info" icon={<CircularProgress size={14} />} sx={{ flexShrink: 0, py: 0, fontSize: '0.75rem' }}>
              {progressLog || 'Executing query — fetching results from S3...'}
            </Alert>
          )}

          {/* BF-382/383/414 — engine chip is now visible DURING execution too
              (was post-completion only).  Single-worker is rendered explicitly
              so the user can confirm "yes, this is running on 1 worker". */}
          {executionBadge && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 1, py: 0.5, flexShrink: 0 }}>
              {executionBadge.fromCache && (
                <Chip
                  size="small"
                  color="success"
                  label="⚡ Result Cache HIT"
                  title="Served from the result cache (no re-execution)."
                  sx={{ fontSize: 11 }}
                />
              )}
              {executionBadge.fromMultiWorker ? (
                <Chip
                  size="small"
                  color="info"
                  label={
                    `🔀 Multi-worker (${executionBadge.workerCount || '?'} workers` +
                    (executionBadge.mergeStrategy ? `, ${executionBadge.mergeStrategy})` : ')')
                  }
                  title="Query was split across N parallel DuckDB workers."
                  sx={{ fontSize: 11 }}
                />
              ) : executionBadge.engine === 'spark_connect' ? (
                <Chip
                  size="small"
                  color="secondary"
                  label="⚡ Spark Connect"
                  title="Query routed to Spark Connect cluster (big-data path)."
                  sx={{ fontSize: 11 }}
                />
              ) : executionBadge.engine === 'sql_connector' ? (
                <Chip
                  size="small"
                  color="default"
                  label="🔌 SQL Connector"
                  title="Query pushed down to the source database engine."
                  sx={{ fontSize: 11 }}
                />
              ) : executionBadge.engine === 'single' || executionBadge.workerCount === 1 ? (
                <Chip
                  size="small"
                  variant="outlined"
                  color={
                    // 2026-06-04 — warn-style chip when single-worker
                    // fires against a large file set so the regression
                    // is visually loud (was generic-outline, blended
                    // in with the other chips).  Threshold 100 mirrors
                    // single_worker_large_file_warn_threshold default.
                    typeof mwScanPlan?.file_count === 'number' && mwScanPlan.file_count > 100
                      ? 'warning'
                      : 'default'
                  }
                  label={
                    `🔂 Single worker` +
                    (typeof mwScanPlan?.file_count === 'number'
                      ? ` · ${mwScanPlan.file_count.toLocaleString()} files`
                      : '')
                  }
                  title={[
                    'Query is running on one DuckDB worker (multi-worker dispatch declined).',
                    typeof mwScanPlan?.file_count === 'number'
                      ? `Total files: ${mwScanPlan.file_count.toLocaleString()}`
                      : '',
                    mwScanPlan?.per_table_file_counts
                      ? `Per table: ${
                          Object.entries(mwScanPlan.per_table_file_counts)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 6)
                            .map(([n, c]) => `${n}=${c.toLocaleString()}`)
                            .join(', ')
                        }`
                      : '',
                    mwScanPlan?.rationale
                      ? `Strategist: ${mwScanPlan.rationale}`
                      : '',
                    'Check the admin Query Diagnostics page for the exact engine_router decision row.',
                  ].filter(Boolean).join('\n')}
                  sx={{ fontSize: 11 }}
                />
              ) : null}

              {/* SCAN-STRATEGY (2026-06-01) chip cluster — six chips
                  derived from the existing ``multi_worker_progress`` +
                  new ``scan_plan_decided`` WS events.  All data is
                  already in flight; we just surface it so users don't
                  have to scan the per-worker grid for every status
                  check.  Each chip renders only when it has data. */}

              {/* (1) Scan profile picked by the strategist + rationale */}
              {mwScanPlan?.profile && (
                <Chip
                  size="small"
                  color="info"
                  variant="outlined"
                  label={
                    `⚡ ${mwScanPlan.profile.toUpperCase()}` +
                    (mwScanPlan.file_order ? ` · ${mwScanPlan.file_order.replace(/_/g, '-')}` : '')
                  }
                  title={[
                    mwScanPlan.rationale || '',
                    mwScanPlan.caller     ? `Caller: ${mwScanPlan.caller}` : '',
                    typeof mwScanPlan.file_count === 'number' ? `Files: ${mwScanPlan.file_count.toLocaleString()}` : '',
                    // 2026-06-04 — per-table breakdown for JOIN/UNION
                    // queries so user can see WHICH table dominates
                    // ("table_A: 3000 · table_B: 5" → table_A is the
                    // bottleneck).  Top 6 by count, rest summarised.
                    mwScanPlan.per_table_file_counts
                      ? `Per table: ${
                          Object.entries(mwScanPlan.per_table_file_counts)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 6)
                            .map(([n, c]) => `${n}=${c.toLocaleString()}`)
                            .join(', ')
                        }${
                          Object.keys(mwScanPlan.per_table_file_counts).length > 6
                            ? `, … (+${Object.keys(mwScanPlan.per_table_file_counts).length - 6} more)`
                            : ''
                        }`
                      : '',
                    typeof mwScanPlan.max_workers === 'number' ? `Workers: ${mwScanPlan.max_workers}` : '',
                    typeof mwScanPlan.prewarm_footers === 'boolean' ? `Prewarm: ${mwScanPlan.prewarm_footers ? 'on' : 'off'}` : '',
                    typeof mwScanPlan.prewarm_concurrency === 'number' ? `Prewarm concurrency: ${mwScanPlan.prewarm_concurrency}` : '',
                    typeof mwScanPlan.duckdb_threads === 'number' ? `DuckDB threads: ${mwScanPlan.duckdb_threads}` : '',
                    typeof mwScanPlan.boto3_max_pool_connections === 'number' ? `boto3 pool: ${mwScanPlan.boto3_max_pool_connections}` : '',
                  ].filter(Boolean).join('\n')}
                  sx={{ fontSize: 11 }}
                />
              )}

              {/* (1b) Prewarm chip (round 9, 2026-06-01) — distinct from
                  the multi-worker chip so users see the 30s-250s of HEAD
                  storms as its own stage rather than "executing".  Three
                  stages: prewarm_footers (in-progress, info color) →
                  prewarm_done (success color, shows warmed/timed_out) OR
                  prewarm_skipped_recent (default color, recent-cache hit). */}
              {prewarmStage?.stage && (
                <Chip
                  size="small"
                  color={
                    prewarmStage.stage === 'prewarm_done' ? 'success' :
                    prewarmStage.stage === 'prewarm_skipped_recent' ? 'default' :
                    prewarmStage.stage === 'prewarm_stale' ? 'warning' :
                    'info'
                  }
                  variant={prewarmStage.stage === 'prewarm_done' ? 'filled' : 'outlined'}
                  label={
                    prewarmStage.stage === 'prewarm_done'
                      ? `🔥 Prewarmed ${prewarmStage.warmed ?? '?'}/${prewarmStage.files_total ?? '?'} in ${
                          typeof prewarmStage.elapsed_s === 'number' ? prewarmStage.elapsed_s.toFixed(1) + 's' : '?'
                        }`
                      : prewarmStage.stage === 'prewarm_skipped_recent'
                        ? `⏭ Prewarm skipped (pool hot, last <90s)`
                        : prewarmStage.stage === 'prewarm_stale'
                          ? `🔥 Prewarming ${prewarmStage.files_total ?? '?'} files… (status stale)`
                          : `🔥 Prewarming ${prewarmStage.files_total ?? '?'} files…`
                  }
                  title={
                    prewarmStage.stage === 'prewarm_stale'
                      ? `Last prewarm update was >5min ago — WebSocket may have dropped. Query may still be running; check via the polling fallback.`
                      : (prewarmStage.message ||
                        (prewarmStage.stage === 'prewarm_footers'
                          ? `S3 connection pool warmup in progress (concurrency ${prewarmStage.concurrency ?? '?'}).`
                          : prewarmStage.stage === 'prewarm_done'
                            ? `${prewarmStage.warmed ?? 0} warmed, ${prewarmStage.errors ?? 0} errors, ${prewarmStage.timed_out ?? 0} timed out.`
                            : `Same file set was prewarmed in the last 90s; connection pool still hot.`))
                  }
                  sx={{ fontSize: 11 }}
                />
              )}

              {/* (2) Aggregate worker state — "12/16 running · 3 setup · 1 done" */}
              {(() => {
                const summary = summariseWorkerStates(Object.values(mwWorkers));
                if (!summary) return null;
                const allDone = summary.completed === summary.total;
                const anyFailed = summary.failed > 0;
                const tip = [
                  `Total workers: ${summary.total}`,
                  summary.running   ? `Running: ${summary.running}` : '',
                  summary.setup     ? `Setting up: ${summary.setup}` : '',
                  summary.starting  ? `Starting: ${summary.starting}` : '',
                  summary.completed ? `Completed: ${summary.completed}` : '',
                  summary.failed    ? `Failed: ${summary.failed}` : '',
                  summary.cancelled ? `Cancelled: ${summary.cancelled}` : '',
                ].filter(Boolean).join('\n');
                return (
                  <Chip
                    size="small"
                    color={anyFailed ? 'error' : allDone ? 'success' : 'primary'}
                    variant={allDone ? 'filled' : 'outlined'}
                    label={`👷 ${formatWorkerSummary(summary)}`}
                    title={tip}
                    sx={{ fontSize: 11 }}
                  />
                );
              })()}

              {/* (3) Progress percentage — completed/total workers */}
              {(() => {
                const ws = Object.values(mwWorkers);
                if (ws.length === 0) return null;
                const done = ws.filter(w => w.state === 'completed').length;
                const pct = Math.round((done / ws.length) * 100);
                if (done === 0) return null;
                return (
                  <Chip
                    size="small"
                    variant="outlined"
                    color={pct === 100 ? 'success' : 'default'}
                    label={`✓ ${pct}% (${done}/${ws.length})`}
                    title={`${done} of ${ws.length} workers completed`}
                    sx={{ fontSize: 11 }}
                  />
                );
              })()}

              {/* (4) Aggregate rows + files across workers */}
              {(() => {
                const ws = Object.values(mwWorkers);
                if (ws.length === 0) return null;
                const totalRows = ws.reduce(
                  (acc, w) => acc + (typeof w.rows === 'number' ? w.rows : 0), 0);
                const totalFiles = ws.reduce(
                  (acc, w) => acc + (typeof w.files_count === 'number' ? w.files_count : 0), 0);
                if (totalRows === 0 && totalFiles === 0) return null;
                const parts: string[] = [];
                if (totalRows > 0)  parts.push(`${totalRows.toLocaleString()} rows`);
                if (totalFiles > 0) parts.push(`${totalFiles.toLocaleString()} files`);
                return (
                  <Chip
                    size="small"
                    variant="outlined"
                    label={`📊 ${parts.join(' · ')}`}
                    title="Sum across all workers (live)."
                    sx={{ fontSize: 11 }}
                  />
                );
              })()}

              {/* (5) Stuck worker warning — only renders when something
                  is actually wedged.  Threshold mirrors the per-worker
                  grid's "⏳ stuck Ns" indicator (>=30s on same frame). */}
              {(() => {
                const stuck = Object.values(mwWorkers).filter(
                  w => typeof w.stuck_s === 'number' && w.stuck_s >= 30,
                );
                if (stuck.length === 0) return null;
                const maxStuck = Math.max(...stuck.map(w => w.stuck_s || 0));
                return (
                  <Chip
                    size="small"
                    color="warning"
                    label={`⚠ ${stuck.length} stuck · max ${formatElapsed(maxStuck)}`}
                    title={
                      `${stuck.length} worker${stuck.length === 1 ? '' : 's'} ` +
                      `stuck on the same stack frame for ≥30s.  Common causes: ` +
                      `(a) S3 / VPC endpoint reachability, (b) corporate proxy ` +
                      `connect timeout, (c) DB-side query lock.  See per-worker ` +
                      `grid below for the exact frame.`
                    }
                    sx={{ fontSize: 11 }}
                  />
                );
              })()}

              {/* (6) Wall-clock elapsed chip */}
              {(() => {
                const elapses = Object.values(mwWorkers)
                  .map(w => (typeof w.elapsed_s === 'number' ? w.elapsed_s : 0));
                const maxElapsed = elapses.length ? Math.max(...elapses) : 0;
                if (maxElapsed <= 0) return null;
                return (
                  <Chip
                    size="small"
                    variant="outlined"
                    label={`⏱ ${formatElapsed(maxElapsed)}`}
                    title="Wall-clock elapsed since dispatch (max of any worker's elapsed time)."
                    sx={{ fontSize: 11 }}
                  />
                );
              })()}
            </Box>
          )}

          {/* BF-599 (2026-05-30): live per-worker grid.  Renders the moment
              the first `multi_worker_progress` WS event arrives — admins no
              longer need to be admins to see "worker 0: setup 3/5 (read_parquet…)
              — 12s elapsed".  Same data as AdminPage's "Live Workers" table
              but scoped to THIS execution and visible to the query owner. */}
          {Object.keys(mwWorkers).length > 0 && (
            <Box sx={{ px: 1, py: 0.5, flexShrink: 0 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 600 }}>
                  Workers ({Object.keys(mwWorkers).length})
                </Typography>
                {Object.values(mwWorkers).some(
                  w => ['starting', 'setup', 'running'].includes(w.state),
                ) && (
                  <Chip size="small" color="info" label="live" sx={{ height: 16, fontSize: 10 }} />
                )}
              </Box>
              <Box sx={{
                display: 'grid',
                gridTemplateColumns: 'auto auto auto auto auto 1fr',
                columnGap: 1.5, rowGap: 0.25,
                fontSize: '0.7rem', fontFamily: 'monospace',
                maxHeight: 160, overflow: 'auto',
                px: 1, py: 0.5,
                bgcolor: 'background.default',
                border: 1, borderColor: 'divider', borderRadius: 0.5,
              }}>
                <Box sx={{ fontWeight: 700 }}>Worker</Box>
                <Box sx={{ fontWeight: 700 }}>State</Box>
                <Box sx={{ fontWeight: 700, textAlign: 'right' }}>Files</Box>
                <Box sx={{ fontWeight: 700, textAlign: 'right' }}>Rows</Box>
                <Box sx={{ fontWeight: 700, textAlign: 'right' }}>Elapsed</Box>
                <Box sx={{ fontWeight: 700 }}>Detail / error</Box>
                {Object.values(mwWorkers)
                  .sort((a, b) => a.chunk_index - b.chunk_index)
                  .map((w) => {
                    const stateColor: Record<string, string> = {
                      starting:  'text.secondary',
                      setup:     'info.main',
                      running:   'primary.main',
                      completed: 'success.main',
                      failed:    'error.main',
                      cancelled: 'warning.main',
                    };
                    // BF-599d: prefer the heartbeat-sampled stack frame
                    // ("iceberg_reader.py:412 _S3_CALL_POOL.submit") over
                    // the opaque "executing partial_sql".  Append
                    // "stuck Ns" when the same frame has been on top
                    // for >30s so the eye spots wedged workers fast.
                    const stuckHint =
                      typeof w.stuck_s === 'number' && w.stuck_s >= 30
                        ? ` ⏳ stuck ${w.stuck_s.toFixed(0)}s`
                        : '';
                    const setupDetail =
                      w.state === 'setup' && w.setup_total
                        ? `setup ${w.setup_step ?? 0}/${w.setup_total}` +
                          (w.setup_current ? ` — ${w.setup_current}` : '')
                        : '';
                    const detail = w.error
                      ? w.error
                      : w.state === 'completed'
                      ? `done${w.rows ? ` (${w.rows.toLocaleString()} rows)` : ''}`
                      : w.state === 'cancelled'
                      ? 'cancelled'
                      : w.running_detail
                      ? (setupDetail ? `${setupDetail} · ` : '') +
                        `in ${w.running_detail}${stuckHint}`
                      : setupDetail
                      ? `${setupDetail}${stuckHint}`
                      : w.state === 'running'
                      ? `executing partial_sql${stuckHint}`
                      : w.state || '';
                    return (
                      <React.Fragment key={w.chunk_index}>
                        <Box>#{w.chunk_index}</Box>
                        <Box sx={{ color: stateColor[w.state] || 'text.primary' }}>
                          {w.state}
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          {w.files_count?.toLocaleString?.() ?? '—'}
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          {w.rows?.toLocaleString?.() ?? '—'}
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          {typeof w.elapsed_s === 'number' ? formatElapsed(w.elapsed_s) : '—'}
                        </Box>
                        <Box sx={{
                          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                          color: w.error ? 'error.main' : 'text.secondary',
                        }}>
                          {detail}
                        </Box>
                      </React.Fragment>
                    );
                  })}
              </Box>
            </Box>
          )}

          {/* BF-256: Engine selector chip row — Auto / DuckDB / Spark Connect.
              Auto uses the row-threshold gate; explicit override forces one
              engine.  Helpful when the table is huge and the user wants to
              skip the threshold check, or when debugging an engine. */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, px: 1, flexShrink: 0 }}>
            <Typography variant="caption" color="text.secondary">Engine:</Typography>
            {(['auto', 'duckdb', 'spark'] as const).map(opt => (
              <Chip
                key={opt}
                label={opt === 'auto' ? 'Auto' : opt === 'duckdb' ? 'DuckDB (local)' : 'Spark Connect (cluster)'}
                size="small"
                variant={engineOverride === opt ? 'filled' : 'outlined'}
                color={engineOverride === opt
                  ? (opt === 'spark' ? 'secondary' : 'primary')
                  : 'default'}
                onClick={() => setEngineOverride(opt)}
                sx={{ fontSize: '0.7rem', height: 22 }}
              />
            ))}
            {engineOverride === 'spark' && (
              <Typography variant="caption" color="warning.main" sx={{ ml: 1 }}>
                Spark cluster must be running and <code>spark_connect.enabled=true</code>
              </Typography>
            )}
          </Box>

          {/* BF-428I/K — Per-query S3 reader override.  Effective only
              when admin master switch s3_readers.integration_enabled =
              true.  Chip row hidden when backend metadata unavailable
              (no admin auth / endpoint not registered). */}
          {readerMetadata.length > 0 && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, px: 1, flexShrink: 0, flexWrap: 'wrap' }}>
              <Typography variant="caption" color="text.secondary">S3 Reader:</Typography>
              {[{ name: 'auto', label: 'Auto' }, ...readerMetadata].map(opt => (
                <Chip
                  key={opt.name}
                  label={opt.label}
                  size="small"
                  variant={readerOverride === opt.name ? 'filled' : 'outlined'}
                  color={readerOverride === opt.name
                    ? (opt.name === 'athena' ? 'secondary' : 'primary')
                    : 'default'}
                  onClick={() => setReaderOverride(opt.name)}
                  sx={{ fontSize: '0.7rem', height: 22 }}
                />
              ))}
            </Box>
          )}

          {/* Results */}
          <Paper elevation={0} sx={{
            flexGrow: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column',
            border: '1px solid', borderColor: 'divider',
          }}>
            {/* BF-266: gate on showResults (set by execution_completed WS
                event), not just executionId.  Same pattern CQB uses.
                While query is running we render a centered "running"
                placeholder; the grid only mounts when results are
                actually ready, so /results never reads a partial
                parquet and never displays an empty grid. */}
            {streamingSource && showResults ? (
              // Phase 142: Streaming mode — mount grid with a streaming source
              // so it pulls rows from /api/stream as the engine reads from S3.
              <React.Suspense fallback={<Box sx={{ p: 3, textAlign: 'center' }}><CircularProgress /></Box>}>
                <DataGridViewer streamingSource={streamingSource}
                  connectionId={String(selectedConnId ?? '')} embedded={true}
                  partitionColumns={partitionColumns}
                  columnMetadata={Object.keys(bqbColumnMetadata).length > 0 ? bqbColumnMetadata : undefined}
                  onCellAction={handleCellDrilldown} />
              </React.Suspense>
            ) : executionId && showResults ? (
              <React.Suspense fallback={<Box sx={{ p: 3, textAlign: 'center' }}><CircularProgress /></Box>}>
                <DataGridViewer executionId={executionId}
                  connectionId={String(selectedConnId ?? '')} embedded={true}
                  partitionColumns={partitionColumns}
                  columnMetadata={Object.keys(bqbColumnMetadata).length > 0 ? bqbColumnMetadata : undefined}
                  onCellAction={handleCellDrilldown} />
              </React.Suspense>
            ) : executionId && executing ? (
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexGrow: 1, color: 'text.secondary', flexDirection: 'column', gap: 1.5 }}>
                <CircularProgress size={36} thickness={4} />
                <Typography variant="body2" fontWeight={600} color="text.primary">
                  Query running on backend
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {progressLog || 'Waiting for engine to finish…'}
                </Typography>
              </Box>
            ) : (
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexGrow: 1, color: 'text.secondary' }}>
                <Stack alignItems="center" spacing={0.5}>
                  <TableChartIcon sx={{ fontSize: 40, opacity: 0.2 }} />
                  <Typography variant="caption">Select columns and Execute to see results</Typography>
                </Stack>
              </Box>
            )}
          </Paper>
        </Box>
      </Box>

      {/* ── Load Query Dialog ─────────────────────────────────────── */}
      {/* Phase 134-N — tabbed view showing BOTH saved queries (from the
          ``saved_queries`` table) AND .sql files (``sql_files``) so the
          user can find their work regardless of which Save action they
          used.  Pre-fix only sql_files was listed — saved-via-modal
          queries were invisible. */}
      <Dialog open={loadDialogOpen} onClose={() => setLoadDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Load Query</DialogTitle>
        <Tabs
          value={loadDialogTab}
          onChange={(_, v) => setLoadDialogTab(v)}
          variant="fullWidth"
        >
          <Tab
            label={`Saved Queries (${savedQueryList.length})`}
            value="queries"
          />
          <Tab
            label={`SQL Files (${savedQueries.length})`}
            value="files"
          />
        </Tabs>
        <DialogContent>
          {loadDialogTab === 'queries' ? (
            <List dense sx={{ maxHeight: 400, overflow: 'auto' }}>
              {savedQueryList.map((q: any) => {
                const qc = q.query_config || {};
                const hasRawSql = !!(qc.raw_sql || qc.custom_sql);
                return (
                  <ListItem key={q.id} disablePadding>
                    <ListItemButton
                      onClick={() => handleLoadSavedQuery(q.id)}
                      disabled={!hasRawSql}
                    >
                      <ListItemText
                        primary={q.name}
                        secondary={
                          q.description ||
                          (hasRawSql
                            ? `Created ${q.created_at?.slice(0, 10) || ''}`
                            : 'Visual query — open from Saved Queries page')
                        }
                      />
                    </ListItemButton>
                  </ListItem>
                );
              })}
              {savedQueryList.length === 0 && (
                <Typography variant="body2" color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No saved queries found.  Saves via "Save query" land here.
                </Typography>
              )}
            </List>
          ) : (
            <List dense sx={{ maxHeight: 400, overflow: 'auto' }}>
              {savedQueries.map((q) => (
                <ListItem key={q.id} disablePadding>
                  <ListItemButton onClick={() => handleLoadSqlFile(q.id)}>
                    <ListItemText primary={q.name}
                      secondary={q.description || `Created ${q.created_at?.slice(0, 10) || ''}`} />
                  </ListItemButton>
                </ListItem>
              ))}
              {savedQueries.length === 0 && (
                <Typography variant="body2" color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No SQL files found.  Saves via "Save as .sql file…" land here.
                </Typography>
              )}
            </List>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setLoadDialogOpen(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* ── Save Query Modal ────────────────────────────────────────── */}
      <React.Suspense fallback={null}>
        {showSaveDialog && (
          <SaveQueryModal open={showSaveDialog} queryConfig={buildQueryConfig()}
            sqlPreview={sqlText} editingQueryId={savedQueryId} editingQueryName={savedQueryName}
            onClose={() => {
              setShowSaveDialog(false);
              // BF-496 — clear the auto-publish intent if the user
              // dismissed Save without saving, so a future unrelated
              // Save doesn't accidentally open the Publish dialog.
              setPublishAfterSave(false);
            }}
            onSaved={handleSaved} />
        )}
      </React.Suspense>

      {/* ── Publish View Dialog ─────────────────────────────────────── */}
      {/* Single dialog used for both saved_query and sql_file sources.
          Saved-query path wins when both are present (richer metadata).
          The dialog itself routes the publish payload to the right
          backend ``source_type`` based on the props passed. */}
      <React.Suspense fallback={null}>
        {publishDialogOpen && savedQueryId && (
          <PublishViewDialog open={publishDialogOpen} onClose={() => setPublishDialogOpen(false)}
            sourceType="saved_query"
            queryId={savedQueryId} queryName={savedQueryName} columns={Array.from(selectedPhysical)} />
        )}
        {publishDialogOpen && !savedQueryId && loadedSqlFileId && (
          <PublishViewDialog open={publishDialogOpen} onClose={() => setPublishDialogOpen(false)}
            sourceType="sql_file"
            sqlFileId={loadedSqlFileId}
            queryName={savedQueryName || `sql-file-${loadedSqlFileId}`}
            columns={Array.from(selectedPhysical)} />
        )}
      </React.Suspense>

      {/* ── Advanced SQL Modals (Phase 134) ────────────────────────── */}
      <React.Suspense fallback={null}>
        {showHavingModal && (
          <HavingBuilderModal
            open={showHavingModal}
            aggregations={havingAggregations}
            tables={modalTableList}
            schemas={modalSchemas}
            having={having}
            onUpdate={setHaving}
            onClose={handleCloseHaving}
          />
        )}
        {showComputedModal && (
          <ComputedColumnBuilderModal
            open={showComputedModal}
            tables={modalTableList}
            schemas={modalSchemas}
            computedColumns={computedColumns}
            onUpdate={setComputedColumns}
            onClose={handleCloseComputed}
          />
        )}
        {showCaseModal && (
          <CaseExpressionBuilderModal
            open={showCaseModal}
            tables={modalTableList}
            schemas={modalSchemas}
            caseExpressions={caseExpressions}
            onUpdate={setCaseExpressions}
            onClose={handleCloseCase}
          />
        )}
        {showWindowModal && (
          <WindowFunctionBuilderModal
            open={showWindowModal}
            tables={modalTableList}
            schemas={modalSchemas}
            windowFunctions={windowFunctions}
            onUpdate={setWindowFunctions}
            onClose={handleCloseWindow}
          />
        )}
      </React.Suspense>

      {/* ── Query Templates ────────────────────────────────────────── */}
      {showTemplates && (
        <QueryTemplates
          open={showTemplates}
          onClose={handleCloseTemplates}
          onSelect={handleTemplateSelect}
        />
      )}

      {/* Phase 138: Visual EXPLAIN dialog */}
      <ExplainViewer
        open={explainOpen}
        onClose={() => setExplainOpen(false)}
        sql={sqlText}
        connectionId={selectedConnId}
      />
    </Box>
  );
};

export default BusinessQueryBuilder;
