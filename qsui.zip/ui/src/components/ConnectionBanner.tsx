/**
 * BF-414 — Non-intrusive backend-connection indicator.
 *
 * Earlier we showed a sticky top-of-viewport banner ("Connection to the
 * backend is unstable…") that created a bad impression every time the
 * frontend hit a transient blip — even though user context was preserved.
 *
 * New behaviour:
 *   - Default: invisible.  Backend up → nothing on screen.
 *   - Offline: tiny floating WifiOff icon in the bottom-left, no text.
 *   - Hover/click: tooltip explains "reconnecting" and shows Retry.
 *
 * Long-running queries continue on the server regardless — the icon is
 * informational only, never blocking.
 */
import React, { useState } from 'react';
import {
  Box,
  IconButton,
  Tooltip,
  Popover,
  Typography,
  Button,
  Stack,
} from '@mui/material';
import {
  WifiOff as WifiOffIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

const ConnectionBanner: React.FC = () => {
  const { apiOnline, retryConnection } = useAuth();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  if (apiOnline) return null;

  const open = Boolean(anchorEl);

  return (
    <Box
      sx={{
        position: 'fixed',
        bottom: 16,
        left: 16,
        zIndex: (theme) => theme.zIndex.snackbar + 10,
      }}
    >
      <Tooltip title="Reconnecting to backend…  Click for details." arrow>
        <IconButton
          size="small"
          aria-label="Backend reconnecting"
          onClick={(e) => setAnchorEl(e.currentTarget)}
          sx={{
            bgcolor: 'warning.main',
            color: 'warning.contrastText',
            boxShadow: 2,
            width: 28,
            height: 28,
            '&:hover': { bgcolor: 'warning.dark' },
          }}
        >
          <WifiOffIcon sx={{ fontSize: 16 }} />
        </IconButton>
      </Tooltip>

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
        transformOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Box sx={{ p: 2, maxWidth: 320 }}>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
            <WifiOffIcon fontSize="small" color="warning" />
            <Typography variant="subtitle2">Reconnecting…</Typography>
          </Stack>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            Your work is preserved.  Long-running queries continue on the
            server.  Auto-retrying every 30 seconds.
          </Typography>
          <Button
            size="small"
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={() => { retryConnection(); setAnchorEl(null); }}
            fullWidth
          >
            Retry now
          </Button>
        </Box>
      </Popover>
    </Box>
  );
};

export default ConnectionBanner;
