/**
 * FeedTodayPage — Phase 130/5
 *
 * Operations dashboard for daily feed_runs.  Shows status tiles + a
 * filterable table of every feed run scheduled (or already executed)
 * for a business_date.  Admins can force-run the SOD generator, sweep
 * SLA breaches, and cancel pending runs.
 *
 * Layout inspired by the OTG-config dashboard pattern: stat cards
 * across the top, runs table below.
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Alert, CircularProgress,
  TextField, MenuItem, Select, FormControl, InputLabel, TablePagination,
} from '@mui/material';
import {
  Refresh as RefreshIcon, Cancel as CancelIcon,
  Terminal as TerminalIcon,
  CheckCircle as DoneIcon, Error as FailIcon,
  HourglassTop as PendingIcon, Block as SkipIcon,
  Schedule as RunningIcon, Warning as BreachIcon,
  InfoOutlined as InfoIcon, Dashboard as DashboardIcon,
  Replay as ReplayIcon, PlayArrow as TriggerIcon,
  Lock as LockIcon,
  Code as PreviewSqlIcon, ContentCopy as CopyIcon,
} from '@mui/icons-material';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  FormGroup, FormControlLabel, Checkbox, Divider,
  Menu, ListItemIcon, ListItemText,
} from '@mui/material';
import RouterIcon from '@mui/icons-material/CallSplit';
import BoltIcon from '@mui/icons-material/Bolt';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import { useNotifications } from '../context/NotificationContext';
import FeedExecutionPerformanceChip from './FeedExecutionPerformanceChip';
import FeedSqlPreviewDialog from './FeedSqlPreviewDialog';

type FeedRun = {
  id: number;
  feed_config_id: number;
  business_date: string;
  run_date: string;
  status: string;
  priority: number;
  sla_from?: string | null;
  sla_to?: string | null;
  sla_breached: boolean;
  action_decision: string;
  action_reason?: string | null;
  scheduled_time?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  output_path?: string | null;
  control_file_path?: string | null;
  total_rows?: number;
  // Phase 130 hotfix-13 — incremented every time an operator clicks
  // Rerun (or bulk-rerun) on this row.  Surfaced as a small badge on
  // the dashboard so reviewers see at-a-glance whether a row has been
  // re-fired multiple times.
  retry_count?: number;
  triggered_by?: string;
  // Joined from feed_configs at /api/feed-runs response time so the
  // table can show a human-readable feed name instead of just an id.
  feed_name?: string | null;
  feed_owner?: string | null;
  // Computed server-side: true if current user is feed owner or admin.
  // Drives the per-row Rerun button enable state.
  can_rerun?: boolean;
  // Phase 130 hotfix-13 — populated from feed_executions when the
  // row's most recent execution finished/failed.  Used to show
  // stage breakdown + failing-stage badge.
  error?: string | null;
  stage_timings?: Record<string, number> | null;
  failed_stage?: string | null;
  execution_backend?: string | null;
  // Round 16: id of the latest feed_executions row (when one exists)
  // — used by the BQB-parity perf chip to fetch logs + stage_history.
  feed_execution_id?: number | null;
  // Feed's CONFIGURED backend (from feed_configs.execution_backend).
  // When this differs from the run's actual execution_backend,
  // render a per-row "override" chip so ops sees the divergence.
  feed_configured_backend?: string | null;
  // BF-473 — operator category (sod / intraday / eod / daily / monthly / custom)
  // Surfaced as a small chip on the row; powers the category filter.
  frequency_category?: string | null;
  // BF-478 — file_size surfaced on the info icon popover.
  file_size_bytes?: number | null;
};

const STATUS_LIST = ['pending', 'running', 'completed', 'failed', 'skipped', 'cancelled'];

const STATUS_ICON: Record<string, React.ReactElement> = {
  pending:   <PendingIcon fontSize="small" />,
  running:   <RunningIcon fontSize="small" />,
  completed: <DoneIcon fontSize="small" />,
  failed:    <FailIcon fontSize="small" />,
  skipped:   <SkipIcon fontSize="small" />,
  cancelled: <CancelIcon fontSize="small" />,
};

const STATUS_COLOR: Record<string, 'default' | 'success' | 'error' | 'warning' | 'info'> = {
  pending:   'warning',
  running:   'info',
  completed: 'success',
  failed:    'error',
  skipped:   'default',
  cancelled: 'default',
};

const todayUtcIso = (): string => new Date().toISOString().slice(0, 10);

/** Phase 145.7 — human-readable label for backend stage names.
 *  Maps the canonical stage IDs feed_engine emits via feed_progress
 *  to friendly strings the operator can scan at a glance. */
const _FEED_STAGE_LABEL: Record<string, string> = {
  status_running:        'Starting',
  query_native:          'Running query (native)',
  query_spark_connect:   'Running query (Spark Connect)',
  query_airflow:         'Submitting Airflow DAG',
  query_executing:       'Executing query',
  register_views:        'Registering S3 views',
  pre_download:          'Downloading files',
  duckdb_execute:        'DuckDB execute',
  fetch_results:         'Fetching results',
  format_csv:            'Writing CSV',
  format_parquet:        'Writing Parquet',
  format_json:           'Writing JSON',
  format_excel:          'Writing Excel',
  deliver_local:         'Saving to local path',
  deliver_s3:            'Uploading to S3',
  deliver_sftp:          'Uploading via SFTP',
  deliver_oracle:        'Loading into Oracle',
  control_file:          'Writing control file',
};
function feedHumaniseStage(stage: string): string {
  if (!stage) return '…';
  if (_FEED_STAGE_LABEL[stage]) return _FEED_STAGE_LABEL[stage];
  // Strip ``query_`` / ``format_`` / ``deliver_`` prefix and title-case
  // for unknown stages so the chip is still readable.
  return stage.replace(/^(query|format|deliver)_/, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());
}

/** BF-478 (2026-05-19) — leaf component, fetches the feed_config on
 *  first open and shows filename / file path / config preview /
 *  why-0-records hint in a popover.  Defers the HTTP call until the
 *  user actually clicks the info icon (no waste on rows nobody looks
 *  at).  React.memo guards against re-renders from the parent.
 */
interface FeedRunInfoIconProps {
  feedConfigId: number;
  outputPath?: string | null;
  controlFilePath?: string | null;
  totalRows?: number;
  fileSizeBytes?: number | null;
  status: string;
  actionDecision?: string;
  actionReason?: string | null;
  startedAt?: string | null;
  completedAt?: string | null;
  triggeredBy?: string;
  frequencyCategory?: string | null;
  error?: string | null;
}
const FeedRunInfoIcon: React.FC<FeedRunInfoIconProps> = React.memo((props) => {
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [cfg, setCfg] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleOpen = useCallback(async (e: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(e.currentTarget);
    setOpen(true);
    if (cfg) return;  // cached
    setLoading(true);
    try {
      const r = await fetch(`/api/feeds/${props.feedConfigId}`, { credentials: 'include' });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      setCfg(data);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [cfg, props.feedConfigId]);

  // Compose the "why 0 records" hint so the user doesn't have to guess.
  const zeroRowsHint = useMemo(() => {
    if ((props.totalRows ?? 0) !== 0 || props.status !== 'completed') return null;
    if (props.actionDecision === 'SKIP') {
      return `Feed was SKIPPED for this business_date (${props.actionReason || 'ACTION_CONDITION returned SKIP'}). No execution ran.`;
    }
    return (
      "Genuine empty result: query executed successfully but matched 0 rows. "
      + "Common causes: WHERE clause filters too strict for this business_date, "
      + "or the upstream data hasn't landed yet. "
      + "If unexpected, check the feed's SQL against the source manually."
    );
  }, [props.totalRows, props.status, props.actionDecision, props.actionReason]);

  return (
    <>
      <Tooltip title="Show file details + config">
        <IconButton size="small" onClick={handleOpen} sx={{ p: 0.25 }}>
          <InfoIcon sx={{ fontSize: 16 }} />
        </IconButton>
      </Tooltip>
      <Menu
        open={open}
        anchorEl={anchorEl}
        onClose={() => setOpen(false)}
        slotProps={{ paper: { sx: { maxWidth: 520, p: 1.5 } } }}
      >
        <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
          Feed run details
        </Typography>

        {zeroRowsHint && (
          <Alert severity={props.actionDecision === 'SKIP' ? 'info' : 'warning'} sx={{ mb: 1.5, fontSize: '0.78rem' }}>
            <strong>Why total records = 0?</strong><br />{zeroRowsHint}
          </Alert>
        )}

        <Box sx={{ fontFamily: 'JetBrains Mono, Menlo, monospace', fontSize: 11, lineHeight: 1.6 }}>
          <div><strong>Output file:</strong> {props.outputPath || <em>—</em>}</div>
          <div><strong>Control file:</strong> {props.controlFilePath || <em>—</em>}</div>
          <div><strong>Rows / bytes:</strong> {(props.totalRows ?? 0).toLocaleString()} / {(props.fileSizeBytes ?? 0).toLocaleString()}</div>
          <div><strong>Triggered by:</strong> {props.triggeredBy || '—'}</div>
          <div><strong>Started:</strong> {props.startedAt || '—'}</div>
          <div><strong>Completed:</strong> {props.completedAt || '—'}</div>
          {props.frequencyCategory && (
            <div><strong>Category:</strong> {props.frequencyCategory}</div>
          )}
        </Box>

        <Divider sx={{ my: 1 }} />
        <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
          Feed config
        </Typography>
        {loading && <CircularProgress size={14} />}
        {error && <Alert severity="error" sx={{ fontSize: '0.75rem' }}>{error}</Alert>}
        {cfg && (
          <Box sx={{ fontFamily: 'JetBrains Mono, Menlo, monospace', fontSize: 11, lineHeight: 1.5 }}>
            <div><strong>Name:</strong> {cfg.name}</div>
            <div><strong>Source:</strong> {cfg.source_type} #{cfg.source_id}</div>
            <div><strong>Connection:</strong> #{cfg.connection_id || '—'}</div>
            <div><strong>Output format:</strong> {cfg.output_format}</div>
            <div><strong>Destination:</strong> {cfg.destination_type} → {(cfg.destination_config && cfg.destination_config.path) || '—'}</div>
            <div><strong>Backend:</strong> {cfg.execution_backend || 'auto'}</div>
            <div><strong>Calendar:</strong> {cfg.calendar_name || '—'}</div>
            <div><strong>Category:</strong> {cfg.frequency_category || '—'}</div>
            {cfg.action_condition_sql && (
              <Box sx={{ mt: 0.5 }}>
                <strong>ACTION_CONDITION:</strong>
                <pre style={{ margin: 0, fontSize: 10, whiteSpace: 'pre-wrap' }}>{cfg.action_condition_sql}</pre>
              </Box>
            )}
          </Box>
        )}
      </Menu>
    </>
  );
});
FeedRunInfoIcon.displayName = 'FeedRunInfoIcon';

/** BF-466b (2026-05-19) — leaf component owns its own elapsed counter.
 *
 * Before: FeedTodayPage had a page-level setLiveTick(+1) every 1 s while
 * any feed was running.  That re-rendered the ENTIRE table (every row,
 * every chip, every tooltip) once per second.  With many rows the
 * cumulative render time blocked the JS event loop hard enough that
 * WebSocketContext's heartbeat watchdog tripped → ws.close() → reconnect
 * storm (code 1000).  BF-465 had gated the tick on hasLiveFeeds but
 * didn't remove the page-wide re-render — only deferred it.
 *
 * Now: each live chip owns its own setInterval.  Only the Chip's
 * Box/Typography subtree re-renders.  Parent table doesn't.  Event
 * loop free; WS heartbeat stable.
 *
 * Tab-hidden gate — pause when the tab is in the background.
 */
interface _LiveProgress {
  stage: string;
  elapsed: number;
  stages_done: number;
  backend: string;
  last_update_ts: number;
  history: { stage: string; at: number }[];
}
const FeedLiveProgressChip: React.FC<{ lp: _LiveProgress }> = React.memo(({ lp }) => {
  const [tickNonce, setTickNonce] = useState(0);
  const [visible, setVisible] = useState(
    typeof document === 'undefined' ? true : document.visibilityState !== 'hidden',
  );
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const onVis = () => setVisible(document.visibilityState !== 'hidden');
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);
  useEffect(() => {
    if (!visible) return;
    const id = window.setInterval(() => setTickNonce(t => t + 1), 1000);
    return () => window.clearInterval(id);
  }, [visible]);
  // Re-derive on each tick.  tickNonce intentionally unused below — it's
  // only here to force a re-render of THIS leaf component.
  void tickNonce;
  const liveElapsed = lp.elapsed + Math.max(0, (Date.now() - lp.last_update_ts) / 1000);
  return (
    <Tooltip title={
      <Box sx={{ fontSize: 11 }}>
        <Box sx={{ fontWeight: 600, mb: 0.5 }}>
          Live · {feedHumaniseStage(lp.stage)} · {lp.backend}
        </Box>
        <Box sx={{ opacity: 0.85, mb: 0.5 }}>
          Step {lp.stages_done} · {liveElapsed.toFixed(0)}s elapsed
        </Box>
        {lp.history.length > 0 && (
          <>
            <Box sx={{ fontWeight: 600, mt: 1 }}>Timeline:</Box>
            {lp.history.map((h, i) => (
              <Box key={i} sx={{ pl: 1, fontFamily: 'monospace' }}>
                {new Date(h.at).toLocaleTimeString()} · {feedHumaniseStage(h.stage)}
              </Box>
            ))}
          </>
        )}
      </Box>
    }>
      <Chip
        size="small"
        icon={<RunningIcon sx={{ fontSize: 12 }} />}
        label={`${feedHumaniseStage(lp.stage)} · ${liveElapsed.toFixed(0)}s · step ${lp.stages_done}`}
        color="info"
        sx={{
          ml: 0.5, fontSize: '0.65rem', height: 20,
          animation: 'fr-pulse 1.5s ease-in-out infinite',
          '@keyframes fr-pulse': {
            '0%, 100%': { opacity: 1 },
            '50%':      { opacity: 0.6 },
          },
        }}
      />
    </Tooltip>
  );
});
FeedLiveProgressChip.displayName = 'FeedLiveProgressChip';

const FeedTodayPage: React.FC = () => {
  const { addNotification } = useNotifications();  // BF-475 — color-coded toasts
  const [businessDate, setBusinessDate] = useState<string>(todayUtcIso());
  const [statusFilter, setStatusFilter] = useState<string>('');
  // BF-473 — operator category filter (client-side, no API param needed
  // since rows already carry frequency_category from the join).
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [rows, setRows] = useState<FeedRun[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Phase 130 hotfix-13 — show a banner when the system is not in
  // 'auto' backend mode (halt / native_only / airflow_only) so
  // operators know why pending rows aren't firing or why all feeds
  // are landing on one backend.
  const [backendOverride, setBackendOverride] = useState<string>('auto');
  const [overrideMeta, setOverrideMeta] = useState<{
    updated_by?: string | null; updated_at?: string | null;
  } | null>(null);
  // Rerun-with-backend menu state.  Anchored to the row's Rerun button
  // so admins can choose Auto / Native / Airflow per execution.
  const [rerunMenu, setRerunMenu] = useState<{
    anchor: HTMLElement | null;
    run: FeedRun | null;
  }>({ anchor: null, run: null });
  // Expanded row for stage_timings breakdown (CBQ-parity per-stage view).
  const [expandedRunId, setExpandedRunId] = useState<number | null>(null);
  // Phase 132.27 — exec_id of the row whose live logs are open
  const [logsExecId, setLogsExecId] = useState<string | null>(null);
  // Phase 130 hotfix-13 — backend choice for bulk-rerun.  Defaults to
  // 'auto' (honour per-feed setting + global override).  Admins can
  // override to push the whole selection through native or airflow.
  const [bulkBackend, setBulkBackend] = useState<'auto' | 'native' | 'airflow'>('auto');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  // Bulk-rerun popup state
  const [triggerOpen, setTriggerOpen] = useState(false);
  const [triggerStatuses, setTriggerStatuses] = useState<string[]>(['failed']);
  // Per-row selection — when ANY rows are selected, Trigger Runs
  // targets those specific feed_runs instead of opening the status
  // picker.  Owner-gated client-side too (server enforces anyway).
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  // Preview SQL dialog state — opened from the Actions column.
  // Backed by the reusable FeedSqlPreviewDialog component shared with FeedConfigsPage.
  const [previewFeedId, setPreviewFeedId] = useState<number | null>(null);

  const toggleRowSelected = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());
  // Phase 130 hotfix-9 — UI triggers are unconstrained.  Admin /
  // owner can fire a feed any time regardless of current status;
  // status sync (via execute_feed's feed_run_id parameter) keeps
  // the dashboard accurate as the rerun progresses.
  // BF-473 — apply category filter (client-side) before pagination so
  // category-filtered tables paginate correctly and select-all only
  // affects visible rows.
  const filteredRows = useMemo(
    () => categoryFilter
      ? rows.filter(r => r.frequency_category === categoryFilter)
      : rows,
    [rows, categoryFilter],
  );
  const visibleRowIds = useMemo(
    () => filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .filter(r => r.can_rerun)
              .map(r => r.id),
    [filteredRows, page, rowsPerPage]
  );
  const toggleSelectAllVisible = () => {
    setSelectedIds(prev => {
      const allSelected = visibleRowIds.every(id => prev.has(id));
      const next = new Set(prev);
      if (allSelected) {
        visibleRowIds.forEach(id => next.delete(id));
      } else {
        visibleRowIds.forEach(id => next.add(id));
      }
      return next;
    });
  };

  // BF-468 — split into two entry points so background polls don't
  // flash the loading spinner.  User report: "its shows polling
  // again n again" — the 60s setInterval refresh was visibly
  // flickering the loading state every minute.  Silent refreshes
  // skip the spinner.  Manual loads (initial mount, filter change,
  // post-rerun) still show it.
  const _doLoad = useCallback(async (silent: boolean) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const params: any = { business_date: businessDate };
      if (statusFilter) params.status = statusFilter;
      const resp: any = await api.listTodaysFeedRuns(params);
      setRows((resp?.items ?? []) as FeedRun[]);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      if (!silent) setLoading(false);
    }
  }, [businessDate, statusFilter]);
  const load = useCallback(() => _doLoad(false), [_doLoad]);
  const loadSilent = useCallback(() => _doLoad(true), [_doLoad]);

  useEffect(() => { load(); }, [load]);

  // ── Live updates via WebSocket (Phase 131 deep-dive) ────────────────
  // Subscribe to backend feed events so the dashboard reflects state
  // changes within ~milliseconds instead of waiting for the 30s
  // polling tick.  Events handled:
  //   feed_progress     → stash current stage on the row in a side map
  //                       (renders as a "live: <stage>" chip)
  //   feed_completed    → optimistic patch + lazy reload
  //   feed_failed       → optimistic patch + lazy reload
  //   feed_cancelled    → optimistic patch + lazy reload
  //   feed_dep_ready    → flip action_decision WAIT→RUN in-place
  //   feed_dep_sla_breach → flash the SLA-breached counter
  // All handlers fail-open so a malformed event never breaks the page.
  const { addListener, isConnected: wsConnected } = useWebSocket();
  // Phase 145.7 — richer live-progress state.  Type lives at module
  // scope as ``_LiveProgress`` (see top of file) so FeedLiveProgressChip
  // can share it without duplicating the shape.
  const [liveStages, setLiveStages] = useState<Record<number, _LiveProgress>>({});
  const [wsEventCount, setWsEventCount] = useState(0);
  // BF-466b — page-level tick REMOVED.  The live progress chip
  // (FeedLiveProgressChip) now owns its own setInterval as a leaf
  // component, so only the chip re-renders every second.  The table
  // and all other rows stay quiet.  Event loop free; WS heartbeat
  // stable even with hundreds of feed rows on screen.

  // Stash the latest rows + load callback in refs so the WS listener
  // can read fresh state without forcing the effect to re-register on
  // every state change (which would churn the subscription every time
  // a row updates — wasteful + brittle).
  const rowsRef = useRef<FeedRun[]>([]);
  const loadRef = useRef(loadSilent);
  useEffect(() => { rowsRef.current = rows; }, [rows]);
  // BF-468 — loadRef points at the SILENT loader for WS-driven
  // refreshes (no spinner flash).  feed_progress arrivals etc. cause
  // a re-fetch but should be invisible to the user.
  useEffect(() => { loadRef.current = loadSilent; }, [loadSilent]);

  useEffect(() => {
    const unsub = addListener((msg) => {
      try {
        const t = (msg as any).type as string;
        if (!t || !t.startsWith('feed_')) return;
        setWsEventCount((c) => c + 1);
        const feedId = Number((msg as any).feed_id);
        const runId = Number((msg as any).feed_run_id);
        if (t === 'feed_progress' && feedId) {
          const stage = String((msg as any).stage || '');
          const elapsed = Number((msg as any).elapsed_seconds || 0);
          const stagesDone = Number((msg as any).stages_done || 0);
          const backendName = String((msg as any).backend || '');
          setRows((prev) => prev.map((r) =>
            r.feed_config_id === feedId && r.status !== 'completed'
              ? { ...r, status: 'running' }
              : r,
          ));
          // feed_progress doesn't carry feed_run_id, so look up via ref.
          const matchRow = rowsRef.current.find((r) => r.feed_config_id === feedId);
          if (matchRow) {
            setLiveStages((prev) => {
              const existing = prev[matchRow.id];
              // Build history: append the new stage if it differs from the
              // last one we recorded.  Same stage repeated → just update
              // elapsed (the backend ticks every stage transition, not
              // every second).
              const lastStage = existing?.history?.[existing.history.length - 1]?.stage;
              const history = existing?.history ?? [];
              const newHistory = lastStage !== stage
                ? [...history, { stage, at: Date.now() }]
                : history;
              return {
                ...prev,
                [matchRow.id]: {
                  stage,
                  elapsed,
                  stages_done: stagesDone,
                  backend: backendName,
                  last_update_ts: Date.now(),
                  history: newHistory,
                },
              };
            });
          }
        } else if (t === 'feed_completed' || t === 'feed_failed' || t === 'feed_cancelled') {
          if (feedId) {
            const matches = rowsRef.current.filter((r) => r.feed_config_id === feedId).map((r) => r.id);
            if (matches.length) {
              setLiveStages((prev) => {
                const next = { ...prev };
                for (const id of matches) delete next[id];
                return next;
              });
            }
          }
          // Authoritative refresh — coalesces multiple final events.
          void loadRef.current();
        } else if (t === 'feed_dep_ready' && runId) {
          setRows((prev) => prev.map((r) =>
            r.id === runId
              ? { ...r, action_decision: 'RUN', action_reason: 'deps ready' }
              : r,
          ));
        }
      } catch { /* fail-open */ }
    });
    return unsub;
  }, [addListener]);  // ← stable; listener registers once per mount

  // Phase 130 hotfix-13 — poll the backend override every 30s so the
  // failover banner stays accurate.  Cheap admin endpoint; fail-open
  // (silent on error so the dashboard itself never breaks).
  useEffect(() => {
    let cancelled = false;
    const fetchOverride = async () => {
      try {
        const r = await api.getFeedBackendOverride() as {
          value: string;
          persisted: { updated_by?: string | null; updated_at?: string | null } | null;
        };
        if (!cancelled) {
          setBackendOverride(r.value || 'auto');
          setOverrideMeta(r.persisted ?? null);
        }
      } catch {
        // user may not be admin → 401/403 → leave banner off
      }
    };
    void fetchOverride();
    const t = setInterval(() => void fetchOverride(), 30_000);
    return () => { cancelled = true; clearInterval(t); };
  }, []);

  // Reset to first page whenever filters change so the user doesn't
  // land on a page that no longer has data.
  useEffect(() => { setPage(0); }, [businessDate, statusFilter, categoryFilter]);

  // Backstop polling — WS handles most state changes within ms, so we
  // only need a slow safety-net poll (60s) to catch any events the
  // client missed during a reconnect window.  Disabled entirely when
  // viewing a historical business_date (no live activity there).
  // BF-468 — use loadSilent so the spinner doesn't flash every 60s.
  useEffect(() => {
    if (businessDate !== todayUtcIso()) return undefined;
    const t = setInterval(loadSilent, 60_000);
    return () => clearInterval(t);
  }, [businessDate, loadSilent]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { total: rows.length, sla_breached: 0 };
    for (const s of STATUS_LIST) c[s] = 0;
    for (const r of rows) {
      c[r.status] = (c[r.status] ?? 0) + 1;
      if (r.sla_breached) c.sla_breached += 1;
    }
    return c;
  }, [rows]);

  // Phase 130 hotfix-13 — rerun supports per-execution backend override
  // (?backend=native|airflow) so admins can divert a single execution
  // when one side is degraded.  Confirms via window.confirm so the
  // caller knows which backend was used.
  const handleRerun = async (run: FeedRun, backend?: 'native' | 'airflow') => {
    if (!run.can_rerun) return;
    const label = backend ? ` via ${backend}` : '';
    if (!window.confirm(`Rerun ${run.feed_name || `Feed #${run.feed_config_id}`}${label}?`)) return;
    setBusy(true);
    // BF-468 — optimistic UI: flip the row's status to 'pending'
    // immediately so the user sees instant feedback, before waiting
    // for the backend (which can take a moment to register the
    // execution) and before the WS feed_progress event arrives.
    // If the API call fails, we restore the original status below.
    const _previousStatus = run.status;
    setRows((prev) => prev.map((r) =>
      r.id === run.id
        ? { ...r, status: 'pending', error: null, retry_count: (r.retry_count || 0) + 1 }
        : r,
    ));
    try {
      await api.rerunFeedRun(run.id, backend ? { backend } : undefined);
      // BF-468 — fast follow-up refresh so we get the authoritative
      // server status (pending → running) in 500 ms instead of
      // waiting 60 s for the next backstop poll.  Silent so the
      // spinner doesn't flash.
      setTimeout(() => { void loadSilent(); }, 500);
      setTimeout(() => { void loadSilent(); }, 3000);
      // BF-475 — green toast confirms the rerun was accepted by
      // the backend.  Status itself is reflected on the row
      // (already flipped to 'pending' optimistically above).
      addNotification({
        type: 'success',
        title: `Rerun triggered${backend ? ` via ${backend}` : ''}`,
        message: run.feed_name || `Feed #${run.feed_config_id}`,
      });
    } catch (e: any) {
      // Restore original status on failure so the dashboard reflects truth
      setRows((prev) => prev.map((r) =>
        r.id === run.id ? { ...r, status: _previousStatus } : r,
      ));
      // BF-475 — red toast surfaces the API error inline so the user
      // doesn't miss it (was buried in a long page-level error banner).
      addNotification({
        type: 'error',
        title: 'Rerun failed',
        message: e?.message || String(e),
      });
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
      setRerunMenu({ anchor: null, run: null });
    }
  };

  const handleBulkTrigger = async (backend?: 'native' | 'airflow') => {
    // When the user has selected specific rows via checkboxes, trigger
    // only those; otherwise use the status filter from the popup.
    const usingSelection = selectedIds.size > 0;
    if (!usingSelection && triggerStatuses.length === 0) {
      setError('Select at least one status (or check specific feeds) to trigger.');
      return;
    }
    setBusy(true);
    try {
      const payload = usingSelection
        ? { run_ids: Array.from(selectedIds) }
        : { business_date: businessDate, statuses: triggerStatuses };
      const r: any = await api.bulkRerunFeedRuns(payload, backend ? { backend } : undefined);
      setTriggerOpen(false);
      clearSelection();
      await load();
      // BF-475 — color-coded toast.  Green when at least one feed
      // triggered successfully and nothing failed; warning when
      // partial (triggered + denied/skipped); error when 0 triggered
      // OR any denied count > 0.
      const triggered = Number(r?.triggered ?? 0);
      const denied    = Number(r?.denied ?? 0);
      const skipped   = Number(r?.skipped_inactive ?? 0);
      const parts: string[] = [];
      if (r?.triggered != null) parts.push(`triggered ${triggered}`);
      if (denied)               parts.push(`${denied} denied (not your feeds)`);
      if (skipped)               parts.push(`${skipped} skipped (inactive)`);
      const summary = parts.length ? parts.join(', ') : 'No runs matched the filter.';
      let toneType: 'success' | 'error' | 'warning' | 'info';
      let title: string;
      if (triggered > 0 && denied === 0 && skipped === 0) {
        toneType = 'success'; title = `Triggered ${triggered} feed${triggered === 1 ? '' : 's'}`;
      } else if (triggered > 0) {
        toneType = 'warning'; title = `Triggered ${triggered} (with ${denied + skipped} skipped/denied)`;
      } else {
        toneType = 'error';   title = denied ? 'No runs triggered — all denied' : 'No runs matched';
      }
      addNotification({ type: toneType, title, message: summary });
    } catch (e: any) {
      // BF-475 — failures always red
      addNotification({
        type: 'error',
        title: 'Trigger failed',
        message: e?.message || String(e),
      });
    } finally {
      setBusy(false);
    }
  };

  const handleBulkCancel = async () => {
    if (selectedIds.size === 0) return;
    const pendingIds = rows
      .filter(r => selectedIds.has(r.id) && r.can_rerun && (r.status === 'pending' || r.status === 'skipped'))
      .map(r => r.id);
    if (pendingIds.length === 0) {
      setError('No pending/skipped rows selected to cancel.');
      return;
    }
    if (!window.confirm(`Cancel ${pendingIds.length} selected run(s)?`)) return;
    setBusy(true);
    try {
      // No bulk cancel endpoint — fire individual cancels in parallel.
      // OK for small selections; we limit it via the visible page anyway.
      await Promise.all(pendingIds.map(id => api.cancelFeedRun(id).catch(() => null)));
      clearSelection();
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleCancel = async (runId: number) => {
    if (!window.confirm(`Cancel feed run #${runId}?`)) return;
    setBusy(true);
    try {
      await api.cancelFeedRun(runId);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2 }}>
        <DashboardIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 600 }}>Feed Run Status</Typography>
        {/* Phase 131 deep-dive — live WS indicator.  Green when connected;
            grey-out when fallback polling.  Event-counter badge gives ops
            a quick "is the stream alive?" signal at a glance. */}
        <Tooltip title={
          wsConnected
            ? `Live · ${wsEventCount} updates received this session`
            : 'WebSocket disconnected — falling back to polling every 60s'
        }>
          <Chip
            size="small"
            icon={<BoltIcon sx={{ fontSize: 14 }} />}
            label={wsConnected ? `Live${wsEventCount > 0 ? ` · ${wsEventCount}` : ''}` : 'Polling'}
            color={wsConnected ? 'success' : 'default'}
            variant={wsConnected ? 'filled' : 'outlined'}
            sx={{ fontWeight: 500 }}
          />
        </Tooltip>
        <Box sx={{ flex: 1 }} />
        <Tooltip title="Manual refresh (auto-refreshes via WebSocket; this is a backstop)">
          <span>
            <IconButton size="small" onClick={() => void load()} disabled={loading}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </span>
        </Tooltip>
      </Stack>

      {/* Status tiles — clickable filters in lifecycle order.
          "Total" sits at the end as the catch-all summary + clear-filter
          shortcut.  Selected tile gets a coloured ring + lift effect. */}
      <Stack direction="row" spacing={1.5} sx={{ flexWrap: 'wrap', mb: 3 }}>
        <StatTile label="Pending"     value={counts.pending}   color="warning.main"
                  icon={<PendingIcon fontSize="small" />}
                  onClick={() => setStatusFilter(statusFilter === 'pending' ? '' : 'pending')}
                  selected={statusFilter === 'pending'} />
        <StatTile label="In Progress" value={counts.running}   color="info.main"
                  icon={<RunningIcon fontSize="small" />}
                  onClick={() => setStatusFilter(statusFilter === 'running' ? '' : 'running')}
                  selected={statusFilter === 'running'} />
        <StatTile label="Completed"   value={counts.completed} color="success.main"
                  icon={<DoneIcon fontSize="small" />}
                  onClick={() => setStatusFilter(statusFilter === 'completed' ? '' : 'completed')}
                  selected={statusFilter === 'completed'} />
        <StatTile label="Failed"      value={counts.failed}    color="error.main"
                  icon={<FailIcon fontSize="small" />}
                  onClick={() => setStatusFilter(statusFilter === 'failed' ? '' : 'failed')}
                  selected={statusFilter === 'failed'} />
        <StatTile label="Not Started" value={counts.skipped}   color="text.secondary"
                  icon={<SkipIcon fontSize="small" />}
                  onClick={() => setStatusFilter(statusFilter === 'skipped' ? '' : 'skipped')}
                  selected={statusFilter === 'skipped'} />
        <StatTile label="SLA Breached"
                  value={counts.sla_breached}
                  color={counts.sla_breached > 0 ? 'error.main' : 'text.secondary'}
                  icon={<BreachIcon fontSize="small" />} />
        <StatTile label="Total"       value={counts.total}     color="text.primary"
                  icon={<DashboardIcon fontSize="small" />}
                  onClick={() => setStatusFilter('')}
                  selected={statusFilter === ''}
                  emphasized />
      </Stack>

      {/* Filters + actions */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" spacing={2} alignItems="center" sx={{ flexWrap: 'wrap' }}>
          <TextField
            type="date"
            label="Business date"
            size="small"
            value={businessDate}
            onChange={e => setBusinessDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            sx={{ minWidth: 180 }}
          />
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel>Status</InputLabel>
            <Select
              value={statusFilter}
              label="Status"
              onChange={e => setStatusFilter(e.target.value)}
            >
              <MenuItem value=""><em>All</em></MenuItem>
              {STATUS_LIST.map(s => (
                <MenuItem key={s} value={s}>{s}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* BF-473 — frequency category filter.  Derived from the
              rows themselves so the dropdown only shows categories
              actually in use for the current business_date. */}
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel>Category</InputLabel>
            <Select
              value={categoryFilter}
              label="Category"
              onChange={e => setCategoryFilter(e.target.value)}
            >
              <MenuItem value=""><em>All categories</em></MenuItem>
              {Array.from(new Set(
                rows.map(r => r.frequency_category).filter(Boolean) as string[],
              )).sort().map(c => (
                <MenuItem key={c} value={c}>{c.toUpperCase()}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            startIcon={<RefreshIcon />}
            onClick={load}
            disabled={loading || busy}
          >Refresh</Button>
          {/* Bulk trigger — opens a popup to pick statuses to rerun.
              Permission is enforced server-side: rows the user can't
              touch are silently skipped + counted in the response. */}
          {/* Bulk-trigger by STATUS only — when checkboxes are
              selected, the floating Feed Control panel (bottom-right)
              is the primary action surface, not this button. */}
          {selectedIds.size === 0 && (
            <Button
              startIcon={<TriggerIcon />}
              onClick={() => setTriggerOpen(true)}
              disabled={busy}
              variant="outlined"
              size="small"
            >Trigger by status…</Button>
          )}
          {(loading || busy) && <CircularProgress size={20} />}
        </Stack>
      </Paper>

      {/* Phase 130 hotfix-13 — failover banner when backend_override
          is set to a non-default value.  halt = no executions; the
          others = forced one-sided routing.  Banner shows who set it
          and when so on-call knows whether to investigate. */}
      {backendOverride !== 'auto' && (
        <Alert
          severity={backendOverride === 'halt' ? 'error' : 'warning'}
          sx={{ mb: 2 }}
          icon={backendOverride === 'halt' ? <LockIcon /> : <BreachIcon />}
        >
          <strong>Backend override active: <code>{backendOverride}</code>.</strong>{' '}
          {backendOverride === 'halt' && (
            <>All feed executions are paused.  Pending rows hold until an admin flips the override back.</>
          )}
          {backendOverride === 'native_only' && (
            <>All feeds are routed to the native worker (Airflow side off or degraded).</>
          )}
          {backendOverride === 'airflow_only' && (
            <>All feeds are routed to Airflow (native side off or degraded).</>
          )}
          {overrideMeta?.updated_by && (
            <Typography variant="caption" display="block" sx={{ mt: 0.5 }}>
              Set by <strong>{overrideMeta.updated_by}</strong>
              {overrideMeta.updated_at && (
                <> at {new Date(overrideMeta.updated_at).toLocaleString()}</>
              )}
              . Admin → Feed Failover to change.
            </Typography>
          )}
        </Alert>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper>
        <Table size="small">
          <TableHead>
            <TableRow sx={{ '& .MuiTableCell-head': {
              fontWeight: 600,
              fontSize: '0.72rem',
              textTransform: 'uppercase',
              letterSpacing: 0.5,
              color: 'text.secondary',
              borderBottom: '2px solid',
              borderBottomColor: 'divider',
            }}}>
              <TableCell padding="checkbox">
                <Checkbox
                  size="small"
                  indeterminate={
                    selectedIds.size > 0 &&
                    !visibleRowIds.every(id => selectedIds.has(id))
                  }
                  checked={
                    visibleRowIds.length > 0 &&
                    visibleRowIds.every(id => selectedIds.has(id))
                  }
                  onChange={toggleSelectAllVisible}
                  disabled={visibleRowIds.length === 0}
                />
              </TableCell>
              <TableCell>Task Name</TableCell>
              <TableCell>SLA</TableCell>
              <TableCell>Start Time</TableCell>
              <TableCell>End Time</TableCell>
              <TableCell>Duration</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="right">Total Records</TableCell>
              <TableCell>Triggered By</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={10} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  {loading ? 'Loading…' : 'No feed runs for this date.'}
                </TableCell>
              </TableRow>
            )}
            {filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).flatMap(r => [
              <TableRow
                key={r.id}
                hover
                selected={selectedIds.has(r.id)}
                sx={{
                  // Interactive cue — coloured left border telegraphs
                  // row status without the eye having to find the chip.
                  borderLeft: '3px solid',
                  borderLeftColor:
                    r.status === 'completed' ? 'success.main'
                    : r.status === 'failed'  ? 'error.main'
                    : r.status === 'running' ? 'info.main'
                    : r.status === 'pending' ? 'warning.main'
                    : 'divider',
                }}
              >
                <TableCell padding="checkbox">
                  <Tooltip title={r.can_rerun ? '' : `View-only (owner: ${r.feed_owner || 'unknown'})`}>
                    <span>
                      <Checkbox
                        size="small"
                        checked={selectedIds.has(r.id)}
                        onChange={() => toggleRowSelected(r.id)}
                        disabled={!r.can_rerun}
                      />
                    </span>
                  </Tooltip>
                </TableCell>
                <TableCell>
                  <Stack direction="row" alignItems="center" gap={0.75} flexWrap="wrap">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {r.feed_name || `Feed #${r.feed_config_id}`}
                    </Typography>
                    {/* BF-478 — info icon: filename, file path, config, why-0-records */}
                    <FeedRunInfoIcon
                      feedConfigId={r.feed_config_id}
                      outputPath={r.output_path}
                      controlFilePath={r.control_file_path}
                      totalRows={r.total_rows}
                      fileSizeBytes={r.file_size_bytes}
                      status={r.status}
                      actionDecision={r.action_decision}
                      actionReason={r.action_reason}
                      startedAt={r.started_at}
                      completedAt={r.completed_at}
                      triggeredBy={r.triggered_by}
                      frequencyCategory={r.frequency_category}
                      error={r.error}
                    />
                    {/* BF-473 — operator category chip */}
                    {r.frequency_category && (
                      <Tooltip title={`Feed category: ${r.frequency_category}`}>
                        <Chip
                          size="small"
                          label={r.frequency_category.toUpperCase()}
                          variant="outlined"
                          sx={{ height: 18, fontSize: '0.6rem', fontWeight: 600 }}
                        />
                      </Tooltip>
                    )}
                    {/* Phase 130 hotfix-13 — operator-rerun counter.
                        Increments every time someone clicks Rerun /
                        Bulk-rerun.  Helps reviewers see when a row
                        keeps being re-fired (often a sign the
                        underlying source is intermittently failing). */}
                    {(r.retry_count ?? 0) > 0 && (
                      <Tooltip title={
                        `This row has been rerun ${r.retry_count} time${r.retry_count === 1 ? '' : 's'} ` +
                        `by an operator (excludes scheduled cron firings; ` +
                        `see Execution History for the full attempt log).`
                      }>
                        <Chip
                          size="small"
                          label={`rerun ${r.retry_count}×`}
                          color="info"
                          variant="outlined"
                          sx={{ height: 18, fontSize: '0.65rem' }}
                        />
                      </Tooltip>
                    )}
                  </Stack>
                  {r.feed_name && (
                    <Typography variant="caption" color="text.secondary">
                      #{r.feed_config_id}
                    </Typography>
                  )}
                </TableCell>
                <TableCell>
                  {r.sla_breached ? (
                    <Tooltip title={r.action_reason || 'SLA breached'}>
                      <Chip
                        icon={<BreachIcon />}
                        label="BREACHED"
                        color="error"
                        size="small"
                      />
                    </Tooltip>
                  ) : (
                    <Typography variant="caption" color="text.secondary">
                      {r.sla_to || '—'}
                    </Typography>
                  )}
                </TableCell>
                <TableCell>{_formatTime(r.started_at)}</TableCell>
                <TableCell>{_formatTime(r.completed_at)}</TableCell>
                <TableCell>
                  {/* Phase 130 hotfix-13 — stage breakdown tooltip.
                      Hover reveals per-stage seconds (status_running /
                      query_native / format_csv / deliver_s3 / ...) so
                      operators can see which stage is slow without
                      digging into logs. */}
                  {r.stage_timings && Object.keys(r.stage_timings).length > 0 ? (
                    <Tooltip title={
                      <Box>
                        <Typography variant="caption" sx={{ display: 'block', fontWeight: 600, mb: 0.5 }}>
                          Stage timings
                        </Typography>
                        {Object.entries(r.stage_timings)
                          .filter(([k]) => k !== 'row_count' && k !== 'query_output_bytes')
                          .sort()
                          .map(([k, v]) => (
                            <Typography key={k} variant="caption" sx={{ display: 'block' }}>
                              {k}: {typeof v === 'number' ? `${v.toFixed(2)}s` : String(v)}
                            </Typography>
                          ))}
                      </Box>
                    }>
                      <span style={{ cursor: 'help', textDecoration: 'underline dotted' }}>
                        {_formatDuration(r.started_at, r.completed_at, r.status)}
                      </span>
                    </Tooltip>
                  ) : (
                    _formatDuration(r.started_at, r.completed_at, r.status)
                  )}
                  {r.failed_stage && r.status === 'failed' && (
                    <Tooltip title={`Failed during the ${r.failed_stage} stage`}>
                      <Chip
                        size="small"
                        label={`stage: ${r.failed_stage}`}
                        color="error"
                        variant="outlined"
                        sx={{ ml: 0.5, fontSize: '0.65rem', height: 18 }}
                      />
                    </Tooltip>
                  )}
                  {/* Round 16: BQB-parity perf chip — shows stage_history
                      + log_lines for completed / failed / cancelled runs.
                      Only renders when feed_execution_id is known; the
                      chip itself handles "no data yet" empty-state. */}
                  {r.feed_execution_id != null && r.status !== 'pending' && (
                    <Box component="span" sx={{ ml: 0.5 }}>
                      <FeedExecutionPerformanceChip executionDbId={r.feed_execution_id} />
                    </Box>
                  )}
                  {/* Phase 131 deep-dive #7 (2026-05-18 revamp) — failure
                      error chip is now bigger + always-visible with the
                      FIRST LINE of the error (precursor warning included),
                      not just the first 60 chars.  Hover shows the full
                      sanitized error inline; click toggles the expanded
                      panel for copy/retry actions.  User report: "ui
                      doesnt show rigt errors" — the prior 60-char chip
                      was buried among 5+ other chips and easy to miss. */}
                  {r.status === 'failed' && r.error && (() => {
                    const fullErr = r.error || '';
                    const firstLine = fullErr.split('\n')[0];
                    const chipLabel = firstLine.length > 120
                      ? firstLine.slice(0, 120) + '…'
                      : firstLine;
                    const isOpen = expandedRunId === r.id;
                    return (
                      <Tooltip
                        title={
                          <Box sx={{ fontSize: 11, fontFamily: 'JetBrains Mono, Menlo, monospace',
                                     whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                                     maxWidth: 520 }}>
                            {fullErr}
                          </Box>
                        }
                        placement="bottom-start"
                      >
                        <Chip
                          size="small"
                          icon={<FailIcon sx={{ fontSize: 14 }} />}
                          label={chipLabel}
                          color="error"
                          variant={isOpen ? 'filled' : 'outlined'}
                          onClick={() => setExpandedRunId(isOpen ? null : r.id)}
                          sx={{ display: 'flex', ml: 0, mt: 0.5,
                                fontSize: '0.7rem', height: 22, maxWidth: 560,
                                fontWeight: 600, cursor: 'pointer',
                                '& .MuiChip-label': {
                                  textOverflow: 'ellipsis', overflow: 'hidden',
                                  px: 0.75,
                                } }}
                        />
                      </Tooltip>
                    );
                  })()}
                  {/* Phase 145.7 — richer live-progress chip during execution.
                      Shows: humanised stage name · elapsed seconds (live-ticking
                      via the 1s interval state, so the counter advances even
                      between WS events) · step count.  Tooltip surfaces the
                      full stage timeline so operators can see what happened
                      and roughly when.  Driven by feed_progress events;
                      cleared on the final state event. */}
                  {r.status === 'running' && liveStages[r.id] && (
                    <FeedLiveProgressChip lp={liveStages[r.id]} />
                  )}
                  {/* Phase 131-A — WAIT chip when feed is gated on
                      upstream deps that haven't landed yet for this
                      business_date.  Tooltip surfaces the action_reason
                      written by the dep poller. */}
                  {r.status === 'pending' && r.action_decision === 'WAIT' && (
                    <Tooltip title={r.action_reason || 'Waiting on upstream dependencies'}>
                      <Chip
                        size="small"
                        label="WAIT (deps)"
                        color="warning"
                        variant="outlined"
                        sx={{ ml: 0.5, fontSize: '0.65rem', height: 18 }}
                      />
                    </Tooltip>
                  )}
                  {/* Phase 130 hotfix-13 — per-execution backend-override
                      badge.  Shown when the run actually executed on a
                      DIFFERENT backend than the feed is configured for
                      (operator clicked "Rerun via native" / "Rerun via
                      airflow", or the global override flipped it). */}
                  {r.execution_backend && r.feed_configured_backend &&
                   r.execution_backend !== r.feed_configured_backend &&
                   r.feed_configured_backend !== 'auto' && (
                    <Tooltip title={
                      `Ran on ${r.execution_backend} (feed configured for ${r.feed_configured_backend}). ` +
                      `Either an operator overrode the backend on this rerun, OR the global override is forcing this routing.`
                    }>
                      <Chip
                        size="small"
                        label={`${r.execution_backend} override`}
                        color="warning"
                        variant="outlined"
                        sx={{ ml: 0.5, fontSize: '0.65rem', height: 18 }}
                      />
                    </Tooltip>
                  )}
                </TableCell>
                <TableCell>
                  {/* Per-feed status icon — colour-filled chip so each
                      row's state reads at a glance.  Matches the left-
                      border colour so eye + status read together. */}
                  <Chip
                    label={r.status}
                    color={STATUS_COLOR[r.status] || 'default'}
                    size="small"
                    icon={STATUS_ICON[r.status]}
                    variant="filled"
                    sx={{ fontWeight: 500, textTransform: 'uppercase', fontSize: '0.7rem' }}
                  />
                </TableCell>
                <TableCell align="right">{r.total_rows != null ? r.total_rows.toLocaleString() : '—'}</TableCell>
                <TableCell>
                  <Typography variant="caption">{r.triggered_by || '—'}</Typography>
                </TableCell>
                <TableCell align="right">
                  {/* Preview SQL — available to ALL viewers regardless of
                      can_rerun.  Read-only access lets end users see what
                      query is running without needing to own the feed. */}
                  <Tooltip title="Preview SQL">
                    <IconButton size="small"
                                onClick={() => setPreviewFeedId(r.feed_config_id)}>
                      <PreviewSqlIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  {/* Merged Action — one contextual button per row:
                       - pending  -> Cancel
                       - terminal (completed/failed/skipped/cancelled) -> Rerun
                       - running  -> no action (executing)
                      Owner-gated via can_rerun; non-owners see a lock
                      icon with explanatory tooltip. */}
                  {(() => {
                    const status = r.status;
                    const isTerminal = ['completed', 'failed', 'skipped', 'cancelled'].includes(status);
                    if (!r.can_rerun) {
                      return (
                        <Tooltip title={
                          `View-only. Owner: ${r.feed_owner || 'unknown'}. ` +
                          `Ask an admin or the owner to act on this run.`
                        }>
                          <span>
                            <IconButton size="small" disabled>
                              <LockIcon fontSize="small" sx={{ opacity: 0.4 }} />
                            </IconButton>
                          </span>
                        </Tooltip>
                      );
                    }
                    if (status === 'pending') {
                      return (
                        <Tooltip title="Cancel this pending run">
                          <IconButton size="small" onClick={() => handleCancel(r.id)} disabled={busy} color="warning">
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      );
                    }
                    if (isTerminal) {
                      // Phase 130 hotfix-13 — Rerun button opens a small
                      // menu so admins can pick which backend to use
                      // (auto / native / airflow).  Useful when one
                      // side is degraded and you want to push a single
                      // rerun via the other path without flipping the
                      // global override.
                      return (
                        <Tooltip title="Rerun (click to pick backend)">
                          <IconButton size="small"
                            onClick={(e) => setRerunMenu({ anchor: e.currentTarget, run: r })}
                            disabled={busy} color="primary">
                            <ReplayIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      );
                    }
                    // running — show a spinner-style disabled icon
                    return (
                      <Tooltip title="Currently executing">
                        <span>
                          <IconButton size="small" disabled>
                            <RunningIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                    );
                  })()}
                  {/* Phase 132.27 — live log tail for the active execution.
                      Bound to feed_execution_id (DB numeric); WS events
                      carry exec_db_id so the dialog filters precisely. */}
                  {r.feed_execution_id != null && (
                    <Tooltip title="Live log tail">
                      <IconButton size="small"
                        onClick={() => setLogsExecId(String(r.feed_execution_id))}>
                        <TerminalIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                </TableCell>
              </TableRow>,
              /* Phase 131 deep-dive #7 — expanded error panel.  When the
                 user clicks the failure chip we render a full-width row
                 below the failed row with the complete sanitized error
                 (matches BQB's inline Alert pattern).  Click again to
                 collapse.  Only failed runs with error text render this. */
              expandedRunId === r.id && r.status === 'failed' && r.error && (
                <TableRow key={`${r.id}-error`} sx={{ borderLeft: '3px solid', borderLeftColor: 'error.main' }}>
                  <TableCell colSpan={11} sx={{ bgcolor: 'error.lighter', py: 1.5 }}>
                    <Stack direction="row" spacing={1} alignItems="flex-start">
                      <FailIcon fontSize="small" color="error" sx={{ mt: 0.5 }} />
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ fontWeight: 600, color: 'error.dark', display: 'block', mb: 0.5 }}>
                          {r.failed_stage
                            ? `Failed during '${r.failed_stage}' stage`
                            : 'Execution failed'}
                          {r.feed_name ? ` · ${r.feed_name}` : ''}
                        </Typography>
                        <Box sx={{
                          fontFamily: 'JetBrains Mono, Menlo, monospace',
                          fontSize: 11, lineHeight: 1.5,
                          color: 'text.primary',
                          whiteSpace: 'pre-wrap',
                          wordBreak: 'break-word',
                          bgcolor: 'background.paper', p: 1, borderRadius: 0.5,
                          border: 1, borderColor: 'error.light',
                          maxHeight: 240, overflowY: 'auto',
                        }}>
                          {r.error}
                        </Box>
                        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                          <Button size="small" startIcon={<ReplayIcon fontSize="small" />}
                            disabled={!r.can_rerun}
                            onClick={() => r.can_rerun && void handleRerun(r)}>
                            Retry this run
                          </Button>
                          <Button size="small"
                            onClick={() => {
                              try { void navigator.clipboard.writeText(r.error || ''); }
                              catch { /* ignore */ }
                            }}>
                            Copy error
                          </Button>
                          <Button size="small" onClick={() => setExpandedRunId(null)}>
                            Close
                          </Button>
                        </Stack>
                      </Box>
                    </Stack>
                  </TableCell>
                </TableRow>
              ),
            ])}
            </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={rows.length}
          page={page}
          onPageChange={(_, p) => setPage(p)}
          rowsPerPage={rowsPerPage}
          rowsPerPageOptions={[10, 25, 50, 100, 200]}
          onRowsPerPageChange={e => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
        />
      </Paper>

      {/* Floating "Feed Control" action panel — AutoSys-style multi-
          action with per-row status breakdown.  Anchored bottom-right,
          slides in when any checkbox is selected. */}
      {(() => {
        const selectedRows = rows.filter(r => selectedIds.has(r.id));
        const counts = {
          completed: selectedRows.filter(r => r.status === 'completed').length,
          failed:    selectedRows.filter(r => r.status === 'failed').length,
          skipped:   selectedRows.filter(r => r.status === 'skipped').length,
          cancelled: selectedRows.filter(r => r.status === 'cancelled').length,
        };
        const totalTerminal = counts.completed + counts.failed + counts.skipped + counts.cancelled;
        return (
          <Paper
            elevation={8}
            sx={{
              position: 'fixed',
              bottom: 24,
              right: 24,
              minWidth: 280,
              p: 2.5,
              borderRadius: 2,
              zIndex: 1300,
              transition: 'transform 0.25s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s',
              transform: selectedIds.size > 0 ? 'translateY(0)' : 'translateY(120%)',
              opacity: selectedIds.size > 0 ? 1 : 0,
              pointerEvents: selectedIds.size > 0 ? 'auto' : 'none',
              background: 'linear-gradient(180deg, var(--mui-palette-background-paper) 0%, var(--mui-palette-background-default) 100%)',
              border: '1px solid',
              borderColor: 'divider',
            }}
          >
            <Stack spacing={1.5}>
              <Stack direction="row" alignItems="center" justifyContent="space-between">
                <Stack>
                  <Typography variant="overline" sx={{ color: 'text.secondary', fontSize: '0.65rem', lineHeight: 1 }}>
                    Feed Control
                  </Typography>
                  <Typography variant="body2" sx={{ mt: 0.5, fontWeight: 600 }}>
                    {selectedIds.size} selected
                  </Typography>
                </Stack>
                <Tooltip title="Per-row breakdown of selection by status">
                  <InfoIcon fontSize="small" sx={{ color: 'text.disabled' }} />
                </Tooltip>
              </Stack>

              {/* Selection status mini-summary */}
              <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', gap: 0.5 }}>
                {counts.completed > 0 && (
                  <Chip size="small" label={`${counts.completed} done`} color="success"
                        icon={<DoneIcon />} sx={{ height: 22 }} />
                )}
                {counts.failed > 0 && (
                  <Chip size="small" label={`${counts.failed} failed`} color="error"
                        icon={<FailIcon />} sx={{ height: 22 }} />
                )}
                {counts.skipped > 0 && (
                  <Chip size="small" label={`${counts.skipped} not started`}
                        icon={<SkipIcon />} sx={{ height: 22 }} />
                )}
                {counts.cancelled > 0 && (
                  <Chip size="small" label={`${counts.cancelled} cancelled`}
                        icon={<CancelIcon />} sx={{ height: 22 }} />
                )}
              </Stack>

              <Divider />

              {/* Phase 130 hotfix-13 — bulk-rerun backend selector.
                  Three-chip toggle so the operator picks once for the
                  whole selection.  'auto' = honour per-feed setting +
                  global override (default).  'native' / 'airflow' =
                  force the entire bulk through one path. */}
              <Box>
                <Typography variant="overline" sx={{ color: 'text.secondary', fontSize: '0.6rem', display: 'block', mb: 0.5 }}>
                  Bulk backend
                </Typography>
                <Stack direction="row" gap={0.5}>
                  {(['auto', 'native', 'airflow'] as const).map((b) => (
                    <Chip
                      key={b}
                      label={b}
                      size="small"
                      color={bulkBackend === b ? 'primary' : 'default'}
                      variant={bulkBackend === b ? 'filled' : 'outlined'}
                      onClick={() => setBulkBackend(b)}
                      clickable
                      sx={{ height: 22, fontSize: '0.7rem' }}
                    />
                  ))}
                </Stack>
              </Box>

              {/* AutoSys-style action set — only show actions that
                  would actually affect the selection */}
              <Button
                startIcon={<TriggerIcon />}
                onClick={() => handleBulkTrigger(bulkBackend === 'auto' ? undefined : bulkBackend)}
                disabled={busy || totalTerminal === 0}
                variant="contained"
                color="success"
                size="small"
                fullWidth
                sx={{ justifyContent: 'flex-start' }}
              >Start ({totalTerminal}){bulkBackend !== 'auto' ? ` via ${bulkBackend}` : ''}</Button>

              <Button
                startIcon={<TriggerIcon />}
                onClick={async () => {
                  if (!window.confirm(`Force-start ${selectedIds.size} feed(s)?  Bypasses ACTION_CONDITION skip rules.`)) return;
                  setBusy(true);
                  try {
                    // Force-start = same as bulk-rerun for now; the
                    // server will honour terminal-only.  A future
                    // hotfix can add a /force endpoint that overrides
                    // the SKIP decision.
                    const r: any = await api.bulkRerunFeedRuns({
                      run_ids: Array.from(selectedIds),
                    });
                    clearSelection();
                    await load();
                    setError(`Force-start: triggered ${r?.triggered ?? 0}, denied ${r?.denied ?? 0}, skipped ${(r?.skipped_inactive ?? 0) + (r?.skipped_non_terminal ?? 0)}`);
                  } catch (e: any) { setError(e?.message || String(e)); }
                  finally { setBusy(false); }
                }}
                disabled={busy || selectedIds.size === 0}
                variant="outlined"
                color="primary"
                size="small"
                fullWidth
                sx={{ justifyContent: 'flex-start' }}
              >Force Start</Button>

              <Button
                startIcon={<CancelIcon />}
                onClick={handleBulkCancel}
                disabled={busy}
                variant="outlined"
                color="warning"
                size="small"
                fullWidth
                sx={{ justifyContent: 'flex-start' }}
              >Cancel Pending</Button>

              <Button
                onClick={clearSelection}
                disabled={busy}
                variant="text"
                size="small"
                fullWidth
                sx={{ justifyContent: 'flex-start', color: 'text.secondary' }}
              >Deselect All</Button>
            </Stack>
          </Paper>
        );
      })()}

      {/* Bulk Trigger popup */}
      <Dialog open={triggerOpen} onClose={() => setTriggerOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Trigger Feed Runs</DialogTitle>
        <DialogContent dividers>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Rerun all feeds on <strong>{businessDate}</strong> matching the selected statuses.
            Server enforces ownership — feeds you don't own will be silently skipped.
          </Typography>
          <FormGroup>
            {STATUS_LIST.map(s => (
              <FormControlLabel
                key={s}
                control={
                  <Checkbox
                    checked={triggerStatuses.includes(s)}
                    onChange={e => {
                      if (e.target.checked) {
                        setTriggerStatuses(prev => [...prev, s]);
                      } else {
                        setTriggerStatuses(prev => prev.filter(x => x !== s));
                      }
                    }}
                  />
                }
                label={
                  <Stack direction="row" spacing={1} alignItems="center">
                    {STATUS_ICON[s]}
                    <span style={{ textTransform: 'capitalize' }}>{s}</span>
                    <Chip label={String(counts[s] ?? 0)} size="small" />
                  </Stack>
                }
              />
            ))}
          </FormGroup>
          <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
            <Button size="small" onClick={() => setTriggerStatuses([...STATUS_LIST])}>Select all</Button>
            <Button size="small" onClick={() => setTriggerStatuses([])}>Clear</Button>
            <Button size="small" onClick={() => setTriggerStatuses(['failed'])}>Failed only</Button>
            <Button size="small" onClick={() => setTriggerStatuses(['pending', 'skipped'])}>Unrun</Button>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTriggerOpen(false)} disabled={busy}>Cancel</Button>
          <Button
            variant="contained"
            onClick={() => handleBulkTrigger()}
            disabled={busy || triggerStatuses.length === 0}
            startIcon={<TriggerIcon />}
          >
            Trigger ({triggerStatuses.reduce((acc, s) => acc + (counts[s] ?? 0), 0)} runs)
          </Button>
        </DialogActions>
      </Dialog>

      {/* Phase 130 hotfix-13 — Rerun-with-backend menu, anchored to
          the per-row Rerun button.  Three choices: Auto (honour
          per-feed setting + size router), Native (force native),
          Airflow (force airflow).  Calls /rerun?backend=... */}
      <Menu
        anchorEl={rerunMenu.anchor}
        open={Boolean(rerunMenu.anchor)}
        onClose={() => setRerunMenu({ anchor: null, run: null })}
      >
        <MenuItem onClick={() => rerunMenu.run && void handleRerun(rerunMenu.run)} disabled={busy}>
          <ListItemIcon><RouterIcon fontSize="small" /></ListItemIcon>
          <ListItemText
            primary="Rerun (auto)"
            secondary="Honour per-feed + global override"
          />
        </MenuItem>
        <MenuItem onClick={() => rerunMenu.run && void handleRerun(rerunMenu.run, 'native')} disabled={busy}>
          <ListItemIcon><RouterIcon fontSize="small" /></ListItemIcon>
          <ListItemText
            primary="Rerun via native"
            secondary="In-process DuckDB worker"
          />
        </MenuItem>
        <MenuItem onClick={() => rerunMenu.run && void handleRerun(rerunMenu.run, 'airflow')} disabled={busy}>
          <ListItemIcon><RouterIcon fontSize="small" /></ListItemIcon>
          <ListItemText
            primary="Rerun via Airflow"
            secondary="Spark on Kubernetes (big feeds)"
          />
        </MenuItem>
      </Menu>

      {/* Reusable preview dialog — same component used by FeedConfigsPage. */}
      <FeedSqlPreviewDialog
        open={previewFeedId != null}
        feedId={previewFeedId}
        onClose={() => setPreviewFeedId(null)}
      />

      {/* Phase 132.27 — Live log tail dialog */}
      <FeedLiveLogDialog
        execDbId={logsExecId}
        onClose={() => setLogsExecId(null)}
      />
    </Box>
  );
};

// ── Phase 132.27 — Live log tail dialog for a feed execution ────────────
const FeedLiveLogDialog: React.FC<{
  execDbId: string | null; onClose: () => void;
}> = ({ execDbId, onClose }) => {
  const ws = useWebSocket();
  const [lines, setLines] = useState<Array<{
    at: string; level: string; line: string;
  }>>([]);
  const [paused, setPaused] = useState(false);
  const MAX_LINES = 1000;

  useEffect(() => {
    if (!ws?.addListener || !execDbId) return;
    const target = Number(execDbId);
    const handler = (msg: any) => {
      if (!msg || msg.event !== 'feed_run_log') return;
      if (msg.exec_db_id !== target) return;
      if (paused) return;
      setLines(prev => {
        const next = prev.concat([{
          at: msg.at, level: msg.level, line: msg.line,
        }]);
        return next.length > MAX_LINES ? next.slice(-MAX_LINES) : next;
      });
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, execDbId, paused]);

  useEffect(() => {
    if (execDbId === null) setLines([]);
  }, [execDbId]);

  const levelColor: Record<string, string> = {
    INFO: '#e0e0e0', WARNING: '#ffb74d', ERROR: '#ef5350',
    DEBUG: '#888',
  };

  return (
    <Dialog open={execDbId !== null} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Stack direction="row" alignItems="center" spacing={1}>
          <Typography>Live logs — execution #{execDbId}</Typography>
          <Chip label={`${lines.length}${lines.length >= MAX_LINES ? ' (capped)' : ''}`}
                size="small" variant="outlined" sx={{ fontSize: 10 }} />
          <Box sx={{ flex: 1 }} />
          <Button size="small" onClick={() => setPaused(p => !p)}>
            {paused ? 'Resume' : 'Pause'}
          </Button>
          <Button size="small" onClick={() => setLines([])}>Clear</Button>
        </Stack>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ p: 1, height: 480, overflow: 'auto',
                    fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                    background: '#1e1e1e', color: '#e0e0e0', borderRadius: 1 }}>
          {lines.length === 0 && (
            <Typography variant="caption" sx={{ color: '#888' }}>
              Waiting for log lines… (live-tail starts as soon as the next
              feed_engine logger.info() fires).
            </Typography>
          )}
          {lines.map((l, i) => (
            <Box key={i} sx={{ whiteSpace: 'pre-wrap', mb: 0.25 }}>
              <span style={{ color: '#888' }}>
                {(l.at || '').slice(11, 19)}
              </span>{' '}
              <span style={{ color: levelColor[l.level] || '#e0e0e0',
                              fontWeight: l.level === 'ERROR' ? 600 : 400 }}>
                [{l.level || 'INFO'}]
              </span>{' '}
              {l.line}
            </Box>
          ))}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">Close</Button>
      </DialogActions>
    </Dialog>
  );
};

const StatTile: React.FC<{
  label: string;
  value: number;
  color?: string;
  icon?: React.ReactNode;
  onClick?: () => void;
  selected?: boolean;
  /** When true, render with a slightly bolder treatment (used for "Total"). */
  emphasized?: boolean;
}> =
  ({ label, value, color = 'text.primary', icon, onClick, selected, emphasized }) => (
  <Paper
    onClick={onClick}
    elevation={selected ? 3 : 0}
    variant={selected ? 'elevation' : 'outlined'}
    sx={{
      px: 2, py: 1.5, minWidth: 130, flex: '1 1 130px',
      cursor: onClick ? 'pointer' : 'default',
      borderRadius: 2,
      borderLeft: '4px solid',
      borderLeftColor: selected ? color : (emphasized ? 'text.primary' : 'divider'),
      transition: 'all 0.18s cubic-bezier(0.4, 0, 0.2, 1)',
      backgroundColor: selected ? 'action.selected' : 'background.paper',
      position: 'relative',
      overflow: 'hidden',
      '&::after': selected ? {
        content: '""',
        position: 'absolute', top: 0, right: 0, width: 32, height: 32,
        background: `radial-gradient(circle at top right, ${typeof color === 'string' && color.includes('.') ? '' : color} 0%, transparent 70%)`,
        opacity: 0.15,
        pointerEvents: 'none',
      } : undefined,
      '&:hover': onClick ? {
        borderLeftColor: color,
        backgroundColor: selected ? 'action.selected' : 'action.hover',
        transform: 'translateY(-2px)',
        boxShadow: selected ? 6 : 1,
      } : {},
    }}
  >
    <Stack direction="row" alignItems="center" spacing={0.75}>
      {icon && <Box sx={{ color, display: 'flex', alignItems: 'center' }}>{icon}</Box>}
      <Typography
        variant="overline"
        sx={{
          color: 'text.secondary',
          fontSize: '0.65rem',
          letterSpacing: 0.7,
          lineHeight: 1,
        }}
      >
        {label}
      </Typography>
    </Stack>
    <Typography
      variant="h5"
      sx={{
        color,
        mt: 0.75,
        fontWeight: emphasized ? 700 : 600,
        lineHeight: 1.1,
      }}
    >
      {value}
    </Typography>
  </Paper>
);

// ── Formatters ────────────────────────────────────────────────────────

const _formatTime = (iso?: string | null): string => {
  if (!iso) return '—';
  // ISO has 'YYYY-MM-DDTHH:MM:SS' — take 11..19 for HH:MM:SS
  return iso.slice(11, 19) || '—';
};

const _formatDuration = (
  started?: string | null,
  completed?: string | null,
  status?: string,
): string => {
  if (!started) return '—';
  const start = Date.parse(started);
  if (Number.isNaN(start)) return '—';
  const end = completed ? Date.parse(completed) : Date.now();
  if (Number.isNaN(end) || end < start) return '—';
  const secs = Math.floor((end - start) / 1000);
  const hh = Math.floor(secs / 3600);
  const mm = Math.floor((secs % 3600) / 60);
  const ss = secs % 60;
  const formatted = hh > 0
    ? `${hh}h ${mm}m ${ss}s`
    : mm > 0
      ? `${mm}m ${ss}s`
      : `${ss}s`;
  // Append "·" suffix for runs still in progress so it's clear the
  // duration is the elapsed clock, not the final total.
  if (status === 'running' && !completed) return `${formatted} · running`;
  return formatted;
};

export default FeedTodayPage;
