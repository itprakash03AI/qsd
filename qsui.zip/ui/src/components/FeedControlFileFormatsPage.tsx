/**
 * FeedControlFileFormatsPage — Phase 130 hotfix-4
 *
 * Admin UI for the feed_control_file_formats table.  Each row defines
 * one CTL layout + checksum combination.  Feeds reference rows by id
 * via feed_configs.control_file_format_id.
 *
 * No hardcoded format logic — admin can edit every field including the
 * checksum algorithm list (MD5 FIPS-safe, SHA-1, SHA-256, SHA-512,
 * CRC32) and per-field labels / widths / formats.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Stack, Alert, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, FormControlLabel, Switch, Chip, FormControl, InputLabel,
  Select, MenuItem, Divider, Tooltip,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Refresh as RefreshIcon, AutoFixHigh as SeedIcon,
  ContentCopy as CopyIcon,
} from '@mui/icons-material';
import api from '../services/api';

const ALL_FIELDS = [
  'filename', 'row_count', 'byte_size',
  'checksum_md5', 'checksum_sha1', 'checksum_sha256',
  'checksum_sha512', 'checksum_crc32',
  'business_date', 'feed_name', 'feed_id', 'run_id', 'generated_at',
];

const ALGORITHM_BADGES: Record<string, 'default' | 'primary' | 'secondary' | 'warning' | 'info' | 'success'> = {
  md5:    'warning',
  sha1:   'warning',
  sha256: 'success',
  sha512: 'success',
  crc32:  'info',
  none:   'default',
};

type ControlFileFormat = {
  id: number;
  name: string;
  description?: string | null;
  style: string;
  delimiter: string;
  fields?: string[] | null;
  field_specs?: Record<string, any> | null;
  checksum_algorithm?: string | null;
  checksum_algorithms?: string[] | null;
  date_format?: string | null;
  datetime_format?: string | null;
  is_active: boolean;
  is_default: boolean;
  created_by?: string | null;
  created_at?: string | null;
};

const FeedControlFileFormatsPage: React.FC = () => {
  const [rows, setRows] = useState<ControlFileFormat[]>([]);
  const [algos, setAlgos] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<ControlFileFormat | null>(null);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [list, algoResp]: any = await Promise.all([
        api.listControlFileFormats(),
        api.listChecksumAlgorithms().catch(() => ({ algorithms: [] })),
      ]);
      const items: ControlFileFormat[] = Array.isArray(list) ? list : (list?.items ?? []);
      setRows(items);
      setAlgos((algoResp?.algorithms || []) as string[]);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const seed = async () => {
    setBusy(true);
    try {
      const r: any = await api.seedDefaultControlFileFormats();
      await load();
      if (r?.inserted === 0) {
        setError('All defaults already exist — nothing inserted.');
      }
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!window.confirm(`Delete format "${name}"?  Feeds referencing it will fall back to the default layout.`)) return;
    try {
      await api.deleteControlFileFormat(id);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Stack>
          <Typography variant="h5">Control File Formats</Typography>
          <Typography variant="caption" color="text.secondary">
            Define how the sidecar .ctl manifest renders (layout, checksum algorithms, field labels).  Feeds reference rows by id.
          </Typography>
        </Stack>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
          <Button startIcon={<SeedIcon />} onClick={seed} disabled={busy}>Seed defaults</Button>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setCreating(true)}>
            New format
          </Button>
        </Stack>
      </Stack>

      {error && (
        <Alert severity="info" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Style</TableCell>
              <TableCell>Delimiter</TableCell>
              <TableCell>Fields</TableCell>
              <TableCell>Checksums</TableCell>
              <TableCell>Active</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow>
                <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                  <CircularProgress size={22} />
                </TableCell>
              </TableRow>
            )}
            {!loading && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  No formats yet — click <strong>Seed defaults</strong> for predefined templates, or <strong>New format</strong> to design your own.
                </TableCell>
              </TableRow>
            )}
            {rows.map(r => {
              const algoList = (r.checksum_algorithms && r.checksum_algorithms.length > 0)
                ? r.checksum_algorithms
                : (r.checksum_algorithm ? [r.checksum_algorithm] : []);
              return (
                <TableRow key={r.id} hover>
                  <TableCell>{r.id}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <strong>{r.name}</strong>
                      {r.is_default && <Chip label="default" size="small" color="primary" />}
                    </Stack>
                    {r.description && (
                      <Typography variant="caption" color="text.secondary"
                                  display="block" sx={{ mt: 0.5 }}>
                        {r.description}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Chip label={r.style} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell>
                    {r.style !== 'key_value' && (
                      <code>{r.delimiter}</code>
                    )}
                  </TableCell>
                  <TableCell>
                    <Tooltip title={(r.fields || []).join(', ') || '(default)'}>
                      <span>{(r.fields || []).length || '—'}</span>
                    </Tooltip>
                  </TableCell>
                  <TableCell>
                    {algoList.length === 0 ? (
                      <Chip label="none" size="small" />
                    ) : algoList.map((a, i) => (
                      <Chip
                        key={i}
                        label={a.toUpperCase()}
                        size="small"
                        color={ALGORITHM_BADGES[a] || 'default'}
                        sx={{ mr: 0.5 }}
                      />
                    ))}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={r.is_active ? 'Active' : 'Inactive'}
                      color={r.is_active ? 'success' : 'default'}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="right">
                    <IconButton size="small" onClick={() => setEditing(r)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" onClick={() => handleDelete(r.id, r.name)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>

      {creating && (
        <FormatDialog
          algos={algos}
          allFields={ALL_FIELDS}
          onClose={() => setCreating(false)}
          onSaved={async () => { setCreating(false); await load(); }}
        />
      )}
      {editing && (
        <FormatDialog
          algos={algos}
          allFields={ALL_FIELDS}
          existing={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => { setEditing(null); await load(); }}
        />
      )}
    </Box>
  );
};


/* ── Create / Edit dialog ─────────────────────────────────────────── */

const FormatDialog: React.FC<{
  algos: string[];
  allFields: string[];
  existing?: ControlFileFormat;
  onClose: () => void;
  onSaved: () => void;
}> = ({ algos, allFields, existing, onClose, onSaved }) => {
  const isEdit = !!existing;
  const [name, setName] = useState(existing?.name || '');
  const [description, setDescription] = useState(existing?.description || '');
  const [style, setStyle] = useState(existing?.style || 'key_value');
  const [delimiter, setDelimiter] = useState(existing?.delimiter || '|');
  const [fields, setFields] = useState<string[]>(existing?.fields || []);
  const [fieldSpecs, setFieldSpecs] = useState<Record<string, any>>(
    existing?.field_specs || {},
  );
  const [algorithms, setAlgorithms] = useState<string[]>(
    existing?.checksum_algorithms && existing.checksum_algorithms.length > 0
      ? existing.checksum_algorithms
      : (existing?.checksum_algorithm ? [existing.checksum_algorithm] : ['sha256']),
  );
  const [dateFormat, setDateFormat] = useState(existing?.date_format || '%Y%m%d');
  const [datetimeFormat, setDatetimeFormat] = useState(
    existing?.datetime_format || '%Y-%m-%dT%H:%M:%SZ',
  );
  const [isActive, setIsActive] = useState(existing?.is_active ?? true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const toggleField = (f: string) => {
    setFields(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const toggleAlgorithm = (a: string) => {
    setAlgorithms(prev => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]);
  };

  const editLabel = (f: string, label: string) => {
    setFieldSpecs(prev => ({
      ...prev,
      [f]: { ...(prev[f] || {}), label },
    }));
  };

  const handleSave = async () => {
    if (!name.trim()) { setErr('Name is required'); return; }
    setBusy(true); setErr(null);
    try {
      const payload: any = {
        name: name.trim(),
        description: description.trim() || null,
        style,
        delimiter,
        fields: fields.length > 0 ? fields : null,
        field_specs: Object.keys(fieldSpecs).length > 0 ? fieldSpecs : null,
        checksum_algorithm: algorithms.length === 1 ? algorithms[0] : (algorithms.length === 0 ? 'none' : null),
        checksum_algorithms: algorithms.length > 1 ? algorithms : null,
        date_format: dateFormat || null,
        datetime_format: datetimeFormat || null,
        is_active: isActive,
      };
      if (isEdit) {
        await api.updateControlFileFormat(existing!.id, payload);
      } else {
        await api.createControlFileFormat(payload);
      }
      onSaved();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>{isEdit ? `Edit ${existing?.name}` : 'New control file format'}</DialogTitle>
      <DialogContent dividers>
        {err && <Alert severity="error" sx={{ mb: 2 }}>{err}</Alert>}
        <Stack spacing={2}>
          <TextField label="Name" value={name} onChange={e => setName(e.target.value)}
                     required fullWidth size="small" disabled={isEdit}
                     helperText={isEdit ? 'Name cannot be changed after creation' : 'Lowercase + underscores recommended (e.g. enterprise_kv_md5)'} />
          <TextField label="Description" value={description} onChange={e => setDescription(e.target.value)}
                     fullWidth size="small" multiline rows={2} />

          <Divider />
          <Typography variant="subtitle2">Layout</Typography>

          <Stack direction="row" spacing={2}>
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Style</InputLabel>
              <Select value={style} label="Style" onChange={e => setStyle(e.target.value)}>
                <MenuItem value="key_value">key_value — FIELD=value per line</MenuItem>
                <MenuItem value="delimited">delimited — single line, delimiter-joined</MenuItem>
                <MenuItem value="fixed_width">fixed_width — padded fields, no separators</MenuItem>
              </Select>
            </FormControl>
            {style !== 'key_value' && (
              <TextField label="Delimiter" value={delimiter}
                         onChange={e => setDelimiter(e.target.value)}
                         size="small" sx={{ width: 100 }} />
            )}
          </Stack>

          <Typography variant="subtitle2">Fields (in output order)</Typography>
          <Typography variant="caption" color="text.secondary">
            Click to toggle.  Click again to remove.  Order matches click order.
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
            {allFields.map(f => (
              <Chip
                key={f}
                label={f}
                size="small"
                color={fields.includes(f) ? 'primary' : 'default'}
                variant={fields.includes(f) ? 'filled' : 'outlined'}
                onClick={() => toggleField(f)}
              />
            ))}
          </Box>
          {fields.length > 0 && (
            <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>
              Order: {fields.join(' → ')}
            </Typography>
          )}

          {fields.length > 0 && (
            <>
              <Typography variant="subtitle2">Per-field labels (optional)</Typography>
              <Typography variant="caption" color="text.secondary">
                Override the default UPPERCASE label.  Blank = use default.
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1 }}>
                {fields.map(f => (
                  <TextField
                    key={f}
                    size="small"
                    label={`${f} label`}
                    placeholder={f.toUpperCase()}
                    value={fieldSpecs[f]?.label || ''}
                    onChange={e => editLabel(f, e.target.value)}
                  />
                ))}
              </Box>
            </>
          )}

          <Divider />
          <Typography variant="subtitle2">Checksum algorithms</Typography>
          <Typography variant="caption" color="text.secondary">
            Computed on the COMPRESSED data file (post-zip).  Select multiple for defence in depth — they all hash in a single read pass.
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
            {algos.filter(a => a !== 'none').map(a => (
              <Chip
                key={a}
                label={a.toUpperCase()}
                size="small"
                color={algorithms.includes(a) ? 'primary' : 'default'}
                variant={algorithms.includes(a) ? 'filled' : 'outlined'}
                onClick={() => toggleAlgorithm(a)}
              />
            ))}
          </Box>
          {algorithms.includes('md5') && (
            <Alert severity="info" sx={{ mt: 1 }}>
              <strong>MD5 on OpenShift / FIPS:</strong> handled automatically via
              {' '}<code>hashlib.md5(..., usedforsecurity=False)</code> —
              the FIPS-safe pattern.  Output is byte-for-byte identical to standard MD5.
            </Alert>
          )}

          <Divider />
          <Typography variant="subtitle2">Date formats (strftime)</Typography>
          <Stack direction="row" spacing={2}>
            <TextField label="Date format" value={dateFormat}
                       onChange={e => setDateFormat(e.target.value)}
                       size="small" sx={{ flex: 1 }}
                       helperText="e.g. %Y%m%d → 20260515" />
            <TextField label="Datetime format" value={datetimeFormat}
                       onChange={e => setDatetimeFormat(e.target.value)}
                       size="small" sx={{ flex: 1 }}
                       helperText="e.g. %Y-%m-%dT%H:%M:%SZ" />
          </Stack>

          <FormControlLabel
            control={<Switch checked={isActive} onChange={e => setIsActive(e.target.checked)} />}
            label="Active (feeds can pick this format)"
          />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={busy}>
          {busy ? <CircularProgress size={16} /> : (isEdit ? 'Save' : 'Create')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FeedControlFileFormatsPage;
