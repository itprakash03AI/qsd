/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowDagCanvas — visual DAG editor for a DataFlow.
 *
 * Uses @xyflow/react (already a project dep) + dagre for auto-layout.
 * Each stage = a node.  Predecessors = edges.  Click a node → side
 * drawer with the schema-driven config form (rendered from each stage
 * type's CONFIG_SCHEMA).  Drag a stage type out of the palette to add a
 * new node.  Save serialises the DAG back to the WorkflowSpec shape the
 * backend already understands.
 *
 * Architecture (single responsibility per class / hook):
 *   • StagePalette  — list of registered stage types, draggable to canvas.
 *   • StageNode      — react-flow node renderer (alias chip + type chip).
 *   • ConfigDrawer   — slide-in panel; renders inputs from CONFIG_SCHEMA.
 *   • DataFlowDagCanvas (default export) — wires the three together.
 *
 * The DAG model is the single source of truth — the linear list in
 * DataFlowBuilderPage now just hosts this canvas.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  ReactFlowProvider,
  Handle,
  Position,
  useReactFlow,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  type Connection,
  type Edge,
  type Node,
  type NodeProps,
  type NodeChange,
  type EdgeChange,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from 'dagre';
import {
  Box, Button, Chip, Drawer, IconButton, MenuItem, Paper, Select,
  Stack, TextField, Tooltip, Typography, FormControlLabel, Switch,
  Divider,
} from '@mui/material';
import {
  Close as CloseIcon, Delete as DeleteIcon, AccountTree as DagIcon,
  AutoFixHigh as LayoutIcon, Add as AddIcon,
} from '@mui/icons-material';
import type {
  StageDef, StageTypeManifest,
} from '../../services/api/dataflows';
// Phase 132.38 — reusable Static / Dynamic WHERE-clause editor.  Surfaces
// whenever a stage declares ``"type": "where_clauses"`` on a CONFIG_SCHEMA
// field (e.g. SqlQueryStage, StarburstToFile, …).
import WhereClausesEditor from '../common/WhereClausesEditor';
import { SqlColumnExtractor } from '../common/extractSqlColumns';
import { fetchPartitionValueOptions } from '../common/fetchPartitionValueOptions';
import type { PartitionValueOptions } from '../common/fetchPartitionValueOptions';
import { previewColumns as fetchPreviewColumns } from '../common/sqlPreviewApi';


// ── Category palette colours ────────────────────────────────────────────


const CATEGORY_COLOURS: Record<string, string> = {
  source:    '#1976d2',
  transform: '#00897b',
  sink:      '#e65100',
  pipeline:  '#c2185b',   // pink/magenta — dual source-sink (X→Y stages)
  control:   '#7b1fa2',
  quality:   '#388e3c',
  notify:    '#616161',
};

const colour = (cat: string) => CATEGORY_COLOURS[cat] || '#455a64';


// ── Custom node component ──────────────────────────────────────────────


interface StageNodeData {
  alias: string;
  stageType: string;
  stageDisplayName?: string;
  category: string;
  hasError?: boolean;
  selected?: boolean;
  onFailure?: string;
  onDelete?: () => void;
}


function StageNode({ data, selected }: NodeProps) {
  const d = data as unknown as StageNodeData;
  const c = colour(d.category);
  const [hover, setHover] = React.useState(false);
  return (
    <Box
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      sx={{
        bgcolor: 'background.paper',
        border: 2,
        borderColor: selected ? c : (d.hasError ? 'error.main' : 'divider'),
        borderRadius: 1.5, px: 1.5, py: 1, minWidth: 160,
        cursor: 'pointer', position: 'relative',
        boxShadow: selected ? 3 : 1,
        transition: 'box-shadow 0.15s, border-color 0.15s',
      }}>
      <Handle type="target" position={Position.Top}
               style={{ background: c, width: 8, height: 8 }} />
      <Stack spacing={0.5}>
        <Typography variant="body2" sx={{ fontWeight: 600 }}>{d.alias}</Typography>
        <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap">
          <Chip label={d.stageDisplayName || d.stageType} size="small"
                 sx={{ fontSize: 10, height: 20, bgcolor: c, color: 'white' }} />
          {d.onFailure && d.onFailure !== 'halt' && (
            <Chip label={d.onFailure} size="small" variant="outlined"
                   sx={{ fontSize: 10, height: 20 }} />
          )}
        </Stack>
      </Stack>
      {/* Visible delete badge — appears on hover OR when selected.  Click
          stops propagation so it doesn't toggle the side drawer. */}
      {(hover || selected) && d.onDelete && (
        <IconButton
          size="small"
          onClick={(e) => { e.stopPropagation(); d.onDelete && d.onDelete(); }}
          sx={{
            position: 'absolute', top: -8, right: -8,
            bgcolor: 'background.paper',
            border: 1, borderColor: 'error.main',
            color: 'error.main', width: 20, height: 20,
            '&:hover': { bgcolor: 'error.main', color: 'white' },
          }}>
          <CloseIcon sx={{ fontSize: 13 }} />
        </IconButton>
      )}
      <Handle type="source" position={Position.Bottom}
               style={{ background: c, width: 8, height: 8 }} />
    </Box>
  );
}

const nodeTypes = { stage: StageNode };


// ── Auto-layout via dagre ──────────────────────────────────────────────


function autoLayout(nodes: Node[], edges: Edge[]): Node[] {
  const g = new dagre.graphlib.Graph();
  g.setGraph({ rankdir: 'TB', ranksep: 60, nodesep: 30 });
  g.setDefaultEdgeLabel(() => ({}));
  nodes.forEach(n => g.setNode(n.id, { width: 180, height: 70 }));
  edges.forEach(e => g.setEdge(e.source, e.target));
  dagre.layout(g);
  return nodes.map(n => {
    const pos = g.node(n.id);
    return { ...n, position: { x: pos.x - 90, y: pos.y - 35 } };
  });
}


// ── Schema-driven config form ──────────────────────────────────────────


interface ConfigFormProps {
  schema: Record<string, any>;
  values: Record<string, any>;
  onChange: (key: string, value: any) => void;
}


// Cache of looked-up options across forms — fetched once per mount,
// reused for every field that points at the same lookup.
const _lookupCache: Record<string, Array<{ id: number; label: string }>> = {};
const _lookupInflight: Record<string, Promise<void>> = {};

async function fetchLookup(kind: string): Promise<Array<{ id: number; label: string }>> {
  if (_lookupCache[kind]) return _lookupCache[kind];
  if (!_lookupInflight[kind]) {
    _lookupInflight[kind] = (async () => {
      try {
        const api = (await import('../../services/api')).default as any;
        let list: any[] = [];
        if (kind === 'sql_files')  list = await api.sqlFiles?.list?.() ?? [];
        if (kind === 'saved_queries') list = await api.listQueries?.() ?? [];
        if (kind === 'connections')   list = await api.listConnections?.() ?? [];
        // Phase 132.34 lookups — sap_tasks dropdown so admins pick a
        // SapTaskConfig from the side-drawer instead of typing the id.
        if (kind === 'sap_tasks')     list = await api.sapTasks?.list?.() ?? [];
        _lookupCache[kind] = (list || []).map((x: any) => ({
          id:    x.id,
          label: x.name || x.label || `#${x.id}`,
        }));
      } catch {
        _lookupCache[kind] = [];
      }
    })();
  }
  await _lookupInflight[kind];
  return _lookupCache[kind] || [];
}


function LookupField({
  fieldName, lookupKind, value, onChange, description,
}: {
  fieldName:   string;
  lookupKind:  string;
  value:       any;
  onChange:    (v: any) => void;
  description?: string;
}) {
  const [options, setOptions] = React.useState<Array<{ id: number; label: string }>>([]);
  React.useEffect(() => {
    let cancelled = false;
    fetchLookup(lookupKind).then(opts => { if (!cancelled) setOptions(opts); });
    return () => { cancelled = true; };
  }, [lookupKind]);
  return (
    <Box>
      <Typography variant="caption" sx={{ color: 'text.secondary' }}>{fieldName}</Typography>
      <Select fullWidth size="small" displayEmpty
               value={value ?? ''}
               onChange={e => onChange(e.target.value === '' ? undefined : Number(e.target.value))}>
        <MenuItem value="">(none)</MenuItem>
        {options.map(o => (
          <MenuItem key={o.id} value={o.id}>{o.label} <Typography
            component="span" variant="caption" color="text.secondary"
            sx={{ ml: 1 }}>#{o.id}</Typography></MenuItem>
        ))}
      </Select>
      {description && (
        <Typography variant="caption" color="text.secondary"
                      sx={{ display: 'block', fontSize: 11 }}>{description}</Typography>
      )}
    </Box>
  );
}


/** Per-stage hook — fetch partition cache for the stage's connection.
 *  Used by the WHERE-clauses editor below to surface partition badges
 *  + value-picker autocomplete.  Stage configs name the connection
 *  field inconsistently across stage types, so we try the common
 *  spellings and bail (returning empty) when none are set. */
function _usePartitionInfoForStage(values: Record<string, any>): PartitionValueOptions {
  const [info, setInfo] = useState<PartitionValueOptions>({
    valueOptionsByColumn: {}, partitionColumns: [],
  });
  const cid = (
    values?.connection_id
    ?? values?.source_connection_id
    ?? values?.src_connection_id
    ?? null
  );
  const cidNum = (typeof cid === 'number' && Number.isFinite(cid)) ? cid : null;
  useEffect(() => {
    let cancelled = false;
    if (!cidNum) {
      setInfo({ valueOptionsByColumn: {}, partitionColumns: [] });
      return () => { cancelled = true; };
    }
    fetchPartitionValueOptions(cidNum).then(p => {
      if (!cancelled) setInfo(p);
    });
    return () => { cancelled = true; };
  }, [cidNum]);
  return info;
}


/** Phase 133-H round 6 — fetch the full column catalogue from
 *  schema_cache for every table the stage's SQL references.  Returns
 *  the columns_by_table dict the editor folds into its dropdown. */
function _useFullColumnCatalogForStage(values: Record<string, any>): {
  columnsByTable: Record<string, Array<{name: string; type?: string}>>;
  partitionColumnsByTable: Record<string, string[]>;
} {
  const [out, setOut] = useState<{
    columnsByTable: Record<string, Array<{name: string; type?: string}>>;
    partitionColumnsByTable: Record<string, string[]>;
  }>({ columnsByTable: {}, partitionColumnsByTable: {} });
  const cid = (
    values?.connection_id
    ?? values?.source_connection_id
    ?? values?.src_connection_id
    ?? null
  );
  const cidNum = (typeof cid === 'number' && Number.isFinite(cid)) ? cid : null;
  const SQL_KEYS = ['sql', 'query', 'raw_sql', 'source_query',
                    'secondary_raw_sql', 'select_sql'];
  const sqlBlob = SQL_KEYS
    .map(k => (typeof values?.[k] === 'string' ? values[k] : ''))
    .filter(Boolean)
    .join('\n');
  useEffect(() => {
    let cancelled = false;
    if (!cidNum || !sqlBlob.trim()) {
      setOut({ columnsByTable: {}, partitionColumnsByTable: {} });
      return () => { cancelled = true; };
    }
    fetchPreviewColumns(sqlBlob, 'duckdb', cidNum).then(r => {
      if (cancelled || !r) return;
      setOut({
        columnsByTable: r.columns_by_table || {},
        partitionColumnsByTable: r.partition_columns_by_table || {},
      });
    });
    return () => { cancelled = true; };
  }, [cidNum, sqlBlob]);
  return out;
}


function ConfigForm({ schema, values, onChange }: ConfigFormProps) {
  const _partInfo = _usePartitionInfoForStage(values);
  const _fullCatalog = _useFullColumnCatalogForStage(values);
  const keys = Object.keys(schema || {});
  if (keys.length === 0) {
    return (
      <Typography variant="caption" color="text.secondary"
                    sx={{ fontStyle: 'italic' }}>
        This stage takes no configuration.
      </Typography>
    );
  }
  return (
    <Stack spacing={1.5}>
      {keys.map(k => {
        const def = schema[k] || {};
        const t = def.type;
        const v = values[k];
        const enumOpts: string[] | undefined = def.enum;
        const lookup: string | undefined = def.lookup;

        // Lookup fields render a dropdown sourced from a QS API
        // (connections / sql_files / saved_queries / etc.).  Picked
        // up via the `lookup` hint on the backend schema.
        if (lookup) {
          return (
            <LookupField key={k} fieldName={k} lookupKind={lookup}
                          value={v}
                          description={def.description}
                          onChange={val => onChange(k, val)} />
          );
        }

        if (enumOpts && Array.isArray(enumOpts)) {
          return (
            <Box key={k}>
              <Typography variant="caption" sx={{ color: 'text.secondary' }}>{k}</Typography>
              <Select fullWidth size="small" value={v ?? ''}
                       onChange={e => onChange(k, e.target.value)}>
                {enumOpts.map(o => (<MenuItem key={o} value={o}>{o}</MenuItem>))}
              </Select>
            </Box>
          );
        }
        // Phase 132.38 — per-stage Static / Dynamic WHERE-clause mapping
        // (same primitive Published Views + Feed Gen use).  Surfaces
        // whenever a stage's CONFIG_SCHEMA declares ``"type":
        // "where_clauses"`` on a field — e.g. SqlQueryStage,
        // StarburstToFile, and any future SQL-bearing stage.
        if (t === 'where_clauses') {
          const rows = Array.isArray(v) ? v : [];
          // Pull columns from any sibling SQL-bearing field in this
          // stage's config (sql / query / raw_sql / source_query /
          // secondary_raw_sql).  Same primitive every where-editor
          // uses — never asks the publisher to type column names from
          // memory when the SQL is already on the form.
          const SQL_KEYS = ['sql', 'query', 'raw_sql', 'source_query',
                            'secondary_raw_sql', 'select_sql'];
          const _sqlBlob = SQL_KEYS
            .map(sk => (typeof values[sk] === 'string' ? values[sk] : ''))
            .filter(Boolean)
            .join('\n');
          const _ex = new SqlColumnExtractor(
            _sqlBlob,
            _partInfo.partitionColumns,
            _partInfo.valueOptionsByColumn,
          );
          const _colOpts = _ex.toColumnOptions();
          const _valOpts = _ex.toValueOptions();
          const _valKnown = Object.keys(_valOpts).length;
          // Phase 133-H round 6 — fold full schema_cache columns into
          // the dropdown so it shows every column on the underlying
          // tables, not just the names that appear in the SQL.
          const _seen = new Set(_colOpts.map(o => o.name.toLowerCase()));
          const _partLookup = new Set(
            _partInfo.partitionColumns.map(c => c.toLowerCase()),
          );
          Object.values(_fullCatalog.partitionColumnsByTable).forEach(arr =>
            arr.forEach(c => _partLookup.add(c.toLowerCase())),
          );
          // Phase 133-I round 22 — iterate with table key so options
          // carry tableSource (CQB-style per-table grouping).
          Object.entries(_fullCatalog.columnsByTable).forEach(([tbl, cols]) => {
            const groupLabel = tbl.replace(/^.*:/, '') || 'Other';
            cols.forEach(c => {
              const k = (c.name || '').toLowerCase();
              if (!k || _seen.has(k)) return;
              _seen.add(k);
              _colOpts.push({
                name: c.name,
                type: c.type || 'string',
                isPartition: _partLookup.has(k),
                tableSource: groupLabel,
              } as any);
            });
          });
          // Phase 133-H — extract a table hint for the editor's lazy
          // distinct-values fetcher.  Picks the first FROM target out
          // of the SQL blob so warehouse-side dropdowns populate even
          // when the partition cache has nothing for this table.
          const _fromMatch = _sqlBlob.match(
            /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
          );
          const _tableHint = _fromMatch
            ? _fromMatch[1].replace(/[\s"`\[\]]/g, '')
            : null;
          const _cidForEditor = (
            values?.connection_id
            ?? values?.source_connection_id
            ?? values?.src_connection_id
            ?? null
          );
          const _cidNum = (typeof _cidForEditor === 'number' && Number.isFinite(_cidForEditor))
            ? _cidForEditor : null;
          return (
            <Box key={k}>
              <WhereClausesEditor
                value={rows}
                onChange={(next) => onChange(k, next)}
                columnOptions={_colOpts}
                valueOptionsByColumn={_valOpts}
                connectionId={_cidNum}
                distinctValuesTable={_tableHint}
                classifyTable={_tableHint}
                title={k === 'where_clauses' ? 'WHERE Clauses' : k}
                hint={
                  <>
                    {def.description}
                    {' '}
                    {_colOpts.length === 0
                      ? <em>Type SQL in this stage first; columns auto-populate.</em>
                      : <em>{_colOpts.length} column(s){
                          _valKnown > 0
                            ? `, ${_valKnown} with cached values`
                            : ''
                        }.</em>}
                  </>
                }
              />
            </Box>
          );
        }
        if (t === 'boolean') {
          return (
            <FormControlLabel key={k}
              control={<Switch checked={!!v}
                                onChange={e => onChange(k, e.target.checked)} />}
              label={k}
            />
          );
        }
        if (t === 'integer' || t === 'number') {
          return (
            <TextField key={k} size="small" type="number" label={k}
                        value={v ?? ''}
                        onChange={e => onChange(k, e.target.value === ''
                          ? undefined : Number(e.target.value))} />
          );
        }
        if (t === 'object' || t === 'array') {
          // Multi-line JSON editor for nested objects.
          const display = v === undefined ? '' : JSON.stringify(v, null, 2);
          return (
            <TextField key={k} size="small" multiline minRows={3}
                        label={`${k} (JSON)`}
                        value={display}
                        onChange={e => {
                          const text = e.target.value;
                          if (!text.trim()) { onChange(k, undefined); return; }
                          try { onChange(k, JSON.parse(text)); }
                          catch { onChange(k + '__draft', text); }
                        }}
                        sx={{ fontFamily: 'monospace' }} />
          );
        }
        return (
          <TextField key={k} size="small" label={k} value={v ?? ''}
                      onChange={e => onChange(k, e.target.value || undefined)}
                      multiline={(v || '').length > 60}
                      minRows={(v || '').length > 60 ? 2 : 1} />
        );
      })}
    </Stack>
  );
}


// ── Stage palette (left rail) ──────────────────────────────────────────


interface PaletteProps {
  stageTypes: StageTypeManifest[];
  onAdd: (stageType: StageTypeManifest) => void;
}


function StagePalette({ stageTypes, onAdd }: PaletteProps) {
  const byCategory = useMemo(() => {
    const grouped: Record<string, StageTypeManifest[]> = {};
    stageTypes.forEach(t => {
      grouped[t.category] = grouped[t.category] || [];
      grouped[t.category].push(t);
    });
    return grouped;
  }, [stageTypes]);

  return (
    <Paper variant="outlined" sx={{
      width: 220, height: '100%', overflow: 'auto', flexShrink: 0,
    }}>
      <Typography variant="caption" sx={{
        display: 'block', px: 1.5, py: 1,
        color: 'text.secondary', textTransform: 'uppercase',
        letterSpacing: 0.5, fontSize: 11,
        borderBottom: 1, borderColor: 'divider',
      }}>Stage Library</Typography>
      {Object.entries(byCategory).sort().map(([cat, types]) => (
        <Box key={cat} sx={{ mb: 1 }}>
          <Typography variant="caption" sx={{
            display: 'block', px: 1.5, pt: 1, pb: 0.5,
            color: colour(cat), fontWeight: 600, fontSize: 10,
            textTransform: 'uppercase', letterSpacing: 0.5,
          }}>{cat}</Typography>
          {types.map(t => (
            <Tooltip key={t.name}
                      title={`${t.name} · ${t.description || ''}`}
                      placement="right">
              <Box onClick={() => onAdd(t)}
                    sx={{
                      px: 1.5, py: 0.6, mx: 1, mb: 0.3, borderRadius: 0.5,
                      cursor: 'pointer', fontSize: 12,
                      bgcolor: 'background.default',
                      '&:hover': { bgcolor: 'action.hover' },
                      borderLeft: 3, borderColor: colour(cat),
                    }}>
                {t.display_name || t.name}
              </Box>
            </Tooltip>
          ))}
        </Box>
      ))}
    </Paper>
  );
}


// ── Main DAG canvas ────────────────────────────────────────────────────


export interface DataFlowDagCanvasProps {
  stages: StageDef[];
  stageTypes: StageTypeManifest[];
  onChange: (stages: StageDef[]) => void;
}


function InnerCanvas({ stages, stageTypes, onChange }: DataFlowDagCanvasProps) {
  // ── Internal model: keep stages in parent prop, derive RF nodes/edges ──

  const stageTypeMap = useMemo(() => {
    const m: Record<string, StageTypeManifest> = {};
    stageTypes.forEach(t => { m[t.name] = t; });
    return m;
  }, [stageTypes]);

  const [selectedAlias, setSelectedAlias] = useState<string | null>(null);

  // Forward-declared so the node data can reference deletion without
  // creating a memoisation cycle.
  const deleteStageRef = useRef<(alias: string) => void>(() => {});

  // Per-alias position overrides — populated by user drag.  When unset
  // for an alias, the auto-layout (dagre) position is used.  This lets
  // admins move nodes around the canvas without losing the ability to
  // snap back to auto-layout via the [Auto-layout] button.
  const [positionOverrides, setPositionOverrides] =
    useState<Record<string, { x: number; y: number }>>({});

  // Build edges first (independent of node positions)
  const edges: Edge[] = useMemo(() => {
    const e: Edge[] = [];
    stages.forEach(s => {
      (s.predecessors || []).forEach(p => {
        e.push({ id: `${p}->${s.stage_alias}`, source: p, target: s.stage_alias,
                  type: 'smoothstep' });
      });
    });
    return e;
  }, [stages]);

  // Compute base auto-layout positions (only when the structure changes,
  // not when the user drags a node)
  const autoLaidPositions = useMemo(() => {
    const raw: Node[] = stages.map((s, idx) => ({
      id: s.stage_alias,
      type: 'stage',
      position: { x: 0, y: idx * 100 },
      data: {},
    }));
    const laid = autoLayout(raw, edges);
    const map: Record<string, { x: number; y: number }> = {};
    laid.forEach(n => { map[n.id] = n.position; });
    return map;
  }, [stages, edges]);

  // Final node list — overrides win over auto-layout positions
  const nodes: Node[] = useMemo(() => {
    return stages.map(s => ({
      id: s.stage_alias,
      type: 'stage',
      position: positionOverrides[s.stage_alias]
                  || autoLaidPositions[s.stage_alias]
                  || { x: 0, y: 0 },
      data: {
        alias: s.stage_alias,
        stageType: s.stage_type,
        stageDisplayName: stageTypeMap[s.stage_type]?.display_name,
        category: stageTypeMap[s.stage_type]?.category || 'transform',
        onFailure: s.on_failure || 'halt',
        onDelete: () => deleteStageRef.current(s.stage_alias),
      },
    }));
  }, [stages, stageTypeMap, positionOverrides, autoLaidPositions]);

  // Reset overrides if a stage is deleted (don't keep dead aliases in the map)
  useEffect(() => {
    const alive = new Set(stages.map(s => s.stage_alias));
    setPositionOverrides(prev => {
      const trimmed: Record<string, { x: number; y: number }> = {};
      let changed = false;
      for (const [k, v] of Object.entries(prev)) {
        if (alive.has(k)) trimmed[k] = v;
        else changed = true;
      }
      return changed ? trimmed : prev;
    });
  }, [stages]);

  const resetLayout = useCallback(() => setPositionOverrides({}), []);

  // ── Mutations propagate back through onChange ──

  const updateStage = useCallback((alias: string, patch: Partial<StageDef>) => {
    onChange(stages.map(s => s.stage_alias === alias ? { ...s, ...patch } : s));
  }, [stages, onChange]);

  const deleteStage = useCallback((alias: string) => {
    onChange(stages
      .filter(s => s.stage_alias !== alias)
      .map(s => ({
        ...s,
        predecessors: (s.predecessors || []).filter(p => p !== alias),
      }))
      .map((s, i) => ({ ...s, seq: i + 1 })));
    setSelectedAlias(null);
  }, [stages, onChange]);

  // Keep ref pointing at the latest deleteStage so node onDelete callbacks
  // are stable across re-renders (no React-Flow warning about stale refs).
  useEffect(() => { deleteStageRef.current = deleteStage; }, [deleteStage]);

  const onConnect = useCallback((conn: Connection) => {
    if (!conn.source || !conn.target || conn.source === conn.target) return;
    // Add target.predecessors += source (if not already present)
    onChange(stages.map(s => {
      if (s.stage_alias !== conn.target) return s;
      const preds = new Set(s.predecessors || []);
      preds.add(conn.source!);
      return { ...s, predecessors: Array.from(preds) };
    }));
  }, [stages, onChange]);

  // Track edge selection separately so clicking an edge highlights it
  // visually (without thrashing our stages state — predecessor edges
  // are the source of truth).  Persist the selection in local state.
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);

  const onEdgesChange = useCallback((changes: EdgeChange[]) => {
    // Selection changes only flip our local selectedEdgeId so the edge
    // visually highlights.  Removes mutate stages.predecessors so the
    // change actually persists.
    for (const c of changes) {
      if (c.type === 'select') {
        setSelectedEdgeId((c as any).selected ? (c as any).id : null);
      }
    }
    const removes = changes.filter(c => c.type === 'remove');
    if (removes.length === 0) return;
    const edgeIds = new Set(removes.map((c: any) => c.id));
    onChange(stages.map(s => ({
      ...s,
      predecessors: (s.predecessors || []).filter(
        p => !edgeIds.has(`${p}->${s.stage_alias}`),
      ),
    })));
    setSelectedEdgeId(null);
  }, [stages, onChange]);

  // Convenience: handle clicking an edge to select it (some browsers
  // don't fire the select change consistently without this hook).
  const onEdgeClick = useCallback((_e: any, edge: Edge) => {
    setSelectedEdgeId(edge.id);
  }, []);

  // Delete the currently-selected edge via a visible button (in addition
  // to Backspace / Delete keys).
  const deleteSelectedEdge = useCallback(() => {
    if (!selectedEdgeId) return;
    onEdgesChange([{ id: selectedEdgeId, type: 'remove' } as any]);
  }, [selectedEdgeId, onEdgesChange]);

  const onNodesChange = useCallback((changes: NodeChange[]) => {
    // Honour user-driven position changes (drag).  We only store the
    // *final* position (after dragging stops) so re-renders don't thrash
    // — react-flow emits 'position' events both during drag (dragging=
    // true) and at end (dragging=false).
    let next: Record<string, { x: number; y: number }> | null = null;
    for (const c of changes) {
      if (c.type === 'position' && (c as any).position && !(c as any).dragging) {
        next = next || { ...positionOverrides };
        next[(c as any).id] = (c as any).position;
      }
    }
    if (next) setPositionOverrides(next);
  }, [positionOverrides]);

  const onAddFromPalette = useCallback((stageType: StageTypeManifest) => {
    // Find a unique alias
    let n = stages.length + 1;
    let alias = `${stageType.name}_${n}`;
    while (stages.find(s => s.stage_alias === alias)) {
      n += 1;
      alias = `${stageType.name}_${n}`;
    }
    // Auto-wire: link from the last existing stage (linear default)
    const last = stages[stages.length - 1];
    onChange([...stages, {
      stage_alias: alias,
      stage_type:  stageType.name,
      seq:          stages.length + 1,
      predecessors: last ? [last.stage_alias] : [],
      config:       {},
      on_failure:   'halt',
    }]);
    setSelectedAlias(alias);
  }, [stages, onChange]);

  const selectedStage = stages.find(s => s.stage_alias === selectedAlias) || null;
  const selectedSchema = selectedStage
    ? stageTypeMap[selectedStage.stage_type]?.config_schema || {}
    : {};

  return (
    <Box sx={{ display: 'flex', height: 600, gap: 1 }}>
      <StagePalette stageTypes={stageTypes} onAdd={onAddFromPalette} />

      <Box sx={{ flex: 1, position: 'relative',
                  border: 1, borderColor: 'divider', borderRadius: 1 }}>
        {/* Auto-layout reset — appears top-right of the canvas.  Always
            visible; resets to dagre even if no overrides exist (no-op then). */}
        <Tooltip title="Snap all nodes back to auto-layout (dagre)">
          <Button
            size="small"
            startIcon={<LayoutIcon />}
            onClick={resetLayout}
            sx={{
              position: 'absolute', top: 8, right: 8, zIndex: 5,
              bgcolor: 'background.paper',
              border: 1, borderColor: 'divider',
              '&:hover': { bgcolor: 'action.hover' },
            }}>
            Auto-layout
          </Button>
        </Tooltip>
        {/* Selected-edge action button — appears when an edge is clicked. */}
        {selectedEdgeId && (
          <Box sx={{
            position: 'absolute', top: 8, right: 130, zIndex: 5,
            display: 'flex', gap: 1,
          }}>
            <Button size="small" startIcon={<CloseIcon />} color="error"
                     variant="contained" onClick={deleteSelectedEdge}
                     sx={{ boxShadow: 2 }}>
              Delete edge
            </Button>
          </Box>
        )}
        <ReactFlow
          nodes={nodes.map(n => ({
            ...n,
            selected: n.id === selectedAlias,
            draggable: true,
          }))}
          edges={edges.map(e => ({
            ...e,
            selected: e.id === selectedEdgeId,
            // Selected edges are bolder + red so admins see they're
            // selectable + which one will be deleted by Backspace.
            style: e.id === selectedEdgeId
              ? { stroke: '#dc2626', strokeWidth: 3 }
              : { stroke: '#94a3b8', strokeWidth: 2 },
            animated: e.id === selectedEdgeId,
          }))}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onEdgeClick={onEdgeClick}
          onConnect={onConnect}
          onNodeClick={(_e, n) => { setSelectedAlias(n.id); setSelectedEdgeId(null); }}
          onPaneClick={() => { setSelectedAlias(null); setSelectedEdgeId(null); }}
          nodesDraggable
          nodesConnectable
          edgesFocusable
          elementsSelectable
          fitView
          minZoom={0.3}
          maxZoom={1.8}
          deleteKeyCode={['Backspace', 'Delete']}
        >
          <Background gap={16} />
          <Controls position="bottom-left" />
          <MiniMap pannable zoomable style={{ width: 140, height: 80 }} />
        </ReactFlow>
        {stages.length === 0 && (
          <Box sx={{
            position: 'absolute', top: '50%', left: '50%',
            transform: 'translate(-50%, -50%)', textAlign: 'center',
            color: 'text.secondary', pointerEvents: 'none',
          }}>
            <DagIcon sx={{ fontSize: 48, opacity: 0.4 }} />
            <Typography variant="body2" sx={{ mt: 1 }}>
              Click a stage type in the left panel to add your first stage.
            </Typography>
          </Box>
        )}
      </Box>

      {/* Config drawer — only when a node is selected */}
      <Drawer anchor="right" variant="persistent" open={!!selectedStage}
               PaperProps={{ sx: { width: 360, position: 'relative' } }}
               sx={{ '& .MuiDrawer-paper': { position: 'static' }, height: '100%' }}>
        {selectedStage && (
          <Box sx={{ height: '100%', overflow: 'auto', p: 2 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center"
                    sx={{ mb: 2 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                Stage: {selectedStage.stage_alias}
              </Typography>
              <IconButton size="small" onClick={() => setSelectedAlias(null)}>
                <CloseIcon fontSize="small" />
              </IconButton>
            </Stack>

            <Stack spacing={2}>
              <TextField label="Alias" size="small" fullWidth
                          value={selectedStage.stage_alias}
                          onChange={e => {
                            const newAlias = e.target.value.trim();
                            if (!newAlias || newAlias === selectedStage.stage_alias) return;
                            // Update this stage's alias AND any downstream's predecessor reference.
                            const oldAlias = selectedStage.stage_alias;
                            onChange(stages.map(s => {
                              if (s.stage_alias === oldAlias) {
                                return { ...s, stage_alias: newAlias };
                              }
                              if ((s.predecessors || []).includes(oldAlias)) {
                                return {
                                  ...s,
                                  predecessors: (s.predecessors || []).map(
                                    p => p === oldAlias ? newAlias : p,
                                  ),
                                };
                              }
                              return s;
                            }));
                            setSelectedAlias(newAlias);
                          }} />

              <Box>
                <Typography variant="caption" sx={{ color: 'text.secondary' }}>Stage type</Typography>
                <Select fullWidth size="small" value={selectedStage.stage_type}
                         onChange={e => updateStage(selectedStage.stage_alias,
                           { stage_type: e.target.value, config: {} })}>
                  {stageTypes.map(t => (
                    <MenuItem key={t.name} value={t.name}>
                      {t.display_name || t.name}
                      <Typography variant="caption" color="text.secondary"
                                    sx={{ ml: 1 }}>[{t.category}]</Typography>
                    </MenuItem>
                  ))}
                </Select>
                {stageTypeMap[selectedStage.stage_type]?.description && (
                  <Typography variant="caption" color="text.secondary"
                                sx={{ display: 'block', mt: 0.5 }}>
                    {stageTypeMap[selectedStage.stage_type].description}
                  </Typography>
                )}
              </Box>

              <Divider>Configuration</Divider>
              <ConfigForm schema={selectedSchema}
                          values={selectedStage.config || {}}
                          onChange={(k, v) => {
                            const cfg = { ...(selectedStage.config || {}) };
                            if (v === undefined) delete cfg[k]; else cfg[k] = v;
                            updateStage(selectedStage.stage_alias, { config: cfg });
                          }} />

              <Divider>Failure handling</Divider>
              <Select fullWidth size="small"
                       value={selectedStage.on_failure || 'halt'}
                       onChange={e => updateStage(selectedStage.stage_alias,
                         { on_failure: e.target.value as any })}>
                <MenuItem value="halt">on_failure: halt</MenuItem>
                <MenuItem value="continue">continue (independent branches keep running)</MenuItem>
                <MenuItem value="branch_to">branch_to (route to fallback stage)</MenuItem>
              </Select>
              {selectedStage.on_failure === 'branch_to' && (
                <Select fullWidth size="small" displayEmpty
                         value={selectedStage.on_failure_target || ''}
                         onChange={e => updateStage(selectedStage.stage_alias,
                           { on_failure_target: e.target.value })}>
                  <MenuItem value="" disabled>Pick fallback stage…</MenuItem>
                  {stages.filter(s => s.stage_alias !== selectedStage.stage_alias)
                    .map(s => (
                      <MenuItem key={s.stage_alias} value={s.stage_alias}>{s.stage_alias}</MenuItem>
                    ))}
                </Select>
              )}

              <TextField label="Timeout (seconds)" size="small" type="number"
                          value={selectedStage.timeout_seconds ?? ''}
                          onChange={e => updateStage(selectedStage.stage_alias,
                            { timeout_seconds: e.target.value ? Number(e.target.value) : null })} />

              <TextField label="Retry policy (JSON)" size="small" multiline minRows={3}
                          value={selectedStage.retry_policy
                            ? JSON.stringify(selectedStage.retry_policy, null, 2) : ''}
                          onChange={e => {
                            if (!e.target.value.trim()) {
                              updateStage(selectedStage.stage_alias, { retry_policy: {} });
                              return;
                            }
                            try {
                              updateStage(selectedStage.stage_alias,
                                { retry_policy: JSON.parse(e.target.value) });
                            } catch { /* parse error — wait until valid */ }
                          }}
                          placeholder='{"max_attempts": 3, "backoff_seconds": 5}'
                          sx={{ fontFamily: 'monospace' }} />

              <Divider />

              <Button startIcon={<DeleteIcon />} color="error" size="small"
                       onClick={() => deleteStage(selectedStage.stage_alias)}>
                Delete stage
              </Button>
            </Stack>
          </Box>
        )}
      </Drawer>
    </Box>
  );
}


export default function DataFlowDagCanvas(props: DataFlowDagCanvasProps) {
  return (
    <ReactFlowProvider>
      <InnerCanvas {...props} />
    </ReactFlowProvider>
  );
}
