/**
 * Shared "Run with overrides" dialog for DataFlow launches.
 *
 * Used by DataFlowsPage, DataFlowDashboardPage, and DataFlowSimpleJobPage.
 * Three call sites used to copy-paste this dialog inline; this is the
 * single source of truth for:
 *   - Static-row context message
 *   - Per-row TextField for each Dynamic row (column / operator /
 *     stage_alias / publisher-default helper text)
 *   - Cancel / Run actions
 *
 * Caller owns the override-values state so the open/close + value
 * lifecycle integrates cleanly with whatever launch flow surrounds it.
 */
import * as React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Stack,
  Button, Typography,
} from '@mui/material';
import type { DynamicDataflowRow } from '../../services/api/dataflows';
import DynamicWhereOverrideField from '../common/DynamicWhereOverrideField';


export interface DataflowOverrideDialogProps {
  /** Dataflow being launched; ``null`` keeps the dialog closed. */
  dataflowName: string | null | undefined;
  /** Dynamic rows declared across the dataflow's stages.  Empty list
   *  is a valid input — the dialog renders a brief "no overrides
   *  needed" message in that case. */
  rows: DynamicDataflowRow[];
  /** Current override-values dict.  Keyed by column name; values are
   *  always strings (the launch helper coerces). */
  values: Record<string, any>;
  onValuesChange: (next: Record<string, any>) => void;
  onCancel: () => void;
  /** Called when the user clicks "Run".  Caller is responsible for
   *  closing the dialog (e.g. via onCancel) and firing the run. */
  onConfirm: () => void;
  /** Phase 133-H — connection ID per row for lazy distinct-values
   *  lookup.  When the row's stage has a connection_id, the override
   *  field becomes a dropdown of known values instead of a textbox.
   *  Optional — empty / missing entries fall back to free-text. */
  connectionIdByRow?: (row: DynamicDataflowRow) => number | null;
  /** Table hint per row for the lookup.  Typically extracted from the
   *  stage's SQL by the caller (first FROM target). */
  tableByRow?: (row: DynamicDataflowRow) => string | null;
}


export function DataflowOverrideDialog({
  dataflowName, rows, values, onValuesChange, onCancel, onConfirm,
  connectionIdByRow, tableByRow,
}: DataflowOverrideDialogProps) {
  return (
    <Dialog open={!!dataflowName} onClose={onCancel} maxWidth="sm" fullWidth>
      <DialogTitle>
        Run {dataflowName} — override values
      </DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {rows.length === 0
            ? 'No dynamic rows to override — confirm to start the run.'
            : 'One or more stages have dynamic WHERE-clause rows.  '
              + 'Override the values for this run, or leave blank to use '
              + 'the publisher default.  Static rows always apply.'}
        </Typography>
        <Stack spacing={2}>
          {rows.map((r, i) => (
            <DynamicWhereOverrideField
              key={`${r.stageAlias}-${r.column}-${i}`}
              column={r.column}
              operator={r.operator}
              publisherDefault={r.value}
              value={values[r.column] ?? ''}
              onChange={(next) => onValuesChange({
                ...values, [r.column]: next,
              })}
              connectionId={connectionIdByRow ? connectionIdByRow(r) : null}
              table={tableByRow ? tableByRow(r) : null}
              label={`${r.column} (${r.operator}) — stage "${r.stageAlias}"`}
            />
          ))}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onCancel}>Cancel</Button>
        <Button variant="contained" onClick={onConfirm}>
          Run
        </Button>
      </DialogActions>
    </Dialog>
  );
}


export default DataflowOverrideDialog;
