/**
 * Quick-launch helper for DataFlows.
 *
 * Fetches the active dataflow version, collects any Dynamic
 * where-clause rows across all stages, and EITHER returns them to the
 * caller (so it can show an override dialog) OR signals "fire now"
 * (no Dynamic rows present).
 *
 * Used by DataFlowsPage + DataFlowDashboardPage so a quick-launch
 * button click doesn't silently drop Dynamic rows to publisher
 * defaults — same UX DataFlowSimpleJobPage already implements inline.
 */
import api from '../../services/api';
import {
  collectDataflowDynamicRows,
  DynamicDataflowRow,
} from '../../services/api/dataflows';


export interface PendingLaunch {
  /** Active dataflow name to launch on confirm. */
  name: string;
  /** Dynamic rows the user is being asked to override.  Pre-seeded
   *  with publisher defaults so the user can keep them by clicking OK. */
  rows: DynamicDataflowRow[];
}


/** Resolve a dataflow name to either an immediate-fire start (when no
 *  Dynamic rows are declared) or a PendingLaunch the UI should prompt
 *  the user about.  Returns ``null`` when the fetch failed AND there's
 *  no detail to inspect — caller should fall back to firing without
 *  overrides.
 */
export async function inspectDynamicRows(
  dataflowName: string,
): Promise<DynamicDataflowRow[]> {
  let df: any = null;
  try {
    // listDataFlows accepts an optional ``name`` filter and returns an
    // array; we pick the active version.  No dedicated getByName route
    // exists yet (worth adding if this becomes hot).
    const arr: any[] = await api.dataflows.listDataFlows({ name: dataflowName });
    if (Array.isArray(arr)) {
      df = arr.find(d => d?.status === 'active') || arr[0];
    }
  } catch {
    return [];
  }
  return collectDataflowDynamicRows(df);
}


/** Convenience: fire startRun with an optional ``_consumer_overrides``
 *  context.  Strips empty values so a blank override falls back to the
 *  publisher's default. */
export async function fireDataflowRun(
  dataflowName: string,
  overrides?: Record<string, any>,
): Promise<{ id: number }> {
  const clean: Record<string, any> = {};
  for (const [k, v] of Object.entries(overrides || {})) {
    if (v !== '' && v !== null && v !== undefined) clean[k] = v;
  }
  const context = Object.keys(clean).length
    ? { _consumer_overrides: clean }
    : undefined;
  return await api.dataflows.startRun(
    dataflowName, context ? { context } : {},
  ) as any;
}
