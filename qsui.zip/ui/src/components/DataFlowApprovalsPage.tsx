/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowApprovalsPage — pending human-in-the-loop approvals.
 * Admin can approve or reject each row.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, IconButton, MenuItem, Paper, Select, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Tooltip, Typography,
} from '@mui/material';
import {
  CheckCircle as ApproveIcon, Cancel as RejectIcon,
  Refresh as RefreshIcon, OpenInNew as OpenIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import type { ApprovalRequest } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const STATUS_COLOR: Record<string, any> = {
  pending: 'warning', approved: 'success', rejected: 'error', expired: 'default',
};

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 16).replace('T', ' ') : '—';

export default function DataFlowApprovalsPage() {
  const nav = useNavigate();
  const [items, setItems] = useState<ApprovalRequest[]>([]);
  const [statusFilter, setStatusFilter] = useState('pending');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [decideDialog, setDecideDialog] = useState<{ item: ApprovalRequest; decision: 'approve' | 'reject' } | null>(null);
  const [decisionNotes, setDecisionNotes] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const list = await api.dataflows.listApprovals(
        statusFilter ? { status: statusFilter } : undefined,
      );
      setItems(toArray<ApprovalRequest>(list));
    } catch (e: any) {
      setError(e?.message || 'Failed to load approvals');
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  const onDecide = async () => {
    if (!decideDialog) return;
    try {
      await api.dataflows.decideApproval(decideDialog.item.id,
        decideDialog.decision, decisionNotes || undefined);
      setDecideDialog(null); setDecisionNotes('');
      await load();
    } catch (e: any) {
      setError(e?.message || 'Decision failed');
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">DataFlow Approvals</Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Select size="small" value={statusFilter}
                   onChange={e => setStatusFilter(e.target.value)} sx={{ minWidth: 160 }}>
            <MenuItem value="">All statuses</MenuItem>
            <MenuItem value="pending">Pending</MenuItem>
            <MenuItem value="approved">Approved</MenuItem>
            <MenuItem value="rejected">Rejected</MenuItem>
            <MenuItem value="expired">Expired</MenuItem>
          </Select>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>DataFlow</TableCell>
              <TableCell>Run</TableCell>
              <TableCell>Title</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Requested by</TableCell>
              <TableCell>Created</TableCell>
              <TableCell>Decided by</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={9} align="center">
                <CircularProgress size={20} />
              </TableCell></TableRow>
            )}
            {!loading && items.length === 0 && (
              <TableRow><TableCell colSpan={9} align="center">
                <Typography variant="body2" color="text.secondary">No approvals.</Typography>
              </TableCell></TableRow>
            )}
            {items.map(a => (
              <TableRow key={a.id} hover>
                <TableCell>#{a.id}</TableCell>
                <TableCell>{a.dataflow_name}</TableCell>
                <TableCell>
                  <Button size="small" sx={{ textTransform: 'none' }}
                           onClick={() => nav(`/dataflows/runs/${a.run_id}`)}>
                    #{a.run_id} <OpenIcon fontSize="inherit" sx={{ ml: 0.5 }} />
                  </Button>
                </TableCell>
                <TableCell>{a.title || '—'}</TableCell>
                <TableCell>
                  <Chip label={a.status} size="small" color={STATUS_COLOR[a.status] || 'default'}
                         variant="outlined" sx={{ fontSize: 10 }} />
                </TableCell>
                <TableCell>{a.requested_by || '—'}</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{fmtDt(a.created_at)}</TableCell>
                <TableCell>{a.decided_by || '—'}</TableCell>
                <TableCell align="right">
                  {a.status === 'pending' && (
                    <>
                      <Tooltip title="Approve">
                        <IconButton size="small" color="success"
                                     onClick={() => { setDecideDialog({ item: a, decision: 'approve' }); }}>
                          <ApproveIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Reject">
                        <IconButton size="small" color="error"
                                     onClick={() => { setDecideDialog({ item: a, decision: 'reject' }); }}>
                          <RejectIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={!!decideDialog} onClose={() => setDecideDialog(null)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {decideDialog?.decision === 'approve' ? 'Approve' : 'Reject'} request #{decideDialog?.item.id}
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 2 }}>
            {decideDialog?.item.title}
            {decideDialog?.item.description && (
              <Box component="span" sx={{ display: 'block', color: 'text.secondary', mt: 1 }}>
                {decideDialog.item.description}
              </Box>
            )}
          </Typography>
          <TextField fullWidth multiline minRows={3} label="Decision notes (optional)"
                      value={decisionNotes} onChange={e => setDecisionNotes(e.target.value)} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDecideDialog(null)}>Cancel</Button>
          <Button variant="contained"
                   color={decideDialog?.decision === 'approve' ? 'success' : 'error'}
                   onClick={onDecide}>
            {decideDialog?.decision === 'approve' ? 'Approve' : 'Reject'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
