/**
 * Admin Panel — QueryStudio Enterprise
 * Two-panel layout: left nav sidebar + right content area.
 * Only the active section loads data & polls.
 *
 * Performance: each admin sub-section is lazy-loaded via React.lazy() so
 * AdminPage's initial JS chunk doesn't bundle code for sections the user
 * may never open.  First-paint chunk drops dramatically; per-section JS
 * is fetched on demand the first time a sidebar item is clicked, then
 * cached by the browser for the rest of the session.  The active-section
 * renderer is wrapped in <Suspense> with a thin LinearProgress fallback
 * for the brief network round-trip on first click of each section.
 */
import React, { useState, useEffect, useCallback, Fragment, Suspense, lazy } from 'react';

// ── Lazy-loaded admin sections — one chunk per section ─────────────────────
// Every section file uses `export default`, so the dynamic-import shorthand
// works directly without a wrapper.
const ActiveQueriesSection         = lazy(() => import('./admin/ActiveQueriesSection'));
const SystemHealthSection          = lazy(() => import('./admin/SystemHealthSection'));
const WorkerPoolSection            = lazy(() => import('./admin/WorkerPoolSection'));
const AppConfigSection             = lazy(() => import('./admin/AppConfigSection'));
const QueueConfigSection           = lazy(() => import('./admin/QueueConfigSection'));
const SchedulerSection             = lazy(() => import('./admin/SchedulerSection'));
const UserManagementSection        = lazy(() => import('./admin/UserManagementSection'));
const UserActivitySection          = lazy(() => import('./admin/UserActivitySection'));
const StorageSection               = lazy(() => import('./admin/StorageSection'));
const StorageOverviewSection       = lazy(() => import('./admin/StorageOverviewSection'));
const CacheSection                 = lazy(() => import('./admin/CacheSection'));
const AggCacheSection              = lazy(() => import('./admin/AggCacheSection'));
const ResultCacheSection           = lazy(() => import('./admin/ResultCacheSection'));
const MultiWorkerSection           = lazy(() => import('./admin/MultiWorkerSection'));
const MultiPodSection              = lazy(() => import('./admin/MultiPodSection'));
const EngineRouterSection          = lazy(() => import('./admin/EngineRouterSection'));
const AuditLogSection              = lazy(() => import('./admin/AuditLogSection'));
const AWSPortalSection             = lazy(() => import('./admin/AWSPortalSection'));
const AgentsAdminSection           = lazy(() => import('./admin/AgentsAdminSection'));
const S3PerformanceSection         = lazy(() => import('./admin/S3PerformanceSection'));
const ScanStrategyAdminSection     = lazy(() => import('./admin/ScanStrategyAdminSection'));
const SparkConnectSection          = lazy(() => import('./admin/SparkConnectSection'));
const FeedFailoverSection          = lazy(() => import('./admin/FeedFailoverSection'));
const UserGroupsAdminSection       = lazy(() => import('./admin/UserGroupsAdminSection'));
const FeedEtlDependenciesAdminSection = lazy(() => import('./admin/FeedEtlDependenciesAdminSection'));
const S3ReadersAdminSection        = lazy(() => import('./admin/S3ReadersAdminSection'));
const CacheTelemetrySection        = lazy(() => import('./admin/CacheTelemetrySection'));
const ProxySection                 = lazy(() => import('./admin/ProxySection'));
const VpcCheckSection              = lazy(() => import('./admin/VpcCheckSection'));
const IcebergWriterSection         = lazy(() => import('./admin/IcebergWriterSection'));
const IcebergSection               = lazy(() => import('./admin/IcebergSection'));
const IcebergMetadataSyncSection   = lazy(() => import('./admin/IcebergMetadataSyncSection'));
const BackgroundJobsSection        = lazy(() => import('./admin/BackgroundJobsSection'));
const CustomJobsSection            = lazy(() => import('./admin/CustomJobsSection'));
const GovernanceAdminSection       = lazy(() => import('./admin/GovernanceAdminSection'));
const AuditExplorerAdminSection    = lazy(() => import('./admin/AuditExplorerAdminSection'));
const CacheExplorerAdminSection    = lazy(() => import('./admin/CacheExplorerAdminSection'));
const RLSAdminSection              = lazy(() => import('./admin/RLSAdminSection'));
const RowSecurityAdminSection      = lazy(() => import('./admin/RowSecurityAdminSection'));
const ConnectionProfilesAdminSection = lazy(() => import('./admin/ConnectionProfilesAdminSection'));
const WorkspaceAdminSection        = lazy(() => import('./admin/WorkspaceAdminSection'));
const ReportCatalogAdminSection    = lazy(() => import('./admin/ReportCatalogAdminSection'));
const BusinessPortalAdminSection   = lazy(() => import('./admin/BusinessPortalAdminSection'));
const DeliveryAdminSection         = lazy(() => import('./admin/DeliveryAdminSection'));
const UIVisibilityAdminSection     = lazy(() => import('./admin/UIVisibilityAdminSection'));
const AuditComplianceAdminSection  = lazy(() => import('./admin/AuditComplianceAdminSection'));
const ApiKeyRequestsSection        = lazy(() => import('./admin/ApiKeyRequestsSection'));
const SelfTestSection              = lazy(() => import('./admin/SelfTestSection'));
const ApiRequestBuilderSection     = lazy(() => import('./admin/ApiRequestBuilderSection'));
const QueryDiagnosticSection       = lazy(() => import('./admin/QueryDiagnosticSection'));
const ColumnStatsStatusSection     = lazy(() => import('./admin/ColumnStatsStatusSection'));
const PruningHealthSection         = lazy(() => import('./admin/PruningHealthSection'));
const IcebergMirrorStatusSection   = lazy(() => import('./admin/IcebergMirrorStatusSection'));
const PlainParquetBrainSection     = lazy(() => import('./admin/PlainParquetBrainSection'));
const OutputGatewayStatusSection   = lazy(() => import('./admin/OutputGatewayStatusSection'));
const WriterAdvisorSection         = lazy(() => import('./admin/WriterAdvisorSection'));
const BrainOverviewSection         = lazy(() => import('./admin/BrainOverviewSection'));
const OperationsDashboardSection   = lazy(() => import('./admin/OperationsDashboardSection'));

import {
  Box, Typography, Chip, Divider, Tooltip,
  List, ListItemButton, ListItemIcon, ListItemText,
  LinearProgress,
  useTheme,
} from '@mui/material';
import {
  Storage as StorageIcon,
  Security as AuditIcon,
  Memory as CacheIcon,
  MonitorHeart as HealthIcon,
  PlayCircleOutline as ActiveIcon,
  HourglassTop as RunningIcon,
  Settings as SettingsIcon,
  Schedule as ScheduleIcon,
  Assessment as ActivityIcon,
  History as HistoryIcon,
  Hub as QueueIcon,
  SwapHoriz as SwapHorizIcon,
  Workspaces as WorkspacesIcon,
  GppGood as GppGoodIcon,
  VisibilityOff as VisibilityOffIcon,
  Speed as SpeedIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { safeFetch } from '../services/api/core';
import { toArray } from '../utils/toArray';

// ── Admin sections definition ───────────────────────────────────────────────
type AdminSection =
  | 'activeQueries' | 'systemHealth' | 'selfTest' | 'workerPool'
  | 'appConfig' | 'scheduler' | 'queueConfig' | 'governance'
  | 'userManagement' | 'userGroups' | 'userActivity'
  | 'storageOverview'
  | 'storage' | 'cache' | 'aggCache' | 'resultCache' | 'multiWorker' | 'multiPod' | 'engineRouter' | 'auditLog' | 'auditExplorer'
  | 'rlsPolicies' | 'rowSecurity' | 'connectionProfiles' | 'workspaces'
  | 'auditCompliance' | 'uiVisibility' | 'awsPortal'
  | 'reportCatalog' | 'businessPortal' | 'delivery'
  | 'cacheExplorer'
  | 'cacheTelemetry'
  | 'agents'
  | 's3Performance'
  | 'scanStrategy'
  | 'sparkConnect'
  | 'feedFailover'
  | 'feedEtlDeps'
  | 'userGroups'
  | 's3Readers'
  | 'icebergWriter'
  | 'iceberg'
  | 'icebergMetaSync'
  | 'backgroundJobs'
  | 'customJobs'
  | 'proxy'
  | 'vpcCheck'
  | 'apiRequestBuilder'
  | 'queryDiagnostic'
  | 'columnStatsStatus'
  | 'brainOverview'
  | 'pruningHealth'
  | 'writerAdvisor'
  | 'icebergMirror'
  | 'plainParquetBrain'
  | 'outputGateway'
  | 'operationsDashboard'
  | 'apiKeyRequests';

// Phase 139 honest-fix: per-section stability marker. Renders a small badge
// in the sidebar so admins can tell battle-tested vs experimental at a glance.
//   stable  — production-tested, default-safe
//   beta    — recently-shipped or behind a non-default config gate
//   alpha   — opt-in only, may break / change without notice
type StabilityLevel = 'stable' | 'beta' | 'alpha';

interface AdminSectionDef {
  id: AdminSection;
  label: string;
  icon: React.ReactNode;
  stability?: StabilityLevel;  // omit = stable (default)
  hint?: string;               // tooltip shown on the badge
}

// Bug D helper — flat lookup set of valid section IDs.  Populated from
// ADMIN_SECTIONS below; used by the deep-link parser to guard against a
// bad ?section= value.
const SECTION_DEFS_FLAT = new Set<string>();

const ADMIN_SECTIONS: { group: string; items: AdminSectionDef[] }[] = [
  { group: 'MONITORING', items: [
    { id: 'activeQueries', label: 'Active Queries', icon: <ActiveIcon fontSize="small" /> },
    { id: 'systemHealth',  label: 'System Health',  icon: <HealthIcon fontSize="small" /> },
    { id: 'selfTest',      label: 'Self-Test Diagnostics', icon: <HealthIcon fontSize="small" />,
      hint: 'BF-600-st — in-memory self-tests for the BF-600 pruning fixes (boolean, NOT IN, decimal, LIKE prefix, IS NOT NULL, function-wrap) + system health (DuckDB, DB ping, watchdog, httpfs prefix). Runs in <1s. Any logged-in user.' },
    { id: 'workerPool',    label: 'Worker Pool',    icon: <RunningIcon fontSize="small" /> },
    { id: 'apiRequestBuilder', label: 'API Request Builder', icon: <SettingsIcon fontSize="small" />,
      hint: 'Postman/Insomnia-style runner for ANY backend endpoint — uses your active session cookie so there is no token paste.  Handy for admin debug calls + endpoints that do not have a dedicated UI yet.' },
    { id: 'queryDiagnostic', label: 'Query Diagnostic', icon: <SpeedIcon fontSize="small" />,
      stability: 'beta', hint: '2026-06-03 — single-pane "why was my query slow" view.  Aggregates engine router decisions, multi-worker dispatch + per-worker timing, live system RAM/CPU, and a heuristic bottleneck classifier (10 rules) into ONE screen.' },
    { id: 'operationsDashboard', label: 'Operations Dashboard', icon: <SpeedIcon fontSize="small" />,
      stability: 'beta', hint: '2026-06-03 — consolidated view: every background job + every live column-stats scan + memory_guard watchdog state.  Auto-refreshes every 5s.  Use this when you turn on iceberg metadata sync / prewarm_background to see if they\'re actually doing work.' },
  ]},
  { group: 'CONFIGURATION', items: [
    { id: 'appConfig',   label: 'App Config',    icon: <SettingsIcon fontSize="small" /> },
    { id: 'governance',  label: 'Governance',    icon: <GppGoodIcon fontSize="small" /> },
    { id: 'queueConfig', label: 'Queue Backend',  icon: <QueueIcon fontSize="small" /> },
    { id: 'scheduler',   label: 'Scheduler',     icon: <ScheduleIcon fontSize="small" /> },
  ]},
  { group: 'USERS', items: [
    { id: 'userManagement', label: 'User Management', icon: <AuditIcon fontSize="small" /> },
    { id: 'userGroups',     label: 'User Groups',     icon: <AuditIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 130 hotfix-13 — entitlement groups with per-user read_only / read_write flavour + group notification email. Honoured by feeds + reports.' },
    { id: 'userActivity',   label: 'User Activity',   icon: <ActivityIcon fontSize="small" /> },
  ]},
  { group: 'SYSTEM', items: [
    { id: 'storageOverview', label: 'Storage & Caches',   icon: <StorageIcon fontSize="small" />,
      hint: 'Unified view of every cache + storage layer on this pod. Use the specific section (Result Cache, Iceberg, etc.) for advanced editing.' },
    { id: 'storage',         label: 'Storage',             icon: <StorageIcon fontSize="small" /> },
    { id: 'cache',           label: 'Cache',               icon: <CacheIcon fontSize="small" /> },
    { id: 'cacheExplorer',   label: 'Cache Explorer',      icon: <CacheIcon fontSize="small" /> },
    { id: 'cacheTelemetry',  label: 'Cache Telemetry',     icon: <CacheIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 139 — needs Prometheus scrape for full value' },
    { id: 'aggCache',        label: 'Agg Cache',           icon: <CacheIcon fontSize="small" /> },
    { id: 'resultCache',     label: 'Result Cache',        icon: <CacheIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-382 — repeat-query result cache (L1 in-memory + L2 on-disk). Disabled by default.' },
    { id: 'multiWorker',     label: 'Multi-Worker (in-pod)', icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-383 (Option F) — splits large queries across N parallel DuckDB workers IN THE SAME POD. Disabled by default.' },
    { id: 'multiPod',        label: 'Multi-Pod Workers',     icon: <StorageIcon fontSize="small" />,
      stability: 'alpha', hint: 'BF-384 (Option G) — distributes chunks across SEPARATE worker pods over HTTP. Requires multi_pod.enabled + worker pods reachable. Disabled by default.' },
    { id: 'engineRouter',    label: 'Engine Router',          icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-385 — Picks single / multi_worker / multi_pod / spark_connect per query. Configurable rules.' },
    { id: 's3Performance',   label: 'S3 Performance',      icon: <StorageIcon fontSize="small" /> },
    { id: 'scanStrategy',    label: 'Scan Strategy',       icon: <SpeedIcon fontSize="small" />,
      stability: 'beta', hint: '2026-06-01 — single source of truth for per-scan decisions (file order, workers, footer prewarm, DuckDB pragmas, boto3 pool). Replaces scattered BF-535 / multi_worker.max_workers / s3 perf knobs.' },
    { id: 'sparkConnect',    label: 'Spark Connect',        icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Disabled by default; needs K8s Spark Connect server deployed' },
    { id: 'feedFailover',    label: 'Feed Failover',         icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 130 hotfix-13 — switch feeds between native worker and Airflow when one side is down. DB-driven, admin-tunable.' },
    { id: 'feedEtlDeps',     label: 'Feed ETL Dependencies', icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 131-A — catalogue + operator backfill for upstream dependencies (Kafka / Oracle / FILE / API). End users add deps per-feed in Production Controls.' },
    { id: 's3Readers',       label: 'S3 Readers (BF-428)',   icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Pluggable S3 read strategies: direct httpfs, full predownload, smart predownload, PyArrow+S3FS, S3 Select, Athena. Master switch off by default.' },
    { id: 'icebergWriter',   label: 'Iceberg Writer',       icon: <StorageIcon fontSize="small" />,
      stability: 'alpha', hint: 'Requires pyiceberg + iceberg_writer.enabled=true. Production validation pending.' },
    { id: 'iceberg',         label: 'Iceberg & S3 Cache',   icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-273 — turn on iceberg_mor.enabled if your tables have V2 delete files; persistent NFS file cache for S3.' },
    { id: 'icebergMetaSync', label: 'Iceberg Metadata Sync', icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-296/298/299/300 — keeps iceberg metadata cached locally so pruning runs at QueryStudio and S3 is hit only for surviving data files.' },
    { id: 'columnStatsStatus', label: 'Column Stats Status', icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: '2026-06-03 — list every (bucket, table, snapshot) tuple in iceberg_column_stats_supplement_v2 with file count + freshness.  Trigger force-rescan when the running scan reported "done with 0 files scanned".' },
    { id: 'brainOverview', label: 'Brain Overview', icon: <HealthIcon fontSize="small" />,
      stability: 'alpha', hint: '2026-06-10 unified pruning brain dashboard — coordinator pressure, cost model, skew, forecaster, writer advisor, mirror summary, output gateway, supplement backpressure, portal cred pre-warmer, alerts dispatcher.  Single roundtrip to /api/admin/brain/overview consolidates 10 admin endpoints.' },
    { id: 'pruningHealth', label: 'Pruning Health', icon: <HealthIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 148 — cluster-wide pruning effectiveness over a chosen window. Top worst tables / queries, supplement coverage gaps, week-over-week degradation alerts.' },
    { id: 'writerAdvisor', label: 'Writer Advisor', icon: <HealthIcon fontSize="small" />,
      stability: 'alpha', hint: 'Phase 149 charter P2 — actionable per-table partition / bucket / sort-order recommendations the writer team can adopt. Closes the brain feedback loop: when reads consistently hit weak pruning on a column, the source table gets a fix.' },
    { id: 'icebergMirror', label: 'Iceberg Mirror', icon: <StorageIcon fontSize="small" />,
      stability: 'alpha', hint: 'Phase 150 — consolidated read-side mirror of an iceberg snapshot in QS-internal bucket. Routing OFF by default. Flip iceberg.mirror.enabled + per-row routing_enabled after observing zero dual-run divergence.' },
    { id: 'plainParquetBrain', label: 'Plain Parquet Brain', icon: <StorageIcon fontSize="small" />,
      stability: 'alpha', hint: 'Phase 151 — extends supplement / bloom / mirror to plain-parquet S3 tables. Refresh bloom or supplement for a specific business_date (or any partition value) without scanning the whole directory. Mirror routing OFF by default — flip plain_parquet.mirror.enabled + routing_enabled after divergence-free SHADOW soak.' },
    { id: 'outputGateway', label: 'Output Gateway', icon: <StorageIcon fontSize="small" />,
      stability: 'alpha', hint: 'Phase 150 — S3-backed result_cache extension. Big-scan queries (post-prune file count > output_gateway.min_files_threshold) memoize their consolidated parquet to QS-internal S3 so repeat runs across pods share the result. OFF by default.' },
    { id: 'backgroundJobs',  label: 'Background Jobs',       icon: <HistoryIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-308 — start/stop every background task (sync loops, schedulers, etc.) from one place.' },
    { id: 'customJobs',      label: 'Custom Jobs (cron)',    icon: <HistoryIcon fontSize="small" />,
      stability: 'beta', hint: 'BF-312 — admin can schedule webhook / SQL / iceberg-sync / cache-clear on cron expressions.' },
    { id: 'proxy',           label: 'Corporate Proxy',      icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 140-A — flip proxy.enabled when VPC endpoint goes live. Backend restart required.' },
    { id: 'vpcCheck',        label: 'VPC + S3 Check',        icon: <StorageIcon fontSize="small" />,
      stability: 'beta', hint: 'Run the 6-layer connectivity probe from the browser — same logic as tools/qs_vpc_check.py.' },
    { id: 'auditLog',        label: 'Audit Log',           icon: <HistoryIcon fontSize="small" /> },
    { id: 'auditExplorer',   label: 'Audit Explorer',      icon: <HistoryIcon fontSize="small" /> },
    { id: 'auditCompliance', label: 'Audit & Compliance',  icon: <GppGoodIcon fontSize="small" /> },
  ]},
  { group: 'REPORTING', items: [
    { id: 'reportCatalog',      label: 'Report Catalog',       icon: <SettingsIcon fontSize="small" /> },
    { id: 'businessPortal',     label: 'Business Portal',      icon: <SettingsIcon fontSize="small" /> },
    { id: 'delivery',           label: 'Delivery & Alerts',    icon: <SettingsIcon fontSize="small" /> },
    { id: 'rlsPolicies',        label: 'Report RLS (legacy)',   icon: <AuditIcon fontSize="small" /> },
    { id: 'rowSecurity',        label: 'Row & Column Security', icon: <GppGoodIcon fontSize="small" />,
      stability: 'beta', hint: 'Phase 141 — Lake-Formation-equivalent generic row & column policies. Disabled by default; flip row_security.enabled.' },
    { id: 'connectionProfiles', label: 'Connection Profiles',  icon: <SwapHorizIcon fontSize="small" /> },
    { id: 'workspaces',         label: 'Workspaces',           icon: <WorkspacesIcon fontSize="small" /> },
  ]},
  { group: 'INTEGRATIONS', items: [
    { id: 'awsPortal', label: 'AWS Portal', icon: <StorageIcon fontSize="small" /> },
    { id: 'agents', label: 'Self-Healing Agents', icon: <HealthIcon fontSize="small" />,
      stability: 'beta', hint: 'agents.enabled defaults false; auto-fix UI works without it' },
  ]},
  { group: 'ACCESS CONTROL', items: [
    { id: 'uiVisibility', label: 'UI Visibility', icon: <VisibilityOffIcon fontSize="small" /> },
    { id: 'apiKeyRequests', label: 'API Key Requests', icon: <AuditIcon fontSize="small" /> },
  ]},
];

// Bug D fix — populate the deep-link guard set from the section catalog
// above.  Any item registered in ADMIN_SECTIONS becomes a valid
// `?section=<id>` target; anything else falls back to the default.
for (const _group of ADMIN_SECTIONS) {
  for (const _item of _group.items) {
    SECTION_DEFS_FLAT.add(_item.id);
  }
}

// Stability badge styling — small chip rendered next to the section label.
const STABILITY_STYLES: Record<StabilityLevel, { bg: string; fg: string; label: string }> = {
  stable: { bg: '#e8f5e9', fg: '#2e7d32', label: 'STABLE' },
  beta:   { bg: '#fff3e0', fg: '#e65100', label: 'BETA' },
  alpha:  { bg: '#ffebee', fg: '#c62828', label: 'ALPHA' },
};

// All sections are self-contained; polling is handled by each extracted component.
const POLL_CONFIG: Partial<Record<AdminSection, { keys: string[]; interval: number }>> = {};

// ══ Main component ══════════════════════════════════════════════════════════
const AdminPage = () => {
  const { addNotification } = useNotifications();
  const theme = useTheme();

  // ── Active section ──
  // Bug D fix — honor deep-links of the form /admin?section=<id>.  The
  // Phase 148 PruningHealthSection emits this shape for "click to
  // diagnose" links from the worst-queries table.  Without URL-param
  // parsing here, those links land on Active Queries instead of the
  // requested section.  Per-section components can read
  // ``execution_id`` etc. from the same URL when they need it.
  const _initialSection: AdminSection = (() => {
    try {
      const sp = new URLSearchParams(window.location.search);
      const s = (sp.get('section') || '') as AdminSection;
      // Guard against an attacker / typo seeding an invalid section
      // (would crash the renderer lookup); fall back to the default.
      if (s && SECTION_DEFS_FLAT.has(s)) return s;
    } catch { /* SSR / no window */ }
    return 'activeQueries';
  })();
  const [activeSection, setActiveSection] = useState<AdminSection>(_initialSection);

  // Listen for in-app pushState navigations so deep-links from inside
  // other sections (Pruning Health → Query Diagnostic) re-route without
  // a full reload.
  useEffect(() => {
    const onPop = () => {
      try {
        const sp = new URLSearchParams(window.location.search);
        const s = (sp.get('section') || '') as AdminSection;
        if (s && SECTION_DEFS_FLAT.has(s)) setActiveSection(s);
      } catch { /* no-op */ }
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const [activeQ,     setActiveQ]     = useState<any[]>([]);
  const [loading,     setLoading]     = useState({
    activeQ: true,
  });

  const setOne = (k: string, v: boolean) =>
    setLoading(prev => ({ ...prev, [k]: v }));

  // ── Data loading ──────────────────────────────────────────────────────────
  const loadSection = useCallback(async (section: string) => {
    setOne(section, true);
    try {
      switch (section) {
        case 'activeQ': {
          const d = await safeFetch('/api/admin/active-queries');
          setActiveQ(toArray(d));  // BF-430E
          break;
        }
      }
    } catch (err: any) {
      // section-specific error handling handled by extracted components
    }
    setOne(section, false);
  }, []); // eslint-disable-line

  // ── Fetch active query count for nav badge (initial + 30s poll) ───────────
  useEffect(() => {
    loadSection('activeQ');
    const t = setInterval(() => loadSection('activeQ'), 30_000);
    return () => clearInterval(t);
  }, []); // eslint-disable-line

  // ── Derived ──────────────────────────────────────────────────────────────
  const totalActive  = activeQ.length;

  // ── Renderer map ──
  const RENDERERS: Record<AdminSection, () => React.ReactNode> = {
    activeQueries:  () => <ActiveQueriesSection addNotification={addNotification} />,
    systemHealth:   () => <SystemHealthSection />,
    selfTest:       () => <SelfTestSection addNotification={addNotification} />,
    workerPool:     () => <WorkerPoolSection addNotification={addNotification} />,
    apiRequestBuilder: () => <ApiRequestBuilderSection />,
    queryDiagnostic:   () => <QueryDiagnosticSection />,
    columnStatsStatus: () => <ColumnStatsStatusSection />,
    brainOverview: () => <BrainOverviewSection />,
    pruningHealth: () => <PruningHealthSection />,
    writerAdvisor: () => <WriterAdvisorSection />,
    icebergMirror: () => <IcebergMirrorStatusSection />,
    plainParquetBrain: () => <PlainParquetBrainSection />,
    outputGateway: () => <OutputGatewayStatusSection />,
    operationsDashboard: () => <OperationsDashboardSection />,
    appConfig:      () => <AppConfigSection addNotification={addNotification} />,
    queueConfig:    () => <QueueConfigSection addNotification={addNotification} />,
    scheduler:      () => <SchedulerSection addNotification={addNotification} />,
    userManagement: () => <UserManagementSection addNotification={addNotification} />,
    userActivity:   () => <UserActivitySection />,
    storageOverview: () => <StorageOverviewSection addNotification={addNotification} />,
    storage:        () => <StorageSection addNotification={addNotification} />,
    cache:          () => <CacheSection addNotification={addNotification} />,
    aggCache:       () => <AggCacheSection addNotification={addNotification} />,
    resultCache:    () => <ResultCacheSection addNotification={addNotification} />,
    multiWorker:    () => <MultiWorkerSection addNotification={addNotification} />,
    multiPod:       () => <MultiPodSection addNotification={addNotification} />,
    engineRouter:   () => <EngineRouterSection addNotification={addNotification} />,
    auditLog:       () => <AuditLogSection />,
    governance:         () => <GovernanceAdminSection />,
    auditExplorer:      () => <AuditExplorerAdminSection />,
    cacheExplorer:      () => <CacheExplorerAdminSection />,
    rlsPolicies:        () => <RLSAdminSection />,
    rowSecurity:        () => <RowSecurityAdminSection addNotification={addNotification} />,
    connectionProfiles: () => <ConnectionProfilesAdminSection />,
    workspaces:         () => <WorkspaceAdminSection />,
    auditCompliance:    () => <AuditComplianceAdminSection />,
    uiVisibility:       () => <UIVisibilityAdminSection />,
    reportCatalog:      () => <ReportCatalogAdminSection />,
    businessPortal:     () => <BusinessPortalAdminSection />,
    delivery:           () => <DeliveryAdminSection />,
    awsPortal:          () => <AWSPortalSection addNotification={addNotification} />,
    agents:             () => <AgentsAdminSection addNotification={addNotification} />,
    cacheTelemetry:     () => <CacheTelemetrySection />,
    s3Performance:      () => <S3PerformanceSection />,
    scanStrategy:       () => <ScanStrategyAdminSection />,
    sparkConnect:       () => <SparkConnectSection />,
    feedFailover:       () => <FeedFailoverSection />,
    feedEtlDeps:        () => <FeedEtlDependenciesAdminSection />,
    userGroups:         () => <UserGroupsAdminSection />,
    s3Readers:          () => <S3ReadersAdminSection />,
    icebergWriter:      () => <IcebergWriterSection />,
    iceberg:            () => <IcebergSection />,
    icebergMetaSync:    () => <IcebergMetadataSyncSection />,
    backgroundJobs:     () => <BackgroundJobsSection />,
    customJobs:         () => <CustomJobsSection />,
    proxy:              () => <ProxySection />,
    vpcCheck:           () => <VpcCheckSection />,
    apiKeyRequests:     () => <ApiKeyRequestsSection />,
  };

  // Find current section label
  const currentLabel = ADMIN_SECTIONS.flatMap(g => g.items).find(i => i.id === activeSection)?.label ?? '';

  // ══════════════════════════════════════════════════════════════════════════
  // ── Render ────────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════
  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 64px)' }}>

      {/* ── Left nav sidebar ── */}
      <Box sx={{
        width: 220,
        flexShrink: 0,
        borderRight: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        overflowY: 'auto',
        py: 1,
      }}>
        {/* Mini header */}
        <Box sx={{ px: 2, py: 1.5, mb: 0.5 }}>
          <Typography variant="subtitle2" fontWeight={700}>Admin Panel</Typography>
        </Box>
        <Divider />

        {ADMIN_SECTIONS.map(group => (
          <Fragment key={group.group}>
            <Typography
              variant="overline"
              sx={{
                px: 2, pt: 2, pb: 0.5, display: 'block',
                color: 'text.disabled', fontSize: '0.6rem', letterSpacing: 1.2,
              }}
            >
              {group.group}
            </Typography>
            <List disablePadding>
              {group.items.map(item => (
                <ListItemButton
                  key={item.id}
                  selected={activeSection === item.id}
                  onClick={() => setActiveSection(item.id)}
                  sx={{
                    minHeight: 38,
                    px: 2,
                    py: 0.25,
                    '&.Mui-selected': {
                      bgcolor: 'action.selected',
                      borderRight: 3,
                      borderColor: 'primary.main',
                    },
                  }}
                >
                  <ListItemIcon sx={{
                    minWidth: 30,
                    color: activeSection === item.id ? 'primary.main' : 'text.secondary',
                  }}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    primaryTypographyProps={{
                      fontSize: '0.82rem',
                      fontWeight: activeSection === item.id ? 600 : 400,
                    }}
                  />
                  {/* Phase 139 honest-fix #4 — stability marker (BETA / ALPHA) */}
                  {item.stability && item.stability !== 'stable' && (
                    <Tooltip title={item.hint || `Stability: ${item.stability}`} arrow placement="right">
                      <Chip
                        size="small"
                        label={STABILITY_STYLES[item.stability].label}
                        sx={{
                          height: 16, fontSize: 9, fontWeight: 700, ml: 0.5,
                          bgcolor: STABILITY_STYLES[item.stability].bg,
                          color:   STABILITY_STYLES[item.stability].fg,
                          '& .MuiChip-label': { px: 0.6 },
                        }}
                        data-stability-badge={item.stability}
                      />
                    </Tooltip>
                  )}
                  {/* Badge for active queries count */}
                  {item.id === 'activeQueries' && totalActive > 0 && (
                    <Chip size="small" label={totalActive} color="error"
                      sx={{ height: 18, fontSize: 10, fontWeight: 700, ml: 0.5 }} />
                  )}
                </ListItemButton>
              ))}
            </List>
          </Fragment>
        ))}
      </Box>

      {/* ── Right content panel ── */}
      <Box sx={{ flex: 1, overflow: 'auto', p: 3 }}>
        {/* Content header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
          <Typography variant="h5" fontWeight={700}>{currentLabel}</Typography>
        </Box>

        {/* Active section content — wrapped in <Suspense> so the brief
            chunk-fetch on first click of each section shows a non-blocking
            progress indicator instead of a blank panel.  Lazy chunks are
            cached by the browser after first load, so subsequent clicks
            of the same section are instant. */}
        <Suspense
          fallback={
            <Box sx={{ pt: 0.5 }}>
              <LinearProgress />
              <Typography variant="caption" color="text.secondary"
                sx={{ display: 'block', mt: 1 }}>
                Loading section…
              </Typography>
            </Box>
          }
        >
          {RENDERERS[activeSection]?.()}
        </Suspense>
      </Box>

    </Box>
  );
};

export default AdminPage;
