/**
 * UserGroupsPage — Phase 130 hotfix-7 Entitlement Groups admin
 *
 * Admin CRUD for user_groups + user_group_members.  Members of a group
 * inherit owner-equivalent permissions on resources whose
 * owner_group_id == this group's id.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Stack, Alert, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, FormControlLabel, Switch, Chip,
  Select, MenuItem, FormControl, InputLabel, Divider, Tooltip,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Refresh as RefreshIcon, Group as GroupIcon,
  PersonAdd as PersonAddIcon,
} from '@mui/icons-material';
import api from '../services/api';

type UserGroup = {
  id: number;
  name: string;
  description?: string | null;
  is_active: boolean;
  created_by?: string | null;
  created_at?: string | null;
  members?: GroupMember[];
};

type GroupMember = {
  id: number;
  group_id: number;
  username: string;
  role_in_group: string;
  added_by?: string | null;
  added_at?: string | null;
};

const UserGroupsPage: React.FC = () => {
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<UserGroup | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list: any = await api.listUserGroups();
      const items: UserGroup[] = Array.isArray(list) ? list : (list?.items ?? []);
      // Hydrate each group with its members so the table can show counts
      const hydrated = await Promise.all(items.map(async g => {
        try {
          const full: any = await api.getUserGroup(g.id);
          return { ...g, members: full?.members || [] };
        } catch { return g; }
      }));
      setGroups(hydrated);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (g: UserGroup) => {
    if (!window.confirm(`Delete group "${g.name}"?  Members will be removed.  Feeds with this group as owner will lose group-based access (individual owner unchanged).`)) return;
    try {
      await api.deleteUserGroup(g.id);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Stack>
          <Typography variant="h5">Entitlement Groups</Typography>
          <Typography variant="caption" color="text.secondary">
            Group users together so feeds (and other resources) can have shared ownership.  Members can rerun, cancel, and edit the feeds their group owns.
          </Typography>
        </Stack>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setCreating(true)}>
            New Group
          </Button>
        </Stack>
      </Stack>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>
      )}

      <Paper>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Members</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Created By</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                <CircularProgress size={22} />
              </TableCell></TableRow>
            )}
            {!loading && groups.length === 0 && (
              <TableRow><TableCell colSpan={7} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                No groups yet.  Click <strong>New Group</strong> to create one.
              </TableCell></TableRow>
            )}
            {groups.map(g => (
              <TableRow key={g.id} hover>
                <TableCell>{g.id}</TableCell>
                <TableCell>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <GroupIcon fontSize="small" color="action" />
                    <strong>{g.name}</strong>
                  </Stack>
                </TableCell>
                <TableCell>
                  <Typography variant="caption" color="text.secondary">
                    {g.description || '—'}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Tooltip title={(g.members || []).map(m => m.username).join(', ') || '(none)'}>
                    <Chip
                      label={`${(g.members || []).length} member${(g.members || []).length === 1 ? '' : 's'}`}
                      size="small"
                      variant="outlined"
                    />
                  </Tooltip>
                </TableCell>
                <TableCell>
                  <Chip label={g.is_active ? 'Active' : 'Inactive'}
                        color={g.is_active ? 'success' : 'default'} size="small" />
                </TableCell>
                <TableCell><Typography variant="caption">{g.created_by || '—'}</Typography></TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => setEditing(g)}><EditIcon fontSize="small" /></IconButton>
                  <IconButton size="small" onClick={() => handleDelete(g)}><DeleteIcon fontSize="small" /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>

      {creating && (
        <GroupDialog
          onClose={() => setCreating(false)}
          onSaved={async () => { setCreating(false); await load(); }}
        />
      )}
      {editing && (
        <GroupEditDialog
          group={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => { setEditing(null); await load(); }}
          onError={setError}
        />
      )}
    </Box>
  );
};


/* ── Create dialog ───────────────────────────────────────────────── */

const GroupDialog: React.FC<{
  onClose: () => void;
  onSaved: () => void;
}> = ({ onClose, onSaved }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const handleSave = async () => {
    if (!name.trim()) { setErr('Name is required'); return; }
    setBusy(true); setErr(null);
    try {
      await api.createUserGroup({
        name: name.trim(),
        description: description.trim() || undefined,
        is_active: true,
      });
      onSaved();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>New Entitlement Group</DialogTitle>
      <DialogContent>
        {err && <Alert severity="error" sx={{ mb: 2 }}>{err}</Alert>}
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField label="Group Name" value={name} onChange={e => setName(e.target.value)}
                     placeholder="trading-desk-l1" required fullWidth size="small"
                     helperText="Short identifier — lowercase + hyphens recommended" />
          <TextField label="Description" value={description}
                     onChange={e => setDescription(e.target.value)}
                     multiline rows={2} fullWidth size="small" />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={busy}>
          {busy ? <CircularProgress size={16} /> : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};


/* ── Edit dialog with member management ──────────────────────────── */

const GroupEditDialog: React.FC<{
  group: UserGroup;
  onClose: () => void;
  onSaved: () => void;
  onError: (msg: string) => void;
}> = ({ group, onClose, onSaved, onError }) => {
  const [description, setDescription] = useState(group.description || '');
  const [isActive, setIsActive] = useState(group.is_active);
  const [members, setMembers] = useState<GroupMember[]>(group.members || []);
  const [newUsername, setNewUsername] = useState('');
  const [newRole, setNewRole] = useState('member');
  const [busy, setBusy] = useState(false);

  const saveSettings = async () => {
    setBusy(true);
    try {
      await api.updateUserGroup(group.id, {
        description: description || null,
        is_active: isActive,
      });
      onSaved();
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const addMember = async () => {
    if (!newUsername.trim()) return;
    setBusy(true);
    try {
      const row: any = await api.addUserGroupMember(group.id, {
        username: newUsername.trim(),
        role_in_group: newRole,
      });
      setMembers(m => [...m, row]
        .sort((a, b) => a.username.localeCompare(b.username)));
      setNewUsername('');
      setNewRole('member');
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const removeMember = async (username: string) => {
    setBusy(true);
    try {
      await api.removeUserGroupMember(group.id, username);
      setMembers(m => m.filter(x => x.username !== username));
    } catch (e: any) {
      onError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems="center">
          <GroupIcon /> <span>{group.name}</span>
        </Stack>
      </DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField label="Description" value={description}
                     onChange={e => setDescription(e.target.value)}
                     multiline rows={2} fullWidth size="small" />
          <FormControlLabel
            control={<Switch checked={isActive} onChange={e => setIsActive(e.target.checked)} />}
            label="Active"
          />
          <Button onClick={saveSettings} variant="outlined" disabled={busy} sx={{ alignSelf: 'flex-start' }}>
            Save settings
          </Button>

          <Divider />

          <Typography variant="subtitle1">Members ({members.length})</Typography>
          <Stack direction="row" spacing={1} alignItems="flex-end">
            <TextField label="Username" size="small" value={newUsername}
                       onChange={e => setNewUsername(e.target.value)}
                       placeholder="alice"
                       sx={{ flex: 1 }} />
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>Role</InputLabel>
              <Select value={newRole} label="Role" onChange={e => setNewRole(e.target.value)}>
                <MenuItem value="member">member</MenuItem>
                <MenuItem value="owner">owner</MenuItem>
                <MenuItem value="admin">admin</MenuItem>
              </Select>
            </FormControl>
            <Button startIcon={<PersonAddIcon />} onClick={addMember}
                    disabled={busy || !newUsername.trim()}>
              Add
            </Button>
          </Stack>

          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Username</TableCell>
                <TableCell>Role</TableCell>
                <TableCell>Added By</TableCell>
                <TableCell align="right" />
              </TableRow>
            </TableHead>
            <TableBody>
              {members.length === 0 && (
                <TableRow><TableCell colSpan={4} align="center" sx={{ color: 'text.secondary' }}>
                  No members yet.  Add one above.
                </TableCell></TableRow>
              )}
              {members.map(m => (
                <TableRow key={m.id}>
                  <TableCell><strong>{m.username}</strong></TableCell>
                  <TableCell>
                    <Chip label={m.role_in_group} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell><Typography variant="caption">{m.added_by || '—'}</Typography></TableCell>
                  <TableCell align="right">
                    <IconButton size="small" onClick={() => removeMember(m.username)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default UserGroupsPage;
