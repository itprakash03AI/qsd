/**
 * Agent Suggestion Inline — embedded in error displays.
 *
 * When a query fails and the Self-Healing Agent (Phase 120) classifies the
 * error with a non-auto-retry strategy, this component renders the suggestion
 * inline with the error message — instead of relying on the separate
 * `agent_suggestion` notification toast that's easy to miss.
 *
 * Surfaces a friendly explanation per strategy + an action button when the
 * fix is something the user can apply with one click (e.g. "add partition
 * filter", "refresh credentials").
 */
import React from 'react';
import {
  Box, Typography, Button, Stack, Chip, Tooltip,
} from '@mui/material';
import {
  AutoFixHigh as FixIcon, OpenInNew as OpenIcon,
  Refresh as RefreshIcon, FilterAlt as FilterIcon,
  MemoryOutlined as MemoryIcon,
} from '@mui/icons-material';

// ── Type ────────────────────────────────────────────────────────────────────
export interface AgentSuggestion {
  agent: string;
  strategy: string;
  reason?: string;
  cte_analysis?: { table: string; missing_partition_columns: string[] }[];
  /** BF-414 — backend may include strategy-specific hints (e.g.
   *  ``add_partition_filter`` returns ``partition_columns: string[]``).
   *  The shape varies per strategy so this is intentionally untyped. */
  retry_params?: Record<string, unknown>;
}

interface Props {
  suggestion: AgentSuggestion | null | undefined;
  /** Optional handler — called when user clicks the apply / try-fix button.
   *  Receives the strategy + reason so the parent can decide what to do
   *  (e.g. open partition filter modal, refresh connection, retry). */
  onApply?: (suggestion: AgentSuggestion) => void;
}

// ── Strategy → display metadata mapping ─────────────────────────────────────
const STRATEGY_DETAILS: Record<string, {
  label: string;
  description: string;
  icon: React.ReactElement;
  actionable: boolean;
  buttonLabel?: string;
}> = {
  add_partition_filter: {
    label: 'Add partition filter',
    description: 'Your query scans every partition.  Add a WHERE clause on a partition column to scan only the relevant files.',
    icon: <FilterIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Add filter',
  },
  reduce_memory: {
    label: 'Reduce memory pressure',
    description: 'The query exceeded available memory. Try LIMIT, narrower SELECT, or a smaller date range.',
    icon: <MemoryIcon fontSize="small" />,
    actionable: false,
  },
  refresh_credentials: {
    label: 'Refresh credentials',
    description: 'S3 / database credentials expired. Reconnect or refresh your session token.',
    icon: <RefreshIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Open connection',
  },
  refresh_schema: {
    label: 'Refresh schema',
    description: 'The underlying table schema changed. Reload the column list and retry.',
    icon: <RefreshIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Reload schema',
  },
  reinstall_extension: {
    label: 'DuckDB extension issue',
    description: 'A required DuckDB extension (httpfs, iceberg) failed to load.  The platform can reinstall it automatically.',
    icon: <FixIcon fontSize="small" />,
    actionable: false,
  },
  simplify_query: {
    label: 'Simplify the query',
    description: 'Query is too complex or contains a syntax issue. Consider splitting it or removing nested CTEs.',
    icon: <FixIcon fontSize="small" />,
    actionable: false,
  },
  retry_with_backoff: {
    label: 'Transient error',
    description: 'Looks transient (network, throttling). Retrying may succeed.',
    icon: <RefreshIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Retry',
  },
  add_group_by: {
    label: 'Add GROUP BY clause',
    description: 'Aggregate function (SUM / AVG / COUNT…) is mixed with non-aggregated columns. Add a GROUP BY for every column that is not inside an aggregate, OR remove the non-aggregated columns from SELECT.',
    icon: <FixIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Auto-fix SQL',
  },
  // BF-288: ambiguous-column auto-fix.  Without this entry the strategy
  // fell into FALLBACK_DETAIL (actionable=false) and the user saw the
  // suggestion text but no button — which was BF-277's whole point.
  qualify_ambiguous_columns: {
    label: 'Qualify ambiguous columns',
    description: 'A column you reference exists in multiple FROM tables. Auto-fix prefixes it with the first table\'s alias (e.g. a.col).',
    icon: <FixIcon fontSize="small" />,
    actionable: true,
    buttonLabel: 'Auto-fix SQL',
  },
  check_sql_syntax: {
    label: 'SQL syntax error',
    description: 'Review the query for typos, missing commas, or unclosed quotes.',
    icon: <FixIcon fontSize="small" />,
    actionable: false,
  },
};

const FALLBACK_DETAIL: {
  label: string;
  description: string;
  icon: React.ReactElement;
  actionable: boolean;
  buttonLabel?: string;
} = {
  label: 'Suggestion',
  description: '',
  icon: <FixIcon fontSize="small" />,
  actionable: false,
};

const AgentSuggestionInline: React.FC<Props> = ({ suggestion, onApply }) => {
  if (!suggestion || !suggestion.strategy) return null;

  const detail = STRATEGY_DETAILS[suggestion.strategy] || {
    ...FALLBACK_DETAIL,
    label: suggestion.strategy.replace(/_/g, ' '),
  };

  return (
    <Box
      data-testid="agent-suggestion-inline"
      sx={{
        mt: 1, p: 1.25, borderRadius: 1.5,
        border: '1px solid', borderColor: 'info.light',
        bgcolor: 'info.lighter',
        bgcolorAlt: 'rgba(33, 150, 243, 0.06)',
      }}
      style={{ background: 'rgba(33, 150, 243, 0.06)' }}
    >
      <Stack direction="row" spacing={1} alignItems="flex-start">
        <Box sx={{ pt: 0.25, color: 'info.main' }}>
          {detail.icon}
        </Box>
        <Box sx={{ flexGrow: 1, minWidth: 0 }}>
          <Stack direction="row" spacing={0.75} alignItems="center" mb={0.25}>
            <Typography variant="body2" fontWeight={600}>
              {detail.label}
            </Typography>
            <Tooltip title="Detected by the Self-Healing Agent">
              <Chip
                label="AI"
                size="small"
                sx={{ height: 16, fontSize: 9, fontWeight: 600 }}
              />
            </Tooltip>
          </Stack>
          {(suggestion.reason || detail.description) && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              {suggestion.reason || detail.description}
            </Typography>
          )}

          {/* CTE analysis — show which tables are missing partition filters */}
          {suggestion.cte_analysis && suggestion.cte_analysis.length > 0 && (
            <Box sx={{ mt: 0.75 }}>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.25 }}>
                Tables missing partition filters:
              </Typography>
              <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', gap: 0.5 }}>
                {suggestion.cte_analysis.map((c, i) => (
                  <Chip
                    key={i}
                    size="small"
                    label={`${c.table}: ${(c.missing_partition_columns || []).join(', ')}`}
                    sx={{ fontSize: 10, height: 20 }}
                  />
                ))}
              </Stack>
            </Box>
          )}
        </Box>
        {detail.actionable && onApply && (
          <Button
            size="small"
            variant="outlined"
            startIcon={<OpenIcon fontSize="small" />}
            onClick={() => onApply(suggestion)}
            sx={{ flexShrink: 0, textTransform: 'none', whiteSpace: 'nowrap' }}
          >
            {detail.buttonLabel}
          </Button>
        )}
      </Stack>
    </Box>
  );
};

export default AgentSuggestionInline;
