/**
 * SQL Query Page — Enterprise SQL editor for Trino/Starburst, Snowflake, Databricks
 *
 * Layout: Superset-style
 *   Left  (300px) — Connection + Schema Browser (catalogs → schemas → tables → columns)
 *   Center         — Primary SQL editor + optional secondary SQL editor for cross-source joins
 *   Results        — DataGridViewer (same as Query Builder)
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { alpha } from '@mui/material/styles';
import {
  Box, Typography, Button, Paper, Chip, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, MenuItem, IconButton, Tooltip, Stack, Divider,
  List, ListItem, ListItemButton, ListItemText, ListItemIcon,
  Collapse, InputAdornment, Alert, LinearProgress,
  ToggleButton, ToggleButtonGroup, Tabs, Tab,
  useMediaQuery,
} from '@mui/material';
import {
  PlayArrow as RunIcon, Save as SaveIcon, Add as AddIcon,
  Delete as DeleteIcon, Edit as EditIcon, Refresh as RefreshIcon,
  Storage as CatalogIcon, Schema as SchemaIcon, TableChart as TableIcon,
  ViewColumn as ColumnIcon, ExpandMore as ExpandMoreIcon,
  ChevronRight as ChevronRightIcon, ContentCopy as CopyIcon,
  Link as JoinIcon, Close as CloseIcon, Search as SearchIcon,
  Bookmark as BookmarkIcon, Code as CodeIcon, CheckCircle as CheckIcon,
  Cancel as CancelIcon, Menu as MenuIcon,
  Stream as StreamIcon, CloudDownload as CloudDownloadIcon,
  AutoAwesome as NLIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import { useAssistantContext } from '../context/AssistantContext';
import DataGridViewer from './DataGridViewer';
import NLToSQLPanel from './NLToSQLPanel';
import QueryWarningBanner from './QueryWarningBanner';
import api from '../services/api';
import { toArray } from '../utils/toArray';
import { safeFetch } from '../services/api/core';
import { useServerDraft } from '../hooks/useServerDraft';

const SCHEMA_PANEL_W = 300;
const fmtSecs = (s: number) => {
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60), sec = s % 60;
  return sec > 0 ? `${m}m ${sec}s` : `${m}m`;
};

// ── Type badge ────────────────────────────────────────────────────────────────
const ConnTypeBadge = ({ type }) => {
  const colors = {
    trino: '#3b82f6', starburst: '#f59e0b', snowflake: '#22d3ee', databricks: '#f97316',
    s3: '#22c55e',
  };
  return (
    <Chip
      label={(type || '').toUpperCase()}
      size="small"
      sx={{
        fontSize: 10, height: 18, fontWeight: 700,
        bgcolor: colors[type] || 'grey.400', color: 'white',
        '& .MuiChip-label': { px: 0.75 },
      }}
    />
  );
};

// Phase 142 — replaced the legacy plain-textarea SQL editor with the proper
// CodeMirror-based ``./SqlEditor`` component so SqlQueryPage gets the same
// syntax highlighting + schema-aware autocomplete as CQB / BQB.  The
// local wrapper preserves the prior API (value, onChange, label, schema).
import RealSqlEditor from './SqlEditor';

const SqlEditor = ({
  value, onChange, label, placeholder, schema,
}: {
  value: string; onChange: (v: string) => void;
  label?: string; placeholder?: string;
  schema?: Record<string, string[]>;
}) => (
  <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
    {label && (
      <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', px: 1.5, py: 0.5, borderBottom: 1, borderColor: 'divider', display: 'block', textTransform: 'uppercase', letterSpacing: 0.5, bgcolor: 'grey.50' }}>
        {label}
      </Typography>
    )}
    <RealSqlEditor
      value={value}
      onChange={onChange}
      schema={schema}
      placeholder={placeholder}
      minHeight="240px"
      maxHeight="60vh"
      showFormatButton
      showTemplatesButton
    />
  </Box>
);

// ── Schema tree node ──────────────────────────────────────────────────────────
const SchemaTreeNode = ({ label, icon, children, onInsert, depth = 0, loading = false, count = undefined, type }: {
  label: any; icon: any; children: any; onInsert: any;
  depth?: number; loading?: boolean; count?: any; type: any;
}) => {
  const [open, setOpen] = useState(false);
  const hasChildren = !!children;
  const iconColor = { catalog: 'primary.main', schema: 'warning.main', table: 'success.main', column: 'text.secondary' }[type] || 'text.secondary';

  return (
    <>
      <ListItem disablePadding>
        <ListItemButton
          onClick={() => { if (hasChildren) setOpen(o => !o); if (onInsert) onInsert(); }}
          sx={{
            pl: 1 + depth * 1.5,
            py: 0.4,
            '&:hover .insert-hint': { opacity: 1 },
          }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 24, color: iconColor }}>
            {loading ? <CircularProgress size={14} /> : icon}
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="body2" sx={{ fontSize: 13, lineHeight: 1.4, flexGrow: 1 }} noWrap>
                  {label}
                </Typography>
                {count !== undefined && (
                  <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0 }}>{count}</Typography>
                )}
              </Box>
            }
          />
          {hasChildren && (
            open ? <ExpandMoreIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
                 : <ChevronRightIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
          )}
        </ListItemButton>
      </ListItem>
      {hasChildren && (
        <Collapse in={open} unmountOnExit>
          {children}
        </Collapse>
      )}
    </>
  );
};

// ── Column list (leaf) ────────────────────────────────────────────────────────
const ColumnList = ({ columns, onInsert }) => (
  <List disablePadding>
    {columns.map(col => (
      <ListItem key={col.name} disablePadding>
        <ListItemButton
          onClick={() => onInsert(col.name)}
          sx={{ pl: 7, py: 0.25 }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 20 }}>
            <ColumnIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: 12, flexGrow: 1 }} noWrap>{col.name}</Typography>
                <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0, fontFamily: 'monospace' }}>{col.type}</Typography>
              </Box>
            }
          />
        </ListItemButton>
      </ListItem>
    ))}
  </List>
);

// ── Table tree with lazy-load ─────────────────────────────────────────────────
// `isS3`: when true, tables are registered parquet/iceberg tables — click-to-insert
// produces a starter `SELECT * FROM <table> WHERE <partition>='...' LIMIT 500` snippet
// using the first partition column from the backend response (Phase 108).
const TableTree = ({ connectionId, catalog, schema, onInsertTable, onInsertColumn, isS3 }) => {
  const [tables, setTables] = useState(null);
  const [columns, setColumns] = useState({});
  const [loadingTables, setLoadingTables] = useState(false);
  const [loadingCols, setLoadingCols] = useState({});

  useEffect(() => {
    setLoadingTables(true);
    api.listSqlTables(connectionId, catalog, schema)
      .then(setTables)
      .catch(() => setTables([]))
      .finally(() => setLoadingTables(false));
  }, [connectionId, catalog, schema]);

  const loadColumns = (tableName) => {
    if (columns[tableName] !== undefined) return;
    setLoadingCols(p => ({ ...p, [tableName]: true }));
    api.listSqlColumns(connectionId, catalog, schema, tableName)
      .then(cols => setColumns(p => ({ ...p, [tableName]: cols })))
      .catch(() => setColumns(p => ({ ...p, [tableName]: [] })))
      .finally(() => setLoadingCols(p => ({ ...p, [tableName]: false })));
  };

  const buildInsertText = (t) => {
    if (!isS3) return `${catalog}.${schema}.${t.name}`;
    const partCols = t.partition_columns || [];
    const partCol = partCols[0];
    if (partCol) {
      return `SELECT *\nFROM ${t.name}\nWHERE ${partCol} = 'value'\nLIMIT 500`;
    }
    return `SELECT *\nFROM ${t.name}\nLIMIT 500`;
  };

  if (loadingTables) return <Box sx={{ pl: 6, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!tables) return null;

  return (
    <List disablePadding>
      {tables.map(t => (
        <SchemaTreeNode
          key={t.name}
          label={t.name}
          icon={<TableIcon sx={{ fontSize: 14 }} />}
          depth={3}
          type="table"
          onInsert={() => { onInsertTable(buildInsertText(t), isS3); loadColumns(t.name); }}
          loading={loadingCols[t.name]}
          count={columns[t.name]?.length}
        >
          {(columns[t.name] !== undefined) && (
            <ColumnList
              columns={columns[t.name]}
              onInsert={col => onInsertColumn(isS3 ? col : `${catalog}.${schema}.${t.name}.${col}`)}
            />
          )}
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Schema tree ───────────────────────────────────────────────────────────────
const SchemaTree = ({ connectionId, catalog, onInsert, isS3 }) => {
  const [schemas, setSchemas] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.listSqlSchemas(connectionId, catalog)
      .then(setSchemas)
      .catch(() => setSchemas([]))
      .finally(() => setLoading(false));
  }, [connectionId, catalog]);

  if (loading) return <Box sx={{ pl: 5, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!schemas) return null;

  return (
    <List disablePadding>
      {schemas.map(s => (
        <SchemaTreeNode
          key={s}
          label={s}
          icon={<SchemaIcon sx={{ fontSize: 14 }} />}
          depth={2}
          type="schema"
          onInsert={() => onInsert(`${catalog}.${s}`)}
        >
          <TableTree
            connectionId={connectionId}
            catalog={catalog}
            schema={s}
            onInsertTable={onInsert}
            onInsertColumn={onInsert}
            isS3={isS3}
          />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Catalog tree ──────────────────────────────────────────────────────────────
const CatalogTree = ({ connectionId, onInsert, isS3 }) => {
  const [catalogs, setCatalogs] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = () => {
    setLoading(true);
    setError(null);
    api.listSqlCatalogs(connectionId)
      .then(setCatalogs)
      .catch(e => setError(e.message || 'Failed to load catalogs'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { if (connectionId) load(); }, [connectionId]);

  if (!connectionId) return (
    <Box sx={{ p: 2 }}>
      <Typography variant="caption" color="text.disabled">Select a connection to browse schema</Typography>
    </Box>
  );

  if (loading && !catalogs) return <Box sx={{ p: 2 }}><CircularProgress size={20} /></Box>;
  if (error) return (
    <Box sx={{ p: 1 }}>
      <Alert severity="error" sx={{ fontSize: 12 }} action={<Button size="small" onClick={load}>Retry</Button>}>{error}</Alert>
    </Box>
  );

  return (
    <List disablePadding>
      {(catalogs || []).map(cat => (
        <SchemaTreeNode
          key={cat}
          label={cat}
          icon={<CatalogIcon sx={{ fontSize: 14 }} />}
          depth={1}
          type="catalog"
          onInsert={() => onInsert(cat)}
        >
          <SchemaTree connectionId={connectionId} catalog={cat} onInsert={onInsert} isS3={isS3} />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Save Query Dialog ─────────────────────────────────────────────────────────
const SaveSqlQueryDialog = ({ open, onClose, onSaved, primaryConnectionId, primarySql, secondaryConnectionId, secondarySql, joinConfig, editingQuery }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    if (open) {
      setName(editingQuery?.name || '');
      setDescription(editingQuery?.description || '');
    }
  }, [open, editingQuery]);

  const handleSave = async () => {
    if (!name.trim()) { alert('Enter a query name'); return; }
    try {
      const payload = {
        name:                   name.trim(),
        description:            description || null,
        primary_connection_id:  primaryConnectionId,
        primary_sql:            primarySql,
        secondary_connection_id: secondaryConnectionId || null,
        secondary_sql:          secondaryConnectionId ? secondarySql : null,
        join_config:            secondaryConnectionId ? joinConfig : null,
      };
      let result;
      if (editingQuery?.id) {
        result = await api.updateSqlQuery(editingQuery.id, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated` });
      } else {
        result = await api.createSqlQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved` });
      }
      onSaved(result);
      onClose();
    } catch (e) {
      addNotification({ type: 'error', title: 'Save Error', message: e.message });
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <SaveIcon fontSize="small" />
        {editingQuery?.id ? 'Update SQL Query' : 'Save SQL Query'}
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField label="Name" required fullWidth value={name} onChange={e => setName(e.target.value)} />
          <TextField label="Description" fullWidth multiline rows={2} value={description} onChange={e => setDescription(e.target.value)} />
          {secondaryConnectionId && (
            <Alert severity="info" sx={{ fontSize: 12 }}>
              Cross-source join configuration will be saved with this query.
            </Alert>
          )}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {editingQuery?.id ? 'Update' : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ── Join Config Dialog ────────────────────────────────────────────────────────
const JoinConfigDialog = ({ open, onClose, config, onChange }) => {
  const [local, setLocal] = useState({ how: 'inner', left_on: '', right_on: '', ...config });

  useEffect(() => { if (open) setLocal({ how: 'inner', left_on: '', right_on: '', ...config }); }, [open]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Cross-Source Join Configuration</DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField select label="Join Type" fullWidth size="small" value={local.how} onChange={e => setLocal(p => ({ ...p, how: e.target.value }))}>
            {['inner', 'left', 'right', 'outer'].map(h => (
              <MenuItem key={h} value={h}>{h.toUpperCase()} JOIN</MenuItem>
            ))}
          </TextField>
          <TextField label="Primary Key Column" placeholder="e.g. customer_id" fullWidth size="small" value={local.left_on} onChange={e => setLocal(p => ({ ...p, left_on: e.target.value }))} helperText="Column from primary source query" />
          <TextField label="Secondary Key Column" placeholder="e.g. id" fullWidth size="small" value={local.right_on} onChange={e => setLocal(p => ({ ...p, right_on: e.target.value }))} helperText="Column from secondary source query" />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onChange(local); onClose(); }}>Apply</Button>
      </DialogActions>
    </Dialog>
  );
};

// ── Saved Queries Panel ───────────────────────────────────────────────────────
const SavedQueriesPanel = ({ onLoad, onClose }) => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    api.listSqlQueries(true).then(d => setQueries(toArray(d))).catch(() => setQueries([])).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return q ? queries.filter(r => r.name.toLowerCase().includes(q)) : queries;
  }, [queries, search]);

  const handleDelete = async (query) => {
    if (!window.confirm(`Delete "${query.name}"?`)) return;
    try {
      await api.deleteSqlQuery(query.id);
      setQueries(prev => prev.filter(q => q.id !== query.id));
      addNotification({ type: 'success', title: 'Deleted', message: `"${query.name}" deleted` });
    } catch (e) {
      addNotification({ type: 'error', title: 'Delete Error', message: e.message });
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ p: 1.5, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, flexGrow: 1 }}>Saved SQL Queries</Typography>
        <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
      </Box>
      <Box sx={{ p: 1 }}>
        <TextField
          size="small" fullWidth placeholder="Search…" value={search}
          onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
        />
      </Box>
      <Box sx={{ flex: 1, overflowY: 'auto' }}>
        {loading ? <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress size={24} /></Box> : (
          filtered.map(q => (
            <Box key={q.id} sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', '&:hover': { bgcolor: 'action.hover' } }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" fontWeight={600} noWrap>{q.name}</Typography>
                  {q.secondary_connection_id && (
                    <Chip label="Cross-source" size="small" color="warning" sx={{ fontSize: 10, height: 16, mt: 0.25 }} />
                  )}
                  <Typography variant="caption" color="text.disabled" display="block">
                    {q.execution_count} runs · {q.created_at ? new Date(q.created_at).toLocaleDateString() : ''}
                  </Typography>
                </Box>
                <Tooltip title="Load into editor"><IconButton size="small" color="primary" onClick={() => onLoad(q)}><EditIcon fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => handleDelete(q)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
              </Box>
            </Box>
          ))
        )}
        {!loading && filtered.length === 0 && (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="caption" color="text.disabled">No saved SQL queries found</Typography>
          </Box>
        )}
      </Box>
    </Box>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ══════════════════════════════════════════════════════════════════════════════
const SqlQueryPage = () => {
  const { addNotification } = useNotifications();
  const { lastMessage } = useWebSocket();
  const isCompactScreen = useMediaQuery('(max-width:1280px)');
  const { setAssistantCtx } = useAssistantContext();

  // SQL connector connections (trino, starburst, snowflake, databricks) + all for type lookups
  const [sqlConnections, setSqlConnections] = useState([]);
  const allConnectionsRef = useRef<any[]>([]);
  const [connectionsLoading, setConnectionsLoading] = useState(true);
  const [schemaOpen, setSchemaOpen] = useState(!isCompactScreen);

  // Schema browser
  const [primaryConnId, setPrimaryConnId] = useState(null);
  const [schemaTarget, setSchemaTarget] = useState('primary'); // 'primary' | 'secondary'

  // SQL editors — Phase 142: server-side draft persistence (DB-backed).
  // Replaces the prior localStorage bandage with /api/user/drafts/* so
  // drafts survive refresh / device switch / cookie clear / pod restart.
  // Keys are namespaced by primary connection so each connection keeps
  // its own primary + secondary drafts independent.
  const _DEFAULT_PRIMARY = '-- Primary SQL Query\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000';
  const _DEFAULT_SECONDARY = '-- Secondary SQL Query (optional cross-source join)\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000';
  const _primaryDraftKey = `sqlpage.primary.${primaryConnId ?? 'none'}`;
  const _secondaryDraftKey = `sqlpage.secondary.${primaryConnId ?? 'none'}`;
  const [primarySql, setPrimarySql] = useServerDraft<string>(_primaryDraftKey, _DEFAULT_PRIMARY);
  const [secondaryConnId, setSecondaryConnId] = useState(null);
  const [secondarySql, setSecondarySql] = useServerDraft<string>(_secondaryDraftKey, _DEFAULT_SECONDARY);

  // Phase 142 — Schema-aware autocomplete: prefetch catalog/schema/table
  // metadata for the active SQL connector so the SqlEditor's CodeMirror
  // completion engine knows table + column names.  Keys: table → columns.
  // Lazy: only fetches if user has the connection selected.
  const [primarySchema, setPrimarySchema] = useState<Record<string, string[]>>({});
  const [secondarySchema, setSecondarySchema] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (!primaryConnId) { setPrimarySchema({}); return; }
    let cancelled = false;
    (async () => {
      try {
        const cats: any[] = await api.listSqlCatalogs(String(primaryConnId)).catch(() => []);
        if (!cats?.length || cancelled) return;
        const out: Record<string, string[]> = {};
        // Fetch only the FIRST catalog + first schema to keep it cheap.
        // The user usually queries one schema at a time; broader autocomplete
        // is a Phase 143 improvement that scans on-demand as they type.
        const cat = cats[0]?.name || cats[0];
        const schs: any[] = await api.listSqlSchemas(String(primaryConnId), cat).catch(() => []);
        if (!schs?.length || cancelled) return;
        const sch = schs[0]?.name || schs[0];
        const tabs: any[] = await api.listSqlTables(String(primaryConnId), cat, sch).catch(() => []);
        for (const t of (tabs || []).slice(0, 50)) {
          const tname = t?.name || t;
          // Bare name AND fully-qualified — user can type either form
          out[tname] = [];
          out[`${cat}.${sch}.${tname}`] = [];
        }
        if (!cancelled) setPrimarySchema(out);
      } catch { /* fail-open: no schema → no autocomplete */ }
    })();
    return () => { cancelled = true; };
  }, [primaryConnId]);

  useEffect(() => {
    if (!secondaryConnId) { setSecondarySchema({}); return; }
    let cancelled = false;
    (async () => {
      try {
        const cats: any[] = await api.listSqlCatalogs(String(secondaryConnId)).catch(() => []);
        if (!cats?.length || cancelled) return;
        const out: Record<string, string[]> = {};
        const cat = cats[0]?.name || cats[0];
        const schs: any[] = await api.listSqlSchemas(String(secondaryConnId), cat).catch(() => []);
        if (!schs?.length || cancelled) return;
        const sch = schs[0]?.name || schs[0];
        const tabs: any[] = await api.listSqlTables(String(secondaryConnId), cat, sch).catch(() => []);
        for (const t of (tabs || []).slice(0, 50)) {
          const tname = t?.name || t;
          out[tname] = [];
          out[`${cat}.${sch}.${tname}`] = [];
        }
        if (!cancelled) setSecondarySchema(out);
      } catch {}
    })();
    return () => { cancelled = true; };
  }, [secondaryConnId]);
  const [joinConfig, setJoinConfig] = useState({ how: 'inner', left_on: '', right_on: '' });
  const [showSecondary, setShowSecondary] = useState(false);

  // Dialogs
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showJoinConfig, setShowJoinConfig] = useState(false);
  const [showSavedPanel, setShowSavedPanel] = useState(false);
  const [editingQuery, setEditingQuery] = useState(null);

  // Execution
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const [resultsExecutionId, setResultsExecutionId] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [etaSeconds, setEtaSeconds] = useState(null);
  const execStartRef = useRef<number | null>(null);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Phase 47: Query warnings from pre-execution analysis
  const [queryWarnings, setQueryWarnings] = useState<any[]>([]);
  // BF-571/572: agent format-string auto-fixes (Starburst %i → DuckDB %M etc.)
  const [agentFormatFixes, setAgentFormatFixes] = useState<any[]>([]);

  // Phase 48: NL-to-SQL panel toggle + tables for schema context
  const [showNLPanel, setShowNLPanel] = useState(false);
  const [nlTables, setNlTables] = useState<string[]>([]);

  // Streaming source — enables DataGridViewer to paginate directly from S3
  const [enableStreaming, setEnableStreaming] = useState(true); // default ON for S3 connections
  const [streamBgDownload, setStreamBgDownload] = useState(true); // also run background S3→local download
  const [streamingSource, setStreamingSource] = useState<{ queryConfig?: any; rawSql?: string; connectionId: number } | null>(null);
  const [resultKey] = useState(0);

  // Cache strategy
  const [cacheStrategy, setCacheStrategy] = useState<'auto' | 'bypass' | 'refresh'>('auto');

  // Row limit
  const [rowLimit, setRowLimit] = useState(10000);

  // Active editor tab
  const [activeTab, setActiveTab] = useState(0);

  // Pick up SQL generated by GlobalAssistantPanel (navigate from any page)
  useEffect(() => {
    const pending = sessionStorage.getItem('nl_sql_pending');
    if (pending) {
      setPrimarySql(pending);
      sessionStorage.removeItem('nl_sql_pending');
    }
  }, []);

  // Load SQL connector connections on mount
  useEffect(() => {
    api.listConnections(true)
      .then(conns => {
        allConnectionsRef.current = conns || [];
        const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 's3'];
        setSqlConnections((conns || []).filter(c => SQL_TYPES.includes(c.connection_type)));
      })
      .catch(() => setSqlConnections([]))
      .finally(() => setConnectionsLoading(false));
  }, []);

  // Cleanup elapsed timer on unmount
  useEffect(() => {
    return () => { if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current); };
  }, []);

  // Load top-tables for NL panel when it opens or connection changes
  useEffect(() => {
    if (!showNLPanel || !primaryConnId) return;
    (api as any).getTopTables(primaryConnId)
      .then((r: any) => setNlTables((r?.tables || r || []).map((t: any) => t.table_name || t.object_name || t)))
      .catch(() => setNlTables([]));
  }, [showNLPanel, primaryConnId]);

  // Keep GlobalAssistantPanel context in sync with current SQL editor connection
  useEffect(() => {
    const conn = (sqlConnections as any[]).find((c: any) => c.id === primaryConnId);
    setAssistantCtx({
      connectionId: primaryConnId ?? undefined,
      connectionType: conn?.connection_type || 'duckdb',
      pageName: 'sql',
    });
  }, [primaryConnId, sqlConnections]);

  // WebSocket progress handler
  useEffect(() => {
    if (!lastMessage || lastMessage.execution_id !== executionId) return;
    const msg = lastMessage as any;
    if (msg.type === 'execution_progress') {
      setProgress({ status: msg.data?.status || 'processing', ...msg.data });
      if (msg.data?.status === 'completed') {
        if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
        const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
        setExecuting(false);
        setProgress({ status: 'completed', total_rows: msg.data.total_rows, elapsed: finalElapsed });
        setResultsExecutionId(executionId);
        setShowResults(true);
        // Seamless transition: clear streaming, DataGridViewer picks up executionId
        setStreamingSource(null);
      }
    } else if (msg.type === 'execution_completed') {
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
      setExecuting(false);
      setProgress({
        status: 'completed',
        total_rows: msg.stats?.total_rows,
        elapsed: finalElapsed,
        stale_warning: msg.stale_warning || null,
      });
      setResultsExecutionId(executionId);
      setShowResults(true);
      // Seamless transition: clear streaming, DataGridViewer picks up executionId
      setStreamingSource(null);
    } else if (msg.type === 'execution_failed') {
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      setExecuting(false);
      setStreamingSource(null);  // clear streaming so error is visible
      setProgress({ status: 'failed', error: msg.error });
    } else if (msg.type === 'execution_cancelled') {
      setStreamingSource(null);
    }
  }, [lastMessage, executionId]);

  const handleInsertText = useCallback((text, replace = false) => {
    const target = schemaTarget === 'secondary' ? secondarySql : primarySql;
    const setter = schemaTarget === 'secondary' ? setSecondarySql : setPrimarySql;
    // Phase 108: when `replace` is true (e.g. clicking an S3 starter snippet)
    // and the editor still holds the default placeholder, swap the content
    // entirely instead of appending a second SELECT block.
    const isPlaceholder = target.trim().startsWith('-- Primary SQL Query') ||
                          target.trim().startsWith('-- Secondary SQL Query') ||
                          target.trim() === '';
    if (replace && isPlaceholder) {
      setter(text);
      return;
    }
    setter(target + (target.endsWith('\n') ? '' : '\n') + text);
  }, [schemaTarget, primarySql, secondarySql]);

  const handleExecute = async () => {
    if (!primaryConnId) {
      addNotification({ type: 'warning', title: 'No Connection', message: 'Select a primary data source connection' });
      return;
    }
    if (!primarySql.trim()) {
      addNotification({ type: 'warning', title: 'Empty Query', message: 'Enter a SQL query to execute' });
      return;
    }
    if (showSecondary && secondaryConnId && (!joinConfig.left_on || !joinConfig.right_on)) {
      addNotification({ type: 'warning', title: 'Join Config Incomplete', message: 'Configure join columns before executing cross-source query' });
      setShowJoinConfig(true);
      return;
    }

    // Determine if stream-only (no background download)
    // Phase 108: reuse the memoized isPrimaryS3 derived flag.
    const streamOnly = enableStreaming && !streamBgDownload && isPrimaryS3 && !showSecondary;

    try {
      setExecuting(true);
      setShowResults(false);
      setProgress({ status: 'starting' });
      setElapsed(0);
      execStartRef.current = Date.now();
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      elapsedTimerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - (execStartRef.current ?? Date.now())) / 1000));
      }, 1000);

      if (streamOnly) {
        // ── Stream-only: no background S3→local download ──
        if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
        setStreamingSource({ rawSql: primarySql, connectionId: primaryConnId! });
        setShowResults(true);
        setExecuting(false);
        setProgress(null);
        addNotification({ type: 'info', title: 'Stream Only', message: 'Streaming directly from S3 — no background download' });
        return;
      }

      // ── Normal path: background download (+ optional streaming preview) ──
      safeFetch(`/api/admin/query-eta${primaryConnId ? `?connection_id=${primaryConnId}` : ''}`)
        .then(d => setEtaSeconds(d.p75_seconds ?? null)).catch(() => {});

      const payload = {
        primary_connection_id: primaryConnId,
        primary_sql: primarySql,
        row_limit: rowLimit || null,
        ...(showSecondary && secondaryConnId
          ? {
              secondary_connection_id: secondaryConnId,
              secondary_sql: secondarySql,
              join_config: joinConfig,
            }
          : {}),
      };

      if (cacheStrategy !== 'auto') (payload as any).cache_strategy = cacheStrategy;
      const response = await api.executeSqlQuery(payload);
      setExecutionId(response.execution_id);
      // Phase 47: capture query warnings from backend analysis
      setQueryWarnings(response.query_warnings || []);
      // BF-571/572: surface agent format-string auto-fixes — Starburst
      // %i → DuckDB %M, DATE_FORMAT → STRFTIME, etc.  Backend repairs
      // the SQL in-flight; this banner tells the user what changed.
      const _ff = (response as any).agent_format_fixes || [];
      setAgentFormatFixes(Array.isArray(_ff) ? _ff : []);
      addNotification({ type: 'info', title: 'SQL Query Started', message: `ID: ${response.execution_id?.substring(0, 8)}` });

      // ── Streaming preview alongside background download ──
      if (enableStreaming && primaryConnId && !showSecondary && isPrimaryS3) {
        setStreamingSource({ rawSql: primarySql, connectionId: primaryConnId });
        setShowResults(true);
      }
    } catch (e) {
      setExecuting(false);
      setProgress(null);
      addNotification({ type: 'error', title: 'Execution Failed', message: e.message });
    }
  };

  const loadSavedQuery = (q) => {
    setPrimaryConnId(q.primary_connection_id);
    setPrimarySql(q.primary_sql || '');
    if (q.secondary_connection_id) {
      setSecondaryConnId(q.secondary_connection_id);
      setSecondarySql(q.secondary_sql || '');
      setJoinConfig(q.join_config || { how: 'inner', left_on: '', right_on: '' });
      setShowSecondary(true);
    } else {
      setSecondaryConnId(null);
      setShowSecondary(false);
    }
    setEditingQuery(q);
    setShowSavedPanel(false);
    addNotification({ type: 'info', title: 'Query Loaded', message: `Editing "${q.name}"` });
  };

  // Phase 108: memoize connection lookups — avoids 4 .find() scans + .toLowerCase()
  // on every render; recomputes only when the connection list or selected IDs change.
  const { primaryConn, secondaryConn, browsedConnId, isBrowsedS3, isPrimaryS3 } = useMemo(() => {
    const pConn = sqlConnections.find(c => c.id === primaryConnId);
    const sConn = sqlConnections.find(c => c.id === secondaryConnId);
    const bId = schemaTarget === 'secondary' ? secondaryConnId : primaryConnId;
    const bConn = schemaTarget === 'secondary' ? sConn : pConn;
    return {
      primaryConn: pConn,
      secondaryConn: sConn,
      browsedConnId: bId,
      isBrowsedS3: (bConn?.connection_type || '').toLowerCase() === 's3',
      isPrimaryS3: (pConn?.connection_type || '').toLowerCase() === 's3',
    };
  }, [sqlConnections, primaryConnId, secondaryConnId, schemaTarget]);

  const statusColor = { starting: 'info', processing: 'warning', completed: 'success', failed: 'error' };

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', overflow: 'hidden' }}>

      {/* ─── Left: Schema Browser ──────────────────────────────────────────── */}
      <Box sx={{
        width: schemaOpen ? SCHEMA_PANEL_W : 0,
        minWidth: schemaOpen ? SCHEMA_PANEL_W : 0,
        transition: 'width 0.2s ease, min-width 0.2s ease',
        display: 'flex', flexDirection: 'column', borderRight: schemaOpen ? 1 : 0, borderColor: 'divider', bgcolor: 'background.paper', overflow: 'hidden',
      }}>

        {/* Header */}
        <Box sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="caption" sx={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Schema Browser
          </Typography>
          <IconButton size="small" onClick={() => setSchemaOpen(false)} sx={{ p: 0.25 }}>
            <ChevronRightIcon sx={{ fontSize: 16, transform: 'rotate(180deg)' }} />
          </IconButton>
        </Box>

        {/* Connection pickers */}
        <Box sx={{ p: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
            Browse schema for:
          </Typography>
          <ToggleButtonGroup size="small" value={schemaTarget} exclusive onChange={(_, v) => v && setSchemaTarget(v)} sx={{ mb: 1 }}>
            <ToggleButton value="primary" sx={{ fontSize: 11 }}>Primary</ToggleButton>
            {showSecondary && <ToggleButton value="secondary" sx={{ fontSize: 11 }}>Secondary</ToggleButton>}
          </ToggleButtonGroup>

          {/* Primary connection */}
          <TextField
            select fullWidth size="small" label="Primary Source"
            value={primaryConnId || ''}
            onChange={e => { setPrimaryConnId(e.target.value || null); setSchemaTarget('primary'); setResultsExecutionId(null); setStreamingSource(null); setShowResults(false); }}
            sx={{ mb: 1 }}
          >
            <MenuItem value=""><em>Select connection…</em></MenuItem>
            {sqlConnections.map(c => (
              <MenuItem key={c.id} value={c.id}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <ConnTypeBadge type={c.connection_type} />
                  <Typography variant="body2" noWrap>{c.name}</Typography>
                </Box>
              </MenuItem>
            ))}
          </TextField>

          {/* Secondary connection (cross-source) */}
          {showSecondary && (
            <TextField
              select fullWidth size="small" label="Secondary Source"
              value={secondaryConnId || ''}
              onChange={e => { setSecondaryConnId(e.target.value || null); setSchemaTarget('secondary'); }}
            >
              <MenuItem value=""><em>Select connection…</em></MenuItem>
              {sqlConnections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ConnTypeBadge type={c.connection_type} />
                    <Typography variant="body2" noWrap>{c.name}</Typography>
                  </Box>
                </MenuItem>
              ))}
            </TextField>
          )}
        </Box>

        {/* Catalog/schema tree */}
        <Box sx={{ flex: 1, overflowY: 'auto' }}>
          <CatalogTree
            connectionId={browsedConnId}
            onInsert={handleInsertText}
            isS3={isBrowsedS3}
          />
        </Box>

        {connectionsLoading && (
          <Box sx={{ p: 1 }}><LinearProgress /></Box>
        )}
        {!connectionsLoading && sqlConnections.length === 0 && (
          <Box sx={{ p: 2 }}>
            <Alert severity="info" sx={{ fontSize: 12 }}>
              No SQL connections found. Add a Trino, Snowflake, or Databricks connection first.
            </Alert>
          </Box>
        )}
      </Box>

      {/* ─── Right: Editor + Results ────────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'row', overflow: 'hidden' }}>

      {/* ─── Center: Editor + Results ──────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Toolbar */}
        <Box sx={{ px: 1.5, py: 0.75, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0, bgcolor: 'background.paper', flexWrap: 'wrap' }}>

          {/* Schema panel toggle */}
          {!schemaOpen && (
            <Tooltip title="Show schema browser">
              <IconButton size="small" onClick={() => setSchemaOpen(true)} sx={{ border: 1, borderColor: 'divider' }}>
                <MenuIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}

          {/* Saved queries toggle */}
          <Tooltip title="Saved SQL Queries">
            <IconButton size="small" color={showSavedPanel ? 'primary' : 'default'} onClick={() => setShowSavedPanel(p => !p)}>
              <BookmarkIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          {/* Cross-source toggle — disabled for S3 (not yet supported on SQL page) */}
          <Tooltip title={
            isPrimaryS3
              ? 'Cross-source with S3 is not yet supported here — use Query Builder Federation view.'
              : (showSecondary ? 'Remove secondary source' : 'Add secondary source for cross-source join')
          }>
            <span>
              <Button
                size="small"
                startIcon={<JoinIcon />}
                variant={showSecondary ? 'contained' : 'outlined'}
                color={showSecondary ? 'warning' : 'inherit'}
                onClick={() => setShowSecondary(p => !p)}
                disabled={isPrimaryS3}
                sx={{ fontSize: 12 }}
              >
                Cross-Source
              </Button>
            </span>
          </Tooltip>

          {showSecondary && secondaryConnId && (
            <Tooltip title="Configure join keys">
              <Button
                size="small"
                startIcon={<CodeIcon />}
                variant="outlined"
                color={joinConfig.left_on && joinConfig.right_on ? 'success' : 'warning'}
                onClick={() => setShowJoinConfig(true)}
                sx={{ fontSize: 12 }}
              >
                Join: {joinConfig.how.toUpperCase()}
                {joinConfig.left_on && joinConfig.right_on && (
                  <> · {joinConfig.left_on} = {joinConfig.right_on}</>
                )}
              </Button>
            </Tooltip>
          )}

          <Box sx={{ flexGrow: 1 }} />

          {/* Row limit */}
          <TextField
            select size="small" label="Row Limit" value={rowLimit}
            onChange={e => setRowLimit(Number(e.target.value))}
            sx={{ minWidth: 120 }}
          >
            {[1000, 5000, 10000, 50000, 100000].map(n => (
              <MenuItem key={n} value={n}>{n.toLocaleString()}</MenuItem>
            ))}
          </TextField>

          {/* Save */}
          <Tooltip title="Save query">
            <IconButton size="small" onClick={() => setShowSaveDialog(true)} disabled={!primaryConnId}>
              <SaveIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          {/* NL-to-SQL toggle */}
          <Tooltip title="Describe your query in plain English and get SQL instantly">
            <Button
              size="small"
              variant={showNLPanel ? 'contained' : 'outlined'}
              color="secondary"
              startIcon={<NLIcon sx={{ fontSize: 15 }} />}
              onClick={() => setShowNLPanel(v => !v)}
              sx={{ whiteSpace: 'nowrap', fontSize: '0.75rem', py: 0.4 }}
            >
              NL→SQL
            </Button>
          </Tooltip>

          {/* Execute */}
          <Button
            variant="contained"
            startIcon={executing ? <CircularProgress size={16} color="inherit" /> : <RunIcon />}
            onClick={handleExecute}
            disabled={executing || !primaryConnId}
            size="small"
            sx={{ minWidth: 100 }}
          >
            {executing ? 'Running…' : 'Run SQL'}
          </Button>

          {/* Streaming toggles — only for S3 connections */}
          {(() => {
            const conn = sqlConnections.find((c: any) => c.id === primaryConnId);
            return conn?.connection_type === 's3' ? (
              <>
                <Tooltip title={enableStreaming
                  ? 'Streaming ON — preview data from S3 while query runs.'
                  : 'Streaming OFF — wait for full query to complete.'
                }>
                  <Chip
                    icon={<StreamIcon sx={{ fontSize: 16 }} />}
                    label="Stream"
                    size="small"
                    variant={enableStreaming ? 'filled' : 'outlined'}
                    color={enableStreaming ? 'info' : 'default'}
                    onClick={() => setEnableStreaming(!enableStreaming)}
                    sx={{ cursor: 'pointer', fontWeight: enableStreaming ? 700 : 400 }}
                  />
                </Tooltip>
                {enableStreaming && (
                  <Tooltip title={streamBgDownload
                    ? 'Download ON — also downloads full results to local file in background (for export/history).'
                    : 'Download OFF — stream only, no local file created. Faster, saves disk space.'
                  }>
                    <Chip
                      icon={<CloudDownloadIcon sx={{ fontSize: 16 }} />}
                      label="Download"
                      size="small"
                      variant={streamBgDownload ? 'filled' : 'outlined'}
                      color={streamBgDownload ? 'warning' : 'default'}
                      onClick={() => setStreamBgDownload(!streamBgDownload)}
                      sx={{ cursor: 'pointer', fontWeight: streamBgDownload ? 700 : 400 }}
                    />
                  </Tooltip>
                )}
              </>
            ) : null;
          })()}
        </Box>

        {/* Saved queries panel */}
        {showSavedPanel && (
          <Box sx={{ height: 340, borderBottom: 1, borderColor: 'divider', overflow: 'hidden', flexShrink: 0 }}>
            <SavedQueriesPanel
              onLoad={loadSavedQuery}
              onClose={() => setShowSavedPanel(false)}
            />
          </Box>
        )}

        {/* Connection badges */}
        {(primaryConn || secondaryConn) && (
          <Box sx={{ px: 1.5, py: 0.5, display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'grey.50', borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
            {primaryConn && (
              <Chip
                icon={<ConnTypeBadge type={primaryConn.connection_type} />}
                label={`Primary: ${primaryConn.name}`}
                size="small"
                variant="outlined"
                sx={{ fontSize: 12 }}
              />
            )}
            {secondaryConn && (
              <>
                <Typography variant="caption" color="text.disabled">→ {joinConfig.how?.toUpperCase()} JOIN →</Typography>
                <Chip
                  icon={<ConnTypeBadge type={secondaryConn.connection_type} />}
                  label={`Secondary: ${secondaryConn.name}`}
                  size="small"
                  color="warning"
                  variant="outlined"
                  sx={{ fontSize: 12 }}
                />
              </>
            )}
            {editingQuery && (
              <Chip label={`Editing: ${editingQuery.name}`} size="small" color="info" onDelete={() => setEditingQuery(null)} />
            )}
          </Box>
        )}

        {/* Progress bar */}
        {executing && (
          <Box sx={{ flexShrink: 0 }}>
            <LinearProgress color={statusColor[progress?.status] || 'primary'} />
            <Box sx={{ px: 2, py: 0.5, bgcolor: 'grey.50', display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>
                {progress?.message || progress?.status || 'Executing…'} · {fmtSecs(elapsed)} elapsed
              </Typography>
              {etaSeconds != null && elapsed < etaSeconds && (
                <Typography variant="caption" color="primary.main" sx={{ fontWeight: 500 }}>
                  ~{fmtSecs(Math.max(1, Math.round(etaSeconds - elapsed)))} remaining
                </Typography>
              )}
            </Box>
          </Box>
        )}
        {!executing && progress?.status === 'completed' && !progress?.stale_warning && (
          <Box sx={{ px: 2, py: 0.5, bgcolor: 'success.50', borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
            <Typography variant="caption" color="success.main" sx={{ fontWeight: 600 }}>
              Completed in {fmtSecs(progress.elapsed ?? 0)} · {(progress.total_rows || 0).toLocaleString()} rows
            </Typography>
          </Box>
        )}
        {!executing && progress?.stale_warning && (
          <Alert severity="warning" sx={{ mx: 1, mt: 0.5, py: 0.4, flexShrink: 0, fontSize: '0.8rem' }}
            onClose={() => setProgress((p: any) => p ? { ...p, stale_warning: null } : p)}>
            <strong>Showing cached result</strong> — {progress.stale_warning}
          </Alert>
        )}

        {/* Error */}
        {progress?.status === 'failed' && (
          <Alert severity="error" sx={{ m: 1, flexShrink: 0 }} onClose={() => setProgress(null)}>
            {progress.error}
          </Alert>
        )}

        {/* SQL Editors */}
        <Box sx={{ display: 'flex', flex: showResults ? '0 0 280px' : 1, minHeight: 180, borderBottom: showResults ? 1 : 0, borderColor: 'divider', overflow: 'hidden', flexShrink: showResults ? 0 : 1 }}>
          {showSecondary ? (
            <Box sx={{ display: 'flex', width: '100%' }}>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: 1, borderColor: 'divider' }}>
                <SqlEditor
                  value={primarySql}
                  onChange={setPrimarySql}
                  schema={primarySchema}
                  label={`Primary: ${primaryConn?.name || 'select a connection'}`}
                />
              </Box>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                <SqlEditor
                  value={secondarySql}
                  onChange={setSecondarySql}
                  schema={secondarySchema}
                  label={`Secondary: ${secondaryConn?.name || 'select a connection'}`}
                />
              </Box>
            </Box>
          ) : (
            <SqlEditor
              value={primarySql}
              onChange={setPrimarySql}
              schema={primarySchema}
              label={primaryConn ? `${primaryConn.name} (${primaryConn.connection_type})` : 'Select a connection'}
            />
          )}
        </Box>

        {/* Phase 108: S3 helper text — reminds users that partition filters prune scans */}
        {isPrimaryS3 && !showResults && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <Alert severity="info" sx={{ fontSize: 12, py: 0.4 }}>
              <strong>S3 / Parquet</strong> — use registered table names directly (no catalog/schema prefix).
              Add a partition column to WHERE (e.g. <code>dt = '2025-01-15'</code>) to avoid full-table scans.
            </Alert>
          </Box>
        )}

        {/* Phase 47: Query warning banner */}
        {queryWarnings.length > 0 && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <QueryWarningBanner warnings={queryWarnings} onDismiss={() => setQueryWarnings([])} />
          </Box>
        )}

        {/* BF-571/572 (2026-05-29): agent format-string auto-fixes.
            Shown when the backend rewrote Starburst/Trino/MySQL specifiers
            so DuckDB can run the SQL.  Dismissable. */}
        {agentFormatFixes.length > 0 && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <Alert
              severity="info"
              onClose={() => setAgentFormatFixes([])}
              sx={{ fontSize: '0.8rem', py: 0.4 }}
            >
              <strong>Agent auto-corrected {agentFormatFixes.length} format issue
                {agentFormatFixes.length === 1 ? '' : 's'} in your SQL:</strong>
              {' '}{agentFormatFixes.map((f: any, i: number) => (
                <span key={i}>
                  {i > 0 ? ' · ' : ''}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.original_format}
                  </code>
                  {' → '}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.repaired_format}
                  </code>
                  {f.function_rewritten && <em> ({f.function} → STRFTIME)</em>}
                </span>
              ))}
            </Alert>
          </Box>
        )}

        {/* Results — single DataGridViewer handles both streaming and local */}
        {showResults && (streamingSource || resultsExecutionId) && (
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            {streamingSource && executing && (
              <Paper elevation={0} sx={(theme) => ({ p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, bgcolor: alpha(theme.palette.primary.main, 0.08), border: `1px solid ${alpha(theme.palette.primary.main, 0.3)}`, borderRadius: 1, mx: 1, mt: 1, flexShrink: 0 })}>
                <CircularProgress size={18} thickness={5} sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.dark' }}>
                    Streaming from S3 — query is being processed
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'primary.main' }}>
                    You can paginate, sort, and filter while results are loading.
                  </Typography>
                </Box>
              </Paper>
            )}
            <Box sx={{ flex: 1, overflow: 'hidden' }}>
              <DataGridViewer
                key={resultKey}
                executionId={resultsExecutionId}
                streamingSource={streamingSource}
                onClose={() => { setShowResults(false); setResultsExecutionId(null); setStreamingSource(null); }}
              />
            </Box>
          </Box>
        )}
      </Box>{/* end center column */}

      {/* ─── Right: NL-to-SQL Panel (Phase 48) ─────────────────────────────── */}
      {showNLPanel && (
        <Box sx={{
          width: 340, flexShrink: 0,
          borderLeft: 1, borderColor: 'divider',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
          bgcolor: 'background.paper',
        }}>
          <NLToSQLPanel
            connectionId={primaryConnId ?? undefined}
            connectionType={sqlConnections.find((c: any) => c.id === primaryConnId)?.connection_type}
            tables={nlTables}
            onUseSql={(sql) => {
              setPrimarySql(sql);
              setShowNLPanel(false);
            }}
          />
        </Box>
      )}

      </Box>{/* end outer flex row */}

      {/* ─── Dialogs ─────────────────────────────────────────────────────────── */}
      <SaveSqlQueryDialog
        open={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        onSaved={(q) => setEditingQuery(q)}
        primaryConnectionId={primaryConnId}
        primarySql={primarySql}
        secondaryConnectionId={showSecondary ? secondaryConnId : null}
        secondarySql={secondarySql}
        joinConfig={joinConfig}
        editingQuery={editingQuery}
      />

      <JoinConfigDialog
        open={showJoinConfig}
        onClose={() => setShowJoinConfig(false)}
        config={joinConfig}
        onChange={setJoinConfig}
      />
    </Box>
  );
};

export default SqlQueryPage;
