/**
 * Phase 100 — GuidedTour spotlight component.
 *
 * Renders a spotlight overlay around the target element with a tooltip showing
 * the step title, description, and navigation controls. Uses pure MUI — no
 * additional npm dependencies.
 */
import React, { useEffect, useState, useRef } from 'react';
import { Box, Paper, Typography, Button, IconButton, Backdrop, LinearProgress } from '@mui/material';
import { Close as CloseIcon, ArrowBack, ArrowForward, CheckCircle } from '@mui/icons-material';
import { useTour } from '../context/TourContext';

const SPOTLIGHT_PADDING = 8;
const TOOLTIP_OFFSET = 16;
const TRANSITION_MS = 300;

interface TargetRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

const GuidedTour: React.FC = () => {
  const { activeTour, currentStep, currentStepData, totalSteps, nextStep, prevStep, dismissTour } = useTour();
  const [targetRect, setTargetRect] = useState<TargetRect | null>(null);
  const [visible, setVisible] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);

  // Find and measure the target element
  useEffect(() => {
    if (!currentStepData?.target) {
      setTargetRect(null);
      setVisible(false);
      return;
    }

    const findTarget = () => {
      const el = document.querySelector(currentStepData.target);
      if (el) {
        const rect = el.getBoundingClientRect();
        setTargetRect({
          top: rect.top + window.scrollY,
          left: rect.left + window.scrollX,
          width: rect.width,
          height: rect.height,
        });
        // Scroll into view if off-screen
        if (rect.top < 0 || rect.bottom > window.innerHeight) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        setVisible(true);
      } else {
        // Target not found — skip to next step or show fallback
        setTargetRect(null);
        setVisible(true);
      }
    };

    // Small delay to allow DOM to settle
    const timer = setTimeout(findTarget, 100);
    window.addEventListener('resize', findTarget);
    window.addEventListener('scroll', findTarget, true);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', findTarget);
      window.removeEventListener('scroll', findTarget, true);
    };
  }, [currentStepData]);

  if (!activeTour || !currentStepData) return null;

  const progress = ((currentStep + 1) / totalSteps) * 100;
  const isLastStep = currentStep === totalSteps - 1;

  // Calculate tooltip position
  const getTooltipStyle = (): React.CSSProperties => {
    if (!targetRect) {
      // Centered fallback when target not found
      return {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        zIndex: 1501,
      };
    }

    const pos = currentStepData.position || 'bottom';
    const base: React.CSSProperties = {
      position: 'absolute',
      zIndex: 1501,
      maxWidth: 380,
    };

    switch (pos) {
      case 'top':
        return { ...base, top: targetRect.top - TOOLTIP_OFFSET, left: targetRect.left, transform: 'translateY(-100%)' };
      case 'bottom':
        return { ...base, top: targetRect.top + targetRect.height + TOOLTIP_OFFSET, left: targetRect.left };
      case 'left':
        return { ...base, top: targetRect.top, left: targetRect.left - TOOLTIP_OFFSET, transform: 'translateX(-100%)' };
      case 'right':
        return { ...base, top: targetRect.top, left: targetRect.left + targetRect.width + TOOLTIP_OFFSET };
      default:
        return { ...base, top: targetRect.top + targetRect.height + TOOLTIP_OFFSET, left: targetRect.left };
    }
  };

  // Build clip-path polygon to create a spotlight hole in the backdrop
  const getClipPath = (): string => {
    if (!targetRect) return 'none';
    const t = targetRect.top - SPOTLIGHT_PADDING;
    const l = targetRect.left - SPOTLIGHT_PADDING;
    const w = targetRect.width + SPOTLIGHT_PADDING * 2;
    const h = targetRect.height + SPOTLIGHT_PADDING * 2;
    const r = l + w;
    const b = t + h;
    // Outer box (full screen) → inner cutout (spotlight hole)
    return `polygon(
      0% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%,
      ${l}px ${t}px, ${l}px ${b}px, ${r}px ${b}px, ${r}px ${t}px, ${l}px ${t}px
    )`;
  };

  return (
    <>
      {/* Backdrop with spotlight hole */}
      <Backdrop
        open={visible}
        sx={{
          zIndex: 1500,
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          clipPath: targetRect ? getClipPath() : 'none',
          transition: `opacity ${TRANSITION_MS}ms ease`,
        }}
        onClick={dismissTour}
      />

      {/* Tooltip */}
      {visible && (
        <Paper
          ref={tooltipRef}
          elevation={8}
          sx={{
            ...getTooltipStyle(),
            p: 2.5,
            borderRadius: 2,
            transition: `all ${TRANSITION_MS}ms ease`,
            opacity: visible ? 1 : 0,
          }}
        >
          {/* Header */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
            <Typography variant="subtitle1" fontWeight="bold">{currentStepData.title}</Typography>
            <IconButton size="small" onClick={dismissTour} sx={{ mt: -0.5, mr: -0.5 }}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>

          {/* Description */}
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {currentStepData.description}
          </Typography>

          {/* Progress bar */}
          <LinearProgress variant="determinate" value={progress} sx={{ mb: 1.5, borderRadius: 1 }} />
          <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: 'block' }}>
            Step {currentStep + 1} of {totalSteps} — {activeTour.name}
          </Typography>

          {/* Navigation */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Button
              size="small"
              startIcon={<ArrowBack />}
              onClick={prevStep}
              disabled={currentStep === 0}
            >
              Back
            </Button>
            <Button
              size="small"
              variant="contained"
              endIcon={isLastStep ? <CheckCircle /> : <ArrowForward />}
              onClick={nextStep}
            >
              {isLastStep ? 'Finish' : 'Next'}
            </Button>
          </Box>

          {!targetRect && (
            <Typography variant="caption" color="warning.main" sx={{ mt: 1, display: 'block' }}>
              Target element not found on this page. Click Next to continue.
            </Typography>
          )}
        </Paper>
      )}
    </>
  );
};

export default GuidedTour;
