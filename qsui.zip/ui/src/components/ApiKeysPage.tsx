import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Autocomplete, InputAdornment, Select, MenuItem, FormControl, InputLabel,
} from '@mui/material';
import {
  VpnKey as KeyIcon, Delete as DeleteIcon, Add as AddIcon,
  ContentCopy as CopyIcon, Refresh as RefreshIcon, AllInclusive as NeverIcon,
  Visibility as RevealIcon,
} from '@mui/icons-material';

const EXPIRY_OPTIONS = [
  { label: 'Never expires', value: '' },
  { label: '30 days',       value: String(30 * 24) },
  { label: '90 days',       value: String(90 * 24) },
  { label: '1 year',        value: String(365 * 24) },
  { label: '2 years',       value: String(2 * 365 * 24) },
  { label: 'Custom (hours)', value: '__custom__' },
];
import api from '../services/api';

interface ApiKeyItem {
  id: number;
  key_prefix: string;
  name: string;
  created_by: string | null;
  scoped_view_ids: number[];
  rate_limit: string | null;
  is_active: boolean;
  expires_at: string | null;
  created_at: string | null;
  last_used_at: string | null;
  usage_count: number;
}

interface PublishedView {
  id: number;
  slug: string;
  name: string;
}

const ApiKeysPage = () => {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [views, setViews] = useState<PublishedView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Create dialog
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newScoped, setNewScoped] = useState<PublishedView[]>([]);
  const [newRateLimit, setNewRateLimit] = useState('');
  const [newExpiryOption, setNewExpiryOption] = useState('');       // '' = never
  const [newExpiresHours, setNewExpiresHours] = useState('');       // custom hours
  const [creating, setCreating] = useState(false);

  // Key reveal dialog
  const [revealedKey, setRevealedKey] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [k, v] = await Promise.all([
        api.listApiKeys(),
        api.listPublishedViews(),
      ]);
      setKeys(Array.isArray(k) ? k : []);
      setViews(Array.isArray(v) ? v : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      // Resolve expiry hours: '' = never, preset = preset value, custom = user input
      const resolvedHours =
        newExpiryOption === '' ? undefined :
        newExpiryOption === '__custom__' ? (newExpiresHours ? Number(newExpiresHours) : undefined) :
        Number(newExpiryOption);
      const result = await api.createApiKey({
        name: newName.trim(),
        scoped_view_ids: newScoped.map(v => v.id),
        rate_limit: newRateLimit.trim() || undefined,
        expires_hours: resolvedHours,
      });
      setShowCreate(false);
      setNewName('');
      setNewScoped([]);
      setNewRateLimit('');
      setNewExpiryOption('');
      setNewExpiresHours('');
      // Show the raw key
      if (result.raw_key) {
        setRevealedKey(result.raw_key);
      }
      loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleRevoke = async (id: number) => {
    if (!window.confirm('Revoke this API key? This cannot be undone.')) return;
    try {
      await api.revokeApiKey(id);
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleReveal = async (id: number) => {
    try {
      const res = await api.revealApiKey(id);
      if (res?.raw_key) setRevealedKey(res.raw_key);
      else setError('Raw key not available for this key');
    } catch (err: any) {
      setError(err.message || 'Failed to reveal key');
    }
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
  };

  const viewNameMap = new Map(views.map(v => [v.id, v.name]));

  return (
    <Box sx={{ p: 3, maxWidth: 1200, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <KeyIcon />
          <Typography variant="h5" fontWeight={600}>API Keys</Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RefreshIcon />} onClick={loadData} size="small">Refresh</Button>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setShowCreate(true)} size="small">
            Create Key
          </Button>
        </Stack>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : keys.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            No API keys yet. Create one to allow external systems to access published views.
          </Typography>
        </Paper>
      ) : (
        <Paper variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Name</strong></TableCell>
                <TableCell><strong>Prefix</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
                <TableCell><strong>Scoped Views</strong></TableCell>
                <TableCell><strong>Rate Limit</strong></TableCell>
                <TableCell><strong>Usage</strong></TableCell>
                <TableCell><strong>Last Used</strong></TableCell>
                <TableCell><strong>Expires</strong></TableCell>
                <TableCell align="right"><strong>Actions</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {keys.map(k => (
                <TableRow key={k.id} sx={{ opacity: k.is_active ? 1 : 0.5 }}>
                  <TableCell>
                    <Typography variant="body2" fontWeight={500}>{k.name}</Typography>
                    <Typography variant="caption" color="text.secondary">{k.created_by || '-'}</Typography>
                  </TableCell>
                  <TableCell><code style={{ fontSize: 11 }}>{k.key_prefix}...</code></TableCell>
                  <TableCell>
                    <Chip
                      label={k.is_active ? 'Active' : 'Revoked'}
                      size="small"
                      color={k.is_active ? 'success' : 'default'}
                    />
                  </TableCell>
                  <TableCell>
                    {k.scoped_view_ids.length > 0
                      ? k.scoped_view_ids.map(id => (
                          <Chip key={id} label={viewNameMap.get(id) || `#${id}`} size="small" sx={{ mr: 0.5, mb: 0.5 }} />
                        ))
                      : <Typography variant="caption" color="text.secondary">All views</Typography>
                    }
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">{k.rate_limit || 'Default'}</Typography>
                  </TableCell>
                  <TableCell>{k.usage_count}</TableCell>
                  <TableCell>
                    <Typography variant="caption">
                      {k.last_used_at ? new Date(k.last_used_at).toLocaleString() : 'Never'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {k.expires_at
                      ? <Typography variant="caption">{new Date(k.expires_at).toLocaleDateString()}</Typography>
                      : <Chip icon={<NeverIcon />} label="Never expires" size="small" color="success" variant="outlined" />
                    }
                  </TableCell>
                  <TableCell align="right">
                    {k.is_active && (
                      <>
                        <Tooltip title="Reveal raw key (admin)">
                          <IconButton size="small" onClick={() => handleReveal(k.id)}>
                            <RevealIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Revoke key">
                          <IconButton size="small" color="error" onClick={() => handleRevoke(k.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}

      {/* Create Key Dialog */}
      <Dialog open={showCreate} onClose={() => setShowCreate(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create API Key</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Key Name"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              fullWidth size="small"
              placeholder="e.g., Risk Team ETL Pipeline"
            />
            <Autocomplete
              multiple size="small"
              options={views}
              getOptionLabel={v => `${v.name} (${v.slug})`}
              value={newScoped}
              onChange={(_, v) => setNewScoped(v)}
              renderInput={params => (
                <TextField {...params} label="Scoped Views" placeholder="Leave empty for all views" />
              )}
            />
            <TextField
              label="Rate Limit (optional)"
              value={newRateLimit}
              onChange={e => setNewRateLimit(e.target.value)}
              fullWidth size="small"
              placeholder="e.g., 120/minute"
              helperText="Leave empty for default rate limit"
            />
            <FormControl fullWidth size="small">
              <InputLabel>Expiration</InputLabel>
              <Select
                value={newExpiryOption}
                label="Expiration"
                onChange={e => { setNewExpiryOption(e.target.value); setNewExpiresHours(''); }}
              >
                {EXPIRY_OPTIONS.map(o => (
                  <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            {newExpiryOption === '__custom__' && (
              <TextField
                label="Custom expiry (hours)"
                value={newExpiresHours}
                onChange={e => setNewExpiresHours(e.target.value)}
                fullWidth size="small" type="number"
                helperText="e.g. 720 = 30 days"
              />
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCreate(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={creating || !newName.trim()}>
            {creating ? 'Creating...' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Key Reveal Dialog */}
      <Dialog open={!!revealedKey} onClose={() => setRevealedKey('')} maxWidth="sm" fullWidth>
        <DialogTitle>API Key</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            Treat this key as a password. It can be re-revealed later by an admin from this page.
          </Alert>
          <TextField
            fullWidth size="small"
            value={revealedKey}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => copyKey(revealedKey)} size="small">
                    <CopyIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              ),
              sx: { fontFamily: 'monospace', fontSize: 13 },
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button variant="contained" onClick={() => setRevealedKey('')}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ApiKeysPage;
