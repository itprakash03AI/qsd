/**
 * Phase 131 deep-dive #13 (round 16) — BQB-parity perf chip for feed runs.
 *
 * Clone of ExecutionPerformanceChip pointed at /api/feed-executions/{id}
 * (the feed-execution row, which carries the same ``files_metadata``
 * envelope: ``stage_history`` + ``log_lines``).
 *
 * Deliberately separate from the BQB chip so changes to one don't
 * affect the other.  Rendering is identical — copy-paste with the
 * URL swapped.
 */
import { useState, useEffect } from 'react';
import {
  Box, Chip, Popover, Table, TableBody, TableCell, TableHead,
  TableRow, Typography, CircularProgress,
} from '@mui/material';
import SpeedIcon from '@mui/icons-material/Speed';
import { rawFetch } from '../services/api/core';

interface StageEntry {
  stage: string;
  stage_label: string;
  duration_seconds: number;
  files_done?: number;
  bytes_done?: number;
  in_flight?: boolean;
}

interface StageHistory {
  stages: StageEntry[];
  extras?: Record<string, unknown>;
  total_seconds?: number;
}

interface LogLine {
  ts: number;
  level: string;
  logger: string;
  msg: string;
  stage?: string | null;
}

interface Props {
  /** feed_execution.id (DB id) — used to fetch /api/feed-executions/{id} */
  executionDbId: number;
}

export default function FeedExecutionPerformanceChip({ executionDbId }: Props) {
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [data, setData] = useState<StageHistory | null>(null);
  const [logLines, setLogLines] = useState<LogLine[]>([]);
  const [showLogs, setShowLogs] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!executionDbId) return;
    let cancelled = false;
    setLoading(true);
    rawFetch(`/api/feed-executions/${executionDbId}`)
      .then(r => r.json())
      .then(j => {
        if (cancelled) return;
        const fm = j?.files_metadata;
        const parsed: any = typeof fm === 'string' ? JSON.parse(fm) : fm;
        setData(parsed?.stage_history ?? null);
        setLogLines(Array.isArray(parsed?.log_lines) ? parsed.log_lines : []);
      })
      .catch(e => { if (!cancelled) setError(String(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [executionDbId]);

  if (loading) return <CircularProgress size={14} sx={{ mx: 1 }} />;

  const total = data?.total_seconds ?? 0;
  const stages = data?.stages ?? [];
  const slowest = stages.length > 0
    ? [...stages].sort((a, b) => (b.duration_seconds || 0) - (a.duration_seconds || 0))[0]
    : null;

  const stagePart = stages.length > 0
    ? `${total.toFixed(1)}s · ${stages.length} steps${
        slowest ? ` · ${slowest.stage_label}=${slowest.duration_seconds.toFixed(1)}s` : ''
      }`
    : '';
  const logPart = logLines.length > 0 ? ` · ${logLines.length} logs` : '';
  const chipLabel = (stagePart + logPart) || (error ? 'logs (error)' : 'logs');

  const fmtTime = (ts: number) => {
    try { return new Date(ts * 1000).toLocaleTimeString(); } catch { return String(ts); }
  };
  const levelColor = (level: string) => {
    if (level === 'ERROR' || level === 'CRITICAL') return 'error.main';
    if (level === 'WARNING') return 'warning.main';
    return 'text.secondary';
  };

  return (
    <>
      <Chip
        size="small"
        icon={<SpeedIcon sx={{ fontSize: 14 }} />}
        label={chipLabel}
        variant="outlined"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        sx={{ fontSize: 11, cursor: 'pointer' }}
      />
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Box sx={{ p: 2, minWidth: 380, maxWidth: 720 }}>
          {stages.length === 0 && logLines.length === 0 && (
            <Box sx={{ py: 1 }}>
              <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
                Feed Execution Performance
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                {error
                  ? `Could not load: ${error}`
                  : 'No stage breakdown or logs persisted for this feed run yet. They appear once the run finishes.'}
              </Typography>
              <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 1, fontSize: 10 }}>
                execution_db_id: {executionDbId}
              </Typography>
            </Box>
          )}
          {stages.length > 0 && (
            <>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Feed Execution · {total.toFixed(2)}s total
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Stage</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Duration</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">% of total</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {stages.map((s, i) => {
                    const pct = total > 0 ? (s.duration_seconds / total) * 100 : 0;
                    return (
                      <TableRow key={i}>
                        <TableCell sx={{ fontSize: 11 }}>
                          {s.stage_label || s.stage}
                          {s.in_flight && <em style={{ marginLeft: 4 }}>(running)</em>}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          {s.duration_seconds.toFixed(2)}s
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 1 }}>
                            <Box sx={{
                              width: 60, height: 6, bgcolor: 'grey.200', borderRadius: 1,
                              overflow: 'hidden',
                            }}>
                              <Box sx={{
                                width: `${Math.min(100, pct)}%`, height: '100%',
                                bgcolor: pct > 50 ? 'warning.main' : 'primary.main',
                              }} />
                            </Box>
                            <span>{pct.toFixed(0)}%</span>
                          </Box>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </>
          )}
          {data?.extras && Object.keys(data.extras).length > 0 && (
            <Box sx={{ mt: 1.5, pt: 1.5, borderTop: 1, borderColor: 'divider' }}>
              <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                Details
              </Typography>
              {Object.entries(data.extras).map(([k, v]) => (
                <Typography key={k} variant="caption" sx={{ fontSize: 10, display: 'block', color: 'text.secondary' }}>
                  {k}: {String(v)}
                </Typography>
              ))}
            </Box>
          )}
          {logLines.length > 0 && (
            <Box sx={{ mt: 1.5, pt: 1.5, borderTop: 1, borderColor: 'divider' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 600 }}>
                  Feed logs ({logLines.length})
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontSize: 10, color: 'primary.main', cursor: 'pointer', userSelect: 'none' }}
                  onClick={() => setShowLogs(s => !s)}
                >
                  {showLogs ? 'hide' : 'show'}
                </Typography>
              </Box>
              {showLogs && (
                <Box
                  sx={{
                    maxHeight: 280, overflowY: 'auto',
                    fontFamily: 'JetBrains Mono, Menlo, monospace',
                    fontSize: 10, lineHeight: 1.5,
                    bgcolor: 'grey.50', p: 1, borderRadius: 1,
                    border: 1, borderColor: 'divider',
                  }}
                >
                  {logLines.map((l, i) => (
                    <Box key={i} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                      <Box sx={{ color: 'text.disabled', whiteSpace: 'nowrap', flex: '0 0 auto' }}>
                        {fmtTime(l.ts)}
                      </Box>
                      <Box sx={{ color: levelColor(l.level), fontWeight: 600, width: 60, flex: '0 0 60px' }}>
                        {l.level}
                      </Box>
                      {l.stage && (
                        <Box sx={{ color: 'text.secondary', flex: '0 0 110px' }}>
                          [{l.stage}]
                        </Box>
                      )}
                      <Box sx={{ flex: 1, wordBreak: 'break-word' }}>
                        {l.msg}
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </Box>
          )}
        </Box>
      </Popover>
    </>
  );
}
