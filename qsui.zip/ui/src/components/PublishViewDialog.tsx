import { useState, useMemo, useEffect, useCallback } from 'react';
import { API_BASE_URL, PUBLISHED_API_BASE_URL } from '../services/api/core';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField,
  Stack, Alert, Autocomplete, Typography, Box, InputAdornment,
  Select, MenuItem, FormControl, InputLabel, Checkbox, FormControlLabel,
  IconButton, Divider, Table, TableHead, TableRow, TableCell, TableBody,
  CircularProgress, Collapse, Chip, Tooltip,
  RadioGroup, Radio, FormLabel,
} from '@mui/material';
import {
  ContentCopy as CopyIcon, Add as AddIcon, Delete as DeleteIcon,
  ExpandMore as ExpandMoreIcon, ExpandLess as ExpandLessIcon,
  AutoFixHigh as AutoDetectIcon,
} from '@mui/icons-material';
import api from '../services/api';
import {
  applyWhereModeToggle, syncAllowedFiltersAfterToggle,
  buildWhereClausesFromQueryConfig,
  buildWhereClausesFromRawSql,
} from './publish-view/whereClauseHelpers';
import {
  distinctValues as fetchDistinctValues,
  previewColumns as fetchPreviewColumns,
} from './common/sqlPreviewApi';

// ── Constants ────────────────────────────────────────────────────────────────

const PARAM_TYPES = ['string', 'integer', 'float', 'boolean', 'date'] as const;
type ParamType = typeof PARAM_TYPES[number];

// ── Interfaces ───────────────────────────────────────────────────────────────

interface ParamDefinition {
  name: string;
  type: ParamType;
  required: boolean;
  default: string | null;
  description: string;
  inferredReason?: string;  // present only when backend auto-inferred the type
}

// Phase 132.36 — one WHERE clause from the saved query, surfaced in the
// publish dialog with a Dynamic / Static toggle.  Dynamic means the
// consumer can override the value via a URL param (?column=value);
// Static means the value is locked in at publish time.
interface WhereClause {
  column: string;
  operator: string;
  value: any;
  mode: 'dynamic' | 'static';
  isPartition: boolean;
}

// Phase 132.37 — operator vocabulary mirrors the backend engine
// (parquet_engine_v2._build_where) and the bare-form filter parser
// (api/published_views/helpers._parse_filters).  Labels are what the
// publisher sees; values are what the backend understands.
const OPERATORS: { value: string; label: string; takesList: boolean; takesValue: boolean }[] = [
  { value: 'eq',           label: '= equals',           takesList: false, takesValue: true  },
  { value: 'ne',           label: '!= not equals',      takesList: false, takesValue: true  },
  { value: 'in',           label: 'IN (any of)',        takesList: true,  takesValue: true  },
  { value: 'not_in',       label: 'NOT IN',             takesList: true,  takesValue: true  },
  { value: 'gt',           label: '>  greater than',    takesList: false, takesValue: true  },
  { value: 'gte',          label: '>= at least',        takesList: false, takesValue: true  },
  { value: 'lt',           label: '<  less than',       takesList: false, takesValue: true  },
  { value: 'lte',          label: '<= at most',         takesList: false, takesValue: true  },
  { value: 'contains',     label: 'contains (ILIKE)',   takesList: false, takesValue: true  },
  { value: 'not_contains', label: "doesn't contain",    takesList: false, takesValue: true  },
  { value: 'between',      label: 'BETWEEN (2 values)', takesList: true,  takesValue: true  },
  { value: 'is_null',      label: 'IS NULL',            takesList: false, takesValue: false },
  { value: 'is_not_null',  label: 'IS NOT NULL',        takesList: false, takesValue: false },
];

interface PublishViewDialogProps {
  open: boolean;
  onClose: () => void;
  queryId?: number;
  queryName: string;
  columns?: string[];
  queryParamDefs?: ParamDefinition[];   // Phase 86: auto-populated from saved query
  sourceType?: 'saved_query' | 'business_report' | 'federation' | 'sql_file';
  businessReportId?: number;                        // Phase 91
  federationViewId?: number;                        // Phase 93
  sqlFileId?: number;                               // sql_file source
}

// ── Helpers ──────────────────────────────────────────────────────────────────

const slugify = (text: string) =>
  text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const EMPTY_PARAM = (): ParamDefinition => ({
  name: '',
  type: 'string',
  required: false,
  default: '',
  description: '',
});

// ── Component ────────────────────────────────────────────────────────────────

const PublishViewDialog = ({ open, onClose, queryId, queryName, columns = [], queryParamDefs = [], sourceType = 'saved_query', businessReportId, federationViewId, sqlFileId }: PublishViewDialogProps) => {
  const [slug, setSlug] = useState(() => slugify(queryName));
  const [name, setName] = useState(queryName);
  const [description, setDescription] = useState('');
  const [allowedFilters, setAllowedFilters] = useState<string[]>([]);
  const [defaultLimit, setDefaultLimit] = useState(1000);
  const [maxLimit, setMaxLimit] = useState(50000);
  const [cacheTtl, setCacheTtl] = useState(300);
  const [paramDefs, setParamDefs] = useState<ParamDefinition[]>([]);
  const [allowedAdGroupsInput, setAllowedAdGroupsInput] = useState('');
  // BF-430A — per-PV reader override.  Empty string = use the snapshotted
  // query_config / global s3_readers config.  Reader list is fetched from
  // the backend admin endpoint so a future reader doesn't require a
  // frontend rebuild.
  const [readerOverride, setReaderOverride] = useState('');
  const [availableReaders, setAvailableReaders] = useState<
    { name: string; label: string; description: string }[]
  >([]);
  // Phase 133-J — publisher-time credential routing.  Two questions asked
  // here so consumer (curl) calls never face a credential prompt:
  //   1. executionConnectionId — which connection runs the query.  Empty
  //      means "inherit from the saved query / sql_file / BR".
  //   2. credentialMode — whose credentials resolve at runtime.
  // Default mode is 'publisher' for new PVs (delegated trust — matches the
  // typical "publish for external consumption" intent).  Existing PVs
  // without these columns continue with backend default 'consumer'.
  const [executionConnectionId, setExecutionConnectionId] = useState<number | ''>('');
  const [credentialMode, setCredentialMode] =
    useState<'consumer' | 'publisher' | 'shared'>('publisher');
  const [availableConnections, setAvailableConnections] = useState<
    { id: number; name: string; connection_type: string; is_shared?: boolean }[]
  >([]);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState('');
  const [published, setPublished] = useState(false);
  const [publishedSlug, setPublishedSlug] = useState('');
  const [testApiKey, setTestApiKey] = useState('');  // BF-122: auto-generated test key
  // Phase 86: track whether params were auto-populated
  const [autoPopulatedParams, setAutoPopulatedParams] = useState(false);

  // Phase 85C-4: Data preview state
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [previewCols, setPreviewCols] = useState<string[]>([]);
  const [previewError, setPreviewError] = useState('');

  // Partition auto-detection state
  const [partitionDetecting, setPartitionDetecting] = useState(false);
  const [partitionWarnings, setPartitionWarnings] = useState<string[]>([]);
  const [availableColumns, setAvailableColumns] = useState<string[]>([]);
  const [partitionColumns, setPartitionColumns] = useState<Record<string, string[]>>({});
  // BF-492 (2026-05-27) — cross-connection awareness banner.
  // Saved queries authored against two connections (BQB "cross-connection"
  // toggle, CQB cross-source) snapshot ``secondary_connection_id`` into
  // query_config.  The published consumer endpoint already routes those
  // through the federation engine, but the publisher had no visible cue
  // that they were publishing a multi-source query.  Detection runs in
  // loadColumnCatalog (saved_query path) + the sql_file partition
  // detector (already pulls secondary_connection_id at line 277).
  const [crossConnInfo, setCrossConnInfo] = useState<{
    primary: number | null;
    secondary: number;
    combineMode: string;
  } | null>(null);
  // Phase 132.36 — surfaced WHERE clauses from the saved query.  Each gets
  // a Dynamic/Static toggle so the publisher can decide which columns
  // become URL parameters and which stay locked in the snapshot.
  const [whereClauses, setWhereClauses] = useState<WhereClause[]>([]);
  // BF-268: full column catalogue for the underlying tables — not just
  // the user-selected subset.  Lets the user pick any column as a
  // parameter source instead of typing names by hand.  Grouped by source
  // table so a query touching multiple tables shows them separately.
  const [columnCatalog, setColumnCatalog] = useState<{
    table: string;
    columns: { name: string; type: string }[];
  }[]>([]);
  const [columnCatalogLoading, setColumnCatalogLoading] = useState(false);
  // Phase 132.37 — distinct partition values per column.  Populated by
  // ``api.getRegisteredTablePartitions`` for partition columns the
  // backend already knows.  Lets the value picker offer a real
  // search-and-select dropdown instead of a free-text field.  Keyed by
  // lowercase bare column name so qualified refs (``trades.region``)
  // match the partition list keyed on ``region``.
  const [partitionValues, setPartitionValues] = useState<Record<string, string[]>>({});
  // Phase 133-H round 4 — table → connection_id mapping for cross-source
  // PVs.  When a publisher creates a primary=Trino + secondary=Oracle
  // PV, the columnCatalog has tables from BOTH connections.  Lazy
  // distinct-values must route to the right warehouse — this map lets
  // the lazy fetcher look up which connection each table belongs to.
  const [tableConnectionIds, setTableConnectionIds] =
    useState<Record<string, number>>({});
  // Phase 133-H round 14 — alias → real table mapping from sqlglot.
  // ``FROM trades a JOIN positions b`` → {a: "trades", b: "positions"}.
  // Used by columnOptions to surface alias-qualified column entries
  // (``a.code``, ``b.code``) so JOIN-with-alias publishers get
  // disambiguated dropdowns matching exactly what they wrote.
  const [tableAliases, setTableAliases] = useState<Record<string, string>>({});

  // Phase 86: Auto-populate paramDefs from queryParamDefs when dialog opens
  // AND auto-detect partition columns from query_config
  useEffect(() => {
    if (!open) {
      // Reset transient state when the dialog closes so opening it again
      // for a different query doesn't show stale rows.  Phase 132.36.
      // Phase 133-H — also drop fetched dropdowns (partition values,
      // columnCatalog, partition columns) so a different query doesn't
      // see the previous query's column / value lists.
      setWhereClauses([]);
      setPartitionValues({});
      setColumnCatalog([]);
      setPartitionColumns({});
      setPartitionWarnings([]);
      setTableConnectionIds({});
      setTableAliases({});
      return;
    }

    // Auto-populate from SQL-detected {{params}} (existing Phase 86 logic)
    if (queryParamDefs.length > 0 && paramDefs.length === 0) {
      setParamDefs(queryParamDefs.map(p => ({
        name: p.name,
        type: p.type,
        required: p.required,
        default: p.default || '',
        description: p.description || '',
      })));
      setAutoPopulatedParams(true);
    }

    // Auto-detect partition columns for any source with a query config
    if (queryId) {
      detectPartitionColumns();
      // BF-268: also load full column catalogue so the user can pick ANY
      // column from the underlying tables as a parameter source.
      loadColumnCatalog();
    }
    // Phase 133-I round 20 — sql_file source has no ``queryId``;
    // it only has ``sqlFileId`` + ``sourceType='sql_file'``.  Without
    // this branch, ``detectPartitionColumns`` and the column catalog
    // population NEVER fired for sql_file publishes → user saw empty
    // dropdowns despite the saved SQL having WHERE-clause columns.
    if (!queryId && sqlFileId && sourceType === 'sql_file') {
      detectPartitionColumnsFromSqlFile();
    }

    // BF-430A — load available readers for the override dropdown.  Falls
    // back silently if the admin endpoint isn't reachable (the field
    // remains usable with manual entry through the textfield helper).
    api.s3Readers.metadata().then(setAvailableReaders).catch(() => {
      setAvailableReaders([]);
    });

    // Phase 133-J — load connections so the publisher can redirect
    // execution at runtime (e.g. point at a shared system-account
    // connection without rebuilding the saved query).  Empty list is
    // fine — the picker just shows the inherited connection.
    api.listConnections(true).then((rows: any) => {
      const list = Array.isArray(rows) ? rows : [];
      setAvailableConnections(list.map((c: any) => ({
        id: c.id,
        name: c.name,
        connection_type: c.connection_type,
        is_shared: !!c.is_shared,
      })));
    }).catch(() => {
      setAvailableConnections([]);
    });
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Detect partition columns from saved query's query_config
  // Phase 133-I round 20 — sql_file equivalent of detectPartitionColumns.
  // Fetches the .sql file content, calls /api/sql/preview-columns with
  // the connection_id so the backend's schema_cache returns columns
  // (NO S3 round-trip — that's the user's complaint about full scan).
  // Populates columnCatalog + partitionColumns + tableAliases.
  const detectPartitionColumnsFromSqlFile = useCallback(async () => {
    if (!sqlFileId) return;
    setPartitionDetecting(true);
    setPartitionWarnings([]);
    try {
      const sf: any = await api.sqlFiles.get(Number(sqlFileId));
      const sqlContent: string = sf?.content || '';
      const connId: number | null = sf?.connection_id || null;
      // Phase 133-I round 29 — cross-source sql_file: ALSO fetch the
      // secondary side's columns so the publisher sees the full
      // dropdown for either side of a JOIN/UNION combine.
      const secConnId: number | null = sf?.secondary_connection_id || null;
      const secContent: string = sf?.secondary_content || '';
      // BF-492 — same cross-connection awareness as the saved_query path.
      if (secConnId) {
        setCrossConnInfo({
          primary: connId,
          secondary: secConnId,
          combineMode: sf?.combine_mode || 'union',
        });
      } else {
        setCrossConnInfo(null);
      }
      if (!sqlContent.trim()) {
        setPartitionWarnings(['SQL file is empty']);
        return;
      }
      // Single backend call: returns columns_by_table from schema_cache
      // (sub-ms DB hit), partition_columns_by_table, table_aliases, and
      // table_connection_ids.  This is the cached-schema path the user
      // explicitly asked for — no S3 scan.
      const pc = await fetchPreviewColumns(sqlContent, 'duckdb', connId);
      // Fire the secondary lookup in parallel — independent connection.
      const pcSec = secConnId && secContent
        ? await fetchPreviewColumns(secContent, 'duckdb', secConnId)
        : null;
      if (!pc) return;
      const cbt = pc.columns_by_table || {};
      const pcb = pc.partition_columns_by_table || {};
      const tcids = pc.table_connection_ids || {};
      const aliases = pc.table_aliases || {};
      // Fold into columnCatalog (same shape detectPartitionColumns uses).
      const cbtEntries = Object.entries(cbt);
      if (cbtEntries.length > 0) {
        setColumnCatalog(prev => {
          const byTable = new Map<string, { name: string; type: string }[]>(
            prev.map(g => [g.table, g.columns]),
          );
          cbtEntries.forEach(([tbl, cols]) => {
            const list = (cols || []).map(c => ({
              name: c.name || '',
              type: c.type || 'string',
            })).filter(c => c.name);
            if (list.length > 0) byTable.set(tbl, list);
          });
          return Array.from(byTable.entries()).map(([table, columns]) => ({ table, columns }));
        });
      }
      if (Object.keys(pcb).length > 0) setPartitionColumns(pcb);
      if (Object.keys(tcids).length > 0) {
        setTableConnectionIds(prev => ({ ...prev, ...tcids }));
      }
      if (Object.keys(aliases).length > 0) {
        setTableAliases(prev => ({ ...prev, ...aliases }));
      }
      // Phase 133-I round 29 — merge SECONDARY side's results into the
      // same state.  table_connection_ids correctly tags secondary
      // tables with the secondary conn_id so lazy distinct-values
      // routes to the right warehouse.
      if (pcSec) {
        const secCbt = pcSec.columns_by_table || {};
        const secPcb = pcSec.partition_columns_by_table || {};
        const secTcids = pcSec.table_connection_ids || {};
        const secAliases = pcSec.table_aliases || {};
        const secEntries = Object.entries(secCbt);
        if (secEntries.length > 0) {
          setColumnCatalog(prev => {
            const byTable = new Map<string, { name: string; type: string }[]>(
              prev.map(g => [g.table, g.columns]),
            );
            secEntries.forEach(([tbl, cols]) => {
              const list = (cols || []).map(c => ({
                name: c.name || '',
                type: c.type || 'string',
              })).filter(c => c.name);
              if (list.length > 0) byTable.set(tbl, list);
            });
            return Array.from(byTable.entries()).map(([table, columns]) => ({ table, columns }));
          });
        }
        if (Object.keys(secPcb).length > 0) {
          setPartitionColumns(prev => ({ ...prev, ...secPcb }));
        }
        if (Object.keys(secTcids).length > 0) {
          setTableConnectionIds(prev => ({ ...prev, ...secTcids }));
        }
        if (Object.keys(secAliases).length > 0) {
          setTableAliases(prev => ({ ...prev, ...secAliases }));
        }
      }
      // For sql_file source we don't have qc.filters — but the SQL's
      // own WHERE clause is in sqlContent.  Build empty WHERE rows;
      // publisher adds them via "+ Add Mapping" or by toggling
      // partition badges from the chip picker.
      // Extract bare column names from SQL for the picker fallback.
      const sqlCols = (pc.columns || []).map(c => c.name).filter(Boolean);
      const secSqlCols = pcSec ? (pcSec.columns || []).map(c => c.name).filter(Boolean) : [];
      const allBare = Array.from(new Set([...sqlCols, ...secSqlCols]));
      if (allBare.length > 0) setAvailableColumns(allBare);

      // Phase 133-I round 32 — auto-create paramDefs from partition
      // columns (Required by design — the publisher wants consumers to
      // drive partition pruning).  Same flow detectPartitionColumns
      // uses via the suggested_params field of the backend response.
      // For sql_file we synthesize from partition_columns_by_table.
      const allPartitionCols = new Set<string>();
      Object.values(pcb).forEach(arr => arr.forEach(c => c && allPartitionCols.add(c)));
      if (pcSec) {
        Object.values(pcSec.partition_columns_by_table || {}).forEach(arr =>
          arr.forEach(c => c && allPartitionCols.add(c)),
        );
      }
      if (allPartitionCols.size > 0) {
        setParamDefs(prev => {
          const existing = new Set(prev.map(p => p.name.toLowerCase()));
          const additions: ParamDefinition[] = [];
          allPartitionCols.forEach(col => {
            if (existing.has(col.toLowerCase())) return;
            additions.push({
              name: col,
              type: _inferTypeForColumn(col),
              required: true,
              default: '',
              description: `Partition column (auto-detected from sql_file)`,
              inferredReason: 'from partition column',
            });
            existing.add(col.toLowerCase());
          });
          if (additions.length > 0) {
            setAutoPopulatedParams(true);
            return [...prev, ...additions];
          }
          return prev;
        });
      }
    } catch (err: any) {
      setPartitionWarnings([err.message || 'Failed to extract columns from SQL file']);
    } finally {
      setPartitionDetecting(false);
    }
  }, [sqlFileId]);

  const detectPartitionColumns = useCallback(async () => {
    if (!queryId) return;
    setPartitionDetecting(true);
    setPartitionWarnings([]);
    try {
      // Fetch the saved query to get its query_config
      const sq = await api.getSavedQuery(String(queryId)) as any;
      if (!sq?.query_config) {
        setPartitionWarnings(['Could not load saved query config']);
        return;
      }
      const qc = sq.query_config;
      const connId = qc.connection_id;
      // BF-492 — detect cross-connection saved queries.  The execute
      // path (published_views_api.py line 1446+) ALREADY handles
      // secondary_connection_id correctly — this just surfaces the fact
      // in the UI so the publisher knows what they're publishing.
      if (qc.secondary_connection_id) {
        setCrossConnInfo({
          primary: connId ?? null,
          secondary: qc.secondary_connection_id,
          combineMode: qc.combine_mode || 'union',
        });
      } else {
        setCrossConnInfo(null);
      }

      // Phase 133-I round 21 — ALSO call /api/sql/preview-columns with
      // the saved query's raw_sql + connection_id.  This pulls from
      // schema_cache (no S3 scan) and works EVEN WHEN qc.files is
      // empty / detect_partitions returns nothing — exactly the case
      // the user kept hitting on raw-SQL saved queries.  Same path
      // the sql_file branch uses (round 20).
      const _sqlForCatalog = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
        .filter((s: any) => typeof s === 'string' && s.trim())
        .join('\n');
      if (_sqlForCatalog && connId) {
        try {
          const pc = await fetchPreviewColumns(_sqlForCatalog, 'duckdb', connId);
          if (pc) {
            const cbt = pc.columns_by_table || {};
            const pcb = pc.partition_columns_by_table || {};
            const tcids = pc.table_connection_ids || {};
            const aliases = pc.table_aliases || {};
            const cbtEntries = Object.entries(cbt);
            if (cbtEntries.length > 0) {
              setColumnCatalog(prev => {
                const byTable = new Map<string, { name: string; type: string }[]>(
                  prev.map(g => [g.table, g.columns]),
                );
                cbtEntries.forEach(([tbl, cols]) => {
                  const list = (cols || []).map(c => ({
                    name: c.name || '',
                    type: c.type || 'string',
                  })).filter(c => c.name);
                  if (list.length > 0) byTable.set(tbl, list);
                });
                return Array.from(byTable.entries()).map(([table, columns]) => ({ table, columns }));
              });
            }
            if (Object.keys(pcb).length > 0) {
              setPartitionColumns(prev => ({ ...prev, ...pcb }));
            }
            if (Object.keys(tcids).length > 0) {
              setTableConnectionIds(prev => ({ ...prev, ...tcids }));
            }
            if (Object.keys(aliases).length > 0) {
              setTableAliases(prev => ({ ...prev, ...aliases }));
            }
          }
        } catch { /* best-effort */ }
      }

      // Phase 133-H round 12 — extract available columns from
      // query_config.  BQB saves them as ``qc.columns`` (flat string
      // array); CQB / older shapes save as ``qc.selected_columns``
      // (objects).  Read BOTH — first match wins, dedupe by lower-case.
      const selCols: string[] = [];
      const seenLower = new Set<string>();
      const _push = (n: string) => {
        const k = (n || '').toLowerCase();
        if (!k || seenLower.has(k)) return;
        seenLower.add(k);
        selCols.push(n);
      };
      // BQB shape: qc.columns is a flat string array.
      if (Array.isArray(qc.columns)) {
        qc.columns.forEach((c: any) => {
          if (typeof c === 'string') _push(c);
          else if (c && typeof c === 'object') _push(c.columnName || c.name || c.physical_name || '');
        });
      }
      // CQB / older shape: qc.selected_columns is a list of objects.
      if (Array.isArray(qc.selected_columns)) {
        qc.selected_columns.forEach((c: any) =>
          _push(c?.columnName || c?.name || c?.physical_name || ''),
        );
      }
      // Phase 133-H round 14 — extract table aliases from the saved
      // query's raw_sql via sqlglot so the dropdown can suggest
      // alias-qualified columns (``a.code``, ``b.code``) for JOIN
      // queries.  Best-effort — non-SQL sources fall through with
      // an empty alias map.
      const _rawSqlForAliases = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
        .filter((s: any) => typeof s === 'string' && s.trim())
        .join('\n');
      if (_rawSqlForAliases) {
        try {
          const _pc = await fetchPreviewColumns(_rawSqlForAliases, 'duckdb', null);
          if (_pc?.table_aliases && Object.keys(_pc.table_aliases).length > 0) {
            setTableAliases(prev => ({ ...prev, ..._pc.table_aliases }));
          }
        } catch { /* best-effort */ }
      }

      // Phase 133-H round 13 — preserve qualifier on availableColumns
      // so JOIN queries with table aliases keep ``a.code`` and
      // ``b.code`` distinct.  columnOptions adds both qualified AND
      // bare entries to the dropdown so either form picks up the
      // matching row.
      if (selCols.length > 0) {
        setAvailableColumns(selCols);
      }

      // Call detect-partitions endpoint
      const result = await api.detectPartitions({
        query_config: qc,
        connection_id: connId,
      });

      const suggested: any[] = result?.suggested_params || [];
      const pcols: Record<string, string[]> = result?.partition_columns || {};
      const warns: string[] = result?.warnings || [];
      // Phase 133-H — backend now returns the FULL column list per
      // source table.  Works for SQL connectors (Trino/Snowflake/etc.),
      // registered S3 tables, iceberg tables, and raw S3 — every shape
      // the WHERE-clause editor needs to show a column dropdown.
      const cbt: Record<string, Array<{name: string; type?: string}>> =
        result?.columns_by_table || {};
      const tcids: Record<string, number> =
        result?.table_connection_ids || {};
      if (Object.keys(tcids).length > 0) {
        setTableConnectionIds(prev => ({ ...prev, ...tcids }));
      }

      setPartitionColumns(pcols);
      if (warns.length > 0) setPartitionWarnings(warns);

      // Phase 133-H — seed columnCatalog from detect-partitions so the
      // WHERE-clause Autocomplete shows every column the underlying
      // tables expose (not just user-selected or partition cols).
      // ``loadColumnCatalog`` runs in parallel and may also populate
      // this; we merge by table so neither wins/loses arbitrarily.
      const cbtEntries = Object.entries(cbt);
      if (cbtEntries.length > 0) {
        setColumnCatalog(prev => {
          const byTable = new Map<string, { name: string; type: string }[]>(
            prev.map(g => [g.table, g.columns]),
          );
          cbtEntries.forEach(([tbl, cols]) => {
            const list = (cols || []).map(c => ({
              name: c.name || '',
              type: c.type || 'string',
            })).filter(c => c.name);
            if (list.length > 0) byTable.set(tbl, list);
          });
          return Array.from(byTable.entries()).map(([table, columns]) => ({ table, columns }));
        });
      }

      // Phase 132.36 — populate the WHERE Clauses section via the
      // pure helper so the logic is unit-tested in isolation.
      const allPartitionCols = new Set<string>();
      Object.values(pcols).forEach(arr => arr.forEach(c => allPartitionCols.add(c)));
      const qcFilters: any[] = Array.isArray(qc.filters) ? qc.filters : [];
      // Phase 132.37 — if the publisher had previously categorised rows on
      // an earlier publish, restore that mapping (stashed inside
      // query_config._where_clauses_mapping on republish).
      const prior: any[] = Array.isArray(qc._where_clauses_mapping)
        ? qc._where_clauses_mapping : [];
      // Phase 134-L — when the source query is raw SQL (BQB SQL editor /
      // sql_file source_type) qc.filters is empty because the filters
      // live inside the SQL text.  Fall back to parsing WHERE triples
      // out of qc.raw_sql / qc.custom_sql / qc.secondary_raw_sql so the
      // publisher sees their source query's WHERE clauses by default
      // instead of an empty editor.
      const _rawSqlBlob: string = [
        qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql,
      ].filter((s: any) => typeof s === 'string' && s.trim()).join('\n');

      const _fromVisual = buildWhereClausesFromQueryConfig(qcFilters, allPartitionCols);
      const _fromRawSql = _fromVisual.length === 0 && _rawSqlBlob
        ? buildWhereClausesFromRawSql(_rawSqlBlob, allPartitionCols)
        : [];

      const wcs: WhereClause[] = prior.length > 0
        ? prior.map(p => ({
            column: p.column,
            operator: p.operator || 'eq',
            value: p.value,
            mode: (p.mode === 'dynamic' ? 'dynamic' : 'static') as 'dynamic' | 'static',
            isPartition: allPartitionCols.has(p.column),
          }))
        : (_fromVisual.length > 0 ? _fromVisual : _fromRawSql);
      // Phase 132.37 — seed partition columns that have no row yet.  The
      // publisher sees every partition column up front and decides
      // Dynamic vs Static instead of having to remember to add them.
      const seenCols = new Set(wcs.map(w => w.column.toLowerCase()));
      allPartitionCols.forEach(pcol => {
        if (!seenCols.has(pcol.toLowerCase())) {
          wcs.push({
            column: pcol,
            operator: 'eq',
            value: '',
            mode: 'dynamic',
            isPartition: true,
          });
          seenCols.add(pcol.toLowerCase());
        }
      });
      setWhereClauses(prev => {
        // Don't clobber edits the user already made (e.g., they toggled
        // a row).  Only overwrite when we have no prior rows.
        if (prev.length === 0) return wcs;
        return prev;
      });
      // Phase 133-H — kick off distinct-value fetch for every column we
      // seeded so the value picker is a dropdown from the first render,
      // not after the publisher clicks the column twice.
      wcs.forEach(w => {
        if (w.column) lazilyFetchDistinctValues(w.column);
      });
      // Sync allowed_filters from the Dynamic rows.
      const dynamicCols = wcs.filter(w => w.mode === 'dynamic').map(w => w.column);
      if (dynamicCols.length > 0) {
        setAllowedFilters(prev => {
          const merged = Array.from(new Set([...prev, ...dynamicCols]));
          return merged;
        });
      }

      // Phase 132.37 — fetch distinct partition values for each registered
      // table so the value picker offers a search-and-select dropdown.
      // Best-effort: ignore errors (the value field falls back to free text).
      Object.entries(pcols).forEach(([tableName, _cols]) => {
        if (!connId || !tableName) return;
        api.getRegisteredTablePartitions(String(connId), tableName)
          .then((pres: any) => {
            const vals: Record<string, string[]> = pres?.values || {};
            if (!vals || Object.keys(vals).length === 0) return;
            setPartitionValues(prev => {
              const next = { ...prev };
              Object.entries(vals).forEach(([col, arr]) => {
                const k = (col || '').toLowerCase();
                const list = Array.isArray(arr) ? arr.map(String) : [];
                if (list.length > 0) next[k] = list;
              });
              return next;
            });
          })
          .catch(() => { /* best-effort */ });
      });

      // Auto-populate partition params as defaults (only if no params already set)
      if (suggested.length > 0) {
        setParamDefs(prev => {
          const existingNames = new Set(prev.map(p => p.name));
          const newParams: ParamDefinition[] = suggested
            .filter((s: any) => !existingNames.has(s.name))
            .map((s: any) => ({
              name: s.name,
              type: (s.type || 'string') as ParamType,
              required: s.required ?? true,
              default: s.default || '',
              description: s.description || '',
              inferredReason: s.inferred_reason,
            }));
          if (newParams.length > 0) {
            setAutoPopulatedParams(true);
            return [...prev, ...newParams];
          }
          return prev;
        });
      }
    } catch (err: any) {
      // Non-fatal: partition detection is best-effort
      setPartitionWarnings([err.message || 'Partition detection failed']);
    } finally {
      setPartitionDetecting(false);
    }
  }, [queryId]);

  // Load preview when dialog opens and queryId is provided (skipped for
  // non-query sources — business_report / federation / sql_file each
  // need their own preview path; sql_file preview pending its own UI).
  useEffect(() => {
    if (!open || !queryId) return;
    if (sourceType === 'business_report' || sourceType === 'federation' || sourceType === 'sql_file') return;
    setPreviewLoading(true);
    setPreviewRows([]);
    setPreviewCols([]);
    setPreviewError('');
    api.executeQuery({ query_id: String(queryId), output_format: 'json', limit: 10 } as any)
      .then(async (res: any) => {
        const execId = res?.execution_id;
        if (!execId) return;
        let attempts = 0;
        while (attempts < 12) {
          await new Promise(r => setTimeout(r, 800));
          const status = await api.getExecutionStatus(execId);
          if (status?.status === 'completed' || status?.result) {
            const rows = status?.result?.rows || status?.rows || [];
            const cols = status?.result?.columns || status?.columns || (rows[0] ? Object.keys(rows[0]) : []);
            setPreviewRows(rows.slice(0, 10));
            setPreviewCols(cols);
            // Update available columns from actual result if not already set
            if (cols.length > 0) {
              setAvailableColumns(prev => prev.length > 0 ? prev : cols);
            }
            break;
          }
          if (status?.status === 'failed') {
            setPreviewError('Preview failed: ' + (status?.error || 'unknown'));
            break;
          }
          attempts++;
        }
      })
      .catch((e: any) => setPreviewError(e.message || 'Preview failed'))
      .finally(() => setPreviewLoading(false));
  }, [open, queryId]);

  // Use dedicated Published API URL if configured, otherwise fall back to main API
  const pubBase = PUBLISHED_API_BASE_URL || API_BASE_URL || window.location.origin;
  const apiUrl = useMemo(
    () => `${pubBase}/api/v1/views/${publishedSlug || slug}/data`,
    [pubBase, publishedSlug, slug]
  );

  // Phase 132.37 — type inference for the value picker.  Re-used by the
  // auto-param-sync effect so a Dynamic WHERE row gets a sensibly-typed
  // ParamDefinition (date partition → date param, year/month → integer,
  // etc.).  Also used to decide whether the value-picker should show a
  // number input vs free text.  Falls back to 'string' so we never block
  // the publisher with a guess-it-wrong type.
  const _inferTypeForColumn = useCallback((rawCol: string): ParamType => {
    const colName = (rawCol || '').toLowerCase().replace(/^.*\./, '');
    if (!colName) return 'string';
    // 1. columnCatalog hit (preferred — real schema type)
    for (const grp of columnCatalog) {
      const hit = grp.columns.find(c => (c.name || '').toLowerCase() === colName);
      if (hit) return _mapColumnType(hit.type);
    }
    // 2. partition column name heuristics (matches backend _infer_param_type)
    if (colName.includes('date')) return 'date';
    if (colName.endsWith('_dt')) return 'date';
    if (['year', 'month', 'day', 'quarter'].includes(colName)) return 'integer';
    return 'string';
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columnCatalog]);

  // Phase 132.37 — auto-generate ParamDefinitions from Dynamic WHERE
  // rows.  Each Dynamic row needs a matching ParamDefinition so the
  // backend's runtime parameter parser accepts ?col=value AND publishes
  // the column in the API documentation.  We tag auto-added params
  // with ``inferredReason = "from WHERE clause"`` so the publisher can
  // see why it appeared, and so flipping a row Dynamic→Static (or
  // deleting it) safely removes the auto-param without clobbering
  // manually-added ones.  Manually-added params (no inferredReason or
  // a different reason) are never touched.
  const PARAM_FROM_WHERE_REASON = 'from WHERE clause';
  useEffect(() => {
    if (!open) return;
    const dynamicCols = Array.from(
      new Set(
        whereClauses
          .filter(w => w.mode === 'dynamic' && (w.column || '').trim())
          .map(w => w.column.trim().replace(/^.*\./, '')),
      ),
    );
    const dynamicLowerSet = new Set(dynamicCols.map(c => c.toLowerCase()));
    setParamDefs(prev => {
      // 1. Drop auto-from-WHERE params whose column is no longer Dynamic.
      let next = prev.filter(p =>
        p.inferredReason !== PARAM_FROM_WHERE_REASON ||
        dynamicLowerSet.has(p.name.toLowerCase()),
      );
      // 2. Add a new auto-param for any Dynamic column not yet present.
      // Phase 133-I — Dynamic columns are REQUIRED by design: the
      // publisher's act of marking a column Dynamic means "consumer
      // MUST supply this at call time".  Auto-param is required=true;
      // publisher can still uncheck the box in the UI to make it
      // optional if they want a default-applied-on-skip behaviour.
      const existing = new Set(next.map(p => p.name.toLowerCase()));
      for (const col of dynamicCols) {
        if (existing.has(col.toLowerCase())) continue;
        next = [...next, {
          name: col,
          type: _inferTypeForColumn(col),
          required: true,
          default: '',
          description: 'Auto-created from WHERE mapping (Dynamic)',
          inferredReason: PARAM_FROM_WHERE_REASON,
        }];
        existing.add(col.toLowerCase());
      }
      return next;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [whereClauses, open]);

  // Phase 132.36 — toggle a WHERE row between Dynamic / Static.  Side
  // effect: keep the Allowed Filter Columns list in sync so consumers
  // can hit ?column=value for every Dynamic row.
  //
  // Phase 132.36 hotfix-1: when multiple WHERE rows share a column
  // (e.g. ``region IN ('APAC')`` AND ``region != 'TEST'``), toggling
  // ONE row to Static must NOT remove the column from allowed_filters
  // if another peer row on the same column is still Dynamic.  Compute
  // the new array, then derive allowed_filters from "any row still
  // Dynamic for this column?".
  const setWhereMode = useCallback((idx: number, mode: 'dynamic' | 'static') => {
    setWhereClauses(prev => {
      const next = applyWhereModeToggle(prev, idx, mode);
      // Phase 133-H round 11 — chip-click should also update the value
      // field to reflect the new mode (Dynamic = `?`, Static = clear
      // the `?` sentinel if present).  Keeps value-field and chip in
      // sync regardless of which UI the publisher prefers.
      if (next[idx]) {
        const row = next[idx];
        const opSpec = OPERATORS.find(o => o.value === row.operator);
        const isListOp = !!opSpec?.takesList;
        const takesValue = opSpec ? opSpec.takesValue : true;
        if (takesValue) {
          if (mode === 'dynamic') {
            row.value = isListOp ? ['?'] : '?';
          } else if (row.value === '?' || (Array.isArray(row.value) && row.value.every(v => String(v) === '?'))) {
            // Clear the sentinel when switching back to Static — let
            // the publisher type a real value.
            row.value = isListOp ? [] : '';
          }
        }
      }
      const col = next[idx]?.column;
      if (col) {
        setAllowedFilters(afPrev =>
          syncAllowedFiltersAfterToggle(next, col, afPrev),
        );
      }
      return next;
    });
  }, []);

  // Phase 132.37 — flat list of all picker-eligible columns for the
  // searchable WHERE-row column Autocomplete.  Sourced from
  // columnCatalog (preferred — has types) with a fallback to the
  // selected-columns + partition-column lists when the catalog isn't
  // populated yet (e.g. metadata cache miss).  De-duped by lowercase
  // name so repeated picks across tables don't show twice.
  const columnOptions = useMemo<{ name: string; type: string; isPartition: boolean; tableSource: string }[]>(() => {
    const seen = new Set<string>();
    const out: { name: string; type: string; isPartition: boolean; tableSource: string }[] = [];
    const partitionSet = new Set<string>();
    Object.values(partitionColumns).forEach(arr => arr.forEach(c => partitionSet.add(c.toLowerCase())));

    // Phase 133-H round 13 — JOIN-with-aliases: bare + qualified.
    // Phase 133-I round 21 — also carries a ``tableSource`` field so
    // the Autocomplete can groupBy() table — same UX CQB uses.
    const _push = (rawName: string, type: string, tableSource: string = '') => {
      if (!rawName) return;
      const lowerKey = rawName.toLowerCase();
      if (seen.has(lowerKey)) return;
      const bare = rawName.includes('.')
        ? rawName.substring(rawName.lastIndexOf('.') + 1)
        : rawName;
      const bareKey = bare.toLowerCase();
      const isPart = partitionSet.has(bareKey) || partitionSet.has(lowerKey);
      seen.add(lowerKey);
      out.push({
        name: rawName,
        type: type || 'string',
        isPartition: isPart,
        tableSource: tableSource || (isPart ? 'Partition columns' : 'Other'),
      });
    };

    // Phase 133-H round 14 — reverse-lookup: real table → list of
    // aliases the publisher wrote in the saved SQL.  Lets us emit
    // alias-qualified entries (``a.code``, ``b.code``) alongside the
    // table-qualified ones (``trades.code``).
    const aliasesByTable: Record<string, string[]> = {};
    Object.entries(tableAliases).forEach(([alias, realTable]) => {
      if (!alias || !realTable) return;
      const lk = realTable.toLowerCase();
      if (!aliasesByTable[lk]) aliasesByTable[lk] = [];
      aliasesByTable[lk].push(alias);
    });

    columnCatalog.forEach(grp => {
      const tableKey = (grp.table || '').replace(/^.*:/, '');
      const tableLower = tableKey.toLowerCase();
      const aliasesForThisTable = aliasesByTable[tableLower] || [];
      // Phase 133-I round 21 — pass tableSource so the dropdown can
      // group by table (matches CQB's UX).
      const groupLabel = tableKey || 'Other';
      grp.columns.forEach(c => {
        const bare = c.name || '';
        if (!bare) return;
        _push(bare, c.type || 'string', groupLabel);
        if (tableKey) _push(`${tableKey}.${bare}`, c.type || 'string', groupLabel);
        aliasesForThisTable.forEach(alias => {
          _push(`${alias}.${bare}`, c.type || 'string', groupLabel);
        });
      });
    });

    // Phase 133-H round 12 — selected_columns / qc.columns (BQB/CQB
    // saved column list).  Pre-stripped to bare names in
    // detectPartitionColumns — but the original qualified form might
    // also appear in filters.  Push both.
    availableColumns.forEach(c => _push(c, 'string'));

    // Phase 133-H round 12 — ``columns`` prop from caller (BQB hands
    // us selectedPhysical = ``[trades.region, ...]``).  Push the
    // qualified form AND the bare form so a row carrying either
    // shape finds a match.
    columns.forEach(c => {
      if (!c) return;
      _push(c, 'string');   // qualified e.g. ``trades.region``
      const bare = c.includes('.')
        ? c.substring(c.lastIndexOf('.') + 1)
        : c;
      _push(bare, 'string'); // bare e.g. ``region``
    });

    // Make sure partition columns we *know about* are always pickable
    // even when columnCatalog / selected_columns missed them.
    partitionSet.forEach(pcol => {
      const lk = pcol.toLowerCase();
      if (!seen.has(lk)) {
        seen.add(lk);
        out.push({ name: pcol, type: 'string', isPartition: true, tableSource: 'Partition columns' });
      }
    });
    return out;
  }, [columnCatalog, availableColumns, partitionColumns, columns, tableAliases]);

  // Phase 132.37 — add an empty WHERE-row.  Defaults: Dynamic + eq.
  const addWhereClause = () => {
    setWhereClauses(prev => [...prev, {
      column: '', operator: 'eq', value: '', mode: 'dynamic', isPartition: false,
    }]);
  };

  const removeWhereClause = (idx: number) => {
    setWhereClauses(prev => {
      const removed = prev[idx]?.column;
      const next = prev.filter((_, i) => i !== idx);
      if (removed) {
        setAllowedFilters(afPrev =>
          syncAllowedFiltersAfterToggle(next, removed, afPrev),
        );
      }
      return next;
    });
  };

  // Phase 133-H — lazy distinct-values fetcher.  When the user picks a
  // column in a WHERE row that doesn't yet have known values cached
  // (e.g. a non-partition column on a SQL warehouse), fetch up to 200
  // distinct values via /api/sql/distinct-values so the value picker
  // becomes a dropdown instead of a plain textbox.  Best-effort —
  // failures fall back to free-text quietly.
  const lazilyFetchDistinctValues = useCallback(async (
    column: string,
  ) => {
    const colKey = (column || '').toLowerCase().replace(/^.*\./, '');
    if (!colKey) return;
    setPartitionValues(prev => {
      // Avoid duplicate fetches — if we already have values for this
      // column (or fetched and got nothing), don't re-hit the backend.
      if (Object.prototype.hasOwnProperty.call(prev, colKey)) return prev;
      return { ...prev, [colKey]: [] };  // sentinel: in-flight
    });
    try {
      const sq = await api.getSavedQuery(String(queryId)) as any;
      const qc = sq?.query_config || {};
      const primaryConnId = qc.connection_id;
      if (!primaryConnId) return;
      // Pick a table to query against.  Prefer the table the column
      // actually belongs to via columnCatalog; fall back to the first
      // table the query references.
      let table = '';
      for (const grp of columnCatalog) {
        if (grp.columns.some(c => c.name.toLowerCase() === colKey)) {
          table = grp.table;
          break;
        }
      }
      // Phase 133-H round 4 — pick the right connection for the
      // resolved table.  Cross-source PVs have tables from both
      // primary and secondary connections; routing to the wrong one
      // returns empty.  Fall back to primary when the table isn't
      // in the map (single-source publishes).
      const connId = (table && tableConnectionIds[table])
        ? tableConnectionIds[table]
        : primaryConnId;
      if (!table) {
        const files: any[] = qc.files || [];
        for (const f of files) {
          const p = typeof f === 'string' ? f : (f?.path || '');
          if (p.startsWith('__registered__:')) {
            table = p.slice('__registered__:'.length);
            break;
          }
          if (p.startsWith('__iceberg__:')) {
            table = p.slice('__iceberg__:'.length);
            break;
          }
        }
      }
      // Phase 133-H deep-dive — SQL-warehouse publishes have empty
      // ``files[]`` and the table lives inside ``raw_sql`` /
      // ``custom_sql`` / ``secondary_raw_sql``.  Pull the first FROM
      // target out of any of them so the lookup has a target.
      if (!table) {
        const sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
          .filter(s => typeof s === 'string')
          .join('\n');
        const m = sqlBlob.match(
          /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
        );
        if (m) table = m[1].replace(/[\s"`\[\]]/g, '');
      }
      if (!table) return;  // distinct-values endpoint requires a table
      // Phase 133-H round 4 — strip table qualifier from column so
      // the endpoint doesn't quote ``"schema.table.col"`` as one ident.
      const bareCol = column.includes('.')
        ? column.substring(column.lastIndexOf('.') + 1)
        : column;
      const res = await fetchDistinctValues(Number(connId), table, bareCol);
      const vals: string[] = (res?.values || []).map(String);
      if (vals.length > 0) {
        setPartitionValues(prev => ({ ...prev, [colKey]: vals }));
      }
    } catch {
      /* best-effort */
    }
  }, [queryId, columnCatalog, tableConnectionIds]);

  // Phase 133-H round 11 — `?` sentinel UX.  The user's design: the
  // publisher edits the value field directly; entering `?` flips the
  // row to Dynamic, anything else makes it Static.  No click on the
  // chip required.  The chips still work as click-to-toggle (which
  // sets value to `?` or restores the original) for users who prefer
  // that flow.
  const _isQuestionSentinel = (v: any): boolean => {
    if (v === '?') return true;
    if (Array.isArray(v)) {
      return v.length > 0 && v.every(item => String(item).trim() === '?');
    }
    return false;
  };

  // Phase 133-I round 21 — ``syncAllowedFilters`` flag: only push the
  // column to allowedFilters when the change is FINAL (onChange =
  // user picked from dropdown OR blurred the field).  Per-keystroke
  // onInputChange must NOT sync — otherwise every partial typed
  // character ("r", "re", "reg", "regi"...) gets pushed into the
  // Allowed Filter Columns advanced field, polluting it with garbage.
  const updateWhereField = (
    idx: number,
    field: keyof WhereClause,
    value: any,
    syncAllowedFilters: boolean = true,
  ) => {
    setWhereClauses(prev => prev.map((w, i) => {
      if (i !== idx) return w;
      const next = { ...w, [field]: value };
      if (field === 'column') {
        const isPartition = Object.values(partitionColumns).some(arr =>
          arr.some(c => c.toLowerCase() === String(value).toLowerCase()),
        );
        next.isPartition = isPartition;
      }
      if (field === 'operator') {
        // Switching to a list operator and the value isn't an array → wrap it.
        const opSpec = OPERATORS.find(o => o.value === value);
        if (opSpec?.takesList && !Array.isArray(next.value)) {
          next.value = next.value ? [String(next.value)] : [];
        }
        if (!opSpec?.takesList && Array.isArray(next.value)) {
          next.value = next.value[0] ?? '';
        }
        if (opSpec && !opSpec.takesValue) {
          next.value = null;
        }
      }
      // Phase 133-H round 11 — derive mode from value when the value
      // field changes.  `?` (or list of `?`s) → Dynamic, anything else
      // → Static.  This is the "replace value with ? to make dynamic"
      // UX the user asked for.
      if (field === 'value') {
        next.mode = _isQuestionSentinel(value) ? 'dynamic' : 'static';
      }
      return next;
    }));
    // Column rename → keep allowed_filters in sync via peer-aware helper.
    // Skip on per-keystroke typing — only sync when the column is finalized.
    if (field === 'column' && syncAllowedFilters) {
      setWhereClauses(prev2 => {
        setAllowedFilters(afPrev =>
          syncAllowedFiltersAfterToggle(prev2, String(value), afPrev),
        );
        return prev2;
      });
    }
    // Mode auto-flipped via value change → resync allowed_filters too.
    if (field === 'value' && syncAllowedFilters) {
      setWhereClauses(prev2 => {
        const col = prev2[idx]?.column;
        if (col) {
          setAllowedFilters(afPrev =>
            syncAllowedFiltersAfterToggle(prev2, col, afPrev),
          );
        }
        return prev2;
      });
    }
  };

  // Phase 132.36: prefer bare-form params (?name=value) over the
  // bracketed back-compat form (?param[name]=value).  Bracketed form
  // is only required when the param name collides with a reserved
  // pagination/projection key (limit/offset/sort/columns/format/cache).
  const RESERVED_PARAM_NAMES = new Set([
    'limit', 'offset', 'sort', 'columns', 'format', 'cache',
    'snapshot_id', 'as_of_timestamp', 'engine', 'filter',
  ]);
  // Phase 133-I round 23 — curl example uses the same bare-name logic
  // as the URL preview + placeholder format.  Was emitting literally
  // ``?region=string`` (the type literal as the placeholder value)
  // and using qualified names like ``trades.region`` instead of the
  // bare ``region`` the backend expects.
  const curlExample = useMemo(() => {
    const validParams = paramDefs.filter(p => p.name.trim());
    if (validParams.length > 0) {
      const paramStr = validParams
        .map(p => {
          const needsBracket = RESERVED_PARAM_NAMES.has(p.name);
          const key = needsBracket ? `param[${p.name}]` : p.name;
          const placeholder = p.default
            ? encodeURIComponent(String(p.default))
            : `<${p.type}>`;
          return `${key}=${placeholder}`;
        })
        .join('&');
      return `curl -H "X-API-Key: qs_YOUR_KEY" \\\n  "${apiUrl}?${paramStr}&limit=10"`;
    }
    return `curl -H "X-API-Key: qs_YOUR_KEY" "${apiUrl}?limit=10"`;
  }, [apiUrl, paramDefs]);

  // ── Param definition handlers ────────────────────────────────────────────

  const addParam = () => setParamDefs(prev => [...prev, EMPTY_PARAM()]);

  // BF-268: map a backend column type → ParamType (DuckDB / parquet types →
  // the 5 we support: string / integer / float / boolean / date).
  const _mapColumnType = (colType: string): ParamType => {
    const t = (colType || '').toLowerCase();
    if (t.includes('date') || t.includes('time')) return 'date';
    if (t.includes('bool')) return 'boolean';
    if (t === 'int' || t.includes('int') || t.includes('long') || t.includes('bigint')) return 'integer';
    if (t.includes('float') || t.includes('double') || t.includes('decimal') || t.includes('numeric') || t.includes('real')) return 'float';
    return 'string';
  };

  const addParamFromColumn = (colName: string, colType?: string) => {
    // Check if already exists
    if (paramDefs.some(p => p.name === colName)) return;
    // Prefer real column type when we have it (BF-268); otherwise fall back
    // to name-based heuristic for legacy callers without metadata.
    let type: ParamType = 'string';
    if (colType) {
      type = _mapColumnType(colType);
    } else {
      const lower = colName.toLowerCase();
      if (lower.includes('date') || lower === 'business_date' || lower === 'trade_date') type = 'date';
      else if (lower === 'year' || lower === 'month' || lower === 'day' || lower === 'quarter') type = 'integer';
    }
    setParamDefs(prev => [...prev, { name: colName, type, required: false, default: '', description: '' }]);
  };

  // BF-268: fetch full column catalogue for all referenced tables so the
  // user can pick ANY column as a parameter source — not just the ones
  // selected in BQB/CQB.  Best-effort: if any single fetch fails we still
  // show what we got from the others.  Triggered when the dialog opens
  // alongside detectPartitionColumns().
  const loadColumnCatalog = useCallback(async () => {
    if (!queryId) return;
    setColumnCatalogLoading(true);
    try {
      const sq = await api.getSavedQuery(String(queryId)) as any;
      const qc = sq?.query_config;
      const connId = qc?.connection_id;
      if (!qc || !connId) {
        setColumnCatalogLoading(false);
        return;
      }
      const files: any[] = qc.files || [];
      // Resolve table name from each file ref.  Phase 133-H deep-dive:
      // ``__iceberg__:`` paths now go through the same schema endpoint
      // as ``__registered__:`` (the backend treats iceberg tables as
      // registered for schema/partition lookups).  Without this, the
      // dialog tried previewDatasetColumns with the literal
      // ``__iceberg__:tablename`` path which fails.
      const tablesToFetch = files.map(f => {
        const path = typeof f === 'string' ? f : (f?.path || '');
        if (path.startsWith('__registered__:')) {
          return { kind: 'registered', name: path.slice('__registered__:'.length), path };
        }
        if (path.startsWith('__iceberg__:')) {
          return { kind: 'registered', name: path.slice('__iceberg__:'.length), path };
        }
        // Raw S3 / local path — last segment as display name
        const segs = path.replace(/\/$/, '').split('/');
        return { kind: 'raw', name: segs[segs.length - 1] || path, path };
      });
      // Fire all schema fetches in parallel
      const results = await Promise.all(tablesToFetch.map(async (t) => {
        try {
          if (t.kind === 'registered') {
            const sch: any = await api.getRegisteredTableSchema(String(connId), t.name);
            const cols = (sch?.columns || []).map((c: any) => ({
              name: c.name || c.column_name || '',
              type: String(c.type || c.data_type || 'string'),
            })).filter((c: any) => c.name);
            return { table: t.name, columns: cols };
          }
          // Raw S3 / parquet file
          const pv: any = await api.previewDatasetColumns(Number(connId), t.path);
          const cols = (pv?.columns || []).map((c: any) => ({
            name: c.name || c.column_name || '',
            type: String(c.type || c.data_type || 'string'),
          })).filter((c: any) => c.name);
          return { table: t.name, columns: cols };
        } catch {
          return { table: t.name, columns: [] };
        }
      }));
      // Phase 133-H — merge with existing catalog so detectPartitionColumns
      // (which runs in parallel and populates SQL-warehouse / iceberg
      // schemas via ``columns_by_table``) isn't clobbered by a later
      // setState here.  Both functions feed the same Autocomplete; we
      // never want one to wipe the other's contribution.
      setColumnCatalog(prev => {
        const byTable = new Map<string, { name: string; type: string }[]>(
          prev.map(g => [g.table, g.columns]),
        );
        results.forEach(r => {
          if (r.columns.length > 0) byTable.set(r.table, r.columns);
        });
        return Array.from(byTable.entries()).map(([table, columns]) => ({ table, columns }));
      });
    } catch {
      // Non-fatal — catalog is a UX enhancement, not required for publish
    } finally {
      setColumnCatalogLoading(false);
    }
  }, [queryId]);

  const removeParam = (idx: number) =>
    setParamDefs(prev => prev.filter((_, i) => i !== idx));

  const updateParam = (idx: number, field: keyof ParamDefinition, value: any) =>
    setParamDefs(prev =>
      prev.map((p, i) => {
        if (i !== idx) return p;
        const next = { ...p, [field]: value };
        // User overrode the auto-inferred type — clear the reason so the
        // tooltip doesn't keep showing a now-stale rationale.
        if (field === 'type' && p.inferredReason) next.inferredReason = undefined;
        return next;
      })
    );

  // ── Publish handler ──────────────────────────────────────────────────────

  const handlePublish = async () => {
    setError('');
    setPublishing(true);
    try {
      const validParams = paramDefs
        .filter(p => p.name.trim())
        .map(p => ({
          name: p.name.trim(),
          type: p.type,
          required: p.required,
          default: (p.default ?? '').trim() || undefined,
          description: p.description.trim() || undefined,
        }));

      const allowedAdGroups = allowedAdGroupsInput
        .split(',')
        .map(g => g.trim())
        .filter(g => g.length > 0);

      // Phase 132.37 — emit explicit WHERE mapping so the backend can
      // merge static rows into query_config.filters and dynamic columns
      // into allowed_filters.  Skip empty (no column) and is_null /
      // is_not_null rows have a null value by design.
      const validWhereClauses = whereClauses
        .filter(w => (w.column || '').trim())
        .map(w => {
          const op = (w.operator || 'eq');
          const opSpec = OPERATORS.find(o => o.value === op);
          const takesValue = opSpec?.takesValue !== false;
          let value: any = takesValue ? w.value : null;
          if (opSpec?.takesList && !Array.isArray(value)) {
            value = typeof value === 'string' && value
              ? value.split(',').map(s => s.trim()).filter(Boolean)
              : (value ? [value] : []);
          }
          return { column: w.column.trim(), operator: op, value, mode: w.mode };
        });

      // Phase 91/93: branch on source type
      const commonFields = {
        slug,
        name,
        description: description || undefined,
        allowed_filters: allowedFilters,
        default_limit: defaultLimit,
        max_limit: maxLimit,
        cache_ttl_seconds: cacheTtl,
        param_definitions: validParams,
        allowed_ad_groups: allowedAdGroups,
        // BF-430A — only send when set so backend keeps NULL semantics
        // (NULL = use snapshotted query_config / global s3_readers config).
        ...(readerOverride ? { reader_override: readerOverride } : {}),
        // Phase 132.37 — only send when the publisher actually mapped
        // any rows; empty array would clobber a prior categorisation on
        // republish.
        ...(validWhereClauses.length > 0 ? { where_clauses: validWhereClauses } : {}),
        // Phase 133-J — publisher-time credential routing.  Always send
        // the mode so the backend stores the publisher's explicit pick
        // (default 'publisher' in the UI = delegated trust, no consumer
        // prompt).  execution_connection_id is omitted when blank so the
        // backend keeps the legacy "inherit from query_config" path.
        credential_mode: credentialMode,
        ...(executionConnectionId !== '' ? { execution_connection_id: Number(executionConnectionId) } : {}),
      };
      let publishBody: Parameters<typeof api.publishView>[0];
      if (sourceType === 'business_report') {
        publishBody = { ...commonFields, source_type: 'business_report', business_report_id: businessReportId };
      } else if (sourceType === 'federation') {
        publishBody = { ...commonFields, source_type: 'federation', federation_view_id: federationViewId } as any;
      } else if (sourceType === 'sql_file') {
        // Backend accepts ``source_type: 'sql_file'`` + ``sql_file_id``
        // (see api/published_views/management.py publish_view).  The
        // backend reads the .sql content + connection_id from the
        // SqlFile row at publish time — caller only supplies the id.
        publishBody = { ...commonFields, source_type: 'sql_file', sql_file_id: sqlFileId } as any;
      } else {
        publishBody = { ...commonFields, query_id: queryId };
      }
      const result = await api.publishView(publishBody);
      setPublished(true);
      setPublishedSlug(result.slug);
      setTestApiKey(result.test_api_key || '');
    } catch (err: any) {
      setError(err.message || 'Publish failed');
    } finally {
      setPublishing(false);
    }
  };

  const handleClose = () => {
    setPublished(false);
    setError('');
    setTestApiKey('');
    onClose();
  };

  const copyText = (text: string) => navigator.clipboard.writeText(text);

  // ── Published confirmation view ──────────────────────────────────────────

  if (published) {
    return (
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>View Created</DialogTitle>
        <DialogContent>
          <Alert severity="success" sx={{ mb: 2 }}>
            Your query is now available as an external API endpoint.
          </Alert>

          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>API Endpoint:</Typography>
          <TextField
            fullWidth size="small" value={apiUrl}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end">
                  <Button size="small" onClick={() => copyText(apiUrl)} startIcon={<CopyIcon />}>Copy</Button>
                </InputAdornment>
              ),
              sx: { fontFamily: 'monospace', fontSize: 12 },
            }}
            sx={{ mb: 2 }}
          />

          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Example:</Typography>
          <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, fontFamily: 'monospace', fontSize: 11, overflowX: 'auto' }}>
            {curlExample}
          </Box>

          {/* Phase 86 / 132.36: Parameters documentation section.
              Prefer bare-form (?name=value) — only falls back to
              bracketed form for reserved-name collisions. */}
          {paramDefs.filter(p => p.name.trim()).length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Parameters</Typography>
              <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1 }}>
                {paramDefs.filter(p => p.name.trim()).map(p => {
                  const needsBracket = RESERVED_PARAM_NAMES.has(p.name);
                  const url = needsBracket
                    ? `?param[${p.name}]=value`
                    : `?${p.name}=value`;
                  return (
                  <Box key={p.name} sx={{ mb: 0.5, fontFamily: 'monospace', fontSize: 12 }}>
                    <span style={{ color: '#1565c0' }}>{url}</span>
                    <span style={{ color: '#666', marginLeft: 8 }}>
                      ({p.type}, {p.required ? 'required' : 'optional'}
                      {p.default ? `, default: ${p.default}` : ''})
                      {p.description ? ` — ${p.description}` : ''}
                    </span>
                  </Box>
                  );
                })}
              </Box>
            </Box>
          )}

          {testApiKey && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Test API Key (30-day, 60 req/min):</Typography>
              <TextField
                fullWidth size="small" value={testApiKey}
                InputProps={{
                  readOnly: true,
                  endAdornment: (
                    <InputAdornment position="end">
                      <Button size="small" onClick={() => copyText(testApiKey)} startIcon={<CopyIcon />}>Copy</Button>
                    </InputAdornment>
                  ),
                  sx: { fontFamily: 'monospace', fontSize: 12 },
                }}
              />
              <Typography variant="caption" color="text.secondary">
                Copy now — this test key is shown only once. Request a permanent key from the Published Views page.
              </Typography>
            </Box>
          )}

          {!testApiKey && (
            <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
              Go to API Keys to create an access key, then use it in the X-API-Key header.
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button variant="contained" onClick={handleClose}>Done</Button>
        </DialogActions>
      </Dialog>
    );
  }

  // ── Form view ────────────────────────────────────────────────────────────

  return (
    // BF-487 (2026-05-27) — widened to "md" so WHERE-clause Autocomplete
    // popper (capped at min(600px, 90vw)) fits inside the dialog instead
    // of overflowing into the page.  "sm" (640px) was narrower than the
    // popper's max-width which made dropdown values appear to crash out
    // of the form on long column names + distinct-value lists.
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>Publish as API</DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {/* BF-492 — cross-connection awareness banner.  Surfaces when the
            saved query / sql_file carries secondary_connection_id (set
            by BQB's cross-connection toggle / CQB cross-source / sql_file
            multi-side).  Reassures the publisher that the multi-source
            shape WILL be preserved through publish — the execute path
            already handles it via the federation engine. */}
        {crossConnInfo && (
          <Alert severity="info" sx={{ mb: 2 }}>
            <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }}>
              Cross-connection query detected
            </Typography>
            <Typography variant="caption" sx={{ display: 'block' }}>
              This query joins data from connection #{crossConnInfo.primary ?? '?'}
              {' '}+ connection #{crossConnInfo.secondary}
              {' '}(combine: {crossConnInfo.combineMode}).  The consumer
              endpoint will route through the federation engine on every
              call — same RLS / cred-routing rules apply on both sides.
            </Typography>
          </Alert>
        )}

        {/* Phase 91: BR source info — no preview available */}
        {sourceType === 'business_report' && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Preview not available — data is fetched live from the business report at query time.
          </Alert>
        )}

        {sourceType === 'federation' && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Data is fetched live from the federation view at query time.
          </Alert>
        )}

        {/* Phase 85C-4: Data preview section (saved_query only) */}
        {queryId && sourceType === 'saved_query' && (
          <Box sx={{ mb: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
            <Box
              sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, py: 1, cursor: 'pointer', bgcolor: 'grey.50' }}
              onClick={() => setPreviewOpen(v => !v)}
            >
              <Typography variant="subtitle2" sx={{ fontSize: 13 }}>
                Preview Data (10 rows)
                {previewLoading && <CircularProgress size={12} sx={{ ml: 1 }} />}
                {previewRows.length > 0 && !previewLoading && (
                  <span style={{ color: '#4caf50', marginLeft: 8, fontWeight: 400, fontSize: 12 }}>
                    {previewRows.length} rows loaded
                  </span>
                )}
              </Typography>
              {previewOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
            </Box>
            <Collapse in={previewOpen}>
              <Box sx={{ px: 1.5, pb: 1.5, pt: 0.5 }}>
                {previewError && <Alert severity="warning" sx={{ mb: 1 }}>{previewError}</Alert>}
                {previewLoading && <Box sx={{ textAlign: 'center', py: 2 }}><CircularProgress size={20} /></Box>}
                {!previewLoading && previewRows.length > 0 && (
                  <Box sx={{ overflowX: 'auto' }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          {previewCols.map(col => (
                            <TableCell key={col} sx={{ fontWeight: 700, fontSize: 11, whiteSpace: 'nowrap' }}>{col}</TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {previewRows.map((row, idx) => (
                          <TableRow key={idx}>
                            {previewCols.map(col => (
                              <TableCell key={col} sx={{ fontSize: 11, whiteSpace: 'nowrap' }}>
                                {row[col] === null || row[col] === undefined
                                  ? <span style={{ color: '#aaa' }}>null</span>
                                  : String(row[col]).substring(0, 40)}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Box>
                )}
                {!previewLoading && !previewError && previewRows.length === 0 && (
                  <Typography variant="caption" color="text.secondary">No preview available</Typography>
                )}
              </Box>
            </Collapse>
          </Box>
        )}

        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Name" value={name} onChange={e => setName(e.target.value)}
            fullWidth size="small"
          />
          <TextField
            label="Slug (URL identifier)"
            value={slug}
            onChange={e => setSlug(e.target.value)}
            fullWidth size="small"
            helperText={`Endpoint: /api/v1/views/${slug}/data`}
          />
          <TextField
            label="Description" value={description}
            onChange={e => setDescription(e.target.value)}
            fullWidth size="small" multiline rows={2}
          />
          {/* ── Phase 132.37 — WHERE Clauses (Dynamic / Static) ────────
              Always shown for saved_query and sql_file sources so the
              publisher is forced to decide per column whether consumers
              can override it.  Partition columns are pre-seeded as
              Dynamic; the publisher can flip them, edit the value, or
              click "+ Add Mapping" to surface ANY column from the
              catalog as a Dynamic or Static filter. */}
          {(sourceType === 'saved_query' || sourceType === 'sql_file') && (
            <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 1.5 }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
                <Typography variant="subtitle2">
                  WHERE Clauses ({whereClauses.length})
                </Typography>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Tooltip title="Dynamic = consumer can override via URL (?column=value). Static = locked in at publish time.">
                    <Chip
                      size="small" variant="outlined"
                      label={
                        `${whereClauses.filter(w => w.mode === 'dynamic').length} dynamic · ` +
                        `${whereClauses.filter(w => w.mode === 'static').length} static`
                      }
                    />
                  </Tooltip>
                  <Button size="small" startIcon={<AddIcon />} onClick={addWhereClause}>
                    Add Mapping
                  </Button>
                </Stack>
              </Stack>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                Rows pre-populated from your saved query's WHERE clause +
                detected partition columns.  To make a row{' '}
                <strong>Dynamic</strong> (consumer overrides via{' '}
                <code>?column=value</code>), <strong>replace the value with{' '}
                <code>?</code></strong>.  Leave any other value to lock it
                <strong> Static</strong>.  (Or click the chip — it does
                the same thing.)
              </Typography>
              {whereClauses.length === 0 ? (
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                  No WHERE mappings yet. Click <strong>+ Add Mapping</strong> to
                  pick a column, choose an operator, and decide Dynamic vs Static.
                </Typography>
              ) : (
                whereClauses.map((w, idx) => {
                  const opSpec = OPERATORS.find(o => o.value === w.operator) || OPERATORS[0];
                  const colKey = (w.column || '').toLowerCase().replace(/^.*\./, '');
                  const knownValues = partitionValues[colKey] || [];
                  const valueLabel = `Value${opSpec.takesList ? 's' : ''}`;
                  return (
                    <Box key={idx}
                      sx={{ display: 'grid',
                            gridTemplateColumns: '2.2fr 1.6fr 2.6fr auto auto',
                            gap: 1, alignItems: 'center',
                            border: '1px solid', borderColor: 'divider',
                            borderRadius: 1, p: 1, mb: 1 }}>
                      <Autocomplete
                        size="small" freeSolo openOnFocus
                        options={columnOptions}
                        value={w.column}
                        // Phase 134-L — auto-resize popper so long
                        // qualified column names + value lists aren't
                        // clipped to the narrow grid cell width.  Same
                        // override the shared WhereClausesEditor + the
                        // DynamicWhereOverrideField use.
                        slotProps={{
                          popper: {
                            sx: {
                              width: 'auto !important',
                              minWidth: '100%',
                              maxWidth: 'min(600px, 90vw)',
                              '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                              '& .MuiAutocomplete-option': {
                                whiteSpace: 'normal',
                                wordBreak: 'break-word',
                              },
                            },
                          },
                        }}
                        onChange={(_, v) => {
                          const name = typeof v === 'string' ? v : (v?.name || '');
                          updateWhereField(idx, 'column', name);
                          // Phase 133-H — kick off lazy distinct-values
                          // fetch so the value picker becomes a dropdown
                          // instead of a plain textbox on the next render.
                          if (name) lazilyFetchDistinctValues(name);
                        }}
                        onInputChange={(_, v, reason) => {
                          if (reason === 'input') {
                            // Phase 133-I round 21 — pass syncAllowedFilters=false
                            // on per-keystroke typing so partial input ("r",
                            // "re", "reg"...) doesn't pollute allowedFilters.
                            // The final value (commit on dropdown pick OR
                            // blur) re-syncs via onChange below.
                            updateWhereField(idx, 'column', v, false);
                            if (v) lazilyFetchDistinctValues(v);
                          }
                        }}
                        onBlur={() => {
                          // Phase 133-I round 21 — commit allowedFilters sync
                          // when the field loses focus (user finished typing).
                          if (w.column) {
                            setWhereClauses(prev2 => {
                              setAllowedFilters(afPrev =>
                                syncAllowedFiltersAfterToggle(prev2, w.column, afPrev),
                              );
                              return prev2;
                            });
                          }
                        }}
                        getOptionLabel={o => typeof o === 'string' ? o : o.name}
                        groupBy={o => {
                          if (typeof o === 'string') return '';
                          // Phase 133-I round 21 — group by source table
                          // (matches CQB).  Partition columns sit in
                          // their own group at the top by lexical sort.
                          return o.isPartition ? '⚑ Partition columns' : (o.tableSource || 'Other');
                        }}
                        renderOption={(props, o) => {
                          const label = typeof o === 'string' ? o : o.name;
                          const type = typeof o === 'string' ? '' : (o.type || '');
                          const isPart = typeof o !== 'string' && o.isPartition;
                          return (
                            <li {...props} key={label} style={{ padding: '4px 12px' }}>
                              <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', gap: 1 }}>
                                {isPart && (
                                  <span style={{ fontSize: 11, color: '#1976d2', flexShrink: 0 }}>⚑</span>
                                )}
                                <Typography
                                  component="span"
                                  sx={{
                                    fontFamily: 'monospace',
                                    fontSize: 13,
                                    fontWeight: isPart ? 600 : 400,
                                    color: 'text.primary',
                                    flexGrow: 1,
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  }}
                                >
                                  {label}
                                </Typography>
                                {type && (
                                  <Typography
                                    component="span"
                                    sx={{
                                      fontSize: 10,
                                      color: 'text.secondary',
                                      fontStyle: 'italic',
                                      flexShrink: 0,
                                      ml: 'auto',
                                    }}
                                  >
                                    {type}
                                  </Typography>
                                )}
                              </Box>
                            </li>
                          );
                        }}
                        renderGroup={(p) => (
                          <li key={p.key}>
                            <Box sx={{
                              position: 'sticky', top: 0, zIndex: 1,
                              bgcolor: 'grey.100',
                              px: 1.5, py: 0.5,
                              fontSize: 11, fontWeight: 700,
                              color: 'text.secondary',
                              textTransform: 'uppercase',
                              letterSpacing: 0.5,
                              borderBottom: 1, borderColor: 'divider',
                            }}>
                              {p.group}
                            </Box>
                            <ul style={{ padding: 0, margin: 0 }}>{p.children}</ul>
                          </li>
                        )}
                        ListboxProps={{
                          sx: { maxHeight: 360, '& .MuiAutocomplete-option': { minHeight: 32 } },
                        }}
                        renderInput={p => (
                          <TextField {...p} label="Column" placeholder="Search columns…" />
                        )}
                      />
                      <Autocomplete
                        size="small" disableClearable openOnFocus
                        options={OPERATORS}
                        // Phase 134-L — same popper auto-resize.
                        slotProps={{
                          popper: {
                            sx: {
                              width: 'auto !important',
                              minWidth: '100%',
                              maxWidth: 'min(600px, 90vw)',
                              '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                              '& .MuiAutocomplete-option': {
                                whiteSpace: 'normal',
                                wordBreak: 'break-word',
                              },
                            },
                          },
                        }}
                        getOptionLabel={(o) => typeof o === 'string'
                          ? (OPERATORS.find(op => op.value === o)?.label || o)
                          : o.label}
                        isOptionEqualToValue={(opt, val) => {
                          const ov = typeof opt === 'string' ? opt : opt.value;
                          const vv = typeof val === 'string' ? val : val.value;
                          return ov === vv;
                        }}
                        value={OPERATORS.find(o => o.value === w.operator) || OPERATORS[0]}
                        onChange={(_, v) => {
                          if (!v) return;
                          const next = typeof v === 'string' ? v : v.value;
                          updateWhereField(idx, 'operator', next);
                        }}
                        renderInput={(p) => (
                          <TextField {...p} label="Operator" placeholder="Search operators…" />
                        )}
                      />
                      {opSpec.takesValue ? (
                        opSpec.takesList ? (
                          <Autocomplete
                            multiple freeSolo size="small" openOnFocus
                            options={knownValues}
                            // Phase 134-L — auto-resize popper.
                            slotProps={{
                              popper: {
                                sx: {
                                  width: 'auto !important',
                                  minWidth: '100%',
                                  maxWidth: 'min(600px, 90vw)',
                                  '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                  '& .MuiAutocomplete-option': {
                                    whiteSpace: 'normal',
                                    wordBreak: 'break-word',
                                  },
                                },
                              },
                            }}
                            value={Array.isArray(w.value) ? w.value.map(String) : (w.value ? [String(w.value)] : [])}
                            onChange={(_, v) => updateWhereField(idx, 'value', v)}
                            renderInput={p => (
                              <TextField {...p}
                                label={w.mode === 'dynamic' ? `${valueLabel} (?=Dynamic)` : valueLabel}
                                placeholder={w.mode === 'dynamic'
                                  ? `? — consumer supplies via ?${w.column || 'col'}=val`
                                  : (knownValues.length ? 'Pick / type (or ? for Dynamic)' : 'Type values, ? for Dynamic')} />
                            )}
                          />
                        ) : (
                          // Phase 133-H round 7 — always-Autocomplete
                          // (searchable dropdown) even when knownValues
                          // is empty.  No more plain textboxes.
                          // Phase 133-H round 10 — clarify what the
                          // value means based on mode: Static = locked
                          // value the API always applies; Dynamic =
                          // consumer supplies at call time via
                          // ?col=value (publisher's value is just an
                          // optional default surfaced in /docs).
                          <Autocomplete
                            size="small" freeSolo openOnFocus
                            options={knownValues}
                            // Phase 134-L — auto-resize popper.
                            slotProps={{
                              popper: {
                                sx: {
                                  width: 'auto !important',
                                  minWidth: '100%',
                                  maxWidth: 'min(600px, 90vw)',
                                  '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                  '& .MuiAutocomplete-option': {
                                    whiteSpace: 'normal',
                                    wordBreak: 'break-word',
                                  },
                                },
                              },
                            }}
                            value={w.value == null ? '' : String(w.value)}
                            onChange={(_, v) => updateWhereField(idx, 'value', v ?? '')}
                            onInputChange={(_, v, reason) => {
                              if (reason === 'input') updateWhereField(idx, 'value', v);
                            }}
                            renderInput={p => (
                              <TextField {...p}
                                label={w.mode === 'dynamic' ? `${valueLabel} (?=Dynamic)` : valueLabel}
                                placeholder={w.mode === 'dynamic'
                                  ? `? — consumer supplies via ?${w.column || 'col'}=val`
                                  : (knownValues.length > 0 ? 'Pick / type (or ? for Dynamic)' : 'Type a value, or ? for Dynamic')} />
                            )}
                          />
                        )
                      ) : (
                        <Typography variant="caption" color="text.secondary" sx={{ pl: 1 }}>
                          (no value — {opSpec.label})
                        </Typography>
                      )}
                      <Stack direction="row" spacing={0.5}>
                        <Chip
                          label="Dynamic"
                          size="small" clickable
                          color={w.mode === 'dynamic' ? 'primary' : 'default'}
                          variant={w.mode === 'dynamic' ? 'filled' : 'outlined'}
                          onClick={() => setWhereMode(idx, 'dynamic')}
                        />
                        <Chip
                          label="Static"
                          size="small" clickable
                          color={w.mode === 'static' ? 'default' : 'default'}
                          variant={w.mode === 'static' ? 'filled' : 'outlined'}
                          onClick={() => setWhereMode(idx, 'static')}
                        />
                      </Stack>
                      <IconButton size="small" color="error"
                        onClick={() => removeWhereClause(idx)}
                        aria-label="Remove WHERE mapping">
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  );
                })
              )}
              {/* URL preview for Dynamic rows.
                  Phase 133-I round 23 — column name in the URL is the
                  BARE name (qualifier stripped) since the consumer
                  passes ``?col=value`` not ``?table.col=value`` —
                  matches the backend filter resolver's bare-key lookup
                  + the auto-paramDef generator's qualifier-strip.
                  Placeholder is ``<value>`` (clearer than ``value``)
                  and respects the publisher's typed default when set.
              */}
              {whereClauses.some(w => w.mode === 'dynamic' && (w.column || '').trim()) && (
                <Box sx={{ mt: 1.5, p: 1, bgcolor: 'grey.50', borderRadius: 1, fontFamily: 'monospace', fontSize: 11 }}>
                  <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: 'text.secondary', fontFamily: 'inherit' }}>
                    Consumer URL preview:
                  </Typography>
                  {`/api/v1/views/${slug}/data?` + whereClauses
                    .filter(w => w.mode === 'dynamic' && (w.column || '').trim())
                    .map(w => {
                      const bareCol = w.column.includes('.')
                        ? w.column.substring(w.column.lastIndexOf('.') + 1)
                        : w.column;
                      const isQ = w.value === '?' || (Array.isArray(w.value) && w.value.every(v => String(v) === '?'));
                      if (Array.isArray(w.value) && w.value.length && !isQ) {
                        return `${bareCol}=` + w.value.map(v => encodeURIComponent(String(v))).join(',');
                      }
                      if (isQ || !w.value) {
                        return `${bareCol}=<value>`;
                      }
                      return `${bareCol}=${encodeURIComponent(String(w.value))}`;
                    })
                    .join('&')}
                </Box>
              )}
            </Box>
          )}

          <Autocomplete
            multiple freeSolo size="small" openOnFocus
            // Phase 133-H round 15 — share columnOptions with the WHERE
            // editor so this advanced field has the same dropdown
            // (bare + table-qualified + alias-qualified entries).  Was
            // using the raw ``columns`` prop which gave only the
            // BQB-selected list, missing alias-qualified forms.
            options={columnOptions.map(o => o.name)}
            // Phase 134-L — auto-resize popper.
            slotProps={{
              popper: {
                sx: {
                  width: 'auto !important',
                  minWidth: '100%',
                  maxWidth: 'min(600px, 90vw)',
                  '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                  '& .MuiAutocomplete-option': {
                    whiteSpace: 'normal',
                    wordBreak: 'break-word',
                  },
                },
              },
            }}
            value={allowedFilters}
            onChange={(_, v) => setAllowedFilters(v)}
            renderInput={params => (
              <TextField {...params} label="Allowed Filter Columns (advanced)"
                placeholder="Additional ad-hoc columns consumers can filter on"
                helperText="Auto-populated from Dynamic WHERE rows above; add extra ad-hoc filter columns here." />
            )}
          />
          <Stack direction="row" spacing={2}>
            <TextField
              label="Default Limit" type="number" value={defaultLimit}
              onChange={e => setDefaultLimit(Number(e.target.value))}
              size="small" sx={{ flex: 1 }}
            />
            <TextField
              label="Max Limit" type="number" value={maxLimit}
              onChange={e => setMaxLimit(Number(e.target.value))}
              size="small" sx={{ flex: 1 }}
            />
          </Stack>
          <TextField
            label="Cache TTL (seconds)" type="number" value={cacheTtl}
            onChange={e => setCacheTtl(Number(e.target.value))}
            size="small" helperText="0 = always fresh, 300 = 5 min cache"
          />
          <TextField
            label="Allowed AD Groups (optional)"
            value={allowedAdGroupsInput}
            onChange={e => setAllowedAdGroupsInput(e.target.value)}
            fullWidth size="small"
            placeholder="grp-analytics, grp-risk-team"
            helperText="Comma-separated LDAP group names. Leave empty to allow all authenticated AD users. API key access is always separate."
          />

          {/* Phase 133-J — Connection & credential routing.  Answers two
              questions at publish time so consumer (curl) calls
              auto-resolve and never face a credential prompt:
                (1) which connection should consumer requests run against
                (2) whose credentials should resolve at runtime          */}
          <Divider sx={{ my: 1 }} />
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              Execution Connection & Credentials
            </Typography>
            <Stack spacing={1.5}>
              <FormControl fullWidth size="small">
                <InputLabel id="exec-conn-label">Execution Connection</InputLabel>
                <Select
                  labelId="exec-conn-label"
                  label="Execution Connection"
                  value={executionConnectionId === '' ? '' : String(executionConnectionId)}
                  onChange={e => {
                    const v = e.target.value;
                    setExecutionConnectionId(v === '' ? '' : Number(v));
                  }}
                >
                  <MenuItem value="">
                    <em>Inherit from saved query / file (default)</em>
                  </MenuItem>
                  {availableConnections.map(c => (
                    <MenuItem key={c.id} value={String(c.id)}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Typography variant="body2">{c.name}</Typography>
                        <Chip size="small" label={c.connection_type} variant="outlined" />
                        {c.is_shared && (
                          <Chip size="small" label="shared" color="info" variant="outlined" />
                        )}
                      </Stack>
                    </MenuItem>
                  ))}
                </Select>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, ml: 1.5 }}>
                  Override the connection consumers run against (e.g. point at
                  a shared system-account connection). Leave blank to use the
                  source's own connection.
                </Typography>
              </FormControl>

              <FormControl>
                <FormLabel sx={{ fontSize: '0.85rem' }}>Credential Mode</FormLabel>
                <RadioGroup
                  value={credentialMode}
                  onChange={e => setCredentialMode(e.target.value as any)}
                >
                  <FormControlLabel
                    value="publisher"
                    control={<Radio size="small" />}
                    label={
                      <Box>
                        <Typography variant="body2">Use my credentials</Typography>
                        <Typography variant="caption" color="text.secondary" component="div">
                          Consumers run under your stored credentials. No prompt;
                          you delegate access.
                        </Typography>
                        <Typography variant="caption" color="warning.main" component="div">
                          Note: your portal password is held in an 8-hour
                          in-memory vault and wiped on pod restart. For
                          set-and-forget APIs prefer "shared credentials".
                        </Typography>
                      </Box>
                    }
                  />
                  <FormControlLabel
                    value="shared"
                    control={<Radio size="small" />}
                    label={
                      <Box>
                        <Typography variant="body2">
                          Use connection's shared credentials (recommended for set-and-forget)
                        </Typography>
                        <Typography variant="caption" color="text.secondary" component="div">
                          Uses the connection's system account.  Survives pod
                          restarts and works indefinitely.  The chosen
                          connection must have a system account attached or
                          publish will fail with a clear error.
                        </Typography>
                      </Box>
                    }
                  />
                  <FormControlLabel
                    value="consumer"
                    control={<Radio size="small" />}
                    label={
                      <Box>
                        <Typography variant="body2">Require consumer credentials</Typography>
                        <Typography variant="caption" color="text.secondary">
                          Each caller must have their own portal password
                          stored. Curl callers will hit 401 if their vault is
                          empty.
                        </Typography>
                      </Box>
                    }
                  />
                </RadioGroup>
              </FormControl>
            </Stack>
          </Box>

          {/* BF-430A — per-PV S3 reader override.  Reader list comes from
              the live registry so a future reader doesn't need a frontend
              rebuild.  Empty (default) = use the snapshotted query_config
              / global s3_readers config. */}
          <FormControl fullWidth size="small">
            <InputLabel id="reader-override-label">S3 Reader Override (optional)</InputLabel>
            <Select
              labelId="reader-override-label"
              label="S3 Reader Override (optional)"
              value={readerOverride}
              onChange={e => setReaderOverride(String(e.target.value || ''))}
            >
              <MenuItem value="">
                <em>Use default (auto-route)</em>
              </MenuItem>
              {availableReaders.map(r => (
                <MenuItem key={r.name} value={r.name}>
                  <Box>
                    <Typography variant="body2">{r.label}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {r.description}
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
            </Select>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, ml: 1.5 }}>
              Force a specific S3 reader for this view's runtime requests.
              Default routes via the global cost-based router (recommended).
            </Typography>
          </FormControl>

          {/* ── Runtime Parameters (Phase 80/86) ─────────────────────────── */}
          <Divider />
          <Box>
            <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
              <Typography variant="subtitle2">Runtime Parameters</Typography>
              <Stack direction="row" spacing={1}>
                {/* Phase 133-I round 32 — Detect Partitions button fires
                    the right callback based on source.  Was gated on
                    queryId only; sql_file users couldn't trigger detection. */}
                {(queryId || sqlFileId) && (
                  <Button
                    size="small"
                    startIcon={partitionDetecting ? <CircularProgress size={14} /> : <AutoDetectIcon />}
                    onClick={queryId ? detectPartitionColumns : detectPartitionColumnsFromSqlFile}
                    disabled={partitionDetecting}
                  >
                    {partitionDetecting ? 'Detecting...' : 'Detect Partitions'}
                  </Button>
                )}
                <Button size="small" startIcon={<AddIcon />} onClick={addParam}>
                  Add Parameter
                </Button>
              </Stack>
            </Stack>

            {autoPopulatedParams && paramDefs.length > 0 && (
              <Alert severity="info" sx={{ mb: 1, py: 0.5 }}>
                Partition columns auto-detected as required parameters ({paramDefs.length} found).
                Add more or remove as needed.
              </Alert>
            )}

            {partitionWarnings.length > 0 && (
              <Alert severity="warning" sx={{ mb: 1, py: 0.5, fontSize: 12 }}>
                {partitionWarnings.map((w, i) => <div key={i}>{w}</div>)}
              </Alert>
            )}

            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              Declare parameters API consumers pass as <code>?name=value</code>
              {' '}— bracketed <code>?param[name]=value</code> is only required
              when the name collides with a reserved key
              (<code>limit</code>, <code>offset</code>, <code>sort</code>,
              <code>columns</code>, <code>format</code>, <code>cache</code>).
              Use {'{{name}}'} placeholders in your query filters or SQL to reference them.
            </Typography>

            {/* Available columns reference — click to add as parameter */}
            {/* BF-268: full column catalogue grouped by source table.
                Falls back to selected-only list when catalog isn't ready. */}
            {columnCatalogLoading && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <CircularProgress size={14} />
                <Typography variant="caption" color="text.secondary">
                  Loading all columns from underlying tables…
                </Typography>
              </Box>
            )}
            {columnCatalog.length > 0 ? (
              <Box sx={{ mb: 1.5 }}>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                  Pick any column to add as a parameter (type auto-detected from schema):
                </Typography>
                {columnCatalog.map(group => (
                  <Box key={group.table} sx={{ mb: 1 }}>
                    <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.primary', display: 'block', mb: 0.4 }}>
                      {group.table}
                      <span style={{ color: '#888', fontWeight: 400, marginLeft: 8 }}>
                        {group.columns.length} column{group.columns.length === 1 ? '' : 's'}
                      </span>
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {group.columns.map(col => {
                        const alreadyAdded = paramDefs.some(p => p.name === col.name);
                        const isPartition = Object.values(partitionColumns).some(cols => cols.includes(col.name));
                        const paramType = _mapColumnType(col.type);
                        return (
                          <Tooltip
                            key={col.name}
                            title={
                              alreadyAdded
                                ? 'Already added'
                                : `${col.type} → param type: ${paramType}${isPartition ? ' (partition column)' : ''}`
                            }
                          >
                            <Chip
                              label={`${col.name}: ${paramType}`}
                              size="small"
                              variant={alreadyAdded ? 'filled' : 'outlined'}
                              color={isPartition ? 'primary' : 'default'}
                              onClick={alreadyAdded ? undefined : () => addParamFromColumn(col.name, col.type)}
                              disabled={alreadyAdded}
                              sx={{
                                fontSize: 11,
                                height: 24,
                                cursor: alreadyAdded ? 'default' : 'pointer',
                                ...(isPartition && !alreadyAdded ? { borderWidth: 2 } : {}),
                              }}
                            />
                          </Tooltip>
                        );
                      })}
                    </Box>
                  </Box>
                ))}
              </Box>
            ) : availableColumns.length > 0 && (
              <Box sx={{ mb: 1.5 }}>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                  Available columns (click to add as parameter):
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {availableColumns.map(col => {
                    const alreadyAdded = paramDefs.some(p => p.name === col);
                    const isPartition = Object.values(partitionColumns).some(cols => cols.includes(col));
                    return (
                      <Tooltip
                        key={col}
                        title={alreadyAdded ? 'Already added' : isPartition ? 'Partition column — click to add' : 'Click to add as parameter'}
                      >
                        <Chip
                          label={col}
                          size="small"
                          variant={alreadyAdded ? 'filled' : 'outlined'}
                          color={isPartition ? 'primary' : 'default'}
                          onClick={alreadyAdded ? undefined : () => addParamFromColumn(col)}
                          disabled={alreadyAdded}
                          sx={{
                            fontSize: 11,
                            height: 24,
                            cursor: alreadyAdded ? 'default' : 'pointer',
                            ...(isPartition && !alreadyAdded ? { borderWidth: 2 } : {}),
                          }}
                        />
                      </Tooltip>
                    );
                  })}
                </Box>
              </Box>
            )}

            {paramDefs.map((p, idx) => (
              <Box
                key={idx}
                sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 1.5, mb: 1 }}
              >
                <Stack direction="row" spacing={1} alignItems="flex-start" flexWrap="wrap">
                  {/* Phase 133-H round 16 — Name is a searchable
                      Autocomplete sourced from the same columnOptions
                      as the WHERE editor.  Publisher picks a column,
                      partition badge shown if applicable.  freeSolo so
                      they can still type a custom param name (not all
                      params correspond to columns). */}
                  <Autocomplete
                    size="small" freeSolo openOnFocus
                    options={columnOptions}
                    value={p.name}
                    onChange={(_, v) => {
                      const name = typeof v === 'string' ? v : (v?.name || '');
                      updateParam(idx, 'name', name);
                    }}
                    onInputChange={(_, v, reason) => {
                      if (reason === 'input') updateParam(idx, 'name', v);
                    }}
                    getOptionLabel={(o) => typeof o === 'string' ? o : o.name}
                    groupBy={(o) => {
                      if (typeof o === 'string') return '';
                      return o.isPartition ? '⚑ Partition columns' : (o.tableSource || 'Other');
                    }}
                    renderOption={(propsRow, o) => {
                      const label = typeof o === 'string' ? o : o.name;
                      const type = typeof o === 'string' ? '' : (o.type || '');
                      const isPart = typeof o !== 'string' && o.isPartition;
                      return (
                        <li {...propsRow} key={label} style={{ padding: '4px 12px' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', gap: 1 }}>
                            {isPart && (
                              <span style={{ fontSize: 11, color: '#1976d2', flexShrink: 0 }}>⚑</span>
                            )}
                            <Typography component="span" sx={{
                              fontFamily: 'monospace', fontSize: 13,
                              fontWeight: isPart ? 600 : 400,
                              color: 'text.primary', flexGrow: 1,
                              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                            }}>
                              {label}
                            </Typography>
                            {type && (
                              <Typography component="span" sx={{
                                fontSize: 10, color: 'text.secondary',
                                fontStyle: 'italic', flexShrink: 0, ml: 'auto',
                              }}>
                                {type}
                              </Typography>
                            )}
                          </Box>
                        </li>
                      );
                    }}
                    renderGroup={(rp) => (
                      <li key={rp.key}>
                        <Box sx={{
                          position: 'sticky', top: 0, zIndex: 1,
                          bgcolor: 'grey.100', px: 1.5, py: 0.5,
                          fontSize: 11, fontWeight: 700,
                          color: 'text.secondary', textTransform: 'uppercase',
                          letterSpacing: 0.5,
                          borderBottom: 1, borderColor: 'divider',
                        }}>
                          {rp.group}
                        </Box>
                        <ul style={{ padding: 0, margin: 0 }}>{rp.children}</ul>
                      </li>
                    )}
                    ListboxProps={{
                      sx: { maxHeight: 360, '& .MuiAutocomplete-option': { minHeight: 32 } },
                    }}
                    // BF-487 — auto-resize popper so long qualified column
                    // names aren't clipped to this narrow grid-cell width.
                    slotProps={{
                      popper: {
                        sx: {
                          width: 'auto !important',
                          minWidth: '100%',
                          maxWidth: 'min(600px, 90vw)',
                          '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                          '& .MuiAutocomplete-option': {
                            whiteSpace: 'normal',
                            wordBreak: 'break-word',
                          },
                        },
                      },
                    }}
                    sx={{ flex: '1 1 120px' }}
                    renderInput={(rp) => (
                      <TextField {...rp} label="Name" placeholder="Search columns…"
                        helperText="Pick a column or type a custom name" />
                    )}
                  />
                  <Box sx={{ flex: '1 1 100px', display: 'flex', flexDirection: 'column' }}>
                    {/* Phase 133-H round 16 — Type field upgraded to
                        searchable Autocomplete for UX consistency
                        with the rest of the dialog. */}
                    <Autocomplete
                      size="small" disableClearable openOnFocus
                      options={[...PARAM_TYPES]}
                      value={p.type}
                      onChange={(_, v) => v && updateParam(idx, 'type', v)}
                      // BF-487 — popper override (see Name field above).
                      slotProps={{
                        popper: {
                          sx: {
                            width: 'auto !important',
                            minWidth: '100%',
                            maxWidth: 'min(600px, 90vw)',
                            '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                          },
                        },
                      }}
                      renderInput={(rp) => (
                        <TextField {...rp} label="Type" placeholder="Search types…" />
                      )}
                    />
                    {p.inferredReason && (
                      <Tooltip title={`Auto-inferred: ${p.inferredReason}. You can override.`} placement="bottom-start">
                        <Typography
                          variant="caption"
                          color="text.secondary"
                          sx={{ fontSize: 10, mt: 0.25, lineHeight: 1.2, cursor: 'help' }}
                        >
                          auto: {p.inferredReason}
                        </Typography>
                      </Tooltip>
                    )}
                  </Box>
                  {/* Phase 133-H round 8 — default value is a searchable
                      dropdown sourced from partitionValues (same cache
                      the WHERE editor uses).  freeSolo so the publisher
                      can still type a custom default. */}
                  <Autocomplete
                    size="small" freeSolo openOnFocus
                    options={partitionValues[(p.name || '').toLowerCase()] || []}
                    value={p.default ?? ''}
                    onChange={(_, v) => updateParam(idx, 'default', v ?? '')}
                    onInputChange={(_, v, reason) => {
                      if (reason === 'input') updateParam(idx, 'default', v);
                    }}
                    // BF-487 — popper override so long distinct values
                    // (e.g. timestamp partitions) don't clip to this
                    // narrow grid-cell width.
                    slotProps={{
                      popper: {
                        sx: {
                          width: 'auto !important',
                          minWidth: '100%',
                          maxWidth: 'min(600px, 90vw)',
                          '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                          '& .MuiAutocomplete-option': {
                            whiteSpace: 'normal',
                            wordBreak: 'break-word',
                          },
                        },
                      },
                    }}
                    sx={{ flex: '1 1 100px' }}
                    renderInput={(rp) => (
                      <TextField {...rp} label="Default" placeholder="optional" />
                    )}
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        size="small"
                        checked={p.required}
                        onChange={e => updateParam(idx, 'required', e.target.checked)}
                      />
                    }
                    label="Required"
                    sx={{ alignSelf: 'center', m: 0 }}
                  />
                  <IconButton
                    size="small"
                    color="error"
                    onClick={() => removeParam(idx)}
                    sx={{ alignSelf: 'center' }}
                    aria-label="Remove parameter"
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Stack>
                <TextField
                  label="Description" size="small" value={p.description}
                  onChange={e => updateParam(idx, 'description', e.target.value)}
                  fullWidth sx={{ mt: 1 }}
                  placeholder="Optional description for API consumers"
                />
              </Box>
            ))}

            {paramDefs.length === 0 && !partitionDetecting && (
              <Typography variant="caption" color="text.secondary">
                No parameters defined. Partition columns are auto-detected — click "Add Parameter" to add custom ones.
              </Typography>
            )}
            {partitionDetecting && (
              <Box sx={{ textAlign: 'center', py: 1 }}>
                <CircularProgress size={16} />
                <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                  Detecting partition columns...
                </Typography>
              </Box>
            )}
          </Box>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          onClick={handlePublish}
          disabled={publishing || !slug.trim() || !name.trim()}
        >
          {publishing ? 'Creating...' : 'Create View'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PublishViewDialog;
