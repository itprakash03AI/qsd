/**
 * GlobalAssistantPanel — unified pattern-based assistant (no LLM).
 *
 * Intents (auto-detected from input):
 *   nl2sql   — natural-language → SQL generation (11 patterns, backend)
 *   analyze  — SQL anti-pattern / lint analysis
 *   schema   — column list for a table (schema cache + usage stats)
 *   data     — last execution result schema + row count
 *   tables   — most-used tables ranking
 *   help     — built-in feature guide
 *
 * Context-aware: reads AssistantContext so pages can register their current
 * connection/tables — improves NL→SQL when schema is known.
 *
 * "Use this SQL" stores SQL in sessionStorage → SqlQueryPage / QueryBuilder
 * reads it on mount.
 */
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Box, Typography, TextField, IconButton, Paper, Chip, Stack, Divider,
  Alert, CircularProgress, Tooltip, Button,
} from '@mui/material';
import {
  Send as SendIcon,
  ContentCopy as CopyIcon,
  PlayArrow as UseIcon,
  AutoAwesome as MagicIcon,
  LightbulbOutlined as TipIcon,
  TableChart as TableIcon,
  Terminal as SqlIcon,
  BugReport as AnalyzeIcon,
  HelpOutline as HelpIcon,
  Schema as SchemaIcon,
  DataObject as DataIcon,
  MenuBook as DocsIcon,
  GridOn as GridIcon,
  ThumbUp as ThumbUpIcon,
  ThumbDown as ThumbDownIcon,
  BarChart as BarChartIcon,
  School as SchoolIcon,
  AutoFixHigh as AiIcon,
  FlashOn as FlashIcon,
  Storage as StorageIcon,
  AccountTree as LineageIcon,
  PivotTableChart as PivotIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useServerDraft } from '../hooks/useServerDraft';
import { useAssistantContext } from '../context/AssistantContext';
import { useAuth } from '../context/AuthContext';
import { isNumericCol, isCategoryCol, isDateCol, isIdCol, fetchChatbotPatterns, findFaqAnswer, getGlossary } from '../config/columnPatterns';
import { classifyColumns, generateChartPresets, generatePivotPresets, reorderPresets, chartPresetKey, pivotPresetKey, ChartPreset, PivotPreset } from '../services/columnIntelligence';

// ── Types ─────────────────────────────────────────────────────────────────────

type IntentKind = 'nl2sql' | 'analyze' | 'schema' | 'data' | 'tables' | 'help' | 'greet' | 'docs' | 'griddata' | 'chart' | 'pivot' | 'faq' | 'glossary' | 'tour';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  intent?: IntentKind;
  // NL→SQL
  sql?: string;
  confidence?: number;
  pattern?: string;
  explanation?: string;
  alternatives?: string[];
  warnings?: string[];
  // Analysis
  analysisWarnings?: any[];
  // Schema / data
  schemaResult?: any;
  dataResult?: any;
  // Docs
  docsResults?: any[];
  // Tables
  tables?: any[];
  // Grid data query
  gridResult?: any;
  // Inline chart
  chartConfig?: { type: 'bar' | 'line' | 'pie'; xKey: string; yKey: string; data: any[]; title: string };
  // Feedback state for nl2sql messages
  feedbackGiven?: 1 | -1 | null;
  // Phase 84C: learning engine fields
  nlHistoryId?: number | null;
  nlSource?: 'regex_pattern' | 'learned' | 'local_llm' | string;
  nlSimilarity?: number | null;
  nlSuggestions?: Array<{ nl_query: string; sql: string; similarity: number }>;
  // Phase 57 — semantic mode
  semanticMode?: boolean;
  datasetName?: string;
  semanticRewrites?: string[];
  // Phase 77 — smart predictions
  chartSuggestions?: any[];
  pivotSuggestions?: any[];
  dataProfile?: any;
  // Chart/pivot suggestion feedback (per-preset index → rating)
  chartFeedback?: Record<number, 1 | -1>;
  pivotFeedback?: Record<number, 1 | -1>;
}

// ── Intent detection ──────────────────────────────────────────────────────────

// SQL_KEYWORDS: only words that are unambiguously SQL (not common English).
// Removed: 'where' ("where is my data?"), 'from' ("from what I know..."),
//          'update' ("update me on..."), 'delete' ("delete this query")
const SQL_KEYWORDS     = /\b(select|join|group\s+by|order\s+by|having|insert|create|drop|with\s+\w+\s+as)\b/i;
// Only match clear SQL-analysis requests — avoid broad phrases like "why" which are better served by docs
const ANALYZE_TRIGGERS = /^(analyze|check|review|lint|validate|fix)\b/i;
const TABLE_TRIGGERS   = /\b(what table|which table|show table|top table|list table|available table|suggest table|find table|tables? (for|in|about|to use))\b/i;
// "describe" without data-context words (those go to griddata)
const SCHEMA_TRIGGERS  = /\b(what columns?|describe(?!\s+(this|the|my|current|these)?\s*(data|result|grid|dataset|rows?))|schema of|columns? (in|of|for)|fields? (in|of|for)|structure of|tell me about table)\b/i;
const DATA_TRIGGERS    = /\b(last result|last query result|my last (result|query)|recent result|summarize result|result summary|what.s in (my )?(last|recent) (result|data))\b/i;
// "overview" removed — handled better by griddata when a result is loaded
const HELP_TRIGGERS    = /^(help|\?|what can you do|capabilities|features|how (do|can) (i|you)|commands|examples|faq|about|what is querystudio)[?!.\s]*$/i;
const TOUR_TRIGGERS    = /^(tour|guided tour|start tour|walkthrough|get started|how do i get started|onboarding|show me around)[?!.\s]*$/i;
const GREET_TRIGGERS   = /^(hi|hello|hey|howdy|hola|good (morning|afternoon|evening)|what.?s up|sup|yo|greetings|morning|evening|afternoon)[\s!?.]*$/i;
const DOCS_TRIGGERS      = /^(how (do|can|to)|what (is|are|does)|explain|tell me (about|how)|show me how|what.?s the|how does|can i|does it support|is there|walk me through|guide|tutorial|document)/i;
const GRIDDATA_TRIGGERS  = /\b(max(imum)?|min(imum)?|avg|average|mean|median|sum|total|count\s*(where|by)?|group\s*by|aggregate(\s+by)?|roll\s*up|top\s+\d+|bottom\s+\d+|distinct(\s+values?)?|first\s+\d+|rows?\s+where|filter|show\s+where|trend(ing)?|over\s+time|monthly|weekly|daily|yearly|quarterly|by\s+(month|week|day|year|quarter)|growth|time\s+series|summar(y|ize|ise)?|overview|describe\s+(this|the|my|current)?\s*(data|result|grid|dataset|rows?)|profile|insights?|outlier|anomal|unusual|extreme\s+values?|spike|dip|pivot|cross\s*tab|crosstab|null(s|\s+values?)?|missing|duplicat|unique\s+count|percent(ile)?|cumulative|running\s+total|frequency|distribut|correlat|ratio|sort\s+by|rank(ing)?|sample|random\s+rows?|most\s+common|variance|std\s+dev|standard\s+deviation|ytd|mtd|qtd|this\s+month|this\s+year|this\s+quarter|last\s+month|last\s+quarter|last\s+7\s+days?|last\s+30\s+days?|last\s+90\s+days?|year[\s-]to[\s-]date|month[\s-]to[\s-]date)\b/i;
const CHART_TRIGGERS     = /\b(chart|plot|graph|visuali[sz]e?|bar\s+chart|line\s+chart|area\s+chart|pie\s+chart|scatter(\s+chart)?|histogram|suggest\s+(a\s+)?(chart|graph|viz)|show\s+(me\s+)?(a\s+)?(chart|graph)|render\s+(a\s+)?(chart|graph))\b/i;
const PIVOT_TRIGGERS     = /\b(pivot|crosstab|cross[\s-]tab|pivot\s+table|pivot\s+by|suggest\s+pivot)\b/i;
const PROFILE_TRIGGERS   = /\b(describe\s+(this\s+)?(data|result)|profile|data\s+quality|outlier|insight|overview|summarize\s+(this\s+)?(data|result)|whats?\s+interesting|column\s+stats?)\b/i;
const GLOSSARY_TRIGGERS  = /\b(glossary|business terms?|what terms?|terms? you know|what.* mean|vocab(ulary)?|data dictionary|list terms?|show terms?)\b/i;

function buildGreetReply(name?: string): string {
  const n = name && name !== 'guest' ? `, ${name.split(' ')[0]}` : '';
  const replies = [
    `Hey${n}! Ready to help with your data. Try 'top 10 orders by revenue' or 'columns in customers'.`,
    `Hi${n}! What data question can I answer for you today?`,
    `Hello${n}! I can generate SQL, browse your schema, or analyze queries — just ask.`,
    `Hey${n}! Great to see you. Ask me anything about your data or how to use QueryStudio.`,
    `Hi${n}! SQL, schema, analysis, how-to docs — I've got you covered.`,
  ];
  return replies[Math.floor(Math.random() * replies.length)];
}

function detectIntent(input: string, hasGrid = false): IntentKind {
  const q = input.trim();
  if (GREET_TRIGGERS.test(q))    return 'greet';
  if (TOUR_TRIGGERS.test(q))     return 'tour';
  if (HELP_TRIGGERS.test(q))     return 'help';
  if (GLOSSARY_TRIGGERS.test(q)) return 'glossary';
  // FAQ checked here so the user message label is consistent with the response
  if (findFaqAnswer(q))          return 'faq';
  if (DATA_TRIGGERS.test(q))     return 'data';
  if (TABLE_TRIGGERS.test(q))    return 'tables';
  // SQL_KEYWORDS only triggers analyze when input is not a natural-language docs question.
  // Common English words (where/from/update/delete) have been removed from SQL_KEYWORDS
  // so only unambiguous SQL syntax (select/join/group by/etc.) triggers this path.
  if (ANALYZE_TRIGGERS.test(q) || (SQL_KEYWORDS.test(q) && !DOCS_TRIGGERS.test(q))) return 'analyze';
  // When grid is loaded, pivot/chart/data queries take priority over schema lookup and docs
  if (hasGrid && PIVOT_TRIGGERS.test(q))    return 'pivot';
  if (hasGrid && CHART_TRIGGERS.test(q))    return 'chart';
  if (hasGrid && GRIDDATA_TRIGGERS.test(q)) return 'griddata';
  // Schema and docs only reached when no grid match (or no grid loaded)
  if (SCHEMA_TRIGGERS.test(q))  return 'schema';
  if (DOCS_TRIGGERS.test(q))    return 'docs';
  return 'nl2sql';
}

/** Extract table name from a schema question. */
function extractTableFromSchema(q: string): string {
  const patterns = [
    /(?:describe|schema of|structure of|tell me about table)\s+(\S+)/i,
    /(?:columns?|fields?)\s+(?:in|of|for)\s+(\S+)/i,
    /(?:what columns? (?:does|in|of))\s+(\S+)/i,
  ];
  for (const p of patterns) {
    const m = q.match(p);
    if (m) return m[1].replace(/[?.,;:!]$/, '');
  }
  // Last word fallback
  const words = q.trim().split(/\s+/);
  return words[words.length - 1].replace(/[?.,;:!]$/, '');
}

// ── Examples ──────────────────────────────────────────────────────────────────

// Static examples grouped by topic — shown in Browse Topics overlay
const GENERIC_EXAMPLES = [
  // Product / FAQ
  { label: 'what is QueryStudio?',                icon: <HelpIcon    sx={{ fontSize: 13 }} />, group: 'product' },
  { label: 'what features does QueryStudio have?',icon: <HelpIcon    sx={{ fontSize: 13 }} />, group: 'product' },
  { label: 'help',                                icon: <HelpIcon    sx={{ fontSize: 13 }} />, group: 'product' },
  { label: 'glossary',                            icon: <HelpIcon    sx={{ fontSize: 13 }} />, group: 'product' },
  // Data
  { label: 'what tables are available',           icon: <TableIcon   sx={{ fontSize: 13 }} />, group: 'data' },
  { label: 'last result',                         icon: <DataIcon    sx={{ fontSize: 13 }} />, group: 'data' },
  { label: 'columns in orders',                   icon: <SchemaIcon  sx={{ fontSize: 13 }} />, group: 'data' },
  { label: 'describe customers',                  icon: <SchemaIcon  sx={{ fontSize: 13 }} />, group: 'data' },
  // How-to
  { label: 'how do I execute a query?',           icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I schedule a query?',          icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I create a dashboard?',        icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I share a report?',            icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I export results?',            icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I add a connection?',          icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I create a materialized view?',icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how does lineage work?',              icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I use the query builder?',     icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I create a parametric report?',icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  { label: 'how do I set up alerts?',             icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'howto' },
  // Features
  { label: 'what is the circuit breaker?',        icon: <FlashIcon   sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'what is data lineage?',               icon: <LineageIcon sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'what is NL-to-SQL?',                  icon: <AiIcon      sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'what is anomaly detection?',          icon: <FlashIcon   sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'what is the query cache?',            icon: <StorageIcon sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'explain S3 connections',              icon: <StorageIcon sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'explain Snowflake connection',        icon: <StorageIcon sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'explain Arrow IPC',                   icon: <FlashIcon   sx={{ fontSize: 13 }} />, group: 'features' },
  { label: 'explain RBAC and permissions',        icon: <DocsIcon    sx={{ fontSize: 13 }} />, group: 'features' },
  // NL-to-SQL examples
  { label: 'top 10 customers by revenue',         icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'orders in the last 7 days',           icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'average order value by region',       icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'count of transactions per month',     icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'show all active accounts',            icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'max amount per account',              icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'distinct status values',              icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  { label: 'sum of sales by country',             icon: <SqlIcon     sx={{ fontSize: 13 }} />, group: 'nlsql' },
  // Technical / Learning
  { label: 'what is DuckDB?',                     icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
  { label: 'what is Parquet?',                    icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
  { label: 'what is Trino?',                      icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
  { label: 'what is Snowflake?',                  icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
  { label: 'explain S3 partitioning',             icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
  { label: 'SQL tips for S3 queries',             icon: <SchoolIcon  sx={{ fontSize: 13 }} />, group: 'tech' },
];

// ── Typeahead prompt suggestions ──────────────────────────────────────────────
// All prompts known to work — shown as typeahead suggestions while user types
const ALL_PROMPTS: string[] = [
  // Help / FAQ
  'help', 'what is QueryStudio?', 'what features does QueryStudio have?', 'faq', 'what can you do?',
  // How-to
  'how do I execute a query?', 'how do I schedule a query?', 'how do I create a dashboard?',
  'how do I share a report?', 'how do I export results?', 'how do I add a connection?',
  'how do I create a materialized view?', 'how do I create a parametric report?',
  'how do I use the query builder?', 'how does lineage work?', 'how do I set up alerts?',
  'how do I connect to S3?', 'how do I connect to Snowflake?',
  // Data / schema
  'what tables are available', 'show top tables', 'list tables',
  'last result', 'summarize last result', 'what is in my last result',
  'columns in orders', 'columns in customers', 'describe transactions',
  'schema of accounts', 'fields in invoices', 'what columns does orders have',
  // Features
  'what is the circuit breaker?', 'what is data lineage?', 'what is NL-to-SQL?',
  'what is anomaly detection?', 'what is the query cache?',
  'explain S3 connections', 'explain Snowflake connection', 'explain Trino connection',
  'explain Arrow IPC', 'explain RBAC and permissions',
  // NL-to-SQL
  'top 10 customers by revenue', 'top 5 orders by amount',
  'orders in the last 7 days', 'orders in the last 30 days',
  'average order value by region', 'count of transactions per month',
  'show all active accounts', 'show all records where status = pending',
  'max amount per account', 'distinct status values',
  'sum of sales by country', 'total revenue by product', 'monthly trend of sales',
  'records with null values in amount', 'duplicate rows by account id',
  // Grid data queries (need loaded result) — overview
  'summarize', 'describe this data', 'insights', 'overview',
  // Aggregation
  'top 10 by amount', 'bottom 10 by amount',
  'sum of revenue by category', 'average by status', 'count by type', 'median of amount',
  'sum of amount by status and type', 'total by country',
  // Trends & time
  'trend by month', 'by quarter', 'by week', 'by day of week',
  'running total by date', 'cumulative sum by month',
  'this month', 'last month', 'this year', 'ytd', 'mtd', 'this quarter', 'last quarter',
  'last 7 days', 'last 30 days', 'last 90 days',
  // Filter & search
  'filter status=active', 'rows where amount > 0', 'rows where amount > 1000',
  'filter id=', 'show records where status = pending',
  // Distribution & stats
  'distinct values in status', 'most common values in category',
  'frequency distribution of status', 'percentile 95 of amount',
  'correlation between amount and total', 'variance of amount', 'std dev of amount',
  // Pivot
  'pivot amount by status', 'pivot count by category', 'crosstab', 'pivot by month',
  // Data quality
  'show nulls in amount', 'rows with any null', 'count nulls per column',
  'duplicates in id', 'unique count per category', 'random sample 20 rows',
  'outliers in amount',
  // Charts (need loaded result)
  'bar chart of amount by status', 'line chart by month', 'pie chart by category',
  'area chart by date', 'scatter chart', 'suggest a chart', 'visualize this data',
  // Analyze SQL
  'analyze SELECT * FROM orders', 'check my query for issues',
  // Tech / learning
  'what is DuckDB?', 'what is Parquet?', 'what is Trino?', 'what is Snowflake?',
  'explain S3 partitioning', 'SQL tips for S3 queries',
];

/**
 * Build grid-aware example chips from real column names.
 *
 * Strategy:
 *  - Classify columns using the configurable patterns in src/config/columnPatterns.ts
 *  - Use real column names only when classification is confident
 *  - Fall back to safe, always-valid generic chips when no match
 *
 * To add support for your organisation's column naming conventions, edit:
 *   frontend/src/config/columnPatterns.ts
 */
function buildGridExamples(cols: string[]): Array<{ label: string; icon: React.ReactNode; group: string }> {
  if (!cols.length) return [];

  // Classify columns using the configurable patterns file
  const numCols  = cols.filter(c => isNumericCol(c));
  const catCols  = cols.filter(c => isCategoryCol(c));
  const dateCols = cols.filter(c => isDateCol(c));
  const idCols   = cols.filter(c => isIdCol(c));

  // Best picks — use real col name when we have high-confidence classification
  const num1    = numCols[0]  ?? null;   // null = no confident numeric found
  const num2    = numCols[1]  ?? null;
  const cat1    = catCols[0]  ?? null;   // null = no confident category found
  const cat2    = catCols[1]  ?? null;
  const date1   = dateCols[0] ?? null;
  const id1     = idCols[0]   ?? null;

  const hasDate    = !!date1;
  const hasTwoNums = numCols.length >= 2;

  // Helper — build a chip only when all required column picks are available
  const chip = (
    label: string,
    icon: React.ReactNode,
    group: string,
    ...requires: Array<string | null>
  ) => requires.every(r => r !== null) ? { label, icon, group } : null;

  const G = <GridIcon sx={{ fontSize: 13 }} />;
  const B = <BarChartIcon sx={{ fontSize: 13 }} />;
  const P = <PivotIcon sx={{ fontSize: 13 }} />;

  const candidates = [
    // ── Overview — valid for any result ───────────────────────────────────────
    { label: 'summarize',            icon: G, group: 'summary' },
    { label: 'describe this data',   icon: G, group: 'summary' },
    { label: 'profile this dataset', icon: G, group: 'summary' },

    // ── Aggregation — only when real numeric + category columns exist ──────────
    chip(`sum of ${num1} by ${cat1}`,             G, 'agg', num1, cat1),
    chip(`average ${num1} by ${cat1}`,            G, 'agg', num1, cat1),
    chip(`count by ${cat1}`,                      G, 'agg', cat1),
    chip(`total ${num1} per ${cat1}`,             G, 'agg', num1, cat1),
    chip(`median of ${num1}`,                     G, 'agg', num1),
    chip(`sum of ${num1} by ${cat1} and ${cat2}`, G, 'agg', num1, cat1, cat2),

    // ── Ranking — real numeric column required for column-specific chips ───────
    chip(`top 10 by ${num1}`,                    G, 'rank', num1),
    chip(`bottom 10 by ${num1}`,                 G, 'rank', num1),
    chip(`outliers in ${num1}`,                  G, 'rank', num1),

    // ── Filter — real column required ─────────────────────────────────────────
    chip(`rows where ${num1} > 0`,               G, 'filter', num1),
    chip(`filter ${id1}=`,                       G, 'filter', id1),
    { label: 'rows with any null',               icon: G, group: 'filter' },

    // ── Charts — only when real columns exist for meaningful visualisation ─────
    chip(`bar chart of ${num1} by ${cat1}`,      B, 'chart', num1, cat1),
    chip(`pie chart by ${cat1}`,                 B, 'chart', cat1),
    ...(hasDate ? [{ label: `line chart of ${num1 ?? 'values'} by month`, icon: B, group: 'chart' }] : []),
    ...(hasTwoNums ? [chip(`scatter ${num1} vs ${num2}`, B, 'chart', num1, num2)] : []),

    // ── Pivot — real numeric + category required ───────────────────────────────
    chip(`pivot ${num1} by ${cat1}`,             P, 'pivot', num1, cat1),

    // ── Trends — date column required, numeric preferred ──────────────────────
    ...(hasDate ? [
      chip(`trend of ${num1} by month`,            G, 'trend', num1),
      chip(`running total of ${num1} by ${date1}`, G, 'trend', num1, date1),
      { label: `${date1} by quarter`,              icon: G, group: 'trend' },
      { label: 'this month',                       icon: G, group: 'trend' },
      { label: 'last 30 days',                     icon: G, group: 'trend' },
    ] : []),

    // ── Distribution — real category / numeric columns required ───────────────
    chip(`distinct values in ${cat1}`,           G, 'dist', cat1),
    chip(`most common values in ${cat1}`,        G, 'dist', cat1),
    chip(`frequency distribution of ${cat1}`,    G, 'dist', cat1),
    chip(`correlation between ${num1} and ${num2}`, G, 'dist', num1, num2),

    // ── Data Quality — valid for any result ───────────────────────────────────
    { label: 'count nulls per column',           icon: G, group: 'quality' },
    chip(`show nulls in ${num1}`,                G, 'quality', num1),
    chip(`duplicates in ${id1}`,                 G, 'quality', id1),
    { label: 'random sample 20 rows',            icon: G, group: 'quality' },
  ];

  // Filter out null entries (chips that lacked required columns)
  return candidates.filter(Boolean) as Array<{ label: string; icon: React.ReactNode; group: string }>;
}

// Groups for the dataset-loaded Browse Topics
const GRID_GROUPS = [
  { key: 'summary', label: 'Overview' },
  { key: 'chart',   label: 'Charts' },
  { key: 'agg',     label: 'Aggregations' },
  { key: 'rank',    label: 'Ranking & Outliers' },
  { key: 'filter',  label: 'Filter & Search' },
  { key: 'pivot',   label: 'Pivot' },
  { key: 'trend',   label: 'Trends & Time' },
  { key: 'dist',    label: 'Distribution & Stats' },
  { key: 'quality', label: 'Data Quality' },
];

/** Simple frontend column name resolver: exact → prefix → substring. */
function _resolveColFE(name: string, cols: string[]): string | null {
  if (!name || !cols.length) return null;
  const nl = name.toLowerCase();
  return cols.find(c => c.toLowerCase() === nl)
    || cols.find(c => c.toLowerCase().startsWith(nl))
    || cols.find(c => c.toLowerCase().includes(nl))
    || null;
}

/** Suggest a chart type + axis columns from the available columns + user query. */
function suggestChart(cols: string[], q: string): { chartType: string; xCol: string; yCol: string; agg: string; title: string } | null {
  // Use the configurable patterns from columnPatterns.ts
  const datCols = cols.filter(c => isDateCol(c));
  const numCols = cols.filter(c => isNumericCol(c));
  const catCols = cols.filter(c => isCategoryCol(c));

  // Best picks with non-classified fallbacks
  const numCol = numCols[0] || cols.find(c => !isIdCol(c) && !isDateCol(c) && !isCategoryCol(c) && cols.indexOf(c) > 0) || cols[1] || cols[0];
  const catCol = catCols[0] || cols.find(c => !isNumericCol(c) && !isDateCol(c) && !isIdCol(c)) || cols[0];
  const datCol = datCols[0];

  // User-specified chart type
  const forceType: string | null = /pie/i.test(q) ? 'pie' : /area/i.test(q) ? 'area' : /line|trend/i.test(q) ? 'line' : /scatter/i.test(q) ? 'scatter' : /bar/i.test(q) ? 'bar' : null;

  // User-specified columns: "chart of X by Y", "X by Y chart", "bar chart of X vs Y"
  const colMatch = /(?:of\s+|chart\s+of\s+)?(\w+)\s+(?:by|vs?\.?|per|versus)\s+(\w+)/i.exec(q);
  if (colMatch) {
    const userA = _resolveColFE(colMatch[1], cols);
    const userB = _resolveColFE(colMatch[2], cols);
    if (userA && userB) {
      // If B is a date col → trend
      if (/date|time|period|month|year|fiscal/i.test(userB)) {
        return { chartType: 'line', xCol: userB, yCol: userA, agg: 'sum', title: `${userA} over time` };
      }
      return { chartType: forceType || 'bar', xCol: userB, yCol: userA, agg: 'sum', title: `${userA} by ${userB}` };
    }
  }

  if (forceType === 'pie' && catCol) {
    return { chartType: 'pie', xCol: catCol, yCol: numCol || cols[1] || cols[0], agg: 'count', title: `Distribution by ${catCol}` };
  }
  if ((forceType === 'line' || forceType === 'area') && datCol && numCol) {
    return { chartType: forceType, xCol: datCol, yCol: numCol, agg: 'sum', title: `${numCol} trend over time` };
  }
  if (forceType === 'scatter' && numCols.length >= 2) {
    return { chartType: 'scatter', xCol: numCols[0], yCol: numCols[1], agg: 'sum', title: `${numCols[0]} vs ${numCols[1]}` };
  }
  // Auto-detect
  if (datCol && numCol) return { chartType: 'line', xCol: datCol, yCol: numCol, agg: 'sum', title: `${numCol} over time` };
  if (catCol && numCol) return { chartType: 'bar',  xCol: catCol, yCol: numCol, agg: 'sum', title: `${numCol} by ${catCol}` };
  if (catCol)           return { chartType: 'pie',  xCol: catCol, yCol: cols[1] || cols[0], agg: 'count', title: `Distribution by ${catCol}` };
  return null;
}

const HELP_TEXT = `**What is QueryStudio?**
QueryStudio is an enterprise data query platform — write SQL, connect to data sources (S3, Snowflake, DuckDB, Trino, Oracle, Databricks), schedule queries, build dashboards, and govern data lineage.

**Key Features**
• SQL Editor — write SQL with NL-to-SQL assist, auto-suggest, query analyzer
• Query Builder — visual drag-and-drop query builder (no SQL required)
• Connections — S3, Snowflake, Databricks, Trino, Oracle, DuckDB/Parquet
• Scheduled Queries — CRON automation, anomaly detection, email/webhook alerts
• Dashboards — multi-chart, filter widgets, auto-refresh panels
• Materialized Views — pre-computed tables for fast repeated access
• Data Lineage — table-level & column-level lineage with interactive graph
• Parametric Reports — shareable reports with runtime URL-based filters
• Query Cache — auto-cache results, circuit breaker for failing connections
• Schema Browser — explore tables and columns per connection
• Data Grid — export CSV/Excel/JSON, chart & pivot views

**FAQ**
Q: How do I connect to my database?
A: Go to Connections → Add Connection. Supports S3, Snowflake, DuckDB, Trino, Oracle, Databricks.

Q: How do I run a query?
A: Open SQL Editor, select a connection, type SQL (or use NL-to-SQL), press Run or Ctrl+Enter.

Q: How do I schedule a query?
A: Open your saved query → Schedule tab → set CRON expression and notification settings.

Q: How do I share results?
A: Use Parametric Reports (shareable URL with filters) or add charts to a Dashboard.

Q: What is the circuit breaker?
A: Auto-protection that stops hammering a failing connection after repeated errors, then retries after a cooldown.

Q: Does it support row-level security?
A: Yes — RBAC (admin/analyst/viewer) with LDAP/AD SSO integration.

Q: What is data lineage?
A: Tracks which tables and columns are read/written by each query. Go to the Lineage page.

**QueryStudio Assistant** — what I can do:
• **SQL from English**: "top 10 customers by revenue" / "orders in the last 7 days"
• **Analyze SQL**: "analyze SELECT * FROM big_table" — detects anti-patterns
• **Schema lookup**: "columns in orders" / "describe customers"
• **Grid data queries** (when results are loaded):
  - Summarize, top N, sum/avg/count by group, trend by month
  - Outlier detection, distinct values, nulls, duplicates
  - Pivot: "pivot amount by status"
• **Charts** (when results are loaded): "bar chart of amount by status" / "pie chart by category"
• **Find tables**: "what tables are available?" — ranked by usage
• **Feature docs**: "how do I schedule a query?" / "explain S3 connections"
• **Browse Topics**: click the ? icon in the header for a full guided topic list

**Tips:**
• The assistant knows your current connection — NL→SQL uses your live schema
• "Use in SQL Editor" opens generated SQL ready to run
• Start typing 2+ characters for prompt suggestions
• Press Tab to autocomplete a suggestion, ↑↓ to navigate, Enter to send
• Works on every page — no need to leave what you're doing
`;

const SEV_COLOUR = { error: 'error', warning: 'warning', info: 'info' } as const;

// ── Component ─────────────────────────────────────────────────────────────────

interface GlobalAssistantPanelProps {
  onClose?: () => void;
}

const GlobalAssistantPanel: React.FC<GlobalAssistantPanelProps> = ({ onClose }) => {
  const navigate    = useNavigate();
  const assistCtx   = useAssistantContext();
  const { user }    = useAuth();
  // Phase 142 — persist NL assistant conversation + input across refresh.
  const [messages, setMessages] = useServerDraft<Message[]>('nl.assistant.messages', []);
  const [input, setInput]       = useServerDraft<string>('nl.assistant.input', '');
  const [loading, setLoading]   = useState(false);
  const [showExamples, setShowExamples] = useState(false); // show examples overlay mid-conversation
  const [showSugg, setShowSugg] = useState(false);         // typeahead dropdown visible
  const [hintIdx, setHintIdx]   = useState(-1);            // keyboard nav index in suggestions
  const bottomRef = useRef<HTMLDivElement>(null);
  const lastAutoExecRef = useRef<string | undefined>(undefined);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const persistTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Compute typeahead suggestions from current input
  const typingSugg = React.useMemo(() => {
    const q = input.trim().toLowerCase();
    if (q.length < 1) return [];
    return ALL_PROMPTS.filter(p => p.toLowerCase().includes(q)).slice(0, 8);
  }, [input]);

  // Load column classification patterns from backend config.json once on mount
  useEffect(() => { fetchChatbotPatterns(); }, []);

  // Phase 114-G: Load conversation from backend on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const conv = await api.getOrCreateConversation();
        if (cancelled) return;
        setConversationId(conv.id);
        if (conv.messages && conv.messages.length > 0) {
          setMessages(conv.messages);
        }
      } catch {
        // Fail silently — conversation memory is best-effort
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Phase 114-G: Debounced persist to backend (300ms)
  const persistMessages = useCallback((msgs: Message[], convId: number | null) => {
    if (!convId) return;
    if (persistTimer.current) clearTimeout(persistTimer.current);
    persistTimer.current = setTimeout(async () => {
      try {
        const title = msgs.find(m => m.role === 'user')?.content?.slice(0, 80) || 'Conversation';
        await api.updateConversation(convId, { messages: msgs, title });
      } catch {
        // silent
      }
    }, 300);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    // Phase 114-G: persist on every messages update (debounced)
    if (messages.length > 0) persistMessages(messages, conversationId);
  }, [messages, conversationId, persistMessages]);

  // ── Proactive grid insight when a new result loads ─────────────────────────
  useEffect(() => {
    const eid = assistCtx.executionId;
    const cols = assistCtx.resultColumns || [];
    if (!eid || !cols.length || eid === lastAutoExecRef.current) return;
    lastAutoExecRef.current = eid;
    // Classify columns using configurable patterns (src/config/columnPatterns.ts)
    const numCols = cols.filter(c => isNumericCol(c));
    const catCols = cols.filter(c => isCategoryCol(c));
    const datCols = cols.filter(c => isDateCol(c));
    const parts: string[] = [];
    if (numCols.length) parts.push(`numeric: ${numCols.slice(0, 3).join(', ')}`);
    if (catCols.length) parts.push(`categorical: ${catCols.slice(0, 3).join(', ')}`);
    if (datCols.length) parts.push(`dates: ${datCols.slice(0, 2).join(', ')}`);
    // Build hints using only real column names from the result
    const trendHint   = datCols[0]  ? `**trend of ${numCols[0] ?? datCols[0]} by month**` : null;
    const countHint   = catCols[0]  ? `**count by ${catCols[0]}**`   : null;
    const outlierHint = numCols[0]  ? `**outliers in ${numCols[0]}**` : null;
    const hintSuggestions = ['**summarize**', trendHint, countHint, outlierHint].filter(Boolean).join(', ');
    const noClassHint = parts.length === 0
      ? ' (No numeric/category columns recognised — add patterns to `config.json → chatbot.*_patterns` for smarter suggestions.)'
      : '';
    const hint = `I see ${cols.length} columns${parts.length ? ' — ' + parts.join(' · ') : ''}.\n\nTry: ${hintSuggestions || '**summarize**, **count nulls per column**, **random sample 20 rows**'}.${noClassHint}`;
    setMessages(prev => [
      ...prev,
      { id: `auto_${eid}`, role: 'assistant', intent: 'griddata', content: hint },
    ]);
  }, [assistCtx.executionId]); // eslint-disable-line

  // ── Send ──────────────────────────────────────────────────────────────────

  const handleSend = async (raw?: string) => {
    const q = (raw ?? input).trim();
    if (!q) return;
    setInput('');
    const msgId  = Date.now().toString();
    const intent = detectIntent(q, !!assistCtx.executionId);
    setMessages(prev => [...prev, { id: msgId + '_u', role: 'user', content: q, intent }]);
    setLoading(true);

    try {
      // ── Greet ─────────────────────────────────────────────────────────────
      if (intent === 'greet') {
        const reply = buildGreetReply(user?.display_name || user?.username);
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'greet', content: reply }]);
        return;
      }

      // ── Tour ──────────────────────────────────────────────────────────────
      if (intent === 'tour') {
        window.dispatchEvent(new CustomEvent('qs:start-tour', { detail: { tourId: 'getting_started' } }));
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'tour',
          content: 'Starting the **Getting Started** guided tour! Follow the spotlight to learn about QueryStudio\'s main features.' }]);
        return;
      }

      // ── Help ──────────────────────────────────────────────────────────────
      if (intent === 'help') {
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'help', content: HELP_TEXT }]);
        return;
      }

      // ── Glossary — list business terms defined in config.json ─────────────
      if (intent === 'glossary') {
        const glossary = getGlossary();
        const entries = Object.entries(glossary);
        const content = entries.length
          ? `I know ${entries.length} business term${entries.length !== 1 ? 's' : ''}:\n\n` +
            entries.map(([term, mapping]) => `**${term}** → \`${mapping}\``).join('\n')
          : 'No business glossary defined yet. Add entries to `config.json → chatbot.glossary`.';
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'glossary', content }]);
        return;
      }

      // ── FAQ — org-specific Q&A defined in config.json chatbot.faq ───────────
      if (intent === 'faq') {
        const faqAnswer = findFaqAnswer(q) ?? '';
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'faq', content: faqAnswer }]);
        return;
      }

      // ── Table list ────────────────────────────────────────────────────────
      if (intent === 'tables') {
        const r = await (api as any).getTopTables(assistCtx.connectionId);
        const tables = (r?.tables || r || []).slice(0, 12);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'tables',
          content: tables.length
            ? `Found ${tables.length} most-used tables:`
            : 'No table usage data yet. Run some queries first.',
          tables,
        }]);
        return;
      }

      // ── Schema lookup ─────────────────────────────────────────────────────
      if (intent === 'schema') {
        const tableName = extractTableFromSchema(q);
        const r = await (api as any).getSuggestSchema(tableName, assistCtx.connectionId);
        // Fallback: if backend has no schema but grid columns are loaded, use them
        if (!r.columns?.length && assistCtx.resultColumns?.length) {
          const gridCols = assistCtx.resultColumns.map((c: string) => ({ name: c, type: '—' }));
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'schema',
            content: `No cached schema for "${tableName}" — showing columns from your loaded grid result instead:`,
            schemaResult: {
              table: '(current grid result)',
              columns: gridCols,
              source: 'grid_result',
              message: 'Tip: open the Schema Browser for this connection to cache the full schema.',
            },
          }]);
        } else {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'schema',
            content: r.columns?.length
              ? `${r.table} — ${r.columns.length} column${r.columns.length !== 1 ? 's' : ''}${r.source === 'usage_stats' ? ' (from usage history)' : ''}`
              : (r.message || `No schema found for "${tableName}". Run a query referencing it first, or open the Schema Browser.`),
            schemaResult: r,
          }]);
        }
        return;
      }

      // ── Last result ───────────────────────────────────────────────────────
      if (intent === 'data') {
        const r = await (api as any).getLastResultInfo();
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'data',
          content: r.found
            ? `Last result: ${r.total_rows?.toLocaleString() || '?'} rows, ${r.columns?.length || '?'} columns`
            : (r.message || 'No result data found.'),
          dataResult: r,
        }]);
        return;
      }

      // ── Analyze ───────────────────────────────────────────────────────────
      if (intent === 'analyze') {
        const sql = q.replace(/^(analyze|check|review|lint|validate|fix):?\s*/i, '').trim();
        if (!sql || sql.length < 5) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'analyze',
            content: 'Include the SQL to analyze, e.g.: analyze SELECT * FROM my_table',
          }]);
          return;
        }
        const r = await (api as any).analyzeQuery(sql, assistCtx.connectionType || 'duckdb', []);
        const warns = r?.warnings || [];
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'analyze',
          content: warns.length
            ? `Found ${warns.length} issue${warns.length > 1 ? 's' : ''}:`
            : '✅ No issues detected — query looks clean.',
          analysisWarnings: warns,
          sql,
        }]);
        return;
      }

      // ── Docs / feature questions ──────────────────────────────────────────
      if (intent === 'docs') {
        const r = await (api as any).getSuggestDocs(q);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'docs',
          content: r.found
            ? `Found ${r.results.length} relevant section${r.results.length !== 1 ? 's' : ''} in the docs:`
            : "Hmm, I didn't find a specific match in the docs. Try rephrasing, or type 'help' for a feature overview.",
          docsResults: r.results || [],
        }]);
        return;
      }

      // ── Chart — enhanced multi-preset approach (Phase 77) ────────────────
      if (intent === 'chart') {
        const cols = assistCtx.resultColumns || [];
        if (!cols.length) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'chart',
            content: 'No data is loaded in the grid yet. Run a query first, then ask for a chart.',
          }]);
          return;
        }

        // Try multi-preset approach using columnIntelligence
        try {
          const classified = classifyColumns(
            cols,
            assistCtx.resultData || [],
            assistCtx.columnTypes || {}
          );
          let presets = generateChartPresets(classified);

          // Apply feedback reordering — liked presets promoted, disliked demoted
          try {
            const fbRes = await (api as any).getChartCorrections(assistCtx.connectionId);
            const fbArr = fbRes?.corrections || fbRes || [];
            if (Array.isArray(fbArr) && fbArr.length > 0) {
              const fbMap = new Map<string, number>();
              for (const c of fbArr) {
                const rating = parseInt(c.corrected_value || c.rating || '0', 10);
                fbMap.set(c.context_key || c.key || '', rating);
              }
              presets = reorderPresets(presets, fbMap, (p: ChartPreset) => chartPresetKey(assistCtx.connectionId || 0, p));
            }
          } catch (fbErr) {
            console.warn('[assistant] chart feedback fetch failed:', fbErr);
          }

          if (presets.length > 0) {
            setMessages(prev => [...prev, {
              id: msgId + '_a', role: 'assistant', intent: 'chart',
              content: `Here are ${Math.min(presets.length, 5)} chart suggestions based on your data:`,
              chartSuggestions: presets.slice(0, 5),
            }]);
            return;
          }
        } catch (chartErr) {
          console.warn('[assistant] chart generation failed:', chartErr);
        }

        // Fallback to simple single-chart suggestion
        const suggestion = suggestChart(cols, q);
        if (!suggestion) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'chart',
            content: "Couldn't determine a chart for the current columns. Try: 'bar chart of amount by status'.",
          }]);
          return;
        }
        assistCtx.setAssistantCtx({ chartPush: { ...suggestion, ts: Date.now() } });
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'chart',
          content: `${suggestion.title} -- chart rendered in the Chart tab above.`,
        }]);
        return;
      }

      // ── Pivot — multi-preset suggestions (Phase 77) ──────────────────────
      if (intent === 'pivot') {
        const cols = assistCtx.resultColumns || [];
        if (!cols.length) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'pivot',
            content: 'No data is loaded in the grid yet. Run a query first, then ask for pivot suggestions.',
          }]);
          return;
        }
        try {
          const classified = classifyColumns(cols, assistCtx.resultData || [], assistCtx.columnTypes || {});
          let presets = generatePivotPresets(classified);
          // Apply feedback reordering — liked presets promoted, disliked demoted
          try {
            const fbRes = await (api as any).getPivotCorrections(assistCtx.connectionId);
            const fbArr = fbRes?.corrections || fbRes || [];
            if (Array.isArray(fbArr) && fbArr.length > 0) {
              const fbMap = new Map<string, number>();
              for (const c of fbArr) {
                const rating = parseInt(c.corrected_value || c.rating || '0', 10);
                fbMap.set(c.context_key || c.key || '', rating);
              }
              presets = reorderPresets(presets, fbMap, (p: PivotPreset) => pivotPresetKey(assistCtx.connectionId || 0, p));
            }
          } catch (fbErr) {
            console.warn('[assistant] pivot feedback fetch failed:', fbErr);
          }
          if (presets.length > 0) {
            setMessages(prev => [...prev, {
              id: msgId + '_a', role: 'assistant', intent: 'pivot',
              content: `Here are ${presets.length} pivot suggestions:`,
              pivotSuggestions: presets.slice(0, 4),
            }]);
            return;
          }
        } catch (pivotErr) {
          console.warn('[assistant] pivot generation failed:', pivotErr);
        }
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'pivot',
          content: "Couldn't generate pivot suggestions for this data. Need at least one categorical and one numeric column.",
        }]);
        return;
      }

      // ── Grid data query ───────────────────────────────────────────────────
      if (intent === 'griddata') {
        // Profile/describe request -> call data-profile endpoint (Phase 77)
        if (PROFILE_TRIGGERS.test(q)) {
          try {
            const profile = await (api as any).dataProfile(
              assistCtx.executionId, assistCtx.fileId, assistCtx.resultColumns || []
            );
            if (profile && profile.row_count) {
              setMessages(prev => [...prev, {
                id: msgId + '_a', role: 'assistant', intent: 'griddata',
                content: `Data profile (${profile.row_count.toLocaleString()} rows, ${(profile.columns || []).length} columns):`,
                dataProfile: profile,
              }]);
              return;
            }
          } catch (profileErr) {
            console.warn('[assistant] data profile failed:', profileErr);
            setMessages(prev => [...prev, {
              id: msgId + '_a', role: 'assistant', intent: 'griddata',
              content: 'Data profiling failed. Make sure you have query results loaded, then try again.',
            }]);
            setLoading(false);
            return;
          }
        }
        const r = await (api as any).dataQuery(q, assistCtx.resultColumns || [], assistCtx.executionId, assistCtx.fileId);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'griddata',
          content: r.found
            ? `${r.answer}:`
            : (r.message || "Couldn't run that query on the current grid."),
          gridResult: r,
        }]);
        return;
      }

      // ── NL → SQL (default) ────────────────────────────────────────────────
      const r = await (api as any).nlToSql({
        question: q,
        connection_id: assistCtx.connectionId,
        tables: assistCtx.tables,
        columns: assistCtx.columns,
        connection_type: assistCtx.connectionType || 'duckdb',
        dataset_id: assistCtx.datasetId,
      });

      // Low confidence — try docs before showing a bad SQL template
      if ((r.confidence || 0) < 0.25) {
        const docsR = await (api as any).getSuggestDocs(q);
        if (docsR.found && docsR.results?.length > 0) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'docs',
            content: `I couldn't generate SQL for that, but here's what the docs say:`,
            docsResults: docsR.results,
          }]);
          return;
        }
      }

      setMessages(prev => [...prev, {
        id: msgId + '_a', role: 'assistant', intent: 'nl2sql',
        content: r.explanation || 'SQL generated.',
        sql: r.sql, confidence: r.confidence, pattern: r.pattern_matched,
        warnings: r.warnings || [], alternatives: r.alternatives || [],
        semanticMode: r.semantic_mode,
        datasetName: r.dataset_name,
        semanticRewrites: r.semantic_rewrites || [],
        // Phase 84C: learning engine fields
        nlHistoryId: r.history_id ?? null,
        nlSource: r.source ?? 'regex_pattern',
        nlSimilarity: r.similarity ?? null,
        nlSuggestions: r.suggestions ?? [],
      }]);

    } catch (e: any) {
      const raw = e?.message || '';
      // HTML response → endpoint doesn't exist in running server (needs restart)
      const needsRestart = raw.includes('DOCTYPE') || raw.includes('token \'<\'') || raw.includes("token '<'");
      setMessages(prev => [...prev, {
        id: msgId + '_e', role: 'assistant', intent,
        content: needsRestart
          ? "The backend needs a restart to pick up new features. Ask your admin to restart the QueryStudio server, then try again."
          : `Error: ${raw || 'Request failed.'}`,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleUseSql = (sql: string) => {
    sessionStorage.setItem('nl_sql_pending', sql);
    navigate('/sql');
    onClose?.();
  };

  const copyToClipboard = (text: string) => navigator.clipboard.writeText(text).catch(() => {});

  const handleFeedback = (msgId: string, msg: Message, rating: 1 | -1) => {
    setMessages(prev => prev.map(m => m.id === msgId ? { ...m, feedbackGiven: rating } : m));
    if (msg.sql) {
      // Legacy feedback endpoint (always called)
      (api as any).saveNlFeedback(
        msg.content, msg.sql, rating,
        assistCtx.connectionType || 'duckdb',
        assistCtx.tables?.slice(0, 5).join(',') || undefined,
      ).catch(() => {});
      // Phase 84D: learning engine feedback (uses history_id for reinforcement)
      if (msg.nlHistoryId != null) {
        (api as any).saveNlLearningFeedback({
          history_id: msg.nlHistoryId,
          was_edited: false,
          executed_sql: msg.sql,
          execution_success: true,
          feedback_score: rating,
        }).catch(() => {});
      }
    }
  };

  // ── Chart / Pivot preset feedback (Phase 77 robustness) ─────────────────
  const handlePresetFeedback = (
    msgId: string, presetIdx: number, kind: 'chart' | 'pivot',
    preset: any, rating: 1 | -1,
  ) => {
    const fbField = kind === 'chart' ? 'chartFeedback' : 'pivotFeedback';
    const sugField = kind === 'chart' ? 'chartSuggestions' : 'pivotSuggestions';
    setMessages(prev => prev.map(m => {
      if (m.id !== msgId) return m;
      const updated: any = { ...m, [fbField]: { ...(m[fbField] || {}), [presetIdx]: rating } };
      // BF-71: Remove disliked preset immediately from the rendered list
      if (rating === -1 && Array.isArray(m[sugField])) {
        updated[sugField] = (m[sugField] as any[]).filter((_: any, i: number) => i !== presetIdx);
      }
      return updated;
    }));
    // Build context_key same as DataGridViewer uses
    const contextKey = kind === 'chart'
      ? chartPresetKey(assistCtx.connectionId || 0, preset)
      : pivotPresetKey(assistCtx.connectionId || 0, preset);
    (api as any).saveSuggestionCorrection({
      correction_type: kind,
      context_key: contextKey,
      corrected_value: String(rating),
      original_value: '0',
      context_extra: String(assistCtx.connectionId || ''),
    }).catch(() => {});
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const contextChip = (assistCtx.connectionId != null || assistCtx.executionId || assistCtx.datasetId) && (
    <Stack direction="row" spacing={0.4} flexWrap="wrap">
      {assistCtx.datasetId != null && (
        <Chip size="small"
          label={`dataset: ${assistCtx.datasetName || `#${assistCtx.datasetId}`}`}
          color="secondary" variant="outlined"
          sx={{ height: 16, fontSize: '0.62rem' }} />
      )}
      {assistCtx.connectionId != null && !assistCtx.datasetId && (
        <Chip size="small"
          label={`conn #${assistCtx.connectionId}${assistCtx.pageName ? ` · ${assistCtx.pageName}` : ''}`}
          sx={{ height: 16, fontSize: '0.62rem', bgcolor: 'action.selected' }} />
      )}
      {assistCtx.executionId && (
        <Chip size="small" icon={<GridIcon sx={{ fontSize: 10 }} />}
          label={`${assistCtx.resultColumns?.length || '?'} cols loaded`}
          color="info" variant="outlined"
          sx={{ height: 16, fontSize: '0.62rem' }} />
      )}
    </Stack>
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* Header */}
      <Box sx={{
        px: 2, py: 1.25, borderBottom: '1.5px solid #00aeef',
        display: 'flex', alignItems: 'center', gap: 1,
        background: 'linear-gradient(90deg, #00aeef18 0%, transparent 100%)',
        flexShrink: 0,
      }}>
        {/* Icon with gold star */}
        <Box sx={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
          <MagicIcon sx={{ color: '#00aeef', fontSize: 20 }} />
          <Box sx={{
            position: 'absolute', top: -3, right: -4,
            width: 8, height: 8, borderRadius: '50%',
            bgcolor: '#FFD700',
            boxShadow: '0 0 4px rgba(255,215,0,0.9)',
          }} />
        </Box>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="subtitle2" fontWeight={700} lineHeight={1.2}
            sx={{ color: '#00aeef', letterSpacing: 0.2 }}>
            QueryStudio Assistant
          </Typography>
          <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap">
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.66rem' }}>
              SQL · Schema · Analyze · Data · Docs
            </Typography>
            {contextChip}
          </Stack>
        </Box>
        {/* New conversation button */}
        {messages.length > 0 && (
          <Tooltip title="New conversation">
            <IconButton size="small" sx={{ flexShrink: 0 }}
              onClick={async () => {
                setMessages([]);
                try {
                  const conv = await api.createConversation({ title: 'New conversation', messages: [] });
                  setConversationId(conv.id);
                } catch { /* silent */ }
              }}>
              <Box component="span" sx={{ fontSize: '0.65rem', fontWeight: 700, color: 'text.secondary' }}>+New</Box>
            </IconButton>
          </Tooltip>
        )}
        {/* Topics / Back button — always visible once chat has started */}
        {messages.length > 0 && (
          <Tooltip title={showExamples ? 'Back to chat' : 'Browse topics'}>
            <IconButton size="small"
              onClick={() => setShowExamples(v => !v)}
              sx={{ color: showExamples ? '#00aeef' : 'text.secondary', flexShrink: 0 }}>
              {showExamples
                ? <Box component="span" sx={{ fontSize: '0.7rem', fontWeight: 700 }}>← Chat</Box>
                : <HelpIcon sx={{ fontSize: 16 }} />
              }
            </IconButton>
          </Tooltip>
        )}
      </Box>

      {/* Messages */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1.5, py: 1,
                 display: 'flex', flexDirection: 'column', gap: 1.25 }}>

        {/* ── Topics overlay — replaces chat when showExamples=true ── */}
        {showExamples ? (() => {
          const hasGrid = !!assistCtx.executionId && (assistCtx.resultColumns?.length || 0) > 0;
          const gridExamples = hasGrid ? buildGridExamples(assistCtx.resultColumns || []) : [];
          const handleTopicClick = (label: string) => { setShowExamples(false); handleSend(label); };
          const Section = ({ title, group, color }: { title: string; group: string; color?: string }) => (
            <>
              <Typography variant="caption" color={color || 'text.secondary'}
                sx={{ display: 'block', mb: 0.4, mt: 0.75, fontSize: '0.71rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                {title}
              </Typography>
              <Stack spacing={0.4} sx={{ mb: 0.5 }}>
                {GENERIC_EXAMPLES.filter(e => e.group === group).map((ex, i) => (
                  <Chip key={i} icon={ex.icon as any} label={ex.label} size="small" variant="outlined"
                    sx={{ cursor: 'pointer', justifyContent: 'flex-start', fontSize: '0.73rem', height: 26 }}
                    onClick={() => handleTopicClick(ex.label)} />
                ))}
              </Stack>
            </>
          );
          return (
            <Box sx={{ mt: 0.5 }}>
              <Typography variant="body2" fontWeight={700} sx={{ mb: 0.25, fontSize: '0.82rem', color: '#00aeef' }}>
                All Topics
              </Typography>
              <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.67rem' }}>
                Click any topic to send it — or start typing for suggestions
              </Typography>

              {/* Grid-aware sections — only when result is loaded */}
              {hasGrid && GRID_GROUPS.map(grp => {
                const items = gridExamples.filter(ex => ex.group === grp.key);
                if (!items.length) return null;
                return (
                  <React.Fragment key={grp.key}>
                    <Typography variant="caption" color="info.main"
                      sx={{ display: 'block', mb: 0.4, mt: 0.75, fontSize: '0.71rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                      {grp.label}
                    </Typography>
                    <Stack spacing={0.4} sx={{ mb: 0.5 }}>
                      {items.map((ex, i) => (
                        <Chip key={i} icon={ex.icon as any} label={ex.label} size="small"
                          color="info" variant="outlined"
                          sx={{ cursor: 'pointer', justifyContent: 'flex-start', fontSize: '0.73rem', height: 26 }}
                          onClick={() => handleTopicClick(ex.label)} />
                      ))}
                    </Stack>
                  </React.Fragment>
                );
              })}

              <Section title="SQL from plain English" group="nlsql" />
              <Section title="Data & Schema" group="data" />
              <Section title="How-to Guides" group="howto" />
              <Section title="Product FAQ" group="product" />
              <Section title="Features & Architecture" group="features" />
              <Section title="Technical / Learning" group="tech" />
            </Box>
          );
        })() : (
          <>
            {/* Empty-state examples — adapt to context */}
            {messages.length === 0 && (() => {
              const hasGrid = !!assistCtx.executionId && (assistCtx.resultColumns?.length || 0) > 0;
              const gridExamples = hasGrid ? buildGridExamples(assistCtx.resultColumns || []) : [];
              return (
                <Box sx={{ mt: 0.5 }}>
                  {hasGrid ? (
                    <>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5, fontSize: '0.8rem' }}>
                        Data loaded — try these or type for suggestions:
                      </Typography>
                      {/* Show top items from key groups */}
                      {['summary','chart','agg','rank','quality'].map(grpKey => {
                        const items = gridExamples.filter(ex => ex.group === grpKey).slice(0, 2);
                        return items.map((ex, i) => (
                          <Chip key={`${grpKey}_${i}`} icon={ex.icon as any} label={ex.label} size="small"
                            color="info" variant="outlined"
                            sx={{ cursor: 'pointer', justifyContent: 'flex-start', fontSize: '0.73rem', height: 26, mb: 0.5, display: 'flex' }}
                            onClick={() => handleSend(ex.label)} />
                        ));
                      })}
                      <Typography variant="caption" color="info.main" sx={{ fontSize: '0.65rem', display: 'block', mb: 0.5, mt: 0.25, cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                        onClick={() => setShowExamples(true)}>
                        → See all data query topics
                      </Typography>
                      <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.65rem', display: 'block', mb: 0.5 }}>
                        Or ask anything else:
                      </Typography>
                    </>
                  ) : (
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1.25, fontSize: '0.8rem' }}>
                      Ask about your data, features, or how to use QueryStudio:
                    </Typography>
                  )}
                  <Stack spacing={0.5}>
                    {GENERIC_EXAMPLES.map((ex, i) => (
                      <Chip key={i} icon={ex.icon as any} label={ex.label} size="small" variant="outlined"
                        sx={{ cursor: 'pointer', justifyContent: 'flex-start', fontSize: '0.73rem', height: 26 }}
                        onClick={() => handleSend(ex.label)} />
                    ))}
                  </Stack>
                </Box>
              );
            })()}

            {/* Message list */}
            {messages.map(msg => (
          <Box key={msg.id} sx={{ display: 'flex', flexDirection: 'column',
                                  alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>

            {/* User bubble */}
            {msg.role === 'user' && (
              <Paper elevation={0} sx={{
                px: 1.5, py: 0.75, bgcolor: 'secondary.main', color: 'secondary.contrastText',
                borderRadius: '12px 12px 2px 12px', maxWidth: '88%',
              }}>
                <Typography variant="body2" sx={{ fontSize: '0.82rem' }}>{msg.content}</Typography>
              </Paper>
            )}

            {/* Assistant response */}
            {msg.role === 'assistant' && (
              <Box sx={{ maxWidth: '100%', width: '100%' }}>

                <Typography variant="body2" color="text.secondary"
                  sx={{ mb: 0.5, fontSize: '0.79rem', whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </Typography>

                {/* ── NL→SQL ── */}
                {msg.intent === 'nl2sql' && msg.sql && (
                  <>
                    {msg.confidence != null && (
                      <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mb: 0.5 }}>
                        <Chip label={`${Math.round(msg.confidence * 100)}% match`} size="small"
                          color={msg.confidence >= 0.8 ? 'success' : msg.confidence >= 0.5 ? 'warning' : 'error'}
                          sx={{ height: 18, fontSize: '0.68rem' }} />
                        {msg.pattern && (
                          <Chip label={msg.pattern} size="small" variant="outlined"
                            sx={{ height: 18, fontSize: '0.68rem' }} />
                        )}
                        {msg.semanticMode && (
                          <Chip label={`Semantic: ${msg.datasetName || 'dataset'}`}
                            size="small" color="secondary" variant="outlined"
                            sx={{ height: 18, fontSize: '0.68rem' }} />
                        )}
                      </Stack>
                    )}
                    <SqlBlock sql={msg.sql} onUse={handleUseSql} onCopy={copyToClipboard} />
                    {msg.warnings && msg.warnings.length > 0 && (
                      <Alert severity="warning" icon={<TipIcon fontSize="small" />}
                        sx={{ mt: 0.75, py: 0.25, fontSize: '0.73rem' }}>
                        {msg.warnings.join(' ')}
                      </Alert>
                    )}
                    {msg.alternatives && msg.alternatives.length > 0 && (
                      <Box sx={{ mt: 0.5 }}>
                        <Typography variant="caption" color="text.secondary">Alternatives:</Typography>
                        {msg.alternatives.map((alt, i) => (
                          <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.25 }}>
                            <Box component="code" sx={{ fontSize: '0.7rem', color: 'text.secondary', flex: 1, fontFamily: 'monospace' }}>{alt}</Box>
                            <Tooltip title="Use this">
                              <IconButton size="small" onClick={() => handleUseSql(alt)}>
                                <UseIcon sx={{ fontSize: 12 }} />
                              </IconButton>
                            </Tooltip>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </>
                )}

                {/* ── Analyze ── */}
                {msg.intent === 'analyze' && msg.analysisWarnings && msg.analysisWarnings.length > 0 && (
                  <Stack spacing={0.5} sx={{ mt: 0.5 }}>
                    {msg.analysisWarnings.map((w: any, i: number) => (
                      <Alert key={i} severity={SEV_COLOUR[w.severity] ?? 'info'}
                        sx={{ py: 0.25, '& .MuiAlert-message': { fontSize: '0.73rem' } }}>
                        <strong>{w.code}</strong> — {w.message}
                        {w.suggestion && (
                          <Typography variant="caption" color="text.secondary" display="block">
                            💡 {w.suggestion}
                          </Typography>
                        )}
                      </Alert>
                    ))}
                    {msg.sql && (
                      <Box sx={{ mt: 0.5 }}>
                        <SqlBlock sql={msg.sql} onUse={handleUseSql} onCopy={copyToClipboard} />
                      </Box>
                    )}
                  </Stack>
                )}

                {/* ── Schema ── */}
                {msg.intent === 'schema' && msg.schemaResult && msg.schemaResult.columns?.length > 0 && (
                  <SchemaTable result={msg.schemaResult} onUseSql={handleUseSql} />
                )}

                {/* ── Last result / data ── */}
                {msg.intent === 'data' && msg.dataResult?.found && (
                  <DataResultPanel result={msg.dataResult} onUseSql={handleUseSql} />
                )}

                {/* ── Grid data ── */}
                {msg.intent === 'griddata' && msg.gridResult?.found && (
                  <GridDataResultPanel result={msg.gridResult} />
                )}
                {msg.intent === 'griddata' && !msg.gridResult?.found && msg.gridResult?.message && (
                  <Alert severity="info" sx={{ mt: 0.5, py: 0.25, fontSize: '0.73rem' }}>
                    {msg.gridResult.message}
                    {msg.gridResult.sql && (
                      <Box component="pre" sx={{ mt: 0.4, fontFamily: 'monospace', fontSize: '0.65rem', color: 'text.secondary', whiteSpace: 'pre-wrap', m: 0 }}>
                        {msg.gridResult.sql}
                      </Box>
                    )}
                  </Alert>
                )}

                {/* ── Chart Suggestions (Phase 77) ── */}
                {msg.chartSuggestions && msg.chartSuggestions.length > 0 && (
                  <Stack spacing={1} sx={{ mt: 1 }}>
                    {msg.chartSuggestions.map((preset: any, idx: number) => {
                      const cfb = msg.chartFeedback?.[idx];
                      return (
                        <Paper
                          key={idx}
                          elevation={1}
                          sx={{
                            p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5,
                            '&:hover': { bgcolor: 'action.hover' },
                            border: '1px solid', borderColor: 'divider', borderRadius: 1,
                          }}
                        >
                          <BarChartIcon color="primary" fontSize="small" />
                          <Box sx={{ flex: 1, cursor: 'pointer' }} onClick={() => {
                            assistCtx.setAssistantCtx({
                              chartPush: {
                                chartType: preset.chartType || preset.chart_type,
                                xCol: preset.xColumn || preset.x_column || preset.xCol,
                                yCol: preset.yColumn || preset.y_column || preset.yCol,
                                agg: preset.agg || 'sum',
                                title: preset.title || preset.label || `${preset.chartType || preset.chart_type} chart`,
                                ts: Date.now(),
                              }
                            });
                          }}>
                            <Typography variant="body2" fontWeight={600}>
                              {preset.title || preset.label || `${preset.chartType || preset.chart_type} chart`}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {preset.chartType || preset.chart_type} &mdash; {preset.xColumn || preset.xCol || preset.x_column} x {preset.yColumn || preset.yCol || preset.y_column}
                            </Typography>
                          </Box>
                          <Tooltip title="Good suggestion">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              color={cfb === 1 ? 'success' : 'default'}
                              onClick={() => handlePresetFeedback(msg.id, idx, 'chart', preset, 1)}>
                              <ThumbUpIcon sx={{ fontSize: 13 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Not useful">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              color={cfb === -1 ? 'error' : 'default'}
                              onClick={() => handlePresetFeedback(msg.id, idx, 'chart', preset, -1)}>
                              <ThumbDownIcon sx={{ fontSize: 13 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Use this chart">
                            <IconButton size="small" color="primary" onClick={() => {
                              assistCtx.setAssistantCtx({
                                chartPush: {
                                  chartType: preset.chartType || preset.chart_type,
                                  xCol: preset.xColumn || preset.x_column || preset.xCol,
                                  yCol: preset.yColumn || preset.y_column || preset.yCol,
                                  agg: preset.agg || 'sum',
                                  title: preset.title || preset.label || `${preset.chartType || preset.chart_type} chart`,
                                  ts: Date.now(),
                                }
                              });
                            }}>
                              <UseIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Paper>
                      );
                    })}
                  </Stack>
                )}

                {/* ── Pivot Suggestions (Phase 77) ── */}
                {msg.pivotSuggestions && msg.pivotSuggestions.length > 0 && (
                  <Stack spacing={1} sx={{ mt: 1 }}>
                    {msg.pivotSuggestions.map((preset: any, idx: number) => {
                      const pfb = msg.pivotFeedback?.[idx];
                      return (
                        <Paper
                          key={idx}
                          elevation={1}
                          sx={{
                            p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5,
                            '&:hover': { bgcolor: 'action.hover' },
                            border: '1px solid', borderColor: 'divider', borderRadius: 1,
                          }}
                        >
                          <PivotIcon color="secondary" fontSize="small" />
                          <Box sx={{ flex: 1, cursor: 'pointer' }} onClick={() => {
                            assistCtx.setAssistantCtx({
                              pivotPush: { ...preset, ts: Date.now() }
                            });
                          }}>
                            <Typography variant="body2" fontWeight={600}>
                              {preset.label || preset.title || 'Pivot suggestion'}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              Rows: {(preset.rowFields || []).join(', ')} | Values: {(preset.values || []).map((v: any) => typeof v === 'string' ? v : v.column).join(', ')}
                            </Typography>
                          </Box>
                          <Tooltip title="Good suggestion">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              color={pfb === 1 ? 'success' : 'default'}
                              onClick={() => handlePresetFeedback(msg.id, idx, 'pivot', preset, 1)}>
                              <ThumbUpIcon sx={{ fontSize: 13 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Not useful">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              color={pfb === -1 ? 'error' : 'default'}
                              onClick={() => handlePresetFeedback(msg.id, idx, 'pivot', preset, -1)}>
                              <ThumbDownIcon sx={{ fontSize: 13 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Use this pivot">
                            <IconButton size="small" color="secondary" onClick={() => {
                              assistCtx.setAssistantCtx({
                                pivotPush: { ...preset, ts: Date.now() }
                              });
                            }}>
                              <UseIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Paper>
                      );
                    })}
                  </Stack>
                )}

                {/* ── Data Profile (Phase 77) ── */}
                {msg.dataProfile && (
                  <Box sx={{ mt: 1 }}>
                    {msg.dataProfile.data_quality && (
                      <Alert severity={msg.dataProfile.data_quality.columns_with_high_nulls?.length > 0 ? 'warning' : 'success'} sx={{ mb: 1, py: 0 }}>
                        <Typography variant="caption">
                          {msg.dataProfile.row_count?.toLocaleString()} rows |{' '}
                          {msg.dataProfile.data_quality.total_nulls || 0} total nulls |{' '}
                          {msg.dataProfile.data_quality.duplicate_rows || 0} duplicate rows
                          {msg.dataProfile.data_quality.columns_with_high_nulls?.length > 0 &&
                            ` | High nulls: ${msg.dataProfile.data_quality.columns_with_high_nulls.join(', ')}`}
                        </Typography>
                      </Alert>
                    )}
                    <Box sx={{ maxHeight: 300, overflow: 'auto' }}>
                      <table style={{ width: '100%', fontSize: '0.75rem', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid #ddd' }}>
                            <th style={{ textAlign: 'left', padding: '4px 8px' }}>Column</th>
                            <th style={{ textAlign: 'left', padding: '4px 8px' }}>Type</th>
                            <th style={{ textAlign: 'right', padding: '4px 8px' }}>Nulls</th>
                            <th style={{ textAlign: 'left', padding: '4px 8px' }}>Stats</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(msg.dataProfile.columns || []).map((col: any, idx: number) => (
                            <tr key={idx} style={{ borderBottom: '1px solid #eee' }}>
                              <td style={{ padding: '3px 8px', fontWeight: 500 }}>{col.name}</td>
                              <td style={{ padding: '3px 8px' }}>
                                <Chip label={col.type} size="small" variant="outlined"
                                  color={col.type === 'numeric' ? 'primary' : col.type === 'temporal' ? 'info' : 'default'}
                                  sx={{ height: 20, fontSize: '0.65rem' }}
                                />
                              </td>
                              <td style={{ padding: '3px 8px', textAlign: 'right', color: (col.null_pct || 0) > 0.5 ? '#d32f2f' : 'inherit' }}>
                                {col.nulls || 0} ({((col.null_pct || 0) * 100).toFixed(1)}%)
                              </td>
                              <td style={{ padding: '3px 8px', fontSize: '0.7rem' }}>
                                {col.type === 'numeric' && (
                                  <>min: {col.min_val ?? '-'} | max: {col.max_val ?? '-'} | mean: {col.mean_val ?? '-'} | outliers: {col.outlier_count ?? 0}</>
                                )}
                                {col.type === 'categorical' && (
                                  <>{col.distinct ?? 0} distinct | top: {(col.top_values || []).slice(0, 3).map((tv: any) => tv.value).join(', ')}</>
                                )}
                                {col.type === 'temporal' && (
                                  <>{col.min_date ?? '-'} to {col.max_date ?? '-'} | {col.distinct_months ?? 0} months</>
                                )}
                                {col.type !== 'numeric' && col.type !== 'categorical' && col.type !== 'temporal' && (
                                  <>-</>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </Box>
                  </Box>
                )}

                {/* ── Docs ── */}
                {(msg.intent === 'docs' || msg.intent === 'nl2sql') && msg.docsResults && msg.docsResults.length > 0 && (
                  <DocsResultPanel results={msg.docsResults} />
                )}

                {/* ── NL→SQL feedback ── */}
                {msg.intent === 'nl2sql' && msg.sql && (
                  <Box sx={{ mt: 0.5 }}>
                    {/* Source / similarity chip */}
                    {msg.nlSource === 'learned' && msg.nlSimilarity != null && (
                      <Chip
                        size="small"
                        icon={<SchoolIcon sx={{ fontSize: 10 }} />}
                        label={`Learned (${Math.round(msg.nlSimilarity * 100)}% match)`}
                        color="info"
                        variant="outlined"
                        sx={{ height: 16, fontSize: '0.62rem', mb: 0.5, mr: 0.5 }}
                      />
                    )}
                    {msg.nlSource === 'local_llm' && (
                      <Chip
                        size="small"
                        label="AI Generated"
                        sx={{
                          height: 16, fontSize: '0.62rem', mb: 0.5, mr: 0.5,
                          bgcolor: '#ede9fe', color: '#6d28d9', border: '1px solid #c4b5fd',
                        }}
                      />
                    )}
                    {/* Similar past queries as suggestions */}
                    {msg.nlSuggestions && msg.nlSuggestions.length > 0 && (
                      <Box sx={{ mb: 0.5 }}>
                        <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.62rem' }}>
                          Similar past queries:
                        </Typography>
                        {msg.nlSuggestions.slice(0, 3).map((s, i) => (
                          <Tooltip key={i} title={s.sql} placement="top">
                            <Chip
                              size="small"
                              label={s.nl_query.length > 40 ? s.nl_query.slice(0, 40) + '…' : s.nl_query}
                              variant="outlined"
                              onClick={() => handleSend(s.nl_query)}
                              sx={{ height: 16, fontSize: '0.6rem', mr: 0.4, mb: 0.3, cursor: 'pointer' }}
                            />
                          </Tooltip>
                        ))}
                      </Box>
                    )}
                    <Stack direction="row" spacing={0.5} alignItems="center">
                      <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.65rem' }}>
                        Helpful?
                      </Typography>
                      <Tooltip title="Thumbs up — save as a good example">
                        <IconButton size="small" sx={{ p: 0.25 }}
                          color={msg.feedbackGiven === 1 ? 'success' : 'default'}
                          onClick={() => handleFeedback(msg.id, msg, 1)}>
                          <ThumbUpIcon sx={{ fontSize: 12 }} />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Thumbs down — mark as incorrect">
                        <IconButton size="small" sx={{ p: 0.25 }}
                          color={msg.feedbackGiven === -1 ? 'error' : 'default'}
                          onClick={() => handleFeedback(msg.id, msg, -1)}>
                          <ThumbDownIcon sx={{ fontSize: 12 }} />
                        </IconButton>
                      </Tooltip>
                      {msg.feedbackGiven != null && (
                        <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.63rem' }}>
                          {msg.feedbackGiven === 1 ? 'Thanks! Saved as a good example.' : 'Noted. Thanks for the feedback.'}
                        </Typography>
                      )}
                    </Stack>
                  </Box>
                )}

                {/* ── Table suggestions ── */}
                {msg.intent === 'tables' && msg.tables && msg.tables.length > 0 && (
                  <Stack spacing={0.25} sx={{ mt: 0.5 }}>
                    {msg.tables.map((t: any, i: number) => {
                      const name = t.table_name || t.object_name || t;
                      return (
                        <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                          <TableIcon sx={{ fontSize: 12, color: 'text.secondary' }} />
                          <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: '0.73rem', flex: 1 }}>
                            {name}
                          </Typography>
                          {t.use_count && (
                            <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.65rem' }}>
                              ×{t.use_count}
                            </Typography>
                          )}
                          <Tooltip title="Describe this table">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              onClick={() => handleSend(`columns in ${name}`)}>
                              <SchemaIcon sx={{ fontSize: 11 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Generate SELECT">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              onClick={() => handleSend(`show all ${name}`)}>
                              <SqlIcon sx={{ fontSize: 11 }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      );
                    })}
                  </Stack>
                )}

              </Box>
            )}
          </Box>
        ))}
          </>
        )}

        {loading && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CircularProgress size={13} />
            <Typography variant="caption" color="text.secondary">Processing…</Typography>
          </Box>
        )}
        <div ref={bottomRef} />
      </Box>

      <Divider />

      {/* Input */}
      <Box sx={{ px: 1.5, py: 1, bgcolor: 'background.paper', flexShrink: 0, position: 'relative' }}>
        {/* Typeahead suggestions */}
        {showSugg && typingSugg.length > 0 && (
          <Paper elevation={4} sx={{
            position: 'absolute', bottom: '100%', left: 12, right: 12, mb: 0.5,
            maxHeight: 260, overflowY: 'auto', zIndex: 1400,
            border: '1px solid', borderColor: 'divider', borderRadius: 1,
          }}>
            <Box sx={{ px: 1, py: 0.5, borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'action.hover' }}>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem', fontWeight: 600 }}>
                Suggestions — click to send
              </Typography>
            </Box>
            {typingSugg.map((s, i) => (
              <Box key={s}
                onMouseDown={e => { e.preventDefault(); setInput(''); setShowSugg(false); handleSend(s); }}
                sx={{
                  px: 1.5, py: 0.6, cursor: 'pointer', fontSize: '0.79rem',
                  bgcolor: i === hintIdx ? 'action.selected' : 'transparent',
                  '&:hover': { bgcolor: 'action.hover' },
                  borderBottom: i < typingSugg.length - 1 ? '1px solid' : 'none',
                  borderColor: 'divider',
                }}>
                {s}
              </Box>
            ))}
          </Paper>
        )}
        <Box sx={{ display: 'flex', gap: 0.75, alignItems: 'flex-end' }}>
          <TextField
            multiline maxRows={3} fullWidth size="small"
            placeholder="Try: top 10 by amount · bar chart · how do I schedule · columns in orders…"
            value={input}
            onChange={e => { setInput(e.target.value); setHintIdx(-1); setShowSugg(true); }}
            onFocus={() => { if (input.trim().length >= 1) setShowSugg(true); }}
            onBlur={() => setTimeout(() => setShowSugg(false), 150)}
            onKeyDown={e => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setHintIdx(i => Math.min(i + 1, typingSugg.length - 1)); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setHintIdx(i => Math.max(i - 1, -1)); }
              else if (e.key === 'Tab' && typingSugg.length > 0 && showSugg) {
                e.preventDefault();
                const pick = typingSugg[hintIdx >= 0 ? hintIdx : 0];
                setInput(pick); setShowSugg(false); setHintIdx(-1);
              }
              else if (e.key === 'Escape') { setShowSugg(false); setHintIdx(-1); }
              else if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (hintIdx >= 0 && showSugg && typingSugg[hintIdx]) {
                  const pick = typingSugg[hintIdx];
                  setInput(''); setShowSugg(false); setHintIdx(-1); handleSend(pick);
                } else {
                  setShowSugg(false); handleSend();
                }
              }
            }}
            sx={{ '& .MuiInputBase-root': { fontSize: '0.8rem' } }}
          />
          <IconButton onClick={() => { setShowSugg(false); handleSend(); }} disabled={!input.trim() || loading}
            sx={{ mb: 0.25, flexShrink: 0, color: '#00aeef', '&:hover': { bgcolor: '#00aeef18' }, '&:disabled': { color: 'text.disabled' } }}>
            <SendIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

// ── Sub-components ────────────────────────────────────────────────────────────

const SqlBlock = ({ sql, onUse, onCopy }: { sql: string; onUse: (s: string) => void; onCopy: (s: string) => void }) => (
  <Paper variant="outlined" sx={{ p: 1, bgcolor: 'grey.50', borderRadius: 1 }}>
    <Box component="pre" sx={{ m: 0, fontFamily: 'monospace', fontSize: '0.75rem',
      whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: 'text.primary', lineHeight: 1.55 }}>
      {sql}
    </Box>
    <Stack direction="row" spacing={0.5} sx={{ mt: 0.75 }}>
      <Button size="small" variant="contained" color="secondary"
        startIcon={<UseIcon sx={{ fontSize: 13 }} />}
        sx={{ fontSize: '0.7rem', py: 0.25, px: 1 }}
        onClick={() => onUse(sql)}>
        Use in SQL Editor
      </Button>
      <Tooltip title="Copy SQL">
        <IconButton size="small" onClick={() => onCopy(sql)}>
          <CopyIcon sx={{ fontSize: 13 }} />
        </IconButton>
      </Tooltip>
    </Stack>
  </Paper>
);

const SchemaTable = ({ result, onUseSql }: { result: any; onUseSql: (sql: string) => void }) => {
  const cols: any[] = result.columns || [];
  const selectSql   = `SELECT\n  ${cols.map((c: any) => c.name).join(',\n  ')}\nFROM ${result.table}\nLIMIT 100`;
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1 }}>
      {result.message && (
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, fontStyle: 'italic' }}>
          {result.message}
        </Typography>
      )}
      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {['Column', 'Type', ...(cols[0]?.use_count != null ? ['Uses'] : [])].map(h => (
              <Box component="th" key={h} sx={{ textAlign: 'left', pb: 0.25, color: 'text.secondary',
                fontWeight: 600, borderBottom: '1px solid', borderColor: 'divider', pr: 1 }}>
                {h}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {cols.slice(0, 30).map((c: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              <Box component="td" sx={{ fontFamily: 'monospace', py: 0.15, pr: 1, color: 'primary.main', fontSize: '0.71rem' }}>
                {c.name}
              </Box>
              <Box component="td" sx={{ color: 'text.secondary', pr: 1, fontSize: '0.68rem' }}>
                {c.type || '—'}
              </Box>
              {c.use_count != null && (
                <Box component="td" sx={{ color: 'text.disabled', fontSize: '0.65rem' }}>
                  ×{c.use_count}
                </Box>
              )}
            </Box>
          ))}
          {cols.length > 30 && (
            <Box component="tr">
              <Box component="td" colSpan={3} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {cols.length - 30} more
              </Box>
            </Box>
          )}
        </Box>
      </Box>
      <Button size="small" variant="outlined" color="secondary"
        startIcon={<UseIcon sx={{ fontSize: 12 }} />}
        sx={{ mt: 0.75, fontSize: '0.68rem', py: 0.2 }}
        onClick={() => onUseSql(selectSql)}>
        SELECT all columns
      </Button>
    </Paper>
  );
};

const DataResultPanel = ({ result, onUseSql }: { result: any; onUseSql: (sql: string) => void }) => {
  const cols: any[] = result.columns || [];
  const execAt = result.executed_at ? new Date(result.executed_at).toLocaleString() : '—';
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1 }}>
      <Stack direction="row" spacing={1} sx={{ mb: 0.75 }} flexWrap="wrap">
        <Chip label={`${(result.total_rows || 0).toLocaleString()} rows`} size="small"
          color="info" sx={{ height: 18, fontSize: '0.68rem' }} />
        <Chip label={`${cols.length} cols`} size="small" variant="outlined"
          sx={{ height: 18, fontSize: '0.68rem' }} />
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.67rem', alignSelf: 'center' }}>
          {execAt}
        </Typography>
      </Stack>
      {result.sql_preview && (
        <Box component="pre" sx={{ m: 0, mb: 0.75, fontFamily: 'monospace', fontSize: '0.68rem',
          color: 'text.secondary', whiteSpace: 'pre-wrap', wordBreak: 'break-all',
          bgcolor: 'grey.50', p: 0.75, borderRadius: 0.5, border: '1px solid', borderColor: 'divider' }}>
          {result.sql_preview}{result.sql_preview.length >= 300 ? '…' : ''}
        </Box>
      )}
      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {['Column', 'Type'].map(h => (
              <Box component="th" key={h} sx={{ textAlign: 'left', pb: 0.25, color: 'text.secondary',
                fontWeight: 600, borderBottom: '1px solid', borderColor: 'divider', pr: 1 }}>
                {h}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {cols.slice(0, 20).map((c: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              <Box component="td" sx={{ fontFamily: 'monospace', py: 0.15, pr: 1, color: 'primary.main', fontSize: '0.71rem' }}>
                {c.name}
              </Box>
              <Box component="td" sx={{ color: 'text.secondary', fontSize: '0.68rem' }}>
                {c.type || '—'}
              </Box>
            </Box>
          ))}
          {cols.length > 20 && (
            <Box component="tr">
              <Box component="td" colSpan={2} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {cols.length - 20} more columns
              </Box>
            </Box>
          )}
        </Box>
      </Box>
      {result.sql_preview && (
        <Button size="small" variant="outlined" color="secondary"
          startIcon={<UseIcon sx={{ fontSize: 12 }} />}
          sx={{ mt: 0.75, fontSize: '0.68rem', py: 0.2 }}
          onClick={() => onUseSql(result.sql_preview)}>
          Re-run this query
        </Button>
      )}
    </Paper>
  );
};

const DocsResultPanel = ({ results }: { results: any[] }) => (
  <Stack spacing={0.75} sx={{ mt: 0.75 }}>
    {results.map((r: any, i: number) => (
      <Paper key={i} variant="outlined" sx={{ p: 1, borderRadius: 1, borderLeft: '3px solid', borderLeftColor: 'primary.main' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.4 }}>
          <DocsIcon sx={{ fontSize: 12, color: 'primary.main' }} />
          <Typography variant="caption" fontWeight={700} sx={{ fontSize: '0.73rem', color: 'primary.main' }}>
            {r.heading}
          </Typography>
          <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.62rem', ml: 'auto' }}>
            {r.source}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.72rem', lineHeight: 1.5 }}>
          {r.excerpt}
        </Typography>
      </Paper>
    ))}
  </Stack>
);

const GridDataResultPanel = ({ result }: { result: any }) => {
  const navigate = useNavigate();
  const cols: string[]  = result.columns || [];
  const rows: any[]     = result.rows || [];
  const [showSql, setShowSql] = React.useState(false);
  const [copied, setCopied]   = React.useState(false);

  const handleCopySql = () => {
    if (result.sql) {
      navigator.clipboard.writeText(result.sql).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      });
    }
  };

  const handleOpenInEditor = () => {
    if (result.sql) {
      sessionStorage.setItem('pendingSql', result.sql);
      navigate('/sql');
    }
  };

  const handleExportCsv = () => {
    if (!cols.length || !rows.length) return;
    const escape = (v: any) => {
      const s = v == null ? '' : String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [cols.map(escape).join(',')];
    rows.forEach(row => lines.push(cols.map(c => escape(row[c])).join(',')));
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'query_result.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  if (!rows.length) return (
    <Alert severity="info" sx={{ mt: 0.5, py: 0.25, fontSize: '0.73rem' }}>
      Query returned no rows.
    </Alert>
  );
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1, overflowX: 'auto' }}>
      {/* Toolbar */}
      <Stack direction="row" spacing={0.5} sx={{ mb: 0.75 }} alignItems="center" flexWrap="wrap">
        <GridIcon sx={{ fontSize: 12, color: 'info.main' }} />
        <Typography variant="caption" sx={{ fontSize: '0.7rem', color: 'info.main', fontWeight: 600 }}>
          {result.row_count} row{result.row_count !== 1 ? 's' : ''}
        </Typography>
        <Box sx={{ flex: 1 }} />
        {result.sql && (
          <>
            <Tooltip title={showSql ? 'Hide SQL' : 'Show generated SQL'}>
              <Chip label="SQL" size="small" variant={showSql ? 'filled' : 'outlined'}
                color={showSql ? 'primary' : 'default'}
                onClick={() => setShowSql(v => !v)}
                sx={{ height: 18, fontSize: '0.65rem', cursor: 'pointer' }} />
            </Tooltip>
            <Tooltip title={copied ? 'Copied!' : 'Copy SQL'}>
              <IconButton size="small" onClick={handleCopySql}
                sx={{ p: 0.25, color: copied ? 'success.main' : 'text.secondary' }}>
                <CopyIcon sx={{ fontSize: 12 }} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Open SQL in Editor">
              <IconButton size="small" onClick={handleOpenInEditor} sx={{ p: 0.25, color: 'text.secondary' }}>
                <SqlIcon sx={{ fontSize: 12 }} />
              </IconButton>
            </Tooltip>
          </>
        )}
        <Tooltip title="Export as CSV">
          <IconButton size="small" onClick={handleExportCsv} sx={{ p: 0.25, color: 'text.secondary' }}>
            <Box component="span" sx={{ fontSize: '0.6rem', fontWeight: 700, lineHeight: 1 }}>CSV</Box>
          </IconButton>
        </Tooltip>
      </Stack>

      {/* SQL preview */}
      {showSql && result.sql && (
        <Box sx={{
          mb: 0.75, p: 0.75, bgcolor: 'action.hover', borderRadius: 0.75,
          fontFamily: 'monospace', fontSize: '0.65rem', color: 'text.primary',
          whiteSpace: 'pre-wrap', wordBreak: 'break-all',
          maxHeight: 120, overflowY: 'auto',
          border: '1px solid', borderColor: 'divider',
        }}>
          {result.sql}
        </Box>
      )}

      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {cols.map(c => (
              <Box component="th" key={c} sx={{ textAlign: 'left', pb: 0.25, pr: 1,
                color: 'text.secondary', fontWeight: 600,
                borderBottom: '1px solid', borderColor: 'divider', whiteSpace: 'nowrap' }}>
                {c}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {rows.slice(0, 20).map((row: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              {cols.map(c => (
                <Box component="td" key={c} sx={{ py: 0.15, pr: 1, fontFamily: 'monospace', fontSize: '0.71rem', whiteSpace: 'nowrap' }}>
                  {row[c] == null ? <span style={{ color: '#aaa' }}>null</span> : String(row[c])}
                </Box>
              ))}
            </Box>
          ))}
          {rows.length > 20 && (
            <Box component="tr">
              <Box component="td" colSpan={cols.length} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {rows.length - 20} more rows
              </Box>
            </Box>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default GlobalAssistantPanel;
