/**
 * Phase 111-G: Unified Report Builder — type picker + delegation.
 *
 * For new reports: shows a type picker (Tabular, Pivot, Saved Query), then
 * delegates to the appropriate builder component.
 *
 * For editing existing reports: detects the report type from the stored
 * data and opens the correct builder directly.
 */
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, Grid, CircularProgress, Skeleton,
  Card, CardContent, CardActionArea, Alert, Chip,
  TextField, Select, MenuItem, FormControl, InputLabel, IconButton,
  ToggleButton, ToggleButtonGroup, Tooltip,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import TableChartIcon from '@mui/icons-material/TableChart';
import PivotTableChartIcon from '@mui/icons-material/PivotTableChart';
import StorageIcon from '@mui/icons-material/Storage';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const BusinessReportBuilder = lazy(() => import('./BusinessReportBuilder'));
const PivotReportBuilder = lazy(() => import('./PivotReportBuilder'));

type ReportType = 'tabular' | 'pivot' | 'raw_sql';

const TYPE_OPTIONS: Array<{
  type: ReportType;
  title: string;
  subtitle: string;
  bestFor: string[];
  icon: React.ReactElement;
}> = [
  {
    type: 'tabular',
    title: 'Tabular Report',
    subtitle: 'Pick columns from a dataset, add filters and parameters, group by sections, and apply running calculations.',
    bestFor: ['Monthly sales summaries', 'Filtered data exports', 'Reports with subtotals'],
    icon: <TableChartIcon sx={{ fontSize: 48 }} />,
  },
  {
    type: 'pivot',
    title: 'Pivot / Crosstab',
    subtitle: 'Drag-and-drop dimensions into rows and columns, then add measures with aggregations.',
    bestFor: ['Revenue by region & quarter', 'Cross-tabulated comparisons', 'Multi-dimensional analysis'],
    icon: <PivotTableChartIcon sx={{ fontSize: 48 }} />,
  },
  {
    type: 'raw_sql',
    title: 'Saved Query Report',
    subtitle: 'Wrap an existing saved query as a report. Add parameters that users fill in before each run.',
    bestFor: ['Reusing complex queries', 'Parameterized ad-hoc reports', 'Quick report from existing work'],
    icon: <StorageIcon sx={{ fontSize: 48 }} />,
  },
];

const builderFallback = (
  <Box sx={{ p: 3, maxWidth: 900, mx: 'auto' }}>
    <Skeleton variant="text" width={300} height={40} sx={{ mb: 2 }} />
    <Skeleton variant="rectangular" height={120} sx={{ mb: 2, borderRadius: 1 }} />
    <Skeleton variant="rectangular" height={200} sx={{ mb: 2, borderRadius: 1 }} />
    <Skeleton variant="rectangular" height={60} sx={{ borderRadius: 1 }} />
  </Box>
);

const UnifiedReportBuilder: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const [reportType, setReportType] = useState<ReportType | null>(null);
  const [loading, setLoading] = useState(!!id);
  const [error, setError] = useState('');

  // Editing an existing report — detect type automatically
  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.getBusinessReport(Number(id))
      .then((report: any) => {
        const dst = report?.data_source_type || 'saved_query';
        const lc = report?.layout_config || {};

        if (dst === 'raw_sql') {
          setReportType('raw_sql');
        } else if (lc.report_type === 'pivot') {
          setReportType('pivot');
        } else {
          setReportType('tabular');
        }
      })
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return builderFallback;
  if (error) return <Alert severity="error" sx={{ m: 3 }}>{error}</Alert>;

  // Type picker for new reports
  if (!reportType) {
    return (
      <Box sx={{ p: 3, maxWidth: 880, mx: 'auto' }}>
        <Button size="small" startIcon={<ArrowBackIcon />} sx={{ mb: 2 }}
          onClick={() => navigate('/business-reports')}>
          Back to Reports
        </Button>
        <Typography variant="h5" sx={{ mb: 0.5 }}>Create New Report</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Choose how you want to build your report.
        </Typography>
        <Grid container spacing={2} sx={{ alignItems: 'stretch' }}>
          {TYPE_OPTIONS.map(opt => (
            <Grid key={opt.type} size={{ xs: 12, sm: 4 }}>
              <Card
                variant="outlined"
                sx={{
                  height: '100%',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                  '&:hover': { borderColor: 'primary.main', boxShadow: 2 },
                }}
              >
                <CardActionArea
                  onClick={() => setReportType(opt.type)}
                  sx={{ height: '100%', p: 2.5, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start' }}
                >
                  <Box sx={{ color: 'primary.main', mb: 1 }}>{opt.icon}</Box>
                  <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 0.5 }}>{opt.title}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', mb: 1.5, fontSize: '0.8rem', lineHeight: 1.4 }}>
                    {opt.subtitle}
                  </Typography>
                  <Box sx={{ mt: 'auto', width: '100%', pt: 1.5, borderTop: '1px solid', borderColor: 'divider' }}>
                    <Typography variant="caption" fontWeight="bold" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                      Examples:
                    </Typography>
                    {opt.bestFor.map(ex => (
                      <Typography key={ex} variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.6, pl: 0.5 }}>
                        &bull; {ex}
                      </Typography>
                    ))}
                  </Box>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Prerequisite note */}
        <Alert severity="info" variant="outlined" sx={{ mt: 3, fontSize: '0.8rem' }} icon={<HelpOutlineIcon fontSize="small" />}>
          <strong>Tabular</strong> and <strong>Pivot</strong> reports require a dataset (semantic layer).{' '}
          <strong>Saved Query</strong> reports use an existing saved query from the Query Builder or SQL Query page.{' '}
          {isAdmin && (
            <Button size="small" variant="text" sx={{ ml: 0.5, textTransform: 'none', p: 0, minWidth: 'auto' }}
              onClick={() => navigate('/datasets')}>
              Manage Datasets
            </Button>
          )}
        </Alert>
      </Box>
    );
  }

  // For tabular/pivot — check if datasets exist before delegating
  if (reportType === 'tabular' || reportType === 'pivot') {
    return <DatasetGatedBuilder reportType={reportType} id={id} />;
  }

  // Saved query report
  return <RawSqlReportBuilder reportId={id ? Number(id) : undefined} />;
};

// ── Dataset Gate — checks for datasets before showing the builder ──────────

const DatasetGatedBuilder: React.FC<{ reportType: 'tabular' | 'pivot'; id?: string }> = ({ reportType, id }) => {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [hasDatasets, setHasDatasets] = useState(true);
  const [datasetCreated, setDatasetCreated] = useState(false);

  useEffect(() => {
    // Editing an existing report — skip check, it already has a dataset
    if (id) { setChecking(false); return; }
    api.listDatasets().then((ds: any) => {
      setHasDatasets(Array.isArray(ds) && ds.length > 0);
    }).catch(() => setHasDatasets(false))
      .finally(() => setChecking(false));
  }, [id, datasetCreated]);

  if (checking) return builderFallback;

  // No datasets — show quick-create flow
  if (!hasDatasets && !id) {
    return (
      <QuickDatasetSetup
        onCreated={() => setDatasetCreated(true)}
        onSkip={() => navigate('/business-reports/new')}
        reportType={reportType}
      />
    );
  }

  // Datasets exist — delegate to the actual builder
  if (reportType === 'pivot') {
    return (
      <Suspense fallback={builderFallback}>
        <PivotReportBuilder />
      </Suspense>
    );
  }
  return (
    <Suspense fallback={builderFallback}>
      <BusinessReportBuilder />
    </Suspense>
  );
};

// ── Quick Dataset Setup — inline mini-wizard ────────────────────────────────

interface QuickSetupProps {
  onCreated: () => void;
  onSkip: () => void;
  reportType: 'tabular' | 'pivot';
}

const QuickDatasetSetup: React.FC<QuickSetupProps> = ({ onCreated, onSkip, reportType }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState(0); // 0=pick connection, 1=pick tables, 2=name+create
  const [connections, setConnections] = useState<any[]>([]);
  const [selectedConn, setSelectedConn] = useState<number | null>(null);
  const [tables, setTables] = useState<any[]>([]);
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [dsName, setDsName] = useState('');
  const [dsSubject, setDsSubject] = useState('');
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');
  const [loadingTables, setLoadingTables] = useState(false);

  // Load connections on mount
  useEffect(() => {
    api.listConnections().then((c: any) => setConnections(Array.isArray(c) ? c : [])).catch(() => []);
  }, []);

  // Load tables when connection selected
  useEffect(() => {
    if (!selectedConn) return;
    setLoadingTables(true);
    api.listRegisteredTables(String(selectedConn))
      .then((t: any) => setTables(Array.isArray(t) ? t : []))
      .catch(() => setTables([]))
      .finally(() => setLoadingTables(false));
  }, [selectedConn]);

  const handleCreate = async () => {
    if (!dsName.trim()) { setError('Dataset name is required'); return; }
    if (!dsSubject.trim()) { setError('Subject is required'); return; }
    if (!selectedConn || selectedTables.length === 0) { setError('Select at least one table'); return; }

    setCreating(true);
    setError('');
    try {
      // Create the dataset
      const ds = await api.createDataset({
        name: dsName.trim(),
        subject: dsSubject.trim(),
        description: `Auto-created for ${reportType} report`,
        connection_ids: [selectedConn],
        source_tables: selectedTables.map(t => ({
          connection_id: selectedConn,
          table: t,
          alias: t.split('/').pop()?.replace(/\.\w+$/, '') || t,
        })),
        is_published: false,
      });

      if (!ds?.id) throw new Error('Dataset creation failed');

      // Fetch columns for each selected table and bulk-add them
      const allCols: any[] = [];
      for (const tableName of selectedTables) {
        try {
          const schema = await api.getRegisteredTableSchema(String(selectedConn), tableName);
          const cols = Array.isArray(schema) ? schema : (schema?.columns || []);
          for (const col of cols) {
            const name = col.name || col.column_name || '';
            if (!name) continue;
            const dtype = (col.type || col.data_type || 'string').toLowerCase();
            const isNumeric = /int|float|double|decimal|number|numeric|bigint|real/i.test(dtype);
            allCols.push({
              physical_name: name,
              friendly_name: name.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()),
              column_type: isNumeric ? 'measure' : 'dimension',
              data_type: isNumeric ? 'number' : /date|time|timestamp/i.test(dtype) ? 'date' : 'string',
              aggregation: isNumeric ? 'sum' : '',
            });
          }
        } catch { /* skip table if schema fetch fails */ }
      }

      if (allCols.length > 0) {
        await api.bulkCreateDatasetColumns(ds.id, allCols);
      }

      onCreated();
    } catch (err: any) {
      setError(err?.message || 'Failed to create dataset');
    } finally {
      setCreating(false);
    }
  };

  const toggleTable = (name: string) => {
    setSelectedTables(prev =>
      prev.includes(name) ? prev.filter(t => t !== name) : [...prev, name]
    );
  };

  return (
    <Box sx={{ p: 3, maxWidth: 700, mx: 'auto' }}>
      <Button size="small" startIcon={<ArrowBackIcon />} sx={{ mb: 2 }}
        onClick={onSkip}>
        Back
      </Button>
      <Typography variant="h5" sx={{ mb: 0.5 }}>
        Set Up Data Source
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        {reportType === 'pivot' ? 'Pivot' : 'Tabular'} reports need a dataset.
        Let's create one from your data connections — it takes 30 seconds.
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Step 0: Pick connection */}
      <Paper sx={{ p: 3, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          1. Choose a connection
        </Typography>
        {connections.length === 0 ? (
          <Alert severity="warning">
            No connections configured.{' '}
            <Button size="small" variant="text" onClick={() => navigate('/connections')} sx={{ textTransform: 'none' }}>
              Set up a connection first
            </Button>
          </Alert>
        ) : (
          <FormControl fullWidth size="small">
            <InputLabel>Connection</InputLabel>
            <Select
              label="Connection"
              value={selectedConn ?? ''}
              onChange={e => {
                setSelectedConn(Number(e.target.value) || null);
                setSelectedTables([]);
                if (step < 1) setStep(1);
              }}
            >
              <MenuItem value=""><em>-- Select --</em></MenuItem>
              {connections.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.name || `Connection #${c.id}`}</MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
      </Paper>

      {/* Step 1: Pick tables */}
      {step >= 1 && selectedConn && (
        <Paper sx={{ p: 3, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            2. Select tables ({selectedTables.length} selected)
          </Typography>
          {loadingTables ? (
            <CircularProgress size={24} />
          ) : tables.length === 0 ? (
            <Alert severity="warning">
              No registered tables found for this connection. Register tables in the connection settings.
            </Alert>
          ) : (
            <Box sx={{ maxHeight: 200, overflow: 'auto', display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {tables.map((t: any) => {
                const name = t.name || t;
                const selected = selectedTables.includes(name);
                return (
                  <Chip
                    key={name}
                    label={name}
                    size="small"
                    color={selected ? 'primary' : 'default'}
                    variant={selected ? 'filled' : 'outlined'}
                    onClick={() => {
                      toggleTable(name);
                      if (step < 2) setStep(2);
                    }}
                    sx={{ cursor: 'pointer' }}
                  />
                );
              })}
            </Box>
          )}
        </Paper>
      )}

      {/* Step 2: Name + create */}
      {step >= 2 && selectedTables.length > 0 && (
        <Paper sx={{ p: 3, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            3. Name your dataset
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
            <TextField
              size="small" label="Dataset Name" fullWidth required
              value={dsName} onChange={e => setDsName(e.target.value)}
              placeholder="e.g., Sales Data"
            />
            <TextField
              size="small" label="Subject" sx={{ minWidth: 160 }} required
              value={dsSubject} onChange={e => setDsSubject(e.target.value)}
              placeholder="e.g., Sales"
            />
          </Box>
          <Button variant="contained" onClick={handleCreate} disabled={creating}>
            {creating ? 'Creating...' : 'Create Dataset & Continue'}
          </Button>
        </Paper>
      )}

      <Box sx={{ mt: 3 }}>
        <Typography variant="caption" color="text.secondary">
          Already have a dataset?{' '}
          <Button size="small" variant="text" sx={{ textTransform: 'none', p: 0, minWidth: 'auto' }}
            onClick={() => navigate('/datasets')}>
            Manage Datasets
          </Button>
        </Typography>
      </Box>
    </Box>
  );
};

// ── Inline Raw SQL Report Builder ───────────────────────────────────────────
// Minimal builder for raw_sql reports: pick saved query, set parameters, save.

interface RawSqlBuilderProps {
  reportId?: number;
}

const RawSqlReportBuilder: React.FC<RawSqlBuilderProps> = ({ reportId }) => {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [savedQueries, setSavedQueries] = useState<any[]>([]);
  const [sqlQueries, setSqlQueries] = useState<any[]>([]);
  const [sqlFiles, setSqlFiles] = useState<any[]>([]);
  const [selectedSavedQuery, setSelectedSavedQuery] = useState<number | null>(null);
  const [selectedSqlQuery, setSelectedSqlQuery] = useState<number | null>(null);
  const [selectedSqlFile, setSelectedSqlFile] = useState<number | null>(null);
  // Phase 131 deep-dive #13: 'sqlfile' added — pick a published .sql file
  // (SqlFile) as the report source.  Backend resolves the file content
  // to sql_override + connection_override_id at execution time.
  const [sourceType, setSourceType] = useState<'parquet' | 'sql' | 'sqlfile'>('parquet');
  const [parameters, setParameters] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Load available queries + existing report if editing
  useEffect(() => {
    const loads: Promise<any>[] = [
      api.listQueries(true).catch(() => []),
      api.listSqlQueries ? api.listSqlQueries().catch(() => []) : Promise.resolve([]),
      api.sqlFiles && api.sqlFiles.list
        ? api.sqlFiles.list().catch(() => [])
        : Promise.resolve([]),
    ];

    if (reportId) {
      loads.push(api.getBusinessReport(reportId).catch(() => null));
    }

    Promise.all(loads).then(([sq, sqlq, sf, existing]) => {
      setSavedQueries(Array.isArray(sq) ? sq : []);
      setSqlQueries(Array.isArray(sqlq) ? sqlq : []);
      setSqlFiles(Array.isArray(sf) ? sf : []);

      if (existing) {
        setName(existing.name || '');
        setDescription(existing.description || '');
        setParameters(existing.raw_parameters_schema || []);
        if (existing.raw_saved_query_id) {
          setSourceType('parquet');
          setSelectedSavedQuery(existing.raw_saved_query_id);
        } else if (existing.raw_sql_saved_query_id) {
          setSourceType('sql');
          setSelectedSqlQuery(existing.raw_sql_saved_query_id);
        } else if (existing.raw_sql_file_id) {
          setSourceType('sqlfile');
          setSelectedSqlFile(existing.raw_sql_file_id);
        }
      }
    }).finally(() => setLoading(false));
  }, [reportId]);

  const handleSave = async () => {
    if (!name.trim()) { setError('Name is required'); return; }
    if (sourceType === 'parquet' && !selectedSavedQuery) { setError('Select a saved query'); return; }
    if (sourceType === 'sql' && !selectedSqlQuery) { setError('Select a SQL query'); return; }
    if (sourceType === 'sqlfile' && !selectedSqlFile) { setError('Select a published .sql file'); return; }

    setSaving(true);
    setError('');

    const data: any = {
      name: name.trim(),
      description,
      data_source_type: 'raw_sql',
      dataset_id: 0,
      raw_saved_query_id: sourceType === 'parquet' ? selectedSavedQuery : null,
      raw_sql_saved_query_id: sourceType === 'sql' ? selectedSqlQuery : null,
      raw_sql_file_id: sourceType === 'sqlfile' ? selectedSqlFile : null,
      raw_parameters_schema: parameters,
    };

    try {
      if (reportId) {
        await api.updateBusinessReport(reportId, data);
        navigate(`/business-reports/${reportId}`);
      } else {
        const created = await api.createBusinessReport(data);
        navigate(`/business-reports/${created.id}`);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to save report');
    } finally {
      setSaving(false);
    }
  };

  const addParameter = () => {
    setParameters(prev => [...prev, {
      name: '', label: '', type: 'string', required: false, default_value: '', options: [],
    }]);
  };

  const updateParam = (idx: number, field: string, value: any) => {
    setParameters(prev => prev.map((p, i) => i === idx ? { ...p, [field]: value } : p));
  };

  const removeParam = (idx: number) => {
    setParameters(prev => prev.filter((_, i) => i !== idx));
  };

  if (loading) return builderFallback;

  return (
    <Box sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <Button size="small" startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/business-reports')}>
          Back to Reports
        </Button>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>
          {reportId ? 'Edit Saved Query Report' : 'New Saved Query Report'}
        </Typography>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }} icon={<HelpOutlineIcon />}>
        A Saved Query Report wraps an existing query (from the Query Builder or SQL Query page) as a
        reusable report. Users fill in parameters before each run — great for recurring reports.
      </Alert>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="subtitle1" gutterBottom>Report Details</Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField
            label="Report Name"
            required
            size="small"
            fullWidth
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g., Monthly Sales by Region"
          />
          <TextField
            label="Description"
            size="small"
            fullWidth
            multiline
            minRows={2}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="What does this report show? Who is the audience?"
          />
        </Box>
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
          <Typography variant="subtitle1">Data Source</Typography>
          <Tooltip title="Choose where the data comes from. 'Data Query' uses a saved query from the Query Builder (results stored as Parquet). 'SQL Query' runs live SQL from the SQL Query page each time.">
            <HelpOutlineIcon fontSize="small" sx={{ color: 'text.secondary', cursor: 'help' }} />
          </Tooltip>
        </Box>
        <ToggleButtonGroup
          value={sourceType}
          exclusive
          onChange={(_, v) => { if (v) setSourceType(v); }}
          size="small"
          sx={{ mb: 2 }}
        >
          <ToggleButton value="parquet">Data Query (Query Builder)</ToggleButton>
          <ToggleButton value="sql">SQL Query</ToggleButton>
          <ToggleButton value="sqlfile">Published .sql File</ToggleButton>
        </ToggleButtonGroup>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>
          {sourceType === 'parquet'
            ? 'Select a saved query from the Query Builder. Results are pre-computed and stored as Parquet files for fast access.'
            : sourceType === 'sql'
            ? 'Select a SQL query from the SQL Query page. The query runs live against the database each time the report is executed.'
            : <>Select a published .sql file. The file content runs live against its bound connection each time the report is executed. <a href="/docs/published-sql-file-as-report.html" target="_blank" rel="noreferrer">Learn more</a></>}
        </Typography>

        {sourceType === 'parquet' && (
          <FormControl fullWidth size="small">
            <InputLabel>Saved Query</InputLabel>
            <Select
              label="Saved Query"
              value={selectedSavedQuery ?? ''}
              onChange={e => setSelectedSavedQuery(Number(e.target.value) || null)}
            >
              <MenuItem value="">
                <em>-- Select a saved query --</em>
              </MenuItem>
              {savedQueries.map((q: any) => (
                <MenuItem key={q.id} value={q.id}>{q.name || `Query #${q.id}`}</MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
        {sourceType === 'sql' && (
          <FormControl fullWidth size="small">
            <InputLabel>SQL Query</InputLabel>
            <Select
              label="SQL Query"
              value={selectedSqlQuery ?? ''}
              onChange={e => setSelectedSqlQuery(Number(e.target.value) || null)}
            >
              <MenuItem value="">
                <em>-- Select a SQL query --</em>
              </MenuItem>
              {sqlQueries.map((q: any) => (
                <MenuItem key={q.id} value={q.id}>{q.name || `SQL #${q.id}`}</MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
        {sourceType === 'sqlfile' && (
          <FormControl fullWidth size="small">
            <InputLabel>Published .sql File</InputLabel>
            <Select
              label="Published .sql File"
              value={selectedSqlFile ?? ''}
              onChange={e => setSelectedSqlFile(Number(e.target.value) || null)}
            >
              <MenuItem value="">
                <em>-- Select a published .sql file --</em>
              </MenuItem>
              {sqlFiles.length === 0 && (
                <MenuItem value="" disabled>
                  <em>No .sql files found — create one from the SQL Query page (Save .sql)</em>
                </MenuItem>
              )}
              {sqlFiles.map((f: any) => (
                <MenuItem key={f.id} value={f.id}>
                  {f.name || `SqlFile #${f.id}`}
                  {f.connection_id ? ` (conn ${f.connection_id})` : ''}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
          <Typography variant="subtitle1" sx={{ flexGrow: 1 }}>Parameters</Typography>
          <Button size="small" variant="outlined" onClick={addParameter}>+ Add Parameter</Button>
        </Box>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
          Parameters let users fill in values before running. Use {'{{param_name}}'} in your query to reference them.
        </Typography>
        {parameters.length === 0 ? (
          <Paper variant="outlined" sx={{ p: 2, textAlign: 'center', bgcolor: 'action.hover' }}>
            <Typography variant="body2" color="text.secondary">
              No parameters defined. Click "+ Add Parameter" to let users provide input before each run.
            </Typography>
          </Paper>
        ) : (
          parameters.map((p, idx) => (
            <Paper key={idx} variant="outlined" sx={{ p: 1.5, mb: 1.5, display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField
                size="small" label="Name" value={p.name}
                onChange={e => updateParam(idx, 'name', e.target.value)}
                sx={{ flex: 1 }}
                placeholder="e.g., start_date"
              />
              <TextField
                size="small" label="Label" value={p.label}
                onChange={e => updateParam(idx, 'label', e.target.value)}
                sx={{ flex: 1 }}
                placeholder="e.g., Start Date"
              />
              <FormControl size="small" sx={{ minWidth: 110 }}>
                <InputLabel>Type</InputLabel>
                <Select
                  label="Type"
                  value={p.type}
                  onChange={e => updateParam(idx, 'type', e.target.value)}
                >
                  <MenuItem value="string">String</MenuItem>
                  <MenuItem value="number">Number</MenuItem>
                  <MenuItem value="date">Date</MenuItem>
                  <MenuItem value="boolean">Boolean</MenuItem>
                  <MenuItem value="select">Select</MenuItem>
                </Select>
              </FormControl>
              <TextField
                size="small" label="Default" value={p.default_value || ''}
                onChange={e => updateParam(idx, 'default_value', e.target.value)}
                sx={{ width: 120 }}
              />
              <IconButton size="small" color="error" onClick={() => removeParam(idx)}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Paper>
          ))
        )}
      </Paper>

      <Box sx={{ display: 'flex', gap: 2 }}>
        <Button variant="outlined" onClick={() => navigate('/business-reports')}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : (reportId ? 'Update Report' : 'Create Report')}
        </Button>
      </Box>
    </Box>
  );
};

export default UnifiedReportBuilder;
