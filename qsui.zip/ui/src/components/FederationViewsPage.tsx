/**
 * FederationViewsPage — Admin CRUD for cross-connection saved queries (Phase 93).
 *
 * Users can create named "Oracle-style views" that JOIN or UNION results from
 * two different S3 connections.  These views can then be published as APIs or
 * used as data sources in business reports.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Select, MenuItem, FormControl, InputLabel, Chip, Alert,
  CircularProgress, Tooltip, Switch, FormControlLabel, Divider,
  TableContainer, Grid, Autocomplete,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import PreviewIcon from '@mui/icons-material/Visibility';
import PublishIcon from '@mui/icons-material/CloudUpload';
import StorageIcon from '@mui/icons-material/Storage';
import api from '../services/api';
// BF-489 (2026-05-27) — Federation Views can now be published as APIs
// directly from this page.  Backend (source_type="federation") +
// PublishViewDialog already supported this since Phase 93 — only the
// frontend button was missing.  Mounts the same dialog the other 4
// entry points use; the dialog handles federation-specific branches
// internally (preview disabled, payload sends federation_view_id).
import PublishViewDialog from './PublishViewDialog';

interface FederationView {
  id: number;
  name: string;
  description: string;
  primary_conn_id: number;
  primary_query: Record<string, any>;
  secondary_conn_id: number;
  secondary_query: Record<string, any>;
  combine_mode: string;
  join_on: Array<{ left: string; right: string }>;
  join_how: string;
  output_columns: string[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  // Phase 97 materialization fields
  status?: string;
  row_count?: number;
  column_count?: number;
  file_size_bytes?: number;
  last_materialized?: string;
  last_error?: string;
  schema_cache?: any[];
}

interface Connection {
  id: number;
  name: string;
  connection_type: string;
  config?: Record<string, any>;
}

const EMPTY_VIEW: Partial<FederationView> = {
  name: '',
  description: '',
  primary_conn_id: 0,
  primary_query: { files: [], filters: [], columns: [] },
  secondary_conn_id: 0,
  secondary_query: { files: [], filters: [], columns: [] },
  combine_mode: 'union',
  join_on: [],
  join_how: 'inner',
  output_columns: [],
  is_active: true,
};

const FederationViewsPage: React.FC = () => {
  const [views, setViews] = useState<FederationView[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editView, setEditView] = useState<Partial<FederationView> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [previewData, setPreviewData] = useState<any>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [primaryTables, setPrimaryTables] = useState<any[]>([]);
  const [secondaryTables, setSecondaryTables] = useState<any[]>([]);
  const [materializingIds, setMaterializingIds] = useState<Set<number>>(new Set());
  const [primarySchema, setPrimarySchema] = useState<any[]>([]);
  const [secondarySchema, setSecondarySchema] = useState<any[]>([]);
  // BF-489 — Publish-as-API dialog state.  Holds the FV we're publishing
  // (null = dialog closed).
  const [publishFv, setPublishFv] = useState<FederationView | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [fvs, conns] = await Promise.all([
        api.listFederationViews(),
        api.listConnections(),
      ]);
      setViews(fvs);
      setConnections(conns);
    } catch (e: any) {
      setError(e.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Load registered tables when connection changes
  const loadRegisteredTables = useCallback((connId: number, side: 'primary' | 'secondary') => {
    const conn = connections.find(c => c.id === connId);
    const tables = conn?.config?.registered_tables || [];
    if (side === 'primary') setPrimaryTables(tables);
    else setSecondaryTables(tables);
  }, [connections]);

  // Load column schema for join column dropdowns
  const loadSchemaForSide = useCallback(async (connId: number, files: string[], side: 'primary' | 'secondary') => {
    if (!connId || !files?.length) {
      if (side === 'primary') setPrimarySchema([]);
      else setSecondarySchema([]);
      return;
    }
    try {
      // Use first selected table's schema
      const tableName = files[0]?.replace('__registered__:', '') || '';
      if (!tableName) return;
      const schema = await api.getRegisteredTableSchema(String(connId), tableName);
      const cols = (schema?.columns || []).map((c: any) => ({ name: c.name, type: c.type || '' }));
      if (side === 'primary') setPrimarySchema(cols);
      else setSecondarySchema(cols);
    } catch {
      // Silently fail — user can still type manually (freeSolo)
    }
  }, []);

  const handleMaterialize = async (fv: FederationView) => {
    setMaterializingIds(prev => new Set(prev).add(fv.id));
    try {
      await api.materializeFederationView(fv.id);
      loadData();
    } catch (e: any) {
      setError(e.message || 'Materialize failed');
    } finally {
      setMaterializingIds(prev => { const n = new Set(prev); n.delete(fv.id); return n; });
    }
  };

  const handleCreate = () => {
    setEditView({ ...EMPTY_VIEW });
    setPrimarySchema([]);
    setSecondarySchema([]);
    setError('');
    setDialogOpen(true);
  };

  const handleEdit = (fv: FederationView) => {
    setEditView({ ...fv });
    setError('');
    loadRegisteredTables(fv.primary_conn_id, 'primary');
    loadRegisteredTables(fv.secondary_conn_id, 'secondary');
    // Load column schemas for join column dropdowns
    loadSchemaForSide(fv.primary_conn_id, fv.primary_query?.files || [], 'primary');
    loadSchemaForSide(fv.secondary_conn_id, fv.secondary_query?.files || [], 'secondary');
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!editView?.name?.trim()) { setError('Name is required'); return; }
    if (!editView.primary_conn_id) { setError('Primary connection is required'); return; }
    if (!editView.secondary_conn_id) { setError('Secondary connection is required'); return; }

    setSaving(true);
    setError('');
    try {
      if (editView.id) {
        await api.updateFederationView(editView.id, editView);
      } else {
        await api.createFederationView(editView as any);
      }
      setDialogOpen(false);
      setEditView(null);
      loadData();
    } catch (e: any) {
      setError(e.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.deleteFederationView(id);
      setDeleteConfirm(null);
      loadData();
    } catch (e: any) {
      setError(e.message || 'Delete failed');
    }
  };

  const handlePreview = async (id: number) => {
    setPreviewLoading(true);
    setPreviewOpen(true);
    setPreviewData(null);
    try {
      const result = await api.previewFederationView(id);
      setPreviewData(result);
    } catch (e: any) {
      setPreviewData({ error: e.message || 'Preview failed' });
    } finally {
      setPreviewLoading(false);
    }
  };

  const getConnName = (id: number) =>
    connections.find(c => c.id === id)?.name || `Connection #${id}`;

  // Add/remove join_on entries
  const addJoinColumn = () => {
    if (!editView) return;
    setEditView({
      ...editView,
      join_on: [...(editView.join_on || []), { left: '', right: '' }],
    });
  };
  const removeJoinColumn = (idx: number) => {
    if (!editView) return;
    const newJoin = [...(editView.join_on || [])];
    newJoin.splice(idx, 1);
    setEditView({ ...editView, join_on: newJoin });
  };
  const updateJoinColumn = (idx: number, field: 'left' | 'right', value: string) => {
    if (!editView) return;
    const newJoin = [...(editView.join_on || [])];
    newJoin[idx] = { ...newJoin[idx], [field]: value };
    setEditView({ ...editView, join_on: newJoin });
  };

  // Helper: update query files for a side (also triggers schema load for join dropdowns)
  const updateQueryFiles = (side: 'primary' | 'secondary', tableName: string, add: boolean) => {
    if (!editView) return;
    const key = side === 'primary' ? 'primary_query' : 'secondary_query';
    const connKey = side === 'primary' ? 'primary_conn_id' : 'secondary_conn_id';
    const query = { ...(editView[key] || { files: [], filters: [], columns: [] }) };
    const path = `__registered__:${tableName}`;
    if (add) {
      query.files = [...(query.files || []), path];
    } else {
      query.files = (query.files || []).filter((f: string) => f !== path);
    }
    setEditView({ ...editView, [key]: query });
    // Refresh column schema for join column dropdowns
    const connId = editView[connKey] as number;
    if (connId) loadSchemaForSide(connId, query.files, side);
  };

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Federation Views</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={handleCreate}>
          Create View
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Primary</TableCell>
              <TableCell>Secondary</TableCell>
              <TableCell>Mode</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Created</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {views.length === 0 && (
              <TableRow><TableCell colSpan={9} align="center">No federation views yet</TableCell></TableRow>
            )}
            {views.map(fv => (
              <TableRow key={fv.id} hover>
                <TableCell><strong>{fv.name}</strong></TableCell>
                <TableCell>{fv.description || '—'}</TableCell>
                <TableCell><Chip label={getConnName(fv.primary_conn_id)} size="small" /></TableCell>
                <TableCell><Chip label={getConnName(fv.secondary_conn_id)} size="small" /></TableCell>
                <TableCell>
                  <Chip
                    label={fv.combine_mode === 'join' ? `${fv.join_how.toUpperCase()} JOIN` : 'UNION'}
                    size="small"
                    color={fv.combine_mode === 'join' ? 'primary' : 'secondary'}
                  />
                </TableCell>
                <TableCell>
                  {(() => {
                    const st = fv.status || 'virtual';
                    const colorMap: Record<string, 'default' | 'warning' | 'success' | 'error'> = {
                      virtual: 'default', materializing: 'warning', ready: 'success', failed: 'error',
                    };
                    return (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Chip label={st.toUpperCase()} size="small" color={colorMap[st] || 'default'} />
                        {st === 'ready' && fv.row_count != null && (
                          <Typography variant="caption" color="text.secondary">
                            {fv.row_count.toLocaleString()} rows
                          </Typography>
                        )}
                      </Box>
                    );
                  })()}
                </TableCell>
                <TableCell>{fv.is_active ? 'Yes' : 'No'}</TableCell>
                <TableCell>{fv.created_at ? new Date(fv.created_at).toLocaleDateString() : ''}</TableCell>
                <TableCell align="right">
                  <Tooltip title="Materialize to Parquet">
                    <span>
                      <IconButton
                        size="small"
                        color="success"
                        onClick={() => handleMaterialize(fv)}
                        disabled={materializingIds.has(fv.id)}
                      >
                        {materializingIds.has(fv.id) ? <CircularProgress size={18} /> : <StorageIcon />}
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Preview"><IconButton size="small" onClick={() => handlePreview(fv.id)}><PreviewIcon /></IconButton></Tooltip>
                  {/* BF-489 — Publish as API.  Only offered for active
                      Federation Views since the consumer-facing endpoint
                      will refuse to execute against a deactivated FV. */}
                  {fv.is_active && (
                    <Tooltip title="Publish as API">
                      <IconButton
                        size="small"
                        color="primary"
                        onClick={() => setPublishFv(fv)}
                      >
                        <PublishIcon />
                      </IconButton>
                    </Tooltip>
                  )}
                  <Tooltip title="Edit"><IconButton size="small" onClick={() => handleEdit(fv)}><EditIcon /></IconButton></Tooltip>
                  <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setDeleteConfirm(fv.id)}><DeleteIcon /></IconButton></Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* BF-489 — Publish-as-API dialog.  Mounted with sourceType='federation'
          + federationViewId; the dialog sends the right backend payload
          (source_type='federation', federation_view_id=<id>) on submit.
          Columns prop fed from output_columns OR schema_cache so the
          WHERE-clause editor's column dropdown isn't empty (federation
          source has no live preview to populate it from). */}
      {publishFv && (
        <PublishViewDialog
          open={!!publishFv}
          onClose={() => setPublishFv(null)}
          queryName={publishFv.name || ''}
          sourceType="federation"
          federationViewId={publishFv.id}
          columns={
            (publishFv.output_columns && publishFv.output_columns.length > 0)
              ? publishFv.output_columns
              : (publishFv.schema_cache || [])
                  .map((c: any) => (typeof c === 'string' ? c : c?.name))
                  .filter((s: any): s is string => typeof s === 'string' && !!s)
          }
        />
      )}

      {/* ── Create / Edit Dialog ──────────────────────────────────────────── */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editView?.id ? 'Edit Federation View' : 'Create Federation View'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <TextField
            label="View Name"
            fullWidth
            margin="dense"
            value={editView?.name || ''}
            onChange={e => setEditView({ ...editView!, name: e.target.value })}
          />
          <TextField
            label="Description"
            fullWidth
            margin="dense"
            multiline
            rows={2}
            value={editView?.description || ''}
            onChange={e => setEditView({ ...editView!, description: e.target.value })}
          />

          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" gutterBottom>Primary Connection (Left Side)</Typography>

          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <FormControl fullWidth margin="dense" size="small">
                <InputLabel>Primary Connection</InputLabel>
                <Select
                  value={editView?.primary_conn_id || 0}
                  label="Primary Connection"
                  onChange={e => {
                    const cid = Number(e.target.value);
                    setEditView({ ...editView!, primary_conn_id: cid });
                    loadRegisteredTables(cid, 'primary');
                  }}
                >
                  <MenuItem value={0} disabled>Select...</MenuItem>
                  {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                </Select>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Typography variant="caption" color="text.secondary">
                Tables: {(editView?.primary_query?.files || []).map((f: string) =>
                  f.replace('__registered__:', '')
                ).join(', ') || 'none selected'}
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                {primaryTables.map((t: any) => {
                  const selected = (editView?.primary_query?.files || []).includes(`__registered__:${t.name}`);
                  return (
                    <Chip
                      key={t.name}
                      label={t.name}
                      size="small"
                      color={selected ? 'primary' : 'default'}
                      variant={selected ? 'filled' : 'outlined'}
                      onClick={() => updateQueryFiles('primary', t.name, !selected)}
                    />
                  );
                })}
              </Box>
            </Grid>
          </Grid>

          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" gutterBottom>Secondary Connection (Right Side)</Typography>

          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <FormControl fullWidth margin="dense" size="small">
                <InputLabel>Secondary Connection</InputLabel>
                <Select
                  value={editView?.secondary_conn_id || 0}
                  label="Secondary Connection"
                  onChange={e => {
                    const cid = Number(e.target.value);
                    setEditView({ ...editView!, secondary_conn_id: cid });
                    loadRegisteredTables(cid, 'secondary');
                  }}
                >
                  <MenuItem value={0} disabled>Select...</MenuItem>
                  {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                </Select>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Typography variant="caption" color="text.secondary">
                Tables: {(editView?.secondary_query?.files || []).map((f: string) =>
                  f.replace('__registered__:', '')
                ).join(', ') || 'none selected'}
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                {secondaryTables.map((t: any) => {
                  const selected = (editView?.secondary_query?.files || []).includes(`__registered__:${t.name}`);
                  return (
                    <Chip
                      key={t.name}
                      label={t.name}
                      size="small"
                      color={selected ? 'secondary' : 'default'}
                      variant={selected ? 'filled' : 'outlined'}
                      onClick={() => updateQueryFiles('secondary', t.name, !selected)}
                    />
                  );
                })}
              </Box>
            </Grid>
          </Grid>

          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" gutterBottom>Combine Mode</Typography>

          <Grid container spacing={2} alignItems="center">
            <Grid size={{ xs: 12, md: 4 }}>
              <FormControl fullWidth margin="dense" size="small">
                <InputLabel>Mode</InputLabel>
                <Select
                  value={editView?.combine_mode || 'union'}
                  label="Mode"
                  onChange={e => setEditView({ ...editView!, combine_mode: e.target.value })}
                >
                  <MenuItem value="union">UNION (stack rows)</MenuItem>
                  <MenuItem value="join">JOIN (match columns)</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            {editView?.combine_mode === 'join' && (
              <Grid size={{ xs: 12, md: 4 }}>
                <FormControl fullWidth margin="dense" size="small">
                  <InputLabel>Join Type</InputLabel>
                  <Select
                    value={editView?.join_how || 'inner'}
                    label="Join Type"
                    onChange={e => setEditView({ ...editView!, join_how: e.target.value })}
                  >
                    <MenuItem value="inner">INNER JOIN</MenuItem>
                    <MenuItem value="left">LEFT JOIN</MenuItem>
                    <MenuItem value="right">RIGHT JOIN</MenuItem>
                    <MenuItem value="full">FULL OUTER JOIN</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            )}
          </Grid>

          {editView?.combine_mode === 'join' && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="caption" gutterBottom>Join Column Mapping</Typography>
              {(editView.join_on || []).map((jo, idx) => (
                <Grid container spacing={1} key={idx} sx={{ mb: 1 }} alignItems="center">
                  <Grid size={{ xs: 5 }}>
                    <Autocomplete
                      size="small"
                      freeSolo
                      options={primarySchema}
                      getOptionLabel={(opt: any) => typeof opt === 'string' ? opt : `${opt.name} (${opt.type})`}
                      value={jo.left || ''}
                      onInputChange={(_e, val) => updateJoinColumn(idx, 'left', val)}
                      onChange={(_e, val) => updateJoinColumn(idx, 'left', typeof val === 'string' ? val : val?.name || '')}
                      // BF-490 — popper auto-resize for long "name (type)" labels.
                      slotProps={{
                        popper: {
                          sx: {
                            width: 'auto !important',
                            minWidth: '100%',
                            maxWidth: 'min(600px, 90vw)',
                            '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                            '& .MuiAutocomplete-option': {
                              whiteSpace: 'normal', wordBreak: 'break-word',
                            },
                          },
                        },
                      }}
                      renderInput={(params) => <TextField {...params} placeholder="Primary column" />}
                    />
                  </Grid>
                  <Grid size={{ xs: 1 }}>
                    <Typography align="center">=</Typography>
                  </Grid>
                  <Grid size={{ xs: 5 }}>
                    <Autocomplete
                      size="small"
                      freeSolo
                      options={secondarySchema}
                      getOptionLabel={(opt: any) => typeof opt === 'string' ? opt : `${opt.name} (${opt.type})`}
                      value={jo.right || ''}
                      onInputChange={(_e, val) => updateJoinColumn(idx, 'right', val)}
                      onChange={(_e, val) => updateJoinColumn(idx, 'right', typeof val === 'string' ? val : val?.name || '')}
                      // BF-490 — popper auto-resize.
                      slotProps={{
                        popper: {
                          sx: {
                            width: 'auto !important',
                            minWidth: '100%',
                            maxWidth: 'min(600px, 90vw)',
                            '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                            '& .MuiAutocomplete-option': {
                              whiteSpace: 'normal', wordBreak: 'break-word',
                            },
                          },
                        },
                      }}
                      renderInput={(params) => <TextField {...params} placeholder="Secondary column" />}
                    />
                  </Grid>
                  <Grid size={{ xs: 1 }}>
                    <IconButton size="small" color="error" onClick={() => removeJoinColumn(idx)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Grid>
                </Grid>
              ))}
              <Button size="small" onClick={addJoinColumn}>+ Add Column</Button>
            </Box>
          )}

          <FormControlLabel
            control={
              <Switch
                checked={editView?.is_active !== false}
                onChange={e => setEditView({ ...editView!, is_active: e.target.checked })}
              />
            }
            label="Active"
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} /> : (editView?.id ? 'Update' : 'Create')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Preview Dialog ────────────────────────────────────────────────── */}
      <Dialog open={previewOpen} onClose={() => setPreviewOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle>Preview Results</DialogTitle>
        <DialogContent>
          {previewLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress /></Box>}
          {previewData?.error && <Alert severity="error">{previewData.error}</Alert>}
          {previewData && !previewData.error && (
            <>
              {/* BF-565 (2026-05-29): consume BF-525 type_mismatches
                  signal.  When the federation engine auto-promoted
                  cross-side type mismatches (e.g. DECIMAL ↔ FLOAT),
                  surface a warning so the user knows downstream
                  aggregations may have lost precision. */}
              {Array.isArray(previewData.type_mismatches) && previewData.type_mismatches.length > 0 && (
                <Alert severity="warning" sx={{ mb: 1 }}>
                  <strong>Type mismatch across sides:</strong> DuckDB auto-promoted these columns and
                  downstream aggregations may have lost precision —
                  <ul style={{ margin: '4px 0 0 0', paddingLeft: 18 }}>
                    {previewData.type_mismatches.map((m: string, i: number) => (
                      <li key={i}><code>{m}</code></li>
                    ))}
                  </ul>
                </Alert>
              )}
              <Typography variant="body2" sx={{ mb: 1 }}>
                Total: {previewData.total_rows} rows | Showing: {previewData.returned_rows}
              </Typography>
              <TableContainer component={Paper} sx={{ maxHeight: 400 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      {(previewData.columns || []).map((c: any) => (
                        <TableCell key={c.name}><strong>{c.name}</strong></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {(previewData.data || []).map((row: any, ri: number) => (
                      <TableRow key={ri}>
                        {(previewData.columns || []).map((c: any) => (
                          <TableCell key={c.name}>
                            {row[c.name] != null ? String(row[c.name]).slice(0, 100) : ''}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* ── Delete Confirmation ───────────────────────────────────────────── */}
      <Dialog open={deleteConfirm !== null} onClose={() => setDeleteConfirm(null)}>
        <DialogTitle>Delete Federation View?</DialogTitle>
        <DialogContent>
          <Typography>This action cannot be undone. Published views and business reports using this federation view will stop working.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteConfirm(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default FederationViewsPage;
