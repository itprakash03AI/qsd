import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  Table, TableHead, TableRow, TableCell, TableBody,
  Typography, IconButton, Tooltip, CircularProgress,
  Box, Alert, Chip,
} from '@mui/material';
import { Restore as RestoreIcon, History as HistoryIcon } from '@mui/icons-material';
import api from '../services/api';
import { toArray } from '../utils/toArray';

interface Props {
  queryId: number | string;
  queryName: string;
  open: boolean;
  onClose: () => void;
  onRestored: () => void;
}

export default function QueryVersionHistory({ queryId, queryName, open, onClose, onRestored }: Props) {
  const [versions, setVersions] = useState<any[]>([]);
  const [loading, setLoading]   = useState(false);
  const [restoring, setRestoring] = useState<number | null>(null);
  const [error, setError]       = useState('');

  useEffect(() => {
    if (open && queryId) {
      setLoading(true);
      setError('');
      api.listQueryVersions(queryId)
        .then(d => setVersions(toArray(d)))
        .catch(() => setError('Failed to load version history'))
        .finally(() => setLoading(false));
    }
  }, [open, queryId]);

  const handleRestore = async (versionId: number) => {
    setRestoring(versionId);
    try {
      await api.restoreQueryVersion(queryId, versionId);
      onRestored();
      onClose();
    } catch {
      setError('Failed to restore version');
    } finally {
      setRestoring(null);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, fontWeight: 700 }}>
        <HistoryIcon color="primary" />
        Version History — {queryName}
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : versions.length === 0 ? (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
            No version history yet. Versions are saved automatically each time you update a query.
          </Typography>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow sx={{ background: '#f8fafc' }}>
                <TableCell sx={{ fontWeight: 600 }}>Version</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Changed By</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Note</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {versions.map((v: any, idx: number) => (
                <TableRow key={v.id} hover>
                  <TableCell>
                    <Chip label={`v${v.version_number}`} size="small"
                          color={idx === 0 ? 'primary' : 'default'} />
                  </TableCell>
                  <TableCell>{v.name || '—'}</TableCell>
                  <TableCell>{v.changed_by || '—'}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap', fontSize: 12 }}>
                    {v.changed_at
                      ? new Date(v.changed_at).toLocaleString()
                      : '—'}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                    {v.change_note || '—'}
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Restore this version">
                      <span>
                        <IconButton
                          size="small"
                          onClick={() => handleRestore(v.id)}
                          disabled={restoring === v.id}
                        >
                          {restoring === v.id
                            ? <CircularProgress size={16} />
                            : <RestoreIcon fontSize="small" />}
                        </IconButton>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
