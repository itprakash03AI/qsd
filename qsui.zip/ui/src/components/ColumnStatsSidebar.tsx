/**
 * Column Stats Sidebar — Snowsight-style result-grid sidebar.
 *
 * Shows per-column profile (distinct/null/min/max + histogram + top values)
 * for the most recently executed query.  Powered by the backend endpoint
 * GET /api/executions/{id}/column-stats which reads the result parquet via
 * DuckDB and returns precomputed stats.
 *
 * Why this exists: cloud warehouse competitors (Snowsight, Databricks)
 * surface column profiles next to result grids so analysts don't have to
 * write `SELECT MIN(x), MAX(x), COUNT(DISTINCT x) FROM result` themselves.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Typography, IconButton, CircularProgress, Tooltip, Chip,
  TextField, InputAdornment, Divider, Stack, Skeleton, Drawer,
} from '@mui/material';
import {
  Close as CloseIcon, Search as SearchIcon, Refresh as RefreshIcon,
  BarChart as BarChartIcon, Numbers as NumbersIcon,
  CalendarMonth as DateIcon, ToggleOn as BoolIcon,
  TextFields as TextIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip,
  ResponsiveContainer, Cell,
} from 'recharts';
import { API_BASE_URL } from '../services/api/core';

// ── Types — match backend response from /api/executions/{id}/column-stats ──
export interface ColumnStat {
  name: string;
  type: string;
  null_count: number;
  distinct_count: number;
  total: number;
  min?: number | string;
  max?: number | string;
  mean?: number;
  median?: number;
  stdev?: number;
  histogram?: { bucket: string; count: number }[];
  top_values?: { value: string; count: number }[];
  true_count?: number;
  false_count?: number;
}

export interface ColumnStatsResponse {
  available: boolean;
  reason?: string;
  execution_id?: string;
  row_count?: number;
  columns?: ColumnStat[];
}

// ── Helpers ─────────────────────────────────────────────────────────────────
const isNumeric = (s: ColumnStat) =>
  typeof s.mean === 'number' || s.histogram !== undefined;
const isTemporal = (s: ColumnStat) =>
  /DATE|TIMESTAMP|TIME/.test((s.type || '').toUpperCase());
const isBool = (s: ColumnStat) =>
  /BOOL/.test((s.type || '').toUpperCase());

const fmtPct = (part: number, whole: number) =>
  whole > 0 ? `${((100 * part) / whole).toFixed(1)}%` : '—';

const fmtNum = (v: any) => {
  if (v == null) return '—';
  const n = typeof v === 'number' ? v : parseFloat(v);
  if (isNaN(n)) return String(v);
  if (Math.abs(n) >= 1e6) return n.toExponential(2);
  if (Number.isInteger(n)) return n.toLocaleString();
  return n.toFixed(2);
};

const typeIcon = (s: ColumnStat) => {
  if (isBool(s))     return <BoolIcon fontSize="small" sx={{ color: '#7e57c2' }} />;
  if (isTemporal(s)) return <DateIcon fontSize="small" sx={{ color: '#26a69a' }} />;
  if (isNumeric(s))  return <NumbersIcon fontSize="small" sx={{ color: '#1976d2' }} />;
  return <TextIcon fontSize="small" sx={{ color: '#78909c' }} />;
};

// ── Per-column card ─────────────────────────────────────────────────────────
const ColumnStatCard: React.FC<{ stat: ColumnStat }> = ({ stat }) => {
  const total = stat.total || 0;
  const nullPct = total > 0 ? (100 * stat.null_count) / total : 0;

  return (
    <Box sx={{
      p: 1.25, mb: 1, borderRadius: 1.5,
      border: '1px solid', borderColor: 'divider',
      bgcolor: 'background.paper',
      transition: 'border-color 0.15s',
      '&:hover': { borderColor: 'primary.light' },
    }}>
      {/* Header row: name + type */}
      <Stack direction="row" spacing={0.75} alignItems="center" mb={0.75}>
        {typeIcon(stat)}
        <Typography variant="body2" fontWeight={600} sx={{
          flexGrow: 1,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {stat.name}
        </Typography>
        <Chip label={stat.type} size="small" sx={{
          height: 18, fontSize: 10, fontFamily: 'monospace',
        }} />
      </Stack>

      {/* Counts row */}
      <Stack direction="row" spacing={1.5} mb={0.75}>
        <Tooltip title={`${stat.distinct_count.toLocaleString()} unique values (approx.)`}>
          <Box>
            <Typography variant="caption" color="text.secondary">Distinct</Typography>
            <Typography variant="body2" fontWeight={500}>
              {stat.distinct_count.toLocaleString()}
            </Typography>
          </Box>
        </Tooltip>
        <Tooltip title={`${stat.null_count.toLocaleString()} null values`}>
          <Box>
            <Typography variant="caption" color="text.secondary">Null</Typography>
            <Typography variant="body2" fontWeight={500} sx={{
              color: nullPct > 10 ? 'warning.main' : 'text.primary',
            }}>
              {fmtPct(stat.null_count, total)}
            </Typography>
          </Box>
        </Tooltip>
      </Stack>

      {/* Numeric summary */}
      {isNumeric(stat) && (
        <Box sx={{ mb: stat.histogram ? 0.75 : 0 }}>
          <Stack direction="row" spacing={1.5} sx={{ flexWrap: 'wrap' }}>
            {stat.min !== undefined && (
              <Box>
                <Typography variant="caption" color="text.secondary">Min</Typography>
                <Typography variant="body2">{fmtNum(stat.min)}</Typography>
              </Box>
            )}
            {stat.max !== undefined && (
              <Box>
                <Typography variant="caption" color="text.secondary">Max</Typography>
                <Typography variant="body2">{fmtNum(stat.max)}</Typography>
              </Box>
            )}
            {stat.mean !== undefined && (
              <Box>
                <Typography variant="caption" color="text.secondary">Mean</Typography>
                <Typography variant="body2">{fmtNum(stat.mean)}</Typography>
              </Box>
            )}
            {stat.median !== undefined && (
              <Box>
                <Typography variant="caption" color="text.secondary">Median</Typography>
                <Typography variant="body2">{fmtNum(stat.median)}</Typography>
              </Box>
            )}
          </Stack>
        </Box>
      )}

      {/* Histogram for numeric */}
      {stat.histogram && stat.histogram.length > 0 && (
        <Box sx={{ height: 80, mt: 0.5, mx: -0.5 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stat.histogram} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
              <XAxis dataKey="bucket" hide />
              <YAxis hide />
              <RTooltip
                formatter={(v: any) => [v.toLocaleString(), 'count']}
                labelFormatter={(l) => `Range: ${l}`}
                contentStyle={{ fontSize: 11 }}
              />
              <Bar dataKey="count" fill="#42a5f5" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Box>
      )}

      {/* Boolean counts */}
      {isBool(stat) && (
        <Stack direction="row" spacing={1.5}>
          <Box>
            <Typography variant="caption" color="text.secondary">True</Typography>
            <Typography variant="body2">
              {(stat.true_count ?? 0).toLocaleString()} ({fmtPct(stat.true_count ?? 0, total)})
            </Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">False</Typography>
            <Typography variant="body2">
              {(stat.false_count ?? 0).toLocaleString()} ({fmtPct(stat.false_count ?? 0, total)})
            </Typography>
          </Box>
        </Stack>
      )}

      {/* Temporal range */}
      {isTemporal(stat) && (stat.min || stat.max) && (
        <Stack direction="row" spacing={1.5}>
          {stat.min !== undefined && (
            <Box>
              <Typography variant="caption" color="text.secondary">From</Typography>
              <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                {String(stat.min)}
              </Typography>
            </Box>
          )}
          {stat.max !== undefined && (
            <Box>
              <Typography variant="caption" color="text.secondary">To</Typography>
              <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                {String(stat.max)}
              </Typography>
            </Box>
          )}
        </Stack>
      )}

      {/* Top values for categorical / temporal */}
      {stat.top_values && stat.top_values.length > 0 && !isBool(stat) && (
        <Box sx={{ mt: 0.75 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.25 }}>
            Top values
          </Typography>
          {stat.top_values.slice(0, 5).map((tv, i) => {
            const pct = total > 0 ? (100 * tv.count) / total : 0;
            return (
              <Box key={i} sx={{ position: 'relative', mb: 0.25 }}>
                {/* Bar background */}
                <Box sx={{
                  position: 'absolute', inset: 0,
                  width: `${Math.min(100, pct)}%`,
                  bgcolor: 'primary.light', opacity: 0.18,
                  borderRadius: 0.5,
                }} />
                <Stack direction="row" spacing={0.5} sx={{
                  position: 'relative', px: 0.5, py: 0.25, fontSize: 11,
                }}>
                  <Box sx={{
                    flexGrow: 1, overflow: 'hidden',
                    textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>
                    {tv.value === '' ? <em>(empty)</em> : tv.value}
                  </Box>
                  <Box sx={{ color: 'text.secondary' }}>
                    {tv.count.toLocaleString()}
                  </Box>
                </Stack>
              </Box>
            );
          })}
        </Box>
      )}
    </Box>
  );
};

// ── Sidebar shell ───────────────────────────────────────────────────────────
export interface ColumnStatsSidebarProps {
  /** Execution ID to fetch stats for. Pass null to render a closed sidebar. */
  executionId: string | null;
  /** Toggle visibility */
  open: boolean;
  /** Close handler — called when the user clicks the X button */
  onClose: () => void;
  /** Optional: highlight a specific column (e.g. when user clicks a header) */
  focusedColumn?: string | null;
  /** Width in px (defaults to 320) */
  width?: number;
}

const ColumnStatsSidebar: React.FC<ColumnStatsSidebarProps> = ({
  executionId, open, onClose, focusedColumn, width = 320,
}) => {
  const [data, setData]       = useState<ColumnStatsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);
  const [filter, setFilter]   = useState('');

  const load = async () => {
    if (!executionId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/executions/${encodeURIComponent(executionId)}/column-stats`,
        { credentials: 'include' },
      );
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || `HTTP ${res.status}`);
      }
      const json: ColumnStatsResponse = await res.json();
      setData(json);
      if (!json.available) {
        setError(json.reason || 'Stats not yet available');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load column stats');
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  // Auto-load when opened with a fresh execution_id
  useEffect(() => {
    if (open && executionId) {
      load();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, executionId]);

  // Reorder: focused column first, then any matching the filter
  const filteredColumns = useMemo(() => {
    const cols = data?.columns || [];
    const f = filter.trim().toLowerCase();
    const matches = f
      ? cols.filter(c => c.name.toLowerCase().includes(f))
      : cols;
    if (!focusedColumn) return matches;
    const focused = matches.find(c => c.name === focusedColumn);
    if (!focused) return matches;
    return [focused, ...matches.filter(c => c.name !== focusedColumn)];
  }, [data, filter, focusedColumn]);

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      variant="persistent"
      data-testid="column-stats-sidebar"
      PaperProps={{
        sx: {
          width, display: 'flex', flexDirection: 'column',
          bgcolor: 'background.default', overflow: 'hidden',
        },
      }}
    >
      {/* Header */}
      <Stack direction="row" alignItems="center" spacing={1} sx={{ p: 1.25, pb: 1 }}>
        <BarChartIcon fontSize="small" sx={{ color: 'primary.main' }} />
        <Typography variant="subtitle2" fontWeight={600} flexGrow={1}>
          Column profile
        </Typography>
        {data?.row_count != null && (
          <Tooltip title="Result row count">
            <Chip
              label={`${data.row_count.toLocaleString()} rows`}
              size="small"
              sx={{ height: 20, fontSize: 11 }}
            />
          </Tooltip>
        )}
        <Tooltip title="Refresh">
          <IconButton size="small" onClick={load} disabled={loading || !executionId}>
            <RefreshIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Close">
          <IconButton size="small" onClick={onClose}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Stack>

      {/* Filter */}
      <Box sx={{ px: 1.25, pb: 1 }}>
        <TextField
          fullWidth size="small" placeholder="Filter columns…"
          value={filter} onChange={e => setFilter(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Divider />

      {/* Body */}
      <Box sx={{ flexGrow: 1, overflowY: 'auto', p: 1.25 }}>
        {loading && (
          <>
            <Skeleton variant="rounded" height={120} sx={{ mb: 1 }} />
            <Skeleton variant="rounded" height={120} sx={{ mb: 1 }} />
            <Skeleton variant="rounded" height={120} />
          </>
        )}

        {!loading && error && (
          <Typography variant="body2" color="text.secondary" sx={{ p: 1 }}>
            {error}
          </Typography>
        )}

        {!loading && !error && filteredColumns.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ p: 1 }}>
            No columns match "{filter}".
          </Typography>
        )}

        {!loading && filteredColumns.map(c => (
          <ColumnStatCard key={c.name} stat={c} />
        ))}
      </Box>
    </Drawer>
  );
};

export default ColumnStatsSidebar;
