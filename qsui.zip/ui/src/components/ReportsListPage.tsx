/**
 * Phase 56+111 — Unified Reports List Page
 *
 * Lists ALL report types (Tabular, Pivot, Saved Query) in one place.
 * Phase 111: consolidated from separate report pages.
 * Example cards with mini data preview — clicking opens the REAL seeded report
 * (auto-seeds if not yet created). No static preview dialogs.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Tooltip, CircularProgress,
  Alert, TextField, InputAdornment, Dialog, DialogTitle, DialogContent,
  DialogActions, Grid, Card, CardContent, CardActions, Divider, Skeleton,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  ContentCopy as DuplicateIcon,
  Search as SearchIcon,
  TableChart as TabularIcon,
  PivotTableChart as PivotIcon,
  Storage as QueryIcon,
  OpenInNew as OpenIcon,
  Assessment as AssessmentIcon,
  TrendingUp as TrendingUpIcon,
  Receipt as ReceiptIcon,
  AccountBalance as AccountBalanceIcon,
  AutoFixHigh as SeedIcon,
  PlayArrow as PlayArrowIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

/* ── Example report showcase — uses real column names from project data ── */

const EXAMPLE_REPORTS = [
  {
    name: 'P&L by Trading Book',
    type: 'tabular' as const,
    description: 'Profit & Loss summary by Book_id and Master_book_id — USD and functional currency amounts with trade counts per desk.',
    icon: TrendingUpIcon,
    color: '#1976d2',
    preview: {
      headers: ['Book_id', 'Master_book_id', 'USD_CURRENCY_AMOUNT', 'GBP_AMOUNT', 'Trades'],
      rows: [
        ['EQ-DESK-01', 'MASTER-EQ', '$12,450,800', '\u00a38,920,100', '1,342'],
        ['FI-DESK-03', 'MASTER-FI', '$8,910,200', '\u00a36,380,500', '876'],
        ['FX-DESK-07', 'MASTER-FX', '-$2,340,500', '-\u00a31,675,200', '2,105'],
      ],
    },
  },
  {
    name: 'FX Exposure by Currency & Book',
    type: 'pivot' as const,
    description: 'Cross-tab of transactional_currency_id vs Book_id — shows USD_CURRENCY_AMOUNT exposure and FX rate impact across desks.',
    icon: AssessmentIcon,
    color: '#9c27b0',
    preview: {
      headers: ['Currency', 'EQ-DESK-01', 'FI-DESK-03', 'FX-DESK-07'],
      rows: [
        ['EUR', '$4.2M', '$2.8M', '-$1.1M'],
        ['GBP', '$3.1M', '$1.9M', '-$0.8M'],
        ['JPY', '$1.8M', '$0.6M', '$2.4M'],
      ],
    },
  },
  {
    name: 'GL Account Hierarchy Summary',
    type: 'tabular' as const,
    description: 'SAP account drill-down from sap_acc_level1 to sap_account with USD and FUNCTIONAL_CURRENCY_AMOUNT — cost centre and profit centre view.',
    icon: AccountBalanceIcon,
    color: '#1976d2',
    preview: {
      headers: ['sap_acc_level1', 'sap_acc_level2', 'sap_account', 'USD_AMT', 'Cost Centre'],
      rows: [
        ['Assets', 'Securities', '40010100', '$24.5M', 'CC-100'],
        ['Assets', 'Derivatives', '40020300', '$18.2M', 'CC-200'],
        ['Liabilities', 'Repo', '50010100', '-$12.8M', 'CC-100'],
      ],
    },
  },
  {
    name: 'Position by Instrument & SEDOL',
    type: 'pivot' as const,
    description: 'Investment positions grouped by sedol and instrument — pivot by system_entity showing USD_CURRENCY_AMOUNT and trade_id counts.',
    icon: AssessmentIcon,
    color: '#9c27b0',
    preview: {
      headers: ['sedol', 'instrument', 'Entity-UK', 'Entity-US'],
      rows: [
        ['B0WNLY7', 'HSBC Holdings', '$8.4M', '$12.1M'],
        ['B4T3BW2', 'Barclays PLC', '$5.2M', '$3.8M'],
        ['BH4HKS3', 'Shell PLC', '$14.6M', '$9.2M'],
      ],
    },
  },
  {
    name: 'Trade Reconciliation',
    type: 'saved_query' as const,
    description: 'Filter by trade_id, sedol, or Book_id to reconcile positions — shows sap_account, currency amounts, and FX rates.',
    icon: ReceiptIcon,
    color: '#0288d1',
    preview: {
      headers: ['trade_id', 'sedol', 'sap_account', 'USD_AMT', 'FX_Rate'],
      rows: [
        ['TRD-10042', 'B0WNLY7', '40010100', '$245,000', '1.2650'],
        ['TRD-10043', 'B4T3BW2', '40020300', '$890,500', '0.7890'],
        ['TRD-10044', 'BH4HKS3', '50010100', '$1,120,000', '1.0000'],
      ],
    },
  },
  {
    name: 'Desk P&L by Cost Centre',
    type: 'saved_query' as const,
    description: 'Parameterized P&L — filter by su (desk), MU (cost centre), and sap_acc_level1 to view USD and GBP amounts per profit centre.',
    icon: AccountBalanceIcon,
    color: '#0288d1',
    preview: {
      headers: ['su', 'MU', 'sap_acc_level1', 'USD_AMT', 'GBP_AMT'],
      rows: [
        ['Rates Desk', 'CC-Fixed Income', 'Trading P&L', '$4.2M', '\u00a33.0M'],
        ['Credit Desk', 'CC-Credit', 'Trading P&L', '-$1.8M', '-\u00a31.3M'],
        ['Equities', 'CC-Equities', 'Revaluation', '$6.5M', '\u00a34.6M'],
      ],
    },
  },
];

const TYPE_CONFIG = {
  tabular: { label: 'Tabular', color: 'primary' as const, icon: TabularIcon },
  pivot: { label: 'Pivot', color: 'secondary' as const, icon: PivotIcon },
  saved_query: { label: 'Saved Query', color: 'info' as const, icon: QueryIcon },
};

const SEED_KEY = 'qs-sample-reports-seeded';

/* ── Mini Data Preview ──────────────────────────────────────────────────── */

const MiniPreview: React.FC<{ preview: typeof EXAMPLE_REPORTS[0]['preview'] }> = ({ preview }) => (
  <Box sx={{
    mt: 1.5, borderRadius: 1, overflow: 'hidden', border: '1px solid',
    borderColor: 'divider', fontSize: '0.65rem', fontFamily: 'monospace',
  }}>
    <Box sx={{
      display: 'grid', gridTemplateColumns: `repeat(${preview.headers.length}, 1fr)`,
      bgcolor: 'grey.100', borderBottom: '1px solid', borderColor: 'divider',
    }}>
      {preview.headers.map(h => (
        <Box key={h} sx={{ px: 0.75, py: 0.5, fontWeight: 700, color: 'text.secondary', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {h}
        </Box>
      ))}
    </Box>
    {preview.rows.map((row, ri) => (
      <Box key={ri} sx={{
        display: 'grid', gridTemplateColumns: `repeat(${preview.headers.length}, 1fr)`,
        borderBottom: ri < preview.rows.length - 1 ? '1px solid' : 'none', borderColor: 'divider',
        '&:hover': { bgcolor: 'action.hover' },
      }}>
        {row.map((cell, ci) => (
          <Box key={ci} sx={{
            px: 0.75, py: 0.4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            color: cell === 'pending' ? 'warning.main' : (cell.startsWith('$') ? 'text.primary' : 'text.primary'),
            fontWeight: cell.startsWith('$') || cell.endsWith('%') ? 600 : 400,
          }}>
            {cell}
          </Box>
        ))}
      </Box>
    ))}
  </Box>
);


/* ── Main Component ─────────────────────────────────────────────────────── */

const ReportsListPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [seedMsg, setSeedMsg] = useState('');
  const [openingCard, setOpeningCard] = useState<string | null>(null);

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const username = user?.username || '';

  const loadReports = () => {
    setLoading(true);
    api.listBusinessReports()
      .then((data: any) => setReports(Array.isArray(data) ? data : []))
      .catch(() => setError('Failed to load reports'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadReports(); }, []);

  const filtered = reports.filter(r => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (r.name || '').toLowerCase().includes(q) ||
      (r.description || '').toLowerCase().includes(q) ||
      (r.owner || '').toLowerCase().includes(q);
  });

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.deleteBusinessReport(deleteId);
      setReports(prev => prev.filter(r => r.id !== deleteId));
    } catch { setError('Failed to delete report'); }
    setDeleteId(null);
  };

  const handleDuplicate = async (id: number) => {
    try {
      const dup = await api.duplicateBusinessReport(id);
      if (dup?.id) navigate(`/business-reports/${dup.id}/edit`);
    } catch { setError('Failed to duplicate report'); }
  };

  /* ── Seed actual sample reports via backend ──────────────────────────── */
  const handleSeedSamples = async () => {
    setSeeding(true);
    setSeedMsg('');
    try {
      const result = await api.seedSampleReports();
      if (result?.status === 'already_exists') {
        setSeedMsg(`Sample reports already exist (${result.reports?.length || 0} reports). Open them from the table above.`);
      } else if (result?.status === 'created') {
        localStorage.setItem(SEED_KEY, 'true');
        setSeedMsg(`Created ${result.reports?.length || 0} IB P&L sample reports with ${result.columns_created || 0} columns! Open any report to execute, export, or chart.`);
      } else {
        setSeedMsg('Sample reports created successfully!');
        localStorage.setItem(SEED_KEY, 'true');
      }
      loadReports();
    } catch {
      setSeedMsg('Failed to create sample reports. Please try again.');
    } finally {
      setSeeding(false);
    }
  };

  /* ── Open example card → find or seed real report, then navigate ────── */
  const handleOpenExample = async (exampleName: string) => {
    // Check if the real report already exists in loaded reports
    const match = reports.find(r => r.name === exampleName);
    if (match) {
      navigate(`/business-reports/${match.id}`);
      return;
    }
    // Not found — seed the sample reports, then navigate
    setOpeningCard(exampleName);
    try {
      const result = await api.seedSampleReports();
      const seeded = result?.reports || [];
      localStorage.setItem(SEED_KEY, 'true');
      const target = seeded.find((r: any) => r.name === exampleName);
      if (target) {
        navigate(`/business-reports/${target.id}`);
      } else if (seeded.length > 0) {
        // Name mismatch — navigate to the first seeded report
        navigate(`/business-reports/${seeded[0].id}`);
      } else {
        setSeedMsg('Sample reports created! Refresh to see them.');
        loadReports();
      }
    } catch {
      setSeedMsg('Failed to create sample reports. Please try again.');
    } finally {
      setOpeningCard(null);
    }
  };

  const alreadySeeded = localStorage.getItem(SEED_KEY) === 'true';

  if (loading) {
    return (
      <Box sx={{ p: 3 }}>
        <Skeleton variant="text" width={200} height={40} sx={{ mb: 2 }} />
        <Grid container spacing={2}>
          {[0, 1, 2, 3, 4, 5].map(i => (
            <Grid key={i} size={{ xs: 12, sm: 6, lg: 4 }}>
              <Skeleton variant="rectangular" height={220} sx={{ borderRadius: 2 }} />
            </Grid>
          ))}
        </Grid>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 600 }}>Reports</Typography>
        {reports.length > 0 && (
          <TextField
            size="small" placeholder="Search reports..."
            value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
            sx={{ width: 250 }}
          />
        )}
        <Button variant="contained" startIcon={<AddIcon />}
          onClick={() => navigate('/business-reports/new')}>
          New Report
        </Button>
        <Button variant="outlined" startIcon={<SeedIcon />}
          onClick={handleSeedSamples} disabled={seeding}>
          {seeding ? 'Creating...' : 'Seed Samples'}
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {seedMsg && <Alert severity={seedMsg.includes('Created') ? 'success' : 'info'} sx={{ mb: 2 }} onClose={() => setSeedMsg('')}>{seedMsg}</Alert>}

      {/* Reports table (when reports exist) */}
      {reports.length > 0 && (
        <>
          {filtered.length === 0 ? (
            <Paper sx={{ p: 4, textAlign: 'center' }}>
              <Typography color="text.secondary">No matching reports found.</Typography>
            </Paper>
          ) : (
            <TableContainer component={Paper} sx={{ mb: 4 }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Owner</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Executions</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Last Executed</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Updated</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filtered.map(r => (
                    <TableRow key={r.id} hover sx={{ cursor: 'pointer' }}
                      onClick={() => navigate(`/business-reports/${r.id}`)}>
                      <TableCell>
                        <Typography variant="body2" fontWeight="bold">{r.name}</Typography>
                        {r.description && (
                          <Typography variant="caption" color="text.secondary">{r.description.slice(0, 60)}</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip size="small" variant="outlined"
                          label={
                            r.data_source_type === 'raw_sql' ? 'Saved Query' :
                            (r.layout_config?.report_type === 'pivot') ? 'Pivot' :
                            'Tabular'
                          }
                          color={
                            r.data_source_type === 'raw_sql' ? 'info' :
                            (r.layout_config?.report_type === 'pivot') ? 'secondary' :
                            'default'
                          }
                        />
                      </TableCell>
                      <TableCell>{r.owner}</TableCell>
                      <TableCell>
                        {r.is_published ? (
                          <Chip size="small" label="Published" color="success" />
                        ) : (
                          <Chip size="small" label="Draft" variant="outlined" />
                        )}
                      </TableCell>
                      <TableCell>{r.execution_count || 0}</TableCell>
                      <TableCell>
                        {r.last_executed_at ? new Date(r.last_executed_at).toLocaleString() : '-'}
                      </TableCell>
                      <TableCell>
                        {r.updated_at ? new Date(r.updated_at).toLocaleDateString() : '-'}
                      </TableCell>
                      <TableCell align="right" onClick={e => e.stopPropagation()}>
                        <Tooltip title="Open"><IconButton size="small" onClick={() => navigate(`/business-reports/${r.id}`)}>
                          <ViewIcon fontSize="small" />
                        </IconButton></Tooltip>
                        {(r.owner === username || isAdmin) && (
                          <Tooltip title="Edit"><IconButton size="small" onClick={() => navigate(`/business-reports/${r.id}/edit`)}>
                            <EditIcon fontSize="small" />
                          </IconButton></Tooltip>
                        )}
                        <Tooltip title="Duplicate"><IconButton size="small" onClick={() => handleDuplicate(r.id)}>
                          <DuplicateIcon fontSize="small" />
                        </IconButton></Tooltip>
                        {(r.owner === username || isAdmin) && (
                          <Tooltip title="Delete"><IconButton size="small" color="error"
                            onClick={() => setDeleteId(r.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton></Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </>
      )}

      {/* Example report showcase — always visible */}
      <Box>
        {reports.length === 0 && (
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <AssessmentIcon sx={{ fontSize: 48, color: 'primary.main', mb: 1 }} />
            <Typography variant="h5" fontWeight={600} gutterBottom>
              Enterprise P&L and Position Reporting
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 640, mx: 'auto', mb: 2 }}>
              Build tabular P&L summaries, pivot crosstabs by book and currency, or parameterized
              query reports for trade reconciliation and desk-level analysis.
              Click any report below to open it with full execute, export, and share capabilities.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button variant="contained" size="large" startIcon={<AddIcon />}
                onClick={() => navigate('/business-reports/new')}>
                Create Report
              </Button>
              {!alreadySeeded && (
                <Button variant="outlined" size="large" startIcon={<SeedIcon />}
                  onClick={handleSeedSamples} disabled={seeding}>
                  {seeding ? 'Creating...' : 'Create Sample Reports'}
                </Button>
              )}
            </Box>
          </Box>
        )}

        {reports.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle1" fontWeight={600} color="text.secondary">
              IB P&L Sample Reports — click to open
            </Typography>
          </Box>
        )}

        <Grid container spacing={2.5}>
          {EXAMPLE_REPORTS.map((ex, idx) => {
            const tc = TYPE_CONFIG[ex.type];
            const Icon = ex.icon;
            const isOpening = openingCard === ex.name;
            const hasReal = reports.some(r => r.name === ex.name);
            return (
              <Grid key={idx} size={{ xs: 12, sm: 6, lg: 4 }}>
                <Card
                  variant="outlined"
                  sx={{
                    height: '100%', display: 'flex', flexDirection: 'column',
                    borderLeft: `4px solid ${ex.color}`,
                    transition: 'box-shadow 0.2s, transform 0.2s',
                    cursor: 'pointer',
                    '&:hover': {
                      boxShadow: 4,
                      transform: 'translateY(-2px)',
                    },
                  }}
                  onClick={() => !isOpening && handleOpenExample(ex.name)}
                >
                  <CardContent sx={{ flex: 1, pb: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Icon sx={{ fontSize: 22, color: ex.color }} />
                        <Typography variant="subtitle1" fontWeight={700} sx={{ lineHeight: 1.3 }}>
                          {ex.name}
                        </Typography>
                      </Box>
                      <Chip size="small" label={tc.label} color={tc.color} variant="outlined" sx={{ fontSize: '0.7rem', height: 22 }} />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem', mb: 0.5, lineHeight: 1.4 }}>
                      {ex.description}
                    </Typography>
                    <MiniPreview preview={ex.preview} />
                  </CardContent>
                  <CardActions sx={{ px: 2, pb: 1.5, pt: 0.5 }}>
                    <Button
                      size="small"
                      variant={hasReal ? 'contained' : 'outlined'}
                      startIcon={isOpening ? <CircularProgress size={14} /> : <OpenIcon sx={{ fontSize: 14 }} />}
                      sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                      disabled={isOpening}
                      onClick={(e) => { e.stopPropagation(); handleOpenExample(ex.name); }}
                    >
                      {isOpening ? 'Opening...' : hasReal ? 'Open Report' : 'Open Report'}
                    </Button>
                    <Chip
                      size="small" variant="outlined"
                      label={hasReal ? 'Ready' : 'Will auto-create'}
                      color={hasReal ? 'success' : 'default'}
                      sx={{ ml: 'auto', fontSize: '0.65rem', height: 20 }}
                    />
                  </CardActions>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Box>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteId !== null} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Report</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this report? This cannot be undone.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ReportsListPage;
