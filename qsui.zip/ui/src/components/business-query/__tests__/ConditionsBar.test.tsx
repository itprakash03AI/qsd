/**
 * Phase 138 — ConditionsBar render + interaction tests.
 *
 * Covers the chip-bar replacement for the old FilterSection + SortSection
 * (single row instead of two stacked Paper boxes).
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ConditionsBar from '../ConditionsBar';
import type { MappedColumn, BusinessFilter, SortDef } from '../types';

const COLUMNS: MappedColumn[] = [
  { physical_name: 'amount', friendly_name: 'Amount', is_partition: false, type: 'numeric' } as any,
  { physical_name: 'region', friendly_name: 'Region', is_partition: true,  type: 'string'  } as any,
];

const baseProps = {
  filters: [] as BusinessFilter[],
  onAddFilter: vi.fn(),
  onRemoveFilter: vi.fn(),
  onFilterChange: vi.fn(),
  partitionValues: {},
  partitionColumns: [] as string[],
  hasPartitionFilter: false,
  hasSelectedColumns: true,
  filterLogic: 'AND' as 'AND' | 'OR',
  onFilterLogicChange: vi.fn(),
  sortColumns: [] as SortDef[],
  onAddSort: vi.fn(),
  onRemoveSort: vi.fn(),
  onSortChange: vi.fn(),
  mappedColumns: COLUMNS,
};

describe('ConditionsBar', () => {
  it('renders Filter and Sort add buttons in empty state', () => {
    render(<ConditionsBar {...baseProps} />);
    expect(screen.getByRole('button', { name: /^Filter$/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /^Sort$/ })).toBeInTheDocument();
  });

  it('disables add buttons when no columns are mapped', () => {
    render(<ConditionsBar {...baseProps} mappedColumns={[]} />);
    expect(screen.getByRole('button', { name: /^Filter$/ })).toBeDisabled();
    expect(screen.getByRole('button', { name: /^Sort$/ })).toBeDisabled();
  });

  it('calls onAddFilter when the + Filter button is clicked', async () => {
    const onAddFilter = vi.fn();
    render(<ConditionsBar {...baseProps} onAddFilter={onAddFilter} />);
    await userEvent.click(screen.getByRole('button', { name: /^Filter$/ }));
    expect(onAddFilter).toHaveBeenCalled();
  });

  it('calls onAddSort when the + Sort button is clicked', async () => {
    const onAddSort = vi.fn();
    render(<ConditionsBar {...baseProps} onAddSort={onAddSort} />);
    await userEvent.click(screen.getByRole('button', { name: /^Sort$/ }));
    expect(onAddSort).toHaveBeenCalled();
  });

  it('renders one chip per filter with the friendly column name + value', () => {
    const filters: BusinessFilter[] = [
      { id: 'f1', physical_name: 'amount', friendly_name: 'Amount',
        operator: 'gt', value: '100', is_partition: false },
      { id: 'f2', physical_name: 'region', friendly_name: 'Region',
        operator: 'eq', value: 'US',  is_partition: true  },
    ];
    render(<ConditionsBar {...baseProps} filters={filters} />);
    // Friendly names appear in chip labels (operator labels: > and =)
    expect(screen.getByText(/Amount > 100/)).toBeInTheDocument();
    expect(screen.getByText(/Region = US/)).toBeInTheDocument();
  });

  it('renders one chip per sort with arrow + friendly name', () => {
    const sortColumns: SortDef[] = [
      { column: 'amount', direction: 'DESC' },
      { column: 'region', direction: 'ASC'  },
    ];
    render(<ConditionsBar {...baseProps} sortColumns={sortColumns} />);
    expect(screen.getByText(/↓ Amount/)).toBeInTheDocument();
    expect(screen.getByText(/↑ Region/)).toBeInTheDocument();
  });

  it('shows AND/OR toggle only when there are 2+ filters', () => {
    const onFilterLogicChange = vi.fn();
    const { rerender } = render(
      <ConditionsBar {...baseProps} onFilterLogicChange={onFilterLogicChange} />
    );
    // 0 filters → no AND/OR chip
    expect(screen.queryByText('AND')).not.toBeInTheDocument();

    const filters: BusinessFilter[] = [
      { id: '1', physical_name: 'amount', friendly_name: 'A', operator: 'eq', value: '1', is_partition: false },
      { id: '2', physical_name: 'region', friendly_name: 'R', operator: 'eq', value: 'X', is_partition: false },
    ];
    rerender(<ConditionsBar {...baseProps} filters={filters} onFilterLogicChange={onFilterLogicChange} />);
    expect(screen.getByText('AND')).toBeInTheDocument();
  });

  it('toggles AND ↔ OR when the logic chip is clicked', async () => {
    const onFilterLogicChange = vi.fn();
    const filters: BusinessFilter[] = [
      { id: '1', physical_name: 'amount', friendly_name: 'A', operator: 'eq', value: '1', is_partition: false },
      { id: '2', physical_name: 'region', friendly_name: 'R', operator: 'eq', value: 'X', is_partition: false },
    ];
    render(<ConditionsBar {...baseProps} filters={filters} onFilterLogicChange={onFilterLogicChange} />);
    await userEvent.click(screen.getByText('AND'));
    expect(onFilterLogicChange).toHaveBeenCalledWith('OR');
  });

  it('shows partition-hint Alert only when condition triggers', () => {
    const { rerender } = render(
      <ConditionsBar
        {...baseProps}
        partitionColumns={['region']}
        hasPartitionFilter={false}
      />
    );
    expect(screen.getByText(/partition filter/i)).toBeInTheDocument();

    rerender(
      <ConditionsBar
        {...baseProps}
        partitionColumns={['region']}
        hasPartitionFilter={true}   // user already has a partition filter
      />
    );
    expect(screen.queryByText(/improves speed/i)).not.toBeInTheDocument();
  });

  it('shows the count summary when there are conditions', () => {
    const filters: BusinessFilter[] = [
      { id: '1', physical_name: 'amount', friendly_name: 'A', operator: 'eq', value: '1', is_partition: false },
    ];
    const sortColumns: SortDef[] = [
      { column: 'amount', direction: 'ASC' },
    ];
    render(<ConditionsBar {...baseProps} filters={filters} sortColumns={sortColumns} />);
    expect(screen.getByText(/1 filter\b/i)).toBeInTheDocument();
    expect(screen.getByText(/1 sort/i)).toBeInTheDocument();
  });
});
