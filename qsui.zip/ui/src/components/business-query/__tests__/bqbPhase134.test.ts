/**
 * Phase 134 — Vitest tests for Business Query Builder enhancements.
 * Covers: utils (buildExpr, qid, frequency tracking), SQL generation logic,
 * snapshot build/restore, column search, template application, config merge.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { qid, buildExpr, trackColumnUse, getFrequentColumns, safeStringify } from '../utils';

// ── qid (SQL identifier quoting) ─────────────────────────────────

describe('qid', () => {
  it('wraps name in double quotes', () => {
    expect(qid('column_name')).toBe('"column_name"');
  });

  it('escapes embedded double quotes', () => {
    expect(qid('col"with"quotes')).toBe('"col""with""quotes"');
  });

  it('handles spaces in column names', () => {
    expect(qid('column name')).toBe('"column name"');
  });

  it('handles SQL reserved words', () => {
    expect(qid('SELECT')).toBe('"SELECT"');
    expect(qid('ORDER')).toBe('"ORDER"');
  });

  it('handles empty string', () => {
    expect(qid('')).toBe('""');
  });
});

// ── buildExpr (SQL expression builder) ──────────────────────────

describe('buildExpr', () => {
  it('returns quoted column when no agg or transform', () => {
    expect(buildExpr('amount', '', '')).toBe('"amount"');
  });

  it('applies aggregation', () => {
    expect(buildExpr('amount', 'SUM', '')).toBe('SUM("amount")');
    expect(buildExpr('amount', 'AVG', '')).toBe('AVG("amount")');
    expect(buildExpr('amount', 'MAX', '')).toBe('MAX("amount")');
    expect(buildExpr('amount', 'MIN', '')).toBe('MIN("amount")');
    expect(buildExpr('id', 'COUNT', '')).toBe('COUNT("id")');
  });

  it('handles COUNT_DISTINCT', () => {
    expect(buildExpr('cust_id', 'COUNT_DISTINCT', '')).toBe('COUNT(DISTINCT "cust_id")');
  });

  it('applies transform only', () => {
    expect(buildExpr('trade_date', '', 'YEAR')).toBe('YEAR("trade_date")');
    expect(buildExpr('name', '', 'UPPER')).toBe('UPPER("name")');
  });

  it('applies ROUND transform', () => {
    expect(buildExpr('price', '', 'ROUND')).toBe('ROUND("price", 2)');
  });

  it('applies agg + transform (agg wraps transform)', () => {
    expect(buildExpr('amount', 'SUM', 'ROUND')).toBe('SUM(ROUND("amount", 2))');
    expect(buildExpr('trade_date', 'COUNT', 'YEAR')).toBe('COUNT(YEAR("trade_date"))');
  });

  it('COUNT_DISTINCT ignores transform (uses raw col)', () => {
    expect(buildExpr('id', 'COUNT_DISTINCT', 'UPPER')).toBe('COUNT(DISTINCT "id")');
  });
});

// ── trackColumnUse / getFrequentColumns (localStorage) ──────────

describe('column frequency tracking', () => {
  let store: Record<string, string>;

  beforeEach(() => {
    store = {};
    vi.stubGlobal('localStorage', {
      getItem: vi.fn((key: string) => store[key] || null),
      setItem: vi.fn((key: string, value: string) => { store[key] = value; }),
      removeItem: vi.fn((key: string) => { delete store[key]; }),
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('tracks a new column use (count = 1)', () => {
    trackColumnUse(1, 'schema.table1', 'col_a');
    const key = 'qs_bqb_col_freq_1_schema.table1';
    expect(store[key]).toBeDefined();
    const data = JSON.parse(store[key]);
    expect(data.col_a).toBe(1);
  });

  it('increments existing column count', () => {
    trackColumnUse(1, 'schema.table1', 'col_a');
    trackColumnUse(1, 'schema.table1', 'col_a');
    trackColumnUse(1, 'schema.table1', 'col_a');
    const data = JSON.parse(store['qs_bqb_col_freq_1_schema.table1']);
    expect(data.col_a).toBe(3);
  });

  it('tracks multiple columns independently', () => {
    trackColumnUse(1, 'schema.table1', 'col_a');
    trackColumnUse(1, 'schema.table1', 'col_b');
    trackColumnUse(1, 'schema.table1', 'col_a');
    const data = JSON.parse(store['qs_bqb_col_freq_1_schema.table1']);
    expect(data.col_a).toBe(2);
    expect(data.col_b).toBe(1);
  });

  it('tracks different tables separately', () => {
    trackColumnUse(1, 'schema.table1', 'col_a');
    trackColumnUse(1, 'schema.table2', 'col_a');
    expect(store['qs_bqb_col_freq_1_schema.table1']).toBeDefined();
    expect(store['qs_bqb_col_freq_1_schema.table2']).toBeDefined();
    const d1 = JSON.parse(store['qs_bqb_col_freq_1_schema.table1']);
    const d2 = JSON.parse(store['qs_bqb_col_freq_1_schema.table2']);
    expect(d1.col_a).toBe(1);
    expect(d2.col_a).toBe(1);
  });

  it('tracks different connections separately', () => {
    trackColumnUse(1, 'schema.table1', 'col_a');
    trackColumnUse(2, 'schema.table1', 'col_a');
    expect(store['qs_bqb_col_freq_1_schema.table1']).toBeDefined();
    expect(store['qs_bqb_col_freq_2_schema.table1']).toBeDefined();
  });

  it('getFrequentColumns returns empty set for new table', () => {
    const result = getFrequentColumns(1, 'schema.unknown');
    expect(result.size).toBe(0);
  });

  it('getFrequentColumns returns columns used 3+ times', () => {
    // col_a = 4 times (should be frequent)
    for (let i = 0; i < 4; i++) trackColumnUse(1, 'schema.table1', 'col_a');
    // col_b = 2 times (not frequent)
    for (let i = 0; i < 2; i++) trackColumnUse(1, 'schema.table1', 'col_b');
    // col_c = 3 times (should be frequent — threshold is >= 3)
    for (let i = 0; i < 3; i++) trackColumnUse(1, 'schema.table1', 'col_c');

    const frequent = getFrequentColumns(1, 'schema.table1');
    expect(frequent.has('col_a')).toBe(true);
    expect(frequent.has('col_b')).toBe(false);
    expect(frequent.has('col_c')).toBe(true);
    expect(frequent.size).toBe(2);
  });

  it('handles localStorage errors gracefully', () => {
    vi.stubGlobal('localStorage', {
      getItem: vi.fn(() => { throw new Error('quota exceeded'); }),
      setItem: vi.fn(() => { throw new Error('quota exceeded'); }),
    });
    // Should not throw
    expect(() => trackColumnUse(1, 'table', 'col')).not.toThrow();
    expect(getFrequentColumns(1, 'table').size).toBe(0);
  });
});

// ── safeStringify (BF-426) ──────────────────────────────────────

describe('safeStringify', () => {
  it('serializes plain objects identically to JSON.stringify', () => {
    const obj = { a: 1, b: 'two', c: [1, 2, 3], d: { nested: true } };
    expect(safeStringify(obj)).toBe(JSON.stringify(obj));
  });

  it('replaces window reference with [Window]', () => {
    const obj: any = { name: 'tab1', leak: typeof window !== 'undefined' ? window : null };
    const out = safeStringify(obj);
    expect(out).toContain('"leak":');
    if (typeof window !== 'undefined') expect(out).toContain('[Window]');
  });

  it('breaks circular references with [Circular]', () => {
    const a: any = { name: 'a' };
    a.self = a;
    expect(() => safeStringify(a)).not.toThrow();
    expect(safeStringify(a)).toContain('[Circular]');
  });

  it('drops function values', () => {
    const obj = { name: 'x', cb: () => 'hi', value: 42 };
    const parsed = JSON.parse(safeStringify(obj));
    expect(parsed.cb).toBeUndefined();
    expect(parsed.name).toBe('x');
    expect(parsed.value).toBe(42);
  });

  it('replaces DOM nodes with [DOM]', () => {
    if (typeof document === 'undefined') return;
    const div = document.createElement('div');
    const obj = { el: div, label: 'wrapper' };
    expect(safeStringify(obj)).toContain('[DOM]');
  });

  it('replaces Event instances with [Event]', () => {
    if (typeof Event === 'undefined') return;
    const evt = new Event('click');
    const obj = { evt, ok: true };
    expect(safeStringify(obj)).toContain('[Event]');
  });

  it('preserves null and primitive values', () => {
    expect(safeStringify(null)).toBe('null');
    expect(safeStringify(0)).toBe('0');
    expect(safeStringify(false)).toBe('false');
    expect(safeStringify('hello')).toBe('"hello"');
  });

  it('handles arrays without index reordering', () => {
    expect(safeStringify([1, 'two', null, true])).toBe('[1,"two",null,true]');
  });

  it('survives a polluted snapshot (the actual BQB scenario)', () => {
    // Mimics what would crash native JSON.stringify: a snapshot where one
    // any[] field accidentally captured a SyntheticEvent-like object.
    const fakeEvent: any = {
      nativeEvent: { type: 'click' },
      target: { value: 'x' },
      currentTarget: null,
      preventDefault: () => {},
    };
    const snapshot = {
      tabs: [{ id: 't1', name: 'Tab 1', filters: [fakeEvent] }],
      activeTabId: 't1',
    };
    expect(() => safeStringify(snapshot)).not.toThrow();
    expect(safeStringify(snapshot)).toContain('[SyntheticEvent]');
  });
});

// ── BqbTabSnapshot shape ────────────────────────────────────────

describe('BqbTabSnapshot type contract', () => {
  it('has all required fields', () => {
    // Importing the type just for validation — create a minimal snapshot
    const snapshot = {
      selectedConnId: 1,
      selectedTables: [{ name: 'T1', path: '__registered__:T1' }],
      selectedCrossTables: [],
      selectedPhysical: ['col_a', 'col_b'],
      columnAggregations: { col_a: 'SUM' },
      columnTransforms: {},
      filters: [],
      sortColumns: [],
      joinConfig: null,
      queryLimit: 5000,
      sqlText: 'SELECT "col_a" FROM "T1"',
      executionId: null,
      savedQueryId: null,
      savedQueryName: '',
      cacheStrategy: 'auto',
      showCrossConn: false,
      crossConnId: null,
      having: [],
      computedColumns: [],
      caseExpressions: [],
      windowFunctions: [],
      distinct: false,
      filterLogic: 'AND' as const,
    };
    // Verify all keys exist (23 fields in BqbTabSnapshot interface)
    expect(Object.keys(snapshot)).toHaveLength(23);
    expect(snapshot.selectedConnId).toBe(1);
    expect(snapshot.filterLogic).toBe('AND');
    expect(snapshot.distinct).toBe(false);
  });

  it('snapshot round-trip preserves data integrity', () => {
    const snapshot = {
      selectedConnId: 42,
      selectedTables: [{ name: 'Orders', path: 's3://bucket/orders' }],
      selectedCrossTables: [{ name: 'Returns', path: '__registered__:returns' }],
      selectedPhysical: ['order_id', 'amount', 'trade_date'],
      columnAggregations: { amount: 'SUM', order_id: 'COUNT' },
      columnTransforms: { trade_date: 'YEAR' },
      filters: [{ column: 'amount', operator: '>', value: '1000', logicalOp: 'AND' }],
      sortColumns: [{ column: 'amount', direction: 'DESC' }],
      joinConfig: { type: 'INNER', leftKey: 'order_id', rightKey: 'order_id' },
      queryLimit: 10000,
      sqlText: 'SELECT SUM("amount") FROM "Orders"',
      executionId: 'exec-123',
      savedQueryId: 7,
      savedQueryName: 'My Query',
      cacheStrategy: 'refresh',
      showCrossConn: true,
      crossConnId: 99,
      having: [{ column: 'amount', agg: 'SUM', operator: '>', value: '5000' }],
      computedColumns: [{ name: 'margin', expression: '"revenue" - "cost"' }],
      caseExpressions: [{ name: 'status', cases: [{ when: '"amount" > 0', then: "'positive'" }] }],
      windowFunctions: [{ name: 'rank', fn: 'ROW_NUMBER', partitionBy: 'region', orderBy: 'amount DESC' }],
      distinct: true,
      filterLogic: 'OR' as const,
    };
    // Serialize and deserialize (simulating sessionStorage round-trip)
    const serialized = JSON.stringify(snapshot);
    const restored = JSON.parse(serialized);

    expect(restored.selectedConnId).toBe(42);
    expect(restored.selectedTables).toHaveLength(1);
    expect(restored.selectedCrossTables).toHaveLength(1);
    expect(restored.selectedPhysical).toEqual(['order_id', 'amount', 'trade_date']);
    expect(restored.columnAggregations.amount).toBe('SUM');
    expect(restored.columnTransforms.trade_date).toBe('YEAR');
    expect(restored.having).toHaveLength(1);
    expect(restored.computedColumns).toHaveLength(1);
    expect(restored.caseExpressions).toHaveLength(1);
    expect(restored.windowFunctions).toHaveLength(1);
    expect(restored.distinct).toBe(true);
    expect(restored.filterLogic).toBe('OR');
    expect(restored.showCrossConn).toBe(true);
    expect(restored.crossConnId).toBe(99);
  });
});

// ── SQL generation patterns ─────────────────────────────────────

describe('SQL generation patterns', () => {
  // Helper to build a SELECT clause from selected columns
  const buildSelectClause = (
    columns: Array<{ physical: string; agg: string; transform: string }>,
    distinct: boolean = false,
  ): string => {
    const exprs = columns.map(c => buildExpr(c.physical, c.agg, c.transform));
    return `SELECT ${distinct ? 'DISTINCT ' : ''}${exprs.join(', ')}`;
  };

  it('generates plain SELECT', () => {
    const sql = buildSelectClause([
      { physical: 'order_id', agg: '', transform: '' },
      { physical: 'amount', agg: '', transform: '' },
    ]);
    expect(sql).toBe('SELECT "order_id", "amount"');
  });

  it('generates SELECT with aggregations', () => {
    const sql = buildSelectClause([
      { physical: 'region', agg: '', transform: '' },
      { physical: 'amount', agg: 'SUM', transform: '' },
      { physical: 'cust_id', agg: 'COUNT_DISTINCT', transform: '' },
    ]);
    expect(sql).toBe('SELECT "region", SUM("amount"), COUNT(DISTINCT "cust_id")');
  });

  it('generates SELECT DISTINCT', () => {
    const sql = buildSelectClause([
      { physical: 'region', agg: '', transform: '' },
      { physical: 'status', agg: '', transform: '' },
    ], true);
    expect(sql).toBe('SELECT DISTINCT "region", "status"');
  });

  it('generates SELECT with transforms', () => {
    const sql = buildSelectClause([
      { physical: 'trade_date', agg: '', transform: 'YEAR' },
      { physical: 'amount', agg: 'SUM', transform: 'ROUND' },
    ]);
    expect(sql).toBe('SELECT YEAR("trade_date"), SUM(ROUND("amount", 2))');
  });

  it('generates HAVING clause expression', () => {
    const havingExpr = `${buildExpr('amount', 'SUM', '')} > 5000`;
    expect(havingExpr).toBe('SUM("amount") > 5000');
  });

  it('generates window function expression', () => {
    const windowExpr = `ROW_NUMBER() OVER (PARTITION BY ${qid('region')} ORDER BY ${qid('amount')} DESC)`;
    expect(windowExpr).toBe('ROW_NUMBER() OVER (PARTITION BY "region" ORDER BY "amount" DESC)');
  });

  it('generates computed column expression', () => {
    const computed = `(${qid('revenue')} - ${qid('cost')}) AS ${qid('margin')}`;
    expect(computed).toBe('("revenue" - "cost") AS "margin"');
  });

  it('generates filter with AND logic', () => {
    const filters = [
      { column: 'amount', operator: '>', value: '1000' },
      { column: 'status', operator: '=', value: "'active'" },
    ];
    const where = filters.map(f => `${qid(f.column)} ${f.operator} ${f.value}`).join(' AND ');
    expect(where).toBe('"amount" > 1000 AND "status" = \'active\'');
  });

  it('generates filter with OR logic', () => {
    const filters = [
      { column: 'region', operator: '=', value: "'EMEA'" },
      { column: 'region', operator: '=', value: "'APAC'" },
    ];
    const where = filters.map(f => `${qid(f.column)} ${f.operator} ${f.value}`).join(' OR ');
    expect(where).toBe('"region" = \'EMEA\' OR "region" = \'APAC\'');
  });
});

// ── Query template application ──────────────────────────────────

describe('query template application', () => {
  it('substitutes {table} placeholder', () => {
    const template = 'SELECT {dimensions}, {measure}\nFROM {table}\nORDER BY {measure} DESC\nLIMIT {N}';
    const result = template
      .replace(/\{table\}/g, '"orders"')
      .replace(/\{dimensions\}/g, '"region"')
      .replace(/\{measure\}/g, '"amount"')
      .replace(/\{N\}/g, '10');
    expect(result).toContain('FROM "orders"');
    expect(result).toContain('ORDER BY "amount" DESC');
    expect(result).toContain('LIMIT 10');
  });

  it('substitutes year-over-year template', () => {
    const template = 'SELECT YEAR({date_col}) AS yr, SUM({measure}) AS total\nFROM {table}\nGROUP BY yr\nORDER BY yr';
    const result = template
      .replace(/\{table\}/g, '"trades"')
      .replace(/\{date_col\}/g, '"trade_date"')
      .replace(/\{measure\}/g, '"amount"');
    expect(result).toContain('YEAR("trade_date")');
    expect(result).toContain('SUM("amount")');
    expect(result).toContain('FROM "trades"');
  });

  it('substitutes running total template', () => {
    const template = 'SELECT {dimensions}, {measure},\n  SUM({measure}) OVER (ORDER BY {date_col}) AS running_total\nFROM {table}';
    const result = template
      .replace(/\{table\}/g, '"orders"')
      .replace(/\{dimensions\}/g, '"region"')
      .replace(/\{measure\}/g, '"revenue"')
      .replace(/\{date_col\}/g, '"order_date"');
    expect(result).toContain('SUM("revenue") OVER (ORDER BY "order_date")');
    expect(result).toContain('"region", "revenue"');
  });
});

// ── Column search matching ──────────────────────────────────────

describe('column search matching logic', () => {
  const columnsByTable: Record<string, Record<string, Array<{ physical_name: string; friendly_name: string }>>> = {
    'schema.orders': {
      'Amount / Value': [
        { physical_name: 'amount', friendly_name: 'Amount' },
        { physical_name: 'quantity', friendly_name: 'Quantity' },
      ],
      'Identifier': [
        { physical_name: 'order_id', friendly_name: 'Order ID' },
      ],
    },
    'schema.customers': {
      'Identifier': [
        { physical_name: 'cust_id', friendly_name: 'Customer ID' },
      ],
      'Text / Name': [
        { physical_name: 'cust_name', friendly_name: 'Customer Name' },
      ],
    },
    'schema.trades': {
      'Amount / Value': [
        { physical_name: 'amount', friendly_name: 'Trade Amount' },
      ],
    },
  };

  const searchColumns = (query: string) => {
    const q = query.trim().toLowerCase();
    if (!q || q.length < 2) return null;
    const matchingTables: string[] = [];
    for (const [tablePath, catGroups] of Object.entries(columnsByTable)) {
      for (const cols of Object.values(catGroups)) {
        if (cols.some(c =>
          c.physical_name.toLowerCase().includes(q) ||
          c.friendly_name.toLowerCase().includes(q)
        )) {
          matchingTables.push(tablePath);
          break;
        }
      }
    }
    return matchingTables.length > 0 ? { query: q, tables: matchingTables } : null;
  };

  it('returns null for empty search', () => {
    expect(searchColumns('')).toBeNull();
    expect(searchColumns(' ')).toBeNull();
  });

  it('returns null for single char search', () => {
    expect(searchColumns('a')).toBeNull();
  });

  it('finds tables with matching physical name', () => {
    const result = searchColumns('amount');
    expect(result).not.toBeNull();
    expect(result!.tables).toContain('schema.orders');
    expect(result!.tables).toContain('schema.trades');
    expect(result!.tables).not.toContain('schema.customers');
  });

  it('finds tables with matching friendly name', () => {
    const result = searchColumns('Customer');
    expect(result).not.toBeNull();
    expect(result!.tables).toContain('schema.customers');
    expect(result!.tables).not.toContain('schema.orders');
  });

  it('case-insensitive matching', () => {
    const result = searchColumns('ORDER_ID');
    expect(result).not.toBeNull();
    expect(result!.tables).toContain('schema.orders');
  });

  it('partial matching works', () => {
    const result = searchColumns('cust');
    expect(result).not.toBeNull();
    expect(result!.tables).toContain('schema.customers');
  });

  it('returns null for no match', () => {
    expect(searchColumns('zzzzz')).toBeNull();
  });

  it('reports correct table count', () => {
    // 'amount' appears in orders and trades (2 tables)
    const result = searchColumns('amount');
    expect(result!.tables).toHaveLength(2);
  });
});

// ── Type filter logic ───────────────────────────────────────────

describe('table type filter', () => {
  const tables = [
    { name: 'T1', path: 'p1', _type: 'registered' },
    { name: 'T2', path: 'p2', _type: 'materialized' },
    { name: 'T3', path: 'p3', _type: 'local' },
    { name: 'T4', path: 'p4', _type: 'federation' },
    { name: 'T5', path: 'p5', _type: 'iceberg' },
    { name: 'T6', path: 'p6', _type: 'registered' },
  ];

  it('all filter shows everything', () => {
    const filtered = tables;
    expect(filtered).toHaveLength(6);
  });

  it('type filter narrows to matching type', () => {
    const filter = 'registered';
    const filtered = tables.filter(t => t._type === filter);
    expect(filtered).toHaveLength(2);
    expect(filtered.every(t => t._type === 'registered')).toBe(true);
  });

  it('materialized filter', () => {
    expect(tables.filter(t => t._type === 'materialized')).toHaveLength(1);
  });

  it('iceberg filter', () => {
    expect(tables.filter(t => t._type === 'iceberg')).toHaveLength(1);
  });

  it('unknown type returns empty', () => {
    expect(tables.filter(t => t._type === 'excel')).toHaveLength(0);
  });
});

// ── Favorites sort logic ────────────────────────────────────────

describe('favorites sorting', () => {
  const tables = [
    { name: 'Alpha', path: 'p1' },
    { name: 'Beta', path: 'p2' },
    { name: 'Gamma', path: 'p3' },
    { name: 'Delta', path: 'p4' },
  ];
  const favorites = new Set(['p3', 'p1']);

  it('sorts favorites first', () => {
    const sorted = [...tables].sort((a, b) => {
      const aFav = favorites.has(a.path) ? 0 : 1;
      const bFav = favorites.has(b.path) ? 0 : 1;
      return aFav - bFav;
    });
    // p1 (Alpha) and p3 (Gamma) are favorites — should come first
    expect(favorites.has(sorted[0].path)).toBe(true);
    expect(favorites.has(sorted[1].path)).toBe(true);
    expect(favorites.has(sorted[2].path)).toBe(false);
    expect(favorites.has(sorted[3].path)).toBe(false);
  });
});
