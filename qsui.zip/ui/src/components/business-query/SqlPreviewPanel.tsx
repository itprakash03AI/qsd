/**
 * Phase 130-B — Editable SQL preview panel with CodeMirror syntax highlighting.
 *
 * Always-editable code editor that displays auto-generated SQL and allows
 * users to freely modify it (aliases, functions, joins, etc.).
 *
 * Sizing model (Phase 138):
 *   - Default: auto-grows from line count (min 84px, max 520px) so short SQL
 *     leaves room for the result grid.
 *   - User can drag the bottom edge to set an explicit height — overrides auto.
 *   - Reset button (↺) clears the user override and returns to auto-sizing.
 *   - Expand button (UnfoldMore/Less) snaps to MAX or auto.
 */
import React, { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import {
  Box, IconButton, Tooltip, Typography,
} from '@mui/material';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import UnfoldMoreIcon from '@mui/icons-material/UnfoldMore';
import UnfoldLessIcon from '@mui/icons-material/UnfoldLess';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import SqlEditor from '../SqlEditor';

interface SqlPreviewPanelProps {
  sql: string;
  onChange: (sql: string) => void;
  onCopy: () => void;
  error?: string | null;
  disabled?: boolean;
  placeholder?: string;
  /** Table → column names for SQL autocomplete */
  schema?: Record<string, string[]>;
}

const MIN_HEIGHT = 84;          // toolbar (32) + ~2 visible lines (52)
const MAX_HEIGHT = 520;
const HARD_MAX_HEIGHT = 800;    // user can drag beyond MAX up to this
const TOOLBAR_PX  = 32;
const LINE_HEIGHT_PX = 21;
const VERTICAL_PADDING_PX = 16;

const SqlPreviewPanel: React.FC<SqlPreviewPanelProps> = ({
  sql, onChange, onCopy, error, disabled, placeholder, schema,
}) => {
  const [expanded, setExpanded] = useState(false);
  // userHeight === null means "use auto-sizing"; a number means the user
  // dragged the resize handle to that exact height.
  const [userHeight, setUserHeight] = useState<number | null>(null);
  const dragRef = useRef<{ startY: number; startHeight: number } | null>(null);

  // Auto-compute height from SQL line count
  const autoHeight = useMemo(() => {
    const lineCount = Math.max(2, (sql || '').split('\n').length);
    const contentPx = lineCount * LINE_HEIGHT_PX + VERTICAL_PADDING_PX;
    const needed = TOOLBAR_PX + contentPx;
    return Math.max(MIN_HEIGHT, Math.min(needed, MAX_HEIGHT));
  }, [sql]);

  // Resolution order: user-dragged height > expand toggle > auto.
  const editorHeight = userHeight ?? (expanded ? MAX_HEIGHT : autoHeight);

  // ── Drag-to-resize ────────────────────────────────────────────────────────
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!dragRef.current) return;
    const dy = e.clientY - dragRef.current.startY;
    const next = dragRef.current.startHeight + dy;
    setUserHeight(Math.max(MIN_HEIGHT, Math.min(HARD_MAX_HEIGHT, next)));
  }, []);

  const handleMouseUp = useCallback(() => {
    dragRef.current = null;
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  }, [handleMouseMove]);

  const handleResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    dragRef.current = { startY: e.clientY, startHeight: editorHeight };
    document.body.style.cursor = 'ns-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  }, [editorHeight, handleMouseMove, handleMouseUp]);

  // Cleanup global listeners if the component unmounts mid-drag
  useEffect(() => () => {
    if (dragRef.current) {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
  }, [handleMouseMove, handleMouseUp]);

  const showReset = userHeight !== null;

  return (
    <Box sx={{
      display: 'flex', flexDirection: 'column', height: editorHeight,
      transition: dragRef.current ? 'none' : 'height 0.2s ease',
      border: error ? '1px solid' : 'none',
      borderColor: error ? 'error.main' : 'transparent',
      position: 'relative',
    }}>
      {/* Header bar */}
      <Box sx={{
        display: 'flex', alignItems: 'center', px: 1, py: 0.5,
        borderBottom: '1px solid', borderColor: 'divider',
        bgcolor: 'grey.50',
      }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 600, flexGrow: 1, fontSize: '0.78rem' }}>
          SQL
        </Typography>
        {showReset && (
          <Tooltip title="Reset to auto-size">
            <IconButton size="small" onClick={() => setUserHeight(null)} aria-label="Reset editor height">
              <RestartAltIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
        <Tooltip title={expanded ? 'Collapse editor' : 'Expand editor'}>
          <IconButton
            size="small"
            onClick={() => { setUserHeight(null); setExpanded(prev => !prev); }}
          >
            {expanded ? <UnfoldLessIcon fontSize="small" /> : <UnfoldMoreIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
        <Tooltip title="Copy SQL">
          <IconButton size="small" onClick={onCopy} disabled={!sql.trim()}>
            <ContentCopyIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>

      {/* CodeMirror SQL editor */}
      <Box sx={{ flexGrow: 1, minHeight: 0, overflow: 'hidden', opacity: disabled ? 0.6 : 1 }}>
        <SqlEditor
          value={sql}
          onChange={onChange}
          readOnly={disabled}
          showFormatButton
          showExplainButton
          placeholder={placeholder || 'SELECT columns FROM table...'}
          schema={schema}
          height={editorHeight - 42}
        />
      </Box>

      {/* Error message */}
      {error && (
        <Typography variant="caption" color="error" sx={{ px: 1, py: 0.5, borderTop: '1px solid', borderColor: 'error.main' }}>
          {error}
        </Typography>
      )}

      {/* Drag handle — bottom edge.  6px tall hover target with a centred 1px
          divider line.  Hovering changes the cursor to ns-resize. */}
      <Box
        role="separator"
        aria-orientation="horizontal"
        aria-label="Resize SQL editor"
        onMouseDown={handleResizeStart}
        sx={{
          position: 'absolute', left: 0, right: 0, bottom: 0,
          height: 6, cursor: 'ns-resize',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          '&:hover .resizer-bar, &:active .resizer-bar': {
            backgroundColor: 'primary.main', opacity: 0.6,
          },
        }}
      >
        <Box
          className="resizer-bar"
          sx={{
            width: 32, height: 3, borderRadius: 2,
            backgroundColor: 'divider', transition: 'background-color 0.15s, opacity 0.15s',
            opacity: 0.7,
          }}
        />
      </Box>
    </Box>
  );
};

export default SqlPreviewPanel;
