/**
 * Phase 130-E — Shared types & constants for BusinessQueryBuilder sub-components.
 * Phase 134  — BqbTabSnapshot for tab persistence.
 * BF-427     — Snapshot fields tightened from any[] to concrete types so a
 *              misrouted setter (e.g., onChange={setFilters} called with `e`
 *              instead of `e.target.value`) fails at compile time instead of
 *              crashing native JSON.stringify at runtime.
 */
export type { MappedColumn, ColumnCategory } from '../../services/api/businessQueryBuilder';
import type {
  HavingDef, ComputedColumnDef, CaseExpressionDef, WindowFunctionDef,
} from '../query-builder/types';

export interface ConnectionOption { id: number; name: string; connection_type: string; config?: Record<string, any>; }
export interface TableOption { name: string; path: string; num_rows?: number; _type?: 'registered' | 'local' | 'materialized' | 'federation' | 'iceberg' | 's3file' | 'sql_table'; }
export interface BusinessFilter {
  id: string; physical_name: string; friendly_name: string;
  operator: string; value: string; is_partition: boolean;
}
export interface SortDef { column: string; direction: 'ASC' | 'DESC'; }
export interface JoinConfig {
  leftTable: string; rightTable: string;
  leftCol: string; rightCol: string;
  joinType: 'INNER' | 'LEFT';
}

/** Serializable snapshot of all BQB state — used by BusinessQueryTabManager for tab persistence. */
export interface BqbTabSnapshot {
  selectedConnId: number | null;
  selectedTables: Array<{ name: string; path: string; num_rows?: number }>;
  selectedCrossTables: Array<{ name: string; path: string; num_rows?: number }>;
  selectedPhysical: string[];
  columnAggregations: Record<string, string>;
  columnTransforms: Record<string, string>;
  filters: BusinessFilter[];
  sortColumns: SortDef[];
  joinConfig: JoinConfig | null;
  queryLimit: number;
  sqlText: string;
  executionId: string | null;
  savedQueryId: number | null;
  savedQueryName: string;
  cacheStrategy: string;
  showCrossConn: boolean;
  crossConnId: number | null;
  crossConnMode: 'union' | 'join';
  crossJoinHow: string;
  crossJoinLeftOn: string;
  crossJoinRightOn: string;
  having: HavingDef[];
  computedColumns: ComputedColumnDef[];
  caseExpressions: CaseExpressionDef[];
  windowFunctions: WindowFunctionDef[];
  distinct: boolean;
  filterLogic: 'AND' | 'OR';
}

/** Props injected by BusinessQueryTabManager for tab-aware mode. */
export interface BqbTabProps {
  tabId?: string;
  isActive?: boolean;
  initialSnapshot?: BqbTabSnapshot | null;
  onSnapshotChange?: (snapshot: BqbTabSnapshot) => void;
  onDirtyChange?: (dirty: boolean) => void;
  onNameChange?: (name: string) => void;
}

export const FILTER_OPERATORS = [
  { value: 'eq', label: '=' },
  { value: 'neq', label: '\u2260' },
  { value: 'gt', label: '>' },
  { value: 'gte', label: '\u2265' },
  { value: 'lt', label: '<' },
  { value: 'lte', label: '\u2264' },
  { value: 'like', label: 'Contains' },
  { value: 'in', label: 'In' },
];

export const AGG_MEASURE = ['', 'SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
export const AGG_DIMENSION = ['', 'COUNT'];

export const TRANSFORMS: Record<string, string[]> = {
  date: ['', 'YEAR', 'MONTH', 'DAY'],
  string: ['', 'UPPER', 'LOWER', 'TRIM'],
  number: ['', 'ROUND', 'ABS'],
  boolean: [''],
};
