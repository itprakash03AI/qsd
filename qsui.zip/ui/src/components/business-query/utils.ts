/**
 * Phase 130-E — Shared utilities for BusinessQueryBuilder sub-components.
 */

/** Quote a SQL identifier (column/table name) — prevents injection + handles spaces/keywords. */
export const qid = (name: string): string => `"${name.replace(/"/g, '""')}"`;

// BF-427: safeStringify promoted to src/utils/safeStringify.ts so the entire
// product can use it (admin save handlers, useServerDraft, error formatting,
// storage writes).  Re-exported here for back-compat with BF-426 callers.
export { safeStringify } from '../../utils/safeStringify';

/** Build SQL expression for a column with optional aggregation + transform. */
export const buildExpr = (physical: string, agg: string, transform: string): string => {
  const col = qid(physical);
  let inner = col;
  if (transform === 'ROUND') inner = `ROUND(${col}, 2)`;
  else if (transform) inner = `${transform}(${col})`;

  if (!agg) return inner;
  if (agg === 'COUNT_DISTINCT') return `COUNT(DISTINCT ${col})`;
  return `${agg}(${inner})`;
};

/** Regex matching common ETL/DW type prefixes and suffixes to strip from display names. */
const _ETL_PREFIX = /^(fk_|ref_|src_|dim_|dn_|dw_|etl_|raw_|stg_)/i;
const _ETL_SUFFIX = /_(dn|dw|etl|raw|stg|fk|ref|src|dim)$/i;

/**
 * Format a physical column name as a human-readable alias.
 * Strips ETL/DW type prefixes (dn_, dw_, etl_, raw_, stg_, fk_, dim_, ref_, src_)
 * and equivalent suffixes so 'dn_amount' → "Amount", 'amount_dn' → "Amount".
 * Physical column names are never changed — only the display label is affected.
 * SYSTEM_CODE → "System Code", CPTY_DT → "Cpty Dt"
 */
export const toAlias = (name: string): string => {
  const stripped = name.replace(_ETL_PREFIX, '').replace(_ETL_SUFFIX, '');
  const result = stripped.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
  return result || name.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
};

/**
 * Build a SQL window function expression from structured modal data.
 * Returns null if the entry is invalid (no alias).
 */
export const buildWindowExpr = (wf: any): string | null => {
  if (!wf.alias) return null;
  const col = wf.column ? qid(wf.column) : '';
  let fnCall: string;
  if (['LAG', 'LEAD'].includes(wf.function) && col) {
    const offset = wf.offset || 1;
    const def = wf.default_value ? `, ${wf.default_value}` : '';
    fnCall = `${wf.function}(${col}, ${offset}${def})`;
  } else {
    fnCall = col ? `${wf.function}(${col})` : `${wf.function}()`;
  }
  const partBy = (wf.partition_by || []).length > 0
    ? `PARTITION BY ${(wf.partition_by as string[]).map(c => qid(c)).join(', ')} `
    : '';
  const ordBy = (wf.order_by || []).length > 0
    ? `ORDER BY ${(wf.order_by as any[]).map((o: any) => `${qid(o.column)} ${o.direction}`).join(', ')}`
    : '';
  return `${fnCall} OVER (${partBy}${ordBy})`;
};

/**
 * Build a CASE WHEN SQL expression from structured modal data.
 * Returns null if the entry is invalid.
 */
export const buildCaseExpr = (ce: any): string | null => {
  if (!ce.alias || !Array.isArray(ce.when_clauses) || ce.when_clauses.length === 0) return null;
  const esc = (v: any) => String(v ?? '').replace(/'/g, "''");
  const whenParts = ce.when_clauses.map((w: any) => {
    const col = qid(w.when_column || '');
    const val = `'${esc(w.when_value)}'`;
    let cond: string;
    switch (w.when_operator) {
      case 'is_null':     cond = `${col} IS NULL`; break;
      case 'is_not_null': cond = `${col} IS NOT NULL`; break;
      case 'neq':  cond = `${col} != ${val}`; break;
      case 'gte':  cond = `${col} >= ${val}`; break;
      case 'lte':  cond = `${col} <= ${val}`; break;
      case 'gt':   cond = `${col} > ${val}`; break;
      case 'lt':   cond = `${col} < ${val}`; break;
      case 'like': cond = `${col} LIKE '%${esc(w.when_value)}%'`; break;
      default:     cond = `${col} = ${val}`;
    }
    return `WHEN ${cond} THEN '${esc(w.then_value)}'`;
  });
  const elseClause = ce.else_value ? ` ELSE '${esc(ce.else_value)}'` : '';
  return `CASE ${whenParts.join(' ')}${elseClause} END`;
};

/** Tiny MUI Select style shared by agg/transform chip dropdowns. */
export const tinySelectSx = {
  height: 20, fontSize: '0.6rem', minWidth: 42,
  '& .MuiSelect-select': { py: 0, px: 0.4, fontSize: '0.6rem' },
  '& .MuiOutlinedInput-notchedOutline': { borderColor: 'divider' },
  borderRadius: '4px',
};

// ── Smart Defaults: Column Frequency Tracking ─────────────────────
const FREQ_PREFIX = 'qs_bqb_col_freq_';

/** Record that a column was selected for a table. */
export const trackColumnUse = (connId: number, tablePath: string, colName: string) => {
  const key = `${FREQ_PREFIX}${connId}_${tablePath}`;
  try {
    const data: Record<string, number> = JSON.parse(localStorage.getItem(key) || '{}');
    data[colName] = (data[colName] || 0) + 1;
    localStorage.setItem(key, JSON.stringify(data));
  } catch { /* ignore storage errors */ }
};

/** Get frequently-used columns for a table (used 3+ times). */
export const getFrequentColumns = (connId: number, tablePath: string): Set<string> => {
  const key = `${FREQ_PREFIX}${connId}_${tablePath}`;
  try {
    const data: Record<string, number> = JSON.parse(localStorage.getItem(key) || '{}');
    return new Set(Object.entries(data).filter(([, count]) => count >= 3).map(([col]) => col));
  } catch {
    return new Set();
  }
};
