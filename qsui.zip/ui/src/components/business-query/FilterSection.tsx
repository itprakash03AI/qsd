/**
 * Phase 130-E — Filter rows extracted from BusinessQueryBuilder.
 */
import React from 'react';
import {
  Box, Typography, Paper, Button, TextField, Select, MenuItem,
  FormControl, IconButton, Alert, Autocomplete, Tooltip,
} from '@mui/material';
import FilterListIcon from '@mui/icons-material/FilterList';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import type { MappedColumn, BusinessFilter } from './types';
import { FILTER_OPERATORS } from './types';

export interface FilterSectionProps {
  filters: BusinessFilter[];
  onAddFilter: () => void;
  onRemoveFilter: (id: string) => void;
  onFilterChange: (id: string, field: string, value: string) => void;
  partitionValues: Record<string, string[]>;
  partitionColumns: string[];
  hasPartitionFilter: boolean;
  /** Pre-sorted: partition cols first, then alphabetical. Passed from BQB via sortedMappedColumns. */
  mappedColumns: MappedColumn[];
  hasSelectedColumns: boolean;
  filterLogic?: 'AND' | 'OR';
  onFilterLogicChange?: (v: 'AND' | 'OR') => void;
}

const FilterSection: React.FC<FilterSectionProps> = ({
  filters, onAddFilter, onRemoveFilter, onFilterChange,
  partitionValues, partitionColumns,
  hasPartitionFilter, mappedColumns, hasSelectedColumns,
  filterLogic = 'AND', onFilterLogicChange,
}) => (
  // Compact bar when no filters yet (~28px); expands as filters are added.
  // Padding tightens to py:0.25 for the empty state — gives the result grid
  // back ~16px of vertical real estate per section.
  <Paper elevation={0} sx={{
    px: 1, py: filters.length > 0 ? 0.75 : 0.25,
    flexShrink: 0, border: '1px solid', borderColor: 'divider',
  }}>
    <Box sx={{ display: 'flex', alignItems: 'center', mb: filters.length > 0 ? 0.5 : 0 }}>
      <FilterListIcon sx={{ fontSize: 14, mr: 0.5 }} />
      <Typography variant="caption" sx={{ fontWeight: 700, flexGrow: 1, fontSize: '0.7rem' }}>
        Filters {filters.length > 0 ? `(${filters.length})` : ''}
      </Typography>
      {filters.length > 1 && onFilterLogicChange && (
        <Button size="small" variant="outlined"
          onClick={() => onFilterLogicChange(filterLogic === 'AND' ? 'OR' : 'AND')}
          sx={{ fontSize: '0.65rem', py: 0, minHeight: 20, mr: 0.5, minWidth: 40,
            fontWeight: 700, borderColor: filterLogic === 'OR' ? 'warning.main' : 'primary.main',
            color: filterLogic === 'OR' ? 'warning.main' : 'primary.main',
          }}>
          {filterLogic}
        </Button>
      )}
      <Button size="small" startIcon={<AddIcon sx={{ fontSize: 14 }} />} onClick={onAddFilter}
        disabled={mappedColumns.length === 0}
        sx={{ fontSize: '0.7rem', py: 0, minHeight: 22 }}>Add</Button>
    </Box>
    {filters.map(f => (
      <Box key={f.id} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
        <FormControl size="small" sx={{ minWidth: 160 }}>
          <Select value={f.physical_name}
            onChange={e => onFilterChange(f.id, 'physical_name', e.target.value)}
            sx={{ height: 28, fontSize: '0.8rem' }}>
            {mappedColumns.map(col => (
              <MenuItem key={col.physical_name} value={col.physical_name}
                sx={col.is_partition ? { fontWeight: 600, bgcolor: 'action.hover' } : undefined}>
                {col.friendly_name}{col.is_partition ? ' ⚡' : ''}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 80 }}>
          <Select value={f.operator} onChange={e => onFilterChange(f.id, 'operator', e.target.value)}
            sx={{ height: 28, fontSize: '0.8rem' }}>
            {FILTER_OPERATORS.map(op => (
              <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
            ))}
          </Select>
        </FormControl>
        {f.is_partition && partitionValues[f.physical_name]?.length > 0 ? (
          <Autocomplete
            size="small" freeSolo
            options={partitionValues[f.physical_name]}
            inputValue={f.value}
            onInputChange={(_e, val) => onFilterChange(f.id, 'value', val || '')}
            renderInput={(params) => (
              <TextField {...params} size="small" placeholder="Select value..."
                sx={{ '& .MuiInputBase-root': { height: 28, fontSize: '0.8rem' } }} />
            )}
            sx={{ flexGrow: 1 }}
          />
        ) : (
          <TextField size="small" placeholder="Value..." value={f.value}
            onChange={e => onFilterChange(f.id, 'value', e.target.value)}
            sx={{ flexGrow: 1, '& .MuiInputBase-root': { height: 28, fontSize: '0.8rem' } }} />
        )}
        <Tooltip title="Remove this filter">
          <IconButton size="small" onClick={() => onRemoveFilter(f.id)} sx={{ p: 0.25 }}>
            <CloseIcon sx={{ fontSize: 16 }} />
          </IconButton>
        </Tooltip>
      </Box>
    ))}
    {hasSelectedColumns && partitionColumns.length > 0 && !hasPartitionFilter && (
      <Alert severity="info" variant="outlined" sx={{ py: 0, '& .MuiAlert-message': { py: 0.25 } }}>
        <Typography variant="caption" sx={{ fontSize: '0.7rem' }}>
          No partition filter -- adding one on{' '}
          {partitionColumns.slice(0, 2).map(p => {
            const col = mappedColumns.find(c => c.physical_name === p);
            return col?.friendly_name || p;
          }).join(', ')}{' '}improves speed.
        </Typography>
      </Alert>
    )}
  </Paper>
);

export default FilterSection;
