/**
 * Phase 130-E — Sort rows extracted from BusinessQueryBuilder.
 */
import React from 'react';
import {
  Box, Typography, Paper, Button, Select, MenuItem,
  FormControl, IconButton, Tooltip,
} from '@mui/material';
import SortIcon from '@mui/icons-material/Sort';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import type { MappedColumn, SortDef } from './types';

export interface SortSectionProps {
  sortColumns: SortDef[];
  onAddSort: () => void;
  onRemoveSort: (idx: number) => void;
  onSortChange: (idx: number, field: string, value: string) => void;
  /** Pre-sorted: partition cols first, then alphabetical. Passed from BQB via sortedMappedColumns. */
  mappedColumns: MappedColumn[];
}

const SortSection: React.FC<SortSectionProps> = ({
  sortColumns, onAddSort, onRemoveSort, onSortChange, mappedColumns,
}) => (
  // Compact when empty — see FilterSection for the same pattern.
  <Paper elevation={0} sx={{
    px: 1, py: sortColumns.length > 0 ? 0.75 : 0.25,
    flexShrink: 0, border: '1px solid', borderColor: 'divider',
  }}>
    <Box sx={{ display: 'flex', alignItems: 'center', mb: sortColumns.length > 0 ? 0.5 : 0 }}>
      <SortIcon sx={{ fontSize: 14, mr: 0.5 }} />
      <Typography variant="caption" sx={{ fontWeight: 700, flexGrow: 1, fontSize: '0.7rem' }}>
        Sort {sortColumns.length > 0 ? `(${sortColumns.length})` : ''}
      </Typography>
      <Button size="small" startIcon={<AddIcon sx={{ fontSize: 14 }} />} onClick={onAddSort}
        disabled={mappedColumns.length === 0}
        sx={{ fontSize: '0.7rem', py: 0, minHeight: 22 }}>Add</Button>
    </Box>
    {sortColumns.map((s, idx) => (
      <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
        <FormControl size="small" sx={{ minWidth: 180 }}>
          <Select value={s.column}
            onChange={e => onSortChange(idx, 'column', e.target.value)}
            sx={{ height: 28, fontSize: '0.8rem' }}>
            {mappedColumns.map(col => (
              <MenuItem key={col.physical_name} value={col.physical_name}
                sx={col.is_partition ? { fontWeight: 600 } : undefined}>
                {col.friendly_name}{col.is_partition ? ' ⚡' : ''}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button size="small" variant="outlined"
          onClick={() => onSortChange(idx, 'direction', s.direction === 'ASC' ? 'DESC' : 'ASC')}
          sx={{ fontSize: '0.7rem', minWidth: 50, height: 28, px: 0.5 }}>
          {s.direction}
        </Button>
        <Tooltip title="Remove this sort">
          <IconButton size="small" onClick={() => onRemoveSort(idx)} sx={{ p: 0.25 }}>
            <CloseIcon sx={{ fontSize: 16 }} />
          </IconButton>
        </Tooltip>
      </Box>
    ))}
  </Paper>
);

export default SortSection;
