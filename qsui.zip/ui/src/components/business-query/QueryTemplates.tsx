/**
 * Phase 134 — Query template selector for BusinessQueryBuilder.
 * Pre-built patterns that fill builder state with common query shapes.
 */
import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  List, ListItem, ListItemButton, ListItemText, ListItemIcon,
  Chip, Typography,
} from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import FunctionsIcon from '@mui/icons-material/Functions';
import FilterListIcon from '@mui/icons-material/FilterList';
import BarChartIcon from '@mui/icons-material/BarChart';

export interface QueryTemplate {
  id: string;
  name: string;
  description: string;
  icon: 'top_n' | 'yoy' | 'running_total' | 'distinct_count' | 'period_compare';
  /** SQL skeleton with placeholders */
  sqlTemplate: string;
  /** Suggest which column types to select */
  suggestTypes?: { measures?: boolean; dates?: boolean; dimensions?: boolean };
}

const BUILT_IN_TEMPLATES: QueryTemplate[] = [
  {
    id: 'top_n',
    name: 'Top N',
    description: 'Top N rows by a measure column (descending)',
    icon: 'top_n',
    sqlTemplate: 'SELECT {dimensions}, {measure}\nFROM {table}\nORDER BY {measure} DESC\nLIMIT {N}',
    suggestTypes: { measures: true, dimensions: true },
  },
  {
    id: 'yoy',
    name: 'Year-over-Year',
    description: 'Aggregate by year for period comparison',
    icon: 'yoy',
    sqlTemplate: 'SELECT YEAR({date_col}) AS yr, SUM({measure}) AS total\nFROM {table}\nGROUP BY yr\nORDER BY yr',
    suggestTypes: { measures: true, dates: true },
  },
  {
    id: 'running_total',
    name: 'Running Total',
    description: 'Cumulative sum using a window function',
    icon: 'running_total',
    sqlTemplate: 'SELECT {dimensions}, {measure},\n  SUM({measure}) OVER (ORDER BY {date_col}) AS running_total\nFROM {table}',
    suggestTypes: { measures: true, dates: true },
  },
  {
    id: 'distinct_count',
    name: 'Distinct Count',
    description: 'Count distinct values grouped by a dimension',
    icon: 'distinct_count',
    sqlTemplate: 'SELECT {dimension}, COUNT(DISTINCT {id_col}) AS unique_count\nFROM {table}\nGROUP BY {dimension}\nORDER BY unique_count DESC',
    suggestTypes: { dimensions: true },
  },
  {
    id: 'period_compare',
    name: 'Period Comparison',
    description: 'Compare current vs prior period side-by-side',
    icon: 'period_compare',
    sqlTemplate: 'SELECT {dimension},\n  SUM(CASE WHEN {date_col} >= {current_start} THEN {measure} END) AS current_period,\n  SUM(CASE WHEN {date_col} < {current_start} THEN {measure} END) AS prior_period\nFROM {table}\nGROUP BY {dimension}',
    suggestTypes: { measures: true, dates: true, dimensions: true },
  },
];

const ICON_MAP: Record<string, React.ReactElement> = {
  top_n: <BarChartIcon />,
  yoy: <TrendingUpIcon />,
  running_total: <FunctionsIcon />,
  distinct_count: <FilterListIcon />,
  period_compare: <CompareArrowsIcon />,
};

export interface QueryTemplatesProps {
  open: boolean;
  onClose: () => void;
  onSelect: (template: QueryTemplate) => void;
}

const QueryTemplates: React.FC<QueryTemplatesProps> = ({ open, onClose, onSelect }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
    <DialogTitle sx={{ pb: 0.5 }}>Query Templates</DialogTitle>
    <DialogContent sx={{ p: 0 }}>
      <Typography variant="caption" color="text.secondary" sx={{ px: 3, display: 'block', mb: 1 }}>
        Select a template to pre-fill the SQL editor with a common query pattern.
      </Typography>
      <List dense>
        {BUILT_IN_TEMPLATES.map(t => (
          <ListItem key={t.id} disablePadding>
            <ListItemButton onClick={() => { onSelect(t); onClose(); }}>
              <ListItemIcon sx={{ minWidth: 36 }}>
                {ICON_MAP[t.icon] || <BarChartIcon />}
              </ListItemIcon>
              <ListItemText
                primary={t.name}
                secondary={t.description}
                primaryTypographyProps={{ fontWeight: 600, fontSize: '0.85rem' }}
                secondaryTypographyProps={{ fontSize: '0.75rem' }}
              />
              {t.suggestTypes?.measures && <Chip label="Measure" size="small" sx={{ height: 18, fontSize: '0.6rem', mr: 0.3 }} />}
              {t.suggestTypes?.dates && <Chip label="Date" size="small" color="info" sx={{ height: 18, fontSize: '0.6rem', mr: 0.3 }} />}
              {t.suggestTypes?.dimensions && <Chip label="Dim" size="small" color="secondary" sx={{ height: 18, fontSize: '0.6rem' }} />}
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Cancel</Button>
    </DialogActions>
  </Dialog>
);

export default QueryTemplates;
