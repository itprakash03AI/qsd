/**
 * Phase 130-E — Join banner extracted from BusinessQueryBuilder.
 */
import React from 'react';
import {
  Paper, Typography, Select, MenuItem, FormControl, IconButton, Tooltip,
} from '@mui/material';
import LinkIcon from '@mui/icons-material/Link';
import CloseIcon from '@mui/icons-material/Close';
import type { MappedColumn, JoinConfig } from './types';

export interface JoinBannerProps {
  joinConfig: JoinConfig;
  onJoinConfigChange: (cfg: JoinConfig | null) => void;
  mappedColumns: MappedColumn[];
  displayTableName: (path: string) => string;
}

const JoinBanner: React.FC<JoinBannerProps> = ({
  joinConfig, onJoinConfigChange, mappedColumns, displayTableName,
}) => (
  <Paper elevation={0} sx={{
    px: 1, py: 0.5, flexShrink: 0, display: 'flex', alignItems: 'center', gap: 0.75,
    border: '1px solid', borderColor: 'info.light', bgcolor: 'info.50',
  }}>
    <LinkIcon sx={{ fontSize: 16, color: 'info.main' }} />
    <Typography variant="caption" sx={{ fontWeight: 600, fontSize: '0.75rem' }}>JOIN:</Typography>
    <Typography variant="caption" sx={{ fontSize: '0.72rem' }}>
      {displayTableName(joinConfig.leftTable)}
    </Typography>
    <Select value={joinConfig.joinType} size="small"
      onChange={e => onJoinConfigChange({ ...joinConfig, joinType: e.target.value as 'INNER' | 'LEFT' })}
      sx={{ height: 22, fontSize: '0.7rem', minWidth: 70, '& .MuiSelect-select': { py: 0, px: 0.5 } }}>
      <MenuItem value="INNER" sx={{ fontSize: '0.7rem' }}>INNER</MenuItem>
      <MenuItem value="LEFT" sx={{ fontSize: '0.7rem' }}>LEFT</MenuItem>
    </Select>
    <Typography variant="caption" sx={{ fontSize: '0.72rem' }}>JOIN {displayTableName(joinConfig.rightTable)} ON</Typography>
    <FormControl size="small">
      <Select value={joinConfig.leftCol} size="small"
        onChange={e => onJoinConfigChange({ ...joinConfig, leftCol: e.target.value })}
        sx={{ height: 22, fontSize: '0.7rem', minWidth: 90, '& .MuiSelect-select': { py: 0, px: 0.5 } }}>
        {mappedColumns.filter(c => c.source_table === joinConfig.leftTable).map(c => (
          <MenuItem key={c.physical_name} value={c.physical_name} sx={{ fontSize: '0.7rem' }}>{c.physical_name}</MenuItem>
        ))}
      </Select>
    </FormControl>
    <Typography variant="caption">=</Typography>
    <FormControl size="small">
      <Select value={joinConfig.rightCol} size="small"
        onChange={e => onJoinConfigChange({ ...joinConfig, rightCol: e.target.value })}
        sx={{ height: 22, fontSize: '0.7rem', minWidth: 90, '& .MuiSelect-select': { py: 0, px: 0.5 } }}>
        {mappedColumns.filter(c => c.source_table === joinConfig.rightTable).map(c => (
          <MenuItem key={c.physical_name} value={c.physical_name} sx={{ fontSize: '0.7rem' }}>{c.physical_name}</MenuItem>
        ))}
      </Select>
    </FormControl>
    <Tooltip title="Remove this join">
      <IconButton size="small" onClick={() => onJoinConfigChange(null)} sx={{ p: 0.25, ml: 'auto' }}>
        <CloseIcon sx={{ fontSize: 14 }} />
      </IconButton>
    </Tooltip>
  </Paper>
);

export default JoinBanner;
