/**
 * Phase 138 — ConditionsBar: single-row chip bar that combines filters + sort.
 *
 * Replaces the two stacked Paper sections that ate ~80px of vertical space
 * even when empty.  Snowsight / Databricks pattern: each filter / sort is a
 * removable chip on a single row; clicking a chip opens a popover for inline
 * editing.  Adding a new filter or sort opens an empty-state popover.
 *
 * Vertical footprint:
 *   * Empty:    ~30px (single row with two "+" buttons)
 *   * Active:   single row (chips wrap if many)
 *
 * Net win for the result grid: ~50–60px when no filters/sorts; same as the
 * old layout when populated, but more visually compact.
 */
import React, { useState, useCallback, useMemo } from 'react';
import {
  Box, Chip, Button, Popover, Stack, Select, MenuItem,
  FormControl, TextField, IconButton, Typography, Autocomplete, Tooltip,
  Alert,
} from '@mui/material';
import FilterListIcon from '@mui/icons-material/FilterList';
import SortIcon from '@mui/icons-material/Sort';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import type { MappedColumn, BusinessFilter, SortDef } from './types';
import { FILTER_OPERATORS } from './types';

export interface ConditionsBarProps {
  // Filter props
  filters: BusinessFilter[];
  onAddFilter: () => void;
  onRemoveFilter: (id: string) => void;
  onFilterChange: (id: string, field: string, value: string) => void;
  partitionValues: Record<string, string[]>;
  partitionColumns: string[];
  hasPartitionFilter: boolean;
  hasSelectedColumns: boolean;
  filterLogic?: 'AND' | 'OR';
  onFilterLogicChange?: (v: 'AND' | 'OR') => void;
  // Sort props
  sortColumns: SortDef[];
  onAddSort: () => void;
  onRemoveSort: (idx: number) => void;
  onSortChange: (idx: number, field: string, value: string) => void;
  // Shared
  /** Pre-sorted: partition cols first, then alphabetical. */
  mappedColumns: MappedColumn[];
}

const opLabel = (op: string): string => {
  const m = FILTER_OPERATORS.find(o => o.value === op);
  return m ? m.label : op;
};

const friendlyOf = (mappedColumns: MappedColumn[], physical: string): string => {
  const c = mappedColumns.find(c => c.physical_name === physical);
  return c?.friendly_name || physical;
};

// ── Filter editor popover content ──────────────────────────────────────────
const FilterEditor: React.FC<{
  filter: BusinessFilter;
  mappedColumns: MappedColumn[];
  partitionValues: Record<string, string[]>;
  onChange: (id: string, field: string, value: string) => void;
  onRemove: (id: string) => void;
  onClose: () => void;
}> = ({ filter, mappedColumns, partitionValues, onChange, onRemove, onClose }) => (
  <Box sx={{ p: 1.5, minWidth: 360 }}>
    <Stack direction="row" spacing={1} alignItems="center" mb={1}>
      <FilterListIcon fontSize="small" sx={{ color: 'primary.main' }} />
      <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Edit filter</Typography>
      <Tooltip title="Remove this filter">
        <IconButton size="small" onClick={() => { onRemove(filter.id); onClose(); }}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Stack>
    <Stack spacing={1}>
      <FormControl size="small" fullWidth>
        <Select
          value={filter.physical_name}
          onChange={e => onChange(filter.id, 'physical_name', e.target.value)}
          sx={{ fontSize: '0.85rem' }}
        >
          {mappedColumns.map(col => (
            <MenuItem
              key={col.physical_name}
              value={col.physical_name}
              sx={col.is_partition ? { fontWeight: 600, bgcolor: 'action.hover' } : undefined}
            >
              {col.friendly_name}{col.is_partition ? ' ⚡' : ''}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl size="small" fullWidth>
        <Select
          value={filter.operator}
          onChange={e => onChange(filter.id, 'operator', e.target.value)}
          sx={{ fontSize: '0.85rem' }}
        >
          {FILTER_OPERATORS.map(op => (
            <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
          ))}
        </Select>
      </FormControl>
      {filter.is_partition && (partitionValues[filter.physical_name] || []).length > 0 ? (
        <Autocomplete
          size="small"
          freeSolo
          options={partitionValues[filter.physical_name]}
          inputValue={filter.value}
          onInputChange={(_e, val) => onChange(filter.id, 'value', val || '')}
          renderInput={params => <TextField {...params} placeholder="Value..." />}
        />
      ) : (
        <TextField
          size="small"
          fullWidth
          placeholder="Value..."
          value={filter.value}
          onChange={e => onChange(filter.id, 'value', e.target.value)}
        />
      )}
    </Stack>
  </Box>
);

// ── Sort editor popover content ────────────────────────────────────────────
const SortEditor: React.FC<{
  sort: SortDef;
  index: number;
  mappedColumns: MappedColumn[];
  onChange: (idx: number, field: string, value: string) => void;
  onRemove: (idx: number) => void;
  onClose: () => void;
}> = ({ sort, index, mappedColumns, onChange, onRemove, onClose }) => (
  <Box sx={{ p: 1.5, minWidth: 320 }}>
    <Stack direction="row" spacing={1} alignItems="center" mb={1}>
      <SortIcon fontSize="small" sx={{ color: 'primary.main' }} />
      <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Edit sort</Typography>
      <Tooltip title="Remove this sort">
        <IconButton size="small" onClick={() => { onRemove(index); onClose(); }}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Stack>
    <Stack spacing={1}>
      <FormControl size="small" fullWidth>
        <Select
          value={sort.column}
          onChange={e => onChange(index, 'column', e.target.value)}
          sx={{ fontSize: '0.85rem' }}
        >
          {mappedColumns.map(col => (
            <MenuItem
              key={col.physical_name}
              value={col.physical_name}
              sx={col.is_partition ? { fontWeight: 600 } : undefined}
            >
              {col.friendly_name}{col.is_partition ? ' ⚡' : ''}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <Button
        size="small" variant="outlined"
        startIcon={sort.direction === 'ASC' ? <ArrowUpwardIcon /> : <ArrowDownwardIcon />}
        onClick={() => onChange(index, 'direction', sort.direction === 'ASC' ? 'DESC' : 'ASC')}
      >
        {sort.direction === 'ASC' ? 'Ascending' : 'Descending'}
      </Button>
    </Stack>
  </Box>
);

// ── Main bar ─────────────────────────────────────────────────────────────
const ConditionsBar: React.FC<ConditionsBarProps> = ({
  filters, onAddFilter, onRemoveFilter, onFilterChange,
  partitionValues, partitionColumns, hasPartitionFilter, hasSelectedColumns,
  filterLogic = 'AND', onFilterLogicChange,
  sortColumns, onAddSort, onRemoveSort, onSortChange,
  mappedColumns,
}) => {
  type Anchor = { type: 'filter' | 'sort'; key: string | number; el: HTMLElement } | null;
  const [anchor, setAnchor] = useState<Anchor>(null);

  const close = useCallback(() => setAnchor(null), []);

  const showPartitionHint = useMemo(
    () => hasSelectedColumns && partitionColumns.length > 0 && !hasPartitionFilter,
    [hasSelectedColumns, partitionColumns, hasPartitionFilter],
  );

  // Auto-open the latest filter/sort when the user clicks the + button so
  // they don't have to chase down a placeholder chip.
  const handleAddFilter = useCallback((e: React.MouseEvent<HTMLElement>) => {
    onAddFilter();
    // Wait for the new filter to land in props, then open its popover
    const trigger = e.currentTarget;
    setTimeout(() => {
      // BF-264: drop the off-by-one read.  filters[filters.length] is
      // always undefined (0-based indexing).  We don't have the new
      // filter's id yet so the marker key '__last__' is what gets used
      // downstream — the lookup was dead code anyway.
      setAnchor({ type: 'filter', key: '__last__', el: trigger });
    }, 0);
  }, [onAddFilter]);

  const handleAddSort = useCallback((e: React.MouseEvent<HTMLElement>) => {
    onAddSort();
    const trigger = e.currentTarget;
    setTimeout(() => {
      setAnchor({ type: 'sort', key: '__last__', el: trigger });
    }, 0);
  }, [onAddSort]);

  // Resolve "__last__" marker against current props
  const activeFilter = useMemo(() => {
    if (!anchor || anchor.type !== 'filter') return null;
    if (anchor.key === '__last__') return filters[filters.length - 1] || null;
    return filters.find(f => f.id === anchor.key) || null;
  }, [anchor, filters]);

  const activeSortIdx = useMemo<number | null>(() => {
    if (!anchor || anchor.type !== 'sort') return null;
    if (anchor.key === '__last__') return sortColumns.length - 1;
    return typeof anchor.key === 'number' ? anchor.key : null;
  }, [anchor, sortColumns]);

  const activeSort = activeSortIdx != null ? sortColumns[activeSortIdx] : null;

  const disabled = mappedColumns.length === 0;

  return (
    <Box sx={{ flexShrink: 0 }}>
      <Box sx={{
        display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0.5,
        px: 1, py: 0.5,
        border: '1px solid', borderColor: 'divider', borderRadius: 1,
        bgcolor: 'background.paper',
      }}>
        {/* Filters group */}
        <Tooltip title="Add filter">
          <span>
            <Button
              size="small"
              variant="text"
              disabled={disabled}
              startIcon={<FilterListIcon sx={{ fontSize: 14 }} />}
              endIcon={<AddIcon sx={{ fontSize: 14 }} />}
              onClick={handleAddFilter}
              sx={{ textTransform: 'none', py: 0, minHeight: 24, fontSize: '0.7rem', fontWeight: 700 }}
            >
              Filter
            </Button>
          </span>
        </Tooltip>

        {filters.length > 1 && onFilterLogicChange && (
          <Tooltip title={`Combine with ${filterLogic === 'AND' ? 'OR' : 'AND'}`}>
            <Chip
              label={filterLogic}
              size="small"
              onClick={() => onFilterLogicChange(filterLogic === 'AND' ? 'OR' : 'AND')}
              sx={{
                height: 22, fontSize: '0.65rem', fontWeight: 700,
                bgcolor: filterLogic === 'OR' ? 'warning.lighter' : 'primary.lighter',
                color:   filterLogic === 'OR' ? 'warning.main'    : 'primary.main',
                cursor: 'pointer',
              }}
              style={{
                background: filterLogic === 'OR'
                  ? 'rgba(237, 108, 2, 0.12)'
                  : 'rgba(25, 118, 210, 0.12)',
              }}
            />
          </Tooltip>
        )}

        {filters.map(f => {
          const friendly = friendlyOf(mappedColumns, f.physical_name);
          const valueDisplay = f.value || (f.operator === 'in' ? '…' : '');
          const label = `${friendly} ${opLabel(f.operator)} ${valueDisplay}`.trim();
          return (
            <Chip
              key={f.id}
              label={label}
              size="small"
              icon={<FilterListIcon sx={{ fontSize: 14 }} />}
              onClick={(e) => setAnchor({ type: 'filter', key: f.id, el: e.currentTarget })}
              onDelete={() => onRemoveFilter(f.id)}
              deleteIcon={<CloseIcon sx={{ fontSize: 14 }} />}
              sx={{
                height: 22, fontSize: '0.7rem', maxWidth: 260,
                fontFamily: 'monospace',
                bgcolor: f.is_partition ? 'action.selected' : undefined,
                cursor: 'pointer',
                '& .MuiChip-label': { textOverflow: 'ellipsis', overflow: 'hidden' },
              }}
            />
          );
        })}

        {/* Divider between filter & sort sections */}
        <Box sx={{ flexShrink: 0, width: 1, height: 18, bgcolor: 'divider', mx: 0.5 }} />

        {/* Sort group */}
        <Tooltip title="Add sort">
          <span>
            <Button
              size="small"
              variant="text"
              disabled={disabled}
              startIcon={<SortIcon sx={{ fontSize: 14 }} />}
              endIcon={<AddIcon sx={{ fontSize: 14 }} />}
              onClick={handleAddSort}
              sx={{ textTransform: 'none', py: 0, minHeight: 24, fontSize: '0.7rem', fontWeight: 700 }}
            >
              Sort
            </Button>
          </span>
        </Tooltip>

        {sortColumns.map((s, idx) => {
          const friendly = friendlyOf(mappedColumns, s.column);
          const arrow = s.direction === 'ASC' ? '↑' : '↓';
          return (
            <Chip
              key={`sort-${idx}-${s.column}`}
              label={`${arrow} ${friendly}`}
              size="small"
              onClick={(e) => setAnchor({ type: 'sort', key: idx, el: e.currentTarget })}
              onDelete={() => onRemoveSort(idx)}
              deleteIcon={<CloseIcon sx={{ fontSize: 14 }} />}
              sx={{
                height: 22, fontSize: '0.7rem', maxWidth: 200,
                cursor: 'pointer',
              }}
            />
          );
        })}

        {/* Spacer + count summary */}
        <Box sx={{ flexGrow: 1 }} />
        {(filters.length > 0 || sortColumns.length > 0) && (
          <Typography variant="caption" sx={{ color: 'text.disabled', fontSize: '0.65rem' }}>
            {filters.length} filter{filters.length === 1 ? '' : 's'}
            {' · '}
            {sortColumns.length} sort
          </Typography>
        )}
      </Box>

      {/* Partition pruning hint — outside the bar so it doesn't squeeze chips */}
      {showPartitionHint && (
        <Alert severity="info" variant="outlined" sx={{ py: 0, mt: 0.5, '& .MuiAlert-message': { py: 0.25 } }}>
          <Typography variant="caption" sx={{ fontSize: '0.7rem' }}>
            No partition filter — adding one on{' '}
            {partitionColumns.slice(0, 2).map(p => friendlyOf(mappedColumns, p)).join(', ')}{' '}
            improves speed.
          </Typography>
        </Alert>
      )}

      {/* Popover — single instance, content swaps based on anchor.type */}
      <Popover
        open={!!anchor}
        anchorEl={anchor?.el || null}
        onClose={close}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        {activeFilter && (
          <FilterEditor
            filter={activeFilter}
            mappedColumns={mappedColumns}
            partitionValues={partitionValues}
            onChange={onFilterChange}
            onRemove={onRemoveFilter}
            onClose={close}
          />
        )}
        {activeSort && activeSortIdx != null && (
          <SortEditor
            sort={activeSort}
            index={activeSortIdx}
            mappedColumns={mappedColumns}
            onChange={onSortChange}
            onRemove={onRemoveSort}
            onClose={close}
          />
        )}
      </Popover>
    </Box>
  );
};

export default ConditionsBar;
