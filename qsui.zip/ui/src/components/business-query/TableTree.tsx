/**
 * Phase 130-E — Table/column tree panel extracted from BusinessQueryBuilder.
 * Phase 134  — Type filter chips, MV/FED/ICE badges, favorites, context menu.
 */
import React, { useState, useCallback, useMemo } from 'react';
import {
  Box, Typography, Paper, TextField, Select, MenuItem,
  FormControl, Chip, IconButton, Accordion, AccordionSummary,
  AccordionDetails, Checkbox, InputAdornment, Tooltip,
  CircularProgress, SelectChangeEvent, Menu, Autocomplete,
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import StorageIcon from '@mui/icons-material/Storage';
import TableChartIcon from '@mui/icons-material/TableChart';
import BoltIcon from '@mui/icons-material/Bolt';
import LinkIcon from '@mui/icons-material/Link';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PreviewIcon from '@mui/icons-material/Preview';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import type { MappedColumn, TableOption, ConnectionOption } from './types';
import { AGG_MEASURE, AGG_DIMENSION, TRANSFORMS } from './types';
import { tinySelectSx } from './utils';
import api from '../../services/api';

// ── Badge config per table type ──────────────────────────────────
const TYPE_BADGES: Record<string, { label: string; color: string; bg: string }> = {
  registered:   { label: 'REG', color: '#1e40af', bg: '#dbeafe' },
  materialized: { label: 'MV',  color: '#7c3aed', bg: '#ede9fe' },
  local:        { label: 'LOCAL', color: '#d97706', bg: '#fef3c7' },
  federation:   { label: 'FED', color: '#047857', bg: '#d1fae5' },
  iceberg:      { label: 'ICE', color: '#0e7490', bg: '#cffafe' },
};

const TYPE_FILTER_CHIPS = [
  { key: 'all', label: 'ALL' },
  { key: 'registered', label: 'REG' },
  { key: 'materialized', label: 'MV' },
  { key: 'local', label: 'LOCAL' },
  { key: 'federation', label: 'FED' },
  { key: 'iceberg', label: 'ICE' },
];

export interface TableTreeProps {
  tables: TableOption[];
  selectedTables: TableOption[];
  onToggleTable: (t: TableOption) => void;
  tableSearch: string;
  onTableSearchChange: (v: string) => void;
  selectedConnId: number | null;
  connName: (id: number | null) => string;
  loadingColumns: boolean;
  columnsByTable: Record<string, Record<string, MappedColumn[]>>;
  selectedPhysical: Set<string>;
  onToggleColumn: (name: string) => void;
  onToggleCategory: (cat: string, cols: MappedColumn[]) => void;
  columnAggregations: Record<string, string>;
  onAggChange: (col: string, val: string) => void;
  columnTransforms: Record<string, string>;
  onTransformChange: (col: string, val: string) => void;
  panelOpen: boolean;
  onPanelToggle: () => void;
  // Cross-connection
  showCrossConn: boolean;
  onToggleCrossConn: () => void;
  crossConnId: number | null;
  onCrossConnChange: (id: number | null) => void;
  connections: ConnectionOption[];
  crossTables: TableOption[];
  selectedCrossTables: TableOption[];
  onToggleCrossTable: (t: TableOption) => void;
  crossConnMode?: 'union' | 'join';
  onCrossConnModeChange?: (mode: 'union' | 'join') => void;
  crossJoinLeftOn?: string;
  crossJoinRightOn?: string;
  onCrossJoinLeftOnChange?: (col: string) => void;
  onCrossJoinRightOnChange?: (col: string) => void;
  crossJoinHow?: string;
  onCrossJoinHowChange?: (how: string) => void;
  allColumnNames?: string[];
  filteredTables: TableOption[];
  filteredCrossTables: TableOption[];
  // Phase 134 — type filter + favorites + smart defaults
  tableTypeFilter?: string;
  onTypeFilterChange?: (v: string) => void;
  tableFavorites?: Set<string>;
  frequentColumns?: Record<string, Set<string>>;
  // User-triggered schema refresh — mirrors CQB's schema-refresh
  // button.  Forces a fresh live S3 read AND bypasses both the
  // browser-side ``columnCache`` and the backend's L1/L2 cache.
  // No-op when no tables are selected.
  onRefreshSchema?: () => void;
}

interface ColumnsForTableProps {
  tablePath: string;
  catGroups: Record<string, MappedColumn[]>;
  selectedPhysical: Set<string>;
  onToggleColumn: (name: string) => void;
  onToggleCategory: (cat: string, cols: MappedColumn[]) => void;
  columnAggregations: Record<string, string>;
  onAggChange: (col: string, val: string) => void;
  columnTransforms: Record<string, string>;
  onTransformChange: (col: string, val: string) => void;
  frequentCols?: Set<string>;
  searchQuery?: string;
}

// ── ColumnRow — memoized per-column renderer ─────────────────────────────────
// Phase 138 fix: with 1000+ columns, "select all" was unresponsive because the
// Set identity change forced ColumnsForTable to re-render every row.  Each row
// has Checkbox + 2 Typography + (when checked) 2 Selects + Chip + Tooltip ≈ 6
// MUI components — 1000 rows × 6 = 6000 React elements per click.
//
// Splitting the row into its own React.memo'd component with PRIMITIVE props
// (isChecked: boolean, currentAgg: string, currentTransform: string) means
// memo's shallow-equality check short-circuits unchanged rows — only the row
// whose isChecked actually flipped re-renders.  Select-all on a category
// toggles every row's isChecked, but the inner Box JSX is identical so the
// render is fast.
interface ColumnRowProps {
  col: MappedColumn;
  isChecked: boolean;
  currentAgg: string;
  currentTransform: string;
  isFrequent: boolean;
  searchQuery?: string;
  onToggle: (name: string) => void;
  onAggChange: (col: string, val: string) => void;
  onTransformChange: (col: string, val: string) => void;
}

const ColumnRow = React.memo<ColumnRowProps>(({
  col, isChecked, currentAgg, currentTransform, isFrequent, searchQuery,
  onToggle, onAggChange, onTransformChange,
}) => {
  const aggOptions = col.column_type === 'measure' ? AGG_MEASURE : AGG_DIMENSION;
  const transformOptions = TRANSFORMS[col.data_type] || [''];
  const matches = !!(searchQuery && searchQuery.length >= 2 &&
    (col.physical_name.toLowerCase().includes(searchQuery) ||
     col.friendly_name.toLowerCase().includes(searchQuery)));
  return (
    <Box
      sx={{
        display: 'flex', alignItems: 'center', py: 0.1, px: 0.25,
        cursor: 'pointer', borderRadius: 0.5,
        '&:hover': { bgcolor: 'action.hover' },
      }}
      onClick={() => onToggle(col.physical_name)}
    >
      <Checkbox size="small" checked={isChecked} sx={{ p: 0.1, mr: 0.25 }} />
      <Box sx={{ flexGrow: 1, minWidth: 0 }}>
        <Typography variant="caption" noWrap
          sx={{
            fontWeight: 500, display: 'block', lineHeight: 1.3, fontSize: '0.72rem',
            ...(matches ? { bgcolor: 'warning.light', color: 'warning.contrastText', px: 0.3, borderRadius: 0.5 } : {}),
          }}>
          {col.friendly_name}
          {isFrequent && (
            <Tooltip title="Frequently used column">
              <StarIcon sx={{ fontSize: 10, color: 'warning.main', ml: 0.3, verticalAlign: 'middle' }} />
            </Tooltip>
          )}
        </Typography>
        <Typography variant="caption" color="text.secondary" noWrap
          sx={{ fontSize: '0.6rem', display: 'block', lineHeight: 1.1, opacity: 0.7 }}>
          {col.physical_name}
        </Typography>
      </Box>

      {/* Inline aggregation dropdown (only when checked) */}
      {isChecked && aggOptions.length > 1 && (
        <Tooltip title="Aggregation (SUM, AVG, COUNT...)">
          <Select
            value={currentAgg} displayEmpty size="small"
            renderValue={v => v || 'Agg'}
            onClick={e => e.stopPropagation()}
            onChange={e => { e.stopPropagation(); onAggChange(col.physical_name, e.target.value); }}
            sx={{
              ...tinySelectSx, ml: 0.25,
              bgcolor: currentAgg ? 'primary.50' : undefined,
              color: currentAgg ? 'primary.main' : 'text.secondary',
              fontWeight: currentAgg ? 600 : 400,
            }}
          >
            <MenuItem value="" sx={{ fontSize: '0.65rem', color: 'text.secondary' }}>None</MenuItem>
            {aggOptions.filter(o => o).map(o => (
              <MenuItem key={o} value={o} sx={{ fontSize: '0.65rem' }}>{o}</MenuItem>
            ))}
          </Select>
        </Tooltip>
      )}

      {/* Inline transform dropdown */}
      {isChecked && transformOptions.length > 1 && (
        <Tooltip title="Transform (YEAR, UPPER, ROUND...)">
          <Select
            value={currentTransform} displayEmpty size="small"
            renderValue={v => v || 'Fn'}
            onClick={e => e.stopPropagation()}
            onChange={e => { e.stopPropagation(); onTransformChange(col.physical_name, e.target.value); }}
            sx={{
              ...tinySelectSx, ml: 0.25,
              bgcolor: currentTransform ? 'secondary.50' : undefined,
              color: currentTransform ? 'secondary.main' : 'text.secondary',
              fontWeight: currentTransform ? 600 : 400,
            }}
          >
            <MenuItem value="" sx={{ fontSize: '0.65rem', color: 'text.secondary' }}>None (raw value)</MenuItem>
            {transformOptions.filter(t => t).map(t => (
              <MenuItem key={t} value={t} sx={{ fontSize: '0.65rem' }}>{t}</MenuItem>
            ))}
          </Select>
        </Tooltip>
      )}

      {col.is_partition && (
        <Tooltip title="Partition column">
          <BoltIcon sx={{ fontSize: 12, color: 'warning.main', ml: 0.25 }} />
        </Tooltip>
      )}
      <Chip
        label={col.column_type === 'measure' ? 'M' : 'D'}
        size="small"
        color={col.column_type === 'measure' ? 'primary' : 'default'}
        sx={{ height: 14, fontSize: '0.55rem', ml: 0.25, minWidth: 16 }}
      />
    </Box>
  );
});
ColumnRow.displayName = 'ColumnRow';

/** Render category > column tree for a single table.
 * React.memo prevents re-renders when unrelated BQB state (sqlText, etc.) changes. */
const ColumnsForTable = React.memo<ColumnsForTableProps>(({
  catGroups, selectedPhysical, onToggleColumn, onToggleCategory,
  columnAggregations, onAggChange, columnTransforms, onTransformChange,
  frequentCols, searchQuery,
}) => (
  <>
    {Object.entries(catGroups).map(([catName, cols]) => {
      const allSelected = cols.every(c => selectedPhysical.has(c.physical_name));
      const someSelected = cols.some(c => selectedPhysical.has(c.physical_name));
      // Auto-expand categories when searching and columns match
      const hasSearchMatch = searchQuery && searchQuery.length >= 2 && cols.some(c =>
        c.physical_name.toLowerCase().includes(searchQuery) ||
        c.friendly_name.toLowerCase().includes(searchQuery)
      );
      return (
        <Accordion key={catName} defaultExpanded={!!hasSearchMatch} disableGutters
          sx={{ '&:before': { display: 'none' }, boxShadow: 'none' }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon sx={{ fontSize: 14 }} />}
            sx={{ minHeight: 24, pl: 2, pr: 0.5,
              '& .MuiAccordionSummary-content': { m: 0, alignItems: 'center' } }}>
            <Checkbox size="small" checked={allSelected}
              indeterminate={someSelected && !allSelected}
              onClick={e => { e.stopPropagation(); onToggleCategory(catName, cols); }}
              sx={{ p: 0.1, mr: 0.25 }} />
            <Typography variant="caption" sx={{ fontWeight: 600, flexGrow: 1, fontSize: '0.72rem' }}>
              {catName}
            </Typography>
            <Chip label={cols.length} size="small" sx={{ height: 14, fontSize: '0.55rem' }} />
          </AccordionSummary>
          <AccordionDetails sx={{ p: 0, pl: 2.5 }}>
            {cols.map(col => (
              <ColumnRow
                key={col.physical_name}
                col={col}
                isChecked={selectedPhysical.has(col.physical_name)}
                currentAgg={columnAggregations[col.physical_name] || ''}
                currentTransform={columnTransforms[col.physical_name] || ''}
                isFrequent={!!frequentCols?.has(col.physical_name)}
                searchQuery={searchQuery}
                onToggle={onToggleColumn}
                onAggChange={onAggChange}
                onTransformChange={onTransformChange}
              />
            ))}
          </AccordionDetails>
        </Accordion>
      );
    })}
  </>
));

ColumnsForTable.displayName = 'ColumnsForTable';

const TableTree: React.FC<TableTreeProps> = ({
  selectedTables, onToggleTable, tableSearch, onTableSearchChange,
  selectedConnId, connName, loadingColumns, columnsByTable,
  selectedPhysical, onToggleColumn, onToggleCategory,
  columnAggregations, onAggChange, columnTransforms, onTransformChange,
  panelOpen, onPanelToggle,
  showCrossConn, onToggleCrossConn, crossConnId, onCrossConnChange,
  connections, crossTables, selectedCrossTables, onToggleCrossTable,
  filteredTables, filteredCrossTables,
  crossConnMode = 'union', onCrossConnModeChange,
  crossJoinLeftOn = '', crossJoinRightOn = '', onCrossJoinLeftOnChange, onCrossJoinRightOnChange,
  crossJoinHow = 'inner', onCrossJoinHowChange,
  allColumnNames = [],
  tableTypeFilter = 'all', onTypeFilterChange,
  tableFavorites = new Set(),
  frequentColumns = {},
  onRefreshSchema,
}) => {
  // ── Column search across ALL tables ──────────────────────────
  const columnSearchMatch = useMemo(() => {
    const q = tableSearch.trim().toLowerCase();
    if (!q || q.length < 2) return null;
    // Check if search matches column names across all tables in columnsByTable
    const matchingTables: string[] = [];
    for (const [tablePath, catGroups] of Object.entries(columnsByTable)) {
      for (const cols of Object.values(catGroups)) {
        if (cols.some(c =>
          c.physical_name.toLowerCase().includes(q) ||
          c.friendly_name.toLowerCase().includes(q)
        )) {
          matchingTables.push(tablePath);
          break;
        }
      }
    }
    return matchingTables.length > 0 ? { query: q, tables: matchingTables } : null;
  }, [tableSearch, columnsByTable]);

  // ── Context menu state ────────────────────────────────────────
  const [ctxMenu, setCtxMenu] = useState<{ anchorEl: HTMLElement; table: TableOption } | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewData, setPreviewData] = useState<{ name: string; rows: any[]; columns: string[] } | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  const handleContextMenu = useCallback((e: React.MouseEvent<HTMLElement>, table: TableOption) => {
    e.preventDefault();
    e.stopPropagation();
    setCtxMenu({ anchorEl: e.currentTarget, table });
  }, []);

  const handlePreview = useCallback(async (table: TableOption) => {
    setCtxMenu(null);
    setPreviewLoading(true);
    setPreviewOpen(true);
    try {
      const res = await api.executeQuery({
        query_config: { files: [table.path], columns: ['*'], limit: 100 },
        raw_sql: `SELECT * FROM ${table.path.startsWith('__') ? table.name : table.path} LIMIT 100`,
        output_format: 'json',
      } as any);
      // Wait briefly then fetch results
      if (res.execution_id) {
        const data = await api.getExecutionResults(res.execution_id);
        const rows = data?.rows || data?.data || [];
        const columns = data?.columns?.map((c: any) => c.name || c) || (rows[0] ? Object.keys(rows[0]) : []);
        setPreviewData({ name: table.name, rows: rows.slice(0, 100), columns });
      }
    } catch {
      setPreviewData({ name: table.name, rows: [], columns: [] });
    } finally {
      setPreviewLoading(false);
    }
  }, [selectedConnId]);

  const handleToggleFavorite = useCallback(async (table: TableOption) => {
    setCtxMenu(null);
    try {
      await api.toggleTableFavorite({
        table_path: table.path,
        table_name: table.name,
        connection_id: selectedConnId || undefined,
      });
    } catch { /* silently fail */ }
  }, [selectedConnId]);

  const handleCopyName = useCallback((table: TableOption) => {
    navigator.clipboard.writeText(table.name);
    setCtxMenu(null);
  }, []);

  // Closed state: width:0 (fully hidden — matches CQB's behaviour).  The
  // re-open button is rendered by the parent (BusinessQueryBuilder) in the
  // toolbar so the user always has a way back without a 36px stub eating
  // result-grid real estate.
  if (!panelOpen) {
    return (
      <Box sx={{
        width: 0, minWidth: 0,
        transition: 'width 0.2s, min-width 0.2s',
        overflow: 'hidden',
      }} />
    );
  }

  return (
    <Paper elevation={1} sx={{
      width: 300, minWidth: 280,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
      transition: 'width 0.2s, min-width 0.2s',
    }}>
      {/* Panel header */}
      <Box sx={{
        display: 'flex', alignItems: 'center', px: 0.5, py: 0.25,
        borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50',
      }}>
        <IconButton size="small" onClick={onPanelToggle} sx={{ mr: 0.5 }} aria-label="Hide objects panel">
          <ChevronLeftIcon fontSize="small" />
        </IconButton>
        <Typography variant="caption" sx={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, flexGrow: 1 }}>
          Objects
        </Typography>
        {selectedPhysical.size > 0 && (
          <Chip label={`${selectedPhysical.size} cols`} size="small" color="primary"
            sx={{ height: 16, fontSize: '0.6rem' }} />
        )}
      </Box>

      {/* Body — early-return at top handles the closed state, so the rest of
          the panel always renders. */}
      <>
          {/* Search + Refresh schema */}
          {selectedConnId && (
            <Box sx={{ px: 0.5, py: 0.25, borderBottom: '1px solid', borderColor: 'divider',
                       display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <TextField
                size="small" fullWidth placeholder="Search tables & columns..."
                value={tableSearch} onChange={e => onTableSearchChange(e.target.value)}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment>,
                }}
                sx={{ '& .MuiInputBase-root': { height: 28, fontSize: '0.8rem' } }}
              />
              {/* Mirrors the CQB schema-refresh button.  Disabled when no
                  table is selected (nothing to refresh) or when a load is
                  already in flight.  Backend's stale-while-revalidate
                  means a transient S3 503 returns the previous cached
                  schema instead of crashing. */}
              {onRefreshSchema && (
                <Tooltip title={
                  selectedTables.length === 0
                    ? 'Select a table to refresh its schema'
                    : 'Refresh schema + partitions (forces fresh S3 read)'
                }>
                  <span>
                    <IconButton
                      size="small"
                      onClick={onRefreshSchema}
                      disabled={selectedTables.length === 0 || loadingColumns}
                      aria-label="Refresh schema"
                      sx={{ p: 0.5 }}
                    >
                      <RefreshIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </span>
                </Tooltip>
              )}
            </Box>
          )}

          {/* Column search match indicator */}
          {columnSearchMatch && (
            <Box sx={{ px: 0.5, py: 0.2, bgcolor: 'info.50', borderBottom: '1px solid', borderColor: 'divider' }}>
              <Typography variant="caption" sx={{ fontSize: '0.65rem', color: 'info.main', fontWeight: 600 }}>
                {columnSearchMatch.tables.length} table{columnSearchMatch.tables.length > 1 ? 's' : ''} have column matching "{columnSearchMatch.query}"
              </Typography>
            </Box>
          )}

          {/* Type filter chips */}
          {selectedConnId && onTypeFilterChange && (
            <Box sx={{
              display: 'flex', gap: 0.3, px: 0.5, py: 0.3, flexWrap: 'wrap',
              borderBottom: '1px solid', borderColor: 'divider',
            }}>
              {TYPE_FILTER_CHIPS.map(chip => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  variant={tableTypeFilter === chip.key ? 'filled' : 'outlined'}
                  color={tableTypeFilter === chip.key ? 'primary' : 'default'}
                  onClick={() => onTypeFilterChange(chip.key)}
                  sx={{
                    height: 18, fontSize: '0.6rem', fontWeight: 600,
                    cursor: 'pointer',
                    ...(chip.key !== 'all' && TYPE_BADGES[chip.key] ? {
                      borderColor: TYPE_BADGES[chip.key].color,
                      ...(tableTypeFilter === chip.key ? { bgcolor: TYPE_BADGES[chip.key].bg, color: TYPE_BADGES[chip.key].color } : {}),
                    } : {}),
                  }}
                />
              ))}
            </Box>
          )}

          {/* Scrollable tree */}
          <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
            {!selectedConnId && (
              <Typography variant="caption" color="text.secondary" sx={{ p: 1.5, display: 'block' }}>
                Select a connection above
              </Typography>
            )}

            {loadingColumns && (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                <CircularProgress size={20} />
              </Box>
            )}

            {/* Primary source header */}
            {selectedConnId && (
              <Box sx={{ px: 1, py: 0.4, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <StorageIcon sx={{ fontSize: 14, color: 'primary.main' }} />
                <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem' }}>
                  {connName(selectedConnId)}
                </Typography>
              </Box>
            )}

            {/* Primary tables */}
            {filteredTables.map(t => {
              const isSelected = selectedTables.some(s => s.path === t.path);
              const hasColumns = !!columnsByTable[t.path];
              const badge = t._type ? TYPE_BADGES[t._type] : null;
              const isFav = tableFavorites.has(t.path);
              return (
                <Accordion key={t.path} disableGutters
                  defaultExpanded={false}
                  sx={{ '&:before': { display: 'none' }, boxShadow: 'none' }}>
                  <AccordionSummary
                    expandIcon={isSelected && hasColumns ? <ExpandMoreIcon sx={{ fontSize: 16 }} /> : <Box sx={{ width: 16 }} />}
                    sx={{
                      minHeight: 28, px: 0.5, pl: 1.5,
                      '& .MuiAccordionSummary-content': { m: 0, alignItems: 'center' },
                    }}
                    onContextMenu={(e) => handleContextMenu(e, t)}
                  >
                    <Checkbox size="small" checked={isSelected}
                      onClick={e => { e.stopPropagation(); onToggleTable(t); }}
                      sx={{ p: 0.1, mr: 0.25 }} />
                    {isFav && (
                      <StarIcon sx={{ fontSize: 12, color: 'warning.main', mr: 0.25 }} />
                    )}
                    <TableChartIcon sx={{ fontSize: 14, mr: 0.5, opacity: 0.5 }} />
                    {badge && (
                      <Chip label={badge.label} size="small"
                        sx={{
                          height: 14, fontSize: '0.5rem', fontWeight: 700, mr: 0.3,
                          color: badge.color, bgcolor: badge.bg, border: 'none',
                        }}
                      />
                    )}
                    <Typography variant="caption" noWrap sx={{ fontWeight: isSelected ? 600 : 400, flexGrow: 1, fontSize: '0.78rem' }}>
                      {t.name}
                    </Typography>
                    {t.num_rows && (
                      <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.6rem', ml: 0.5 }}>
                        {t.num_rows.toLocaleString()}
                      </Typography>
                    )}
                  </AccordionSummary>
                  {isSelected && hasColumns && (
                    <AccordionDetails sx={{ p: 0 }}>
                      <ColumnsForTable
                        tablePath={t.path}
                        catGroups={columnsByTable[t.path]}
                        selectedPhysical={selectedPhysical}
                        onToggleColumn={onToggleColumn}
                        onToggleCategory={onToggleCategory}
                        columnAggregations={columnAggregations}
                        onAggChange={onAggChange}
                        columnTransforms={columnTransforms}
                        onTransformChange={onTransformChange}
                        frequentCols={frequentColumns[t.path]}
                        searchQuery={tableSearch.trim().toLowerCase()}
                      />
                    </AccordionDetails>
                  )}
                </Accordion>
              );
            })}

            {filteredTables.length === 0 && selectedConnId && !loadingColumns && (
              <Typography variant="caption" color="text.secondary" sx={{ p: 1, pl: 1.5, display: 'block' }}>
                No tables match
              </Typography>
            )}

            {/* 2nd Source section */}
            <Box sx={{ borderTop: '1px solid', borderColor: 'divider', mt: 0.5 }}>
              <Box
                sx={{
                  px: 1, py: 0.4, display: 'flex', alignItems: 'center', gap: 0.5,
                  cursor: 'pointer',
                  bgcolor: showCrossConn ? 'secondary.50' : 'action.hover',
                  '&:hover': { bgcolor: 'action.selected' },
                }}
                onClick={onToggleCrossConn}
              >
                <LinkIcon sx={{ fontSize: 14, color: showCrossConn ? 'secondary.main' : 'text.disabled' }} />
                <Typography variant="caption" sx={{ fontWeight: 700, flexGrow: 1, fontSize: '0.72rem' }}>
                  2nd Source
                </Typography>
                <Typography variant="caption" color={showCrossConn ? 'secondary' : 'text.secondary'}
                  sx={{ fontWeight: 600, fontSize: '0.65rem' }}>
                  {showCrossConn ? 'ON' : 'OFF'}
                </Typography>
              </Box>

              {showCrossConn && (
                <>
                  <Box sx={{ px: 0.5, py: 0.25 }}>
                    <FormControl size="small" fullWidth>
                      <Select value={crossConnId || ''} displayEmpty
                        onChange={(e: SelectChangeEvent<number | string>) => {
                          onCrossConnChange(Number(e.target.value) || null);
                        }}
                        sx={{ height: 28, fontSize: '0.8rem' }}>
                        <MenuItem value="" disabled><em>Select connection...</em></MenuItem>
                        {connections.filter(c => c.id !== selectedConnId).map(c => (
                          <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>

                  {crossConnId && (
                    <>
                      {/* Mode toggle: UNION ALL / JOIN */}
                      <Box sx={{ px: 0.5, py: 0.25, display: 'flex', gap: 0.5 }}>
                        <Chip label="UNION ALL" size="small"
                          color={crossConnMode === 'union' ? 'secondary' : 'default'}
                          variant={crossConnMode === 'union' ? 'filled' : 'outlined'}
                          onClick={() => onCrossConnModeChange?.('union')}
                          sx={{ fontSize: '0.65rem', height: 22 }} />
                        <Chip label="JOIN" size="small"
                          color={crossConnMode === 'join' ? 'secondary' : 'default'}
                          variant={crossConnMode === 'join' ? 'filled' : 'outlined'}
                          onClick={() => onCrossConnModeChange?.('join')}
                          sx={{ fontSize: '0.65rem', height: 22 }} />
                      </Box>
                      {/* JOIN config */}
                      {crossConnMode === 'join' && (
                        <Box sx={{ px: 0.5, py: 0.25, display: 'flex', flexDirection: 'column', gap: 0.3 }}>
                          <FormControl size="small" fullWidth>
                            <Select value={crossJoinHow} onChange={(e) => onCrossJoinHowChange?.(e.target.value)}
                              sx={{ height: 24, fontSize: '0.72rem' }}>
                              <MenuItem value="inner">INNER JOIN</MenuItem>
                              <MenuItem value="left">LEFT JOIN</MenuItem>
                              <MenuItem value="right">RIGHT JOIN</MenuItem>
                              <MenuItem value="outer">FULL OUTER JOIN</MenuItem>
                            </Select>
                          </FormControl>
                          <Autocomplete size="small" freeSolo options={allColumnNames}
                            value={crossJoinLeftOn} onChange={(_e, v) => onCrossJoinLeftOnChange?.(v || '')}
                            onInputChange={(_e, v) => onCrossJoinLeftOnChange?.(v || '')}
                            renderInput={(params) => <TextField {...params} placeholder="Left key column" sx={{ '& .MuiInputBase-root': { height: 24, fontSize: '0.72rem' } }} />}
                          />
                          <Autocomplete size="small" freeSolo options={allColumnNames}
                            value={crossJoinRightOn} onChange={(_e, v) => onCrossJoinRightOnChange?.(v || '')}
                            onInputChange={(_e, v) => onCrossJoinRightOnChange?.(v || '')}
                            renderInput={(params) => <TextField {...params} placeholder="Right key column" sx={{ '& .MuiInputBase-root': { height: 24, fontSize: '0.72rem' } }} />}
                          />
                        </Box>
                      )}
                      <Box sx={{ px: 1, py: 0.3, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <StorageIcon sx={{ fontSize: 14, color: 'secondary.main' }} />
                        <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem' }}>
                          {connName(crossConnId)}
                        </Typography>
                      </Box>
                      {filteredCrossTables.map(t => {
                        const isSelected = selectedCrossTables.some(s => s.path === t.path);
                        return (
                          <Box key={t.path} sx={{
                            display: 'flex', alignItems: 'center', py: 0.1, px: 0.5, pl: 1.5,
                            cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' },
                          }}
                            onClick={() => onToggleCrossTable(t)}>
                            <Checkbox size="small" checked={isSelected} sx={{ p: 0.1, mr: 0.25 }} />
                            <TableChartIcon sx={{ fontSize: 14, mr: 0.5, opacity: 0.5 }} />
                            <Typography variant="caption" noWrap sx={{ fontWeight: isSelected ? 600 : 400, fontSize: '0.78rem' }}>
                              {t.name}
                            </Typography>
                          </Box>
                        );
                      })}
                    </>
                  )}
                </>
              )}
            </Box>
          </Box>
        </>

      {/* ── Context Menu ── */}
      <Menu
        open={!!ctxMenu}
        onClose={() => setCtxMenu(null)}
        anchorEl={ctxMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => { if (ctxMenu) handlePreview(ctxMenu.table); }}>
          <PreviewIcon sx={{ fontSize: 14, mr: 1 }} /> Preview (100 rows)
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) { onToggleTable(ctxMenu.table); setCtxMenu(null); } }}>
          <AddCircleOutlineIcon sx={{ fontSize: 14, mr: 1 }} /> Add to Query
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) handleToggleFavorite(ctxMenu.table); }}>
          {ctxMenu && tableFavorites.has(ctxMenu.table.path)
            ? <StarIcon sx={{ fontSize: 14, mr: 1, color: 'warning.main' }} />
            : <StarBorderIcon sx={{ fontSize: 14, mr: 1 }} />}
          {ctxMenu && tableFavorites.has(ctxMenu.table.path) ? 'Unfavorite' : 'Favorite'}
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) handleCopyName(ctxMenu.table); }}>
          <ContentCopyIcon sx={{ fontSize: 14, mr: 1 }} /> Copy Name
        </MenuItem>
      </Menu>

      {/* ── Preview Dialog ── */}
      <Dialog open={previewOpen} onClose={() => setPreviewOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle sx={{ py: 1 }}>
          Preview: {previewData?.name || '...'}
        </DialogTitle>
        <DialogContent sx={{ p: 0 }}>
          {previewLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : previewData && previewData.rows.length > 0 ? (
            <Box sx={{ overflow: 'auto', maxHeight: 400 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.75rem' }}>
                <thead>
                  <tr>
                    {previewData.columns.map(col => (
                      <th key={col} style={{
                        padding: '4px 8px', textAlign: 'left', borderBottom: '2px solid #ddd',
                        position: 'sticky', top: 0, background: '#f5f5f5', fontWeight: 600,
                      }}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.rows.map((row: any, i: number) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                      {previewData.columns.map(col => (
                        <td key={col} style={{ padding: '3px 8px', borderBottom: '1px solid #eee' }}>
                          {row[col] != null ? String(row[col]) : ''}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </Box>
          ) : (
            <Typography variant="body2" color="text.secondary" sx={{ p: 3, textAlign: 'center' }}>
              No data available
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default React.memo(TableTree);
