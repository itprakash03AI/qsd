/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowBuilderPage — visual DAG builder.
 *
 * Layout:
 *   ┌─────────────────────────────────────────────────┐
 *   │ Header: name / description / trigger / context  │
 *   ├──────────┬──────────────────────────┬───────────┤
 *   │ Palette  │  Canvas (drag/connect)    │  Config   │
 *   │          │                            │  Drawer   │
 *   └──────────┴──────────────────────────┴───────────┘
 *
 * All stage editing happens through DataFlowDagCanvas — this page
 * is just the header form + save action.
 */
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Alert, Box, Button, ButtonGroup, CircularProgress, MenuItem, Paper, Select, Stack,
  TextField, Typography,
} from '@mui/material';
import {
  Save as SaveIcon, AccountTree as DagIcon, ViewList as SimpleIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { StageDef, StageTypeManifest, DataFlowDef } from '../services/api/dataflows';
import DataFlowDagCanvas from './dataflow/DataFlowDagCanvas';
import { toArray } from '../utils/toArray';


interface TemplateSummary {
  name:          string;
  description?:  string;
  label?:        string;
  category?:     string;
  stage_count?:  number;
  trigger_type?: string;
}


export default function DataFlowBuilderPage() {
  const nav = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id;

  const [stageTypes, setStageTypes] = useState<StageTypeManifest[]>([]);
  const [templates, setTemplates] = useState<TemplateSummary[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [triggerType, setTriggerType] = useState('manual');
  const [defaultContextText, setDefaultContextText] = useState('{}');
  const [stages, setStages] = useState<StageDef[]>([]);
  const [originalDataFlow, setOriginalDataFlow] = useState<DataFlowDef | null>(null);

  // ── Initial load ────────────────────────────────────────────────────

  useEffect(() => {
    api.dataflows.listTemplates()
      .then(d => setTemplates(toArray<TemplateSummary>(d)))
      .catch(() => {});
    api.dataflows.listStageTypes()
      .then(d => setStageTypes(toArray<StageTypeManifest>(d)))
      .catch(e => setError(e?.message || 'Failed to load stage types'));
  }, []);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.dataflows.getDataFlow(Number(id))
      .then(df => {
        setOriginalDataFlow(df);
        setName(df.name);
        setDescription(df.description || '');
        setTriggerType(df.trigger_type);
        setDefaultContextText(JSON.stringify(df.default_context || {}, null, 2));
        setStages((df.stages || []).map(s => ({
          stage_alias:       s.stage_alias,
          stage_type:        s.stage_type,
          seq:               s.seq,
          predecessors:      s.predecessors || [],
          config:            s.config || {},
          retry_policy:      s.retry_policy || {},
          timeout_seconds:   s.timeout_seconds || null,
          on_failure:        s.on_failure || 'halt',
          on_failure_target: s.on_failure_target || null,
        })));
      })
      .catch(e => setError(e?.message || 'Failed to load dataflow'))
      .finally(() => setLoading(false));
  }, [id]);

  // ── Save ────────────────────────────────────────────────────────────

  // ── Load a template's stages into the canvas (no save until user
  // hits Save Draft).  Used by the "Start from template" picker.
  const loadTemplate = async (templateName: string) => {
    if (!templateName) return;
    setError(null);
    try {
      const tmpl = await api.dataflows.getTemplate(templateName);
      if (stages.length > 0) {
        if (!window.confirm(
          `Replace the current ${stages.length} stage(s) with the "${templateName}" template?`,
        )) return;
      }
      // Suggest a fresh, unique name if the user hasn't picked one yet.
      if (!name) {
        try {
          const check = await api.dataflows.checkNameAvailable(tmpl.name + '_copy');
          setName(check.suggestion || tmpl.name + '_copy');
        } catch {
          setName(tmpl.name + '_copy');
        }
      }
      setDescription(tmpl.description || '');
      setTriggerType(tmpl.trigger_type || 'manual');
      setDefaultContextText(JSON.stringify(tmpl.default_context || {}, null, 2));
      setStages((tmpl.stages || []).map((s: any) => ({
        stage_alias:       s.stage_alias,
        stage_type:        s.stage_type,
        seq:               s.seq,
        predecessors:      s.predecessors || [],
        config:            s.config || {},
        retry_policy:      s.retry_policy || {},
        timeout_seconds:   s.timeout_seconds || null,
        on_failure:        s.on_failure || 'halt',
        on_failure_target: s.on_failure_target || null,
      })));
      setSelectedTemplate('');   // reset picker so the same template can be re-seeded
    } catch (e: any) {
      setError(e?.message || 'Failed to load template');
    }
  };

  const onSave = async () => {
    setError(null);
    setSaving(true);
    try {
      let defaultCtx = {};
      try { defaultCtx = JSON.parse(defaultContextText || '{}'); }
      catch { throw new Error('Default context is not valid JSON'); }

      // Re-number seq from the current DAG order
      const cleanedStages: StageDef[] = stages.map((s, i) => ({
        ...s,
        seq: i + 1,
        predecessors: s.predecessors || [],
        config: s.config || {},
      }));

      const spec = {
        name,
        description,
        trigger_type: triggerType,
        default_context: defaultCtx,
        stages: cleanedStages,
      };

      let saved: DataFlowDef;
      if (isEdit && originalDataFlow) {
        saved = await api.dataflows.addVersion(originalDataFlow.id, spec as any);
      } else {
        saved = await api.dataflows.createDataFlow(spec as any);
      }
      nav(`/dataflows/${saved.id}`);
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <Box sx={{ p: 3 }}><CircularProgress size={22} /></Box>;
  }

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">
          {isEdit ? `Edit dataflow: ${originalDataFlow?.name || ''} (new version)` : 'New DataFlow (DAG editor)'}
        </Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          {/* DAG ↔ Simple toggle — same underlying DataFlow data */}
          <ButtonGroup size="small" variant="outlined">
            <Button startIcon={<SimpleIcon />}
                     onClick={() => nav(isEdit ? `/dataflows/simple/${id}` : '/dataflows/new')}>
              Simple
            </Button>
            <Button startIcon={<DagIcon />} variant="contained" disabled>DAG</Button>
          </ButtonGroup>
          <Button onClick={() => nav('/dataflows/list')}>Cancel</Button>
          <Button startIcon={<SaveIcon />} variant="contained"
                   disabled={saving || !name || stages.length === 0}
                   onClick={onSave}>{saving ? 'Saving…' : 'Save Draft'}</Button>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack spacing={2}>
          {/* Template picker — ALWAYS visible when creating a new
              DataFlow, even if the templates list happens to be empty.
              Empty state shows a clear path to force-seed. */}
          {!isEdit && (
            templates.length > 0 ? (
              <Stack direction="row" spacing={2} alignItems="center">
                <Select size="small" displayEmpty
                         value={selectedTemplate}
                         onChange={e => {
                           setSelectedTemplate(e.target.value);
                           loadTemplate(e.target.value);
                         }}
                         sx={{ minWidth: 340 }}>
                  <MenuItem value="" disabled>
                    Start from a template (optional)…
                  </MenuItem>
                  {templates.map(t => (
                    <MenuItem key={t.name} value={t.name}>
                      <Box>
                        <Typography variant="body2">{t.label || t.name}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {t.description?.slice(0, 80) || ''} · {t.stage_count ?? 0} stages
                        </Typography>
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
                <Typography variant="caption" color="text.secondary">
                  Pick a template to seed the canvas, then customise.
                </Typography>
              </Stack>
            ) : (
              // No templates loaded — could be: API failure, DB empty
              // (seeder hasn't run), or a transient hiccup.  Surface the
              // force-seed escape hatch so admins aren't blocked.
              <Alert severity="info" action={
                <Button size="small" color="primary"
                         onClick={async () => {
                           try {
                             const r: any = await (api as any).post(
                               '/api/dataflows/templates/seed', {});
                             const list = toArray<TemplateSummary>(await api.dataflows.listTemplates());
                             setTemplates(list);
                             if (list.length === 0) {
                               setError(`Seed returned ${r?.seeded ?? 0}; still empty. ` +
                                          `Check backend logs for [template_seeder] errors.`);
                             }
                           } catch (e: any) {
                             setError(e?.message || 'Force-seed failed');
                           }
                         }}>
                  Force-seed templates
                </Button>
              }>
                No starter templates loaded.  Click <strong>Force-seed templates</strong>
                to populate them — safe to run multiple times.
                Then refresh the page.
              </Alert>
            )
          )}

          <Stack direction="row" spacing={2}>
            <TextField label="DataFlow name" required fullWidth value={name} disabled={isEdit}
                        onChange={e => setName(e.target.value)} />
            <Select size="small" sx={{ minWidth: 180 }} value={triggerType}
                     onChange={e => setTriggerType(e.target.value)}>
              <MenuItem value="manual">manual</MenuItem>
              <MenuItem value="cron">cron / schedule</MenuItem>
              <MenuItem value="event">event</MenuItem>
              <MenuItem value="upstream">upstream</MenuItem>
            </Select>
          </Stack>
          <TextField label="Description" multiline minRows={1} fullWidth
                      value={description} onChange={e => setDescription(e.target.value)} />
          <TextField label="Default context (JSON, available as {key} in all stage configs)"
                      fullWidth multiline minRows={2}
                      value={defaultContextText}
                      onChange={e => setDefaultContextText(e.target.value)}
                      sx={{ fontFamily: 'monospace' }} />
        </Stack>
      </Paper>

      <DataFlowDagCanvas
        stages={stages}
        stageTypes={stageTypes}
        onChange={setStages}
      />

      <Stack direction="row" spacing={1} sx={{ mt: 2 }} justifyContent="flex-end">
        <Typography variant="caption" color="text.secondary"
                      sx={{ alignSelf: 'center', mr: 'auto' }}>
          {stages.length} stage{stages.length === 1 ? '' : 's'} · drag a stage
          from the left panel · click a node to edit · drag handle-to-handle to wire.
        </Typography>
        <Button onClick={() => nav('/dataflows/list')}>Cancel</Button>
        <Button startIcon={<SaveIcon />} variant="contained"
                 disabled={saving || !name || stages.length === 0}
                 onClick={onSave}>{saving ? 'Saving…' : 'Save Draft'}</Button>
      </Stack>
    </Box>
  );
}
