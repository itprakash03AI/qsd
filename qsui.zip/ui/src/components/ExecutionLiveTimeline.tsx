/**
 * Live per-stage timeline for an in-flight query execution.
 *
 * Subscribes to WebSocket ``execution_progress`` events (heartbeat broadcasts
 * every 15s with stage info) filtered by execution_id and renders:
 *   - the CURRENT stage label with elapsed-in-stage seconds
 *   - a compact list of stages already completed during this query, with
 *     each one's duration computed from the stage transitions seen
 *
 * Pairs with ``ExecutionPerformanceChip`` (post-execution).  Mount this one
 * while the query is running; ``ExecutionPerformanceChip`` takes over once
 * the execution completes and the DB has the persisted stage_history.
 *
 * Backend hook: api/execute_api._await_with_heartbeat broadcasts
 *   { type: "execution_progress",
 *     execution_id, data: { stage, stage_label, stage_elapsed_seconds,
 *                            files_done, files_total, bytes_done, ... } }
 *
 * No API calls — pure WebSocket consumer.  Memoryless on remount: starts
 * the timeline fresh each time it's mounted.  That's by design — the
 * post-execution chip handles "show me what already happened."
 */
import { useEffect, useRef, useState } from 'react';
import {
  Box, Chip, Popover, Table, TableBody, TableCell, TableHead, TableRow,
  Typography, LinearProgress,
} from '@mui/material';
import HourglassTopIcon from '@mui/icons-material/HourglassTop';
import { useWebSocket } from '../context/WebSocketContext';

interface CompletedStage {
  stage: string;
  stage_label: string;
  duration_seconds: number;
  files_done: number;
}

interface CurrentStage {
  stage: string;
  stage_label: string;
  elapsed_seconds: number;
  files_done: number;
  files_total: number;
  bytes_done: number;
  message?: string;
  extras: Record<string, string | number>;
}

interface Props {
  executionId: string;
  /** Hide the chip when these statuses are seen on the WS stream. */
  terminalStatuses?: string[];
}

const DEFAULT_TERMINAL = ['completed', 'failed', 'cancelled'];

export default function ExecutionLiveTimeline({
  executionId,
  terminalStatuses = DEFAULT_TERMINAL,
}: Props) {
  const { addListener } = useWebSocket();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [completed, setCompleted] = useState<CompletedStage[]>([]);
  const [current, setCurrent] = useState<CurrentStage | null>(null);
  const [terminal, setTerminal] = useState(false);

  // Track previous stage so we can detect transitions and append the
  // completed entry to the history list.
  const prevRef = useRef<{
    stage: string;
    elapsed: number;
    label: string;
    files_done: number;
  } | null>(null);

  useEffect(() => {
    if (!executionId) return;

    const off = addListener((msg: any) => {
      if (msg?.execution_id !== executionId) return;

      // Terminal: hide the live chip — post-execution chip takes over.
      if (msg.type === 'execution_completed' || msg.type === 'execution_failed') {
        setTerminal(true);
        return;
      }
      const status = msg?.data?.status;
      if (status && terminalStatuses.includes(status)) {
        setTerminal(true);
        return;
      }

      if (msg.type !== 'execution_progress') return;
      const d = msg.data || {};
      const stage = d.stage as string | undefined;
      if (!stage) return;

      const elapsed = Number(d.stage_elapsed_seconds ?? 0);
      const label = String(d.stage_label || stage);
      const files_done = Number(d.files_done ?? 0);
      const files_total = Number(d.files_total ?? 0);
      const bytes_done = Number(d.bytes_done ?? 0);
      const extras = (d.extras && typeof d.extras === 'object') ? d.extras : {};

      // If the stage changed since last heartbeat, the previous one finished —
      // append it to the completed list with its final duration.
      const prev = prevRef.current;
      if (prev && prev.stage !== stage) {
        setCompleted(c => {
          // Avoid double-append if the same prev entry was already pushed
          // (can happen on rapid redux of state).
          if (c.length > 0 && c[c.length - 1].stage === prev.stage) return c;
          return [...c, {
            stage:            prev.stage,
            stage_label:      prev.label,
            duration_seconds: prev.elapsed,
            files_done:       prev.files_done,
          }];
        });
      }

      prevRef.current = { stage, elapsed, label, files_done };
      setCurrent({
        stage, stage_label: label,
        elapsed_seconds: elapsed,
        files_done, files_total, bytes_done,
        extras,
        message: d.message ? String(d.message) : undefined,
      });
    });

    return () => { off(); };
  }, [executionId, addListener, terminalStatuses]);

  if (terminal || !current) return null;

  const fileProgress = current.files_total > 0
    ? Math.round((current.files_done / current.files_total) * 100)
    : null;

  const chipLabel = `${current.stage_label} · ${current.elapsed_seconds.toFixed(0)}s${
    fileProgress !== null ? ` · ${current.files_done}/${current.files_total}` : ''
  }`;

  return (
    <>
      <Chip
        size="small"
        icon={<HourglassTopIcon sx={{ fontSize: 14 }} />}
        label={chipLabel}
        color="primary"
        variant="outlined"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        sx={{ fontSize: 11, cursor: 'pointer', maxWidth: 360 }}
      />
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Box sx={{ p: 2, minWidth: 360, maxWidth: 600 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Query in progress &mdash; live timeline
          </Typography>

          {/* In-flight stage panel */}
          <Box sx={{
            p: 1.25, mb: 1.5, borderRadius: 1,
            bgcolor: 'primary.light', color: 'primary.contrastText',
          }}>
            <Typography variant="caption" sx={{ fontWeight: 600, display: 'block' }}>
              {current.stage_label}{' '}
              <em style={{ opacity: 0.85 }}>
                · {current.elapsed_seconds.toFixed(1)}s in stage
              </em>
            </Typography>
            {current.message && (
              <Typography variant="caption" sx={{ display: 'block', fontSize: 10, opacity: 0.9 }}>
                {current.message}
              </Typography>
            )}
            {fileProgress !== null && (
              <Box sx={{ mt: 0.5 }}>
                <LinearProgress
                  variant="determinate"
                  value={Math.min(100, fileProgress)}
                  sx={{ height: 6, borderRadius: 1 }}
                />
                <Typography variant="caption" sx={{ fontSize: 10, opacity: 0.9 }}>
                  {current.files_done.toLocaleString()} / {current.files_total.toLocaleString()} files
                  ({fileProgress}%)
                </Typography>
              </Box>
            )}
          </Box>

          {/* Completed stages so far (during THIS run) */}
          {completed.length > 0 && (
            <>
              <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                Completed steps so far ({completed.length})
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Stage</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Duration</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {completed.map((s, i) => (
                    <TableRow key={i}>
                      <TableCell sx={{ fontSize: 11 }}>{s.stage_label || s.stage}</TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {s.duration_seconds.toFixed(2)}s
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </>
          )}

          <Typography variant="caption" sx={{ mt: 1, fontSize: 10, color: 'text.secondary', display: 'block' }}>
            Updates every 15s via WebSocket. Once the query finishes, the
            full per-step breakdown appears in the post-execution chip.
          </Typography>
        </Box>
      </Popover>
    </>
  );
}
