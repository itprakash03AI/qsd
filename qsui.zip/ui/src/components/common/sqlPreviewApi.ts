/**
 * Frontend bindings for the backend SQL utility endpoints
 * (POST /api/sql/preview-columns + POST /api/sql/distinct-values).
 *
 * The browser-side ``SqlColumnExtractor`` regex is good enough for
 * simple SELECT/WHERE statements but misses CTEs / sub-queries /
 * window functions.  These helpers call sqlglot on the backend so the
 * editor's column dropdown handles those shapes correctly, with a
 * graceful regex fallback when the call fails.
 */
import { safeFetch } from '../../services/api/core';
import { safeStringify } from '../../utils/safeStringify';


export interface PreviewColumn {
  name: string;
  is_alias: boolean;
}


export interface PreviewColumnsResult {
  columns: PreviewColumn[];
  tables: string[];
  warnings: string[];
  /** Phase 133-H round 6 — populated when caller passed ``connectionId``.
   *  Full column list per source table, sourced from ``schema_cache``
   *  with connector ``list_columns()`` fallback.  Empty when the
   *  connection isn't known (no cache yet) or the connector is non-SQL
   *  (S3 / file). */
  columns_by_table?: Record<string, Array<{name: string; type?: string}>>;
  partition_columns_by_table?: Record<string, string[]>;
  table_connection_ids?: Record<string, number>;
  /** Phase 133-H round 14 — alias → real table name for every
   *  explicit ``FROM <table> <alias>`` / ``JOIN <table> <alias>``
   *  the publisher wrote.  Lets the editor offer alias-qualified
   *  column entries (``a.code``, ``b.code``) in the dropdown when
   *  the saved query uses JOIN aliases. */
  table_aliases?: Record<string, string>;
}


/** Call the backend sqlglot-based column extractor.  Returns ``null``
 *  on any error so the caller can fall back to the regex extractor.
 *
 *  Phase 133-H round 6 — when ``connectionId`` is supplied, the
 *  endpoint ALSO returns full column lists per source table sourced
 *  from the ``schema_cache``.  Editors get a dropdown of EVERY
 *  column on the underlying tables, not just the ones the publisher
 *  named in the SQL.
 */
export async function previewColumns(
  sql: string | null | undefined,
  dialect: string = 'duckdb',
  connectionId?: number | null,
): Promise<PreviewColumnsResult | null> {
  if (!sql || !sql.trim()) {
    return { columns: [], tables: [], warnings: [] };
  }
  try {
    const body: any = { sql, dialect };
    if (connectionId && Number.isFinite(connectionId)) {
      body.connection_id = Number(connectionId);
    }
    const r: any = await safeFetch('/api/sql/preview-columns', {
      method: 'POST',
      body: safeStringify(body),
    });
    return r as PreviewColumnsResult;
  } catch {
    return null;
  }
}


export interface DistinctValuesResult {
  values: string[];
  cached: boolean;
  warnings: string[];
}


/** Fetch distinct values for ``column`` on a connection.  Backend caps
 *  the result count + caches for 5 min.  Returns ``null`` on error so
 *  the caller can treat as "no autocomplete available" rather than
 *  surfacing a toast on every dropdown open. */
export async function distinctValues(
  connectionId: number,
  table: string,
  column: string,
  limit: number = 200,
): Promise<DistinctValuesResult | null> {
  if (!connectionId || !table || !column) return null;
  try {
    const r: any = await safeFetch('/api/sql/distinct-values', {
      method: 'POST',
      body: safeStringify({
        connection_id: connectionId, table, column, limit,
      }),
    });
    return r as DistinctValuesResult;
  } catch {
    return null;
  }
}
