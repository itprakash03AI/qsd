/**
 * Lightweight SQL column extractor for the WhereClausesEditor.
 *
 * OOP design — one class with named capabilities:
 *
 *   const ex = new SqlColumnExtractor(sql, partitionColumns);
 *   ex.extractNames();          // string[]
 *   ex.toColumnOptions();       // [{name, type, isPartition}]
 *   ex.toValueOptions();        // {col: string[]} (overridable by tests / mocks)
 *
 * The class is INTENTIONALLY browser-only — no sqlglot, no backend
 * round-trip — because the editor needs to render dropdowns inline as
 * the publisher types.  Regex-based extraction handles the common
 * SELECT / WHERE / GROUP-BY shapes well enough that the user always
 * sees a real dropdown instead of a plain text field.
 */

export interface ExtractedColumn {
  name: string;
  type?: string;
  isPartition?: boolean;
  /** Phase 133-I round 22 — optional source-table label so the
   *  Autocomplete consumer can groupBy() table.  Extractor leaves
   *  this undefined (regex doesn't know which table a column came
   *  from); callers folding in schema_cache results set it. */
  tableSource?: string;
}


const _SELECT_BLOCK = /\bselect\s+([\s\S]*?)\s+from\b/gi;
const _WHERE_BLOCK = /\bwhere\b([\s\S]*?)(?=\b(group\s+by|order\s+by|limit|offset|union|intersect|except|having)\b|$)/gi;

const _SQL_KEYWORDS: ReadonlySet<string> = new Set([
  'select', 'from', 'where', 'and', 'or', 'not', 'in', 'is', 'null',
  'between', 'like', 'as', 'on', 'join', 'left', 'right', 'inner',
  'outer', 'full', 'cross', 'group', 'order', 'by', 'asc', 'desc',
  'having', 'limit', 'offset', 'union', 'intersect', 'except',
  'distinct', 'case', 'when', 'then', 'else', 'end', 'true', 'false',
  'with', 'recursive', 'all', 'any', 'some', 'exists',
  'count', 'sum', 'avg', 'min', 'max', 'coalesce', 'nullif', 'cast',
  'substring', 'trim', 'lower', 'upper', 'length', 'date',
  'current_date', 'current_timestamp', 'now',
]);


export class SqlColumnExtractor {
  private readonly sql: string;
  private readonly partitionLookup: ReadonlySet<string>;
  private readonly partitionList: ReadonlyArray<string>;
  private readonly valueOptionsByColumn: Record<string, string[]>;
  private _cachedNames: string[] | null = null;

  /** @param sql               SQL string to scan.
   *  @param partitionColumns  Optional partition columns (marked + surfaced even if not in SQL).
   *  @param valueOptions      Optional ``{column: distinct-values[]}`` map driving the
   *                            per-row value-picker autocomplete in the editor.
   *                            Typically fetched from the connection's partition cache.
   */
  constructor(
    sql: string | null | undefined,
    partitionColumns: string[] | null | undefined = null,
    valueOptions: Record<string, string[]> | null | undefined = null,
  ) {
    this.sql = (sql || '').trim();
    const partList = (partitionColumns || []).filter(Boolean);
    this.partitionList = partList;
    this.partitionLookup = new Set(partList.map(c => c.toLowerCase()));
    this.valueOptionsByColumn = { ...(valueOptions || {}) };
  }

  // ── public API ─────────────────────────────────────────────────

  /** Ordered, case-insensitively de-duped list of column names referenced
   *  in the SQL.  Empty SQL or unparseable input → ``[]``. */
  extractNames(): string[] {
    if (this._cachedNames !== null) return this._cachedNames;
    if (!this.sql) {
      this._cachedNames = [];
      return this._cachedNames;
    }
    const seen = new Set<string>();
    const out: string[] = [];

    const _push = (col: string) => {
      const key = col.toLowerCase();
      if (!key || seen.has(key)) return;
      if (_SQL_KEYWORDS.has(key)) return;
      seen.add(key);
      out.push(col);
    };

    for (const c of this._fromSelectList()) _push(c);
    for (const c of this._fromWhereBlock()) _push(c);

    this._cachedNames = out;
    return out;
  }

  /** Build the editor's ``columnOptions`` array.  Surfaces every
   *  partition column even when it didn't appear in the SQL (e.g. a
   *  ``SELECT *`` hides partitions from extraction). */
  toColumnOptions(): ExtractedColumn[] {
    const names = this.extractNames();
    const out: ExtractedColumn[] = names.map(name => ({
      name,
      type: 'string',
      isPartition: this.partitionLookup.has(name.toLowerCase()),
    }));
    for (const pc of this.partitionList) {
      if (!out.some(o => o.name.toLowerCase() === pc.toLowerCase())) {
        out.push({ name: pc, type: 'string', isPartition: true });
      }
    }
    return out;
  }

  /** Per-column distinct-value map driving the editor's
   *  value-picker autocomplete.  Keys are case-normalised to match
   *  the column names extracted from the SQL — callers can supply
   *  partition cache results with any casing and the lookup still
   *  matches. */
  toValueOptions(): Record<string, string[]> {
    const out: Record<string, string[]> = {};
    const seenColumns = new Set(
      this.extractNames().map(c => c.toLowerCase()),
    );
    for (const pc of this.partitionList) {
      seenColumns.add(pc.toLowerCase());
    }
    for (const [k, v] of Object.entries(this.valueOptionsByColumn)) {
      if (!Array.isArray(v)) continue;
      const lk = k.toLowerCase();
      // Surface for any column name we recognise from SQL or partition
      // hints; callers can also pass keys for columns that didn't show
      // up in extraction (still useful for free-text rows).
      if (seenColumns.has(lk) || lk === k.toLowerCase()) {
        out[k] = v.map(x => String(x ?? ''));
      }
    }
    return out;
  }

  // ── private helpers ────────────────────────────────────────────

  private _stripTablePrefix(s: string): string {
    const cleaned = s.replace(/^["`\[]|["`\]]$/g, '');
    const idx = cleaned.lastIndexOf('.');
    if (idx >= 0) return cleaned.slice(idx + 1).replace(/^["`\[]|["`\]]$/g, '');
    return cleaned;
  }

  private _splitTopLevel(text: string): string[] {
    let depth = 0; let buf = '';
    const items: string[] = [];
    for (const ch of text) {
      if (ch === '(') depth++;
      else if (ch === ')') depth = Math.max(0, depth - 1);
      if (ch === ',' && depth === 0) {
        items.push(buf); buf = '';
      } else {
        buf += ch;
      }
    }
    if (buf.trim()) items.push(buf);
    return items;
  }

  private _fromSelectList(): string[] {
    const cols: string[] = [];
    _SELECT_BLOCK.lastIndex = 0;
    let sm: RegExpExecArray | null;
    while ((sm = _SELECT_BLOCK.exec(this.sql)) !== null) {
      for (const raw of this._splitTopLevel(sm[1])) {
        let item = raw.trim();
        if (!item || item === '*') continue;
        const asMatch = item.match(
          /(?:\s+as\s+|\s+)(["`\[]?[a-zA-Z_][a-zA-Z0-9_]*["`\]]?)\s*$/i,
        );
        if (asMatch && !item.toLowerCase().endsWith(' from')) {
          cols.push(this._stripTablePrefix(asMatch[1]));
          continue;
        }
        if (/^[\w".`\[\]]+$/.test(item.replace(/\s/g, ''))) {
          cols.push(this._stripTablePrefix(item.replace(/\s/g, '')));
          continue;
        }
        const fnMatch = item.match(/\(\s*([\w."`\[\]]+)\s*\)/);
        if (fnMatch) cols.push(this._stripTablePrefix(fnMatch[1]));
      }
    }
    _SELECT_BLOCK.lastIndex = 0;
    return cols;
  }

  private _fromWhereBlock(): string[] {
    const COL_BEFORE_OP = /\b((?:["`\[][^"`\]]+["`\]]|[a-zA-Z_][a-zA-Z0-9_]*)(?:\.(?:["`\[][^"`\]]+["`\]]|[a-zA-Z_][a-zA-Z0-9_]*))?)\s*(?:=|!=|<>|<=|>=|<|>|\bin\b|\blike\b|\bnot\s+like\b|\bnot\s+in\b|\bbetween\b|\bis\b)/gi;
    const cols: string[] = [];
    _WHERE_BLOCK.lastIndex = 0;
    let wm: RegExpExecArray | null;
    while ((wm = _WHERE_BLOCK.exec(this.sql)) !== null) {
      let m: RegExpExecArray | null;
      while ((m = COL_BEFORE_OP.exec(wm[1])) !== null) {
        const ident = this._stripTablePrefix(m[1]);
        if (_SQL_KEYWORDS.has(ident.toLowerCase())) continue;
        cols.push(ident);
      }
    }
    _WHERE_BLOCK.lastIndex = 0;
    return cols;
  }
}


/** Convenience function — equivalent to ``new SqlColumnExtractor(sql).extractNames()``. */
export function extractSqlColumns(sql: string | null | undefined): string[] {
  return new SqlColumnExtractor(sql).extractNames();
}


/** Convenience function — equivalent to
 *  ``new SqlColumnExtractor(sql, partitions).toColumnOptions()``. */
export function columnOptionsFromSql(
  sql: string | null | undefined,
  partitionColumns: string[] | null | undefined = null,
): ExtractedColumn[] {
  return new SqlColumnExtractor(sql, partitionColumns).toColumnOptions();
}


// ── Phase 134-L (audit follow-up) — full WHERE triple extraction ────
//
// Where the existing extractor stops at column NAMES, the publish dialog
// needs full ``(column, operator, value)`` triples seeded as rows so
// the publisher sees their source query's WHERE clauses by default
// (and can flip Dynamic / Static without retyping anything).
//
// Regex-based — same trade-off as the rest of this module: browser-only,
// no backend round-trip.  Handles the common shapes:
//
//   col = 'literal'        → eq, value='literal'
//   col != 'X'             → ne, value='X'
//   col <> 'X'             → ne (synonym), value='X'
//   col > 100              → gt, value=100 (string form)
//   col >=, <=, <
//   col IN ('A','B','C')   → in, value=['A','B','C']
//   col NOT IN (...)       → not_in, value=[...]
//   col BETWEEN x AND y    → between, value=[x, y]
//   col LIKE '%foo%'       → contains, value='%foo%' (strip wildcards optional)
//   col IS NULL            → is_null, value=null
//   col IS NOT NULL        → is_not_null, value=null
//
// Skips parameterised forms (``col = ?`` or ``col = :name``) — those
// already plug into the Dynamic param flow.


export interface ExtractedWhereTriple {
  column: string;
  operator: string;            // 'eq'|'ne'|'gt'|'ge'|'lt'|'le'|'in'|'not_in'|'between'|'like'|'is_null'|'is_not_null'
  value: string | string[] | null;
  /** True when the value side was a SQL literal (string/number).
   *  False when it was a placeholder (``?`` / ``:name`` / ``$1``) —
   *  caller treats placeholders as Dynamic rows with no default. */
  valueIsLiteral: boolean;
}


const _OPERATOR_PATTERN = (
  '\\s*(?:' +
  '(?<eq>=)' +
  '|(?<ne><>|!=)' +
  '|(?<ge>>=)' +
  '|(?<le><=)' +
  '|(?<gt>>)' +
  '|(?<lt><)' +
  '|(?<not_in>\\bnot\\s+in\\b)' +
  '|(?<inop>\\bin\\b)' +
  '|(?<between>\\bbetween\\b)' +
  '|(?<not_like>\\bnot\\s+like\\b)' +
  '|(?<like>\\blike\\b)' +
  '|(?<is_not_null>\\bis\\s+not\\s+null\\b)' +
  '|(?<is_null>\\bis\\s+null\\b)' +
  ')'
);

// Column-ident allowing optional ``table.`` / ``alias.`` qualifier +
// backtick / double-quote / square-bracket quoting.
const _COL_IDENT = (
  '((?:["`\\[][^"`\\]]+["`\\]]|[a-zA-Z_][a-zA-Z0-9_]*)' +
  '(?:\\.(?:["`\\[][^"`\\]]+["`\\]]|[a-zA-Z_][a-zA-Z0-9_]*))?)'
);

const _WHERE_TRIPLE_RE = new RegExp(
  '\\b' + _COL_IDENT + _OPERATOR_PATTERN,
  'gi',
);


function _stripQuotesAndPrefix(s: string): string {
  let v = (s || '').trim();
  v = v.replace(/^["`\[]|["`\]]$/g, '');
  const dotIdx = v.lastIndexOf('.');
  if (dotIdx >= 0) {
    v = v.slice(dotIdx + 1).replace(/^["`\[]|["`\]]$/g, '');
  }
  return v;
}


function _unwrapLiteral(raw: string): { value: string; isLiteral: boolean } {
  const v = (raw || '').trim();
  // Placeholder forms — not a literal.
  if (v === '?' || /^:[a-zA-Z_][a-zA-Z0-9_]*$/.test(v) || /^\$\d+$/.test(v)) {
    return { value: '', isLiteral: false };
  }
  // Quoted string literal — strip surrounding quotes + SQL ''-escape.
  if ((v.startsWith("'") && v.endsWith("'")) ||
      (v.startsWith('"') && v.endsWith('"'))) {
    const inner = v.slice(1, -1).replace(/''/g, "'");
    return { value: inner, isLiteral: true };
  }
  // Bare numeric / identifier — keep as-is.
  return { value: v, isLiteral: /^-?\d+(\.\d+)?$/.test(v) || true };
}


function _captureValueAfter(sql: string, startIdx: number, operator: string): {
  raw: string; consumed: number;
} {
  // Walk forward from startIdx, respecting parens (for IN-lists +
  // BETWEEN), single quotes (for string literals), and the
  // ``AND``/``OR`` boundary that terminates this clause.
  const tail = sql.slice(startIdx);
  let depth = 0; let i = 0; let inStr = false; let strCh = '';
  const isListOp = operator === 'in' || operator === 'not_in';
  const isBetween = operator === 'between';

  while (i < tail.length) {
    const ch = tail[i];
    // String literal toggle.
    if (inStr) {
      if (ch === strCh) {
        // Check for doubled quote (escape).
        if (tail[i + 1] === strCh) { i += 2; continue; }
        inStr = false;
        i++; continue;
      }
      i++; continue;
    }
    if (ch === "'" || ch === '"') {
      inStr = true; strCh = ch; i++; continue;
    }
    if (ch === '(') { depth++; i++; continue; }
    if (ch === ')') {
      depth--;
      if (depth < 0) break;
      i++; continue;
    }
    // Top-level AND/OR terminates the clause.  BETWEEN x AND y treats
    // the FIRST AND as a value separator (not a terminator).
    if (depth === 0) {
      const ahead = tail.slice(i).match(/^\s*\b(and|or)\b/i);
      if (ahead) {
        const kw = ahead[1].toLowerCase();
        if (isBetween && kw === 'and') {
          // BETWEEN inner separator — consume the AND and continue.
          i += ahead[0].length;
          isBetween && (operator = 'between_seen_and');  // mark
          continue;
        }
        break;
      }
    }
    if (depth === 0 && !isListOp && !isBetween && /\s/.test(ch)
        && tail.slice(0, i).trim().length > 0) {
      // Soft stop on whitespace if we already captured a literal
      // and the next char is a closer.  Only kicks in for the simple
      // scalar ops.
      // Don't break here — let AND/OR or end-of-string handle it.
    }
    i++;
  }
  return { raw: tail.slice(0, i).trim(), consumed: i };
}


export function extractWhereTriples(
  sql: string | null | undefined,
): ExtractedWhereTriple[] {
  if (!sql) return [];
  const out: ExtractedWhereTriple[] = [];

  _WHERE_BLOCK.lastIndex = 0;
  let wm: RegExpExecArray | null;
  while ((wm = _WHERE_BLOCK.exec(sql)) !== null) {
    const whereBody = wm[1] || '';
    _WHERE_TRIPLE_RE.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = _WHERE_TRIPLE_RE.exec(whereBody)) !== null) {
      const rawCol = m[1] || '';
      const column = _stripQuotesAndPrefix(rawCol);
      if (_SQL_KEYWORDS.has(column.toLowerCase())) continue;

      const groups = m.groups || {};
      let operator = '';
      if (groups.eq) operator = 'eq';
      else if (groups.ne) operator = 'ne';
      else if (groups.ge) operator = 'gte';
      else if (groups.le) operator = 'lte';
      else if (groups.gt) operator = 'gt';
      else if (groups.lt) operator = 'lt';
      else if (groups.inop) operator = 'in';
      else if (groups.not_in) operator = 'not_in';
      else if (groups.between) operator = 'between';
      else if (groups.like) operator = 'contains';
      else if (groups.not_like) operator = 'not_contains';
      else if (groups.is_null) operator = 'is_null';
      else if (groups.is_not_null) operator = 'is_not_null';
      if (!operator) continue;

      // is_null / is_not_null take no value.
      if (operator === 'is_null' || operator === 'is_not_null') {
        out.push({ column, operator, value: null, valueIsLiteral: true });
        continue;
      }

      // Capture the value after the operator match.
      const opEnd = m.index + m[0].length;
      const cap = _captureValueAfter(whereBody, opEnd, operator);

      // IN / NOT IN  → split the paren'd CSV of literals.
      if (operator === 'in' || operator === 'not_in') {
        const body = cap.raw.replace(/^\(|\)$/g, '');
        const parts = body.split(/\s*,\s*/).filter(p => p.length > 0);
        const values = parts.map(p => _unwrapLiteral(p).value);
        const anyLiteral = parts.some(p => _unwrapLiteral(p).isLiteral);
        out.push({ column, operator, value: values, valueIsLiteral: anyLiteral });
        continue;
      }

      // BETWEEN → x AND y  (we marked the AND-seen state above)
      if (operator === 'between') {
        // Split by the first top-level AND.
        const parts = cap.raw.split(/\s+\band\b\s+/i);
        const lo = parts[0] ? _unwrapLiteral(parts[0]).value : '';
        const hi = parts[1] ? _unwrapLiteral(parts[1]).value : '';
        out.push({
          column, operator,
          value: [lo, hi].filter(x => x !== ''),
          valueIsLiteral: true,
        });
        continue;
      }

      // Scalar ops — eq/ne/gt/gte/lt/lte/contains/not_contains.
      const lit = _unwrapLiteral(cap.raw);
      out.push({
        column, operator,
        value: lit.value,
        valueIsLiteral: lit.isLiteral,
      });
    }
  }
  _WHERE_BLOCK.lastIndex = 0;
  return out;
}
