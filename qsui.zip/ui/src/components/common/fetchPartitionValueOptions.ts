/**
 * Fetch ``valueOptionsByColumn`` from a connection's partition cache.
 *
 * Used by the Reconciliation / Feed / DataFlow WHERE-editors to drive
 * the per-row value-picker autocomplete.  Pulls from the existing
 * ``/api/connections/{id}/partition_values`` endpoint which serves
 * cached partition values for parquet / iceberg tables.
 *
 * Best-effort — every fetch failure is swallowed; the editor falls
 * back to free-text inputs when no values are returned.
 */
import { safeFetch } from '../../services/api/core';


export interface PartitionValueOptions {
  /** ``{column: distinct-values[]}`` — the shape the WhereClausesEditor
   *  expects on its ``valueOptionsByColumn`` prop. */
  valueOptionsByColumn: Record<string, string[]>;
  /** Lowercased column names known to be partitions on this connection
   *  — drives the partition badge in the column dropdown. */
  partitionColumns: string[];
}


/** Fetch partition values for a single table on a connection.  Returns
 *  ``null`` on any error so the caller can keep accumulating values
 *  from other tables without aborting. */
async function _fetchTablePartitionValues(
  connectionId: number,
  tableName: string,
): Promise<{ partition_columns?: string[];
              partition_values?: Record<string, string[]> } | null> {
  try {
    const r: any = await safeFetch(
      `/api/connections/${connectionId}/tables/${encodeURIComponent(tableName)}/partition_values`,
    );
    return r || null;
  } catch {
    return null;
  }
}


/** Pull partition columns + their cached values for every table on a
 *  connection.  Used at dialog-open time so the editor's value picker
 *  has a working dropdown without any user typing.
 *
 *  Resilient — missing endpoint, no tables, no partition info, network
 *  failure all yield an empty result rather than throwing.
 */
export async function fetchPartitionValueOptions(
  connectionId: number | null | undefined,
): Promise<PartitionValueOptions> {
  const out: PartitionValueOptions = {
    valueOptionsByColumn: {},
    partitionColumns: [],
  };
  if (!connectionId || !Number.isFinite(connectionId)) return out;

  let tables: string[] = [];
  try {
    const r: any = await safeFetch(
      `/api/connections/${connectionId}/tables`,
    );
    if (Array.isArray(r)) tables = r.filter(Boolean);
    else if (Array.isArray(r?.tables)) tables = r.tables.filter(Boolean);
  } catch {
    return out;
  }

  // Cap to avoid hammering the backend when a connection has hundreds
  // of tables — partition cache is per-table so we scan a reasonable
  // ceiling and rely on the editor's free-text fallback for the rest.
  const SCAN_CAP = 50;
  const sampled = tables.slice(0, SCAN_CAP);

  const seenPartition = new Set<string>();
  for (const t of sampled) {
    const tableName = typeof t === 'string' ? t : (t as any)?.name;
    if (!tableName) continue;
    const r = await _fetchTablePartitionValues(connectionId, tableName);
    if (!r) continue;
    const partCols = Array.isArray(r.partition_columns) ? r.partition_columns : [];
    const values: Record<string, string[]> =
      (r.partition_values && typeof r.partition_values === 'object')
        ? r.partition_values as any
        : {};
    for (const pc of partCols) {
      if (!pc) continue;
      seenPartition.add(String(pc));
      const v = values[pc];
      if (Array.isArray(v)) {
        const existing = new Set(out.valueOptionsByColumn[pc] || []);
        for (const x of v) {
          if (x !== null && x !== undefined) existing.add(String(x));
        }
        out.valueOptionsByColumn[pc] = Array.from(existing).sort();
      }
    }
  }
  out.partitionColumns = Array.from(seenPartition);
  return out;
}
