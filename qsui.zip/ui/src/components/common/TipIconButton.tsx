import { ReactNode } from 'react';
import { IconButton, IconButtonProps, Tooltip, TooltipProps } from '@mui/material';

/**
 * IconButton with a required tooltip.  Use this instead of bare
 * `<IconButton>` so every clickable icon explains itself on hover.
 *
 * The wrapping `<span>` is required so that disabled IconButtons still
 * show their tooltip — disabled MUI buttons swallow pointer events
 * otherwise.
 */
export interface TipIconButtonProps extends Omit<IconButtonProps, 'children'> {
  tip: ReactNode;
  tipPlacement?: TooltipProps['placement'];
  children: ReactNode;
}

export default function TipIconButton({
  tip,
  tipPlacement = 'top',
  children,
  ...iconButtonProps
}: TipIconButtonProps) {
  return (
    <Tooltip title={tip} placement={tipPlacement} arrow>
      <span style={{ display: 'inline-flex' }}>
        <IconButton {...iconButtonProps}>{children}</IconButton>
      </span>
    </Tooltip>
  );
}
