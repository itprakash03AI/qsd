/**
 * Phase 132.38 — locks the reusable WhereClausesEditor contract so the
 * Feed Generation + DataFlow pages that reuse it can't have the rug
 * pulled out by an accidental rename / signature change.
 */
import { describe, it, expect } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { useState } from 'react';
import WhereClausesEditor, {
  WhereClauseRow, WHERE_OPERATORS,
} from '../WhereClausesEditor';


function Harness(props: { initial?: WhereClauseRow[] }) {
  const [rows, setRows] = useState<WhereClauseRow[]>(props.initial || []);
  return (
    <div>
      <WhereClausesEditor
        value={rows}
        onChange={setRows}
        columnOptions={[
          { name: 'region', type: 'string', isPartition: true },
          { name: 'trade_date', type: 'date', isPartition: true },
          { name: 'amount', type: 'float', isPartition: false },
        ]}
      />
      <pre data-testid="rows">{JSON.stringify(rows)}</pre>
    </div>
  );
}


describe('WhereClausesEditor', () => {
  it('exposes the full engine operator vocabulary', () => {
    // Lock-in: backend/core/where_clause_mapping.py validates these
    // 13 operators.  A drift here breaks every UI-built row.
    const names = WHERE_OPERATORS.map(o => o.value).sort();
    expect(names).toEqual([
      'between', 'contains', 'eq', 'gt', 'gte', 'in', 'is_not_null',
      'is_null', 'lt', 'lte', 'ne', 'not_contains', 'not_in',
    ]);
  });

  it('renders empty-state hint when no rows are present', () => {
    render(<Harness />);
    expect(screen.getByText(/No WHERE mappings yet/i)).toBeTruthy();
  });

  it('Add Mapping button appends an empty Dynamic row', () => {
    render(<Harness />);
    fireEvent.click(screen.getByRole('button', { name: /Add Mapping/i }));
    const rows = JSON.parse(screen.getByTestId('rows').textContent || '[]');
    expect(rows).toHaveLength(1);
    expect(rows[0].mode).toBe('dynamic');
    expect(rows[0].operator).toBe('eq');
  });

  it('Delete button removes the row at that index', () => {
    render(<Harness initial={[
      { column: 'region', operator: 'eq', value: 'APAC', mode: 'static' },
      { column: 'amount', operator: 'gt', value: 100, mode: 'dynamic' },
    ]} />);
    const deletes = screen.getAllByLabelText(/Remove WHERE mapping/i);
    expect(deletes).toHaveLength(2);
    fireEvent.click(deletes[0]);
    const rows = JSON.parse(screen.getByTestId('rows').textContent || '[]');
    expect(rows).toHaveLength(1);
    expect(rows[0].column).toBe('amount');
  });

  it('Dynamic / Static chips toggle mode', () => {
    render(<Harness initial={[
      { column: 'region', operator: 'eq', value: 'APAC', mode: 'dynamic' },
    ]} />);
    // Click the Static chip.
    fireEvent.click(screen.getByText('Static'));
    const rows = JSON.parse(screen.getByTestId('rows').textContent || '[]');
    expect(rows[0].mode).toBe('static');
  });

  it('readOnly hides the Add button and disables deletes', () => {
    function ReadOnlyHarness() {
      return (
        <WhereClausesEditor
          value={[{ column: 'x', operator: 'eq', value: 1, mode: 'static' }]}
          onChange={() => {}}
          readOnly
        />
      );
    }
    render(<ReadOnlyHarness />);
    expect(screen.queryByRole('button', { name: /Add Mapping/i })).toBeNull();
    const del = screen.getByLabelText(/Remove WHERE mapping/i) as HTMLButtonElement;
    expect(del.disabled).toBe(true);
  });
});
