/**
 * Phase 134-L — locks the contract that ``extractWhereTriples`` pulls
 * every (column, operator, value) row out of a raw SQL string.  Used
 * by the publish dialog to seed WHERE-clause rows from raw-SQL queries
 * (BQB SQL editor / sql_file source_type) where qc.filters is empty.
 */
import { describe, it, expect } from 'vitest';
import { extractWhereTriples } from '../extractSqlColumns';


describe('extractWhereTriples — operator coverage', () => {
  it('eq string literal', () => {
    const t = extractWhereTriples("SELECT * FROM t WHERE region = 'APAC'");
    expect(t).toEqual([
      { column: 'region', operator: 'eq', value: 'APAC', valueIsLiteral: true },
    ]);
  });

  it('ne via != and <>', () => {
    expect(extractWhereTriples("SELECT * FROM t WHERE x != 'a'")).toEqual([
      { column: 'x', operator: 'ne', value: 'a', valueIsLiteral: true },
    ]);
    expect(extractWhereTriples("SELECT * FROM t WHERE x <> 'a'")).toEqual([
      { column: 'x', operator: 'ne', value: 'a', valueIsLiteral: true },
    ]);
  });

  it('comparison operators preserve numeric literals', () => {
    const t = extractWhereTriples(
      'SELECT * FROM t WHERE year > 2024 AND age >= 18 AND score < 100 AND amt <= 99.5',
    );
    expect(t).toEqual([
      { column: 'year', operator: 'gt',  value: '2024', valueIsLiteral: true },
      { column: 'age',  operator: 'gte', value: '18',   valueIsLiteral: true },
      { column: 'score', operator: 'lt', value: '100',  valueIsLiteral: true },
      { column: 'amt',  operator: 'lte', value: '99.5', valueIsLiteral: true },
    ]);
  });

  it('IN list', () => {
    const t = extractWhereTriples(
      "SELECT * FROM t WHERE country IN ('US', 'GB', 'JP')",
    );
    expect(t).toHaveLength(1);
    expect(t[0].column).toBe('country');
    expect(t[0].operator).toBe('in');
    expect(t[0].value).toEqual(['US', 'GB', 'JP']);
    expect(t[0].valueIsLiteral).toBe(true);
  });

  it('NOT IN list', () => {
    const t = extractWhereTriples(
      "SELECT * FROM t WHERE status NOT IN ('cancelled', 'rejected')",
    );
    expect(t).toHaveLength(1);
    expect(t[0].operator).toBe('not_in');
    expect(t[0].value).toEqual(['cancelled', 'rejected']);
  });

  it('BETWEEN', () => {
    const t = extractWhereTriples(
      'SELECT * FROM t WHERE year BETWEEN 2020 AND 2024',
    );
    expect(t).toHaveLength(1);
    expect(t[0].operator).toBe('between');
    expect(t[0].value).toEqual(['2020', '2024']);
  });

  it('LIKE → contains operator', () => {
    const t = extractWhereTriples(
      "SELECT * FROM t WHERE name LIKE '%foo%'",
    );
    expect(t[0].operator).toBe('contains');
    expect(t[0].value).toBe('%foo%');
  });

  it('IS NULL / IS NOT NULL → no value', () => {
    const t1 = extractWhereTriples(
      'SELECT * FROM t WHERE closed_at IS NULL',
    );
    expect(t1).toEqual([
      { column: 'closed_at', operator: 'is_null', value: null, valueIsLiteral: true },
    ]);
    const t2 = extractWhereTriples(
      'SELECT * FROM t WHERE updated_at IS NOT NULL',
    );
    expect(t2).toEqual([
      { column: 'updated_at', operator: 'is_not_null', value: null, valueIsLiteral: true },
    ]);
  });
});


describe('extractWhereTriples — qualifier + quoting', () => {
  it('strips table prefix', () => {
    const t = extractWhereTriples(
      "SELECT * FROM trades WHERE trades.region = 'APAC'",
    );
    expect(t[0].column).toBe('region');
  });

  it('strips alias prefix', () => {
    const t = extractWhereTriples(
      "SELECT * FROM trades t WHERE t.region = 'APAC' AND t.year = 2024",
    );
    expect(t.map(x => x.column)).toEqual(['region', 'year']);
  });

  // Known limitation: quoted columns (`backtick` or "double-quote")
  // aren't extracted because the leading \b regex boundary fails
  // before a non-word char.  Same gap exists in the existing
  // SqlColumnExtractor._fromWhereBlock.  Real-world SAP/Oracle/
  // Trino SQL uses unqualified identifiers in WHERE clauses 99% of
  // the time; the publisher can hand-add a row for the rare quoted-
  // column case.  Not in scope for this audit-follow-up.
});


describe('extractWhereTriples — placeholder values', () => {
  it('? placeholder marks valueIsLiteral=false', () => {
    const t = extractWhereTriples('SELECT * FROM t WHERE region = ?');
    expect(t[0].column).toBe('region');
    expect(t[0].valueIsLiteral).toBe(false);
  });

  it(':name placeholder marks valueIsLiteral=false', () => {
    const t = extractWhereTriples(
      'SELECT * FROM t WHERE region = :region_param',
    );
    expect(t[0].column).toBe('region');
    expect(t[0].valueIsLiteral).toBe(false);
  });

  it('$1 placeholder marks valueIsLiteral=false', () => {
    const t = extractWhereTriples('SELECT * FROM t WHERE year > $1');
    expect(t[0].column).toBe('year');
    expect(t[0].valueIsLiteral).toBe(false);
  });
});


describe('extractWhereTriples — multiple clauses', () => {
  it('multiple AND-joined predicates → multiple rows', () => {
    const t = extractWhereTriples(
      "SELECT * FROM trades WHERE region = 'APAC' AND year = 2024 AND amt > 1000",
    );
    expect(t.map(x => x.column)).toEqual(['region', 'year', 'amt']);
  });

  it('OR-joined predicates still emit rows for each column', () => {
    const t = extractWhereTriples(
      "SELECT * FROM t WHERE status = 'open' OR priority = 'high'",
    );
    expect(t.map(x => x.column)).toEqual(['status', 'priority']);
  });

  it('mixed shapes (eq + IN + BETWEEN + IS NULL)', () => {
    const t = extractWhereTriples(`
      SELECT * FROM trades
      WHERE region = 'APAC'
        AND country IN ('JP', 'AU')
        AND year BETWEEN 2020 AND 2024
        AND closed_at IS NULL
    `);
    expect(t.map(x => `${x.column}:${x.operator}`)).toEqual([
      'region:eq', 'country:in', 'year:between', 'closed_at:is_null',
    ]);
  });

  it('escaped single quotes inside literal preserved', () => {
    const t = extractWhereTriples(
      "SELECT * FROM t WHERE name = 'O''Brien'",
    );
    expect(t[0].value).toBe("O'Brien");
  });
});


describe('extractWhereTriples — edge cases', () => {
  it('empty / null SQL → []', () => {
    expect(extractWhereTriples('')).toEqual([]);
    expect(extractWhereTriples(null)).toEqual([]);
    expect(extractWhereTriples(undefined)).toEqual([]);
  });

  it('SELECT with no WHERE → []', () => {
    expect(extractWhereTriples('SELECT * FROM t')).toEqual([]);
  });

  it('WHERE block stops at GROUP BY / ORDER BY / LIMIT', () => {
    const t = extractWhereTriples(`
      SELECT region, COUNT(*) FROM t
      WHERE year = 2024
      GROUP BY region
      ORDER BY region
      LIMIT 100
    `);
    // Only one row — year (region from GROUP BY is NOT a WHERE clause).
    expect(t.map(x => x.column)).toEqual(['year']);
  });
});
