/**
 * Vitest contract — SqlColumnExtractor.
 *
 * Locks the regex behaviour the WhereClausesEditor relies on.  If you
 * change the extractor and these tests still pass, the dropdowns in
 * Reconciliation / Feed Generation / DataFlow stages keep working.
 */
import { describe, it, expect } from 'vitest';
import {
  SqlColumnExtractor,
  extractSqlColumns,
  columnOptionsFromSql,
} from '../extractSqlColumns';


describe('SqlColumnExtractor.extractNames', () => {
  it('returns [] for empty / null input', () => {
    expect(new SqlColumnExtractor(null).extractNames()).toEqual([]);
    expect(new SqlColumnExtractor(undefined).extractNames()).toEqual([]);
    expect(new SqlColumnExtractor('').extractNames()).toEqual([]);
    expect(new SqlColumnExtractor('   ').extractNames()).toEqual([]);
  });

  it('pulls plain SELECT-list columns', () => {
    expect(new SqlColumnExtractor(
      'SELECT region, year, total FROM sales',
    ).extractNames()).toEqual(['region', 'year', 'total']);
  });

  it('strips table prefixes from SELECT items', () => {
    expect(new SqlColumnExtractor(
      'SELECT trades.region, t.year FROM trades t',
    ).extractNames()).toEqual(['region', 'year']);
  });

  it('respects column AS alias', () => {
    expect(new SqlColumnExtractor(
      'SELECT COUNT(*) AS row_count, SUM(amount) AS total FROM t',
    ).extractNames()).toEqual(['row_count', 'total']);
  });

  it('also pulls columns referenced in WHERE', () => {
    const names = new SqlColumnExtractor(
      "SELECT a, b FROM t WHERE region = 'EU' AND year BETWEEN 2020 AND 2026",
    ).extractNames();
    expect(names).toContain('region');
    expect(names).toContain('year');
  });

  it('de-dupes case-insensitively', () => {
    const names = new SqlColumnExtractor(
      "SELECT Region, region FROM t WHERE REGION = 'EU'",
    ).extractNames();
    expect(names).toEqual(['Region']);   // first-seen casing wins
  });

  it('skips SQL keywords', () => {
    const names = new SqlColumnExtractor(
      'SELECT region, year FROM t WHERE region IS NOT NULL',
    ).extractNames();
    expect(names).not.toContain('null');
    expect(names).not.toContain('and');
  });

  it('handles SELECT * (returns nothing extractable)', () => {
    expect(new SqlColumnExtractor(
      'SELECT * FROM trades WHERE region = ?',
    ).extractNames()).toContain('region');
  });
});


describe('SqlColumnExtractor.toColumnOptions', () => {
  it('flags partition columns and surfaces them even when not in SQL', () => {
    const opts = new SqlColumnExtractor(
      'SELECT amount FROM trades',
      ['region', 'year'],   // partitions known from connection metadata
    ).toColumnOptions();

    const lookup = Object.fromEntries(
      opts.map(o => [o.name.toLowerCase(), o]),
    );
    expect(lookup['amount']).toBeDefined();
    expect(lookup['amount'].isPartition).toBe(false);
    // ``region`` + ``year`` are partitions but absent from SELECT —
    // they're still surfaced so the publisher can filter on them.
    expect(lookup['region']).toBeDefined();
    expect(lookup['region'].isPartition).toBe(true);
    expect(lookup['year']).toBeDefined();
    expect(lookup['year'].isPartition).toBe(true);
  });

  it('marks columns that DO appear in SELECT+partitions as partitions', () => {
    const opts = new SqlColumnExtractor(
      'SELECT region, amount FROM trades',
      ['region'],
    ).toColumnOptions();
    const region = opts.find(o => o.name.toLowerCase() === 'region')!;
    expect(region.isPartition).toBe(true);
  });
});


describe('extractSqlColumns / columnOptionsFromSql convenience exports', () => {
  it('extractSqlColumns delegates to the class', () => {
    expect(extractSqlColumns('SELECT a, b FROM t')).toEqual(['a', 'b']);
  });

  it('columnOptionsFromSql delegates to the class', () => {
    const opts = columnOptionsFromSql('SELECT a FROM t', ['b']);
    expect(opts.map(o => o.name).sort()).toEqual(['a', 'b']);
  });
});


describe('SqlColumnExtractor caching', () => {
  it('caches extractNames result across calls', () => {
    const ex = new SqlColumnExtractor('SELECT a, b FROM t');
    const r1 = ex.extractNames();
    const r2 = ex.extractNames();
    expect(r1).toBe(r2);  // same reference — cached
  });
});


describe('SqlColumnExtractor.toValueOptions', () => {
  it('returns {} when no value map supplied', () => {
    expect(new SqlColumnExtractor('SELECT a FROM t').toValueOptions())
      .toEqual({});
  });

  it('surfaces value options for columns referenced in SQL', () => {
    const v = new SqlColumnExtractor(
      "SELECT a, region FROM t",
      null,
      { region: ['EU', 'US'], unrelated: ['X'] },
    ).toValueOptions();
    expect(v.region).toEqual(['EU', 'US']);
  });

  it('surfaces value options for partition columns even if not in SQL', () => {
    const v = new SqlColumnExtractor(
      'SELECT amount FROM trades',
      ['region'],                      // partition
      { region: ['EU', 'US'] },
    ).toValueOptions();
    expect(v.region).toEqual(['EU', 'US']);
  });

  it('coerces values to strings', () => {
    const v = new SqlColumnExtractor(
      "SELECT a FROM t WHERE year = ?",
      null,
      { year: [2024, 2025, 2026] as any },
    ).toValueOptions();
    expect(v.year).toEqual(['2024', '2025', '2026']);
  });
});
