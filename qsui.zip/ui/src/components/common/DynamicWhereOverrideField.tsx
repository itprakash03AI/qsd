/**
 * Phase 133-H — runtime override input for a single Dynamic WHERE row.
 *
 * Used by the three "Run with overrides" dialogs (DataFlow, Feed,
 * Reconciliation) so the operator can pick from known distinct values
 * via an Autocomplete dropdown instead of being asked to type the
 * value from memory into a plain text field.
 *
 * Lazy: fires ``/api/sql/distinct-values`` on first render and caches
 * per (connection_id, table, column) for 5 minutes (backend handles
 * the cache).  Falls back to free-text when the lookup returns nothing
 * — same UX contract the WhereClausesEditor uses.
 */
import { useEffect, useState } from 'react';
import { TextField, Autocomplete } from '@mui/material';
import { distinctValues as fetchDistinctValues } from './sqlPreviewApi';
import { WHERE_OPERATORS } from './WhereClausesEditor';


// Phase 133-K — popper override so the dropdown auto-resizes to its
// widest option instead of being clipped to the input's width.  Caps
// at 600px / 90vw so a pathological value doesn't run off screen.
const _autoWidthPopperSlot = {
  popper: {
    sx: {
      width: 'auto !important',
      minWidth: '100%',
      maxWidth: 'min(600px, 90vw)',
      // Force the listbox to wrap-as-needed instead of truncating mid-row.
      '& .MuiAutocomplete-listbox': {
        maxHeight: 360,
      },
      '& .MuiAutocomplete-option': {
        whiteSpace: 'normal',
        wordBreak: 'break-word',
      },
    },
  },
};


export interface DynamicWhereOverrideFieldProps {
  column: string;
  operator: string;
  /** Publisher's default value — shown as helper text. */
  publisherDefault?: any;
  /** Current override value (string or list for list operators). */
  value: any;
  onChange: (next: any) => void;
  /** Connection ID for the distinct-values lookup.  When unset the
   *  field renders a plain TextField (no dropdown). */
  connectionId?: number | null;
  /** Table the column belongs to — required by the lookup endpoint. */
  table?: string | null;
  /** Phase 133-H round 6 — fallback (connection_id, table) tuples
   *  the field tries in order if the primary lookup returns no
   *  values.  Lets cross-source feeds / recons offer a dropdown
   *  whether the column lives on the primary or secondary side. */
  fallbackTargets?: Array<{ connectionId: number; table: string }>;
  /** Display label override.  Defaults to ``${column} (${operator})``. */
  label?: string;
  fullWidth?: boolean;
  size?: 'small' | 'medium';
}


export function DynamicWhereOverrideField(props: DynamicWhereOverrideFieldProps) {
  const {
    column, operator, publisherDefault, value, onChange,
    connectionId, table, fallbackTargets = [],
    label, fullWidth = true, size = 'small',
  } = props;
  const opSpec = WHERE_OPERATORS.find(o => o.value === operator);
  const takesList = !!opSpec?.takesList;
  const takesValue = opSpec ? opSpec.takesValue : true;
  const effLabel = label || `${column} (${operator})`;
  const helperText =
    publisherDefault !== undefined && publisherDefault !== null && publisherDefault !== ''
      ? `Publisher default: ${typeof publisherDefault === 'string'
            ? publisherDefault
            : JSON.stringify(publisherDefault)}`
      : 'No default — leave blank to drop this filter.';

  const [options, setOptions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!column) return;
    let cancelled = false;
    setLoading(true);
    // Phase 133-H round 4 — strip qualifier from column.  Backend
    // quotes ``column`` as a single identifier; passing
    // ``schema.col`` becomes ``"schema.col"`` and fails.
    const bareCol = column.includes('.')
      ? column.substring(column.lastIndexOf('.') + 1)
      : column;
    // Phase 133-H round 6 — try the primary (connectionId, table)
    // first; if it returns nothing, try each fallback in order until
    // one yields a non-empty dropdown.  Lets cross-source feeds /
    // recons offer values regardless of which side the column lives on.
    const targets: Array<{ cid: number; tbl: string }> = [];
    if (connectionId && table) {
      targets.push({ cid: Number(connectionId), tbl: table });
    }
    fallbackTargets.forEach(f => {
      if (f.connectionId && f.table) {
        targets.push({ cid: Number(f.connectionId), tbl: f.table });
      }
    });
    if (targets.length === 0) {
      setLoading(false);
      return () => { cancelled = true; };
    }
    (async () => {
      for (const t of targets) {
        if (cancelled) return;
        try {
          const res = await fetchDistinctValues(t.cid, t.tbl, bareCol);
          const vals = (res?.values || []).map(String);
          if (vals.length > 0) {
            if (!cancelled) setOptions(vals);
            break;
          }
        } catch { /* best-effort, try next target */ }
      }
      if (!cancelled) setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [connectionId, table, column, JSON.stringify(fallbackTargets)]);

  if (!takesValue) {
    return (
      <TextField label={effLabel} size={size} fullWidth={fullWidth}
        disabled value="(no value)" helperText={`${operator} — no value needed`} />
    );
  }

  // List operators (IN, NOT IN, BETWEEN) → multi-Autocomplete so
  // the operator can pick / type several values.
  if (takesList) {
    const arr = Array.isArray(value)
      ? value.map(String)
      : (value ? String(value).split(',').map(s => s.trim()).filter(Boolean) : []);
    return (
      <Autocomplete
        multiple freeSolo size={size} openOnFocus
        options={options}
        value={arr}
        loading={loading}
        onChange={(_, v) => onChange(v.join(','))}
        slotProps={_autoWidthPopperSlot}
        renderInput={p => (
          <TextField {...p} label={effLabel} fullWidth={fullWidth}
            placeholder={options.length ? 'Pick or type values' : 'value1,value2,…'}
            helperText={helperText} />
        )}
      />
    );
  }

  // Single-value operators → ALWAYS Autocomplete freeSolo so the UX
  // is uniform whether or not we have known values yet.  Phase 133-H
  // round 7: no more plain textboxes — even an empty options list
  // renders as an Autocomplete (the user gets the chevron + a
  // consistent look across all editors).
  return (
    <Autocomplete
      size={size} freeSolo openOnFocus
      options={options}
      value={value == null ? '' : String(value)}
      loading={loading}
      onChange={(_, v) => onChange(v ?? '')}
      onInputChange={(_, v, reason) => {
        if (reason === 'input') onChange(v);
      }}
      slotProps={_autoWidthPopperSlot}
      renderInput={p => (
        <TextField {...p} label={effLabel} fullWidth={fullWidth}
          placeholder={options.length > 0
            ? 'Pick or type a value'
            : (loading ? 'Loading values…' : 'Type a value')}
          helperText={helperText} />
      )}
    />
  );
}


export default DynamicWhereOverrideField;
