/**
 * Phase 132.38 — reusable per-config Static / Dynamic WHERE-clause
 * editor.  Same UX the publish dialog uses, lifted out so Feed
 * Generation configs and DataFlow stages can reuse the contract.
 *
 * Contract:
 *   * ``value`` is a list of WhereClause rows ({column, operator,
 *     value, mode}).  The component never mutates its input; every
 *     change emits a new array via ``onChange``.
 *   * ``columnOptions`` powers the column Autocomplete.  Pass the
 *     full set of columns the editor's audience can choose from
 *     (e.g. all columns from the underlying tables, grouped by
 *     ``isPartition``).  If empty, the column field falls back to
 *     plain free-text — the editor never blocks the publisher.
 *   * ``valueOptionsByColumn`` is an optional ``{column: string[]}``
 *     map that turns the value field into an Autocomplete of known
 *     distinct values (e.g. partition values fetched from the
 *     backend).  Missing entries → plain TextField (or multi-text
 *     for list operators).
 *   * ``title`` / ``hint`` / ``addLabel`` let the consumer tailor
 *     the section header without re-styling the whole component.
 */
import { useCallback, useState, useEffect, useRef } from 'react';
import {
  Box, Stack, Typography, Button, Chip, Tooltip, IconButton, TextField,
  Autocomplete, FormControl, InputLabel, Select, MenuItem,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, Warning as WarningIcon, ErrorOutline as ErrorOutlineIcon } from '@mui/icons-material';
import { distinctValues as fetchDistinctValues } from './sqlPreviewApi';
import { safeFetch } from '../../services/api/core';


// Phase 133-K — popper override so dropdowns auto-resize to their
// widest option instead of being clipped to the (often narrow) grid
// cell width.  Capped at 600px / 90vw so long values stay readable
// but don't run off the screen.  Long options wrap instead of getting
// truncated mid-row.
const AUTO_WIDTH_POPPER_SLOT = {
  popper: {
    sx: {
      width: 'auto !important',
      minWidth: '100%',
      maxWidth: 'min(600px, 90vw)',
      '& .MuiAutocomplete-listbox': {
        maxHeight: 360,
      },
      '& .MuiAutocomplete-option': {
        whiteSpace: 'normal',
        wordBreak: 'break-word',
      },
    },
  },
};


// ── Public types ────────────────────────────────────────────────────


export type WhereMode = 'dynamic' | 'static';

export interface WhereClauseRow {
  column: string;
  operator: string;
  value: any;
  mode: WhereMode;
}

export interface WhereColumnOption {
  name: string;
  type?: string;
  isPartition?: boolean;
  /** Phase 133-I round 22 — source table for this column.  Used by
   *  the dropdown's groupBy() to show columns grouped per table —
   *  the CQB UX.  Partition columns get their own group at the top
   *  via the badge.  Missing tableSource falls into ``Other``. */
  tableSource?: string;
}

// Operator vocabulary — mirrors the backend engine
// (parquet_engine_v2._build_where + the bare-form parser).  Keep this
// list in sync with backend/core/where_clause_mapping.py operator pattern.
export const WHERE_OPERATORS: {
  value: string;
  label: string;
  takesList: boolean;
  takesValue: boolean;
}[] = [
  { value: 'eq',           label: '= equals',           takesList: false, takesValue: true  },
  { value: 'ne',           label: '!= not equals',      takesList: false, takesValue: true  },
  { value: 'in',           label: 'IN (any of)',        takesList: true,  takesValue: true  },
  { value: 'not_in',       label: 'NOT IN',             takesList: true,  takesValue: true  },
  { value: 'gt',           label: '>  greater than',    takesList: false, takesValue: true  },
  { value: 'gte',          label: '>= at least',        takesList: false, takesValue: true  },
  { value: 'lt',           label: '<  less than',       takesList: false, takesValue: true  },
  { value: 'lte',          label: '<= at most',         takesList: false, takesValue: true  },
  { value: 'contains',     label: 'contains (ILIKE)',   takesList: false, takesValue: true  },
  { value: 'not_contains', label: "doesn't contain",    takesList: false, takesValue: true  },
  { value: 'between',      label: 'BETWEEN (2 values)', takesList: true,  takesValue: true  },
  { value: 'is_null',      label: 'IS NULL',            takesList: false, takesValue: false },
  { value: 'is_not_null',  label: 'IS NOT NULL',        takesList: false, takesValue: false },
];


// ── Component ───────────────────────────────────────────────────────


export interface WhereClausesEditorProps {
  value: WhereClauseRow[];
  onChange: (next: WhereClauseRow[]) => void;
  columnOptions?: WhereColumnOption[];
  valueOptionsByColumn?: Record<string, string[]>;
  title?: string;
  hint?: React.ReactNode;
  addLabel?: string;
  /** Disable adding / editing rows — useful for read-only previews. */
  readOnly?: boolean;
  /** Phase 133-H — connection ID for lazy ``/api/sql/distinct-values``
   *  lookup.  When set, the editor auto-fetches the value picker's
   *  dropdown values for any column the static ``valueOptionsByColumn``
   *  doesn't already cover.  No-op when not set (today's behaviour). */
  connectionId?: number | null;
  /** Phase 133-H — table hint for the distinct-values lookup.  The
   *  endpoint REQUIRES a table; pass the most-relevant one (e.g. the
   *  primary FROM table of the SQL). */
  distinctValuesTable?: string | null;
  /** Phase 147.1 — table this WHERE editor is targeting.  When set
   *  alongside ``connectionId``, the editor calls
   *  ``POST /api/queries/classify-filters`` after each edit and renders
   *  an inline warning chip next to the operator dropdown when the
   *  row's verdict is ``weak`` / ``unsupported``.  No-op when unset. */
  classifyTable?: string | null;
}


// Phase 147.1 — per-filter verdict surfaced by /api/queries/classify-filters
interface FilterRewrite {
  column:      string;
  operator:    string;
  value:       any;
  confidence:  number;
  explanation: string;
}
interface PruneClassification {
  support:        'supported' | 'weak' | 'unsupported' | 'unknown';
  reason:         string;
  column_kind?:   string;
  rewrite?: FilterRewrite;
}


export function WhereClausesEditor(props: WhereClausesEditorProps) {
  const {
    value, onChange,
    columnOptions = [],
    valueOptionsByColumn = {},
    title = 'WHERE Clauses',
    hint,
    addLabel = 'Add Mapping',
    readOnly = false,
    connectionId = null,
    distinctValuesTable = null,
    classifyTable = null,
  } = props;

  // Phase 133-H — locally-cached distinct values fetched lazily via
  // ``/api/sql/distinct-values``.  Merged with the parent-supplied
  // ``valueOptionsByColumn`` so per-row dropdowns show real values
  // even when the parent didn't pre-fetch them (SQL warehouse
  // non-partition columns, iceberg non-cached tables, etc.).
  const [lazyValueOptions, setLazyValueOptions] = useState<Record<string, string[]>>({});

  const lazilyFetchValues = useCallback((rawColumn: string) => {
    if (!connectionId || !distinctValuesTable) return;
    const colKey = (rawColumn || '').toLowerCase().replace(/^.*\./, '');
    if (!colKey) return;
    if (Object.prototype.hasOwnProperty.call(lazyValueOptions, colKey)) return;
    if (Object.prototype.hasOwnProperty.call(valueOptionsByColumn, colKey)) return;
    setLazyValueOptions(prev => ({ ...prev, [colKey]: [] }));  // sentinel
    // Phase 133-H round 4 — strip qualifier from rawColumn before
    // sending.  Endpoint quotes the column as a single identifier;
    // passing ``schema.col`` becomes ``"schema.col"`` which fails.
    const bareCol = rawColumn.includes('.')
      ? rawColumn.substring(rawColumn.lastIndexOf('.') + 1)
      : rawColumn;
    fetchDistinctValues(Number(connectionId), distinctValuesTable, bareCol)
      .then(res => {
        const vals = (res?.values || []).map(String);
        if (vals.length > 0) {
          setLazyValueOptions(prev => ({ ...prev, [colKey]: vals }));
        }
      })
      .catch(() => { /* best-effort */ });
  }, [connectionId, distinctValuesTable, lazyValueOptions, valueOptionsByColumn]);

  // Phase 133-H — kick off lazy fetch for every row already present so
  // the value picker is a dropdown from the first render.  When
  // connection / table changes, drop any cached values fetched against
  // the old connection so we don't show stale dropdowns.
  useEffect(() => {
    setLazyValueOptions({});
  }, [connectionId, distinctValuesTable]);

  // Phase 147.1 — per-row pruning-hostile filter classifications.  The
  // editor calls POST /api/queries/classify-filters whenever the WHERE
  // rows change, debounced by 350ms so a typing burst collapses to one
  // request.  Failure → empty map (chips render nothing — fail-OPEN).
  const [classifications, setClassifications] = useState<PruneClassification[]>([]);
  // Phase 147.D — server-side flag mirrored to client so we can silently
  // apply confidence==1.0 rewrites when ops opt in.  Stays OFF by
  // default; flipped via `query_guardrails.auto_rewrite_pruning_hostile_ops`
  // only after Phase C acceptance metrics show ≥95% accept rate.
  const [autoApplyEnabled, setAutoApplyEnabled] = useState(false);
  // Per-row "auto-fixed" chip — set when a row is auto-applied so the
  // user sees the explanation without a modal.
  const [autoFixed, setAutoFixed] = useState<Record<number, FilterRewrite>>({});
  // Track which row indices were already auto-applied so the effect
  // doesn't loop: each apply triggers a fresh classify, whose result
  // might re-suggest the same rewrite shape.
  const autoAppliedRef = useRef<Set<string>>(new Set());
  // Bug I fix — request-counter so a slow earlier request can't
  // overwrite a faster later one's results.  Each fire-off captures
  // its sequence number; the resolved handler discards itself if a
  // newer fire-off has already started.
  const classifyReqRef = useRef(0);
  useEffect(() => {
    if (!classifyTable || !connectionId || readOnly) {
      setClassifications([]);
      return;
    }
    const completeRows = value
      .map((w) => ({
        col: w.column || '',
        op:  w.operator || '',
        val: Array.isArray(w.value) ? w.value : (w.value ?? ''),
      }))
      .filter((f) => f.col && f.op);
    if (completeRows.length === 0) {
      setClassifications([]);
      return;
    }
    const handle = setTimeout(async () => {
      const seq = ++classifyReqRef.current;
      try {
        const r = await safeFetch('/api/queries/classify-filters', {
          method: 'POST',
          timeoutMs: 8000,
          body: JSON.stringify({
            connection_id: Number(connectionId),
            table_name:    classifyTable,
            filters:       completeRows,
          }),
        });
        // Bug I — drop stale response when a newer call has started.
        if (seq !== classifyReqRef.current) return;
        const out: PruneClassification[] = [];
        const results = (r?.results || []) as PruneClassification[];
        // Re-align results to the original ``value`` row order — rows
        // missing column/operator weren't sent, so we map by completeness.
        let cursor = 0;
        for (const w of value) {
          if (w.column && w.operator && cursor < results.length) {
            out.push(results[cursor]);
            cursor += 1;
          } else {
            out.push({ support: 'unknown', reason: 'row incomplete' });
          }
        }
        setClassifications(out);
        const serverAuto = !!r?.auto_apply_enabled;
        setAutoApplyEnabled(serverAuto);
        // Phase 147.D — auto-apply confidence==1.0 rewrites when the
        // server-side flag is on AND the user hasn't already declined
        // this row.  Tracked by (column, before-operator) tuple so that
        // re-classifying after apply doesn't re-fire on the rewritten
        // shape.  Each apply both mutates the row and fires the audit
        // (identical to the manual Apply chip path).
        if (serverAuto && !readOnly) {
          let mutated: WhereClauseRow[] | null = null;
          const fixedNext: Record<number, FilterRewrite> = {};
          out.forEach((cls, idx) => {
            const rw = cls.rewrite;
            if (!rw || rw.confidence < 1.0) return;
            const beforeRow = value[idx];
            if (!beforeRow?.column || !beforeRow?.operator) return;
            const fingerprint = `${beforeRow.column}::${beforeRow.operator}::${JSON.stringify(beforeRow.value)}`;
            if (autoAppliedRef.current.has(fingerprint)) return;
            // Same operator alias map as the manual Apply click handler
            // (kept inline so the two paths can't drift).
            const opAlias: Record<string, string> = {
              equals: 'eq', equal: 'eq',
              not_equals: 'neq', ne: 'neq',
              gt: 'gt', ge: 'gte', lt: 'lt', le: 'lte',
              in: 'in', not_in: 'not_in',
              between: 'between',
              is_null: 'is_null', is_not_null: 'is_not_null',
              like: 'contains', not_like: 'not_contains',
              starts_with: 'starts_with',
            };
            const nextOp = opAlias[rw.operator] || rw.operator;
            if (!mutated) mutated = value.slice();
            mutated[idx] = {
              ...mutated[idx],
              column:   rw.column,
              operator: nextOp,
              value:    rw.value,
            };
            autoAppliedRef.current.add(fingerprint);
            fixedNext[idx] = rw;
            // Mirror the manual-Apply audit path.
            safeFetch('/api/queries/rewrite-applied', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                connection_id: connectionId ?? null,
                table_name:    classifyTable ?? null,
                before: {
                  column:   beforeRow.column,
                  operator: beforeRow.operator,
                  value:    beforeRow.value,
                },
                after: {
                  column:   rw.column,
                  operator: nextOp,
                  value:    rw.value,
                },
                confidence:  rw.confidence,
                reason:      cls.reason,
                explanation: rw.explanation,
                auto_applied: true,
              }),
            }).catch(() => { /* fire-and-forget */ });
          });
          if (mutated) {
            setAutoFixed((m) => ({ ...m, ...fixedNext }));
            onChange(mutated);
          }
        }
      } catch {
        if (seq === classifyReqRef.current) setClassifications([]);
      }
    }, 350);
    return () => {
      clearTimeout(handle);
      // Invalidate any in-flight result whose seq is older than the
      // counter at unmount/dep-change time.
      classifyReqRef.current += 1;
    };
  }, [value, classifyTable, connectionId, readOnly]);
  useEffect(() => {
    if (!connectionId || !distinctValuesTable) return;
    value.forEach(w => {
      if (w.column) lazilyFetchValues(w.column);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectionId, distinctValuesTable, value.length]);

  const addRow = useCallback(() => {
    onChange([...value, {
      column: '', operator: 'eq', value: '', mode: 'dynamic',
    }]);
  }, [value, onChange]);

  const updateRow = useCallback(
    (idx: number, patch: Partial<WhereClauseRow>) => {
      // Phase 147.D — user touched this row, clear the auto-fixed chip
      // so it doesn't outlive the manual edit and mislead the reader.
      if (autoFixed[idx]) {
        setAutoFixed((m) => {
          const { [idx]: _drop, ...rest } = m;
          return rest;
        });
      }
      onChange(value.map((row, i) => {
        if (i !== idx) return row;
        const next: WhereClauseRow = { ...row, ...patch };
        if (patch.operator !== undefined) {
          const opSpec = WHERE_OPERATORS.find(o => o.value === patch.operator);
          if (opSpec?.takesList && !Array.isArray(next.value)) {
            next.value = next.value ? [String(next.value)] : [];
          }
          if (!opSpec?.takesList && Array.isArray(next.value)) {
            next.value = next.value[0] ?? '';
          }
          if (opSpec && !opSpec.takesValue) {
            next.value = null;
          }
        }
        return next;
      }));
    },
    [value, onChange],
  );

  const removeRow = useCallback(
    (idx: number) => onChange(value.filter((_, i) => i !== idx)),
    [value, onChange],
  );

  const setMode = useCallback(
    (idx: number, mode: WhereMode) => updateRow(idx, { mode }),
    [updateRow],
  );

  const dynamicCount = value.filter(w => w.mode === 'dynamic').length;
  const staticCount = value.filter(w => w.mode === 'static').length;

  return (
    <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 1.5 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
        <Typography variant="subtitle2">
          {title} ({value.length})
        </Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Tooltip title="Dynamic = caller can override at trigger time. Static = locked at config time.">
            <Chip
              size="small" variant="outlined"
              label={`${dynamicCount} dynamic · ${staticCount} static`}
            />
          </Tooltip>
          {!readOnly && (
            <Button size="small" startIcon={<AddIcon />} onClick={addRow}>
              {addLabel}
            </Button>
          )}
        </Stack>
      </Stack>

      {hint && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
          {hint}
        </Typography>
      )}

      {value.length === 0 ? (
        <>
          {/* 2026-06-10 brain coverage — empty WHERE is the #1 source
              of accidental full-table scans.  Surface a structured
              warning chip (red) when the editor has zero rows AND a
              table context is set (i.e. the editor knows what would
              be scanned).  Without classifyTable we don't know what
              would be scanned, so we just show the neutral "add one"
              copy. */}
          {classifyTable ? (
            <Box sx={{
              p: 1, mb: 1,
              border: 1, borderColor: 'error.main', borderRadius: 1,
              background: 'rgba(244, 67, 54, 0.04)',
            }}>
              <Stack direction="row" spacing={1} alignItems="center">
                <ErrorOutlineIcon fontSize="small" color="error" />
                <Typography variant="body2" color="error.main"
                            sx={{ fontWeight: 600 }}>
                  Full-table scan warning
                </Typography>
              </Stack>
              <Typography variant="caption" color="text.secondary"
                          sx={{ display: 'block', mt: 0.5 }}>
                This query has no WHERE filters — it will scan every
                file in <code>{classifyTable}</code>.  Add at least
                one filter on a partition or bucket column so the
                pruning brain can skip irrelevant files.
                {!readOnly && <> Click <strong>+ {addLabel}</strong> to add one.</>}
              </Typography>
            </Box>
          ) : (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              No WHERE mappings yet.{' '}
              {!readOnly && <>Click <strong>+ {addLabel}</strong> to add one.</>}
            </Typography>
          )}
        </>
      ) : (
        value.map((w, idx) => {
          const opSpec = WHERE_OPERATORS.find(o => o.value === w.operator) || WHERE_OPERATORS[0];
          const colKey = (w.column || '').toLowerCase().replace(/^.*\./, '');
          // Phase 133-H — merge parent-supplied static values with the
          // editor's locally-fetched lazy values so the picker is a
          // dropdown whenever EITHER source has data.
          const knownValues = (valueOptionsByColumn[colKey] && valueOptionsByColumn[colKey].length > 0)
            ? valueOptionsByColumn[colKey]
            : (lazyValueOptions[colKey] || []);
          const valueLabel = `Value${opSpec.takesList ? 's' : ''}`;
          return (
            <Box key={idx}
              sx={{ display: 'grid',
                    gridTemplateColumns: '2.2fr 1.6fr 2.6fr auto auto',
                    gap: 1, alignItems: 'center',
                    border: '1px solid', borderColor: 'divider',
                    borderRadius: 1, p: 1, mb: 1 }}>
              <Autocomplete
                size="small" freeSolo openOnFocus
                disabled={readOnly}
                options={columnOptions}
                value={w.column}
                slotProps={AUTO_WIDTH_POPPER_SLOT}
                onChange={(_, v) => {
                  const name = typeof v === 'string' ? v : (v?.name || '');
                  updateRow(idx, { column: name });
                  // Phase 133-H — trigger lazy distinct-values fetch
                  // for this column so the value field becomes a
                  // dropdown on the next render.
                  if (name) lazilyFetchValues(name);
                }}
                onInputChange={(_, v, reason) => {
                  if (reason === 'input') {
                    updateRow(idx, { column: v });
                    // Phase 133-H round 8 — also lazy-fetch when the
                    // user TYPES a column name instead of picking one
                    // from the dropdown.  Same sentinel guards prevent
                    // duplicate fetches per keystroke.
                    if (v) lazilyFetchValues(v);
                  }
                }}
                getOptionLabel={(o) => typeof o === 'string' ? o : o.name}
                groupBy={(o) => {
                  if (typeof o === 'string') return '';
                  // Phase 133-I round 22 — group by source table (CQB UX).
                  // Partition columns get their own header at the top.
                  return o.isPartition ? '⚑ Partition columns' : (o.tableSource || 'Other');
                }}
                renderOption={(propsRow, o) => (
                  <li {...propsRow} key={typeof o === 'string' ? o : o.name}>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <code style={{ fontSize: 12 }}>{typeof o === 'string' ? o : o.name}</code>
                      {typeof o !== 'string' && o.type && (
                        <span style={{ color: '#888', fontSize: 11 }}>{o.type}</span>
                      )}
                      {typeof o !== 'string' && o.isPartition && (
                        <Chip size="small" label="partition" color="primary"
                              variant="outlined" sx={{ height: 16, fontSize: 10 }} />
                      )}
                    </Stack>
                  </li>
                )}
                renderInput={(p) => (
                  <TextField {...p} label="Column" placeholder="Search columns…" />
                )}
              />
              <Autocomplete
                size="small" disableClearable openOnFocus
                disabled={readOnly}
                options={WHERE_OPERATORS}
                slotProps={AUTO_WIDTH_POPPER_SLOT}
                getOptionLabel={(o) => typeof o === 'string'
                  ? (WHERE_OPERATORS.find(op => op.value === o)?.label || o)
                  : o.label}
                isOptionEqualToValue={(opt, val) => {
                  const ov = typeof opt === 'string' ? opt : opt.value;
                  const vv = typeof val === 'string' ? val : val.value;
                  return ov === vv;
                }}
                value={WHERE_OPERATORS.find(o => o.value === w.operator) || WHERE_OPERATORS[0]}
                onChange={(_, v) => {
                  if (!v) return;
                  const next = typeof v === 'string' ? v : v.value;
                  updateRow(idx, { operator: next });
                }}
                renderInput={(p) => (
                  <TextField {...p} label="Operator" placeholder="Search operators…" />
                )}
              />
              {/* Phase 147.1 — pruning-hostile filter warning chip.
                  Renders only when the classifier returned a non-
                  supported verdict for this row.  Tooltip carries the
                  reason + (when available) the suggested rewrite. */}
              {/* Phase 147.D — auto-fixed chip.  When the silent
                  auto-apply path mutated this row, surface a small
                  green chip so the user knows *something* changed
                  (instead of being puzzled by a different operator).
                  Tooltip carries the rewrite explanation. */}
              {autoFixed[idx] && (
                <Tooltip title={
                  `Auto-applied (confidence ${autoFixed[idx].confidence.toFixed(2)}): ` +
                  autoFixed[idx].explanation
                }>
                  <Chip size="small" color="success" variant="outlined"
                        label="auto-fixed" sx={{ ml: 0.5 }} />
                </Tooltip>
              )}
              {classifications[idx] && classifications[idx].support !== 'supported'
                  && classifications[idx].support !== 'unknown' && (
                <Stack direction="row" spacing={0.5} alignItems="center">
                  <Tooltip
                    title={
                      <Box>
                        <Typography variant="caption" sx={{ display: 'block', fontWeight: 700 }}>
                          {classifications[idx].support === 'unsupported'
                            ? '⚠ This filter WON\'T prune files'
                            : '⚠ Weak pruning'}
                        </Typography>
                        <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                          {classifications[idx].reason}
                        </Typography>
                        {classifications[idx].rewrite && (
                          <Box sx={{ mt: 1, p: 0.5, background: 'rgba(255,255,255,0.1)', borderRadius: 0.5 }}>
                            <Typography variant="caption" sx={{ display: 'block', fontWeight: 700 }}>
                              Suggested rewrite (conf {classifications[idx].rewrite!.confidence.toFixed(2)}):
                            </Typography>
                            <Typography variant="caption" sx={{ display: 'block', fontFamily: 'monospace' }}>
                              {classifications[idx].rewrite!.column}{' '}
                              {classifications[idx].rewrite!.operator}{' '}
                              {Array.isArray(classifications[idx].rewrite!.value)
                                ? JSON.stringify(classifications[idx].rewrite!.value)
                                : String(classifications[idx].rewrite!.value)}
                            </Typography>
                            <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                              {classifications[idx].rewrite!.explanation}
                            </Typography>
                          </Box>
                        )}
                      </Box>
                    }
                  >
                    <Box sx={{ display: 'inline-flex', alignItems: 'center',
                                cursor: 'help', px: 0.5 }}>
                      {classifications[idx].support === 'unsupported'
                        ? <ErrorOutlineIcon fontSize="small" color="error" />
                        : <WarningIcon fontSize="small" color="warning" />}
                    </Box>
                  </Tooltip>
                  {/* Phase 147.C — apply-rewrite affordance.  Renders
                      only when the classifier returned a rewrite for
                      this row; click mutates the WhereClause to the
                      suggested shape.  Confidence labelled on the chip
                      so the user can tell loss-y rewrites
                      (LOWER → IN, conf 0.7) from semantically-identical
                      ones (CAST drop / LIKE→equals / DATE()→range,
                      conf ≥ 0.9). */}
                  {classifications[idx].rewrite && !readOnly && (
                    <Tooltip title={
                      `Apply: ${classifications[idx].rewrite!.column} ` +
                      `${classifications[idx].rewrite!.operator} ` +
                      `${Array.isArray(classifications[idx].rewrite!.value)
                          ? JSON.stringify(classifications[idx].rewrite!.value)
                          : String(classifications[idx].rewrite!.value)}` +
                      ` (confidence ${classifications[idx].rewrite!.confidence.toFixed(2)})`
                    }>
                      <Chip
                        size="small"
                        clickable
                        variant="outlined"
                        color={classifications[idx].rewrite!.confidence >= 0.9
                                ? 'success' : 'warning'}
                        label={`Apply (${classifications[idx].rewrite!.confidence.toFixed(2)})`}
                        onClick={() => {
                          const rw = classifications[idx].rewrite!;
                          // Map operator alias from classifier → editor operator.
                          // Classifier returns 'equals' / 'between' / 'in' (canonical);
                          // WHERE_OPERATORS uses 'eq' / 'between' / 'in'.
                          const opAlias: Record<string, string> = {
                            equals: 'eq', equal: 'eq',
                            not_equals: 'neq', ne: 'neq',
                            gt: 'gt', ge: 'gte', lt: 'lt', le: 'lte',
                            in: 'in', not_in: 'not_in',
                            between: 'between',
                            is_null: 'is_null', is_not_null: 'is_not_null',
                            like: 'contains', not_like: 'not_contains',
                            starts_with: 'starts_with',
                          };
                          const nextOp = opAlias[rw.operator] || rw.operator;
                          const beforeRow = value[idx];
                          updateRow(idx, {
                            column: rw.column,
                            operator: nextOp,
                            value: rw.value as any,
                          });
                          // Phase 147.C audit log — fire-and-forget.  Lets ops
                          // see acceptance rate before flipping Phase 147.D
                          // auto-apply.  No await; failure is silent.
                          safeFetch('/api/queries/rewrite-applied', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              connection_id: connectionId ?? null,
                              table_name:    classifyTable ?? null,
                              before: {
                                column:   beforeRow?.column,
                                operator: beforeRow?.operator,
                                value:    beforeRow?.value,
                              },
                              after: {
                                column:   rw.column,
                                operator: nextOp,
                                value:    rw.value,
                              },
                              confidence:  rw.confidence,
                              reason:      classifications[idx].reason,
                              explanation: rw.explanation,
                            }),
                          }).catch(() => { /* fire-and-forget */ });
                        }}
                      />
                    </Tooltip>
                  )}
                </Stack>
              )}
              {opSpec.takesValue ? (
                opSpec.takesList ? (
                  <Autocomplete
                    multiple freeSolo size="small" openOnFocus
                    disabled={readOnly}
                    options={knownValues}
                    slotProps={AUTO_WIDTH_POPPER_SLOT}
                    value={Array.isArray(w.value) ? w.value.map(String) : (w.value ? [String(w.value)] : [])}
                    onChange={(_, v) => updateRow(idx, { value: v })}
                    renderInput={(p) => (
                      <TextField {...p} label={valueLabel}
                        placeholder={knownValues.length ? 'Pick or type…' : 'Type values, comma to add'} />
                    )}
                  />
                ) : (
                  // Phase 133-H round 7 — single-value picker is ALWAYS
                  // an Autocomplete freeSolo, even when knownValues is
                  // empty.  No more plain textboxes — consistent look
                  // across every editor surface.
                  <Autocomplete
                    size="small" freeSolo openOnFocus
                    disabled={readOnly}
                    options={knownValues}
                    slotProps={AUTO_WIDTH_POPPER_SLOT}
                    value={w.value == null ? '' : String(w.value)}
                    onChange={(_, v) => updateRow(idx, { value: v ?? '' })}
                    onInputChange={(_, v, reason) => {
                      if (reason === 'input') updateRow(idx, { value: v });
                    }}
                    renderInput={(p) => (
                      <TextField {...p} label={valueLabel}
                        placeholder={knownValues.length > 0
                          ? 'Pick or type…'
                          : 'Type a value'} />
                    )}
                  />
                )
              ) : (
                <Typography variant="caption" color="text.secondary" sx={{ pl: 1 }}>
                  (no value — {opSpec.label})
                </Typography>
              )}
              <Stack direction="row" spacing={0.5}>
                <Chip
                  label="Dynamic"
                  size="small" clickable={!readOnly}
                  color={w.mode === 'dynamic' ? 'primary' : 'default'}
                  variant={w.mode === 'dynamic' ? 'filled' : 'outlined'}
                  onClick={readOnly ? undefined : () => setMode(idx, 'dynamic')}
                />
                <Chip
                  label="Static"
                  size="small" clickable={!readOnly}
                  color={w.mode === 'static' ? 'default' : 'default'}
                  variant={w.mode === 'static' ? 'filled' : 'outlined'}
                  onClick={readOnly ? undefined : () => setMode(idx, 'static')}
                />
              </Stack>
              <IconButton size="small" color="error"
                disabled={readOnly}
                onClick={() => removeRow(idx)}
                aria-label="Remove WHERE mapping">
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Box>
          );
        })
      )}
    </Box>
  );
}

export default WhereClausesEditor;
