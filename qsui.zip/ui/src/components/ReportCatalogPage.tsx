/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Unified Report Catalog (Phase 23A + Phase 58)
 *
 * Browse both parametric and business reports organized by folders and tags.
 * Features: folder tree, tag filter, favorites, recently viewed, template gallery,
 * certified badge, share links, embed tokens, clone from template.
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Divider, IconButton, InputAdornment,
  List, ListItemButton, ListItemIcon, ListItemText, Paper, Skeleton, Tab, Tabs,
  TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon,
  Assessment as ReportIcon,
  Bookmark as BookmarkIcon,
  CheckCircle as CertifiedIcon,
  ChevronRight as ChevronRightIcon,
  Clear as ClearIcon,
  Code as EmbedIcon,
  ContentCopy as CloneIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  ExpandLess as CollapseIcon,
  ExpandMore as ExpandMoreIcon,
  Folder as FolderIcon,
  FolderOpen as FolderOpenIcon,
  History as RecentIcon,
  Label as TagIcon,
  Link as ShareIcon,
  PlayArrow as RunIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  Star as StarIcon,
  StarBorder as StarBorderIcon,
  ViewModule as TemplateIcon,
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

// ── Constants ──────────────────────────────────────────────────────────────

const TYPE_COLORS = {
  parametric: { bg: '#e3f2fd', fg: '#1565c0', label: 'Parametric' },
  business:   { bg: '#e8f5e9', fg: '#2e7d32', label: 'Business' },
};

// ── FolderTreeItem ────────────────────────────────────────────────────────

function FolderTreeItem({
  folder, depth, selectedFolderId, onSelect, onEdit, onDelete,
}: {
  folder: any; depth: number; selectedFolderId: number | null;
  onSelect: (id: number | null) => void;
  onEdit: (f: any) => void;
  onDelete: (f: any) => void;
}) {
  const [expanded, setExpanded] = useState(depth === 0);
  const hasChildren = (folder.children || []).length > 0;
  const active = selectedFolderId === folder.id;

  return (
    <>
      <ListItemButton
        dense
        selected={active}
        sx={{ pl: 1.5 + depth * 2, pr: 1, py: 0.4, borderRadius: 1, mb: 0.25 }}
        onClick={() => onSelect(active ? null : folder.id)}
      >
        <ListItemIcon sx={{ minWidth: 28 }}>
          {active ? <FolderOpenIcon sx={{ fontSize: 16, color: folder.color || '#1976d2' }} />
                  : <FolderIcon sx={{ fontSize: 16, color: folder.color || '#1976d2' }} />}
        </ListItemIcon>
        <ListItemText
          primary={folder.name}
          primaryTypographyProps={{ variant: 'body2', fontWeight: active ? 600 : 400, noWrap: true }}
        />
        {hasChildren && (
          <IconButton size="small" sx={{ p: 0.25 }} onClick={e => { e.stopPropagation(); setExpanded(v => !v); }}>
            {expanded ? <CollapseIcon sx={{ fontSize: 14 }} /> : <ExpandMoreIcon sx={{ fontSize: 14 }} />}
          </IconButton>
        )}
        <IconButton size="small" sx={{ p: 0.25, opacity: 0, '.MuiListItemButton-root:hover &': { opacity: 1 } }}
          onClick={e => { e.stopPropagation(); onEdit(folder); }}>
          <EditIcon sx={{ fontSize: 12 }} />
        </IconButton>
        <IconButton size="small" color="error" sx={{ p: 0.25, opacity: 0, '.MuiListItemButton-root:hover &': { opacity: 1 } }}
          onClick={e => { e.stopPropagation(); onDelete(folder); }}>
          <DeleteIcon sx={{ fontSize: 12 }} />
        </IconButton>
      </ListItemButton>
      {hasChildren && expanded && folder.children.map((child: any) => (
        <FolderTreeItem key={child.id} folder={child} depth={depth + 1}
          selectedFolderId={selectedFolderId} onSelect={onSelect}
          onEdit={onEdit} onDelete={onDelete} />
      ))}
    </>
  );
}

// ── ReportCard ────────────────────────────────────────────────────────────

function ReportCard({
  report, tags, favoriteIds, onToggleFavorite, onRun, onShare, onEmbed, onClone,
  isAdmin,
}: {
  report: any; tags: any[]; favoriteIds: any[];
  onToggleFavorite: (id: number, type: string) => void;
  onRun: (r: any) => void;
  onShare?: (r: any) => void;
  onEmbed?: (r: any) => void;
  onClone?: (r: any) => void;
  isAdmin: boolean;
}) {
  const reportType = report.report_type || 'parametric';
  const tc = TYPE_COLORS[reportType] || TYPE_COLORS.parametric;
  const isFav = favoriteIds.some((f: any) =>
    typeof f === 'object'
      ? f.report_id === report.id && f.report_type === reportType
      : f === report.id
  );

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2, display: 'flex', flexDirection: 'column', gap: 1,
        cursor: 'pointer', transition: 'box-shadow 0.15s',
        '&:hover': { boxShadow: 3, borderColor: 'primary.light' },
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
        <ReportIcon sx={{ fontSize: 20, color: tc.fg, mt: 0.25, flexShrink: 0 }} />
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <Typography variant="body2" fontWeight={600} noWrap title={report.name} sx={{ flex: 1 }}>
              {report.name}
            </Typography>
            {report.is_certified && (
              <Tooltip title="Certified template">
                <CertifiedIcon sx={{ fontSize: 16, color: 'success.main' }} />
              </Tooltip>
            )}
          </Box>
          {report.description && (
            <Typography variant="caption" color="text.secondary" noWrap title={report.description}>
              {report.description}
            </Typography>
          )}
        </Box>
        <Tooltip title={isFav ? 'Remove from favorites' : 'Add to favorites'}>
          <IconButton size="small" sx={{ p: 0.25 }}
            onClick={e => { e.stopPropagation(); onToggleFavorite(report.id, reportType); }}>
            {isFav
              ? <StarIcon sx={{ fontSize: 16, color: 'warning.main' }} />
              : <StarBorderIcon sx={{ fontSize: 16, color: 'text.disabled' }} />}
          </IconButton>
        </Tooltip>
      </Box>

      <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', alignItems: 'center' }}>
        <Chip
          label={tc.label} size="small"
          sx={{ height: 18, fontSize: 10, bgcolor: tc.bg, color: tc.fg, fontWeight: 600 }}
        />
        {report.template_category && (
          <Chip label={report.template_category} size="small" variant="outlined"
            sx={{ height: 18, fontSize: 10 }} />
        )}
        {(report.execution_count || 0) > 0 && (
          <Chip label={`${report.execution_count} runs`} size="small" variant="outlined"
            sx={{ height: 18, fontSize: 10 }} />
        )}
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 0.5 }}>
        {reportType === 'business' && report.is_certified && onClone && (
          <Tooltip title="Use this template">
            <IconButton size="small" onClick={e => { e.stopPropagation(); onClone(report); }}>
              <CloneIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        )}
        {reportType === 'business' && onShare && (
          <Tooltip title="Share">
            <IconButton size="small" onClick={e => { e.stopPropagation(); onShare(report); }}>
              <ShareIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        )}
        {reportType === 'business' && onEmbed && (isAdmin || report.owner) && (
          <Tooltip title="Embed">
            <IconButton size="small" onClick={e => { e.stopPropagation(); onEmbed(report); }}>
              <EmbedIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        )}
        <Button size="small" variant="contained" startIcon={<RunIcon />}
          onClick={() => onRun(report)}>
          Run
        </Button>
      </Box>
    </Paper>
  );
}

// ── ShareDialog ──────────────────────────────────────────────────────────

function ShareDialog({ open, report, onClose }: {
  open: boolean; report: any; onClose: () => void;
}) {
  const [shares, setShares] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState('');

  const loadShares = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    try {
      const res = await api.listBusinessReportShares(report.id);
      setShares(res.shares || []);
    } finally { setLoading(false); }
  }, [report?.id]);

  useEffect(() => { if (open) loadShares(); }, [open, loadShares]);

  const handleCreate = async () => {
    setCreating(true);
    try {
      await api.createBusinessReportShare(report.id);
      loadShares();
    } catch (e: any) { alert(e.message); }
    finally { setCreating(false); }
  };

  const handleRevoke = async (token: string) => {
    try {
      await api.revokeBusinessReportShare(report.id, token);
      loadShares();
    } catch (e: any) { alert(e.message); }
  };

  const copyLink = (token: string) => {
    const url = `${window.location.origin}/shared-business-report/${token}`;
    navigator.clipboard.writeText(url);
    setCopied(token);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Share: {report?.name}</DialogTitle>
      <DialogContent>
        {loading ? <CircularProgress size={20} /> : (
          <>
            {shares.length === 0 && (
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                No share links yet. Create one to share this report publicly.
              </Typography>
            )}
            {shares.map((s: any) => (
              <Box key={s.token} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1,
                p: 1, bgcolor: 'grey.50', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ flex: 1, fontFamily: 'monospace' }}>
                  ...{s.token.slice(-12)}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {s.access_count} views
                </Typography>
                <Button size="small" onClick={() => copyLink(s.token)}>
                  {copied === s.token ? 'Copied!' : 'Copy'}
                </Button>
                <IconButton size="small" color="error" onClick={() => handleRevoke(s.token)}>
                  <DeleteIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Box>
            ))}
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={handleCreate} disabled={creating}>
          {creating ? <CircularProgress size={16} /> : 'New Share Link'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── EmbedDialog ──────────────────────────────────────────────────────────

function EmbedDialog({ open, report, onClose }: {
  open: boolean; report: any; onClose: () => void;
}) {
  const [tokens, setTokens] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState('');

  const loadTokens = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    try {
      const res = await api.listBusinessReportEmbeds(report.id);
      setTokens(res.tokens || []);
    } finally { setLoading(false); }
  }, [report?.id]);

  useEffect(() => { if (open) loadTokens(); }, [open, loadTokens]);

  const handleCreate = async () => {
    setCreating(true);
    try {
      await api.createBusinessReportEmbed(report.id);
      loadTokens();
    } catch (e: any) { alert(e.message); }
    finally { setCreating(false); }
  };

  const handleRevoke = async (token: string) => {
    try {
      await api.revokeBusinessReportEmbed(token);
      loadTokens();
    } catch (e: any) { alert(e.message); }
  };

  const copySnippet = (token: string) => {
    const url = `${window.location.origin}/embedded-business-report/${token}`;
    const html = `<iframe src="${url}" width="100%" height="600" frameBorder="0"></iframe>`;
    navigator.clipboard.writeText(html);
    setCopied(token);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Embed: {report?.name}</DialogTitle>
      <DialogContent>
        {loading ? <CircularProgress size={20} /> : (
          <>
            {tokens.length === 0 && (
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                No embed tokens yet. Create one to embed this report in an external page.
              </Typography>
            )}
            {tokens.map((t: any) => (
              <Box key={t.token} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1,
                p: 1, bgcolor: 'grey.50', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ flex: 1, fontFamily: 'monospace' }}>
                  ...{t.token.slice(-12)}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {t.access_count} loads
                </Typography>
                <Button size="small" onClick={() => copySnippet(t.token)}>
                  {copied === t.token ? 'Copied!' : 'Copy HTML'}
                </Button>
                <IconButton size="small" color="error" onClick={() => handleRevoke(t.token)}>
                  <DeleteIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Box>
            ))}
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={handleCreate} disabled={creating}>
          {creating ? <CircularProgress size={16} /> : 'New Embed Token'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── FolderDialog ──────────────────────────────────────────────────────────

function FolderDialog({ open, folder, onClose, onSaved }: {
  open: boolean; folder: any; onClose: () => void; onSaved: () => void;
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#1976d2');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) { setName(folder?.name || ''); setColor(folder?.color || '#1976d2'); setError(''); }
  }, [open, folder]);

  const handleSave = async () => {
    if (!name.trim()) { setError('Name is required'); return; }
    setSaving(true);
    try {
      if (folder?.id) {
        await api.updateReportFolder(folder.id, { name: name.trim(), color });
      } else {
        await api.createReportFolder({ name: name.trim(), color });
      }
      onSaved();
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>{folder?.id ? 'Edit Folder' : 'New Folder'}</DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}
        <TextField label="Folder name" fullWidth size="small" value={name}
          onChange={e => setName(e.target.value)} autoFocus sx={{ mb: 2, mt: 1 }} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="body2" color="text.secondary">Color:</Typography>
          <input type="color" value={color} onChange={e => setColor(e.target.value)}
            style={{ width: 40, height: 28, border: 'none', padding: 0, cursor: 'pointer' }} />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── TagDialog ─────────────────────────────────────────────────────────────

function TagDialog({ open, onClose, onSaved }: {
  open: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#1976d2');
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) { setName(''); setColor('#1976d2'); } }, [open]);

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await api.createReportTag({ name: name.trim(), color });
      onSaved();
    } catch (e: any) { alert(e.message); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>New Tag</DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        <TextField label="Tag name" fullWidth size="small" value={name}
          onChange={e => setName(e.target.value)} autoFocus sx={{ mb: 2, mt: 1 }} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="body2" color="text.secondary">Color:</Typography>
          <input type="color" value={color} onChange={e => setColor(e.target.value)}
            style={{ width: 40, height: 28, border: 'none', padding: 0, cursor: 'pointer' }} />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Template Gallery ──────────────────────────────────────────────────────

function TemplateGallery({ onClone, onRun }: {
  onClone: (r: any) => void; onRun: (r: any) => void;
}) {
  const [templates, setTemplates] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [tList, catRes] = await Promise.all([
          api.listTemplates(selectedCat || undefined),
          api.listTemplateCategories(),
        ]);
        setTemplates(Array.isArray(tList) ? tList : []);
        setCategories(catRes.categories || []);
      } finally { setLoading(false); }
    })();
  }, [selectedCat]);

  if (loading) return (
    <Box sx={{ p: 2 }}>
      <Skeleton variant="rounded" height={40} width={300} sx={{ mb: 2 }} />
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        {[1, 2, 3, 4, 5, 6].map(i => (
          <Skeleton key={i} variant="rounded" height={160} sx={{ width: 280, borderRadius: 2 }} />
        ))}
      </Box>
    </Box>
  );

  return (
    <Box sx={{ p: 2 }}>
      {/* Category filter tabs */}
      {categories.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Chip label="All" size="small" onClick={() => setSelectedCat(null)}
            color={selectedCat === null ? 'primary' : 'default'}
            sx={{ mr: 0.5, mb: 0.5 }} />
          {categories.map(c => (
            <Chip key={c} label={c} size="small"
              onClick={() => setSelectedCat(selectedCat === c ? null : c)}
              color={selectedCat === c ? 'primary' : 'default'}
              sx={{ mr: 0.5, mb: 0.5 }} />
          ))}
        </Box>
      )}

      {templates.length === 0 ? (
        <Box sx={{ textAlign: 'center', pt: 6 }}>
          <TemplateIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
          <Typography variant="h6" color="text.secondary">No templates available</Typography>
          <Typography variant="body2" color="text.disabled">
            Admins can certify business reports to make them available as templates.
          </Typography>
        </Box>
      ) : (
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 2 }}>
          {templates.map((t: any) => (
            <Paper key={t.id} variant="outlined" sx={{
              p: 2, display: 'flex', flexDirection: 'column', gap: 1,
              '&:hover': { boxShadow: 3, borderColor: 'success.light' },
            }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <CertifiedIcon sx={{ fontSize: 18, color: 'success.main' }} />
                <Typography variant="body2" fontWeight={600} noWrap sx={{ flex: 1 }}>{t.name}</Typography>
              </Box>
              {t.description && (
                <Typography variant="caption" color="text.secondary" noWrap>{t.description}</Typography>
              )}
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                {t.template_category && (
                  <Chip label={t.template_category} size="small" sx={{ height: 18, fontSize: 10 }} />
                )}
                <Chip label={`by ${t.owner || 'admin'}`} size="small" variant="outlined"
                  sx={{ height: 18, fontSize: 10 }} />
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 'auto' }}>
                <Button size="small" variant="outlined" startIcon={<RunIcon />}
                  onClick={() => onRun(t)}>Preview</Button>
                <Button size="small" variant="contained" color="success" startIcon={<CloneIcon />}
                  onClick={() => onClone(t)}>Use Template</Button>
              </Box>
            </Paper>
          ))}
        </Box>
      )}
    </Box>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────

export default function ReportCatalogPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = (user as any)?.role === 'admin' || (user as any)?.role === 'super_admin' || (user as any)?.is_admin;

  // Data
  const [catalog, setCatalog] = useState<any>({ folders: [], tags: [], favorites: [], recent: [] });
  const [allReports, setAllReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Navigation state
  const [selectedFolderId, setSelectedFolderId] = useState<number | null>(null);
  const [selectedTagId, setSelectedTagId] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'favorites' | 'recent' | 'templates'>('all');
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [typeFilter, setTypeFilter] = useState<'all' | 'parametric' | 'business'>('all');

  // Favorites (mutable)
  const [favoriteIds, setFavoriteIds] = useState<any[]>([]);

  // Dialogs
  const [folderDialogOpen, setFolderDialogOpen] = useState(false);
  const [editFolder, setEditFolder] = useState<any>(null);
  const [deleteFolder, setDeleteFolder] = useState<any>(null);
  const [tagDialogOpen, setTagDialogOpen] = useState(false);
  const [shareReport, setShareReport] = useState<any>(null);
  const [embedReport, setEmbedReport] = useState<any>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const cat = await api.getReportCatalog();
      setCatalog(cat);
      const merged: any[] = [
        ...(cat.parametric_reports || []),
        ...(cat.business_reports || []),
      ];
      merged.sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''));
      setAllReports(merged);
      setFavoriteIds(cat.favorites || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Search debounce
  useEffect(() => {
    if (!searchQ.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await api.searchReportsUnified(searchQ.trim());
        setSearchResults(res.results || []);
      } finally { setSearching(false); }
    }, 300);
    return () => clearTimeout(t);
  }, [searchQ]);

  const handleToggleFavorite = async (reportId: number, reportType: string) => {
    try {
      await api.toggleReportFavorite(reportId, reportType);
      setFavoriteIds(prev => {
        const exists = prev.some((f: any) =>
          typeof f === 'object'
            ? f.report_id === reportId && f.report_type === reportType
            : false
        );
        if (exists) {
          return prev.filter((f: any) =>
            typeof f === 'object'
              ? !(f.report_id === reportId && f.report_type === reportType)
              : f !== reportId
          );
        }
        return [...prev, { report_id: reportId, report_type: reportType }];
      });
    } catch (e: any) { alert(e.message); }
  };

  const handleRun = async (report: any) => {
    const reportType = report.report_type || 'parametric';
    try { await api.recordReportView(report.id, reportType); } catch {}
    if (reportType === 'business') {
      navigate(`/business-reports/${report.id}`);
    } else {
      navigate(`/report-manager?reportId=${report.id}`);
    }
  };

  const handleClone = async (report: any) => {
    try {
      const cloned = await api.cloneBusinessReport(report.id);
      navigate(`/business-reports/${cloned.id}/edit`);
    } catch (e: any) { alert(e.message); }
  };

  const handleDeleteFolder = async () => {
    if (!deleteFolder) return;
    try {
      await api.deleteReportFolder(deleteFolder.id);
      if (selectedFolderId === deleteFolder.id) setSelectedFolderId(null);
      setDeleteFolder(null);
      load();
    } catch (e: any) { alert(e.message); }
  };

  // Compute visible reports
  const visibleReports = useMemo(() => {
    if (searchQ.trim()) return searchResults;

    let list = [...allReports];

    // Type filter
    if (typeFilter !== 'all') {
      list = list.filter(r => (r.report_type || 'parametric') === typeFilter);
    }

    if (viewMode === 'favorites') {
      list = list.filter(r => {
        const rt = r.report_type || 'parametric';
        return favoriteIds.some((f: any) =>
          typeof f === 'object'
            ? f.report_id === r.id && f.report_type === rt
            : f === r.id
        );
      });
    } else if (viewMode === 'recent') {
      const recentItems: any[] = catalog.recent || [];
      list = list.filter(r => {
        const rt = r.report_type || 'parametric';
        return recentItems.some((ri: any) =>
          typeof ri === 'object'
            ? ri.report_id === r.id && ri.report_type === rt
            : ri === r.id
        );
      });
    } else if (selectedFolderId != null) {
      list = list.filter(r => r.folder_id === selectedFolderId);
    }

    if (selectedTagId != null) {
      list = list.filter(r => (r.tags || []).some((t: any) => (t.id || t) === selectedTagId));
    }

    return list;
  }, [allReports, searchQ, searchResults, viewMode, selectedFolderId, selectedTagId, favoriteIds, catalog, typeFilter]);

  const tags = catalog.tags || [];
  const folders = catalog.folders || [];

  return (
    <Box sx={{ display: 'flex', height: '100%', overflow: 'hidden' }}>
      {/* ── Left Sidebar ─────────────────────────────────────────── */}
      <Box sx={{
        width: 240, flexShrink: 0, borderRight: '1px solid', borderColor: 'divider',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <Box sx={{ px: 1.5, py: 1, display: 'flex', alignItems: 'center', gap: 0.5,
          borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" fontWeight={600} sx={{ flex: 1 }}>Catalog</Typography>
          <Tooltip title="Refresh">
            <IconButton size="small" onClick={load} disabled={loading}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>

        <Box sx={{ flex: 1, overflowY: 'auto', px: 1, py: 1 }}>
          {/* View shortcuts */}
          <Typography variant="caption" color="text.disabled" sx={{ px: 0.5, display: 'block', mb: 0.5 }}>
            VIEWS
          </Typography>
          {[
            { id: 'all',       label: 'All Reports', icon: <ReportIcon sx={{ fontSize: 16 }} /> },
            { id: 'favorites', label: 'Favorites',   icon: <StarIcon sx={{ fontSize: 16, color: 'warning.main' }} /> },
            { id: 'recent',    label: 'Recently Viewed', icon: <RecentIcon sx={{ fontSize: 16 }} /> },
            { id: 'templates', label: 'Templates',   icon: <TemplateIcon sx={{ fontSize: 16, color: 'success.main' }} /> },
          ].map(v => (
            <ListItemButton key={v.id} dense selected={viewMode === v.id && selectedFolderId == null}
              sx={{ borderRadius: 1, mb: 0.25, pl: 1.5 }}
              onClick={() => { setViewMode(v.id as any); setSelectedFolderId(null); setSelectedTagId(null); }}>
              <ListItemIcon sx={{ minWidth: 26 }}>{v.icon}</ListItemIcon>
              <ListItemText primary={v.label} primaryTypographyProps={{ variant: 'body2' }} />
            </ListItemButton>
          ))}

          <Divider sx={{ my: 1 }} />

          {/* Type filter */}
          <Typography variant="caption" color="text.disabled" sx={{ px: 0.5, display: 'block', mb: 0.5 }}>
            TYPE
          </Typography>
          <Box sx={{ display: 'flex', gap: 0.5, px: 0.5, mb: 1, flexWrap: 'wrap' }}>
            {(['all', 'parametric', 'business'] as const).map(t => (
              <Chip key={t} label={t === 'all' ? 'All' : TYPE_COLORS[t].label} size="small"
                onClick={() => setTypeFilter(t)}
                color={typeFilter === t ? 'primary' : 'default'}
                variant={typeFilter === t ? 'filled' : 'outlined'}
                sx={{ height: 22, fontSize: 11 }} />
            ))}
          </Box>

          <Divider sx={{ my: 1 }} />

          {/* Folders */}
          <Box sx={{ display: 'flex', alignItems: 'center', px: 0.5, mb: 0.5 }}>
            <Typography variant="caption" color="text.disabled" sx={{ flex: 1 }}>FOLDERS</Typography>
            <Tooltip title="New folder">
              <IconButton size="small" sx={{ p: 0.25 }} onClick={() => { setEditFolder(null); setFolderDialogOpen(true); }}>
                <AddIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
          </Box>
          {folders.length === 0 ? (
            <Typography variant="caption" color="text.disabled" sx={{ px: 1, display: 'block' }}>
              No folders yet
            </Typography>
          ) : folders.map((f: any) => (
            <FolderTreeItem key={f.id} folder={f} depth={0}
              selectedFolderId={selectedFolderId}
              onSelect={id => { setSelectedFolderId(id); setViewMode('all'); }}
              onEdit={folder => { setEditFolder(folder); setFolderDialogOpen(true); }}
              onDelete={setDeleteFolder}
            />
          ))}

          <Divider sx={{ my: 1 }} />

          {/* Tags */}
          <Box sx={{ display: 'flex', alignItems: 'center', px: 0.5, mb: 0.5 }}>
            <Typography variant="caption" color="text.disabled" sx={{ flex: 1 }}>TAGS</Typography>
            <Tooltip title="New tag">
              <IconButton size="small" sx={{ p: 0.25 }} onClick={() => setTagDialogOpen(true)}>
                <AddIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
          </Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, px: 0.5 }}>
            {tags.map((t: any) => (
              <Chip key={t.id} label={t.name} size="small"
                onClick={() => setSelectedTagId(selectedTagId === t.id ? null : t.id)}
                onDelete={() => api.deleteReportTag(t.id).then(load)}
                sx={{
                  height: 20, fontSize: 10,
                  bgcolor: selectedTagId === t.id ? (t.color || '#1976d2') : undefined,
                  color: selectedTagId === t.id ? '#fff' : undefined,
                  borderColor: t.color || '#9e9e9e',
                  border: '1px solid',
                }}
                variant="outlined"
              />
            ))}
            {tags.length === 0 && (
              <Typography variant="caption" color="text.disabled">No tags yet</Typography>
            )}
          </Box>
        </Box>
      </Box>

      {/* ── Main Area ─────────────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {viewMode === 'templates' ? (
          <TemplateGallery onClone={handleClone} onRun={handleRun} />
        ) : (
          <>
            {/* Search bar */}
            <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider',
              display: 'flex', alignItems: 'center', gap: 1.5, flexShrink: 0 }}>
              <TextField
                size="small" placeholder="Search reports..." value={searchQ}
                onChange={e => setSearchQ(e.target.value)}
                sx={{ flex: 1, maxWidth: 400 }}
                InputProps={{
                  startAdornment: <InputAdornment position="start">
                    {searching ? <CircularProgress size={14} /> : <SearchIcon fontSize="small" />}
                  </InputAdornment>,
                  endAdornment: searchQ ? (
                    <InputAdornment position="end">
                      <IconButton size="small" onClick={() => setSearchQ('')}><ClearIcon fontSize="small" /></IconButton>
                    </InputAdornment>
                  ) : null,
                }}
              />
              <Typography variant="body2" color="text.secondary">
                {visibleReports.length} report{visibleReports.length !== 1 ? 's' : ''}
              </Typography>
              {selectedTagId != null && (
                <Chip
                  label={`Tag: ${tags.find((t: any) => t.id === selectedTagId)?.name || selectedTagId}`}
                  size="small" onDelete={() => setSelectedTagId(null)} color="primary"
                />
              )}
            </Box>

            {/* Report grid */}
            <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', pt: 6 }}>
                  <CircularProgress />
                </Box>
              ) : visibleReports.length === 0 ? (
                <Box sx={{ textAlign: 'center', pt: 8 }}>
                  <ReportIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
                  <Typography variant="h6" color="text.secondary">
                    {searchQ.trim() ? 'No reports match your search' : 'No reports in this view'}
                  </Typography>
                  <Typography variant="body2" color="text.disabled" sx={{ mb: 1.5 }}>
                    {searchQ.trim() ? 'Try a different search term' : 'Create parametric or business reports to see them here.'}
                  </Typography>
                  {!searchQ.trim() && (
                    <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
                      <Button variant="outlined" size="small" onClick={() => navigate('/report-manager')}>
                        Parametric Reports
                      </Button>
                      <Button variant="contained" size="small" onClick={() => navigate('/business-reports/new')}>
                        New Business Report
                      </Button>
                    </Box>
                  )}
                </Box>
              ) : (
                <Box sx={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                  gap: 2,
                }}>
                  {visibleReports.map((r: any) => (
                    <ReportCard key={`${r.report_type || 'p'}-${r.id}`} report={r} tags={tags}
                      favoriteIds={favoriteIds}
                      onToggleFavorite={handleToggleFavorite}
                      onRun={handleRun}
                      onShare={r.report_type === 'business' ? setShareReport : undefined}
                      onEmbed={r.report_type === 'business' ? setEmbedReport : undefined}
                      onClone={r.is_certified ? handleClone : undefined}
                      isAdmin={isAdmin}
                    />
                  ))}
                </Box>
              )}
            </Box>
          </>
        )}
      </Box>

      {/* ── Dialogs ───────────────────────────────────────────────── */}
      <FolderDialog
        open={folderDialogOpen} folder={editFolder}
        onClose={() => setFolderDialogOpen(false)}
        onSaved={() => { setFolderDialogOpen(false); load(); }}
      />
      <TagDialog
        open={tagDialogOpen}
        onClose={() => setTagDialogOpen(false)}
        onSaved={() => { setTagDialogOpen(false); load(); }}
      />
      <ShareDialog
        open={!!shareReport} report={shareReport}
        onClose={() => setShareReport(null)}
      />
      <EmbedDialog
        open={!!embedReport} report={embedReport}
        onClose={() => setEmbedReport(null)}
      />

      <Dialog open={!!deleteFolder} onClose={() => setDeleteFolder(null)} maxWidth="xs">
        <DialogTitle>Delete Folder?</DialogTitle>
        <DialogContent>
          <Typography>
            Delete folder <strong>{deleteFolder?.name}</strong>?
            Reports inside will be unassigned (not deleted).
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteFolder(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDeleteFolder}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
