/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowRunDetailPage — detail view of one dataflow run.
 *
 * Shows the run status, every stage's status with logs/outputs, and
 * actions: cancel running, resume failed, rerun-single-stage.  Live
 * updates via WebSocket.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, IconButton, MenuItem,
  Paper, Select, Stack, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Refresh as RefreshIcon, ExpandMore as ExpandIcon, ExpandLess as CollapseIcon,
  Replay as ResumeIcon, Cancel as CancelIcon, RestartAlt as RerunIcon,
  ArrowBack as BackIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import type { DataFlowRun } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const STATUS_COLOR: Record<string, any> = {
  pending: 'default', running: 'info', succeeded: 'success',
  failed: 'error', cancelled: 'warning', partial: 'warning',
  not_started: 'default', skipped: 'default',
};

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 19).replace('T', ' ') : '—';
const fmtDur = (s?: number | null) => s == null ? '—' : `${s.toFixed(2)}s`;

function StageRow({ stage, onRerun }: { stage: any; onRerun: (alias: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <TableRow hover>
        <TableCell>{stage.seq}</TableCell>
        <TableCell>{stage.stage_alias}</TableCell>
        <TableCell><Chip label={stage.stage_type} size="small" variant="outlined" sx={{ fontSize: 10 }} /></TableCell>
        <TableCell>
          <Chip label={stage.status} size="small" color={STATUS_COLOR[stage.status] || 'default'}
                 variant="outlined" sx={{ fontSize: 10 }} />
        </TableCell>
        <TableCell sx={{ fontSize: 12 }}>{stage.attempts}</TableCell>
        <TableCell sx={{ fontSize: 12 }}>{fmtDur(stage.duration_seconds)}</TableCell>
        <TableCell sx={{ fontSize: 12 }}>{fmtDt(stage.started_at)}</TableCell>
        <TableCell align="right">
          <Tooltip title="Rerun this stage">
            <IconButton size="small" onClick={() => onRerun(stage.stage_alias)}
                         disabled={stage.status === 'running'}>
              <RerunIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <IconButton size="small" onClick={() => setOpen(o => !o)}>
            {open ? <CollapseIcon fontSize="small" /> : <ExpandIcon fontSize="small" />}
          </IconButton>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell colSpan={8} sx={{ pb: 0, pt: 0, borderBottom: open ? undefined : 'none' }}>
          <Collapse in={open}>
            <Box sx={{ p: 2, bgcolor: 'background.default' }}>
              {stage.error && (
                <Alert severity="error" sx={{ mb: 2 }}>{stage.error}</Alert>
              )}
              {/* BF-527 (2026-05-28): pre-execution stages have no outputs yet.
                  Previously the Outputs block silently disappeared, which made
                  the pipeline look broken to an operator inspecting a queued
                  run.  Now show a clear "no outputs yet" hint with the stage's
                  status so it's obvious the section exists but is empty by
                  design. */}
              {stage.outputs && Object.keys(stage.outputs).length > 0 ? (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>Outputs</Typography>
                  <Paper variant="outlined" sx={{ p: 1, fontFamily: 'monospace', fontSize: 12,
                                                    maxHeight: 220, overflow: 'auto' }}>
                    <pre style={{ margin: 0 }}>{JSON.stringify(stage.outputs, null, 2)}</pre>
                  </Paper>
                </Box>
              ) : (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>Outputs</Typography>
                  <Paper variant="outlined" sx={{ p: 1, fontSize: 12, color: 'text.secondary' }}>
                    {stage.status === 'not_started' || stage.status === 'pending'
                      ? `Pending — stage has not started yet (status: ${stage.status}).`
                      : stage.status === 'running'
                      ? 'Running — outputs will appear when the stage completes.'
                      : stage.status === 'skipped'
                      ? 'Skipped — branch policy excluded this stage from execution.'
                      : `No outputs recorded for this stage (status: ${stage.status}).`}
                  </Paper>
                </Box>
              )}
              {stage.log_lines && stage.log_lines.length > 0 && (
                <Box>
                  <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>Logs</Typography>
                  <Paper variant="outlined" sx={{ p: 1, fontFamily: 'monospace', fontSize: 12,
                                                    maxHeight: 220, overflow: 'auto' }}>
                    {stage.log_lines.map((l: string, i: number) =>
                      <div key={i}>{l}</div>)}
                  </Paper>
                </Box>
              )}
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
}

export default function DataFlowRunDetailPage() {
  const nav = useNavigate();
  const { id } = useParams<{ id: string }>();
  const ws = useWebSocket();

  const [run, setRun] = useState<DataFlowRun | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true); setError(null);
    try {
      const r = await api.dataflows.getRun(Number(id));
      setRun(r);
    } catch (e: any) {
      setError(e?.message || 'Failed to load run');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!ws?.addListener || !id) return;
    const handler = (msg: any) => {
      if (!msg) return;
      if (msg.run_id !== Number(id)) return;
      if (msg.event === 'workflow_stage_started' ||
          msg.event === 'workflow_stage_completed' ||
          msg.event === 'workflow_run_completed' ||
          msg.event === 'workflow_run_cancelled') {
        load();
      }
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, id, load]);

  const onCancel = async () => {
    if (!run) return;
    if (!window.confirm(`Cancel run #${run.id}?`)) return;
    try { await api.dataflows.cancelRun(run.id); await load(); }
    catch (e: any) { setError(e?.message || 'Cancel failed'); }
  };
  const onResume = async () => {
    if (!run) return;
    try { await api.dataflows.resumeRun(run.id); await load(); }
    catch (e: any) { setError(e?.message || 'Resume failed'); }
  };
  const onRerun = async (alias: string) => {
    if (!run) return;
    if (!window.confirm(`Rerun stage "${alias}"?`)) return;
    try {
      try {
        await api.dataflows.rerunStage(run.id, alias, false);
      } catch (e: any) {
        if ((e?.message || '').includes('unsafe')) {
          if (window.confirm('This stage is marked unsafe to rerun (may double-send notifications, etc.). Force rerun anyway?')) {
            await api.dataflows.rerunStage(run.id, alias, true);
          } else { return; }
        } else { throw e; }
      }
      await load();
    } catch (e: any) { setError(e?.message || 'Rerun failed'); }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <IconButton onClick={() => nav('/dataflows/runs')}><BackIcon /></IconButton>
        <Typography variant="h5">Run #{id}</Typography>
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<RefreshIcon />} onClick={load}>Refresh</Button>
        {run && run.status === 'running' && (
          <Button startIcon={<CancelIcon />} color="warning" onClick={onCancel}>Cancel</Button>
        )}
        {run && (run.status === 'failed' || run.status === 'partial' || run.status === 'cancelled') && (
          <Button startIcon={<ResumeIcon />} variant="contained" onClick={onResume}>Resume</Button>
        )}
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {loading && <CircularProgress size={20} />}
      {run && (
        <>
          <Paper sx={{ p: 2, mb: 2 }}>
            <Stack direction="row" spacing={3} flexWrap="wrap">
              <Box>
                <Typography variant="caption" color="text.secondary">DataFlow</Typography>
                <Typography>{run.dataflow_name} (v{run.dataflow_version})</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Status</Typography>
                <Box>
                  <Chip label={run.status} size="small" color={STATUS_COLOR[run.status] || 'default'}
                         variant="outlined" sx={{ fontSize: 10 }} />
                  {run.sla_breached && (
                    <Chip label="SLA breached" size="small" color="error"
                           sx={{ fontSize: 10, ml: 0.5 }} />
                  )}
                </Box>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Triggered by</Typography>
                <Typography>{run.triggered_by || '—'}</Typography>
                {run.run_as && run.run_as !== run.triggered_by && (
                  <Typography variant="caption" color="text.secondary">
                    (as {run.run_as})
                  </Typography>
                )}
              </Box>
              {run.expected_completion_at && (
                <Box>
                  <Typography variant="caption" color="text.secondary">SLA deadline</Typography>
                  <Typography>{fmtDt(run.expected_completion_at)}</Typography>
                </Box>
              )}
              <Box>
                <Typography variant="caption" color="text.secondary">Started</Typography>
                <Typography>{fmtDt(run.started_at)}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Duration</Typography>
                <Typography>{fmtDur(run.duration_seconds)}</Typography>
              </Box>
            </Stack>
            {run.error && (
              <Alert severity="error" sx={{ mt: 2 }}>{run.error}</Alert>
            )}
          </Paper>

          <TableContainer component={Paper}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>#</TableCell>
                  <TableCell>Alias</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Attempts</TableCell>
                  <TableCell>Duration</TableCell>
                  <TableCell>Started</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(run.stages || []).map(s => (
                  <StageRow key={s.id} stage={s} onRerun={onRerun} />
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <LiveLogTail runId={Number(id)} />
          <Annotations runId={Number(id)} />
        </>
      )}
    </Box>
  );
}

// ── Phase 132.26 — Live log tail (WS workflow_stage_log events) ──────────
function LiveLogTail({ runId }: { runId: number }) {
  const ws = useWebSocket();
  const [lines, setLines] = useState<Array<{ at: string; stage_alias: string; line: string }>>([]);
  const [paused, setPaused] = useState(false);
  const MAX_LINES = 500;

  useEffect(() => {
    if (!ws?.addListener) return;
    const handler = (msg: any) => {
      if (!msg || msg.event !== 'workflow_stage_log') return;
      if (msg.run_id !== runId) return;
      if (paused) return;
      setLines(prev => {
        const next = prev.concat([{
          at: msg.at, stage_alias: msg.stage_alias, line: msg.line,
        }]);
        return next.length > MAX_LINES ? next.slice(-MAX_LINES) : next;
      });
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, runId, paused]);

  return (
    <Paper sx={{ p: 2, mt: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <Typography variant="subtitle1">Live log tail</Typography>
        <Chip label={`${lines.length}${lines.length >= MAX_LINES ? ' (capped)' : ''}`}
              size="small" variant="outlined" sx={{ fontSize: 10 }} />
        <Box sx={{ flex: 1 }} />
        <Button size="small" onClick={() => setPaused(p => !p)}>
          {paused ? 'Resume' : 'Pause'}
        </Button>
        <Button size="small" onClick={() => setLines([])}>Clear</Button>
      </Stack>
      <Box sx={{ p: 1, maxHeight: 280, overflow: 'auto',
                  fontFamily: 'monospace', fontSize: 11,
                  background: '#1e1e1e', color: '#e0e0e0', borderRadius: 1 }}>
        {lines.length === 0 && (
          <Typography variant="caption" sx={{ color: '#888' }}>
            Waiting for log lines… (live-tail starts as soon as stages emit ctx.log())
          </Typography>
        )}
        {lines.map((l, i) => (
          <Box key={i} sx={{ whiteSpace: 'pre-wrap' }}>
            <span style={{ color: '#888' }}>
              {(l.at || '').slice(11, 19)}
            </span>{' '}
            <span style={{ color: '#7ec699' }}>[{l.stage_alias}]</span>{' '}
            {l.line}
          </Box>
        ))}
      </Box>
    </Paper>
  );
}

// ── Phase 132.23 — Run annotations panel ─────────────────────────────────
function Annotations({ runId }: { runId: number }) {
  const [items, setItems] = useState<any[]>([]);
  const [note, setNote] = useState('');
  const [severity, setSeverity] = useState<'info' | 'warning' | 'resolution'>('info');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api.dataflows.listRunAnnotations(runId);
      setItems(toArray(r));
    } catch (e: any) { setErr(e?.message || 'Failed to load annotations'); }
  }, [runId]);
  useEffect(() => { if (runId) load(); }, [runId, load]);

  const onAdd = async () => {
    if (!note.trim()) return;
    setBusy(true); setErr(null);
    try {
      await api.dataflows.addRunAnnotation(runId, { note: note.trim(), severity });
      setNote('');
      await load();
    } catch (e: any) { setErr(e?.message || 'Add failed'); }
    finally { setBusy(false); }
  };

  const sevColor: Record<string, any> = {
    info: 'default', warning: 'warning', resolution: 'success',
  };

  return (
    <Paper sx={{ p: 2, mt: 2 }}>
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Annotations / post-mortem</Typography>
      {err && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setErr(null)}>{err}</Alert>}
      <Stack direction="row" spacing={1} sx={{ mb: 2 }} alignItems="flex-start">
        <TextField fullWidth multiline minRows={2} placeholder="Add a note (what you found, what you did, what to watch for next time)…"
          value={note} onChange={e => setNote(e.target.value)} />
        <Select size="small" value={severity} onChange={e => setSeverity(e.target.value as any)}
          sx={{ minWidth: 140 }}>
          <MenuItem value="info">info</MenuItem>
          <MenuItem value="warning">warning</MenuItem>
          <MenuItem value="resolution">resolution</MenuItem>
        </Select>
        <Button variant="contained" onClick={onAdd} disabled={!note.trim() || busy}>Add</Button>
      </Stack>
      {items.length === 0 && (
        <Typography variant="caption" color="text.secondary">No annotations yet.</Typography>
      )}
      <Stack spacing={1}>
        {items.map(a => (
          <Box key={a.id} sx={{ borderLeft: '3px solid #ccc', pl: 1.5, py: 0.5 }}>
            <Stack direction="row" spacing={1} alignItems="center">
              <Chip label={a.severity} size="small" color={sevColor[a.severity] || 'default'}
                variant="outlined" sx={{ fontSize: 10 }} />
              <Typography variant="caption" color="text.secondary">
                {a.created_by || 'anon'} · {(a.created_at || '').slice(0, 19).replace('T', ' ')}
              </Typography>
            </Stack>
            <Typography variant="body2" sx={{ mt: 0.5, whiteSpace: 'pre-wrap' }}>{a.note}</Typography>
          </Box>
        ))}
      </Stack>
    </Paper>
  );
}
