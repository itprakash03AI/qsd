/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowSchedulesPage — list / create / delete dataflow schedules.
 * Supports either cron_expression OR calendar_rule (SOD / WD-N / month-end / intraday).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControlLabel, IconButton, MenuItem,
  Paper, Select, Stack, Switch, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  PlayArrow as TickIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { DataFlowDef, DataFlowSchedule } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 16).replace('T', ' ') : '—';

// Phase 132.22 — schedule preview pane inside the create dialog
function SchedulePreview({ form }: { form: any }) {
  const [fires, setFires] = useState<string[]>([]);
  const [previewErr, setPreviewErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const refresh = async () => {
    setLoading(true); setPreviewErr(null);
    try {
      const body: any = {
        timezone: form.timezone || 'UTC',
        count: 10,
      };
      if (form.mode === 'cron') body.cron_expression = form.cron_expression;
      else body.calendar_rule = form.calendar_rule;
      const r: any = await api.dataflows.previewSchedule(body);
      setFires(toArray<string>(r, 'fires'));
      if (r.errors?.length) setPreviewErr(r.errors[0]);
    } catch (e: any) {
      setPreviewErr(e?.message || 'Preview failed');
      setFires([]);
    } finally { setLoading(false); }
  };

  // Auto-refresh when cron or calendar_rule changes
  useEffect(() => {
    if (form.mode === 'cron' ? !form.cron_expression : !form.calendar_rule) return;
    refresh();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.mode, form.cron_expression, form.calendar_rule, form.timezone]);

  return (
    <Box sx={{ border: '1px solid #eee', borderRadius: 1, p: 1.5, background: '#fafafa' }}>
      <Stack direction="row" alignItems="center" spacing={1}>
        <Typography variant="caption" color="text.secondary">Preview — next 10 fires:</Typography>
        <Button size="small" onClick={refresh}>Refresh</Button>
        {loading && <CircularProgress size={14} />}
      </Stack>
      {previewErr && <Alert severity="warning" sx={{ mt: 1, fontSize: 12 }}>{previewErr}</Alert>}
      {!previewErr && fires.length === 0 && (
        <Typography variant="caption" color="text.secondary">— (set cron / calendar_rule above to preview)</Typography>
      )}
      {fires.length > 0 && (
        <Stack spacing={0.25} sx={{ mt: 1 }}>
          {fires.map((f, i) => (
            <Typography key={i} variant="caption" sx={{ fontFamily: 'monospace', fontSize: 11 }}>
              {i + 1}. {f.slice(0, 19).replace('T', ' ')}
            </Typography>
          ))}
        </Stack>
      )}
    </Box>
  );
}

export default function DataFlowSchedulesPage() {
  const [schedules, setSchedules] = useState<DataFlowSchedule[]>([]);
  const [dataflows, setWorkflows] = useState<DataFlowDef[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const [form, setForm] = useState<any>({
    dataflow_id: '',
    name: '',
    mode: 'cron',
    cron_expression: '0 9 * * 1-5',
    calendar_rule: { type: 'daily', calendar: '', hour: 9, minute: 0,
                       skip_non_business_days: true },
    timezone: 'UTC',
    is_active: true,
  });

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [s, w] = await Promise.all([
        api.dataflows.listSchedules(),
        api.dataflows.listDataFlows({ status: 'active' }),
      ]);
      setSchedules(toArray<DataFlowSchedule>(s));
      setWorkflows(toArray<DataFlowDef>(w));
    } catch (e: any) {
      setError(e?.message || 'Failed to load schedules');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const onCreate = async () => {
    try {
      const body: any = {
        dataflow_id: Number(form.dataflow_id),
        name: form.name,
        timezone: form.timezone,
        is_active: form.is_active,
      };
      if (form.mode === 'cron') {
        body.cron_expression = form.cron_expression;
      } else {
        body.calendar_rule = form.calendar_rule;
      }
      await api.dataflows.createSchedule(body);
      setDialogOpen(false);
      setForm({ ...form, name: '', dataflow_id: '' });
      await load();
    } catch (e: any) {
      setError(e?.message || 'Create schedule failed');
    }
  };

  const onDelete = async (id: number) => {
    if (!window.confirm('Delete this schedule?')) return;
    try { await api.dataflows.deleteSchedule(id); await load(); }
    catch (e: any) { setError(e?.message || 'Delete failed'); }
  };

  const onTick = async () => {
    try {
      const r = await api.dataflows.schedulerTickDebug();
      alert(`Scheduler fired ${r.fired} schedule(s)`);
      await load();
    } catch (e: any) { setError(e?.message || 'Tick failed'); }
  };

  const ruleLabel = (s: DataFlowSchedule) => {
    if (s.cron_expression) return `cron: ${s.cron_expression}`;
    if (s.calendar_rule) {
      const r: any = s.calendar_rule;
      return `calendar: ${r.type} ${r.calendar || ''} ${r.hour ?? ''}:${(r.minute ?? 0).toString().padStart(2, '0')}`;
    }
    return '—';
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">DataFlow Schedules</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<TickIcon />} onClick={onTick}>Run Tick</Button>
          <Button startIcon={<AddIcon />} variant="contained"
                   onClick={() => setDialogOpen(true)}>New Schedule</Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>DataFlow</TableCell>
              <TableCell>Rule</TableCell>
              <TableCell>Timezone</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Last run</TableCell>
              <TableCell>Next run</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={8} align="center">
                <CircularProgress size={20} />
              </TableCell></TableRow>
            )}
            {!loading && schedules.length === 0 && (
              <TableRow><TableCell colSpan={8} align="center">
                <Typography variant="body2" color="text.secondary">No schedules.</Typography>
              </TableCell></TableRow>
            )}
            {schedules.map(s => {
              const wf = dataflows.find(w => w.id === s.dataflow_id);
              return (
                <TableRow key={s.id} hover>
                  <TableCell>{s.name}</TableCell>
                  <TableCell>{wf?.name || `#${s.dataflow_id}`}</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{ruleLabel(s)}</TableCell>
                  <TableCell>{s.timezone}</TableCell>
                  <TableCell>
                    <Chip label={s.is_active ? 'on' : 'off'} size="small"
                           color={s.is_active ? 'success' : 'default'}
                           variant="outlined" sx={{ fontSize: 10 }} />
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{fmtDt(s.last_run_at)}</TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{fmtDt(s.next_run_at)}</TableCell>
                  <TableCell align="right">
                    <IconButton size="small" color="error" onClick={() => onDelete(s.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Create dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>New DataFlow Schedule</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Select value={form.dataflow_id} fullWidth displayEmpty
                     onChange={e => setForm({ ...form, dataflow_id: e.target.value })}>
              <MenuItem value="" disabled>Select active dataflow…</MenuItem>
              {dataflows.map(w => (
                <MenuItem key={w.id} value={w.id}>{w.name} (v{w.version})</MenuItem>
              ))}
            </Select>
            <TextField fullWidth label="Schedule name" value={form.name}
                        onChange={e => setForm({ ...form, name: e.target.value })} />
            <Select fullWidth value={form.mode}
                     onChange={e => setForm({ ...form, mode: e.target.value })}>
              <MenuItem value="cron">Cron expression</MenuItem>
              <MenuItem value="calendar">Calendar rule (Daily Batch / Workday-N / Month-End / Intraday)</MenuItem>
            </Select>
            {form.mode === 'cron' && (
              <TextField fullWidth label="Cron (5 fields)" value={form.cron_expression}
                          onChange={e => setForm({ ...form, cron_expression: e.target.value })}
                          helperText='e.g. "0 9 * * 1-5" weekdays 09:00' />
            )}
            {form.mode === 'calendar' && (
              <Stack spacing={1}>
                <Select fullWidth value={form.calendar_rule.type}
                         onChange={e => setForm({
                           ...form,
                           calendar_rule: { ...form.calendar_rule, type: e.target.value },
                         })}>
                  <MenuItem value="daily">Daily Batch — Plain</MenuItem>
                  <MenuItem value="sod">Daily Batch — Morning</MenuItem>
                  <MenuItem value="eod">Daily Batch — Evening</MenuItem>
                  <MenuItem value="workday_n">Workday-N Batch</MenuItem>
                  <MenuItem value="month_end">Month-End Batch</MenuItem>
                  <MenuItem value="last_n_business_days_of_month">Last-N Business Days</MenuItem>
                  <MenuItem value="intraday">Intraday Batch (sub-cron)</MenuItem>
                </Select>
                <Stack direction="row" spacing={1}>
                  <TextField label="Calendar name" value={form.calendar_rule.calendar || ''}
                              onChange={e => setForm({
                                ...form,
                                calendar_rule: { ...form.calendar_rule, calendar: e.target.value },
                              })} sx={{ flex: 1 }} />
                  <TextField label="Hour" type="number" value={form.calendar_rule.hour ?? 9}
                              onChange={e => setForm({
                                ...form,
                                calendar_rule: { ...form.calendar_rule, hour: Number(e.target.value) },
                              })} sx={{ width: 90 }} />
                  <TextField label="Minute" type="number" value={form.calendar_rule.minute ?? 0}
                              onChange={e => setForm({
                                ...form,
                                calendar_rule: { ...form.calendar_rule, minute: Number(e.target.value) },
                              })} sx={{ width: 90 }} />
                </Stack>
                {(form.calendar_rule.type === 'workday_n' ||
                   form.calendar_rule.type === 'last_n_business_days_of_month') && (
                  <TextField label="N" type="number" value={form.calendar_rule.n || 1}
                              onChange={e => setForm({
                                ...form,
                                calendar_rule: { ...form.calendar_rule, n: Number(e.target.value) },
                              })} />
                )}
                {form.calendar_rule.type === 'intraday' && (
                  <TextField label="Sub-cron (5 fields)"
                              value={form.calendar_rule.minute_cron || '*/15 * * * *'}
                              onChange={e => setForm({
                                ...form,
                                calendar_rule: { ...form.calendar_rule, minute_cron: e.target.value },
                              })} />
                )}
              </Stack>
            )}
            <TextField fullWidth label="Timezone" value={form.timezone}
                        onChange={e => setForm({ ...form, timezone: e.target.value })} />
            <FormControlLabel
              control={<Switch checked={form.is_active}
                                onChange={e => setForm({ ...form, is_active: e.target.checked })} />}
              label="Active"
            />
            <SchedulePreview form={form} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained"
                   disabled={!form.dataflow_id || !form.name}
                   onClick={onCreate}>Create</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
