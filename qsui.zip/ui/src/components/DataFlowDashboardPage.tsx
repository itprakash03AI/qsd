/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowDashboardPage — at-a-glance overview of the DataFlow engine.
 *
 * Layout:
 *   • Top row of stat cards (active dataflows, running, today, pending
 *     approvals, active schedules).
 *   • Quick actions strip (start a run, create from template, view all
 *     runs, manage schedules).
 *   • Three columns of live tables:
 *       - Recent runs (last 20, WS-driven)
 *       - Pending approvals
 *       - Upcoming schedules (next 5 fires)
 *
 * Lazy-loaded.  Subscribes to workflow_* WS events for live refresh.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Box, Button, Card, CardContent, Chip, CircularProgress, Dialog,
  DialogActions, DialogContent, DialogTitle, Grid, IconButton, Paper,
  Stack, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  PlayArrow as RunIcon, AddCircle as TemplateIcon,
  EventNote as SchedulesIcon, History as RunsIcon,
  CheckCircle as ApproveIcon, Refresh as RefreshIcon,
  OpenInNew as OpenIcon, ErrorOutline as ErrorIcon,
  CheckCircleOutline as OkIcon, AccessTime as PendingIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import { toArray } from '../utils/toArray';
import type {
  DataFlowDef, DataFlowRun, DataFlowSchedule, ApprovalRequest,
  DynamicDataflowRow,
} from '../services/api/dataflows';
import { collectDataflowDynamicRows } from '../services/api/dataflows';
import {
  inspectDynamicRows, fireDataflowRun,
} from './dataflow/launchWithOverrides';
import DataflowOverrideDialog from './dataflow/DataflowOverrideDialog';

const RUN_STATUS_COLOR: Record<string, any> = {
  pending: 'default', running: 'info', succeeded: 'success',
  failed: 'error', cancelled: 'warning', partial: 'warning',
};
const APPROVAL_STATUS_COLOR: Record<string, any> = {
  pending: 'warning', approved: 'success', rejected: 'error', expired: 'default',
};

const fmtDt  = (iso?: string | null) => iso ? iso.slice(0, 16).replace('T', ' ') : '—';
const fmtDur = (s?: number | null) => s == null ? '—' : `${s.toFixed(1)}s`;

// ── Stat card ─────────────────────────────────────────────────────────────

function StatCard({ label, value, color, icon, onClick }: {
  label: string;
  value: number | string;
  color?: 'primary' | 'success' | 'warning' | 'error' | 'info';
  icon?: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <Card variant="outlined" sx={{
      cursor: onClick ? 'pointer' : 'default',
      transition: 'box-shadow 0.15s',
      '&:hover': onClick ? { boxShadow: 2 } : {},
    }} onClick={onClick}>
      <CardContent sx={{ pb: '16px !important' }}>
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="caption" color="text.secondary"
                         sx={{ textTransform: 'uppercase', fontSize: 11, letterSpacing: 0.5 }}>
              {label}
            </Typography>
            <Typography variant="h4" sx={{
              fontWeight: 600, color: color ? `${color}.main` : 'text.primary',
              mt: 0.5,
            }}>{value}</Typography>
          </Box>
          {icon && (
            <Box sx={{
              color: color ? `${color}.main` : 'text.secondary',
              opacity: 0.7,
            }}>{icon}</Box>
          )}
        </Stack>
      </CardContent>
    </Card>
  );
}

// ── Main dashboard ────────────────────────────────────────────────────────

export default function DataFlowDashboardPage() {
  const nav = useNavigate();
  const ws = useWebSocket();

  const [dataflows, setWorkflows] = useState<DataFlowDef[]>([]);
  const [runs, setRuns] = useState<DataFlowRun[]>([]);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>([]);
  const [schedules, setSchedules] = useState<DataFlowSchedule[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [wfs, runRows, apprs, scheds] = await Promise.all([
        api.dataflows.listDataFlows({ status: 'active' }),
        api.dataflows.listRuns({ limit: 20 }),
        api.dataflows.listApprovals({ status: 'pending', limit: 10 }),
        api.dataflows.listSchedules({ is_active: true }),
      ]);
      setWorkflows(toArray<DataFlowDef>(wfs));
      setRuns(toArray<DataFlowRun>(runRows));
      setApprovals(toArray<ApprovalRequest>(apprs));
      setSchedules(toArray<DataFlowSchedule>(scheds));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Live refresh via WS — any workflow_* event triggers a re-fetch.
  useEffect(() => {
    if (!ws?.addListener) return;
    const handler = (msg: any) => {
      if (!msg || typeof msg.event !== 'string') return;
      if (msg.event.startsWith('workflow_')) load();
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, load]);

  // ── Derived stats ─────────────────────────────────────────────────────

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return {
      activeWorkflows: dataflows.length,
      running:         runs.filter(r => r.status === 'running').length,
      today:           runs.filter(r => (r.started_at || '').startsWith(today)).length,
      pendingApprovals: approvals.length,
      activeSchedules: schedules.length,
      failedToday:     runs.filter(r =>
        r.status === 'failed' && (r.ended_at || '').startsWith(today),
      ).length,
    };
  }, [dataflows, runs, approvals, schedules]);

  // Upcoming fires (sort by next_run_at)
  const upcoming = useMemo(() => {
    return [...schedules]
      .filter(s => s.next_run_at)
      .sort((a, b) => String(a.next_run_at).localeCompare(String(b.next_run_at)))
      .slice(0, 5);
  }, [schedules]);

  // ── Quick "start a run" via the first active dataflow ─────────────────

  // Phase 132.38 deep-dive — quick-launch override dialog state.
  const [launchPending, setLaunchPending] = useState<{
    name: string; rows: DynamicDataflowRow[];
  } | null>(null);
  const [launchOverrides, setLaunchOverrides] = useState<Record<string, any>>({});

  const _launch = async (name: string) => {
    const dyn = await inspectDynamicRows(name);
    if (dyn.length > 0) {
      const seed: Record<string, any> = {};
      for (const r of dyn) {
        if (r.value !== null && r.value !== undefined && r.value !== '') {
          seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
        }
      }
      setLaunchOverrides(seed);
      setLaunchPending({ name, rows: dyn });
      return;
    }
    try {
      const run = await fireDataflowRun(name);
      nav(`/dataflows/runs/${run.id}`);
    } catch (e: any) { alert(e?.message || 'Start failed'); }
  };

  const onQuickStart = async () => {
    if (dataflows.length === 0) {
      nav('/dataflows/list');
      return;
    }
    if (dataflows.length === 1) {
      await _launch(dataflows[0].name);
      return;
    }
    nav('/dataflows/list');
  };

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 3 }}>
        <Box>
          <Typography variant="h5">DataFlow Dashboard</Typography>
          <Typography variant="caption" color="text.secondary">
            Live view of the dataflow engine — auto-refreshes on stage events.
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<RunIcon />} variant="contained"
                   onClick={onQuickStart}>Start a Run</Button>
          <Button startIcon={<TemplateIcon />} onClick={() => nav('/dataflows/list')}>
            Manage DataFlows
          </Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>

      {/* Stat cards */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 2 }}>
          <StatCard label="Active DataFlows" value={stats.activeWorkflows}
                     color="primary" icon={<OkIcon fontSize="large" />}
                     onClick={() => nav('/dataflows/list')} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 2 }}>
          <StatCard label="Running" value={stats.running}
                     color="info" icon={<PendingIcon fontSize="large" />}
                     onClick={() => nav('/dataflows/runs')} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 2 }}>
          <StatCard label="Today's Runs" value={stats.today}
                     color="primary" icon={<RunsIcon fontSize="large" />}
                     onClick={() => nav('/dataflows/runs')} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 2 }}>
          <StatCard label="Failed Today" value={stats.failedToday}
                     color={stats.failedToday > 0 ? 'error' : 'success'}
                     icon={<ErrorIcon fontSize="large" />}
                     onClick={() => nav('/dataflows/runs?status=failed')} />
        </Grid>
        {/* Approvals card only appears when at least one approval is
            pending — keeps the dashboard clean for the common case where
            a workflow doesn't use the human_approval stage. */}
        {stats.pendingApprovals > 0 && (
          <Grid size={{ xs: 12, sm: 6, md: 2 }}>
            <StatCard label="Pending Approvals" value={stats.pendingApprovals}
                       color="warning"
                       icon={<ApproveIcon fontSize="large" />}
                       onClick={() => nav('/dataflows/approvals')} />
          </Grid>
        )}
        <Grid size={{ xs: 12, sm: 6, md: 2 }}>
          <StatCard label="Active Schedules" value={stats.activeSchedules}
                     color="info" icon={<SchedulesIcon fontSize="large" />}
                     onClick={() => nav('/dataflows/schedules')} />
        </Grid>
      </Grid>

      {loading && <Box sx={{ mb: 2 }}><CircularProgress size={20} /></Box>}

      {/* Three-column live panels */}
      <Grid container spacing={2}>

        {/* Recent runs */}
        <Grid size={{ xs: 12, md: 7 }}>
          <Paper variant="outlined">
            <Stack direction="row" justifyContent="space-between" alignItems="center"
                    sx={{ px: 2, py: 1, borderBottom: 1, borderColor: 'divider' }}>
              <Typography variant="subtitle2">Recent Runs</Typography>
              <Button size="small" onClick={() => nav('/dataflows/runs')}>View all</Button>
            </Stack>
            <TableContainer sx={{ maxHeight: 480 }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell>Run</TableCell>
                    <TableCell>DataFlow</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Triggered by</TableCell>
                    <TableCell>Started</TableCell>
                    <TableCell>Duration</TableCell>
                    <TableCell align="right">Open</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {runs.length === 0 && (
                    <TableRow><TableCell colSpan={7} align="center">
                      <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                        No runs yet.
                      </Typography>
                    </TableCell></TableRow>
                  )}
                  {runs.map(r => (
                    <TableRow key={r.id} hover>
                      <TableCell>#{r.id}</TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          {r.dataflow_name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          v{r.dataflow_version}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip label={r.status} size="small"
                               color={RUN_STATUS_COLOR[r.status] || 'default'}
                               variant="outlined" sx={{ fontSize: 10 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>{r.triggered_by || '—'}</TableCell>
                      <TableCell sx={{ fontSize: 12 }}>{fmtDt(r.started_at)}</TableCell>
                      <TableCell sx={{ fontSize: 12 }}>{fmtDur(r.duration_seconds)}</TableCell>
                      <TableCell align="right">
                        <IconButton size="small" onClick={() => nav(`/dataflows/runs/${r.id}`)}>
                          <OpenIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        {/* Side column — approvals + upcoming */}
        <Grid size={{ xs: 12, md: 5 }}>
          <Stack spacing={2}>

            {/* Pending approvals — only rendered when at least one is
                pending; otherwise the dashboard collapses cleanly. */}
            {approvals.length > 0 && (
            <Paper variant="outlined">
              <Stack direction="row" justifyContent="space-between" alignItems="center"
                      sx={{ px: 2, py: 1, borderBottom: 1, borderColor: 'divider' }}>
                <Typography variant="subtitle2">Pending Approvals</Typography>
                <Button size="small" onClick={() => nav('/dataflows/approvals')}>View all</Button>
              </Stack>
              <Box sx={{ maxHeight: 220, overflow: 'auto' }}>
                {approvals.map(a => (
                  <Box key={a.id} sx={{
                    px: 2, py: 1.2, borderBottom: 1, borderColor: 'divider',
                    cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' },
                  }} onClick={() => nav('/dataflows/approvals')}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          {a.title || `Approval #${a.id}`}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {a.dataflow_name} · run #{a.run_id} · requested by {a.requested_by || '—'}
                        </Typography>
                      </Box>
                      <Chip label={a.status} size="small"
                             color={APPROVAL_STATUS_COLOR[a.status] || 'default'}
                             variant="outlined" sx={{ fontSize: 10 }} />
                    </Stack>
                  </Box>
                ))}
              </Box>
            </Paper>
            )}

            {/* Upcoming schedules */}
            <Paper variant="outlined">
              <Stack direction="row" justifyContent="space-between" alignItems="center"
                      sx={{ px: 2, py: 1, borderBottom: 1, borderColor: 'divider' }}>
                <Typography variant="subtitle2">Upcoming Schedules</Typography>
                <Button size="small" onClick={() => nav('/dataflows/schedules')}>Manage</Button>
              </Stack>
              <Box sx={{ maxHeight: 220, overflow: 'auto' }}>
                {upcoming.length === 0 && (
                  <Typography variant="body2" color="text.secondary"
                                sx={{ p: 2, textAlign: 'center' }}>
                    No active schedules.
                  </Typography>
                )}
                {upcoming.map(s => {
                  const wf = dataflows.find(w => w.id === s.dataflow_id);
                  const rule = s.cron_expression
                    ? `cron: ${s.cron_expression}`
                    : (s.calendar_rule?.type || 'calendar');
                  return (
                    <Box key={s.id} sx={{
                      px: 2, py: 1.2, borderBottom: 1, borderColor: 'divider',
                    }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {s.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {wf?.name || `dataflow #${s.dataflow_id}`} · {rule}
                          </Typography>
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          <Typography variant="caption" color="text.secondary"
                                       sx={{ display: 'block' }}>
                            next
                          </Typography>
                          <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                            {fmtDt(s.next_run_at)}
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                  );
                })}
              </Box>
            </Paper>

          </Stack>
        </Grid>
      </Grid>

      {/* Quick-launch override dialog (Phase 132.38 deep-dive) */}
      <DataflowOverrideDialog
        dataflowName={launchPending?.name || null}
        rows={launchPending?.rows || []}
        values={launchOverrides}
        onValuesChange={setLaunchOverrides}
        onCancel={() => setLaunchPending(null)}
        onConfirm={async () => {
          const cur = launchPending!;
          setLaunchPending(null);
          try {
            const run = await fireDataflowRun(cur.name, launchOverrides);
            nav(`/dataflows/runs/${run.id}`);
          } catch (e: any) { alert(e?.message || 'Start failed'); }
        }}
        connectionIdByRow={(r) => r.connectionId ?? null}
        tableByRow={(r) => r.table ?? null}
      />
    </Box>
  );
}
