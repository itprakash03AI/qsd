import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, Accordion, AccordionSummary, AccordionDetails,
  Chip, Button, TextField, MenuItem, Select, FormControl, InputLabel,
  Table, TableHead, TableRow, TableCell, TableBody,
  Alert, Divider, Stack, Tooltip, IconButton, CircularProgress,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  ContentCopy as CopyIcon,
  PlayArrow as PlayIcon,
  Launch as LaunchIcon,
  CheckCircle as CheckIcon,
  Science as TestIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { API_BASE_URL, safeFetch } from '../services/api';
import { DynamicWhereOverrideField } from './common/DynamicWhereOverrideField';
import { WHERE_OPERATORS } from './common/WhereClausesEditor';

interface ParamDef {
  name: string;
  type: string;
  required: boolean;
  default: string;
  description: string;
}

interface PublishedView {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  is_active: boolean;
  allowed_filters: string[];
  default_limit: number;
  max_limit: number;
  cache_ttl_seconds: number;
  param_definitions?: ParamDef[];
  created_by: string | null;
  created_at: string | null;
  connection_id?: number | null;
  execution_connection_id?: number | null;
  query_config?: Record<string, any> | null;
}

// Mirrors backend ``core.where_clause_mapping.col_key``: lowercase,
// strip quotes/brackets, drop any qualifier prefix.  Used to match
// allowed_filters against the publisher's _where_clauses_mapping rows
// regardless of how the column was originally written.
const colKey = (c: string): string =>
  (c || '')
    .replace(/[`"\[\]]/g, '')
    .split('.')
    .pop()!
    .toLowerCase();

interface PublisherWhereHint {
  operator: string;
  defaultValue: any;
}

// Best-effort lookup of the publisher's Dynamic-row metadata for a
// given allowed_filters column.  Falls back to operator='eq' / no
// default when the PV has no _where_clauses_mapping (legacy / not all
// PVs carry it).
const getPublisherHint = (
  qc: Record<string, any> | null | undefined,
  column: string,
): PublisherWhereHint => {
  const mapping: any[] = Array.isArray(qc?._where_clauses_mapping)
    ? qc!._where_clauses_mapping
    : [];
  const target = colKey(column);
  for (const row of mapping) {
    if (!row || typeof row !== 'object') continue;
    if (colKey(row.column || '') !== target) continue;
    if ((row.mode || 'static') !== 'dynamic') continue;
    return {
      operator: (row.operator || 'eq').toLowerCase(),
      defaultValue: row.value,
    };
  }
  return { operator: 'eq', defaultValue: undefined };
};

// Pull a usable table hint out of the PV's frozen query_config so the
// distinct-values lookup has somewhere to aim.  Mirrors the chain
// PublishedViewsPage's test dialog uses (files[__registered__:…] →
// raw_sql FROM-clause regex).  Returns null when nothing usable.
const extractTableHint = (qc: Record<string, any> | null | undefined): string | null => {
  if (!qc) return null;
  const files: any[] = Array.isArray(qc.files) ? qc.files : [];
  for (const f of files) {
    const p = typeof f === 'string' ? f : (f?.path || '');
    if (typeof p !== 'string') continue;
    if (p.startsWith('__registered__:')) return p.slice(15);
    if (p.startsWith('__iceberg__:')) return p.slice(12);
  }
  const sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
    .filter((s: any) => typeof s === 'string' && s.trim())
    .join('\n');
  const m = sqlBlob.match(/\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i);
  if (m) return m[1].replace(/[\s"`\[\]]/g, '');
  return null;
};

interface ApiKey {
  id: number;
  name: string;
  key_prefix: string;
  scoped_view_ids: number[] | null;
  is_active: boolean;
}

const CODE_BG = '#1e1e1e';
const CODE_COLOR = '#d4d4d4';

const ApiExplorerPage = () => {
  const [views, setViews] = useState<PublishedView[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [selectedKeyId, setSelectedKeyId] = useState<number | 'custom'>('custom');
  const [customKey, setCustomKey] = useState('YOUR_API_KEY');
  const [expanded, setExpanded] = useState<number | false>(false);

  // Per-view test state
  const [testingView, setTestingView] = useState<number | null>(null);
  const [testParams, setTestParams] = useState<Record<string, string>>({});
  // Filter VALUE only (no leading "op:" prefix any more — the operator
  // lives in testOps so we can render a dedicated picker and let the
  // value field be a real Autocomplete).
  const [testFilters, setTestFilters] = useState<Record<string, string>>({});
  const [testOps, setTestOps] = useState<Record<string, string>>({});
  const [testFormat, setTestFormat] = useState('json');
  const [testLimit, setTestLimit] = useState('100');
  const [testResult, setTestResult] = useState<any>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [testError, setTestError] = useState('');
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.listPublishedViews(), api.listApiKeys()])
      .then(([v, k]) => {
        setViews(Array.isArray(v) ? v.filter((x: any) => x.is_active) : []);
        setApiKeys(Array.isArray(k) ? k.filter((x: any) => x.is_active) : []);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const displayKey =
    selectedKeyId === 'custom'
      ? customKey
      : `${apiKeys.find(k => k.id === selectedKeyId)?.key_prefix ?? 'qs'}...`;

  const buildQs = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    // Phase 132.36 — emit bare-form ?name=value where possible.  Only
    // fall back to bracketed ?param[name]=value / ?filter[name]=op:val
    // for reserved-name collisions.
    const RESERVED = new Set([
      'limit', 'offset', 'sort', 'columns', 'format', 'cache',
      'snapshot_id', 'as_of_timestamp', 'engine', 'filter',
    ]);
    const qp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (!v) return;
      const key = RESERVED.has(k) ? `param[${k}]` : k;
      qp.set(key, v);
    });
    Object.entries(filters).forEach(([k, v]) => {
      const op = (ops[k] || 'eq').toLowerCase();
      const opSpec = WHERE_OPERATORS.find(o => o.value === op);
      // is_null / is_not_null — emit op without value.
      if (opSpec && !opSpec.takesValue) {
        qp.set(`filter.${k}`, op);
        return;
      }
      if (!v || !v.trim()) return;
      // Default operator with simple scalar — bare form is friendlier
      // (?region=APAC).  Anything else routes via filter.col=op:val so
      // the backend's bare-form parser can't misread it.
      if (op === 'eq' && !RESERVED.has(k)) {
        qp.set(k, v.trim());
      } else {
        qp.set(`filter.${k}`, `${op}:${v.trim()}`);
      }
    });
    if (format !== 'json') qp.set('format', format);
    if (limit && limit !== String(view.default_limit)) qp.set('limit', limit);
    return qp.toString();
  };

  const buildUrl = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    const origin = API_BASE_URL || window.location.origin;
    const base = `${origin}/api/v1/views/${view.slug}/data`;
    const qs = buildQs(view, params, filters, ops, format, limit);
    return qs ? `${base}?${qs}` : base;
  };

  const buildCurl = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) =>
    `curl -H "X-API-Key: ${displayKey}" \\\n  "${buildUrl(view, params, filters, ops, format, limit)}"`;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 1500);
    });
  };

  const handleTest = async (view: PublishedView) => {
    setTestLoading(true);
    setTestError('');
    setTestResult(null);
    try {
      const qs = buildQs(view, testParams, testFilters, testOps, testFormat, testLimit);
      const path = `/api/v1/views/${view.slug}/data${qs ? `?${qs}` : ''}`;

      // If the user pasted a custom key, use it as X-API-Key (bypass session auth).
      // This lets them verify their key works end-to-end before sharing it.
      // Otherwise fall back to session auth via safeFetch.
      const hasCustomKey =
        selectedKeyId === 'custom' &&
        customKey &&
        customKey !== 'YOUR_API_KEY' &&
        customKey.trim().length > 8;

      if (hasCustomKey) {
        const fullUrl = `${API_BASE_URL}${path}`;
        const resp = await fetch(fullUrl, {
          method: 'GET',
          headers: {
            'Accept': testFormat === 'json' ? 'application/json' : '*/*',
            'X-API-Key': customKey.trim(),
          },
        });
        if (!resp.ok) {
          let detail = '';
          try { detail = (await resp.json()).detail ?? ''; } catch { detail = await resp.text(); }
          throw new Error(`HTTP ${resp.status} ${resp.statusText}${detail ? ' — ' + detail : ''}`);
        }
        if (testFormat === 'json') {
          setTestResult(await resp.json());
        } else {
          const blob = await resp.blob();
          setTestResult({
            _format: testFormat,
            _size_bytes: blob.size,
            _content_type: resp.headers.get('content-type'),
            _note: `${testFormat.toUpperCase()} blob received — download via curl or client SDK for full content.`,
          });
        }
      } else {
        const result = await safeFetch(path);
        setTestResult(result);
      }
    } catch (e: any) {
      setTestError(e.message || 'Request failed');
    } finally {
      setTestLoading(false);
    }
  };

  if (loading) return <Box p={4}><CircularProgress /></Box>;

  return (
    <Box p={3} maxWidth={1400}>
      {/* Header */}
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight={600}>API Explorer</Typography>
          <Typography variant="body2" color="text.secondary">
            Browse and test published data endpoints. All endpoints accept API key or AD session auth.
          </Typography>
        </Box>
        <Button
          variant="outlined"
          size="small"
          startIcon={<LaunchIcon />}
          onClick={() => window.open('/docs', '_blank')}
        >
          Full API Docs (Swagger)
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Auth guide */}
      <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
        <Typography variant="subtitle2" fontWeight={600} gutterBottom>Authentication</Typography>
        <Typography variant="body2" color="text.secondary" mb={1.5}>
          Paste an API key below to test requests <strong>as that key</strong> (verifies the key + scopes + rate limit work end-to-end).
          Get keys from the{' '}
          <a href="/api-keys" style={{ color: 'inherit', textDecoration: 'underline' }}>API Keys page</a>{' '}
          (use the eye icon to reveal an existing key).
          If left blank, the live tester falls back to your current AD/SSO session cookie.
        </Typography>

        <Box
          component="pre"
          sx={{
            bgcolor: CODE_BG, color: CODE_COLOR, px: 2, py: 1.5, borderRadius: 1,
            fontFamily: 'monospace', fontSize: '0.8rem', mb: 1.5, overflowX: 'auto', m: 0,
          }}
        >
          {`GET ${API_BASE_URL || window.location.origin}/api/v1/views/{slug}/data\nX-API-Key: qs_xxxxxxxxxxxxxxxx`}
        </Box>

        <Stack direction="row" spacing={2} alignItems="center" mt={1.5} flexWrap="wrap">
          <FormControl size="small" sx={{ minWidth: 220 }}>
            <InputLabel>API key for curl examples</InputLabel>
            <Select
              value={selectedKeyId}
              label="API key for curl examples"
              onChange={e => setSelectedKeyId(e.target.value as any)}
            >
              <MenuItem value="custom">Custom / paste key</MenuItem>
              {apiKeys.map(k => (
                <MenuItem key={k.id} value={k.id}>{k.name} ({k.key_prefix}…)</MenuItem>
              ))}
            </Select>
          </FormControl>
          {selectedKeyId === 'custom' && (
            <TextField
              size="small"
              label="API Key"
              value={customKey}
              onChange={e => setCustomKey(e.target.value)}
              sx={{ minWidth: 280 }}
              InputProps={{ style: { fontFamily: 'monospace' } }}
            />
          )}
        </Stack>
      </Paper>

      {/* Endpoints list */}
      {views.length === 0 ? (
        <Alert severity="info">
          No active published views.{' '}
          <a href="/published-views" style={{ color: 'inherit' }}>Create one</a> to expose data via the API.
        </Alert>
      ) : (
        <>
          <Typography variant="body2" color="text.secondary" mb={1}>
            {views.length} active endpoint{views.length !== 1 ? 's' : ''}
          </Typography>
          {views.map(view => {
            const defaultParams = Object.fromEntries(
              (view.param_definitions || []).map(p => [p.name, p.default || ''])
            );
            const isOpen = expanded === view.id;
            const isTesting = testingView === view.id;
            const exampleCurl = buildCurl(view, defaultParams, {}, {}, 'json', String(view.default_limit));

            return (
              <Accordion
                key={view.id}
                expanded={isOpen}
                onChange={(_, open) => setExpanded(open ? view.id : false)}
                variant="outlined"
                sx={{ mb: 1, '&:before': { display: 'none' } }}
              >
                <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ py: 0.5 }}>
                  <Stack direction="row" alignItems="center" spacing={1.5} flexWrap="wrap">
                    <Chip
                      label="GET"
                      size="small"
                      color="success"
                      sx={{ fontWeight: 700, fontFamily: 'monospace', minWidth: 44 }}
                    />
                    <Typography variant="body2" fontFamily="monospace" sx={{ wordBreak: 'break-all' }}>
                      /api/v1/views/<strong>{view.slug}</strong>/data
                    </Typography>
                    <Typography variant="body2" color="text.secondary">— {view.name}</Typography>
                    {(view.param_definitions?.length ?? 0) > 0 && (
                      <Chip label={`${view.param_definitions!.length} params`} size="small" variant="outlined" />
                    )}
                    {(view.allowed_filters?.length ?? 0) > 0 && (
                      <Chip label={`${view.allowed_filters!.length} filters`} size="small" variant="outlined" />
                    )}
                  </Stack>
                </AccordionSummary>

                <AccordionDetails sx={{ pt: 0 }}>
                  <Divider sx={{ mb: 2 }} />

                  {view.description && (
                    <Typography variant="body2" color="text.secondary" mb={2}>{view.description}</Typography>
                  )}

                  {/* Meta chips */}
                  <Stack direction="row" spacing={1} mb={2} flexWrap="wrap">
                    <Chip label={`Default limit: ${view.default_limit.toLocaleString()}`} size="small" />
                    <Chip label={`Max: ${view.max_limit.toLocaleString()}`} size="small" />
                    <Chip label={`Cache: ${view.cache_ttl_seconds}s`} size="small" />
                    <Chip label="Formats: json · csv · parquet" size="small" />
                  </Stack>

                  {/* Runtime parameters */}
                  {(view.param_definitions?.length ?? 0) > 0 && (
                    <Box mb={2}>
                      <Typography variant="subtitle2" gutterBottom>Runtime Parameters</Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ '& th': { fontWeight: 600 } }}>
                            <TableCell>Name</TableCell>
                            <TableCell>Type</TableCell>
                            <TableCell>Required</TableCell>
                            <TableCell>Default</TableCell>
                            <TableCell>Description</TableCell>
                            <TableCell>Query string key</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {view.param_definitions!.map(p => (
                            <TableRow key={p.name}>
                              <TableCell><code>{p.name}</code></TableCell>
                              <TableCell><Chip label={p.type || 'string'} size="small" /></TableCell>
                              <TableCell>{p.required ? '✓' : '—'}</TableCell>
                              <TableCell><code>{p.default || '—'}</code></TableCell>
                              <TableCell sx={{ color: 'text.secondary', fontSize: '0.8rem' }}>
                                {p.description || '—'}
                              </TableCell>
                              <TableCell>
                                {/* Phase 132.36 — bare-form preferred. */}
                                <code style={{ fontSize: '0.75rem' }}>{p.name}</code>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Box>
                  )}

                  {/* Allowed filters */}
                  {(view.allowed_filters?.length ?? 0) > 0 && (
                    <Box mb={2}>
                      <Typography variant="subtitle2" gutterBottom>Allowed Filters</Typography>
                      <Typography variant="body2" color="text.secondary" mb={1}>
                        Bare form (simple): <code>?column=value</code> or
                        {' '}<code>?column=('A','B')</code> for IN.
                        <br />Explicit form (operators):
                        {' '}<code>?filter.column=operator:value</code> —
                        <code>eq</code>, <code>ne</code>, <code>gt</code>,{' '}
                        <code>gte</code>, <code>lt</code>, <code>lte</code>,{' '}
                        <code>in</code>, <code>not_in</code>,{' '}
                        <code>contains</code>, <code>between</code>.
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap">
                        {view.allowed_filters.map(f => (
                          <Chip key={f} label={f} size="small" sx={{ fontFamily: 'monospace' }} />
                        ))}
                      </Stack>
                    </Box>
                  )}

                  {/* Curl example */}
                  <Box mb={2}>
                    <Stack direction="row" alignItems="center" spacing={1} mb={0.5}>
                      <Typography variant="subtitle2">Example Request</Typography>
                      <Tooltip title={copied === `curl-${view.id}` ? 'Copied!' : 'Copy'}>
                        <IconButton size="small" onClick={() => handleCopy(exampleCurl, `curl-${view.id}`)}>
                          {copied === `curl-${view.id}`
                            ? <CheckIcon fontSize="small" color="success" />
                            : <CopyIcon fontSize="small" />}
                        </IconButton>
                      </Tooltip>
                    </Stack>
                    <Box
                      component="pre"
                      sx={{
                        bgcolor: CODE_BG, color: CODE_COLOR, p: 2, borderRadius: 1,
                        fontFamily: 'monospace', fontSize: '0.8rem',
                        overflowX: 'auto', m: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                      }}
                    >
                      {exampleCurl}
                    </Box>
                  </Box>

                  {/* Try it button */}
                  <Button
                    variant={isTesting ? 'outlined' : 'contained'}
                    size="small"
                    startIcon={<TestIcon />}
                    onClick={() => {
                      if (isTesting) {
                        setTestingView(null);
                      } else {
                        setTestingView(view.id);
                        setTestParams(defaultParams);
                        // Auto-fill publisher defaults from
                        // _where_clauses_mapping (Dynamic rows only) so
                        // consumers see the intended starting values.
                        const initFilters: Record<string, string> = {};
                        const initOps: Record<string, string> = {};
                        (view.allowed_filters || []).forEach(col => {
                          const hint = getPublisherHint(view.query_config, col);
                          initOps[col] = hint.operator;
                          if (hint.defaultValue !== undefined && hint.defaultValue !== null) {
                            initFilters[col] = Array.isArray(hint.defaultValue)
                              ? hint.defaultValue.join(',')
                              : String(hint.defaultValue);
                          } else {
                            initFilters[col] = '';
                          }
                        });
                        setTestFilters(initFilters);
                        setTestOps(initOps);
                        setTestFormat('json');
                        setTestLimit(String(view.default_limit > 500 ? 100 : view.default_limit));
                        setTestResult(null);
                        setTestError('');
                      }
                    }}
                  >
                    {isTesting ? 'Close test panel' : 'Try it'}
                  </Button>

                  {/* Inline test panel */}
                  {isTesting && (
                    <Box mt={2} p={2} bgcolor="action.hover" borderRadius={1}>
                      <Typography variant="subtitle2" gutterBottom>Live Request Builder</Typography>

                      {/* Param inputs */}
                      {(view.param_definitions?.length ?? 0) > 0 && (
                        <Box mb={2}>
                          <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                            Parameters
                          </Typography>
                          <Stack spacing={1}>
                            {view.param_definitions!.map(p => (
                              <TextField
                                key={p.name}
                                size="small"
                                fullWidth
                                label={p.name}
                                value={testParams[p.name] ?? ''}
                                onChange={e =>
                                  setTestParams(prev => ({ ...prev, [p.name]: e.target.value }))
                                }
                                placeholder={p.default || p.type || 'value'}
                                required={p.required}
                                helperText={p.description || undefined}
                              />
                            ))}
                          </Stack>
                        </Box>
                      )}

                      {/* Filter inputs — Phase 133-K: real Autocomplete
                          with distinct-value dropdown per (connection,
                          table, column), publisher defaults auto-filled,
                          operator picker beside each value. */}
                      {(view.allowed_filters?.length ?? 0) > 0 && (() => {
                        const cid = view.execution_connection_id ?? view.connection_id ?? null;
                        const table = extractTableHint(view.query_config);
                        const secondaryCid =
                          (view.query_config?.secondary_connection_id as number) ?? null;
                        const fallback =
                          secondaryCid && table
                            ? [{ connectionId: secondaryCid, table }]
                            : [];
                        return (
                          <Box mb={2}>
                            <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                              Filters — pick or type a value.  Publisher defaults are pre-filled where
                              available; change the operator if you need something other than equals.
                            </Typography>
                            <Stack spacing={1}>
                              {view.allowed_filters.map(f => {
                                const op = testOps[f] || 'eq';
                                const hint = getPublisherHint(view.query_config, f);
                                return (
                                  <Stack
                                    key={f}
                                    direction="row"
                                    spacing={1}
                                    alignItems="flex-start"
                                  >
                                    <FormControl size="small" sx={{ minWidth: 170, mt: 0 }}>
                                      <InputLabel>{`op (${f})`}</InputLabel>
                                      <Select
                                        label={`op (${f})`}
                                        value={op}
                                        onChange={e =>
                                          setTestOps(prev => ({ ...prev, [f]: e.target.value }))
                                        }
                                      >
                                        {WHERE_OPERATORS.map(o => (
                                          <MenuItem key={o.value} value={o.value}>
                                            {o.label}
                                          </MenuItem>
                                        ))}
                                      </Select>
                                    </FormControl>
                                    <Box flex={1} minWidth={0}>
                                      <DynamicWhereOverrideField
                                        column={f}
                                        operator={op}
                                        publisherDefault={hint.defaultValue}
                                        value={testFilters[f] ?? ''}
                                        onChange={v =>
                                          setTestFilters(prev => ({
                                            ...prev,
                                            [f]: Array.isArray(v) ? v.join(',') : String(v ?? ''),
                                          }))
                                        }
                                        connectionId={cid}
                                        table={table}
                                        fallbackTargets={fallback}
                                        label={`filter[${f}]`}
                                        fullWidth
                                      />
                                    </Box>
                                  </Stack>
                                );
                              })}
                            </Stack>
                          </Box>
                        );
                      })()}

                      <Stack direction="row" spacing={2} mb={2} alignItems="flex-start">
                        <FormControl size="small" sx={{ minWidth: 110 }}>
                          <InputLabel>Format</InputLabel>
                          <Select
                            value={testFormat}
                            label="Format"
                            onChange={e => setTestFormat(e.target.value)}
                          >
                            <MenuItem value="json">json</MenuItem>
                            <MenuItem value="csv">csv</MenuItem>
                            <MenuItem value="parquet">parquet</MenuItem>
                          </Select>
                        </FormControl>
                        <TextField
                          size="small"
                          label="Limit"
                          type="number"
                          value={testLimit}
                          onChange={e => setTestLimit(e.target.value)}
                          sx={{ width: 110 }}
                          inputProps={{ min: 1, max: view.max_limit }}
                        />
                        <Button
                          variant="contained"
                          size="small"
                          startIcon={testLoading ? <CircularProgress size={14} /> : <PlayIcon />}
                          disabled={testLoading}
                          onClick={() => handleTest(view)}
                        >
                          Send
                        </Button>
                        {(() => {
                          const usingApiKey =
                            selectedKeyId === 'custom' &&
                            customKey &&
                            customKey !== 'YOUR_API_KEY' &&
                            customKey.trim().length > 8;
                          return (
                            <Chip
                              size="small"
                              color={usingApiKey ? 'primary' : 'default'}
                              label={usingApiKey
                                ? `Auth: X-API-Key (${customKey.trim().slice(0, 8)}…)`
                                : 'Auth: session (paste key above to test as key)'}
                              sx={{ alignSelf: 'center' }}
                            />
                          );
                        })()}
                      </Stack>

                      {/* Live curl */}
                      <Box mb={2}>
                        <Stack direction="row" alignItems="center" spacing={1} mb={0.5}>
                          <Typography variant="caption" color="text.secondary">Live curl</Typography>
                          <Tooltip title={copied === `live-${view.id}` ? 'Copied!' : 'Copy curl'}>
                            <IconButton
                              size="small"
                              onClick={() =>
                                handleCopy(
                                  buildCurl(view, testParams, testFilters, testOps, testFormat, testLimit),
                                  `live-${view.id}`,
                                )
                              }
                            >
                              {copied === `live-${view.id}`
                                ? <CheckIcon fontSize="small" color="success" />
                                : <CopyIcon fontSize="small" />}
                            </IconButton>
                          </Tooltip>
                        </Stack>
                        <Box
                          component="pre"
                          sx={{
                            bgcolor: CODE_BG, color: CODE_COLOR, p: 1.5, borderRadius: 1,
                            fontFamily: 'monospace', fontSize: '0.75rem',
                            overflowX: 'auto', m: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                          }}
                        >
                          {buildCurl(view, testParams, testFilters, testOps, testFormat, testLimit)}
                        </Box>
                      </Box>

                      {testError && <Alert severity="error" sx={{ mb: 1 }}>{testError}</Alert>}

                      {testResult && (
                        <Box>
                          <Typography variant="caption" color="text.secondary">
                            Response —{' '}
                            {(testResult.rows ?? testResult.data ?? []).length} rows
                            {testResult.total_rows != null &&
                              ` of ${testResult.total_rows.toLocaleString()} total`}
                          </Typography>
                          <Box
                            component="pre"
                            sx={{
                              bgcolor: CODE_BG, color: CODE_COLOR, p: 1.5, borderRadius: 1,
                              fontFamily: 'monospace', fontSize: '0.75rem',
                              maxHeight: 300, overflow: 'auto', mt: 0.5,
                            }}
                          >
                            {JSON.stringify(testResult, null, 2).slice(0, 4000)}
                          </Box>
                        </Box>
                      )}
                    </Box>
                  )}
                </AccordionDetails>
              </Accordion>
            );
          })}
        </>
      )}
    </Box>
  );
};

export default ApiExplorerPage;
