/**
 * ReportChangeHistory — Field-level change timeline for business reports (Phase 114-L).
 *
 * Shows chronological list of changes with field-level diffs:
 *  - Green for additions, amber for modifications, red for removals
 *  - Action chips: created, updated, published, unpublished
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Chip, CircularProgress, Alert, Divider,
} from '@mui/material';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import EditIcon from '@mui/icons-material/Edit';
import PublishIcon from '@mui/icons-material/Publish';
import UnpublishedIcon from '@mui/icons-material/Unpublished';
import api from '../services/api';
import { toArray } from '../utils/toArray';

interface Change {
  field: string;
  old: string | null;
  new: string | null;
}

interface ChangeLogEntry {
  id: number;
  report_id: number;
  username: string;
  action: string;
  changes: Change[];
  created_at: string;
}

interface ReportChangeHistoryProps {
  reportId: number;
}

const ACTION_CONFIG: Record<string, { color: 'success' | 'info' | 'warning' | 'error'; icon: React.ReactNode }> = {
  created:     { color: 'success', icon: <AddCircleIcon sx={{ fontSize: 14 }} /> },
  updated:     { color: 'info',    icon: <EditIcon sx={{ fontSize: 14 }} /> },
  published:   { color: 'success', icon: <PublishIcon sx={{ fontSize: 14 }} /> },
  unpublished: { color: 'warning', icon: <UnpublishedIcon sx={{ fontSize: 14 }} /> },
};

export default function ReportChangeHistory({ reportId }: ReportChangeHistoryProps) {
  const [entries, setEntries] = useState<ChangeLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const data = await api.getReportChangeHistory(reportId, 50);
      setEntries(toArray(data));  // BF-428P
    } catch (e: any) {
      setError(e.message || 'Failed to load change history');
    } finally {
      setLoading(false);
    }
  }, [reportId]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <Box sx={{ p: 2, textAlign: 'center' }}><CircularProgress size={24} /></Box>;

  return (
    <Box sx={{ px: 1.5, py: 1, overflowY: 'auto', height: '100%' }}>
      {error && <Alert severity="warning" sx={{ mb: 1 }} onClose={() => setError('')}>{error}</Alert>}

      {entries.length === 0 && (
        <Typography color="text.secondary" variant="body2" sx={{ py: 3, textAlign: 'center' }}>
          No change history yet.
        </Typography>
      )}

      {entries.map((entry, idx) => {
        const cfg = ACTION_CONFIG[entry.action] || ACTION_CONFIG.updated;
        return (
          <Box key={entry.id}>
            {idx > 0 && <Divider sx={{ my: 1 }} />}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
              <Chip
                icon={cfg.icon as any}
                label={entry.action}
                size="small"
                color={cfg.color}
                variant="outlined"
                sx={{ height: 22, fontSize: '0.7rem' }}
              />
              <Typography variant="caption" fontWeight={600}>{entry.username}</Typography>
              <Typography variant="caption" color="text.secondary">
                {new Date(entry.created_at).toLocaleString()}
              </Typography>
            </Box>

            {/* Field-level diffs */}
            {entry.changes && entry.changes.length > 0 && (
              <Box sx={{ ml: 2, mt: 0.5 }}>
                {entry.changes.map((change, ci) => (
                  <Box key={ci} sx={{ mb: 0.5 }}>
                    <Typography variant="caption" fontWeight={600} sx={{ color: 'text.secondary' }}>
                      {change.field}
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 0.25 }}>
                      {change.old != null && (
                        <Typography variant="caption" sx={{
                          bgcolor: '#ffebee', color: '#c62828', px: 0.75, py: 0.25,
                          borderRadius: 0.5, fontFamily: 'monospace', fontSize: '0.7rem',
                          maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}>
                          - {change.old}
                        </Typography>
                      )}
                      {change.new != null && (
                        <Typography variant="caption" sx={{
                          bgcolor: '#e8f5e9', color: '#2e7d32', px: 0.75, py: 0.25,
                          borderRadius: 0.5, fontFamily: 'monospace', fontSize: '0.7rem',
                          maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}>
                          + {change.new}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                ))}
              </Box>
            )}
          </Box>
        );
      })}
    </Box>
  );
}
