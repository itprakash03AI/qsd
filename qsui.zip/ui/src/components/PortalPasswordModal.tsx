/**
 * BF-285 — AWS Portal Password Modal.
 *
 * QueryStudio does NOT persist user passwords.  But the AWS portal
 * flow (auth_mode="portal") needs the password whenever the boto3
 * RefreshableCredentials callback fires.  Solution: prompt the user
 * once per session, store encrypted in the in-memory vault on the
 * backend, and the refresh callback reads from there transparently.
 *
 * Trigger surfaces:
 *   1. Preemptive: app load — useEffect hook in App.tsx checks
 *      ``GET /api/aws-portal/password-status`` and opens the modal
 *      if vaulted=false.
 *   2. Reactive: query failed with 401 ``portal_password_required``
 *      — caller opens this modal, on success retries the query.
 *
 * On success the modal calls onSuccess() so the caller can:
 *   - retry the failed query
 *   - update its local "vaulted" flag
 *   - dismiss any error banner
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, TextField, Typography,
} from '@mui/material';
import LockIcon from '@mui/icons-material/LockOutlined';
import api from '../services/api';

interface PortalPasswordModalProps {
  open:       boolean;
  username?:  string;     // current AD user — populated from useAuth context
  reason?:    string;     // optional context for why we're prompting
  // BF-PORTAL-CONN-OVERRIDES: connection that triggered the prompt.
  // Forwarded to /api/aws-portal/authenticate so the backend reads
  // that connection's portal_base_url / proxy_url / role_name overrides
  // instead of the global defaults.  Without this, a connection whose
  // Connection Manager test works can still fail mid-query with
  // "wrong version number" SSL errors after the modal "succeeds".
  connectionId?: number;
  onClose:    () => void;
  onSuccess?: () => void; // caller retries the failed query / refreshes UI
}

const PortalPasswordModal: React.FC<PortalPasswordModalProps> = ({
  open, username, reason, connectionId, onClose, onSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setPassword('');
      setErr(null);
      setSubmitting(false);
    }
  }, [open]);

  const handleSubmit = async () => {
    if (!username) {
      setErr('No active user — please log in first.');
      return;
    }
    if (!password.trim()) {
      setErr('Password is required.');
      return;
    }
    setSubmitting(true);
    setErr(null);
    try {
      const resp: any = await (api as any).authenticateAWSPortal(username, password, connectionId);
      if (resp?.success) {
        setPassword('');  // clear immediately — never keep in component state longer than needed
        if (onSuccess) onSuccess();
        onClose();
      } else {
        setErr(resp?.message || 'Authentication failed.');
      }
    } catch (e: any) {
      setErr(e?.detail || e?.message || 'Authentication failed — check your password and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !submitting) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <Dialog open={open} onClose={submitting ? undefined : onClose} maxWidth="xs" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <LockIcon color="primary" />
          AWS Portal Password
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          QueryStudio doesn't store your password.  Enter it once per
          session so we can refresh AWS credentials automatically while
          your queries run.
        </Typography>
        {reason && (
          <Alert severity="info" sx={{ mb: 2 }}>{reason}</Alert>
        )}
        <TextField
          label="AD Username"
          fullWidth size="small" margin="normal"
          value={username || ''}
          disabled
          helperText="From your current login session"
        />
        <TextField
          label="AD Password"
          type="password"
          fullWidth size="small" margin="normal"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={handleKey}
          autoFocus
          autoComplete="current-password"
          disabled={submitting}
        />
        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
          The password is encrypted in memory and discarded on logout
          or backend restart.  Never written to disk.
        </Typography>
        {err && <Alert severity="error" sx={{ mt: 2 }}>{err}</Alert>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={submitting}>Cancel</Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={submitting || !password.trim()}
          startIcon={submitting ? <CircularProgress size={16} /> : <LockIcon />}
        >
          {submitting ? 'Authenticating…' : 'Submit'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PortalPasswordModal;
