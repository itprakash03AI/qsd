/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * SharedBusinessReportPage — Public share-link page for business reports (no auth required).
 *
 * Route: /shared-business-report/:token
 *
 * Features:
 *  - Report info card (name, description)
 *  - Parameter prompt (if report has parameters)
 *  - Execute via public endpoint
 *  - Results table with pagination
 *  - Export CSV
 */
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { getUserFriendlyError } from '../utils/errorMessages';
import { useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Box, Button, CircularProgress, Divider, FormControl, IconButton,
  InputAdornment, InputLabel, Menu, MenuItem, ListItemIcon, ListItemText,
  Paper, Select, TableContainer, Table, TableHead,
  TableRow, TableCell, TableBody, TablePagination, TextField,
  Typography,
} from '@mui/material';
import {
  BoltOutlined as BoltIcon,
  ContentCopy as CopyIcon,
  Download as DownloadIcon,
  GetApp as GetAppIcon,
  LinkOff as LinkOffIcon,
  PictureAsPdf as PictureAsPdfIcon,
  PlayArrow as RunIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  TableView as TableViewIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useParamLovs } from '../hooks/useParamLovs';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100, 250];

function exportCsv(columns: string[], rows: any[][], filename: string) {
  const header = columns.join(',');
  const body = rows.map(r =>
    r.map(v => {
      const s = v === null || v === undefined ? '' : String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n')
        ? `"${s.replace(/"/g, '""')}"` : s;
    }).join(',')
  ).join('\n');
  const blob = new Blob([header + '\n' + body], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

export default function SharedBusinessReportPage() {
  const { token } = useParams<{ token: string }>();
  // FIX 4 (Phase 81): URL params with p_* prefix pre-fill report parameters
  // e.g. /shared-business-report/abc123?p_region=West&p_start_date=2025-01-01
  const [searchParams] = useSearchParams();

  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Execution
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [execError, setExecError] = useState('');

  // Parameter values
  const [paramValues, setParamValues] = useState<Record<string, any>>({});

  // Table
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [searchQ, setSearchQ] = useState('');
  const [copied, setCopied] = useState(false);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  const [exportError, setExportError] = useState('');

  // LOV loading via token-based endpoint (no auth)
  const sharedFetchFn = useCallback(
    (body: any) => token ? api.getSharedReportParamValues(token, body) : Promise.resolve({ values: [] }),
    [token]
  );
  const paramLovs = useParamLovs({
    reportId: report?.id || 0,
    parameters: report?.parameters,
    paramValues,
    fetchFn: sharedFetchFn,
  });

  // Load report metadata
  useEffect(() => {
    if (!token) return;
    (async () => {
      setLoading(true);
      try {
        const res = await api.getSharedBusinessReport(token);
        setReport(res.report);
        // FIX 4: URL params (p_<name>) override defaults; fall back to default_value
        const defaults: Record<string, any> = {};
        (res.report.parameters || []).forEach((p: any) => {
          const urlVal = searchParams.get(`p_${p.name}`);
          if (urlVal != null) {
            defaults[p.name] = urlVal;
          } else if (p.default_value != null) {
            defaults[p.name] = p.default_value;
          }
        });
        setParamValues(defaults);
      } catch (e: any) {
        setError(getUserFriendlyError(e, 'Share link not found or expired'));
      } finally { setLoading(false); }
    })();
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleExecute = useCallback(async () => {
    if (!token) return;
    setExecuting(true);
    setExecError('');
    try {
      const res = await api.executeSharedBusinessReport(token, {
        parameter_values: paramValues,
      });
      setResult(res);
      setPage(0);
    } catch (e: any) {
      setExecError(getUserFriendlyError(e, 'Execution failed'));
    } finally { setExecuting(false); }
  }, [token, paramValues]);

  // Auto-execute if no params, or all params were pre-filled via URL p_* params
  useEffect(() => {
    if (!report || result || executing) return;
    const params = report.parameters || [];
    if (params.length === 0) {
      handleExecute();
      return;
    }
    // Auto-run if all required params have values from URL or defaults
    const allFilled = params.every((p: any) => !p.is_required || paramValues[p.name] != null && paramValues[p.name] !== '');
    const anyFromUrl = params.some((p: any) => searchParams.has(`p_${p.name}`));
    if (anyFromUrl && allFilled) {
      handleExecute();
    }
  }, [report]); // eslint-disable-line react-hooks/exhaustive-deps

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filter rows by search
  const columns = result?.columns || [];
  const allRows = result?.rows || [];
  const filteredRows = useMemo(() => {
    if (!searchQ.trim()) return allRows;
    const q = searchQ.toLowerCase();
    return allRows.filter((row: any[]) =>
      row.some(v => String(v ?? '').toLowerCase().includes(q))
    );
  }, [allRows, searchQ]);

  const paginatedRows = filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh', flexDirection: 'column', gap: 2 }}>
        <LinkOffIcon sx={{ fontSize: 64, color: 'text.disabled' }} />
        <Typography variant="h5" color="text.secondary">Share Link Unavailable</Typography>
        <Typography variant="body2" color="text.disabled">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: 3 }}>
      {/* Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
          <BoltIcon sx={{ color: 'primary.main' }} />
          <Typography variant="h5" fontWeight={600}>{report?.name}</Typography>
          <Box sx={{ flex: 1 }} />
          <Button size="small" startIcon={<CopyIcon />} onClick={copyLink}>
            {copied ? 'Copied!' : 'Copy Link'}
          </Button>
        </Box>
        {report?.description && (
          <Typography variant="body2" color="text.secondary" sx={{ ml: 5 }}>
            {report.description}
          </Typography>
        )}
      </Paper>

      {/* Parameters */}
      {(report?.parameters || []).length > 0 && (
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Parameters</Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            {report.parameters.map((p: any) => {
              const labelWithRequired = p.is_required ? `${p.label} *` : p.label;
              if (p.parameter_type === 'dropdown' || p.parameter_type === 'multi_select') {
                const lovs = paramLovs[p.id] || [];
                return (
                  <FormControl key={p.id} size="small" sx={{ minWidth: 200 }}>
                    <InputLabel>{labelWithRequired}</InputLabel>
                    <Select label={labelWithRequired}
                            value={paramValues[p.name] || (p.parameter_type === 'multi_select' ? [] : '')}
                            multiple={p.parameter_type === 'multi_select'}
                            onChange={e => {
                              const newVal = e.target.value;
                              setParamValues(prev => {
                                const next = { ...prev, [p.name]: newVal };
                                for (const child of (report.parameters || [])) {
                                  if (child.depends_on_param_id === p.id) {
                                    next[child.name] = child.parameter_type === 'multi_select' ? [] : '';
                                  }
                                }
                                return next;
                              });
                            }}>
                      {!p.is_required && <MenuItem value=""><em>All</em></MenuItem>}
                      {lovs.map((v: string) => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                );
              }
              if (p.parameter_type === 'date' || p.parameter_type === 'date_range') {
                return (
                  <Box key={p.id} sx={{ display: 'flex', gap: 1 }}>
                    <TextField size="small" type="date"
                      label={labelWithRequired + (p.parameter_type === 'date_range' ? ' From' : '')}
                      InputLabelProps={{ shrink: true }}
                      value={p.parameter_type === 'date_range' ? (paramValues[p.name]?.from || '') : (paramValues[p.name] || '')}
                      onChange={e => {
                        if (p.parameter_type === 'date_range') {
                          setParamValues(prev => ({
                            ...prev,
                            [p.name]: { ...(prev[p.name] || {}), from: e.target.value },
                          }));
                        } else {
                          setParamValues(prev => ({ ...prev, [p.name]: e.target.value }));
                        }
                      }}
                      sx={{ minWidth: 170 }} />
                    {p.parameter_type === 'date_range' && (
                      <TextField size="small" type="date"
                        label={labelWithRequired + ' To'}
                        InputLabelProps={{ shrink: true }}
                        value={paramValues[p.name]?.to || ''}
                        onChange={e => setParamValues(prev => ({
                          ...prev,
                          [p.name]: { ...(prev[p.name] || {}), to: e.target.value },
                        }))}
                        sx={{ minWidth: 170 }} />
                    )}
                  </Box>
                );
              }
              return (
                <TextField key={p.id} size="small"
                  label={labelWithRequired}
                  value={paramValues[p.name] || ''}
                  onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                  sx={{ minWidth: 180 }} />
              );
            })}
            <Button variant="contained" startIcon={<RunIcon />}
              onClick={handleExecute} disabled={executing}>
              {executing ? <CircularProgress size={16} /> : 'Run Report'}
            </Button>
          </Box>
        </Paper>
      )}

      {execError && <Alert severity="error" sx={{ mb: 2 }}>{execError}</Alert>}
      {exportError && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setExportError('')}>{exportError}</Alert>}

      {/* Results */}
      {result && (
        <Paper sx={{ overflow: 'hidden' }}>
          <Box sx={{ px: 2, py: 1, display: 'flex', alignItems: 'center', gap: 1,
            borderBottom: '1px solid', borderColor: 'divider' }}>
            <TextField
              size="small" placeholder="Filter rows..." value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              sx={{ flex: 1, maxWidth: 300 }}
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                endAdornment: searchQ ? (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSearchQ('')}><ClearIcon fontSize="small" /></IconButton>
                  </InputAdornment>
                ) : null,
              }}
            />
            <Typography variant="body2" color="text.secondary">
              {filteredRows.length} row{filteredRows.length !== 1 ? 's' : ''}
            </Typography>
            <Button size="small" startIcon={<DownloadIcon />}
              onClick={(e) => setExportAnchor(e.currentTarget)}>
              Export
            </Button>
            <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
              onClose={() => setExportAnchor(null)}>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadSharedReportExcel(token!, paramValues); } catch (e: any) { setExportError(e?.message || 'Excel export failed'); } }}>
                <ListItemIcon><TableViewIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Excel</ListItemText>
              </MenuItem>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadSharedReportPDF(token!, paramValues); } catch (e: any) { setExportError(e?.message || 'PDF export failed'); } }}>
                <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
                <ListItemText>PDF</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => { setExportAnchor(null); exportCsv(columns, filteredRows, `${report?.name || 'report'}.csv`); }}>
                <ListItemIcon><GetAppIcon fontSize="small" /></ListItemIcon>
                <ListItemText>CSV (client)</ListItemText>
              </MenuItem>
            </Menu>
          </Box>

          <TableContainer sx={{ maxHeight: 600 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((col: string, i: number) => (
                    <TableCell key={i} sx={{
                      fontWeight: 600, bgcolor: '#00aeef', color: '#fff',
                      textTransform: 'uppercase', fontSize: 11,
                    }}>{col}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRows.map((row: any[], ri: number) => (
                  <TableRow key={ri} hover>
                    {row.map((v: any, ci: number) => (
                      <TableCell key={ci} sx={{ fontSize: 12 }}>
                        {v === null || v === undefined ? '' : String(v)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={filteredRows.length}
            page={page} onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </Paper>
      )}
    </Box>
  );
}
