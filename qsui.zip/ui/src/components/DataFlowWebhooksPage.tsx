/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowWebhooksPage — webhook triggers (Phase 132.22).
 *
 * Mint a token, bind it to a DataFlow, share the resulting URL with the
 * external system.  Token is shown ONCE on creation only.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControlLabel, IconButton, MenuItem,
  Paper, Select, Stack, Switch, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  ContentCopy as CopyIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { DataFlowDef } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const fmtDt = (iso?: string | null) => iso ? iso.slice(0, 16).replace('T', ' ') : '—';

export default function DataFlowWebhooksPage() {
  const [hooks, setHooks] = useState<any[]>([]);
  const [dataflows, setDataflows] = useState<DataFlowDef[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [tokenDialog, setTokenDialog] = useState<{
    open: boolean; token?: string; name?: string; signing_secret?: string;
  }>({ open: false });

  const [form, setForm] = useState<any>({
    dataflow_id: '' as string | number,
    name: '',
    allowed_ips_csv: '',
    is_active: true,
    require_signature: false,
  });

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [h, w] = await Promise.all([
        api.dataflows.listWebhookTriggers(),
        api.dataflows.listDataFlows({ status: 'active' }),
      ]);
      setHooks(toArray(h));
      setDataflows(toArray<DataFlowDef>(w));
    } catch (e: any) {
      setError(e?.message || 'Failed to load webhooks');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const onCreate = async () => {
    try {
      const allowed = (form.allowed_ips_csv || '').split(',').map((s: string) => s.trim()).filter(Boolean);
      const r: any = await api.dataflows.createWebhookTrigger({
        dataflow_id: Number(form.dataflow_id),
        name: form.name,
        allowed_ips: allowed,
        is_active: form.is_active,
        require_signature: form.require_signature,
      });
      setDialogOpen(false);
      setForm({ dataflow_id: '', name: '', allowed_ips_csv: '',
                is_active: true, require_signature: false });
      setTokenDialog({ open: true, token: r.token, name: r.name,
                        signing_secret: r.signing_secret });
      await load();
    } catch (e: any) { setError(e?.message || 'Create failed'); }
  };

  const onDelete = async (id: number, name: string) => {
    if (!window.confirm(`Delete webhook "${name}"?`)) return;
    try { await api.dataflows.deleteWebhookTrigger(id); await load(); }
    catch (e: any) { setError(e?.message || 'Delete failed'); }
  };

  const nameOf = (id: number) => dataflows.find(d => d.id === id)?.name || `#${id}`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">Webhook Triggers</Typography>
        <Stack direction="row" spacing={1}>
          <Button startIcon={<AddIcon />} variant="contained" onClick={() => setDialogOpen(true)}>New Webhook</Button>
          <Tooltip title="Refresh"><IconButton onClick={load}><RefreshIcon /></IconButton></Tooltip>
        </Stack>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Fire a DataFlow run from external systems (Jenkins, GitLab, vendor) via
        <code> POST /api/webhooks/dataflow/&lt;token&gt;</code> with an optional JSON body.
        Tokens are returned ONCE on creation and never shown again — store them securely.
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>DataFlow</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Allowed IPs</TableCell>
              <TableCell>Fires</TableCell>
              <TableCell>Last fired</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && <TableRow><TableCell colSpan={7} align="center"><CircularProgress size={20} /></TableCell></TableRow>}
            {!loading && hooks.length === 0 && (
              <TableRow><TableCell colSpan={7} align="center">
                <Typography variant="body2" color="text.secondary">No webhooks yet.</Typography>
              </TableCell></TableRow>
            )}
            {hooks.map(h => (
              <TableRow key={h.id} hover>
                <TableCell>{h.name}</TableCell>
                <TableCell>{nameOf(h.dataflow_id)}</TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    {h.is_active ? <Chip label="active" size="small" color="success" sx={{ fontSize: 10 }} /> : <Chip label="off" size="small" sx={{ fontSize: 10 }} />}
                    {h.has_signing_secret && (
                      <Tooltip title="HMAC signature verification enabled">
                        <Chip label="HMAC" size="small" color="info" variant="outlined" sx={{ fontSize: 10 }} />
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
                <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                  {h.allowed_ips?.length ? h.allowed_ips.join(', ') : 'any'}
                </TableCell>
                <TableCell sx={{ fontSize: 12 }}>{h.fire_count}</TableCell>
                <TableCell sx={{ fontSize: 12 }}>{fmtDt(h.last_fired_at)}</TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={() => onDelete(h.id, h.name)}><DeleteIcon fontSize="small" /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>New Webhook Trigger</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Select size="small" fullWidth displayEmpty value={form.dataflow_id}
              onChange={e => setForm({ ...form, dataflow_id: e.target.value })}>
              <MenuItem value="" disabled>Pick a DataFlow…</MenuItem>
              {dataflows.map(d => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
            </Select>
            <TextField label="Name" size="small" fullWidth value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. jenkins-prod" />
            <TextField label="Allowed source IPs (optional, CIDR list)" size="small" fullWidth
              value={form.allowed_ips_csv}
              onChange={e => setForm({ ...form, allowed_ips_csv: e.target.value })}
              placeholder="10.0.0.0/8, 192.168.1.0/24"
              helperText="Leave blank to accept from any source IP" />
            <FormControlLabel control={<Switch checked={form.is_active}
              onChange={e => setForm({ ...form, is_active: e.target.checked })} />} label="Active" />
            <FormControlLabel control={<Switch checked={form.require_signature}
              onChange={e => setForm({ ...form, require_signature: e.target.checked })} />}
              label="Require HMAC signature (recommended)" />
            {form.require_signature && (
              <Alert severity="info" sx={{ fontSize: 12 }}>
                Caller must include header <code>X-QueryStudio-Signature: sha256=&lt;hex&gt;</code>
                where hex = <code>HMAC-SHA256(signing_secret, raw_body).hexdigest()</code>.
                The secret is returned ONCE alongside the token after Create.
              </Alert>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={onCreate}
            disabled={!form.dataflow_id || !form.name}>Create</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={tokenDialog.open} onClose={() => setTokenDialog({ open: false })} maxWidth="sm" fullWidth>
        <DialogTitle>Webhook token created — copy it now</DialogTitle>
        <DialogContent>
          <Alert severity="warning" sx={{ mb: 2 }}>
            This is the only time the token is shown. Store it in your external system now —
            QueryStudio will not display it again.
          </Alert>
          <Typography variant="caption" color="text.secondary">Webhook URL:</Typography>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mt: 0.5 }}>
            <TextField fullWidth size="small" InputProps={{ readOnly: true }}
              value={`POST ${typeof window !== 'undefined' ? window.location.origin : ''}/api/webhooks/dataflow/${tokenDialog.token || ''}`}
              sx={{ fontFamily: 'monospace' }} />
            <Tooltip title="Copy URL">
              <IconButton onClick={() =>
                copyToClipboard(`${typeof window !== 'undefined' ? window.location.origin : ''}/api/webhooks/dataflow/${tokenDialog.token || ''}`)}>
                <CopyIcon />
              </IconButton>
            </Tooltip>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>Token only:</Typography>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mt: 0.5 }}>
            <TextField fullWidth size="small" InputProps={{ readOnly: true }}
              value={tokenDialog.token || ''} sx={{ fontFamily: 'monospace' }} />
            <Tooltip title="Copy">
              <IconButton onClick={() => copyToClipboard(tokenDialog.token || '')}>
                <CopyIcon />
              </IconButton>
            </Tooltip>
          </Box>
          {tokenDialog.signing_secret && (
            <>
              <Alert severity="warning" sx={{ mt: 2 }}>
                Signing secret — also shown only once. Use it to HMAC-SHA256
                each request body and pass the digest as
                <code> X-QueryStudio-Signature: sha256=&lt;hex&gt;</code>.
              </Alert>
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mt: 1 }}>
                <TextField fullWidth size="small" InputProps={{ readOnly: true }}
                  value={tokenDialog.signing_secret} sx={{ fontFamily: 'monospace' }} />
                <Tooltip title="Copy">
                  <IconButton onClick={() =>
                    copyToClipboard(tokenDialog.signing_secret || '')}>
                    <CopyIcon />
                  </IconButton>
                </Tooltip>
              </Box>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTokenDialog({ open: false })} variant="contained">I have copied the token</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
