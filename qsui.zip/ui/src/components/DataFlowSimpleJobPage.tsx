/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowSimpleJobPage — guided ETL job page.
 *
 * Operates in three modes via URL params:
 *   • /dataflows/simple/new            — create from a job type
 *   • /dataflows/simple/:id            — view existing (read-only header,
 *                                          per-step expand still works)
 *   • /dataflows/simple/:id?edit=1     — edit existing (creates a new draft
 *                                          version on Save)
 *
 * Both this Simple page and the DAG editor are two views of THE SAME
 * DataFlow record — toggle between them with the [Simple | DAG] button
 * top-right.  All edits flow through the same /api/dataflows endpoints,
 * so the two views stay in perfect sync.
 */
import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Divider, FormControlLabel, IconButton,
  MenuItem, Paper, Select, Stack, Switch, TextField, Tooltip, Typography,
  Collapse, ButtonGroup,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, AccountTree as DagIcon,
  ViewList as SimpleIcon, ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon, Save as SaveIcon,
  CheckCircle as OkIcon, ErrorOutline as ErrorIcon,
  Edit as EditIcon, ArrowUpward as UpIcon, ArrowDownward as DownIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  DataFlowDef, StageDef, StageTypeManifest, DynamicDataflowRow,
} from '../services/api/dataflows';
import { collectDataflowDynamicRows } from '../services/api/dataflows';
import DataflowOverrideDialog from './dataflow/DataflowOverrideDialog';
import { toArray } from '../utils/toArray';


// ── Types ─────────────────────────────────────────────────────────────


interface JobType {
  id:          string;
  label:       string;
  description: string;
  template:    string;
  category:    string;
}

interface KeyValuePair {
  key:   string;
  value: any;
}

interface Connection {
  id:   number;
  name: string;
  connection_type?: string;
  type?: string;
}


// ── Step reorder + remove helpers ─────────────────────────────────────
//
// Reordering steps in a linear DAG rewires the predecessor edges so the
// new visual order matches the execution order:
//
//   before: A → B → C (preds: B=[A], C=[B])
//   move B down:
//   after:  A → C → B (preds: C=[A], B=[C])
//
// Edges that point OUTSIDE this linear chain are preserved as-is — only
// "from previous step" edges are rebuilt.  This keeps the move action
// safe even when the DAG isn't strictly linear.


function reorderAndRewire(
  stages: StageDef[],
  fromIdx: number,
  toIdx: number,
): StageDef[] {
  if (fromIdx === toIdx) return stages;
  const copy = [...stages];
  const [moved] = copy.splice(fromIdx, 1);
  copy.splice(toIdx, 0, moved);
  return relinkChain(copy);
}


function removeAndRewire(
  stages: StageDef[],
  alias: string,
): StageDef[] {
  return relinkChain(stages
    .filter(s => s.stage_alias !== alias)
    .map(s => ({
      ...s,
      predecessors: (s.predecessors || []).filter(p => p !== alias),
    })));
}


function relinkChain(stages: StageDef[]): StageDef[] {
  // Build alias→idx map and identify which predecessors are "chain
  // links" (from immediate prior step in the OLD order).  We do the
  // simple thing: every step's predecessors keep references that still
  // resolve to a stage in the array; in addition, ensure each step
  // (except the first) has at least one predecessor — defaulting to
  // the previous step in the new order.
  const aliveSet = new Set(stages.map(s => s.stage_alias));
  return stages.map((s, idx) => {
    let preds = (s.predecessors || []).filter(p => aliveSet.has(p));
    // If predecessors are now empty AND this isn't the first row, link
    // to the previous step so the chain isn't broken.
    if (preds.length === 0 && idx > 0) {
      preds = [stages[idx - 1].stage_alias];
    }
    return { ...s, predecessors: preds, seq: idx + 1 };
  });
}


function applyConnectionToGlobals(conn: Connection,
                                    role: 'oracle' | 's3' | 'starburst'): KeyValuePair[] {
  if (role === 'oracle') {
    return [
      { key: 'oracle_url',      value: (conn as any).oracle_url || '' },
      { key: 'oracle_user',     value: (conn as any).username || (conn as any).user || '' },
      { key: 'oracle_password', value: (conn as any).password ? '<from-connection>' : '' },
    ];
  }
  if (role === 's3') {
    return [
      { key: 's3_access_key', value: (conn as any).access_key_id || '<from-connection>' },
      { key: 's3_secret_key', value: '<from-connection>' },
      { key: 's3_bucket',     value: (conn as any).bucket || '' },
    ];
  }
  return [];
}


// ── Step card (collapsible per-step override) ────────────────────────


function StepCard({
  step, stageManifest, expanded, onToggle, onChange, readOnly,
  canMoveUp, canMoveDown, onMoveUp, onMoveDown, onRemove,
}: {
  step: StageDef;
  stageManifest?: StageTypeManifest;
  expanded: boolean;
  onToggle: () => void;
  onChange: (config: Record<string, any>) => void;
  readOnly?: boolean;
  canMoveUp?: boolean;
  canMoveDown?: boolean;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onRemove?: () => void;
}) {
  const config = step.config || {};
  const cfgEntries = Object.entries(config);
  const schemaKeys = Object.keys(stageManifest?.config_schema || {});
  return (
    <Paper variant="outlined" sx={{ mb: 1 }}>
      <Stack direction="row" alignItems="center" spacing={1}
              sx={{ px: 2, py: 1, cursor: 'pointer' }}
              onClick={onToggle}>
        <Typography variant="caption" sx={{ minWidth: 22, color: 'text.secondary' }}>
          #{step.seq}
        </Typography>
        <Box sx={{ flex: 1 }}>
          <Typography variant="body2" sx={{ fontWeight: 500 }}>
            {step.stage_alias}
          </Typography>
          <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mt: 0.25 }}>
            <Chip label={stageManifest?.display_name || step.stage_type} size="small" variant="outlined"
                   sx={{ fontSize: 10, height: 18 }} />
            {cfgEntries.length > 0 && (
              <Chip label={`${cfgEntries.length} override${cfgEntries.length === 1 ? '' : 's'}`}
                     size="small" color="primary" variant="outlined"
                     sx={{ fontSize: 10, height: 18 }} />
            )}
            {step.predecessors && step.predecessors.length > 0 && (
              <Chip label={`after: ${step.predecessors.join(', ')}`} size="small"
                     variant="outlined" sx={{ fontSize: 10, height: 18 }} />
            )}
          </Stack>
        </Box>
        {!readOnly && (
          <>
            <Tooltip title="Move step up (rewires predecessor edges)">
              <span>
                <IconButton size="small"
                             disabled={!canMoveUp}
                             onClick={e => { e.stopPropagation(); onMoveUp && onMoveUp(); }}>
                  <UpIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="Move step down (rewires predecessor edges)">
              <span>
                <IconButton size="small"
                             disabled={!canMoveDown}
                             onClick={e => { e.stopPropagation(); onMoveDown && onMoveDown(); }}>
                  <DownIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
            {onRemove && (
              <Tooltip title="Remove step">
                <IconButton size="small" color="error"
                             onClick={e => { e.stopPropagation(); onRemove(); }}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </>
        )}
        <IconButton size="small">{expanded ? <CollapseIcon /> : <ExpandIcon />}</IconButton>
      </Stack>

      <Collapse in={expanded}>
        <Box sx={{ px: 2, pb: 2, borderTop: 1, borderColor: 'divider' }}>
          <Typography variant="caption" color="text.secondary"
                        sx={{ display: 'block', mt: 1, mb: 1 }}>
            {readOnly
              ? 'Read-only view.  Click Edit at the top to modify overrides.'
              : 'Override global parameters for this step only.  Leave blank to use the global value.'}
          </Typography>
          {schemaKeys.length === 0 ? (
            <Typography variant="caption" color="text.secondary"
                          sx={{ fontStyle: 'italic' }}>
              No configurable fields for this stage.
            </Typography>
          ) : (
            <Stack spacing={1.5}>
              {schemaKeys.map(k => {
                const def = stageManifest?.config_schema?.[k] || {};
                const v = config[k];
                const common = { fullWidth: true, size: 'small' as const };
                if (def.enum) {
                  return (
                    <Box key={k}>
                      <Typography variant="caption" color="text.secondary">{k}</Typography>
                      <Select {...common} value={v ?? ''} displayEmpty
                               disabled={readOnly}
                               onChange={e => {
                                 const next = { ...config };
                                 if (e.target.value === '') delete next[k];
                                 else next[k] = e.target.value;
                                 onChange(next);
                               }}>
                        <MenuItem value="">(use global)</MenuItem>
                        {def.enum.map((o: string) => (
                          <MenuItem key={o} value={o}>{o}</MenuItem>
                        ))}
                      </Select>
                      {def.description && (
                        <Typography variant="caption" color="text.secondary"
                                      sx={{ display: 'block', fontSize: 11 }}>
                          {def.description}
                        </Typography>
                      )}
                    </Box>
                  );
                }
                if (def.type === 'boolean') {
                  return (
                    <FormControlLabel key={k} disabled={readOnly}
                      control={<Switch checked={v === true}
                                        onChange={e => {
                                          const next = { ...config };
                                          if (!e.target.checked && v === undefined) {
                                            delete next[k];
                                          } else {
                                            next[k] = e.target.checked;
                                          }
                                          onChange(next);
                                        }} />}
                      label={`${k}${def.description ? ` — ${def.description}` : ''}`} />
                  );
                }
                if (def.type === 'integer' || def.type === 'number') {
                  return (
                    <TextField key={k} {...common} type="number" label={k}
                                helperText={def.description}
                                value={v ?? ''}
                                disabled={readOnly}
                                onChange={e => {
                                  const next = { ...config };
                                  if (e.target.value === '') delete next[k];
                                  else next[k] = Number(e.target.value);
                                  onChange(next);
                                }} />
                  );
                }
                return (
                  <TextField key={k} {...common} label={k}
                              helperText={def.description}
                              value={v ?? ''}
                              placeholder="(use global)"
                              disabled={readOnly}
                              onChange={e => {
                                const next = { ...config };
                                if (e.target.value === '') delete next[k];
                                else next[k] = e.target.value;
                                onChange(next);
                              }} />
                );
              })}
            </Stack>
          )}
        </Box>
      </Collapse>
    </Paper>
  );
}


// ── Main page ─────────────────────────────────────────────────────────


export default function DataFlowSimpleJobPage() {
  const nav = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();

  const isView = !!id;
  const editMode = !id || searchParams.get('edit') === '1';
  const readOnly = !editMode;

  // ── State ─────────────────────────────────────────────────────────
  const [jobTypes, setJobTypes] = useState<JobType[]>([]);
  const [stageTypes, setStageTypes] = useState<StageTypeManifest[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);

  const [jobTypeId, setJobTypeId] = useState<string>('');
  const [originalDataFlow, setOriginalDataFlow] = useState<DataFlowDef | null>(null);
  const [name, setName] = useState<string>('');
  const [nameStatus, setNameStatus] =
    useState<{ available: boolean; suggestion: string } | null>(null);
  const [description, setDescription] = useState<string>('');

  const [globalParams, setGlobalParams] = useState<KeyValuePair[]>([
    { key: 'business_date', value: '{{business_date}}' },
  ]);

  const [stages, setStages] = useState<StageDef[]>([]);
  const [expandedStep, setExpandedStep] = useState<string | null>(null);

  const [scheduleMode, setScheduleMode] = useState<'none' | 'cron' | 'calendar'>('none');
  const [cron, setCron] = useState('0 9 * * 1-5');
  const [calendarRule, setCalendarRule] = useState<any>({
    type: 'sod', calendar: '', hour: 7, minute: 0,
    skip_non_business_days: true,
  });

  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedJobType = useMemo(
    () => jobTypes.find(j => j.id === jobTypeId), [jobTypes, jobTypeId]);
  const stageTypeMap = useMemo(() => {
    const m: Record<string, StageTypeManifest> = {};
    stageTypes.forEach(t => { m[t.name] = t; });
    return m;
  }, [stageTypes]);

  // ── Initial loads ─────────────────────────────────────────────────

  useEffect(() => {
    api.dataflows.listJobTypes()
      .then(d => setJobTypes(toArray<JobType>(d)))
      .catch(() => {});
    api.dataflows.listStageTypes()
      .then(d => setStageTypes(toArray<StageTypeManifest>(d)))
      .catch(() => {});
    (api as any).listConnections?.().then((cs: unknown) => setConnections(toArray<Connection>(cs)))
      .catch(() => {});
  }, []);

  // ── Load existing DataFlow when viewing/editing ──────────────────

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.dataflows.getDataFlow(Number(id))
      .then(df => {
        setOriginalDataFlow(df);
        setName(df.name);
        setDescription(df.description || '');
        // Inflate default_context into globalParams kv list
        const ctx = df.default_context || {};
        setGlobalParams(Object.entries(ctx).map(([k, v]) => ({ key: k, value: v })));
        setStages((df.stages || []).map(s => ({ ...s })));
      })
      .catch(e => setError(e?.message || 'Failed to load dataflow'))
      .finally(() => setLoading(false));
  }, [id]);

  // ── Load template stages when picking a job type (create mode) ────

  useEffect(() => {
    if (!selectedJobType || isView) return;
    api.dataflows.getTemplate(selectedJobType.template)
      .then((tmpl: any) => {
        setStages((tmpl.stages || []).map((s: any) => ({
          stage_alias:       s.stage_alias,
          stage_type:        s.stage_type,
          seq:               s.seq,
          predecessors:      s.predecessors || [],
          config:            s.config || {},
          retry_policy:      s.retry_policy || {},
          timeout_seconds:   s.timeout_seconds || null,
          on_failure:        s.on_failure || 'halt',
          on_failure_target: s.on_failure_target || null,
        })));
        // Merge template's default_context into our globalParams (only
        // for keys not already set).
        const tctx = tmpl.default_context || {};
        setGlobalParams(prev => {
          const have = new Set(prev.map(p => p.key));
          const additions: KeyValuePair[] = [];
          Object.entries(tctx).forEach(([k, v]) => {
            if (!have.has(k)) additions.push({ key: k, value: v });
          });
          return [...prev, ...additions];
        });
      })
      .catch(() => {});
  }, [selectedJobType, isView]);

  // Suggested name when the user types (create mode only)
  useEffect(() => {
    if (isView || !name) { setNameStatus(null); return; }
    const tid = setTimeout(() => {
      api.dataflows.checkNameAvailable(name).then(setNameStatus).catch(() => {});
    }, 350);
    return () => clearTimeout(tid);
  }, [name, isView]);

  // ── Mutations ─────────────────────────────────────────────────────

  const addGlobalParam = () =>
    setGlobalParams([...globalParams, { key: '', value: '' }]);
  const updateGlobalParam = (i: number, patch: Partial<KeyValuePair>) =>
    setGlobalParams(globalParams.map((p, idx) =>
      idx === i ? { ...p, ...patch } : p));
  const removeGlobalParam = (i: number) =>
    setGlobalParams(globalParams.filter((_, idx) => idx !== i));

  const applyConnection = (role: 'oracle' | 's3' | 'starburst', conn: Connection) => {
    const newKv = applyConnectionToGlobals(conn, role);
    const remove = new Set(newKv.map(p => p.key));
    setGlobalParams([
      ...globalParams.filter(p => !remove.has(p.key)),
      ...newKv,
    ]);
  };

  // ── Save ──────────────────────────────────────────────────────────

  const onSave = async () => {
    setError(null);
    if (!name) { setError('Give your job a name.'); return; }
    if (!isView && !selectedJobType) { setError('Pick a job type first.'); return; }
    if (stages.length === 0) { setError('No stages — pick a job type or use the DAG editor.'); return; }
    setSaving(true);
    try {
      const ctx: Record<string, any> = {};
      globalParams.forEach(p => {
        if (p.key && p.value !== '' && p.value !== undefined) {
          ctx[p.key] = p.value;
        }
      });

      const spec = {
        name,
        description,
        trigger_type: (scheduleMode !== 'none' ? 'cron' : 'manual') as any,
        default_context: ctx,
        stages: stages.map(s => ({
          stage_alias: s.stage_alias,
          stage_type:  s.stage_type,
          seq:         s.seq,
          predecessors: s.predecessors || [],
          config:      s.config || {},
          retry_policy: s.retry_policy || {},
          timeout_seconds: s.timeout_seconds || null,
          on_failure:  s.on_failure || 'halt',
          on_failure_target: s.on_failure_target || null,
        })),
      };

      let savedId: number;
      if (originalDataFlow) {
        const v2 = await api.dataflows.addVersion(originalDataFlow.id, spec as any);
        await api.dataflows.promoteDataFlow(v2.id);
        savedId = v2.id;
      } else {
        const created = await api.dataflows.createDataFlow(spec as any);
        await api.dataflows.promoteDataFlow(created.id);
        savedId = created.id;
      }

      // Schedule (create mode only — for view/edit, schedules are managed
      // separately in /dataflows/schedules)
      if (!isView) {
        if (scheduleMode === 'cron') {
          await api.dataflows.createSchedule({
            dataflow_id:  savedId,
            name:         `${name}_default`,
            cron_expression: cron,
            timezone:     'UTC',
            is_active:    true,
          });
        } else if (scheduleMode === 'calendar') {
          await api.dataflows.createSchedule({
            dataflow_id:  savedId,
            name:         `${name}_default`,
            calendar_rule: calendarRule,
            timezone:     'UTC',
            is_active:    true,
          });
        }
      }

      nav(`/dataflows/simple/${savedId}`);
    } catch (e: any) {
      setError(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  // Phase 133-E follow-up — per-trigger override dialog state.
  // When ANY stage on the dataflow declares Dynamic where-clause rows,
  // we prompt the caller for values before starting the run.  Static
  // rows always apply and don't show here.
  const [overrideRows, setOverrideRows] = useState<DynamicDataflowRow[] | null>(null);
  const [overrideValues, setOverrideValues] = useState<Record<string, any>>({});

  const _fireStartRun = useCallback(async (
    overrides?: Record<string, any>,
  ) => {
    if (!originalDataFlow) return;
    try {
      const context = (overrides && Object.keys(overrides).length)
        ? { _consumer_overrides: overrides }
        : undefined;
      const run = await api.dataflows.startRun(
        originalDataFlow.name,
        context ? { context } : {},
      );
      nav(`/dataflows/runs/${run.id}`);
    } catch (e: any) { setError(e?.message || 'Start failed'); }
  }, [originalDataFlow, nav]);

  const onStartRun = useCallback(async () => {
    if (!originalDataFlow) return;
    const dyn = collectDataflowDynamicRows(originalDataFlow);
    if (dyn.length > 0) {
      const seed: Record<string, any> = {};
      for (const r of dyn) {
        if (r.value !== null && r.value !== undefined && r.value !== '') {
          seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
        }
      }
      setOverrideValues(seed);
      setOverrideRows(dyn);
      return;
    }
    await _fireStartRun();
  }, [originalDataFlow, _fireStartRun]);

  const onConfirmOverrides = useCallback(async () => {
    // Strip empty/null values so a Dynamic row falls back to the
    // publisher's stored default instead of forcing "" into the SQL.
    const overrides: Record<string, any> = {};
    for (const [k, v] of Object.entries(overrideValues)) {
      if (v !== '' && v !== null && v !== undefined) overrides[k] = v;
    }
    setOverrideRows(null);
    await _fireStartRun(overrides);
  }, [overrideValues, _fireStartRun]);

  // ── Render ────────────────────────────────────────────────────────

  if (loading) {
    return <Box sx={{ p: 3 }}><CircularProgress size={22} /></Box>;
  }

  // Toggle to DAG view of the SAME DataFlow
  const toggleToDag = () => {
    if (id) nav(`/dataflows/${id}`);
    else nav('/dataflows/new');
  };

  return (
    <Box sx={{ p: 3, maxWidth: 900, mx: 'auto' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5">
            {isView
              ? (readOnly ? `View: ${originalDataFlow?.name}` : `Edit: ${originalDataFlow?.name}`)
              : 'New ETL Job'}
          </Typography>
          {isView && originalDataFlow && (
            <Typography variant="caption" color="text.secondary">
              v{originalDataFlow.version} · {originalDataFlow.status} · {stages.length} step{stages.length === 1 ? '' : 's'}
            </Typography>
          )}
          {!isView && (
            <Typography variant="caption" color="text.secondary">
              Quick-create from a curated job type.  Same data — view as DAG for the visual layout.
            </Typography>
          )}
        </Box>
        <Stack direction="row" spacing={1} alignItems="center">
          {/* Simple ↔ DAG toggle — same underlying DataFlow */}
          <ButtonGroup size="small" variant="outlined">
            <Button startIcon={<SimpleIcon />} variant="contained" disabled>Simple</Button>
            <Button startIcon={<DagIcon />} onClick={toggleToDag}>DAG</Button>
          </ButtonGroup>
          {isView && readOnly && (
            <>
              <Button startIcon={<EditIcon />}
                       onClick={() => setSearchParams({ edit: '1' })}>Edit</Button>
              {originalDataFlow?.status === 'active' && (
                <Button startIcon={<DagIcon />} variant="contained"
                         onClick={onStartRun}>Run Now</Button>
              )}
            </>
          )}
          {(editMode) && (
            <>
              <Button onClick={() => isView
                ? setSearchParams({})
                : nav('/dataflows/list')}>Cancel</Button>
              <Button startIcon={<SaveIcon />} variant="contained"
                       disabled={saving || !name || stages.length === 0}
                       onClick={onSave}>{saving ? 'Saving…' : 'Save & Activate'}</Button>
            </>
          )}
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {/* Step 1: Job type — only when creating */}
      {!isView && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="overline" color="text.secondary">1 · Job type</Typography>
          <Select fullWidth size="small" value={jobTypeId} displayEmpty
                   onChange={e => setJobTypeId(e.target.value)} sx={{ mt: 1 }}>
            <MenuItem value="" disabled>Pick the ETL pattern that fits your job…</MenuItem>
            {jobTypes.map(j => (
              <MenuItem key={j.id} value={j.id}>
                <Box>
                  <Typography variant="body2">{j.label}</Typography>
                  <Typography variant="caption" color="text.secondary">{j.description}</Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          {selectedJobType && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
              <strong>Category:</strong> {selectedJobType.category} ·
              <strong> Template:</strong> {selectedJobType.template}
            </Typography>
          )}
        </Paper>
      )}

      {/* Step 2: Name */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="overline" color="text.secondary">
          {isView ? 'Name' : '2 · Name your job'}
        </Typography>
        <TextField fullWidth size="small" value={name} sx={{ mt: 1 }}
                    disabled={isView /* name is immutable per version */}
                    placeholder="e.g. my_daily_gl_extract"
                    onChange={e => setName(e.target.value)}
                    error={!!(nameStatus && !nameStatus.available)}
                    helperText={
                      isView ? 'Name is fixed once created. Use Clone to make a copy with a different name.'
                      : !name ? 'Will be globally unique — auto-suffix on conflict.'
                      : nameStatus?.available
                        ? <Stack direction="row" spacing={0.5} alignItems="center">
                            <OkIcon fontSize="inherit" color="success" />
                            <span>"{name}" is available.</span>
                          </Stack>
                      : nameStatus
                        ? <Stack direction="row" spacing={0.5} alignItems="center">
                            <ErrorIcon fontSize="inherit" color="warning" />
                            <span>Taken — will save as "{nameStatus.suggestion}"</span>
                          </Stack>
                      : 'Checking availability…'
                    } />
        <TextField fullWidth size="small" multiline minRows={1} sx={{ mt: 2 }}
                    label="Description (optional)"
                    disabled={readOnly}
                    value={description}
                    onChange={e => setDescription(e.target.value)} />
      </Paper>

      {/* Step 3: Global params */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Typography variant="overline" color="text.secondary">
            {isView ? 'Global parameters' : '3 · Global parameters (shared by all steps)'}
          </Typography>
          {editMode && (
            <Button startIcon={<AddIcon />} size="small" onClick={addGlobalParam}>
              Add parameter
            </Button>
          )}
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, mb: 1 }}>
          Available to every step.  Per-step overrides take precedence.
        </Typography>

        {connections.length > 0 && editMode && (
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <Select size="small" displayEmpty value=""
                     onChange={e => {
                       const conn = connections.find(c => c.id === Number(e.target.value));
                       if (conn) applyConnection('oracle', conn);
                     }}
                     sx={{ minWidth: 220 }}>
              <MenuItem value="" disabled>Auto-fill Oracle connection…</MenuItem>
              {connections.filter(c =>
                (c.connection_type || c.type || '').toLowerCase().includes('oracle'),
              ).map(c => (<MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>))}
            </Select>
            <Select size="small" displayEmpty value=""
                     onChange={e => {
                       const conn = connections.find(c => c.id === Number(e.target.value));
                       if (conn) applyConnection('s3', conn);
                     }}
                     sx={{ minWidth: 220 }}>
              <MenuItem value="" disabled>Auto-fill S3 connection…</MenuItem>
              {connections.filter(c =>
                (c.connection_type || c.type || '').toLowerCase().includes('s3'),
              ).map(c => (<MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>))}
            </Select>
          </Stack>
        )}

        <Stack spacing={1}>
          {globalParams.map((p, i) => (
            <Stack direction="row" spacing={1} key={i}>
              <TextField size="small" label="key" value={p.key}
                          disabled={readOnly}
                          onChange={e => updateGlobalParam(i, { key: e.target.value })}
                          sx={{ minWidth: 220 }} />
              <TextField size="small" label="value" value={p.value ?? ''}
                          disabled={readOnly}
                          onChange={e => updateGlobalParam(i, { value: e.target.value })}
                          fullWidth />
              {editMode && (
                <IconButton size="small" color="error"
                             onClick={() => removeGlobalParam(i)}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              )}
            </Stack>
          ))}
          {globalParams.length === 0 && (
            <Typography variant="caption" color="text.secondary"
                          sx={{ fontStyle: 'italic' }}>
              No global parameters set.
            </Typography>
          )}
        </Stack>
      </Paper>

      {/* Steps with optional overrides */}
      {stages.length > 0 && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="overline" color="text.secondary">
            {isView ? `Steps (${stages.length})` : `4 · Steps & per-step overrides`}
          </Typography>
          <Typography variant="caption" color="text.secondary"
                        sx={{ display: 'block', mt: 0.5, mb: 1 }}>
            Click any step to expand its per-step config.  Steps run in
            the order shown, respecting predecessor edges.
          </Typography>
          {stages.map((s, idx) => (
            <StepCard key={s.stage_alias}
                      step={s}
                      stageManifest={stageTypeMap[s.stage_type]}
                      expanded={expandedStep === s.stage_alias}
                      onToggle={() => setExpandedStep(
                        expandedStep === s.stage_alias ? null : s.stage_alias)}
                      onChange={cfg => setStages(stages.map(
                        x => x.stage_alias === s.stage_alias ? { ...x, config: cfg } : x))}
                      readOnly={readOnly}
                      canMoveUp={idx > 0}
                      canMoveDown={idx < stages.length - 1}
                      onMoveUp={() => setStages(reorderAndRewire(stages, idx, idx - 1))}
                      onMoveDown={() => setStages(reorderAndRewire(stages, idx, idx + 1))}
                      onRemove={() => setStages(removeAndRewire(stages, s.stage_alias))} />
          ))}
        </Paper>
      )}

      {/* Schedule (create mode only — view mode uses /dataflows/schedules) */}
      {!isView && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="overline" color="text.secondary">5 · Schedule (optional)</Typography>
          <Stack direction="row" spacing={2} sx={{ mt: 1 }} alignItems="center">
            <Select size="small" value={scheduleMode}
                     onChange={e => setScheduleMode(e.target.value as any)}
                     sx={{ minWidth: 200 }}>
              <MenuItem value="none">Manual (no schedule)</MenuItem>
              <MenuItem value="cron">Cron expression</MenuItem>
              <MenuItem value="calendar">Business calendar rule</MenuItem>
            </Select>
            {scheduleMode === 'cron' && (
              <TextField size="small" label="Cron (5 fields)" value={cron}
                          onChange={e => setCron(e.target.value)}
                          sx={{ flex: 1 }} />
            )}
          </Stack>
          {scheduleMode === 'calendar' && (
            <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
              <Select size="small" value={calendarRule.type} sx={{ minWidth: 180 }}
                       onChange={e => setCalendarRule({ ...calendarRule, type: e.target.value })}>
                <MenuItem value="daily">Daily Batch — Plain</MenuItem>
                <MenuItem value="sod">Daily Batch — Morning</MenuItem>
                <MenuItem value="eod">Daily Batch — Evening</MenuItem>
                <MenuItem value="workday_n">Workday-N Batch</MenuItem>
                <MenuItem value="month_end">Month-End Batch</MenuItem>
                <MenuItem value="intraday">Intraday Batch</MenuItem>
              </Select>
              <TextField size="small" label="Calendar"
                          value={calendarRule.calendar || ''}
                          onChange={e => setCalendarRule({ ...calendarRule, calendar: e.target.value })}
                          sx={{ flex: 1 }} />
              <TextField size="small" type="number" label="Hour"
                          value={calendarRule.hour}
                          onChange={e => setCalendarRule({ ...calendarRule, hour: Number(e.target.value) })}
                          sx={{ width: 80 }} />
              <TextField size="small" type="number" label="Min"
                          value={calendarRule.minute}
                          onChange={e => setCalendarRule({ ...calendarRule, minute: Number(e.target.value) })}
                          sx={{ width: 80 }} />
              {calendarRule.type === 'workday_n' && (
                <TextField size="small" type="number" label="N"
                            value={calendarRule.n || 1}
                            onChange={e => setCalendarRule({ ...calendarRule, n: Number(e.target.value) })}
                            sx={{ width: 70 }} />
              )}
            </Stack>
          )}
        </Paper>
      )}

      {/* ── Phase 133-E follow-up — DataFlow run override dialog.
          Opens automatically when the user clicks "Run" on a flow
          that has stages with Dynamic where-clause rows.  Static
          rows always apply and are surfaced as read-only context. ─ */}
      <DataflowOverrideDialog
        dataflowName={overrideRows ? (originalDataFlow?.name || null) : null}
        rows={overrideRows || []}
        values={overrideValues}
        onValuesChange={setOverrideValues}
        onCancel={() => setOverrideRows(null)}
        onConfirm={onConfirmOverrides}
        connectionIdByRow={(r) => r.connectionId ?? null}
        tableByRow={(r) => r.table ?? null}
      />
    </Box>
  );
}
