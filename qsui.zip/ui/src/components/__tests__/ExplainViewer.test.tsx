/**
 * Phase 138 — ExplainViewer dialog tests.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import ExplainViewer from '../ExplainViewer';

const SAMPLE_RESPONSE = {
  available: true,
  plan_text: '┌───────────────────────────┐\n│       PROJECTION          │\n│   ~1000 rows              │\n└───────────────────────────┘',
  operators: [
    { name: 'PROJECTION', rows_estimate: 1000, indent: 0 },
    { name: 'PARQUET_SCAN', rows_estimate: 5000, indent: 1 },
  ],
  analyzed: false,
};

describe('ExplainViewer', () => {
  it('does not render when closed', () => {
    render(<ExplainViewer open={false} onClose={vi.fn()} sql="SELECT 1" />);
    expect(screen.queryByText(/query plan/i)).not.toBeInTheDocument();
  });

  it('renders operator list from API response when opened', async () => {
    server.use(
      http.post('*/api/execute/explain', () => HttpResponse.json(SAMPLE_RESPONSE)),
    );
    render(<ExplainViewer open={true} onClose={vi.fn()} sql="SELECT * FROM t" />);
    await waitFor(() => {
      expect(screen.getByText(/PROJECTION/)).toBeInTheDocument();
    });
    expect(screen.getByText(/PARQUET_SCAN/)).toBeInTheDocument();
  });

  it('shows row-estimate chips formatted as 1K / 1M', async () => {
    server.use(
      http.post('*/api/execute/explain', () => HttpResponse.json(SAMPLE_RESPONSE)),
    );
    render(<ExplainViewer open={true} onClose={vi.fn()} sql="SELECT 1" />);
    await waitFor(() => screen.getByText(/PROJECTION/));
    // 1000 → "1K", 5000 → "5K"
    expect(screen.getByText(/1K rows/)).toBeInTheDocument();
    expect(screen.getByText(/5K rows/)).toBeInTheDocument();
  });

  it('toggles between EXPLAIN and ANALYZE modes', async () => {
    let calledAnalyze = false;
    server.use(
      http.post('*/api/execute/explain', async ({ request }) => {
        const body = await request.json() as any;
        calledAnalyze = !!body.analyze;
        return HttpResponse.json({ ...SAMPLE_RESPONSE, analyzed: !!body.analyze });
      }),
    );
    render(<ExplainViewer open={true} onClose={vi.fn()} sql="SELECT 1" />);
    await waitFor(() => screen.getByText(/PROJECTION/));

    expect(calledAnalyze).toBe(false);

    // ToggleButton accessible name is the value, not the visible text — find by text content
    const analyzeBtn = screen.getAllByText(/ANALYZE/i).find(el => el.tagName === 'BUTTON');
    if (analyzeBtn) await userEvent.click(analyzeBtn);
    await waitFor(() => expect(calledAnalyze).toBe(true));
  });

  it('shows error message when API returns available:false', async () => {
    server.use(
      http.post('*/api/execute/explain', () =>
        HttpResponse.json({ available: false, reason: 'Catalog Error: table not found' })
      ),
    );
    render(<ExplainViewer open={true} onClose={vi.fn()} sql="SELECT * FROM bad" />);
    await waitFor(() => {
      expect(screen.getByText(/table not found/i)).toBeInTheDocument();
    });
  });

  it('toggles raw plan text via "Show raw plan" button', async () => {
    server.use(
      http.post('*/api/execute/explain', () => HttpResponse.json(SAMPLE_RESPONSE)),
    );
    render(<ExplainViewer open={true} onClose={vi.fn()} sql="SELECT 1" />);
    await waitFor(() => screen.getByText(/PROJECTION/));
    // Raw plan hidden by default
    expect(screen.queryByText(/┌───/)).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: /show raw plan/i }));
    expect(screen.getByText(/┌───/)).toBeInTheDocument();
  });

  it('calls onClose when close button is clicked', async () => {
    server.use(
      http.post('*/api/execute/explain', () => HttpResponse.json(SAMPLE_RESPONSE)),
    );
    const onClose = vi.fn();
    render(<ExplainViewer open={true} onClose={onClose} sql="SELECT 1" />);
    await waitFor(() => screen.getByText(/PROJECTION/));
    await userEvent.click(screen.getByRole('button', { name: /^close$/i }));
    expect(onClose).toHaveBeenCalled();
  });
});
