/**
 * Phase 133 — ReconciliationPage smoke tests.
 *
 * Verifies the page renders, the table shows entities returned by the
 * API mock, the New-Report dialog opens, and the per-row Check + Reload
 * + History buttons fire the expected api method.  Uses ``vi.mock`` to
 * stub the api client so the test doesn't hit the network.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';


// Vitest hoists ``vi.mock`` above any imports, so the mock object
// MUST live inside the factory closure to avoid the
// "Cannot access 'mockApi' before initialization" reference error.
vi.mock('../../services/api', () => {
  const mock = {
    reconciliation: {
      dashboard:   vi.fn(),
      list:        vi.fn(),
      get:         vi.fn(),
      create:      vi.fn(),
      update:      vi.fn(),
      deactivate:  vi.fn(),
      runs:        vi.fn(),
      checkNow:    vi.fn(),
      reloadNow:   vi.fn(),
    },
    listConnections: vi.fn(),
    sqlFiles:        { list: vi.fn() },
  };
  return { default: mock };
});


import ReconciliationPage from '../ReconciliationPage';
import api from '../../services/api';
const mockApi = api as unknown as {
  reconciliation: Record<string, ReturnType<typeof vi.fn>>;
  listConnections: ReturnType<typeof vi.fn>;
  sqlFiles: { list: ReturnType<typeof vi.fn> };
};


function _wrap() {
  return (
    <MemoryRouter>
      <ReconciliationPage />
    </MemoryRouter>
  );
}


beforeEach(() => {
  Object.values(mockApi.reconciliation).forEach((fn: any) => fn.mockReset());
  mockApi.listConnections.mockReset();
  mockApi.sqlFiles.list.mockReset();

  mockApi.reconciliation.list.mockResolvedValue([]);
  mockApi.listConnections.mockResolvedValue([
    { id: 1, name: 'starburst_prod', connection_type: 'starburst' },
    { id: 2, name: 'oracle_dest',     connection_type: 'oracle' },
    { id: 3, name: 'oracle_etl',      connection_type: 'oracle' },
  ]);
  mockApi.sqlFiles.list.mockResolvedValue([]);
});


describe('ReconciliationPage', () => {
  it('renders the page header + tabs', async () => {
    render(_wrap());
    await waitFor(() =>
      expect(screen.getByText(/Reconciliation Reports/i)).toBeTruthy());
    expect(screen.getByRole('button', { name: /New Report/i })).toBeTruthy();
    expect(screen.getByRole('tab', { name: /Dashboard/i })).toBeTruthy();
    expect(screen.getByRole('tab', { name: /Configuration/i })).toBeTruthy();
  });

  it('shows the empty state when no entities exist', async () => {
    render(_wrap());
    await waitFor(() =>
      expect(screen.getByText(/No reconciliation reports yet/i)).toBeTruthy());
  });

  it('lists entities returned by the API', async () => {
    mockApi.reconciliation.list.mockResolvedValueOnce([
      { id: 1, name: 'fact_table_recon', description: 'FACT_TABLE vs Oracle',
        is_active: true, comparison_mode: 'row_by_row',
        source_connection_id: 1, dest_connection_id: 2,
        comparison_columns: [], key_columns: [],
        max_rows_compared: 50000, tolerance: 0, tolerance_pct: 0,
        dag_ids: [], business_date_template: '{{business_date}}',
        auto_reload_on_break: false, schedule_enabled: true,
        check_interval_hours: 2,
        last_status: 'ok', last_source_row_count: 100, last_dest_row_count: 100 },
    ]);
    render(_wrap());
    await waitFor(() =>
      expect(screen.getByText('fact_table_recon')).toBeTruthy());
    expect(screen.getByText(/FACT_TABLE vs Oracle/)).toBeTruthy();
    expect(screen.getByText('OK')).toBeTruthy();
  });

  it('opens the New Report dialog', async () => {
    render(_wrap());
    await waitFor(() =>
      expect(screen.getByRole('button', { name: /New Report/i })).toBeTruthy());
    fireEvent.click(screen.getByRole('button', { name: /New Report/i }));
    await waitFor(() =>
      expect(screen.getByText(/New Reconciliation Report/i)).toBeTruthy());
    // Connection picker labels appear at LEAST once each (MUI duplicates
    // labels into the floating-label slot + the legend, so just confirm
    // presence rather than count).
    expect(screen.getAllByText(/Source connection/i).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/Destination connection/i).length)
      .toBeGreaterThan(0);
    expect(screen.getByText(/Save changes|Create report/i)).toBeTruthy();
  });

  it('Check Now button fires api.reconciliation.checkNow', async () => {
    mockApi.reconciliation.list.mockResolvedValueOnce([
      { id: 7, name: 'r', is_active: true, comparison_mode: 'row_count',
        source_connection_id: 1, dest_connection_id: 2,
        comparison_columns: [], key_columns: [],
        max_rows_compared: 50000, tolerance: 0, tolerance_pct: 0,
        dag_ids: [], business_date_template: '{{business_date}}',
        auto_reload_on_break: false, schedule_enabled: true,
        check_interval_hours: 2 },
    ]);
    mockApi.reconciliation.checkNow.mockResolvedValueOnce(
      { run: { id: 1, status: 'completed', break_detected: false } as any,
        break_detected: false });

    render(_wrap());
    await waitFor(() => expect(screen.getByText('r')).toBeTruthy());

    const checkBtn = screen.getAllByRole('button').find(
      (b) => b.getAttribute('aria-label')?.includes('Check')
        || b.querySelector('[data-testid="PlayArrowIcon"]') !== null,
    );
    if (checkBtn) fireEvent.click(checkBtn);
    await waitFor(() =>
      expect(mockApi.reconciliation.checkNow).toHaveBeenCalled());
  });

  it('Reload button is hidden when no etl_connection_id', async () => {
    mockApi.reconciliation.list.mockResolvedValueOnce([
      { id: 1, name: 'no_reload', is_active: true,
        comparison_mode: 'row_count',
        source_connection_id: 1, dest_connection_id: 2,
        etl_connection_id: null, dag_ids: [],
        comparison_columns: [], key_columns: [],
        max_rows_compared: 50000, tolerance: 0, tolerance_pct: 0,
        business_date_template: '{{business_date}}',
        auto_reload_on_break: false, schedule_enabled: true,
        check_interval_hours: 2 },
    ]);
    render(_wrap());
    await waitFor(() => expect(screen.getByText('no_reload')).toBeTruthy());
    // No Reload-tooltip button rendered.
    expect(screen.queryByRole('button', { name: /Reload/i })).toBeNull();
  });
});
