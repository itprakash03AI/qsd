/**
 * Phase 136 — AgentSuggestionInline render + interaction tests.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AgentSuggestionInline from '../AgentSuggestionInline';

describe('AgentSuggestionInline', () => {
  it('renders nothing when suggestion is null', () => {
    const { container } = render(
      <AgentSuggestionInline suggestion={null} />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it('renders nothing when suggestion has no strategy', () => {
    const { container } = render(
      <AgentSuggestionInline
        suggestion={{ agent: 'query_resilience', strategy: '' } as any}
      />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it('renders the friendly label for known strategies', () => {
    render(
      <AgentSuggestionInline
        suggestion={{
          agent: 'query_resilience',
          strategy: 'add_partition_filter',
          reason: 'Query scans every partition.',
        }}
      />
    );
    expect(screen.getByText(/add partition filter/i)).toBeInTheDocument();
    expect(screen.getByText(/scans every partition/i)).toBeInTheDocument();
  });

  it('falls back to a humanised label for unknown strategies', () => {
    render(
      <AgentSuggestionInline
        suggestion={{
          agent: 'query_resilience',
          strategy: 'unknown_thing_here',
        }}
      />
    );
    // strategy name with underscores → spaces
    expect(screen.getByText(/unknown thing here/i)).toBeInTheDocument();
  });

  it('shows the action button only for actionable strategies', () => {
    const { rerender } = render(
      <AgentSuggestionInline
        suggestion={{ agent: 'a', strategy: 'reduce_memory' }}
        onApply={vi.fn()}
      />
    );
    // reduce_memory is not actionable — no button
    expect(screen.queryByRole('button')).not.toBeInTheDocument();

    rerender(
      <AgentSuggestionInline
        suggestion={{ agent: 'a', strategy: 'add_partition_filter' }}
        onApply={vi.fn()}
      />
    );
    expect(screen.getByRole('button', { name: /add filter/i })).toBeInTheDocument();
  });

  it('calls onApply with the suggestion when the button is clicked', async () => {
    const onApply = vi.fn();
    const suggestion = {
      agent: 'query_resilience',
      strategy: 'retry_with_backoff',
      reason: 'Transient network error',
    };
    render(<AgentSuggestionInline suggestion={suggestion} onApply={onApply} />);

    await userEvent.click(screen.getByRole('button', { name: /retry/i }));
    expect(onApply).toHaveBeenCalledTimes(1);
    expect(onApply).toHaveBeenCalledWith(suggestion);
  });

  it('renders CTE analysis chips when present', () => {
    render(
      <AgentSuggestionInline
        suggestion={{
          agent: 'query_resilience',
          strategy: 'add_partition_filter',
          cte_analysis: [
            { table: 'orders', missing_partition_columns: ['dt'] },
            { table: 'shipments', missing_partition_columns: ['region', 'dt'] },
          ],
        }}
      />
    );
    expect(screen.getByText(/orders: dt/i)).toBeInTheDocument();
    expect(screen.getByText(/shipments: region, dt/i)).toBeInTheDocument();
  });

  it('has an AI badge so users know the suggestion is auto-generated', () => {
    render(
      <AgentSuggestionInline
        suggestion={{ agent: 'query_resilience', strategy: 'reduce_memory' }}
      />
    );
    expect(screen.getByText('AI')).toBeInTheDocument();
  });

  // BF-288: regression — qualify_ambiguous_columns must show the
  // Auto-fix SQL button (was falling through to FALLBACK_DETAIL with
  // actionable=false → no button → users complained "I don't see the
  // auto-fix button on BQB").
  it('shows Auto-fix SQL button for qualify_ambiguous_columns strategy', () => {
    const onApply = vi.fn();
    render(
      <AgentSuggestionInline
        suggestion={{
          agent: 'query_resilience',
          strategy: 'qualify_ambiguous_columns',
          reason: 'Column "sap_company_id" exists in 2+ tables.',
        }}
        onApply={onApply}
      />
    );
    expect(screen.getByText(/qualify ambiguous columns/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /auto-fix sql/i })).toBeInTheDocument();
  });

  // BF-288: regression — add_group_by also must show the button.
  it('shows Auto-fix SQL button for add_group_by strategy', () => {
    render(
      <AgentSuggestionInline
        suggestion={{
          agent: 'query_resilience',
          strategy: 'add_group_by',
        }}
        onApply={vi.fn()}
      />
    );
    expect(screen.getByRole('button', { name: /auto-fix sql/i })).toBeInTheDocument();
  });
});
