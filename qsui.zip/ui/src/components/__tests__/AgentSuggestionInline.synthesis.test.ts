/**
 * BF-243 unit test — client-side error pattern recognition for agent
 * suggestion synthesis when the backend agent is disabled.
 *
 * The actual logic is inline in BQB / CQB execution_failed handlers; this
 * test pins the regex contract so a future refactor can't silently break
 * the auto-fix button when agents.enabled=false.
 */
import { describe, it, expect } from 'vitest';

const PATTERN = /must appear in the group by clause|must be part of an aggregate function/;

describe('BF-243: client-side GROUP BY error recognition', () => {
  it('matches the literal DuckDB BinderError text', () => {
    const err = 'Binder Error: column "product_id" must appear in the GROUP BY clause or must be part of an aggregate function.';
    expect(PATTERN.test(err.toLowerCase())).toBe(true);
  });

  it('matches the alternative wording', () => {
    const err = 'or it must be part of an aggregate function';
    expect(PATTERN.test(err.toLowerCase())).toBe(true);
  });

  it('does not match unrelated errors', () => {
    expect(PATTERN.test('connection refused')).toBe(false);
    expect(PATTERN.test('table not found')).toBe(false);
    expect(PATTERN.test('expired token')).toBe(false);
  });

  it('case-insensitive (input must be lowercased)', () => {
    const err = 'BINDER ERROR: column X MUST APPEAR IN THE GROUP BY CLAUSE';
    expect(PATTERN.test(err.toLowerCase())).toBe(true);
  });
});
