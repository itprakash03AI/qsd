/**
 * Phase 136 — ColumnStatsSidebar render + data loading tests.
 *
 * Uses MSW to mock the column-stats endpoint so the component can be tested
 * without a real backend.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import ColumnStatsSidebar from '../ColumnStatsSidebar';

const SAMPLE_RESPONSE = {
  available: true,
  execution_id: 'exec-123',
  row_count: 50,
  columns: [
    {
      name: 'amount', type: 'DOUBLE',
      null_count: 0, distinct_count: 50, total: 50,
      min: 0.0, max: 73.5, mean: 36.75, median: 36.75,
      histogram: [
        { bucket: '0–7.4', count: 5 },
        { bucket: '7.4–14.7', count: 5 },
      ],
    },
    {
      name: 'region', type: 'VARCHAR',
      null_count: 5, distinct_count: 2, total: 50,
      top_values: [
        { value: 'US', count: 30 },
        { value: 'UK', count: 15 },
      ],
    },
    {
      name: 'is_paid', type: 'BOOLEAN',
      null_count: 0, distinct_count: 2, total: 50,
      true_count: 25, false_count: 25,
    },
  ],
};

describe('ColumnStatsSidebar', () => {
  it('does not load data when closed', async () => {
    let fetchCalled = false;
    server.use(
      http.get('*/api/executions/exec-closed/column-stats', () => {
        fetchCalled = true;
        return HttpResponse.json(SAMPLE_RESPONSE);
      })
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-closed"
        open={false}
        onClose={vi.fn()}
      />
    );
    // Wait a tick to be sure no fetch fires
    await new Promise(r => setTimeout(r, 50));
    expect(fetchCalled).toBe(false);
  });

  it('shows loading skeletons while fetching', async () => {
    server.use(
      http.get('*/api/executions/exec-123/column-stats', async () => {
        await new Promise(r => setTimeout(r, 100));
        return HttpResponse.json(SAMPLE_RESPONSE);
      })
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-123"
        open={true}
        onClose={vi.fn()}
      />
    );
    // Skeleton elements rendered before fetch resolves
    expect(screen.getByTestId('column-stats-sidebar')).toBeInTheDocument();
  });

  it('renders all columns with their stats from the API', async () => {
    server.use(
      http.get('*/api/executions/exec-123/column-stats', () =>
        HttpResponse.json(SAMPLE_RESPONSE)
      )
    );

    render(
      <ColumnStatsSidebar
        executionId="exec-123"
        open={true}
        onClose={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('amount')).toBeInTheDocument();
    });
    expect(screen.getByText('region')).toBeInTheDocument();
    expect(screen.getByText('is_paid')).toBeInTheDocument();
    // Row count chip
    expect(screen.getByText(/50 rows/i)).toBeInTheDocument();
  });

  it('shows top values for categorical columns', async () => {
    server.use(
      http.get('*/api/executions/exec-123/column-stats', () =>
        HttpResponse.json(SAMPLE_RESPONSE)
      )
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-123"
        open={true}
        onClose={vi.fn()}
      />
    );
    await waitFor(() => {
      expect(screen.getByText('US')).toBeInTheDocument();
    });
    expect(screen.getByText('UK')).toBeInTheDocument();
  });

  it('filters columns by name when user types in the filter box', async () => {
    server.use(
      http.get('*/api/executions/exec-123/column-stats', () =>
        HttpResponse.json(SAMPLE_RESPONSE)
      )
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-123"
        open={true}
        onClose={vi.fn()}
      />
    );

    await waitFor(() => screen.getByText('region'));

    const filter = screen.getByPlaceholderText(/filter columns/i);
    await userEvent.type(filter, 'amount');

    expect(screen.getByText('amount')).toBeInTheDocument();
    expect(screen.queryByText('region')).not.toBeInTheDocument();
    expect(screen.queryByText('is_paid')).not.toBeInTheDocument();
  });

  it('calls onClose when the close button is clicked', async () => {
    server.use(
      http.get('*/api/executions/exec-123/column-stats', () =>
        HttpResponse.json(SAMPLE_RESPONSE)
      )
    );
    const onClose = vi.fn();
    render(
      <ColumnStatsSidebar
        executionId="exec-123"
        open={true}
        onClose={onClose}
      />
    );
    await waitFor(() => screen.getByText('amount'));

    // Find close button by aria-label / icon — use the Tooltip title text
    const closeBtn = screen.getByRole('button', { name: /close/i });
    await userEvent.click(closeBtn);
    expect(onClose).toHaveBeenCalled();
  });

  it('shows the reason when stats are not available', async () => {
    server.use(
      http.get('*/api/executions/exec-pending/column-stats', () =>
        HttpResponse.json({ available: false, reason: 'execution status: pending' })
      )
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-pending"
        open={true}
        onClose={vi.fn()}
      />
    );
    await waitFor(() => {
      expect(screen.getByText(/execution status: pending/i)).toBeInTheDocument();
    });
  });

  it('shows error message when API call fails', async () => {
    server.use(
      http.get('*/api/executions/exec-error/column-stats', () =>
        HttpResponse.json({ detail: 'boom' }, { status: 500 })
      )
    );
    render(
      <ColumnStatsSidebar
        executionId="exec-error"
        open={true}
        onClose={vi.fn()}
      />
    );
    await waitFor(() => {
      // Error text shown — the exact message comes from response body
      expect(screen.queryByText('amount')).not.toBeInTheDocument();
    });
  });
});
