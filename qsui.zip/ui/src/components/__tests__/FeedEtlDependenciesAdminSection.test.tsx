/**
 * FeedEtlDependenciesAdminSection — render + interaction tests.
 *
 * Phase 131-A.  Covers:
 *   1. Initial load of dependency-type catalogue + poll-status.
 *   2. Add-type form submits POST + reloads.
 *   3. Tracking record form submits + reloads poll status.
 *   4. WAIT vs RUN chip rendering on the poll-status table.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import FeedEtlDependenciesAdminSection from '../admin/FeedEtlDependenciesAdminSection';

const TYPES_FIXTURE = [
  { id: 1, dependency_type: 'KAFKA', description: 'Kafka topic', is_active: true },
  { id: 2, dependency_type: 'ORACLE_TABLE', description: 'Oracle table', is_active: true },
];

const POLL_FIXTURE = [
  { id: 100, feed_config_id: 7, etl_id: 7, business_date: '2026-05-16',
    action_decision: 'WAIT', action_reason: 'waiting on topic.x' },
  { id: 101, feed_config_id: 8, etl_id: 8, business_date: '2026-05-16',
    action_decision: 'RUN', action_reason: 'deps ready (2 complete)' },
];

describe('FeedEtlDependenciesAdminSection', () => {
  it('lists dependency types and poll rows on load', async () => {
    server.use(
      http.get('*/api/admin/etl-dependencies/types',
                () => HttpResponse.json({ items: TYPES_FIXTURE })),
      http.get('*/api/admin/etl-dependencies/poll-status',
                () => HttpResponse.json({ items: POLL_FIXTURE, count: POLL_FIXTURE.length })),
    );
    render(<FeedEtlDependenciesAdminSection />);

    // Both catalogue rows render
    await waitFor(() => expect(screen.getByText('KAFKA')).toBeInTheDocument());
    expect(screen.getByText('ORACLE_TABLE')).toBeInTheDocument();

    // Poll table shows the two pending feed_runs
    expect(screen.getByText('waiting on topic.x')).toBeInTheDocument();
    expect(screen.getByText('deps ready (2 complete)')).toBeInTheDocument();
  });

  it('renders WAIT chip in warning color and RUN in success', async () => {
    server.use(
      http.get('*/api/admin/etl-dependencies/types',
                () => HttpResponse.json({ items: TYPES_FIXTURE })),
      http.get('*/api/admin/etl-dependencies/poll-status',
                () => HttpResponse.json({ items: POLL_FIXTURE, count: 2 })),
    );
    render(<FeedEtlDependenciesAdminSection />);
    await waitFor(() => expect(screen.getByText('WAIT')).toBeInTheDocument());
    // Both chips render
    expect(screen.getByText('WAIT')).toBeInTheDocument();
    expect(screen.getByText('RUN')).toBeInTheDocument();
  });

  it('submits add-type POST and reloads catalogue', async () => {
    const seenPosts: any[] = [];
    server.use(
      http.get('*/api/admin/etl-dependencies/types',
                () => HttpResponse.json({ items: TYPES_FIXTURE })),
      http.get('*/api/admin/etl-dependencies/poll-status',
                () => HttpResponse.json({ items: [], count: 0 })),
      http.post('*/api/admin/etl-dependencies/types', async ({ request }) => {
        seenPosts.push(await request.json());
        return HttpResponse.json({ id: 3, dependency_type: 'FILE', is_active: true });
      }),
    );
    render(<FeedEtlDependenciesAdminSection />);
    await waitFor(() => expect(screen.getByText('KAFKA')).toBeInTheDocument());

    const user = userEvent.setup();
    const typeInput = screen.getByLabelText(/New type name/i);
    await user.type(typeInput, 'file');
    await user.click(screen.getByRole('button', { name: /Add \/ Update/i }));

    await waitFor(() => expect(seenPosts.length).toBe(1));
    // Backend receives the uppercased name (UI normalises)
    expect(seenPosts[0].dependency_type).toBe('FILE');
  });

  it('submits tracking record POST', async () => {
    const seenPosts: any[] = [];
    server.use(
      http.get('*/api/admin/etl-dependencies/types',
                () => HttpResponse.json({ items: TYPES_FIXTURE })),
      http.get('*/api/admin/etl-dependencies/poll-status',
                () => HttpResponse.json({ items: [], count: 0 })),
      http.post('*/api/admin/etl-dependencies/tracking', async ({ request }) => {
        seenPosts.push(await request.json());
        return HttpResponse.json({ id: 1, action: 'COMPLETE' });
      }),
    );
    render(<FeedEtlDependenciesAdminSection />);
    await waitFor(() => expect(screen.getByText('KAFKA')).toBeInTheDocument());

    const user = userEvent.setup();
    // Pick KAFKA in the tracking-form type select (the second instance —
    // first is on the add-type form which is a TextField, not a Select).
    // userEvent.selectOptions targets a <select>; MUI Select renders a
    // listbox so we click + then pick the menu option.
    const selects = screen.getAllByRole('combobox');
    // The first combobox is the tracking-type select (the add-type form
    // uses a TextField).  Click to open + select KAFKA.
    await user.click(selects[0]);
    await user.click(await screen.findByRole('option', { name: 'KAFKA' }));

    await user.type(screen.getByLabelText(/Dependency key/i), 'topic.daily');
    await user.click(screen.getByRole('button', { name: /^Record$/i }));

    await waitFor(() => expect(seenPosts.length).toBe(1));
    expect(seenPosts[0].dependency_key).toBe('topic.daily');
    expect(seenPosts[0].action).toBe('COMPLETE');
  });
});
