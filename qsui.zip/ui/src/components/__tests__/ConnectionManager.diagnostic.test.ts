/**
 * 2026-06-16 — guard that ConnectionManager surfaces the [DIAG] block
 * from a connection-test failure.
 *
 * Backstory: the backend (s3_storage._diagnose_endpoint_failure) now
 * emits a multi-line diagnostic on TCP/DNS-layer failures, and the
 * connection_manager wrapper forwards it as `testResult.diagnostic`.
 * Before this commit the frontend's test-result Alert only rendered
 * `testResult.message` — the diagnostic was silently dropped.  This
 * static guard pins the render so a future refactor that drops the
 * diagnostic block triggers a failing test instead of disappearing
 * into the void.
 *
 * Implemented as a source-text grep instead of a full render test:
 *   - ConnectionManager is a 2500-line component with many providers
 *   - the guard's purpose is "the source still references this field"
 *   - full render coverage would be brittle (Material-UI Dialog + many
 *     deps) without proving more than the grep proves
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { resolve } from 'path';

describe('ConnectionManager — diagnostic field render', () => {
  const src = readFileSync(
    resolve(__dirname, '../ConnectionManager.tsx'),
    'utf-8'
  );

  it('renders testResult.diagnostic when the backend returns one', () => {
    expect(src).toContain('testResult.diagnostic');
  });

  it('uses a monospace block for the diagnostic (preserves [DIAG] formatting)', () => {
    // The [DIAG] block is multi-line and indented; a regular paragraph
    // would collapse whitespace.  `Box component="pre"` + monospace font
    // is the safe rendering choice.
    const idx = src.indexOf('testResult.diagnostic');
    expect(idx).toBeGreaterThan(-1);
    // Look on both sides of the occurrence — JSX may place the pre
    // wrapper before OR after the {testResult.diagnostic} expression.
    const region = src.slice(Math.max(0, idx - 800), idx + 800);
    expect(region).toContain('monospace');
    expect(region).toMatch(/component="pre"|component={'pre'}/);
  });

  it('preserves whitespace so the multi-line block is readable', () => {
    const idx = src.indexOf('testResult.diagnostic');
    const region = src.slice(Math.max(0, idx - 800), idx + 800);
    // pre-wrap is the rule that lets long DNS hostnames soft-wrap while
    // preserving line breaks; without it long URLs break the dialog.
    expect(region).toContain('pre-wrap');
  });
});
