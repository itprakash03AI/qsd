/**
 * MyGroupsPage — render + access-level display tests.
 *
 * Phase 130 hotfix-13.  End-user page showing which entitlement
 * groups the current user belongs to and at what access level.
 */
import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import MyGroupsPage from '../MyGroupsPage';

const GROUPS = [
  {
    id: 1, name: 'ops_team', description: 'Ops on-call',
    is_active: true,
    notification_email: 'ops@example.com',
    role_in_group: 'member',
    resource_access_level: 'read_write',
    added_at: '2026-05-01T08:00:00+00:00',
  },
  {
    id: 2, name: 'finance_readers', description: 'Finance audit folks',
    is_active: true,
    notification_email: null,
    role_in_group: 'member',
    resource_access_level: 'read_only',
    added_at: '2026-05-02T08:00:00+00:00',
  },
];

describe('MyGroupsPage', () => {
  it('shows empty-state when user has no groups', async () => {
    server.use(
      http.get('*/api/user-groups/my', () => HttpResponse.json([])),
    );
    render(<MyGroupsPage />);
    await waitFor(() =>
      expect(screen.getByText(/not in any entitlement groups yet/i)).toBeInTheDocument()
    );
  });

  it('renders each group with name + description', async () => {
    server.use(
      http.get('*/api/user-groups/my', () => HttpResponse.json(GROUPS)),
    );
    render(<MyGroupsPage />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());
    expect(screen.getByText('finance_readers')).toBeInTheDocument();
    expect(screen.getByText('Ops on-call')).toBeInTheDocument();
    expect(screen.getByText('Finance audit folks')).toBeInTheDocument();
  });

  it('renders read-write vs read-only chips per access level', async () => {
    server.use(
      http.get('*/api/user-groups/my', () => HttpResponse.json(GROUPS)),
    );
    render(<MyGroupsPage />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());
    // Both chips render via filled MUI Chip — text is visible
    expect(screen.getByText('read-write')).toBeInTheDocument();
    expect(screen.getByText('read-only')).toBeInTheDocument();
  });

  it('surfaces group notification email when present', async () => {
    server.use(
      http.get('*/api/user-groups/my', () => HttpResponse.json(GROUPS)),
    );
    render(<MyGroupsPage />);
    await waitFor(() => expect(screen.getByText('ops@example.com')).toBeInTheDocument());
  });

  it('handles API error without crashing', async () => {
    server.use(
      http.get('*/api/user-groups/my', () =>
        HttpResponse.json({ detail: 'boom' }, { status: 500 })),
    );
    render(<MyGroupsPage />);
    await waitFor(() => expect(screen.getByText('My Groups')).toBeInTheDocument());
    // Error gets rendered via MUI Alert (severity=error).
    await waitFor(() => {
      const alerts = document.querySelectorAll('.MuiAlert-root');
      expect(alerts.length).toBeGreaterThan(0);
    });
  });
});
