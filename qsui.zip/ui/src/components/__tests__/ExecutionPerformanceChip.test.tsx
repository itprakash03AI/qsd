/**
 * BF-297 — ExecutionPerformanceChip render + interaction tests.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import ExecutionPerformanceChip from '../ExecutionPerformanceChip';

const mockExecution = {
  execution_id: 'exec-test-001',
  status: 'completed',
  files_metadata: {
    stage_history: {
      total_seconds: 14.8,
      stages: [
        { stage: 'metadata_read',     stage_label: 'Reading Iceberg metadata',  duration_seconds: 0.2 },
        { stage: 'manifest_prune',    stage_label: 'Pruning manifest files',    duration_seconds: 0.1 },
        { stage: 'boto3_predownload', stage_label: 'Downloading files from S3', duration_seconds: 12.0 },
        { stage: 'duckdb_execute',    stage_label: 'Executing SQL',             duration_seconds: 2.0 },
        { stage: 'parquet_write',     stage_label: 'Writing result file',       duration_seconds: 0.5 },
      ],
      extras: {
        iceberg_cache_hit: true,
        iceberg_manifests_read: 29,
      },
    },
  },
};

beforeEach(() => {
  server.use(
    http.get('*/api/executions/exec-test-001', () => HttpResponse.json(mockExecution)),
  );
});

describe('ExecutionPerformanceChip', () => {
  it('renders the chip with total duration + step count', async () => {
    render(<ExecutionPerformanceChip executionId="exec-test-001" />);
    // Match for "14.8s · 5 steps"
    expect(await screen.findByText(/14\.8s.*5 steps/)).toBeInTheDocument();
  });

  it('opens the popover with stage breakdown when clicked', async () => {
    const user = userEvent.setup();
    render(<ExecutionPerformanceChip executionId="exec-test-001" />);
    const chip = await screen.findByText(/14\.8s/);
    await user.click(chip);
    await waitFor(() => {
      expect(screen.getByText('Reading Iceberg metadata')).toBeInTheDocument();
      expect(screen.getByText('Downloading files from S3')).toBeInTheDocument();
      expect(screen.getByText('Executing SQL')).toBeInTheDocument();
    });
  });

  it('shows extras (iceberg_cache_hit etc.)', async () => {
    const user = userEvent.setup();
    render(<ExecutionPerformanceChip executionId="exec-test-001" />);
    const chip = await screen.findByText(/14\.8s/);
    await user.click(chip);
    await waitFor(() => {
      expect(screen.getByText(/iceberg_cache_hit: true/)).toBeInTheDocument();
    });
  });

  it('renders empty-state chip (not null) when execution has no stage history', async () => {
    // Phase 140 behaviour change: previously the chip silently returned
    // null when there was no stage_history + no log_lines, which made it
    // look "removed" to the user.  Now it ALWAYS renders so the user can
    // click in to see "no data persisted yet" or the executionId for
    // diagnostics.
    server.use(
      http.get('*/api/executions/empty-exec', () =>
        HttpResponse.json({ execution_id: 'empty-exec', files_metadata: null }),
      ),
    );
    const user = userEvent.setup();
    render(<ExecutionPerformanceChip executionId="empty-exec" />);
    const chip = await screen.findByText('perf');
    expect(chip).toBeInTheDocument();
    await user.click(chip);
    await waitFor(() => {
      expect(screen.getByText(/No stage breakdown or logs persisted/)).toBeInTheDocument();
      expect(screen.getByText(/execution_id: empty-exec/)).toBeInTheDocument();
    });
  });

  it('shows the slowest stage in the chip label', async () => {
    render(<ExecutionPerformanceChip executionId="exec-test-001" />);
    // Slowest is boto3_predownload at 12.0s — label = "Downloading files from S3"
    expect(await screen.findByText(/Downloading files from S3=12\.0s/)).toBeInTheDocument();
  });
});
