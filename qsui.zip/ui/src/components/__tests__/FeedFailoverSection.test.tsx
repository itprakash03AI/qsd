/**
 * FeedFailoverSection — render + interaction tests.
 *
 * Phase 130 hotfix-13.  Verifies that:
 *   1. The component fetches the override + health + tunables in parallel
 *      and renders the current state.
 *   2. Changing the override dropdown enables the Apply button.
 *   3. Clicking Apply POSTs the new value and reloads state.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import FeedFailoverSection from '../admin/FeedFailoverSection';

const OVERRIDE_RESPONSE = {
  value: 'auto',
  valid_values: ['airflow_only', 'auto', 'halt', 'native_only'],
  persisted: null,
};

const HEALTH_RESPONSE = {
  checked_at: '2026-05-16T08:00:00+00:00',
  override: { value: 'auto', airflow_failover_to_native: true },
  probes: {
    checked_at: '2026-05-16T08:00:00+00:00',
    airflow: {
      backend: 'airflow', healthy: true, detail: 'ok',
      checked_at: '2026-05-16T08:00:00+00:00',
    },
    native: {
      backend: 'native', healthy: true, detail: 'recent tick (5s ago)',
      checked_at: '2026-05-16T08:00:00+00:00',
    },
  },
  circuit_breakers: [
    { name: 'airflow', state: 'closed', failures: 0, threshold: 3, cooldown: 60 },
  ],
  agent: {
    agent_enabled: false,
    interval_seconds: 30,
    unhealthy_streak_required: 3,
    healthy_streak_required: 3,
    current_override: 'auto',
    streaks: {
      airflow_unhealthy: 0, airflow_healthy: 0,
      native_unhealthy: 0,  native_healthy: 0,
    },
    last_snapshot: {},
  },
};

const TUNABLES_RESPONSE = {
  items: [
    {
      key: 'feed_generation.airflow_failover_to_native',
      type: 'bool',
      effective_value: true,
      persisted: null,
    },
    {
      key: 'feed_generation.failover_agent_enabled',
      type: 'bool',
      effective_value: false,
      persisted: null,
    },
    {
      key: 'feed_generation.failover_agent_interval_seconds',
      type: 'int',
      effective_value: 30,
      persisted: null,
    },
  ],
};

describe('FeedFailoverSection', () => {
  it('renders override + health + tunables on first load', async () => {
    server.use(
      http.get('*/api/admin/feed-generation/backend-override', () => HttpResponse.json(OVERRIDE_RESPONSE)),
      http.get('*/api/admin/feed-generation/health', () => HttpResponse.json(HEALTH_RESPONSE)),
      http.get('*/api/admin/feed-generation/failover-tunables', () => HttpResponse.json(TUNABLES_RESPONSE)),
    );
    render(<FeedFailoverSection />);
    await waitFor(() => expect(screen.getByText(/Feed Backend Failover/)).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText(/Healthy — ok/)).toBeInTheDocument());
    expect(screen.getByText(/Healthy — recent tick/)).toBeInTheDocument();
  });

  it('disables Apply when override matches current value', async () => {
    server.use(
      http.get('*/api/admin/feed-generation/backend-override', () => HttpResponse.json(OVERRIDE_RESPONSE)),
      http.get('*/api/admin/feed-generation/health', () => HttpResponse.json(HEALTH_RESPONSE)),
      http.get('*/api/admin/feed-generation/failover-tunables', () => HttpResponse.json(TUNABLES_RESPONSE)),
    );
    render(<FeedFailoverSection />);
    await waitFor(() => expect(screen.getByText(/Apply override/)).toBeInTheDocument());
    const applyBtn = screen.getByRole('button', { name: /Apply override/i });
    expect(applyBtn).toBeDisabled();
  });

  it('POSTs new override and reloads', async () => {
    let posted: { value?: string } = {};
    let calls = 0;
    server.use(
      http.get('*/api/admin/feed-generation/backend-override', () => {
        calls += 1;
        if (calls === 1) return HttpResponse.json(OVERRIDE_RESPONSE);
        return HttpResponse.json({ ...OVERRIDE_RESPONSE, value: 'native_only' });
      }),
      http.get('*/api/admin/feed-generation/health', () => HttpResponse.json(HEALTH_RESPONSE)),
      http.get('*/api/admin/feed-generation/failover-tunables', () => HttpResponse.json(TUNABLES_RESPONSE)),
      http.post('*/api/admin/feed-generation/backend-override', async ({ request }) => {
        posted = (await request.json()) as { value?: string };
        return HttpResponse.json({ value: posted.value, persisted: { updated_by: 'tester' } });
      }),
    );
    render(<FeedFailoverSection />);
    await waitFor(() => expect(screen.getByText(/Apply override/)).toBeInTheDocument());

    const user = userEvent.setup();
    // Multiple selects on the page (override + bool tunables); find the
    // one whose displayed value is currently 'auto' — only the override
    // matches.
    const allCombos = screen.getAllByRole('combobox');
    const overrideSelect = allCombos.find((el) => el.textContent === 'auto');
    expect(overrideSelect).toBeDefined();
    await user.click(overrideSelect!);
    const option = await screen.findByRole('option', { name: 'native_only' });
    await user.click(option);

    const applyBtn = screen.getByRole('button', { name: /Apply override/i });
    expect(applyBtn).not.toBeDisabled();
    await user.click(applyBtn);

    await waitFor(() => expect(posted.value).toBe('native_only'));
  });
});
