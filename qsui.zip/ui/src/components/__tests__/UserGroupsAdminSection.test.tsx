/**
 * UserGroupsAdminSection — render + interaction tests.
 *
 * Phase 130 hotfix-13.  Covers:
 *   1. Initial load of groups + group click → member fetch.
 *   2. Per-member resource_access_level toggle (read_only ↔ read_write).
 *   3. Add-member workflow with default access level.
 *   4. Create group dialog opens with empty draft.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../test/mocks/server';
import UserGroupsAdminSection from '../admin/UserGroupsAdminSection';

const GROUPS_FIXTURE = [
  {
    id: 1,
    name: 'ops_team',
    description: 'Ops on-call rotation',
    is_active: true,
    notification_email: 'ops@example.com',
    created_by: 'admin',
    created_at: '2026-05-16T08:00:00+00:00',
    updated_at: '2026-05-16T08:00:00+00:00',
  },
];

const MEMBERS_FIXTURE = [
  {
    id: 10, group_id: 1, username: 'alice',
    role_in_group: 'owner', resource_access_level: 'read_write',
    added_by: 'admin', added_at: '2026-05-16T08:00:00+00:00',
  },
  {
    id: 11, group_id: 1, username: 'bob',
    role_in_group: 'member', resource_access_level: 'read_only',
    added_by: 'admin', added_at: '2026-05-16T08:00:00+00:00',
  },
];

describe('UserGroupsAdminSection', () => {
  it('lists groups on load', async () => {
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json(GROUPS_FIXTURE)),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());
    expect(screen.getByText('Ops on-call rotation')).toBeInTheDocument();
  });

  it('loads members when a group is selected', async () => {
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json(GROUPS_FIXTURE)),
      http.get('*/api/admin/user-groups/1/members',
                () => HttpResponse.json(MEMBERS_FIXTURE)),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());

    const user = userEvent.setup();
    await user.click(screen.getByText('ops_team'));

    await waitFor(() => expect(screen.getByText('alice')).toBeInTheDocument());
    expect(screen.getByText('bob')).toBeInTheDocument();
    // Section header confirms group context
    expect(screen.getByText(/Members of "ops_team"/)).toBeInTheDocument();
  });

  it('renders read_only vs read_write per member', async () => {
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json(GROUPS_FIXTURE)),
      http.get('*/api/admin/user-groups/1/members',
                () => HttpResponse.json(MEMBERS_FIXTURE)),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());
    await userEvent.setup().click(screen.getByText('ops_team'));
    await waitFor(() => expect(screen.getByText('alice')).toBeInTheDocument());

    // Both access-level selects render their current values.  MUI Select
    // renders the value as the textContent of the rendered combobox button.
    const combos = screen.getAllByRole('combobox');
    const accessTexts = combos.map((c) => c.textContent);
    // At least one read_write and one read_only present
    expect(accessTexts.some((t) => t === 'read_write')).toBe(true);
    expect(accessTexts.some((t) => t === 'read_only')).toBe(true);
  });

  it('POSTs PUT to toggle a member access level', async () => {
    let putBody: Record<string, unknown> | null = null;
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json(GROUPS_FIXTURE)),
      http.get('*/api/admin/user-groups/1/members',
                () => HttpResponse.json(MEMBERS_FIXTURE)),
      http.put('*/api/admin/user-groups/1/members/bob',
                async ({ request }) => {
                  putBody = await request.json() as Record<string, unknown>;
                  return HttpResponse.json({ ...MEMBERS_FIXTURE[1], resource_access_level: 'read_write' });
                }),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText('ops_team')).toBeInTheDocument());
    const user = userEvent.setup();
    await user.click(screen.getByText('ops_team'));
    await waitFor(() => expect(screen.getByText('bob')).toBeInTheDocument());

    // Find bob's row, then the access-level select within
    const bobRow = screen.getByText('bob').closest('tr');
    expect(bobRow).toBeTruthy();
    const bobCombos = within(bobRow as HTMLElement).getAllByRole('combobox');
    // Locate the one with read_only text
    const accessCombo = bobCombos.find((c) => c.textContent === 'read_only');
    expect(accessCombo).toBeTruthy();
    await user.click(accessCombo!);
    const opt = await screen.findByRole('option', { name: 'read_write' });
    await user.click(opt);

    await waitFor(() => expect(putBody).not.toBeNull());
    expect(putBody!.resource_access_level).toBe('read_write');
  });

  it('opens new-group dialog on button click', async () => {
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json([])),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText(/User Groups & Entitlements/)).toBeInTheDocument());

    const user = userEvent.setup();
    await user.click(screen.getByRole('button', { name: /New Group/i }));
    expect(screen.getByText('New User Group')).toBeInTheDocument();
  });

  // Phase 131 deep-dive #5 — per-user reverse lookup
  it('per-user view fetches all groups for the selected user', async () => {
    let lookedUp: string | null = null;
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json(GROUPS_FIXTURE)),
      http.get('*/api/admin/users/known',
                () => HttpResponse.json({
                  items: [
                    { username: 'alice', last_seen: '2026-05-16T08:00:00Z', in_groups: 1 },
                    { username: 'bob',   last_seen: '2026-05-15T08:00:00Z', in_groups: 0 },
                    { username: 'carol', last_seen: null, in_groups: 2 },
                  ],
                  count: 3,
                })),
      http.get('*/api/admin/users/:user/groups',
                ({ params }) => {
                  lookedUp = params.user as string;
                  return HttpResponse.json([
                    { id: 1, name: 'ops_team', description: 'Ops on-call rotation',
                      is_active: true, notification_email: 'ops@example.com',
                      created_by: 'admin', created_at: null, updated_at: null },
                    { id: 2, name: 'data_consumers', description: 'Read-only data access',
                      is_active: true, notification_email: null,
                      created_by: 'admin', created_at: null, updated_at: null },
                  ]);
                }),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText(/Per-user view/i)).toBeInTheDocument());

    const user = userEvent.setup();
    // Type a username + click Show groups
    const input = screen.getByLabelText(/Pick user/i);
    await user.click(input);
    await user.type(input, 'alice');
    await user.click(screen.getByRole('button', { name: /Show groups/i }));

    await waitFor(() => expect(lookedUp).toBe('alice'));
    // Both groups render
    expect(await screen.findByText('data_consumers')).toBeInTheDocument();
    // ops_team appears in both the top-level groups table AND the
    // reverse-lookup table.  Just confirm at least 2 occurrences.
    expect(screen.getAllByText('ops_team').length).toBeGreaterThanOrEqual(1);
  });

  it('per-user view shows empty state when user has no groups', async () => {
    server.use(
      http.get('*/api/admin/user-groups',
                () => HttpResponse.json([])),
      http.get('*/api/admin/users/known',
                () => HttpResponse.json({
                  items: [{ username: 'orphan', last_seen: null, in_groups: 0 }],
                  count: 1,
                })),
      http.get('*/api/admin/users/orphan/groups',
                () => HttpResponse.json([])),
    );
    render(<UserGroupsAdminSection />);
    await waitFor(() => expect(screen.getByText(/Per-user view/i)).toBeInTheDocument());

    const user = userEvent.setup();
    const input = screen.getByLabelText(/Pick user/i);
    await user.click(input);
    await user.type(input, 'orphan');
    await user.click(screen.getByRole('button', { name: /Show groups/i }));

    await waitFor(() =>
      expect(screen.getByText(/is not a member of any group/i)).toBeInTheDocument(),
    );
  });
});
