import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Select, MenuItem, FormControl, InputLabel, FormControlLabel, Switch,
  Stepper, Step, StepLabel, Collapse, Divider, Autocomplete,
  FormHelperText,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  PlayArrow as RunIcon, Pause as PauseIcon, Schedule as ScheduleIcon,
  Edit as EditIcon, ExpandMore as ExpandIcon, ExpandLess as CollapseIcon,
  CheckCircle as SuccessIcon, Error as ErrorIcon, HourglassTop as PendingIcon,
  Cancel as CancelIcon, Replay as RetryIcon, Download as DownloadIcon,
  NetworkCheck as TestIcon, InfoOutlined as InfoIcon,
  AccessTime as SodIcon, NotificationsActive as SlaIcon,
  Code as PreviewSqlIcon, ContentCopy as CopyIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toArray } from '../utils/toArray';
import { describeCron } from '../utils/describeCron';
import WhereClausesEditor, {
  WhereClauseRow, WHERE_OPERATORS,
} from './common/WhereClausesEditor';
import { SqlColumnExtractor } from './common/extractSqlColumns';
import { fetchPartitionValueOptions } from './common/fetchPartitionValueOptions';
import DynamicWhereOverrideField from './common/DynamicWhereOverrideField';
import { previewColumns as fetchPreviewColumns } from './common/sqlPreviewApi';
import type { PartitionValueOptions } from './common/fetchPartitionValueOptions';

// ── Constants ────────────────────────────────────────────────────────────────

const SOURCE_TYPES = ['saved_query', 'published_view', 'sql_file', 'raw_sql'] as const;
const SOURCE_TYPE_LABELS: Record<string, string> = {
  saved_query:    'Saved Query',
  published_view: 'Published View',
  sql_file:       'SQL File',
  raw_sql:        'Raw SQL',
};
const OUTPUT_FORMATS = ['csv', 'parquet', 'json', 'excel'] as const;
const DESTINATION_TYPES = ['local', 's3', 'sftp', 'oracle'] as const;
const BACKEND_TYPES = ['auto', 'native', 'spark_connect', 'airflow'] as const;
const STEP_LABELS = ['Source', 'Output', 'Destination & Schedule', 'Controls & Entitlement'];

// Common IANA timezones — UTC first, then alphabetical.  Browsers since
// Chrome 99 / Safari 15.4 expose Intl.supportedValuesOf('timeZone'), but
// we keep a fallback list so the dropdown is always populated.
const _FALLBACK_TIMEZONES = [
  'UTC', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Europe/Berlin',
  'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney',
];
const TIMEZONES: string[] = (() => {
  try {
    // @ts-ignore — supportedValuesOf isn't in older TS lib defs
    const list: string[] = Intl.supportedValuesOf?.('timeZone') ?? [];
    if (list.length > 0) {
      // Pin UTC at top so it's the default choice
      return ['UTC', ...list.filter(t => t !== 'UTC').sort()];
    }
  } catch { /* fallthrough */ }
  return _FALLBACK_TIMEZONES;
})();

const STATUS_COLORS: Record<string, 'success' | 'error' | 'warning' | 'info' | 'default'> = {
  completed: 'success',
  failed: 'error',
  running: 'info',
  pending: 'warning',
  cancelled: 'default',
};

// ── Interfaces ───────────────────────────────────────────────────────────────

interface FeedConfig {
  id: number;
  name: string;
  description: string | null;
  is_active: boolean;
  source_type: string;
  source_id: number;
  connection_id: number | null;
  query_params: Record<string, any> | null;
  output_format: string;
  output_filename_template: string | null;
  destination_type: string;
  destination_config: Record<string, any>;
  execution_backend: string;
  // Phase 131 deep-dive #13 (round 8) — auto-router size threshold
  size_threshold_rows?: number | null;
  last_row_count?: number | null;
  estimated_row_count?: number | null;
  schedule_enabled: boolean;
  cron_expression: string | null;
  timezone: string;
  run_count: number;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  // Phase 130 hotfix-2 — cross-source combine.  Optional: when
  // secondary_connection_id is set the feed pulls primary + secondary
  // sides separately and combines them in DuckDB before delivery.
  secondary_connection_id?: number | null;
  secondary_source_type?: string | null;
  secondary_source_id?: number | null;
  combine_mode?: string | null;          // 'union' | 'join'
  join_config?: Record<string, any> | null;
  control_file_template?: string | null;
  control_file_format_id?: number | null;
}

// Lookup options for the source / connection pickers — populated when
// the dialog opens.  Shape matches what /api/queries, /api/published-views,
// /api/sql-files, /api/connections actually return.
interface ConnectionOption {
  id: number;
  name: string;
  connection_type: string;
}
interface SavedQueryOption {
  id: number;
  name: string;
  description?: string | null;
  query_config?: { connection_id?: number };
}
interface PublishedViewOption {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  connection_id?: number;
}
interface SqlFileOption {
  id: number;
  name: string;
  description?: string | null;
  connection_id?: number | null;
}

interface FeedExecution {
  id: number;
  feed_config_id: number;
  execution_id: string;
  status: string;
  execution_backend: string | null;
  trigger_type: string;
  triggered_by: string | null;
  started_at: string | null;
  completed_at: string | null;
  total_rows: number;
  file_size_bytes: number;
  output_format: string | null;
  output_filename: string | null;
  destination_path: string | null;
  error_message: string | null;
  duration_seconds: number | null;
}

// ── Component ────────────────────────────────────────────────────────────────

const FeedConfigsPage = () => {
  const [feeds, setFeeds] = useState<FeedConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Create/Edit dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  // Admin-only ad-hoc trigger state (Run SOD now / SLA sweep).
  const { user } = useAuth();
  const userRole = ((user as any)?.role || '').toLowerCase();
  const isAdmin = userRole === 'admin' || userRole === 'super_admin';
  const [adminBusy, setAdminBusy] = useState(false);

  // SOD trigger dialog — asks admin which business_date to run for.
  // Default = today UTC.  Useful for backfilling missed days or seeding
  // a brand-new feed_config mid-day.  Idempotent on the backend.
  const [sodDialogOpen, setSodDialogOpen] = useState(false);
  const [sodDate, setSodDate] = useState<string>(() => new Date().toISOString().slice(0, 10));

  const handleRunSodNow = () => {
    // Reset to today each time the dialog opens (avoid stale dates).
    setSodDate(new Date().toISOString().slice(0, 10));
    setSodDialogOpen(true);
  };

  const confirmRunSodNow = async () => {
    if (!sodDate) return;
    setSodDialogOpen(false);
    setAdminBusy(true);
    try {
      const result: any = await api.runSodNow(sodDate);
      setSuccess(
        `SOD complete for ${sodDate}: ` +
        `created=${result?.created ?? 0}, ` +
        `skipped=${result?.skipped_by_condition ?? 0}, ` +
        `already=${result?.already_existed ?? 0}, ` +
        `skipped_window=${result?.skipped_window ?? 0}`,
      );
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setAdminBusy(false);
    }
  };

  const handleSlaSweepNow = async () => {
    setAdminBusy(true);
    try {
      const result: any = await api.slaSweepNow();
      setSuccess(`SLA sweep complete: breached_new=${result?.breached_new ?? 0}, checked=${result?.checked ?? 0}`);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setAdminBusy(false);
    }
  };
  const [editFeed, setEditFeed] = useState<FeedConfig | null>(null);
  const [activeStep, setActiveStep] = useState(0);

  // Lookup-list state — populated on mount and whenever the create/edit
  // dialog opens, so the source / connection pickers always have fresh
  // options without flicker.
  const [connections, setConnections] = useState<ConnectionOption[]>([]);
  const [savedQueries, setSavedQueries] = useState<SavedQueryOption[]>([]);
  const [publishedViews, setPublishedViews] = useState<PublishedViewOption[]>([]);
  const [sqlFilesList, setSqlFilesList] = useState<SqlFileOption[]>([]);

  // Form state
  const [formName, setFormName] = useState('');
  // Phase 131 — generic task_type.  file_feed is the legacy default
  // (produces a file artifact + delivers it); other types reserved
  // for future routing branches.
  const [formTaskType, setFormTaskType] = useState<'file_feed'|'oracle_push'|'api_push'|'custom'>('file_feed');
  // Phase 132.38 — per-feed Static / Dynamic WHERE-clause mapping.
  // Same primitive Published Views uses (api param concept).  Persisted
  // inside query_params._where_clauses_mapping so feed_configs needs no
  // DB migration.
  const [formWhereClauses, setFormWhereClauses] = useState<WhereClauseRow[]>([]);
  const [formDescription, setFormDescription] = useState('');
  const [formSourceType, setFormSourceType] = useState<string>('saved_query');
  const [formSourceId, setFormSourceId] = useState<number | ''>('');
  const [formConnectionId, setFormConnectionId] = useState<number | ''>('');
  // raw_sql source: backend reads SQL from query_params.sql, so the form
  // owns it and we ship it inside the create/update payload below.
  const [formRawSql, setFormRawSql] = useState('');
  // Phase 133-F — partition cache for the picked connection, used to
  // surface partition badges + per-value autocomplete in the WHERE-
  // clauses editor.  Refetched whenever formConnectionId changes.
  const [formPartitionInfo, setFormPartitionInfo] = useState<PartitionValueOptions>({
    valueOptionsByColumn: {}, partitionColumns: [],
  });
  // Phase 133-H round 6 — full column catalogue per source table for
  // the WHERE-clause editor.  Fetched via /api/sql/preview-columns
  // with connection_id; backend reads ``schema_cache`` (populated by
  // every CQB / BQB / register-table call) and falls back to
  // ``connector.list_columns()`` on miss.  Lets the dropdown show
  // every column on the underlying tables — not just the names that
  // appear in the SQL text.
  const [formColumnCatalog, setFormColumnCatalog] = useState<{
    columnsByTable: Record<string, Array<{name: string; type?: string}>>;
    partitionColumnsByTable: Record<string, string[]>;
    tableConnectionIds: Record<string, number>;
  }>({ columnsByTable: {}, partitionColumnsByTable: {}, tableConnectionIds: {} });

  // Phase 133-I round 19 — secondary connection's columns for the
  // cross-source JOIN key picker.  Without this, the user had to type
  // the secondary side's column names from memory (plain TextField).
  // Fetched lazily via /api/sql/preview-columns with the same SQL
  // resolution as the primary side — but against the secondary
  // connection's ID.  Falls back to free-text typing on empty.
  const [formSecondaryColumnCatalog, setFormSecondaryColumnCatalog] = useState<{
    columnsByTable: Record<string, Array<{name: string; type?: string}>>;
  }>({ columnsByTable: {} });
  // Tracks whether the user has manually overridden the auto-derived
  // connection from the picked source.  Without this, selecting a saved
  // query that already carries a connection would silently lock the
  // connection picker to the source's connection forever.
  const [formConnOverridden, setFormConnOverridden] = useState(false);
  const [formOutputFormat, setFormOutputFormat] = useState('csv');
  const [formFilenameTemplate, setFormFilenameTemplate] = useState('');
  const [formDestType, setFormDestType] = useState('local');
  const [formDestPath, setFormDestPath] = useState('');
  const [formDestBucket, setFormDestBucket] = useState('');
  const [formDestPrefix, setFormDestPrefix] = useState('');
  const [formDestHost, setFormDestHost] = useState('');
  const [formDestPort, setFormDestPort] = useState('22');
  const [formDestUser, setFormDestUser] = useState('');
  const [formDestPassword, setFormDestPassword] = useState('');
  const [formDestRemoteDir, setFormDestRemoteDir] = useState('/');
  const [formBackend, setFormBackend] = useState('auto');
  // Phase 131 deep-dive #13 (round 8): per-feed size threshold for the
  // auto router.  Empty string = inherit global (feed_generation.auto_
  // route_threshold_rows, default 500K).
  const [formSizeThresholdRows, setFormSizeThresholdRows] = useState('');
  const [formScheduleEnabled, setFormScheduleEnabled] = useState(false);
  const [formCron, setFormCron] = useState('');
  const [formTimezone, setFormTimezone] = useState('UTC');
  const [formNotifySuccess, setFormNotifySuccess] = useState(false);
  const [formNotifyFailure, setFormNotifyFailure] = useState(true);
  const [formNotifyEmails, setFormNotifyEmails] = useState('');

  // Phase 130 hotfix-2 — cross-source combine state.  When the user
  // sets a secondary connection, the feed runs both sides separately
  // and the engine combines via UNION ALL BY NAME / JOIN before the
  // output is written.  The control file (if configured) describes
  // the combined output.
  const [formCrossSourceEnabled, setFormCrossSourceEnabled] = useState(false);
  const [formSecondaryConnectionId, setFormSecondaryConnectionId] = useState<number | ''>('');
  const [formCombineMode, setFormCombineMode] = useState<'union' | 'join'>('union');
  const [formJoinKeysLeft, setFormJoinKeysLeft] = useState('');   // comma-sep
  const [formJoinKeysRight, setFormJoinKeysRight] = useState(''); // comma-sep
  const [formJoinType, setFormJoinType] = useState<'INNER' | 'LEFT' | 'RIGHT' | 'FULL'>('INNER');
  const [formControlFileTemplate, setFormControlFileTemplate] = useState('');
  const [formControlFileFormatId, setFormControlFileFormatId] = useState<number | ''>('');
  const [controlFileFormats, setControlFileFormats] = useState<Array<{id:number,name:string,description?:string|null,is_default?:boolean}>>([]);

  // Phase 130 hotfix-13 — Owner Group + Calendar pickers.  Backend
  // supports owner_group_id (entitlement group with per-user
  // read_only/read_write flavour) and calendar_name (BusinessCalendar
  // used for {{prev_business_day}} / {{prev_eom}} resolution).
  const [formOwnerGroupId, setFormOwnerGroupId] = useState<number | ''>('');
  const [formCalendarName, setFormCalendarName] = useState<string>('');
  const [userGroupsList, setUserGroupsList] = useState<Array<{id:number,name:string,description?:string|null}>>([]);
  const [calendarsList, setCalendarsList] = useState<Array<{id:number,name:string}>>([]);

  // BF-473 (2026-05-19) — operator-facing frequency category.  Open
  // string with suggested vocabulary fetched from
  // /api/feeds/frequency-categories so a custom value typed by one
  // admin shows up in the next admin's dropdown.
  const [formFrequencyCategory, setFormFrequencyCategory] = useState<string>('');
  const [frequencyCategoriesList, setFrequencyCategoriesList] = useState<
    Array<{ value: string; label: string }>
  >([]);

  // Phase 131 — production controls (opt-in per feed)
  // 131-A: end users add deps inline below.  When deps are present and
  //        etl_id is null, backend auto-fills etl_id = feed_id so the
  //        poller picks the feed up.  There is no explicit etl_id form
  //        field — the user just adds deps; the linkage is implicit.
  // 131-B: row_count_action + row_count_threshold_pct enable per-feed
  //        anomaly detection against the rolling baseline.
  // 131-C: integrity_check_enabled NULL = inherit system default.
  const [formRowCountAction, setFormRowCountAction] = useState<'off'|'warn'|'fail'>('off');
  const [formRowCountThresholdPct, setFormRowCountThresholdPct] = useState<string>('');
  const [formIntegrityCheck, setFormIntegrityCheck] = useState<'inherit'|'on'|'off'>('inherit');

  // 131-A inline editor — list of deps attached to this feed.  Loaded
  // when editing an existing feed; new feeds start empty and the
  // mappings are persisted right after the feed save returns.
  type DepRow = {
    id?: number;                  // present on existing rows
    dependency_type_id: number;
    dependency_type?: string;     // human label
    dependency_key: string;
    description?: string | null;
  };
  type DepType = { id: number; dependency_type: string; description?: string | null };
  const [formDeps, setFormDeps] = useState<DepRow[]>([]);
  const [availableDepTypes, setAvailableDepTypes] = useState<DepType[]>([]);
  const [newDepTypeId, setNewDepTypeId] = useState<number | ''>('');
  const [newDepKey, setNewDepKey] = useState<string>('');
  const [newDepDesc, setNewDepDesc] = useState<string>('');

  // Execution history
  const [expandedFeedId, setExpandedFeedId] = useState<number | null>(null);
  const [executions, setExecutions] = useState<FeedExecution[]>([]);
  const [execLoading, setExecLoading] = useState(false);

  // ── Data Loading ───────────────────────────────────────────────────────────

  const loadFeeds = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await api.listFeeds();
      // BF-428P: normalise — backend wrapper / null shouldn't crash .map
      setFeeds(toArray(data));
    } catch (err: any) {
      setError(err.message || 'Failed to load feeds');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadFeeds(); }, [loadFeeds]);

  // Load the lookup lists once on mount (also refreshed when dialog opens
  // so a user who creates a new saved query in another tab sees it without
  // a full page refresh).  All four calls run in parallel and fail-open —
  // a missing list just produces an empty dropdown rather than blocking
  // feed-config CRUD entirely.
  const loadLookups = useCallback(async () => {
    const [conns, queries, pviews, sfs, fmts, groups, cals, depTypesRaw, freqCats] = await Promise.all([
      api.listConnections(true).catch(() => []),
      api.listQueries(true).catch(() => []),
      api.listPublishedViews().catch(() => ({ views: [] })),
      api.sqlFiles.list({ limit: 500 }).catch(() => []),
      // Phase 130 hotfix-4 — load CTL formats for the picker.  Silently
      // empty when the user lacks admin rights (the dropdown just won't
      // populate; legacy template field still works).
      api.listControlFileFormats({ is_active: true }).catch(() => []),
      // Phase 130 hotfix-13 — Owner Group picker + Calendar picker
      // populated from admin endpoints.  Both fail silently for non-
      // admin users — pickers just won't populate.
      (api as any).listUserGroups?.({ is_active: true }).catch(() => []) ?? Promise.resolve([]),
      (api as any).listFeedCalendars?.({ is_active: true }).catch(() => []) ?? Promise.resolve([]),
      // Phase 131-A — dependency type catalogue (non-admin endpoint).
      fetch('/api/feed-dependency-types', { credentials: 'include' })
        .then((r) => r.ok ? r.json() : { items: [] })
        .catch(() => ({ items: [] })),
      // BF-473 — frequency category suggestions (baseline + in-DB custom)
      fetch('/api/feeds/frequency-categories', { credentials: 'include' })
        .then((r) => r.ok ? r.json() : { categories: [] })
        .catch(() => ({ categories: [] })),
    ]);
    setConnections(toArray(conns));
    setSavedQueries(toArray(queries));
    // /api/published-views returns { views: [...] }; toArray handles both
    // wrapped + bare shapes via the BF-428P helper.
    const pv = (pviews && (pviews as any).views) || pviews;
    setPublishedViews(toArray(pv));
    setSqlFilesList(toArray(sfs));
    setControlFileFormats(toArray(fmts));
    setUserGroupsList(toArray(groups));
    setCalendarsList(toArray(cals));
    setAvailableDepTypes(toArray((depTypesRaw as any)?.items));
    // BF-473 — category suggestions
    setFrequencyCategoriesList(toArray((freqCats as any)?.categories));
  }, []);

  useEffect(() => { loadLookups(); }, [loadLookups]);

  // Phase 133-F — partition cache refetch on connection change.
  useEffect(() => {
    let cancelled = false;
    const cid = typeof formConnectionId === 'number' ? formConnectionId : null;
    if (!cid) {
      setFormPartitionInfo({ valueOptionsByColumn: {}, partitionColumns: [] });
      return () => { cancelled = true; };
    }
    fetchPartitionValueOptions(cid).then(p => {
      if (!cancelled) setFormPartitionInfo(p);
    });
    return () => { cancelled = true; };
  }, [formConnectionId]);

  // Phase 133-H round 6 — refetch full column catalogue when SQL or
  // connection changes.  Backend reads schema_cache so the request is
  // cheap (DB round-trip, no warehouse call) for tables that have
  // been queried before.
  //
  // Phase 133-H round 17 — resolve the EFFECTIVE SQL for column
  // extraction based on source_type.  raw_sql uses formRawSql
  // directly; saved_query / published_view / sql_file fetch the
  // referenced entity and pull its SQL (so the WHERE editor's
  // dropdown is populated even before the user types anything).
  const [resolvedSqlForEditor, setResolvedSqlForEditor] = useState('');
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (formSourceType === 'raw_sql') {
        if (!cancelled) setResolvedSqlForEditor(formRawSql || '');
        return;
      }
      if (!formSourceId) {
        if (!cancelled) setResolvedSqlForEditor('');
        return;
      }
      try {
        if (formSourceType === 'saved_query') {
          const sq: any = await api.getSavedQuery(String(formSourceId));
          const qc = sq?.query_config || {};
          // Build a synthetic SQL from raw_sql, or from columns + files if structured.
          let sqlForEd = '';
          if (typeof qc.raw_sql === 'string' && qc.raw_sql.trim()) {
            sqlForEd = qc.raw_sql;
          } else if (Array.isArray(qc.columns) && qc.columns.length > 0) {
            const tbl = (qc.files || [])[0];
            const tblPath = typeof tbl === 'string' ? tbl : tbl?.path || '';
            const tblName = tblPath.replace(/^__(registered|iceberg)__:/, '') || 'src';
            sqlForEd = `SELECT ${qc.columns.join(', ')} FROM ${tblName}`;
          }
          if (!cancelled) setResolvedSqlForEditor(sqlForEd);
        } else if (formSourceType === 'sql_file') {
          const sf: any = await api.sqlFiles.get(Number(formSourceId));
          if (!cancelled) setResolvedSqlForEditor(sf?.content || '');
        } else if (formSourceType === 'published_view') {
          // PVs don't expose raw SQL directly; skip — feed config
          // doesn't currently let publishers add WHERE rows on PV
          // sources anyway (they were already locked at publish time).
          if (!cancelled) setResolvedSqlForEditor('');
        }
      } catch {
        if (!cancelled) setResolvedSqlForEditor('');
      }
    })();
    return () => { cancelled = true; };
  }, [formSourceType, formSourceId, formRawSql]);

  useEffect(() => {
    let cancelled = false;
    const cid = typeof formConnectionId === 'number' ? formConnectionId : null;
    const sqlToUse = resolvedSqlForEditor || formRawSql;
    if (!cid || !sqlToUse.trim()) {
      setFormColumnCatalog({
        columnsByTable: {},
        partitionColumnsByTable: {},
        tableConnectionIds: {},
      });
      return () => { cancelled = true; };
    }
    fetchPreviewColumns(sqlToUse, 'duckdb', cid).then(res => {
      if (cancelled || !res) return;
      setFormColumnCatalog({
        columnsByTable: res.columns_by_table || {},
        partitionColumnsByTable: res.partition_columns_by_table || {},
        tableConnectionIds: res.table_connection_ids || {},
      });
    });
    return () => { cancelled = true; };
  }, [formConnectionId, resolvedSqlForEditor, formRawSql]);

  // Phase 133-I round 19 — secondary side schema fetch for the
  // cross-source JOIN key picker.  Uses the SAME SQL the primary
  // catalog used (assumption: both sides query the same logical
  // schema — that's WHY they're being combined).  When the
  // assumption breaks the JOIN key field falls back to free-text.
  useEffect(() => {
    let cancelled = false;
    const sid = typeof formSecondaryConnectionId === 'number' ? formSecondaryConnectionId : null;
    const sqlToUse = resolvedSqlForEditor || formRawSql;
    if (!sid || !sqlToUse.trim()) {
      setFormSecondaryColumnCatalog({ columnsByTable: {} });
      return () => { cancelled = true; };
    }
    fetchPreviewColumns(sqlToUse, 'duckdb', sid).then(res => {
      if (cancelled || !res) return;
      setFormSecondaryColumnCatalog({
        columnsByTable: res.columns_by_table || {},
      });
    });
    return () => { cancelled = true; };
  }, [formSecondaryConnectionId, resolvedSqlForEditor, formRawSql]);

  // ── Deep-link support: open Create dialog pre-filled when the page
  // is navigated from CQB / BQB via the "Create Feed…" menu.  URL
  // contract:
  //
  //     /feeds?source_type=saved_query&source_id=42
  //     /feeds?source_type=sql_file&source_id=7&name=daily-trades
  //
  // Auto-opens the create dialog and pre-selects the source so the
  // user only has to fill in destination + schedule.  Cleans the
  // query string after consuming it so a refresh / back-button
  // doesn't re-trigger.  No-op if the parameters are missing or
  // reference a source we don't recognise.
  const _location = useLocation();
  const _navigate = useNavigate();
  const _deepLinkAppliedRef = React.useRef(false);
  useEffect(() => {
    if (_deepLinkAppliedRef.current) return;
    const params = new URLSearchParams(_location.search);
    const stype = params.get('source_type');
    const sid = params.get('source_id');
    const suggestedName = params.get('name');
    if (!stype || !sid) return;
    // Validate against known source types
    if (!['saved_query', 'published_view', 'sql_file', 'raw_sql'].includes(stype)) return;
    const sidNum = Number(sid);
    if (!Number.isFinite(sidNum) || sidNum < 0) return;

    _deepLinkAppliedRef.current = true;
    setEditFeed(null);
    resetForm();
    setFormSourceType(stype);
    setFormSourceId(sidNum);
    if (suggestedName) setFormName(suggestedName);
    // Async — open dialog after lookups load so the source picker shows
    // the resolved name immediately rather than an ID placeholder.
    loadLookups().then(() => setDialogOpen(true));
    // Strip the deep-link query string so the dialog doesn't re-open on
    // a Refresh button click.
    _navigate(_location.pathname, { replace: true });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_location.search]);

  const loadExecutions = useCallback(async (feedId: number) => {
    setExecLoading(true);
    try {
      const data = await api.listFeedExecutions(feedId);
      setExecutions(toArray(data));
    } catch (err: any) {
      setError(err.message || 'Failed to load executions');
    } finally {
      setExecLoading(false);
    }
  }, []);

  // ── Dialog helpers ─────────────────────────────────────────────────────────

  const resetForm = () => {
    setFormName('');
    setFormTaskType('file_feed');
    setFormWhereClauses([]);
    setFormDescription('');
    setFormSourceType('saved_query');
    setFormSourceId('');
    setFormConnectionId('');
    setFormRawSql('');
    setFormConnOverridden(false);
    setFormOutputFormat('csv');
    setFormFilenameTemplate('');
    setFormDestType('local');
    setFormDestPath('');
    setFormDestBucket('');
    setFormDestPrefix('');
    setFormDestHost('');
    setFormDestPort('22');
    setFormDestUser('');
    setFormDestPassword('');
    setFormDestRemoteDir('/');
    setFormBackend('auto');
    setFormSizeThresholdRows('');
    setFormScheduleEnabled(false);
    setFormCron('');
    setFormTimezone('UTC');
    setFormNotifySuccess(false);
    setFormNotifyFailure(true);
    setFormNotifyEmails('');
    // Phase 130 hotfix-2 — cross-source defaults
    setFormCrossSourceEnabled(false);
    setFormSecondaryConnectionId('');
    setFormCombineMode('union');
    setFormJoinKeysLeft('');
    setFormJoinKeysRight('');
    setFormJoinType('INNER');
    setFormControlFileTemplate('');
    setFormControlFileFormatId('');
    setFormOwnerGroupId('');
    setFormCalendarName('');
    setFormFrequencyCategory('');  // BF-473
    // Phase 131 — production-controls defaults
    setFormRowCountAction('off');
    setFormRowCountThresholdPct('');
    setFormIntegrityCheck('inherit');
    setFormDeps([]);
    setNewDepTypeId('');
    setNewDepKey('');
    setActiveStep(0);
  };

  const openCreate = async () => {
    setEditFeed(null);
    resetForm();
    // await so the dialog opens with populated dropdowns rather than
    // a flash of "No saved queries available" before the GET resolves.
    await loadLookups();
    setDialogOpen(true);
  };

  const openEdit = async (feed: FeedConfig) => {
    setEditFeed(feed);
    setFormName(feed.name);
    setFormTaskType((feed as any).task_type || 'file_feed');
    setFormDescription(feed.description || '');
    setFormSourceType(feed.source_type);
    setFormSourceId(feed.source_id);
    setFormConnectionId(feed.connection_id || '');
    setFormRawSql(((feed.query_params || {}) as any).sql || '');
    // Phase 132.38 — restore the publisher's WHERE-mapping from the
    // sentinel key inside query_params so re-opening the dialog
    // re-renders the Dynamic / Static toggles + values.
    const _wcm = ((feed.query_params || {}) as any)._where_clauses_mapping;
    setFormWhereClauses(Array.isArray(_wcm)
      ? _wcm.map((r: any) => ({
          column: r?.column || '',
          operator: r?.operator || 'eq',
          value: r?.value ?? '',
          mode: (r?.mode === 'static' ? 'static' : 'dynamic') as 'static' | 'dynamic',
        }))
      : []);
    // Edit mode: assume the saved connection was admin's deliberate
    // choice — don't auto-derive on first render or we'd clobber it.
    setFormConnOverridden(true);
    // Wait for the lookup lists BEFORE opening so the source +
    // connection pickers can resolve their value-by-id lookups
    // immediately (otherwise edit shows empty fields for 200-500 ms).
    await loadLookups();
    setFormOutputFormat(feed.output_format);
    setFormFilenameTemplate(feed.output_filename_template || '');
    setFormDestType(feed.destination_type);
    const dc = feed.destination_config || {};
    setFormDestPath(dc.path || '');
    setFormDestBucket(dc.bucket || '');
    setFormDestPrefix(dc.prefix || '');
    setFormDestHost(dc.host || '');
    setFormDestPort(String(dc.port || '22'));
    setFormDestUser(dc.username || '');
    setFormDestPassword(dc.password || '');
    setFormDestRemoteDir(dc.remote_dir || '/');
    setFormBackend(feed.execution_backend || 'auto');
    setFormSizeThresholdRows(
      feed.size_threshold_rows != null ? String(feed.size_threshold_rows) : ''
    );
    setFormScheduleEnabled(feed.schedule_enabled);
    setFormCron(feed.cron_expression || '');
    setFormTimezone(feed.timezone || 'UTC');
    // Cross-source hydrate
    if (feed.secondary_connection_id) {
      setFormCrossSourceEnabled(true);
      setFormSecondaryConnectionId(feed.secondary_connection_id);
      setFormCombineMode((feed.combine_mode === 'join' ? 'join' : 'union'));
      const jc: any = feed.join_config || {};
      setFormJoinKeysLeft(Array.isArray(jc.left_on) ? jc.left_on.join(',') : (jc.left_on || ''));
      setFormJoinKeysRight(Array.isArray(jc.right_on) ? jc.right_on.join(',') : (jc.right_on || ''));
      setFormJoinType((jc.how || 'INNER').toUpperCase());
    } else {
      setFormCrossSourceEnabled(false);
      setFormSecondaryConnectionId('');
      setFormCombineMode('union');
      setFormJoinKeysLeft('');
      setFormJoinKeysRight('');
      setFormJoinType('INNER');
    }
    setFormControlFileTemplate(feed.control_file_template || '');
    setFormControlFileFormatId(feed.control_file_format_id || '');
    // Phase 130 hotfix-13 — hydrate Owner Group + Calendar so editing
    // preserves the entitlement / calendar associations.
    setFormOwnerGroupId(((feed as any).owner_group_id ?? '') || '');
    setFormCalendarName((feed as any).calendar_name || '');
    setFormFrequencyCategory((feed as any).frequency_category || '');  // BF-473
    // Phase 131 — production controls
    setFormRowCountAction(((feed as any).row_count_action || 'off') as 'off'|'warn'|'fail');
    const _thr = (feed as any).row_count_threshold_pct;
    setFormRowCountThresholdPct(_thr == null ? '' : String(_thr));
    const _ic = (feed as any).integrity_check_enabled;
    setFormIntegrityCheck(_ic === true ? 'on' : _ic === false ? 'off' : 'inherit');
    // Phase 131-A — load existing dependencies for this feed.  Empty
    // array when feed has none.  Failure here is non-fatal — the user
    // can still edit other fields and the deps panel just shows blank.
    setFormDeps([]);
    fetch(`/api/feeds/${feed.id}/dependencies`, { credentials: 'include' })
      .then((r) => r.ok ? r.json() : null)
      .then((data) => {
        if (data && Array.isArray(data.items)) {
          setFormDeps(data.items.map((it: any) => ({
            id: it.id,
            dependency_type_id: it.dependency_type_id,
            dependency_type: it.dependency_type,
            dependency_key: it.dependency_key,
            description: it.description,
          })));
        }
      })
      .catch(() => { /* ignore — leave empty */ });
    setActiveStep(0);
    setDialogOpen(true);
  };

  // ── Source / connection picker helpers ─────────────────────────────────────

  /** Returns the connection_id implied by the currently-picked source, or null. */
  const sourceImplicitConnectionId = useCallback((): number | null => {
    if (!formSourceId) return null;
    if (formSourceType === 'saved_query') {
      const q = savedQueries.find(x => x.id === formSourceId);
      return q?.query_config?.connection_id ?? null;
    }
    if (formSourceType === 'published_view') {
      const v = publishedViews.find(x => x.id === formSourceId);
      return v?.connection_id ?? null;
    }
    if (formSourceType === 'sql_file') {
      const s = sqlFilesList.find(x => x.id === formSourceId);
      return s?.connection_id ?? null;
    }
    return null;
  }, [formSourceId, formSourceType, savedQueries, publishedViews, sqlFilesList]);

  // Auto-derive connection from the picked source — but only when the
  // user hasn't manually overridden it.  Switching source type resets
  // both the picked source and the override flag (see source-type
  // onChange below) so a fresh source can populate a fresh connection.
  useEffect(() => {
    if (formConnOverridden) return;
    if (formSourceType === 'raw_sql') return;  // raw_sql has no implicit conn
    const implicit = sourceImplicitConnectionId();
    if (implicit && implicit !== formConnectionId) {
      setFormConnectionId(implicit);
    }
  }, [formSourceId, formSourceType, formConnOverridden, sourceImplicitConnectionId, formConnectionId]);

  const connectionLabel = (id: number | null | undefined): string => {
    if (!id) return '';
    const c = connections.find(x => x.id === id);
    return c ? `${c.name}` : `Connection ${id}`;
  };

  const sourceSummary = useCallback((feed: FeedConfig): string => {
    if (feed.source_type === 'saved_query') {
      const q = savedQueries.find(x => x.id === feed.source_id);
      return q?.name || `Saved query #${feed.source_id}`;
    }
    if (feed.source_type === 'published_view') {
      const v = publishedViews.find(x => x.id === feed.source_id);
      return v ? `${v.name} (${v.slug})` : `Published view #${feed.source_id}`;
    }
    if (feed.source_type === 'sql_file') {
      const s = sqlFilesList.find(x => x.id === feed.source_id);
      return s?.name || `SQL file #${feed.source_id}`;
    }
    if (feed.source_type === 'raw_sql') {
      return 'Inline SQL';
    }
    return `#${feed.source_id}`;
  }, [savedQueries, publishedViews, sqlFilesList]);

  // Validation gate for Step 0 / Save button.  raw_sql is the only path
  // that needs the SQL textarea + a connection; every other path needs
  // a picked source (its connection is auto-derived).
  const _step0Ready = useMemo(() => {
    if (!formName.trim()) return false;
    if (formSourceType === 'raw_sql') {
      return Boolean(formRawSql.trim()) && Boolean(formConnectionId);
    }
    return Boolean(formSourceId);
  }, [formName, formSourceType, formSourceId, formRawSql, formConnectionId]);

  // BF-566 (2026-05-29): destination-step validation.  Previously the
  // wizard's Create button only gated on _step0Ready; a user with an
  // empty bucket / path / host could hit Create and get an opaque
  // backend 500.  Now: per-destination-type required-field check.
  const _step3Ready = useMemo(() => {
    if (formDestType === 'local') return Boolean(formDestPath?.trim());
    if (formDestType === 's3') return Boolean(formDestBucket?.trim());
    if (formDestType === 'sftp') {
      return Boolean(formDestHost?.trim())
        && Boolean(formDestUser?.trim())
        && Boolean(formDestRemoteDir?.trim());
    }
    return true;
  }, [formDestType, formDestPath, formDestBucket,
      formDestHost, formDestUser, formDestRemoteDir]);
  const _allStepsReady = _step0Ready && _step3Ready;

  const buildDestConfig = (): Record<string, any> => {
    if (formDestType === 'local') return { path: formDestPath || 'data/feeds' };
    if (formDestType === 's3') return { bucket: formDestBucket, prefix: formDestPrefix };
    if (formDestType === 'sftp') return {
      host: formDestHost, port: parseInt(formDestPort, 10),
      username: formDestUser, password: formDestPassword,
      remote_dir: formDestRemoteDir,
    };
    return {};
  };

  const handleSave = async () => {
    const data: Record<string, any> = {
      name: formName,
      task_type: formTaskType,
      description: formDescription || undefined,
      source_type: formSourceType,
      // raw_sql has no source row to reference — backend ignores source_id
      // for that path but still requires the field to be an int.
      source_id: formSourceType === 'raw_sql' ? 0 : Number(formSourceId),
      connection_id: formConnectionId ? Number(formConnectionId) : undefined,
      output_format: formOutputFormat,
      output_filename_template: formFilenameTemplate || undefined,
      destination_type: formDestType,
      destination_config: buildDestConfig(),
      execution_backend: formBackend,
      size_threshold_rows: formSizeThresholdRows.trim() === ''
        ? null
        : (Number.isFinite(Number(formSizeThresholdRows))
            ? Math.max(0, Math.floor(Number(formSizeThresholdRows)))
            : null),
      schedule_enabled: formScheduleEnabled,
      cron_expression: formCron || undefined,
      timezone: formTimezone,
      notify_on_success: formNotifySuccess,
      notify_on_failure: formNotifyFailure,
      notify_emails: formNotifyEmails || undefined,
      // Phase 130 — control file template (sidecar .ctl)
      control_file_template: formControlFileTemplate.trim() || null,
      // Phase 130 hotfix-4 — DB-driven CTL format (id; NULL → default)
      control_file_format_id: formControlFileFormatId
        ? Number(formControlFileFormatId)
        : null,
      // Phase 130 hotfix-13 — entitlement + calendar.  Pass null
      // explicitly so editing an existing feed can CLEAR these
      // associations (a previously-grouped feed can become solo).
      owner_group_id: formOwnerGroupId ? Number(formOwnerGroupId) : null,
      calendar_name: formCalendarName || null,
      // BF-473 — frequency category (open string).  null clears it.
      frequency_category: formFrequencyCategory || null,
      // Phase 131 — production controls (each opt-in, null = inherit
      // system default / disable on this feed).  etl_id is intentionally
      // NOT sent from this page — the backend auto-fills etl_id=feed_id
      // when the user adds at least one upstream dependency via the
      // inline editor below.  Admins who need to align with the OTG
      // side can override via the admin endpoint.
      row_count_action: formRowCountAction,
      row_count_threshold_pct:
        formRowCountThresholdPct === '' ? null : parseFloat(formRowCountThresholdPct),
      integrity_check_enabled:
        formIntegrityCheck === 'inherit' ? null
        : formIntegrityCheck === 'on' ? true
        : false,
    };
    // Phase 130 hotfix-2 — cross-source combine.  When user enabled
    // it AND picked a secondary connection, send the secondary fields;
    // otherwise explicitly null them so a previously-cross-source feed
    // can be reverted to single-source.
    if (formCrossSourceEnabled && formSecondaryConnectionId) {
      data.secondary_connection_id = Number(formSecondaryConnectionId);
      data.combine_mode = formCombineMode;
      if (formCombineMode === 'join') {
        const left = formJoinKeysLeft.split(',').map(s => s.trim()).filter(Boolean);
        const right = formJoinKeysRight.split(',').map(s => s.trim()).filter(Boolean);
        data.join_config = {
          how: formJoinType,
          left_on: left,
          right_on: right,
        };
      } else {
        data.join_config = null;
      }
    } else {
      data.secondary_connection_id = null;
      data.combine_mode = null;
      data.join_config = null;
    }
    // raw_sql carries its SQL inside query_params — feed_engine reads it
    // from query_params.sql at execution time.
    if (formSourceType === 'raw_sql' && formRawSql.trim()) {
      data.query_params = { sql: formRawSql.trim() };
    }
    // Phase 132.38 — submit the publisher's WHERE-mapping as a
    // sibling field.  Backend _embed_where_mapping_in_query_params
    // tucks it into query_params._where_clauses_mapping before
    // persisting.  Empty array clears the mapping on update.
    data.where_clauses = formWhereClauses
      .filter(w => (w.column || '').trim())
      .map(w => ({
        column: w.column.trim(),
        operator: w.operator || 'eq',
        value: w.value ?? null,
        mode: w.mode,
      }));

    try {
      let savedId: number | null = null;
      if (editFeed) {
        await api.updateFeed(editFeed.id, data);
        savedId = editFeed.id;
        setSuccess('Feed updated successfully');
      } else {
        // cast: handleSave normalises the union of "edit fields" + the
        // conditional query_params so the runtime shape always matches
        // createFeed's signature, but TS can't infer that.
        const created = await api.createFeed(data as Parameters<typeof api.createFeed>[0]);
        savedId = (created as any)?.id ?? null;
        setSuccess('Feed created successfully');
      }
      // Phase 131-A — persist the dependency mappings in a separate
      // atomic call.  Errors here surface as a soft warning so the
      // feed save isn't lost; the user can retry the deps without
      // re-entering everything.
      if (savedId != null) {
        try {
          await fetch(`/api/feeds/${savedId}/dependencies`, {
            method: 'PUT',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              dependencies: formDeps.map((d) => ({
                dependency_type_id: d.dependency_type_id,
                dependency_key: d.dependency_key,
                description: d.description ?? null,
                is_active: true,
              })),
            }),
          }).then((r) => {
            if (!r.ok) throw new Error(`dependencies save failed: ${r.status}`);
          });
        } catch (depErr: any) {
          setError(`Feed saved but dependencies failed: ${depErr.message}`);
        }
      }
      setDialogOpen(false);
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to save feed');
    }
  };

  // ── Actions ────────────────────────────────────────────────────────────────

  // Phase 132.38 — "Trigger with overrides" dialog.  When the user
  // clicks Run on a feed whose publisher declared at least one Dynamic
  // WHERE row, the dialog opens with one input per Dynamic column so
  // the dashboard caller can supply values at trigger time.  Feeds
  // with no Dynamic rows skip the dialog and trigger immediately —
  // legacy one-click run behaviour is preserved.
  const [runDialogFeed, setRunDialogFeed] = useState<FeedConfig | null>(null);
  const [runOverrides, setRunOverrides] = useState<Record<string, any>>({});

  const _dynamicRowsForFeed = useCallback((feed: FeedConfig): WhereClauseRow[] => {
    const mapping = ((feed.query_params || {}) as any)._where_clauses_mapping;
    if (!Array.isArray(mapping)) return [];
    return mapping
      .filter((r: any) => r?.mode === 'dynamic' && (r?.column || '').trim())
      .map((r: any) => ({
        column: r.column,
        operator: r.operator || 'eq',
        value: r.value ?? '',
        mode: 'dynamic',
      }));
  }, []);

  const handleRun = async (feedId: number) => {
    const feed = feeds.find(f => f.id === feedId);
    if (feed) {
      const dynamicRows = _dynamicRowsForFeed(feed);
      if (dynamicRows.length > 0) {
        // Seed override inputs with the publisher's default values so
        // the caller can edit instead of typing from scratch.
        const seed: Record<string, any> = {};
        dynamicRows.forEach(r => {
          if (r.value !== null && r.value !== undefined && r.value !== '') {
            seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
          }
        });
        setRunOverrides(seed);
        setRunDialogFeed(feed);
        return;
      }
    }
    // No Dynamic rows → legacy fire-and-forget behaviour.
    try {
      await api.executeFeed(feedId);
      setSuccess('Feed execution started');
      if (expandedFeedId === feedId) loadExecutions(feedId);
    } catch (err: any) {
      setError(err.message || 'Failed to start execution');
    }
  };

  const confirmRunWithOverrides = async () => {
    const feed = runDialogFeed;
    if (!feed) return;
    // Strip empty-value entries so the engine sees only what the
    // caller actually supplied (Dynamic w/o override = no filter,
    // matches the PV "Dynamic = optional" contract).
    const payload: Record<string, any> = {};
    Object.entries(runOverrides).forEach(([k, v]) => {
      if (v !== null && v !== undefined && String(v).trim() !== '') {
        payload[k] = v;
      }
    });
    setRunDialogFeed(null);
    try {
      await api.executeFeed(
        feed.id,
        Object.keys(payload).length > 0 ? payload : undefined,
      );
      setSuccess(
        Object.keys(payload).length > 0
          ? `Feed execution started (overrides: ${Object.keys(payload).join(', ')})`
          : 'Feed execution started',
      );
      if (expandedFeedId === feed.id) loadExecutions(feed.id);
    } catch (err: any) {
      setError(err.message || 'Failed to start execution');
    }
  };

  // Preview SQL — fetches the resolved query string from the backend
  // resolver (no execution, no DuckDB connection).  Lets users verify
  // what SQL the feed will run before scheduling / debugging.
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewData, setPreviewData] = useState<any>(null);
  const [previewError, setPreviewError] = useState<string>('');
  const handlePreviewSql = useCallback(async (feedId: number) => {
    setPreviewOpen(true);
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewData(null);
    try {
      const data = await api.get(`/api/feeds/${feedId}/preview-sql`);
      setPreviewData(data);
    } catch (err: any) {
      setPreviewError(err?.detail || err?.message || 'Could not load SQL preview');
    } finally {
      setPreviewLoading(false);
    }
  }, []);
  const copyPreviewSql = useCallback(() => {
    const txt = (previewData?.sql || '') +
      (previewData?.secondary_sql ? `\n\n-- Secondary side (${previewData.combine_mode}):\n${previewData.secondary_sql}` : '');
    if (txt) {
      try { navigator.clipboard.writeText(txt); setSuccess('SQL copied'); } catch {}
    }
  }, [previewData]);

  const handleDelete = async (feedId: number) => {
    try {
      await api.deleteFeed(feedId);
      setSuccess('Feed deactivated');
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to delete feed');
    }
  };

  const handleToggleSchedule = async (feed: FeedConfig) => {
    try {
      if (feed.schedule_enabled) {
        await api.disableSchedule(feed.id);
        setSuccess('Schedule disabled');
      } else {
        await api.enableSchedule(feed.id);
        setSuccess('Schedule enabled');
      }
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to toggle schedule');
    }
  };

  const handleTestDest = async (feedId: number) => {
    try {
      const result = await api.testDestination(feedId);
      if (result.success) {
        setSuccess(result.message || 'Destination test passed');
      } else {
        setError(result.message || 'Destination test failed');
      }
    } catch (err: any) {
      setError(err.message || 'Test failed');
    }
  };

  const handleToggleExpand = (feedId: number) => {
    if (expandedFeedId === feedId) {
      setExpandedFeedId(null);
    } else {
      setExpandedFeedId(feedId);
      loadExecutions(feedId);
    }
  };

  const handleRetry = async (execId: number, feedId: number) => {
    try {
      await api.retryFeedExecution(execId);
      setSuccess('Retry started');
      loadExecutions(feedId);
    } catch (err: any) {
      setError(err.message || 'Retry failed');
    }
  };

  const handleCancel = async (execId: number, feedId: number) => {
    try {
      await api.cancelFeedExecution(execId);
      setSuccess('Execution cancelled');
      loadExecutions(feedId);
    } catch (err: any) {
      setError(err.message || 'Cancel failed');
    }
  };

  // ── Render Helpers ─────────────────────────────────────────────────────────

  const formatBytes = (bytes: number) => {
    if (!bytes) return '-';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  const formatDuration = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return '-';
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
  };

  const renderStatusChip = (status: string) => (
    <Chip
      size="small"
      label={status}
      color={STATUS_COLORS[status] || 'default'}
      icon={
        status === 'completed' ? <SuccessIcon /> :
        status === 'failed' ? <ErrorIcon /> :
        status === 'running' ? <PendingIcon /> :
        status === 'cancelled' ? <CancelIcon /> :
        undefined
      }
    />
  );

  // ── Main Render ────────────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" fontWeight={600}>Feed File Generation</Typography>
        <Stack direction="row" spacing={1}>
          {/* Admin-only ad-hoc background-job triggers.  SOD + SLA both
              normally run on the configured cron schedule (no manual
              click needed for daily ops) — these buttons are here so
              admins can force a run after creating new feeds, after a
              missed window, or for testing.  Not on the monitoring
              dashboard — that view is read-only. */}
          {isAdmin && (
            <>
              <Tooltip title="Force-run the SOD generator now (admin only).  Normally runs daily on schedule.">
                <span>
                  <Button
                    startIcon={<SodIcon />}
                    onClick={handleRunSodNow}
                    disabled={adminBusy}
                    variant="outlined"
                  >Run SOD Now</Button>
                </span>
              </Tooltip>
              <Tooltip title="Force the SLA breach sweep (admin only).  Normally runs every minute.">
                <span>
                  <Button
                    startIcon={<SlaIcon />}
                    onClick={handleSlaSweepNow}
                    disabled={adminBusy}
                    variant="outlined"
                  >SLA Sweep</Button>
                </span>
              </Tooltip>
            </>
          )}
          <Button startIcon={<RefreshIcon />} onClick={loadFeeds} disabled={loading}>Refresh</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>New Task</Button>
        </Stack>
      </Stack>

      {error && <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" onClose={() => setSuccess('')} sx={{ mb: 2 }}>{success}</Alert>}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
      ) : feeds.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">No feed configurations yet. Click "New Feed" to create one.</Typography>
        </Paper>
      ) : (
        <Paper>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell />
                <TableCell>Name</TableCell>
                <TableCell>Source</TableCell>
                <TableCell>Format</TableCell>
                <TableCell>Destination</TableCell>
                <TableCell>Schedule</TableCell>
                <TableCell>Runs</TableCell>
                <TableCell title="Row count of the last successful run; feeds the auto-router's size decision">
                  Last rows
                </TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {feeds.map(feed => (
                <React.Fragment key={feed.id}>
                  <TableRow hover sx={{ '& > *': { borderBottom: expandedFeedId === feed.id ? 'none' : undefined } }}>
                    <TableCell sx={{ width: 40, px: 1 }}>
                      <IconButton size="small" onClick={() => handleToggleExpand(feed.id)}>
                        {expandedFeedId === feed.id ? <CollapseIcon /> : <ExpandIcon />}
                      </IconButton>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>{feed.name}</Typography>
                      {feed.description && (
                        <Typography variant="caption" color="text.secondary" display="block">
                          {feed.description}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Chip size="small"
                            label={SOURCE_TYPE_LABELS[feed.source_type] || feed.source_type}
                            variant="outlined" />
                      <Tooltip title={`source_id=${feed.source_id}`}>
                        <Typography variant="caption" color="text.secondary"
                                    display="block" sx={{ maxWidth: 180 }} noWrap>
                          {sourceSummary(feed)}
                        </Typography>
                      </Tooltip>
                      {feed.connection_id && (
                        <Typography variant="caption" color="text.secondary"
                                    display="block" sx={{ maxWidth: 180 }} noWrap>
                          via {connectionLabel(feed.connection_id)}
                        </Typography>
                      )}
                      {feed.secondary_connection_id && (
                        <Tooltip title={
                          `Cross-source ${(feed.combine_mode || 'union').toUpperCase()} ` +
                          `with ${connectionLabel(feed.secondary_connection_id)}`
                        }>
                          <Chip
                            size="small"
                            color="info"
                            variant="outlined"
                            label={`+${(feed.combine_mode || 'union').toUpperCase()}`}
                            sx={{ mt: 0.5, height: 18, fontSize: '0.7rem' }}
                          />
                        </Tooltip>
                      )}
                    </TableCell>
                    <TableCell>{feed.output_format.toUpperCase()}</TableCell>
                    <TableCell>
                      <Chip size="small" label={feed.destination_type} variant="outlined" />
                    </TableCell>
                    <TableCell>
                      {feed.schedule_enabled ? (
                        <Tooltip title={feed.cron_expression || ''}>
                          <Chip size="small" label="Active" color="success" icon={<ScheduleIcon />} />
                        </Tooltip>
                      ) : (
                        <Chip size="small" label="Off" variant="outlined" />
                      )}
                    </TableCell>
                    <TableCell>{feed.run_count}</TableCell>
                    <TableCell sx={{ fontVariantNumeric: 'tabular-nums', fontSize: 12 }}>
                      {feed.last_row_count != null
                        ? feed.last_row_count.toLocaleString()
                        : (feed.estimated_row_count != null
                            ? `~${feed.estimated_row_count.toLocaleString()}`
                            : '—')}
                    </TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        label={feed.is_active ? 'Active' : 'Inactive'}
                        color={feed.is_active ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Stack direction="row" spacing={0} justifyContent="flex-end">
                        <Tooltip title="Preview SQL">
                          <IconButton size="small" onClick={() => handlePreviewSql(feed.id)}>
                            <PreviewSqlIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Run Now">
                          <IconButton size="small" onClick={() => handleRun(feed.id)} disabled={!feed.is_active}>
                            <RunIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title={feed.schedule_enabled ? 'Pause Schedule' : 'Enable Schedule'}>
                          <IconButton size="small" onClick={() => handleToggleSchedule(feed)}
                                      disabled={!feed.is_active || !feed.cron_expression}>
                            {feed.schedule_enabled ? <PauseIcon fontSize="small" /> : <ScheduleIcon fontSize="small" />}
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Test Destination">
                          <IconButton size="small" onClick={() => handleTestDest(feed.id)}>
                            <TestIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => openEdit(feed)}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" color="error" onClick={() => handleDelete(feed.id)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Stack>
                    </TableCell>
                  </TableRow>

                  {/* Execution History Panel */}
                  <TableRow>
                    <TableCell colSpan={9} sx={{ py: 0 }}>
                      <Collapse in={expandedFeedId === feed.id} timeout="auto" unmountOnExit>
                        <Box sx={{ py: 2, px: 2 }}>
                          <Typography variant="subtitle2" gutterBottom>Execution History</Typography>
                          {execLoading ? (
                            <CircularProgress size={20} />
                          ) : executions.length === 0 ? (
                            <Typography variant="body2" color="text.secondary">No executions yet.</Typography>
                          ) : (
                            <Table size="small">
                              <TableHead>
                                <TableRow>
                                  <TableCell>Status</TableCell>
                                  <TableCell>Backend</TableCell>
                                  <TableCell>Trigger</TableCell>
                                  <TableCell>Rows</TableCell>
                                  <TableCell>Size</TableCell>
                                  <TableCell>Duration</TableCell>
                                  <TableCell>Started</TableCell>
                                  <TableCell>Error</TableCell>
                                  <TableCell align="right">Actions</TableCell>
                                </TableRow>
                              </TableHead>
                              <TableBody>
                                {executions.map(exec => (
                                  <TableRow key={exec.id}>
                                    <TableCell>{renderStatusChip(exec.status)}</TableCell>
                                    <TableCell>{exec.execution_backend || '-'}</TableCell>
                                    <TableCell>{exec.trigger_type}</TableCell>
                                    <TableCell>{exec.total_rows?.toLocaleString() || '-'}</TableCell>
                                    <TableCell>{formatBytes(exec.file_size_bytes)}</TableCell>
                                    <TableCell>{formatDuration(exec.duration_seconds)}</TableCell>
                                    <TableCell>
                                      {exec.started_at ? new Date(exec.started_at).toLocaleString() : '-'}
                                    </TableCell>
                                    <TableCell sx={{ maxWidth: 200 }}>
                                      {exec.error_message ? (
                                        <Tooltip title={exec.error_message}>
                                          <Typography variant="caption" color="error" noWrap display="block">
                                            {exec.error_message.slice(0, 80)}
                                          </Typography>
                                        </Tooltip>
                                      ) : '-'}
                                    </TableCell>
                                    <TableCell align="right">
                                      <Stack direction="row" spacing={0} justifyContent="flex-end">
                                        {exec.status === 'failed' && (
                                          <Tooltip title="Retry">
                                            <IconButton size="small" onClick={() => handleRetry(exec.id, feed.id)}>
                                              <RetryIcon fontSize="small" />
                                            </IconButton>
                                          </Tooltip>
                                        )}
                                        {(exec.status === 'pending' || exec.status === 'running') && (
                                          <Tooltip title="Cancel">
                                            <IconButton size="small" onClick={() => handleCancel(exec.id, feed.id)}>
                                              <CancelIcon fontSize="small" />
                                            </IconButton>
                                          </Tooltip>
                                        )}
                                        {exec.status === 'completed' && exec.destination_path && (
                                          <Tooltip title="Download">
                                            <IconButton size="small" onClick={() => window.open(
                                              `/api/feed-executions/${exec.id}/download`, '_blank'
                                            )}>
                                              <DownloadIcon fontSize="small" />
                                            </IconButton>
                                          </Tooltip>
                                        )}
                                      </Stack>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          )}
                        </Box>
                      </Collapse>
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}

      {/* Create / Edit Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editFeed ? 'Edit Task Configuration' : 'New Task Configuration'}</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1 }}>
            <Stepper activeStep={activeStep} sx={{ mb: 3 }}>
              {STEP_LABELS.map(label => (
                <Step key={label}><StepLabel>{label}</StepLabel></Step>
              ))}
            </Stepper>

            {/* Step 0: Source */}
            {activeStep === 0 && (
              <Stack spacing={2}>
                <TextField label="Task Name" value={formName} onChange={e => setFormName(e.target.value)}
                           required fullWidth size="small"
                           helperText="Generic — a task can be a feed file, an Oracle push, an API call, etc." />
                <FormControl fullWidth size="small">
                  <InputLabel id="task-type-label">Task Type</InputLabel>
                  <Select labelId="task-type-label" label="Task Type"
                          value={formTaskType}
                          onChange={(e) => setFormTaskType(e.target.value as 'file_feed' | 'oracle_push' | 'api_push' | 'custom')}>
                    <MenuItem value="file_feed">File feed (CSV / Parquet / JSON / Excel)</MenuItem>
                    <MenuItem value="oracle_push">Oracle push (insert/merge rows)</MenuItem>
                    <MenuItem value="api_push">API push (POST to REST endpoint)</MenuItem>
                    <MenuItem value="custom">Custom</MenuItem>
                  </Select>
                  <FormHelperText>
                    File feed routes through the existing pipeline today; the other
                    types are reserved for future task kinds.
                  </FormHelperText>
                </FormControl>
                <TextField label="Description" value={formDescription} onChange={e => setFormDescription(e.target.value)}
                           fullWidth size="small" multiline rows={2} />
                <FormControl fullWidth size="small">
                  <InputLabel>Source Type</InputLabel>
                  <Select value={formSourceType} label="Source Type"
                          onChange={e => {
                            // Switching type invalidates the current source
                            // pick AND any derived connection; reset both
                            // so the user can't ship a stale source_id from
                            // the previous type.
                            setFormSourceType(e.target.value);
                            setFormSourceId('');
                            setFormConnOverridden(false);
                            setFormConnectionId('');
                          }}>
                    {SOURCE_TYPES.map(t => (
                      <MenuItem key={t} value={t}>{SOURCE_TYPE_LABELS[t] || t}</MenuItem>
                    ))}
                  </Select>
                </FormControl>

                {/* Source picker — shape depends on source_type so the
                    user never has to know a raw numeric ID. */}
                {formSourceType === 'saved_query' && (
                  <Autocomplete
                    size="small"
                    options={savedQueries}
                    value={savedQueries.find(q => q.id === formSourceId) || null}
                    getOptionLabel={q => q.name || `Saved query #${q.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormSourceId(v ? v.id : '');
                      // Any source change invalidates the prior auto-/
                      // manual-set connection — picking a new saved
                      // query should re-derive its own connection_id
                      // even in edit mode.  Manual connection edits
                      // (in the connection picker below) re-flip this
                      // back to true.
                      setFormConnOverridden(false);
                    }}
                    renderOption={(props, q) => (
                      <li {...props} key={q.id}>
                        <Box>
                          <Typography variant="body2">{q.name}</Typography>
                          {q.description && (
                            <Typography variant="caption" color="text.secondary">
                              {q.description}
                            </Typography>
                          )}
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField {...params} label="Saved Query" required
                                 helperText={savedQueries.length === 0
                                   ? 'No saved queries available — create one in the Query Builder first.'
                                   : `${savedQueries.length} saved queries available`} />
                    )}
                  />
                )}

                {formSourceType === 'published_view' && (
                  <Autocomplete
                    size="small"
                    options={publishedViews}
                    value={publishedViews.find(v => v.id === formSourceId) || null}
                    getOptionLabel={v => v.name ? `${v.name} (${v.slug})` : `Published view #${v.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormSourceId(v ? v.id : '');
                      setFormConnOverridden(false);
                    }}
                    renderOption={(props, v) => (
                      <li {...props} key={v.id}>
                        <Box>
                          <Typography variant="body2">{v.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            /{v.slug}{v.description ? ` — ${v.description}` : ''}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField {...params} label="Published View" required
                                 helperText={publishedViews.length === 0
                                   ? 'No published views available — publish one from a saved query first.'
                                   : `${publishedViews.length} published views available`} />
                    )}
                  />
                )}

                {formSourceType === 'sql_file' && (
                  <Autocomplete
                    size="small"
                    options={sqlFilesList}
                    value={sqlFilesList.find(s => s.id === formSourceId) || null}
                    getOptionLabel={s => s.name || `SQL file #${s.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormSourceId(v ? v.id : '');
                      setFormConnOverridden(false);
                    }}
                    renderOption={(props, s) => (
                      <li {...props} key={s.id}>
                        <Box>
                          <Typography variant="body2">{s.name}</Typography>
                          {s.description && (
                            <Typography variant="caption" color="text.secondary">
                              {s.description}
                            </Typography>
                          )}
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField {...params} label="SQL File" required
                                 helperText={sqlFilesList.length === 0
                                   ? 'No SQL files available — save one from the Query Builder first.'
                                   : `${sqlFilesList.length} SQL files available`} />
                    )}
                  />
                )}

                {formSourceType === 'raw_sql' && (
                  <Box>
                    <TextField
                      label="SQL Query"
                      value={formRawSql}
                      onChange={e => setFormRawSql(e.target.value)}
                      required multiline rows={6} fullWidth size="small"
                      placeholder={"SELECT *\nFROM your_table\nWHERE trade_date = '{{business_date}}'"}
                      helperText="Inline SQL — run against the connection picked below.  For reusable queries, save them and pick 'Saved Query' or 'SQL File' instead."
                      sx={{ '& textarea': { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                    />
                    {/* Phase 130 hotfix-13 — inline token reference.  Same
                        substitution layer Published Views use; calendar
                        attached above makes the business-day tokens
                        holiday-aware. */}
                    <Box sx={{ mt: 1, p: 1.2, bgcolor: 'action.hover', borderRadius: 1 }}>
                      <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                        Supported date tokens (auto-resolved at run time):
                      </Typography>
                      <Stack direction="row" gap={0.5} flexWrap="wrap">
                        {[
                          ['{{business_date}}', "Today's business date (calendar-rolled)"],
                          ['{{business_date_yyyymmdd}}', '20260515 format'],
                          ['{{prev_business_day}}', 'Previous business day (skips weekends + holidays when calendar attached)'],
                          ['{{prev_eom}}', 'Last business day of previous month'],
                          ['{{month_end}}', 'Last business day of current month'],
                          ['{{next_month_end}}', 'Last business day of next month'],
                          ['{{run_date}}', 'When the feed actually ran (UTC)'],
                        ].map(([tok, desc]) => (
                          <Tooltip key={tok} title={desc}>
                            <Chip
                              label={tok}
                              size="small"
                              variant="outlined"
                              sx={{ fontFamily: 'monospace', fontSize: '0.7rem', height: 22 }}
                              onClick={() => {
                                // Insert at cursor end — quick paste UX.
                                setFormRawSql(formRawSql + tok);
                              }}
                              clickable
                            />
                          </Tooltip>
                        ))}
                      </Stack>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                        Click a chip to append.  Each token also has <code>_yyyymmdd</code> + <code>_iso</code> variants
                        (e.g. <code>{'{{prev_eom_yyyymmdd}}'}</code>).  Values are SQL-escape-safe.
                      </Typography>
                    </Box>
                  </Box>
                )}

                {/* Connection picker — required for raw_sql, optional
                    elsewhere (auto-derived from source).  Shows an info
                    chip when the value came from the picked source so
                    the user understands why it's pre-filled. */}
                <Box>
                  <Autocomplete
                    size="small"
                    options={connections}
                    value={connections.find(c => c.id === formConnectionId) || null}
                    getOptionLabel={c => c.name || `Connection #${c.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormConnectionId(v ? v.id : '');
                      // Any manual edit suppresses the auto-derive on
                      // subsequent source changes; the user clearly
                      // wants this specific connection.
                      setFormConnOverridden(true);
                    }}
                    renderOption={(props, c) => (
                      <li {...props} key={c.id}>
                        <Box>
                          <Typography variant="body2">{c.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {c.connection_type}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField
                        {...params}
                        label={formSourceType === 'raw_sql' ? 'Connection (required)' : 'Connection'}
                        required={formSourceType === 'raw_sql'}
                        helperText={
                          formSourceType === 'raw_sql'
                            ? 'Required — the SQL runs against this connection.'
                            : (formConnectionId && !formConnOverridden)
                              ? 'Auto-derived from the picked source.  Override only when you want to run against a different connection.'
                              : 'Optional — defaults to the source\'s own connection.'
                        }
                      />
                    )}
                  />
                  {formConnectionId && !formConnOverridden && formSourceType !== 'raw_sql' && (
                    <Chip
                      icon={<InfoIcon fontSize="small" />}
                      size="small"
                      label={`Inherited from ${SOURCE_TYPE_LABELS[formSourceType]}`}
                      color="info"
                      variant="outlined"
                      sx={{ mt: 0.5 }}
                    />
                  )}
                </Box>

                {/* Phase 132.38 — per-feed Static / Dynamic WHERE-clause
                    mapping.  Same primitive Published Views uses.  Static
                    rows are locked at save time; Dynamic rows let a
                    trigger caller (Run-with-overrides dialog OR the
                    /api/v1/feeds/{id}/trigger external endpoint) supply
                    the value at run time via ``query_params``.  Persisted
                    inside query_params._where_clauses_mapping. */}
                <Box>
                  {(() => {
                    // Real column dropdown (no plain text) — pulls
                    // names from the feed's saved SQL.  Partition
                    // badges + per-value autocomplete come from the
                    // connection's partition cache (refetched on
                    // formConnectionId change above).
                    // Phase 133-H round 17 — use resolvedSqlForEditor
                    // which is populated regardless of source_type (raw_sql,
                    // saved_query, sql_file).  formRawSql alone is empty for
                    // saved_query / sql_file sources → editor saw no columns.
                    const _ex = new SqlColumnExtractor(
                      resolvedSqlForEditor || formRawSql,
                      formPartitionInfo.partitionColumns,
                      formPartitionInfo.valueOptionsByColumn,
                    );
                    const _opts = _ex.toColumnOptions();
                    const _vals = _ex.toValueOptions();
                    const _valKnown = Object.keys(_vals).length;
                    // Phase 133-H round 6 — fold in the FULL schema
                    // from formColumnCatalog so the dropdown lists every
                    // column on the source tables (not just the ones
                    // mentioned in the SQL text).
                    const _seen = new Set(_opts.map(o => o.name.toLowerCase()));
                    const _allPartCols = new Set<string>(
                      formPartitionInfo.partitionColumns.map(c => c.toLowerCase()),
                    );
                    Object.values(formColumnCatalog.partitionColumnsByTable).forEach(arr =>
                      arr.forEach(c => _allPartCols.add(c.toLowerCase())),
                    );
                    // Phase 133-I round 22 — iterate WITH the table key
                    // so each pushed option carries ``tableSource``.  The
                    // shared WhereClausesEditor groupBy() uses it to show
                    // columns grouped per table — the CQB UX.
                    Object.entries(formColumnCatalog.columnsByTable).forEach(([tbl, cols]) => {
                      const groupLabel = tbl.replace(/^.*:/, '') || 'Other';
                      cols.forEach(c => {
                        const k = (c.name || '').toLowerCase();
                        if (!k || _seen.has(k)) return;
                        _seen.add(k);
                        _opts.push({
                          name: c.name,
                          type: c.type || 'string',
                          isPartition: _allPartCols.has(k),
                          tableSource: groupLabel,
                        });
                      });
                    });
                    // Phase 133-H round 18 — extract FROM target from
                    // the RESOLVED SQL, not formRawSql.  formRawSql is
                    // empty for saved_query / sql_file sources, so the
                    // round-17 fix populated columns but the lazy
                    // distinct-values fetch still had no table hint
                    // (silent ECONNREFUSED — value picker stayed empty).
                    const _sqlForHint = resolvedSqlForEditor || formRawSql || '';
                    const _fromMatch = _sqlForHint.match(
                      /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
                    );
                    const _tableHint = _fromMatch
                      ? _fromMatch[1].replace(/[\s"`\[\]]/g, '')
                      : null;
                    return (
                      <WhereClausesEditor
                        value={formWhereClauses}
                        onChange={setFormWhereClauses}
                        columnOptions={_opts}
                        valueOptionsByColumn={_vals}
                        connectionId={typeof formConnectionId === 'number' ? formConnectionId : null}
                        distinctValuesTable={_tableHint}
                        classifyTable={_tableHint}
                        title="WHERE Clauses"
                        hint={
                          <>
                            Choose per column whether the value is locked
                            at config time (<strong>Static</strong>) or
                            supplied by the trigger caller at run time
                            (<strong>Dynamic</strong>, override via
                            {' '}<code>query_params</code>).
                            {' '}
                            {_opts.length === 0
                              ? <em>Type SQL above first; columns will auto-populate.</em>
                              : <em>{_opts.length} column(s){
                                  _valKnown > 0
                                    ? `, ${_valKnown} with cached values`
                                    : ''
                                }.</em>}
                          </>
                        }
                        addLabel="Add Mapping"
                      />
                    );
                  })()}
                </Box>

                {/* Phase 130 hotfix-2 — Cross-source combine.
                    When enabled, the feed pulls primary + secondary
                    sides separately (each with its own credentials)
                    and combines them before delivery.  Common use
                    case: AWS S3 + on-prem S3 returning the same
                    schema; UNION ALL BY NAME reconciles them. */}
                <Divider sx={{ pt: 1 }} />
                <FormControlLabel
                  control={
                    <Switch
                      checked={formCrossSourceEnabled}
                      onChange={e => setFormCrossSourceEnabled(e.target.checked)}
                    />
                  }
                  label={
                    <Stack>
                      <Typography variant="body2">Combine with a second connection</Typography>
                      <Typography variant="caption" color="text.secondary">
                        Run the same query (or a different one) on a second source and
                        merge before delivery.  Same credentials never mix.
                      </Typography>
                    </Stack>
                  }
                />
                {formCrossSourceEnabled && (
                  <Stack spacing={2} sx={{ pl: 2, borderLeft: '2px solid', borderColor: 'divider' }}>
                    <Autocomplete
                      size="small"
                      options={connections.filter(c => c.id !== formConnectionId)}
                      value={connections.find(c => c.id === formSecondaryConnectionId) || null}
                      getOptionLabel={c => c.name || `Connection #${c.id}`}
                      isOptionEqualToValue={(a, b) => a.id === b.id}
                      onChange={(_, v) => setFormSecondaryConnectionId(v ? v.id : '')}
                      renderInput={params => (
                        <TextField
                          {...params}
                          label="Secondary connection"
                          required={formCrossSourceEnabled}
                          helperText="The second data source.  Same query runs against this connection by default."
                        />
                      )}
                    />
                    <FormControl size="small" fullWidth>
                      <InputLabel>Combine mode</InputLabel>
                      <Select
                        value={formCombineMode}
                        label="Combine mode"
                        onChange={e => setFormCombineMode(e.target.value as 'union' | 'join')}
                      >
                        <MenuItem value="union">UNION ALL — stack rows from both sides (same schema)</MenuItem>
                        <MenuItem value="join">JOIN — match rows on a key column</MenuItem>
                      </Select>
                    </FormControl>
                    {formCombineMode === 'join' && (
                      <Stack spacing={2}>
                        <FormControl size="small" fullWidth>
                          <InputLabel>Join type</InputLabel>
                          <Select
                            value={formJoinType}
                            label="Join type"
                            onChange={e => setFormJoinType(e.target.value as any)}
                          >
                            <MenuItem value="INNER">INNER</MenuItem>
                            <MenuItem value="LEFT">LEFT</MenuItem>
                            <MenuItem value="RIGHT">RIGHT</MenuItem>
                            <MenuItem value="FULL">FULL OUTER</MenuItem>
                          </Select>
                        </FormControl>
                        {/* Phase 133-I round 19 — JOIN key columns
                            picker.  Was plain TextField (user had to
                            type from memory).  Now multi-Autocomplete
                            sourced from the relevant connection's
                            schema with freeSolo fallback for free-typing. */}
                        <Autocomplete
                          multiple freeSolo size="small" openOnFocus
                          options={Object.values(formColumnCatalog.columnsByTable)
                            .flat()
                            .map(c => c.name)
                            .filter((v, i, a) => v && a.indexOf(v) === i)}
                          value={formJoinKeysLeft
                            ? formJoinKeysLeft.split(',').map(s => s.trim()).filter(Boolean)
                            : []}
                          onChange={(_, v) => setFormJoinKeysLeft(v.join(', '))}
                          renderInput={(rp) => (
                            <TextField {...rp} size="small"
                              label="Primary key columns"
                              placeholder="Pick or type column names"
                              helperText="Columns from the primary side to join on"
                            />
                          )}
                        />
                        <Autocomplete
                          multiple freeSolo size="small" openOnFocus
                          options={Object.values(formSecondaryColumnCatalog.columnsByTable)
                            .flat()
                            .map(c => c.name)
                            .filter((v, i, a) => v && a.indexOf(v) === i)}
                          value={formJoinKeysRight
                            ? formJoinKeysRight.split(',').map(s => s.trim()).filter(Boolean)
                            : []}
                          onChange={(_, v) => setFormJoinKeysRight(v.join(', '))}
                          renderInput={(rp) => (
                            <TextField {...rp} size="small"
                              label="Secondary key columns"
                              placeholder="Pick or type column names"
                              helperText="Must match the number of primary keys"
                            />
                          )}
                        />
                      </Stack>
                    )}
                  </Stack>
                )}
              </Stack>
            )}

            {/* Step 1: Output */}
            {activeStep === 1 && (
              <Stack spacing={2}>
                <FormControl fullWidth size="small">
                  <InputLabel>Output Format</InputLabel>
                  <Select value={formOutputFormat} label="Output Format"
                          onChange={e => setFormOutputFormat(e.target.value)}>
                    {OUTPUT_FORMATS.map(f => <MenuItem key={f} value={f}>{f.toUpperCase()}</MenuItem>)}
                  </Select>
                </FormControl>
                <TextField label="Filename Template" value={formFilenameTemplate}
                           onChange={e => setFormFilenameTemplate(e.target.value)}
                           fullWidth size="small"
                           helperText="Legacy: {name},{date},{ext},{timestamp},{uuid}.  Enterprise: ${YYYYMMDD}, ${COB_PREV_EOM(YYYYMMDD)}, {run_date:YYYYMMDD}" />
                <TextField label="Control File Template (.ctl)" value={formControlFileTemplate}
                           onChange={e => setFormControlFileTemplate(e.target.value)}
                           fullWidth size="small"
                           helperText="Optional sidecar manifest filename.  Leave empty for no .ctl.  Example: feed_{run_date:YYYYMMDD}.ctl"
                           placeholder="feed_{run_date:YYYYMMDD}.ctl" />
                {formControlFileTemplate.trim() && (
                  <FormControl size="small" fullWidth>
                    <InputLabel>Control File Format</InputLabel>
                    <Select
                      value={formControlFileFormatId}
                      label="Control File Format"
                      onChange={e => setFormControlFileFormatId(e.target.value as any)}
                    >
                      <MenuItem value=""><em>Default layout — single SHA-256 checksum</em></MenuItem>
                      {controlFileFormats.map(f => (
                        <MenuItem key={f.id} value={f.id}>
                          {f.name}{f.description ? ` — ${f.description}` : ''}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}
                <FormControl fullWidth size="small">
                  <InputLabel>Execution Backend</InputLabel>
                  <Select value={formBackend} label="Execution Backend"
                          onChange={e => setFormBackend(e.target.value)}>
                    {BACKEND_TYPES.map(b => <MenuItem key={b} value={b}>{b.replace('_', ' ')}</MenuItem>)}
                  </Select>
                </FormControl>
                {/* Help text per chosen backend — operators see when each is appropriate */}
                {formBackend === 'auto' && (
                  <TextField
                    label="Size threshold (rows) — empty = use global default"
                    value={formSizeThresholdRows}
                    onChange={e => setFormSizeThresholdRows(e.target.value.replace(/[^\d]/g, ''))}
                    fullWidth size="small"
                    placeholder="500000"
                    helperText="In auto mode, feeds exceeding this row count route to Airflow. Estimate uses the last successful run's actual row count."
                  />
                )}
                {formBackend === 'spark_connect' && (
                  <Alert severity="info">
                    Spark Connect routes the entire feed through the Spark cluster
                    via gRPC.  Best for big-volume daily extracts where partition
                    layout creates many small files DuckDB can't fan-out efficiently.
                    Requires <code>spark_connect.enabled=true</code> + reachable
                    server (verify via Admin → Spark Connect → Test).  Zero data
                    duplication — Spark reads source files directly.
                  </Alert>
                )}
                {formBackend === 'native' && (
                  <Alert severity="info" sx={{ '& .MuiAlert-message': { width: '100%' } }}>
                    Native = QueryStudio's DuckDB engine.  Fast for moderate
                    volumes (≤ low millions of rows).  Runs in the API pod so
                    output is immediate.
                  </Alert>
                )}
                {formBackend === 'airflow' && (
                  <Alert severity="info">
                    Airflow runs the feed as a DAG on a separate worker.  Good
                    for very large feeds, long-running transformations, or feeds
                    that need to integrate with other ETL jobs.  Requires Airflow
                    to be configured.
                  </Alert>
                )}
              </Stack>
            )}

            {/* Step 2: Destination + Schedule */}
            {activeStep === 2 && (
              <Stack spacing={2}>
                <FormControl fullWidth size="small">
                  <InputLabel>Destination Type</InputLabel>
                  <Select value={formDestType} label="Destination Type"
                          onChange={e => setFormDestType(e.target.value)}>
                    {DESTINATION_TYPES.map(d => <MenuItem key={d} value={d}>{d.toUpperCase()}</MenuItem>)}
                  </Select>
                </FormControl>

                {formDestType === 'local' && (
                  <TextField label="Output Directory" value={formDestPath}
                             onChange={e => setFormDestPath(e.target.value)}
                             fullWidth size="small" placeholder="data/feeds" />
                )}
                {formDestType === 's3' && (
                  <>
                    <TextField label="S3 Bucket" value={formDestBucket}
                               onChange={e => setFormDestBucket(e.target.value)}
                               fullWidth size="small" required />
                    <TextField label="S3 Prefix" value={formDestPrefix}
                               onChange={e => setFormDestPrefix(e.target.value)}
                               fullWidth size="small" />
                  </>
                )}
                {formDestType === 'sftp' && (
                  <>
                    <Stack direction="row" spacing={1}>
                      <TextField label="Host" value={formDestHost}
                                 onChange={e => setFormDestHost(e.target.value)}
                                 size="small" required sx={{ flex: 3 }} />
                      <TextField label="Port" value={formDestPort}
                                 onChange={e => setFormDestPort(e.target.value)}
                                 size="small" sx={{ flex: 1 }} />
                    </Stack>
                    <Stack direction="row" spacing={1}>
                      <TextField label="Username" value={formDestUser}
                                 onChange={e => setFormDestUser(e.target.value)}
                                 size="small" sx={{ flex: 1 }} />
                      <TextField label="Password" type="password" value={formDestPassword}
                                 onChange={e => setFormDestPassword(e.target.value)}
                                 size="small" sx={{ flex: 1 }} />
                    </Stack>
                    <TextField label="Remote Directory" value={formDestRemoteDir}
                               onChange={e => setFormDestRemoteDir(e.target.value)}
                               fullWidth size="small" />
                  </>
                )}

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Schedule</Typography>
                <FormControlLabel
                  control={<Switch checked={formScheduleEnabled}
                                   onChange={e => setFormScheduleEnabled(e.target.checked)} />}
                  label="Enable Scheduled Execution"
                />
                {formScheduleEnabled && (
                  <>
                    <Stack direction="row" spacing={1}>
                      <TextField
                        label="Cron Expression"
                        value={formCron}
                        onChange={e => setFormCron(e.target.value)}
                        size="small" sx={{ flex: 2 }}
                        placeholder="0 6 * * *"
                        helperText={describeCron(formCron) || 'min hour day-of-month month day-of-week — e.g. 0 6 * * * = daily at 06:00'}
                        FormHelperTextProps={{
                          sx: describeCron(formCron) ? { color: 'success.main', fontWeight: 500 } : undefined,
                        }}
                      />
                      <Autocomplete
                        size="small"
                        options={TIMEZONES}
                        value={formTimezone}
                        onChange={(_, v) => setFormTimezone(v || 'UTC')}
                        disableClearable
                        sx={{ flex: 1 }}
                        renderInput={params => <TextField {...params} label="Timezone" />}
                      />
                    </Stack>
                    {/* Common-pattern shortcuts so users don't have to remember cron syntax. */}
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                      {[
                        { label: 'Every hour',        expr: '0 * * * *' },
                        { label: 'Daily 06:00',       expr: '0 6 * * *' },
                        { label: 'Daily 22:00',       expr: '0 22 * * *' },
                        { label: 'Weekdays 09:00',    expr: '0 9 * * 1-5' },
                        { label: 'Mondays 08:00',     expr: '0 8 * * 1' },
                        { label: 'Monthly 1st 02:00', expr: '0 2 1 * *' },
                      ].map(p => (
                        <Chip
                          key={p.expr}
                          size="small"
                          label={p.label}
                          variant={formCron === p.expr ? 'filled' : 'outlined'}
                          color={formCron === p.expr ? 'primary' : 'default'}
                          onClick={() => setFormCron(p.expr)}
                          clickable
                        />
                      ))}
                    </Stack>
                  </>
                )}

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Notifications</Typography>
                <Stack direction="row" spacing={2}>
                  <FormControlLabel
                    control={<Switch checked={formNotifySuccess}
                                     onChange={e => setFormNotifySuccess(e.target.checked)} size="small" />}
                    label="On Success"
                  />
                  <FormControlLabel
                    control={<Switch checked={formNotifyFailure}
                                     onChange={e => setFormNotifyFailure(e.target.checked)} size="small" />}
                    label="On Failure"
                  />
                </Stack>
                <TextField label="Notification Emails (comma-separated)" value={formNotifyEmails}
                           onChange={e => setFormNotifyEmails(e.target.value)}
                           fullWidth size="small" />
              </Stack>
            )}

            {/* Step 3: Controls & Entitlement (Phase 130 hotfix-13 + Phase 131) */}
            {activeStep === 3 && (
              <Stack spacing={2}>
                {/* Phase 130 hotfix-13 — Entitlement + Calendar pickers */}
                <Typography variant="subtitle2">Entitlement &amp; Calendar</Typography>
                <FormControl fullWidth size="small">
                  <InputLabel id="owner-group-label">Owner Group (optional)</InputLabel>
                  <Select
                    labelId="owner-group-label"
                    label="Owner Group (optional)"
                    value={formOwnerGroupId === '' ? '' : String(formOwnerGroupId)}
                    onChange={(e) => {
                      const v = e.target.value;
                      setFormOwnerGroupId(v === '' ? '' : Number(v));
                    }}
                  >
                    <MenuItem value=""><em>No group — solo (only creator + admins)</em></MenuItem>
                    {userGroupsList.map((g) => (
                      <MenuItem key={g.id} value={String(g.id)}>
                        {g.name}{g.description ? ` — ${g.description}` : ''}
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    Group members get view/edit access per their access level (read_only vs read_write).
                  </FormHelperText>
                </FormControl>
                <FormControl fullWidth size="small">
                  <InputLabel id="calendar-label">Business Calendar (optional)</InputLabel>
                  <Select
                    labelId="calendar-label"
                    label="Business Calendar (optional)"
                    value={formCalendarName}
                    onChange={(e) => setFormCalendarName(String(e.target.value))}
                  >
                    <MenuItem value=""><em>None — plain calendar-day arithmetic</em></MenuItem>
                    {calendarsList.map((c) => (
                      <MenuItem key={c.id} value={c.name}>{c.name}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    Drives <code>{'{{business_date}}'}</code>, <code>{'{{prev_business_day}}'}</code>,
                    <code>{'{{prev_eom}}'}</code> — skips weekends + holidays when attached.
                  </FormHelperText>
                </FormControl>

                {/* BF-473 — Frequency Category (open string, admin-suggested vocabulary) */}
                <FormControl fullWidth size="small">
                  <InputLabel id="frequency-cat-label">Frequency category (optional)</InputLabel>
                  <Select
                    labelId="frequency-cat-label"
                    label="Frequency category (optional)"
                    value={formFrequencyCategory}
                    onChange={(e) => setFormFrequencyCategory(String(e.target.value))}
                  >
                    <MenuItem value=""><em>Uncategorized</em></MenuItem>
                    {frequencyCategoriesList.map((c) => (
                      <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    Operator-facing label for dashboards / filtering.  Actual firing is
                    still controlled by <code>cron_expression</code> + <code>action_condition_sql</code>.
                    Need a new category? Type it in the database — it shows up here next time.
                  </FormHelperText>
                </FormControl>

                {/* Phase 131 — Production Controls (opt-in safety gates) */}
                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Production Controls (Phase 131)</Typography>

                {/* 131-A — Inline dependency editor (end-user owned).
                    Each row gates the feed on a Kafka topic / Oracle
                    table partition / FILE arrival / API event for the
                    current business_date.  Backend auto-fills etl_id
                    when deps exist so the poller picks the feed up. */}
                <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                  <Typography variant="body2" sx={{ mb: 0.5 }}>
                    Upstream dependencies (triggers)
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                    Generic trigger gating: any external system, Kafka topic, file landing,
                    or API event.  Feed waits until ALL rows have <code>action=COMPLETE</code> or
                    <code>SKIP</code> for the run's business_date.  Leave empty to run unconditionally.
                  </Typography>

                  {formDeps.length > 0 && (
                    <Table size="small" sx={{ mb: 1 }}>
                      <TableHead>
                        <TableRow>
                          <TableCell>Type</TableCell>
                          <TableCell>Dependency key</TableCell>
                          <TableCell>Description</TableCell>
                          <TableCell />
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {formDeps.map((d, idx) => {
                          const t = availableDepTypes.find((x) => x.id === d.dependency_type_id);
                          return (
                            <TableRow key={d.id ?? `new-${idx}`}>
                              <TableCell><code>{t?.dependency_type || d.dependency_type || d.dependency_type_id}</code></TableCell>
                              <TableCell><code>{d.dependency_key}</code></TableCell>
                              <TableCell>
                                <Typography variant="caption" color="text.secondary">
                                  {d.description || ''}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <IconButton size="small"
                                  onClick={() => setFormDeps((prev) => prev.filter((_, i) => i !== idx))}>
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  )}

                  <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                    <FormControl size="small" sx={{ minWidth: 160 }}>
                      <InputLabel id="new-dep-type-label">Dependency type</InputLabel>
                      <Select labelId="new-dep-type-label" label="Dependency type"
                        value={newDepTypeId === '' ? '' : String(newDepTypeId)}
                        onChange={(e) => setNewDepTypeId(
                          e.target.value === '' ? '' : Number(e.target.value),
                        )}>
                        {availableDepTypes.length === 0 && (
                          <MenuItem value="" disabled>
                            <em>No types — ask admin to add KAFKA / ORACLE_TABLE / FILE / API</em>
                          </MenuItem>
                        )}
                        {availableDepTypes.map((t) => (
                          <MenuItem key={t.id} value={String(t.id)}>{t.dependency_type}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    <TextField label="Dependency key (e.g. topic.daily-prices)"
                      size="small" sx={{ flex: 1, minWidth: 200 }}
                      value={newDepKey}
                      onChange={(e) => setNewDepKey(e.target.value)} />
                    <TextField label="Description (optional)"
                      size="small" sx={{ minWidth: 180 }}
                      value={newDepDesc}
                      onChange={(e) => setNewDepDesc(e.target.value)} />
                    <Button variant="outlined"
                      onClick={() => {
                        if (!newDepTypeId || !newDepKey.trim()) return;
                        setFormDeps((prev) => [...prev, {
                          dependency_type_id: Number(newDepTypeId),
                          dependency_key: newDepKey.trim(),
                          description: newDepDesc.trim() || null,
                        }]);
                        setNewDepKey('');
                        setNewDepDesc('');
                      }}
                      disabled={!newDepTypeId || !newDepKey.trim()}>
                      Add
                    </Button>
                  </Stack>
                </Box>
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ minWidth: 180 }}>
                    <InputLabel id="rc-action-label">Row-count check</InputLabel>
                    <Select
                      labelId="rc-action-label"
                      label="Row-count check"
                      value={formRowCountAction}
                      onChange={(e) => setFormRowCountAction(e.target.value as 'off'|'warn'|'fail')}
                    >
                      <MenuItem value="off">Off (no check)</MenuItem>
                      <MenuItem value="warn">Warn on breach</MenuItem>
                      <MenuItem value="fail">Fail on breach</MenuItem>
                    </Select>
                  </FormControl>
                  <TextField
                    label="Threshold % (deviation)"
                    type="number"
                    value={formRowCountThresholdPct}
                    onChange={(e) => setFormRowCountThresholdPct(e.target.value)}
                    size="small" sx={{ minWidth: 180 }}
                    disabled={formRowCountAction === 'off'}
                    helperText="Empty = system default (10%)"
                  />
                </Stack>
                <FormControl fullWidth size="small">
                  <InputLabel id="ic-label">File integrity check</InputLabel>
                  <Select
                    labelId="ic-label"
                    label="File integrity check"
                    value={formIntegrityCheck}
                    onChange={(e) => setFormIntegrityCheck(e.target.value as 'inherit'|'on'|'off')}
                  >
                    <MenuItem value="inherit">Inherit system default</MenuItem>
                    <MenuItem value="on">Always on for this feed</MenuItem>
                    <MenuItem value="off">Disabled for this feed</MenuItem>
                  </Select>
                  <FormHelperText>
                    Verifies parquet footer / CSV line count + post-delivery S3 size. Safe to keep on.
                  </FormHelperText>
                </FormControl>
              </Stack>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          {activeStep > 0 && <Button onClick={() => setActiveStep(s => s - 1)}>Back</Button>}
          {activeStep < STEP_LABELS.length - 1 ? (
            <Button variant="contained" onClick={() => setActiveStep(s => s + 1)}
                    disabled={activeStep === 0 && !_step0Ready}>
              Next
            </Button>
          ) : (
            <Button variant="contained" onClick={handleSave}
                    disabled={!_allStepsReady}
                    title={!_allStepsReady ? 'Required fields missing — review each step' : undefined}>
              {editFeed ? 'Update' : 'Create'}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Phase 132.38 — Trigger-with-overrides dialog.  Appears only
          when the user clicks Run on a feed whose publisher declared at
          least one Dynamic WHERE row.  The dialog shows one input per
          Dynamic column so the dashboard caller can supply per-run
          values.  Static rows stay locked; the consumer cannot edit
          them here even if they wanted to.  Empty inputs are stripped
          so "Dynamic without value = no filter on that column" — same
          contract as PVs. */}
      <Dialog
        open={Boolean(runDialogFeed)}
        onClose={() => setRunDialogFeed(null)}
        maxWidth="sm" fullWidth
      >
        <DialogTitle>
          Run feed: {runDialogFeed?.name || ''}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <Alert severity="info">
              This feed declares <strong>Dynamic</strong> WHERE rows.
              Supply values below or leave blank to skip the filter.
              Static rows are locked at publish time and not editable
              here.
            </Alert>
            {runDialogFeed && (() => {
              // Phase 133-H — table hint for the lazy distinct-values
              // lookup.  Pull FROM targets from the feed's primary +
              // secondary SQL.  Cross-source feeds have a secondary
              // connection: surface it as a fallback so a Dynamic row
              // whose column lives on the secondary side still gets a
              // dropdown.
              const _params = (runDialogFeed.query_params as any) || {};
              const _pickFrom = (s: string | undefined) => {
                if (!s) return null;
                const m = s.match(
                  /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
                );
                return m ? m[1].replace(/[\s"`\[\]]/g, '') : null;
              };
              const _primaryTable = _pickFrom(_params.raw_sql);
              const _secondaryTable = _pickFrom(_params.secondary_raw_sql);
              const _cid = runDialogFeed.connection_id ?? null;
              const _secCid = (runDialogFeed as any).secondary_connection_id ?? null;
              const _fallback: Array<{ connectionId: number; table: string }> = [];
              if (_secCid && _secondaryTable) {
                _fallback.push({ connectionId: _secCid, table: _secondaryTable });
              }
              return _dynamicRowsForFeed(runDialogFeed).map((row) => (
                <DynamicWhereOverrideField
                  key={row.column}
                  column={row.column}
                  operator={row.operator}
                  publisherDefault={row.value}
                  value={runOverrides[row.column] ?? ''}
                  onChange={(next) => setRunOverrides(prev => ({
                    ...prev, [row.column]: next,
                  }))}
                  connectionId={_cid}
                  table={_primaryTable}
                  fallbackTargets={_fallback}
                />
              ));
            })()}
            {runDialogFeed && _dynamicRowsForFeed(runDialogFeed).length === 0 && (
              <Typography variant="body2" color="text.secondary">
                No Dynamic rows on this feed.
              </Typography>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRunDialogFeed(null)}>Cancel</Button>
          <Button
            variant="contained" startIcon={<RunIcon />}
            onClick={confirmRunWithOverrides}
          >
            Run Feed
          </Button>
        </DialogActions>
      </Dialog>

      {/* Run SOD Now — date picker dialog (admin only).  Lets admin
          backfill a missed day or seed a fresh feed_config mid-day. */}
      <Dialog open={sodDialogOpen} onClose={() => setSodDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Run SOD Generator</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Creates/updates <code>feed_runs</code> rows for the chosen business date.
              Idempotent — if rows already exist for (feed × business_date) they are
              not duplicated.  Per-feed calendars are respected (e.g. weekend-skip
              calendars roll the business_date back to the previous business day).
            </Typography>
            <TextField
              label="Business date"
              type="date"
              value={sodDate}
              onChange={(e) => setSodDate(e.target.value)}
              fullWidth size="small"
              InputLabelProps={{ shrink: true }}
              helperText="Defaults to today (UTC).  Pick an earlier date to backfill."
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSodDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={confirmRunSodNow}
                  disabled={!sodDate || adminBusy}
                  startIcon={<SodIcon />}>
            Run SOD for {sodDate || '…'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Preview SQL dialog — shows the resolved query the feed will run,
          plus source / connection metadata so users can verify before
          scheduling. */}
      <Dialog open={previewOpen} onClose={() => setPreviewOpen(false)}
              fullWidth maxWidth="md">
        <DialogTitle>
          <Stack direction="row" alignItems="center" spacing={1}>
            <PreviewSqlIcon fontSize="small" />
            <Box sx={{ flexGrow: 1 }}>Feed Query Preview</Box>
            {previewData?.sql && (
              <Tooltip title="Copy to clipboard">
                <IconButton size="small" onClick={copyPreviewSql}>
                  <CopyIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          {previewLoading && <CircularProgress size={20} />}
          {previewError && <Alert severity="error" sx={{ mb: 2 }}>{previewError}</Alert>}
          {previewData && !previewLoading && (
            <>
              <Stack direction="row" spacing={1} sx={{ mb: 1.5, flexWrap: 'wrap' }}>
                <Chip size="small" label={`Source: ${previewData.source_type} · ${previewData.source_name}`} />
                {previewData.connection_name && (
                  <Chip size="small" color="primary" variant="outlined"
                        label={`Connection: ${previewData.connection_name} (${previewData.connection_type})`} />
                )}
                <Chip size="small" variant="outlined" label={`Dialect: ${previewData.dialect}`} />
                {previewData.combine_mode && (
                  <Chip size="small" color="secondary"
                        label={`Cross-conn: ${previewData.combine_mode.toUpperCase()}`} />
                )}
              </Stack>
              {previewData.source_status !== 'ok' && (
                <Alert severity={previewData.source_status === 'not_found' || previewData.source_status === 'missing_file' ? 'error' : 'warning'}
                       sx={{ mb: 2 }}>
                  <strong>{previewData.source_status}:</strong> {previewData.source_message}
                </Alert>
              )}
              {previewData.sql ? (
                <Box component="pre"
                     sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                           borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 360,
                           fontFamily: 'JetBrains Mono, Menlo, monospace', whiteSpace: 'pre-wrap' }}>
                  {previewData.sql}
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                  No SQL available for this feed (see status above).
                </Typography>
              )}
              {previewData.secondary_sql && (
                <>
                  <Typography variant="caption" sx={{ display: 'block', mt: 2, mb: 0.5, color: 'text.secondary' }}>
                    Secondary side ({previewData.combine_mode}) — {previewData.secondary_connection_name || ''}
                  </Typography>
                  <Box component="pre"
                       sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                             borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 240,
                             fontFamily: 'JetBrains Mono, Menlo, monospace', whiteSpace: 'pre-wrap' }}>
                    {previewData.secondary_sql}
                  </Box>
                </>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default FeedConfigsPage;
