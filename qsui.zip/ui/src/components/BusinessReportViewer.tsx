/**
 * Phase 56+81 — Business Report Viewer
 *
 * Phase 81 enhancements:
 *  - Server-side pagination (page/page_size query params)
 *  - Column header sorting (clickable, cyclic null→asc→desc→null)
 *  - Grand totals footer row (sum numeric cols)
 *  - Better data-type cell formatting (numbers, dates, booleans, nulls)
 *  - Async execution with progress bar + Cancel button
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination,
  TableFooter, CircularProgress, Alert, TextField, Select, MenuItem, Menu, FormControl,
  InputLabel, Collapse, Breadcrumbs, Link, Tooltip, Badge, LinearProgress,
  FormControlLabel, Switch, ListItemIcon, ListItemText, Snackbar,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  PlayArrow as PlayIcon,
  Edit as EditIcon,
  GetApp as ExportIcon,
  PictureAsPdf as PdfIcon,
  TableView as ExcelIcon,
  ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon,
  Bolt as BoltIcon,
  NavigateNext as NavNextIcon,
  FilterList as FilterIcon,
  ContentCopy as DuplicateIcon,
  CheckCircle as CertifiedIcon,
  Link as ShareLinkIcon,
  Code as EmbedCodeIcon,
  Email as EmailIcon,
  ArrowUpward as SortAscIcon,
  ArrowDownward as SortDescIcon,
  UnfoldMore as SortNoneIcon,
  Cancel as CancelIcon,
  FlashOn as FlashOnIcon,
  InfoOutlined as InfoOutlinedIcon,
  Public as PublishApiIcon,
  History as HistoryIcon,
  KeyboardArrowUp as DrillUpIcon,
  KeyboardDoubleArrowDown as ExpandNextLevelIcon,
  AccountTree as GoNextLevelIcon,
  TouchApp as DrillClickIcon,
  ChatBubbleOutline as CommentIcon,
  Timeline as TimelineIcon,
} from '@mui/icons-material';
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors,
} from '@dnd-kit/core';
import {
  SortableContext, horizontalListSortingStrategy, useSortable, arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import api from '../services/api';
import { applyFormatPattern, formatAccounting } from '../utils/formatters';
import { resolveParamDefault } from '../utils/parameterUtils';
import { useParamLovs } from '../hooks/useParamLovs';
import { useWebSocket } from '../context/WebSocketContext';
import SubscriptionManager from './SubscriptionManager';
import PublishViewDialog from './PublishViewDialog';
import ReportCommentPanel from './ReportCommentPanel';
import ReportChangeHistory from './ReportChangeHistory';
import useReportEngine, { SectionDef, RunningCalcDef, DrillState, BandedRow, MeasureAggConfig } from '../hooks/useReportEngine';

// ── Constants ────────────────────────────────────────────────────────────────

const DEFAULT_PAGE_SIZE = 500;
const PAGE_SIZE_OPTIONS = [100, 200, 500, 1000, 2000, 5000];

// Default style config (used when report has no layout_config.style_config)
interface StyleConfig {
  header_bg: string; header_text: string; accent_color: string;
  negative_format: 'brackets' | 'minus' | 'red';
  stripe_rows: boolean; subtotal_bg: string; grand_total_bg: string;
}
const DEFAULT_STYLE: StyleConfig = {
  header_bg: '#1976D2', header_text: '#FFFFFF', accent_color: '#e3f2fd',
  negative_format: 'brackets', stripe_rows: true,
  subtotal_bg: '#f5f5f5', grand_total_bg: '#e8eaf6',
};

const getRowStyles = (sc: StyleConfig): Record<string, any> => ({
  header: { bgcolor: sc.accent_color, fontWeight: 'bold' },
  subtotal: { bgcolor: sc.subtotal_bg, fontWeight: 'bold', fontStyle: 'italic' },
  grand_total: { bgcolor: sc.grand_total_bg, fontWeight: 'bold' },
  data: {},
});

// ── Data type helpers ─────────────────────────────────────────────────────────

function detectColType(colName: string, sampleValue: any): 'integer' | 'float' | 'date' | 'datetime' | 'boolean' | 'string' {
  if (typeof sampleValue === 'boolean') return 'boolean';
  if (typeof sampleValue === 'number') {
    return Number.isInteger(sampleValue) ? 'integer' : 'float';
  }
  if (typeof sampleValue === 'string') {
    // ISO date: YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(sampleValue)) return 'date';
    // ISO datetime
    if (/^\d{4}-\d{2}-\d{2}T/.test(sampleValue)) return 'datetime';
  }
  return 'string';
}

function formatCellValue(
  value: any, colType: string, formatPattern?: string, dataType?: string,
  negativeFormat: 'brackets' | 'minus' | 'red' = 'brackets',
): React.ReactNode {
  if (value === null || value === undefined) return <span style={{ color: '#aaa' }}>—</span>;

  // Phase 101: apply semantic layer format pattern if available
  if (formatPattern) {
    const formatted = applyFormatPattern(value, formatPattern, dataType);
    if (formatted !== null) {
      // Wrap negative numbers in styling
      const num = typeof value === 'number' ? value : parseFloat(String(value));
      if (!isNaN(num) && num < 0) {
        const display = negativeFormat === 'brackets'
          ? formatted.replace(/^-/, '').replace(/^(.*)$/, '($1)')
          : formatted;
        return <span style={{ color: '#d32f2f' }}>{display}</span>;
      }
      return formatted;
    }
  }

  if (colType === 'boolean') return value ? '✓' : '✗';

  // Numeric columns — apply negative formatting
  if (colType === 'integer' || colType === 'float') {
    const num = typeof value === 'number' ? value : parseFloat(String(value));
    if (isNaN(num)) return String(value);
    const decimals = colType === 'float' ? 2 : 0;
    if (num < 0) {
      const display = negativeFormat === 'brackets'
        ? formatAccounting(num, decimals)
        : num.toLocaleString(undefined, { maximumFractionDigits: decimals });
      return <span style={{ color: '#d32f2f' }}>{display}</span>;
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals });
  }

  if (colType === 'date') {
    try { return new Date(String(value)).toLocaleDateString(); }
    catch { return String(value); }
  }
  if (colType === 'datetime') {
    try { return new Date(String(value)).toLocaleString(); }
    catch { return String(value); }
  }
  return String(value);
}

// ── Component ────────────────────────────────────────────────────────────────

const BusinessReportViewer: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const reportId = Number(id);
  const { addListener } = useWebSocket();

  // Report state
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');

  // Subscription dialog
  const [subOpen, setSubOpen] = useState(false);

  // Phase 91: Publish as API dialog
  const [publishApiOpen, setPublishApiOpen] = useState(false);

  // Execution state
  const [executing, setExecuting] = useState(false);
  const [asyncExecId, setAsyncExecId] = useState<string | null>(null);
  const [asyncProgress, setAsyncProgress] = useState(0);
  // WS wakeup: resolve the polling sleep early when WS message arrives
  const wsPollWakeup = useRef<(() => void) | null>(null);
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [rawRows, setRawRows] = useState<any[]>([]);
  const [resultColumns, setResultColumns] = useState<string[]>([]);
  // All rows for client-side drill (loaded once after execution)
  const [allRows, setAllRows] = useState<any[]>([]);
  const [allRowsLoading, setAllRowsLoading] = useState(false);

  // Pagination
  const [page, setPage] = useState(0);  // 0-indexed for MUI
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [totalRows, setTotalRows] = useState(0);

  // Sorting (Phase 81 FIX 3)
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc' | null>(null);

  // Grand totals (Phase 81 FIX 9)
  const [showTotals, setShowTotals] = useState(true);

  // Parameter state
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  const [paramsPanelOpen, setParamsPanelOpen] = useState(true);

  // Slicer state
  const [slicerValues, setSlicerValues] = useState<Record<string, any[]>>({});

  // Drill state
  const [drillState, setDrillState] = useState<DrillState>({ level: 0, filters: [] });
  const [drillHierarchyLevels, setDrillHierarchyLevels] = useState<Array<{ column_name: string; label: string }>>([]);
  const [drillClickMode, setDrillClickMode] = useState(false); // when true, clicking a row drills down
  // expandedLevels: how many hierarchy levels to show as columns (0 = just report columns)
  const [expandedLevels, setExpandedLevels] = useState(0);

  // Column metadata (for resolving names)
  const [datasetColumns, setDatasetColumns] = useState<any[]>([]);
  // Column display order (drag-drop reorder in viewer, persisted to layout_config)
  const [columnOrder, setColumnOrder] = useState<string[] | null>(null);
  const saveOrderTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollAbort = useRef(false);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (saveOrderTimer.current) clearTimeout(saveOrderTimer.current);
      pollAbort.current = true;
    };
  }, []);

  // Execution history
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyItems, setHistoryItems] = useState<any[]>([]);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyPage, setHistoryPage] = useState(0); // 0-indexed for MUI
  const [historyPageSize, setHistoryPageSize] = useState(10);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Phase 114-L: Collaboration panel
  const [collabTab, setCollabTab] = useState<'comments' | 'history'>('comments');
  const [collabOpen, setCollabOpen] = useState(false);
  const [commentCount, setCommentCount] = useState(0);

  const loadHistory = useCallback(async (pg: number, ps: number) => {
    if (!reportId) return;
    setHistoryLoading(true);
    try {
      const res = await api.getExecutionHistory(reportId, pg + 1, ps);
      setHistoryItems(res.items || []);
      setHistoryTotal(res.total || 0);
    } catch { /* ignore */ }
    finally { setHistoryLoading(false); }
  }, [reportId]);

  useEffect(() => {
    if (historyOpen) loadHistory(historyPage, historyPageSize);
  }, [historyOpen, historyPage, historyPageSize, loadHistory]);

  // ── WS listener: wake up polling early on report execution events ─────────
  useEffect(() => {
    return addListener((msg: any) => {
      if (!msg || !msg.type) return;
      if ((msg.type === 'report_execution_completed' || msg.type === 'report_execution_failed')
          && msg.report_id === reportId) {
        // Wake up polling sleep immediately
        if (wsPollWakeup.current) wsPollWakeup.current();
      }
    });
  }, [addListener, reportId]);

  // ── Load report ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (!reportId) return;
    setLoading(true);
    (async () => {
      try {
        const r = await api.getBusinessReport(reportId);
        setReport(r);
        // Restore saved column order from layout_config (reset if none saved)
        const savedOrder = r.layout_config?.column_order;
        setColumnOrder(Array.isArray(savedOrder) && savedOrder.length > 0 ? savedOrder : null);
        // Init param values with defaults (resolve @TODAY etc. for date types)
        const defaults: Record<string, any> = {};
        for (const p of (r.parameters || [])) {
          defaults[p.name] = resolveParamDefault(p);
        }
        setParamValues(defaults);
        // Init slicer values
        const sv: Record<string, any[]> = {};
        for (const colId of (r.slicer_column_ids || [])) {
          sv[String(colId)] = [];
        }
        setSlicerValues(sv);
        // Load dataset columns + drill hierarchies
        const ds = await api.getDataset(r.dataset_id);
        const cols = ds?.columns || [];
        setDatasetColumns(cols);
        // Resolve drill hierarchy levels to physical column names
        if (r.drill_hierarchy_id && ds?.hierarchies) {
          const h = (ds.hierarchies as any[]).find((h: any) => h.id === r.drill_hierarchy_id);
          if (h?.levels) {
            const resolved = (h.levels as any[]).map((lv: any) => {
              const col = cols.find((c: any) => c.id === lv.column_id);
              return { column_name: col?.physical_name || '', label: lv.label || col?.friendly_name || '' };
            }).filter((lv: any) => lv.column_name);
            setDrillHierarchyLevels(resolved);
            setDrillState({ level: 0, filters: [], hierarchy_levels: resolved });
          }
        }
      } catch (err: any) {
        const msg = (err?.message || '').toLowerCase();
        if (msg.includes('access denied') || msg.includes('403')) setError('Access denied: you do not have permission to view this report.');
        else if (msg.includes('not found') || msg.includes('404')) setError('Report not found. It may have been deleted.');
        else setError('Failed to load report');
      } finally {
        setLoading(false);
      }
    })();
  }, [reportId]);

  // Phase 114-L: Load comment count
  useEffect(() => {
    if (!reportId) return;
    api.countReportComments(reportId).then((r: any) => setCommentCount(r?.count || 0)).catch(() => {});
  }, [reportId]);

  // ── Shared LOV hook (cascade-aware, parallel loading) ─────────────────────
  const paramLovs = useParamLovs({ reportId, parameters: report?.parameters, paramValues });

  // ── Column name resolver ──────────────────────────────────────────────────

  const getColDisplayName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  }, [datasetColumns]);

  const getColPhysicalName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col?.physical_name || `col_${colId}`;
  }, [datasetColumns]);

  // ── Build engine input ────────────────────────────────────────────────────

  const sectionDefs: SectionDef[] = useMemo(() => {
    if (!report?.section_definitions) return [];
    return report.section_definitions.map((s: any) => ({
      ...s,
      break_column_name: getColPhysicalName(s.break_column_id),
      subtotal_measure_names: (s.subtotal_measure_ids || []).map((id: number) => getColPhysicalName(id)),
    }));
  }, [report?.section_definitions, getColPhysicalName]);

  const runningCalcs: RunningCalcDef[] = useMemo(() => {
    if (!report?.running_calculations) return [];
    return report.running_calculations.map((c: any) => ({
      ...c,
      measure_col_name: getColPhysicalName(c.measure_col_id),
      partition_col_name: c.partition_col_id ? getColPhysicalName(c.partition_col_id) : undefined,
    }));
  }, [report?.running_calculations, getColPhysicalName]);

  // Resolve style config from report's layout_config (or use defaults)
  const styleConfig: StyleConfig = useMemo(() => {
    const sc = report?.layout_config?.style_config;
    return sc ? { ...DEFAULT_STYLE, ...sc } : DEFAULT_STYLE;
  }, [report?.layout_config]);

  const rowTypeStyles = useMemo(() => getRowStyles(styleConfig), [styleConfig]);

  // Map slicer column IDs to physical names for the engine
  const slicerByName = useMemo(() => {
    const mapped: Record<string, any[]> = {};
    for (const [colIdStr, vals] of Object.entries(slicerValues)) {
      const physName = getColPhysicalName(Number(colIdStr));
      mapped[physName] = vals;
    }
    return mapped;
  }, [slicerValues, getColPhysicalName]);

  // Measure column physical names + aggregation configs for client-side drill grouping
  const measureColNames = useMemo(() =>
    datasetColumns
      .filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi')
      .map((c: any) => c.physical_name),
    [datasetColumns]
  );
  const measureAggConfigs = useMemo(() =>
    datasetColumns
      .filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi')
      .map((c: any) => ({
        column: c.physical_name,
        aggregation: (c.aggregation || 'sum') as any,
      })),
    [datasetColumns]
  );

  // Client-side mode: drill report with all rows loaded
  const isClientSide = Boolean(report?.drill_hierarchy_id) && drillHierarchyLevels.length > 0
    && allRows.length > 0 && !allRowsLoading;

  const engineOutput = useReportEngine({
    rows: isClientSide ? allRows : rawRows,
    columns: resultColumns,
    sectionDefs,
    runningCalcs,
    slicerValues: slicerByName,
    drillState: isClientSide ? drillState : { level: 0, filters: [] },
    drillHierarchyLevels: isClientSide ? drillHierarchyLevels : undefined,
    measureColumns: isClientSide ? measureColNames : undefined,
    measureAggConfigs: isClientSide ? measureAggConfigs : undefined,
    expandedLevels: isClientSide ? expandedLevels : undefined,
    sortColumn: isClientSide ? (sortColumn ?? undefined) : undefined,
    sortDirection: isClientSide ? sortDirection : undefined,
  });

  // ── Detect column types from first data row ───────────────────────────────

  const colTypeMap = useMemo((): Record<string, string> => {
    const cols = resultColumns.concat(engineOutput.calculatedColumns);
    const sampleRow = (allRows.length > 0 ? allRows[0] : rawRows[0]) || {};
    const map: Record<string, string> = {};
    for (const col of cols) {
      map[col] = detectColType(col, sampleRow[col]);
    }
    return map;
  }, [rawRows, allRows, resultColumns, engineOutput.calculatedColumns]);

  // ── Grand totals computation (Phase 81 FIX 9) ────────────────────────────
  // Use engine grand totals when available (respects slicer filters), fall back to local computation

  const grandTotals = useMemo(() => {
    // Engine computes slicer-aware grand totals — prefer them when available
    if (engineOutput.grandTotals && Object.keys(engineOutput.grandTotals).length > 0) {
      return engineOutput.grandTotals;
    }
    const allCols = resultColumns.concat(engineOutput.calculatedColumns);
    const dataRows = rawRows;
    if (dataRows.length === 0) return null;
    const hasNumeric = allCols.some(c => ['integer', 'float'].includes(colTypeMap[c] || ''));
    if (!hasNumeric) return null;

    const totals: Record<string, any> = {};
    for (const col of allCols) {
      const t = colTypeMap[col];
      if (t === 'integer' || t === 'float') {
        const sum = dataRows.reduce((acc: number, row: any) => {
          const v = row[col];
          return acc + (typeof v === 'number' ? v : 0);
        }, 0);
        totals[col] = sum;
      } else {
        totals[col] = null;
      }
    }
    return totals;
  }, [rawRows, resultColumns, engineOutput.calculatedColumns, engineOutput.grandTotals, colTypeMap]);

  // ── Sort column handler (Phase 81 FIX 3) ─────────────────────────────────

  const handleSortColumn = (col: string) => {
    setSortColumn(prev => {
      if (prev !== col) {
        setSortDirection('asc');
        return col;
      }
      setSortDirection(d => {
        if (d === 'asc') return 'desc';
        setSortColumn(null);
        return null;
      });
      return prev;
    });
    setPage(0);
  };

  // ── Fetch page of results (Phase 81 FIX 2) ───────────────────────────────

  const fetchResultsPage = useCallback(async (
    execResult: any,
    targetPage: number,
    targetPageSize: number,
    targetSortCol: string | null,
    targetSortDir: string | null,
  ) => {
    if (!execResult?.execution_id) return;
    try {
      const data = await api.getBusinessReportPagedResults(
        reportId,
        execResult.execution_id,
        targetPage + 1,  // MUI is 0-indexed, API is 1-indexed
        targetPageSize,
        targetSortCol,
        targetSortDir,
      );
      setRawRows(data.rows || []);
      setResultColumns(data.columns || []);
      setTotalRows(data.total_rows ?? (data.rows?.length || 0));
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to fetch results page');
    }
  }, [reportId]);

  // Fetch all rows for client-side drill (runs once after execution for drill reports)
  const fetchAllRows = useCallback(async (execResult: any, knownTotalRows: number) => {
    if (!execResult?.execution_id || knownTotalRows <= 0) return;
    setAllRowsLoading(true);
    try {
      const fetchSize = 5000;
      const totalPages = Math.ceil(knownTotalRows / fetchSize);
      const allFetched: any[] = [];
      // Fetch in batches of 4 for controlled concurrency
      for (let i = 0; i < totalPages; i += 4) {
        const batch = [];
        for (let j = i; j < Math.min(i + 4, totalPages); j++) {
          batch.push(
            api.getBusinessReportPagedResults(reportId, execResult.execution_id, j + 1, fetchSize)
          );
        }
        const results = await Promise.all(batch);
        for (const data of results) {
          allFetched.push(...(data.rows || []));
        }
      }
      setAllRows(allFetched);
    } catch (err: any) {
      console.error('Failed to fetch all rows for client-side drill:', err);
      setError('Failed to load all rows for instant drill-down. Drill functionality may be limited.');
    } finally {
      setAllRowsLoading(false);
    }
  }, [reportId]);

  // Re-fetch when page, pageSize, or sort changes (server-side pagination only)
  useEffect(() => {
    if (executionResult && !isClientSide) {
      fetchResultsPage(executionResult, page, pageSize, sortColumn, sortDirection);
    }
  }, [page, pageSize, sortColumn, sortDirection]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Execute report (async path) ───────────────────────────────────────────

  const handleExecute = async (overrideParamValues?: Record<string, any>) => {
    if (!report) return;
    const effectiveParams = overrideParamValues || paramValues;
    // Validate required params before execute
    const params = (report.parameters || []) as any[];
    const isEmptyVal = (v: any) => v == null || v === '';
    const missing = params.filter((p: any) => p.is_required && isEmptyVal(effectiveParams[p.name]) && isEmptyVal(p.default_value))
      .map((p: any) => p.label || p.name);
    if (missing.length > 0) {
      setError(`Required parameter(s) missing: ${missing.join(', ')}`);
      return;
    }
    setExecuting(true);
    setError('');
    setAsyncExecId(null);
    setAsyncProgress(0);
    setPage(0);
    setSortColumn(null);
    setSortDirection(null);
    setAllRows([]);  // Reset client-side data
    setDrillState(prev => ({ ...prev, level: 0, filters: [] }));
    setExpandedLevels(0);
    pollAbort.current = false;

    const isDrillReport = Boolean(report.drill_hierarchy_id) && drillHierarchyLevels.length > 0;

    try {
      // Start async execution — no drill overrides; always fetch full detail data
      const startRes = await api.executeBusinessReportAsync(reportId, {
        parameter_values: effectiveParams,
      });
      const execId = startRes.execution_id;
      setAsyncExecId(execId);
      setAsyncProgress(10);

      // Poll status (WS can wake us up early via wsPollWakeup ref)
      let done = false;
      let pollResult: any = null;
      const pollStart = Date.now();
      const POLL_TIMEOUT_MS = 10 * 60 * 1000; // 10 minute timeout
      while (!done) {
        if (pollAbort.current) break;
        if (Date.now() - pollStart > POLL_TIMEOUT_MS) {
          setError('Report execution timed out. Please try again.');
          api.cancelBusinessReportAsync(reportId, execId).catch(() => {});
          break;
        }
        await new Promise<void>(resolve => {
          const timer = setTimeout(resolve, 2000);
          wsPollWakeup.current = () => { clearTimeout(timer); resolve(); };
        });
        wsPollWakeup.current = null;
        if (pollAbort.current) break;
        const statusRes = await api.getBusinessReportAsyncStatus(reportId, execId);
        setAsyncProgress(statusRes.progress_pct || 0);
        if (statusRes.status === 'completed') {
          done = true;
          // Fetch initial page
          const initialPageRes = await api.getBusinessReportPagedResults(reportId, execId, 1, pageSize);
          setRawRows(initialPageRes.rows || []);
          setResultColumns(initialPageRes.columns || []);
          setTotalRows(initialPageRes.total_rows ?? 0);
          pollResult = { execution_id: execId, total_rows: initialPageRes.total_rows };
        } else if (statusRes.status === 'failed') {
          done = true;
          setError(statusRes.error || 'Report execution failed');
        }
      }
      if (pollResult) {
        setExecutionResult(pollResult);
        // For drill reports: fetch ALL rows for client-side drill (background)
        if (isDrillReport && pollResult.total_rows > 0) {
          fetchAllRows(pollResult, pollResult.total_rows);
        }
      }
    } catch (err: any) {
      // Fallback: try synchronous execution
      try {
        const result = await api.executeBusinessReport(reportId, {
          parameter_values: effectiveParams,
        });
        setExecutionResult(result);
        if (result.data && Array.isArray(result.data)) {
          setRawRows(result.data);
          const cols = Array.isArray(result.columns)
            ? result.columns.map((c: any) => typeof c === 'string' ? c : c.name || c.column_name || '')
            : [];
          setResultColumns(cols);
          setTotalRows(result.total_rows ?? result.data.length);
          // For drill reports with sync results, use the data directly
          if (isDrillReport) {
            setAllRows(result.data);
          }
        } else if (result.execution_id) {
          await fetchResultsPage(result, 0, pageSize, null, null);
          if (isDrillReport && result.total_rows) {
            fetchAllRows(result, result.total_rows);
          }
        }
      } catch (err2: any) {
        setError(err2?.detail || err2?.message || 'Execution failed');
      }
    } finally {
      setExecuting(false);
      setAsyncExecId(null);
      setAsyncProgress(0);
      if (historyOpen) loadHistory(historyPage, historyPageSize);
    }
  };

  const handleCancelExecution = async () => {
    if (!asyncExecId) return;
    try {
      await api.cancelBusinessReportAsync(reportId, asyncExecId);
    } catch { /* ignore */ }
    setExecuting(false);
    setAsyncExecId(null);
    setAsyncProgress(0);
  };

  // ── Export menu ──────────────────────────────────────────────────────────
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);

  // ── Drill handlers (Power BI-style — pure client-side, instant) ─────────

  const hasDrill = Boolean(report?.drill_hierarchy_id) && drillHierarchyLevels.length > 0;
  const canDrillDeeper = hasDrill && drillState.level < drillHierarchyLevels.length;
  const canDrillUp = drillState.level > 0;

  // Drill down on click — click a specific row value to see its children
  const handleDrillDown = (_clickedColumn: string, value: any, row: any) => {
    const levels = drillHierarchyLevels;
    setDrillState(prev => {
      if (levels.length > 0 && prev.level < levels.length) {
        const drillCol = levels[prev.level].column_name;
        const drillVal = row[drillCol] ?? value;
        return { ...prev, level: prev.level + 1, filters: [...prev.filters, { column: drillCol, value: drillVal }], hierarchy_levels: levels };
      }
      return { ...prev, level: prev.level + 1, filters: [...prev.filters, { column: _clickedColumn, value }] };
    });
    setExpandedLevels(0);
    setPage(0);
  };

  // Go to next level — show next hierarchy level for ALL data (no filter added)
  const handleGoToNextLevel = () => {
    if (!canDrillDeeper) return;
    setDrillState(prev => ({ ...prev, level: prev.level + 1 }));
    setExpandedLevels(0);
    setPage(0);
  };

  // Expand to next level — add next hierarchy column alongside current columns
  const handleExpandNextLevel = () => {
    if (!canDrillDeeper) return;
    setExpandedLevels(prev => Math.min(prev + 1, drillHierarchyLevels.length - drillState.level));
    setPage(0);
  };

  // Drill up — go back one level
  const handleDrillUp = (toLevel: number) => {
    setDrillState(prev => ({ ...prev, level: toLevel, filters: prev.filters.slice(0, toLevel) }));
    setExpandedLevels(0);
    setPage(0);
  };

  // ── DnD sensors for column header reorder ────────────────────────────────
  const dndSensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

  // Sortable table header cell
  const SortableHeaderCell: React.FC<{ col: string }> = ({ col }) => {
    const colType = colTypeMap[col] || 'string';
    const isNumeric = ['integer', 'float'].includes(colType);
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: col });
    return (
      <TableCell
        ref={setNodeRef}
        sx={{
          fontWeight: 'bold', whiteSpace: 'nowrap', cursor: 'pointer', userSelect: 'none',
          textAlign: isNumeric ? 'right' : 'left',
          '&:hover': { opacity: 0.85 },
          opacity: isDragging ? 0.5 : 1,
          transform: CSS.Transform.toString(transform), transition,
        }}
        onClick={() => handleSortColumn(col)}
        {...attributes} {...listeners}
      >
        <Box sx={{ display: 'inline-flex', alignItems: 'center' }}>
          {datasetColumns.find((c: any) => c.physical_name === col)?.friendly_name || col}
          <SortIcon col={col} />
        </Box>
      </TableCell>
    );
  };

  // ── Sort icon helper ──────────────────────────────────────────────────────

  const SortIcon: React.FC<{ col: string }> = ({ col }) => {
    if (sortColumn !== col) return <SortNoneIcon sx={{ fontSize: 14, opacity: 0.3, ml: 0.5 }} />;
    if (sortDirection === 'asc') return <SortAscIcon sx={{ fontSize: 14, color: 'primary.main', ml: 0.5 }} />;
    return <SortDescIcon sx={{ fontSize: 14, color: 'primary.main', ml: 0.5 }} />;
  };

  // ── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  if (!report) {
    return <Alert severity="error" sx={{ mt: 4, mx: 4 }}>Report not found</Alert>;
  }

  // Base columns (may change during drill grouping)
  const baseCols = (isClientSide && engineOutput.activeColumns.length > 0)
    ? engineOutput.activeColumns.concat(engineOutput.calculatedColumns)
    : resultColumns.concat(engineOutput.calculatedColumns);

  // Apply user-defined column order if set, falling back to base order
  const allCols = (() => {
    if (!columnOrder) return baseCols;
    // Keep only columns that still exist in baseCols, in the user-specified order
    const baseSet = new Set(baseCols);
    const ordered = columnOrder.filter(c => baseSet.has(c));
    // Append any new columns not in the user order
    for (const c of baseCols) {
      if (!ordered.includes(c)) ordered.push(c);
    }
    return ordered;
  })();

  // Client-side pagination: slice banded rows for the current page
  const paginatedRows = isClientSide
    ? engineOutput.bandedRows.slice(page * pageSize, (page + 1) * pageSize)
    : engineOutput.bandedRows;

  // Total row count for pagination display
  // In client-side mode, use bandedRows.length (includes headers/subtotals) for correct pagination
  const displayTotalRows = isClientSide ? engineOutput.bandedRows.length : totalRows;

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <IconButton onClick={() => navigate('/business-reports')}><ArrowBackIcon /></IconButton>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>{report.name}</Typography>
        {report.is_certified && (
          <Chip icon={<CertifiedIcon />} label="Certified" size="small" color="success" variant="outlined" />
        )}
        {report.template_category && (
          <Chip label={report.template_category} size="small" variant="outlined" />
        )}
        <Tooltip title="Subscribe (email delivery)">
          <IconButton onClick={() => setSubOpen(true)}><EmailIcon /></IconButton>
        </Tooltip>
        {/* Phase 91: Publish as external API */}
        <Tooltip title="Publish as external API">
          <IconButton size="small" onClick={() => setPublishApiOpen(true)}>
            <PublishApiIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Share link">
          <IconButton onClick={async () => {
            try {
              const share = await api.createBusinessReportShare(reportId);
              const url = `${window.location.origin}/shared-business-report/${share.token}`;
              navigator.clipboard.writeText(url);
              setToast('Share link copied to clipboard!');
            } catch (e: any) { setToast(`Share error: ${e.message}`); }
          }}><ShareLinkIcon /></IconButton>
        </Tooltip>
        <Tooltip title="Embed code">
          <IconButton onClick={async () => {
            try {
              const tok = await api.createBusinessReportEmbed(reportId);
              const url = `${window.location.origin}/embedded-business-report/${tok.token}`;
              const html = `<iframe src="${url}" width="100%" height="600" frameBorder="0"></iframe>`;
              navigator.clipboard.writeText(html);
              setToast('Embed HTML copied to clipboard!');
            } catch (e: any) { setToast(`Embed error: ${e.message}`); }
          }}><EmbedCodeIcon /></IconButton>
        </Tooltip>
        <Button variant="contained" startIcon={executing ? <CircularProgress size={16} /> : <PlayIcon />}
          onClick={() => handleExecute()} disabled={executing}>
          {executing ? 'Running...' : 'Execute'}
        </Button>
        {/* Phase 85D-1: Execute with defaults — bypasses parameter prompts */}
        <Tooltip title="Run immediately using default parameter values — no prompts">
          <span>
            <Button variant="outlined" size="small"
              startIcon={<FlashOnIcon />}
              onClick={async () => {
                // Build default values from report params (resolve @TODAY macros)
                const defaults: Record<string, any> = {};
                for (const p of (report?.parameters || [])) {
                  defaults[p.name] = resolveParamDefault(p);
                }
                setParamValues(defaults);
                await handleExecute(defaults);
              }}
              disabled={executing}
              sx={{ whiteSpace: 'nowrap' }}
            >
              Run (defaults)
            </Button>
          </span>
        </Tooltip>
        {executing && asyncExecId && (
          <Tooltip title="Cancel execution">
            <IconButton onClick={handleCancelExecution} color="error"><CancelIcon /></IconButton>
          </Tooltip>
        )}
        <Button variant="outlined" size="small" startIcon={<ExportIcon />}
          onClick={(e) => setExportAnchor(e.currentTarget)}
          disabled={!executionResult}>Export</Button>
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
          onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportExcel(reportId, paramValues); } catch (e: any) { setToast(e?.message || 'Excel export failed'); } }}>
            <ListItemIcon><ExcelIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Excel (formatted)</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportPDF(reportId, paramValues); } catch (e: any) { setToast(e?.message || 'PDF export failed'); } }}>
            <ListItemIcon><PdfIcon fontSize="small" /></ListItemIcon>
            <ListItemText>PDF (max 10k rows)</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportCSV(reportId, paramValues); } catch (e: any) { setToast(e?.message || 'CSV export failed'); } }}>
            <ListItemIcon><ExportIcon fontSize="small" /></ListItemIcon>
            <ListItemText>CSV (raw data)</ListItemText>
          </MenuItem>
        </Menu>
        <IconButton onClick={() => navigate(`/business-reports/${reportId}/edit`)}><EditIcon /></IconButton>
        <Tooltip title="Duplicate"><IconButton onClick={async () => {
          try {
            const dup = await api.duplicateBusinessReport(reportId);
            navigate(`/business-reports/${dup.id}/edit`);
          } catch {}
        }}><DuplicateIcon /></IconButton></Tooltip>
        {/* Phase 114-L: Collaboration panel toggle */}
        <Tooltip title="Comments"><IconButton size="small"
          onClick={() => { setCollabTab('comments'); setCollabOpen(o => !o); }}
          color={collabOpen && collabTab === 'comments' ? 'primary' : 'default'}>
          <Badge badgeContent={commentCount} color="primary" max={99}>
            <CommentIcon />
          </Badge>
        </IconButton></Tooltip>
        <Tooltip title="Change History"><IconButton size="small"
          onClick={() => { setCollabTab('history'); setCollabOpen(o => !o); }}
          color={collabOpen && collabTab === 'history' ? 'primary' : 'default'}>
          <TimelineIcon />
        </IconButton></Tooltip>
      </Box>

      {report.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{report.description}</Typography>
      )}

      {/* Phase 114-L: Collaboration Panel (Comments / Change History) */}
      <Collapse in={collabOpen}>
        <Paper elevation={0} sx={{ mb: 2, border: '1px solid', borderColor: 'divider', maxHeight: 400, display: 'flex', flexDirection: 'column' }}>
          <Box sx={{ display: 'flex', borderBottom: '1px solid', borderColor: 'divider' }}>
            <Button size="small" sx={{ flex: 1, borderRadius: 0, fontWeight: collabTab === 'comments' ? 700 : 400,
              borderBottom: collabTab === 'comments' ? '2px solid' : 'none', borderColor: 'primary.main' }}
              onClick={() => setCollabTab('comments')}>
              Comments {commentCount > 0 ? `(${commentCount})` : ''}
            </Button>
            <Button size="small" sx={{ flex: 1, borderRadius: 0, fontWeight: collabTab === 'history' ? 700 : 400,
              borderBottom: collabTab === 'history' ? '2px solid' : 'none', borderColor: 'primary.main' }}
              onClick={() => setCollabTab('history')}>
              Change History
            </Button>
          </Box>
          <Box sx={{ flex: 1, overflowY: 'auto', maxHeight: 350 }}>
            {collabTab === 'comments' && <ReportCommentPanel reportId={reportId} />}
            {collabTab === 'history' && <ReportChangeHistory reportId={reportId} />}
          </Box>
        </Paper>
      </Collapse>

      {/* Execution History Panel */}
      <Paper elevation={0} sx={{ mb: 2, border: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', px: 2, py: 1, cursor: 'pointer' }}
          onClick={() => setHistoryOpen(prev => !prev)}>
          <HistoryIcon sx={{ mr: 1, fontSize: 18, color: 'text.secondary' }} />
          <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Execution History</Typography>
          {historyTotal > 0 && <Chip size="small" label={historyTotal} sx={{ mr: 1 }} />}
          {historyOpen ? <CollapseIcon /> : <ExpandIcon />}
        </Box>
        <Collapse in={historyOpen}>
          {historyLoading ? (
            <Box sx={{ p: 2, textAlign: 'center' }}><CircularProgress size={20} /></Box>
          ) : historyItems.length === 0 ? (
            <Typography variant="body2" color="text.secondary" sx={{ px: 2, pb: 2 }}>
              No execution history yet. Click Execute to run this report.
            </Typography>
          ) : (
            <>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Status</TableCell>
                      <TableCell>Started</TableCell>
                      <TableCell>Completed</TableCell>
                      <TableCell align="right">Rows</TableCell>
                      <TableCell>Run By</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {historyItems.map((h: any) => (
                      <TableRow key={h.execution_id} hover>
                        <TableCell>
                          <Chip
                            size="small"
                            label={h.status}
                            color={h.status === 'completed' ? 'success' : h.status === 'failed' ? 'error' : h.status === 'running' ? 'warning' : 'default'}
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {h.created_at ? new Date(h.created_at).toLocaleString() : '—'}
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {h.completed_at ? new Date(h.completed_at).toLocaleString() : '—'}
                        </TableCell>
                        <TableCell align="right">
                          {h.total_rows != null ? h.total_rows.toLocaleString() : '—'}
                        </TableCell>
                        <TableCell>{h.created_by || '—'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              {historyTotal > historyPageSize && (
                <TablePagination
                  component="div"
                  count={historyTotal}
                  page={historyPage}
                  onPageChange={(_, p) => setHistoryPage(p)}
                  rowsPerPage={historyPageSize}
                  onRowsPerPageChange={e => { setHistoryPageSize(Number(e.target.value)); setHistoryPage(0); }}
                  rowsPerPageOptions={[10, 25, 50]}
                />
              )}
            </>
          )}
        </Collapse>
      </Paper>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Async progress bar */}
      {executing && asyncExecId && (
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
            <Typography variant="body2" color="text.secondary">Running report... {asyncProgress}%</Typography>
          </Box>
          <LinearProgress variant="determinate" value={asyncProgress} />
        </Box>
      )}

      {/* Parameter Prompt Panel */}
      {report.parameters && report.parameters.length > 0 && (
        <Paper elevation={1} sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', px: 2, py: 1, cursor: 'pointer' }}
            onClick={() => setParamsPanelOpen(prev => !prev)}>
            <FilterIcon sx={{ mr: 1, fontSize: 18 }} />
            <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Parameters</Typography>
            {paramsPanelOpen ? <CollapseIcon /> : <ExpandIcon />}
          </Box>
          <Collapse in={paramsPanelOpen}>
            <Box sx={{ px: 2, pb: 2, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              {report.parameters.map((p: any) => {
                // Phase 85D-2: required marking; 85D-3: description tooltip
                const isRequired = p.is_required;
                const labelWithRequired = isRequired ? `${p.label} *` : p.label;
                const isEmpty = !paramValues[p.name] ||
                  (Array.isArray(paramValues[p.name]) && paramValues[p.name].length === 0);
                const showRequiredError = isRequired && isEmpty;

                const DescTooltip = p.description ? (
                  <Tooltip title={p.description} placement="top">
                    <InfoOutlinedIcon sx={{ fontSize: 14, color: 'text.secondary', cursor: 'help', ml: 0.5, verticalAlign: 'middle' }} />
                  </Tooltip>
                ) : null;

                if (p.parameter_type === 'dropdown' || p.parameter_type === 'multi_select') {
                  const lovValues = paramLovs[p.id] || [];
                  return (
                    <Box key={p.id}>
                      <FormControl size="small" sx={{ minWidth: 180 }} error={showRequiredError}>
                        <InputLabel sx={{ color: isRequired ? 'primary.main' : undefined }}>{labelWithRequired}</InputLabel>
                        <Select
                          value={paramValues[p.name] || (p.parameter_type === 'multi_select' ? [] : '')}
                          label={labelWithRequired}
                          multiple={p.parameter_type === 'multi_select'}
                          onChange={e => {
                            const newVal = e.target.value;
                            setParamValues(prev => {
                              const next = { ...prev, [p.name]: newVal };
                              // Clear dependent children when parent changes
                              for (const child of (report.parameters || [])) {
                                if (child.depends_on_param_id === p.id) {
                                  next[child.name] = child.parameter_type === 'multi_select' ? [] : '';
                                }
                              }
                              return next;
                            });
                          }}
                        >
                          {!p.is_required && <MenuItem value="">All</MenuItem>}
                          {lovValues.map((v: string) => (
                            <MenuItem key={v} value={v}>{v}</MenuItem>
                          ))}
                        </Select>
                        {showRequiredError && (
                          <Typography variant="caption" color="error" sx={{ mt: 0.5, display: 'block', fontSize: 11 }}>
                            This parameter is required
                          </Typography>
                        )}
                      </FormControl>
                      {DescTooltip}
                    </Box>
                  );
                }
                if (p.parameter_type === 'date' || p.parameter_type === 'date_range') {
                  return (
                    <Box key={p.id} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                      <TextField size="small" label={labelWithRequired + (p.parameter_type === 'date_range' ? ' From' : '')}
                        type="date"
                        error={showRequiredError}
                        helperText={showRequiredError ? 'Required' : undefined}
                        InputLabelProps={{ shrink: true, sx: { color: isRequired ? 'primary.main' : undefined } }}
                        value={p.parameter_type === 'date_range' ? (paramValues[p.name]?.from || '') : (paramValues[p.name] || '')}
                        onChange={e => {
                          if (p.parameter_type === 'date_range') {
                            setParamValues(prev => ({
                              ...prev,
                              [p.name]: { ...(prev[p.name] || {}), from: e.target.value },
                            }));
                          } else {
                            setParamValues(prev => ({ ...prev, [p.name]: e.target.value }));
                          }
                        }}
                      />
                      {p.parameter_type === 'date_range' && (
                        <TextField size="small" label={p.label + ' To'}
                          type="date" InputLabelProps={{ shrink: true }}
                          value={paramValues[p.name]?.to || ''}
                          onChange={e => setParamValues(prev => ({
                            ...prev,
                            [p.name]: { ...(prev[p.name] || {}), to: e.target.value },
                          }))}
                        />
                      )}
                      {DescTooltip}
                    </Box>
                  );
                }
                return (
                  <Box key={p.id} sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                    <TextField size="small" label={labelWithRequired}
                      type={p.parameter_type === 'numeric' ? 'number' : 'text'}
                      error={showRequiredError}
                      helperText={showRequiredError ? 'Required' : undefined}
                      InputLabelProps={{ sx: { color: isRequired ? 'primary.main' : undefined } }}
                      value={paramValues[p.name] || ''}
                      onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                    />
                    {DescTooltip}
                  </Box>
                );
              })}
            </Box>
          </Collapse>
        </Paper>
      )}

      {/* Phase 85D-4: Slicer Bar — improved label */}
      {report.slicer_column_ids && report.slicer_column_ids.length > 0 && rawRows.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1, mb: 1 }}>
            <Typography variant="subtitle2">Filter Results By:</Typography>
            <Typography variant="caption" color="text.secondary">
              (applies after data loads — no re-query needed)
            </Typography>
          </Box>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          {report.slicer_column_ids.map((colId: number) => {
            const physName = getColPhysicalName(colId);
            const options = engineOutput.slicerOptions[physName] || [];
            const selected = slicerValues[String(colId)] || [];
            return (
              <FormControl key={colId} size="small" sx={{ minWidth: 160 }}>
                <InputLabel>{getColDisplayName(colId)}</InputLabel>
                <Select
                  multiple value={selected} label={getColDisplayName(colId)}
                  onChange={e => setSlicerValues(prev => ({ ...prev, [String(colId)]: e.target.value as string[] }))}
                  renderValue={(sel: string[]) => sel.length === 0 ? 'All' : sel.join(', ')}
                >
                  {options.map((v: string) => (
                    <MenuItem key={v} value={v}>{v}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          })}
        </Box>
        </Box>
      )}

      {/* Drill-Down Controls (Power BI style) */}
      {hasDrill && executionResult && (
        <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', gap: 0.5, border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 0.5 }}>
            <Tooltip title="Drill up one level">
              <span><IconButton size="small" disabled={!canDrillUp || executing}
                onClick={() => handleDrillUp(Math.max(0, drillState.level - 1))}>
                <DrillUpIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title={`Go to next level${canDrillDeeper ? ': ' + drillHierarchyLevels[drillState.level]?.label : ''}`}>
              <span><IconButton size="small" disabled={!canDrillDeeper || executing}
                onClick={handleGoToNextLevel}>
                <GoNextLevelIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title="Expand — add next hierarchy column alongside current">
              <span><IconButton size="small" disabled={!canDrillDeeper || executing}
                onClick={handleExpandNextLevel}>
                <ExpandNextLevelIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title={drillClickMode ? 'Click-to-drill is ON — click any row to drill into it' : 'Enable click-to-drill mode'}>
              <IconButton size="small"
                color={drillClickMode ? 'primary' : 'default'}
                onClick={() => setDrillClickMode(!drillClickMode)}>
                <DrillClickIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
          {/* Hierarchy level indicator */}
          <Typography variant="caption" color="text.secondary">
            {drillHierarchyLevels[drillState.level]?.label || 'Detail'}
            {expandedLevels > 0 && ` + ${expandedLevels} level${expandedLevels > 1 ? 's' : ''}`}
          </Typography>
          {/* Breadcrumb trail */}
          {drillState.filters.length > 0 && (
            <Breadcrumbs separator={<NavNextIcon sx={{ fontSize: 14 }} />} sx={{ ml: 1 }}>
              <Link component="button" variant="caption" underline="hover"
                onClick={() => handleDrillUp(0)}>All</Link>
              {drillState.filters.map((f, idx) => {
                const lvLabel = drillHierarchyLevels[idx]?.label || f.column;
                return (
                  <Link key={idx} component="button" variant="caption" underline="hover"
                    onClick={() => handleDrillUp(idx + 1)}>
                    {lvLabel}: {f.value}
                  </Link>
                );
              })}
            </Breadcrumbs>
          )}
        </Box>
      )}

      {/* Execution Result Badges */}
      {executionResult && (
        <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <Chip size="small" label={`${displayTotalRows.toLocaleString()} rows${isClientSide ? ' (client-side)' : ''}`} />
          <Chip size="small" label={`Page ${page + 1} — Rows ${(page * pageSize + 1).toLocaleString()}–${Math.min((page + 1) * pageSize, displayTotalRows).toLocaleString()}`} />
          {executionResult.cache_hit ? (
            <Chip size="small" icon={<BoltIcon />} color="success"
              label={`Cache Hit (${executionResult.cache_grain || 'cached'})`} />
          ) : (
            <Chip size="small" variant="outlined" label="Live Query" />
          )}
          {/* Grand totals toggle */}
          {grandTotals && (
            <FormControlLabel
              control={<Switch checked={showTotals} onChange={e => setShowTotals(e.target.checked)} size="small" />}
              label="Totals"
              sx={{ ml: 1 }}
            />
          )}
        </Box>
      )}

      {/* Loading all rows indicator for client-side drill */}
      {allRowsLoading && (
        <Alert severity="info" sx={{ mb: 2 }}>Loading all rows for instant drill-down...</Alert>
      )}

      {/* Results Table */}
      {paginatedRows.length > 0 ? (
        <>
          <DndContext sensors={dndSensors} collisionDetection={closestCenter}
            onDragEnd={(event) => {
              const { active, over } = event;
              if (over && active.id !== over.id) {
                const oldIdx = allCols.indexOf(String(active.id));
                const newIdx = allCols.indexOf(String(over.id));
                const newOrder = arrayMove(allCols, oldIdx, newIdx);
                setColumnOrder(newOrder);
                // Debounced persist to backend
                if (saveOrderTimer.current) clearTimeout(saveOrderTimer.current);
                saveOrderTimer.current = setTimeout(() => {
                  if (reportId) api.updateViewerPrefs(reportId, { column_order: newOrder }).catch(() => {});
                }, 1000);
              }
            }}>
          <TableContainer component={Paper} sx={{ maxHeight: 'calc(100vh - 420px)' }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow sx={{ '& th': { bgcolor: styleConfig.header_bg, color: styleConfig.header_text } }}>
                  <SortableContext items={allCols} strategy={horizontalListSortingStrategy}>
                    {allCols.map(col => (
                      <SortableHeaderCell key={col} col={col} />
                    ))}
                  </SortableContext>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRows.map((row, idx) => {
                  const style = rowTypeStyles[row._rowType] || {};
                  if (row._rowType === 'header') {
                    return (
                      <TableRow key={idx} sx={{ ...style }}>
                        <TableCell colSpan={allCols.length} sx={{ fontWeight: 'bold', fontSize: '0.95rem' }}>
                          {row._sectionValue}
                          {row._sectionCount != null && (
                            <Chip size="small" label={`${row._sectionCount} rows`} sx={{ ml: 1 }} />
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  }
                  const isStripe = styleConfig.stripe_rows && row._rowType === 'data' && idx % 2 === 1;
                  return (
                    <TableRow key={idx} sx={{ ...style, ...(isStripe ? { bgcolor: '#f9f9f9' } : {}) }} hover={row._rowType === 'data'}>
                      {allCols.map(col => {
                        const colType = colTypeMap[col] || 'string';
                        const isNumeric = ['integer', 'float'].includes(colType);
                        const dsMeta = datasetColumns.find((c: any) => c.physical_name === col);
                        return (
                          <TableCell key={col} sx={{
                            whiteSpace: 'nowrap',
                            fontWeight: style.fontWeight,
                            fontStyle: style.fontStyle,
                            textAlign: isNumeric ? 'right' : 'left',
                            cursor: row._rowType === 'data' && drillClickMode && canDrillDeeper ? 'pointer' : 'default',
                          }}
                            onClick={() => {
                              if (row._rowType === 'data' && drillClickMode && canDrillDeeper) {
                                handleDrillDown(col, row[col], row);
                              }
                            }}
                          >
                            {formatCellValue(row[col], colType, dsMeta?.format_pattern, dsMeta?.data_type, styleConfig.negative_format)}
                            {row._rowType === 'subtotal' && col === allCols[0] && row._sectionValue && (
                              <Typography component="span" variant="caption" sx={{ ml: 1 }}>
                                Subtotal: {row._sectionValue}
                              </Typography>
                            )}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  );
                })}
              </TableBody>
              {/* Grand totals footer row (Phase 81 FIX 9) */}
              {showTotals && grandTotals && (
                <TableFooter>
                  <TableRow sx={{ bgcolor: styleConfig.grand_total_bg }}>
                    {allCols.map((col, idx) => {
                      const colType = colTypeMap[col] || 'string';
                      const isNumeric = ['integer', 'float'].includes(colType);
                      const val = grandTotals[col];
                      return (
                        <TableCell key={col} sx={{ fontWeight: 'bold', textAlign: isNumeric ? 'right' : 'left' }}>
                          {idx === 0 ? 'Total' : (val !== null && val !== undefined ? formatCellValue(val, colType, undefined, undefined, styleConfig.negative_format) : '')}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                </TableFooter>
              )}
            </Table>
          </TableContainer>
          </DndContext>

          {/* Pagination (client-side for drill reports, server-side otherwise) */}
          <TablePagination
            component="div"
            count={displayTotalRows}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            rowsPerPage={pageSize}
            onRowsPerPageChange={e => {
              setPageSize(Number(e.target.value));
              setPage(0);
            }}
            rowsPerPageOptions={PAGE_SIZE_OPTIONS}
            labelDisplayedRows={({ from, to, count }) =>
              `Rows ${from.toLocaleString()}–${to.toLocaleString()} of ${count === -1 ? 'many' : count.toLocaleString()}`
            }
          />
        </>
      ) : !executing && executionResult ? (
        <Alert severity="info" sx={{ mt: 2 }}>No results returned. Try adjusting your parameters or filters.</Alert>
      ) : !executing ? (
        <Paper elevation={1} sx={{ p: 4, textAlign: 'center', mt: 2 }}>
          <Typography variant="h6" color="text.secondary">
            Click Execute to run this report
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            {report.parameters?.length > 0 ? 'Fill in the parameters above, then click Execute.' : 'Results will appear here.'}
          </Typography>
        </Paper>
      ) : null}

      {/* Subscription Manager Dialog */}
      <SubscriptionManager
        open={subOpen}
        onClose={() => setSubOpen(false)}
        reportId={reportId}
        reportType="business_report"
        reportName={report?.name || `Report ${reportId}`}
      />

      {/* Phase 91: Publish as external API dialog */}
      {publishApiOpen && (
        <PublishViewDialog
          open={publishApiOpen}
          onClose={() => setPublishApiOpen(false)}
          queryName={report?.name || ''}
          sourceType="business_report"
          businessReportId={reportId}
        />
      )}
      <Snackbar
        open={!!toast}
        autoHideDuration={3000}
        onClose={() => setToast('')}
        message={toast}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Box>
  );
};

export default BusinessReportViewer;
