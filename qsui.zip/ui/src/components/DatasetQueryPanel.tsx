/**
 * Dataset Query Panel — Business User Query Builder (Phase 54)
 *
 * Allows business users to build and execute queries against semantic layer
 * datasets without writing SQL. Supports:
 *   - Column selection (dimension/measure pills with friendly names)
 *   - Filters with cascading prompts (parent→child LOV)
 *   - Pre-defined conditions (one-click WHERE clauses)
 *   - Order by
 *   - Result preview with pagination
 *   - Execution history
 *   - Merged dataset execution (BO multiple data providers)
 *
 * Route: /datasets/:id/query
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Box, Typography, Paper, Button, CircularProgress, IconButton,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Chip, Alert, Tooltip, Stack,
  Select, MenuItem, FormControl, InputLabel,
  Autocomplete,
  Tabs, Tab, Collapse, LinearProgress,
} from '@mui/material';
import {
  PlayArrow as ExecuteIcon,
  Visibility as PreviewIcon,
  FilterAlt as FilterIcon,
  Sort as SortIcon,
  History as HistoryIcon,
  ArrowBack as BackIcon,
  Download as DownloadIcon,
  Code as SqlIcon,
  ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
  Schedule as PendingIcon,
  Close as CloseIcon,
  Bolt as BoltIcon,
} from '@mui/icons-material';
import { alpha, useTheme } from '@mui/material/styles';
import api from '../services/api';
import { useNotifications } from '../context/NotificationContext';
import { useAssistantContext } from '../context/AssistantContext';
import { useParams, useNavigate } from 'react-router-dom';

/* ── Notification helper ───────────────────────────────────────────────── */
const notify = (addNotification: Function, msg: string, type: 'success' | 'error' | 'info' = 'info') =>
  addNotification({ type, title: type === 'error' ? 'Error' : type === 'success' ? 'Success' : 'Info', message: msg });

/* ── Constants ─────────────────────────────────────────────────────────── */
const COLUMN_TYPE_COLORS: Record<string, string> = {
  dimension: '#2196f3',
  measure:   '#4caf50',
  detail:    '#ff9800',
  kpi:       '#e91e63',
};

const OPERATORS = [
  { value: 'eq',          label: '= Equals' },
  { value: 'neq',         label: '≠ Not Equals' },
  { value: 'gt',          label: '> Greater Than' },
  { value: 'gte',         label: '≥ Greater Or Equal' },
  { value: 'lt',          label: '< Less Than' },
  { value: 'lte',         label: '≤ Less Or Equal' },
  { value: 'like',        label: '≈ Like' },
  { value: 'in',          label: '∈ In List' },
  { value: 'between',     label: '↔ Between' },
  { value: 'is_null',     label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

const SORT_DIRECTIONS = [
  { value: 'asc',  label: 'A → Z (Ascending)' },
  { value: 'desc', label: 'Z → A (Descending)' },
];

const RESULTS_PAGE_SIZE = 500;

/* ── Types ─────────────────────────────────────────────────────────────── */
interface DatasetColumn {
  id: number;
  physical_name: string;
  friendly_name: string;
  column_type: string;
  data_type: string;
  aggregation: string;
  class_id: number | null;
  description: string;
  is_hidden: boolean;
}

interface PreDefinedCondition {
  id: number;
  name: string;
  label: string;
  description: string;
  where_clause: string;
}

interface FilterEntry {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
}

interface OrderByEntry {
  column_id: number;
  direction: string;
}

interface ExecutionRecord {
  execution_id: string;
  status: string;
  total_rows: number;
  duration_seconds: number;
  sql_generated: string;
  created_at: string;
}

/* ── Component ─────────────────────────────────────────────────────────── */
const DatasetQueryPanel: React.FC = () => {
  const { id: datasetIdStr } = useParams<{ id: string }>();
  const datasetId = parseInt(datasetIdStr || '0', 10);
  const navigate = useNavigate();
  const theme = useTheme();
  const { addNotification } = useNotifications();
  const { setAssistantCtx } = useAssistantContext();

  // Dataset metadata
  const [dataset, setDataset] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Query builder state
  const [selectedColumnIds, setSelectedColumnIds] = useState<number[]>([]);
  const [filters, setFilters] = useState<FilterEntry[]>([]);
  const [selectedConditionIds, setSelectedConditionIds] = useState<number[]>([]);
  const [orderBy, setOrderBy] = useState<OrderByEntry[]>([]);
  const [rowLimit, setRowLimit] = useState(10000);

  // Execution state
  const [executing, setExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [resultRows, setResultRows] = useState<any[]>([]);
  const [resultColumns, setResultColumns] = useState<string[]>([]);
  const [resultOffset, setResultOffset] = useState(0);
  const [resultTotal, setResultTotal] = useState(0);

  // UI state
  const [activeTab, setActiveTab] = useState(0); // 0=Build, 1=Results, 2=History, 3=SQL
  const [showFilters, setShowFilters] = useState(false);
  const [showSortOrder, setShowSortOrder] = useState(false);
  const [sqlPreview, setSqlPreview] = useState('');
  const [executions, setExecutions] = useState<ExecutionRecord[]>([]);

  // Cascading LOV
  const [lovValues, setLovValues] = useState<Record<number, any[]>>({});
  const [lovLoading, setLovLoading] = useState<Record<number, boolean>>({});

  // Load dataset
  const loadDataset = useCallback(async () => {
    if (!datasetId) return;
    setLoading(true);
    try {
      const ds = await api.getDataset(datasetId);
      setDataset(ds);
    } catch (err: any) {
      notify(addNotification, `Failed to load dataset: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  }, [datasetId, addNotification]);

  useEffect(() => { loadDataset(); }, [loadDataset]);

  // Phase 57: register dataset context for GlobalAssistantPanel
  useEffect(() => {
    if (!dataset) return;
    const tableNames = (dataset.source_tables || []).map(
      (t: any) => t.alias || t.table?.split('/').pop()?.split('.')[0] || 'table'
    );
    setAssistantCtx({
      datasetId: dataset.id,
      datasetName: dataset.name,
      tables: tableNames,
      pageName: 'dataset-query',
    });
  }, [dataset]); // eslint-disable-line react-hooks/exhaustive-deps

  // Derived data
  const columns: DatasetColumn[] = useMemo(() =>
    (dataset?.columns || []).filter((c: DatasetColumn) => !c.is_hidden),
    [dataset],
  );

  const conditions: PreDefinedCondition[] = useMemo(() =>
    dataset?.conditions || [],
    [dataset],
  );

  const classes = useMemo(() => {
    const classMap: Record<number, string> = {};
    (dataset?.classes || []).forEach((cls: any) => { classMap[cls.id] = cls.label || cls.name; });
    return classMap;
  }, [dataset]);

  // Grouped columns (by class)
  const groupedColumns = useMemo(() => {
    const groups: Record<string, DatasetColumn[]> = { 'General': [] };
    columns.forEach(col => {
      const group = col.class_id && classes[col.class_id] ? classes[col.class_id] : 'General';
      if (!groups[group]) groups[group] = [];
      groups[group].push(col);
    });
    return groups;
  }, [columns, classes]);

  const selectedColumns = useMemo(() =>
    selectedColumnIds.map(id => columns.find(c => c.id === id)).filter(Boolean) as DatasetColumn[],
    [selectedColumnIds, columns],
  );

  // Toggle column selection
  const toggleColumn = (colId: number) => {
    setSelectedColumnIds(prev =>
      prev.includes(colId) ? prev.filter(id => id !== colId) : [...prev, colId],
    );
  };

  // Filter management
  const addFilter = () => {
    if (columns.length === 0) return;
    setFilters(prev => [...prev, { column_id: columns[0].id, operator: 'eq', value: '' }]);
    setShowFilters(true);
  };

  const updateFilter = (idx: number, updates: Partial<FilterEntry>) => {
    setFilters(prev => prev.map((f, i) => i === idx ? { ...f, ...updates } : f));
  };

  const removeFilter = (idx: number) => {
    setFilters(prev => prev.filter((_, i) => i !== idx));
  };

  // Sort management
  const addOrderBy = () => {
    if (selectedColumnIds.length === 0) return;
    setOrderBy(prev => [...prev, { column_id: selectedColumnIds[0], direction: 'asc' }]);
    setShowSortOrder(true);
  };

  const updateOrderBy = (idx: number, updates: Partial<OrderByEntry>) => {
    setOrderBy(prev => prev.map((o, i) => i === idx ? { ...o, ...updates } : o));
  };

  const removeOrderBy = (idx: number) => {
    setOrderBy(prev => prev.filter((_, i) => i !== idx));
  };

  // Cascading LOV — load distinct values for a filter column
  const loadColumnValues = async (columnId: number, parentFilters: FilterEntry[] = []) => {
    setLovLoading(prev => ({ ...prev, [columnId]: true }));
    try {
      const resp = await api.getColumnValues(datasetId, {
        column_id: columnId,
        parent_filters: parentFilters.map(f => ({
          column_id: f.column_id, operator: f.operator, value: f.value,
        })),
      });
      setLovValues(prev => ({ ...prev, [columnId]: resp.values || [] }));
    } catch {
      // silently fail — user can type manually
    } finally {
      setLovLoading(prev => ({ ...prev, [columnId]: false }));
    }
  };

  // Execute dataset query
  const executeQuery = async () => {
    if (selectedColumnIds.length === 0) {
      notify(addNotification, 'Select at least one column', 'error');
      return;
    }
    setExecuting(true);
    setExecutionResult(null);
    setResultRows([]);
    try {
      const result = await api.executeDataset(datasetId, {
        column_ids: selectedColumnIds,
        filters: filters.map(f => ({
          column_id: f.column_id, operator: f.operator,
          value: f.value, value2: f.value2,
        })),
        condition_ids: selectedConditionIds,
        order_by: orderBy.map(o => ({
          column_id: o.column_id, direction: o.direction,
        })),
        limit: rowLimit,
      });
      setExecutionResult(result);
      setSqlPreview(result.sql_generated || '');

      // Load first page of results
      if (result.execution_id) {
        const page = await api.getFederationExecutionResults(result.execution_id, 0, RESULTS_PAGE_SIZE);
        setResultRows(page.rows || []);
        setResultColumns(page.columns || []);
        setResultTotal(page.total_rows || 0);
        setResultOffset(0);
      }
      setActiveTab(1); // Switch to Results tab
      notify(addNotification, `Query returned ${result.total_rows} rows in ${result.duration_seconds}s`, 'success');
    } catch (err: any) {
      notify(addNotification, `Execution failed: ${err.message}`, 'error');
    } finally {
      setExecuting(false);
    }
  };

  // Load more results (pagination)
  const loadMoreResults = async () => {
    if (!executionResult?.execution_id) return;
    const newOffset = resultOffset + RESULTS_PAGE_SIZE;
    try {
      const page = await api.getFederationExecutionResults(executionResult.execution_id, newOffset, RESULTS_PAGE_SIZE);
      setResultRows(page.rows || []);
      setResultOffset(newOffset);
    } catch (err: any) {
      notify(addNotification, `Failed to load page: ${err.message}`, 'error');
    }
  };

  // Preview
  const handlePreview = async () => {
    try {
      setExecuting(true);
      const preview = await api.previewDataset(datasetId);
      setResultRows(preview.rows || []);
      setResultColumns((preview.columns || []).map((c: any) => c.physical_name));
      setResultTotal(preview.total_rows || 0);
      setResultOffset(0);
      setExecutionResult(null);
      setActiveTab(1);
      notify(addNotification, `Preview: ${preview.total_rows} rows`, 'info');
    } catch (err: any) {
      notify(addNotification, `Preview failed: ${err.message}`, 'error');
    } finally {
      setExecuting(false);
    }
  };

  // Load execution history
  const loadHistory = async () => {
    try {
      const execs = await api.listDatasetExecutions(datasetId, 20);
      setExecutions(execs || []);
    } catch { /* ignore */ }
  };

  useEffect(() => {
    if (activeTab === 2) loadHistory();
  }, [activeTab]); // eslint-disable-line react-hooks/exhaustive-deps

  // Download results as CSV
  const downloadCsv = () => {
    if (resultRows.length === 0) return;
    const cols = resultColumns.length > 0 ? resultColumns : Object.keys(resultRows[0] || {});
    const header = cols.join(',');
    const rows = resultRows.map(row =>
      cols.map(c => {
        const v = row[c];
        if (v === null || v === undefined) return '';
        const s = String(v);
        return s.includes(',') || s.includes('"') ? `"${s.replace(/"/g, '""')}"` : s;
      }).join(','),
    );
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${dataset?.name || 'dataset'}_results.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Column lookup helper
  const colById = (id: number) => columns.find(c => c.id === id);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight={400}>
        <CircularProgress />
      </Box>
    );
  }

  if (!dataset) {
    return (
      <Box p={3}>
        <Alert severity="error">Dataset not found</Alert>
        <Button startIcon={<BackIcon />} onClick={() => navigate('/datasets')} sx={{ mt: 2 }}>
          Back to Datasets
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 2, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Tooltip title="Back to datasets list">
          <IconButton onClick={() => navigate('/datasets')} size="small">
            <BackIcon />
          </IconButton>
        </Tooltip>
        <Box flex={1}>
          <Typography variant="h5" fontWeight={600}>{dataset.name}</Typography>
          <Typography variant="body2" color="text.secondary">
            {dataset.subject} {dataset.description ? ` — ${dataset.description}` : ''}
          </Typography>
        </Box>
        <Button variant="outlined" startIcon={<PreviewIcon />} onClick={handlePreview}
                disabled={executing} size="small">
          Preview
        </Button>
        <Button variant="contained" startIcon={executing ? <CircularProgress size={18} /> : <ExecuteIcon />}
                onClick={executeQuery} disabled={executing || selectedColumnIds.length === 0}>
          Execute
        </Button>
      </Stack>

      {/* Tabs */}
      <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)} sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Tab label="Build Query" />
        <Tab label={`Results${resultTotal > 0 ? ` (${resultTotal})` : ''}`} />
        <Tab label="History" />
        {sqlPreview && <Tab label="SQL" icon={<SqlIcon fontSize="small" />} iconPosition="start" />}
      </Tabs>

      {/* ── Tab 0: Query Builder ────────────────────────────────────────── */}
      {activeTab === 0 && (
        <Box>
          {/* Column Selection */}
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom sx={{ mb: 1 }}>
              Select Columns ({selectedColumnIds.length} selected)
            </Typography>
            {Object.entries(groupedColumns).map(([group, cols]) => (
              <Box key={group} sx={{ mb: 1.5 }}>
                {Object.keys(groupedColumns).length > 1 && (
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                    {group}
                  </Typography>
                )}
                <Stack direction="row" flexWrap="wrap" gap={0.5}>
                  {cols.map(col => {
                    const selected = selectedColumnIds.includes(col.id);
                    return (
                      <Tooltip key={col.id}
                               title={`${col.physical_name} (${col.column_type}${col.aggregation ? `, ${col.aggregation}` : ''})`}
                               placement="top">
                        <Chip
                          label={col.friendly_name}
                          size="small"
                          onClick={() => toggleColumn(col.id)}
                          variant={selected ? 'filled' : 'outlined'}
                          sx={{
                            borderColor: COLUMN_TYPE_COLORS[col.column_type] || '#999',
                            bgcolor: selected ? alpha(COLUMN_TYPE_COLORS[col.column_type] || '#999', 0.15) : undefined,
                            '&:hover': { bgcolor: alpha(COLUMN_TYPE_COLORS[col.column_type] || '#999', 0.1) },
                            fontWeight: selected ? 600 : 400,
                          }}
                        />
                      </Tooltip>
                    );
                  })}
                </Stack>
              </Box>
            ))}
            <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
              <Chip label="Dimensions" size="small" sx={{ bgcolor: alpha(COLUMN_TYPE_COLORS.dimension, 0.1), borderColor: COLUMN_TYPE_COLORS.dimension }} variant="outlined" />
              <Chip label="Measures" size="small" sx={{ bgcolor: alpha(COLUMN_TYPE_COLORS.measure, 0.1), borderColor: COLUMN_TYPE_COLORS.measure }} variant="outlined" />
              <Chip label="Details" size="small" sx={{ bgcolor: alpha(COLUMN_TYPE_COLORS.detail, 0.1), borderColor: COLUMN_TYPE_COLORS.detail }} variant="outlined" />
              <Chip label="KPIs" size="small" sx={{ bgcolor: alpha(COLUMN_TYPE_COLORS.kpi, 0.1), borderColor: COLUMN_TYPE_COLORS.kpi }} variant="outlined" />
            </Stack>
          </Paper>

          {/* Pre-defined Conditions */}
          {conditions.length > 0 && (
            <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
              <Typography variant="subtitle2" gutterBottom>Pre-defined Conditions</Typography>
              <Stack direction="row" flexWrap="wrap" gap={0.5}>
                {conditions.map(cond => {
                  const active = selectedConditionIds.includes(cond.id);
                  return (
                    <Tooltip key={cond.id} title={cond.description || cond.where_clause} placement="top">
                      <Chip
                        label={cond.label || cond.name}
                        size="small"
                        color={active ? 'primary' : 'default'}
                        variant={active ? 'filled' : 'outlined'}
                        onClick={() => setSelectedConditionIds(prev =>
                          active ? prev.filter(id => id !== cond.id) : [...prev, cond.id])}
                      />
                    </Tooltip>
                  );
                })}
              </Stack>
            </Paper>
          )}

          {/* Filters */}
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between">
              <Typography variant="subtitle2">
                Filters ({filters.length})
              </Typography>
              <Stack direction="row" spacing={1}>
                <Button size="small" startIcon={<FilterIcon />} onClick={addFilter}>Add Filter</Button>
                {filters.length > 0 && (
                  <Tooltip title={showFilters ? 'Collapse filters' : 'Expand filters'}>
                    <span>
                      <IconButton size="small" onClick={() => setShowFilters(!showFilters)}>
                        {showFilters ? <CollapseIcon /> : <ExpandIcon />}
                      </IconButton>
                    </span>
                  </Tooltip>
                )}
              </Stack>
            </Stack>
            <Collapse in={showFilters}>
              {filters.map((filter, idx) => {
                const col = colById(filter.column_id);
                return (
                  <Stack key={idx} direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
                    <FormControl size="small" sx={{ minWidth: 160 }}>
                      <InputLabel>Column</InputLabel>
                      <Select value={filter.column_id} label="Column"
                              onChange={e => {
                                updateFilter(idx, { column_id: Number(e.target.value) });
                                loadColumnValues(Number(e.target.value));
                              }}>
                        {columns.map(c => (
                          <MenuItem key={c.id} value={c.id}>{c.friendly_name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    <FormControl size="small" sx={{ minWidth: 140 }}>
                      <InputLabel>Operator</InputLabel>
                      <Select value={filter.operator} label="Operator"
                              onChange={e => updateFilter(idx, { operator: e.target.value })}>
                        {OPERATORS.map(op => (
                          <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    {!['is_null', 'is_not_null'].includes(filter.operator) && (
                      <Autocomplete
                        freeSolo size="small" sx={{ minWidth: 180 }}
                        options={(lovValues[filter.column_id] || []).map(String)}
                        loading={lovLoading[filter.column_id] || false}
                        inputValue={String(filter.value || '')}
                        onInputChange={(_, val) => updateFilter(idx, { value: val })}
                        onOpen={() => {
                          if (!lovValues[filter.column_id]) loadColumnValues(filter.column_id);
                        }}
                        renderInput={params => <TextField {...params} label="Value" />}
                      />
                    )}
                    {filter.operator === 'between' && (
                      <TextField size="small" label="To" sx={{ minWidth: 120 }}
                                 value={filter.value2 || ''}
                                 onChange={e => updateFilter(idx, { value2: e.target.value })} />
                    )}
                    <Tooltip title="Remove this filter"><IconButton size="small" onClick={() => removeFilter(idx)}><CloseIcon fontSize="small" /></IconButton></Tooltip>
                  </Stack>
                );
              })}
            </Collapse>
          </Paper>

          {/* Sort Order */}
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between">
              <Typography variant="subtitle2">Sort Order ({orderBy.length})</Typography>
              <Stack direction="row" spacing={1}>
                <Button size="small" startIcon={<SortIcon />} onClick={addOrderBy}
                        disabled={selectedColumnIds.length === 0}>
                  Add Sort
                </Button>
                {orderBy.length > 0 && (
                  <Tooltip title={showSortOrder ? 'Collapse sort order' : 'Expand sort order'}>
                    <span>
                      <IconButton size="small" onClick={() => setShowSortOrder(!showSortOrder)}>
                        {showSortOrder ? <CollapseIcon /> : <ExpandIcon />}
                      </IconButton>
                    </span>
                  </Tooltip>
                )}
              </Stack>
            </Stack>
            <Collapse in={showSortOrder}>
              {orderBy.map((ob, idx) => (
                <Stack key={idx} direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
                  <FormControl size="small" sx={{ minWidth: 180 }}>
                    <InputLabel>Column</InputLabel>
                    <Select value={ob.column_id} label="Column"
                            onChange={e => updateOrderBy(idx, { column_id: Number(e.target.value) })}>
                      {selectedColumns.map(c => (
                        <MenuItem key={c.id} value={c.id}>{c.friendly_name}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ minWidth: 160 }}>
                    <InputLabel>Direction</InputLabel>
                    <Select value={ob.direction} label="Direction"
                            onChange={e => updateOrderBy(idx, { direction: e.target.value })}>
                      {SORT_DIRECTIONS.map(d => (
                        <MenuItem key={d.value} value={d.value}>{d.label}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <Tooltip title="Remove this sort"><IconButton size="small" onClick={() => removeOrderBy(idx)}><CloseIcon fontSize="small" /></IconButton></Tooltip>
                </Stack>
              ))}
            </Collapse>
          </Paper>

          {/* Row Limit */}
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <Typography variant="subtitle2">Row Limit</Typography>
              <TextField size="small" type="number" value={rowLimit}
                         onChange={e => setRowLimit(Math.max(1, parseInt(e.target.value) || 1000))}
                         inputProps={{ min: 1, max: 100000 }}
                         sx={{ width: 120 }} />
            </Stack>
          </Paper>
        </Box>
      )}

      {/* ── Tab 1: Results ──────────────────────────────────────────────── */}
      {activeTab === 1 && (
        <Box>
          {executing && <LinearProgress sx={{ mb: 1 }} />}
          {executionResult && (
            <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 1.5 }}>
              <Chip label={`${resultTotal} rows`} size="small" color="primary" />
              <Chip label={`${executionResult.duration_seconds}s`} size="small" variant="outlined" />
              {executionResult.cache_hit ? (
                <Chip
                  icon={<BoltIcon />}
                  label={`Cache Hit (${executionResult.cache_grain || 'custom'}) — ${Math.round((executionResult.cache_age_seconds || 0) / 60)}min old`}
                  color="success"
                  size="small"
                />
              ) : (
                <Chip label="Live Query" variant="outlined" size="small" sx={{ opacity: 0.6 }} />
              )}
              <Box flex={1} />
              <Button size="small" startIcon={<DownloadIcon />} onClick={downloadCsv}
                      disabled={resultRows.length === 0}>
                CSV
              </Button>
              {sqlPreview && (
                <Button size="small" startIcon={<SqlIcon />} onClick={() => setActiveTab(3)}>
                  Show SQL
                </Button>
              )}
            </Stack>
          )}
          {resultRows.length > 0 ? (
            <>
              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 500 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      {(resultColumns.length > 0 ? resultColumns : Object.keys(resultRows[0] || {})).map(col => {
                        const colMeta = columns.find(c => c.physical_name === col);
                        return (
                          <TableCell key={col} sx={{ fontWeight: 600, fontSize: '0.75rem' }}>
                            {colMeta?.friendly_name || col}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {resultRows.map((row, rIdx) => (
                      <TableRow key={rIdx} hover>
                        {(resultColumns.length > 0 ? resultColumns : Object.keys(row)).map(col => (
                          <TableCell key={col} sx={{ fontSize: '0.75rem' }}>
                            {row[col] === null || row[col] === undefined ? (
                              <Typography variant="caption" color="text.disabled" fontStyle="italic">null</Typography>
                            ) : String(row[col])}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              {/* Pagination */}
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 1 }}>
                <Typography variant="caption" color="text.secondary">
                  Showing {resultOffset + 1}–{Math.min(resultOffset + resultRows.length, resultTotal)} of {resultTotal}
                </Typography>
                <Stack direction="row" spacing={1}>
                  <Button size="small" disabled={resultOffset === 0}
                          onClick={() => {
                            if (!executionResult?.execution_id) return;
                            const newOff = Math.max(0, resultOffset - RESULTS_PAGE_SIZE);
                            api.getFederationExecutionResults(executionResult.execution_id, newOff, RESULTS_PAGE_SIZE)
                              .then(page => { setResultRows(page.rows || []); setResultOffset(newOff); });
                          }}>
                    Previous
                  </Button>
                  <Button size="small" disabled={resultOffset + RESULTS_PAGE_SIZE >= resultTotal}
                          onClick={loadMoreResults}>
                    Next
                  </Button>
                </Stack>
              </Stack>
            </>
          ) : (
            !executing && (
              <Alert severity="info" sx={{ mt: 2 }}>
                No results yet. Select columns and click Execute, or use Preview.
              </Alert>
            )
          )}
        </Box>
      )}

      {/* ── Tab 2: History ──────────────────────────────────────────────── */}
      {activeTab === 2 && (
        <Box>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="subtitle2">Recent Executions</Typography>
            <Tooltip title="Reload execution history"><IconButton size="small" onClick={loadHistory}><HistoryIcon fontSize="small" /></IconButton></Tooltip>
          </Stack>
          {executions.length === 0 ? (
            <Alert severity="info">No executions found for this dataset.</Alert>
          ) : (
            <TableContainer component={Paper} variant="outlined">
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 600 }}>Time</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Rows</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Duration</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {executions.map(exec => (
                    <TableRow key={exec.execution_id} hover>
                      <TableCell sx={{ fontSize: '0.75rem' }}>
                        {new Date(exec.created_at).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Chip
                          size="small"
                          label={exec.status}
                          color={exec.status === 'completed' ? 'success' : exec.status === 'failed' ? 'error' : 'default'}
                          icon={exec.status === 'completed' ? <CheckIcon /> : exec.status === 'failed' ? <ErrorIcon /> : <PendingIcon />}
                        />
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{exec.total_rows}</TableCell>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{exec.duration_seconds}s</TableCell>
                      <TableCell>
                        <Button size="small" onClick={async () => {
                          try {
                            const page = await api.getFederationExecutionResults(exec.execution_id, 0, RESULTS_PAGE_SIZE);
                            setResultRows(page.rows || []);
                            setResultColumns(page.columns || []);
                            setResultTotal(page.total_rows || 0);
                            setResultOffset(0);
                            setExecutionResult(exec);
                            setSqlPreview(exec.sql_generated || '');
                            setActiveTab(1);
                          } catch (err: any) {
                            notify(addNotification, `Failed to load: ${err.message}`, 'error');
                          }
                        }}>
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      )}

      {/* ── Tab 3: SQL ──────────────────────────────────────────────────── */}
      {activeTab === 3 && sqlPreview && (
        <Paper variant="outlined" sx={{ p: 2 }}>
          <Typography variant="subtitle2" gutterBottom>Generated SQL</Typography>
          <Box
            component="pre"
            sx={{
              bgcolor: alpha(theme.palette.text.primary, 0.04),
              p: 2, borderRadius: 1, overflow: 'auto',
              fontFamily: 'monospace', fontSize: '0.8rem', lineHeight: 1.5,
              maxHeight: 400,
            }}
          >
            {sqlPreview}
          </Box>
        </Paper>
      )}
    </Box>
  );
};

export default DatasetQueryPanel;
