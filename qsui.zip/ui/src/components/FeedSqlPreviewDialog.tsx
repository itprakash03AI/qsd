/**
 * Reusable Preview SQL dialog for feed gen.
 *
 * Used by:
 *   - FeedConfigsPage    (admin / owner — preview before scheduling)
 *   - FeedTodayPage      (end user — see what query is running on the dashboard)
 *
 * Encapsulates state, fetch, copy-to-clipboard, and rendering in one
 * component so callers just pass ``open``, ``feedId``, ``onClose`` —
 * no need to duplicate the chips / monospace block / loading state.
 *
 * Per user OOP preference (2026-05-18 memory note): single-responsibility
 * component, state co-located, easy to test in isolation.
 */
import { useEffect, useState, useCallback } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Stack, Box, Chip, IconButton, Tooltip, Typography, Alert,
  CircularProgress, Button,
} from '@mui/material';
import {
  Code as PreviewSqlIcon, ContentCopy as CopyIcon,
} from '@mui/icons-material';
import api from '../services/api';

interface FeedSqlPreviewData {
  feed_id: number;
  feed_name?: string;
  sql: string;
  dialect: string;
  source_type: string;
  source_id?: number;
  source_name: string;
  source_status: 'ok' | 'not_found' | 'inactive' | 'missing_file' | 'empty' | string;
  source_message: string;
  connection_id?: number | null;
  connection_name: string;
  connection_type: string;
  secondary_sql?: string | null;
  secondary_connection_name?: string | null;
  combine_mode?: 'union' | 'join' | null;
}

interface Props {
  open: boolean;
  feedId: number | null;
  onClose: () => void;
  onSuccessToast?: (msg: string) => void;
}

export default function FeedSqlPreviewDialog({
  open, feedId, onClose, onSuccessToast,
}: Props) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<FeedSqlPreviewData | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (!open || feedId == null) return;
    let cancelled = false;
    setLoading(true);
    setError('');
    setData(null);
    api.get(`/api/feeds/${feedId}/preview-sql`)
      .then((d: any) => { if (!cancelled) setData(d as FeedSqlPreviewData); })
      .catch((err: any) => {
        if (!cancelled) setError(err?.detail || err?.message || 'Could not load SQL preview');
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [open, feedId]);

  const copyPreviewSql = useCallback(() => {
    if (!data?.sql) return;
    const txt = data.sql + (data.secondary_sql
      ? `\n\n-- Secondary side (${data.combine_mode}):\n${data.secondary_sql}`
      : '');
    try {
      navigator.clipboard.writeText(txt);
      onSuccessToast?.('SQL copied');
    } catch { /* clipboard API can fail in restricted contexts; silent */ }
  }, [data, onSuccessToast]);

  const statusSeverity = (s: string): 'error' | 'warning' | 'info' => {
    if (s === 'not_found' || s === 'missing_file') return 'error';
    if (s === 'inactive' || s === 'empty') return 'warning';
    return 'info';
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle>
        <Stack direction="row" alignItems="center" spacing={1}>
          <PreviewSqlIcon fontSize="small" />
          <Box sx={{ flexGrow: 1 }}>
            Feed Query Preview
            {data?.feed_name && (
              <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                {data.feed_name}
              </Typography>
            )}
          </Box>
          {data?.sql && (
            <Tooltip title="Copy to clipboard">
              <IconButton size="small" onClick={copyPreviewSql}>
                <CopyIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
        </Stack>
      </DialogTitle>
      <DialogContent dividers>
        {loading && <CircularProgress size={20} />}
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {data && !loading && (
          <>
            <Stack direction="row" spacing={1} sx={{ mb: 1.5, flexWrap: 'wrap' }}>
              <Chip size="small"
                    label={`Source: ${data.source_type} · ${data.source_name}`} />
              {data.connection_name && (
                <Chip size="small" color="primary" variant="outlined"
                      label={`Connection: ${data.connection_name} (${data.connection_type})`} />
              )}
              <Chip size="small" variant="outlined"
                    label={`Dialect: ${data.dialect}`} />
              {data.combine_mode && (
                <Chip size="small" color="secondary"
                      label={`Cross-conn: ${data.combine_mode.toUpperCase()}`} />
              )}
            </Stack>
            {data.source_status !== 'ok' && (
              <Alert severity={statusSeverity(data.source_status)} sx={{ mb: 2 }}>
                <strong>{data.source_status}:</strong> {data.source_message}
              </Alert>
            )}
            {data.sql ? (
              <Box component="pre"
                   sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                         borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 360,
                         fontFamily: 'JetBrains Mono, Menlo, monospace',
                         whiteSpace: 'pre-wrap' }}>
                {data.sql}
              </Box>
            ) : (
              <Typography variant="body2" color="text.secondary"
                          sx={{ fontStyle: 'italic' }}>
                No SQL available for this feed (see status above).
              </Typography>
            )}
            {data.secondary_sql && (
              <>
                <Typography variant="caption"
                            sx={{ display: 'block', mt: 2, mb: 0.5,
                                  color: 'text.secondary' }}>
                  Secondary side ({data.combine_mode}) — {data.secondary_connection_name || ''}
                </Typography>
                <Box component="pre"
                     sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                           borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 240,
                           fontFamily: 'JetBrains Mono, Menlo, monospace',
                           whiteSpace: 'pre-wrap' }}>
                  {data.secondary_sql}
                </Box>
              </>
            )}
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
