/**
 * SqlEditor — CodeMirror 6-based SQL editor with syntax highlighting.
 *
 * Replaces plain MUI TextField in CQB and BQB with a proper code editor:
 * - SQL keyword + function highlighting
 * - Table and column name autocomplete (schema-aware)
 * - Line numbers, active line highlight, bracket matching
 * - GitHub Light theme (readable in light mode)
 */
import React, { useCallback, useMemo, useRef } from 'react';
import CodeMirror, { ReactCodeMirrorRef } from '@uiw/react-codemirror';
import { sql } from '@codemirror/lang-sql';
import { linter, Diagnostic } from '@codemirror/lint';
import { githubLight } from '@uiw/codemirror-theme-github';
import { Box, Chip, Stack, Tooltip, Typography, IconButton, Menu, MenuItem, ListItemText } from '@mui/material';
import {
  Warning as WarningIcon,
  Info as InfoIcon,
  PlayArrow as PlayIcon,
  History as HistoryIcon,
  ContentPaste as TemplateIcon,
} from '@mui/icons-material';

// Phase 139 honest-fix #8 — inline anti-pattern detection.
// Pure regex (no extra deps); surfaces warnings as chips ABOVE the editor
// AND as inline CodeMirror linter squigglies (Phase 139 gap closure).
type AntiPattern = { id: string; severity: 'warn' | 'info'; label: string; hint: string;
                     /** Phase 139: byte offsets in the source for inline squiggle */
                     from?: number; to?: number };

// Phase 139 — SQL templates dropdown
const SQL_TEMPLATES: { label: string; sql: string }[] = [
  { label: 'SELECT … LIMIT', sql: 'SELECT col1, col2\nFROM table_name\nWHERE col3 = \'value\'\nLIMIT 100' },
  { label: 'INNER JOIN', sql: 'SELECT a.col1, b.col2\nFROM table_a a\nINNER JOIN table_b b ON a.id = b.id\nLIMIT 100' },
  { label: 'LEFT JOIN', sql: 'SELECT a.*, b.col\nFROM table_a a\nLEFT JOIN table_b b ON a.id = b.id\nLIMIT 100' },
  { label: 'GROUP BY + COUNT', sql: 'SELECT col1, COUNT(*) AS n\nFROM table_name\nGROUP BY col1\nORDER BY n DESC\nLIMIT 100' },
  { label: 'CTE (WITH)', sql: 'WITH ranked AS (\n  SELECT col1, col2,\n         ROW_NUMBER() OVER (PARTITION BY col1 ORDER BY col2 DESC) AS rn\n  FROM table_name\n)\nSELECT * FROM ranked WHERE rn = 1\nLIMIT 100' },
  { label: 'WINDOW (LAG/LEAD)', sql: 'SELECT col1, col2,\n       LAG(col2) OVER (ORDER BY col1) AS prev_val\nFROM table_name\nLIMIT 100' },
  { label: 'CASE WHEN', sql: 'SELECT col1,\n       CASE\n         WHEN col2 > 100 THEN \'high\'\n         WHEN col2 > 10  THEN \'mid\'\n         ELSE \'low\'\n       END AS bucket\nFROM table_name\nLIMIT 100' },
];

function detectAntiPatterns(sqlText: string): AntiPattern[] {
  if (!sqlText || !sqlText.trim()) return [];
  const out: AntiPattern[] = [];
  // Strip single-quoted string literals to avoid false positives — but
  // KEEP the original positions by replacing with same-length spaces.
  const stripped = sqlText.replace(/'(?:[^'\\]|\\.)*'/g, (m) => "'" + " ".repeat(m.length - 2) + "'");
  const upper = stripped.toUpperCase();

  // Helper: regex match → diagnostic with positions
  const match = (re: RegExp, p: Omit<AntiPattern, "from" | "to">): AntiPattern | null => {
    const m = upper.match(re);
    if (!m || m.index === undefined) return null;
    return { ...p, from: m.index, to: m.index + m[0].length };
  };

  const sel = match(/\bSELECT\s+\*/, {
    id: 'select_star', severity: 'info',
    label: 'SELECT *',
    hint: 'Picking columns explicitly lets the engine prune projection — faster + cheaper on warehouse credits.',
  });
  if (sel) out.push(sel);

  if (!/\bLIMIT\s+\d+/.test(upper) && !/\bCOUNT\s*\(/.test(upper) && !/\bGROUP\s+BY\b/.test(upper)) {
    // Anchor to end-of-text — show squiggle at the end where LIMIT should go
    out.push({
      id: 'no_limit', severity: 'warn',
      label: 'No LIMIT',
      hint: 'Add LIMIT N to cap the result size — the grid only renders ~1000 rows anyway.',
      from: Math.max(0, sqlText.length - 1), to: sqlText.length,
    });
  }

  const cross = match(/\bCROSS\s+JOIN\b/, {
    id: 'cross_join', severity: 'warn',
    label: 'CROSS JOIN',
    hint: 'Cartesian product — N×M rows. Verify this is intentional.',
  });
  if (cross) out.push(cross);

  const obp = match(/\bORDER\s+BY\s+\d+/, {
    id: 'order_by_position', severity: 'info',
    label: 'ORDER BY <position>',
    hint: 'Use column names instead of positions — clearer + survives schema changes.',
  });
  if (obp) out.push(obp);

  const sj = match(/\bSELECT\s+\*\s+FROM\s+\S+\s+\S+\s*JOIN\s+/, {
    id: 'select_star_join', severity: 'warn',
    label: 'SELECT * with JOIN',
    hint: 'JOINs with SELECT * pull every column from every table. Specify columns to reduce I/O.',
  });
  if (sj) out.push(sj);

  return out;
}

/** CodeMirror linter — converts detectAntiPatterns to inline squigglies. */
function antiPatternLinter() {
  return linter((view) => {
    const text = view.state.doc.toString();
    const aps = detectAntiPatterns(text);
    const out: Diagnostic[] = [];
    for (const ap of aps) {
      if (ap.from === undefined || ap.to === undefined) continue;
      out.push({
        from: Math.max(0, ap.from),
        to:   Math.min(view.state.doc.length, ap.to),
        severity: ap.severity === 'warn' ? 'warning' : 'info',
        message: `${ap.label} — ${ap.hint}`,
        source: 'querystudio',
      });
    }
    return out;
  });
}

export interface SqlEditorProps {
  /** SQL text value */
  value: string;
  /** Called on every change */
  onChange: (val: string) => void;
  /** Height of the editor area (CSS string or px number) */
  height?: string | number;
  /** Min height */
  minHeight?: string | number;
  /** Max height */
  maxHeight?: string | number;
  /** Table → column name map for autocomplete */
  schema?: Record<string, string[]>;
  /** Disable editing */
  readOnly?: boolean;
  /** Placeholder shown when editor is empty */
  placeholder?: string;
  /** Extra sx-style wrapper props (applied to outer Box) */
  sx?: object;
  /** Phase 139 honest-fix: show "Format SQL" button that calls /api/sql/format */
  showFormatButton?: boolean;
  /** Phase 139 honest-fix: show "Explain" button that calls /api/sql/explain-plain
   *  with the EXPLAIN output of the current SQL. Requires sqlglot + DuckDB on backend. */
  showExplainButton?: boolean;
  /** Phase 139 honest-fix: show "→ Visual" button that calls /api/sql/to-visual
   *  to reverse-engineer SQL into a QueryConfig. Calls onConvertToVisual with the result. */
  showToVisualButton?: boolean;
  /** Callback when user clicks "→ Visual" — gets the parsed QueryConfig */
  onConvertToVisual?: (visualConfig: any) => void;
  /** Phase 139 gap-closure: show "Templates" dropdown menu */
  showTemplatesButton?: boolean;
  /** Phase 139 gap-closure: show "Run Selection" button when text is highlighted */
  showRunSelectionButton?: boolean;
  /** Callback for Run / Run-selection — receives the SQL to execute */
  onRunSql?: (sql: string) => void;
  /** Phase 139 gap-closure: show "Run All Statements" button (multi-statement) */
  showRunAllButton?: boolean;
  /** Callback for Run-all — receives ordered list of statements */
  onRunAllStatements?: (statements: string[]) => void;
  /** Phase 139 gap-closure: show "History" button — opens recent-queries drawer */
  showHistoryButton?: boolean;
  /** Callback when History clicked — parent renders the drawer */
  onOpenHistory?: () => void;
}

const SqlEditor: React.FC<SqlEditorProps> = ({
  value,
  onChange,
  height,
  minHeight,
  maxHeight,
  schema,
  readOnly = false,
  placeholder,
  sx,
  showFormatButton = false,
  showExplainButton = false,
  showToVisualButton = false,
  onConvertToVisual,
  showTemplatesButton = false,
  showRunSelectionButton = false,
  onRunSql,
  showRunAllButton = false,
  onRunAllStatements,
  showHistoryButton = false,
  onOpenHistory,
}) => {
  const handleChange = useCallback((val: string) => {
    onChange(val);
  }, [onChange]);

  const editorRef = useRef<ReactCodeMirrorRef>(null);
  const [templatesAnchor, setTemplatesAnchor] = React.useState<null | HTMLElement>(null);
  const [hasSelection, setHasSelection] = React.useState(false);

  // Run highlighted region — read selection from CodeMirror state
  const handleRunSelection = useCallback(() => {
    if (!onRunSql) return;
    const view = editorRef.current?.view;
    if (!view) return;
    const sel = view.state.selection.main;
    if (sel.empty) {
      // No selection → run whole SQL
      if (value.trim()) onRunSql(value);
      return;
    }
    const selected = view.state.sliceDoc(sel.from, sel.to).trim();
    if (selected) onRunSql(selected);
  }, [onRunSql, value]);

  // Insert template at cursor
  const handleInsertTemplate = useCallback((tpl: string) => {
    setTemplatesAnchor(null);
    const view = editorRef.current?.view;
    if (!view) {
      // Fallback: append at end
      onChange((value ? value + '\n\n' : '') + tpl);
      return;
    }
    const pos = view.state.selection.main.head;
    view.dispatch({
      changes: { from: pos, to: pos, insert: tpl + '\n' },
      selection: { anchor: pos + tpl.length + 1 },
    });
  }, [value, onChange]);

  // Multi-statement: split + run sequentially
  const [runAllBusy, setRunAllBusy] = React.useState(false);
  const handleRunAll = useCallback(async () => {
    if (!onRunAllStatements || !value.trim()) return;
    setRunAllBusy(true);
    try {
      const { safeFetch } = await import('../services/api/core');
      const resp: any = await safeFetch('/api/sql/split', {
        method: 'POST',
        body: { sql: value, dialect: 'duckdb' } as any,
      });
      const stmts: string[] = Array.isArray(resp?.statements) ? resp.statements : [];
      if (stmts.length === 0) return;
      onRunAllStatements(stmts);
    } catch {
      // fallback: split on ; locally
      const stmts = value.split(';').map(s => s.trim()).filter(Boolean);
      if (stmts.length > 0) onRunAllStatements(stmts);
    } finally {
      setRunAllBusy(false);
    }
  }, [value, onRunAllStatements]);

  // Track selection state to enable/disable Run-Selection button
  const onUpdate = useCallback((update: any) => {
    if (update.selectionSet || update.docChanged) {
      const sel = update.state.selection.main;
      setHasSelection(!sel.empty);
    }
  }, []);

  const antiPatterns = useMemo(() => detectAntiPatterns(value), [value]);

  // Phase 139 honest-fix #3: format SQL via /api/sql/format
  const [formatBusy, setFormatBusy] = React.useState(false);
  const handleFormat = useCallback(async () => {
    if (!value.trim() || readOnly) return;
    setFormatBusy(true);
    try {
      const { safeFetch } = await import('../services/api/core');
      const resp: any = await safeFetch('/api/sql/format', {
        method: 'POST',
        body: { sql: value, dialect: 'duckdb' } as any,
      });
      if (resp?.formatted && resp?.sql && resp.sql !== value) {
        onChange(resp.sql);
      }
    } catch {
      // fail-OPEN: leave the SQL as-is
    } finally {
      setFormatBusy(false);
    }
  }, [value, onChange, readOnly]);

  // Phase 139 honest-fix: EXPLAIN-in-English via /api/sql/explain-plain
  const [explainOpen, setExplainOpen] = React.useState(false);
  const [explainText, setExplainText] = React.useState('');
  const [explainBusy, setExplainBusy] = React.useState(false);
  const handleExplain = useCallback(async () => {
    if (!value.trim()) return;
    setExplainBusy(true);
    setExplainOpen(true);
    setExplainText('');
    try {
      const { safeFetch } = await import('../services/api/core');
      // First run EXPLAIN through /api/execute/explain to get the plan text
      let planText = '';
      try {
        const planResp: any = await safeFetch('/api/execute/explain', {
          method: 'POST',
          body: { sql: value, analyze: false } as any,
        });
        planText = planResp?.plan_text || planResp?.plan || '';
      } catch {
        planText = '';
      }
      const resp: any = await safeFetch('/api/sql/explain-plain', {
        method: 'POST',
        body: { explain_text: planText, sql: value } as any,
      });
      setExplainText(resp?.summary || 'No summary available.');
    } catch (e: any) {
      setExplainText(`Failed to summarise plan: ${e?.message || e}`);
    } finally {
      setExplainBusy(false);
    }
  }, [value]);

  // Phase 139 honest-fix: SQL → Visual via /api/sql/to-visual
  const [toVisualBusy, setToVisualBusy] = React.useState(false);
  const handleToVisual = useCallback(async () => {
    if (!value.trim() || !onConvertToVisual) return;
    setToVisualBusy(true);
    try {
      const { safeFetch } = await import('../services/api/core');
      const resp: any = await safeFetch('/api/sql/to-visual', {
        method: 'POST',
        body: { sql: value, dialect: 'duckdb' } as any,
      });
      if (resp) {
        onConvertToVisual(resp);
      }
    } catch (e: any) {
      // Surface as alert via window since SqlEditor doesn't have notif context
      // eslint-disable-next-line no-alert
      alert(`Could not convert SQL to visual config: ${e?.message || e}`);
    } finally {
      setToVisualBusy(false);
    }
  }, [value, onConvertToVisual]);

  const extensions = [
    sql({ schema: schema ?? {} }),
    antiPatternLinter(),
  ];

  const heightPx = height
    ? (typeof height === 'number' ? `${height}px` : height)
    : undefined;

  return (
    <Box
      sx={{
        // flex fill: grow to take available space; minHeight:0 lets CodeMirror
        // shrink correctly inside a flex column (without it height:100% resolves to 0)
        flexGrow: 1,
        minHeight: 0,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        border: 'none',
        position: 'relative',  // anchor for the EXPLAIN popover
        '& .qs-anti-pattern-bar': {
          flexShrink: 0,
          px: 1, py: 0.5,
          borderBottom: '1px solid #eee',
          bgcolor: '#fafbfc',
        },
        '& .cm-editor': {
          flex: 1,
          minHeight: 0,
          height: heightPx ?? '100%',
          ...(minHeight ? { minHeight: typeof minHeight === 'number' ? `${minHeight}px` : minHeight } : {}),
          ...(maxHeight ? { maxHeight: typeof maxHeight === 'number' ? `${maxHeight}px` : maxHeight } : {}),
          fontSize: '0.84rem',
          fontFamily: '"Consolas", "Monaco", "Courier New", monospace',
          lineHeight: 1.55,
        },
        '& .cm-editor.cm-focused': { outline: 'none' },
        // scroller must be scrollable and fill the editor height
        '& .cm-scroller': { overflow: 'auto', flex: 1, minHeight: 0 },
        '& .cm-content': { padding: '6px 0' },
        '& .cm-placeholder': { color: '#aaa', fontStyle: 'italic' },
        ...sx,
      }}
    >
      {(antiPatterns.length > 0 || showFormatButton) && (
        <Stack
          direction="row" spacing={0.5} flexWrap="wrap" useFlexGap alignItems="center"
          className="qs-anti-pattern-bar"
          data-anti-pattern-bar
        >
          {antiPatterns.map(p => (
            <Tooltip key={p.id} title={p.hint} arrow placement="top">
              <Chip
                size="small"
                color={p.severity === 'warn' ? 'warning' : 'info'}
                variant="outlined"
                icon={p.severity === 'warn' ? <WarningIcon /> : <InfoIcon />}
                label={p.label}
                sx={{ fontSize: 11, height: 22 }}
              />
            </Tooltip>
          ))}
          <Box sx={{ ml: 'auto', display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
            {showRunSelectionButton && onRunSql && (
              <Tooltip title={hasSelection ? 'Run highlighted SQL only' : 'Highlight a region to enable, or click to run all'}>
                <Chip
                  size="small"
                  variant={hasSelection ? 'filled' : 'outlined'}
                  color={hasSelection ? 'success' : 'default'}
                  icon={<PlayIcon sx={{ fontSize: 12 }} />}
                  label={hasSelection ? 'Run Selection' : 'Run'}
                  onClick={handleRunSelection}
                  clickable
                  disabled={!value.trim()}
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-run-selection-button
                />
              </Tooltip>
            )}
            {showRunAllButton && onRunAllStatements && (
              <Tooltip title="Split + run each statement sequentially (uses /api/sql/split)">
                <Chip
                  size="small"
                  variant="outlined"
                  label={runAllBusy ? 'Splitting…' : 'Run All'}
                  onClick={handleRunAll}
                  clickable
                  disabled={runAllBusy || !value.trim()}
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-run-all-button
                />
              </Tooltip>
            )}
            {showTemplatesButton && (
              <Tooltip title="Insert SQL template at cursor">
                <Chip
                  size="small"
                  variant="outlined"
                  icon={<TemplateIcon sx={{ fontSize: 12 }} />}
                  label="Templates"
                  onClick={(e) => setTemplatesAnchor(e.currentTarget)}
                  clickable
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-templates-button
                />
              </Tooltip>
            )}
            {showHistoryButton && onOpenHistory && (
              <Tooltip title="Recent queries by you">
                <Chip
                  size="small"
                  variant="outlined"
                  icon={<HistoryIcon sx={{ fontSize: 12 }} />}
                  label="History"
                  onClick={onOpenHistory}
                  clickable
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-history-button
                />
              </Tooltip>
            )}
            {showFormatButton && (
              <Tooltip title="Format SQL (sqlglot)">
                <Chip
                  size="small"
                  variant="outlined"
                  label={formatBusy ? 'Formatting…' : 'Format'}
                  onClick={handleFormat}
                  clickable
                  disabled={formatBusy || !value.trim()}
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-format-button
                />
              </Tooltip>
            )}
            {showExplainButton && (
              <Tooltip title="Explain this query in plain English (Phase 139)">
                <Chip
                  size="small"
                  variant="outlined"
                  label={explainBusy ? 'Explaining…' : 'Explain'}
                  onClick={handleExplain}
                  clickable
                  disabled={explainBusy || !value.trim()}
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-explain-button
                />
              </Tooltip>
            )}
            {showToVisualButton && onConvertToVisual && (
              <Tooltip title="Reverse-engineer this SQL into the visual builder (best-effort; complex SQL may produce warnings)">
                <Chip
                  size="small"
                  variant="outlined"
                  label={toVisualBusy ? 'Converting…' : '→ Visual'}
                  onClick={handleToVisual}
                  clickable
                  disabled={toVisualBusy || !value.trim()}
                  sx={{ fontSize: 11, height: 22 }}
                  data-sql-to-visual-button
                />
              </Tooltip>
            )}
          </Box>
        </Stack>
      )}
      {/* EXPLAIN-in-English popover */}
      {explainOpen && (
        <Box
          data-sql-explain-popover
          sx={{
            position: 'absolute', zIndex: 10, top: 30, left: 8, right: 8,
            bgcolor: 'background.paper', border: '1px solid', borderColor: 'divider',
            boxShadow: 3, borderRadius: 1, p: 1.5, maxWidth: 600,
          }}
        >
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 700 }}>Plain-English plan</Typography>
            <Box sx={{ flex: 1 }} />
            <Chip size="small" label="✕" onClick={() => setExplainOpen(false)} clickable
                  sx={{ height: 20, fontSize: 11, cursor: 'pointer' }} />
          </Stack>
          <Typography variant="body2" sx={{ fontSize: 12, color: explainBusy ? 'text.secondary' : 'text.primary' }}>
            {explainBusy ? 'Computing…' : (explainText || '(no output)')}
          </Typography>
        </Box>
      )}
      <CodeMirror
        ref={editorRef}
        value={value}
        onChange={handleChange}
        onUpdate={onUpdate}
        extensions={extensions}
        theme={githubLight}
        readOnly={readOnly}
        placeholder={placeholder || 'SELECT * FROM table WHERE ...'}
        basicSetup={{
          lineNumbers: true,
          highlightActiveLineGutter: true,
          highlightSpecialChars: true,
          foldGutter: false,
          drawSelection: true,
          dropCursor: true,
          allowMultipleSelections: false,
          indentOnInput: true,
          syntaxHighlighting: true,
          bracketMatching: true,
          closeBrackets: true,
          autocompletion: true,
          rectangularSelection: false,
          crosshairCursor: false,
          highlightActiveLine: true,
          highlightSelectionMatches: true,
          closeBracketsKeymap: false,
          defaultKeymap: true,
          searchKeymap: false,
          historyKeymap: true,
          foldKeymap: false,
          completionKeymap: true,
          lintKeymap: false,
        }}
      />
      {/* Templates dropdown menu */}
      <Menu
        anchorEl={templatesAnchor}
        open={Boolean(templatesAnchor)}
        onClose={() => setTemplatesAnchor(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        {SQL_TEMPLATES.map(t => (
          <MenuItem key={t.label} onClick={() => handleInsertTemplate(t.sql)}
                    sx={{ fontSize: 12, py: 0.5 }}>
            <ListItemText primary={t.label} primaryTypographyProps={{ fontSize: 12 }} />
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
};

export default SqlEditor;
