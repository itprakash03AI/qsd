/**
 * Phase 132.36 hotfix-1 — pure-function helpers for the unified
 * WHERE-clauses section of PublishViewDialog.
 *
 * Extracted from the React component so the toggle math can be
 * unit-tested without React Testing Library / MUI render overhead.
 * The dialog imports these and wires them into useState callbacks.
 */
import { extractWhereTriples } from '../common/extractSqlColumns';

export type WhereMode = 'dynamic' | 'static';

export interface WhereClause {
  column: string;
  operator: string;
  value: unknown;
  mode: WhereMode;
  isPartition: boolean;
}

/**
 * Apply a Dynamic/Static toggle to one row.  Returns a fresh array;
 * never mutates the input.
 */
export function applyWhereModeToggle(
  rows: WhereClause[],
  idx: number,
  mode: WhereMode,
): WhereClause[] {
  return rows.map((w, i) => (i === idx ? { ...w, mode } : w));
}

/**
 * Decide what to do to ``allowedFilters`` after a toggle.  Returns
 * the new array — DOES NOT mutate.
 *
 * Rules (Phase 132.36 hotfix-1 — the same-column peer fix):
 *   * column ∈ allowedFilters + at least one row still Dynamic for that
 *     column → keep it (no-op).
 *   * column ∉ allowedFilters + at least one row Dynamic   → add.
 *   * column ∈ allowedFilters + no rows Dynamic for that col → remove.
 *
 * The peer-aware check prevents the "Static-toggle-clobbers-Dynamic-peer"
 * regression where two rows share a column and toggling one Static
 * removed the column entirely, silently breaking the other row.
 */
export function syncAllowedFiltersAfterToggle(
  rowsAfter: WhereClause[],
  column: string,
  currentAllowedFilters: string[],
): string[] {
  if (!column) return currentAllowedFilters;
  const anyDynamic = rowsAfter.some(
    w => w.column === column && w.mode === 'dynamic',
  );
  const has = currentAllowedFilters.includes(column);
  if (anyDynamic && !has) return [...currentAllowedFilters, column];
  if (!anyDynamic && has) return currentAllowedFilters.filter(c => c !== column);
  return currentAllowedFilters;
}

/**
 * Build a where-clause row set from a saved query's ``query_config.filters``
 * + a known set of partition columns.  Partition columns default to
 * Dynamic; everything else defaults to Static.  The publisher can flip
 * each row in the dialog before saving.
 */
export function buildWhereClausesFromQueryConfig(
  qcFilters: ReadonlyArray<{ column?: string; operator?: string; value?: unknown }>,
  partitionColumns: ReadonlySet<string>,
): WhereClause[] {
  return (qcFilters || []).map(f => {
    const rawCol = f?.column || '';
    // Phase 133-H round 13 — PRESERVE the qualifier on the row.
    // Round 12 stripped ``table.``/``alias.`` prefixes so the row
    // matched bare dropdown entries.  But that collapsed
    // ``a.code`` and ``b.code`` (JOIN with aliases) into the same
    // ``code`` key — losing the per-table distinction the publisher
    // needs.  The dropdown now exposes BOTH qualified and bare
    // forms (see PublishViewDialog.columnOptions), so a row
    // carrying ``a.code`` still finds a matching option.
    //
    // Partition badge: check bare name against the partition set
    // (partition columns are reported bare by the resolver).
    const bare = rawCol.includes('.')
      ? rawCol.substring(rawCol.lastIndexOf('.') + 1)
      : rawCol;
    const isPartition = partitionColumns.has(bare)
                        || partitionColumns.has(rawCol);
    return {
      column: rawCol,
      operator: f?.operator || 'eq',
      value: f?.value,
      mode: (isPartition ? 'dynamic' : 'static') as WhereMode,
      isPartition,
    };
  });
}

/**
 * Phase 134-L (audit follow-up) — seed rows from a raw-SQL query's
 * WHERE clauses.  For raw-SQL queries (BQB SQL editor, sql_file)
 * ``qc.filters`` is empty because the filters live INSIDE the SQL
 * text instead of the visual-builder list.  Without this fallback
 * the publish dialog opens with no rows even though the source query
 * has 5 WHERE columns the publisher wants to expose.
 *
 * Contract:
 *   * Every (column, operator, value) triple in the raw SQL becomes
 *     ONE WhereClause row.
 *   * Partition columns default to Dynamic.  Everything else defaults
 *     to Static (publisher flips to Dynamic in the dialog).
 *   * Placeholder values (``?`` / ``:name``) ⇒ value="" + Dynamic.
 *   * BETWEEN / IN preserve the list shape.
 *
 * Used as a fallback when ``buildWhereClausesFromQueryConfig`` returns
 * an empty list AND ``qc.raw_sql`` (or ``qc.custom_sql`` /
 * ``qc.secondary_raw_sql``) is set.
 */
export function buildWhereClausesFromRawSql(
  rawSql: string | null | undefined,
  partitionColumns: ReadonlySet<string>,
): WhereClause[] {
  if (!rawSql) return [];
  const triples = extractWhereTriples(rawSql);
  return triples.map(t => {
    const isPartition = partitionColumns.has(t.column)
                       || partitionColumns.has(t.column.toLowerCase());
    // Dynamic by default when the value is a placeholder (no literal
    // bound in the SQL) OR the column is partitioned (high-cardinality
    // filter the publisher typically exposes); else Static.
    const isPlaceholder = !t.valueIsLiteral;
    const mode: WhereMode = (isPartition || isPlaceholder) ? 'dynamic' : 'static';
    return {
      column: t.column,
      operator: t.operator,
      value: t.value === null ? '' : t.value,
      mode,
      isPartition,
    };
  });
}


/**
 * Render a consumer URL preview for the Dynamic rows.  Used by the
 * dialog's "Consumer URL preview" panel.
 */
export function previewConsumerUrl(
  basePath: string,
  rows: ReadonlyArray<WhereClause>,
): string {
  const dyn = rows.filter(w => w.mode === 'dynamic');
  if (dyn.length === 0) return basePath;
  const qs = dyn
    .map(w => {
      if (Array.isArray(w.value)) {
        const inner = w.value
          .map(v => `'${typeof v === 'string' ? v.replace(/'/g, "\\'") : String(v)}'`)
          .join(',');
        return `${w.column}=(${inner})`;
      }
      return `${w.column}=${w.value}`;
    })
    .join('&');
  return `${basePath}?${qs}`;
}
