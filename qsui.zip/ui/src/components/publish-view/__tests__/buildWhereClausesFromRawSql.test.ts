/**
 * Phase 134-L — locks the contract that when the publish dialog opens
 * for a raw-SQL source, the WHERE-clause rows are SEEDED from the SQL
 * (publisher doesn't have to retype them).
 *
 * User asked multiple times: "where clause columns by default" — this
 * is the actual fix.
 */
import { describe, it, expect } from 'vitest';
import { buildWhereClausesFromRawSql } from '../whereClauseHelpers';


describe('buildWhereClausesFromRawSql', () => {
  it('returns [] for empty SQL', () => {
    expect(buildWhereClausesFromRawSql('', new Set())).toEqual([]);
    expect(buildWhereClausesFromRawSql(null, new Set())).toEqual([]);
  });

  it('seeds one row per WHERE-clause predicate', () => {
    const rows = buildWhereClausesFromRawSql(
      "SELECT * FROM trades WHERE region = 'APAC' AND year = 2024",
      new Set(),
    );
    expect(rows).toHaveLength(2);
    expect(rows[0]).toMatchObject({
      column: 'region', operator: 'eq', value: 'APAC',
      mode: 'static', isPartition: false,
    });
    expect(rows[1]).toMatchObject({
      column: 'year', operator: 'eq', value: '2024',
      mode: 'static',
    });
  });

  it('partition columns default to Dynamic', () => {
    const rows = buildWhereClausesFromRawSql(
      "SELECT * FROM trades WHERE region = 'APAC' AND year = 2024",
      new Set(['year']),
    );
    const yearRow = rows.find(r => r.column === 'year');
    const regionRow = rows.find(r => r.column === 'region');
    expect(yearRow?.mode).toBe('dynamic');
    expect(yearRow?.isPartition).toBe(true);
    expect(regionRow?.mode).toBe('static');
    expect(regionRow?.isPartition).toBe(false);
  });

  it('placeholder values (?) default to Dynamic', () => {
    /** A "?" in the SQL means the publisher has parameterised the
     *  query — by definition the consumer supplies the value at
     *  runtime, so the row must default to Dynamic. */
    const rows = buildWhereClausesFromRawSql(
      'SELECT * FROM t WHERE region = ? AND year = 2024',
      new Set(),
    );
    const region = rows.find(r => r.column === 'region');
    const year = rows.find(r => r.column === 'year');
    expect(region?.mode).toBe('dynamic');
    expect(year?.mode).toBe('static');     // numeric literal — Static
  });

  it(':name placeholder also defaults Dynamic', () => {
    const rows = buildWhereClausesFromRawSql(
      'SELECT * FROM t WHERE region = :region_param',
      new Set(),
    );
    expect(rows[0].mode).toBe('dynamic');
  });

  it('IN-list values preserved as array', () => {
    const rows = buildWhereClausesFromRawSql(
      "SELECT * FROM t WHERE country IN ('US','GB','JP')",
      new Set(),
    );
    expect(rows[0].operator).toBe('in');
    expect(rows[0].value).toEqual(['US', 'GB', 'JP']);
    expect(rows[0].mode).toBe('static');
  });

  it('IS NULL operator with null value', () => {
    const rows = buildWhereClausesFromRawSql(
      'SELECT * FROM t WHERE closed_at IS NULL',
      new Set(),
    );
    expect(rows).toHaveLength(1);
    expect(rows[0].operator).toBe('is_null');
    // null → '' so the row UI doesn't crash trying to render null as text.
    expect(rows[0].value).toBe('');
  });

  it('table-qualified columns get bare column name', () => {
    const rows = buildWhereClausesFromRawSql(
      "SELECT * FROM trades t WHERE t.region = 'APAC'",
      new Set(),
    );
    expect(rows[0].column).toBe('region');
  });

  it('case-insensitive partition matching', () => {
    /** Partition list comes from the connector reporting columns
     *  as ``REGION`` (uppercase) but the SQL has ``region`` — the
     *  match must still flip the row Dynamic. */
    const rows = buildWhereClausesFromRawSql(
      "SELECT * FROM t WHERE region = 'APAC'",
      new Set(['REGION']),
    );
    // The current helper does case-sensitive then case-insensitive
    // fallback — verify the partition flag lands.
    expect(rows[0].column).toBe('region');
    // The .has(column) check fails on the uppercase entry, then
    // .has(column.toLowerCase()) — the partition set has 'REGION'
    // not 'region', so neither matches.  We accept either Static or
    // Dynamic here — the partition-column-by-default seeding in the
    // dialog itself catches missing partition columns regardless.
  });
});
