/**
 * Phase 132.36 hotfix-1/2 — Vitest unit tests for the WHERE-clause
 * helpers that drive the PublishViewDialog's unified Dynamic/Static
 * toggle UI.  Locks in the same-column peer-aware behaviour (the bug
 * the deep-dive audit caught) + URL-preview rendering.
 */
import { describe, it, expect } from 'vitest';
import {
  applyWhereModeToggle,
  syncAllowedFiltersAfterToggle,
  buildWhereClausesFromQueryConfig,
  previewConsumerUrl,
  WhereClause,
} from '../whereClauseHelpers';

const row = (
  column: string,
  mode: 'dynamic' | 'static' = 'static',
  extra: Partial<WhereClause> = {},
): WhereClause => ({
  column,
  operator: 'eq',
  value: 'X',
  mode,
  isPartition: false,
  ...extra,
});

// ── applyWhereModeToggle ─────────────────────────────────────────────

describe('applyWhereModeToggle', () => {
  it('flips a row without mutating siblings', () => {
    const before = [row('region', 'static'), row('year', 'static')];
    const after  = applyWhereModeToggle(before, 0, 'dynamic');
    expect(after).not.toBe(before);                           // new array
    expect(after[0].mode).toBe('dynamic');
    expect(after[1].mode).toBe('static');
    expect(before[0].mode).toBe('static');                    // input untouched
  });

  it('ignores out-of-range indices safely', () => {
    const before = [row('region', 'static')];
    const after  = applyWhereModeToggle(before, 99, 'dynamic');
    expect(after).toEqual(before);
  });
});

// ── syncAllowedFiltersAfterToggle (the peer-aware fix) ──────────────

describe('syncAllowedFiltersAfterToggle', () => {
  it('adds the column when toggling to Dynamic and not yet present', () => {
    const after = [row('region', 'dynamic')];
    expect(syncAllowedFiltersAfterToggle(after, 'region', []))
      .toEqual(['region']);
  });

  it('removes the column when toggling to Static and no peer is Dynamic', () => {
    const after = [row('region', 'static')];
    expect(syncAllowedFiltersAfterToggle(after, 'region', ['region']))
      .toEqual([]);
  });

  it('PEER-AWARE: same-column peer still Dynamic → keep column in allowedFilters', () => {
    /**
     * The deep-dive-caught bug: two rows on ``region`` — one Dynamic
     * (Row 0) and one just toggled to Static (Row 1).  Naïve code
     * removed ``region`` from allowed_filters, silently breaking
     * Row 0's consumer override.
     */
    const after = [
      row('region', 'dynamic'),       // peer still wants Dynamic
      row('region', 'static'),        // just toggled to Static
    ];
    expect(syncAllowedFiltersAfterToggle(after, 'region', ['region']))
      .toEqual(['region']);
  });

  it('PEER-AWARE: any-row-Dynamic forces presence even when adding from empty', () => {
    const after = [
      row('region', 'dynamic'),
      row('region', 'static'),
    ];
    expect(syncAllowedFiltersAfterToggle(after, 'region', []))
      .toEqual(['region']);
  });

  it('returns the same reference when no change is needed', () => {
    const after = [row('region', 'dynamic')];
    const af = ['region'];
    expect(syncAllowedFiltersAfterToggle(after, 'region', af)).toBe(af);
  });

  it('no-op on empty column name', () => {
    expect(syncAllowedFiltersAfterToggle([], '', ['region']))
      .toEqual(['region']);
  });
});

// ── buildWhereClausesFromQueryConfig ─────────────────────────────────

describe('buildWhereClausesFromQueryConfig', () => {
  it('defaults partition columns to Dynamic, others to Static', () => {
    const qc = [
      { column: 'region',   operator: 'eq', value: 'APAC' },
      { column: 'business_date', operator: 'gte', value: '2026-01-01' },
    ];
    const partitionCols = new Set(['business_date']);
    const out = buildWhereClausesFromQueryConfig(qc, partitionCols);
    expect(out).toEqual([
      { column: 'region',   operator: 'eq',  value: 'APAC',     mode: 'static',  isPartition: false },
      { column: 'business_date', operator: 'gte', value: '2026-01-01', mode: 'dynamic', isPartition: true },
    ]);
  });

  it('handles missing column / operator gracefully', () => {
    const qc = [{ value: 'X' } as any];
    const out = buildWhereClausesFromQueryConfig(qc, new Set());
    expect(out[0].column).toBe('');
    expect(out[0].operator).toBe('eq');
  });

  it('returns empty array for empty input', () => {
    expect(buildWhereClausesFromQueryConfig([], new Set())).toEqual([]);
    expect(buildWhereClausesFromQueryConfig(undefined as any, new Set())).toEqual([]);
  });
});

// ── previewConsumerUrl ───────────────────────────────────────────────

describe('previewConsumerUrl', () => {
  it('returns base path when no Dynamic rows', () => {
    const rows = [row('region', 'static')];
    expect(previewConsumerUrl('/api/v1/views/x/data', rows))
      .toBe('/api/v1/views/x/data');
  });

  it('emits scalar bare-form for Dynamic rows', () => {
    const rows = [row('region', 'dynamic', { value: 'APAC' })];
    expect(previewConsumerUrl('/api/v1/views/x/data', rows))
      .toBe('/api/v1/views/x/data?region=APAC');
  });

  it('emits IN-tuple form for array values', () => {
    const rows = [row('code', 'dynamic', { value: ['A', 'B', 'C'] })];
    expect(previewConsumerUrl('/api/v1/views/x/data', rows))
      .toBe(`/api/v1/views/x/data?code=('A','B','C')`);
  });

  it('joins multiple Dynamic rows with &', () => {
    const rows = [
      row('region', 'dynamic', { value: 'APAC' }),
      row('year',   'dynamic', { value: 2025 }),
    ];
    expect(previewConsumerUrl('/api/v1/views/x/data', rows))
      .toBe('/api/v1/views/x/data?region=APAC&year=2025');
  });

  it('skips Static rows in the URL preview', () => {
    const rows = [
      row('region', 'static',  { value: 'APAC' }),    // skipped
      row('year',   'dynamic', { value: 2025 }),
    ];
    expect(previewConsumerUrl('/api/v1/views/x/data', rows))
      .toBe('/api/v1/views/x/data?year=2025');
  });
});
