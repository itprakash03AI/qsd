/**
 * BulkPartitionActions — Phase 73
 *
 * Chip row above each partition Autocomplete providing:
 * - All / None / Invert (always)
 * - Date range shortcuts (Last 7d, 30d, This month) when date-like values detected
 */
import React, { useMemo, useState } from 'react';
import { Box, Chip, Typography } from '@mui/material';
import {
  detectDatePattern,
  selectDateRange,
  invertSelection,
} from '../../services/partitionUtils';

interface BulkPartitionActionsProps {
  /** All available values for this partition column */
  allValues: string[];
  /** Currently selected values */
  selected: string[];
  /** Callback to update selection */
  onChange: (newSelection: string[]) => void;
}

const BulkPartitionActions: React.FC<BulkPartitionActionsProps> = ({
  allValues,
  selected,
  onChange,
}) => {
  const datePattern = useMemo(() => detectDatePattern(allValues), [allValues]);
  const [zeroResultWarning, setZeroResultWarning] = useState<string | null>(null);

  const handleAll = () => { setZeroResultWarning(null); onChange([...allValues]); };
  const handleNone = () => { setZeroResultWarning(null); onChange([]); };
  const handleInvert = () => { setZeroResultWarning(null); onChange(invertSelection(allValues, selected)); };

  const handleDateRange = (range: 'last7d' | 'last30d' | 'thisMonth' | 'lastMonth' | 'thisYear') => {
    if (!datePattern) return;
    const rangeValues = selectDateRange(allValues, range, datePattern);
    if (rangeValues.length === 0) {
      setZeroResultWarning('No partitions found for the selected date range. The current data may not cover this period.');
      return;
    }
    setZeroResultWarning(null);
    onChange(rangeValues);
  };

  const chipSx = {
    height: 20,
    fontSize: 10,
    fontWeight: 600,
    '& .MuiChip-label': { px: 0.75 },
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 0.5 }}>
        <Chip label="All" size="small" variant="outlined" onClick={handleAll} sx={chipSx} />
        <Chip label="None" size="small" variant="outlined" onClick={handleNone} sx={chipSx} />
        <Chip label="Invert" size="small" variant="outlined" onClick={handleInvert}
          sx={chipSx}
          disabled={selected.length === 0 && allValues.length === 0}
        />
        {datePattern && datePattern !== 'month' && (
          <>
            <Box sx={{ width: 1, borderLeft: '1px solid', borderColor: 'divider', mx: 0.25, my: 0.25 }} />
            {(datePattern === 'date') && (
              <>
                <Chip label="Last 7d" size="small" color="info" variant="outlined"
                  onClick={() => handleDateRange('last7d')} sx={chipSx} />
                <Chip label="Last 30d" size="small" color="info" variant="outlined"
                  onClick={() => handleDateRange('last30d')} sx={chipSx} />
              </>
            )}
            <Chip label="This mo" size="small" color="info" variant="outlined"
              onClick={() => handleDateRange('thisMonth')} sx={chipSx} />
            <Chip label="Last mo" size="small" color="info" variant="outlined"
              onClick={() => handleDateRange('lastMonth')} sx={chipSx} />
            <Chip label="This yr" size="small" color="info" variant="outlined"
              onClick={() => handleDateRange('thisYear')} sx={chipSx} />
          </>
        )}
      </Box>
      {zeroResultWarning && (
        <Typography color="warning.main" variant="caption" sx={{ display: 'block', mt: 0.25 }}>
          {zeroResultWarning}
        </Typography>
      )}
    </Box>
  );
};

export default BulkPartitionActions;
