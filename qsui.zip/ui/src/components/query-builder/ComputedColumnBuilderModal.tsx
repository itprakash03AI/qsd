import React from 'react';
import {
  Box, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, IconButton, Alert, Stack, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Calculate as ComputedIcon,
} from '@mui/icons-material';
import type { ComputedColumnDef } from './types';

interface ComputedColumnBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  computedColumns: ComputedColumnDef[];
  // BF-427: typed callback so misrouted setter fails at compile time
  onUpdate: (cols: ComputedColumnDef[]) => void;
  onClose: () => void;
}

const ComputedColumnBuilderModal = ({ open, tables, schemas, computedColumns, onUpdate, onClose }: ComputedColumnBuilderModalProps) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(computedColumns.length > 0 ? [...computedColumns] : []); }, [open]); // eslint-disable-line

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => setLocal(prev => [...prev, { expression: '', alias: '' }]);
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: string) => setLocal(prev => prev.map((c, idx) => idx === i ? { ...c, [field]: val } : c));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><ComputedIcon color="info" /> Computed Columns</Box></DialogTitle>
      <DialogContent dividers>
        <Alert severity="info" sx={{ mb: 2, fontSize: 12 }}>
          Write SQL expressions using column names and functions. Available columns: <strong>{allCols.slice(0, 10).join(', ')}{allCols.length > 10 ? '...' : ''}</strong>
          <br />Operators: <code>+ - * / %</code> | Functions: <code>YEAR(), MONTH(), DATE_TRUNC(), UPPER(), LOWER(), CONCAT(), SUBSTRING(), ROUND(), COALESCE(), CAST(), ABS(), LENGTH()</code>
        </Alert>
        <Stack spacing={1.5}>
          {local.map((cc, i) => (
            <Paper key={i} variant="outlined" sx={{ p: 1.5, display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField size="small" label="Expression" value={cc.expression} fullWidth
                placeholder="e.g. price * quantity" onChange={e => update(i, 'expression', e.target.value)} />
              <Typography variant="body2" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>AS</Typography>
              <TextField size="small" label="Alias" value={cc.alias} sx={{ minWidth: 150 }}
                placeholder="e.g. total_price" onChange={e => update(i, 'alias', e.target.value)} />
              <IconButton size="small" color="error" onClick={() => remove(i)}><DeleteIcon fontSize="small" /></IconButton>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add Computed Column
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(c => c.expression && c.alias)); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ComputedColumnBuilderModal;
