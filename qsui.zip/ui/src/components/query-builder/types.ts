/**
 * Shared types and constants for query-builder sub-components.
 */

export interface FileItem {
  name: string;
  path: string;
  folder?: string;
  displayPath?: string;
  num_rows?: number;
  num_columns?: number;
}

export interface SchemaColumn {
  name: string;
  type: string;
  empty?: boolean;
}

export interface SelectedColumn {
  tableName: string;
  columnName: string;
  type: string;
}

export interface JoinCondition {
  leftColumn: string;
  rightColumn: string;
}

export interface JoinDef {
  leftTable: string;
  rightTable: string;
  conditions: JoinCondition[];
  joinType: string;
  rightSuffix: string;
  rightColumnAliases: Record<string, string>;
}

export interface AggregationDef {
  column: string;
  function: string;
  alias: string;
  distinct?: boolean;
  _suggestedFn?: string;
  _suggestedDistinct?: boolean;
  _source?: string;
}

export interface FilterDef {
  id: number;
  column: string;
  operator: string;
  value: string;
  value_low?: string;
  value_high?: string;
}

export interface HavingDef {
  column: string;
  function: string;
  operator: string;
  value: string;
}

export interface ComputedColumnDef {
  expression: string;
  alias: string;
}

export interface WhenClause {
  when_column: string;
  when_operator: string;
  when_value: string;
  then_value: string;
}

export interface CaseExpressionDef {
  alias: string;
  else_value: string;
  when_clauses: WhenClause[];
}

export interface OrderByDef {
  column: string;
  direction: 'ASC' | 'DESC';
}

export interface WindowFunctionDef {
  function: string;
  alias: string;
  column: string;
  partition_by: string[];
  order_by: OrderByDef[];
  offset?: number;
  default_value?: string;
}

// ── Shared constants ────────────────────────────────────────────────────────

/**
 * Single source of truth for numeric type detection.
 * Matches all DuckDB numeric types including unsigned variants, HUGEINT,
 * Parquet physical types (INT96), and parameterised types like DECIMAL(18,2).
 * The regex strips parenthesised suffixes before matching.
 */
export const NUMERIC_RE = /^(TINYINT|SMALLINT|INTEGER|BIGINT|HUGEINT|FLOAT|DOUBLE|DECIMAL|NUMERIC|REAL|UTINYINT|USMALLINT|UINTEGER|UBIGINT|NUMBER|DECIMAL128|INT|UINT|int\d*|float\d*|double|decimal|numeric|number|uint\d*|int96)$/i;

/**
 * Expanded Set kept for backward-compat with any direct `.has()` callers.
 */
export const NUMERIC_TYPES = new Set([
  'int8', 'int16', 'int32', 'int64', 'uint8', 'uint16', 'uint32', 'uint64',
  'float', 'float16', 'float32', 'float64', 'double', 'decimal', 'decimal128',
  'number', 'numeric', 'integer', 'bigint', 'smallint', 'tinyint', 'real',
  // DuckDB types previously missing — caused aggregation bug
  'int', 'hugeint', 'ubigint', 'usmallint', 'uint', 'uinteger', 'utinyint', 'int96',
]);

/**
 * Detect whether a column type is numeric.  Uses NUMERIC_RE regex as the
 * primary check (handles parameterised types like DECIMAL(18,2) and all
 * DuckDB unsigned/huge variants).
 */
export const isNumericCol = (type: string) => {
  const t = (type || '').replace(/\(.*\)/, '').trim();
  return NUMERIC_RE.test(t);
};

export const AGG_FUNCS_NUMERIC = ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
export const AGG_FUNCS_ANY = ['COUNT'];

export const FILTER_OPS = [
  { value: 'eq', label: '= (equals)' },
  { value: 'ne', label: '!= (not equals)' },
  { value: 'gt', label: '> (greater than)' },
  { value: 'gte', label: '>= (greater or equal)' },
  { value: 'lt', label: '< (less than)' },
  { value: 'lte', label: '<= (less or equal)' },
  { value: 'in', label: 'IN (comma-separated)' },
  { value: 'not_in', label: 'NOT IN (comma-separated)' },
  { value: 'contains', label: 'LIKE (contains)' },
  { value: 'not_contains', label: 'NOT LIKE' },
  { value: 'between', label: 'BETWEEN (range)' },
  { value: 'is_null', label: 'IS NULL' },
  { value: 'is_not_null', label: 'IS NOT NULL' },
];

export const NO_VALUE_OPS = new Set(['is_null', 'is_not_null']);
export const LIST_OPS = new Set(['in', 'not_in']);

export const HAVING_OPS = [
  { value: 'eq', label: '=' }, { value: 'ne', label: '!=' },
  { value: 'gt', label: '>' }, { value: 'gte', label: '>=' },
  { value: 'lt', label: '<' }, { value: 'lte', label: '<=' },
];

export const AGG_FNS = ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];

export const CASE_OPS = [
  { value: 'eq', label: '=' }, { value: 'ne', label: '!=' },
  { value: 'gt', label: '>' }, { value: 'gte', label: '>=' },
  { value: 'lt', label: '<' }, { value: 'lte', label: '<=' },
  { value: 'is_null', label: 'IS NULL' }, { value: 'is_not_null', label: 'IS NOT NULL' },
];

export const WINDOW_FNS = ['ROW_NUMBER', 'RANK', 'DENSE_RANK', 'LAG', 'LEAD', 'SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
export const WINDOW_NO_COL = new Set(['ROW_NUMBER', 'RANK', 'DENSE_RANK']);

export const JOIN_TYPE_COLORS: Record<string, string> = {
  inner: '#2563eb', left: '#059669', right: '#d97706', outer: '#7c3aed',
};
