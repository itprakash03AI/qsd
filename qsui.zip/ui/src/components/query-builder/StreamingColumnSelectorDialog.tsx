import React from 'react';
import {
  Box, Typography, Button, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Checkbox, Chip, InputAdornment,
} from '@mui/material';
import { Search as SearchIcon } from '@mui/icons-material';

interface StreamingColumnSelectorDialogProps {
  open: boolean;
  columns: Array<{ name: string; type: string; empty: boolean }>;
  estimatedRows: number;
  selectedCols: string[];
  onSelectCols: (cols: string[]) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

const StreamingColumnSelectorDialog = ({
  open, columns, estimatedRows, selectedCols, onSelectCols, onConfirm, onCancel,
}: StreamingColumnSelectorDialogProps) => {
  const [search, setSearch] = React.useState('');
  const filtered = search
    ? columns.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
    : columns;
  const nonEmptyCols = columns.filter(c => !c.empty);

  const toggle = (name: string) => {
    onSelectCols(
      selectedCols.includes(name)
        ? selectedCols.filter(n => n !== name)
        : [...selectedCols, name]
    );
  };

  return (
    <Dialog open={open} onClose={onCancel} maxWidth="sm" fullWidth
      PaperProps={{ sx: { maxHeight: '80vh' } }}>
      <DialogTitle sx={{ pb: 1 }}>
        <Typography variant="h6" fontWeight={700} fontSize={16}>Select Streaming Columns</Typography>
        <Typography variant="caption" color="text.secondary">
          {columns.length} columns available
          {estimatedRows > 0 ? ` · ~${estimatedRows.toLocaleString()} estimated rows` : ''}
          {' · '}{selectedCols.length} selected
        </Typography>
      </DialogTitle>
      <DialogContent dividers sx={{ p: 2 }}>
        <TextField size="small" fullWidth placeholder="Search columns..." variant="outlined"
          value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ mb: 1.5 }} />
        <Box sx={{ display: 'flex', gap: 0.5, mb: 1.5, flexWrap: 'wrap' }}>
          <Button size="small" variant="outlined" onClick={() => onSelectCols(columns.map(c => c.name))}>
            All ({columns.length})
          </Button>
          <Button size="small" variant="outlined" color="success"
            onClick={() => onSelectCols(nonEmptyCols.map(c => c.name))}>
            Non-empty ({nonEmptyCols.length})
          </Button>
          <Button size="small" variant="outlined"
            onClick={() => onSelectCols(nonEmptyCols.slice(0, 20).map(c => c.name))}>
            First 20
          </Button>
          <Button size="small" variant="outlined" color="error" onClick={() => onSelectCols([])}>
            Clear
          </Button>
        </Box>
        <Box sx={{ maxHeight: 360, overflow: 'auto' }}>
          {filtered.map(col => (
            <Box key={col.name} sx={{
              display: 'flex', alignItems: 'center', gap: 0.5, py: 0.25,
              opacity: col.empty ? 0.55 : 1,
            }}>
              <Checkbox checked={selectedCols.includes(col.name)} size="small"
                onChange={() => toggle(col.name)} sx={{ p: 0.25 }} />
              <Typography variant="body2" sx={{ fontSize: 13, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {col.name}
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: 10, flexShrink: 0 }}>
                {col.type}
              </Typography>
              {col.empty && (
                <Chip label="empty" size="small" color="warning" variant="outlined"
                  sx={{ height: 16, fontSize: 9, fontWeight: 700, ml: 0.5, flexShrink: 0 }} />
              )}
            </Box>
          ))}
        </Box>
      </DialogContent>
      <DialogActions sx={{ px: 2, py: 1.5 }}>
        <Button onClick={onCancel} color="inherit" size="small">Skip Streaming</Button>
        <Button variant="contained" onClick={onConfirm} size="small"
          disabled={selectedCols.length === 0}>
          Stream ({selectedCols.length} column{selectedCols.length !== 1 ? 's' : ''})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default StreamingColumnSelectorDialog;
