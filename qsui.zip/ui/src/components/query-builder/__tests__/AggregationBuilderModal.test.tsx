/**
 * Phase 125-C — Aggregation contract tests.
 *
 * Verifies that isNumericCol() correctly classifies DuckDB types so the
 * AggregationBuilderModal offers the right aggregation functions:
 *   - Numeric types → SUM, AVG, COUNT, MIN, MAX
 *   - Non-numeric types → COUNT only
 */
import { describe, it, expect } from 'vitest';
import { isNumericCol, AGG_FUNCS_NUMERIC, AGG_FUNCS_ANY } from '../types';

// ── Contract: numeric types get full aggregation functions ─────────────────

describe('Aggregation function availability contract', () => {
  // All DuckDB numeric types that should enable SUM/AVG/MIN/MAX
  const NUMERIC_TYPES = [
    // Standard SQL
    'INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT', 'REAL', 'FLOAT', 'DOUBLE',
    'DECIMAL', 'NUMERIC', 'DECIMAL(18,2)', 'NUMERIC(10)',
    // DuckDB-specific
    'INT', 'HUGEINT', 'UBIGINT', 'USMALLINT', 'UINT', 'UINTEGER', 'UTINYINT',
    // Parquet/Arrow logical types
    'int8', 'int16', 'int32', 'int64', 'int96',
    'uint8', 'uint16', 'uint32', 'uint64',
    'float32', 'float64', 'decimal128', 'NUMBER',
  ];

  // Non-numeric types that should only get COUNT
  const NON_NUMERIC_TYPES = [
    'VARCHAR', 'TEXT', 'BOOLEAN', 'DATE', 'TIMESTAMP', 'TIMESTAMPTZ',
    'INTERVAL', 'BLOB', 'UUID', 'JSON', 'ENUM',
  ];

  it.each(NUMERIC_TYPES)(
    'numeric type "%s" gets SUM/AVG/COUNT/MIN/MAX',
    (type) => {
      expect(isNumericCol(type)).toBe(true);
      // In the modal, numeric columns get AGG_FUNCS_NUMERIC
      expect(AGG_FUNCS_NUMERIC).toContain('SUM');
      expect(AGG_FUNCS_NUMERIC).toContain('AVG');
      expect(AGG_FUNCS_NUMERIC).toContain('MIN');
      expect(AGG_FUNCS_NUMERIC).toContain('MAX');
      expect(AGG_FUNCS_NUMERIC).toContain('COUNT');
    },
  );

  it.each(NON_NUMERIC_TYPES)(
    'non-numeric type "%s" gets COUNT only',
    (type) => {
      expect(isNumericCol(type)).toBe(false);
      // In the modal, non-numeric columns get AGG_FUNCS_ANY
      expect(AGG_FUNCS_ANY).toEqual(['COUNT']);
    },
  );

  it('AGG_FUNCS_NUMERIC is a superset of AGG_FUNCS_ANY', () => {
    for (const fn of AGG_FUNCS_ANY) {
      expect(AGG_FUNCS_NUMERIC).toContain(fn);
    }
  });

  // Regression: previously missing types that caused the aggregation bug
  it('regression: DuckDB unsigned/huge types are numeric', () => {
    const previouslyMissing = [
      'INT', 'HUGEINT', 'UBIGINT', 'USMALLINT', 'UINT', 'UINTEGER', 'UTINYINT', 'int96',
    ];
    for (const type of previouslyMissing) {
      expect(isNumericCol(type)).toBe(true);
    }
  });
});
