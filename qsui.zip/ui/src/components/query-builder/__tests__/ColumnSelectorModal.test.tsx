/**
 * Phase 126-C — ColumnSelectorModal render + interaction tests.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ColumnSelectorModal from '../ColumnSelectorModal';

const TABLES = [{ name: 'sales', path: 'sales.parquet' }];
const SCHEMAS: Record<string, { name: string; type: string }[]> = {
  'sales.parquet': [
    { name: 'region', type: 'VARCHAR' },
    { name: 'amount', type: 'DOUBLE' },
    { name: 'quantity', type: 'INTEGER' },
  ],
};

const defaultProps = {
  open: true,
  tables: TABLES,
  schemas: SCHEMAS,
  selectedColumns: [],
  onUpdate: vi.fn(),
  onClose: vi.fn(),
};

describe('ColumnSelectorModal', () => {
  it('renders dialog when open', () => {
    render(<ColumnSelectorModal {...defaultProps} />);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('does not render dialog when closed', () => {
    render(<ColumnSelectorModal {...defaultProps} open={false} />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('displays column names from schema', () => {
    render(<ColumnSelectorModal {...defaultProps} />);
    expect(screen.getByText(/region/i)).toBeInTheDocument();
    expect(screen.getByText(/amount/i)).toBeInTheDocument();
    expect(screen.getByText(/quantity/i)).toBeInTheDocument();
  });

  it('shows checkboxes for columns', () => {
    render(<ColumnSelectorModal {...defaultProps} />);
    const checkboxes = screen.getAllByRole('checkbox');
    expect(checkboxes.length).toBeGreaterThanOrEqual(3);
  });

  it('pre-checks selected columns', () => {
    const selectedColumns = [
      { tableName: 'sales', columnName: 'amount', type: 'DOUBLE' },
    ];
    render(
      <ColumnSelectorModal {...defaultProps} selectedColumns={selectedColumns} />
    );
    // The "amount" checkbox should be checked
    const checkboxes = screen.getAllByRole('checkbox');
    const checkedCount = checkboxes.filter(
      (cb) => (cb as HTMLInputElement).checked
    ).length;
    expect(checkedCount).toBeGreaterThanOrEqual(1);
  });

  it('calls onClose when close button clicked', async () => {
    const onClose = vi.fn();
    render(<ColumnSelectorModal {...defaultProps} onClose={onClose} />);
    const dialog = screen.getByRole('dialog');
    // There may be multiple "Close" buttons — use getAllByText and click the first
    const closeBtns = within(dialog).getAllByText(/close/i);
    await userEvent.click(closeBtns[0]);
    expect(onClose).toHaveBeenCalled();
  });
});
