/**
 * Phase 126-C — Query builder types and constants tests.
 *
 * Tests shared constants, filter/having/case operators, window functions,
 * and join type colors from types.ts.
 */
import { describe, it, expect } from 'vitest';
import {
  isNumericCol,
  NUMERIC_RE,
  NUMERIC_TYPES,
  AGG_FUNCS_NUMERIC,
  AGG_FUNCS_ANY,
  AGG_FNS,
  FILTER_OPS,
  NO_VALUE_OPS,
  LIST_OPS,
  HAVING_OPS,
  CASE_OPS,
  WINDOW_FNS,
  WINDOW_NO_COL,
  JOIN_TYPE_COLORS,
} from '../types';

// ── Constants integrity ──────────────────────────────────────────────────────

describe('AGG_FUNCS constants', () => {
  it('AGG_FUNCS_NUMERIC has 5 functions', () => {
    expect(AGG_FUNCS_NUMERIC).toHaveLength(5);
    expect(AGG_FUNCS_NUMERIC).toEqual(['SUM', 'AVG', 'COUNT', 'MIN', 'MAX']);
  });

  it('AGG_FUNCS_ANY has only COUNT', () => {
    expect(AGG_FUNCS_ANY).toEqual(['COUNT']);
  });

  it('AGG_FNS matches AGG_FUNCS_NUMERIC', () => {
    expect(AGG_FNS).toEqual(AGG_FUNCS_NUMERIC);
  });
});

describe('FILTER_OPS', () => {
  it('has 13 operators', () => {
    expect(FILTER_OPS).toHaveLength(13);
  });

  it('all entries have value and label', () => {
    for (const op of FILTER_OPS) {
      expect(op).toHaveProperty('value');
      expect(op).toHaveProperty('label');
    }
  });

  it('includes BETWEEN operator', () => {
    expect(FILTER_OPS.find(op => op.value === 'between')).toBeDefined();
  });

  it('NO_VALUE_OPS has is_null and is_not_null', () => {
    expect(NO_VALUE_OPS.has('is_null')).toBe(true);
    expect(NO_VALUE_OPS.has('is_not_null')).toBe(true);
    expect(NO_VALUE_OPS.size).toBe(2);
  });

  it('LIST_OPS has in and not_in', () => {
    expect(LIST_OPS.has('in')).toBe(true);
    expect(LIST_OPS.has('not_in')).toBe(true);
    expect(LIST_OPS.size).toBe(2);
  });
});

describe('HAVING_OPS', () => {
  it('has 6 comparison operators', () => {
    expect(HAVING_OPS).toHaveLength(6);
    const values = HAVING_OPS.map(o => o.value);
    expect(values).toContain('eq');
    expect(values).toContain('gt');
    expect(values).toContain('lte');
  });
});

describe('CASE_OPS', () => {
  it('has 8 operators (including is_null/is_not_null)', () => {
    expect(CASE_OPS).toHaveLength(8);
    const values = CASE_OPS.map(o => o.value);
    expect(values).toContain('is_null');
    expect(values).toContain('is_not_null');
  });
});

describe('WINDOW_FNS', () => {
  it('has ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD plus aggregates', () => {
    expect(WINDOW_FNS).toContain('ROW_NUMBER');
    expect(WINDOW_FNS).toContain('LAG');
    expect(WINDOW_FNS).toContain('LEAD');
    expect(WINDOW_FNS).toContain('SUM');
  });

  it('WINDOW_NO_COL has ranking functions', () => {
    expect(WINDOW_NO_COL.has('ROW_NUMBER')).toBe(true);
    expect(WINDOW_NO_COL.has('RANK')).toBe(true);
    expect(WINDOW_NO_COL.has('DENSE_RANK')).toBe(true);
    expect(WINDOW_NO_COL.has('SUM')).toBe(false);
  });
});

describe('JOIN_TYPE_COLORS', () => {
  it('has all 4 join types', () => {
    expect(JOIN_TYPE_COLORS).toHaveProperty('inner');
    expect(JOIN_TYPE_COLORS).toHaveProperty('left');
    expect(JOIN_TYPE_COLORS).toHaveProperty('right');
    expect(JOIN_TYPE_COLORS).toHaveProperty('outer');
  });

  it('all values are hex color strings', () => {
    for (const color of Object.values(JOIN_TYPE_COLORS)) {
      expect(color).toMatch(/^#[0-9a-f]{6}$/);
    }
  });
});

// ── NUMERIC_TYPES Set ────────────────────────────────────────────────────────

describe('NUMERIC_TYPES Set', () => {
  it('contains all standard lowercase types', () => {
    for (const t of ['integer', 'bigint', 'double', 'float32', 'decimal128']) {
      expect(NUMERIC_TYPES.has(t)).toBe(true);
    }
  });

  it('does NOT contain non-numeric types', () => {
    for (const t of ['varchar', 'boolean', 'date', 'timestamp']) {
      expect(NUMERIC_TYPES.has(t)).toBe(false);
    }
  });
});

// ── NUMERIC_RE regex ─────────────────────────────────────────────────────────

describe('NUMERIC_RE', () => {
  it('matches case-insensitively', () => {
    expect(NUMERIC_RE.test('integer')).toBe(true);
    expect(NUMERIC_RE.test('INTEGER')).toBe(true);
    expect(NUMERIC_RE.test('Integer')).toBe(true);
  });

  it('does not match partial strings', () => {
    expect(NUMERIC_RE.test('BIGINTEGER')).toBe(false);
    expect(NUMERIC_RE.test('xINTEGER')).toBe(false);
  });

  it('does not match INTERVAL (potential false positive)', () => {
    expect(NUMERIC_RE.test('INTERVAL')).toBe(false);
  });
});
