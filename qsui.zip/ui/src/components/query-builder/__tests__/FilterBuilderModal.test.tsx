/**
 * Phase 126-C — FilterBuilderModal render + interaction tests.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import FilterBuilderModal from '../FilterBuilderModal';

const TABLES = [{ name: 'sales', path: 'sales.parquet' }];
const SCHEMAS: Record<string, { name: string; type: string }[]> = {
  'sales.parquet': [
    { name: 'region', type: 'VARCHAR' },
    { name: 'amount', type: 'DOUBLE' },
    { name: 'date', type: 'DATE' },
  ],
};

const defaultProps = {
  open: true,
  tables: TABLES,
  schemas: SCHEMAS,
  filters: [],
  filterLogic: 'AND',
  onFilterLogicChange: vi.fn(),
  onUpdate: vi.fn(),
  onClose: vi.fn(),
};

describe('FilterBuilderModal', () => {
  it('renders dialog when open', () => {
    render(<FilterBuilderModal {...defaultProps} />);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('does not render dialog when closed', () => {
    render(<FilterBuilderModal {...defaultProps} open={false} />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('renders Add Filter section when no filters exist', () => {
    render(<FilterBuilderModal {...defaultProps} />);
    expect(screen.getByText(/add filter/i)).toBeInTheDocument();
  });

  it('shows existing filters', () => {
    const filters = [
      { id: 1, column: 'region', operator: 'eq', value: 'US' },
    ];
    render(<FilterBuilderModal {...defaultProps} filters={filters} />);
    expect(screen.getByText(/region/i)).toBeInTheDocument();
  });

  it('shows AND/OR toggle', () => {
    render(<FilterBuilderModal {...defaultProps} />);
    // Should show logic buttons
    expect(screen.getByText('AND')).toBeInTheDocument();
    expect(screen.getByText('OR')).toBeInTheDocument();
  });

  it('calls onClose when cancel/close clicked', async () => {
    const onClose = vi.fn();
    render(<FilterBuilderModal {...defaultProps} onClose={onClose} />);
    const dialog = screen.getByRole('dialog');
    const cancelBtn = within(dialog).getByText(/cancel|close|done/i);
    await userEvent.click(cancelBtn);
    expect(onClose).toHaveBeenCalled();
  });
});
