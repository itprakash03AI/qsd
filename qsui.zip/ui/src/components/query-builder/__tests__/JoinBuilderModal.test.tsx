/**
 * Phase 126-C — JoinBuilderModal render tests.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import JoinBuilderModal from '../JoinBuilderModal';

const TABLES = [
  { name: 'orders', path: 'orders.parquet' },
  { name: 'customers', path: 'customers.parquet' },
];
const SCHEMAS: Record<string, { name: string; type: string }[]> = {
  'orders.parquet': [
    { name: 'order_id', type: 'INTEGER' },
    { name: 'customer_id', type: 'INTEGER' },
    { name: 'amount', type: 'DOUBLE' },
  ],
  'customers.parquet': [
    { name: 'id', type: 'INTEGER' },
    { name: 'name', type: 'VARCHAR' },
  ],
};

const defaultProps = {
  open: true,
  tables: TABLES,
  schemas: SCHEMAS,
  joins: [],
  onUpdate: vi.fn(),
  onClose: vi.fn(),
  connectionId: null,
};

describe('JoinBuilderModal', () => {
  it('renders dialog when open', () => {
    render(<JoinBuilderModal {...defaultProps} />);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('does not render dialog when closed', () => {
    render(<JoinBuilderModal {...defaultProps} open={false} />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('shows join type options', () => {
    render(<JoinBuilderModal {...defaultProps} />);
    // Join type selector should include inner
    expect(screen.getByText(/inner/i)).toBeInTheDocument();
  });

  it('shows existing joins', () => {
    const joins = [{
      leftTable: 'orders',
      rightTable: 'customers',
      conditions: [{ leftColumn: 'customer_id', rightColumn: 'id' }],
      joinType: 'inner',
      rightSuffix: '_r',
      rightColumnAliases: {},
    }];
    render(<JoinBuilderModal {...defaultProps} joins={joins} />);
    // Should display the join
    expect(screen.getByText(/orders/i)).toBeInTheDocument();
    expect(screen.getByText(/customers/i)).toBeInTheDocument();
  });
});
