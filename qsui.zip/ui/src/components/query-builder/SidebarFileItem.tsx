import React from 'react';
import {
  Checkbox, Chip, Typography, Tooltip, ListItemButton, ListItemIcon, ListItemText,
} from '@mui/material';
import { Warning as WarningIcon } from '@mui/icons-material';

interface SidebarFileItemProps {
  file: any;
  selected: boolean;
  onToggle: () => void;
  indent?: boolean;
}

const SidebarFileItem = ({ file, selected, onToggle, indent = false }: SidebarFileItemProps) => {
  const folderHint = file.displayPath || file.folder || '';
  // For Excel sheet children (path contains ::), show just the sheet name in the sidebar
  // since the parent file node is visible above. Elsewhere (column picker, SQL preview)
  // the full "filename :: SheetName" from file.name is used for disambiguation.
  const isSheet = (file.path || '').includes('::');
  const rawName = isSheet ? ((file.path || '').split('::').pop() || file.name || '') : (file.name || '');
  const displayName = rawName.replace(/\.(parquet|csv|txt|xlsx|xls|json)$/i, '');
  const ext = isSheet ? 'SHEET' : (file.name || '').match(/\.(csv|txt|xlsx|xls|json)$/i)?.[1]?.toUpperCase();
  return (
    <ListItemButton
      dense
      onClick={onToggle}
      selected={selected}
      sx={{
        pl: indent ? 3.5 : 1.5,
        pr: 1,
        py: 0.5,
        '&.Mui-selected': { bgcolor: 'rgba(21,101,192,0.08)' },
        '&.Mui-selected:hover': { bgcolor: 'rgba(21,101,192,0.12)' },
      }}
    >
      <ListItemIcon sx={{ minWidth: 24 }}>
        <Checkbox
          checked={selected}
          size="small"
          sx={{ p: 0, '& .MuiSvgIcon-root': { fontSize: 16 } }}
          disableRipple
        />
      </ListItemIcon>
      <ListItemText
        primary={<>{displayName}{ext && <Typography component="span" sx={{ ml: 0.5, fontSize: 9, px: 0.5, py: 0.1, bgcolor: 'action.selected', borderRadius: 0.5, fontWeight: 600 }}>{ext}</Typography>}</>}
        secondary={folderHint ? folderHint.replace(/\/$/, '') : null}
        primaryTypographyProps={{ variant: 'caption', fontWeight: selected ? 700 : 400, noWrap: true, component: 'div' }}
        secondaryTypographyProps={{ variant: 'caption', sx: { fontSize: 10, color: 'text.disabled' }, noWrap: true }}
      />
      {file.badge && (
        <Chip size="small" label={file.badge} color="primary" variant="outlined"
          sx={{ height: 18, fontSize: 10, minWidth: 20, ml: 0.5, '& .MuiChip-label': { px: 0.5 } }} />
      )}
      {file.num_rows > 1000000 && (
        <Tooltip title="Large file">
          <WarningIcon sx={{ fontSize: 13, color: 'warning.main', ml: 0.5 }} />
        </Tooltip>
      )}
    </ListItemButton>
  );
};

export default SidebarFileItem;
