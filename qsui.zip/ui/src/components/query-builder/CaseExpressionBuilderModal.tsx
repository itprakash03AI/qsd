import React from 'react';
import {
  Alert, Box, Button, Chip, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, Divider, TextField, MenuItem, IconButton, Stack, Tooltip,
  Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Close as CloseIcon,
  CallSplit as CaseIcon, ArrowUpward as UpIcon,
  ArrowDownward as DownIcon, AutoFixHigh as TemplateIcon,
} from '@mui/icons-material';
import { CASE_OPS, NO_VALUE_OPS } from './types';
import type { CaseExpressionDef } from './types';

interface CaseExpressionBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  caseExpressions: CaseExpressionDef[];
  // BF-427: typed callback so misrouted setter fails at compile time
  onUpdate: (exprs: CaseExpressionDef[]) => void;
  onClose: () => void;
}

// Common starter patterns — drop a fully-formed CASE in with one click.
// Saves the user from authoring the most common cases by hand.
const TEMPLATES = [
  {
    name: 'Bucketize numeric range',
    description: 'Categorize a number into low/medium/high bands',
    build: (col: string) => ({
      alias: `${col}_band`,
      when_clauses: [
        { when_column: col, when_operator: 'lt', when_value: '100', then_value: "'low'" },
        { when_column: col, when_operator: 'lt', when_value: '1000', then_value: "'medium'" },
      ],
      else_value: "'high'",
    }),
  },
  {
    name: 'Map values to labels',
    description: 'Translate codes (1/2/3) to readable labels',
    build: (col: string) => ({
      alias: `${col}_label`,
      when_clauses: [
        { when_column: col, when_operator: 'eq', when_value: '1', then_value: "'Active'" },
        { when_column: col, when_operator: 'eq', when_value: '2', then_value: "'Pending'" },
      ],
      else_value: "'Other'",
    }),
  },
  {
    name: 'Boolean flag from condition',
    description: '1 when condition matches, 0 otherwise',
    build: (col: string) => ({
      alias: `is_${col}`,
      when_clauses: [
        { when_column: col, when_operator: 'is_not_null', when_value: '', then_value: '1' },
      ],
      else_value: '0',
    }),
  },
  {
    name: 'NULL-safe coalesce label',
    description: 'Show "(missing)" when column is NULL',
    build: (col: string) => ({
      alias: `${col}_safe`,
      when_clauses: [
        { when_column: col, when_operator: 'is_null', when_value: '', then_value: "'(missing)'" },
      ],
      else_value: col,
    }),
  },
];

const opLabel = (op: string): string => {
  const found = CASE_OPS.find(o => o.value === op);
  return found ? found.label : op;
};

const buildSqlPreview = (ce: any): string => {
  if (!ce || !ce.when_clauses || ce.when_clauses.length === 0) {
    return '/* no WHEN clauses yet */';
  }
  const lines: string[] = ['CASE'];
  for (const w of ce.when_clauses) {
    if (!w.when_column) continue;
    let cond = `  WHEN ${w.when_column} ${opLabel(w.when_operator)}`;
    if (!NO_VALUE_OPS.has(w.when_operator)) {
      const v = w.when_value || '?';
      cond += ` ${v}`;
    }
    cond += ` THEN ${w.then_value || '?'}`;
    lines.push(cond);
  }
  if (ce.else_value !== '' && ce.else_value != null) {
    lines.push(`  ELSE ${ce.else_value}`);
  }
  lines.push(`END AS ${ce.alias || '<alias>'}`);
  return lines.join('\n');
};

const isCaseValid = (ce: any): { ok: boolean; reason?: string } => {
  if (!ce.alias || !ce.alias.trim()) return { ok: false, reason: 'Result alias is required' };
  if (!ce.when_clauses || ce.when_clauses.length === 0)
    return { ok: false, reason: 'Add at least one WHEN clause' };
  for (let i = 0; i < ce.when_clauses.length; i++) {
    const w = ce.when_clauses[i];
    if (!w.when_column) return { ok: false, reason: `WHEN #${i + 1}: column required` };
    if (!w.then_value && w.then_value !== '0')
      return { ok: false, reason: `WHEN #${i + 1}: THEN result required` };
    if (!NO_VALUE_OPS.has(w.when_operator) && !w.when_value && w.when_value !== '0')
      return { ok: false, reason: `WHEN #${i + 1}: value required for ${opLabel(w.when_operator)}` };
  }
  return { ok: true };
};

const CaseExpressionBuilderModal = ({ open, tables, schemas, caseExpressions, onUpdate, onClose }: CaseExpressionBuilderModalProps) => {
  const [local, setLocal] = React.useState<any[]>([]);
  const [showTemplates, setShowTemplates] = React.useState<number | null>(null);
  React.useEffect(() => { if (open) {
    setLocal(caseExpressions.length > 0 ? caseExpressions.map(ce => ({ ...ce })) : []);
    setShowTemplates(null);
  } }, [open]); // eslint-disable-line

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const colTypeOf = React.useCallback((col: string): string => {
    for (const t of tables) {
      const found = (schemas[t.path] || []).find((c: any) => c.name === col);
      if (found) return String(found.type || '').toUpperCase();
    }
    return '';
  }, [tables, schemas]);

  const valuePlaceholder = React.useCallback((col: string): string => {
    const type = colTypeOf(col);
    if (!type) return 'value';
    if (type.includes('VARCHAR') || type.includes('TEXT') || type.includes('STRING') || type.includes('CHAR'))
      return "'text' (quote strings)";
    if (type.includes('DATE') || type.includes('TIMESTAMP'))
      return "'2026-01-01' (quote dates)";
    if (type.includes('BOOL')) return 'true / false';
    return '123';
  }, [colTypeOf]);

  const thenPlaceholder = "'label' or 1 (quote text)";

  const addCase = () => setLocal(prev => [...prev, {
    alias: '', else_value: '',
    when_clauses: [{ when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }],
  }]);
  const applyTemplate = (caseIndex: number, templateIndex: number, col: string) => {
    const tpl = TEMPLATES[templateIndex];
    if (!tpl || !col) return;
    const built = tpl.build(col);
    setLocal(prev => prev.map((ce, idx) => idx === caseIndex ? built : ce));
    setShowTemplates(null);
  };
  const removeCase = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const updateCase = (i: number, field: string, val: any) => setLocal(prev => prev.map((ce, idx) => idx === i ? { ...ce, [field]: val } : ce));

  const addWhen = (i: number) => {
    const updated = [...local];
    updated[i] = { ...updated[i], when_clauses: [...updated[i].when_clauses, { when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }] };
    setLocal(updated);
  };
  const removeWhen = (ci: number, wi: number) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.filter((_: any, j: number) => j !== wi) };
    setLocal(updated);
  };
  const updateWhen = (ci: number, wi: number, field: string, val: string) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.map((w: any, j: number) => j === wi ? { ...w, [field]: val } : w) };
    setLocal(updated);
  };
  const moveWhen = (ci: number, wi: number, dir: -1 | 1) => {
    const updated = [...local];
    const arr = [...updated[ci].when_clauses];
    const target = wi + dir;
    if (target < 0 || target >= arr.length) return;
    [arr[wi], arr[target]] = [arr[target], arr[wi]];
    updated[ci] = { ...updated[ci], when_clauses: arr };
    setLocal(updated);
  };

  const validCount = local.filter(ce => isCaseValid(ce).ok).length;
  const hasInvalid = local.length > 0 && local.some(ce => !isCaseValid(ce).ok);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CaseIcon color="info" />
          <span>CASE WHEN Expressions</span>
          <Box sx={{ flex: 1 }} />
          {local.length > 0 && (
            <Chip
              label={`${validCount} of ${local.length} valid`}
              size="small"
              color={validCount === local.length ? 'success' : 'warning'}
              variant="outlined"
            />
          )}
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        {local.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 5 }}>
            <CaseIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
            <Typography variant="h6" sx={{ mb: 0.5 }}>Build a CASE WHEN expression</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, maxWidth: 520, mx: 'auto' }}>
              CASE expressions return different values based on conditions —
              like an IF/ELSE in SQL. Useful for bucketing numbers, mapping
              codes to labels, or creating boolean flags.
            </Typography>
            <Box sx={{ bgcolor: 'grey.900', color: '#9cdcfe', p: 1.5, borderRadius: 1, maxWidth: 520, mx: 'auto', mb: 2, fontFamily: 'monospace', fontSize: 12, textAlign: 'left' }}>
              CASE<br />
              &nbsp;&nbsp;WHEN amount &lt; 100 THEN 'low'<br />
              &nbsp;&nbsp;WHEN amount &lt; 1000 THEN 'medium'<br />
              &nbsp;&nbsp;ELSE 'high'<br />
              END AS amount_band
            </Box>
            <Button variant="contained" startIcon={<AddIcon />} onClick={addCase} disabled={allCols.length === 0}>
              Add your first CASE
            </Button>
            {allCols.length === 0 && (
              <Alert severity="warning" sx={{ mt: 2, maxWidth: 520, mx: 'auto' }}>
                Pick at least one table first — CASE needs columns to reference.
              </Alert>
            )}
          </Box>
        ) : (
          <Stack spacing={2}>
            <Alert severity="info" sx={{ fontSize: 12 }}>
              <strong>Quoting tip:</strong> wrap text values in <code>'single quotes'</code> (e.g. <code>'high'</code>, <code>'2026-01-01'</code>).
              Numbers and column names go in unquoted (e.g. <code>100</code>, <code>amount</code>).
              The live SQL preview below each block shows exactly what will run.
            </Alert>
            {local.map((ce, ci) => {
              const validation = isCaseValid(ce);
              const sql = buildSqlPreview(ce);
              return (
                <Paper key={ci}
                  variant="outlined"
                  sx={{
                    p: 2,
                    borderColor: validation.ok ? 'divider' : 'warning.main',
                    borderWidth: validation.ok ? 1 : 2,
                  }}>
                  <Box sx={{ display: 'flex', gap: 1, mb: 1.5, alignItems: 'center', flexWrap: 'wrap' }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }}>
                      CASE #{ci + 1}
                    </Typography>
                    <TextField size="small" label="Result alias" value={ce.alias} required
                      sx={{ minWidth: 200 }}
                      placeholder="e.g. amount_band"
                      error={!ce.alias}
                      helperText={!ce.alias ? 'Required — names the result column' : ''}
                      onChange={e => updateCase(ci, 'alias', e.target.value)} />
                    <Box sx={{ flex: 1 }} />
                    <Tooltip title="Replace this CASE with a starter template">
                      <Button size="small" variant="outlined" startIcon={<TemplateIcon />}
                        onClick={() => setShowTemplates(showTemplates === ci ? null : ci)}>
                        Templates
                      </Button>
                    </Tooltip>
                    <Tooltip title="Delete this CASE expression">
                      <IconButton size="small" color="error" onClick={() => removeCase(ci)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>

                  {showTemplates === ci && (
                    <Paper variant="outlined" sx={{ p: 1.5, mb: 1.5, bgcolor: 'grey.50' }}>
                      <Typography variant="caption" sx={{ fontWeight: 700, mb: 1, display: 'block' }}>
                        Pick a template (replaces current WHEN clauses):
                      </Typography>
                      <Stack spacing={0.5}>
                        {TEMPLATES.map((tpl, ti) => (
                          <Box key={ti} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ flex: 1 }}>
                              <Typography variant="body2" fontWeight={600}>{tpl.name}</Typography>
                              <Typography variant="caption" color="text.secondary">{tpl.description}</Typography>
                            </Box>
                            <TextField select size="small" defaultValue=""
                              SelectProps={{ displayEmpty: true }}
                              sx={{ minWidth: 180 }}
                              onChange={e => applyTemplate(ci, ti, e.target.value)}>
                              <MenuItem value="" disabled>Apply with column…</MenuItem>
                              {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                            </TextField>
                          </Box>
                        ))}
                      </Stack>
                    </Paper>
                  )}

                  {ce.when_clauses.map((w: any, wi: number) => (
                    <Box key={wi} sx={{ display: 'flex', gap: 0.75, alignItems: 'center', mb: 1, flexWrap: 'wrap' }}>
                      <Stack direction="column" sx={{ minWidth: 22 }}>
                        <IconButton size="small" disabled={wi === 0}
                          onClick={() => moveWhen(ci, wi, -1)} sx={{ p: 0.25 }}>
                          <UpIcon sx={{ fontSize: 14 }} />
                        </IconButton>
                        <IconButton size="small" disabled={wi === ce.when_clauses.length - 1}
                          onClick={() => moveWhen(ci, wi, 1)} sx={{ p: 0.25 }}>
                          <DownIcon sx={{ fontSize: 14 }} />
                        </IconButton>
                      </Stack>
                      <Chip label={`WHEN ${wi + 1}`} size="small"
                        sx={{ fontSize: 10, height: 20, fontWeight: 700 }} />
                      <TextField select size="small" label="Column" value={w.when_column}
                        sx={{ minWidth: 160 }}
                        onChange={e => updateWhen(ci, wi, 'when_column', e.target.value)}>
                        {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                      </TextField>
                      <TextField select size="small" label="Op" value={w.when_operator}
                        sx={{ minWidth: 110 }}
                        onChange={e => updateWhen(ci, wi, 'when_operator', e.target.value)}>
                        {CASE_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
                      </TextField>
                      {!NO_VALUE_OPS.has(w.when_operator) && (
                        <TextField size="small" label="Value" value={w.when_value}
                          sx={{ minWidth: 140 }}
                          placeholder={valuePlaceholder(w.when_column)}
                          onChange={e => updateWhen(ci, wi, 'when_value', e.target.value)} />
                      )}
                      <Typography variant="caption" sx={{ fontWeight: 700, color: 'primary.main' }}>→ THEN</Typography>
                      <TextField size="small" label="Result" value={w.then_value}
                        sx={{ minWidth: 140 }}
                        placeholder={thenPlaceholder}
                        error={!w.then_value && w.then_value !== '0'}
                        onChange={e => updateWhen(ci, wi, 'then_value', e.target.value)} />
                      <Tooltip title="Remove this WHEN">
                        <span>
                          <IconButton size="small" onClick={() => removeWhen(ci, wi)}
                            disabled={ce.when_clauses.length <= 1}>
                            <CloseIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </Box>
                  ))}
                  <Button size="small" startIcon={<AddIcon />} onClick={() => addWhen(ci)} sx={{ mb: 1.5 }}>
                    Add WHEN
                  </Button>

                  <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mb: 1.5 }}>
                    <Chip label="ELSE" size="small"
                      sx={{ fontSize: 10, height: 20, fontWeight: 700 }} color="default" />
                    <TextField size="small" label="Default value (optional)" value={ce.else_value || ''} fullWidth
                      placeholder="value when no WHEN matches — leave blank for NULL"
                      onChange={e => updateCase(ci, 'else_value', e.target.value)} />
                  </Box>

                  <Divider sx={{ my: 1 }} />
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }}>
                      LIVE SQL
                    </Typography>
                    {!validation.ok && (
                      <Chip label={validation.reason} size="small" color="warning" variant="outlined"
                        sx={{ fontSize: 10, height: 18 }} />
                    )}
                  </Box>
                  <Box sx={{
                    bgcolor: 'grey.900',
                    color: '#9cdcfe',
                    fontFamily: 'monospace',
                    fontSize: 12,
                    p: 1.25,
                    borderRadius: 1,
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                  }}>
                    {sql}
                  </Box>
                </Paper>
              );
            })}
            <Button size="small" startIcon={<AddIcon />} onClick={addCase} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
              Add another CASE
            </Button>
          </Stack>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning"
          disabled={local.length === 0}>
          Clear all
        </Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Tooltip title={hasInvalid ? 'Some CASE expressions are invalid — fix or remove them first' : ''}>
          <span>
            <Button variant="contained"
              disabled={hasInvalid && validCount === 0}
              onClick={() => { onUpdate(local.filter(ce => isCaseValid(ce).ok)); onClose(); }}>
              Save {validCount > 0 ? `(${validCount})` : ''}
            </Button>
          </span>
        </Tooltip>
      </DialogActions>
    </Dialog>
  );
};

export default CaseExpressionBuilderModal;
