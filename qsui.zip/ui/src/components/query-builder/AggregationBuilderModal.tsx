import React from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Checkbox, FormControlLabel, Chip,
  IconButton, Alert, Stack, Divider, Autocomplete, Tooltip,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Functions as AggIcon,
  Close as CloseIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { suggestAggFunction } from '../../services/columnIntelligence';
import { isNumericCol, AGG_FUNCS_NUMERIC, AGG_FUNCS_ANY } from './types';

// Column-name patterns used to predict role when only name+type are known
// (no row data available in this modal).  Keep IN SYNC with backend
// column-pattern config but defaults are reasonable for English schemas.
const ID_NAME_RE = /(^|_)(id|pk|key|uuid|guid)($|_)/i;
const TEMPORAL_TYPE_RE = /^(DATE|TIME|TIMESTAMP|DATETIME|INTERVAL)/i;
const MEASURE_NAME_RE = /(amount|amt|price|cost|qty|quantity|count|total|sum|revenue|profit|sales|value|balance|score|rate|pct|percent|duration|size|weight|volume)/i;

interface PredictedAgg {
  combo: string;     // e.g. "SUM(amount)"
  fn: string;        // SUM
  column: string;    // amount
  distinct?: boolean;
  reason: string;    // why we suggested it
}

/**
 * Predict useful aggregations purely from column names + types.  Runs
 * with zero historical data, so users always see SOME suggestions.
 *
 * Returns ordered by descending usefulness — measure SUM/AVG first,
 * ID counts second, temporal MIN/MAX third.
 */
function predictAggregations(cols: { name: string; type: string }[]): PredictedAgg[] {
  const out: PredictedAgg[] = [];
  const seen = new Set<string>();
  const push = (p: PredictedAgg) => {
    if (seen.has(p.combo)) return;
    seen.add(p.combo);
    out.push(p);
  };

  for (const c of cols) {
    const lower = c.name.toLowerCase();
    const typeUpper = (c.type || '').toUpperCase();
    const isId = ID_NAME_RE.test(lower);
    const isTemporal = TEMPORAL_TYPE_RE.test(typeUpper);
    const isNumber = isNumericCol(c.type);
    const isMeasure = isNumber && !isId && MEASURE_NAME_RE.test(lower);

    if (isMeasure) {
      push({ combo: `SUM(${c.name})`, fn: 'SUM', column: c.name, reason: 'numeric measure' });
      push({ combo: `AVG(${c.name})`, fn: 'AVG', column: c.name, reason: 'numeric measure' });
    } else if (isId) {
      push({ combo: `COUNT(${c.name})`, fn: 'COUNT', column: c.name, distinct: true, reason: 'identifier — count distinct' });
    } else if (isTemporal) {
      push({ combo: `MIN(${c.name})`, fn: 'MIN', column: c.name, reason: 'date/time range' });
      push({ combo: `MAX(${c.name})`, fn: 'MAX', column: c.name, reason: 'date/time range' });
    } else if (isNumber) {
      // Generic numeric — could be measure-like; still suggest SUM/AVG but lower priority
      push({ combo: `SUM(${c.name})`, fn: 'SUM', column: c.name, reason: 'numeric column' });
      push({ combo: `MAX(${c.name})`, fn: 'MAX', column: c.name, reason: 'numeric column' });
    }
  }
  // Always offer the universal COUNT(*) — works for any table
  if (cols.length > 0) {
    push({ combo: 'COUNT(*)', fn: 'COUNT', column: '*', reason: 'row count' });
  }
  return out;
}

interface AggregationBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  selectedColumns: any[];
  aggregations: any[];
  onUpdate: (aggs: any[]) => void;
  onClose: () => void;
  connectionId?: number | null;
}

const AggregationBuilderModal = ({ open, tables, schemas, selectedColumns, aggregations, onUpdate, onClose, connectionId }: AggregationBuilderModalProps) => {
  const [localAggs, setLocalAggs] = React.useState<any[]>([]);
  const [aggCorrections, setAggCorrections] = React.useState<Map<string, { fn: string; distinct?: boolean }>>(new Map());
  const [popularAggs, setPopularAggs] = React.useState<any[]>([]);
  const [dismissedAggs, setDismissedAggs] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    if (open) setLocalAggs(aggregations.length > 0 ? [...aggregations] : []);
  }, [open]); // eslint-disable-line

  React.useEffect(() => {
    if (!open) return;
    (api as any).getAggCorrections().then((res: any) => {
      const map = new Map<string, { fn: string; distinct?: boolean }>();
      const dismissed = new Set<string>();
      for (const c of (res?.corrections || [])) {
        const val = c.corrected_value;
        const key = (c.context_key || '').toLowerCase();
        if (val === '__dismissed__') {
          dismissed.add(key);
          continue;
        }
        if (val === 'COUNT_DISTINCT') {
          map.set(key, { fn: 'COUNT', distinct: true });
        } else {
          map.set(key, { fn: val });
        }
      }
      setAggCorrections(map);
      setDismissedAggs(dismissed);
    }).catch(() => { /* ignore — use pattern fallback */ });
  }, [open]);

  // Fetch popular aggregation combos for current tables
  React.useEffect(() => {
    if (!open || tables.length === 0) { setPopularAggs([]); return; }
    const tableName = tables[0]?.name || '';
    if (!tableName) return;
    (api as any).getPopularAggs(tableName, connectionId || undefined)
      .then((res: any) => {
        const all = res?.suggestions || [];
        // Filter out previously dismissed popular aggs
        setPopularAggs(all.filter((p: any) => !dismissedAggs.has((p.combo || '').toLowerCase())));
      })
      .catch(() => setPopularAggs([]));
  }, [open, tables, connectionId, dismissedAggs]);

  const allCols = React.useMemo(() => {
    const cols: { table: string; name: string; type: string }[] = [];
    tables.forEach(t => {
      (schemas[t.path] || []).forEach(c => {
        cols.push({ table: t.name, name: c.name, type: c.type || '' });
      });
    });
    return cols;
  }, [tables, schemas]);

  const numericCols = allCols.filter(c => isNumericCol(c.type));

  // Column-aware predictions — always populated, no backend dep.  Hide
  // ones that admin already dismissed via the popular-aggs ✕ flow.
  const predictedAggs: PredictedAgg[] = React.useMemo(() => {
    const preds = predictAggregations(allCols);
    return preds.filter(p => !dismissedAggs.has(p.combo.toLowerCase()));
  }, [allCols, dismissedAggs]);

  const addAgg = () => {
    // Try popular agg first, then fall back to first numeric column
    const existingCols = new Set(localAggs.map(a => `${a.function}(${a.column})`));
    const nextPopular = popularAggs.find((p: any) => !existingCols.has(p.combo));
    if (nextPopular) {
      const m = nextPopular.combo?.match(/^(\w+)\((.+)\)$/);
      if (m) {
        const fn = m[1], col = m[2];
        const colObj = allCols.find(c => c.name === col);
        if (colObj) {
          setLocalAggs(prev => [...prev, {
            column: col, function: fn, alias: '', distinct: false,
            _suggestedFn: fn, _suggestedDistinct: false, _source: nextPopular.source || 'popular',
          }]);
          return;
        }
      }
    }
    const first = numericCols[0] || allCols[0];
    if (!first) return;
    const suggestion = suggestAggFunction(first.name, first.type, aggCorrections, connectionId, first.table);
    setLocalAggs(prev => [...prev, {
      column: first.name,
      function: suggestion.fn,
      alias: '',
      distinct: suggestion.distinct || false,
      _suggestedFn: suggestion.fn,
      _suggestedDistinct: suggestion.distinct || false,
      _source: suggestion.source,
    }]);
  };

  const removeAgg = (idx: number) => setLocalAggs(prev => prev.filter((_, i) => i !== idx));
  const updateAgg = (idx: number, field: string, val: string | boolean) => {
    setLocalAggs(prev => prev.map((a, i) => {
      if (i !== idx) return a;
      const updated = { ...a, [field]: val };
      if (field === 'column') {
        const col = allCols.find(c => c.name === val);
        if (col) {
          const suggestion = suggestAggFunction(col.name, col.type, aggCorrections, connectionId, col.table);
          if (!isNumericCol(col.type) && suggestion.fn !== 'COUNT' && suggestion.fn !== 'MAX') {
            updated.function = 'COUNT';
            updated.distinct = false;
          } else {
            updated.function = suggestion.fn;
            updated.distinct = suggestion.distinct || false;
          }
          updated._suggestedFn = suggestion.fn;
          updated._suggestedDistinct = suggestion.distinct || false;
          updated._source = suggestion.source;
        }
      }
      if ((field === 'function' || field === 'distinct') && updated._suggestedFn) {
        const currentKey = updated.function + (updated.distinct ? '_DISTINCT' : '');
        const suggestedKey = updated._suggestedFn + (updated._suggestedDistinct ? '_DISTINCT' : '');
        if (currentKey !== suggestedKey) {
          const corrVal = updated.distinct && updated.function === 'COUNT'
            ? 'COUNT_DISTINCT' : updated.function;
          const colTable = allCols.find(c => c.name === updated.column)?.table || '';
          (api as any).saveSuggestionCorrection({
            correction_type: 'agg',
            context_key: `conn:${connectionId || 0}|${colTable}|${updated.column.toLowerCase()}`,
            corrected_value: corrVal,
            original_value: suggestedKey,
            context_extra: allCols.find(c => c.name === updated.column)?.type || '',
          }).catch(() => {});
        }
      }
      return updated;
    }));
  };

  const handleDone = () => { onUpdate(localAggs); onClose(); };
  const handleClear = () => { setLocalAggs([]); onUpdate([]); onClose(); };

  const aggColSet = new Set(localAggs.map(a => a.column));
  const groupByCols = selectedColumns.filter(c => !aggColSet.has(c.columnName));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <AggIcon color="secondary" />
          <span>Aggregation — GROUP BY</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        {selectedColumns.length === 0 && (
          <Alert severity="info" sx={{ mb: 2 }}>Select columns first (via the Columns button), then define aggregations here.</Alert>
        )}

        {/* Column-aware predicted aggregations — derived from column names
            + types so they always show, even on a cold cache with zero
            historical usage data.  Dismissed (✕) ones disappear like the
            popular-aggs flow does. */}
        {predictedAggs.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5, mb: 0.5, display: 'block' }}>
              Suggested aggregations ({predictedAggs.length})
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary', display: 'block', mb: 0.75 }}>
              Predicted from column names + types — click to add. Dismiss (✕) the ones you don't want.
            </Typography>
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
              {predictedAggs.map((p, i) => {
                const already = localAggs.some(a => `${a.function}(${a.column})` === p.combo);
                return (
                  <Tooltip key={i} title={p.reason}>
                    <Chip
                      size="small"
                      label={p.combo}
                      onClick={() => {
                        if (already) return;
                        setLocalAggs(prev => [...prev, {
                          column: p.column, function: p.fn, alias: '',
                          distinct: !!p.distinct,
                          _suggestedFn: p.fn,
                          _suggestedDistinct: !!p.distinct,
                          _source: 'predicted',
                        }]);
                      }}
                      onDelete={() => {
                        const dismissKey = p.combo.toLowerCase();
                        setDismissedAggs(prev => new Set([...prev, dismissKey]));
                        (api as any).saveSuggestionCorrection({
                          correction_type: 'agg', context_key: dismissKey,
                          corrected_value: '__dismissed__', original_value: p.combo,
                        }).catch(() => {});
                      }}
                      deleteIcon={<CloseIcon sx={{ fontSize: 12 }} />}
                      disabled={already}
                      sx={{
                        fontSize: 11, cursor: already ? 'default' : 'pointer',
                        bgcolor: '#f0fdf4',
                        color: '#15803d',
                        border: '1px solid #bbf7d0',
                        '&:hover': already ? {} : { bgcolor: '#dcfce7' },
                        '& .MuiChip-deleteIcon': { fontSize: 12, color: 'inherit', '&:hover': { color: '#ef4444' } },
                      }}
                    />
                  </Tooltip>
                );
              })}
            </Box>
          </Box>
        )}

        {popularAggs.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5, mb: 0.5, display: 'block' }}>
              Popular for these tables
            </Typography>
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
              {popularAggs.map((p: any, i: number) => {
                const already = localAggs.some(a => `${a.function}(${a.column})` === p.combo);
                return (
                  <Chip
                    key={i}
                    size="small"
                    label={`${p.combo}${p.use_count > 1 ? ` ×${p.use_count}` : ''}`}
                    onClick={() => {
                      if (already) return;
                      const m = p.combo?.match(/^(\w+)\((.+)\)$/);
                      if (!m) return;
                      setLocalAggs(prev => [...prev, {
                        column: m[2], function: m[1], alias: '', distinct: false,
                        _suggestedFn: m[1], _suggestedDistinct: false, _source: p.source || 'popular',
                      }]);
                    }}
                    onDelete={() => {
                      setPopularAggs(prev => prev.filter((_: any, j: number) => j !== i));
                      const dismissKey = (p.combo || '').toLowerCase();
                      setDismissedAggs(prev => new Set([...prev, dismissKey]));
                      (api as any).saveSuggestionCorrection({
                        correction_type: 'agg', context_key: dismissKey,
                        corrected_value: '__dismissed__', original_value: p.combo,
                      }).catch(() => {});
                    }}
                    deleteIcon={<CloseIcon sx={{ fontSize: 12 }} />}
                    disabled={already}
                    sx={{
                      fontSize: 11, cursor: already ? 'default' : 'pointer',
                      bgcolor: p.source === 'learned' ? '#dbeafe' : '#fef3c7',
                      color: p.source === 'learned' ? '#1d4ed8' : '#92400e',
                      border: `1px solid ${p.source === 'learned' ? '#bfdbfe' : '#fde68a'}`,
                      '&:hover': already ? {} : { bgcolor: p.source === 'learned' ? '#bfdbfe' : '#fde68a' },
                      '& .MuiChip-deleteIcon': { fontSize: 12, color: 'inherit', '&:hover': { color: '#ef4444' } },
                    }}
                  />
                );
              })}
            </Box>
          </Box>
        )}

        <Typography variant="subtitle2" sx={{ mb: 1 }}>Aggregations</Typography>
        <Stack spacing={1.5} sx={{ mb: 3 }}>
          {localAggs.length === 0 && (
            <Typography variant="body2" color="text.secondary">No aggregations defined — click "Add Aggregation" below.</Typography>
          )}
          {localAggs.map((agg, idx) => {
            const col = allCols.find(c => c.name === agg.column);
            const isNum = col ? isNumericCol(col.type) : false;
            const funcs = isNum ? AGG_FUNCS_NUMERIC : AGG_FUNCS_ANY;
            return (
              <Paper key={idx} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
                <TextField
                  select size="small" label="Function" value={agg.function}
                  onChange={e => updateAgg(idx, 'function', e.target.value)}
                  sx={{ minWidth: 100 }}>
                  {funcs.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
                </TextField>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>(</Typography>
                <Autocomplete
                  options={allCols}
                  getOptionLabel={c => c.name}
                  getOptionDisabled={c => !isNumericCol(c.type) && agg.function !== 'COUNT'}
                  value={allCols.find(c => c.name === agg.column) || null}
                  onChange={(_, val) => updateAgg(idx, 'column', val?.name || '')}
                  renderOption={(props, c) => (
                    <li {...props} key={`${c.table}.${c.name}`}>
                      <Typography variant="body2">{c.name}</Typography>
                      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>{c.type}</Typography>
                    </li>
                  )}
                  renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search..." />}
                  size="small"
                  sx={{ minWidth: 180 }}
                />
                <Typography variant="body2" sx={{ fontWeight: 600 }}>)</Typography>
                {agg.function === 'COUNT' && (
                  <FormControlLabel
                    control={<Checkbox checked={agg.distinct || false} size="small"
                      onChange={e => updateAgg(idx, 'distinct', e.target.checked)} />}
                    label={<Typography variant="caption">DISTINCT</Typography>}
                    sx={{ ml: 0, mr: 0 }}
                  />
                )}
                <Typography variant="body2" color="text.secondary">AS</Typography>
                <TextField
                  size="small" label="Alias" value={agg.alias}
                  placeholder={`${agg.function.toLowerCase()}_${agg.column}`}
                  onChange={e => updateAgg(idx, 'alias', e.target.value)}
                  sx={{ minWidth: 150 }}
                />
                {agg._source && (
                  <Chip
                    size="small"
                    label={agg._source === 'correction' ? 'learned' : agg._source === 'popular' ? 'popular' : agg._source === 'pattern' ? 'suggested' : 'default'}
                    onDelete={() => {
                      // Dismiss: remove source label (chip vanishes), save dismissal
                      setLocalAggs(prev => prev.map((a, j) => j === idx ? { ...a, _source: undefined, _suggestedFn: undefined } : a));
                      const dismissCombo = `${agg.function}(${agg.column})`.toLowerCase();
                      setDismissedAggs(prev => new Set([...prev, dismissCombo]));
                      (api as any).saveSuggestionCorrection({
                        correction_type: 'agg', context_key: dismissCombo,
                        corrected_value: '__dismissed__', original_value: `${agg.function}(${agg.column})`,
                      }).catch(() => {});
                    }}
                    deleteIcon={<CloseIcon sx={{ fontSize: 10 }} />}
                    sx={{
                      fontSize: 9, height: 18,
                      bgcolor: agg._source === 'correction' ? '#dbeafe' : agg._source === 'popular' ? '#fef3c7' : agg._source === 'pattern' ? '#f0fdf4' : '#f1f5f9',
                      color: agg._source === 'correction' ? '#1d4ed8' : agg._source === 'popular' ? '#92400e' : agg._source === 'pattern' ? '#15803d' : '#64748b',
                      border: `1px solid ${agg._source === 'correction' ? '#bfdbfe' : agg._source === 'popular' ? '#fde68a' : agg._source === 'pattern' ? '#bbf7d0' : '#e2e8f0'}`,
                      '& .MuiChip-deleteIcon': { fontSize: 10, color: 'inherit', '&:hover': { color: '#ef4444' } },
                    }}
                  />
                )}
                <IconButton size="small" color="error" onClick={() => removeAgg(idx)}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Paper>
            );
          })}
          <Button size="small" startIcon={<AddIcon />} onClick={addAgg} variant="outlined"
            disabled={allCols.length === 0}
            sx={{ alignSelf: 'flex-start' }}>
            Add Aggregation
          </Button>
        </Stack>

        {localAggs.length > 0 && (
          <>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle2" sx={{ mb: 1 }}>GROUP BY (auto-derived)</Typography>
            {groupByCols.length > 0 ? (
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                {groupByCols.map(c => (
                  <Chip key={c.columnName} label={c.columnName} size="small" variant="outlined" />
                ))}
              </Box>
            ) : (
              <Alert severity="warning" sx={{ py: 0 }}>
                No GROUP BY columns — the query will return a single aggregated row.
                Select non-aggregated columns to group by.
              </Alert>
            )}
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              All selected columns that are <strong>not</strong> being aggregated automatically become GROUP BY columns.
            </Typography>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClear} color="warning" disabled={localAggs.length === 0}>Clear All</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" color="secondary" onClick={handleDone}>
          Done ({localAggs.length} aggregation{localAggs.length !== 1 ? 's' : ''})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AggregationBuilderModal;
