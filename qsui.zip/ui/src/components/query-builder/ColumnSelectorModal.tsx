/**
 * CQB Column Selector Modal.
 * Phase 134 — Convergence: optional "Friendly Names" toggle groups columns by
 * category using the same auto-map API as the Business Query Builder.
 */
import React from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Checkbox, FormControlLabel, Stack, InputAdornment,
  Switch, Chip, Accordion, AccordionSummary, AccordionDetails, CircularProgress,
} from '@mui/material';
import {
  ViewColumn as ColumnIcon, Search as SearchIcon,
  ExpandMore as ExpandMoreIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import type { MappedColumn } from '../../services/api/businessQueryBuilder';

interface ColumnSelectorModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  selectedColumns: any[];
  onUpdate: (cols: any[]) => void;
  onClose: () => void;
  connectionId?: number | null;
}

const ColumnSelectorModal = ({ open, tables, schemas, selectedColumns, onUpdate, onClose, connectionId }: ColumnSelectorModalProps) => {
  const [colSearch, setColSearch] = React.useState('');
  const [friendlyMode, setFriendlyMode] = React.useState(false);
  const [mappedData, setMappedData] = React.useState<Record<string, MappedColumn[]>>({});
  const [loadingMap, setLoadingMap] = React.useState(false);

  // Fetch friendly names when toggled on
  const handleFriendlyToggle = React.useCallback(async (on: boolean) => {
    setFriendlyMode(on);
    if (!on || !connectionId || tables.length === 0) return;
    // Only fetch if not already cached
    const needPaths = tables.map(t => t.path).filter(p => !mappedData[p]);
    if (needPaths.length === 0) return;
    setLoadingMap(true);
    try {
      const res = await api.businessQueryBuilder.autoMapColumns({
        connection_id: connectionId,
        table_paths: needPaths,
      });
      const byTable: Record<string, MappedColumn[]> = {};
      res.columns.forEach(c => {
        const tbl = c.source_table || 'Unknown';
        if (!byTable[tbl]) byTable[tbl] = [];
        byTable[tbl].push(c);
      });
      setMappedData(prev => ({ ...prev, ...byTable }));
    } catch { /* silently fall back to physical names */ }
    finally { setLoadingMap(false); }
  }, [connectionId, tables, mappedData]);

  const toggleColumn = (table: any, column: any) => {
    const exists = selectedColumns.find(c => c.tableName === table.name && c.columnName === column.name);
    if (exists) {
      onUpdate(selectedColumns.filter(c => !(c.tableName === table.name && c.columnName === column.name)));
    } else {
      onUpdate([...selectedColumns, { tableName: table.name, columnName: column.name, type: column.type }]);
    }
  };

  const selectAll = (table: any) => {
    const cols = schemas[table.path] || [];
    const newCols = cols.map(c => ({ tableName: table.name, columnName: c.name, type: c.type }));
    onUpdate([...selectedColumns.filter(c => c.tableName !== table.name), ...newCols]);
  };

  const deselectAll = (table: any) => {
    onUpdate(selectedColumns.filter(c => c.tableName !== table.name));
  };

  // Group columns by category when in friendly mode
  const getCategoryGroups = (tablePath: string, tableName: string) => {
    const mapped = mappedData[tablePath];
    if (!mapped) return null;
    const groups: Record<string, MappedColumn[]> = {};
    mapped.forEach(c => {
      const cat = c.category || 'Other';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(c);
    });
    return groups;
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <ColumnIcon />
          <span>Select Columns</span>
          <Box sx={{ flexGrow: 1 }} />
          {connectionId && (
            <FormControlLabel
              control={
                <Switch size="small" checked={friendlyMode}
                  onChange={e => handleFriendlyToggle(e.target.checked)} />
              }
              label={<Typography variant="caption" sx={{ fontSize: '0.75rem', fontWeight: 500 }}>Friendly Names</Typography>}
              sx={{ mr: 0 }}
            />
          )}
          {loadingMap && <CircularProgress size={16} />}
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <TextField
          size="small" fullWidth placeholder="Search columns..."
          value={colSearch} onChange={e => setColSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ mb: 2 }}
        />
        <Stack spacing={2}>
          {tables.map(table => {
            const allCols = schemas[table.path] || [];
            const cols = colSearch ? allCols.filter(c => c.name.toLowerCase().includes(colSearch.toLowerCase())) : allCols;
            const catGroups = friendlyMode ? getCategoryGroups(table.path, table.name) : null;

            return (
              <Paper key={table.path} variant="outlined" sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {table.name}
                    <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      ({cols.length}{colSearch ? ` / ${allCols.length}` : ''} columns)
                    </Typography>
                  </Typography>
                  <Stack direction="row" spacing={1}>
                    <Button size="small" onClick={() => selectAll(table)}>Select All</Button>
                    <Button size="small" onClick={() => deselectAll(table)}>Clear</Button>
                  </Stack>
                </Box>

                {/* Category-grouped view (friendly mode) */}
                {friendlyMode && catGroups ? (
                  <Box>
                    {Object.entries(catGroups).map(([catName, catCols]) => {
                      const filteredCatCols = colSearch
                        ? catCols.filter(c =>
                            c.physical_name.toLowerCase().includes(colSearch.toLowerCase()) ||
                            c.friendly_name.toLowerCase().includes(colSearch.toLowerCase()))
                        : catCols;
                      if (filteredCatCols.length === 0) return null;
                      return (
                        <Accordion key={catName} defaultExpanded={false} disableGutters
                          sx={{ '&:before': { display: 'none' }, boxShadow: 'none' }}>
                          <AccordionSummary expandIcon={<ExpandMoreIcon sx={{ fontSize: 16 }} />}
                            sx={{ minHeight: 28, '& .MuiAccordionSummary-content': { m: 0, alignItems: 'center' } }}>
                            <Typography variant="caption" sx={{ fontWeight: 600, flexGrow: 1 }}>{catName}</Typography>
                            <Chip label={filteredCatCols.length} size="small" sx={{ height: 16, fontSize: '0.6rem' }} />
                          </AccordionSummary>
                          <AccordionDetails sx={{ p: 0, pl: 1 }}>
                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 0.25 }}>
                              {filteredCatCols.map(mc => {
                                const isSelected = selectedColumns.find(
                                  c => c.tableName === table.name && c.columnName === mc.physical_name
                                );
                                const rawCol = allCols.find(c => c.name === mc.physical_name);
                                return (
                                  <FormControlLabel
                                    key={mc.physical_name}
                                    control={<Checkbox checked={!!isSelected}
                                      onChange={() => rawCol && toggleColumn(table, rawCol)} size="small" />}
                                    label={
                                      <Box>
                                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                                          {mc.friendly_name}
                                        </Typography>
                                        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                                          {mc.physical_name} · {mc.data_type}
                                        </Typography>
                                      </Box>
                                    }
                                    sx={{ alignItems: 'flex-start', m: 0 }}
                                  />
                                );
                              })}
                            </Box>
                          </AccordionDetails>
                        </Accordion>
                      );
                    })}
                  </Box>
                ) : (
                  /* Default flat grid view */
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 0.5 }}>
                    {cols.map(col => {
                      const isSelected = selectedColumns.find(c => c.tableName === table.name && c.columnName === col.name);
                      const mapped = mappedData[table.path]?.find(mc => mc.physical_name === col.name);
                      const isPart = mapped?.is_partition;
                      return (
                        <FormControlLabel
                          key={col.name}
                          control={<Checkbox checked={!!isSelected} onChange={() => toggleColumn(table, col)} size="small" />}
                          label={
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <Typography variant="body2">
                                {isPart && '\u26A1 '}
                                {col.name}
                              </Typography>
                              <Typography variant="caption" color="text.secondary">({col.type})</Typography>
                            </Box>
                          }
                        />
                      );
                    })}
                  </Box>
                )}
              </Paper>
            );
          })}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button
          color="warning"
          onClick={() => onUpdate([])}
          disabled={selectedColumns.length === 0}
          sx={{ mr: 'auto' }}
        >
          Reset to SELECT *
        </Button>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedColumns.length || '*'})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ColumnSelectorModal;
