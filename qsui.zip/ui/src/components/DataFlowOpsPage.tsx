/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowOpsPage — Airflow / NiFi-style ops view (Phase 132.20).
 *
 * Three modes:
 *   1. Grid     — N most-recent runs × M stages.  Each cell coloured
 *                  by stage status.  This is Airflow's flagship UI:
 *                  one glance tells you which stage of which run
 *                  failed/SLA-breached.
 *   2. Gantt    — pick a run; show every stage as a horizontal bar
 *                  scaled by duration.  Reveals parallel sections +
 *                  long-pole stages.
 *   3. Estimate — pick an active DataFlow; show stage-by-stage cost
 *                  estimate (seconds + cents) before launching.
 *
 * Live-updated via the same workflow_run_started / workflow_stage_*
 * WebSocket events as the runs dashboard.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, MenuItem, Paper, Select,
  Stack, Tab, Tabs, TextField, Tooltip, Typography,
} from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';
import { useNavigate, useSearchParams } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import type { DataFlowDef, DataFlowRun, DataFlowRunStage } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';

const STATUS_BG: Record<string, string> = {
  succeeded:   '#2e7d32',
  running:     '#0288d1',
  failed:      '#c62828',
  cancelled:   '#ed6c02',
  partial:     '#ed6c02',
  pending:     '#9e9e9e',
  not_started: '#e0e0e0',
  skipped:     '#bdbdbd',
};

const fmtDur = (s?: number | null) => s == null ? '—' : `${s.toFixed(1)}s`;
const fmtDt = (iso?: string | null) => iso ? iso.slice(11, 19) : '—';

// ── Grid view ──────────────────────────────────────────────────────────────

function GridView({
  runs, onOpenRun,
}: { runs: DataFlowRun[]; onOpenRun: (id: number) => void }) {
  // Stages aren't returned by listRuns; we fetch them per-run on demand.
  // To keep this fast, we batch-fetch when runs change.
  const [runStages, setRunStages] = useState<Record<number, DataFlowRunStage[]>>({});
  useEffect(() => {
    const ids = runs.map(r => r.id).filter(id => runStages[id] === undefined);
    if (!ids.length) return;
    let cancelled = false;
    Promise.all(ids.map(id => api.dataflows.getRun(id).catch(() => null) as Promise<DataFlowRun | null>))
      .then(results => {
        if (cancelled) return;
        const next: Record<number, DataFlowRunStage[]> = { ...runStages };
        results.forEach((r, i) => {
          if (r && Array.isArray(r.stages)) next[ids[i]] = r.stages;
        });
        setRunStages(next);
      });
    return () => { cancelled = true; };
  }, [runs]); // eslint-disable-line react-hooks/exhaustive-deps

  // Build the union of stage aliases across all loaded runs, preserving
  // seq order from the most recent run that has them.
  const stageAliases = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const r of runs) {
      const stages = runStages[r.id] || [];
      for (const s of [...stages].sort((a, b) => a.seq - b.seq)) {
        if (!seen.has(s.stage_alias)) {
          seen.add(s.stage_alias); out.push(s.stage_alias);
        }
      }
    }
    return out;
  }, [runs, runStages]);

  if (!runs.length) {
    return <Alert severity="info">No runs to display.</Alert>;
  }

  return (
    <Box sx={{ overflowX: 'auto', mt: 1 }}>
      <table style={{ borderCollapse: 'collapse', fontSize: 11 }}>
        <thead>
          <tr>
            <th style={{ padding: '4px 8px', borderBottom: '1px solid #ddd',
                          position: 'sticky', left: 0, background: 'white' }}>
              Run
            </th>
            <th style={{ padding: '4px 8px', borderBottom: '1px solid #ddd' }}>DataFlow</th>
            <th style={{ padding: '4px 8px', borderBottom: '1px solid #ddd' }}>Status</th>
            {stageAliases.map(alias => (
              <th key={alias} style={{
                padding: '4px 6px', borderBottom: '1px solid #ddd',
                writingMode: 'vertical-rl', transform: 'rotate(180deg)',
                whiteSpace: 'nowrap', minWidth: 18, maxHeight: 120,
              }}>{alias}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {runs.map(r => {
            const byAlias: Record<string, DataFlowRunStage> = {};
            (runStages[r.id] || []).forEach(s => { byAlias[s.stage_alias] = s; });
            return (
              <tr key={r.id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                <td style={{ padding: '4px 8px', position: 'sticky', left: 0, background: 'white' }}>
                  <Button size="small" sx={{ textTransform: 'none', minWidth: 0, p: 0 }}
                          onClick={() => onOpenRun(r.id)}>#{r.id}</Button>
                </td>
                <td style={{ padding: '4px 8px', whiteSpace: 'nowrap' }}>{r.dataflow_name}</td>
                <td style={{ padding: '4px 8px' }}>
                  <Chip label={r.status} size="small"
                        sx={{ fontSize: 10, height: 18,
                              backgroundColor: STATUS_BG[r.status] || '#e0e0e0',
                              color: 'white' }} />
                  {r.sla_breached && (
                    <Chip label="SLA" size="small" color="error" sx={{ fontSize: 10, height: 18, ml: 0.5 }} />
                  )}
                </td>
                {stageAliases.map(alias => {
                  const s = byAlias[alias];
                  if (!s) {
                    return <td key={alias} style={{ minWidth: 18, background: '#fafafa' }} />;
                  }
                  return (
                    <td key={alias} style={{ minWidth: 18, padding: 2 }}>
                      <Tooltip title={`${alias} — ${s.status} (${fmtDur(s.duration_seconds)})`}>
                        <Box sx={{
                          width: 16, height: 16, borderRadius: '2px',
                          backgroundColor: STATUS_BG[s.status] || '#e0e0e0',
                          cursor: 'pointer',
                        }} onClick={() => onOpenRun(r.id)} />
                      </Tooltip>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </Box>
  );
}

// ── Gantt view ────────────────────────────────────────────────────────────

function GanttView({ run }: { run: DataFlowRun | null }) {
  if (!run) return <Alert severity="info">Pick a run from the dropdown.</Alert>;
  const stages: DataFlowRunStage[] = run.stages || [];
  if (!stages.length) return <Alert severity="info">Run has no stages.</Alert>;

  // Determine the timeline: min(started_at) → max(ended_at | now)
  const t0 = stages
    .map(s => s.started_at ? new Date(s.started_at).getTime() : null)
    .filter(Boolean)
    .reduce((m, t) => m == null ? t : Math.min(m, t!), null as number | null);
  if (t0 == null) return <Alert severity="info">No stage has started yet.</Alert>;
  const t1 = stages
    .map(s => s.ended_at ? new Date(s.ended_at).getTime()
               : s.started_at ? Date.now() : null)
    .filter(Boolean)
    .reduce((m, t) => m == null ? t : Math.max(m, t!), null as number | null) || t0 + 1000;
  const spanMs = Math.max(1, t1 - t0);

  return (
    <Box sx={{ mt: 1 }}>
      <Typography variant="caption" color="text.secondary">
        Run #{run.id} · {run.dataflow_name} · total {fmtDur(run.duration_seconds)} ·{' '}
        {fmtDt(run.started_at)} → {fmtDt(run.ended_at)}
        {run.sla_breached && <Chip label="SLA breached" size="small" color="error" sx={{ ml: 1 }} />}
      </Typography>
      <Box sx={{ mt: 1, border: '1px solid #eee', borderRadius: 1, p: 1, background: '#fafafa' }}>
        {stages
          .slice()
          .sort((a, b) => a.seq - b.seq)
          .map(s => {
            const start = s.started_at ? new Date(s.started_at).getTime() : null;
            const end   = s.ended_at   ? new Date(s.ended_at).getTime()
                          : start ? Date.now() : null;
            const left  = start != null ? ((start - t0) / spanMs) * 100 : 0;
            const width = (start != null && end != null)
              ? Math.max(0.5, ((end - start) / spanMs) * 100)
              : 0.5;
            return (
              <Box key={s.stage_alias} sx={{ display: 'flex', alignItems: 'center', my: 0.5 }}>
                <Box sx={{ width: 220, fontSize: 11, whiteSpace: 'nowrap',
                            overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  <Chip label={s.status} size="small"
                        sx={{ fontSize: 9, height: 16, mr: 0.5,
                              backgroundColor: STATUS_BG[s.status] || '#e0e0e0',
                              color: 'white' }} />
                  {s.seq}. {s.stage_alias}
                </Box>
                <Box sx={{ position: 'relative', flexGrow: 1, height: 16, background: '#fff' }}>
                  {start != null && (
                    <Tooltip title={`${s.stage_alias} — ${fmtDur(s.duration_seconds)} (${s.status})`}>
                      <Box sx={{
                        position: 'absolute',
                        left: `${left}%`, width: `${width}%`, height: 12, top: 2,
                        background: STATUS_BG[s.status] || '#bbb',
                        borderRadius: '2px',
                      }} />
                    </Tooltip>
                  )}
                </Box>
                <Box sx={{ width: 80, textAlign: 'right', fontSize: 11, color: 'text.secondary' }}>
                  {fmtDur(s.duration_seconds)}
                </Box>
              </Box>
            );
          })}
      </Box>
    </Box>
  );
}

// ── Estimate view ─────────────────────────────────────────────────────────

function EstimateView({ dataflows }: { dataflows: DataFlowDef[] }) {
  const [pickId, setPickId] = useState<number | ''>('');
  const [est, setEst] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  // Phase 132.28 — cost-predict with item-count / row-count input
  const [items, setItems] = useState<string>('');
  const [rows,  setRows]  = useState<string>('');
  const [usePredict, setUsePredict] = useState(false);

  const load = useCallback(async (id: number) => {
    setLoading(true); setErr(null);
    try {
      if (usePredict) {
        const qs: string[] = [];
        if (items.trim()) qs.push(`items=${Number(items)}`);
        if (rows.trim())  qs.push(`rows=${Number(rows)}`);
        const url = `/api/dataflows/${id}/cost-predict${qs.length ? '?' + qs.join('&') : ''}`;
        const r: any = await fetch(url).then(res => res.ok ? res.json() : Promise.reject(new Error(`HTTP ${res.status}`)));
        setEst(r);
      } else {
        const r = await api.dataflows.estimateDataFlow(id);
        setEst(r);
      }
    } catch (e: any) {
      setErr(e?.message || 'Estimate failed'); setEst(null);
    } finally { setLoading(false); }
  }, [usePredict, items, rows]);
  useEffect(() => { if (pickId) load(Number(pickId)); else setEst(null); }, [pickId, load]);

  return (
    <Box sx={{ mt: 1 }}>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }} flexWrap="wrap">
        <Select size="small" value={pickId} displayEmpty
                onChange={e => {
                  const v = e.target.value as unknown as string | number;
                  setPickId(v === '' || v == null ? '' : Number(v));
                }}
                sx={{ minWidth: 280 }}>
          <MenuItem value="">Pick an active DataFlow…</MenuItem>
          {dataflows.filter(d => d.status === 'active').map(d => (
            <MenuItem key={d.id} value={d.id}>{d.name} (v{d.version})</MenuItem>
          ))}
        </Select>
        <Button size="small" variant={usePredict ? 'contained' : 'outlined'}
                onClick={() => setUsePredict(p => !p)}>
          {usePredict ? 'Item-count prediction' : 'Static estimate'}
        </Button>
        {usePredict && (
          <>
            <TextField label="items" size="small" type="number" sx={{ width: 140 }}
                       value={items} onChange={e => setItems(e.target.value)}
                       helperText="for_each fan-out size" />
            <TextField label="rows" size="small" type="number" sx={{ width: 140 }}
                       value={rows} onChange={e => setRows(e.target.value)}
                       helperText="ETL row_count" />
          </>
        )}
        {loading && <CircularProgress size={18} />}
      </Stack>
      {err && <Alert severity="error" onClose={() => setErr(null)}>{err}</Alert>}
      {est && (
        <Paper sx={{ p: 2 }}>
          <Typography variant="subtitle1">
            {usePredict ? 'Predicted' : 'Estimated'} total: {est.total_seconds}s
            {est.total_cents > 0 && ` · ${(est.total_cents / 100).toFixed(2)} USD`}
            <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
              ({est.stage_count} stage{est.stage_count === 1 ? '' : 's'} ·{' '}
              {usePredict ? 'regression over last 50 runs' : 'static + observed median'})
            </Typography>
          </Typography>
          <table style={{ borderCollapse: 'collapse', fontSize: 12, marginTop: 12, width: '100%' }}>
            <thead>
              <tr>
                <th style={{ padding: '4px 8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Stage</th>
                <th style={{ padding: '4px 8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Type</th>
                <th style={{ padding: '4px 8px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Seconds</th>
                {usePredict ? (
                  <>
                    <th style={{ padding: '4px 8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Method</th>
                    <th style={{ padding: '4px 8px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>R²</th>
                    <th style={{ padding: '4px 8px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Obs</th>
                  </>
                ) : (
                  <th style={{ padding: '4px 8px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Cents</th>
                )}
              </tr>
            </thead>
            <tbody>
              {est.per_stage.map((s: any) => (
                <tr key={s.stage_alias}>
                  <td style={{ padding: '4px 8px' }}>{s.stage_alias}</td>
                  <td style={{ padding: '4px 8px', color: '#666' }}>{s.stage_type}</td>
                  <td style={{ padding: '4px 8px', textAlign: 'right' }}>{s.seconds}</td>
                  {usePredict ? (
                    <>
                      <td style={{ padding: '4px 8px' }}>
                        <Chip label={s.method} size="small"
                          color={s.method === 'regression' ? 'success' :
                                  s.method === 'median' ? 'info' : 'default'}
                          sx={{ fontSize: 9 }} />
                      </td>
                      <td style={{ padding: '4px 8px', textAlign: 'right', color: '#666' }}>
                        {s.r_squared != null ? s.r_squared.toFixed(2) : '—'}
                      </td>
                      <td style={{ padding: '4px 8px', textAlign: 'right', color: '#666' }}>
                        {s.observations ?? 0}
                      </td>
                    </>
                  ) : (
                    <td style={{ padding: '4px 8px', textAlign: 'right' }}>{s.cents}</td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </Paper>
      )}
    </Box>
  );
}

// ── Page shell ────────────────────────────────────────────────────────────

export default function DataFlowOpsPage() {
  const nav = useNavigate();
  const [search, setSearch] = useSearchParams();
  const ws = useWebSocket();
  const initialTab = Number(search.get('tab') || 0);
  const initialDfId = search.get('dataflow_id') || '';

  const [tab, setTab] = useState<number>(initialTab);
  const [dataflows, setDataflows] = useState<DataFlowDef[]>([]);
  const [runs, setRuns] = useState<DataFlowRun[]>([]);
  const [dfFilter, setDfFilter] = useState<string>(initialDfId);
  const [loading, setLoading] = useState(false);

  // For Gantt
  const [pickRunId, setPickRunId] = useState<number | ''>('');
  const [pickRun, setPickRun] = useState<DataFlowRun | null>(null);

  const loadDataflows = useCallback(async () => {
    try {
      const list = await api.dataflows.listDataFlows();
      setDataflows(toArray<DataFlowDef>(list));
    } catch { /* swallow */ }
  }, []);

  const loadRuns = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.dataflows.listRuns({
        ...(dfFilter ? { dataflow_id: Number(dfFilter) } : {}),
        limit: 30,
      });
      setRuns(toArray<DataFlowRun>(list));
    } finally { setLoading(false); }
  }, [dfFilter]);

  useEffect(() => { loadDataflows(); }, [loadDataflows]);
  useEffect(() => { loadRuns(); }, [loadRuns]);

  // Sync filters to URL so links are shareable
  useEffect(() => {
    const next = new URLSearchParams(search);
    next.set('tab', String(tab));
    if (dfFilter) next.set('dataflow_id', dfFilter); else next.delete('dataflow_id');
    setSearch(next, { replace: true });
  }, [tab, dfFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Live updates
  useEffect(() => {
    if (!ws?.addListener) return;
    const handler = (msg: any) => {
      if (!msg) return;
      if (msg.event === 'workflow_run_started' ||
          msg.event === 'workflow_run_completed' ||
          msg.event === 'workflow_stage_completed' ||
          msg.event === 'workflow_run_sla_breached') {
        loadRuns();
        if (pickRunId && (msg.run_id === pickRunId)) {
          api.dataflows.getRun(Number(pickRunId)).then(setPickRun).catch(() => {});
        }
      }
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, loadRuns, pickRunId]);

  // When Gantt run picker changes, fetch the detail
  useEffect(() => {
    if (!pickRunId) { setPickRun(null); return; }
    api.dataflows.getRun(Number(pickRunId)).then(setPickRun).catch(() => setPickRun(null));
  }, [pickRunId]);

  // When tab → Gantt, default pick to first run
  useEffect(() => {
    if (tab === 1 && !pickRunId && runs.length) {
      setPickRunId(runs[0].id);
    }
  }, [tab, runs, pickRunId]);

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h5">DataFlow Ops</Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Select size="small" value={dfFilter} displayEmpty
                  onChange={e => setDfFilter(e.target.value as string)}
                  sx={{ minWidth: 240 }}>
            <MenuItem value="">All DataFlows</MenuItem>
            {dataflows.map(d => (
              <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>
            ))}
          </Select>
          <Button startIcon={<RefreshIcon />} onClick={loadRuns} size="small">
            Refresh
          </Button>
          <Button size="small" variant="outlined"
                   onClick={() => nav('/dataflows/runs')}>All Runs (list)</Button>
        </Stack>
      </Stack>

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 1 }}>
        <Tab label="Grid (runs × stages)" />
        <Tab label="Gantt (one run)" />
        <Tab label="Estimate (pre-run cost)" />
      </Tabs>

      {loading && <CircularProgress size={20} />}
      {tab === 0 && (
        <GridView runs={runs} onOpenRun={id => nav(`/dataflows/runs/${id}`)} />
      )}
      {tab === 1 && (
        <Box>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
            <Select size="small" value={pickRunId} displayEmpty
                    onChange={e => {
                      const v = e.target.value as unknown as string | number;
                      setPickRunId(v === '' || v == null ? '' : Number(v));
                    }}
                    sx={{ minWidth: 260 }}>
              <MenuItem value="">Pick a run…</MenuItem>
              {runs.map(r => (
                <MenuItem key={r.id} value={r.id}>
                  #{r.id} · {r.dataflow_name} · {r.status}
                </MenuItem>
              ))}
            </Select>
            {pickRunId && (
              <Button size="small" onClick={() => nav(`/dataflows/runs/${pickRunId}`)}>
                Open run detail →
              </Button>
            )}
          </Stack>
          <GanttView run={pickRun} />
        </Box>
      )}
      {tab === 2 && (
        <EstimateView dataflows={dataflows} />
      )}
    </Box>
  );
}
