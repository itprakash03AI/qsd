import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, Button, CircularProgress, TextField } from '@mui/material';
import api from '../../services/api';

const DeliveryAdminSection: React.FC = () => {
  const [cfg, setCfg] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const data = await api.getDeliveryConfig();
        setCfg(data);
      } finally { setLoading(false); }
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = await api.setDeliveryConfig(cfg);
      setCfg(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally { setSaving(false); }
  };

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress /></Box>;

  const toggles = [
    { key: 'enabled', label: 'Delivery Enabled' },
  ];
  const numbers = [
    { key: 'max_subscriptions_per_user', label: 'Max Subscriptions per User' },
    { key: 'max_recipients_per_subscription', label: 'Max Recipients per Subscription' },
    { key: 'retry_max_attempts', label: 'Retry Max Attempts' },
    { key: 'retry_backoff_minutes', label: 'Retry Backoff (min)' },
    { key: 'delivery_history_retention_days', label: 'History Retention (days)' },
    { key: 'max_pdf_rows', label: 'Max PDF Rows' },
    { key: 'batch_size', label: 'Batch Size' },
    { key: 'check_interval_minutes', label: 'Check Interval (min)' },
  ];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>Delivery & Alerts Configuration</Typography>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {toggles.map(t => (
          <Paper key={t.key} variant="outlined" sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
            <input type="checkbox" checked={!!cfg[t.key]}
              onChange={e => setCfg((prev: any) => ({ ...prev, [t.key]: e.target.checked }))} />
            <Typography variant="body2">{t.label}</Typography>
          </Paper>
        ))}
      </Box>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {numbers.map(n => (
          <TextField key={n.key} label={n.label} type="number" size="small"
            value={cfg[n.key] ?? ''} fullWidth
            onChange={e => setCfg((prev: any) => ({ ...prev, [n.key]: parseInt(e.target.value) || 0 }))} />
        ))}
      </Box>

      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : saved ? 'Saved!' : 'Save Changes'}
        </Button>
      </Box>
    </Box>
  );
};

export default DeliveryAdminSection;
