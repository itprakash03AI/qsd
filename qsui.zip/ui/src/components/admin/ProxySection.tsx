/**
 * Proxy Admin Section (Phase 140-A / BF-258)
 *
 * Surfaces corporate-proxy configuration so admins can flip
 * `proxy.enabled` from the UI on the day a VPC endpoint to S3 goes live,
 * without SSH-ing to a backend pod or editing config.json by hand.
 *
 * Round-trips through the existing `/api/admin/app-config` endpoint
 * (the backend was extended in Phase 140-A to include the `proxy`
 * section in both GET and PUT).
 *
 * Proxy state is held in module-level singletons used by cached boto3
 * clients, so changes still need a backend restart — the UI shows a
 * banner explaining this.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, FormControlLabel, Grid,
  Paper, Stack, Switch, TextField, Tooltip, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import SaveIcon from '@mui/icons-material/Save';
import RouterIcon from '@mui/icons-material/Router';
import { safeFetch } from '../../services/api/core';

interface ProxyConfig {
  enabled:         boolean;
  url:             string;
  host:            string;
  port:            number;
  apply_to_boto3:  boolean;
  apply_to_duckdb: boolean;
  apply_to_httpx:  boolean;
  no_proxy:        string;
  system_account:  string;
}

const EMPTY: ProxyConfig = {
  enabled: false, url: '', host: '', port: 8080,
  apply_to_boto3: true, apply_to_duckdb: true, apply_to_httpx: true,
  no_proxy: '', system_account: '',
};

const ProxySection: React.FC = () => {
  const [draft, setDraft]     = useState<ProxyConfig>(EMPTY);
  const [saved, setSaved]     = useState<ProxyConfig>(EMPTY);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving]   = useState(false);
  const [err, setErr]         = useState<string | null>(null);
  const [msg, setMsg]         = useState<string | null>(null);
  const [restartPending, setRestartPending] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setErr(null);
    try {
      const resp: any = await safeFetch('/api/admin/app-config');
      const p: ProxyConfig = { ...EMPTY, ...(resp?.proxy || {}) };
      setDraft(p);
      setSaved(p);
    } catch (e: any) {
      setErr(e?.message || 'Failed to load proxy config');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = useCallback(async () => {
    setSaving(true); setErr(null); setMsg(null);
    try {
      const resp: any = await safeFetch('/api/admin/app-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxy: draft }),
      });
      setMsg(resp?.message || 'Saved');
      setSaved(draft);
      if (resp?.restart_required) setRestartPending(true);
    } catch (e: any) {
      setErr(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }, [draft]);

  const dirty = JSON.stringify(draft) !== JSON.stringify(saved);

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <RouterIcon color="primary" />
        <Typography variant="h6">Corporate Proxy</Typography>
        <Chip size="small" label="ADMIN" color="warning" />
        <Chip size="small" label="restart on save" variant="outlined" />
        <Box sx={{ flexGrow: 1 }} />
        <Button startIcon={<RefreshIcon />} size="small" onClick={load} disabled={loading}>
          Reload
        </Button>
      </Stack>

      <Alert severity="info" sx={{ mb: 2 }}>
        Use this panel to flip the corporate proxy on/off — for example, the day your
        network team provisions a VPC endpoint to S3 you can disable the proxy here
        instead of editing <code>config.json</code> directly. <strong>Changes take
        effect on the next backend restart</strong> because cached boto3 clients
        and DuckDB connections hold the proxy settings at construction time.
      </Alert>

      {err && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setErr(null)}>{err}</Alert>}
      {msg && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setMsg(null)}>{msg}</Alert>}
      {restartPending && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          <strong>Restart required:</strong> proxy settings were updated. Restart the
          backend pod (or trigger a Helm rollout) to apply the new configuration. New
          settings will not take effect until then.
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Paper variant="outlined" sx={{ p: 2.5 }}>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12 }}>
              <FormControlLabel
                control={
                  <Switch
                    checked={draft.enabled}
                    onChange={(_, v) => setDraft({ ...draft, enabled: v })}
                  />
                }
                label={
                  <span>
                    <strong>Enabled</strong> — master switch for corporate proxy injection
                  </span>
                }
              />
              <Typography variant="caption" color="text.secondary" display="block" sx={{ ml: 6 }}>
                When OFF, all S3 traffic flows direct (boto3 + DuckDB httpfs).
                Use this for VPC-endpoint deployments.
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                label="Proxy URL (full)"
                size="small"
                fullWidth
                value={draft.url}
                onChange={e => setDraft({ ...draft, url: e.target.value })}
                placeholder="http://proxy.corp.example:8080"
                helperText="Either set this OR Host+Port below"
              />
            </Grid>

            <Grid size={{ xs: 6, md: 4 }}>
              <TextField
                label="Host"
                size="small"
                fullWidth
                value={draft.host}
                onChange={e => setDraft({ ...draft, host: e.target.value })}
                placeholder="proxy.corp.example"
              />
            </Grid>
            <Grid size={{ xs: 6, md: 2 }}>
              <TextField
                label="Port"
                type="number"
                size="small"
                fullWidth
                value={draft.port}
                onChange={e => setDraft({ ...draft, port: Number(e.target.value) || 0 })}
              />
            </Grid>

            <Grid size={{ xs: 12 }}>
              <TextField
                label="No-proxy bypass list"
                size="small"
                fullWidth
                value={draft.no_proxy}
                onChange={e => setDraft({ ...draft, no_proxy: e.target.value })}
                placeholder="localhost,127.0.0.1,.internal.com"
                helperText="Comma-separated hostnames / suffixes that bypass the proxy (e.g. on-prem S3)"
              />
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ mt: 1, mb: 1 }}>
                Per-client toggles
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap">
                <FormControlLabel
                  control={
                    <Switch
                      checked={draft.apply_to_boto3}
                      onChange={(_, v) => setDraft({ ...draft, apply_to_boto3: v })}
                    />
                  }
                  label="boto3 (S3 metadata, manifests, presigned)"
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={draft.apply_to_duckdb}
                      onChange={(_, v) => setDraft({ ...draft, apply_to_duckdb: v })}
                    />
                  }
                  label="DuckDB httpfs (parquet reads)"
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={draft.apply_to_httpx}
                      onChange={(_, v) => setDraft({ ...draft, apply_to_httpx: v })}
                    />
                  }
                  label="httpx / requests (REST connectors)"
                />
              </Stack>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Tooltip title="Name of a System Account in the database with proxy credentials. Leave blank for unauthenticated proxies. Currently the System Account UI only supports aws_portal/snowflake_sso types — proxy entries must be inserted via SQL or future UI extension.">
                <TextField
                  label="System account (for authenticated proxy)"
                  size="small"
                  fullWidth
                  value={draft.system_account}
                  onChange={e => setDraft({ ...draft, system_account: e.target.value })}
                  placeholder="(blank for unauthenticated)"
                />
              </Tooltip>
            </Grid>
          </Grid>

          <Stack direction="row" spacing={1} sx={{ mt: 3 }}>
            <Button
              variant="contained"
              startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon />}
              onClick={save}
              disabled={!dirty || saving || loading}
            >
              {saving ? 'Saving…' : dirty ? 'Save changes' : 'No changes'}
            </Button>
            <Button
              size="small"
              onClick={() => setDraft(saved)}
              disabled={!dirty || saving}
            >
              Discard
            </Button>
          </Stack>
        </Paper>
      )}

      <Box sx={{ mt: 3 }}>
        <Typography variant="caption" color="text.secondary" component="div">
          Reference:
          {' '}<a href="/docs/vpc-endpoint-benefits.html" target="_blank" rel="noreferrer">VPC Endpoint Benefits</a>
          {' '}covers when to flip the master switch off and what changes in
          the network path.
        </Typography>
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 0.5 }}>
          Setup:
          {' '}<a href="/docs/vpc-endpoint-setup.html" target="_blank" rel="noreferrer">VPC Endpoint Setup Guide</a>
          {' '}walks through the config + verification steps, and documents
          the bundled <code>qs_vpc_check.py</code> diagnostic for in-pod
          PASS/FAIL connectivity reports.
        </Typography>
      </Box>
    </Box>
  );
};

export default ProxySection;
