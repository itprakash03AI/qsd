import React from 'react';
import { Paper, Typography } from '@mui/material';

interface StatCardProps {
  label: string;
  value: string | number;
  sub?: string;
  warn?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, sub = '', warn = false }) => (
  <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 120 }}>
    <Typography variant="caption" color="text.secondary">{label}</Typography>
    <Typography variant="h5" fontWeight={700}
      color={warn ? 'error.main' : 'text.primary'}>
      {value}
    </Typography>
    {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
  </Paper>
);

export default StatCard;
