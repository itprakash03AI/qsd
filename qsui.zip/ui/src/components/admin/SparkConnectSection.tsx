/**
 * Spark Connect Admin Section
 *
 * Surfaces Spark Connect server health, active sessions, circuit breaker
 * state, and configuration controls to administrators.
 *
 * Pattern: follows the existing admin section pattern (AgentsAdminSection,
 * S3PerformanceSection, etc.) — single expandable card, config form,
 * action buttons.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Divider,
  FormControlLabel,
  Grid,
  Paper,
  Stack,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import RefreshIcon from '@mui/icons-material/Refresh';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { safeFetch } from '../../services/api/core';

// ── Types ─────────────────────────────────────────────────────────────────────

interface SparkSession {
  username:     string;
  idle_seconds: number;
  created_at:   string;
}

interface RoutingRule {
  name?:                  string;
  match_table_name?:      string;
  match_table_pattern?:   string;
  match_sql_contains?:    string;
  match_sql_regex?:       string;
  min_files?:             number;
  max_files?:             number;
  min_rows?:              number;
  max_rows?:              number;
  engine:                 'spark' | 'duckdb' | 'auto';
  reason?:                string;
}

interface DryRunResult {
  sql_preview:        string;
  sql_hint:           string | null;
  tables_extracted:   string[];
  routing_rule_match: {
    engine:    string;
    source:    string;
    rule_name: string;
    reason:    string;
  };
  decision: {
    engine: string;
    reason: string;
  };
  safety_floors: {
    spark_connect_enabled:  boolean;
    row_threshold:          number;
    circuit_breaker_open:   boolean;
    cross_connection_input: boolean;
    file_count_input:       number;
    row_estimate_input:     number;
  };
  notes: string[];
}

interface SparkStatus {
  enabled:       boolean;
  server_url:    string;
  row_threshold: number;
  circuit_breaker: {
    state:               string;
    failure_threshold:   number;
    cooldown_seconds:    number;
  };
  sessions: {
    active_sessions: number;
    active_queries:  number;
    users:           SparkSession[];
  };
  config: {
    timeout_seconds:              number;
    max_result_rows:              number;
    session_idle_timeout_minutes: number;
    max_sessions_per_user:        number;
    max_concurrent_queries:       number;
  };
  routing_rules?: RoutingRule[];
}

interface ConfigDraft {
  server_url:                   string;
  row_threshold:                number;
  timeout_seconds:              number;
  max_result_rows:              number;
  session_idle_timeout_minutes: number;
  max_sessions_per_user:        number;
  max_concurrent_queries:       number;
}

// ── Component ─────────────────────────────────────────────────────────────────

export const SparkConnectSection: React.FC = () => {
  const [status, setStatus]         = useState<SparkStatus | null>(null);
  const [loading, setLoading]       = useState(false);
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const [error, setError]           = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [draft, setDraft]           = useState<ConfigDraft | null>(null);

  // Dry-run state — paste SQL + optional context, see routing decision.
  const [dryRunSql, setDryRunSql]               = useState<string>('');
  const [dryRunFileCount, setDryRunFileCount]   = useState<number>(0);
  const [dryRunRowEstimate, setDryRunRowEstimate] = useState<number>(0);
  const [dryRunResult, setDryRunResult]         = useState<DryRunResult | null>(null);
  const [dryRunLoading, setDryRunLoading]       = useState(false);
  const [dryRunError, setDryRunError]           = useState<string | null>(null);

  const loadStatus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await safeFetch('/api/admin/spark-connect/status') as SparkStatus;
      setStatus(data);
      if (!draft) {
        setDraft({
          server_url:                   data.server_url,
          row_threshold:                data.row_threshold,
          timeout_seconds:              data.config.timeout_seconds,
          max_result_rows:              data.config.max_result_rows,
          session_idle_timeout_minutes: data.config.session_idle_timeout_minutes,
          max_sessions_per_user:        data.config.max_sessions_per_user,
          max_concurrent_queries:       data.config.max_concurrent_queries,
        });
      }
    } catch (e: any) {
      setError(e?.detail || e?.message || 'Failed to load Spark Connect status');
    } finally {
      setLoading(false);
    }
  }, [draft]);

  useEffect(() => { loadStatus(); }, []);   // eslint-disable-line react-hooks/exhaustive-deps

  const handleToggleEnabled = async () => {
    if (!status) return;
    try {
      await safeFetch('/api/admin/spark-connect/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !status.enabled }),
      });
      loadStatus();
    } catch (e: any) {
      setError(e?.detail || 'Failed to toggle Spark Connect');
    }
  };

  const handleTestConnection = async () => {
    setTestLoading(true);
    setTestResult(null);
    setError(null);
    try {
      const result = await safeFetch('/api/admin/spark-connect/test', { method: 'POST' }) as any;
      setTestResult(`✅ Connected — ${result.latency_ms}ms`);
    } catch (e: any) {
      setTestResult(`❌ ${e?.detail || e?.message || 'Connection failed'}`);
    } finally {
      setTestLoading(false);
    }
  };

  const handleResetBreaker = async () => {
    try {
      await safeFetch('/api/admin/spark-connect/circuit-breaker/reset', { method: 'POST' });
      setSuccessMsg('Circuit breaker reset');
      loadStatus();
    } catch (e: any) {
      setError(e?.detail || 'Failed to reset circuit breaker');
    }
  };

  const handleSaveConfig = async () => {
    if (!draft) return;
    setSaveLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      await safeFetch('/api/admin/spark-connect/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(draft),
      });
      setSuccessMsg('Configuration saved');
      loadStatus();
    } catch (e: any) {
      setError(e?.detail || 'Failed to save configuration');
    } finally {
      setSaveLoading(false);
    }
  };

  const updateDraft = (key: keyof ConfigDraft, value: string | number) => {
    setDraft((prev) => prev ? { ...prev, [key]: value } : prev);
  };

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <Typography variant="h6" sx={{ fontWeight: 700 }}>Spark Connect</Typography>
        <Chip
          size="small"
          label={status?.enabled ? 'Enabled' : 'Disabled'}
          color={status?.enabled ? 'success' : 'default'}
        />
        <Box sx={{ flexGrow: 1 }} />
        <Button size="small" startIcon={<RefreshIcon />} onClick={loadStatus} disabled={loading}>
          Refresh
        </Button>
      </Box>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Zero-download distributed query engine for large S3 datasets (&gt;10M rows).
        Spark Connect reads S3 files directly — no files are pre-downloaded to the
        FastAPI pod.
      </Typography>

      {error   && <Alert severity="error"   sx={{ mb: 2 }}>{error}</Alert>}
      {successMsg && <Alert severity="success" sx={{ mb: 2 }}>{successMsg}</Alert>}

      {loading && !status && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {status && (
        <>
          {/* ── Status strip ── */}
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Grid container spacing={2} alignItems="center">
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">Server URL</Typography>
                <Typography variant="body2" sx={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
                  {status.server_url}
                </Typography>
              </Grid>
              <Grid size={{ xs: 6, sm: 2 }}>
                <Typography variant="caption" color="text.secondary">Active Sessions</Typography>
                <Typography variant="h6">{status.sessions.active_sessions}</Typography>
              </Grid>
              <Grid size={{ xs: 6, sm: 2 }}>
                <Typography variant="caption" color="text.secondary">Active Queries</Typography>
                <Typography variant="h6">{status.sessions.active_queries}</Typography>
              </Grid>
              <Grid size={{ xs: 6, sm: 2 }}>
                <Typography variant="caption" color="text.secondary">Row Threshold</Typography>
                <Typography variant="body2">
                  {(status.row_threshold / 1_000_000).toFixed(0)}M rows
                </Typography>
              </Grid>
              <Grid size={{ xs: 6, sm: 2 }} sx={{ textAlign: 'right' }}>
                <FormControlLabel
                  control={<Switch checked={status.enabled} onChange={handleToggleEnabled} />}
                  label={status.enabled ? 'On' : 'Off'}
                  labelPlacement="start"
                />
              </Grid>
            </Grid>
          </Paper>

          {/* ── Action buttons ── */}
          <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
            <Button
              variant="outlined"
              startIcon={testLoading ? <CircularProgress size={16} /> : <PlayArrowIcon />}
              onClick={handleTestConnection}
              disabled={testLoading || !status.enabled}
              size="small"
            >
              Test Connection
            </Button>
            <Button
              variant="outlined"
              color="warning"
              onClick={handleResetBreaker}
              size="small"
            >
              Reset Circuit Breaker
            </Button>
          </Box>
          {testResult && (
            <Alert
              severity={testResult.startsWith('✅') ? 'success' : 'error'}
              sx={{ mb: 2 }}
              onClose={() => setTestResult(null)}
            >
              {testResult}
            </Alert>
          )}

          <Divider sx={{ my: 2 }} />

          {/* ── Configuration form ── */}
          <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
            Configuration
          </Typography>
          {draft && (
            <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  label="Server URL"
                  value={draft.server_url}
                  onChange={(e) => updateDraft('server_url', e.target.value)}
                  fullWidth
                  size="small"
                  helperText="sc://host:port — must be reachable from the API pod"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Row Threshold"
                  type="number"
                  value={draft.row_threshold}
                  onChange={(e) => updateDraft('row_threshold', Number(e.target.value))}
                  fullWidth
                  size="small"
                  helperText="Rows ≥ this → Spark"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Max Result Rows"
                  type="number"
                  value={draft.max_result_rows}
                  onChange={(e) => updateDraft('max_result_rows', Number(e.target.value))}
                  fullWidth
                  size="small"
                  helperText="Truncate result at this"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Timeout (seconds)"
                  type="number"
                  value={draft.timeout_seconds}
                  onChange={(e) => updateDraft('timeout_seconds', Number(e.target.value))}
                  fullWidth
                  size="small"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Session Idle Timeout (min)"
                  type="number"
                  value={draft.session_idle_timeout_minutes}
                  onChange={(e) => updateDraft('session_idle_timeout_minutes', Number(e.target.value))}
                  fullWidth
                  size="small"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Max Sessions / User"
                  type="number"
                  value={draft.max_sessions_per_user}
                  onChange={(e) => updateDraft('max_sessions_per_user', Number(e.target.value))}
                  fullWidth
                  size="small"
                />
              </Grid>
              <Grid size={{ xs: 6, sm: 3 }}>
                <TextField
                  label="Max Concurrent Queries"
                  type="number"
                  value={draft.max_concurrent_queries}
                  onChange={(e) => updateDraft('max_concurrent_queries', Number(e.target.value))}
                  fullWidth
                  size="small"
                />
              </Grid>
            </Grid>
          )}
          <Button
            variant="contained"
            onClick={handleSaveConfig}
            disabled={saveLoading || !draft}
            size="small"
          >
            {saveLoading ? <CircularProgress size={16} /> : 'Save Configuration'}
          </Button>

          {/* ── Active sessions table ── */}
          {status.sessions.users.length > 0 && (
            <>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                Active Sessions
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>User</TableCell>
                    <TableCell>Idle</TableCell>
                    <TableCell>Created</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {status.sessions.users.map((s) => (
                    <TableRow key={s.username}>
                      <TableCell>{s.username}</TableCell>
                      <TableCell>{s.idle_seconds}s</TableCell>
                      <TableCell>{new Date(s.created_at).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </>
          )}

          {/* ── Routing Rules ── */}
          <Divider sx={{ my: 2 }} />
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, flex: 1 }}>
              Routing Rules ({(status.routing_rules ?? []).length})
            </Typography>
            <Chip label="Phase 151" size="small" color="info" />
          </Stack>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
            Override the row-threshold gate per-table or per-pattern.  Rules
            evaluated top-to-bottom; first match wins.  Hard safety floors
            (enabled, S3-only, cross-conn, circuit breaker) still apply.
            SQL hints (<code>/*+ spark */</code> or <code>-- @engine=spark</code>)
            override rules.  Edit via <code>PUT /api/admin/spark-connect/config</code>
            or directly in <code>config.json</code>.
          </Typography>
          {(status.routing_rules ?? []).length === 0
            ? <Alert severity="info" sx={{ mt: 1 }}>
                No routing rules configured.  Queries are routed purely by the
                row_threshold gate above.  Add rules to force Spark/DuckDB
                per-table.
              </Alert>
            : (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>#</TableCell>
                    <TableCell>Name</TableCell>
                    <TableCell>Match</TableCell>
                    <TableCell>Engine</TableCell>
                    <TableCell>Reason</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {(status.routing_rules ?? []).map((rule, idx) => {
                    const conditions: string[] = [];
                    if (rule.match_table_name)     conditions.push(`table='${rule.match_table_name}'`);
                    if (rule.match_table_pattern)  conditions.push(`pattern='${rule.match_table_pattern}'`);
                    if (rule.match_sql_contains)   conditions.push(`sql~'${rule.match_sql_contains}'`);
                    if (rule.match_sql_regex)      conditions.push(`regex='${rule.match_sql_regex}'`);
                    if (rule.min_files !== undefined) conditions.push(`files>=${rule.min_files}`);
                    if (rule.max_files !== undefined) conditions.push(`files<=${rule.max_files}`);
                    if (rule.min_rows !== undefined)  conditions.push(`rows>=${rule.min_rows}`);
                    if (rule.max_rows !== undefined)  conditions.push(`rows<=${rule.max_rows}`);
                    const color =
                      rule.engine === 'spark'  ? 'primary'  :
                      rule.engine === 'duckdb' ? 'warning' :
                      'default';
                    return (
                      <TableRow key={idx}>
                        <TableCell>{idx}</TableCell>
                        <TableCell>{rule.name || <em style={{ opacity: 0.6 }}>(unnamed)</em>}</TableCell>
                        <TableCell><code style={{ fontSize: '.85em' }}>{conditions.join(' AND ') || '*'}</code></TableCell>
                        <TableCell><Chip label={rule.engine} size="small" color={color} /></TableCell>
                        <TableCell>
                          <Typography variant="caption">{rule.reason || ''}</Typography>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}

          {/* ── Dry-run panel ── */}
          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
            Dry-run — test SQL against routing rules
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
            Paste a SQL string + optional file count + row estimate.  Returns
            the full decision tree — SQL hint detected, tables extracted,
            rule matched, final engine, all safety floor states.  Does NOT
            execute the SQL.
          </Typography>
          <TextField
            multiline minRows={3} maxRows={10} fullWidth size="small"
            placeholder="SELECT * FROM fact_table WHERE business_close_date = '2024-06-10'"
            value={dryRunSql}
            onChange={(e) => setDryRunSql(e.target.value)}
            sx={{ mb: 1 }}
          />
          <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
            <TextField
              label="File count (optional)" type="number" size="small"
              value={dryRunFileCount}
              onChange={(e) => setDryRunFileCount(Number(e.target.value) || 0)}
              sx={{ width: 180 }}
            />
            <TextField
              label="Row estimate (optional)" type="number" size="small"
              value={dryRunRowEstimate}
              onChange={(e) => setDryRunRowEstimate(Number(e.target.value) || 0)}
              sx={{ width: 200 }}
            />
            <Button
              variant="contained" size="small"
              onClick={async () => {
                if (!dryRunSql.trim()) { setDryRunError('SQL is required'); return; }
                setDryRunLoading(true);
                setDryRunResult(null);
                setDryRunError(null);
                try {
                  const r = await safeFetch('/api/admin/spark-connect/dry-run', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      sql: dryRunSql,
                      file_count: dryRunFileCount,
                      row_estimate: dryRunRowEstimate,
                    }),
                  }) as DryRunResult;
                  setDryRunResult(r);
                } catch (e: any) {
                  setDryRunError(e?.detail || e?.message || 'Dry-run failed');
                } finally {
                  setDryRunLoading(false);
                }
              }}
              disabled={dryRunLoading || !dryRunSql.trim()}
            >
              {dryRunLoading ? <CircularProgress size={16} /> : 'Evaluate'}
            </Button>
          </Stack>
          {dryRunError && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setDryRunError(null)}>{dryRunError}</Alert>}
          {dryRunResult && (
            <Box sx={{ mt: 1, p: 1.5, bgcolor: 'background.default', border: '1px solid #ddd', borderRadius: 1 }}>
              <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
                <Typography variant="subtitle2">Final decision:</Typography>
                <Chip
                  label={dryRunResult.decision.engine.toUpperCase()}
                  size="small"
                  color={dryRunResult.decision.engine === 'spark' ? 'primary' : 'warning'}
                />
                <Typography variant="caption" color="text.secondary">
                  {dryRunResult.decision.reason}
                </Typography>
              </Stack>
              <Divider sx={{ my: 1 }} />
              <Typography variant="caption" component="div">
                <strong>Tables:</strong> {dryRunResult.tables_extracted.join(', ') || '(none detected)'}
              </Typography>
              <Typography variant="caption" component="div">
                <strong>SQL hint:</strong> {dryRunResult.sql_hint
                  ? <Chip label={dryRunResult.sql_hint} size="small" color="info" />
                  : '(none)'}
              </Typography>
              <Typography variant="caption" component="div" sx={{ mt: 0.5 }}>
                <strong>Routing rule:</strong>{' '}
                {dryRunResult.routing_rule_match.engine === 'auto'
                  ? '(no rule matched — fall-through)'
                  : <>
                      <Chip
                        label={`${dryRunResult.routing_rule_match.engine} via ${dryRunResult.routing_rule_match.source}`}
                        size="small"
                      />{' '}
                      {dryRunResult.routing_rule_match.rule_name} —{' '}
                      <em>{dryRunResult.routing_rule_match.reason}</em>
                    </>}
              </Typography>
              <Divider sx={{ my: 1 }} />
              <Typography variant="caption" component="div">
                <strong>Safety floors:</strong>{' '}
                enabled={String(dryRunResult.safety_floors.spark_connect_enabled)},{' '}
                row_threshold={dryRunResult.safety_floors.row_threshold},{' '}
                circuit_breaker_open={String(dryRunResult.safety_floors.circuit_breaker_open)}
              </Typography>
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

export default SparkConnectSection;
