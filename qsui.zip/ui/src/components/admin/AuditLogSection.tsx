/**
 * Audit Log section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Shows filterable, paginated audit log table.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, TextField, InputAdornment,
  LinearProgress, Stack, IconButton, Chip,
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import { fmtDate, AUDIT_PER_PAGE } from './adminUtils';

interface AuditEntry {
  timestamp: string;
  username: string;
  action: string;
  resource_type?: string;
  resource_id?: string | number;
  ip_address?: string;
}

const AuditLogSection: React.FC = () => {
  const [auditSearch, setAuditSearch] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [auditPage, setAuditPage] = useState(0);
  const [auditTotal, setAuditTotal] = useState(0);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAudit = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        limit: String(AUDIT_PER_PAGE),
        offset: String(auditPage * AUDIT_PER_PAGE),
        ...(auditSearch ? { username: auditSearch } : {}),
        ...(auditAction ? { action: auditAction } : {}),
      });
      const data: any = await safeFetch(`/api/admin/audit-log?${qs}`);
      // BF-430E — toArray handles both bare array + {items: [...]} wrapper.
      const rows = toArray<AuditEntry>(data);
      setAuditLog(rows);
      setAuditTotal((data && typeof data === 'object' && data.total) || rows.length);
    } catch { setAuditLog([]); }
    finally { setLoading(false); }
  }, [auditPage, auditSearch, auditAction]);

  useEffect(() => { loadAudit(); }, [loadAudit]);

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Stack direction="row" spacing={1.5} mb={2}>
        <TextField
          size="small" placeholder="Filter by user"
          value={auditSearch}
          onChange={e => { setAuditSearch(e.target.value); setAuditPage(0); }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
            endAdornment: auditSearch
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setAuditSearch('')}>
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              : null,
          }}
          sx={{ width: 200 }}
        />
        <TextField
          size="small" placeholder="Filter by action"
          value={auditAction}
          onChange={e => { setAuditAction(e.target.value); setAuditPage(0); }}
          InputProps={{
            endAdornment: auditAction
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setAuditAction('')}>
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              : null,
          }}
          sx={{ width: 200 }}
        />
      </Stack>

      {loading && <LinearProgress sx={{ mb: 1 }} />}
      <TableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              {['Timestamp', 'User', 'Action', 'Resource', 'IP'].map(h => (
                <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {auditLog.length === 0 && !loading ? (
              <TableRow>
                <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  No audit entries found
                </TableCell>
              </TableRow>
            ) : auditLog.map((row, i) => (
              <TableRow key={i} hover>
                <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                  {fmtDate(row.timestamp)}
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem' }}>{row.username || '\u2014'}</TableCell>
                <TableCell>
                  <Chip size="small" label={row.action} variant="outlined"
                    sx={{ fontSize: '0.7rem', height: 20 }} />
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                  {row.resource_type
                    ? `${row.resource_type}${row.resource_id ? ` #${String(row.resource_id).substring(0, 8)}` : ''}`
                    : '\u2014'}
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                  {row.ip_address || '\u2014'}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={auditTotal > 0 ? auditTotal : auditLog.length}
        page={auditPage}
        rowsPerPage={AUDIT_PER_PAGE}
        rowsPerPageOptions={[AUDIT_PER_PAGE]}
        onPageChange={(_, p) => setAuditPage(p)}
      />
    </Paper>
  );
};

export default AuditLogSection;
