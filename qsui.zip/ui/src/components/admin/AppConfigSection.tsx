/**
 * App Configuration section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Covers: Streaming & Query Limits, Feature Toggles, S3 Result Storage.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, MenuItem, Button, CircularProgress,
  LinearProgress,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface AppCfgDraft {
  limits: Record<string, any>;
  features: Record<string, any>;
  s3_results: Record<string, any>;
}

const LIMITS_FIELDS: { key: string; label: string; desc: string; type: 'number' | 'bool' }[] = [
  { key: 'max_stream_files', label: 'Max Stream Files', desc: 'Max S3 parquet files per streaming query', type: 'number' },
  { key: 'stream_query_limit_max', label: 'Stream Row Limit (Max)', desc: 'Maximum rows for streaming queries', type: 'number' },
  { key: 'stream_page_size_max', label: 'Stream Page Size (Max)', desc: 'Maximum page size for stream pagination', type: 'number' },
  { key: 'stream_chart_top_n', label: 'Stream Chart Top N', desc: 'Max rows for streaming chart aggregation', type: 'number' },
  { key: 'stream_chart_max_series', label: 'Stream Chart Max Series', desc: 'Max series in multi-series charts', type: 'number' },
  { key: 'max_upload_size_mb', label: 'Max Upload Size (MB)', desc: 'Maximum file upload size in MB', type: 'number' },
  { key: 'max_display_cols', label: 'Grid Default Columns', desc: 'Default visible columns in data grid (user can add/remove anytime)', type: 'number' },
  { key: 'col_auto_project', label: 'Column Auto-Project', desc: 'Query builder auto-select threshold for wide tables', type: 'number' },
  { key: 'default_query_limit', label: 'Default Query Limit', desc: 'Default row limit for queries', type: 'number' },
  { key: 'duckdb_threads_per_query', label: 'DuckDB Threads/Query', desc: 'Max CPU threads per DuckDB query (0 = auto from CPU/concurrency)', type: 'number' },
  { key: 'duckdb_memory_limit_mb', label: 'DuckDB Memory/Query (MB)', desc: 'Per-query DuckDB memory cap in MB (0 = unlimited)', type: 'number' },
  { key: 'query_timeout_seconds', label: 'Query Timeout (sec)', desc: 'Max query execution time in seconds (0 = no limit)', type: 'number' },
  { key: 'max_concurrent_per_user', label: 'Max Queries/User', desc: 'Max concurrent queries per user', type: 'number' },
  { key: 'max_concurrent_global', label: 'Max Queries Global', desc: 'System-wide max concurrent queries', type: 'number' },
  { key: 'streaming_default_on', label: 'Streaming Default On', desc: 'Enable streaming toggle by default', type: 'bool' },
  { key: 'stream_bg_download_default', label: 'Background Download Default', desc: 'Enable background download by default', type: 'bool' },
];

const FEATURE_ROLE_FIELDS: { key: string; label: string; desc: string }[] = [
  { key: 'streaming_enabled_roles', label: 'Streaming Enabled', desc: 'Roles that can use S3 streaming' },
  { key: 'export_enabled_roles', label: 'Export Enabled', desc: 'Roles that can export data' },
  { key: 'sql_editor_enabled_roles', label: 'SQL Editor Enabled', desc: 'Roles that can use raw SQL editor' },
  { key: 'scheduler_enabled_roles', label: 'Scheduler Enabled', desc: 'Roles that can create schedules' },
  { key: 'connections_enabled_roles', label: 'Connections Enabled', desc: 'Roles that can manage connections' },
  { key: 'upload_enabled_roles', label: 'Upload Enabled', desc: 'Roles that can upload files' },
];

const S3_TEXT_FIELDS: { key: string; label: string; desc: string; type: 'number' | 'text' }[] = [
  { key: 'size_threshold_mb', label: 'Size Threshold (MB)', desc: 'Files larger than this are uploaded to S3 (auto mode)', type: 'number' },
  { key: 'prefix', label: 'S3 Key Prefix', desc: 'S3 key prefix for result files', type: 'text' },
  { key: 'bucket_override', label: 'Bucket Override', desc: 'Use a different bucket for results (empty = default S3 bucket)', type: 'text' },
];

const TH = { fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 } as const;
const TD_LABEL = { py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' } as const;
const TD_DESC = { py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' } as const;

const AppConfigSection: React.FC<Props> = ({ addNotification }) => {
  const [appCfg, setAppCfg] = useState<Record<string, any> | null>(null);
  const [appCfgDraft, setAppCfgDraft] = useState<AppCfgDraft>({ limits: {}, features: {}, s3_results: {} });
  const [appCfgLoading, setAppCfgLoading] = useState(false);
  const [appCfgSaving, setAppCfgSaving] = useState(false);

  const updateAppCfgDraft = (section: 'limits' | 'features' | 's3_results', key: string, value: any) => {
    setAppCfgDraft(prev => ({
      ...prev,
      [section]: { ...prev[section], [key]: value },
    }));
  };

  const loadAppConfig = useCallback(async () => {
    setAppCfgLoading(true);
    try {
      const data = await safeFetch('/api/admin/app-config');
      setAppCfg(data);
      setAppCfgDraft({
        limits: { ...data.limits },
        features: { ...data.features },
        s3_results: { ...(data.s3_results || {}) },
      });
    } catch (err: any) {
      // BF-263: previously silent — UI rendered empty form, admin could
      // accidentally save blank values.  Surface the failure.
      addNotification({
        type: 'error',
        title: 'Failed to Load Config',
        message: err?.message || 'Could not fetch application configuration',
      });
    }
    finally { setAppCfgLoading(false); }
  }, [addNotification]);

  useEffect(() => { loadAppConfig(); }, [loadAppConfig]);

  const handleAppCfgSave = async () => {
    setAppCfgSaving(true);
    try {
      const changedLimits: Record<string, any> = {};
      const changedFeatures: Record<string, any> = {};
      const changedS3Results: Record<string, any> = {};
      if (appCfg) {
        for (const [k, v] of Object.entries(appCfgDraft.limits || {})) {
          if (v !== appCfg.limits?.[k]) changedLimits[k] = typeof appCfg.limits?.[k] === 'number' ? Number(v) : v;
        }
        for (const [k, v] of Object.entries(appCfgDraft.features || {})) {
          if (v !== appCfg.features?.[k]) changedFeatures[k] = v;
        }
        for (const [k, v] of Object.entries(appCfgDraft.s3_results || {})) {
          if (v !== appCfg.s3_results?.[k]) changedS3Results[k] = typeof appCfg.s3_results?.[k] === 'number' ? Number(v) : v;
        }
      }
      const payload: Record<string, any> = {};
      if (Object.keys(changedLimits).length > 0) payload.limits = changedLimits;
      if (Object.keys(changedFeatures).length > 0) payload.features = changedFeatures;
      if (Object.keys(changedS3Results).length > 0) payload.s3_results = changedS3Results;
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'No configuration values were changed' });
        setAppCfgSaving(false);
        return;
      }
      await safeFetch('/api/admin/app-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      addNotification({ type: 'success', title: 'Config Saved', message: 'Application configuration updated. Changes apply immediately.' });
      await loadAppConfig();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save Failed', message: e.message });
    } finally { setAppCfgSaving(false); }
  };

  const renderConfigHeader = () => (
    <TableHead>
      <TableRow>
        <TableCell sx={TH}>Setting</TableCell>
        <TableCell sx={TH}>Value</TableCell>
        <TableCell sx={TH}>Description</TableCell>
      </TableRow>
    </TableHead>
  );

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {appCfgLoading && <LinearProgress sx={{ mb: 1 }} />}
      {appCfg && !appCfgLoading && (
        <Box>
          {/* Streaming & Query Limits */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" gutterBottom>
            Streaming & Query Limits
          </Typography>
          <TableContainer>
            <Table size="small">
              {renderConfigHeader()}
              <TableBody>
                {LIMITS_FIELDS.map(({ key, label, desc, type }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={TD_LABEL}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      {type === 'bool' ? (
                        <TextField
                          size="small" select variant="outlined"
                          value={appCfgDraft.limits?.[key] ?? false}
                          onChange={e => updateAppCfgDraft('limits', key, e.target.value === 'true')}
                          inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                          sx={{ minWidth: 80 }}
                        >
                          <MenuItem value="true">Yes</MenuItem>
                          <MenuItem value="false">No</MenuItem>
                        </TextField>
                      ) : (
                        <TextField
                          size="small" type="number" variant="outlined"
                          value={appCfgDraft.limits?.[key] ?? ''}
                          onChange={e => updateAppCfgDraft('limits', key, e.target.value)}
                          inputProps={{ min: 1, style: { fontSize: 12, padding: '4px 8px', width: 80 } }}
                        />
                      )}
                    </TableCell>
                    <TableCell sx={TD_DESC}>{desc}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Feature Toggles & Role Access */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" sx={{ mt: 3 }} gutterBottom>
            Feature Toggles & Role Access
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={TH}>Feature</TableCell>
                  <TableCell sx={TH}>Value</TableCell>
                  <TableCell sx={TH}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Streaming Mode</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={appCfgDraft.features?.streaming_mode || 'all'}
                      onChange={e => updateAppCfgDraft('features', 'streaming_mode', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 140 }}
                    >
                      <MenuItem value="all">All (Stream + Download)</MenuItem>
                      <MenuItem value="stream_only">Stream Only</MenuItem>
                      <MenuItem value="download_only">Download Only</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>Controls available data access modes</TableCell>
                </TableRow>
                {FEATURE_ROLE_FIELDS.map(({ key, label, desc }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={TD_LABEL}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" variant="outlined"
                        value={appCfgDraft.features?.[key] ?? ''}
                        onChange={e => updateAppCfgDraft('features', key, e.target.value)}
                        placeholder="admin,analyst,viewer"
                        inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 160 } }}
                      />
                    </TableCell>
                    <TableCell sx={TD_DESC}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Max Query Limit by Role</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" variant="outlined"
                      value={appCfgDraft.features?.max_query_limit_by_role ?? ''}
                      onChange={e => updateAppCfgDraft('features', 'max_query_limit_by_role', e.target.value)}
                      placeholder="viewer:1000,analyst:10000"
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 200 } }}
                    />
                  </TableCell>
                  <TableCell sx={TD_DESC}>Per-role row limits (0 = unlimited)</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          {/* S3 Result Storage */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" sx={{ mt: 3 }} gutterBottom>
            S3 Result Storage
          </Typography>
          <TableContainer>
            <Table size="small">
              {renderConfigHeader()}
              <TableBody>
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Enabled</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={String(appCfgDraft.s3_results?.enabled ?? false)}
                      onChange={e => updateAppCfgDraft('s3_results', 'enabled', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 80 }}>
                      <MenuItem value="true">Yes</MenuItem>
                      <MenuItem value="false">No</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>Enable S3 result storage (requires S3 connection)</TableCell>
                </TableRow>
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Storage Mode</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={appCfgDraft.s3_results?.storage_mode || 'local'}
                      onChange={e => updateAppCfgDraft('s3_results', 'storage_mode', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 120 }}>
                      <MenuItem value="local">Local Only</MenuItem>
                      <MenuItem value="auto">Auto (S3 above threshold)</MenuItem>
                      <MenuItem value="s3">Always S3</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>Where to store query results: local disk, S3 above size threshold, or always S3</TableCell>
                </TableRow>
                {S3_TEXT_FIELDS.map(({ key, label, desc, type }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={TD_LABEL}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField size="small" type={type} variant="outlined"
                        value={appCfgDraft.s3_results?.[key] ?? ''}
                        onChange={e => updateAppCfgDraft('s3_results', key, type === 'number' ? Number(e.target.value) : e.target.value)}
                        inputProps={{ ...(type === 'number' ? { min: 1 } : {}), style: { fontSize: 12, padding: '4px 8px', width: type === 'number' ? 80 : 160 } }}
                      />
                    </TableCell>
                    <TableCell sx={TD_DESC}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Delete Local After Upload</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={String(appCfgDraft.s3_results?.delete_local_after_upload ?? false)}
                      onChange={e => updateAppCfgDraft('s3_results', 'delete_local_after_upload', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 80 }}>
                      <MenuItem value="true">Yes</MenuItem>
                      <MenuItem value="false">No</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>Remove local parquet file after S3 upload to save disk space</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 2 }}>
            <Button size="small" variant="text" onClick={loadAppConfig} disabled={appCfgSaving}>
              Reset
            </Button>
            <Button size="small" variant="contained"
              startIcon={appCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
              onClick={handleAppCfgSave} disabled={appCfgSaving}>
              Save Configuration
            </Button>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Changes apply immediately without server restart. Persisted to config.json.
          </Typography>
        </Box>
      )}
      {!appCfg && !appCfgLoading && (
        <Typography variant="body2" color="text.secondary">Failed to load configuration.</Typography>
      )}
    </Paper>
  );
};

export default AppConfigSection;
