/**
 * Storage section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Shows directory sizes, disk usage progress bar, settings summary, and cleanup action.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, CircularProgress,
  LinearProgress, Stack, Divider,
} from '@mui/material';
import {
  CleaningServices as CleanupIcon,
  FolderOpen as FolderIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { fmtSize, fmtMb } from './adminUtils';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const StorageSection: React.FC<Props> = ({ addNotification }) => {
  const [loading, setLoading] = useState(true);
  const [storage, setStorage] = useState<any>(null);
  const [cleanupBusy, setCleanupBusy] = useState(false);

  const loadStorage = useCallback(async () => {
    setLoading(true);
    try {
      const data = await safeFetch('/api/admin/storage');
      setStorage(data);
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadStorage(); }, [loadStorage]);

  const handleCleanup = async () => {
    setCleanupBusy(true);
    try {
      await safeFetch('/api/admin/storage/cleanup', { method: 'POST' });
      addNotification({ type: 'success', title: 'Cleanup Complete', message: 'Stale files removed' });
      loadStorage();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cleanup Failed', message: e.message });
    } finally { setCleanupBusy(false); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button size="small"
          startIcon={cleanupBusy ? <CircularProgress size={14} /> : <CleanupIcon />}
          variant="outlined" color="warning" onClick={handleCleanup} disabled={cleanupBusy}>
          Clean Up Now
        </Button>
      </Box>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {storage && (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            {Object.entries(storage.directories || {}).map(([name, info]: [string, any]) => (
              <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <FolderIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                <Box>
                  <Typography variant="caption" color="text.secondary"
                    sx={{ textTransform: 'capitalize', display: 'block' }}>{name}</Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {fmtSize(info.size_bytes)}
                    <Typography component="span" variant="caption"
                      color="text.secondary" sx={{ ml: 0.5 }}>
                      {info.file_count} files
                    </Typography>
                  </Typography>
                </Box>
              </Box>
            ))}
          </Stack>
          {storage.disk && (
            <Box sx={{ mb: 1.5 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" color="text.secondary">Disk usage</Typography>
                <Typography variant="caption" color="text.secondary">
                  {fmtSize(storage.disk.used_gb * 1024 ** 3)} / {fmtSize(storage.disk.total_gb * 1024 ** 3)}
                </Typography>
              </Box>
              <LinearProgress variant="determinate" value={storage.disk.used_pct}
                color={storage.disk.used_pct > 85 ? 'error' : storage.disk.used_pct > 70 ? 'warning' : 'primary'}
                sx={{ height: 8, borderRadius: 4 }} />
            </Box>
          )}
          <Divider sx={{ my: 1.5 }} />
          <Typography variant="caption" color="text.secondary">
            Downloads expire after <strong>{storage.settings?.downloads_expiry_days}d</strong> {'\u00b7'}
            Execution history kept <strong>{storage.settings?.execution_retention_days}d</strong> {'\u00b7'}
            Cache limit <strong>{fmtMb(storage.settings?.max_cache_size_mb)}</strong> {'\u00b7'}
            Downloads limit <strong>{fmtMb(storage.settings?.max_downloads_size_mb)}</strong>
          </Typography>
        </>
      )}
    </Paper>
  );
};

export default StorageSection;
