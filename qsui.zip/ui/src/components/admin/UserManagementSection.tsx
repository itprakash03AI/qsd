/**
 * User Management section — extracted from AdminPage.
 * Self-contained: manages own state, data fetching, and Add/Edit user dialog.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Button, CircularProgress, LinearProgress,
  Avatar, Chip, IconButton, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Alert,
  useTheme,
} from '@mui/material';
import {
  Settings as SettingsIcon,
  Cancel as CancelIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface UserDlgState {
  open: boolean;
  mode: 'add' | 'edit';
  username: string;
  password: string;
  role: string;
}

interface AdLookupResult {
  display_name: string;
  email?: string;
  groups?: string[];
}

const UserManagementSection: React.FC<Props> = ({ addNotification }) => {
  const theme = useTheme();
  const [userMgmtLoading, setUserMgmtLoading] = useState(true);
  const [userList, setUserList] = useState<any[]>([]);
  const [userDlg, setUserDlg] = useState<UserDlgState>({ open: false, mode: 'add', username: '', password: '', role: 'analyst' });
  const [authType, setAuthType] = useState<string>('none');
  const [adLookup, setAdLookup] = useState<AdLookupResult | null>(null);
  const [adLookupLoading, setAdLookupLoading] = useState(false);
  const [adLookupError, setAdLookupError] = useState('');

  const isAdMode = authType === 'ad';

  const loadUsers = useCallback(async () => {
    setUserMgmtLoading(true);
    try {
      const data = await safeFetch('/api/admin/users');
      setUserList(toArray(data));  // BF-430E
    } catch { setUserList([]); }
    finally { setUserMgmtLoading(false); }
  }, []);

  useEffect(() => {
    loadUsers();
    // Fetch auth type on mount
    safeFetch('/auth/config').then(cfg => {
      setAuthType(cfg.type || 'none');
    }).catch(() => {});
  }, [loadUsers]);

  const handleAdLookup = async () => {
    const username = userDlg.username.trim();
    if (!username) return;
    setAdLookupLoading(true);
    setAdLookupError('');
    setAdLookup(null);
    try {
      const data = await safeFetch(`/api/admin/users/lookup/${encodeURIComponent(username)}`);
      setAdLookup(data);
    } catch (e: any) {
      setAdLookupError(e.message);
    } finally {
      setAdLookupLoading(false);
    }
  };

  const handleSaveUser = async () => {
    const { mode, username, password, role } = userDlg;
    if (!username.trim()) return;
    try {
      const url = mode === 'add'
        ? '/api/admin/users'
        : `/api/admin/users/${encodeURIComponent(username)}`;
      const method = mode === 'add' ? 'POST' : 'PUT';
      const body: Record<string, any> = { username: username.trim(), role };
      if (!isAdMode && password) body.password = password;
      await safeFetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      addNotification({ type: 'success', title: mode === 'add' ? 'User Added' : 'User Updated', message: `${username} (${role})` });
      setUserDlg({ ...userDlg, open: false });
      setAdLookup(null);
      setAdLookupError('');
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  const handleDeleteUser = async (username: string) => {
    if (!confirm(`Remove user "${username}"? This cannot be undone.`)) return;
    try {
      await safeFetch(`/api/admin/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'User Removed', message: username });
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  const openAddDialog = () => {
    setAdLookup(null);
    setAdLookupError('');
    setUserDlg({ open: true, mode: 'add', username: '', password: '', role: 'analyst' });
  };

  return (
    <>
      <Paper variant="outlined" sx={{ p: 2.5 }}>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
          <Button size="small" variant="contained" onClick={openAddDialog}>
            + Add User
          </Button>
        </Box>
        {userMgmtLoading && <LinearProgress sx={{ mb: 1 }} />}
        {!userMgmtLoading && userList.length === 0 ? (
          <Typography variant="body2" color="text.secondary">No users configured (auth may be disabled)</Typography>
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {['User', 'Role', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {userList.map(u => (
                  <TableRow key={u.username} hover>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                        <Avatar sx={{
                          width: 22, height: 22, fontSize: 11,
                          bgcolor: u.role === 'admin'
                            ? theme.palette.error.light
                            : u.role === 'analyst'
                              ? theme.palette.primary.light
                              : theme.palette.grey[400]
                        }}>
                          {u.username[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2">{u.username}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip size="small" label={u.role}
                        color={u.role === 'admin' ? 'error' : u.role === 'analyst' ? 'primary' : 'default'}
                        variant="outlined"
                        sx={{ height: 20, fontSize: 11, fontWeight: 700, textTransform: 'capitalize' }} />
                    </TableCell>
                    <TableCell>
                      <IconButton size="small"
                        onClick={() => setUserDlg({ open: true, mode: 'edit', username: u.username, password: '', role: u.role })}>
                        <SettingsIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" color="error" onClick={() => handleDeleteUser(u.username)}>
                        <CancelIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {/* Add / Edit User Dialog */}
      <Dialog open={userDlg.open} onClose={() => setUserDlg({ ...userDlg, open: false })} maxWidth="xs" fullWidth>
        <DialogTitle>{userDlg.mode === 'add' ? 'Add User' : `Edit User \u2014 ${userDlg.username}`}</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
          {userDlg.mode === 'add' && (
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField label={isAdMode ? 'Windows ID' : 'Username'} size="small" fullWidth value={userDlg.username}
                onChange={e => { setUserDlg({ ...userDlg, username: e.target.value }); setAdLookup(null); setAdLookupError(''); }}
                autoFocus
                onKeyDown={e => { if (isAdMode && e.key === 'Enter') { e.preventDefault(); handleAdLookup(); } }}
              />
              {isAdMode && (
                <Button size="small" variant="outlined" onClick={handleAdLookup}
                  disabled={!userDlg.username.trim() || adLookupLoading}
                  sx={{ minWidth: 90, whiteSpace: 'nowrap' }}>
                  {adLookupLoading ? <CircularProgress size={18} /> : 'Lookup'}
                </Button>
              )}
            </Box>
          )}

          {isAdMode && adLookup && (
            <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'success.50' }}>
              <Typography variant="body2" fontWeight={600}>{adLookup.display_name}</Typography>
              {adLookup.email && <Typography variant="caption" color="text.secondary">{adLookup.email}</Typography>}
              {adLookup.groups && adLookup.groups.length > 0 && (
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  Groups: {adLookup.groups.slice(0, 5).join(', ')}{adLookup.groups.length > 5 ? ` (+${adLookup.groups.length - 5} more)` : ''}
                </Typography>
              )}
            </Paper>
          )}
          {isAdMode && adLookupError && (
            <Alert severity="error" sx={{ py: 0 }}>{adLookupError}</Alert>
          )}

          {!isAdMode && (
            <TextField label={userDlg.mode === 'add' ? 'Password' : 'New Password (leave blank to keep)'} size="small" fullWidth type="password"
              value={userDlg.password} onChange={e => setUserDlg({ ...userDlg, password: e.target.value })} />
          )}

          <TextField label="Role" size="small" fullWidth select value={userDlg.role}
            onChange={e => setUserDlg({ ...userDlg, role: e.target.value })}>
            <MenuItem value="admin">Admin</MenuItem>
            <MenuItem value="analyst">Analyst</MenuItem>
            <MenuItem value="viewer">Viewer</MenuItem>
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUserDlg({ ...userDlg, open: false })}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveUser}
            disabled={
              userDlg.mode === 'add' && (
                !userDlg.username.trim() ||
                (!isAdMode && !userDlg.password)
              )
            }>
            {userDlg.mode === 'add' ? 'Add User' : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default UserManagementSection;
