/**
 * Phase 151 — Plain Parquet Brain admin UI.
 *
 * One panel, three actions: refresh supplement / refresh bloom /
 * build mirror — each scoped to an optional partition slice the
 * operator picks from the top-partition-column detector.  The top
 * (highest-coverage) column is auto-selected so the operator only
 * picks a value; the column name itself is data-driven, never
 * hardcoded.
 *
 * Endpoints used:
 *   GET  /api/admin/parquet/discoverable-tables
 *   GET  /api/admin/parquet/catalog/state
 *   GET  /api/admin/parquet/partition-detect?connection_id=...&table_name=...
 *   POST /api/admin/parquet/supplement/scan
 *   POST /api/admin/parquet/bloom/scan
 *   POST /api/admin/parquet/mirror/build
 *   POST /api/admin/parquet/sync/tick
 *   GET  /api/admin/parquet/sync/recent-ticks
 *   GET  /api/admin/parquet/mirror/state
 *   GET  /api/admin/parquet/mirror/list
 *   POST /api/admin/parquet/mirror/cleanup
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  CircularProgress, TextField, FormControlLabel, Switch,
  Autocomplete, Tooltip, Divider, Grid,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as PlayIcon,
  Search as SearchIcon,
  Build as BuildIcon,
  Storage as StorageIcon,
  Compress as CompressIcon,
  CleaningServices as CleaningIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface DiscoverableTable {
  connection_id:   number;
  connection_name: string;
  bucket:          string;
  table_prefix:    string;
  table_name:      string;
}

interface PartitionColumn {
  column:                  string;
  coverage_pct:            number;
  distinct_value_count:    number;
  distinct_values_sample:  string[];
}

interface PartitionDetectResponse {
  table:           string;
  snapshot_token:  string;
  files_total:     number;
  columns:         PartitionColumn[];
}

interface CatalogTable {
  bucket:          string;
  prefix:          string;
  file_count:      number;
  snapshot_token:  string;
  enumerated_at:   number;
  elapsed_seconds: number;
  truncated:       boolean;
}

interface CatalogState {
  cache_ttl_seconds:     number;
  max_files_per_table:   number;
  tables:                CatalogTable[];
  total_cached_tables:   number;
  error?:                string;
}

interface SyncTick {
  started_at:         string;
  elapsed_seconds:    number;
  tables_considered:  number;
  tables_scanned:     number;
  files_scanned:      number;
  skipped_pressure:   number;
  skipped_cached:     number;
  errors:             number;
  details?:           any[];
}

interface MirrorState {
  build_enabled:     boolean;
  routing_enabled:   boolean;
  cron_enabled:      boolean;
  min_source_files:  number;
  by_status:         Record<string, number>;
  total:             number;
  routing_on:        number;
  error?:            string;
}

interface MirrorRow {
  id:                       number;
  source_bucket:            string;
  source_prefix:            string;
  source_snapshot_id:       string;
  source_format:            string;
  status:                   string;
  routing_enabled:          boolean;
  mirror_file_count:        number;
  mirror_total_bytes:       number;
  built_at:                 string | null;
  last_error:               string;
}


const PlainParquetBrainSection: React.FC = () => {
  // ── Data state ───────────────────────────────────────────────
  const [tables, setTables]                 = useState<DiscoverableTable[]>([]);
  const [catalog, setCatalog]               = useState<CatalogState | null>(null);
  const [recentTicks, setRecentTicks]       = useState<SyncTick[]>([]);
  const [mirrorState, setMirrorState]       = useState<MirrorState | null>(null);
  const [mirrors, setMirrors]               = useState<MirrorRow[]>([]);
  const [loading, setLoading]               = useState(false);
  const [error, setError]                   = useState<string | null>(null);
  const [notice, setNotice]                 = useState<string | null>(null);

  // ── Refresh form state ───────────────────────────────────────
  const [selectedTable, setSelectedTable]   = useState<DiscoverableTable | null>(null);
  const [detected, setDetected]             = useState<PartitionColumn[]>([]);
  const [detecting, setDetecting]           = useState(false);
  const [partitionCol, setPartitionCol]     = useState<string>('');
  const [partitionVal, setPartitionVal]     = useState<string>('');
  const [bloomColumns, setBloomColumns]     = useState<string>('');
  const [forceRebuild, setForceRebuild]     = useState(false);
  // sort_by for mirror builds — DuckDB writes parquet row-groups in
  // this order so WHERE filters on these cols drop row-groups via
  // zone maps at read time.  Empty = no ORDER BY (legacy behaviour).
  const [mirrorSortBy, setMirrorSortBy]     = useState<string[]>([]);
  // Sortedness diagnostics for the picked sort_by columns.
  const [sortednessByCol, setSortednessByCol] = useState<Record<string, {
    verdict: string;
    monotonic_pct: number;
    recommendation: string;
  }>>({});
  const [analysingCol, setAnalysingCol] = useState<string | null>(null);
  const [working, setWorking]               = useState<string | null>(null);

  // ── Loaders ──────────────────────────────────────────────────
  const loadAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [tbls, cat, ticks, mst, mlist] = await Promise.all([
        safeFetch('/api/admin/parquet/discoverable-tables'),
        safeFetch('/api/admin/parquet/catalog/state'),
        safeFetch('/api/admin/parquet/sync/recent-ticks?limit=5'),
        safeFetch('/api/admin/parquet/mirror/state'),
        safeFetch('/api/admin/parquet/mirror/list?limit=50'),
      ]);
      setTables(tbls.tables ?? []);
      setCatalog(cat);
      setRecentTicks(ticks.ticks ?? []);
      setMirrorState(mst);
      setMirrors(mlist.mirrors ?? []);
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const analyseColumnSort = useCallback(async (col: string) => {
    if (!selectedTable || !col) return;
    if (sortednessByCol[col]) return;
    setAnalysingCol(col);
    try {
      const url = (
        `/api/admin/mirror/sort-analysis?` +
        `connection_id=${selectedTable.connection_id}` +
        `&table_name=${encodeURIComponent(selectedTable.table_name)}` +
        `&column=${encodeURIComponent(col)}`
      );
      const resp = await safeFetch(url);
      setSortednessByCol((prev) => ({
        ...prev,
        [col]: {
          verdict:        resp.verdict ?? 'unknown',
          monotonic_pct:  resp.monotonic_pct ?? 0,
          recommendation: resp.recommendation ?? '',
        },
      }));
    } catch (e: any) {
      setSortednessByCol((prev) => ({
        ...prev,
        [col]: {
          verdict: 'unknown',
          monotonic_pct: 0,
          recommendation: `Analysis failed: ${e?.message ?? String(e)}`,
        },
      }));
    } finally {
      setAnalysingCol(null);
    }
  }, [selectedTable, sortednessByCol]);

  const detectPartitions = useCallback(async () => {
    if (!selectedTable) return;
    setDetecting(true);
    setDetected([]);
    setPartitionCol('');
    setPartitionVal('');
    try {
      const url = (
        `/api/admin/parquet/partition-detect?connection_id=` +
        `${selectedTable.connection_id}` +
        `&table_name=${encodeURIComponent(selectedTable.table_name)}`
      );
      const resp: PartitionDetectResponse = await safeFetch(url);
      const cols = resp.columns ?? [];
      setDetected(cols);
      // Auto-pick the top (highest-coverage) column so the operator
      // only picks the VALUE.  No hardcoded column name — whatever
      // the table is actually partitioned by wins.
      if (cols.length > 0) {
        setPartitionCol(cols[0].column);
      }
      setNotice(
        `Found ${cols.length} partition column(s) ` +
        `from ${resp.files_total} files (token=${resp.snapshot_token}).` +
        (cols.length > 0
          ? `  Top column auto-picked: ${cols[0].column} ` +
            `(${cols[0].coverage_pct}% coverage).`
          : ''),
      );
    } catch (e: any) {
      setError(`partition-detect failed: ${e?.message ?? String(e)}`);
    } finally {
      setDetecting(false);
    }
  }, [selectedTable]);

  const partitionFilters = (): Record<string, string> | undefined => {
    if (!partitionCol || !partitionVal) return undefined;
    return { [partitionCol]: partitionVal };
  };

  // ── Action handlers ──────────────────────────────────────────
  const refreshSupplement = useCallback(async () => {
    if (!selectedTable) return;
    setWorking('supplement');
    setError(null);
    setNotice(null);
    try {
      const body: any = {
        connection_id: selectedTable.connection_id,
        table_name:    selectedTable.table_name,
        force:         forceRebuild,
      };
      const filters = partitionFilters();
      if (filters) body.partition_filters = filters;
      const resp = await safeFetch(
        '/api/admin/parquet/supplement/scan',
        { method: 'POST', body: JSON.stringify(body) },
      );
      setNotice(
        `Supplement scan: scanned=${resp.scanned ?? 0}, ` +
        `skipped=${resp.skipped ?? 0}, failed=${resp.failed ?? 0}, ` +
        `rows=${resp.rows_inserted ?? 0}, ` +
        `elapsed=${resp.elapsed_seconds ?? 0}s` +
        (filters ? ` (partition ${partitionCol}=${partitionVal})` : ''),
      );
      await loadAll();
    } catch (e: any) {
      setError(`supplement scan failed: ${e?.message ?? String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [selectedTable, forceRebuild, partitionCol, partitionVal, loadAll]);

  const refreshBloom = useCallback(async () => {
    if (!selectedTable) return;
    const cols = bloomColumns
      .split(',').map((s) => s.trim()).filter(Boolean);
    if (!cols.length) {
      setError(
        'Bloom scan requires at least one column.  Enter a comma-separated ' +
        'list (e.g. "customer_id,order_id") — bloom is heavy per file so ' +
        'we never scan all columns blindly.',
      );
      return;
    }
    setWorking('bloom');
    setError(null);
    setNotice(null);
    try {
      const body: any = {
        connection_id: selectedTable.connection_id,
        table_name:    selectedTable.table_name,
        columns:       cols,
      };
      const filters = partitionFilters();
      if (filters) body.partition_filters = filters;
      const resp = await safeFetch(
        '/api/admin/parquet/bloom/scan',
        { method: 'POST', body: JSON.stringify(body) },
      );
      setNotice(
        `Bloom scan: files_total=${resp.files_total ?? 0}, ` +
        `scanned=${resp.scanned ?? 0}, ` +
        `rows=${resp.rows_inserted ?? 0}, ` +
        `elapsed=${resp.elapsed_seconds ?? 0}s` +
        (filters ? ` (partition ${partitionCol}=${partitionVal})` : ''),
      );
      await loadAll();
    } catch (e: any) {
      setError(`bloom scan failed: ${e?.message ?? String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [selectedTable, bloomColumns, partitionCol, partitionVal, loadAll]);

  const buildMirror = useCallback(async () => {
    if (!selectedTable) return;
    setWorking('mirror');
    setError(null);
    setNotice(null);
    try {
      const body: any = {
        connection_id: selectedTable.connection_id,
        table_name:    selectedTable.table_name,
        force:         forceRebuild,
      };
      const filters = partitionFilters();
      if (filters) body.partition_filters = filters;
      if (mirrorSortBy.length > 0) body.sort_by = mirrorSortBy;
      const resp = await safeFetch(
        '/api/admin/parquet/mirror/build',
        { method: 'POST', body: JSON.stringify(body) },
      );
      const mode = resp.consolidation_mode ?? 'unknown';
      setNotice(
        `Mirror build: status=${resp.status ?? '?'}, ` +
        `consolidation_mode=${mode}, ` +
        `source_files=${resp.source_file_count ?? 0}, ` +
        `mirror_files=${resp.mirror_file_count ?? 0}` +
        (filters ? ` (partition ${partitionCol}=${partitionVal})` : ''),
      );
      await loadAll();
    } catch (e: any) {
      setError(`mirror build failed: ${e?.message ?? String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [
    selectedTable, forceRebuild, partitionCol, partitionVal,
    mirrorSortBy, loadAll,
  ]);

  const forceSyncTick = useCallback(async () => {
    setWorking('sync_tick');
    setError(null);
    try {
      const resp = await safeFetch(
        '/api/admin/parquet/sync/tick', { method: 'POST' },
      );
      setNotice(
        `Sync tick fired: considered=${resp.tables_considered ?? 0}, ` +
        `scanned=${resp.tables_scanned ?? 0}, ` +
        `files=${resp.files_scanned ?? 0}, ` +
        `elapsed=${resp.elapsed_seconds ?? 0}s`,
      );
      await loadAll();
    } catch (e: any) {
      setError(`sync tick failed: ${e?.message ?? String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const cleanupMirror = useCallback(async () => {
    setWorking('mirror_cleanup');
    setError(null);
    try {
      const resp = await safeFetch(
        '/api/admin/parquet/mirror/cleanup', { method: 'POST' },
      );
      setNotice(
        `Mirror cleanup: examined=${resp.examined ?? 0}, ` +
        `marked_stale=${resp.marked_stale ?? 0}, ` +
        `swept_failed=${resp.swept_failed ?? 0}`,
      );
      await loadAll();
    } catch (e: any) {
      setError(`mirror cleanup failed: ${e?.message ?? String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  // ── Renderers ────────────────────────────────────────────────
  const renderFlagChip = (label: string, on: boolean) => (
    <Chip
      label={`${label}: ${on ? 'ON' : 'OFF'}`}
      color={on ? 'success' : 'default'}
      size="small" sx={{ mr: 0.5, mb: 0.5 }}
    />
  );

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <StorageIcon color="primary" />
        <Typography variant="h5">Plain Parquet Brain</Typography>
        <Chip label="Phase 151" size="small" color="info" />
        <Box sx={{ flex: 1 }} />
        <Tooltip title="Reload all panels">
          <Button
            onClick={loadAll} startIcon={<RefreshIcon />}
            disabled={loading}
          >
            Refresh
          </Button>
        </Tooltip>
      </Stack>

      {loading && (
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <CircularProgress size={18} sx={{ mr: 1 }} />
          <Typography variant="body2">Loading…</Typography>
        </Box>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}
      {notice && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setNotice(null)}>
          {notice}
        </Alert>
      )}

      {/* ── Flag posture ────────────────────────────────────── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Posture</Typography>
        <Stack direction="row" flexWrap="wrap">
          {renderFlagChip(
            'Catalog',
            !!catalog && !catalog.error,
          )}
          {renderFlagChip(
            'Mirror build',
            !!mirrorState?.build_enabled,
          )}
          {renderFlagChip(
            'Mirror routing',
            !!mirrorState?.routing_enabled,
          )}
          {renderFlagChip(
            'Mirror cron',
            !!mirrorState?.cron_enabled,
          )}
          <Chip
            label={`Discoverable tables: ${tables.length}`}
            color="info" size="small" sx={{ mr: 0.5, mb: 0.5 }}
          />
          {catalog && (
            <Chip
              label={`Catalog cached: ${catalog.total_cached_tables}`}
              size="small" sx={{ mr: 0.5, mb: 0.5 }}
            />
          )}
          {mirrorState && (
            <Chip
              label={`Mirrors: ${mirrorState.total} (routing on ${mirrorState.routing_on})`}
              size="small" sx={{ mr: 0.5, mb: 0.5 }}
            />
          )}
        </Stack>
      </Paper>

      {/* ── Refresh form ────────────────────────────────────── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>
          Refresh Supplement / Bloom / Mirror
        </Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <Autocomplete
              options={tables}
              getOptionLabel={(t) => (
                `${t.connection_name} → ${t.table_name} ` +
                `(s3://${t.bucket}/${t.table_prefix})`
              )}
              isOptionEqualToValue={(a, b) => (
                a.connection_id === b.connection_id
                && a.table_name === b.table_name
              )}
              value={selectedTable}
              onChange={(_e, v) => {
                setSelectedTable(v);
                setDetected([]);
                setPartitionCol('');
                setPartitionVal('');
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Registered parquet table"
                  size="small"
                />
              )}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <Stack direction="row" spacing={1} alignItems="center">
              <Button
                onClick={detectPartitions}
                disabled={!selectedTable || detecting}
                startIcon={<SearchIcon />}
                variant="outlined" size="small"
              >
                {detecting ? 'Detecting…' : 'Detect top partitions'}
              </Button>
              <FormControlLabel
                control={
                  <Switch
                    size="small"
                    checked={forceRebuild}
                    onChange={(e) => setForceRebuild(e.target.checked)}
                  />
                }
                label="Force (bypass skip-already-scanned)"
              />
            </Stack>
          </Grid>

          {/* Partition picker — appears only when detected has rows */}
          {detected.length > 0 && (
            <>
              <Grid size={{ xs: 12, md: 6 }}>
                <Autocomplete
                  options={detected.map((d) => d.column)}
                  value={partitionCol || null}
                  onChange={(_e, v) => {
                    setPartitionCol(v || '');
                    setPartitionVal('');
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Partition column (top auto-picked; change if needed)"
                      size="small"
                      helperText={(() => {
                        const c = detected.find(
                          (d) => d.column === partitionCol,
                        );
                        return c
                          ? (`coverage ${c.coverage_pct}% · ` +
                             `${c.distinct_value_count} distinct values`)
                          : 'Leave blank = full-table refresh';
                      })()}
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <Autocomplete
                  freeSolo
                  options={(
                    detected.find((d) => d.column === partitionCol)
                      ?.distinct_values_sample ?? []
                  )}
                  value={partitionVal}
                  onInputChange={(_e, v) => setPartitionVal(v)}
                  disabled={!partitionCol}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Partition value to scope refresh"
                      size="small"
                      helperText="Pick from detected sample values or type any value — refresh is scoped to files matching this value"
                    />
                  )}
                />
              </Grid>
            </>
          )}

          <Grid size={{ xs: 12 }}>
            <TextField
              label="Bloom columns (comma-separated)"
              placeholder="customer_id, order_id"
              size="small" fullWidth
              value={bloomColumns}
              onChange={(e) => setBloomColumns(e.target.value)}
              helperText={
                'REQUIRED for bloom scan only — bloom reads the entire ' +
                'column-chunk per file, never scans all columns blindly.'
              }
            />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <Autocomplete
              multiple freeSolo
              size="small"
              options={[]}
              value={mirrorSortBy}
              onChange={(_e, v) => {
                const cols = v as string[];
                setMirrorSortBy(cols);
                cols.forEach((c) => {
                  if (c && !sortednessByCol[c]) analyseColumnSort(c);
                });
              }}
              renderInput={(params) => (
                <TextField {...params}
                  label="Mirror sort_by — column(s) to ORDER BY during build (optional)"
                  helperText={
                    'Mirror builds only.  DuckDB writes parquet row-groups ' +
                    'in this order so WHERE filters skip whole row-groups ' +
                    'via zone maps at read time.  Brain auto-checks if the ' +
                    'column is already sorted in source — if so, mirror ' +
                    "sort_by adds little (don't duplicate data)."
                  }
                  fullWidth
                />
              )}
            />
            {mirrorSortBy.length > 0 && (
              <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mt: 1 }}>
                {mirrorSortBy.map((c) => {
                  const r = sortednessByCol[c];
                  if (!r) {
                    return (
                      <Chip key={c} size="small" variant="outlined"
                            label={
                              analysingCol === c
                                ? `${c}: analysing…`
                                : `${c}: not yet analysed`
                            } />
                    );
                  }
                  const color =
                    r.verdict === 'sorted' ? 'warning' :
                    r.verdict === 'unsorted' ? 'success' :
                    r.verdict === 'partially_sorted' ? 'info' :
                    'default';
                  const label =
                    r.verdict === 'sorted'
                      ? `${c}: already sorted (${r.monotonic_pct}%) — mirror sort_by may not help`
                    : r.verdict === 'unsorted'
                      ? `${c}: UNSORTED (${r.monotonic_pct}%) — sort_by would unlock skipping`
                    : r.verdict === 'partially_sorted'
                      ? `${c}: partially sorted (${r.monotonic_pct}%)`
                    : `${c}: ${r.verdict}`;
                  return (
                    <Tooltip key={c} title={r.recommendation || ''}>
                      <Chip size="small" color={color} label={label} />
                    </Tooltip>
                  );
                })}
              </Stack>
            )}
          </Grid>

          <Grid size={{ xs: 12 }}>
            <Stack direction="row" spacing={1}>
              <Button
                variant="contained" color="primary"
                onClick={refreshSupplement}
                disabled={!selectedTable || working !== null}
                startIcon={
                  working === 'supplement'
                    ? <CircularProgress size={16} color="inherit" />
                    : <RefreshIcon />
                }
              >
                Refresh Supplement
              </Button>
              <Button
                variant="contained" color="secondary"
                onClick={refreshBloom}
                disabled={!selectedTable || working !== null}
                startIcon={
                  working === 'bloom'
                    ? <CircularProgress size={16} color="inherit" />
                    : <CompressIcon />
                }
              >
                Refresh Bloom
              </Button>
              <Button
                variant="contained"
                onClick={buildMirror}
                disabled={
                  !selectedTable
                  || working !== null
                  || !mirrorState?.build_enabled
                }
                startIcon={
                  working === 'mirror'
                    ? <CircularProgress size={16} color="inherit" />
                    : <BuildIcon />
                }
              >
                Build Mirror
              </Button>
              {!mirrorState?.build_enabled && (
                <Tooltip title="plain_parquet.mirror.enabled=false — flip the flag in App Config first">
                  <Chip
                    label="Mirror build disabled"
                    size="small" color="warning"
                    sx={{ alignSelf: 'center' }}
                  />
                </Tooltip>
              )}
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      {/* ── Daemon controls ─────────────────────────────────── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Daemon controls</Typography>
        <Stack direction="row" spacing={1}>
          <Button
            onClick={forceSyncTick}
            disabled={working !== null}
            startIcon={
              working === 'sync_tick'
                ? <CircularProgress size={16} color="inherit" />
                : <PlayIcon />
            }
            variant="outlined" size="small"
          >
            Force sync tick now
          </Button>
          <Button
            onClick={cleanupMirror}
            disabled={working !== null}
            startIcon={
              working === 'mirror_cleanup'
                ? <CircularProgress size={16} color="inherit" />
                : <CleaningIcon />
            }
            variant="outlined" size="small"
          >
            Cleanup stale mirrors
          </Button>
        </Stack>

        <Divider sx={{ my: 2 }} />
        <Typography variant="body2" gutterBottom>
          Recent sync ticks
        </Typography>
        {recentTicks.length === 0
          ? <Typography variant="caption" color="text.secondary">
              No recent ticks recorded yet.
            </Typography>
          : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Started</TableCell>
                  <TableCell align="right">Considered</TableCell>
                  <TableCell align="right">Scanned</TableCell>
                  <TableCell align="right">Files</TableCell>
                  <TableCell align="right">Pressure skips</TableCell>
                  <TableCell align="right">Errors</TableCell>
                  <TableCell align="right">Elapsed (s)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {recentTicks.map((t, i) => (
                  <TableRow key={i}>
                    <TableCell>{t.started_at}</TableCell>
                    <TableCell align="right">{t.tables_considered}</TableCell>
                    <TableCell align="right">{t.tables_scanned}</TableCell>
                    <TableCell align="right">{t.files_scanned}</TableCell>
                    <TableCell align="right">{t.skipped_pressure}</TableCell>
                    <TableCell align="right">{t.errors}</TableCell>
                    <TableCell align="right">{t.elapsed_seconds}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
      </Paper>

      {/* ── Existing mirrors ────────────────────────────────── */}
      <Paper sx={{ p: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Plain parquet mirrors</Typography>
        {mirrors.length === 0
          ? <Typography variant="caption" color="text.secondary">
              No plain-parquet mirrors yet.  Use “Build Mirror” above.
            </Typography>
          : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Bucket / prefix</TableCell>
                  <TableCell>Snapshot</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Files</TableCell>
                  <TableCell align="right">Bytes</TableCell>
                  <TableCell>Routing</TableCell>
                  <TableCell>Built</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {mirrors.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell>{m.id}</TableCell>
                    <TableCell>
                      {m.source_bucket}/{m.source_prefix}
                    </TableCell>
                    <TableCell>
                      <code>{m.source_snapshot_id}</code>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={m.status} size="small"
                        color={m.status === 'ready' ? 'success'
                               : m.status === 'building' ? 'info'
                               : m.status === 'failed' ? 'error'
                               : 'default'}
                      />
                    </TableCell>
                    <TableCell align="right">{m.mirror_file_count}</TableCell>
                    <TableCell align="right">{m.mirror_total_bytes}</TableCell>
                    <TableCell>
                      <Chip
                        label={m.routing_enabled ? 'on' : 'off'}
                        size="small"
                        color={m.routing_enabled ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell>{m.built_at || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
      </Paper>
    </Box>
  );
};

export default PlainParquetBrainSection;
