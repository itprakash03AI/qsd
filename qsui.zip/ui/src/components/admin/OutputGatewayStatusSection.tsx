/**
 * Phase 150 — Output Gateway admin UI.
 *
 * S3-backed result cache: when a query's post-prune source file count
 * exceeds `output_gateway.min_files_threshold` (default 1000), the
 * consolidated result parquet is uploaded to QS-internal S3 instead of
 * being copied into the per-pod local cache.  Repeat runs of the same
 * (SQL, params, snapshot fingerprint, user_ns) tuple read the gateway
 * parquet from S3 — shared across pods.
 *
 * Endpoints:
 *   GET    /api/admin/output-gateway/stats
 *   GET    /api/admin/output-gateway/list
 *   GET    /api/admin/output-gateway/events
 *   POST   /api/admin/output-gateway/cleanup
 *   DELETE /api/admin/output-gateway/snap/{files_hash}
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, Accordion,
  AccordionSummary, AccordionDetails, Grid,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Delete as DeleteIcon,
  CleaningServices as CleaningIcon,
  Cloud as CloudIcon,
  ExpandMore as ExpandMoreIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface GatewayEntry {
  key:                  string;
  sql:                  string;
  snapshot_fingerprint: { files_count?: number; files_hash?: string };
  s3_uri:               string;
  meta_uri:             string;
  row_count:            number;
  column_count:         number;
  size_bytes:           number;
  created_at:           number;
  expires_at:           number;
  hit_count:            number;
  last_hit_at:          number;
  user_namespace:       string | null;
  files_after_prune:    number;
}


interface GatewayStats {
  enabled:                boolean;
  serve_enabled:          boolean;
  min_files_threshold:    number;
  internal_bucket:        string;
  internal_prefix:        string;
  retention_days:         number;
  default_ttl_seconds:    number;
  max_result_mb:          number;
  entry_count:            number;
  total_bytes:            number;
  total_hits:             number;
}


interface EventRecord { at: string; kind: string; [k: string]: any; }
interface TickRecord { started_at: string; elapsed: number;
                       summary?: { scanned?: number; deleted?: number;
                                    retained?: number; errors?: number }; }


const relativeAgeFromEpoch = (epochSeconds: number): string => {
  if (!epochSeconds) return '—';
  const ms = Date.now() - epochSeconds * 1000;
  if (ms < 0) return '?';
  const s = Math.round(ms / 1000);
  if (s < 60)    return `${s}s ago`;
  if (s < 3600)  return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
};


const fmtBytes = (n: number): string => {
  if (!n) return '0';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = n, u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u += 1; }
  return `${v.toFixed(v < 10 ? 2 : 1)} ${units[u]}`;
};


const OutputGatewayStatusSection: React.FC = () => {
  const [stats, setStats] = useState<GatewayStats | null>(null);
  const [entries, setEntries] = useState<GatewayEntry[]>([]);
  const [events, setEvents] = useState<EventRecord[]>([]);
  const [ticks, setTicks] = useState<TickRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [working, setWorking] = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [statsRes, listRes, evRes] = await Promise.all([
        safeFetch('/api/admin/output-gateway/stats',  { timeoutMs: 30000 }),
        safeFetch('/api/admin/output-gateway/list?limit=200', { timeoutMs: 60000 }),
        safeFetch('/api/admin/output-gateway/events', { timeoutMs: 15000 }),
      ]);
      setStats(statsRes ?? null);
      setEntries(listRes?.entries ?? []);
      setEvents(evRes?.events ?? []);
      setTicks(evRes?.ticks ?? []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const forceCleanup = useCallback(async () => {
    setWorking('cleanup');
    try {
      const r = await safeFetch('/api/admin/output-gateway/cleanup', {
        method: 'POST', timeoutMs: 600000,
      });
      alert(`Cleanup: ${JSON.stringify(r ?? {}, null, 2).slice(0, 600)}`);
      await loadAll();
    } catch (e: any) {
      alert(`Cleanup failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const deleteSnap = useCallback(async (hash: string) => {
    if (!confirm(`Bulk-delete every gateway entry under snap=${hash}?`)) return;
    setWorking(`del-${hash}`);
    try {
      const r = await safeFetch(`/api/admin/output-gateway/snap/${encodeURIComponent(hash)}`, {
        method: 'DELETE', timeoutMs: 120000,
      });
      alert(`Deleted ${r?.deleted ?? 0} objects under snap=${hash}`);
      await loadAll();
    } catch (e: any) {
      alert(`Delete failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  // Group entries by snapshot fingerprint for the "bulk-delete by snap"
  // affordance — operators often want to wipe an entire stale snapshot
  // when source iceberg rolls forward.
  const snapGroups = React.useMemo(() => {
    const groups = new Map<string, GatewayEntry[]>();
    for (const e of entries) {
      const h = (e.snapshot_fingerprint?.files_hash || '').slice(0, 32) || '—';
      const cur = groups.get(h) || [];
      cur.push(e);
      groups.set(h, cur);
    }
    return Array.from(groups.entries())
      .sort((a, b) => {
        const aMax = Math.max(...a[1].map((x) => x.created_at || 0));
        const bMax = Math.max(...b[1].map((x) => x.created_at || 0));
        return bMax - aMax;
      });
  }, [entries]);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <CloudIcon fontSize="small" />
        <Typography variant="h6">Output Gateway (S3 result cache)</Typography>
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<CleaningIcon />} variant="outlined" size="small"
                onClick={forceCleanup} disabled={!!working}>
          {working === 'cleanup' ? <CircularProgress size={14} /> : 'Cleanup expired'}
        </Button>
        <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                onClick={loadAll} disabled={loading}>
          {loading ? <CircularProgress size={14} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          <b>What this does:</b> when a query&apos;s post-prune source file count
          exceeds <code>output_gateway.min_files_threshold</code>, the
          consolidated result parquet is uploaded to QS-internal S3 instead of
          being copied into the per-pod local <code>result_cache</code>.
          {' '}Subsequent runs of the same (SQL + params + snapshot fingerprint
          + user namespace) tuple read the gateway parquet from S3 — shared
          across pods.
          {' '}<b>OFF by default</b> — flip
          <code>output_gateway.enabled</code> and
          <code>output_gateway.serve_enabled</code> in config.json after
          observing the local cache is consistently full on big-scan workloads.
        </Typography>
      </Paper>

      {/* Config / stats panel */}
      {stats && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Grid container spacing={2}>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Enabled</Typography>
              <Box>
                <Chip size="small"
                      color={stats.enabled ? 'success' : 'default'}
                      label={`build ${stats.enabled ? 'ON' : 'OFF'}`} />
                &nbsp;
                <Chip size="small"
                      color={stats.serve_enabled ? 'success' : 'default'}
                      label={`serve ${stats.serve_enabled ? 'ON' : 'OFF'}`} />
              </Box>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">
                min_files threshold
              </Typography>
              <Typography>{stats.min_files_threshold.toLocaleString()}</Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Bucket / prefix</Typography>
              <Typography sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                {stats.internal_bucket}/{stats.internal_prefix}
              </Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Retention / TTL</Typography>
              <Typography>{stats.retention_days}d / {Math.round(stats.default_ttl_seconds / 3600)}h</Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Entry count</Typography>
              <Typography>{stats.entry_count.toLocaleString()}</Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Total size</Typography>
              <Typography>{fmtBytes(stats.total_bytes)}</Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Total hits</Typography>
              <Typography>{stats.total_hits.toLocaleString()}</Typography>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">Max result</Typography>
              <Typography>{stats.max_result_mb} MB</Typography>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* Recent ticks */}
      {ticks.length > 0 && (
        <Accordion sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">Recent cleanup ticks ({ticks.length})</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Started</TableCell>
                  <TableCell>Elapsed</TableCell>
                  <TableCell>Scanned / Deleted / Retained / Errors</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {ticks.map((t, i) => {
                  const ageSec = (Date.now() - new Date(t.started_at).getTime()) / 1000;
                  const ago = ageSec < 60 ? `${Math.round(ageSec)}s ago`
                             : ageSec < 3600 ? `${Math.round(ageSec / 60)}m ago`
                             : ageSec < 86400 ? `${Math.round(ageSec / 3600)}h ago`
                             : `${Math.round(ageSec / 86400)}d ago`;
                  const s = t.summary || {};
                  return (
                    <TableRow key={i}>
                      <TableCell>{ago}</TableCell>
                      <TableCell>{t.elapsed?.toFixed(2)}s</TableCell>
                      <TableCell>
                        {(s.scanned ?? 0)} / {(s.deleted ?? 0)} / {(s.retained ?? 0)} / {(s.errors ?? 0)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* Recent events */}
      {events.length > 0 && (
        <Accordion sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">Recent events ({events.length})</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Kind</TableCell>
                  <TableCell>Payload</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {events.slice(0, 30).map((e, i) => {
                  const ageMs = Date.now() - new Date(e.at).getTime();
                  const s = Math.round(ageMs / 1000);
                  const ago = s < 60 ? `${s}s ago`
                             : s < 3600 ? `${Math.round(s / 60)}m ago`
                             : s < 86400 ? `${Math.round(s / 3600)}h ago`
                             : `${Math.round(s / 86400)}d ago`;
                  return (
                    <TableRow key={i}>
                      <TableCell>{ago}</TableCell>
                      <TableCell><Chip size="small" label={e.kind} /></TableCell>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                        {JSON.stringify({ ...e, at: undefined, kind: undefined }).slice(0, 200)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* Entries grouped by snapshot */}
      {snapGroups.length === 0 && !loading && !error && (
        <Alert severity="info">
          No gateway entries yet.  Either <code>output_gateway.enabled</code> is
          false (default), no big-scan query (file count &gt;{' '}
          {stats?.min_files_threshold ?? '?'}) has run recently, or the
          internal S3 bucket isn&apos;t reachable from this pod.
        </Alert>
      )}

      {snapGroups.map(([hash, group]) => (
        <Paper key={hash} sx={{ mb: 2 }}>
          <Stack direction="row" alignItems="center" sx={{ p: 1.5,
                  borderBottom: '1px solid #e5e7eb' }}>
            <Typography variant="subtitle2" sx={{ fontFamily: 'monospace' }}>
              snap = {hash}
            </Typography>
            <Box sx={{ flex: 1 }} />
            <Chip size="small" label={`${group.length} entries`} sx={{ mr: 1 }} />
            <Tooltip title={`Bulk-delete every entry under snap=${hash}`}>
              <IconButton size="small" onClick={() => deleteSnap(hash)}
                          disabled={!!working}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Stack>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Cache key</TableCell>
                <TableCell>User ns</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell align="right">Cols</TableCell>
                <TableCell align="right">Size</TableCell>
                <TableCell align="right">Files (pre-cache)</TableCell>
                <TableCell align="right">Hits</TableCell>
                <TableCell>Created</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {group.map((e) => (
                <TableRow key={e.key}>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                    {e.key.slice(0, 16)}…
                  </TableCell>
                  <TableCell>{e.user_namespace || 'anon'}</TableCell>
                  <TableCell align="right">{e.row_count.toLocaleString()}</TableCell>
                  <TableCell align="right">{e.column_count}</TableCell>
                  <TableCell align="right">{fmtBytes(e.size_bytes)}</TableCell>
                  <TableCell align="right">{e.files_after_prune.toLocaleString()}</TableCell>
                  <TableCell align="right">{e.hit_count}</TableCell>
                  <TableCell>{relativeAgeFromEpoch(e.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      ))}
    </Box>
  );
};


export default OutputGatewayStatusSection;
