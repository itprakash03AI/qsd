/**
 * Iceberg + S3 Cache Admin Section (BF-273)
 *
 * Surfaces three previously config-file-only setting groups:
 *
 * 1. iceberg_mor.enabled — when ON, queries against Iceberg V2 tables
 *    with delete files (UPDATE / DELETE / MERGE) correctly exclude
 *    deleted rows.  Default OFF preserves the historical "skip deletes"
 *    behaviour for append-only ETL pipelines but causes COUNT(DISTINCT)
 *    and aggregations to return STALE rows on tables with deletes.
 *
 * 2. iceberg.metadata_cache_ttl_seconds — caches the resolved
 *    metadata.json key per table so we don't full-scan the metadata/
 *    prefix on every query.  60s default.
 *
 * 3. s3_local_cache.* — persistent NFS cache of S3 files.  Iceberg data
 *    files are immutable so a path-based cache is safe with no ETag
 *    check needed.  Equivalent to Trino split-cache / Snowflake warehouse
 *    cache.  Backend evicts LRU on background scheduler.
 *
 * All three round-trip through the existing /api/admin/app-config
 * endpoint (admin_api.py extended in BF-273 to include them in GET/PUT).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Divider, FormControlLabel, Grid,
  IconButton, Paper, Stack, Switch, TextField, Tooltip, Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import RefreshIcon from '@mui/icons-material/Refresh';
import SaveIcon from '@mui/icons-material/Save';
import SortIcon from '@mui/icons-material/Sort';
import StorageIcon from '@mui/icons-material/Storage';
import { safeFetch } from '../../services/api/core';

interface IcebergCfg {
  metadata_cache_ttl_seconds:    number;
  metadata_count_warn_threshold: number;
}
interface IcebergMorCfg {
  enabled: boolean;
}
interface S3CacheCfg {
  enabled:                 boolean;
  cache_dir:               string;
  max_size_gb:             number;
  evict_interval_minutes:  number;
  min_free_disk_gb:        number;
}

const EMPTY_ICE: IcebergCfg = {
  metadata_cache_ttl_seconds: 60, metadata_count_warn_threshold: 5000,
};
const EMPTY_MOR: IcebergMorCfg = { enabled: false };
const EMPTY_CACHE: S3CacheCfg = {
  enabled: false, cache_dir: '/usr/local/querystudioapi/nfs/data/s3_cache',
  max_size_gb: 100, evict_interval_minutes: 30, min_free_disk_gb: 5.0,
};

// BF-275: per-table sort order rows.  Edited as text (comma-separated
// columns) for ergonomics; serialised to {table_name: string[]} on save.
interface SortOrderRow {
  table:   string;
  columns: string;  // comma-separated; e.g. "code, sap_company_id"
}

const _rowsToMap = (rows: SortOrderRow[]): Record<string, string[]> => {
  const out: Record<string, string[]> = {};
  for (const r of rows) {
    const t = (r.table || '').trim();
    if (!t) continue;
    const cols = (r.columns || '')
      .split(',')
      .map(c => c.trim())
      .filter(c => c.length > 0);
    out[t] = cols;
  }
  return out;
};

const _mapToRows = (m: Record<string, string[]> | undefined | null): SortOrderRow[] => {
  if (!m) return [];
  return Object.entries(m).map(([table, cols]) => ({
    table,
    columns: Array.isArray(cols) ? cols.join(', ') : '',
  }));
};

const IcebergSection: React.FC = () => {
  const [ice,    setIce]    = useState<IcebergCfg>(EMPTY_ICE);
  const [mor,    setMor]    = useState<IcebergMorCfg>(EMPTY_MOR);
  const [cache,  setCache]  = useState<S3CacheCfg>(EMPTY_CACHE);
  const [sortRows,      setSortRows]      = useState<SortOrderRow[]>([]);
  const [savedIce,   setSavedIce]   = useState<IcebergCfg>(EMPTY_ICE);
  const [savedMor,   setSavedMor]   = useState<IcebergMorCfg>(EMPTY_MOR);
  const [savedCache, setSavedCache] = useState<S3CacheCfg>(EMPTY_CACHE);
  const [savedSortRows, setSavedSortRows] = useState<SortOrderRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving,  setSaving]  = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [restartPending, setRestartPending] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setErr(null);
    try {
      const resp: any = await safeFetch('/api/admin/app-config');
      const i: IcebergCfg     = { ...EMPTY_ICE,   ...(resp?.iceberg        || {}) };
      const m: IcebergMorCfg  = { ...EMPTY_MOR,   ...(resp?.iceberg_mor    || {}) };
      const c: S3CacheCfg     = { ...EMPTY_CACHE, ...(resp?.s3_local_cache || {}) };
      const rows: SortOrderRow[] = _mapToRows(resp?.iceberg_sort_orders);
      setIce(i);   setSavedIce(i);
      setMor(m);   setSavedMor(m);
      setCache(c); setSavedCache(c);
      setSortRows(rows); setSavedSortRows(rows);
    } catch (e: any) {
      setErr(e?.message || 'Failed to load Iceberg / cache config');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const dirty =
    JSON.stringify(ice)      !== JSON.stringify(savedIce)      ||
    JSON.stringify(mor)      !== JSON.stringify(savedMor)      ||
    JSON.stringify(cache)    !== JSON.stringify(savedCache)    ||
    JSON.stringify(sortRows) !== JSON.stringify(savedSortRows);

  const save = useCallback(async () => {
    setSaving(true); setErr(null); setMsg(null);
    try {
      const body = JSON.stringify({
        iceberg:             ice,
        iceberg_mor:         mor,
        s3_local_cache:      cache,
        iceberg_sort_orders: _rowsToMap(sortRows),  // BF-275
      });
      const resp: any = await safeFetch('/api/admin/app-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body,
      });
      setMsg(resp?.message || 'Saved');
      setRestartPending(true);
      setSavedIce(ice); setSavedMor(mor); setSavedCache(cache);
      setSavedSortRows(sortRows);
    } catch (e: any) {
      setErr(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }, [ice, mor, cache, sortRows]);

  // BF-275: row-level edit handlers
  const updateSortRow = (idx: number, patch: Partial<SortOrderRow>) =>
    setSortRows(rs => rs.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  const addSortRow    = () => setSortRows(rs => [...rs, { table: '', columns: '' }]);
  const removeSortRow = (idx: number) => setSortRows(rs => rs.filter((_, i) => i !== idx));

  return (
    <Paper sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <StorageIcon color="primary" />
        <Typography variant="h6">Iceberg &amp; S3 Cache</Typography>
        {loading && <CircularProgress size={18} sx={{ ml: 'auto' }} />}
        <Tooltip title="Reload from backend">
          <span>
            <Button size="small" startIcon={<RefreshIcon />} onClick={load}
              disabled={loading || saving} sx={{ ml: 'auto' }}>Reload</Button>
          </span>
        </Tooltip>
      </Box>

      {err && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setErr(null)}>{err}</Alert>}
      {msg && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setMsg(null)}>{msg}</Alert>}
      {restartPending && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Changes saved to <code>config.json</code>. <strong>Backend restart required</strong> for
          the new values to take effect on cached engine instances.
        </Alert>
      )}

      {/* ── Iceberg Merge-on-Read (delete files) ─────────────────────── */}
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
        Merge-on-Read · Delete File Support
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Turn ON if your Iceberg tables receive UPDATE / DELETE / MERGE
        operations (V2 tables with equality or position delete files).
        Off → COUNT(DISTINCT) and aggregations return rows that have been
        logically deleted. On → queries are slower but correct.
      </Typography>
      <FormControlLabel
        control={<Switch checked={mor.enabled}
          onChange={e => setMor({ ...mor, enabled: e.target.checked })} />}
        label={<Box>
          <Typography variant="body2" fontWeight={600}>
            Apply delete files to query results
          </Typography>
          <Typography variant="caption" color="text.secondary">
            iceberg_mor.enabled
          </Typography>
        </Box>}
      />

      <Divider sx={{ my: 3 }} />

      {/* ── Iceberg metadata cache ─────────────────────────────────────── */}
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
        Metadata Cache
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Cache resolved <code>metadata.json</code> keys per table so we
        don't full-scan the <code>metadata/</code> prefix on every query.
        Set to 0 to disable caching.
      </Typography>
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, sm: 6 }}>
          <TextField
            label="metadata_cache_ttl_seconds"
            type="number"
            fullWidth size="small"
            value={ice.metadata_cache_ttl_seconds}
            onChange={e => setIce({ ...ice, metadata_cache_ttl_seconds: Number(e.target.value) || 0 })}
            helperText="0 = disabled · default 60"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6 }}>
          <TextField
            label="metadata_count_warn_threshold"
            type="number"
            fullWidth size="small"
            value={ice.metadata_count_warn_threshold}
            onChange={e => setIce({ ...ice, metadata_count_warn_threshold: Number(e.target.value) || 0 })}
            helperText="WARN log when metadata file count exceeds this"
          />
        </Grid>
      </Grid>

      <Divider sx={{ my: 3 }} />

      {/* ── S3 Local Cache (NFS) ───────────────────────────────────────── */}
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
        Persistent S3 File Cache (NFS)
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Enable to cache S3 files on local NFS so subsequent queries on
        the same files skip the S3 round-trip entirely. Iceberg data
        files are immutable — same key always resolves to byte-identical
        content — so a path-based cache is safe with no ETag check.
        Background scheduler evicts LRU when total size exceeds
        <code>max_size_gb</code>.
      </Typography>
      <Stack spacing={2}>
        <FormControlLabel
          control={<Switch checked={cache.enabled}
            onChange={e => setCache({ ...cache, enabled: e.target.checked })} />}
          label={<Box>
            <Typography variant="body2" fontWeight={600}>
              Enable persistent cache
            </Typography>
            <Typography variant="caption" color="text.secondary">
              s3_local_cache.enabled
            </Typography>
          </Box>}
        />
        <TextField
          label="cache_dir"
          fullWidth size="small"
          value={cache.cache_dir}
          onChange={e => setCache({ ...cache, cache_dir: e.target.value })}
          helperText="PVC-backed directory — must be writable by backend pod"
          disabled={!cache.enabled}
        />
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 4 }}>
            <TextField
              label="max_size_gb" type="number"
              fullWidth size="small"
              value={cache.max_size_gb}
              onChange={e => setCache({ ...cache, max_size_gb: Number(e.target.value) || 0 })}
              helperText="LRU evict above this"
              disabled={!cache.enabled}
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 4 }}>
            <TextField
              label="evict_interval_minutes" type="number"
              fullWidth size="small"
              value={cache.evict_interval_minutes}
              onChange={e => setCache({ ...cache, evict_interval_minutes: Number(e.target.value) || 0 })}
              helperText="LRU sweep frequency"
              disabled={!cache.enabled}
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 4 }}>
            <TextField
              label="min_free_disk_gb" type="number"
              fullWidth size="small"
              value={cache.min_free_disk_gb}
              onChange={e => setCache({ ...cache, min_free_disk_gb: Number(e.target.value) || 0 })}
              helperText="Skip writes when free disk &lt; this"
              disabled={!cache.enabled}
            />
          </Grid>
        </Grid>
      </Stack>

      <Divider sx={{ my: 3 }} />

      {/* ── Per-table sort order (Tier 2) ────────────────────────────── */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
        <SortIcon fontSize="small" sx={{ color: 'primary.main' }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          Per-Table Sort Order (Tier 2)
        </Typography>
      </Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        For each Iceberg table, list the columns to sort by at INSERT time
        (comma-separated). Sort-on-write makes file-level min/max ranges
        non-overlapping for the sort key, so range and equality queries
        prune from thousands of files to dozens. Most useful for
        <strong> secondary hot filters</strong> (columns that are NOT
        already partition columns — sorting inside a partition by the
        partition column is a no-op). Leave blank to disable sorting for
        a table. Empty rows are ignored on save.
      </Typography>
      <Stack spacing={1.5}>
        {sortRows.map((row, idx) => (
          <Box key={idx} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
            <TextField
              label="Table name"
              size="small"
              value={row.table}
              onChange={e => updateSortRow(idx, { table: e.target.value })}
              sx={{ flex: '0 0 240px' }}
              placeholder="e.g. fact_table"
            />
            <TextField
              label="Sort columns (comma-separated)"
              size="small"
              fullWidth
              value={row.columns}
              onChange={e => updateSortRow(idx, { columns: e.target.value })}
              placeholder="e.g. code, business_event, sap_company_id"
            />
            <Tooltip title="Remove this row">
              <span>
                <IconButton onClick={() => removeSortRow(idx)} size="small"
                  sx={{ mt: 0.5 }}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
          </Box>
        ))}
        <Box>
          <Button size="small" startIcon={<AddIcon />} onClick={addSortRow}>
            Add table
          </Button>
        </Box>
      </Stack>

      <Box sx={{ mt: 3, display: 'flex', gap: 1 }}>
        <Button
          variant="contained"
          startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon />}
          onClick={save}
          disabled={!dirty || saving || loading}
        >
          {saving ? 'Saving…' : 'Save'}
        </Button>
        <Button onClick={() => {
          setIce(savedIce); setMor(savedMor); setCache(savedCache);
          setSortRows(savedSortRows);
        }}
          disabled={!dirty || saving}>Discard</Button>
      </Box>
    </Paper>
  );
};

export default IcebergSection;
