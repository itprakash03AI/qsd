/**
 * Cache section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Shows cached results count, cache size, hit rate, and clear cache action.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, CircularProgress,
  LinearProgress, Stack,
} from '@mui/material';
import { DeleteSweep as ClearCacheIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { fmtSize } from './adminUtils';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const CacheSection: React.FC<Props> = ({ addNotification }) => {
  const [loading, setLoading] = useState(true);
  const [cache, setCache] = useState<any>(null);
  const [cacheBusy, setCacheBusy] = useState(false);

  const loadCache = useCallback(async () => {
    setLoading(true);
    try {
      const data = await safeFetch('/api/cache/stats');
      setCache(data);
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadCache(); }, [loadCache]);

  const handleClearCache = async () => {
    setCacheBusy(true);
    try {
      await safeFetch('/api/cache', { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Cache Cleared', message: 'Query result cache cleared' });
      loadCache();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Clear Failed', message: e.message });
    } finally { setCacheBusy(false); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button size="small"
          startIcon={cacheBusy ? <CircularProgress size={14} /> : <ClearCacheIcon />}
          variant="outlined" color="error" onClick={handleClearCache} disabled={cacheBusy}>
          Clear Cache
        </Button>
      </Box>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {cache && (
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          <StatCard label="Cached Results" value={cache.total_entries ?? cache.count ?? '\u2014'} />
          <StatCard label="Cache Size"
            value={fmtSize((cache.total_size_bytes ?? cache.size_bytes) || 0)} />
          <StatCard label="Hit Rate"
            value={cache.hit_rate != null ? `${Math.round(cache.hit_rate * 100)}%` : '\u2014'} />
        </Stack>
      )}
      {!loading && !cache && (
        <Typography variant="body2" color="text.secondary">Cache stats unavailable</Typography>
      )}
    </Paper>
  );
};

export default CacheSection;
