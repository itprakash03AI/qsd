import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Chip, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, FormControl, InputLabel, Select, MenuItem,
  Tooltip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  Collapse, Alert,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon } from '@mui/icons-material';
import api from '../../services/api';
import { toArray } from '../../utils/toArray';

const RLSAdminSection: React.FC = () => {
  const [reports, setReports]         = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [policies, setPolicies]       = useState<any[]>([]);
  const [loading, setLoading]         = useState(false);
  const [addOpen, setAddOpen]         = useState(false);
  const [form, setForm]               = useState({ column_name: '', operator: '=', value_template: '', description: '' });
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState('');

  useEffect(() => {
    api.listReports(false).then(r => setReports(toArray(r))).catch(() => {});  // BF-430E
  }, []);

  const loadPolicies = useCallback(async (reportId: number) => {
    setLoading(true);
    try { const res = await api.listRLSPolicies(reportId); setPolicies(res.policies || []); }
    finally { setLoading(false); }
  }, []);

  const handleSelectReport = (r: any) => {
    setSelectedReport(r);
    loadPolicies(r.id);
    setAddOpen(false);
    setError('');
  };

  const handleCreate = async () => {
    if (!form.column_name || !form.value_template) { setError('Column and value template are required'); return; }
    setSaving(true); setError('');
    try {
      await api.createRLSPolicy(selectedReport.id, form);
      setForm({ column_name: '', operator: '=', value_template: '', description: '' });
      setAddOpen(false);
      loadPolicies(selectedReport.id);
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  };

  const handleDelete = async (policyId: number) => {
    try { await api.deleteRLSPolicy(policyId); loadPolicies(selectedReport.id); }
    catch (e: any) { alert(e.message); }
  };

  const handleToggle = async (policy: any) => {
    try {
      await api.updateRLSPolicy(policy.id, { is_enabled: !policy.is_enabled });
      loadPolicies(selectedReport.id);
    } catch (e: any) { alert(e.message); }
  };

  const RLS_OPERATORS = ['=', '!=', 'IN', 'NOT IN', 'LIKE', '>', '<', '>=', '<='];

  return (
    <Box sx={{ display: 'flex', gap: 3, height: '100%' }}>
      {/* Report selector */}
      <Box sx={{ width: 260, flexShrink: 0 }}>
        <Typography variant="subtitle2" fontWeight={600} sx={{ mb: 1 }}>Select Report</Typography>
        <Paper variant="outlined" sx={{ overflow: 'hidden', maxHeight: 600, overflowY: 'auto' }}>
          {reports.length === 0 ? (
            <Typography variant="body2" color="text.secondary" sx={{ p: 2 }}>No reports found.</Typography>
          ) : reports.map((r: any) => (
            <Box key={r.id}
              onClick={() => handleSelectReport(r)}
              sx={{
                px: 2, py: 1.25, cursor: 'pointer', borderBottom: '1px solid', borderColor: 'divider',
                bgcolor: selectedReport?.id === r.id ? 'primary.50' : 'transparent',
                borderLeft: '3px solid',
                borderLeftColor: selectedReport?.id === r.id ? 'primary.main' : 'transparent',
                '&:hover': { bgcolor: 'action.hover' },
              }}
            >
              <Typography variant="body2" fontWeight={selectedReport?.id === r.id ? 600 : 400} noWrap>
                {r.name}
              </Typography>
            </Box>
          ))}
        </Paper>
      </Box>

      {/* Policy editor */}
      <Box sx={{ flex: 1 }}>
        {!selectedReport ? (
          <Typography variant="body2" color="text.secondary">Select a report to manage its RLS policies.</Typography>
        ) : (
          <>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
              <Typography variant="subtitle1" fontWeight={600}>{selectedReport.name}</Typography>
              <Chip label="Row-Level Security" size="small" color="warning" variant="outlined" sx={{ height: 20, fontSize: 10 }} />
              <Box sx={{ flex: 1 }} />
              <Button size="small" startIcon={<AddIcon />} variant="outlined" onClick={() => setAddOpen(v => !v)}>
                Add Policy
              </Button>
            </Box>

            {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}

            <Collapse in={addOpen}>
              <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
                <Typography variant="subtitle2" sx={{ mb: 1.5 }}>New RLS Policy</Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
                  <TextField label="Column name" size="small" value={form.column_name}
                    onChange={e => setForm(f => ({ ...f, column_name: e.target.value }))} sx={{ flex: '1 1 160px' }} />
                  <FormControl size="small" sx={{ flex: '0 0 120px' }}>
                    <InputLabel>Operator</InputLabel>
                    <Select value={form.operator} label="Operator"
                      onChange={e => setForm(f => ({ ...f, operator: e.target.value }))}>
                      {RLS_OPERATORS.map(op => <MenuItem key={op} value={op}>{op}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <TextField label="Value template" size="small" value={form.value_template}
                    onChange={e => setForm(f => ({ ...f, value_template: e.target.value }))}
                    placeholder="{username} or fixed value"
                    helperText="Use {username}, {role} tokens"
                    sx={{ flex: '1 1 200px' }} />
                  <TextField label="Description (optional)" size="small" value={form.description}
                    onChange={e => setForm(f => ({ ...f, description: e.target.value }))} sx={{ flex: '1 1 200px' }} />
                </Box>
                <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  <Button size="small" onClick={() => setAddOpen(false)}>Cancel</Button>
                  <Button size="small" variant="contained" onClick={handleCreate} disabled={saving}>
                    {saving ? <CircularProgress size={14} /> : 'Create Policy'}
                  </Button>
                </Box>
              </Paper>
            </Collapse>

            {loading ? <CircularProgress size={20} /> : policies.length === 0 ? (
              <Typography variant="body2" color="text.secondary">No RLS policies. This report shows all rows to all users.</Typography>
            ) : (
              <Paper variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Column</TableCell>
                      <TableCell>Operator</TableCell>
                      <TableCell>Value Template</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {policies.map((p: any) => (
                      <TableRow key={p.id}>
                        <TableCell><Typography variant="body2" fontFamily="monospace">{p.column_name}</Typography></TableCell>
                        <TableCell><Chip label={p.operator} size="small" variant="outlined" sx={{ height: 20, fontSize: 10 }} /></TableCell>
                        <TableCell><Typography variant="body2" fontFamily="monospace">{p.value_template}</Typography></TableCell>
                        <TableCell><Typography variant="caption" color="text.secondary">{p.description || '—'}</Typography></TableCell>
                        <TableCell>
                          <Chip
                            label={p.is_enabled ? 'Active' : 'Disabled'}
                            size="small" color={p.is_enabled ? 'success' : 'default'} variant="outlined"
                            sx={{ height: 20, fontSize: 10, cursor: 'pointer' }}
                            onClick={() => handleToggle(p)}
                          />
                        </TableCell>
                        <TableCell>
                          <Tooltip title="Delete policy">
                            <IconButton size="small" color="error" onClick={() => handleDelete(p.id)}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Paper>
            )}

            <Alert severity="info" sx={{ mt: 2 }} icon={false}>
              <Typography variant="caption">
                RLS policies inject WHERE clauses at query execution time.
                Use <code>{'{username}'}</code> and <code>{'{role}'}</code> tokens to filter by the current user's attributes.
              </Typography>
            </Alert>
          </>
        )}
      </Box>
    </Box>
  );
};

export default RLSAdminSection;
