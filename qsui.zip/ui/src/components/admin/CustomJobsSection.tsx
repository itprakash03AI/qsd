/**
 * BF-312 — Admin-defined custom periodic jobs.
 *
 * Lets admins schedule any of 4 safe job types on a cron expression
 * (cronmaker.com format).  Live preview of next 5 firings as the
 * cron is typed.  Test-run button to validate config without waiting
 * for the schedule.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControl, IconButton, InputLabel,
  MenuItem, Paper, Select, Stack, Switch, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { safeFetch } from '../../services/api/core';

interface CustomJob {
  id: number;
  name: string;
  description: string | null;
  job_type: 'webhook' | 'sql_query' | 'iceberg_sync' | 'cache_clear';
  parameters: Record<string, any>;
  cron_expression: string;
  enabled: boolean;
  last_run_at: string | null;
  last_status: 'ok' | 'error' | null;
  last_error: string | null;
  last_duration_seconds: number | null;
  last_output: string | null;
  next_run_at: string | null;
  run_count: number;
  error_count: number;
  created_by: string | null;
  created_at: string;
}

const JOB_TYPES = [
  { value: 'webhook',      label: 'Webhook (HTTP request)' },
  { value: 'sql_query',    label: 'Run SQL query' },
  { value: 'iceberg_sync', label: 'Force-sync Iceberg table' },
  { value: 'cache_clear',  label: 'Clear cache' },
];

const CACHE_TYPES = [
  { value: 'iceberg_snapshot', label: 'Iceberg snapshot cache' },
  { value: 'iceberg_manifest', label: 'Iceberg manifest cache (BF-298)' },
  { value: 'query_result',     label: 'Query result cache' },
  { value: 'partition',        label: 'Partition cache' },
  { value: 'schema',           label: 'Schema cache' },
];

const CRON_PRESETS = [
  { value: '*/5 * * * *',  label: 'Every 5 minutes' },
  { value: '0 * * * *',    label: 'Every hour' },
  { value: '0 */4 * * *',  label: 'Every 4 hours' },
  { value: '0 9 * * *',    label: 'Daily at 9:00 AM' },
  { value: '0 9 * * 1-5',  label: 'Weekdays at 9:00 AM' },
  { value: '0 0 * * 0',    label: 'Weekly on Sunday midnight' },
  { value: '0 0 1 * *',    label: 'Monthly on the 1st' },
];

interface FormState {
  id?: number;
  name: string;
  description: string;
  job_type: string;
  cron_expression: string;
  enabled: boolean;
  // Type-specific parameters
  url: string;
  method: string;
  headers: string;
  body: string;
  timeout_seconds: number;
  query_id: string;
  sql: string;
  connection_id: string;
  bucket: string;
  table_prefix: string;
  cache_type: string;
}

const blankForm: FormState = {
  name: '', description: '',
  job_type: 'webhook', cron_expression: '0 * * * *', enabled: true,
  url: '', method: 'POST', headers: '', body: '', timeout_seconds: 30,
  query_id: '', sql: '', connection_id: '',
  bucket: '', table_prefix: '',
  cache_type: 'iceberg_snapshot',
};

export default function CustomJobsSection() {
  const [jobs, setJobs] = useState<CustomJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState>({ ...blankForm });
  const [cronPreview, setCronPreview] = useState<{ valid: boolean; error?: string; next_runs?: string[] }>({ valid: true });

  const reload = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      const j: any = await safeFetch('/api/admin/custom-jobs');
      setJobs(j?.jobs || []);
    } catch (e) {
      setErr(`Failed to load: ${e}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);
  useEffect(() => {
    const t = setInterval(reload, 15_000);
    return () => clearInterval(t);
  }, [reload]);

  // Live cron preview as user types
  useEffect(() => {
    if (!open || !form.cron_expression) {
      setCronPreview({ valid: true });
      return;
    }
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const j: any = await safeFetch('/api/admin/custom-jobs/preview-cron', {
          method: 'POST',
          body: JSON.stringify({ cron_expression: form.cron_expression, count: 5 }),
        });
        if (!cancelled) setCronPreview(j || { valid: false });
      } catch (e) {
        if (!cancelled) setCronPreview({ valid: false, error: String(e) });
      }
    }, 400);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [open, form.cron_expression]);

  const openCreate = () => {
    setForm({ ...blankForm });
    setOpen(true);
  };

  const openEdit = (j: CustomJob) => {
    const p = j.parameters || {};
    setForm({
      id: j.id,
      name: j.name,
      description: j.description || '',
      job_type: j.job_type,
      cron_expression: j.cron_expression,
      enabled: j.enabled,
      url: String(p.url || ''),
      method: String(p.method || 'POST'),
      headers: typeof p.headers === 'object' ? JSON.stringify(p.headers, null, 2) : String(p.headers || ''),
      body: typeof p.body === 'object' ? JSON.stringify(p.body, null, 2) : String(p.body || ''),
      timeout_seconds: Number(p.timeout_seconds || 30),
      query_id: String(p.query_id || ''),
      sql: String(p.sql || ''),
      connection_id: String(p.connection_id || ''),
      bucket: String(p.bucket || ''),
      table_prefix: String(p.table_prefix || ''),
      cache_type: String(p.cache_type || 'iceberg_snapshot'),
    });
    setOpen(true);
  };

  const buildParameters = useMemo(() => () => {
    if (form.job_type === 'webhook') {
      let parsedHeaders: Record<string, string> | undefined;
      if (form.headers.trim()) {
        try { parsedHeaders = JSON.parse(form.headers); }
        catch { parsedHeaders = undefined; }  // backend will treat as raw string
      }
      let parsedBody: any = form.body;
      if (form.body.trim()) {
        try { parsedBody = JSON.parse(form.body); } catch { /* keep as string */ }
      }
      return {
        url: form.url.trim(),
        method: form.method,
        headers: parsedHeaders ?? (form.headers ? form.headers : undefined),
        body: parsedBody,
        timeout_seconds: Number(form.timeout_seconds) || 30,
      };
    }
    if (form.job_type === 'sql_query') {
      return {
        connection_id: Number(form.connection_id),
        ...(form.query_id ? { query_id: Number(form.query_id) } : {}),
        ...(form.sql      ? { sql: form.sql }                   : {}),
      };
    }
    if (form.job_type === 'iceberg_sync') {
      return {
        connection_id: Number(form.connection_id),
        bucket: form.bucket.trim(),
        table_prefix: form.table_prefix.trim(),
      };
    }
    if (form.job_type === 'cache_clear') {
      return { cache_type: form.cache_type };
    }
    return {};
  }, [form]);

  const save = useCallback(async () => {
    setBusy('save'); setErr(null); setMsg(null);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description || null,
        job_type: form.job_type,
        cron_expression: form.cron_expression.trim(),
        enabled: form.enabled,
        parameters: buildParameters(),
      };
      if (form.id) {
        await safeFetch(`/api/admin/custom-jobs/${form.id}`, {
          method: 'PUT', body: JSON.stringify(payload),
        });
        setMsg(`Updated "${form.name}"`);
      } else {
        await safeFetch('/api/admin/custom-jobs', {
          method: 'POST', body: JSON.stringify(payload),
        });
        setMsg(`Created "${form.name}"`);
      }
      setOpen(false);
      reload();
    } catch (e: any) {
      setErr(`Save failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  }, [form, buildParameters, reload]);

  const handleDelete = useCallback(async (j: CustomJob) => {
    if (!window.confirm(`Delete custom job "${j.name}"?`)) return;
    setBusy(`del-${j.id}`);
    try {
      await safeFetch(`/api/admin/custom-jobs/${j.id}`, { method: 'DELETE' });
      reload();
    } catch (e: any) {
      setErr(`Delete failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const handleRunNow = useCallback(async (j: CustomJob) => {
    setBusy(`run-${j.id}`); setErr(null); setMsg(null);
    try {
      const r: any = await safeFetch(`/api/admin/custom-jobs/${j.id}/run-now`, { method: 'POST' });
      const result = r?.result || {};
      if (result.status === 'ok') {
        setMsg(`Ran "${j.name}" in ${result.duration_seconds?.toFixed(2)}s — ok`);
      } else {
        setErr(`Run "${j.name}" returned error: ${result.error}`);
      }
      reload();
    } catch (e: any) {
      setErr(`Run failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const handleToggle = useCallback(async (j: CustomJob) => {
    setBusy(`tog-${j.id}`);
    try {
      await safeFetch(`/api/admin/custom-jobs/${j.id}`, {
        method: 'PUT',
        body: JSON.stringify({ enabled: !j.enabled }),
      });
      reload();
    } catch (e: any) {
      setErr(`Toggle failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Typography variant="h6">Custom Jobs (cron-scheduled)</Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Tooltip title="Refresh"><IconButton onClick={reload} disabled={loading}><RefreshIcon /></IconButton></Tooltip>
        <Button variant="contained" size="small" startIcon={<AddIcon />} onClick={openCreate}>
          New Job
        </Button>
      </Stack>

      <Typography variant="body2" sx={{ mb: 2, color: 'text.secondary' }}>
        Schedule one of four safe job types on a cron expression
        (<a href="https://cronmaker.com/" target="_blank" rel="noopener noreferrer">cronmaker.com</a> format).
        No arbitrary code execution &mdash; webhook / sql_query / iceberg_sync / cache_clear only.
      </Typography>

      {msg && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setMsg(null)}>{msg}</Alert>}
      {err && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setErr(null)}>{err}</Alert>}

      {loading && jobs.length === 0 ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}><CircularProgress size={28} /></Box>
      ) : jobs.length === 0 ? (
        <Alert severity="info">No custom jobs yet. Click <strong>New Job</strong> to create one.</Alert>
      ) : (
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Name / Type</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Cron</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Enabled</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Last run</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Next run</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Stats</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }} align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {jobs.map((j) => (
              <TableRow key={j.id} hover>
                <TableCell sx={{ fontSize: 11 }}>
                  <strong>{j.name}</strong>
                  <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                    {j.job_type}
                    {j.description ? ` · ${j.description}` : ''}
                  </Typography>
                </TableCell>
                <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>{j.cron_expression}</TableCell>
                <TableCell>
                  <Switch checked={j.enabled} size="small"
                           disabled={busy === `tog-${j.id}`}
                           onChange={() => handleToggle(j)} />
                </TableCell>
                <TableCell sx={{ fontSize: 11 }}>
                  {j.last_run_at ? (
                    <>
                      <Chip size="small" label={j.last_status || '—'}
                             color={j.last_status === 'ok' ? 'success' : 'error'}
                             sx={{ fontSize: 10, height: 18 }} />
                      <Typography variant="caption" sx={{ display: 'block' }}>
                        {new Date(j.last_run_at).toLocaleString()}
                        {j.last_duration_seconds != null ? ` · ${j.last_duration_seconds.toFixed(2)}s` : ''}
                      </Typography>
                      {j.last_error && (
                        <Tooltip title={j.last_error}>
                          <Typography variant="caption" sx={{ display: 'block', color: 'error.main', fontSize: 9 }}>
                            {j.last_error.slice(0, 50)}…
                          </Typography>
                        </Tooltip>
                      )}
                    </>
                  ) : <em>never</em>}
                </TableCell>
                <TableCell sx={{ fontSize: 11 }}>
                  {j.next_run_at ? new Date(j.next_run_at).toLocaleString() : '—'}
                </TableCell>
                <TableCell sx={{ fontSize: 11 }}>
                  {j.run_count} runs · {j.error_count} err
                </TableCell>
                <TableCell align="right">
                  <Tooltip title="Run now">
                    <span>
                      <IconButton size="small" color="success"
                                   disabled={busy === `run-${j.id}`}
                                   onClick={() => handleRunNow(j)}>
                        {busy === `run-${j.id}` ? <CircularProgress size={14} /> : <PlayArrowIcon fontSize="small" />}
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Edit">
                    <IconButton size="small" onClick={() => openEdit(j)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton size="small" color="error"
                                 disabled={busy === `del-${j.id}`}
                                 onClick={() => handleDelete(j)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* ───── Create / Edit dialog ───── */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{form.id ? 'Edit custom job' : 'New custom job'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" required fullWidth size="small"
                        value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <TextField label="Description" fullWidth size="small" multiline maxRows={2}
                        value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

            <FormControl size="small" fullWidth>
              <InputLabel>Job type</InputLabel>
              <Select label="Job type" value={form.job_type}
                       onChange={(e) => setForm({ ...form, job_type: e.target.value })}>
                {JOB_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
              </Select>
            </FormControl>

            {/* Cron with preset shortcuts + live preview */}
            <Box>
              <Stack direction="row" spacing={1} alignItems="center">
                <TextField label="Cron expression" fullWidth size="small"
                            value={form.cron_expression}
                            onChange={(e) => setForm({ ...form, cron_expression: e.target.value })}
                            placeholder="*/5 * * * *  (cronmaker.com format)"
                            error={!cronPreview.valid}
                            helperText={cronPreview.valid ? '5 fields: min hour day month dow' : cronPreview.error} />
                <FormControl size="small" sx={{ minWidth: 160 }}>
                  <InputLabel>Preset</InputLabel>
                  <Select label="Preset" value=""
                           onChange={(e) => setForm({ ...form, cron_expression: e.target.value })}>
                    {CRON_PRESETS.map(p => <MenuItem key={p.value} value={p.value}>{p.label}</MenuItem>)}
                  </Select>
                </FormControl>
              </Stack>
              {cronPreview.valid && cronPreview.next_runs && cronPreview.next_runs.length > 0 && (
                <Box sx={{ mt: 1, pl: 1, borderLeft: '2px solid', borderColor: 'success.main' }}>
                  <Typography variant="caption" sx={{ color: 'success.main', display: 'block', fontWeight: 600 }}>
                    Next 5 runs:
                  </Typography>
                  {cronPreview.next_runs.map((r, i) => (
                    <Typography key={i} variant="caption" sx={{ display: 'block', fontFamily: 'monospace' }}>
                      {new Date(r).toLocaleString()}
                    </Typography>
                  ))}
                </Box>
              )}
            </Box>

            {/* Type-specific parameters */}
            {form.job_type === 'webhook' && (
              <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 1 }}>
                  Webhook parameters
                </Typography>
                <Stack spacing={1.5}>
                  <TextField label="URL" required fullWidth size="small"
                              value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
                  <FormControl size="small" sx={{ width: 120 }}>
                    <InputLabel>Method</InputLabel>
                    <Select label="Method" value={form.method}
                             onChange={(e) => setForm({ ...form, method: e.target.value })}>
                      {['POST', 'GET', 'PUT', 'DELETE', 'PATCH'].map(m =>
                        <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <TextField label="Headers (JSON)" fullWidth size="small" multiline rows={2}
                              value={form.headers} onChange={(e) => setForm({ ...form, headers: e.target.value })}
                              placeholder='{"Authorization": "Bearer ..."}'
                              sx={{ fontFamily: 'monospace' }} />
                  <TextField label="Body (JSON or raw)" fullWidth size="small" multiline rows={3}
                              value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })}
                              sx={{ fontFamily: 'monospace' }} />
                  <TextField label="Timeout (seconds)" type="number" size="small" sx={{ width: 160 }}
                              value={form.timeout_seconds}
                              onChange={(e) => setForm({ ...form, timeout_seconds: Number(e.target.value) })} />
                </Stack>
              </Box>
            )}
            {form.job_type === 'sql_query' && (
              <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 1 }}>
                  SQL query parameters
                </Typography>
                <Stack spacing={1.5}>
                  <TextField label="Connection ID" type="number" required size="small"
                              value={form.connection_id}
                              onChange={(e) => setForm({ ...form, connection_id: e.target.value })} />
                  <TextField label="Saved Query ID (or leave empty + use SQL)" type="number" size="small"
                              value={form.query_id}
                              onChange={(e) => setForm({ ...form, query_id: e.target.value })} />
                  <TextField label="Inline SQL" fullWidth size="small" multiline rows={4}
                              value={form.sql} onChange={(e) => setForm({ ...form, sql: e.target.value })}
                              sx={{ fontFamily: 'monospace' }} />
                </Stack>
              </Box>
            )}
            {form.job_type === 'iceberg_sync' && (
              <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 1 }}>
                  Iceberg sync parameters
                </Typography>
                <Stack spacing={1.5}>
                  <TextField label="Connection ID" type="number" required size="small"
                              value={form.connection_id}
                              onChange={(e) => setForm({ ...form, connection_id: e.target.value })} />
                  <TextField label="Bucket" required fullWidth size="small"
                              value={form.bucket} onChange={(e) => setForm({ ...form, bucket: e.target.value })} />
                  <TextField label="Table prefix" required fullWidth size="small"
                              value={form.table_prefix}
                              onChange={(e) => setForm({ ...form, table_prefix: e.target.value })}
                              placeholder="warehouse/sales/fact_table/" />
                </Stack>
              </Box>
            )}
            {form.job_type === 'cache_clear' && (
              <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 1 }}>
                  Cache to clear
                </Typography>
                <FormControl size="small" fullWidth>
                  <InputLabel>Cache type</InputLabel>
                  <Select label="Cache type" value={form.cache_type}
                           onChange={(e) => setForm({ ...form, cache_type: e.target.value })}>
                    {CACHE_TYPES.map(c => <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>)}
                  </Select>
                </FormControl>
              </Box>
            )}

            <Stack direction="row" alignItems="center" spacing={1}>
              <Switch checked={form.enabled}
                       onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
              <Typography variant="body2">Enabled (run on schedule)</Typography>
            </Stack>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)} disabled={busy === 'save'}>Cancel</Button>
          <Button variant="contained" onClick={save}
                   disabled={busy === 'save' || !form.name || !cronPreview.valid}>
            {busy === 'save' ? <CircularProgress size={16} /> : (form.id ? 'Save' : 'Create')}
          </Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}
