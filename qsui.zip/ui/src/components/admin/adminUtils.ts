/**
 * Shared formatting utilities for Admin panel sections.
 * Fetch is handled by safeFetch from services/api/core — single source of truth.
 */

export const fmtSize = (bytes: number) => {
  if (!bytes) return '0 B';
  const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${s[i]}`;
};

export const fmtMb = (mb: number) =>
  mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb} MB`;

export const fmtDate = (s: string) =>
  s ? new Date(s).toLocaleString() : '—';

export const fmtDuration = (secs: number) => {
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
};

export const WARN_SECS = 300;
export const AUDIT_PER_PAGE = 25;
