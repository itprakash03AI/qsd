import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Button, Alert, LinearProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  FormControl, InputLabel, Select, MenuItem, Stack,
} from '@mui/material';
import { History as HistoryIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

const AuditExplorerAdminSection: React.FC = () => {
  const [days, setDays]               = useState(7);
  const [username, setUsername]       = useState<string>('');
  const [summary, setSummary]         = useState<any[]>([]);
  const [distinct, setDistinct]       = useState<{ usernames: string[]; actions: string[]; resource_types: string[] }>({ usernames: [], actions: [], resource_types: [] });
  const [detailed, setDetailed]       = useState<any[]>([]);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = `?days=${days}${username ? `&username=${encodeURIComponent(username)}` : ''}`;
      const [sData, dData, stData] = await Promise.all([
        safeFetch(`/api/admin/audit-log/action-summary${qs}`),
        safeFetch(`/api/admin/audit-log/distinct-values?days=${Math.max(days, 30)}`),
        safeFetch(`/api/admin/usage-stats/detailed?days=${Math.min(days, 90)}`),
      ]);
      setSummary(sData?.summary || []);
      setDistinct(dData || { usernames: [], actions: [], resource_types: [] });
      setDetailed(stData?.rows || []);
    } catch (e: any) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }, [days, username]);

  useEffect(() => { load(); }, [load]);

  const exportCsv = () => {
    const header = 'action,count,last_seen';
    const rows = summary.map(r => `${r.action},${r.count},${r.last_seen || ''}`);
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `audit-summary-${days}d.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const maxCount = Math.max(1, ...summary.map((r: any) => r.count || 0));

  return (
    <Box sx={{ p: 1 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'wrap' }}>
        <HistoryIcon color="action" />
        <Typography variant="h6" fontWeight={600}>Audit Explorer</Typography>
        <Box sx={{ flex: 1 }} />
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel>Days</InputLabel>
          <Select value={days} label="Days" onChange={e => setDays(Number(e.target.value))}>
            {[1, 7, 14, 30, 60, 90].map(d => <MenuItem key={d} value={d}>{d} days</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 180 }}>
          <InputLabel>User</InputLabel>
          <Select value={username} label="User" onChange={e => setUsername(String(e.target.value))}>
            <MenuItem value="">All users</MenuItem>
            {distinct.usernames.map(u => <MenuItem key={u} value={u}>{u}</MenuItem>)}
          </Select>
        </FormControl>
        <Button size="small" startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
        <Button size="small" variant="outlined" onClick={exportCsv} disabled={summary.length === 0}>
          Export CSV
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {/* Action summary bar chart */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
          Action Summary (last {days} days{username ? ` · ${username}` : ''})
        </Typography>
        {summary.length === 0 ? (
          <Typography variant="caption" color="text.disabled">No audit events in range</Typography>
        ) : (
          <Box>
            {summary.slice(0, 20).map((r: any) => (
              <Box key={r.action} sx={{ mb: 0.5 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.25 }}>
                  <Typography variant="caption" sx={{ fontFamily: 'monospace', minWidth: 200 }}>
                    {r.action}
                  </Typography>
                  <Box sx={{ flex: 1, height: 16, bgcolor: 'action.hover', borderRadius: 0.5, position: 'relative' }}>
                    <Box sx={{
                      position: 'absolute', top: 0, left: 0, bottom: 0,
                      width: `${(r.count / maxCount * 100).toFixed(1)}%`,
                      bgcolor: 'primary.main', borderRadius: 0.5,
                    }} />
                  </Box>
                  <Typography variant="caption" fontWeight={700} sx={{ minWidth: 60, textAlign: 'right' }}>
                    {r.count}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>
        )}
      </Paper>

      {/* Detailed per-user/per-day table */}
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
          Per-User Daily Executions (last {Math.min(days, 90)} days)
        </Typography>
        {detailed.length === 0 ? (
          <Typography variant="caption" color="text.disabled">No execution data</Typography>
        ) : (
          <TableContainer sx={{ maxHeight: 400 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600 }}>Date</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>User</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 600 }}>Executions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {detailed.map((r, i) => (
                  <TableRow key={i} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{r.date}</TableCell>
                    <TableCell>{r.username}</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 600 }}>{r.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>
    </Box>
  );
};

export default AuditExplorerAdminSection;
