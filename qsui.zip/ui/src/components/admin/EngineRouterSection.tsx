/**
 * BF-385 — Engine Router admin panel.
 * Configure routing rules between single / multi_worker / multi_pod / spark_connect.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, Stack, TextField, FormControlLabel, Switch,
  Alert, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Divider, Select, MenuItem, FormControl, InputLabel,
} from '@mui/material';
import api from '../../services/api';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const EngineRouterSection: React.FC<Props> = ({ addNotification }) => {
  const [config, setConfig] = useState<any>(null);
  const [editing, setEditing] = useState<{
    enabled: boolean;
    default_engine: string;
    rules: any[];
  }>({ enabled: true, default_engine: 'single', rules: [] });
  const [history, setHistory] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [testSql, setTestSql] = useState('SELECT date, SUM(price) FROM t GROUP BY date');
  const [testFileCount, setTestFileCount] = useState(500);
  const [testRowEst, setTestRowEst] = useState(0);
  const [testCrossSource, setTestCrossSource] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);

  const load = useCallback(async () => {
    try {
      const [c, h] = await Promise.all([
        api.getEngineRouterConfig().catch(() => null),
        api.getEngineRouterHistory(50).catch(() => ({ entries: [] })),
      ]);
      if (c) {
        setConfig(c);
        setEditing({
          enabled: c.enabled,
          default_engine: c.default_engine,
          rules: c.rules || [],
        });
      }
      setHistory((h as any).entries || []);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload: any = {};
      if (config && editing.enabled !== config.enabled) payload.enabled = editing.enabled;
      if (config && editing.default_engine !== config.default_engine) payload.default_engine = editing.default_engine;
      if (config && JSON.stringify(editing.rules) !== JSON.stringify(config.rules || [])) {
        payload.rules = editing.rules;
      }
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No changes', message: '' });
      } else {
        await api.setEngineRouterConfig(payload);
        addNotification({
          type: 'success', title: 'Config saved',
          message: `Updated: ${Object.keys(payload).join(', ')}`,
        });
        load();
      }
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Save failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const r = await api.testEngineRouter(testSql, testFileCount, testRowEst, testCrossSource);
      setTestResult(r);
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Test failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleUseDefaultRules = () => {
    if (config?.default_rules) {
      setEditing({ ...editing, rules: config.default_rules });
    }
  };

  const handleClearRules = () => {
    setEditing({ ...editing, rules: [] });
  };

  const engineColor: Record<string, any> = {
    single:        'default',
    multi_worker:  'info',
    multi_pod:     'primary',
    spark_connect: 'secondary',
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Engine Router</Typography>
        <Button size="small" variant="outlined" onClick={load}>Refresh</Button>
      </Box>

      <Alert severity="info" sx={{ mb: 2 }}>
        The router picks <strong>single</strong> / <strong>multi_worker</strong> (in-pod) /
        <strong> multi_pod</strong> (cross-pod) / <strong>spark_connect</strong> based on
        configurable rules. Rules are evaluated top-to-bottom; first match wins.
        When <em>rules</em> is empty, built-in defaults apply.
      </Alert>

      {/* Configuration */}
      <Typography variant="subtitle2" sx={{ mb: 1 }}>Configuration</Typography>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <FormControlLabel
          control={<Switch checked={editing.enabled}
                            onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })} />}
          label="Enabled"
        />
        <FormControl size="small" sx={{ width: 200 }}>
          <InputLabel>Default engine</InputLabel>
          <Select
            label="Default engine"
            value={editing.default_engine}
            onChange={(e) => setEditing({ ...editing, default_engine: e.target.value })}
          >
            {(config?.available_engines || ['single', 'multi_worker', 'multi_pod', 'spark_connect']).map((eng: string) => (
              <MenuItem key={eng} value={eng}>{eng}</MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button variant="contained" size="small" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : 'Save Config'}
        </Button>
      </Stack>

      {/* Rules editor — read-only for now; advanced users edit config.json */}
      <Box sx={{ mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1, gap: 1 }}>
          <Typography variant="subtitle2">Routing Rules</Typography>
          <Chip
            size="small"
            label={editing.rules.length > 0 ? `${editing.rules.length} custom` : 'using defaults'}
            color={editing.rules.length > 0 ? 'warning' : 'default'}
          />
          <Box sx={{ flex: 1 }} />
          <Button size="small" variant="outlined" onClick={handleUseDefaultRules}>
            Use defaults
          </Button>
          <Button size="small" variant="outlined" onClick={handleClearRules} color="warning">
            Clear (use defaults)
          </Button>
        </Box>
        {((editing.rules.length > 0 ? editing.rules : (config?.default_rules || []))).map((rule: any, i: number) => (
          <Paper key={i} variant="outlined" sx={{ p: 1.5, mb: 1, bgcolor: 'background.default' }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Typography variant="body2" sx={{ fontWeight: 600, minWidth: 30 }}>
                #{i + 1}
              </Typography>
              <Chip label={rule.name} size="small" />
              <Typography variant="caption" sx={{ color: 'text.secondary' }}>→</Typography>
              <Chip label={rule.engine} size="small" color={engineColor[rule.engine] || 'default'} />
              <Typography variant="caption" sx={{ ml: 1, flex: 1, color: 'text.secondary' }}>
                {rule.reason}
              </Typography>
            </Stack>
            <Box sx={{ mt: 0.5, ml: 4, fontSize: '0.7rem', fontFamily: 'monospace', color: 'text.secondary' }}>
              when: {JSON.stringify(rule.when || {})}
            </Box>
          </Paper>
        ))}
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* Test simulator */}
      <Typography variant="subtitle2" sx={{ mb: 1 }}>Test routing decision (dry-run)</Typography>
      <Stack direction="row" spacing={2} sx={{ mb: 1 }} alignItems="flex-start">
        <TextField
          label="SQL"
          size="small" multiline minRows={2} maxRows={5}
          value={testSql} onChange={(e) => setTestSql(e.target.value)}
          sx={{ flex: 1, fontFamily: 'monospace' }}
        />
        <TextField
          label="File count" size="small" type="number"
          value={testFileCount} onChange={(e) => setTestFileCount(Number(e.target.value))}
          sx={{ width: 110 }}
        />
        <TextField
          label="Row estimate" size="small" type="number"
          value={testRowEst} onChange={(e) => setTestRowEst(Number(e.target.value))}
          sx={{ width: 130 }}
        />
        <FormControlLabel
          control={<Switch checked={testCrossSource}
                            onChange={(e) => setTestCrossSource(e.target.checked)} />}
          label="Cross-source"
        />
        <Button variant="outlined" size="small" onClick={handleTest} disabled={testing}>
          {testing ? '...' : 'Test'}
        </Button>
      </Stack>
      {testResult && (
        <Alert severity="success" sx={{ mb: 2 }}>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <Chip label={`engine: ${testResult.engine}`} color={engineColor[testResult.engine] || 'default'} size="small" />
            <Chip label={`rule: ${testResult.rule || 'default'}`} size="small" />
            {testResult.is_splittable !== undefined && (
              <Chip label={`splittable: ${testResult.is_splittable ? 'yes' : 'no'}`} size="small" variant="outlined" />
            )}
            {testResult.multi_pod_pods > 0 && (
              <Chip label={`pods: ${testResult.multi_pod_pods}`} size="small" variant="outlined" />
            )}
            {testResult.spark_connect_ok && (
              <Chip label="spark ✓" size="small" variant="outlined" />
            )}
          </Stack>
          <Typography variant="caption" sx={{ display: 'block', mt: 1 }}>
            Reason: <code>{testResult.reason}</code>
          </Typography>
        </Alert>
      )}

      {/* Decision history */}
      {history.length > 0 && (
        <>
          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Recent Routing Decisions (last {history.length})
          </Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 320 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>When</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Engine</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Rule</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Files</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Rows Est.</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Reason</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {history.map((h: any, i: number) => {
                  const ts = h.timestamp ? new Date(h.timestamp * 1000) : null;
                  return (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: '0.75rem' }}>
                        {ts ? ts.toLocaleTimeString() : '—'}
                      </TableCell>
                      <TableCell>
                        <Chip label={h.engine} size="small" color={engineColor[h.engine] || 'default'} />
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', fontFamily: 'monospace' }}>{h.rule}</TableCell>
                      <TableCell align="right">{h.file_count?.toLocaleString?.() || 0}</TableCell>
                      <TableCell align="right">{h.row_estimate?.toLocaleString?.() || 0}</TableCell>
                      <TableCell sx={{ fontSize: '0.7rem', maxWidth: 320, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {h.reason}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </Paper>
  );
};

export default EngineRouterSection;
