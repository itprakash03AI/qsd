/**
 * BF-382 — Result Cache admin panel.
 * Self-contained: manages own state and data fetching.
 * Shows L1/L2 hit rates, entry counts, evictions; lets admin clear the
 * cache, invalidate single entries, toggle enabled, and tune size caps.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Button, Stack, TextField, FormControlLabel, Switch,
  Tooltip, IconButton, Alert, Divider, Chip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import api from '../../services/api';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface CacheConfig {
  enabled: boolean;
  cache_dir: string;
  max_entries_l1: number;
  max_size_gb_l2: number;
  default_ttl_seconds: number;
  max_result_mb: number;
  skip_patterns: string[];
}

const DEFAULT_CFG: CacheConfig = {
  enabled: false, cache_dir: '', max_entries_l1: 100, max_size_gb_l2: 10,
  default_ttl_seconds: 3600, max_result_mb: 100, skip_patterns: [],
};

const ResultCacheSection: React.FC<Props> = ({ addNotification }) => {
  const [stats, setStats] = useState<any>(null);
  const [entries, setEntries] = useState<any[]>([]);
  const [config, setConfig] = useState<CacheConfig>(DEFAULT_CFG);
  const [editing, setEditing] = useState<CacheConfig>(DEFAULT_CFG);
  const [saving, setSaving] = useState(false);
  const [newPattern, setNewPattern] = useState('');

  const load = useCallback(async () => {
    try {
      const [s, e, c] = await Promise.all([
        api.getResultCacheStats().catch(() => null),
        api.getResultCacheEntries(50).catch(() => ({ entries: [] })),
        api.getResultCacheConfig().catch(() => DEFAULT_CFG),
      ]);
      setStats(s);
      setEntries(e.entries || []);
      setConfig(c as CacheConfig);
      setEditing(c as CacheConfig);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleClear = async () => {
    if (!window.confirm('Drop ALL cached results? This cannot be undone.')) return;
    try {
      const r = await api.clearResultCache();
      addNotification({
        type: 'success', title: 'Cache cleared',
        message: `Removed ${r.removed || 0} entries`,
      });
      load();
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Clear failed',
        message: e?.message || 'Unknown error',
      });
    }
  };

  const handleInvalidate = async (key: string) => {
    try {
      await api.invalidateResultCacheEntry(key);
      load();
    } catch { /* ignore */ }
  };

  const handleSaveConfig = async () => {
    setSaving(true);
    try {
      const payload: Partial<CacheConfig> = {};
      (Object.keys(editing) as (keyof CacheConfig)[]).forEach((k) => {
        if (JSON.stringify(editing[k]) !== JSON.stringify(config[k])) {
          (payload as any)[k] = editing[k];
        }
      });
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No changes', message: '' });
      } else {
        await api.setResultCacheConfig(payload);
        addNotification({
          type: 'success', title: 'Config saved',
          message: `Updated: ${Object.keys(payload).join(', ')}`,
        });
        load();
      }
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Save failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setSaving(false);
    }
  };

  const hitRate = stats?.l1_hit_rate != null
    ? `${(Number(stats.l1_hit_rate) * 100).toFixed(1)}%`
    : '—';

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Result Cache (Option D)</Typography>
        <Stack direction="row" spacing={1}>
          <Button size="small" variant="outlined" onClick={load}>Refresh</Button>
          <Button size="small" variant="outlined" color="warning" onClick={handleClear}
                  disabled={!stats?.enabled}>
            Clear All
          </Button>
        </Stack>
      </Box>

      {!stats?.enabled && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Result cache is disabled. Enable it below to start caching repeat-query
          results. Cached results return in &lt;50ms instead of re-executing.
        </Alert>
      )}

      {stats?.enabled && (
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 3 }}>
          <StatCard label="L1 Entries" value={stats.l1_entries ?? '—'} />
          <StatCard label="L2 Entries" value={stats.l2_entries ?? '—'} />
          <StatCard label="L1 Hit Rate" value={hitRate} />
          <StatCard label="L1 Hits" value={stats.l1_hits ?? 0} />
          <StatCard label="L2 Hits" value={stats.l2_hits ?? 0} />
          <StatCard label="L1 Evictions" value={stats.evictions_l1 ?? 0} />
          <StatCard label="L2 Evictions" value={stats.evictions_l2 ?? 0} />
          <StatCard label="Rejected (too big)" value={stats.rejected_too_big ?? 0} />
          <StatCard label="L2 Size (MB)"
                    value={stats.l2_size_bytes ? Math.round(stats.l2_size_bytes / 1024 / 1024) : 0} />
        </Stack>
      )}

      {/* Configuration */}
      <Typography variant="subtitle2" sx={{ mb: 1, mt: 1 }}>Configuration</Typography>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <FormControlLabel
          control={
            <Switch
              checked={editing.enabled}
              onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })}
            />
          }
          label="Enabled"
        />
        <TextField
          label="Max L1 entries"
          size="small" type="number"
          value={editing.max_entries_l1}
          onChange={(e) => setEditing({ ...editing, max_entries_l1: Number(e.target.value) })}
          sx={{ width: 140 }}
        />
        <TextField
          label="Max L2 (GB)"
          size="small" type="number"
          value={editing.max_size_gb_l2}
          onChange={(e) => setEditing({ ...editing, max_size_gb_l2: Number(e.target.value) })}
          sx={{ width: 140 }}
          inputProps={{ step: 0.5 }}
        />
        <TextField
          label="Default TTL (s)"
          size="small" type="number"
          value={editing.default_ttl_seconds}
          onChange={(e) => setEditing({ ...editing, default_ttl_seconds: Number(e.target.value) })}
          sx={{ width: 140 }}
        />
        <TextField
          label="Max result size (MB)"
          size="small" type="number"
          value={editing.max_result_mb}
          onChange={(e) => setEditing({ ...editing, max_result_mb: Number(e.target.value) })}
          sx={{ width: 160 }}
        />
        <Button variant="contained" size="small" onClick={handleSaveConfig} disabled={saving}>
          {saving ? 'Saving...' : 'Save Config'}
        </Button>
      </Stack>

      {/* Skip patterns — regex strings that bypass the cache */}
      <Box sx={{ mb: 2 }}>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
          Skip patterns &mdash; regex strings. Queries matching any pattern bypass the cache
          (useful for tables that change frequently or contain time-sensitive data).
        </Typography>
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1 }}>
          {(editing.skip_patterns || []).map((p, i) => (
            <Chip
              key={`${p}-${i}`}
              label={p}
              size="small"
              onDelete={() => setEditing({
                ...editing,
                skip_patterns: editing.skip_patterns.filter((_, idx) => idx !== i),
              })}
              deleteIcon={<CloseIcon />}
              sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}
            />
          ))}
          {(editing.skip_patterns || []).length === 0 && (
            <Typography variant="caption" color="text.disabled">
              No skip patterns set
            </Typography>
          )}
        </Stack>
        <Stack direction="row" spacing={1}>
          <TextField
            label="Add pattern (regex)"
            size="small"
            value={newPattern}
            onChange={(e) => setNewPattern(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && newPattern.trim()) {
                setEditing({
                  ...editing,
                  skip_patterns: [...(editing.skip_patterns || []), newPattern.trim()],
                });
                setNewPattern('');
              }
            }}
            placeholder='e.g. ^SELECT.*sensitive_table'
            sx={{ flex: 1, fontFamily: 'monospace' }}
          />
          <Button
            variant="outlined"
            size="small"
            startIcon={<AddIcon />}
            onClick={() => {
              if (!newPattern.trim()) return;
              setEditing({
                ...editing,
                skip_patterns: [...(editing.skip_patterns || []), newPattern.trim()],
              });
              setNewPattern('');
            }}
          >
            Add
          </Button>
        </Stack>
      </Box>

      <Divider sx={{ mb: 2 }} />

      {/* Entry list */}
      {entries.length > 0 && (
        <Box sx={{ mt: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Recent Entries (newest first)
          </Typography>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Key</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>SQL</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Rows</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Size (KB)</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Hits</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">TTL (s)</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {entries.map((e: any) => (
                  <TableRow key={e.key} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>
                      {String(e.key || '').slice(0, 16)}…
                    </TableCell>
                    <TableCell sx={{ maxWidth: 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      <Tooltip title={e.sql || ''}>
                        <span>{(e.sql || '').slice(0, 80)}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="right">{e.row_count?.toLocaleString?.() || 0}</TableCell>
                    <TableCell align="right">
                      {e.size_bytes ? Math.round(e.size_bytes / 1024) : 0}
                    </TableCell>
                    <TableCell align="right">{e.hit_count || 0}</TableCell>
                    <TableCell align="right">
                      {e.ttl_remaining == null ? '∞' : e.ttl_remaining}
                    </TableCell>
                    <TableCell>
                      <IconButton size="small" color="error"
                                  onClick={() => handleInvalidate(e.key)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}
    </Paper>
  );
};

export default ResultCacheSection;
