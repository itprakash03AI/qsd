/**
 * BF-383 — Multi-Worker Query Execution admin panel.
 * Self-contained: shows dispatch stats + lets admin tune workers, file
 * thresholds, and executor mode.  All settings persist to config.json.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, Stack, TextField,
  FormControlLabel, Switch, Select, MenuItem, FormControl, InputLabel,
  Alert, Divider, Chip, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow,
} from '@mui/material';
import api from '../../services/api';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface MWConfig {
  enabled: boolean;
  max_workers: number;
  min_files_to_split: number;
  max_files_per_worker: number;
  fallback_on_error: boolean;
  executor_mode: 'thread' | 'subprocess';
  // Phase 141 / 143 — broadcast-JOIN knobs
  allow_broadcast_join: boolean;
  broadcast_max_rows: number;
  broadcast_max_small_files: number;
  // Phase 144 — partition-aligned JOIN
  allow_partition_aligned_join: boolean;
}

const DEFAULT_CFG: MWConfig = {
  enabled: false, max_workers: 4, min_files_to_split: 50,
  max_files_per_worker: 5000, fallback_on_error: true, executor_mode: 'thread',
  allow_broadcast_join: false, broadcast_max_rows: 10_000_000, broadcast_max_small_files: 50,
  allow_partition_aligned_join: false,
};

const MultiWorkerSection: React.FC<Props> = ({ addNotification }) => {
  const [stats, setStats] = useState<any>(null);
  const [config, setConfig] = useState<MWConfig>(DEFAULT_CFG);
  const [editing, setEditing] = useState<MWConfig>(DEFAULT_CFG);
  const [saving, setSaving] = useState(false);
  const [testSql, setTestSql] = useState('SELECT date, SUM(price) FROM t GROUP BY date');
  const [testFileCount, setTestFileCount] = useState(100);
  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [activeWorkers, setActiveWorkers] = useState<any[]>([]);

  const load = useCallback(async () => {
    try {
      const [c, s, h, w] = await Promise.all([
        api.getMultiWorkerConfig().catch(() => DEFAULT_CFG),
        api.getMultiWorkerStats().catch(() => null),
        api.getMultiWorkerHistory(50).catch(() => ({ entries: [] })),
        api.getMultiWorkerActive().catch(() => ({ workers: [] })),
      ]);
      setConfig(c as MWConfig);
      setEditing(c as MWConfig);
      setStats(s);
      setHistory((h as any).entries || []);
      setActiveWorkers((w as any).workers || []);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { load(); }, [load]);

  // BF-405: auto-refresh every 2s when any worker is in-flight, so the
  // live grid feels real-time without manual reload clicks.
  useEffect(() => {
    const inFlight = activeWorkers.some(
      w => w.state === 'starting' || w.state === 'setup' || w.state === 'running'
    );
    if (!inFlight) return;
    const id = setInterval(() => {
      api.getMultiWorkerActive()
        .then((w: any) => setActiveWorkers(w?.workers || []))
        .catch(() => {});
    }, 2000);
    return () => clearInterval(id);
  }, [activeWorkers]);

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const r = await api.testMultiWorkerSplit(testSql, testFileCount);
      setTestResult(r);
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Test failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload: Partial<MWConfig> = {};
      (Object.keys(editing) as (keyof MWConfig)[]).forEach((k) => {
        if (JSON.stringify(editing[k]) !== JSON.stringify(config[k])) {
          (payload as any)[k] = editing[k];
        }
      });
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No changes', message: '' });
      } else {
        await api.setMultiWorkerConfig(payload);
        addNotification({
          type: 'success', title: 'Config saved',
          message: `Updated: ${Object.keys(payload).join(', ')}`,
        });
        load();
      }
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Save failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Multi-Worker Query Execution (Option F)</Typography>
        <Button size="small" variant="outlined" onClick={load}>Refresh</Button>
      </Box>

      {!config.enabled && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Multi-worker dispatch is disabled. Enable below to split large queries
          (≥{config.min_files_to_split} files) across {config.max_workers} parallel DuckDB workers.
          JOINs, DISTINCT, window functions and ORDER BY without LIMIT fall back
          to single-worker automatically.
        </Alert>
      )}

      {/* Stats */}
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 3 }}>
        <StatCard label="Dispatches" value={stats?.submitted ?? 0} />
        <StatCard label="Succeeded" value={stats?.succeeded ?? 0} />
        <StatCard label="Failed" value={stats?.failed ?? 0} />
        <StatCard label="Fell Back" value={stats?.fell_back ?? 0} />
        <StatCard label="Worker Runs" value={stats?.total_worker_runs ?? 0} />
        <StatCard label="Worker OK" value={stats?.total_worker_ok ?? 0} />
        <StatCard label="Worker Fail" value={stats?.total_worker_fail ?? 0} />
      </Stack>

      {/* Configuration */}
      <Typography variant="subtitle2" sx={{ mb: 1, mt: 1 }}>Configuration</Typography>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <FormControlLabel
          control={
            <Switch
              checked={editing.enabled}
              onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })}
            />
          }
          label="Enabled"
        />
        <TextField
          label="Max workers"
          size="small" type="number"
          value={editing.max_workers}
          onChange={(e) => setEditing({ ...editing, max_workers: Number(e.target.value) })}
          sx={{ width: 140 }}
        />
        <TextField
          label="Min files to split"
          size="small" type="number"
          value={editing.min_files_to_split}
          onChange={(e) => setEditing({ ...editing, min_files_to_split: Number(e.target.value) })}
          sx={{ width: 160 }}
        />
        <TextField
          label="Max files per worker"
          size="small" type="number"
          value={editing.max_files_per_worker}
          onChange={(e) => setEditing({ ...editing, max_files_per_worker: Number(e.target.value) })}
          sx={{ width: 180 }}
        />
        <FormControl size="small" sx={{ width: 180 }}>
          <InputLabel>Executor mode</InputLabel>
          <Select
            label="Executor mode"
            value={editing.executor_mode}
            onChange={(e) => setEditing({ ...editing, executor_mode: e.target.value as 'thread' | 'subprocess' })}
          >
            <MenuItem value="thread">Thread (default)</MenuItem>
            <MenuItem value="subprocess">Subprocess (crash-isolated)</MenuItem>
          </Select>
        </FormControl>
        <FormControlLabel
          control={
            <Switch
              checked={editing.fallback_on_error}
              onChange={(e) => setEditing({ ...editing, fallback_on_error: e.target.checked })}
            />
          }
          label="Fallback on error"
        />
        <Button variant="contained" size="small" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : 'Save Config'}
        </Button>
      </Stack>

      <Alert severity="warning" sx={{ mt: 2, mb: 2 }}>
        <Typography variant="body2">
          <strong>Supported queries:</strong> SELECT/WHERE, COUNT/SUM/MIN/MAX/AVG, GROUP BY, HAVING (Phase 143-B).
          {' '}
          <strong>Falls back to single-worker:</strong> DISTINCT, window functions,
          ORDER BY without LIMIT, WITH/CTE, multi-table (unless broadcast-JOIN enabled below).
        </Typography>
      </Alert>

      {/* Phase 144 — partition-aligned JOIN admin control. */}
      <Box sx={{
        mt: 2, mb: 2, p: 2,
        bgcolor: 'background.default',
        border: 1, borderColor: 'divider', borderRadius: 1,
      }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          Partition-aligned JOIN (Phase 144) — big × big without Spark
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: 'block' }}>
          When BOTH JOINed tables share the same Hive partition columns AND data
          is co-located (related rows share partition values, e.g. fact + extension
          tables partitioned by the same date), this slices the file lists per
          partition tuple and gives ONE worker per tuple.  Each worker runs the
          full JOIN locally — no shuffle, no broadcast, no Spark needed.
        </Typography>
        <Typography variant="caption" color="warning.main" sx={{ mb: 1.5, display: 'block' }}>
          <strong>Correctness contract:</strong> related rows MUST share partition values.
          If your writer doesn't guarantee this (e.g. ingestion partitions by ingest_date
          not transaction_date), DO NOT enable — results would miss JOIN matches.
        </Typography>
        <FormControlLabel
          control={
            <Switch
              checked={editing.allow_partition_aligned_join}
              onChange={(e) => setEditing({ ...editing, allow_partition_aligned_join: e.target.checked })}
            />
          }
          label="Allow partition-aligned JOIN"
        />
      </Box>

      {/* Phase 141 / 143 — broadcast-JOIN admin controls.
          Previously you had to edit config.json + restart to flip these.
          allow_broadcast_join is the master switch for JOIN dispatch.
          The two thresholds classify which side is "small" enough to broadcast. */}
      <Box sx={{
        mt: 2, mb: 2, p: 2,
        bgcolor: 'background.default',
        border: 1, borderColor: 'divider', borderRadius: 1,
      }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          Broadcast-JOIN (Phase 141 / 143)
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: 'block' }}>
          Splits big × small INNER/LEFT/RIGHT JOIN queries: the big side's files
          fan out across workers, every worker reads the full small-table file list.
          GROUP BY and HAVING are supported via partial-aggregation rewrite + post-merge filter.
          Big × big JOINs are refused; if Spark Connect is enabled they auto-route there.
        </Typography>
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          <FormControlLabel
            control={
              <Switch
                checked={editing.allow_broadcast_join}
                onChange={(e) => setEditing({ ...editing, allow_broadcast_join: e.target.checked })}
              />
            }
            label="Allow broadcast-JOIN"
          />
          <TextField
            label="Broadcast max rows (small side)"
            size="small" type="number"
            value={editing.broadcast_max_rows}
            onChange={(e) => setEditing({ ...editing, broadcast_max_rows: Number(e.target.value) })}
            helperText="Row count above which a table is treated as 'big'"
            sx={{ width: 240 }}
            disabled={!editing.allow_broadcast_join}
          />
          <TextField
            label="Broadcast max small files"
            size="small" type="number"
            value={editing.broadcast_max_small_files}
            onChange={(e) => setEditing({ ...editing, broadcast_max_small_files: Number(e.target.value) })}
            helperText="File count cap on the small side"
            sx={{ width: 220 }}
            disabled={!editing.allow_broadcast_join}
          />
        </Stack>
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* Splittability tester */}
      <Typography variant="subtitle2" sx={{ mb: 1 }}>
        Test query splittability (dry-run)
      </Typography>
      <Typography variant="caption" color="text.secondary" sx={{ mb: 1, display: 'block' }}>
        Paste a SQL pattern + an approximate file count. The dispatcher will
        run <code>decide_split()</code> and report whether the query would fan
        out, the merge strategy, and the per-worker SQL.  No query is executed.
      </Typography>
      <Stack direction="row" spacing={2} sx={{ mb: 2 }} alignItems="flex-start">
        <TextField
          label="SQL"
          size="small"
          multiline
          minRows={2}
          maxRows={6}
          value={testSql}
          onChange={(e) => setTestSql(e.target.value)}
          sx={{ flex: 1, fontFamily: 'monospace' }}
        />
        <TextField
          label="File count"
          size="small" type="number"
          value={testFileCount}
          onChange={(e) => setTestFileCount(Number(e.target.value))}
          sx={{ width: 120 }}
        />
        <Button variant="outlined" size="small" onClick={handleTest} disabled={testing}>
          {testing ? 'Testing...' : 'Test'}
        </Button>
      </Stack>
      {/* BF-405: Live worker grid — visible while any chunk is in-flight */}
      {activeWorkers.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Divider sx={{ my: 2 }} />
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
            <Typography variant="subtitle2">
              Live Workers ({activeWorkers.length})
            </Typography>
            {activeWorkers.some(w => ['starting', 'setup', 'running'].includes(w.state)) && (
              <Chip size="small" color="info" label="auto-refresh 2s" />
            )}
          </Box>
          <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 280 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Dispatch</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Chunk</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>State</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Files</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Rows</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Elapsed</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Error</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {activeWorkers.map((w: any, i: number) => {
                  const stateColors: any = {
                    starting:  'default',
                    setup:     'info',
                    running:   'primary',
                    completed: 'success',
                    failed:    'error',
                    cancelled: 'warning',
                  };
                  return (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: '0.7rem', fontFamily: 'monospace', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {String(w.correlation_id || '').slice(0, 14)}…
                      </TableCell>
                      <TableCell align="right">#{w.chunk_index}</TableCell>
                      <TableCell>
                        <Chip size="small" color={stateColors[w.state] || 'default'} label={w.state} />
                      </TableCell>
                      <TableCell align="right">{w.files_count ?? '—'}</TableCell>
                      <TableCell align="right">{w.rows?.toLocaleString?.() ?? '—'}</TableCell>
                      <TableCell align="right">{w.elapsed_s?.toFixed?.(1)}s</TableCell>
                      <TableCell sx={{ fontSize: '0.7rem', color: 'error.main', maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {w.error || ''}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {/* Recent dispatch history */}
      {history.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Recent Dispatches (last {history.length})
          </Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 280 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>When</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Workers</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">OK/Fail</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Rows</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Elapsed</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Merge</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Note</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {history.map((h: any, i: number) => {
                  const ts = h.timestamp ? new Date(h.timestamp * 1000) : null;
                  const tsLabel = ts
                    ? ts.toLocaleTimeString() + ' ' + ts.toLocaleDateString()
                    : '—';
                  const color =
                    h.status === 'succeeded' ? 'success' :
                    h.status === 'fell_back' ? 'warning' : 'error';
                  return (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{tsLabel}</TableCell>
                      <TableCell>
                        <Chip size="small" color={color as any} label={h.status} />
                      </TableCell>
                      <TableCell align="right">{h.worker_count}</TableCell>
                      <TableCell align="right">{h.succeeded}/{h.failed}</TableCell>
                      <TableCell align="right">{h.rows?.toLocaleString?.() || 0}</TableCell>
                      <TableCell align="right">{h.elapsed_s?.toFixed?.(2) ?? '—'}s</TableCell>
                      <TableCell>{h.merge_strategy || '—'}</TableCell>
                      <TableCell sx={{ fontSize: '0.7rem', maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {h.fallback_reason || ''}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {testResult && (
        <Alert severity={testResult.splittable ? 'success' : 'warning'} sx={{ mb: 1 }}>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <Chip
              size="small"
              label={testResult.splittable ? 'Splittable' : 'Not splittable'}
              color={testResult.splittable ? 'success' : 'warning'}
            />
            {testResult.splittable && (
              <>
                <Chip size="small" label={`Chunks: ${testResult.chunk_count}`} />
                <Chip size="small" label={`Merge: ${testResult.merge_strategy}`} />
                {testResult.needs_fallback && (
                  <Chip size="small" color="warning"
                        label="Nested AVG → would fall back" />
                )}
              </>
            )}
          </Stack>
          {testResult.skip_reason && (
            <Typography variant="caption" sx={{ mt: 1, display: 'block' }}>
              Reason: <code>{testResult.skip_reason}</code>
            </Typography>
          )}
          {testResult.splittable && testResult.partial_sql && testResult.partial_sql !== testSql && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="caption" color="text.secondary">
                Per-worker SQL (after AVG rewrite):
              </Typography>
              <Box component="pre" sx={{
                fontSize: '0.7rem', m: 0, mt: 0.5, p: 1, bgcolor: 'background.paper',
                borderRadius: 0.5, overflow: 'auto', maxHeight: 120,
              }}>
                {testResult.partial_sql}
              </Box>
            </Box>
          )}
        </Alert>
      )}
    </Paper>
  );
};

export default MultiWorkerSection;
