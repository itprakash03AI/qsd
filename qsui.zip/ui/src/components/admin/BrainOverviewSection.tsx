/**
 * Brain Overview — consolidated dashboard for the entire pruning
 * brain.  Single endpoint, single refresh, all signals on one screen.
 *
 * Replaces the previously-scattered admin sections:
 *   * Pruning Health (cluster snapshot, alerts)
 *   * Iceberg Mirror (status counts, routing flag)
 *   * Output Gateway (stats)
 *   * Writer Advisor (top recommendations)
 *   * Column Stats Status (adaptive backpressure)
 *
 * + the new brain capabilities that didn't have UI:
 *   * BrainCoordinator pressure flag + decisions
 *   * CostModel per-table cached stats
 *   * SkewDetector signals
 *   * WorkloadForecaster predictions
 *   * PortalCredPrewarmer recent tick
 *   * Alerts dispatcher recent history
 *
 * Each individual page is still reachable via the existing nav
 * (for deep inspection); Brain Overview is the "everything at a
 * glance" surface.
 *
 * Endpoint used:
 *   GET /api/admin/brain/overview
 *   POST /api/admin/brain/coordinator/tick
 *   POST /api/admin/brain/portal-cred-prewarmer/tick
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  Tooltip, CircularProgress, Grid,
  Accordion, AccordionSummary, AccordionDetails,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as PlayIcon,
  HealthAndSafety as HealthIcon,
  ExpandMore as ExpandMoreIcon,
  TrendingUp as TrendingUpIcon,
  Speed as SpeedIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface BrainOverview {
  computed_at: string;
  coordinator?: {
    current?: { pressure: string; updated_at: string | null };
    recent_reports?: any[];
    error?: string;
  };
  cost_model?: {
    tables?: any[];
    count?: number;
    cache_ttl_seconds?: number;
    min_observations?: number;
    error?: string;
  };
  skew?: {
    total?: number;
    top?: any[];
    error?: string;
  };
  forecaster?: {
    total?: number;
    top?: any[];
    error?: string;
  };
  writer_advisor?: {
    total?: number;
    top?: any[];
    error?: string;
  };
  pruning_health?: {
    window?: string;
    total_queries?: number;
    avg_prune_pct?: number;
    p95_prune_pct?: number;
    alerts?: any[];
    top_worst_tables?: any[];
    error?: string;
  };
  mirror?: {
    total?: number;
    by_status?: Record<string, number>;
    routing_on?: number;
    error?: string;
  };
  output_gateway?: any;
  supplement_backpressure?: any;
  portal_prewarmer?: {
    enabled?: boolean;
    recent?: any[];
    error?: string;
  };
  alerts?: {
    recent?: any[];
    error?: string;
  };
}


const pressureColor = (p: string): 'success' | 'warning' | 'default' => {
  if (p === 'high') return 'warning';
  if (p === 'low')  return 'success';
  return 'default';
};


const fmtPct = (n: number | null | undefined): string =>
  n == null ? '—' : `${n.toFixed(1)}%`;


const BrainOverviewSection: React.FC = () => {
  const [data, setData] = useState<BrainOverview | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [working, setWorking] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const r = await safeFetch('/api/admin/brain/overview',
                                  { timeoutMs: 60000 });
      setData(r as BrainOverview);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const tickCoordinator = useCallback(async () => {
    setWorking('coord');
    try {
      await safeFetch('/api/admin/brain/coordinator/tick',
                        { method: 'POST', timeoutMs: 30000 });
      await load();
    } catch (e: any) {
      alert(`Coordinator tick failed: ${e?.message || String(e)}`);
    } finally { setWorking(null); }
  }, [load]);

  const tickPrewarmer = useCallback(async () => {
    setWorking('prewarm');
    try {
      await safeFetch('/api/admin/brain/portal-cred-prewarmer/tick',
                        { method: 'POST', timeoutMs: 120000 });
      await load();
    } catch (e: any) {
      alert(`Pre-warmer tick failed: ${e?.message || String(e)}`);
    } finally { setWorking(null); }
  }, [load]);

  const pressure = data?.coordinator?.current?.pressure || 'unknown';

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <HealthIcon fontSize="small" />
        <Typography variant="h6">Brain Overview</Typography>
        <Chip size="small" color={pressureColor(pressure)}
              icon={pressure === 'high' ? <WarningIcon /> : <SpeedIcon />}
              label={`pressure: ${pressure}`} />
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<PlayIcon />} variant="outlined" size="small"
                onClick={tickCoordinator} disabled={!!working}>
          {working === 'coord' ? <CircularProgress size={14} /> : 'Coordinator tick'}
        </Button>
        <Button startIcon={<PlayIcon />} variant="outlined" size="small"
                onClick={tickPrewarmer} disabled={!!working}>
          {working === 'prewarm' ? <CircularProgress size={14} /> : 'Pre-warm portals'}
        </Button>
        <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                onClick={load} disabled={loading}>
          {loading ? <CircularProgress size={14} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {!data && loading && <CircularProgress />}
      {!data && !loading && !error && (
        <Alert severity="info">No data yet — click Refresh.</Alert>
      )}

      {data && (
        <Grid container spacing={2}>

          {/* Pruning Health */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Pruning Health · {data.pruning_health?.window || '24h'}
              </Typography>
              {data.pruning_health?.error ? (
                <Alert severity="warning">{data.pruning_health.error}</Alert>
              ) : (
                <>
                  <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
                    <Chip size="small" variant="outlined"
                          label={`avg ${fmtPct(data.pruning_health?.avg_prune_pct)}`} />
                    <Chip size="small" variant="outlined"
                          label={`p95 ${fmtPct(data.pruning_health?.p95_prune_pct)}`} />
                    <Chip size="small" variant="outlined"
                          label={`${(data.pruning_health?.total_queries ?? 0).toLocaleString()} queries`} />
                  </Stack>
                  {(data.pruning_health?.alerts?.length ?? 0) > 0 && (
                    <Alert severity="warning" sx={{ mb: 1 }}>
                      {data.pruning_health!.alerts!.length} table(s) degrading
                    </Alert>
                  )}
                  {(data.pruning_health?.top_worst_tables?.length ?? 0) > 0 && (
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        Top worst tables:
                      </Typography>
                      <ul style={{ margin: 0, paddingLeft: 18 }}>
                        {data.pruning_health!.top_worst_tables!.map((t: any, i: number) => (
                          <li key={i} style={{ fontSize: 12, fontFamily: 'monospace' }}>
                            {t.bucket}/{t.table_prefix} — avg {fmtPct(t.avg_prune_pct)}
                          </li>
                        ))}
                      </ul>
                    </Box>
                  )}
                </>
              )}
            </Paper>
          </Grid>

          {/* Mirror */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Iceberg Mirror (Phase 150)
              </Typography>
              {data.mirror?.error ? (
                <Alert severity="warning">{data.mirror.error}</Alert>
              ) : (
                <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap' }}>
                  <Chip size="small" variant="outlined"
                        label={`${data.mirror?.total ?? 0} mirrors`} />
                  <Chip size="small" color="success" variant="outlined"
                        label={`${data.mirror?.routing_on ?? 0} routing on`} />
                  {data.mirror?.by_status &&
                    Object.entries(data.mirror.by_status).map(([k, v]) => (
                      <Chip key={k} size="small" variant="outlined"
                            label={`${k}: ${v}`} />
                    ))}
                </Stack>
              )}
            </Paper>
          </Grid>

          {/* Writer Advisor */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Writer Advisor recommendations
              </Typography>
              {data.writer_advisor?.error ? (
                <Alert severity="warning">{data.writer_advisor.error}</Alert>
              ) : (
                <>
                  <Chip size="small" color="primary" variant="outlined"
                        label={`${data.writer_advisor?.total ?? 0} pending`} />
                  {(data.writer_advisor?.top?.length ?? 0) > 0 && (
                    <Box sx={{ mt: 1 }}>
                      {data.writer_advisor!.top!.map((r: any, i: number) => (
                        <Box key={i} sx={{ fontSize: 12, mb: 0.5 }}>
                          <Chip size="small" variant="outlined"
                                label={`${r.est_leverage_pct.toFixed(0)}%`}
                                color="success" sx={{ mr: 0.5 }} />
                          <code>{r.bucket}/{r.table_prefix}</code>
                          {' '} · {r.column}{' '}
                          <Chip size="small" variant="outlined" label={r.kind}
                                sx={{ ml: 0.5 }} />
                        </Box>
                      ))}
                    </Box>
                  )}
                </>
              )}
            </Paper>
          </Grid>

          {/* Forecaster */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Workload Forecaster
              </Typography>
              {data.forecaster?.error ? (
                <Alert severity="warning">{data.forecaster.error}</Alert>
              ) : (
                <>
                  <Chip size="small" color="primary" variant="outlined"
                        icon={<TrendingUpIcon />}
                        label={`${data.forecaster?.total ?? 0} predicted spikes (next 24h)`} />
                  {(data.forecaster?.top?.length ?? 0) > 0 && (
                    <Box sx={{ mt: 1 }}>
                      {data.forecaster!.top!.map((p: any, i: number) => (
                        <Typography key={i} variant="caption" sx={{ display: 'block' }}>
                          +{p.hours_ahead}h · <code>{p.bucket}/{p.table_prefix}</code> ·{' '}
                          {p.spike_ratio.toFixed(1)}× baseline
                        </Typography>
                      ))}
                    </Box>
                  )}
                </>
              )}
            </Paper>
          </Grid>

          {/* Skew signals */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Skew detector
              </Typography>
              {data.skew?.error ? (
                <Alert severity="warning">{data.skew.error}</Alert>
              ) : data.skew?.total === 0 ? (
                <Typography variant="caption" color="text.secondary">
                  No skew signals (or column_kind not yet populated in history)
                </Typography>
              ) : (
                <Box>
                  <Chip size="small" color="warning" variant="outlined"
                        label={`${data.skew?.total ?? 0} skew signals`} />
                  {data.skew?.top?.map((s: any, i: number) => (
                    <Typography key={i} variant="caption" sx={{ display: 'block' }}>
                      <code>{s.bucket}/{s.table_prefix}</code> · {s.column} —{' '}
                      {s.divergence_ratio}× baseline
                    </Typography>
                  ))}
                </Box>
              )}
            </Paper>
          </Grid>

          {/* Cost model */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Cost Model
              </Typography>
              {data.cost_model?.error ? (
                <Alert severity="warning">{data.cost_model.error}</Alert>
              ) : (
                <Stack direction="row" spacing={1}>
                  <Chip size="small" variant="outlined"
                        label={`${data.cost_model?.count ?? 0} tables cached`} />
                  <Chip size="small" variant="outlined"
                        label={`TTL ${data.cost_model?.cache_ttl_seconds ?? 0}s`} />
                  <Chip size="small" variant="outlined"
                        label={`min ${data.cost_model?.min_observations ?? 0} obs`} />
                </Stack>
              )}
            </Paper>
          </Grid>

          {/* Supplement backpressure */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Supplement scanner backpressure
              </Typography>
              {data.supplement_backpressure?.error ? (
                <Alert severity="warning">{data.supplement_backpressure.error}</Alert>
              ) : (
                <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap' }}>
                  <Chip size="small" variant="outlined"
                        label={`configured ${data.supplement_backpressure?.configured_max ?? 0}`} />
                  <Chip size="small" color="primary" variant="outlined"
                        label={`adaptive ${data.supplement_backpressure?.adaptive_max ?? 0}`} />
                  <Chip size="small" variant="outlined"
                        label={`avg ${(data.supplement_backpressure?.avg_per_file_seconds ?? 0).toFixed(3)}s/file`} />
                  <Chip size="small" variant="outlined"
                        label={`${data.supplement_backpressure?.samples_in_ring ?? 0} samples`} />
                </Stack>
              )}
            </Paper>
          </Grid>

          {/* Portal pre-warmer */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Portal cred pre-warmer
              </Typography>
              {data.portal_prewarmer?.error ? (
                <Alert severity="warning">{data.portal_prewarmer.error}</Alert>
              ) : (
                <>
                  <Chip size="small"
                        color={data.portal_prewarmer?.enabled ? 'success' : 'default'}
                        label={data.portal_prewarmer?.enabled ? 'enabled' : 'disabled'} />
                  {(data.portal_prewarmer?.recent?.length ?? 0) > 0 && (
                    <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                      Last tick: {data.portal_prewarmer!.recent![0].pre_warmed} warmed,{' '}
                      {data.portal_prewarmer!.recent![0].skipped_cached} cached,{' '}
                      {data.portal_prewarmer!.recent![0].errors} errors
                    </Typography>
                  )}
                </>
              )}
            </Paper>
          </Grid>

          {/* Alerts dispatcher */}
          <Grid size={{ xs: 12 }}>
            <Accordion>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography variant="subtitle2">
                  Alerts dispatcher (Phase 148.D) —{' '}
                  {data.alerts?.recent?.length ?? 0} recent
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                {data.alerts?.error ? (
                  <Alert severity="warning">{data.alerts.error}</Alert>
                ) : (data.alerts?.recent?.length ?? 0) === 0 ? (
                  <Typography variant="caption" color="text.secondary">
                    No alerts fired in recent history.
                  </Typography>
                ) : (
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Fired</TableCell>
                        <TableCell>Bucket / prefix</TableCell>
                        <TableCell>Δ pp</TableCell>
                        <TableCell>Channels</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {data.alerts!.recent!.map((a: any, i: number) => (
                        <TableRow key={i}>
                          <TableCell sx={{ fontSize: 12 }}>{a.fired_at?.slice(0, 19)}</TableCell>
                          <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                            {a.alert?.bucket}/{a.alert?.table_prefix}
                          </TableCell>
                          <TableCell>-{a.alert?.delta_pct_points?.toFixed(1)}pp</TableCell>
                          <TableCell>
                            {a.channels?.map((c: any, ci: number) => (
                              <Chip key={ci} size="small"
                                    color={c.ok ? 'success' : 'error'}
                                    label={c.channel} sx={{ mr: 0.5 }} />
                            ))}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </AccordionDetails>
            </Accordion>
          </Grid>

          {/* Coordinator decisions */}
          <Grid size={{ xs: 12 }}>
            <Accordion>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography variant="subtitle2">
                  Coordinator recent decisions ({data.coordinator?.recent_reports?.length ?? 0})
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                {data.coordinator?.error ? (
                  <Alert severity="warning">{data.coordinator.error}</Alert>
                ) : (data.coordinator?.recent_reports?.length ?? 0) === 0 ? (
                  <Typography variant="caption" color="text.secondary">
                    No coordinator ticks yet — first tick fires within{' '}
                    <code>brain_coordinator.cron_interval_minutes</code>.
                  </Typography>
                ) : (
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>When</TableCell>
                        <TableCell>Pressure</TableCell>
                        <TableCell>Avg s/file</TableCell>
                        <TableCell>Skew sig</TableCell>
                        <TableCell>Writer recs</TableCell>
                        <TableCell>Forecast hot</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {data.coordinator!.recent_reports!.map((r: any, i: number) => (
                        <TableRow key={i}>
                          <TableCell sx={{ fontSize: 12 }}>
                            {r.started_at?.slice(0, 19)}
                          </TableCell>
                          <TableCell>
                            <Chip size="small"
                                  color={pressureColor(r.pressure)}
                                  label={r.pressure} />
                          </TableCell>
                          <TableCell>{r.avg_per_file_seconds}</TableCell>
                          <TableCell>{r.skew_signals}</TableCell>
                          <TableCell>{r.writer_recommendations}</TableCell>
                          <TableCell>{r.forecast_hot_tables?.length ?? 0}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </AccordionDetails>
            </Accordion>
          </Grid>

        </Grid>
      )}
    </Box>
  );
};


export default BrainOverviewSection;
