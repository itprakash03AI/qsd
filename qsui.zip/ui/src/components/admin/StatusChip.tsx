import React from 'react';
import { Chip } from '@mui/material';
import { CheckCircle as OkIcon, Error as ErrIcon } from '@mui/icons-material';

interface StatusChipProps {
  ok: boolean;
  label?: string;
}

const StatusChip: React.FC<StatusChipProps> = ({ ok, label = '' }) => (
  <Chip
    size="small"
    icon={ok
      ? <OkIcon sx={{ fontSize: '14px !important' }} />
      : <ErrIcon sx={{ fontSize: '14px !important' }} />}
    label={label || (ok ? 'OK' : 'Error')}
    color={ok ? 'success' : 'error'}
    variant="outlined"
  />
);

export default StatusChip;
