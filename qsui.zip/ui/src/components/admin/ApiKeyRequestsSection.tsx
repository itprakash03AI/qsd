/**
 * Admin Panel — API Key Requests Approval Section
 *
 * Shows all pending/approved/denied API key requests with approve/deny actions.
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Box, Typography, Button, Table, TableHead, TableRow, TableCell,
  TableBody, Chip, Stack, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, CircularProgress, Alert, Tabs, Tab,
} from '@mui/material';
import {
  CheckCircle as ApproveIcon, Cancel as DenyIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { toArray } from '../../utils/toArray';

const ApiKeyRequestsSection: React.FC = () => {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState(0); // 0=pending, 1=approved, 2=denied, 3=all
  const [error, setError] = useState('');

  // Approve dialog
  const [approveReq, setApproveReq] = useState<any>(null);
  const [approveNote, setApproveNote] = useState('');
  const [approveRateLimit, setApproveRateLimit] = useState('');
  const [approveExpHours, setApproveExpHours] = useState('');
  const [approveSubmitting, setApproveSubmitting] = useState(false);
  const [approveResult, setApproveResult] = useState<{ raw_key: string } | null>(null);

  // Deny dialog
  const [denyReq, setDenyReq] = useState<any>(null);
  const [denyNote, setDenyNote] = useState('');
  const [denySubmitting, setDenySubmitting] = useState(false);

  // BF-124: View name lookup — resolve IDs to names
  const [viewMap, setViewMap] = useState<Record<number, string>>({});
  useEffect(() => {
    (async () => {
      try {
        const views = await api.listPublishedViews();
        const map: Record<number, string> = {};
        (Array.isArray(views) ? views : []).forEach((v: any) => { map[v.id] = v.name || v.slug; });
        setViewMap(map);
      } catch { /* non-critical */ }
    })();
  }, []);

  const resolveViewNames = useMemo(() => (ids: number[]) =>
    ids.map(id => viewMap[id] || `#${id}`).join(', '), [viewMap]);

  const statusMap = ['pending', 'approved', 'denied', undefined];

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      const status = statusMap[tab];
      const data = await api.listApiKeyRequests(status);
      setRequests(toArray(data));  // BF-430E
    } catch (err: any) {
      setError(err.message || 'Failed to load requests');
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => { loadRequests(); }, [loadRequests]);

  const handleApprove = async () => {
    if (!approveReq) return;
    setApproveSubmitting(true);
    try {
      const result = await api.approveApiKeyRequest(approveReq.id, {
        note: approveNote || undefined,
        rate_limit_override: approveRateLimit || undefined,
        expires_hours_override: approveExpHours ? Number(approveExpHours) : undefined,
      });
      setApproveResult({ raw_key: result.raw_key });
      loadRequests();
    } catch (err: any) {
      setError(err.message || 'Approve failed');
      setApproveReq(null);
    } finally {
      setApproveSubmitting(false);
    }
  };

  const handleDeny = async () => {
    if (!denyReq) return;
    setDenySubmitting(true);
    try {
      await api.denyApiKeyRequest(denyReq.id, { note: denyNote || undefined });
      setDenyReq(null);
      setDenyNote('');
      loadRequests();
    } catch (err: any) {
      setError(err.message || 'Deny failed');
      setDenyReq(null);
    } finally {
      setDenySubmitting(false);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" fontWeight={600}>API Key Requests</Typography>
        <Button startIcon={<RefreshIcon />} onClick={loadRequests} size="small">Refresh</Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab label="Pending" />
        <Tab label="Approved" />
        <Tab label="Denied" />
        <Tab label="All" />
      </Tabs>

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : requests.length === 0 ? (
        <Typography color="text.secondary" sx={{ py: 2 }}>No requests found.</Typography>
      ) : (
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell><strong>Requester</strong></TableCell>
              <TableCell><strong>Key Name</strong></TableCell>
              <TableCell><strong>Views</strong></TableCell>
              <TableCell><strong>Justification</strong></TableCell>
              <TableCell><strong>Status</strong></TableCell>
              <TableCell><strong>Date</strong></TableCell>
              <TableCell align="right"><strong>Actions</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {requests.map((r: any) => (
              <TableRow key={r.id}>
                <TableCell>{r.requested_by}</TableCell>
                <TableCell>{r.key_name}</TableCell>
                <TableCell>{resolveViewNames(r.scoped_view_ids || [])}</TableCell>
                <TableCell>
                  <Typography variant="caption" sx={{ maxWidth: 200, display: 'block', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.justification || '-'}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Chip label={r.status} size="small"
                    color={r.status === 'approved' ? 'success' : r.status === 'denied' ? 'error' : 'warning'} />
                </TableCell>
                <TableCell>
                  <Typography variant="caption">{r.created_at ? new Date(r.created_at).toLocaleDateString() : '-'}</Typography>
                </TableCell>
                <TableCell align="right">
                  {r.status === 'pending' && (
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <Button size="small" color="success" startIcon={<ApproveIcon />}
                        onClick={() => { setApproveReq(r); setApproveNote(''); setApproveRateLimit(''); setApproveExpHours(''); setApproveResult(null); }}>
                        Approve
                      </Button>
                      <Button size="small" color="error" startIcon={<DenyIcon />}
                        onClick={() => { setDenyReq(r); setDenyNote(''); }}>
                        Deny
                      </Button>
                    </Stack>
                  )}
                  {r.status === 'approved' && r.reviewed_by && (
                    <Typography variant="caption">by {r.reviewed_by}</Typography>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Approve Dialog */}
      <Dialog open={!!approveReq} onClose={() => !approveResult && setApproveReq(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Approve API Key Request</DialogTitle>
        <DialogContent>
          {approveResult ? (
            <Box sx={{ mt: 1 }}>
              <Alert severity="success" sx={{ mb: 2 }}>Request approved! The API key has been generated.</Alert>
              <TextField label="Raw API Key (copy now — shown once)" value={approveResult.raw_key} fullWidth size="small"
                InputProps={{ readOnly: true }} sx={{ fontFamily: 'monospace' }} />
            </Box>
          ) : approveReq && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Typography>Requester: <strong>{approveReq.requested_by}</strong></Typography>
              <Typography>Key: <strong>{approveReq.key_name}</strong></Typography>
              <Typography>Views: {resolveViewNames(approveReq.scoped_view_ids || [])}</Typography>
              {approveReq.justification && <Typography variant="body2">Justification: {approveReq.justification}</Typography>}
              <TextField label="Note (optional)" value={approveNote} onChange={e => setApproveNote(e.target.value)} fullWidth size="small" multiline rows={2} />
              <TextField label="Rate Limit Override" value={approveRateLimit} onChange={e => setApproveRateLimit(e.target.value)} size="small"
                placeholder={approveReq.rate_limit || 'Use requester value'} />
              <TextField label="Expiry Hours Override" value={approveExpHours} onChange={e => setApproveExpHours(e.target.value)} type="number" size="small"
                placeholder={approveReq.expires_hours ? String(approveReq.expires_hours) : 'No expiry'} />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setApproveReq(null); setApproveResult(null); }}>{approveResult ? 'Close' : 'Cancel'}</Button>
          {!approveResult && (
            <Button variant="contained" color="success" onClick={handleApprove} disabled={approveSubmitting}
              startIcon={approveSubmitting ? <CircularProgress size={14} /> : <ApproveIcon />}>
              Approve & Generate Key
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Deny Dialog */}
      <Dialog open={!!denyReq} onClose={() => setDenyReq(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Deny API Key Request</DialogTitle>
        <DialogContent>
          {denyReq && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Typography>Requester: <strong>{denyReq.requested_by}</strong></Typography>
              <Typography>Key: <strong>{denyReq.key_name}</strong></Typography>
              <TextField label="Reason for Denial (optional)" value={denyNote} onChange={e => setDenyNote(e.target.value)} fullWidth size="small" multiline rows={2} />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDenyReq(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDeny} disabled={denySubmitting}
            startIcon={denySubmitting ? <CircularProgress size={14} /> : <DenyIcon />}>
            Deny Request
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ApiKeyRequestsSection;
