/**
 * BF-600-st (2026-05-31) — Self-Test Diagnostics admin panel.
 *
 * Lets users (no curl, no auth header needed) run in-process self-tests
 * covering the BF-600 pruning fixes + system-level health checks.
 * Tests run in-memory against synthetic data — no S3, no real Iceberg
 * tables, no DuckDB connection (except the DuckDB engine self-test).
 * All complete in well under 1 second.
 *
 * Why it exists:
 *   Operators wanted to verify the pruning subsystem worked after
 *   deployment without setting up real data + sending shell commands.
 *   This panel renders one row per test with PASS/FAIL/duration; the
 *   "Run All" button refreshes the entire suite.
 */
import React, { useState, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, Stack, Chip, Alert,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  CircularProgress, Divider, Tooltip,
} from '@mui/material';
import {
  CheckCircleOutline as PassIcon,
  ErrorOutline as FailIcon,
  PlayArrow as RunIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { rawFetch } from '../../services/api/core';

interface SelfTestResult {
  id: string;
  name: string;
  status: 'pass' | 'fail' | 'skip';
  duration_ms: number;
  details?: string;
  error?: string;
  suite?: string;
}

interface SuiteResponse {
  suite?: string;
  timestamp: string;
  total: number;
  passed: number;
  failed: number;
  tests: SelfTestResult[];
}

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const SelfTestSection: React.FC<Props> = ({ addNotification }) => {
  const [results, setResults] = useState<SelfTestResult[]>([]);
  const [running, setRunning] = useState(false);
  const [lastRunAt, setLastRunAt] = useState<string | null>(null);
  const [summary, setSummary] = useState<{ passed: number; failed: number; total: number } | null>(null);

  const runSuite = useCallback(async (suite: 'pruning' | 'system' | 'all') => {
    setRunning(true);
    try {
      const url = suite === 'all'
        ? '/api/health/self-test'
        : `/api/health/self-test/${suite}`;
      const _r = await rawFetch(url);
      if (!_r.ok) throw new Error(`HTTP ${_r.status}`);
      const resp = await _r.json() as SuiteResponse;
      if (suite === 'all') {
        setResults(resp.tests);
      } else {
        // Replace just this suite's results, keep the others
        setResults((prev) => {
          const filtered = prev.filter((r) => !r.id.startsWith(`${suite}.`));
          const tagged = resp.tests.map((t) => ({ ...t, suite }));
          return [...filtered, ...tagged].sort((a, b) => a.id.localeCompare(b.id));
        });
      }
      setSummary({ passed: resp.passed, failed: resp.failed, total: resp.total });
      setLastRunAt(resp.timestamp);
      if (resp.failed > 0) {
        addNotification({
          type: 'warning',
          title: `${suite} self-test: ${resp.failed} failed`,
          message: `${resp.passed}/${resp.total} passed`,
        });
      } else {
        addNotification({
          type: 'success',
          title: `${suite} self-test: all ${resp.passed} passed`,
          message: `(${Math.round(resp.tests.reduce((s, t) => s + t.duration_ms, 0))}ms total)`,
        });
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Self-test failed to run',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setRunning(false);
    }
  }, [addNotification]);

  const renderStatus = (status: SelfTestResult['status']) => {
    if (status === 'pass') {
      return (
        <Chip
          size="small"
          color="success"
          icon={<PassIcon />}
          label="PASS"
          sx={{ fontWeight: 600 }}
        />
      );
    }
    if (status === 'fail') {
      return (
        <Chip
          size="small"
          color="error"
          icon={<FailIcon />}
          label="FAIL"
          sx={{ fontWeight: 600 }}
        />
      );
    }
    return <Chip size="small" variant="outlined" label="SKIP" />;
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Box>
          <Typography variant="h6">Self-Test Diagnostics</Typography>
          <Typography variant="caption" color="text.secondary">
            Runs in-memory tests for BF-600 pruning fixes + system health.
            No real data, no S3, no curl — runs in &lt;1 second.
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Tooltip title="Run only BF-600 pruning self-tests (BF-600a-g + L1-L4)">
            <Button
              size="small"
              variant="outlined"
              startIcon={<RunIcon />}
              onClick={() => runSuite('pruning')}
              disabled={running}
            >
              Pruning
            </Button>
          </Tooltip>
          <Tooltip title="Run system self-tests (DuckDB engine, DB ping, watchdog, etc.)">
            <Button
              size="small"
              variant="outlined"
              startIcon={<RunIcon />}
              onClick={() => runSuite('system')}
              disabled={running}
            >
              System
            </Button>
          </Tooltip>
          <Tooltip title="Run every self-test in both suites">
            <Button
              size="small"
              variant="contained"
              startIcon={running ? <CircularProgress size={16} color="inherit" /> : <RefreshIcon />}
              onClick={() => runSuite('all')}
              disabled={running}
            >
              {running ? 'Running…' : 'Run All'}
            </Button>
          </Tooltip>
        </Stack>
      </Box>

      {summary && (
        <Alert
          severity={summary.failed === 0 ? 'success' : 'error'}
          sx={{ mb: 2 }}
        >
          <strong>{summary.passed}/{summary.total} passed</strong>
          {summary.failed > 0 && (
            <Typography component="span" sx={{ ml: 2, fontWeight: 600 }}>
              · {summary.failed} FAILED — see rows below
            </Typography>
          )}
          {lastRunAt && (
            <Typography component="span" variant="caption" sx={{ ml: 2, color: 'text.secondary' }}>
              last run: {new Date(lastRunAt).toLocaleString()}
            </Typography>
          )}
        </Alert>
      )}

      {results.length === 0 && !running && (
        <Alert severity="info">
          Click <strong>Run All</strong> to execute the suite.
          Pruning tests cover BF-600a (boolean), BF-600b (NOT IN),
          BF-600d (case-insensitive), BF-600e (decimal precision),
          BF-600g (IS NOT NULL supplement), L1 (LIKE prefix),
          L2 (function-wrap extraction), L3 (NaN/Inf bounds),
          L4 (missing-column fail-open) + BF-599f httpfs prefix.
          System tests cover DuckDB engine, DB ping, per-worker memory,
          loop watchdog, and httpfs prefix round-trip.
        </Alert>
      )}

      {results.length > 0 && (
        <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 600 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 700, width: 90 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 700, width: 80 }}>Suite</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>Test</TableCell>
                <TableCell sx={{ fontWeight: 700, width: 100 }} align="right">Duration</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>Details / error</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {results.map((r) => {
                const suiteLabel = r.suite || r.id.split('.')[0];
                return (
                  <TableRow
                    key={r.id}
                    hover
                    sx={{
                      backgroundColor: r.status === 'fail'
                        ? 'rgba(239, 68, 68, 0.05)'
                        : undefined,
                    }}
                  >
                    <TableCell>{renderStatus(r.status)}</TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        variant="outlined"
                        label={suiteLabel}
                        sx={{ fontSize: '0.65rem' }}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>
                        {r.id}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {r.name}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                        {r.duration_ms.toFixed(2)} ms
                      </Typography>
                    </TableCell>
                    <TableCell sx={{ maxWidth: 380 }}>
                      <Typography
                        variant="caption"
                        sx={{
                          fontFamily: 'monospace',
                          fontSize: '0.7rem',
                          color: r.error ? 'error.main' : 'text.secondary',
                          whiteSpace: 'pre-wrap',
                          wordBreak: 'break-word',
                        }}
                      >
                        {r.error || r.details || ''}
                      </Typography>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Divider sx={{ my: 2 }} />
      <Typography variant="caption" color="text.secondary">
        Endpoints: <code>GET /api/health/self-test</code>,
        {' '}<code>/api/health/self-test/pruning</code>,
        {' '}<code>/api/health/self-test/system</code>.
        Any logged-in user may call; no admin role required.
      </Typography>
    </Paper>
  );
};

export default SelfTestSection;
