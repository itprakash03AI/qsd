/**
 * VPC + S3 Connectivity Check (Admin → VPC Check)
 *
 * UI wrapper around the same 6-layer probe that tools/qs_vpc_check.py
 * runs from the terminal.  Operators who can't kubectl exec into a pod
 * (e.g. on Windows / locked-down workstations) drive the diagnostic
 * from the browser instead.
 *
 * Two flows:
 *
 *   1. Free-form — type any bucket / region / vpce URL into the form.
 *      Used to probe a target BEFORE wiring up a saved Connection.
 *
 *   2. Run against saved Connection — pick from the dropdown of
 *      existing S3 connections; bucket / region / endpoint_url / creds
 *      are pulled server-side.  Used to triage a connection that's
 *      already producing errors elsewhere.
 *
 * The report renders the same PASS / FAIL / WARN status codes as the
 * CLI; each row carries a one-line cause and optional remediation
 * hint.  Exit-code analogue at the top: "X failure(s)".
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Card, CardContent, Chip, CircularProgress,
  Divider, FormControl, FormControlLabel, InputLabel, MenuItem,
  Select, Stack, Switch, TextField, Typography,
} from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import NetworkCheckIcon from '@mui/icons-material/NetworkCheck';
import { safeFetch } from '../../services/api/core';

interface VpcCheckResult {
  name:   string;
  status: 'pass' | 'fail' | 'warn' | 'info';
  detail: string;
  extra?: Record<string, any>;
}

interface VpcCheckReport {
  failures: number;
  results:  VpcCheckResult[];
  // Only present on /connection/{id} response:
  connection_id?:     number;
  bucket?:            string;
  region?:            string;
  vpc_endpoint?:      string | null;
  auth_mode?:         string;
  credentials_source?: string;  // 'config' / 'portal-resolved' / 'live-handler (iam_role)' / etc.
}

interface ConnectionRow {
  id: number;
  name: string;
  connection_type: string;
}

const STATUS_COLOR: Record<VpcCheckResult['status'], 'success' | 'error' | 'warning' | 'info'> = {
  pass: 'success',
  fail: 'error',
  warn: 'warning',
  info: 'info',
};

const VpcCheckSection: React.FC = () => {
  // ── Form state (free-form mode) ────────────────────────────────────
  const [bucket, setBucket]               = useState('');
  const [region, setRegion]               = useState('us-east-1');
  const [vpcEndpoint, setVpcEndpoint]     = useState('');
  const [proxy, setProxy]                 = useState('');
  const [profile, setProfile]             = useState('');
  const [noCreds, setNoCreds]             = useState(false);

  // ── Connection-mode state ──────────────────────────────────────────
  // resolvedFromConn: what the GET /api/connections/{id} actually
  // returned for the picked connection — surfaces in a caption below
  // the dropdown so the operator can SEE why a field is empty (e.g.
  // "the connection doesn't store an endpoint_url, blank is correct").
  const [conns, setConns]                 = useState<ConnectionRow[]>([]);
  const [resolvedFromConn, setResolvedFromConn] = useState<{
    bucket: string; region: string; endpoint_url: string;
    auth_mode: string; error?: string;
  } | null>(null);
  const [connsLoading, setConnsLoading]   = useState(false);
  const [selectedConnId, setSelectedConnId] = useState<number | ''>('');

  // ── Run / result state ─────────────────────────────────────────────
  const [running, setRunning]             = useState(false);
  const [report, setReport]               = useState<VpcCheckReport | null>(null);
  const [error, setError]                 = useState<string | null>(null);

  // Load saved S3 connections once on mount so the dropdown works.
  useEffect(() => {
    let alive = true;
    setConnsLoading(true);
    safeFetch('/api/connections')
      .then((rows: any) => {
        if (!alive) return;
        const list = Array.isArray(rows) ? rows : (rows?.connections || []);
        setConns(list.filter((c: any) => c?.connection_type === 's3'));
      })
      .catch(() => {
        // Non-fatal: dropdown stays empty, free-form mode still works.
      })
      .finally(() => alive && setConnsLoading(false));
    return () => { alive = false; };
  }, []);

  // When the operator picks a saved connection, pre-fill the form fields
  // BELOW so they can see what's about to be tested (bucket / region /
  // endpoint URL) and either run as-is or tweak before re-running.  Pre-
  // 2bc9de1 the form stayed empty until AFTER the report came back,
  // which was confusing — the operator couldn't tell which endpoint was
  // the "VPC URL".  GET /api/connections/{id} returns the same masked-
  // credentials config the connection editor uses (endpoint_url itself
  // is not sensitive — same field as "Custom Endpoint URL" in the
  // connection editor).
  useEffect(() => {
    if (!selectedConnId) {
      setResolvedFromConn(null);
      return;
    }
    let alive = true;
    setResolvedFromConn(null);
    safeFetch(`/api/connections/${selectedConnId}`)
      .then((conn: any) => {
        if (!alive) return;
        const cfg = conn?.config || {};
        const _bucket   = cfg.bucket_name || cfg.bucket || cfg.s3_bucket || '';
        const _region   = cfg.region_name || 'us-east-1';
        const _ep       = cfg.endpoint_url || '';
        const _auth     = cfg.auth_mode || '';
        if (_bucket) setBucket(_bucket);
        if (_region) setRegion(_region);
        // Set endpoint REGARDLESS — including blank.  Blank means the
        // connection uses the standard AWS S3 endpoint (no VPC URL on
        // record).  Without showing the blank state explicitly the
        // operator couldn't tell whether the fetch failed or the
        // connection just doesn't have a custom endpoint.
        setVpcEndpoint(_ep);
        setResolvedFromConn({
          bucket: _bucket, region: _region,
          endpoint_url: _ep, auth_mode: _auth,
        });
      })
      .catch((err: any) => {
        if (!alive) return;
        setResolvedFromConn({
          bucket: '', region: '', endpoint_url: '', auth_mode: '',
          error: err?.message || String(err),
        });
      });
    return () => { alive = false; };
  }, [selectedConnId]);

  const runFreeForm = useCallback(async () => {
    setRunning(true); setError(null); setReport(null);
    try {
      const body = {
        bucket, region,
        vpc_endpoint: vpcEndpoint || null,
        proxy:        proxy || null,
        profile:      profile || null,
        no_creds:     noCreds,
      };
      const r = await safeFetch('/api/admin/vpc-check', {
        method: 'POST', body: JSON.stringify(body),
      });
      setReport(r);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setRunning(false);
    }
  }, [bucket, region, vpcEndpoint, proxy, profile, noCreds]);

  const runConnection = useCallback(async () => {
    if (!selectedConnId) return;
    setRunning(true); setError(null); setReport(null);
    try {
      const r = await safeFetch(
        `/api/admin/vpc-check/connection/${selectedConnId}`,
        { method: 'POST' },
      );
      setReport(r);
      // Pre-fill the free-form fields with what the server resolved, so
      // the operator can tweak + re-run without retyping.
      if (r?.bucket) setBucket(r.bucket);
      if (r?.region) setRegion(r.region);
      if (r?.vpc_endpoint) setVpcEndpoint(r.vpc_endpoint);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setRunning(false);
    }
  }, [selectedConnId]);

  // ── Render ─────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3, maxWidth: 1100 }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 1 }}>
        <NetworkCheckIcon color="primary" />
        <Typography variant="h5" fontWeight={700}>VPC + S3 Connectivity Check</Typography>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Runs the same 6-layer probe as the bundled
        {' '}<code>tools/qs_vpc_check.py</code>{' '}
        CLI — environment, DNS resolution, raw HTTPS (direct + via
        proxy), boto3 <code>head_bucket</code> on the standard endpoint,
        same on the VPC endpoint, and an anonymous bucket-policy
        probe.  Results below.
      </Typography>

      {/* ── Mode A: existing connection ── */}
      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Run against a saved S3 connection
          </Typography>
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 2 }}>
            Picking a connection here fills the form below (bucket,
            region, endpoint URL) with the connection's stored values
            so you can see what's about to be tested.  Edit those
            fields if you want to probe a variation, or click
            <strong>{' '}Run on connection{' '}</strong>
            to test exactly as stored (credentials are resolved
            server-side — they never reach the browser).
          </Typography>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems="center">
            <FormControl size="small" sx={{ minWidth: 280 }}>
              <InputLabel id="vpc-conn-label">S3 Connection</InputLabel>
              <Select
                labelId="vpc-conn-label"
                label="S3 Connection"
                value={selectedConnId}
                onChange={(e) => setSelectedConnId(e.target.value as number)}
                disabled={connsLoading || running}
              >
                <MenuItem value=""><em>— select —</em></MenuItem>
                {conns.map(c => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.name} (#{c.id})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Button
              variant="contained"
              startIcon={running ? <CircularProgress size={16} /> : <PlayArrowIcon />}
              onClick={runConnection}
              disabled={!selectedConnId || running}
            >
              Run on connection
            </Button>
          </Stack>

          {/* Status of the GET /api/connections/{id} fetch — answers
              "why is the Custom Endpoint URL textbox empty?" by showing
              exactly what came back from the connection record. */}
          {resolvedFromConn && (
            <Box sx={{ mt: 2, p: 1.5, bgcolor: 'action.hover', borderRadius: 1 }}>
              {resolvedFromConn.error ? (
                <Alert severity="error" sx={{ mb: 0 }}>
                  Failed to load connection: {resolvedFromConn.error}
                </Alert>
              ) : (
                <Stack spacing={0.5} sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                  <Box><strong>Resolved from connection #{selectedConnId}:</strong></Box>
                  <Box>bucket = {resolvedFromConn.bucket || <em>(empty)</em>}</Box>
                  <Box>region = {resolvedFromConn.region || <em>(empty)</em>}</Box>
                  <Box>
                    endpoint_url = {resolvedFromConn.endpoint_url ||
                      <em style={{ color: '#888' }}>
                        (empty — this connection uses the standard AWS
                        S3 endpoint; no VPC URL on record.  Edit the
                        connection in Connections page and paste the
                        vpce-… URL into "Custom Endpoint URL" if you
                        want VPC routing.)
                      </em>}
                  </Box>
                  <Box>auth_mode = {resolvedFromConn.auth_mode || <em>(not set)</em>}</Box>
                </Stack>
              )}
            </Box>
          )}
        </CardContent>
      </Card>

      {/* ── Mode B: free-form ── */}
      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Or test an arbitrary target
          </Typography>
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 2 }}>
            Use this BEFORE wiring up a real connection, or to probe a
            different bucket / VPC endpoint than the one stored on a
            connection.
          </Typography>
          <Stack spacing={2}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
              <TextField
                label="Bucket" size="small" fullWidth
                placeholder="claude-eu-west-1"
                value={bucket} onChange={e => setBucket(e.target.value)}
              />
              <TextField
                label="Region" size="small" fullWidth
                placeholder="eu-west-1"
                value={region} onChange={e => setRegion(e.target.value)}
              />
            </Stack>
            <TextField
              label="Custom Endpoint URL (VPC vpce-… or S3-compatible)"
              size="small" fullWidth
              placeholder="https://vpce-0a1b2c3d4e5f1234.s3.eu-west-1.vpce.amazonaws.com"
              value={vpcEndpoint} onChange={e => setVpcEndpoint(e.target.value)}
              helperText={
                'Same field as "Custom Endpoint URL" in the Connection editor. ' +
                'Auto-filled from the selected connection above.  Blank = ' +
                'probe the public AWS S3 endpoint for the region.'
              }
            />
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
              <TextField
                label="Proxy URL (optional)" size="small" fullWidth
                placeholder="http://proxy.corp:8080"
                value={proxy} onChange={e => setProxy(e.target.value)}
                helperText="Blank = use server's HTTPS_PROXY env."
              />
              <TextField
                label="AWS Profile (optional)" size="small" fullWidth
                placeholder="default"
                value={profile} onChange={e => setProfile(e.target.value)}
                helperText="Blank = use server's IAM role / env creds."
              />
            </Stack>
            <FormControlLabel
              control={
                <Switch size="small" checked={noCreds}
                  onChange={e => setNoCreds(e.target.checked)} />
              }
              label="Skip boto3 auth — DNS + raw HTTPS only (useful when creds aren't in place yet)"
            />
            <Box>
              <Button
                variant="outlined"
                startIcon={running ? <CircularProgress size={16} /> : <PlayArrowIcon />}
                onClick={runFreeForm}
                disabled={!bucket || !region || running}
              >
                Run free-form check
              </Button>
            </Box>
          </Stack>
        </CardContent>
      </Card>

      {/* ── Error banner ── */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Request failed: {error}
        </Alert>
      )}

      {/* ── Report ── */}
      {report && (
        <Card variant="outlined">
          <CardContent>
            {/* Top-of-report Interpretation banner — boils the 12-line
                report down to the single most-likely root cause so the
                operator doesn't have to read every layer.  Priority
                (highest first):
                  1. input layer failure (bad bucket / fake vpce ID)
                  2. DNS failure
                  3. No-creds — boto3 auth blocked the test
                  4. Network firewall — all raw https failed
                  5. TLS cert mismatch — hit something but wrong cert
                  6. Bucket-policy gate — 403 from a reachable endpoint
                  7. Everything passed                                  */}
            {(() => {
              const rs = report.results || [];
              const has = (substr: string, status?: string) =>
                rs.some(r => r.name.toLowerCase().includes(substr.toLowerCase()) &&
                  (!status || r.status === status));
              const inputFail = rs.find(r => r.name.startsWith('input:') && r.status === 'fail');
              let severity: 'error' | 'warning' | 'success' = 'success';
              let title = 'Every test passed — VPC + S3 connectivity looks healthy.';
              let body = '';
              if (inputFail) {
                severity = 'error';
                title = 'Input is malformed — fix this before debugging the network.';
                body = inputFail.detail;
              } else if (has('FAILED to resolve', 'fail') || has('dns:', 'fail')) {
                severity = 'error';
                title = 'DNS resolution failed.';
                body = 'The hostname doesn\'t resolve from this pod.  Check VPC private DNS / Route 53 private zone, OR fix the URL.';
              } else if (rs.some(r => r.name.startsWith('boto3') && r.detail.includes('NoCredentialsError'))) {
                severity = 'warning';
                title = 'No AWS credentials — auth layers skipped.';
                body = 'Network layers (DNS + raw HTTPS) tested OK, but the connection has no creds.  Add keys, profile, or IAM role to test bucket access.';
              } else if (rs.filter(r => r.name.startsWith('raw https') && r.status === 'fail').length >= 2) {
                severity = 'error';
                title = 'All HTTPS reachability failed — network plumbing is the problem.';
                body = 'No raw TLS connection succeeded.  Likely firewall / Security Group blocks egress to S3 from this pod\'s subnet.';
              } else if (rs.some(r => r.detail.includes('CERTIFICATE_VERIFY_FAILED') || r.detail.includes('Hostname mismatch'))) {
                severity = 'error';
                title = 'TLS cert mismatch — your URL is hitting the wrong server.';
                body = 'A TCP+TLS handshake succeeded but the cert presented doesn\'t cover the hostname you asked for.  Usually means the vpce URL is wrong or a corporate HTTPS-interception proxy is in path.';
              } else if (rs.some(r => r.name.startsWith('boto3') && r.status === 'warn' && r.detail.includes('403'))) {
                severity = 'warning';
                title = 'Reached the bucket but got 403 — IAM / bucket policy blocks the action.';
                body = 'Network works; permissions don\'t.  Check the IAM principal and the bucket policy.';
              } else if (report.failures > 0) {
                severity = 'error';
                title = `${report.failures} failure(s) — see the rows below.`;
                body = 'Multiple layers failed without a single dominant cause.  Walk top to bottom.';
              }
              return (
                <Alert severity={severity} sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" fontWeight={700}>{title}</Typography>
                  {body && <Typography variant="body2" sx={{ mt: 0.5 }}>{body}</Typography>}
                </Alert>
              );
            })()}
            <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
              <Typography variant="h6" fontWeight={600}>Report</Typography>
              <Chip
                size="small"
                color={report.failures === 0 ? 'success' : 'error'}
                label={
                  report.failures === 0
                    ? 'every test passed'
                    : `${report.failures} failure(s)`
                }
              />
              {report.bucket && (
                <Chip size="small" variant="outlined"
                  label={`bucket=${report.bucket} region=${report.region}`} />
              )}
              {report.vpc_endpoint && (
                <Chip size="small" variant="outlined"
                  label={`vpc=${report.vpc_endpoint}`} />
              )}
              {report.auth_mode && (
                <Chip size="small" variant="outlined"
                  color="info"
                  label={`auth=${report.auth_mode}`} />
              )}
              {report.credentials_source && (
                <Chip size="small" variant="outlined"
                  color={
                    report.credentials_source === 'config' ? 'default'
                      : report.credentials_source.startsWith('live-handler') ? 'success'
                      : 'info'
                  }
                  label={`creds=${report.credentials_source}`} />
              )}
            </Stack>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={1}>
              {report.results.map((row, i) => (
                <Box key={i} sx={{
                  display: 'flex', alignItems: 'flex-start', gap: 1.5,
                  fontFamily: 'monospace', fontSize: 13,
                }}>
                  <Chip
                    size="small"
                    color={STATUS_COLOR[row.status]}
                    label={row.status.toUpperCase()}
                    sx={{ minWidth: 64, fontWeight: 700 }}
                  />
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ fontWeight: 600 }}>{row.name}</Box>
                    {row.detail && (
                      <Box sx={{
                        color: 'text.secondary',
                        whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                      }}>
                        {row.detail}
                      </Box>
                    )}
                  </Box>
                </Box>
              ))}
            </Stack>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default VpcCheckSection;
