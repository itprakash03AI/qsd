/**
 * Phase 134-F: Admin UI — S3 Performance Panel.
 * All S3 performance settings configurable from UI.
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Typography, Paper, TextField, Select, MenuItem, FormControl,
  FormControlLabel, Switch, Button, Alert, Divider, Grid, Chip,
  LinearProgress, InputLabel, Stack,
} from '@mui/material';
import {
  Speed as SpeedIcon, Storage as StorageIcon, Security as SecurityIcon,
  Refresh as RefreshIcon, DeleteSweep as ClearIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

interface S3PerfConfig {
  // Column pruning
  column_pruning_download: string;
  // Footer stats
  footer_stats_enabled: boolean;
  footer_stats_dir: string;
  footer_stats_ttl_hours: number;
  footer_stats_min_files_threshold: number;
  // Scan budget
  scan_budget_soft: number;
  scan_budget_hard: number;
  suggest_partitions: boolean;
  // File cache
  file_cache_enabled: boolean;
  file_cache_dir: string;
  file_cache_max_gb: number;
  file_cache_ttl_hours: number;
  file_cache_validate_etag: boolean;
  file_cache_eviction_interval_hours: number;
  // Estimate
  estimate_enabled: boolean;
  estimate_threshold: number;
  estimate_mode: string;
  // Quotas
  scan_quotas_enabled: boolean;
  scan_quota_analyst_hourly: number;
  scan_quota_analyst_daily: number;
  scan_quota_viewer_hourly: number;
  scan_quota_viewer_daily: number;
  // Circuit breaker
  circuit_breaker_enabled: boolean;
  circuit_breaker_threshold: number;
  circuit_breaker_window_seconds: number;
  circuit_breaker_cooldown_seconds: number;
  // Perf audit
  perf_audit_enabled: boolean;
  perf_audit_retention_days: number;
  // Encryption
  cache_encryption_enabled: boolean;
  // Degradation
  graceful_degradation_enabled: boolean;
  allow_partial_results: boolean;
  partial_result_threshold: number;
  // PV warmup
  warmup_enabled: boolean;
  warmup_interval_minutes: number;
  warmup_max_concurrent: number;
}

interface CacheStats {
  file_cache: { total_files: number; total_gb: number; max_gb: number; hit_rate: number; hits: number; misses: number };
  footer_stats: { entries: number; disk_mb: number };
  circuit_breakers: Record<string, string>;
}

const S3PerformanceSection: React.FC = () => {
  const [config, setConfig] = useState<S3PerfConfig | null>(null);
  const [stats, setStats] = useState<CacheStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const loadConfig = useCallback(async () => {
    try {
      setLoading(true);
      const data = await safeFetch('/api/admin/s3-performance/config');
      setConfig(data);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/s3-performance/stats');
      setStats(data);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadConfig(); loadStats(); }, [loadConfig, loadStats]);

  const save = async () => {
    if (!config) return;
    setSaving(true); setError(''); setSuccess('');
    try {
      await safeFetch('/api/admin/s3-performance/config', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      setSuccess('Settings saved');
      loadStats();
    } catch (e: any) { setError(e.message || 'Save failed'); }
    finally { setSaving(false); }
  };

  const clearCache = async (target: string) => {
    try {
      const body: Record<string, boolean> = {};
      if (target === 'file') body.file_cache = true;
      if (target === 'footer') body.footer_stats = true;
      if (target === 'all') { body.file_cache = true; body.footer_stats = true; }
      await safeFetch('/api/admin/s3-performance/clear-cache', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setSuccess(`Cache cleared (${target})`);
      loadStats();
    } catch (e: any) { setError(e.message); }
  };

  const upd = (key: keyof S3PerfConfig, val: any) => {
    if (config) setConfig({ ...config, [key]: val });
  };

  if (loading) return <LinearProgress />;
  if (!config) return <Alert severity="error">Failed to load config</Alert>;

  const fc = stats?.file_cache;
  const fs = stats?.footer_stats;

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
        <SpeedIcon /> S3 Performance Settings
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setError('')}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 1 }} onClose={() => setSuccess('')}>{success}</Alert>}

      {/* ── Cache Stats ── */}
      {stats && (
        <Paper sx={{ p: 2, mb: 2, bgcolor: 'action.hover' }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Live Cache Stats</Typography>
          <Grid container spacing={2}>
            {fc && (<>
              <Grid size={3}>
                <Typography variant="caption" color="text.secondary">File Cache</Typography>
                <Typography variant="body2">{fc.total_gb?.toFixed(1)} / {fc.max_gb} GB ({fc.total_files} files)</Typography>
              </Grid>
              <Grid size={3}>
                <Typography variant="caption" color="text.secondary">Hit Rate</Typography>
                <Typography variant="body2">{(fc.hit_rate * 100).toFixed(0)}% ({fc.hits} hits / {fc.misses} misses)</Typography>
              </Grid>
            </>)}
            {fs && (
              <Grid size={3}>
                <Typography variant="caption" color="text.secondary">Footer Stats</Typography>
                <Typography variant="body2">{fs.entries} entries ({fs.disk_mb?.toFixed(1)} MB)</Typography>
              </Grid>
            )}
            <Grid size={3}>
              <Stack direction="row" spacing={1}>
                <Button size="small" variant="outlined" startIcon={<ClearIcon />}
                  onClick={() => clearCache('file')}>Clear Files</Button>
                <Button size="small" variant="outlined" startIcon={<ClearIcon />}
                  onClick={() => clearCache('footer')}>Clear Stats</Button>
              </Stack>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* ── Column Download Strategy ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Column Download Strategy</Typography>
        <FormControl size="small" sx={{ minWidth: 250 }}>
          <InputLabel>Download Mode</InputLabel>
          <Select value={config.column_pruning_download} label="Download Mode"
            onChange={e => upd('column_pruning_download', e.target.value)}>
            <MenuItem value="auto">Auto (Recommended)</MenuItem>
            <MenuItem value="full">Full File</MenuItem>
            <MenuItem value="columns_only">Selected Columns Only</MenuItem>
          </Select>
        </FormControl>
      </Paper>

      {/* ── Scan Budget ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Scan Budget</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={3}>
            <TextField label="Soft Limit (warn)" type="number" size="small" fullWidth
              value={config.scan_budget_soft} onChange={e => upd('scan_budget_soft', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <TextField label="Hard Limit (block)" type="number" size="small" fullWidth
              value={config.scan_budget_hard} onChange={e => upd('scan_budget_hard', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <FormControlLabel label="Suggest Partitions" control={
              <Switch checked={config.suggest_partitions} onChange={e => upd('suggest_partitions', e.target.checked)} />
            } />
          </Grid>
        </Grid>
      </Paper>

      {/* ── Footer Stats Pruning ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Footer Stats Pruning</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={2}>
            <FormControlLabel label="Enabled" control={
              <Switch checked={config.footer_stats_enabled} onChange={e => upd('footer_stats_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={2}>
            <TextField label="Min Files Trigger" type="number" size="small" fullWidth
              value={config.footer_stats_min_files_threshold} onChange={e => upd('footer_stats_min_files_threshold', +e.target.value)} />
          </Grid>
          <Grid size={2}>
            <TextField label="Cache TTL (hours)" type="number" size="small" fullWidth
              value={config.footer_stats_ttl_hours} onChange={e => upd('footer_stats_ttl_hours', +e.target.value)} />
          </Grid>
          <Grid size={4}>
            <TextField label="Cache Directory" size="small" fullWidth
              value={config.footer_stats_dir} onChange={e => upd('footer_stats_dir', e.target.value)} />
          </Grid>
        </Grid>
      </Paper>

      {/* ── File Download Cache ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}><StorageIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />File Download Cache</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={2}>
            <FormControlLabel label="Enabled" control={
              <Switch checked={config.file_cache_enabled} onChange={e => upd('file_cache_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={2}>
            <TextField label="TTL (hours)" type="number" size="small" fullWidth
              value={config.file_cache_ttl_hours} onChange={e => upd('file_cache_ttl_hours', +e.target.value)} />
          </Grid>
          <Grid size={2}>
            <TextField label="Max Size (GB)" type="number" size="small" fullWidth
              value={config.file_cache_max_gb} onChange={e => upd('file_cache_max_gb', +e.target.value)} />
          </Grid>
          <Grid size={2}>
            <FormControlLabel label="Validate ETag" control={
              <Switch checked={config.file_cache_validate_etag} onChange={e => upd('file_cache_validate_etag', e.target.checked)} />
            } />
          </Grid>
          <Grid size={2}>
            <TextField label="Eviction Interval (hrs)" type="number" size="small" fullWidth
              value={config.file_cache_eviction_interval_hours} onChange={e => upd('file_cache_eviction_interval_hours', +e.target.value)} />
          </Grid>
        </Grid>
      </Paper>

      {/* ── Pre-Execution Estimate ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Pre-Execution Estimate</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={2}>
            <FormControlLabel label="Enabled" control={
              <Switch checked={config.estimate_enabled} onChange={e => upd('estimate_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={3}>
            <TextField label="File Threshold" type="number" size="small" fullWidth
              value={config.estimate_threshold} onChange={e => upd('estimate_threshold', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <FormControl size="small" fullWidth>
              <InputLabel>Mode</InputLabel>
              <Select value={config.estimate_mode} label="Mode"
                onChange={e => upd('estimate_mode', e.target.value)}>
                <MenuItem value="always">Always</MenuItem>
                <MenuItem value="threshold">Threshold</MenuItem>
                <MenuItem value="never">Never</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>

      {/* ── Scan Quotas ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Per-User Scan Quotas</Typography>
        <FormControlLabel label="Enabled" control={
          <Switch checked={config.scan_quotas_enabled} onChange={e => upd('scan_quotas_enabled', e.target.checked)} />
        } />
        {config.scan_quotas_enabled && (
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={3}>
              <TextField label="Analyst Hourly" type="number" size="small" fullWidth
                value={config.scan_quota_analyst_hourly} onChange={e => upd('scan_quota_analyst_hourly', +e.target.value)} />
            </Grid>
            <Grid size={3}>
              <TextField label="Analyst Daily" type="number" size="small" fullWidth
                value={config.scan_quota_analyst_daily} onChange={e => upd('scan_quota_analyst_daily', +e.target.value)} />
            </Grid>
            <Grid size={3}>
              <TextField label="Viewer Hourly" type="number" size="small" fullWidth
                value={config.scan_quota_viewer_hourly} onChange={e => upd('scan_quota_viewer_hourly', +e.target.value)} />
            </Grid>
            <Grid size={3}>
              <TextField label="Viewer Daily" type="number" size="small" fullWidth
                value={config.scan_quota_viewer_daily} onChange={e => upd('scan_quota_viewer_daily', +e.target.value)} />
            </Grid>
          </Grid>
        )}
      </Paper>

      {/* ── Circuit Breaker ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>S3 Circuit Breaker</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={2}>
            <FormControlLabel label="Enabled" control={
              <Switch checked={config.circuit_breaker_enabled} onChange={e => upd('circuit_breaker_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={2}>
            <TextField label="Failure Threshold" type="number" size="small" fullWidth
              value={config.circuit_breaker_threshold} onChange={e => upd('circuit_breaker_threshold', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <TextField label="Window (seconds)" type="number" size="small" fullWidth
              value={config.circuit_breaker_window_seconds} onChange={e => upd('circuit_breaker_window_seconds', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <TextField label="Cooldown (seconds)" type="number" size="small" fullWidth
              value={config.circuit_breaker_cooldown_seconds} onChange={e => upd('circuit_breaker_cooldown_seconds', +e.target.value)} />
          </Grid>
        </Grid>
        {stats?.circuit_breakers && Object.keys(stats.circuit_breakers).length > 0 && (
          <Box sx={{ mt: 1 }}>
            {Object.entries(stats.circuit_breakers).map(([connId, state]) => (
              <Chip key={connId} label={`Conn ${connId}: ${state}`} size="small" sx={{ mr: 0.5 }}
                color={state === 'closed' ? 'success' : state === 'open' ? 'error' : 'warning'} />
            ))}
          </Box>
        )}
      </Paper>

      {/* ── Enterprise ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}><SecurityIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />Enterprise</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={3}>
            <FormControlLabel label="Perf Audit Log" control={
              <Switch checked={config.perf_audit_enabled} onChange={e => upd('perf_audit_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={3}>
            <TextField label="Audit Retention (days)" type="number" size="small" fullWidth
              value={config.perf_audit_retention_days} onChange={e => upd('perf_audit_retention_days', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <FormControlLabel label="Cache Encryption" control={
              <Switch checked={config.cache_encryption_enabled} onChange={e => upd('cache_encryption_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={3}>
            <FormControlLabel label="Graceful Degradation" control={
              <Switch checked={config.graceful_degradation_enabled} onChange={e => upd('graceful_degradation_enabled', e.target.checked)} />
            } />
          </Grid>
        </Grid>
      </Paper>

      {/* ── PV Warm-Up ── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Published Views Warm-Up</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={2}>
            <FormControlLabel label="Enabled" control={
              <Switch checked={config.warmup_enabled} onChange={e => upd('warmup_enabled', e.target.checked)} />
            } />
          </Grid>
          <Grid size={3}>
            <TextField label="Interval (minutes)" type="number" size="small" fullWidth
              value={config.warmup_interval_minutes} onChange={e => upd('warmup_interval_minutes', +e.target.value)} />
          </Grid>
          <Grid size={3}>
            <TextField label="Max Concurrent" type="number" size="small" fullWidth
              value={config.warmup_max_concurrent} onChange={e => upd('warmup_max_concurrent', +e.target.value)} />
          </Grid>
        </Grid>
      </Paper>

      <Divider sx={{ my: 2 }} />
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => { loadConfig(); loadStats(); }}>Reload</Button>
        <Button variant="contained" onClick={save} disabled={saving}>
          {saving ? 'Saving...' : 'Save'}
        </Button>
      </Box>
    </Box>
  );
};

export default S3PerformanceSection;
