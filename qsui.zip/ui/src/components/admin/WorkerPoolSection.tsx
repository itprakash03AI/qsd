/**
 * Worker Pool monitoring + config section — extracted from AdminPage.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, LinearProgress, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, IconButton, Divider, Collapse, TextField, Button,
  CircularProgress,
} from '@mui/material';
import {
  Cancel as CancelIcon,
  Settings as SettingsIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Save as SaveIcon,
  AccessTime as DurationIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { fmtDuration } from './adminUtils';
import StatCard from './StatCard';
import StatusChip from './StatusChip';

/** Live duration ticker.  BF-465 hardening — pause on hidden tab. */
const LiveDuration: React.FC<{ seconds: number; warn: boolean }> = ({ seconds: initial, warn }) => {
  const [secs, setSecs] = useState(initial);
  const [visible, setVisible] = useState(
    typeof document === 'undefined' ? true : document.visibilityState !== 'hidden',
  );
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const onVis = () => setVisible(document.visibilityState !== 'hidden');
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);
  useEffect(() => {
    setSecs(initial);
    if (!visible) return;
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [initial, visible]);
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <DurationIcon sx={{ fontSize: 14, color: warn ? 'error.main' : 'text.secondary' }} />
      <Typography variant="body2" fontWeight={warn ? 700 : 400}
        color={warn ? 'error.main' : 'text.primary'}>
        {fmtDuration(secs)}
      </Typography>
    </Box>
  );
};

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const WorkerPoolSection: React.FC<Props> = ({ addNotification }) => {
  const [loading, setLoading] = useState(true);
  const [poolStats, setPoolStats] = useState<any>(null);
  const [poolTasks, setPoolTasks] = useState<any[]>([]);
  const [poolCfgOpen, setPoolCfgOpen] = useState(false);
  const [poolCfg, setPoolCfg] = useState<any>(null);
  const [poolCfgDraft, setPoolCfgDraft] = useState<any>({});
  const [poolCfgSaving, setPoolCfgSaving] = useState(false);

  const loadStats = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/worker-pool');
      setPoolStats(data);
      setPoolTasks(data.active_tasks || []);
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, []);

  const loadPoolConfig = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/worker-pool/config');
      setPoolCfg(data);
      const draft: any = {};
      if (data?.types) {
        for (const [typeName, cfg] of Object.entries(data.types) as any) {
          const prefix = typeName.toLowerCase();
          draft[`${prefix}_max_concurrent`] = cfg.max_concurrent;
          draft[`${prefix}_default_timeout`] = cfg.default_timeout;
          draft[`${prefix}_max_queue`] = cfg.max_queue;
        }
      }
      setPoolCfgDraft(draft);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadStats(); loadPoolConfig(); }, [loadStats, loadPoolConfig]);
  useEffect(() => {
    const t = setInterval(loadStats, 10_000);
    return () => clearInterval(t);
  }, [loadStats]);

  const updateDraft = (key: string, value: string) => {
    setPoolCfgDraft((prev: any) => ({ ...prev, [key]: value }));
  };

  const handlePoolCfgSave = async () => {
    setPoolCfgSaving(true);
    try {
      const changed: any = {};
      if (poolCfg?.types) {
        for (const [typeName, cfg] of Object.entries(poolCfg.types) as any) {
          const prefix = typeName.toLowerCase();
          for (const field of ['max_concurrent', 'default_timeout', 'max_queue']) {
            const key = `${prefix}_${field}`;
            const newVal = Number(poolCfgDraft[key]);
            if (!isNaN(newVal) && newVal !== cfg[field]) changed[key] = newVal;
          }
        }
      }
      if (Object.keys(changed).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'Configuration unchanged' });
        setPoolCfgSaving(false);
        return;
      }
      const result = await safeFetch('/api/admin/worker-pool/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changed),
      });
      addNotification({ type: 'success', title: 'Config Saved', message: `Applied ${Object.keys(result.changes || {}).length} change(s)` });
      await loadPoolConfig();
      loadStats();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Config Save Failed', message: e.message });
    } finally { setPoolCfgSaving(false); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {poolStats && (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Total Workers" value={poolStats.total_workers ?? '—'} />
            <StatCard label="Active" value={poolStats.active_total ?? 0}
              warn={(poolStats.active_total ?? 0) >= (poolStats.total_workers ?? 40)} />
            <StatCard label="Queued" value={poolStats.queued_total ?? 0}
              warn={(poolStats.queued_total ?? 0) > 0} />
          </Stack>
          {poolStats.by_type && (
            <TableContainer sx={{ mb: 1 }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Type', 'Running', 'Queued', 'Max', 'Completed', 'Failed', 'Timeout', 'Avg Wait', 'Avg Run'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.entries(poolStats.by_type).map(([type, s]: any) => (
                    <TableRow key={type} hover>
                      <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{type}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        <Chip size="small" label={s.running} color={s.running > 0 ? 'primary' : 'default'} sx={{ height: 20, fontSize: 11 }} />
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.queued > 0 ? <Chip size="small" label={s.queued} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.max_concurrent}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.completed}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.failed > 0 ? <Chip size="small" label={s.failed} color="error" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.timeout > 0 ? <Chip size="small" label={s.timeout} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_wait_ms > 0 ? `${s.avg_wait_ms}ms` : '—'}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_run_ms > 0 ? `${(s.avg_run_ms / 1000).toFixed(1)}s` : '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          {poolTasks.length > 0 && (
            <>
              <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mt: 1 }}>
                Active Tasks ({poolTasks.length})
              </Typography>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['Type', 'Execution', 'User', 'Status', 'Duration', 'Action'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {poolTasks.map((t: any) => (
                      <TableRow key={t.task_id} hover>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.work_type}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', fontFamily: 'monospace' }}>
                          {t.execution_id ? t.execution_id.substring(0, 8) + '…' : '—'}
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.username}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          <StatusChip ok={t.status === 'running'} label={t.status} />
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          {t.started_at ? <LiveDuration seconds={Math.round((Date.now() / 1000) - t.started_at)} warn={false} /> : '—'}
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          <IconButton size="small" color="error"
                            onClick={async () => {
                              try {
                                await safeFetch(`/api/admin/worker-pool/tasks/${t.task_id}/cancel`, { method: 'POST' });
                                loadStats();
                              } catch { /* silent */ }
                            }}>
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          )}

          <Divider sx={{ my: 1.5 }} />
          <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', gap: 0.5, py: 0.5 }}
            onClick={() => setPoolCfgOpen(o => !o)}>
            <SettingsIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ flex: 1 }}>
              Configure Limits
            </Typography>
            {poolCfgOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
          </Box>
          <Collapse in={poolCfgOpen}>
            {poolCfg ? (
              <Box sx={{ mt: 1 }}>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Type', 'Max Concurrent', 'Default Timeout (s)', 'Max Queue'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {['INTERACTIVE', 'REPORT', 'SCHEDULED', 'EXPORT', 'SYSTEM'].map(typeName => {
                        const prefix = typeName.toLowerCase();
                        return (
                          <TableRow key={typeName} hover>
                            <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{typeName}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_max_concurrent`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_max_concurrent`, e.target.value)}
                                inputProps={{ min: 1, max: 100, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                              />
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_default_timeout`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_default_timeout`, e.target.value)}
                                inputProps={{ min: 10, style: { fontSize: 12, padding: '4px 8px', width: 72 } }}
                              />
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_max_queue`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_max_queue`, e.target.value)}
                                inputProps={{ min: 1, max: 500, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                              />
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 1.5 }}>
                  <Button size="small" variant="text" onClick={loadPoolConfig} disabled={poolCfgSaving}>Reset</Button>
                  <Button size="small" variant="contained"
                    startIcon={poolCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
                    onClick={handlePoolCfgSave} disabled={poolCfgSaving}>
                    Save
                  </Button>
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  Changes apply immediately without server restart. Running tasks are not affected.
                </Typography>
              </Box>
            ) : (
              <LinearProgress sx={{ mt: 1 }} />
            )}
          </Collapse>
        </>
      )}
    </Paper>
  );
};

export default WorkerPoolSection;
