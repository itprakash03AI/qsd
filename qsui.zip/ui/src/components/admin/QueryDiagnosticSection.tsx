/**
 * Per-query diagnostic — UI panel (2026-06-03).
 *
 * Reads /api/admin/queries/diagnose/recent + /api/admin/queries/diagnose/{id}
 * + /api/admin/system-resources and lays them out so admins can see
 *   * Was the query slow?
 *   * Did multi-worker fire?
 *   * Live system resources at fetch time
 *   * The bottleneck hints — sorted by severity, with action text
 * in one screen, instead of bouncing between 6 raw endpoints.
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Divider, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  Accordion, AccordionSummary, AccordionDetails,
  CircularProgress, IconButton, Tooltip,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  ExpandMore as ExpandMoreIcon,
  Memory as MemoryIcon,
  Speed as SpeedIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface Hint {
  severity: 'critical' | 'warning' | 'info';
  code:     string;
  title:    string;
  detail:   string;
  action:   string;
}

interface PerWorker {
  chunk_index: number;
  files_count: number;
  elapsed_s:   number;
  ok:          boolean;
  row_count:   number;
  error:       string;
}

interface Dispatch {
  timestamp:        number;
  correlation_id:   string;
  status:           string;
  worker_count:     number;
  succeeded:        number;
  failed:           number;
  elapsed_s:        number;
  merge_strategy:   string;
  fallback_reason:  string;
  per_worker:       PerWorker[];
}

interface FilterClause {
  column:         string;
  operator:       string;
  value:          any;
  support:        'supported' | 'weak' | 'unsupported' | 'unknown';
  support_reason: string;
}

interface StageDrops {
  partition?:     number;
  column_stats?:  number;
  supplement?:    number;
  // 149.4 — DB-backed bloom sidecar (separate from BF-548 native S3 bloom)
  bloom_sidecar?: number;
  bloom?:         number;
}

interface PruningSummary {
  source?:               string;
  cache_state?:          string;
  manifests_attempted?:  number;
  manifests_succeeded?:  number;
  manifests_failed?:     number;
  strict_mode?:          boolean;
  metadata_seconds?:     number;
  manifests_seconds?:    number;
  cache_hit?:            boolean;
  // 2026-06-04 — added per-WHERE-clause breakdown
  files_before_prune?:   number;
  files_after_prune?:    number;
  stage_drops?:          StageDrops;
  filter_breakdown?:     FilterClause[];
  snapshot_id?:          string;
  schema_evolution?:     boolean;
}

interface BlockerEvent {
  type:   string;
  detail: string;
  ts:     number;
}

interface WorkerProgress {
  chunk_index:   number;
  rows_scanned?: number;
  bytes_read?:   number;
  current_file?: string;
  first_seen?:   number;
  updated_at?:   number;
}

interface BoundReportCol {
  sources:        string[];
  files_covered:  number;
  files_missing:  number;
  has_bounds:     boolean;
  distinct_count: number;
}

interface DiagEntry {
  execution_id: string;
  fetched_at:   number;
  engine_router: {
    decisions:        any[];
    total_decisions:  number;
    final_engine:     string | null;
    skip_reasons:     string[];
  };
  multi_worker: {
    dispatches:      Dispatch[];
    active_workers:  any[];
    is_running:      boolean;
    n_dispatches:    number;
  };
  config: {
    multi_worker:  any;
    query_engine:  any;
    scan_strategy: any;
    iceberg:       any;
  };
  pruning: {
    available: boolean;
    summary:   PruningSummary;
    blockers:  BlockerEvent[];
  };
  worker_progress: WorkerProgress[];
  bottleneck_hints: Hint[];
  // Phase Z (2026-06-09) — per-table per-col bound-source attribution
  // from the BoundProviderRegistry.  Shape: {table: {col: {...}}}.
  join_key_bound_report?: Record<string, Record<string, BoundReportCol>>;
  // Phase Z.7 (2026-06-09) — captured brain log narrative for THIS
  // execution.  Each entry: {ts, level, logger, message}.
  brain_logs?: Array<{
    ts:      string;
    level:   string;
    logger:  string;
    message: string;
  }>;
  // Phase S (2026-06-08) — unified scan_plan from the brain.
  // Backend admin_queries_diagnose_one enriches the diag with this
  // when available.  Renders below the existing pruning section.
  scan_plan?: ScanPlan;
  scan_plan_source?: 'in_memory' | 'db';
  // Phase T (2026-06-08) — branch routing decision recorded at the
  // start of execute_query_background so the UI can show WHICH path
  // a query took without log-grepping.
  execution_path?: {
    branch:       string;
    has_reg:      boolean;
    raw_sql:      boolean;
    has_s3_reg:   boolean;
    files:        string[];
    notes:        string;
    recorded_at:  string;
  };
}

interface ScanDecision {
  gate:        string;
  action:      string;
  reason:      string;
  files_before: number;
  files_after:  number;
  files_dropped: number;
  columns:     string[];
  elapsed_ms:  number;
}

interface ScanTable {
  table_name:           string;
  connection_id?:       number;
  bucket:               string;
  table_prefix:         string;
  snapshot_id?:         string;
  partition_columns:    string[];
  files_before:         number;
  files_after_partition?: number;
  files_after_stats?:     number;
  files_after_supplement?: number;
  files_after_join_probe?: number;
  files_final:          number;
  decisions:            ScanDecision[];
  pruning_source:       string;
  needs_self_heal:      string[];
  filters_received:     Array<{col: string; op: string; val: any}>;
  // Phase 150 — mirror routing decision (null when not eligible)
  mirror_decision?: {
    routed:                   boolean;
    mirror_id?:               number | null;
    mirror_root_uri?:         string;
    mirror_file_count?:       number;
    source_file_count_before?: number;
    reason?:                  string;
  } | null;
}

interface ScanJoin {
  anchor: string;
  target: string;
  bounds_required: boolean;
  bounds_available: boolean;
  synthesized_filter: any;
  notes: string[];
}

interface ScanPlan {
  execution_id:        string;
  raw_sql?:            string;
  total_files_before:  number;
  total_files_after:   number;
  created_at:          string;
  completed_at?:       string;
  tables:              ScanTable[];
  joins:               ScanJoin[];
}

interface SystemRes {
  ram_mb_total:     number;
  ram_mb_available: number;
  ram_mb_used:      number;
  cpu_count:        number;
  cpu_load_pct:     number;
  source:           string;
}


const severityColor = (s: string): 'error' | 'warning' | 'info' =>
  s === 'critical' ? 'error' : s === 'warning' ? 'warning' : 'info';


// 149.8 — extract the eq/in filter columns from this table's filters_received.
// Bloom only helps for equality / IN-list ops; ranges + LIKE + IS NULL skip
// the scan (would waste a full column read with zero pruning benefit).
const eqInColumnsFromFilters = (
  filters: Array<{col: string; op: string; val: any}> | undefined,
): string[] => {
  if (!filters) return [];
  const out = new Set<string>();
  for (const f of filters) {
    const op = (f.op || '').toLowerCase().trim();
    if (op === '=' || op === '==' || op === 'eq' || op === 'equals' || op === 'in') {
      const bare = (f.col || '').split('.').pop() || '';
      if (bare) out.add(bare.toLowerCase());
    }
  }
  return Array.from(out);
};


// 149.8 — per-table bloom scan state.  Keyed by `${execId}::${tableName}` so
// triggering a scan on one diagnose entry's table doesn't show progress for
// another entry's table with the same name.
interface BloomScanState {
  status: 'idle' | 'starting' | 'running' | 'done' | 'error';
  message: string;
  jobId?: string;
  scanned?: number;
  total?: number;
  failed?: number;
  elapsed?: number;
  rowsInserted?: number;
}


const QueryDiagnosticSection: React.FC = () => {
  const [queries, setQueries] = useState<DiagEntry[]>([]);
  const [sysRes, setSysRes]   = useState<SystemRes | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  // 149.8 — per-(execution_id, table_name) bloom scan state for the UI.
  // Map keyed by `${execId}::${tableName}` so multiple inline scans don't
  // clobber each other when an admin triggers scans on different tables.
  const [bloomScans, setBloomScans] = useState<Record<string, BloomScanState>>({});

  // 149.9 — adaptive prefetch daemon status.  Polled on mount; refreshed
  // after manual force-run.
  const [prefetchStatus, setPrefetchStatus] = useState<any | null>(null);
  const [prefetchLoading, setPrefetchLoading] = useState(false);
  const [prefetchTicking, setPrefetchTicking] = useState(false);
  const [prefetchError, setPrefetchError]     = useState<string | null>(null);

  // 149.10 — per-(bucket, prefix) brain freshness ledger + recent
  // events.  Surfaces snapshot lag so admins can see WHICH tables have
  // out-of-date bloom coverage and refresh them with one click.
  const [freshness, setFreshness] = useState<any | null>(null);
  const [freshnessLoading, setFreshnessLoading] = useState(false);
  const [freshnessRefreshing, setFreshnessRefreshing] = useState<string | null>(null);

  const loadPrefetchStatus = useCallback(async () => {
    setPrefetchLoading(true);
    setPrefetchError(null);
    try {
      const s = await safeFetch('/api/admin/iceberg/prefetch/status');
      setPrefetchStatus(s);
    } catch (e: any) {
      setPrefetchError(e?.message || String(e));
    } finally {
      setPrefetchLoading(false);
    }
  }, []);

  const forceTickNow = useCallback(async () => {
    setPrefetchTicking(true);
    setPrefetchError(null);
    try {
      // Synchronous on the server (waits for the full tick to finish).
      // Could be ~30 min if the configured top_n + max_files_per_target
      // are large.  Frontend shows a disabled spinner; admin can leave
      // the page and the tick continues server-side.
      await safeFetch('/api/admin/iceberg/prefetch/tick', { method: 'POST' });
      // Reload status to pick up the new ring entry
      await loadPrefetchStatus();
    } catch (e: any) {
      setPrefetchError(e?.message || String(e));
    } finally {
      setPrefetchTicking(false);
    }
  }, [loadPrefetchStatus]);

  useEffect(() => {
    loadPrefetchStatus();
  }, [loadPrefetchStatus]);

  // Bug D fix — honour ?execution_id=... deep-links from the Pruning
  // Health dashboard so a "View" click lands on the right row.  Picks
  // the param up on mount + on history-pop, and scrolls the matching
  // row into view once it has rendered.
  const [highlightExecId, setHighlightExecId] = useState<string | null>(() => {
    try {
      return new URLSearchParams(window.location.search).get('execution_id');
    } catch { return null; }
  });
  useEffect(() => {
    const onPop = () => {
      try {
        setHighlightExecId(
          new URLSearchParams(window.location.search).get('execution_id'),
        );
      } catch { /* no-op */ }
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);
  useEffect(() => {
    if (!highlightExecId) return;
    // Try on each render until the row has actually been emitted by
    // the list — bounded retry so the effect doesn't leak forever.
    let tries = 0;
    const timer = setInterval(() => {
      tries += 1;
      const el = document.getElementById(`diag-row-${highlightExecId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        clearInterval(timer);
      } else if (tries > 30) {
        clearInterval(timer);
      }
    }, 250);
    return () => clearInterval(timer);
  }, [highlightExecId, queries.length]);

  const loadFreshness = useCallback(async () => {
    setFreshnessLoading(true);
    try {
      const r = await safeFetch('/api/admin/iceberg/freshness');
      setFreshness(r);
    } catch (e: any) {
      // Best-effort; surface in the panel via empty state
      setFreshness({ ledger: [], recent_events: [], error: e?.message });
    } finally {
      setFreshnessLoading(false);
    }
  }, []);

  const refreshOneTable = useCallback(
    async (bucket: string, table_prefix: string) => {
      const key = `${bucket}::${table_prefix}`;
      setFreshnessRefreshing(key);
      try {
        await safeFetch('/api/admin/iceberg/freshness/refresh', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bucket, table_prefix, blocking: false }),
        });
        // Reload the ledger so the chip color updates
        await loadFreshness();
      } finally {
        setFreshnessRefreshing(null);
      }
    },
    [loadFreshness],
  );

  useEffect(() => {
    loadFreshness();
  }, [loadFreshness]);

  const setBloomScan = useCallback((key: string, state: BloomScanState) => {
    setBloomScans(prev => ({ ...prev, [key]: state }));
  }, []);

  const triggerBloomScan = useCallback(async (
    execId: string,
    tbl: ScanTable,
  ) => {
    const key = `${execId}::${tbl.table_name}`;
    const cols = eqInColumnsFromFilters(tbl.filters_received);
    if (cols.length === 0) {
      setBloomScan(key, {
        status: 'error',
        message: 'No equality / IN filters on this table — bloom can only ' +
                 'prune eq / IN predicates.  Range / LIKE / IS NULL filters ' +
                 'use bounds + supplement instead.',
      });
      return;
    }
    if (!tbl.connection_id) {
      setBloomScan(key, {
        status: 'error',
        message: 'connection_id missing from scan plan — cannot dispatch scan',
      });
      return;
    }
    setBloomScan(key, {
      status: 'starting',
      message: `Scanning bloom for ${cols.length} column(s): ${cols.join(', ')}`,
    });

    try {
      const result = await safeFetch('/api/admin/iceberg/bloom/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          connection_id: tbl.connection_id,
          table_name:    tbl.table_name,
          columns:       cols,
          force:         false,
        }),
      });
      // 149.8 — scan runs synchronously inside the endpoint (asyncio.to_thread)
      // and returns the full summary.  We don't need to poll a separate
      // progress endpoint for this UI surface, though one exists at
      // /api/admin/iceberg/column-stats/scan-progress for the
      // OperationsDashboardSection panel.
      setBloomScan(key, {
        status: 'done',
        message: `Scan complete — ${result?.scanned ?? 0} files scanned, ` +
                 `${result?.rows_inserted ?? 0} bloom rows inserted in ` +
                 `${result?.elapsed_seconds ?? 0}s.  Re-run your query to ` +
                 `see bloom_sidecar pruning fire.`,
        jobId:        result?.job_id,
        scanned:      result?.scanned ?? 0,
        total:        result?.files_total ?? 0,
        failed:       result?.failed ?? 0,
        elapsed:      result?.elapsed_seconds ?? 0,
        rowsInserted: result?.rows_inserted ?? 0,
      });
    } catch (e: any) {
      setBloomScan(key, {
        status: 'error',
        message: `Scan failed: ${e?.message || String(e)}`,
      });
    }
  }, [setBloomScan]);

  // 2026-06-04 — Pruning Probe panel.  User pain: "I have partition
  // filter + bucketing + column stats but still see 3000+ files
  // post-prune — I don't know how to validate pruning is working."
  // The probe lets you iterate on the WHERE shape and watch file
  // counts drop in real time WITHOUT running the heavy query.
  const [probeConn, setProbeConn]       = useState('');
  const [probeBucket, setProbeBucket]   = useState('');
  const [probePrefix, setProbePrefix]   = useState('');
  const [probeTable, setProbeTable]     = useState('');
  const [probeFiltersJson, setProbeFiltersJson] = useState(
    '[\n  {"column": "date", "operator": "=", "value": "2024-01-15"}\n]'
  );
  const [probeForceFresh, setProbeForceFresh] = useState(false);
  const [probeLoading, setProbeLoading] = useState(false);
  const [probeError, setProbeError]     = useState<string | null>(null);
  const [probeResult, setProbeResult]   = useState<any | null>(null);

  const runProbe = useCallback(async () => {
    setProbeLoading(true); setProbeError(null); setProbeResult(null);
    try {
      let filters: any[] = [];
      try {
        filters = JSON.parse(probeFiltersJson);
        if (!Array.isArray(filters)) throw new Error('filters must be a JSON array');
      } catch (parseErr: any) {
        throw new Error(`filters JSON parse error: ${parseErr?.message || parseErr}`);
      }
      const body = {
        connection_id: Number(probeConn),
        bucket:        probeBucket.trim(),
        table_prefix:  probePrefix.trim(),
        table_name:    probeTable.trim() || undefined,
        filters,
        force_fresh:   probeForceFresh,
      };
      const result = await safeFetch('/api/admin/queries/pruning-probe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setProbeResult(result);
    } catch (e: any) {
      setProbeError(e?.message || String(e));
    } finally {
      setProbeLoading(false);
    }
  }, [probeConn, probeBucket, probePrefix, probeTable, probeFiltersJson, probeForceFresh]);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [r1, r2] = await Promise.all([
        safeFetch('/api/admin/queries/diagnose/recent?limit=10'),
        safeFetch('/api/admin/system-resources'),
      ]);
      setQueries(r1?.queries ?? []);
      setSysRes(r2 ?? null);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Live refresh: gate on "any query is running" — otherwise we'd burn
  // CPU polling static history.  5-second interval matches the existing
  // WS architecture rule (never sub-second polls; never client-side
  // ws.close() heartbeats).  Pause when the tab is hidden.
  const anyRunning = queries.some(q => q.multi_worker.is_running);
  useEffect(() => {
    if (!anyRunning) return;
    let cancelled = false;
    const tick = () => {
      if (cancelled) return;
      if (typeof document !== 'undefined' && document.hidden) return;
      load();
    };
    const id = setInterval(tick, 5000);
    return () => { cancelled = true; clearInterval(id); };
  }, [anyRunning, load]);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h6">Query Diagnostic</Typography>
        {anyRunning && (
          <Chip size="small" color="primary" variant="outlined"
                label="LIVE · auto-refresh 5s"
                icon={<CircularProgress size={10} sx={{ color: 'inherit' }} />} />
        )}
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}
                variant="outlined" size="small">
          {loading ? <CircularProgress size={16} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* 2026-06-04 — Pruning probe.  Iterate on WHERE shape and
          watch file count drop without running the heavy query. */}
      <Accordion sx={{ mb: 2 }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="subtitle1" fontWeight={700}>Pruning Probe</Typography>
          <Typography variant="caption" sx={{ ml: 2, color: 'text.secondary' }}>
            Validate partition / bucket / column-stats pruning against a candidate WHERE clause
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} sx={{ mb: 1.5 }}>
            <input
              type="number"
              placeholder="connection_id"
              value={probeConn}
              onChange={(e) => setProbeConn(e.target.value)}
              style={{ flex: 0.5, padding: 6, borderRadius: 4, border: '1px solid #ccc' }}
            />
            <input
              type="text"
              placeholder="bucket"
              value={probeBucket}
              onChange={(e) => setProbeBucket(e.target.value)}
              style={{ flex: 1, padding: 6, borderRadius: 4, border: '1px solid #ccc' }}
            />
            <input
              type="text"
              placeholder="table_prefix (e.g. warehouse/db/fact_left)"
              value={probePrefix}
              onChange={(e) => setProbePrefix(e.target.value)}
              style={{ flex: 1.5, padding: 6, borderRadius: 4, border: '1px solid #ccc' }}
            />
            <input
              type="text"
              placeholder="table_name (optional)"
              value={probeTable}
              onChange={(e) => setProbeTable(e.target.value)}
              style={{ flex: 1, padding: 6, borderRadius: 4, border: '1px solid #ccc' }}
            />
          </Stack>
          <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>
            filters — JSON array of {`{column, operator, value}`} entries:
          </Typography>
          <textarea
            value={probeFiltersJson}
            onChange={(e) => setProbeFiltersJson(e.target.value)}
            rows={5}
            style={{ width: '100%', fontFamily: 'monospace', fontSize: 12, padding: 8,
                     borderRadius: 4, border: '1px solid #ccc', boxSizing: 'border-box' }}
          />
          <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mt: 1.5 }}>
            <label style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
              <input type="checkbox" checked={probeForceFresh}
                     onChange={(e) => setProbeForceFresh(e.target.checked)} />
              force_fresh (bypass snapshot pointer cache)
            </label>
            <Box sx={{ flex: 1 }} />
            <Button variant="contained" size="small"
                    onClick={runProbe}
                    disabled={probeLoading || !probeConn || !probeBucket || !probePrefix}>
              {probeLoading ? <CircularProgress size={16} /> : 'Run probe'}
            </Button>
          </Stack>
          {probeError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>{probeError}</Alert>
          )}
          {probeResult && (
            <Box sx={{ mt: 2, p: 1.5, backgroundColor: 'rgba(0,0,0,0.03)', borderRadius: 1 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>
                {probeResult.files_before_prune?.toLocaleString() ?? '?'}
                &nbsp;→&nbsp;
                {probeResult.files_after_prune?.toLocaleString() ?? '?'} files
                &nbsp;(<strong>{probeResult.pct_pruned ?? 0}% pruned</strong>)
              </Typography>
              <Stack direction="row" spacing={0.75} sx={{ flexWrap: 'wrap', mb: 1.5 }}>
                {probeResult.source && (
                  <Chip size="small" label={`source: ${probeResult.source}`}
                        color={probeResult.source === 'cache' ? 'success' : 'warning'} />
                )}
                {probeResult.cache_hit !== undefined && (
                  <Chip size="small"
                        label={probeResult.cache_hit ? 'cache HIT' : 'cache MISS'}
                        color={probeResult.cache_hit ? 'success' : 'warning'} />
                )}
                {(['partition','column_stats','supplement','bloom_sidecar','bloom'] as const).map((k) => {
                  const v = probeResult.stage_drops?.[k];
                  if (!v) return null;
                  const color = k === 'bloom_sidecar' ? 'secondary' as const
                              : k === 'bloom'         ? 'info'      as const
                              : undefined;
                  return (
                    <Chip key={k} size="small" variant="outlined"
                          color={color}
                          label={`${k}: −${v.toLocaleString()}`} />
                  );
                })}
                {typeof probeResult.metadata_seconds === 'number' && (
                  <Chip size="small" variant="outlined"
                        label={`metadata: ${probeResult.metadata_seconds.toFixed(2)}s`} />
                )}
                {typeof probeResult.manifests_seconds === 'number' && (
                  <Chip size="small" variant="outlined"
                        label={`manifests: ${probeResult.manifests_seconds.toFixed(2)}s`} />
                )}
              </Stack>
              {probeResult.filter_breakdown && probeResult.filter_breakdown.length > 0 && (
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell><Typography variant="caption">Column</Typography></TableCell>
                      <TableCell><Typography variant="caption">Op</Typography></TableCell>
                      <TableCell><Typography variant="caption">Value</Typography></TableCell>
                      <TableCell><Typography variant="caption">Prune support</Typography></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {probeResult.filter_breakdown.map((f: FilterClause, fi: number) => (
                      <TableRow key={fi}>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{f.column}</TableCell>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{f.operator}</TableCell>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                          {Array.isArray(f.value)
                            ? `[${f.value.slice(0, 3).join(', ')}${f.value.length > 3 ? `, …+${f.value.length - 3}` : ''}]`
                            : String(f.value ?? '')}
                        </TableCell>
                        <TableCell>
                          <Chip size="small"
                                color={
                                  f.support === 'supported'   ? 'success' :
                                  f.support === 'weak'        ? 'warning' :
                                  f.support === 'unsupported' ? 'error'   :
                                  'default'
                                }
                                label={f.support}
                                title={f.support_reason} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </Box>
          )}
        </AccordionDetails>
      </Accordion>

      {/* 149.9 — Adaptive Prefetch daemon status */}
      <Accordion sx={{ mb: 2 }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="subtitle1" fontWeight={700}>
            Adaptive Prefetch Daemon (149.6/7)
          </Typography>
          <Typography variant="caption" sx={{ ml: 2, color: 'text.secondary' }}>
            Nightly cron that auto-scans top-N filter cols from query history
            into supplement + bloom sidecars
          </Typography>
          {prefetchStatus && (
            <Box sx={{ ml: 'auto', display: 'flex', gap: 0.5 }}>
              <Chip size="small"
                    color={prefetchStatus.enabled ? 'success' : 'default'}
                    label={prefetchStatus.enabled ? 'enabled' : 'disabled'} />
              {prefetchStatus.dry_run && (
                <Chip size="small" color="warning" label="dry-run" />
              )}
              {prefetchStatus.job_registered && (
                <Chip size="small" variant="outlined"
                      label={`every ${prefetchStatus.interval_hours}h`} />
              )}
            </Box>
          )}
        </AccordionSummary>
        <AccordionDetails>
          {prefetchError && (
            <Alert severity="error" sx={{ mb: 1.5 }}>{prefetchError}</Alert>
          )}
          {prefetchLoading && !prefetchStatus && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CircularProgress size={16} />
              <Typography variant="caption">Loading status…</Typography>
            </Box>
          )}
          {prefetchStatus && (
            <>
              <Stack direction="row" spacing={1.5} alignItems="center"
                      sx={{ mb: 1.5, flexWrap: 'wrap' }}>
                <Chip size="small" variant="outlined"
                      label={`lookback: ${prefetchStatus.lookback_hours}h`} />
                <Chip size="small" variant="outlined"
                      label={`top_n: ${prefetchStatus.top_n}`} />
                <Chip size="small" variant="outlined"
                      label={`max_files: ${prefetchStatus.max_files_per_target}`} />
                {prefetchStatus.daily_budget_bytes > 0 && (
                  <Chip size="small" variant="outlined"
                        label={`budget: ${(prefetchStatus.daily_budget_bytes / (1024 * 1024)).toFixed(0)} MiB/day`} />
                )}
                {prefetchStatus.next_run_at && (
                  <Chip size="small" color="info" variant="outlined"
                        label={`next run: ${new Date(prefetchStatus.next_run_at).toLocaleString()}`} />
                )}
                {!prefetchStatus.job_registered && (
                  <Chip size="small" color="error"
                        label="job NOT registered — check startup logs" />
                )}
                <Box sx={{ flex: 1 }} />
                <Tooltip title={
                  'Trigger one tick immediately instead of waiting for the ' +
                  'next nightly run.  Reads query_pruning_history, ranks ' +
                  'top-N filter cols, fires supplement + bloom scans for ' +
                  'cols lacking coverage.  Synchronous — could take 5-30 min ' +
                  'depending on top_n / max_files_per_target.'
                }>
                  <span>
                    <Button size="small" variant="contained"
                            disabled={prefetchTicking || !prefetchStatus.enabled}
                            onClick={forceTickNow}>
                      {prefetchTicking
                        ? <><CircularProgress size={12} sx={{ mr: 0.5, color: 'inherit' }} /> running tick…</>
                        : 'Run tick now'}
                    </Button>
                  </span>
                </Tooltip>
                <Button size="small" variant="outlined"
                        startIcon={<RefreshIcon />}
                        onClick={loadPrefetchStatus}
                        disabled={prefetchLoading}>
                  Refresh
                </Button>
              </Stack>

              {/* Recent ticks table */}
              {Array.isArray(prefetchStatus.recent_ticks) &&
                prefetchStatus.recent_ticks.length > 0 ? (
                <>
                  <Typography variant="caption" sx={{ fontWeight: 600,
                                                        display: 'block', mb: 0.5 }}>
                    Recent ticks ({prefetchStatus.recent_ticks.length}):
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ py: 0.5 }}>When</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Elapsed</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Targets</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Enqueued</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Sup / Bloom</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Skipped</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Errors</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {prefetchStatus.recent_ticks.slice(0, 10).map((t: any, i: number) => (
                        <TableRow key={i}>
                          <TableCell sx={{ py: 0.5, fontSize: '0.75rem' }}>
                            {t.started_at ? new Date(t.started_at).toLocaleString() : '?'}
                          </TableCell>
                          <TableCell sx={{ py: 0.5 }}>{t.elapsed_s?.toFixed(1)}s</TableCell>
                          <TableCell sx={{ py: 0.5 }}>{t.targets_total ?? 0}</TableCell>
                          <TableCell sx={{ py: 0.5 }}>
                            <Chip size="small"
                                  color={(t.enqueued ?? 0) > 0 ? 'success' : 'default'}
                                  label={t.enqueued ?? 0} />
                          </TableCell>
                          <TableCell sx={{ py: 0.5 }}>
                            {t.supplement_jobs ?? 0} / {t.bloom_jobs ?? 0}
                          </TableCell>
                          <TableCell sx={{ py: 0.5, fontSize: '0.75rem' }}>
                            {t.skipped_budget > 0 && `budget=${t.skipped_budget} `}
                            {t.skipped_dry_run > 0 && `dry=${t.skipped_dry_run}`}
                          </TableCell>
                          <TableCell sx={{ py: 0.5 }}>
                            {Array.isArray(t.errors) && t.errors.length > 0 ? (
                              <Tooltip title={t.errors.join('\n')}>
                                <Chip size="small" color="error"
                                      label={t.errors.length} />
                              </Tooltip>
                            ) : (
                              <Chip size="small" variant="outlined" label="0" />
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  {/* Most-recent tick's targets preview */}
                  {prefetchStatus.recent_ticks[0]?.targets_preview?.length > 0 && (
                    <Box sx={{ mt: 1.5 }}>
                      <Typography variant="caption" sx={{ fontWeight: 600,
                                                            display: 'block', mb: 0.5 }}>
                        Latest tick's targets:
                      </Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ py: 0.5 }}>Table</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Column</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Occurrence</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Needs</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Reason</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {prefetchStatus.recent_ticks[0].targets_preview
                            .slice(0, 20).map((tt: any, ti: number) => (
                            <TableRow key={ti}>
                              <TableCell sx={{ py: 0.5, fontSize: '0.7rem',
                                                fontFamily: 'monospace' }}>
                                {tt.bucket}/{tt.table_prefix}
                              </TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                <code>{tt.column}</code>
                              </TableCell>
                              <TableCell sx={{ py: 0.5 }}>{tt.occurrence_count}</TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                {tt.needs_supplement && <Chip size="small" label="sup"
                                                                color="info"
                                                                sx={{ mr: 0.25 }} />}
                                {tt.needs_bloom && <Chip size="small" label="bloom"
                                                          color="secondary" />}
                              </TableCell>
                              <TableCell sx={{ py: 0.5, fontSize: '0.7rem' }}>
                                {tt.reason}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Box>
                  )}
                </>
              ) : (
                <Alert severity="info" sx={{ mb: 1 }}>
                  No ticks recorded yet on this pod.  The daemon fires every{' '}
                  {prefetchStatus.interval_hours}h —{' '}
                  {prefetchStatus.next_run_at
                    ? `next at ${new Date(prefetchStatus.next_run_at).toLocaleString()}`
                    : 'check startup logs for [adaptive-prefetch] registered'}
                  .  Click <strong>"Run tick now"</strong> to fire one immediately.
                </Alert>
              )}

              {/* 149.10 — per-table freshness ledger */}
              <Box sx={{ mt: 2, pt: 2, borderTop: '1px solid #e5e7eb' }}>
                <Stack direction="row" spacing={1} alignItems="center"
                        sx={{ mb: 1 }}>
                  <Typography variant="subtitle2" fontWeight={700}>
                    Brain Freshness (149.10)
                  </Typography>
                  <Tooltip title={
                    "When iceberg writes a new snapshot, NEW data files have no " +
                    "bloom/supplement coverage until something scans them.  Three " +
                    "triggers keep coverage fresh: (1) the cron daemon above " +
                    "(every 1h), (2) the iceberg watcher fires immediately on " +
                    "snapshot change, (3) lazy on-query check.  This panel shows " +
                    "the per-table lag so you can see WHICH tables need refresh."
                  }>
                    <Chip size="small" variant="outlined"
                          label={`${freshness?.ledger?.length ?? 0} tables tracked`} />
                  </Tooltip>
                  <Box sx={{ flex: 1 }} />
                  <Button size="small" variant="outlined"
                          startIcon={<RefreshIcon />}
                          onClick={loadFreshness}
                          disabled={freshnessLoading}>
                    Reload ledger
                  </Button>
                </Stack>
                {freshness?.error && (
                  <Alert severity="error" sx={{ mb: 1 }}>{freshness.error}</Alert>
                )}
                {Array.isArray(freshness?.ledger) && freshness.ledger.length > 0 ? (
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ py: 0.5 }}>Table</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Snapshot</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Cols covered</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Last source</TableCell>
                        <TableCell sx={{ py: 0.5 }}>Last action</TableCell>
                        <TableCell sx={{ py: 0.5 }}></TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {freshness.ledger.slice(0, 50).map((e: any, i: number) => {
                        const inSync = e.snapshot_in_sync;
                        const key = `${e.bucket}::${e.table_prefix}`;
                        return (
                          <TableRow key={i}>
                            <TableCell sx={{ py: 0.5, fontSize: '0.7rem',
                                              fontFamily: 'monospace' }}>
                              {e.bucket}/{e.table_prefix}
                            </TableCell>
                            <TableCell sx={{ py: 0.5 }}>
                              <Tooltip title={
                                `current: ${e.current_snapshot ?? '(unknown)'}\n` +
                                `last scanned: ${e.last_scanned_snapshot ?? '(none)'}`
                              }>
                                <Chip size="small"
                                      color={inSync ? 'success'
                                              : e.last_scanned_snapshot ? 'warning'
                                              : 'default'}
                                      label={inSync ? 'in sync'
                                              : e.last_scanned_snapshot ? 'stale'
                                              : 'never scanned'} />
                              </Tooltip>
                            </TableCell>
                            <TableCell sx={{ py: 0.5, fontSize: '0.7rem' }}>
                              {Array.isArray(e.cols_covered) ?
                                e.cols_covered.length : 0}
                            </TableCell>
                            <TableCell sx={{ py: 0.5, fontSize: '0.7rem' }}>
                              {e.last_check_source || '—'}
                            </TableCell>
                            <TableCell sx={{ py: 0.5, fontSize: '0.7rem' }}>
                              {e.last_action || '—'}
                              {e.last_error && (
                                <Tooltip title={e.last_error}>
                                  <Chip size="small" color="error"
                                         label="err" sx={{ ml: 0.5 }} />
                                </Tooltip>
                              )}
                            </TableCell>
                            <TableCell sx={{ py: 0.5 }}>
                              <Button size="small" variant="text"
                                      disabled={freshnessRefreshing === key}
                                      onClick={() => refreshOneTable(e.bucket, e.table_prefix)}>
                                {freshnessRefreshing === key
                                  ? <CircularProgress size={12} />
                                  : 'Refresh'}
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                ) : (
                  <Alert severity="info" sx={{ mb: 1 }}>
                    No tables tracked yet.  Coverage builds as the cron tick,
                    watcher hook, or lazy on-query trigger runs.
                  </Alert>
                )}

                {/* Recent freshness events */}
                {Array.isArray(freshness?.recent_events) &&
                  freshness.recent_events.length > 0 && (
                  <Box sx={{ mt: 1.5 }}>
                    <Typography variant="caption" sx={{ fontWeight: 600,
                                                          display: 'block', mb: 0.5 }}>
                      Recent freshness events ({freshness.recent_events.length}):
                    </Typography>
                    <Box sx={{ maxHeight: 200, overflow: 'auto',
                                p: 1, backgroundColor: 'rgba(0,0,0,0.03)',
                                borderRadius: 1, fontSize: '0.7rem',
                                fontFamily: 'monospace' }}>
                      {freshness.recent_events.slice(0, 30).map((ev: any, i: number) => (
                        <div key={i} style={{ marginBottom: 2 }}>
                          <span style={{ color: '#6b7280' }}>
                            {ev.at ? new Date(ev.at).toLocaleTimeString() : '?'}
                          </span>
                          {' '}
                          <Chip size="small"
                                color={ev.action === 'dispatched' ? 'success'
                                        : ev.action === 'error' ? 'error'
                                        : ev.action === 'in_flight' ? 'warning'
                                        : 'default'}
                                label={ev.action || '?'}
                                sx={{ height: 16, fontSize: '0.6rem' }} />
                          {' '}
                          <Chip size="small" variant="outlined"
                                label={ev.source || '?'}
                                sx={{ height: 16, fontSize: '0.6rem' }} />
                          {' '}
                          <strong>{ev.bucket}/{ev.table_prefix}</strong>
                          {' — '}
                          <span style={{ color: '#374151' }}>{ev.reason}</span>
                        </div>
                      ))}
                    </Box>
                  </Box>
                )}
              </Box>
            </>
          )}
        </AccordionDetails>
      </Accordion>

      {/* System resources card */}
      {sysRes && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
            <MemoryIcon fontSize="small" />
            <Typography variant="subtitle1" fontWeight={700}>
              System Resources
            </Typography>
            <Chip size="small" label={`source: ${sysRes.source}`} variant="outlined" />
          </Stack>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
            <Box>
              <Typography variant="caption" color="text.secondary">RAM</Typography>
              <Typography variant="h6">
                {(sysRes.ram_mb_available / 1024).toFixed(1)} GB free
              </Typography>
              <Typography variant="caption">
                {(sysRes.ram_mb_used / 1024).toFixed(1)} / {(sysRes.ram_mb_total / 1024).toFixed(1)} GB used
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">CPU</Typography>
              <Typography variant="h6">{sysRes.cpu_count} cores</Typography>
              <Typography variant="caption">load {sysRes.cpu_load_pct.toFixed(1)}%</Typography>
            </Box>
          </Stack>
        </Paper>
      )}

      {/* Per-query cards */}
      {queries.length === 0 && !loading && (
        <Alert severity="info">
          No recent queries in the engine-router history.  Run a BQB / CQB
          query then click Refresh.
        </Alert>
      )}

      {queries.map((q, idx) => {
        const lastDispatch = q.multi_worker.dispatches[q.multi_worker.dispatches.length - 1];
        const criticalCount = q.bottleneck_hints.filter(h => h.severity === 'critical').length;
        const warningCount  = q.bottleneck_hints.filter(h => h.severity === 'warning').length;
        return (
          <Accordion key={q.execution_id || idx}
                     id={q.execution_id ? `diag-row-${q.execution_id}` : undefined}
                     defaultExpanded={idx === 0 || q.execution_id === highlightExecId}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ flex: 1 }}>
                <SpeedIcon fontSize="small" />
                <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                  {q.execution_id?.slice(0, 16) || '(no exec id)'}…
                </Typography>
                <Chip size="small"
                  label={q.engine_router.final_engine || '?'}
                  color={
                    q.engine_router.final_engine === 'multi_worker' ? 'success' :
                    q.engine_router.final_engine === 'single'       ? 'warning' :
                    'default'
                  }
                />
                {lastDispatch && (
                  <Chip size="small" label={`${lastDispatch.elapsed_s.toFixed(1)}s`}
                        variant="outlined" />
                )}
                {criticalCount > 0 && (
                  <Chip size="small" color="error"
                        label={`${criticalCount} critical`} />
                )}
                {warningCount > 0 && (
                  <Chip size="small" color="warning"
                        label={`${warningCount} warning`} />
                )}
                {q.multi_worker.is_running && (
                  <Chip size="small" color="primary" label="RUNNING" />
                )}
              </Stack>
            </AccordionSummary>
            <AccordionDetails>

              {/* Phase T — execution path / branch routing.  ALWAYS
                  rendered when available so operator immediately knows
                  WHICH code path the query took, even if brain didn't
                  engage on that path. */}
              {q.execution_path && (
                <Box sx={{ mb: 2, p: 1.5, borderRadius: 1,
                            background: 'rgba(157, 124, 255, 0.06)',
                            border: '1px solid #9d7cff' }}>
                  <Typography variant="subtitle2" sx={{ color: '#9d7cff' }}>
                    🛤 Execution Path / Brain Routing
                  </Typography>
                  <Stack direction="row" spacing={1} sx={{ mt: 0.5, flexWrap: 'wrap' }}>
                    <Chip size="small" label={`branch=${q.execution_path.branch}`}
                          color={q.execution_path.branch.startsWith("1") || q.execution_path.branch.startsWith("3")
                                 ? "success" : "warning"} />
                    <Chip size="small" label={`has_reg=${q.execution_path.has_reg}`} />
                    <Chip size="small" label={`raw_sql=${q.execution_path.raw_sql}`} />
                    <Chip size="small" label={`has_s3_reg=${q.execution_path.has_s3_reg}`} />
                  </Stack>
                  <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: '#8b93a7' }}>
                    files={JSON.stringify(q.execution_path.files)}
                  </Typography>
                  {!q.execution_path.has_reg && q.execution_path.raw_sql && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>3_subprocess_raw_sql</code> — Phase S brain
                        orchestration handles this. Look for{' '}
                        <code>Phase S (subprocess path): N raw-SQL JOIN ON probe(s)</code>{' '}
                        in logs to confirm it engaged.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.has_reg && q.execution_path.raw_sql && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>1_bqb_raw_sql</code> — Phase J brain integration
                        via <code>setup_registered_views</code>. Look for{' '}
                        <code>JoinPruner.plan_probes_from_raw_joins</code> in logs.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.branch === '2_structured_no_raw_sql' && (
                    <Alert severity="warning" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>2_structured_no_raw_sql</code> — structured BQB
                        path. JoinPruner uses <code>query_config.joins</code> (JoinConfig
                        objects). If JOIN ON details aren't in JoinConfig, JoinPruner
                        emits 0 probes silently.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.branch === '4_cross_source' && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>4_cross_source</code> — multi-connection
                        query (federation view or cross-connection PV).  Brain
                        runs on each leg separately via{' '}
                        <code>execute_cross_query_background</code>.  Look for
                        per-leg JOIN-PRUNER logs.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.branch === '5_feed_engine' && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>5_feed_engine</code> — Phase Z feed
                        execution.  Recorded by{' '}
                        <code>feed_engine.execute_feed</code>.  Brain bounds
                        aggregation applies to feed-side iceberg reads the
                        same way it does for BQB.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.branch === '6_reports' && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>6_reports</code> — Phase Z report
                        execution.  Recorded by <code>reports_api.execute_report</code>.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.branch === '7_dataflow' && (
                    <Alert severity="info" sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        Branch <code>7_dataflow</code> — Phase Z DataFlow run.
                        Recorded by <code>dataflow.dispatcher.run</code>.
                        execution_id is <code>dataflow-{'{'}run_id{'}'}</code>.
                      </Typography>
                    </Alert>
                  )}
                  {q.execution_path.notes && (
                    <Typography variant="caption" sx={{ display: 'block',
                                                          mt: 0.5, color: '#8b93a7' }}>
                      notes: {q.execution_path.notes}
                    </Typography>
                  )}
                </Box>
              )}

              {/* Phase S (2026-06-08) — unified Brain Scan Plan */}
              {q.scan_plan && (
                <Box sx={{ mb: 2, border: '2px solid #6aa9ff', borderRadius: 1, p: 1.5,
                            background: 'rgba(106, 169, 255, 0.04)' }}>
                  <Typography variant="subtitle2" sx={{ mb: 1, color: '#6aa9ff' }}>
                    🧠 Brain Scan Plan ({q.scan_plan_source})
                    &nbsp;·&nbsp;{q.scan_plan.total_files_before.toLocaleString()} →{' '}
                    {q.scan_plan.total_files_after.toLocaleString()} files
                  </Typography>
                  {q.scan_plan.tables.map((tbl, ti) => (
                    <Box key={ti} sx={{ mb: 1.5, pl: 1,
                                         borderLeft: '3px solid #4ade80' }}>
                      <Typography variant="body2" fontWeight={700}>
                        {tbl.table_name} &nbsp;
                        <Chip size="small" label={tbl.pruning_source} />
                        {tbl.mirror_decision?.routed && (
                          <>
                            &nbsp;
                            <Tooltip title={
                              `Phase 150 — served from mirror.  ` +
                              `source files (post-prune): ${tbl.mirror_decision.source_file_count_before ?? '?'} ` +
                              `→ mirror files: ${tbl.mirror_decision.mirror_file_count ?? '?'}.  ` +
                              `mirror_id=${tbl.mirror_decision.mirror_id ?? '?'}.  ` +
                              (tbl.mirror_decision.mirror_root_uri || '')
                            }>
                              <Chip size="small" color="success"
                                    label={`mirror (${tbl.mirror_decision.mirror_file_count ?? '?'} files)`} />
                            </Tooltip>
                          </>
                        )}
                        {tbl.mirror_decision && !tbl.mirror_decision.routed
                            && tbl.mirror_decision.reason
                            && !/no mirror row/.test(tbl.mirror_decision.reason)
                            && (
                          <>
                            &nbsp;
                            <Tooltip title={`Phase 150 mirror NOT routed: ${tbl.mirror_decision.reason}`}>
                              <Chip size="small" variant="outlined"
                                    label="mirror considered" />
                            </Tooltip>
                          </>
                        )}
                        &nbsp;{tbl.files_before.toLocaleString()} →{' '}
                        {tbl.files_final.toLocaleString()} files
                      </Typography>
                      <Typography variant="caption" sx={{ display: 'block',
                                                            color: '#8b93a7' }}>
                        bucket={tbl.bucket} / prefix={tbl.table_prefix}
                        {tbl.snapshot_id && ` / snap=${tbl.snapshot_id}`}
                      </Typography>
                      {tbl.filters_received.length > 0 && (
                        <Box sx={{ mt: 0.5 }}>
                          <Typography variant="caption" sx={{ fontWeight: 600 }}>
                            Filters received:
                          </Typography>
                          {tbl.filters_received.map((f, fi) => (
                            <Chip key={fi} size="small" sx={{ ml: 0.5, mt: 0.25 }}
                                   label={`${f.col} ${f.op} ${
                                     Array.isArray(f.val) ? `[${f.val.length}]` : f.val
                                   }`} />
                          ))}
                        </Box>
                      )}
                      {/* 149.8 — Bloom Scan inline action.  Triggers a scan
                          for the eq/in filter columns extracted from
                          filters_received above.  Available whenever this
                          table has at least one eq/in filter — bloom can't
                          help range / LIKE / IS NULL, so we don't even show
                          the button for those. */}
                      {(() => {
                        const eqCols = eqInColumnsFromFilters(tbl.filters_received);
                        if (eqCols.length === 0) return null;
                        const key = `${q.execution_id}::${tbl.table_name}`;
                        const scan = bloomScans[key];
                        const inFlight = scan?.status === 'starting' || scan?.status === 'running';
                        return (
                          <Box sx={{ mt: 0.75, p: 0.75,
                                     border: '1px dashed #94a3b8',
                                     borderRadius: 1 }}>
                            <Stack direction="row" spacing={1}
                                    alignItems="center" flexWrap="wrap">
                              <Typography variant="caption" sx={{ fontWeight: 600 }}>
                                Bloom Sidecar (149.4):
                              </Typography>
                              <Tooltip title={
                                `Build bloom filters for these columns so future ` +
                                `queries with equality / IN filters on them prune ` +
                                `sparse files.  Cols extracted from this query's ` +
                                `filters_received: ${eqCols.join(', ')}.  Scan reads ` +
                                `the full column-chunk per file (~1-3s per file) and ` +
                                `stores 10 bits/key in iceberg_bloom_sidecar_v1.  ` +
                                `Idempotent — already-scanned (file, col) pairs are ` +
                                `skipped.`
                              }>
                                <span>
                                  <Button size="small"
                                          variant="outlined"
                                          disabled={inFlight}
                                          onClick={() => triggerBloomScan(q.execution_id, tbl)}>
                                    {inFlight
                                      ? <><CircularProgress size={12} sx={{ mr: 0.5 }} /> scanning</>
                                      : `Scan bloom for ${eqCols.length} col(s)`}
                                  </Button>
                                </span>
                              </Tooltip>
                              {eqCols.map(c => (
                                <Chip key={c} size="small" variant="outlined"
                                       label={c} sx={{ fontSize: '0.7rem' }} />
                              ))}
                            </Stack>
                            {scan && scan.status !== 'idle' && (
                              <Alert
                                severity={
                                  scan.status === 'done'  ? 'success'
                                  : scan.status === 'error' ? 'error'
                                  : 'info'
                                }
                                sx={{ mt: 0.5, py: 0, '& .MuiAlert-message': { py: 0.5 } }}
                              >
                                <Typography variant="caption">
                                  {scan.message}
                                  {scan.status === 'done' && scan.jobId && (
                                    <> &nbsp;<code style={{ fontSize: '0.65rem' }}>
                                      job={scan.jobId}
                                    </code></>
                                  )}
                                </Typography>
                              </Alert>
                            )}
                          </Box>
                        );
                      })()}
                      {tbl.decisions.length > 0 && (
                        <Box sx={{ mt: 0.5 }}>
                          <Typography variant="caption" sx={{ fontWeight: 600 }}>
                            Decisions:
                          </Typography>
                          <Table size="small" sx={{ mt: 0.5 }}>
                            <TableHead>
                              <TableRow>
                                <TableCell sx={{ py: 0.5 }}>Gate</TableCell>
                                <TableCell sx={{ py: 0.5 }}>Action</TableCell>
                                <TableCell sx={{ py: 0.5 }}>Files</TableCell>
                                <TableCell sx={{ py: 0.5 }}>Reason</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {tbl.decisions.map((d, di) => (
                                <TableRow key={di}>
                                  <TableCell sx={{ py: 0.5 }}>
                                    <code>{d.gate}</code>
                                  </TableCell>
                                  <TableCell sx={{ py: 0.5 }}>
                                    <Chip size="small" label={d.action}
                                          color={d.action === 'engaged' ? 'success'
                                                 : d.action === 'failed' || d.action === 'heal_failed' ? 'error'
                                                 : 'default'} />
                                  </TableCell>
                                  <TableCell sx={{ py: 0.5 }}>
                                    {d.files_before} → {d.files_after}
                                    {d.files_dropped > 0 && ` (-${d.files_dropped})`}
                                  </TableCell>
                                  <TableCell sx={{ py: 0.5, fontSize: '0.75rem' }}>
                                    {d.reason}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </Box>
                      )}
                    </Box>
                  ))}
                  {q.scan_plan.joins.length > 0 && (
                    <Box sx={{ mt: 1.5 }}>
                      <Typography variant="caption" sx={{ fontWeight: 600 }}>
                        JOIN Plans:
                      </Typography>
                      {q.scan_plan.joins.map((j, ji) => (
                        <Alert key={ji}
                               severity={j.bounds_available ? 'success' : 'warning'}
                               sx={{ mt: 0.5 }}>
                          <Typography variant="body2">
                            <code>{j.anchor}</code> → <code>{j.target}</code>
                            {j.bounds_available
                              ? ' · bounds available, synth filter injected'
                              : ' · BOUNDS MISSING — target not pruned by JOIN'}
                          </Typography>
                          {j.notes.length > 0 && (
                            <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                              {j.notes.join(' · ')}
                            </Typography>
                          )}
                        </Alert>
                      ))}
                    </Box>
                  )}
                </Box>
              )}

              {/* Bottleneck hints */}
              {q.bottleneck_hints.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Bottleneck Hints
                  </Typography>
                  {q.bottleneck_hints.map((h, hi) => (
                    <Alert key={hi} severity={severityColor(h.severity)}
                           sx={{ mb: 1 }}>
                      <Typography variant="body2" fontWeight={700}>
                        [{h.code}] {h.title}
                      </Typography>
                      <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                        {h.detail}
                      </Typography>
                      <Typography variant="caption" sx={{
                        display: 'block', mt: 0.5, fontFamily: 'monospace',
                        background: 'rgba(0,0,0,0.04)', p: 0.5, borderRadius: 1,
                      }}>
                        → {h.action}
                      </Typography>
                    </Alert>
                  ))}
                </Box>
              )}

              {/* Engine router decisions */}
              {q.engine_router.decisions.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Engine Router Decisions ({q.engine_router.decisions.length})
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Rule</TableCell>
                        <TableCell>Engine</TableCell>
                        <TableCell>Reason</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {q.engine_router.decisions.map((d: any, di: number) => (
                        <TableRow key={di}>
                          <TableCell><code>{d.rule}</code></TableCell>
                          <TableCell>
                            <Chip size="small" label={d.engine} variant="outlined" />
                          </TableCell>
                          <TableCell sx={{ fontSize: 12 }}>{d.reason}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}

              {/* Multi-worker per-chunk timing */}
              {lastDispatch && lastDispatch.per_worker.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Per-Worker ({lastDispatch.worker_count} workers, {lastDispatch.merge_strategy})
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Chunk</TableCell>
                        <TableCell>Files</TableCell>
                        <TableCell>Elapsed (s)</TableCell>
                        <TableCell>Rows</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {lastDispatch.per_worker.map((w, wi) => (
                        <TableRow key={wi}>
                          <TableCell>{w.chunk_index}</TableCell>
                          <TableCell>{w.files_count}</TableCell>
                          <TableCell>{w.elapsed_s.toFixed(2)}</TableCell>
                          <TableCell>{w.row_count?.toLocaleString() || 0}</TableCell>
                          <TableCell>
                            <Chip size="small"
                                  label={w.ok ? 'ok' : (w.error || 'fail')}
                                  color={w.ok ? 'success' : 'error'} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}

              {/* Active workers (if running) */}
              {q.multi_worker.is_running && q.multi_worker.active_workers.length > 0 && (
                <Alert severity="info" sx={{ mb: 2 }}>
                  Query is still running.  Active workers:
                  {q.multi_worker.active_workers.map((w: any, wi: number) => (
                    <div key={wi} style={{ fontSize: 12, marginLeft: 8 }}>
                      • chunk {w.chunk_index}: <b>{w.state}</b> ({w.running_detail || 'no detail'})
                      {w.stuck_s !== undefined && ` — stuck ${w.stuck_s}s`}
                    </div>
                  ))}
                </Alert>
              )}

              {/* Phase Z.7 (2026-06-09) — Brain log narrative.  Every
                  brain-relevant log line for this execution captured
                  by BrainLogCaptureHandler, shown in order with
                  timestamps + levels.  User feedback: "diagnose UI
                  still missing such logs". */}
              {q.brain_logs && q.brain_logs.length > 0 && (
                <Box sx={{ mb: 2, border: '2px solid #0ea5e9', borderRadius: 1,
                            p: 1.5, background: 'rgba(14, 165, 233, 0.05)' }}>
                  <Typography variant="subtitle2" sx={{ mb: 1, color: '#0ea5e9' }}>
                    📜 Brain Log Narrative ({q.brain_logs.length} lines)
                  </Typography>
                  <Typography variant="caption" sx={{ display: 'block',
                                                       mb: 1, color: '#8b93a7' }}>
                    Every brain-relevant log line emitted during THIS
                    execution: JOIN-PRUNER aggregations, Phase S anchor
                    bounds, BF-547 self-heal triggers, column-stats
                    supplement loads.  No more grepping server logs.
                  </Typography>
                  <Box sx={{ maxHeight: 360, overflowY: 'auto',
                              fontFamily: 'monospace', fontSize: 11,
                              background: '#0b1220', color: '#e2e8f0',
                              p: 1, borderRadius: 0.5 }}>
                    {q.brain_logs.map((ln, i) => {
                      const _ts = ln.ts.split('T')[1]?.split('.')[0] ?? ln.ts;
                      const _lvlColor = ln.level === 'WARNING' ? '#f59e0b'
                                       : ln.level === 'ERROR' ? '#ef4444'
                                       : ln.level === 'DEBUG' ? '#6b7280'
                                       : '#60a5fa';
                      return (
                        <Box key={i} sx={{ mb: 0.25,
                                            borderLeft: `3px solid ${_lvlColor}`,
                                            pl: 1 }}>
                          <span style={{ color: '#6b7280' }}>{_ts}</span>{' '}
                          <span style={{ color: _lvlColor, fontWeight: 700 }}>
                            {ln.level.padEnd(7)}
                          </span>{' '}
                          <span style={{ color: '#94a3b8' }}>
                            {ln.logger.replace(/^core\./, '').replace(/^api\./, '')}
                          </span>
                          {' · '}
                          <span style={{ whiteSpace: 'pre-wrap',
                                          wordBreak: 'break-word' }}>
                            {ln.message}
                          </span>
                        </Box>
                      );
                    })}
                  </Box>
                </Box>
              )}

              {/* Phase Z (2026-06-09) — JOIN-PRUNER bound-source
                  attribution.  Renders per-table per-col which source
                  produced bounds (partition / manifest_stats /
                  supplement) plus coverage counts.  This is the brain
                  showing its work: instead of "no bounds returned"
                  the operator now sees "entity_id: supplement (5/5
                  files) → 3 distinct values" or "amount: NO source —
                  scan column-stats supplement to enable pruning". */}
              {q.join_key_bound_report &&
               Object.keys(q.join_key_bound_report).length > 0 && (
                <Box sx={{ mb: 2, border: '2px solid #f59e0b', borderRadius: 1,
                            p: 1.5, background: 'rgba(245, 158, 11, 0.05)' }}>
                  <Typography variant="subtitle2" sx={{ mb: 1, color: '#f59e0b' }}>
                    🔍 JOIN-PRUNER Bound Sources (Phase Z brain)
                  </Typography>
                  <Typography variant="caption" sx={{ display: 'block',
                                                       mb: 1, color: '#8b93a7' }}>
                    Per-col attribution: which source produced bounds for each
                    join key.  Empty sources = the brain has no data to project
                    onto the joined target — run a column-stats scan for that
                    column to enable pruning.
                  </Typography>
                  {Object.entries(q.join_key_bound_report).map(([tbl, cols]) => (
                    <Box key={tbl} sx={{ mb: 1.5, pl: 1,
                                          borderLeft: '3px solid #f59e0b' }}>
                      <Typography variant="body2" fontWeight={700}>
                        {tbl}
                      </Typography>
                      <Table size="small" sx={{ mt: 0.5 }}>
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ py: 0.5 }}>Column</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Source(s)</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Coverage</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Distinct</TableCell>
                            <TableCell sx={{ py: 0.5 }}>Bounds?</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {Object.entries(cols).map(([col, rep]) => (
                            <TableRow key={col}>
                              <TableCell sx={{ py: 0.5 }}><code>{col}</code></TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                {rep.sources.length === 0
                                  ? <Chip size="small" label="none" color="error" />
                                  : rep.sources.map(s => (
                                      <Chip key={s} size="small" label={s}
                                            color={s === 'partition' ? 'success'
                                                   : s === 'manifest_stats' ? 'info'
                                                   : s === 'supplement' ? 'warning'
                                                   : 'default'}
                                            sx={{ mr: 0.5 }} />
                                    ))}
                              </TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                {rep.files_covered} / {rep.files_covered + rep.files_missing}
                              </TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                {rep.distinct_count > 0 ? rep.distinct_count : '—'}
                              </TableCell>
                              <TableCell sx={{ py: 0.5 }}>
                                <Chip size="small"
                                      label={rep.has_bounds ? 'yes' : 'no'}
                                      color={rep.has_bounds ? 'success' : 'error'} />
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Box>
                  ))}
                </Box>
              )}

              {/* Pruning summary — answers "did we get column stats?
                  did we hit cache or fall back to S3?  how many files
                  survived pruning?"  2026-06-04 — when pruning data is
                  NOT available we still render the heading + an
                  explanation, otherwise users debugging "is pruning
                  even running?" see an empty page and conclude the
                  diagnostic is broken when actually iceberg_reader
                  just didn't fire (e.g. JOIN query that took the
                  single-worker register_s3_views path with no
                  filter, or non-Iceberg parquet path). */}
              {!q.pruning?.available && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Iceberg Pruning Summary
                  </Typography>
                  {(() => {
                    // 2026-06-08 — replaced hardcoded "Common reasons" with
                    // per-query diagnosis built from execution_path +
                    // scan_plan + engine_router signals we actually have for
                    // THIS execution.  Goal: tell the operator exactly what
                    // fired and what didn't, not a stock checklist.
                    const ep      = q.execution_path;
                    const sp      = q.scan_plan;
                    const router  = q.engine_router;
                    const mw      = q.multi_worker;
                    const filesN  = ep?.files?.length ?? 0;
                    const facts: React.ReactNode[] = [];
                    const causes: React.ReactNode[] = [];
                    const fixes:  React.ReactNode[] = [];

                    // What we KNOW about this execution
                    if (ep) {
                      facts.push(
                        <>Branch: <code>{ep.branch}</code> · has_reg=<code>{String(ep.has_reg)}</code> · raw_sql=<code>{String(ep.raw_sql)}</code> · has_s3_reg=<code>{String(ep.has_s3_reg)}</code> · files={filesN}</>
                      );
                    } else {
                      facts.push(
                        <>No <code>execution_path</code> recorded — the backend never reached <code>record_execution_path()</code> in <code>execute_api</code>. The query likely ran on a non-BQB path (federation / saved query / published view / report) or the deployed backend is older than Phase T.</>
                      );
                    }
                    if (router?.final_engine) {
                      facts.push(<>Engine router picked <code>{router.final_engine}</code> ({router.total_decisions} decision{router.total_decisions === 1 ? '' : 's'} recorded).</>);
                    }
                    if (mw?.n_dispatches) {
                      facts.push(<>Multi-worker dispatched {mw.n_dispatches} time(s).</>);
                    }
                    if (sp) {
                      facts.push(<>Brain <code>scan_plan</code> WAS recorded ({sp.tables.length} table(s), {sp.joins.length} join(s)) but the pruning_history rollup is empty — likely Phase R UPSERT wrote to <code>query_scan_plans</code> only and the legacy pruning summary path didn't fire.</>);
                    }

                    // Likely cause (specific, not generic)
                    if (ep?.branch === '3_subprocess_raw_sql' && !sp) {
                      causes.push(<>Subprocess raw-SQL branch took over — Phase S brain orchestration runs <i>before</i> the subprocess fires but the recorder didn't see anything. Likely the <code>JoinPruner.plan_probes_from_raw_joins</code> emitted 0 probes (look for <code>Phase S (subprocess path): 0 raw-SQL JOIN ON probe(s)</code> in logs) OR no partition filter could be derived from the WHERE clause.</>);
                      fixes.push(<>Check the executor log for <code>Phase S (subprocess path)</code> — if the count is 0, the JOIN ON columns weren't recognized as partition columns on both sides. Verify <code>registered_tables.partition_columns</code> for both tables.</>);
                    } else if (ep?.branch === '1_bqb_raw_sql' && !sp) {
                      causes.push(<>BQB raw-SQL branch on a registered connection — <code>setup_registered_views</code> was supposed to call <code>JoinPruner.plan_probes_from_raw_joins</code>. Either the call short-circuited (no partition filter to project) or it ran but recorded under a different <code>execution_id</code> (ContextVar didn't propagate into the worker thread).</>);
                      fixes.push(<>Grep logs for <code>JoinPruner.plan_probes_from_raw_joins</code> with this execution_id. If absent, the brain didn't engage. If present with 0 probes, the WHERE clause produced no projectable filter.</>);
                    } else if (ep?.branch === '2_structured_no_raw_sql' && !sp) {
                      causes.push(<>Structured BQB path with no raw_sql — JoinPruner reads <code>query_config.joins</code>. If JoinConfig objects don't carry the ON column pair, JoinPruner emits 0 probes silently.</>);
                      fixes.push(<>Inspect the saved <code>query_config.joins</code> for left/right column names. If they're missing, the structured-side join model needs to carry them.</>);
                    } else if (!ep) {
                      causes.push(<>Query did NOT enter <code>execute_query_background</code> — common for federation, published-view consumer, saved-query API, or report executions where the recorder isn't wired yet.</>);
                      fixes.push(<>Confirm the request actually hit <code>/api/queries/execute</code>. If it came from a different surface, the brain wiring on that surface is the gap.</>);
                    }
                    // Iceberg-specific causes still in scope when path looks right
                    if (ep && (ep.has_reg || ep.has_s3_reg) && !sp) {
                      causes.push(<>Snapshot pointer may have been a cache HIT with no stats refresh — Admin → Iceberg Cache → Refresh and re-run forces a fresh manifest read.</>);
                    }
                    if (ep && !ep.has_s3_reg && !sp) {
                      causes.push(<>No S3-backed iceberg registration on this execution — likely plain parquet or DuckDB-native table; there's no Iceberg manifest to prune from. DuckDB's own row-group skip happens at execute time and isn't reported here.</>);
                    }

                    return (
                      <Alert severity={sp ? 'warning' : 'info'} sx={{ fontSize: 13 }}>
                        <Typography variant="body2" fontWeight={700} sx={{ mb: 0.5 }}>
                          No pruning telemetry recorded for this execution.
                        </Typography>
                        {facts.length > 0 && (
                          <>
                            <Typography variant="caption" fontWeight={700} sx={{ display: 'block', mt: 1 }}>
                              What we observed for THIS query:
                            </Typography>
                            <ul style={{ marginTop: 4, marginBottom: 0, paddingLeft: 18 }}>
                              {facts.map((f, i) => <li key={i}>{f}</li>)}
                            </ul>
                          </>
                        )}
                        {causes.length > 0 && (
                          <>
                            <Typography variant="caption" fontWeight={700} sx={{ display: 'block', mt: 1 }}>
                              Most likely cause:
                            </Typography>
                            <ul style={{ marginTop: 4, marginBottom: 0, paddingLeft: 18 }}>
                              {causes.map((c, i) => <li key={i}>{c}</li>)}
                            </ul>
                          </>
                        )}
                        {fixes.length > 0 && (
                          <>
                            <Typography variant="caption" fontWeight={700} sx={{ display: 'block', mt: 1 }}>
                              Next step:
                            </Typography>
                            <ul style={{ marginTop: 4, marginBottom: 0, paddingLeft: 18 }}>
                              {fixes.map((fx, i) => <li key={i}>{fx}</li>)}
                            </ul>
                          </>
                        )}
                      </Alert>
                    );
                  })()}
                </Box>
              )}
              {q.pruning?.available && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Iceberg Pruning Summary
                  </Typography>
                  <Stack direction="row" spacing={1} sx={{ mb: 1, flexWrap: 'wrap' }}>
                    {q.pruning.summary.source && (
                      <Chip size="small"
                            label={`source: ${q.pruning.summary.source}`}
                            color={
                              q.pruning.summary.source === 'cache' ? 'success' :
                              q.pruning.summary.source === 's3_fallback' ? 'warning' :
                              'default'
                            } />
                    )}
                    {q.pruning.summary.cache_hit !== undefined && (
                      <Chip size="small"
                            label={q.pruning.summary.cache_hit ? 'cache HIT' : 'cache MISS'}
                            color={q.pruning.summary.cache_hit ? 'success' : 'warning'} />
                    )}
                    {q.pruning.summary.manifests_attempted !== undefined && (
                      <Chip size="small" variant="outlined"
                            label={`manifests: ${q.pruning.summary.manifests_succeeded ?? 0}/${q.pruning.summary.manifests_attempted}`}
                            color={
                              (q.pruning.summary.manifests_failed || 0) > 0 ? 'error' : 'default'
                            } />
                    )}
                    {q.pruning.summary.files_after_prune !== undefined && (
                      <Chip size="small" variant="outlined"
                            label={`files after prune: ${q.pruning.summary.files_after_prune}`} />
                    )}
                    {q.pruning.summary.strict_mode && (
                      <Chip size="small" color="info" label="strict_mode ON" />
                    )}
                    {q.pruning.summary.schema_evolution && (
                      <Chip size="small" color="info" label="schema evolved" />
                    )}
                  </Stack>
                  {(q.pruning.summary.metadata_seconds !== undefined ||
                    q.pruning.summary.manifests_seconds !== undefined) && (
                    <Typography variant="caption" color="text.secondary">
                      metadata: {q.pruning.summary.metadata_seconds?.toFixed(2) ?? '?'}s
                      &nbsp;·&nbsp;
                      manifests: {q.pruning.summary.manifests_seconds?.toFixed(2) ?? '?'}s
                      {q.pruning.summary.snapshot_id && (
                        <>&nbsp;·&nbsp;snapshot: {q.pruning.summary.snapshot_id}</>
                      )}
                    </Typography>
                  )}

                  {/* 2026-06-04 — per-WHERE-clause breakdown.  Shows
                      the user "which predicate dropped files vs which
                      fell through to DuckDB". */}
                  {q.pruning.summary.files_before_prune !== undefined &&
                   q.pruning.summary.files_after_prune !== undefined && (
                    <Box sx={{ mt: 1.5, p: 1, backgroundColor: 'rgba(0,0,0,0.02)', borderRadius: 1 }}>
                      <Typography variant="caption" fontWeight={700} sx={{ display: 'block', mb: 0.5 }}>
                        Pruning reduction: {q.pruning.summary.files_before_prune.toLocaleString()}
                        &nbsp;→&nbsp;
                        {q.pruning.summary.files_after_prune.toLocaleString()} files
                        ({(((q.pruning.summary.files_before_prune - q.pruning.summary.files_after_prune)
                           / Math.max(1, q.pruning.summary.files_before_prune)) * 100).toFixed(1)}% pruned)
                      </Typography>
                      {q.pruning.summary.stage_drops && (
                        <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', mb: 1 }}>
                          {(['partition','column_stats','supplement','bloom_sidecar','bloom'] as const).map(k => {
                            const v = q.pruning.summary.stage_drops?.[k] ?? 0;
                            if (!v) return null;
                            // 149.4 — bloom_sidecar = new DB-backed bloom; bloom = BF-548 native S3 bloom
                            const color = k === 'bloom_sidecar' ? 'secondary' as const
                                        : k === 'bloom'         ? 'info'      as const
                                        : undefined;
                            return (
                              <Chip key={k} size="small" variant="outlined"
                                    color={color}
                                    label={`${k}: −${v.toLocaleString()}`} />
                            );
                          })}
                        </Stack>
                      )}
                      {q.pruning.summary.filter_breakdown && q.pruning.summary.filter_breakdown.length > 0 && (
                        <>
                          <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>
                            WHERE-clause prune support:
                          </Typography>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell><Typography variant="caption">Column</Typography></TableCell>
                                <TableCell><Typography variant="caption">Operator</Typography></TableCell>
                                <TableCell><Typography variant="caption">Value</Typography></TableCell>
                                <TableCell><Typography variant="caption">Prune support</Typography></TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {q.pruning.summary.filter_breakdown.map((f, fi) => (
                                <TableRow key={fi}>
                                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{f.column}</TableCell>
                                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{f.operator}</TableCell>
                                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                                    {Array.isArray(f.value)
                                      ? `[${f.value.slice(0, 3).join(', ')}${f.value.length > 3 ? `, …+${f.value.length-3}` : ''}]`
                                      : String(f.value ?? '')}
                                  </TableCell>
                                  <TableCell>
                                    <Chip size="small"
                                          color={
                                            f.support === 'supported'   ? 'success' :
                                            f.support === 'weak'        ? 'warning' :
                                            f.support === 'unsupported' ? 'error'   :
                                            'default'
                                          }
                                          label={f.support}
                                          title={f.support_reason} />
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                            <b>supported</b> = file-level pruning via manifest bounds.&nbsp;
                            <b>weak</b> = prunes only in narrow cases (e.g. NOT IN with single-value files).&nbsp;
                            <b>unsupported</b> = predicate runs in DuckDB row-by-row only.
                          </Typography>
                        </>
                      )}
                    </Box>
                  )}
                </Box>
              )}

              {/* Blocker events */}
              {q.pruning?.blockers && q.pruning.blockers.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Blocker Events ({q.pruning.blockers.length})
                  </Typography>
                  {q.pruning.blockers.slice(-5).reverse().map((b, bi) => (
                    <Alert key={bi} severity="warning" sx={{ mb: 0.5, py: 0.5 }}>
                      <Typography variant="caption" fontWeight={700}>
                        {b.type}
                      </Typography>
                      <Typography variant="caption" sx={{ display: 'block' }}>
                        {b.detail}
                      </Typography>
                    </Alert>
                  ))}
                </Box>
              )}

              {/* Live per-worker progress (rich than `active_workers`
                  alone — shows rows_scanned + current_file as they
                  stream in via record_worker_progress). */}
              {q.worker_progress && q.worker_progress.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Live Worker Progress ({q.worker_progress.length})
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Chunk</TableCell>
                        <TableCell>Rows scanned</TableCell>
                        <TableCell>Bytes read</TableCell>
                        <TableCell>Current file</TableCell>
                        <TableCell>Elapsed (s)</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {q.worker_progress.map((w, wi) => {
                        const elapsed = w.updated_at && w.first_seen
                          ? (w.updated_at - w.first_seen).toFixed(1)
                          : '?';
                        return (
                          <TableRow key={wi}>
                            <TableCell>{w.chunk_index}</TableCell>
                            <TableCell>{(w.rows_scanned ?? 0).toLocaleString()}</TableCell>
                            <TableCell>
                              {w.bytes_read
                                ? `${(w.bytes_read / 1024 / 1024).toFixed(1)} MB`
                                : '—'}
                            </TableCell>
                            <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                              {w.current_file
                                ? w.current_file.length > 50
                                  ? '…' + w.current_file.slice(-47)
                                  : w.current_file
                                : '—'}
                            </TableCell>
                            <TableCell>{elapsed}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </Box>
              )}

              <Divider sx={{ my: 1 }} />
              <Typography variant="caption" color="text.secondary">
                Fetched: {new Date(q.fetched_at * 1000).toLocaleString()}
              </Typography>
            </AccordionDetails>
          </Accordion>
        );
      })}
    </Box>
  );
};

export default QueryDiagnosticSection;
