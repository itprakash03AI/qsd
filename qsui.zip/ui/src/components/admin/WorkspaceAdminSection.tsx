import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Chip, Button,
  Table, TableBody, TableCell, TableHead, TableRow,
  TextField, Tooltip, IconButton,
  Dialog, DialogTitle, DialogContent, DialogActions,
  MenuItem, Select,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, PersonAdd as PersonAddIcon } from '@mui/icons-material';
import api from '../../services/api';
import { useNotifications } from '../../context/NotificationContext';

const WorkspaceAdminSection: React.FC = () => {
  const [workspaces, setWorkspaces] = React.useState<any[]>([]);
  const [members, setMembers] = React.useState<any[]>([]);
  const [selectedWs, setSelectedWs] = React.useState<any | null>(null);
  const [newWsOpen, setNewWsOpen] = React.useState(false);
  const [memberOpen, setMemberOpen] = React.useState(false);
  const [newWsName, setNewWsName] = React.useState('');
  const [newWsDesc, setNewWsDesc] = React.useState('');
  const [newMember, setNewMember] = React.useState('');
  const [newMemberRole, setNewMemberRole] = React.useState('member');
  const { addNotification } = useNotifications();

  const loadWorkspaces = async () => {
    const data = await api.listWorkspaces().catch(() => ({ workspaces: [] }));
    setWorkspaces(data.workspaces || []);
  };

  React.useEffect(() => { loadWorkspaces(); }, []);

  const loadMembers = async (wsId: number) => {
    const data = await api.listWorkspaceMembers(wsId).catch(() => ({ members: [] }));
    setMembers(data.members || []);
  };

  const handleCreate = async () => {
    if (!newWsName.trim()) return;
    try {
      await api.createWorkspace({ name: newWsName.trim(), description: newWsDesc.trim() || null });
      setNewWsOpen(false); setNewWsName(''); setNewWsDesc('');
      loadWorkspaces();
    } catch (e: any) { addNotification({ type: 'error', title: 'Create Failed', message: e.message || 'Failed to create workspace' }); }
  };

  const handleDelete = async (wsId: number) => {
    if (!confirm('Delete this workspace?')) return;
    await api.deleteWorkspace(wsId).catch(() => {});
    loadWorkspaces();
    if (selectedWs?.id === wsId) { setSelectedWs(null); setMemberOpen(false); }
  };

  const handleOpenMembers = (ws: any) => {
    setSelectedWs(ws);
    loadMembers(ws.id);
    setMemberOpen(true);
  };

  const handleAddMember = async () => {
    if (!newMember.trim() || !selectedWs) return;
    try {
      await api.addWorkspaceMember(selectedWs.id, { username: newMember.trim(), role: newMemberRole });
      setNewMember(''); loadMembers(selectedWs.id);
    } catch (e: any) { addNotification({ type: 'error', title: 'Add Failed', message: e.message || 'Failed to add member' }); }
  };

  const handleRemoveMember = async (username: string) => {
    if (!selectedWs) return;
    await api.removeWorkspaceMember(selectedWs.id, username).catch(() => {});
    loadMembers(selectedWs.id);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Workspaces</Typography>
        <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => setNewWsOpen(true)}>
          New Workspace
        </Button>
      </Box>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Members</TableCell>
            <TableCell>Created By</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {workspaces.map(ws => (
            <TableRow key={ws.id} hover>
              <TableCell><Typography variant="body2" fontWeight={500}>{ws.name}</Typography>
                {ws.description && <Typography variant="caption" color="text.secondary">{ws.description}</Typography>}
              </TableCell>
              <TableCell>{ws.member_count ?? 0}</TableCell>
              <TableCell>{ws.created_by || '—'}</TableCell>
              <TableCell align="right">
                <Tooltip title="Manage members"><IconButton size="small" onClick={() => handleOpenMembers(ws)}><PersonAddIcon fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Delete workspace"><IconButton size="small" color="error" onClick={() => handleDelete(ws.id)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* New workspace dialog */}
      <Dialog open={newWsOpen} onClose={() => setNewWsOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>New Workspace</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '12px !important' }}>
          <TextField label="Name" value={newWsName} onChange={e => setNewWsName(e.target.value)} size="small" autoFocus required />
          <TextField label="Description (optional)" value={newWsDesc} onChange={e => setNewWsDesc(e.target.value)} size="small" />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNewWsOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!newWsName.trim()}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* Members dialog */}
      <Dialog open={memberOpen} onClose={() => setMemberOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Members — {selectedWs?.name}</DialogTitle>
        <DialogContent>
          <Table size="small" sx={{ mb: 2 }}>
            <TableHead>
              <TableRow>
                <TableCell>Username</TableCell>
                <TableCell>Role</TableCell>
                <TableCell align="right">Remove</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {members.map(m => (
                <TableRow key={m.username}>
                  <TableCell>{m.username}</TableCell>
                  <TableCell><Chip label={m.role} size="small" color={m.role === 'owner' ? 'primary' : 'default'} /></TableCell>
                  <TableCell align="right">
                    {m.role !== 'owner' && (
                      <IconButton size="small" color="error" onClick={() => handleRemoveMember(m.username)}><DeleteIcon fontSize="small" /></IconButton>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <TextField label="Username" value={newMember} onChange={e => setNewMember(e.target.value)} size="small" sx={{ flex: 1 }} />
            <Select value={newMemberRole} onChange={e => setNewMemberRole(e.target.value)} size="small" sx={{ minWidth: 110 }}>
              <MenuItem value="member">Member</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
              <MenuItem value="owner">Owner</MenuItem>
            </Select>
            <Button variant="outlined" size="small" onClick={handleAddMember} disabled={!newMember.trim()}>Add</Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setMemberOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default WorkspaceAdminSection;
