/**
 * User Activity section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching (read-only).
 * Shows user activity stats with avatar, active-now chip, queries, errors, last active.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, LinearProgress, Avatar, Chip,
  useTheme,
} from '@mui/material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import { fmtDate } from './adminUtils';

interface UserStat {
  username: string;
  active_now: number;
  queries_today: number;
  failed_today: number;
  last_seen: string;
}

const UserActivitySection: React.FC = () => {
  const theme = useTheme();
  const [loading, setLoading] = useState(true);
  const [userStats, setUserStats] = useState<UserStat[]>([]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await safeFetch('/api/admin/user-stats');
      setUserStats(toArray(data));  // BF-430E
    } catch { setUserStats([]); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Poll every 30 seconds — was 10s, but the underlying user-stats endpoint
  // touches the executions table; admin doesn't need second-by-second updates.
  useEffect(() => {
    const t = setInterval(loadData, 30_000);
    return () => clearInterval(t);
  }, [loadData]);

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {userStats.length === 0 && !loading ? (
        <Typography variant="body2" color="text.secondary">No user activity today</Typography>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                {['User', 'Active Now', 'Queries Today', 'Errors', 'Last Active'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem' }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {userStats.map(u => (
                <TableRow key={u.username} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                        bgcolor: theme.palette.primary.light }}>
                        {u.username[0].toUpperCase()}
                      </Avatar>
                      <Typography variant="body2">{u.username}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    {u.active_now > 0
                      ? <Chip size="small" label={u.active_now} color="primary" variant="outlined"
                          sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
                      : <Typography variant="body2" color="text.disabled">{'\u2014'}</Typography>
                    }
                  </TableCell>
                  <TableCell sx={{ fontSize: '0.8rem' }}>{u.queries_today}</TableCell>
                  <TableCell>
                    {u.failed_today > 0
                      ? <Chip size="small" label={u.failed_today} color="error" variant="outlined"
                          sx={{ height: 20, fontSize: 11 }} />
                      : <Typography variant="body2" color="text.disabled">{'\u2014'}</Typography>
                    }
                  </TableCell>
                  <TableCell sx={{ fontSize: '0.72rem', color: 'text.secondary', whiteSpace: 'nowrap' }}>
                    {fmtDate(u.last_seen)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
};

export default UserActivitySection;
