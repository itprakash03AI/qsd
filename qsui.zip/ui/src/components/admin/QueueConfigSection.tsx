/**
 * Queue Configuration section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Covers: Queue backend settings, Redis test, Save/Reset.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, MenuItem, Button, CircularProgress,
  LinearProgress, Stack, Chip, Alert,
} from '@mui/material';
import {
  Save as SaveIcon,
  MonitorHeart as HealthIcon,
  CheckCircle as OkIcon,
  Error as ErrIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const TH = { fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 } as const;
const TD_LABEL = { py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' } as const;
const TD_DESC = { py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' } as const;

const TEXT_FIELDS: { key: string; label: string; desc: string; placeholder: string }[] = [
  { key: 'redis_url', label: 'Redis URL', desc: 'Redis connection URL (e.g. redis://redis:6379/0)', placeholder: 'redis://localhost:6379/0' },
  { key: 'redis_password', label: 'Redis Password', desc: 'Redis AUTH password (leave empty if none)', placeholder: '' },
  { key: 'key_prefix', label: 'Key Prefix', desc: 'Redis key namespace prefix (for multi-tenant)', placeholder: 'qs' },
];

const NUM_FIELDS: { key: string; label: string; desc: string }[] = [
  { key: 'redis_db', label: 'Redis DB', desc: 'Redis database number (0-15)' },
  { key: 'task_ttl_hours', label: 'Task TTL (hrs)', desc: 'Auto-expire completed tasks after N hours' },
];

const QueueConfigSection: React.FC<Props> = ({ addNotification }) => {
  const [queueCfg, setQueueCfg] = useState<any>(null);
  const [queueCfgDraft, setQueueCfgDraft] = useState<Record<string, any>>({});
  const [queueCfgLoading, setQueueCfgLoading] = useState(false);
  const [queueCfgSaving, setQueueCfgSaving] = useState(false);
  const [redisTestResult, setRedisTestResult] = useState<any>(null);
  const [redisTestBusy, setRedisTestBusy] = useState(false);

  const updateQueueDraft = (key: string, value: any) => {
    setQueueCfgDraft(prev => ({ ...prev, [key]: value }));
  };

  const loadQueueConfig = useCallback(async () => {
    setQueueCfgLoading(true);
    setRedisTestResult(null);
    try {
      const data = await safeFetch('/api/admin/queue-config');
      setQueueCfg(data);
      setQueueCfgDraft({ ...data.config });
    } catch { /* silent */ }
    finally { setQueueCfgLoading(false); }
  }, []);

  useEffect(() => { loadQueueConfig(); }, [loadQueueConfig]);

  const handleQueueCfgSave = async () => {
    setQueueCfgSaving(true);
    try {
      const changed: Record<string, any> = {};
      if (queueCfg?.config) {
        for (const [k, v] of Object.entries(queueCfgDraft)) {
          if (k === 'redis_password' && v === '***') continue;
          if (v !== queueCfg.config[k]) changed[k] = v;
        }
      }
      if (Object.keys(changed).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'Queue configuration unchanged' });
        setQueueCfgSaving(false);
        return;
      }
      const result = await safeFetch('/api/admin/queue-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changed),
      });
      addNotification({
        type: 'success',
        title: 'Queue Config Saved',
        message: result.restart_required
          ? 'Backend switch requires restart to take effect.'
          : 'Queue configuration updated.',
      });
      await loadQueueConfig();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save Failed', message: e.message });
    } finally { setQueueCfgSaving(false); }
  };

  const handleTestRedis = async () => {
    setRedisTestBusy(true);
    setRedisTestResult(null);
    try {
      const data = await safeFetch('/api/admin/queue-config/test-redis', { method: 'POST' });
      setRedisTestResult(data);
    } catch (e: any) {
      setRedisTestResult({ connected: false, error: e.message });
    } finally { setRedisTestBusy(false); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {queueCfgLoading && <LinearProgress sx={{ mb: 1 }} />}
      {queueCfg && !queueCfgLoading && (
        <Box>
          {/* Status Banner */}
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Backend" value={queueCfg.status?.backend || '\u2014'} />
            <StatCard label="Connected" value={queueCfg.status?.connected ? 'Yes' : 'No'}
              warn={!queueCfg.status?.connected} />
            {queueCfg.status?.pending_tasks !== undefined && (
              <StatCard label="Pending Tasks" value={queueCfg.status.pending_tasks} />
            )}
            {queueCfg.status?.active_tasks !== undefined && (
              <StatCard label="Active Tasks" value={queueCfg.status.active_tasks} />
            )}
          </Stack>

          {/* Configuration */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" gutterBottom>
            Queue Backend Settings
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={TH}>Setting</TableCell>
                  <TableCell sx={TH}>Value</TableCell>
                  <TableCell sx={TH}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Backend</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={queueCfgDraft.backend || 'sqlite'}
                      onChange={e => updateQueueDraft('backend', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 120 }}
                    >
                      <MenuItem value="sqlite">SQLite (default)</MenuItem>
                      <MenuItem value="redis">Redis</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>
                    Task queue backend. Redis enables instant delivery, pub/sub events, and multi-worker scaling.
                  </TableCell>
                </TableRow>
                {TEXT_FIELDS.map(({ key, label, desc, placeholder }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={TD_LABEL}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" variant="outlined"
                        type={key === 'redis_password' ? 'password' : 'text'}
                        value={queueCfgDraft[key] ?? ''}
                        onChange={e => updateQueueDraft(key, e.target.value)}
                        placeholder={placeholder}
                        inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 220 } }}
                      />
                    </TableCell>
                    <TableCell sx={TD_DESC}>{desc}</TableCell>
                  </TableRow>
                ))}
                {NUM_FIELDS.map(({ key, label, desc }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={TD_LABEL}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" type="number" variant="outlined"
                        value={queueCfgDraft[key] ?? ''}
                        onChange={e => updateQueueDraft(key, Number(e.target.value))}
                        inputProps={{ min: 0, style: { fontSize: 12, padding: '4px 8px', width: 80 } }}
                      />
                    </TableCell>
                    <TableCell sx={TD_DESC}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={TD_LABEL}>Redis SSL</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={queueCfgDraft.redis_ssl ? 'true' : 'false'}
                      onChange={e => updateQueueDraft('redis_ssl', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 80 }}
                    >
                      <MenuItem value="false">No</MenuItem>
                      <MenuItem value="true">Yes</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={TD_DESC}>
                    Use TLS/SSL for Redis connection (rediss://)
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          {/* Test Redis + Save buttons */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <Button size="small" variant="outlined" color="info"
                onClick={handleTestRedis}
                disabled={redisTestBusy}
                startIcon={redisTestBusy ? <CircularProgress size={14} /> : <HealthIcon />}
              >
                Test Redis
              </Button>
              {redisTestResult && (
                <Chip
                  size="small"
                  icon={redisTestResult.connected
                    ? <OkIcon sx={{ fontSize: '14px !important' }} />
                    : <ErrIcon sx={{ fontSize: '14px !important' }} />}
                  label={redisTestResult.connected
                    ? `Connected (v${redisTestResult.redis_version})`
                    : `Failed: ${redisTestResult.error}`}
                  color={redisTestResult.connected ? 'success' : 'error'}
                  variant="outlined"
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button size="small" variant="text" onClick={loadQueueConfig} disabled={queueCfgSaving}>
                Reset
              </Button>
              <Button size="small" variant="contained"
                startIcon={queueCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
                onClick={handleQueueCfgSave} disabled={queueCfgSaving}>
                Save Queue Config
              </Button>
            </Box>
          </Box>
          <Alert severity="info" sx={{ mt: 1.5 }} variant="outlined">
            Switching backend between SQLite and Redis requires a <strong>server restart</strong> to take effect.
            Redis must be reachable when the server starts with <code>backend: &quot;redis&quot;</code>.
            If Redis is unavailable at startup, the system automatically falls back to SQLite.
          </Alert>
        </Box>
      )}
      {!queueCfg && !queueCfgLoading && (
        <Typography variant="body2" color="text.secondary">Failed to load queue configuration.</Typography>
      )}
    </Paper>
  );
};

export default QueueConfigSection;
