import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, CircularProgress, TextField, Alert,
} from '@mui/material';
import { GppGood as GppGoodIcon } from '@mui/icons-material';
import api from '../../services/api';
import { API_BASE_URL } from '../../services/api/core';
import { toArray } from '../../utils/toArray';

const AuditComplianceAdminSection: React.FC = () => {
  const [tab, setTab] = useState(0);

  // Audit Log tab state
  const [auditRows, setAuditRows] = useState<any[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditUsername, setAuditUsername] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [auditResourceType, setAuditResourceType] = useState('');
  const [auditDateFrom, setAuditDateFrom] = useState('');
  const [auditDateTo, setAuditDateTo] = useState('');
  const [auditOffset, setAuditOffset] = useState(0);
  const PAGE_SIZE = 100;

  // Data Access tab state
  const [accessSummary, setAccessSummary] = useState<any[]>([]);
  const [accessLoading, setAccessLoading] = useState(false);

  // GDPR tab state
  const [gdprUsername, setGdprUsername] = useState('');
  const [gdprLoading, setGdprLoading] = useState(false);

  const loadAudit = useCallback(async (offset = 0) => {
    setAuditLoading(true);
    try {
      const rows = await (api as any).getAuditLogFiltered({
        username: auditUsername || undefined,
        action: auditAction || undefined,
        resource_type: auditResourceType || undefined,
        date_from: auditDateFrom || undefined,
        date_to: auditDateTo || undefined,
        limit: PAGE_SIZE,
        offset,
      });
      setAuditRows(toArray(rows));  // BF-430E
      setAuditOffset(offset);
    } finally { setAuditLoading(false); }
  }, [auditUsername, auditAction, auditResourceType, auditDateFrom, auditDateTo]);

  const loadAccessSummary = useCallback(async () => {
    setAccessLoading(true);
    try {
      const res = await (api as any).getDataAccessSummary();
      setAccessSummary(res?.summary || []);
    } finally { setAccessLoading(false); }
  }, []);

  useEffect(() => {
    if (tab === 0) loadAudit(0);
    if (tab === 1) loadAccessSummary();
  }, [tab]);

  const handleExportCSV = () => {
    const params = new URLSearchParams();
    if (auditUsername) params.set('username', auditUsername);
    if (auditAction) params.set('action', auditAction);
    if (auditResourceType) params.set('resource_type', auditResourceType);
    if (auditDateFrom) params.set('date_from', auditDateFrom);
    if (auditDateTo) params.set('date_to', auditDateTo);
    const base = API_BASE_URL.replace(/\/$/, '');
    const url = `${base}/api/admin/audit-log/export?${params.toString()}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = 'audit_log.csv';
    a.click();
  };

  const handleGdprExport = async () => {
    if (!gdprUsername.trim()) return;
    setGdprLoading(true);
    try { await (api as any).generateSubjectExport(gdprUsername.trim()); }
    finally { setGdprLoading(false); }
  };

  return (
    <Box>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        {['Audit Log', 'Data Access', 'GDPR Export'].map((label, i) => (
          <Button key={label} variant={tab === i ? 'contained' : 'text'} size="small"
            sx={{ mr: 1, mb: 1 }} onClick={() => setTab(i)}>
            {label}
          </Button>
        ))}
      </Box>

      {/* Tab 0: Audit Log */}
      {tab === 0 && (
        <Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2, alignItems: 'flex-end' }}>
            <TextField size="small" label="Username" value={auditUsername} onChange={e => setAuditUsername(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Action" value={auditAction} onChange={e => setAuditAction(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Resource Type" value={auditResourceType} onChange={e => setAuditResourceType(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="From (YYYY-MM-DD)" value={auditDateFrom} onChange={e => setAuditDateFrom(e.target.value)} sx={{ width: 160 }} />
            <TextField size="small" label="To (YYYY-MM-DD)" value={auditDateTo} onChange={e => setAuditDateTo(e.target.value)} sx={{ width: 160 }} />
            <Button variant="contained" size="small" onClick={() => loadAudit(0)} disabled={auditLoading}>Search</Button>
            <Button variant="outlined" size="small" onClick={handleExportCSV}>Export CSV</Button>
          </Box>
          {auditLoading ? <CircularProgress size={20} /> : (
            <Box sx={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr>
                    {['Timestamp', 'Username', 'Action', 'Resource Type', 'Resource ID', 'IP Address'].map(h => (
                      <th key={h} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: '2px solid rgba(0,0,0,0.12)', background: 'rgba(0,0,0,0.04)', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {auditRows.map((r, i) => (
                    <tr key={r.id ?? i} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                      <td style={{ padding: '4px 10px', whiteSpace: 'nowrap' }}>{r.timestamp ? new Date(r.timestamp).toLocaleString() : '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.username}</td>
                      <td style={{ padding: '4px 10px' }}>{r.action}</td>
                      <td style={{ padding: '4px 10px' }}>{r.resource_type || '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.resource_id || '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.ip_address || '—'}</td>
                    </tr>
                  ))}
                  {auditRows.length === 0 && (
                    <tr><td colSpan={6} style={{ padding: 16, textAlign: 'center', color: '#888' }}>No entries found</td></tr>
                  )}
                </tbody>
              </table>
              <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                <Button size="small" disabled={auditOffset === 0} onClick={() => loadAudit(Math.max(0, auditOffset - PAGE_SIZE))}>Previous</Button>
                <Button size="small" disabled={auditRows.length < PAGE_SIZE} onClick={() => loadAudit(auditOffset + PAGE_SIZE)}>Next</Button>
              </Box>
            </Box>
          )}
        </Box>
      )}

      {/* Tab 1: Data Access Summary */}
      {tab === 1 && (
        <Box>
          {accessLoading ? <CircularProgress size={20} /> : (
            <Box sx={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr>
                    {['Username', 'Total Executions', 'Total Rows', 'Last Active', 'Exports'].map(h => (
                      <th key={h} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: '2px solid rgba(0,0,0,0.12)', background: 'rgba(0,0,0,0.04)', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {accessSummary.map((r, i) => (
                    <tr key={r.username ?? i} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                      <td style={{ padding: '4px 10px', fontWeight: 600 }}>{r.username}</td>
                      <td style={{ padding: '4px 10px' }}>{(r.total_executions || 0).toLocaleString()}</td>
                      <td style={{ padding: '4px 10px' }}>{(r.total_rows || 0).toLocaleString()}</td>
                      <td style={{ padding: '4px 10px', whiteSpace: 'nowrap' }}>{r.last_active ? new Date(r.last_active).toLocaleString() : '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.export_count || 0}</td>
                    </tr>
                  ))}
                  {accessSummary.length === 0 && (
                    <tr><td colSpan={5} style={{ padding: 16, textAlign: 'center', color: '#888' }}>No data</td></tr>
                  )}
                </tbody>
              </table>
            </Box>
          )}
        </Box>
      )}

      {/* Tab 2: GDPR Export */}
      {tab === 2 && (
        <Box sx={{ maxWidth: 480 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Generate a ZIP archive containing all data QueryStudio holds for a specific user (saved queries, executions, downloads, schedules, and audit log).
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <TextField
              size="small" label="Username" value={gdprUsername}
              onChange={e => setGdprUsername(e.target.value)}
              sx={{ flex: 1 }}
            />
            <Button
              variant="contained" size="small" startIcon={gdprLoading ? <CircularProgress size={14} color="inherit" /> : <GppGoodIcon />}
              onClick={handleGdprExport} disabled={!gdprUsername.trim() || gdprLoading}
            >
              Generate ZIP
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default AuditComplianceAdminSection;
