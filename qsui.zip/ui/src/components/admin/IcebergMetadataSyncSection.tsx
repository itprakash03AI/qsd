/**
 * BF-296/298/299/300 — Iceberg metadata cache + background sync admin UI.
 *
 * Lets admins:
 *   - See last sync run summary (ok/error counts, when, interval)
 *   - See per-table sync status (snapshot_id, file count, duration, errors)
 *   - "Pre-warm All": discover every Iceberg table for every connection
 *     and run an immediate sync pass.  Runs full reconciliation so the
 *     first user query never waits for metadata.
 *   - "Refresh now" per row: re-read metadata.json + reconcile a single
 *     table on demand
 *   - Pin/unpin: keep a table watched even if no recent queries
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Accordion, AccordionDetails, AccordionSummary,
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Divider, FormControl, FormControlLabel, IconButton,
  InputAdornment, InputLabel, LinearProgress, MenuItem, Paper, Popover, Select, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import RefreshIcon from '@mui/icons-material/Refresh';
import RocketIcon from '@mui/icons-material/RocketLaunchOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import TuneIcon from '@mui/icons-material/Tune';
import { safeFetch } from '../../services/api/core';
import { safeStringify } from '../../utils/safeStringify';

interface PredownloadRule {
  strategy?: 'off' | 'top_n_by_record_count' | 'recent_dates' | 'specific_dates' | 'custom';
  partition_column?: string;
  lookback_days?: number;
  dates?: string[];
  filters?: Array<{ col: string; op: string; val: any }>;
  max_files?: number;
  max_gb?: number;
}

interface WatchedTable {
  id: number;
  connection_id: number;
  bucket: string;
  table_prefix: string;
  last_snapshot_id: string | null;
  last_synced_at: string | null;
  last_sync_status: string;
  last_sync_error: string | null;
  last_sync_seconds: number | null;
  last_files_count: number | null;
  pinned: boolean;
  enabled: boolean;
  predownload_rule: PredownloadRule | null;
  created_at: string;
  last_queried_at: string;
}

interface SyncSummary {
  reconciled?: number;
  ok?: number;
  errors?: number;
  ran_at?: string;
  interval_seconds?: number;
  skipped?: boolean;
  error?: string;
  reason?: string;
}

interface CacheStats {
  enabled?: boolean;
  pointer_hits?: number;
  pointer_misses?: number;
  contents_l1_hits?: number;
  contents_l2_hits?: number;
  contents_misses?: number;
  manifest_l1_hits?: number;
  manifest_l2_hits?: number;
  manifest_misses?: number;
  manifest_stores?: number;
  stores?: number;
  pointer_count?: number;
  contents_l1_count?: number;
  l2_row_count?: number;
}

export default function IcebergMetadataSyncSection() {
  const [tables, setTables] = useState<WatchedTable[]>([]);
  const [summary, setSummary] = useState<SyncSummary>({});
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [stats, setStats] = useState<CacheStats>({});
  // BF-318 — per-table predownload rule editor state
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [ruleTarget, setRuleTarget] = useState<WatchedTable | null>(null);
  const [ruleStrategy, setRuleStrategy] = useState<string>('off');
  const [rulePartitionColumn, setRulePartitionColumn] = useState('business_close_date');
  const [ruleLookbackDays, setRuleLookbackDays] = useState(60);
  const [ruleDatesText, setRuleDatesText] = useState('');
  const [ruleCustomFiltersText, setRuleCustomFiltersText] = useState('');
  const [ruleMaxFiles, setRuleMaxFiles] = useState<string>('');
  const [ruleMaxGb, setRuleMaxGb] = useState<string>('');

  // Track whether a manual sync is in flight server-side so the polling
  // effect knows when to stop.  Read from /status .manual_sync.running
  const [manualRunning, setManualRunning] = useState(false);
  const [manualElapsed, setManualElapsed] = useState<number | null>(null);

  // BF-COL-STATS progress tracking — polled from /scan-progress
  interface ScanJob {
    job_id: string;
    connection_id: number | null;
    table_name: string | null;
    bucket: string;
    table_prefix: string;
    total: number;
    total_pre_prune?: number | null;
    files_pruned?: number;
    target_columns?: string[] | null;
    partition_filters?: Array<{ col?: string; column?: string; op?: string; val?: any }> | null;
    filter_rewrites?: Array<{ from: string; to: string }> | null;
    done: number;
    scanned: number;
    skipped: number;
    failed: number;
    files_per_sec: number;
    eta_seconds: number | null;
    eta_status?: 'warming_up' | 'estimating';
    status: 'running' | 'done' | 'error';
    started_at: number;
    updated_at: number;
    finished_at?: number;
    error?: string | null;
  }
  const [scanJobs, setScanJobs] = useState<ScanJob[]>([]);
  const hasRunningScans = scanJobs.some(j => j.status === 'running');

  // BF-COL-STATS — per-table coverage from /status (DB-backed, persisted).
  // BF-359: files / columns are null when /status returns the cheap
  // (no-COUNT-DISTINCT) shape used by polling.  All numeric fields are
  // marked nullable here so the UI never crashes on null.toLocaleString().
  interface ColStatsCoverage {
    bucket: string;
    table_prefix: string;
    snapshot_id: string;
    connection_id: number | null;
    table_name: string | null;
    files: number | null;
    columns: number | null;
    rows: number | null;
    last_scanned: string | null;
  }
  const [colStatsCoverage, setColStatsCoverage] = useState<ColStatsCoverage[]>([]);

  // BF-COL-STATS per-table picker — admin selects WHICH tables to scan
  // instead of blindly hitting every Iceberg table on every connection.
  interface IcebergTable {
    connection_id: number;
    connection_name: string;
    bucket: string;
    table_name: string;
    s3_prefix: string;
    shared_with_connections: number[];
    coverage: { files: number | null; columns: number | null; rows: number | null;
                snapshot_id: string; last_scanned: string | null } | null;
  }
  const [pickerOpen, setPickerOpen] = useState(false);
  const [discoveredTables, setDiscoveredTables] = useState<IcebergTable[]>([]);
  const [discoveredLoading, setDiscoveredLoading] = useState(false);
  const [pickerSelected, setPickerSelected] = useState<Set<string>>(new Set());
  const [pickerForce, setPickerForce] = useState(false);
  // Phase 142+: max_workers control — admin can override the default 32 if
  // the corporate proxy is throttling concurrent S3 connections.  Higher
  // value can saturate available bandwidth; too high overwhelms the proxy.
  const [pickerMaxWorkers, setPickerMaxWorkers] = useState(32);

  // Phase 142+: PER-TABLE column whitelist — different tables have different
  // important columns.  Stored as { "connId|tableName": "col1, col2, ..." }
  // Persisted in localStorage so admin's curated lists survive reloads.
  const [pickerColsByTable, setPickerColsByTable] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem('qs.colstats.target_columns_by_table');
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  });
  // Per-table partition filter — for huge tables admin can scan only
  // specific partition values (e.g. business_close_date = '2025-09-30').
  // Stored as { "connId|tableName": [{col, op, val}, ...] } JSON.
  const [pickerPartsByTable, setPickerPartsByTable] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem('qs.colstats.partition_filters_by_table');
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  });
  // Inline editor anchor — click a row's "Columns" button to open
  const [colEditorAnchor, setColEditorAnchor] = useState<{
    el: HTMLElement; tableKey: string;
  } | null>(null);
  // Cached column-name suggestions for "Load from schema" — fetched on
  // demand when admin opens the editor for a specific table.
  const [colSchemaByTable, setColSchemaByTable] = useState<Record<string, string[]>>({});
  const [colSchemaLoading, setColSchemaLoading] = useState<string | null>(null);
  // Cached partition columns + sample values (from /partitions endpoint)
  const [partInfoByTable, setPartInfoByTable] = useState<Record<string, {
    columns: string[];
    values: Record<string, string[]>;
  }>>({});
  // In-flight gate for partition-info auto-load — prevents duplicate concurrent
  // fetches when admin types fast (every keystroke would otherwise re-fire).
  const [partInfoLoading, setPartInfoLoading] = useState<string | null>(null);
  // Preview file-count-after-filter result (per-table, ephemeral)
  const [previewByTable, setPreviewByTable] = useState<Record<string, {
    total_files: number;
    matching_files: number;
    reduction_pct: number;
    partition_columns: string[];
    warning: string | null;
    loading?: boolean;
  }>>({});
  // Diagnose: time a single S3 footer read to identify slow scan rates
  const [diagnoseRunning, setDiagnoseRunning] = useState(false);
  const [diagnoseResult, setDiagnoseResult] = useState<{
    head_seconds?: number;
    get_seconds?: number;
    total_seconds?: number;
    bytes_read?: number;
    proxy_enabled?: boolean;
    file_path?: string;
    file_size?: number;
    extract_e2e_seconds?: number;
    extract_breakdown?: { head_open?: number; schema_walk?: number; stats_extract?: number; row_groups?: number; columns_iterated?: number };
    extract_columns?: number;
    extract_error?: string;
    active_pool_connections?: number;
    pool_warning?: string;
    error?: string;
  } | null>(null);

  // BF-358: parallelism-test result.  Tells us whether scan slowness is
  // per-file (extract slow) or parallelism (workers serializing).
  const [paraRunning, setParaRunning] = useState(false);
  const [paraResult, setParaResult] = useState<{
    file_count?: number;
    parallel_workers?: number;
    threads_actually_used?: number;
    total_seconds?: number;
    throughput_files_per_sec?: number;
    sequential_baseline_seconds?: number;
    sum_of_per_file_seconds?: number;
    parallel_speedup?: number;
    active_pool_connections?: number;
    per_file?: Array<{ file: string; thread: string; total: number; head_open?: number; stats_extract?: number; row_groups?: number; error?: string | null }>;
    verdict?: string;
    hint?: string;
    error?: string;
  } | null>(null);

  // BF-357: flush-handler-cache state — purges cached S3 client handlers
  const [flushBusy, setFlushBusy] = useState(false);

  // BF-WS-DIAG-3: live WebSocket connection diagnostics — shows on this page
  // because heavy polling here (scan-progress + status + cache stats) is
  // exactly the workload that surfaced the WS staleness bug.
  interface WsConnRow {
    username: string;
    connected_at: string | null;
    last_seen_at: string | null;
    age_seconds: number | null;
    idle_seconds: number | null;
    message_count: number;
  }
  interface WsDiag {
    now: string;
    total_connections: number;
    stale_threshold: number;
    heartbeat_interval: number;
    connections: WsConnRow[];
    stale_count: number;
  }
  const [wsDiag, setWsDiag] = useState<WsDiag | null>(null);
  const [wsDiagOpen, setWsDiagOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');

  // Pagination + filter state for the tables list (BF-ICEBERG-SYNC-VISIBILITY)
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [tableSearch, setTableSearch] = useState<string>('');
  const [pagination, setPagination] = useState<{
    page: number; page_size: number; total: number; total_pages: number;
  }>({ page: 1, page_size: 50, total: 0, total_pages: 1 });

  // Live per-run sync progress
  const [progress, setProgress] = useState<{
    current_table?: { bucket: string; table_prefix: string; started_at: number } | null;
    completed_count?: number;
    total_count?: number;
    per_table_results?: Array<{
      bucket: string; table_prefix: string; status: string;
      error?: string; files_count?: number; elapsed_s: number; finished_at: number;
    }>;
  }>({});

  // Rolling history of completed sync runs
  const [recentRuns, setRecentRuns] = useState<Array<{
    reconciled: number; ok: number; errors: number;
    ran_at: string; completed_at: number;
  }>>([]);

  const reload = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      const qs = new URLSearchParams({
        page: String(page),
        page_size: String(pageSize),
        ...(statusFilter ? { status_filter: statusFilter } : {}),
        ...(tableSearch.trim() ? { search: tableSearch.trim() } : {}),
      }).toString();
      const [statusRes, statsRes] = await Promise.all([
        safeFetch(`/api/admin/iceberg-sync/status?${qs}`),
        safeFetch('/api/admin/iceberg-snapshot-cache/stats').catch(() => ({})),
      ]);
      setTables((statusRes as any)?.tables || []);
      setSummary((statusRes as any)?.summary || {});
      setStats((statsRes as any) || {});
      setProgress((statusRes as any)?.progress || {});
      setRecentRuns((statusRes as any)?.recent_runs || []);
      const pg = (statusRes as any)?.pagination;
      if (pg) setPagination(pg);
      const ms = (statusRes as any)?.manual_sync || {};
      setManualRunning(!!ms.running);
      setManualElapsed(typeof ms.elapsed_seconds === 'number' ? ms.elapsed_seconds : null);
    } catch (e) {
      setErr(`Failed to load sync status: ${e}`);
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, statusFilter, tableSearch]);

  useEffect(() => { reload(); }, [reload]);

  // BF-MANUAL-SYNC-NONBLOCK: while a manual sync is running on the
  // backend, poll status every 5s so the UI shows live elapsed-time and
  // updates the per-table sync status as each one completes.  Stops as
  // soon as manual_sync.running flips false.
  // BF-WS-DIAG-3: pause polling when tab is hidden — saves CPU + prevents
  // disconnect storms when browser throttles background tabs.  Same logic
  // applied to all 4 polling effects on this page.
  const [tabVisible, setTabVisible] = useState(
    typeof document === 'undefined' ? true : document.visibilityState !== 'hidden'
  );
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const onVis = () => setTabVisible(document.visibilityState !== 'hidden');
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  useEffect(() => {
    if (!manualRunning || !tabVisible) return;
    const id = setInterval(() => { reload(); }, 5000);
    return () => clearInterval(id);
  }, [manualRunning, reload, tabVisible]);

  // BF-COL-STATS — poll scan progress every 2s while any scan is running,
  // every 10s otherwise (so admin can still see recent finished jobs
  // when navigating in).
  const loadScanProgress = useCallback(async () => {
    try {
      const [progressRes, statusRes] = await Promise.all([
        safeFetch('/api/admin/iceberg/column-stats/scan-progress'),
        safeFetch('/api/admin/iceberg/column-stats/status').catch(() => ({})),
      ]);
      setScanJobs(((progressRes as any)?.jobs || []) as ScanJob[]);
      setColStatsCoverage(((statusRes as any)?.rows || []) as ColStatsCoverage[]);
    } catch {
      /* ignore — endpoint may be unreachable mid-deploy */
    }
  }, []);

  useEffect(() => { loadScanProgress(); }, [loadScanProgress]);

  // BF-WS-DIAG-3: poll WS diagnostics every 5s while panel is open so
  // admin can SEE if their connection is stale, getting pruned, etc.
  const loadWsDiag = useCallback(async () => {
    try {
      const j: any = await safeFetch('/api/admin/ws-diagnostics');
      setWsDiag(j as WsDiag);
    } catch { /* endpoint may not exist on older deploys */ }
  }, []);
  useEffect(() => {
    if (!wsDiagOpen || !tabVisible) return;
    loadWsDiag();
    const id = setInterval(loadWsDiag, 5000);
    return () => clearInterval(id);
  }, [wsDiagOpen, loadWsDiag, tabVisible]);

  useEffect(() => {
    if (!tabVisible) return;
    const intervalMs = hasRunningScans ? 2000 : 10000;
    const id = setInterval(() => { loadScanProgress(); }, intervalMs);
    return () => clearInterval(id);
  }, [hasRunningScans, loadScanProgress, tabVisible]);

  const bootstrapAll = useCallback(async () => {
    setBusy('bootstrap');
    setErr(null); setMsg(null);
    try {
      // BF-MANUAL-SYNC-NONBLOCK: this POST now returns IMMEDIATELY (~ms)
      // — the server kicks the sync as a background task.  No more
      // multi-minute hang that triggered the offline banner.
      const j: any = await safeFetch('/api/admin/iceberg-sync/bootstrap', {
        method: 'POST',
        body: JSON.stringify({ pin: true, run_now: true }),
      });
      const lines: string[] = [];
      lines.push(`Checked ${j?.connections_checked ?? 0} S3 connection(s).`);
      lines.push(`Discovered ${j?.discovered ?? 0}, registered ${j?.registered ?? 0}.`);
      if (j?.sync_kick?.started) {
        lines.push(`Sync started in background — refresh this section to watch progress.`);
      } else if (j?.sync_kick?.already_running) {
        lines.push(`A manual sync is already running (${j.sync_kick.elapsed_seconds?.toFixed?.(0) ?? '?'}s elapsed).`);
      }
      const skipped = (j?.skipped || []) as Array<{ connection_id: number; reason: string }>;
      if (skipped.length) {
        lines.push('');
        lines.push('Skipped:');
        for (const s of skipped) {
          lines.push(`  • conn ${s.connection_id}: ${s.reason}`);
        }
        lines.push('');
        lines.push('Tip: register Iceberg tables via the connection editor (set format=iceberg), or pass scan_s3=true to scan S3 for tables.');
      }
      const errs = (j?.errors || []) as Array<{ connection_id?: number; error: string }>;
      if (errs.length) {
        lines.push('');
        lines.push('Errors:');
        for (const e of errs) {
          lines.push(`  • conn ${e.connection_id ?? '?'}: ${e.error}`);
        }
      }
      const msgText = lines.join('\n');
      if ((j?.registered ?? 0) === 0) {
        setErr(msgText);
      } else {
        setMsg(msgText);
      }
      // Reload immediately so the UI picks up manual_sync.running=true
      // and the polling loop starts right away.
      reload();
    } catch (e) {
      setErr(`Bootstrap failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const runNow = useCallback(async () => {
    setBusy('run-now');
    setErr(null); setMsg(null);
    try {
      // Returns immediately (kicked into background task).
      const j: any = await safeFetch('/api/admin/iceberg-sync/run', { method: 'POST' });
      if (j?.kick?.started) {
        setMsg('Sync pass started in background — refresh to watch progress.');
      } else if (j?.kick?.already_running) {
        setMsg(`A manual sync is already running (${j.kick.elapsed_seconds?.toFixed?.(0) ?? '?'}s elapsed).`);
      } else {
        setMsg('Sync pass scheduled.');
      }
      reload();
    } catch (e) {
      setErr(`Run failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  // BF-COL-STATS: open the per-table picker.  Admin sees ALL discovered
  // Iceberg tables (across all S3 connections) with coverage state, picks
  // which ones to scan.  Default selection = uncovered tables.  Backend
  // dedupes by (bucket, prefix) automatically — same S3 path on multiple
  // connections is scanned once and shared.
  const openScanPicker = useCallback(async () => {
    setPickerOpen(true);
    setDiscoveredLoading(true);
    setPickerSearch('');
    setPickerForce(false);
    try {
      const j: any = await safeFetch('/api/admin/iceberg/column-stats/list-tables');
      const tabs = (j?.tables || []) as IcebergTable[];
      setDiscoveredTables(tabs);
      // Auto-select tables with no coverage yet — that's the most common
      // intent ("scan the ones that aren't done").  Admin can still tick
      // covered ones to re-scan + force.
      const seenKeys = new Set<string>();
      const autoSel = new Set<string>();
      for (const t of tabs) {
        const key = `${t.connection_id}|${t.table_name}`;
        const sharedKey = `${t.bucket}|${t.s3_prefix.replace(/\/$/, '')}`;
        if (seenKeys.has(sharedKey)) continue; // dedupe across shared connections
        seenKeys.add(sharedKey);
        // BF-359: status now returns files=null when called without
        // include_distinct_counts; use rows as the existence-of-coverage
        // proxy (rows>0 means at least some files have been scanned).
        const cov = t.coverage as any;
        const filesOrRows = cov?.files ?? cov?.rows ?? 0;
        if (!cov || filesOrRows === 0) {
          autoSel.add(key);
        }
      }
      setPickerSelected(autoSel);
    } catch (e) {
      setErr(`Failed to discover tables: ${e}`);
    } finally {
      setDiscoveredLoading(false);
    }
  }, []);

  const togglePickerRow = useCallback((connId: number, tableName: string) => {
    const key = `${connId}|${tableName}`;
    setPickerSelected(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  }, []);

  const runDiagnose = useCallback(async () => {
    // Pick the first selected table — diagnose against that one
    const firstKey = Array.from(pickerSelected)[0];
    if (!firstKey) {
      setDiagnoseResult({ error: 'Select at least one table first' });
      return;
    }
    const [cidStr, ...rest] = firstKey.split('|');
    const tableName = rest.join('|');
    // Pull this table's narrowed columns (if admin set them) so the diagnose
    // measures the same code path the real scan would run.
    const colsRaw = pickerColsByTable[firstKey] || '';
    const target_columns = colsRaw.split(',').map(s => s.trim()).filter(Boolean);
    setDiagnoseRunning(true);
    setDiagnoseResult(null);
    try {
      const j: any = await safeFetch('/api/admin/iceberg/column-stats/diagnose',
        { method: 'POST', body: JSON.stringify({
          connection_id: Number(cidStr),
          table_name: tableName,
          ...(target_columns.length ? { target_columns } : {}),
        }) },
      );
      setDiagnoseResult(j);
    } catch (e: any) {
      setDiagnoseResult({ error: String(e?.message || e) });
    } finally {
      setDiagnoseRunning(false);
    }
  }, [pickerSelected, pickerColsByTable]);

  // BF-358: parallelism-test — runs N files in parallel + reports a verdict
  // about whether parallelism actually works on this connection.  Single
  // 10s test that pinpoints the bottleneck class.
  const runParallelismTest = useCallback(async () => {
    const firstKey = Array.from(pickerSelected)[0];
    if (!firstKey) {
      setParaResult({ error: 'Select at least one table first' });
      return;
    }
    const [cidStr, ...rest] = firstKey.split('|');
    const tableName = rest.join('|');
    const colsRaw = pickerColsByTable[firstKey] || '';
    const target_columns = colsRaw.split(',').map(s => s.trim()).filter(Boolean);
    setParaRunning(true);
    setParaResult(null);
    try {
      const j: any = await safeFetch('/api/admin/iceberg/column-stats/parallelism-test',
        { method: 'POST', body: JSON.stringify({
          connection_id: Number(cidStr),
          table_name: tableName,
          file_count: 8,
          ...(target_columns.length ? { target_columns } : {}),
        }) },
      );
      setParaResult(j);
    } catch (e: any) {
      setParaResult({ error: String(e?.message || e) });
    } finally {
      setParaRunning(false);
    }
  }, [pickerSelected, pickerColsByTable]);

  // BF-357: flush-handler-cache — drops cached S3StorageHandler instances
  // so the next call rebuilds with current config (e.g. picks up new
  // s3.max_pool_connections without a pod restart).
  const runFlushHandlerCache = useCallback(async () => {
    setFlushBusy(true);
    try {
      const j: any = await safeFetch('/api/admin/s3/flush-handler-cache',
        { method: 'POST' });
      setMsg(`Flushed ${j?.flushed ?? 0} cached S3 handler(s) — next call rebuilds with current config (max_pool_connections, proxy, etc.)`);
    } catch (e: any) {
      setErr(`Flush failed: ${e?.message || e}`);
    } finally {
      setFlushBusy(false);
    }
  }, []);

  const submitPickerScan = useCallback(async () => {
    if (pickerSelected.size === 0) {
      setErr('No tables selected');
      return;
    }
    setBusy('col-stats-scan');
    setErr(null); setMsg(null);
    try {
      const tables = Array.from(pickerSelected).map(key => {
        const [cidStr, ...rest] = key.split('|');
        return { connection_id: Number(cidStr), table_name: rest.join('|') };
      });
      // Parse per-table column whitelists + partition filters.
      // Backend shape: tables = [{connection_id, table_name, columns?, partition_filters?}]
      // Strip surrounding quotes from values — common SQL-style typo
      // ('2025-09-30' must become 2025-09-30 to match Iceberg manifest bounds).
      const stripQuotes = (v: string): string => {
        const t = v.trim();
        if ((t.startsWith("'") && t.endsWith("'")) ||
            (t.startsWith('"') && t.endsWith('"'))) {
          return t.slice(1, -1);
        }
        return t;
      };
      const tablesWithCols = tables.map(t => {
        const key = `${t.connection_id}|${t.table_name}`;
        const rawCols = pickerColsByTable[key] || '';
        const cols = rawCols.split(',').map(s => s.trim()).filter(Boolean);
        const uniqueCols = Array.from(new Set(cols));
        const rawParts = pickerPartsByTable[key] || '';
        // Partition filters: parse "col=val, col=val" or JSON array
        let parts: any[] = [];
        if (rawParts.trim()) {
          try {
            // First try JSON form
            const j = JSON.parse(rawParts);
            if (Array.isArray(j)) {
              // Strip quotes on JSON values too
              parts = j.map((f: any) => ({
                ...f,
                val: typeof f.val === 'string' ? stripQuotes(f.val) : f.val,
              }));
            }
          } catch {
            // Fallback: simple "col=val, col=val" syntax
            parts = rawParts.split(',').map(s => s.trim()).filter(Boolean)
              .map(pair => {
                const [col, ...rest] = pair.split('=');
                if (!col || rest.length === 0) return null;
                return {
                  col: col.trim(),
                  op: 'equals',
                  val: stripQuotes(rest.join('=')),
                };
              })
              .filter(Boolean);
          }
        }
        const out: any = { ...t };
        if (uniqueCols.length > 0) out.columns = uniqueCols;
        if (parts.length > 0) out.partition_filters = parts;
        return out;
      });
      // Persist current per-table maps
      try {
        // BF-427: safeStringify defends against picker state pollution.
        localStorage.setItem('qs.colstats.target_columns_by_table',
                             safeStringify(pickerColsByTable));
        localStorage.setItem('qs.colstats.partition_filters_by_table',
                             safeStringify(pickerPartsByTable));
      } catch { /* private mode */ }

      const j: any = await safeFetch(
        '/api/admin/iceberg/column-stats/scan-all',
        { method: 'POST', body: JSON.stringify({
          tables: tablesWithCols,
          force: pickerForce,
          max_workers: pickerMaxWorkers,
        }) },
      );
      const queued = j?.queued ?? 0;
      const skippedDups = (j?.skipped_dups || []) as Array<{ table_name: string; bucket: string }>;
      if (queued === 0) {
        setMsg('No tables queued — selections may have all been duplicates of shared S3 paths.');
      } else {
        setMsg(
          `Column-stats scan queued for ${queued} table(s)`
          + (skippedDups.length > 0
              ? `, ${skippedDups.length} skipped as shared-path duplicates (scan via primary connection covers them).`
              : '.')
          + '\n\nLive progress (files scanned / pending / ETA) appears in the '
          + '"Column-stats scan progress" panel above as workers start.'
        );
        loadScanProgress();
      }
      setPickerOpen(false);
    } catch (e) {
      setErr(`Column-stats scan failed: ${e}`);
    } finally {
      setBusy(null);
    }
    // BF-366: deps MUST include every state read inside this callback —
    // pickerColsByTable + pickerPartsByTable + pickerMaxWorkers were
    // missing, so admin's column selection (typed into the popover) was
    // captured stale and the request body shipped without `columns: []`.
    // Backend then fell back to scanning ALL columns (960 instead of 5).
  }, [pickerSelected, pickerForce, loadScanProgress,
      pickerColsByTable, pickerPartsByTable, pickerMaxWorkers]);

  const filteredDiscoveredTables = useMemo(() => {
    if (!pickerSearch.trim()) return discoveredTables;
    const q = pickerSearch.toLowerCase();
    return discoveredTables.filter(t =>
      t.table_name.toLowerCase().includes(q)
      || t.bucket.toLowerCase().includes(q)
      || t.connection_name.toLowerCase().includes(q));
  }, [discoveredTables, pickerSearch]);

  const refreshOne = useCallback(async (t: WatchedTable) => {
    setBusy(`row-${t.id}`);
    setErr(null); setMsg(null);
    try {
      const j: any = await safeFetch('/api/admin/iceberg-sync/refresh-table', {
        method: 'POST',
        body: JSON.stringify({
          connection_id: t.connection_id, bucket: t.bucket,
          table_prefix: t.table_prefix,
        }),
      });
      setMsg(
        j?.ok
          ? `Refreshed ${t.bucket}/${t.table_prefix} in ${j?.result?.seconds?.toFixed(1)}s`
          : `Refresh returned non-ok: ${j?.result?.error || 'unknown'}`,
      );
      reload();
    } catch (e) {
      setErr(`Refresh failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const openRuleEditor = useCallback((t: WatchedTable) => {
    setRuleTarget(t);
    const r = t.predownload_rule || {};
    setRuleStrategy(r.strategy || 'off');
    setRulePartitionColumn(r.partition_column || 'business_close_date');
    setRuleLookbackDays(r.lookback_days || 60);
    setRuleDatesText((r.dates || []).join(', '));
    setRuleCustomFiltersText(
      r.filters && r.filters.length > 0 ? JSON.stringify(r.filters, null, 2) : '');
    setRuleMaxFiles(r.max_files != null ? String(r.max_files) : '');
    setRuleMaxGb(r.max_gb != null ? String(r.max_gb) : '');
    setRuleDialogOpen(true);
  }, []);

  const saveRule = useCallback(async () => {
    if (!ruleTarget) return;
    setBusy(`rule-${ruleTarget.id}`);
    setErr(null); setMsg(null);
    let rule: any = null;
    if (ruleStrategy === 'off') {
      rule = { strategy: 'off' };
    } else if (ruleStrategy === 'top_n_by_record_count') {
      rule = { strategy: 'top_n_by_record_count' };
      if (ruleMaxFiles) rule.max_files = Number(ruleMaxFiles);
      if (ruleMaxGb) rule.max_gb = Number(ruleMaxGb);
    } else if (ruleStrategy === 'recent_dates') {
      rule = {
        strategy: 'recent_dates',
        partition_column: rulePartitionColumn.trim(),
        lookback_days: Number(ruleLookbackDays),
      };
      if (ruleMaxFiles) rule.max_files = Number(ruleMaxFiles);
      if (ruleMaxGb) rule.max_gb = Number(ruleMaxGb);
    } else if (ruleStrategy === 'specific_dates') {
      rule = {
        strategy: 'specific_dates',
        partition_column: rulePartitionColumn.trim(),
        dates: ruleDatesText.split(',').map(s => s.trim()).filter(Boolean),
      };
      if (ruleMaxFiles) rule.max_files = Number(ruleMaxFiles);
      if (ruleMaxGb) rule.max_gb = Number(ruleMaxGb);
    } else if (ruleStrategy === 'custom') {
      try {
        rule = { strategy: 'custom', filters: JSON.parse(ruleCustomFiltersText || '[]') };
      } catch (e) {
        setErr(`Invalid JSON in custom filters: ${e}`);
        setBusy(null);
        return;
      }
      if (ruleMaxFiles) rule.max_files = Number(ruleMaxFiles);
      if (ruleMaxGb) rule.max_gb = Number(ruleMaxGb);
    } else if (ruleStrategy === '__clear__') {
      rule = null;
    }
    try {
      await safeFetch('/api/admin/iceberg-sync/predownload-rule', {
        method: 'POST',
        body: JSON.stringify({
          connection_id: ruleTarget.connection_id,
          bucket: ruleTarget.bucket,
          table_prefix: ruleTarget.table_prefix,
          rule,
        }),
      });
      setMsg(rule == null ? 'Rule cleared (reverts to global default)' :
        `Rule saved: ${rule.strategy}`);
      setRuleDialogOpen(false);
      reload();
    } catch (e: any) {
      setErr(`Save rule failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  }, [ruleTarget, ruleStrategy, rulePartitionColumn, ruleLookbackDays,
       ruleDatesText, ruleCustomFiltersText, ruleMaxFiles, ruleMaxGb, reload]);

  const unwatch = useCallback(async (t: WatchedTable) => {
    if (!window.confirm(`Stop syncing ${t.bucket}/${t.table_prefix}?`)) return;
    setBusy(`row-${t.id}`);
    try {
      const qs = new URLSearchParams({
        connection_id: String(t.connection_id),
        bucket: t.bucket,
        table_prefix: t.table_prefix,
      }).toString();
      await safeFetch(`/api/admin/iceberg-sync/watched?${qs}`,
        { method: 'DELETE' });
      reload();
    } catch (e) {
      setErr(`Unwatch failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Typography variant="h6">Iceberg Metadata Sync</Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Tooltip title="Refresh status">
          <IconButton onClick={reload} disabled={loading || !!busy}>
            <RefreshIcon />
          </IconButton>
        </Tooltip>
        <Button
          variant="outlined" size="small"
          onClick={runNow} disabled={!!busy}
          startIcon={busy === 'run-now' ? <CircularProgress size={16} /> : null}
        >
          Run sync now
        </Button>
        <Button
          variant="contained" size="small" startIcon={<RocketIcon />}
          onClick={bootstrapAll} disabled={!!busy}
        >
          {busy === 'bootstrap' ? <CircularProgress size={16} sx={{ color: 'white' }} /> : 'Pre-warm all tables'}
        </Button>
        <Tooltip title="One-time scan of parquet footers across all Iceberg tables.  Extracts per-file column min/max bounds for columns the writer didn't track in manifests, so filters like system_id can prune files.  Confirms before kicking off; runs in the background.">
          <Button
            variant="outlined" size="small"
            color="secondary"
            onClick={openScanPicker} disabled={!!busy}
            startIcon={busy === 'col-stats-scan' ? <CircularProgress size={16} /> : null}
          >
            Scan column stats
          </Button>
        </Tooltip>
        <Tooltip title="Live WebSocket connection health — useful when the connection banner appears to see which client WebSockets are stale">
          <Button
            variant="outlined" size="small"
            color={wsDiag && wsDiag.stale_count > 0 ? 'warning' : 'inherit'}
            onClick={() => setWsDiagOpen(v => !v)}
          >
            WS health
            {wsDiag && (
              <Chip
                label={wsDiag.total_connections}
                size="small"
                color={wsDiag.stale_count > 0 ? 'warning' : 'default'}
                sx={{ ml: 0.75, height: 18, fontSize: 10 }}
              />
            )}
          </Button>
        </Tooltip>
      </Stack>

      <Typography variant="body2" sx={{ mb: 2, color: 'text.secondary' }}>
        This page manages the <strong>metadata-only</strong> sync — it reconciles
        Iceberg manifest entries into the QueryStudio DB so query
        pruning runs locally.  After warm-up, queries hit S3 only for the
        small set of data files that survive pruning.  &quot;Pre-warm all
        tables&quot; discovers every Iceberg table for every S3 connection
        and pre-loads its <strong>metadata</strong>.
      </Typography>

      {/* BF-WS-DIAG-3: WebSocket health panel — toggled via "WS health" button */}
      {wsDiagOpen && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2, bgcolor: 'grey.50' }}>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Typography variant="subtitle2">
              WebSocket diagnostics
            </Typography>
            {wsDiag && (
              <>
                <Chip
                  label={`${wsDiag.total_connections} connection${wsDiag.total_connections === 1 ? '' : 's'}`}
                  size="small"
                  color="primary"
                  variant="outlined"
                  sx={{ fontSize: 10, height: 18 }}
                />
                {wsDiag.stale_count > 0 && (
                  <Chip
                    label={`${wsDiag.stale_count} stale`}
                    size="small"
                    color="warning"
                    sx={{ fontSize: 10, height: 18 }}
                  />
                )}
                <Typography variant="caption" color="text.secondary">
                  prune threshold: {wsDiag.stale_threshold}s · heartbeat: {wsDiag.heartbeat_interval}s · poll: 5s
                </Typography>
              </>
            )}
            <Box sx={{ flexGrow: 1 }} />
            <Tooltip title="Refresh now">
              <IconButton size="small" onClick={loadWsDiag}>
                <RefreshIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Stack>
          {!wsDiag ? (
            <Typography variant="caption" color="text.secondary">Loading…</Typography>
          ) : wsDiag.connections.length === 0 ? (
            <Alert severity="info" sx={{ fontSize: 12 }}>No active WebSocket connections on this pod.</Alert>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>User</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Age</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Idle</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Msgs sent</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Health</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {wsDiag.connections.map((c, i) => {
                  const idleSec = c.idle_seconds ?? 0;
                  const healthLabel =
                    idleSec > wsDiag.stale_threshold ? 'STALE — will be pruned'
                    : idleSec > wsDiag.heartbeat_interval * 3 ? 'idle — no recent traffic'
                    : 'healthy';
                  const healthColor: 'success' | 'warning' | 'error' =
                    idleSec > wsDiag.stale_threshold ? 'error'
                    : idleSec > wsDiag.heartbeat_interval * 3 ? 'warning'
                    : 'success';
                  return (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: 11 }}>
                        <strong>{c.username || '(anon)'}</strong>
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {c.age_seconds != null ? `${c.age_seconds.toFixed(0)}s` : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        <strong style={{
                          color: idleSec > wsDiag.stale_threshold ? '#dc2626'
                            : idleSec > wsDiag.heartbeat_interval * 3 ? '#d97706'
                            : 'inherit'
                        }}>
                          {idleSec.toFixed(1)}s
                        </strong>
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {(c.message_count ?? 0).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={healthLabel}
                          size="small"
                          color={healthColor}
                          sx={{ fontSize: 10, height: 18 }}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, fontSize: 10 }}>
            <strong>How to read:</strong> Idle = seconds since last frame from this client.
            Healthy if idle &lt; {wsDiag?.heartbeat_interval ? wsDiag.heartbeat_interval * 3 : 30}s.
            Idle &gt; {wsDiag?.stale_threshold ?? 90}s = staleness pruner will reap this connection on next tick (every {wsDiag?.heartbeat_interval ?? 10}s).
            Per-pod view — multi-pod deploys show only this pod's connections.
          </Typography>
        </Paper>
      )}

      {manualRunning && (
        <Alert severity="info" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
          <CircularProgress size={16} sx={{ mr: 1.5 }} />
          <span>
            Manual sync running in background
            {manualElapsed != null ? ` (${manualElapsed.toFixed(0)}s elapsed)` : ''}
            &nbsp;— per-table status updates as each table completes.
            You can navigate away or close this panel; the sync continues server-side.
          </span>
        </Alert>
      )}

      {/* BF-COL-STATS — persistent coverage table.  Tells admin which
          tables have stats cached, how many files/cols are covered, and
          when each was last scanned.  Empty rows == cache not populated
          for that table yet (a query will hit S3 + miss pruning). */}
      {(colStatsCoverage.length > 0 || scanJobs.some(j => j.status === 'done')) && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Typography variant="subtitle2">
              Column-stats coverage ({colStatsCoverage.length} {colStatsCoverage.length === 1 ? 'snapshot' : 'snapshots'})
            </Typography>
            <Tooltip title="Each row is a (bucket, table_prefix, snapshot_id) covered by the supplement cache.  Pruning runs locally for any column that has a row here — no S3 footer reads at query time.">
              <Chip label="?" size="small" sx={{ fontSize: 9, height: 16, cursor: 'help' }} />
            </Tooltip>
            <Box sx={{ flexGrow: 1 }} />
          </Stack>
          {colStatsCoverage.length === 0 ? (
            <Alert severity="warning" sx={{ fontSize: 12 }}>
              No supplement coverage yet for any Iceberg snapshot.  Click
              <strong> Scan column stats </strong>above to populate.  Until then,
              filters on non-partition / non-tracked columns will scan all files.
            </Alert>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Table</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Snapshot</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Files</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Columns</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Rows</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Last scanned</TableCell>
                  <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {colStatsCoverage.map((c, idx) => {
                  const last = c.last_scanned ? new Date(c.last_scanned) : null;
                  const ageMs = last ? Date.now() - last.getTime() : null;
                  const ageMin = ageMs != null ? Math.floor(ageMs / 60000) : null;
                  const ageText = ageMin == null ? '—'
                    : ageMin < 1 ? 'just now'
                    : ageMin < 60 ? `${ageMin} min ago`
                    : ageMin < 1440 ? `${Math.floor(ageMin / 60)} h ago`
                    : `${Math.floor(ageMin / 1440)} d ago`;
                  // Match against any in-flight scan for this table
                  const runningJob = scanJobs.find(j =>
                    j.status === 'running' &&
                    j.bucket === c.bucket &&
                    j.table_prefix === c.table_prefix);
                  // BF-359: c.files can be null on the cheap polling path,
                  // so use rows (always present + non-null) as the
                  // coverage-exists proxy.
                  const hasCov = (c.files ?? 0) > 0 || (c.rows ?? 0) > 0;
                  const statusChip = runningJob
                    ? <Chip size="small" label="scanning" color="primary" sx={{ fontSize: 10, height: 18 }} />
                    : hasCov
                      ? <Chip size="small" label="covered" color="success" sx={{ fontSize: 10, height: 18 }} />
                      : <Chip size="small" label="empty" color="warning" sx={{ fontSize: 10, height: 18 }} />;
                  return (
                    <TableRow key={`${c.bucket}-${c.table_prefix}-${c.snapshot_id}-${idx}`} hover>
                      <TableCell sx={{ fontSize: 11 }}>
                        <Box>
                          <strong>{c.table_name || '(unregistered)'}</strong>
                          <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                            {c.bucket}/{c.table_prefix}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>
                        {c.snapshot_id ? c.snapshot_id.slice(0, 12) + '…' : '—'}
                      </TableCell>
                      {/* BF-362: files / columns are null when status was
                          fetched without include_distinct_counts (the cheap
                          path used by polling — BF-359).  Render '—' instead
                          of crashing on null.toLocaleString(). */}
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {c.files != null ? c.files.toLocaleString() : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {c.columns != null ? c.columns.toLocaleString() : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }} align="right">
                        {c.rows != null ? c.rows.toLocaleString() : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 11 }}>
                        <Tooltip title={c.last_scanned || ''}>
                          <span>{ageText}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell>{statusChip}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </Paper>
      )}

      {/* BF-COL-STATS — live column-stats scan progress */}
      {scanJobs.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2, bgcolor: 'grey.50' }}>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Typography variant="subtitle2">
              Column-stats scan progress
            </Typography>
            {hasRunningScans && <CircularProgress size={14} />}
            <Box sx={{ flexGrow: 1 }} />
            <Tooltip title="Refresh now">
              <IconButton size="small" onClick={loadScanProgress}>
                <RefreshIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Stack>
          <Stack spacing={1}>
            {scanJobs.map((job) => {
              const pct = job.total > 0
                ? Math.min(100, Math.round((job.done / job.total) * 100))
                : 0;
              const elapsed = ((job.finished_at ?? job.updated_at) - job.started_at);
              const fmtEta = (s: number) => {
                if (s < 60) return `${Math.round(s)}s`;
                if (s < 3600) return `${Math.round(s / 60)}m`;
                return `${(s / 3600).toFixed(1)}h`;
              };
              const etaText = job.status !== 'running'
                ? ''
                : job.eta_status === 'warming_up'
                  ? 'ETA computing…'
                  : (job.eta_seconds != null ? `ETA ~${fmtEta(job.eta_seconds)}` : '');
              const statusColor =
                job.status === 'error' ? 'error.main'
                : job.status === 'done' ? 'success.main'
                : 'primary.main';
              return (
                <Box key={job.job_id} sx={{
                  p: 1, borderRadius: 1, border: '1px solid', borderColor: 'divider',
                  bgcolor: 'background.paper',
                }}>
                  <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
                    <Typography variant="body2" fontWeight={600} sx={{ flexGrow: 1 }}>
                      {job.table_name || '(unknown table)'}
                      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                        conn {job.connection_id ?? '?'} · {job.bucket}
                      </Typography>
                    </Typography>
                    <Chip
                      size="small"
                      label={job.status}
                      sx={{ fontSize: 10, height: 18, color: statusColor, borderColor: statusColor }}
                      variant="outlined"
                    />
                    {job.status === 'running' && (
                      <Tooltip title="Cancel this scan — already-scanned files keep their cached stats; in-flight S3 reads finish before the loop exits (~5-30s).">
                        <Button
                          size="small" variant="outlined" color="error"
                          onClick={async () => {
                            try {
                              await safeFetch('/api/admin/iceberg/column-stats/cancel',
                                { method: 'POST', body: JSON.stringify({ job_id: job.job_id }) });
                              loadScanProgress();
                            } catch (e) { setErr(`Cancel failed: ${e}`); }
                          }}
                          sx={{ fontSize: 10, py: 0, height: 22, ml: 0.5 }}
                        >
                          Cancel
                        </Button>
                      </Tooltip>
                    )}
                  </Stack>
                  {/* Scan context — what columns / partitions / pruning */}
                  {(job.target_columns?.length || job.partition_filters?.length || job.total_pre_prune) && (
                    <Box sx={{ mb: 0.5, p: 0.75, borderRadius: 0.5,
                                bgcolor: 'action.hover', fontSize: 10.5 }}>
                      {job.total_pre_prune != null && job.total != null && job.total_pre_prune > job.total && (
                        <Box sx={{ mb: 0.25 }}>
                          <strong>Scanning {(job.total ?? 0).toLocaleString()}</strong>
                          {' of '}
                          <span style={{ color: '#666' }}>{(job.total_pre_prune ?? 0).toLocaleString()}</span>
                          {' files — '}
                          <span style={{ color: '#2e7d32', fontWeight: 600 }}>
                            {job.total_pre_prune > 0
                              ? Math.round((1 - (job.total ?? 0) / job.total_pre_prune) * 100)
                              : 0}% pruned
                          </span>
                          {' by partition filter'}
                        </Box>
                      )}
                      {job.partition_filters?.length ? (
                        <Box sx={{ mb: 0.25 }}>
                          Partitions:{' '}
                          {job.partition_filters.map((pf, i) => (
                            <Chip
                              key={i}
                              size="small"
                              label={`${pf.col || pf.column} ${pf.op || '='} ${pf.val ?? ''}`}
                              sx={{ height: 16, fontSize: 9.5, fontFamily: 'monospace', mr: 0.25 }}
                              variant="outlined"
                              color="info"
                            />
                          ))}
                          {job.filter_rewrites?.length ? (
                            <Tooltip title={
                              `Source name → partition field name rewrite: ${
                                job.filter_rewrites.map(r => `${r.from}→${r.to}`).join(', ')
                              }`
                            }>
                              <Chip
                                size="small" label="auto-rewrote"
                                sx={{ height: 16, fontSize: 9.5, ml: 0.25 }}
                                color="warning" variant="outlined"
                              />
                            </Tooltip>
                          ) : null}
                        </Box>
                      ) : null}
                      {job.target_columns?.length ? (
                        <Box>
                          Columns:{' '}
                          {job.target_columns.slice(0, 8).map(c => (
                            <Chip
                              key={c}
                              size="small"
                              label={c}
                              sx={{ height: 16, fontSize: 9.5, fontFamily: 'monospace', mr: 0.25 }}
                              variant="outlined"
                            />
                          ))}
                          {job.target_columns.length > 8 && (
                            <Typography component="span" variant="caption" color="text.secondary">
                              +{job.target_columns.length - 8} more
                            </Typography>
                          )}
                        </Box>
                      ) : null}
                    </Box>
                  )}
                  <LinearProgress
                    variant={job.status === 'running' && job.total === 0 ? 'indeterminate' : 'determinate'}
                    value={pct}
                    color={job.status === 'error' ? 'error'
                          : job.status === 'done' ? 'success' : 'primary'}
                    sx={{ height: 6, borderRadius: 1, mb: 0.5 }}
                  />
                  {/* BF-362: backend sometimes ships partial progress
                      payloads; guard every numeric access with (x ?? 0). */}
                  <Stack direction="row" spacing={2} sx={{ fontSize: 11, color: 'text.secondary' }}>
                    <span><strong>{(job.done ?? 0).toLocaleString()}</strong> / {(job.total ?? 0).toLocaleString()} files ({pct}%)</span>
                    <span>scanned {(job.scanned ?? 0).toLocaleString()}</span>
                    {(job.skipped ?? 0) > 0 && <span>skipped {(job.skipped ?? 0).toLocaleString()}</span>}
                    {(job.failed ?? 0) > 0 && <span style={{ color: '#d32f2f' }}>failed {(job.failed ?? 0).toLocaleString()}</span>}
                    {(job.files_per_sec ?? 0) > 0 && <span>{(job.files_per_sec ?? 0).toFixed(1)} f/s</span>}
                    <span>{(elapsed ?? 0).toFixed(0)}s elapsed</span>
                    {etaText && <span>{etaText}</span>}
                  </Stack>
                  {job.error && (
                    <Typography variant="caption" color="error.main" sx={{ display: 'block', mt: 0.5 }}>
                      {job.error}
                    </Typography>
                  )}
                </Box>
              );
            })}
          </Stack>
        </Paper>
      )}

      <Alert severity="warning" sx={{ mb: 2, fontSize: 12 }}>
        <strong>Note on naming</strong>: this is the <strong>METADATA</strong> sync.
        It does NOT download parquet data files by default.  A separate
        opt-in feature — <em>data-file pre-warming</em> — can additionally
        download the top-N largest parquet files into the NFS cache, but
        that&apos;s heavy (gigabytes per tick) and is OFF unless you set both
        <code style={{ margin: '0 4px' }}>iceberg.metadata_sync_predownload_enabled = true</code>
        AND <code>s3_local_cache.enabled = true</code> in config.json.
        Recommended: keep predownload OFF — the metadata cache alone gives
        the big query-time win.
      </Alert>

      {summary && (summary.ran_at || summary.skipped) && (
        <Alert severity={summary.error ? 'error' : summary.skipped ? 'info' : 'success'} sx={{ mb: 2 }}>
          {summary.skipped
            ? `Sync disabled: ${summary.reason || 'check config'}`
            : summary.error
              ? `Last run errored: ${summary.error}`
              : `Last run at ${summary.ran_at} — ${summary.reconciled ?? 0} reconciled (${summary.ok ?? 0} ok, ${summary.errors ?? 0} err). Interval: ${Math.round((summary.interval_seconds ?? 0) / 60)} min.`}
        </Alert>
      )}

      {/* Cache hit/miss telemetry */}
      {stats.enabled !== undefined && (
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 2, mb: 2 }}>
          <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              Snapshot pointer (L1)
            </Typography>
            <Typography variant="body2" fontWeight={600}>
              {stats.pointer_hits ?? 0} hits / {stats.pointer_misses ?? 0} miss
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {stats.pointer_count ?? 0} cached
            </Typography>
          </Box>
          <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              Snapshot contents
            </Typography>
            <Typography variant="body2" fontWeight={600}>
              {stats.contents_l1_hits ?? 0} L1 / {stats.contents_l2_hits ?? 0} L2
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {stats.contents_misses ?? 0} miss · {stats.l2_row_count ?? 0} in DB
            </Typography>
          </Box>
          <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              Per-manifest (BF-298)
            </Typography>
            <Typography variant="body2" fontWeight={600}>
              {stats.manifest_l1_hits ?? 0} L1 / {stats.manifest_l2_hits ?? 0} L2
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {stats.manifest_misses ?? 0} miss · {stats.manifest_stores ?? 0} stored
            </Typography>
          </Box>
          <Box sx={{ p: 1.5, bgcolor: stats.enabled ? 'success.light' : 'warning.light', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              Cache state
            </Typography>
            <Typography variant="body2" fontWeight={600}>
              {stats.enabled ? 'enabled' : 'disabled'}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {stats.contents_l1_count ?? 0} hot in RAM
            </Typography>
          </Box>
        </Box>
      )}

      {msg && (
        <Alert severity="success" sx={{ mb: 2, whiteSpace: 'pre-wrap', fontFamily: 'monospace', fontSize: 12 }}
                onClose={() => setMsg(null)}>{msg}</Alert>
      )}
      {err && (
        <Alert severity="error" sx={{ mb: 2, whiteSpace: 'pre-wrap', fontFamily: 'monospace', fontSize: 12 }}
                onClose={() => setErr(null)}>{err}</Alert>
      )}

      <Divider sx={{ my: 1 }} />

      {/* LIVE SYNC PROGRESS — visible only while a sync is running */}
      {manualRunning && (
        <Box sx={{ mb: 2, p: 1.5, bgcolor: 'info.light', borderRadius: 1, border: '1px solid', borderColor: 'info.main' }}>
          <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 1 }}>
            <CircularProgress size={18} thickness={5} />
            <Box sx={{ flex: 1 }}>
              <Typography variant="body2" fontWeight={600}>
                Sync in progress — {progress.completed_count ?? 0} of {progress.total_count ?? '?'} tables done
                {typeof manualElapsed === 'number' && (
                  <Typography component="span" variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                    ({manualElapsed.toFixed(0)}s elapsed)
                  </Typography>
                )}
              </Typography>
              {progress.current_table && (
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontFamily: 'monospace' }}>
                  Currently syncing: <strong>{progress.current_table.bucket}</strong>/{progress.current_table.table_prefix}
                </Typography>
              )}
              {progress.total_count && progress.total_count > 0 && (
                <Box sx={{ width: '100%', height: 4, bgcolor: 'grey.300', borderRadius: 1, mt: 0.5 }}>
                  <Box sx={{
                    width: `${((progress.completed_count ?? 0) / progress.total_count) * 100}%`,
                    height: '100%',
                    bgcolor: 'primary.main',
                    borderRadius: 1,
                    transition: 'width 0.3s',
                  }} />
                </Box>
              )}
            </Box>
          </Stack>
          {progress.per_table_results && progress.per_table_results.length > 0 && (
            <Accordion variant="outlined" sx={{ mt: 1, bgcolor: 'background.paper' }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography variant="caption">
                  Recent table outcomes ({progress.per_table_results.length})
                </Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ maxHeight: 240, overflow: 'auto', p: 0 }}>
                <Table size="small">
                  <TableBody>
                    {progress.per_table_results.slice().reverse().map((r, i) => (
                      <TableRow key={i}>
                        <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>
                          {r.bucket}/{r.table_prefix}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }}>
                          <Chip size="small"
                                label={r.status}
                                color={r.status === 'ok' ? 'success' : 'error'}
                                sx={{ fontSize: 9, height: 16 }} />
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          {r.files_count ?? '—'} files
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          {r.elapsed_s.toFixed(1)}s
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </AccordionDetails>
            </Accordion>
          )}
        </Box>
      )}

      {/* RECENT SYNC RUNS HISTORY — collapsed by default, shows last 20 */}
      {recentRuns.length > 0 && (
        <Accordion variant="outlined" sx={{ mb: 1.5 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">
              Recent sync runs ({recentRuns.length})
            </Typography>
          </AccordionSummary>
          <AccordionDetails sx={{ p: 0 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontSize: 11 }}>Completed</TableCell>
                  <TableCell sx={{ fontSize: 11 }} align="right">Tables</TableCell>
                  <TableCell sx={{ fontSize: 11 }} align="right">OK</TableCell>
                  <TableCell sx={{ fontSize: 11 }} align="right">Errors</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {recentRuns.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell sx={{ fontSize: 11 }}>
                      {r.completed_at
                        ? new Date(r.completed_at * 1000).toLocaleString()
                        : r.ran_at}
                    </TableCell>
                    <TableCell sx={{ fontSize: 11 }} align="right">{r.reconciled}</TableCell>
                    <TableCell sx={{ fontSize: 11 }} align="right">
                      <Chip size="small" label={r.ok} color="success" sx={{ fontSize: 9, height: 16 }} />
                    </TableCell>
                    <TableCell sx={{ fontSize: 11 }} align="right">
                      {r.errors > 0
                        ? <Chip size="small" label={r.errors} color="error" sx={{ fontSize: 9, height: 16 }} />
                        : <Typography variant="caption">0</Typography>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* TABLE LIST: now with pagination + filters */}
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="subtitle2">
          Watched tables
          {pagination.total > 0 && (
            <Typography component="span" variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
              ({pagination.total} total — showing page {pagination.page} of {pagination.total_pages})
            </Typography>
          )}
        </Typography>
        <Box sx={{ flex: 1 }} />
        <TextField
          size="small" placeholder="Search bucket / prefix…"
          value={tableSearch}
          onChange={(e) => { setTableSearch(e.target.value); setPage(1); }}
          sx={{ width: 220, '& input': { fontSize: 12 } }}
        />
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <Select
            value={statusFilter}
            displayEmpty
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            sx={{ fontSize: 12 }}
          >
            <MenuItem value="">All status</MenuItem>
            <MenuItem value="ok">OK</MenuItem>
            <MenuItem value="error">Error</MenuItem>
            <MenuItem value="unsynced">Not yet synced</MenuItem>
          </Select>
        </FormControl>
      </Stack>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
          <CircularProgress size={28} />
        </Box>
      ) : tables.length === 0 ? (
        <Alert severity="info">
          No tables watched yet. Click &quot;Pre-warm all tables&quot; to discover
          and pre-load every Iceberg table, or run a query against an Iceberg
          table — it will be auto-added to the registry.
        </Alert>
      ) : (
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Connection</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Bucket / Prefix</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Snapshot</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }} align="right">Files</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }} align="right">Last sync</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Status</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }} />
            </TableRow>
          </TableHead>
          <TableBody>
            {tables.map((t) => (
              <TableRow key={t.id} hover>
                <TableCell sx={{ fontSize: 11 }}>{t.connection_id}</TableCell>
                <TableCell sx={{ fontSize: 11 }}>
                  <Box>
                    <strong>{t.bucket}</strong>
                    <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                      {t.table_prefix}
                    </Typography>
                  </Box>
                  {t.pinned && <Chip size="small" label="pinned" sx={{ ml: 0.5, fontSize: 9, height: 16 }} />}
                </TableCell>
                <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>
                  {t.last_snapshot_id ? t.last_snapshot_id.slice(0, 14) + '…' : '—'}
                </TableCell>
                <TableCell sx={{ fontSize: 11 }} align="right">
                  {t.last_files_count ?? '—'}
                </TableCell>
                <TableCell sx={{ fontSize: 11 }} align="right">
                  {t.last_sync_seconds ? `${t.last_sync_seconds.toFixed(1)}s` : '—'}
                </TableCell>
                <TableCell>
                  <Chip
                    size="small"
                    label={t.last_sync_status}
                    color={t.last_sync_status === 'ok' ? 'success'
                          : t.last_sync_status === 'error' ? 'error' : 'default'}
                    sx={{ fontSize: 10, height: 18 }}
                  />
                  {t.last_sync_error && (
                    <Tooltip title={t.last_sync_error}>
                      <Typography variant="caption" sx={{ display: 'block', fontSize: 9, color: 'error.main' }}>
                        {t.last_sync_error.slice(0, 50)}…
                      </Typography>
                    </Tooltip>
                  )}
                </TableCell>
                <TableCell align="right">
                  <Tooltip title={
                    t.predownload_rule
                      ? `Predownload rule: ${t.predownload_rule.strategy || 'default'}`
                      : 'Configure predownload rule (off / recent dates / specific dates / custom)'
                  }>
                    <IconButton size="small"
                      color={t.predownload_rule ? 'primary' : 'default'}
                      onClick={() => openRuleEditor(t)}
                      disabled={!!busy}>
                      <TuneIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Refresh now">
                    <IconButton size="small" onClick={() => refreshOne(t)}
                      disabled={busy === `row-${t.id}`}>
                      {busy === `row-${t.id}` ? <CircularProgress size={14} /> : <RefreshIcon fontSize="small" />}
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Stop syncing this table">
                    <IconButton size="small" onClick={() => unwatch(t)}
                      disabled={!!busy}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* PAGINATION CONTROLS */}
      {pagination.total > 0 && pagination.total > pagination.page_size && (
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1.5 }}>
          <Typography variant="caption" color="text.secondary">
            Showing {((pagination.page - 1) * pagination.page_size) + 1}
            –{Math.min(pagination.page * pagination.page_size, pagination.total)}
            {' '}of {pagination.total}
          </Typography>
          <Box sx={{ flex: 1 }} />
          <FormControl size="small" sx={{ minWidth: 80 }}>
            <Select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
              sx={{ fontSize: 12 }}
            >
              <MenuItem value={25}>25 / page</MenuItem>
              <MenuItem value={50}>50 / page</MenuItem>
              <MenuItem value={100}>100 / page</MenuItem>
              <MenuItem value={250}>250 / page</MenuItem>
            </Select>
          </FormControl>
          <Button size="small" variant="outlined"
                  disabled={page <= 1}
                  onClick={() => setPage(1)}>« First</Button>
          <Button size="small" variant="outlined"
                  disabled={page <= 1}
                  onClick={() => setPage(p => Math.max(1, p - 1))}>‹ Prev</Button>
          <Typography variant="body2" sx={{ minWidth: 70, textAlign: 'center' }}>
            {pagination.page} / {pagination.total_pages}
          </Typography>
          <Button size="small" variant="outlined"
                  disabled={page >= pagination.total_pages}
                  onClick={() => setPage(p => Math.min(pagination.total_pages, p + 1))}>Next ›</Button>
          <Button size="small" variant="outlined"
                  disabled={page >= pagination.total_pages}
                  onClick={() => setPage(pagination.total_pages)}>Last »</Button>
        </Stack>
      )}

      {/* BF-318 — per-table predownload rule editor */}
      <Dialog open={ruleDialogOpen} onClose={() => setRuleDialogOpen(false)}
              maxWidth="sm" fullWidth>
        <DialogTitle>
          Predownload rule
          {ruleTarget && (
            <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
              {ruleTarget.bucket} / {ruleTarget.table_prefix}
            </Typography>
          )}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Alert severity="info" sx={{ fontSize: 12 }}>
              Controls which DATA files this table&apos;s sync pre-downloads
              into the local cache.  When unset (use <strong>Clear</strong>),
              the table falls back to the global
              <code style={{ margin: '0 4px' }}>iceberg.metadata_sync_predownload_*</code>
              defaults.  This does NOT affect metadata caching — that&apos;s
              always on.
            </Alert>

            <FormControl size="small" fullWidth>
              <InputLabel>Strategy</InputLabel>
              <Select label="Strategy" value={ruleStrategy}
                       onChange={(e) => setRuleStrategy(e.target.value)}>
                <MenuItem value="off">Off — skip predownload for this table</MenuItem>
                <MenuItem value="top_n_by_record_count">Top-N by record count (default behaviour, set max_files)</MenuItem>
                <MenuItem value="recent_dates">Recent dates — last N days of a partition column</MenuItem>
                <MenuItem value="specific_dates">Specific dates — explicit list</MenuItem>
                <MenuItem value="custom">Custom — arbitrary AND-ed filter list</MenuItem>
                <MenuItem value="__clear__">Clear (revert to global default)</MenuItem>
              </Select>
            </FormControl>

            {(ruleStrategy === 'recent_dates' || ruleStrategy === 'specific_dates') && (
              <TextField label="Partition column" size="small" fullWidth
                          value={rulePartitionColumn}
                          onChange={(e) => setRulePartitionColumn(e.target.value)}
                          helperText="e.g. business_close_date — must be a partition column on this table" />
            )}

            {ruleStrategy === 'recent_dates' && (
              <TextField label="Lookback days" size="small" type="number"
                          value={ruleLookbackDays}
                          onChange={(e) => setRuleLookbackDays(Number(e.target.value))}
                          helperText="Files where partition[col] >= today − N days" />
            )}

            {ruleStrategy === 'specific_dates' && (
              <TextField label="Dates (comma-separated)" size="small" fullWidth multiline rows={2}
                          value={ruleDatesText}
                          onChange={(e) => setRuleDatesText(e.target.value)}
                          placeholder="2025-09-01, 2025-09-15, 2025-10-01"
                          helperText="Files matching ANY of these partition values" />
            )}

            {ruleStrategy === 'custom' && (
              <TextField label="Filters (JSON array)" size="small" fullWidth multiline rows={5}
                          value={ruleCustomFiltersText}
                          onChange={(e) => setRuleCustomFiltersText(e.target.value)}
                          placeholder='[{"col":"code","op":"in","val":["EMEA","APAC"]},{"col":"d","op":"gte","val":"2025-09-01"}]'
                          helperText="Operators: eq, in, gte, lte, gt, lt — multiple filters AND-ed"
                          sx={{ fontFamily: 'monospace' }} />
            )}

            {ruleStrategy !== 'off' && ruleStrategy !== '__clear__' && (
              <Stack direction="row" spacing={2}>
                <TextField label="Max files (override global)" size="small" type="number"
                            value={ruleMaxFiles}
                            onChange={(e) => setRuleMaxFiles(e.target.value)}
                            placeholder="leave blank to use global"
                            sx={{ flexGrow: 1 }} />
                <TextField label="Max GB (override global)" size="small" type="number"
                            value={ruleMaxGb}
                            onChange={(e) => setRuleMaxGb(e.target.value)}
                            placeholder="leave blank to use global"
                            sx={{ flexGrow: 1 }} />
              </Stack>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRuleDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={saveRule}
                   disabled={busy?.startsWith('rule-')}>
            {busy?.startsWith('rule-') ? <CircularProgress size={16} /> :
              ruleStrategy === '__clear__' ? 'Clear rule' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* BF-COL-STATS — per-table scan picker */}
      <Dialog open={pickerOpen} onClose={() => setPickerOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            Pick tables to scan
            <Box sx={{ flex: 1 }} />
            {discoveredLoading && <CircularProgress size={16} />}
          </Box>
          <Typography variant="caption" color="text.secondary">
            Reads each parquet file's footer (16-256 KB per file).
            Tables sharing the same S3 path are scanned once and shared across connections.
          </Typography>
        </DialogTitle>
        <DialogContent dividers>
          <Stack spacing={1.5}>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
              <TextField
                size="small"
                placeholder="Search table / bucket / connection..."
                value={pickerSearch}
                onChange={(e) => setPickerSearch(e.target.value)}
                sx={{ flex: 1, minWidth: 240 }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><RefreshIcon sx={{ fontSize: 16 }} /></InputAdornment>,
                }}
              />
              <Button size="small" variant="outlined"
                onClick={() => {
                  // Select all visible (post-filter), deduped by (bucket, prefix)
                  const seenSh = new Set<string>();
                  const next = new Set<string>();
                  for (const t of filteredDiscoveredTables) {
                    const sh = `${t.bucket}|${t.s3_prefix.replace(/\/$/, '')}`;
                    if (seenSh.has(sh)) continue;
                    seenSh.add(sh);
                    next.add(`${t.connection_id}|${t.table_name}`);
                  }
                  setPickerSelected(next);
                }}>
                Select all (visible)
              </Button>
              <Button size="small" variant="outlined"
                onClick={() => setPickerSelected(new Set())}>
                Clear
              </Button>
              <FormControlLabel
                control={<Checkbox checked={pickerForce} size="small"
                  onChange={(e) => setPickerForce(e.target.checked)} />}
                label={<Typography variant="caption">Force re-scan (clear existing rows first)</Typography>}
              />
              <Tooltip title="Parallel boto3 connections per scan. Default 32. If your network/proxy throttles S3 connections, lower it. If you have headroom, raising to 64-128 can speed scans 2-4×.">
                <TextField
                  size="small"
                  label="Workers"
                  type="number"
                  value={pickerMaxWorkers}
                  onChange={(e) => {
                    const v = parseInt(e.target.value, 10);
                    if (!isNaN(v) && v >= 1 && v <= 256) setPickerMaxWorkers(v);
                  }}
                  inputProps={{ min: 1, max: 256, step: 8 }}
                  sx={{ width: 100, '& input': { fontSize: '0.75rem', py: 0.5 } }}
                />
              </Tooltip>
              <Tooltip title="Time a single S3 footer read to diagnose slow scan rates">
                <span>
                  <Button
                    size="small" variant="outlined"
                    onClick={runDiagnose}
                    disabled={diagnoseRunning || pickerSelected.size === 0}
                    startIcon={diagnoseRunning ? <CircularProgress size={12} /> : null}
                  >
                    Diagnose 1 file
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="BF-358: run extract on 8 files in parallel — tells you whether scan slowness is per-file work or parallelism (workers serializing on shared resource).  Returns a verdict: OK / POOR_PARALLELISM / WORKERS_NOT_SCHEDULED / SLOW_PER_FILE.">
                <span>
                  <Button
                    size="small" variant="outlined"
                    onClick={runParallelismTest}
                    disabled={paraRunning || pickerSelected.size === 0}
                    startIcon={paraRunning ? <CircularProgress size={12} /> : null}
                  >
                    Parallelism test
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="BF-357: drop cached S3 client handlers so the next call rebuilds with current config (e.g. picks up new max_pool_connections after BF-349 without a pod restart).">
                <span>
                  <Button
                    size="small" variant="outlined"
                    onClick={runFlushHandlerCache}
                    disabled={flushBusy}
                    startIcon={flushBusy ? <CircularProgress size={12} /> : null}
                  >
                    Flush S3 cache
                  </Button>
                </span>
              </Tooltip>
            </Box>

            {/* ── Diagnose result (single-file end-to-end timing) ─────────── */}
            {diagnoseResult && (
              <Alert severity={
                diagnoseResult.error ? 'error'
                : (diagnoseResult.extract_e2e_seconds ?? diagnoseResult.total_seconds ?? 0) > 2 ? 'warning'
                : 'success'
              } sx={{ fontSize: 12 }} onClose={() => setDiagnoseResult(null)}>
                <strong>One-file diagnose:</strong>{' '}
                {diagnoseResult.error ? `Error: ${diagnoseResult.error}` : (
                  <>
                    HEAD <strong>{diagnoseResult.head_seconds?.toFixed(2) ?? '—'}s</strong>{' · '}
                    GET <strong>{diagnoseResult.get_seconds?.toFixed(2) ?? '—'}s</strong>
                    {diagnoseResult.extract_e2e_seconds != null && (
                      <>
                        {' · '}<strong>full extract {diagnoseResult.extract_e2e_seconds.toFixed(2)}s</strong>
                        {diagnoseResult.extract_breakdown?.row_groups != null && (
                          <> ({diagnoseResult.extract_breakdown.row_groups} row groups, {diagnoseResult.extract_breakdown?.columns_iterated ?? '?'} col-iter)</>
                        )}
                      </>
                    )}
                    {diagnoseResult.active_pool_connections != null && (
                      <>
                        {' · '}pool <strong style={{ color: diagnoseResult.active_pool_connections < 32 ? '#d32f2f' : 'inherit' }}>
                          {diagnoseResult.active_pool_connections}
                        </strong>
                      </>
                    )}
                    {diagnoseResult.pool_warning && (
                      <Box sx={{ mt: 0.5, color: 'warning.main', fontSize: 11 }}>
                        ⚠️ {diagnoseResult.pool_warning}
                      </Box>
                    )}
                    {diagnoseResult.extract_error && (
                      <Box sx={{ mt: 0.5, color: 'error.main', fontSize: 11 }}>
                        Extract error: {diagnoseResult.extract_error}
                      </Box>
                    )}
                    <Box sx={{ mt: 0.5, fontSize: 11, color: 'text.secondary' }}>
                      <em>
                        {(diagnoseResult.extract_e2e_seconds ?? 0) < 0.5
                          ? 'Per-file work is fast — if scan is still slow, run Parallelism test next.'
                          : (diagnoseResult.extract_e2e_seconds ?? 0) < 2
                            ? 'Per-file work is normal. Healthy throughput should be 10-50 f/s.'
                            : 'Per-file work is slow — narrow target_columns or check S3 latency in breakdown above.'}
                      </em>
                    </Box>
                  </>
                )}
              </Alert>
            )}

            {/* ── Parallelism test result — BF-358 ────────────────────────── */}
            {paraResult && (
              <Alert
                severity={
                  paraResult.error ? 'error'
                  : paraResult.verdict === 'OK' ? 'success'
                  : paraResult.verdict === 'SLOW_PER_FILE' ? 'warning'
                  : 'error'
                }
                sx={{ fontSize: 12 }}
                onClose={() => setParaResult(null)}
              >
                <strong>Parallelism test:</strong>{' '}
                {paraResult.error ? `Error: ${paraResult.error}` : (
                  <>
                    verdict <Chip size="small" label={paraResult.verdict || '?'} sx={{ height: 18, fontSize: 10, ml: 0.25 }}
                      color={paraResult.verdict === 'OK' ? 'success' : 'warning'} />
                    {' · '}{paraResult.threads_actually_used ?? 0}/{paraResult.parallel_workers ?? 0} threads ran
                    {' · '}<strong>{(paraResult.parallel_speedup ?? 0).toFixed(1)}×</strong> speedup
                    {' (ideal ≈ '}{paraResult.parallel_workers ?? 0}{'×)'}
                    {' · '}<strong>{(paraResult.throughput_files_per_sec ?? 0).toFixed(1)} f/s</strong>
                    {paraResult.active_pool_connections != null && (
                      <>{' · '}pool {paraResult.active_pool_connections}</>
                    )}
                    {paraResult.hint && (
                      <Box sx={{ mt: 0.5, fontSize: 11 }}><em>{paraResult.hint}</em></Box>
                    )}
                    {paraResult.per_file && paraResult.per_file.length > 0 && (
                      <Box sx={{ mt: 0.5, fontSize: 10.5, color: 'text.secondary' }}>
                        Slowest 3 files:{' '}
                        {paraResult.per_file.slice(0, 3).map((p, i) => (
                          <span key={i} style={{ marginRight: 8 }}>
                            <code>{p.file}</code> {p.total.toFixed(2)}s on {p.thread}
                            {p.error ? ` (err: ${p.error.slice(0, 40)})` : ''}
                          </span>
                        ))}
                      </Box>
                    )}
                  </>
                )}
              </Alert>
            )}

            <Alert severity="info" sx={{ fontSize: 12 }}>
              <strong>Auto-selected</strong> tables with no current coverage. Already-covered
              tables are unchecked — tick them only if you want to refresh stats.
              {' '}<strong>Force</strong> clears existing rows for those tables before re-scanning.
            </Alert>

            <Alert severity="info" icon={false} sx={{ fontSize: 11, py: 0.5, '& .MuiAlert-message': { py: 0.25 } }}>
              <strong>Per-table columns:</strong> click <strong>Columns</strong> on any row
              below to limit the scan to specific columns (huge speedup on wide tables — e.g.
              30 of 960 columns is ~30× faster).  Empty = scan all columns.
            </Alert>

            {discoveredTables.length === 0 && !discoveredLoading && (
              <Alert severity="warning" sx={{ fontSize: 12 }}>
                No Iceberg tables registered. Configure tables on an S3 connection
                (set format=iceberg) to scan column stats.
              </Alert>
            )}

            <Box sx={{ maxHeight: '50vh', overflow: 'auto', border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" sx={{ fontSize: 11, fontWeight: 600 }}>Pick</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Table</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Connection</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>S3 path</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Columns</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }} align="right">Files cached</TableCell>
                    <TableCell sx={{ fontSize: 11, fontWeight: 600 }}>Coverage</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredDiscoveredTables.map((t) => {
                    const key = `${t.connection_id}|${t.table_name}`;
                    const checked = pickerSelected.has(key);
                    const sharedCount = (t.shared_with_connections || []).length;
                    const hasCoverage = !!t.coverage && (t.coverage.files || 0) > 0;
                    return (
                      <TableRow key={key} hover
                        onClick={() => togglePickerRow(t.connection_id, t.table_name)}
                        sx={{ cursor: 'pointer' }}>
                        <TableCell padding="checkbox">
                          <Checkbox size="small" checked={checked} />
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }}>
                          <strong>{t.table_name}</strong>
                          {sharedCount > 0 && (
                            <Tooltip title={`Same S3 path is also registered on ${sharedCount} other connection(s) — they'll be covered automatically by this scan`}>
                              <Chip
                                label={`shared ×${sharedCount + 1}`}
                                size="small"
                                color="info"
                                variant="outlined"
                                sx={{ ml: 0.75, fontSize: 9, height: 16 }}
                              />
                            </Tooltip>
                          )}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }}>{t.connection_name}</TableCell>
                        <TableCell sx={{ fontSize: 10, color: 'text.secondary', fontFamily: 'monospace' }}>
                          {t.bucket}/{t.s3_prefix}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }}>
                          {/* Per-table column whitelist + partition filter: click to edit */}
                          {(() => {
                            const colKey = `${t.connection_id}|${t.table_name}`;
                            const rawCols = pickerColsByTable[colKey] || '';
                            const colCount = rawCols.split(',').map(s => s.trim()).filter(Boolean).length;
                            const rawParts = pickerPartsByTable[colKey] || '';
                            const partsActive = rawParts.trim().length > 0;
                            const tipParts: string[] = [];
                            if (colCount > 0) tipParts.push(`Columns: ${colCount}`);
                            if (partsActive) tipParts.push(`Partition filter: ${rawParts.slice(0, 60)}${rawParts.length > 60 ? '…' : ''}`);
                            const tip = tipParts.length === 0
                              ? 'Click to set per-table column whitelist + partition filter'
                              : tipParts.join(' · ');
                            return (
                              <Tooltip title={tip}>
                                <Button
                                  size="small"
                                  variant={(colCount > 0 || partsActive) ? 'contained' : 'outlined'}
                                  color={partsActive ? 'warning' : (colCount > 0 ? 'primary' : 'inherit')}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setColEditorAnchor({ el: e.currentTarget, tableKey: colKey });
                                  }}
                                  sx={{
                                    fontSize: 10, py: 0, height: 22, textTransform: 'none',
                                    minWidth: 80,
                                  }}
                                >
                                  {colCount === 0 && !partsActive ? 'all' :
                                    `${colCount > 0 ? `${colCount}c` : 'all-c'}${partsActive ? ' · part' : ''}`}
                                </Button>
                              </Tooltip>
                            );
                          })()}
                        </TableCell>
                        <TableCell sx={{ fontSize: 11 }} align="right">
                          {/* BF-359: files may be null when status was fetched
                              with include_distinct_counts=false (the cheap
                              path used by polling).  Show row count or '—'. */}
                          {t.coverage?.files != null
                            ? t.coverage.files.toLocaleString()
                            : (t.coverage?.rows != null
                                ? `${t.coverage.rows.toLocaleString()} rows`
                                : '—')}
                        </TableCell>
                        <TableCell>
                          {hasCoverage
                            ? <Chip label="covered" size="small" color="success" sx={{ fontSize: 10, height: 18 }} />
                            : <Chip label="empty" size="small" color="warning" sx={{ fontSize: 10, height: 18 }} />}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {filteredDiscoveredTables.length === 0 && discoveredTables.length > 0 && (
                    <TableRow>
                      <TableCell colSpan={7} align="center" sx={{ color: 'text.secondary', py: 3 }}>
                        No tables match "{pickerSearch}"
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Typography variant="caption" color="text.secondary" sx={{ ml: 2 }}>
            {pickerSelected.size} selected
          </Typography>
          <Box sx={{ flex: 1 }} />
          <Button onClick={() => setPickerOpen(false)}>Cancel</Button>
          <Button variant="contained"
            onClick={submitPickerScan}
            disabled={pickerSelected.size === 0 || busy === 'col-stats-scan'}
            startIcon={busy === 'col-stats-scan' ? <CircularProgress size={14} /> : null}>
            Scan {pickerSelected.size} table{pickerSelected.size !== 1 ? 's' : ''}
            {pickerForce && ' (force)'}
          </Button>
        </DialogActions>

        {/* Per-table column whitelist popover */}
        <Popover
          open={!!colEditorAnchor}
          anchorEl={colEditorAnchor?.el || null}
          onClose={() => setColEditorAnchor(null)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
          PaperProps={{ sx: { p: 2, width: 480 } }}
        >
          {colEditorAnchor && (() => {
            const tableKey = colEditorAnchor.tableKey;
            const [cidStr, ...rest] = tableKey.split('|');
            const tableName = rest.join('|');
            const cid = Number(cidStr);
            const tableInfo = discoveredTables.find(
              t => t.connection_id === cid && t.table_name === tableName);
            const currentVal = pickerColsByTable[tableKey] || '';
            const cachedSchema = colSchemaByTable[tableKey];
            const isLoading = colSchemaLoading === tableKey;
            const setVal = (v: string) => setPickerColsByTable(prev => {
              const next = { ...prev };
              if (v.trim()) next[tableKey] = v;
              else delete next[tableKey];
              return next;
            });
            const loadSchema = async () => {
              setColSchemaLoading(tableKey);
              try {
                const resp: any = await safeFetch(
                  `/api/connections/${cid}/tables/${encodeURIComponent(tableName)}/schema`,
                );
                const cols = (resp?.columns || resp || [])
                  .map((c: any) => c.name || c.column_name || c)
                  .filter((s: any) => typeof s === 'string');
                setColSchemaByTable(prev => ({ ...prev, [tableKey]: cols }));
              } catch (e) {
                setErr(`Failed to load schema for ${tableName}: ${e}`);
              } finally {
                setColSchemaLoading(null);
              }
            };
            return (
              <Stack spacing={1.5}>
                <Box>
                  <Typography variant="subtitle2">Columns to scan</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {tableInfo?.connection_name || `connection ${cid}`} · {tableName}
                  </Typography>
                </Box>
                <Alert severity="info" sx={{ fontSize: 11, py: 0.5 }}>
                  Empty = scan ALL columns. Limiting to a curated list speeds the scan
                  proportionally (e.g. 30 / 960 columns is ~30× faster).
                </Alert>
                <TextField
                  size="small"
                  fullWidth
                  multiline
                  minRows={4}
                  maxRows={10}
                  placeholder="amount, business_close_date, system_id, region, customer_id"
                  value={currentVal}
                  onChange={(e) => setVal(e.target.value)}
                  helperText={(() => {
                    const n = currentVal.split(',').map(s => s.trim()).filter(Boolean).length;
                    return n === 0
                      ? 'Empty — scans ALL columns on this table'
                      : `${n} column${n === 1 ? '' : 's'} selected`;
                  })()}
                  sx={{ '& textarea': { fontFamily: 'monospace', fontSize: '0.75rem' } }}
                />
                <Divider sx={{ my: 0.5 }} />
                {/* Per-table partition filter — scan only specific partition values.
                    Auto-loads partition columns + values from cached metadata so
                    admin doesn't have to type column names. */}
                {(() => {
                  const partInfo = partInfoByTable[tableKey];
                  const loadParts = async () => {
                    // Guard against concurrent duplicate fetches (rapid typing)
                    if (partInfoLoading === tableKey) return;
                    setPartInfoLoading(tableKey);
                    try {
                      const j: any = await safeFetch(
                        `/api/connections/${cid}/tables/${encodeURIComponent(tableName)}/partitions`,
                      );
                      // BF-498 — prefer SOURCE column names for display +
                      // validation (what users naturally type in WHERE
                      // clauses) but keep the partition FIELD name for
                      // looking up sample values from the backend response
                      // (backend keys values by field name).  For identity
                      // transforms source == field; only differs when the
                      // writer renamed under day/bucket/truncate (e.g.
                      // "businessdate_day").
                      const partCols = j?.partition_columns || [];
                      const partVals = j?.partition_values || j?.values || {};
                      const cols: string[] = [];
                      const values: Record<string, string[]> = {};
                      for (const c of partCols) {
                        if (typeof c === 'string') {
                          if (!cols.includes(c)) cols.push(c);
                          if (Array.isArray(partVals[c])) values[c] = partVals[c].map(String).slice(0, 500);
                          continue;
                        }
                        const display = (c.source_column || c.name || '').trim();
                        const fieldName = (c.name || c.source_column || '').trim();
                        if (!display) continue;
                        if (!cols.includes(display)) cols.push(display);
                        // Look up values by the partition FIELD name (how
                        // the backend keys them) but expose under the
                        // display name (so the UI chip click maps directly
                        // to what the user typed in the filter input).
                        const v = partVals[fieldName] || partVals[display];
                        if (Array.isArray(v)) values[display] = v.map(String).slice(0, 500);
                      }
                      setPartInfoByTable(prev => ({ ...prev, [tableKey]: { columns: cols, values } }));
                    } catch (e) {
                      setErr(`Failed to load partition info: ${e}`);
                      // Sentinel: store empty info so auto-load gate (!partInfo)
                      // stops firing on every keystroke. Admin can hit Reload
                      // explicitly to retry after fixing the connection.
                      setPartInfoByTable(prev => prev[tableKey]
                        ? prev
                        : { ...prev, [tableKey]: { columns: [], values: {} } });
                    } finally {
                      setPartInfoLoading(prev => (prev === tableKey ? null : prev));
                    }
                  };
                  return (
                    <Box>
                      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.25 }}>
                        <Typography variant="caption" sx={{ fontWeight: 700 }}>
                          Partition filter — speeds huge tables 30×+
                        </Typography>
                        <Box sx={{ flexGrow: 1 }} />
                        <Button size="small" variant="text" onClick={loadParts}
                          disabled={partInfoLoading === tableKey}
                          startIcon={partInfoLoading === tableKey ? <CircularProgress size={10} /> : null}
                          sx={{ fontSize: 10, py: 0, minHeight: 22 }}>
                          {partInfoLoading === tableKey
                            ? 'Loading…'
                            : (partInfo ? 'Reload' : 'Load partition cols')}
                        </Button>
                      </Stack>
                      <Tooltip title='Format: "column_name=value" — e.g. "business_close_date=2025-09-30". JSON array also accepted for ranges/IN.'>
                        <TextField
                          size="small"
                          fullWidth
                          placeholder={partInfo && partInfo.columns.length > 0
                            ? `${partInfo.columns[0]}=2025-09-30  (must include column_name=)`
                            : 'business_close_date=2025-09-30  (column_name=value format)'}
                          value={pickerPartsByTable[tableKey] || ''}
                          onChange={(e) => {
                            setPickerPartsByTable(prev => {
                              const next = { ...prev };
                              if (e.target.value.trim()) next[tableKey] = e.target.value;
                              else delete next[tableKey];
                              return next;
                            });
                            // Auto-load partition cols on first non-empty input
                            // so typo detection runs without requiring extra click.
                            // Gate on partInfoLoading (NOT colSchemaLoading — that
                            // tracks the schema-popover, a different request).
                            if (e.target.value.trim() && !partInfo && partInfoLoading !== tableKey) {
                              loadParts();
                            }
                          }}
                          sx={{ '& input': { fontFamily: 'monospace', fontSize: '0.75rem' } }}
                        />
                      </Tooltip>
                      {/* Live parse feedback — shows EXACTLY what will be sent.
                          Auto-strips surrounding quotes from values and warns
                          if the column name doesn't match a known partition col. */}
                      {(() => {
                        const raw = pickerPartsByTable[tableKey] || '';
                        if (!raw.trim()) {
                          return (
                            <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'text.disabled', fontSize: 10 }}>
                              Empty — scans all partitions
                            </Typography>
                          );
                        }
                        // Strip surrounding quotes (single or double) — common
                        // SQL-style mistake when typing partition values.
                        const stripQuotes = (v: string) => {
                          const t = v.trim();
                          if ((t.startsWith("'") && t.endsWith("'")) ||
                              (t.startsWith('"') && t.endsWith('"'))) {
                            return t.slice(1, -1);
                          }
                          return t;
                        };
                        let parsed: any[] = [];
                        let isJson = false;
                        try {
                          const j = JSON.parse(raw);
                          if (Array.isArray(j)) { parsed = j; isJson = true; }
                        } catch {}
                        if (!isJson) {
                          parsed = raw.split(',').map(s => s.trim()).filter(Boolean)
                            .map(pair => {
                              const [col, ...rest] = pair.split('=');
                              if (!col || rest.length === 0) return null;
                              return {
                                col: col.trim(),
                                op: 'equals',
                                val: stripQuotes(rest.join('=')),
                              };
                            }).filter(Boolean) as any[];
                        }
                        if (parsed.length === 0) {
                          return (
                            <Alert severity="error" sx={{ fontSize: 11, py: 0.5, mt: 0.5 }}>
                              <strong>Parser found 0 filters.</strong> Did you forget the column name?
                              Use <code>column_name=value</code> format — e.g. <code>business_close_date=2025-09-30</code>.
                              Without this, ALL files will be scanned (no pruning).
                            </Alert>
                          );
                        }
                        // Validate column names against loaded partition columns
                        // (if available).  Case-sensitive match against the
                        // table's actual partition spec.
                        const knownPartCols = partInfo?.columns || [];
                        const knownLower = new Set(knownPartCols.map(c => c.toLowerCase()));
                        const knownExact = new Set(knownPartCols);
                        const unknownCols: { typed: string; suggestion?: string }[] = [];
                        const validationSkipped = knownPartCols.length === 0;
                        for (const f of parsed) {
                          if (validationSkipped) continue;
                          if (knownExact.has(f.col)) continue;       // exact match
                          // Case-insensitive lookup → suggest correct case
                          const lc = f.col.toLowerCase();
                          if (knownLower.has(lc)) {
                            const correct = knownPartCols.find(c => c.toLowerCase() === lc);
                            unknownCols.push({ typed: f.col, suggestion: correct });
                          } else {
                            // Look for similar-looking col (hyphen vs underscore typo)
                            const normalized = f.col.toLowerCase().replace(/[-_]/g, '');
                            const match = knownPartCols.find(c =>
                              c.toLowerCase().replace(/[-_]/g, '') === normalized
                            );
                            unknownCols.push({ typed: f.col, suggestion: match });
                          }
                        }
                        return (
                          <>
                            <Box sx={{ mt: 0.5, display: 'flex', flexWrap: 'wrap', gap: 0.25, alignItems: 'center' }}>
                              <Typography variant="caption" sx={{ color: 'success.main', fontWeight: 600, mr: 0.5, fontSize: 10 }}>
                                ✓ Will send {parsed.length} filter{parsed.length === 1 ? '' : 's'}:
                              </Typography>
                              {parsed.map((f, i) => (
                                <Chip
                                  key={i}
                                  size="small"
                                  label={`${f.col} ${f.op || 'equals'} ${f.val ?? ''}`}
                                  sx={{ fontSize: 9, height: 18, fontFamily: 'monospace' }}
                                  color="success"
                                  variant="outlined"
                                />
                              ))}
                            </Box>
                            {validationSkipped && (
                              <Alert severity="info" sx={{ fontSize: 11, py: 0.5, mt: 0.5 }}>
                                <strong>Column name not validated.</strong> Click <strong>Load partition cols</strong> below
                                to verify your column name matches the table's partition spec
                                (Iceberg names are CASE-SENSITIVE).
                              </Alert>
                            )}
                            {unknownCols.length > 0 && (
                              <Alert
                                severity="warning"
                                sx={{ fontSize: 11, py: 0.5, mt: 0.5 }}
                                action={
                                  unknownCols.every(u => !!u.suggestion) && (
                                    <Button
                                      size="small"
                                      onClick={() => {
                                        // Rewrite raw input with suggested col names
                                        let next = raw;
                                        for (const u of unknownCols) {
                                          if (!u.suggestion) continue;
                                          const re = new RegExp(
                                            '(^|,\\s*)' +
                                              u.typed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') +
                                              '(\\s*=)',
                                          );
                                          next = next.replace(re, `$1${u.suggestion}$2`);
                                        }
                                        setPickerPartsByTable(prev => ({ ...prev, [tableKey]: next }));
                                      }}
                                      sx={{ fontSize: 10, py: 0, minHeight: 22 }}
                                    >
                                      Apply fix
                                    </Button>
                                  )
                                }
                              >
                                <strong>Column name mismatch:</strong>{' '}
                                {unknownCols.map((u, i) => (
                                  <span key={i}>
                                    <code>{u.typed}</code>{' '}
                                    {u.suggestion
                                      ? <>→ did you mean <strong><code>{u.suggestion}</code></strong>?</>
                                      : <>(not a partition column on this table)</>}
                                    {i < unknownCols.length - 1 && '; '}
                                  </span>
                                ))}
                                {' — Iceberg names are CASE-SENSITIVE and the column must be in the table\'s partition spec.'}
                              </Alert>
                            )}
                          </>
                        );
                      })()}
                      {/* Preview file-count: VERIFY the filter is actually pruning */}
                      <Stack direction="row" spacing={1} sx={{ mt: 0.5 }} alignItems="center">
                        <Tooltip title="Run a dry-run: see how many files would be scanned with the current filter, without committing to a real scan. Sub-second.">
                          <span>
                            <Button
                              size="small" variant="outlined"
                              disabled={previewByTable[tableKey]?.loading}
                              startIcon={previewByTable[tableKey]?.loading ? <CircularProgress size={12} /> : null}
                              onClick={async () => {
                                setPreviewByTable(prev => ({ ...prev, [tableKey]: { ...(prev[tableKey] || { total_files: 0, matching_files: 0, reduction_pct: 0, partition_columns: [], warning: null }), loading: true } }));
                                // Re-parse the current filter input
                                const rawParts = pickerPartsByTable[tableKey] || '';
                                let parts: any[] = [];
                                if (rawParts.trim()) {
                                  try {
                                    const j = JSON.parse(rawParts);
                                    if (Array.isArray(j)) parts = j;
                                  } catch {
                                    parts = rawParts.split(',').map(s => s.trim()).filter(Boolean)
                                      .map(pair => {
                                        const [col, ...rest] = pair.split('=');
                                        return col && rest.length ? { col: col.trim(), op: 'equals', val: rest.join('=').trim() } : null;
                                      }).filter(Boolean) as any[];
                                  }
                                }
                                try {
                                  const j: any = await safeFetch(
                                    '/api/admin/iceberg/column-stats/preview-files',
                                    { method: 'POST', body: JSON.stringify({
                                      connection_id: cid, table_name: tableName,
                                      partition_filters: parts,
                                    }) },
                                  );
                                  setPreviewByTable(prev => ({ ...prev, [tableKey]: { ...j, loading: false } }));
                                } catch (e) {
                                  setPreviewByTable(prev => ({ ...prev, [tableKey]: { ...(prev[tableKey] || { total_files: 0, matching_files: 0, reduction_pct: 0, partition_columns: [], warning: null }), loading: false } }));
                                  setErr(`Preview failed: ${e}`);
                                }
                              }}
                              sx={{ fontSize: 11, py: 0, height: 26 }}
                            >
                              Preview file count
                            </Button>
                          </span>
                        </Tooltip>
                        {/* BF-363: defensive rendering — preview response
                            may be partially populated when the backend
                            errors mid-flight or when stage timings are
                            absent for an old build.  Default to 0 / [] so
                            we never call toLocaleString on undefined. */}
                        {previewByTable[tableKey] && !previewByTable[tableKey].loading && (() => {
                          const pv: any = previewByTable[tableKey];
                          const matched = pv?.matching_files ?? 0;
                          const total = pv?.total_files ?? 0;
                          const reduction = pv?.reduction_pct ?? 0;
                          return (
                            <Typography variant="caption" sx={{
                              color: pv?.warning ? 'warning.main' :
                                reduction > 50 ? 'success.main' :
                                'text.secondary',
                              fontWeight: 600,
                            }}>
                              {matched.toLocaleString()} / {total.toLocaleString()} files
                              {reduction > 0 ? ` · ${reduction}% pruned` : ''}
                            </Typography>
                          );
                        })()}
                        {/* BF-499 — show which snapshot the diagnostic actually
                            read, so admins can verify the tool is live (not
                            serving cached results) when results disagree
                            with Starburst / other engines. */}
                        {previewByTable[tableKey] && !previewByTable[tableKey].loading &&
                          (previewByTable[tableKey] as any).snapshot_id && (
                          <Tooltip title={(() => {
                            const pv: any = previewByTable[tableKey];
                            const ts = pv.snapshot_timestamp_ms
                              ? new Date(pv.snapshot_timestamp_ms).toLocaleString()
                              : '—';
                            return `Snapshot ${pv.snapshot_id} written at ${ts}` +
                                   (pv.metadata_key ? `\nmetadata: ${pv.metadata_key}` : '') +
                                   `\nforce_fresh=${pv.force_fresh === false ? 'NO (cached)' : 'YES (live S3)'}`;
                          })()}>
                            <Chip
                              size="small"
                              variant="outlined"
                              color={(previewByTable[tableKey] as any).force_fresh === false ? 'warning' : 'success'}
                              label={
                                (previewByTable[tableKey] as any).force_fresh === false
                                  ? 'cached'
                                  : 'live S3'
                              }
                              sx={{ fontSize: 9, height: 18, ml: 0.5 }}
                            />
                          </Tooltip>
                        )}
                      </Stack>
                      {previewByTable[tableKey]?.warning && (
                        <Alert severity="warning" sx={{ fontSize: 11, py: 0.5, mt: 0.5 }}>
                          {previewByTable[tableKey].warning}
                          {(previewByTable[tableKey]?.partition_columns?.length ?? 0) > 0 && (
                            <> Valid partition columns: <strong>{(previewByTable[tableKey]?.partition_columns ?? []).join(', ')}</strong></>
                          )}
                        </Alert>
                      )}

                      {partInfo && partInfo.columns.length > 0 && (
                        <Box sx={{ mt: 0.75 }}>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.25 }}>
                            Partition columns (click to insert):
                          </Typography>
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.25 }}>
                            {partInfo.columns.map(col => (
                              <Chip
                                key={col}
                                label={col}
                                size="small"
                                variant="outlined"
                                onClick={() => {
                                  const cur = pickerPartsByTable[tableKey] || '';
                                  const next = cur.trim()
                                    ? `${cur.replace(/,\s*$/, '')}, ${col}=`
                                    : `${col}=`;
                                  setPickerPartsByTable(prev => ({ ...prev, [tableKey]: next }));
                                }}
                                sx={{ fontSize: 10, height: 20, fontFamily: 'monospace' }}
                              />
                            ))}
                          </Box>
                          {/* Sample values for the first partition column — quick-pick.
                              BF-498 — display cap lifted from 30 to 300; the surrounding
                              Box already has overflow:auto so all values stay reachable
                              via scroll.  Shows the total count when truncated so the
                              admin knows there are more to consider. */}
                          {partInfo.columns[0] && partInfo.values[partInfo.columns[0]] && (
                            <Box sx={{ mt: 0.5 }}>
                              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.25 }}>
                                Sample values for {partInfo.columns[0]}
                                {partInfo.values[partInfo.columns[0]].length > 300
                                  ? ` (showing 300 of ${partInfo.values[partInfo.columns[0]].length})`
                                  : ` (${partInfo.values[partInfo.columns[0]].length})`}:
                              </Typography>
                              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.25, maxHeight: 120, overflow: 'auto' }}>
                                {partInfo.values[partInfo.columns[0]].slice(0, 300).map(val => (
                                  <Chip
                                    key={val}
                                    label={val}
                                    size="small"
                                    onClick={() => {
                                      const filter = `${partInfo.columns[0]}=${val}`;
                                      setPickerPartsByTable(prev => ({ ...prev, [tableKey]: filter }));
                                    }}
                                    sx={{ fontSize: 9, height: 18, fontFamily: 'monospace', cursor: 'pointer' }}
                                  />
                                ))}
                              </Box>
                            </Box>
                          )}
                        </Box>
                      )}
                    </Box>
                  );
                })()}
                <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                  <Tooltip title="Fetch column list from cached schema for this table">
                    <span>
                      <Button
                        size="small" variant="outlined"
                        onClick={loadSchema}
                        disabled={isLoading}
                        startIcon={isLoading ? <CircularProgress size={12} /> : null}
                      >
                        {cachedSchema ? `Reload schema (${cachedSchema.length})` : 'Load schema'}
                      </Button>
                    </span>
                  </Tooltip>
                  {cachedSchema && cachedSchema.length > 0 && (
                    <Button
                      size="small" variant="text"
                      onClick={() => setVal(cachedSchema.join(', '))}
                    >
                      Insert all {cachedSchema.length}
                    </Button>
                  )}
                  <Box sx={{ flexGrow: 1 }} />
                  <Button size="small" onClick={() => setVal('')}>Clear</Button>
                  <Button size="small" variant="contained"
                    onClick={() => setColEditorAnchor(null)}>
                    Done
                  </Button>
                </Stack>
                {cachedSchema && cachedSchema.length > 0 && (
                  <Box sx={{
                    maxHeight: 180, overflow: 'auto',
                    border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 0.5,
                  }}>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', px: 0.5, mb: 0.5 }}>
                      Click a column to add to the list:
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.25 }}>
                      {cachedSchema.map(col => {
                        const inList = currentVal.split(',').map(s => s.trim()).includes(col);
                        return (
                          <Chip
                            key={col}
                            label={col}
                            size="small"
                            color={inList ? 'primary' : 'default'}
                            variant={inList ? 'filled' : 'outlined'}
                            onClick={() => {
                              if (inList) {
                                // Remove from list
                                const remaining = currentVal.split(',').map(s => s.trim())
                                  .filter(s => s && s !== col).join(', ');
                                setVal(remaining);
                              } else {
                                // Add to list
                                const next = currentVal.trim()
                                  ? `${currentVal.replace(/,\s*$/, '')}, ${col}`
                                  : col;
                                setVal(next);
                              }
                            }}
                            sx={{ fontSize: 10, height: 20, fontFamily: 'monospace' }}
                          />
                        );
                      })}
                    </Box>
                  </Box>
                )}
              </Stack>
            );
          })()}
        </Popover>
      </Dialog>
    </Paper>
  );
}
