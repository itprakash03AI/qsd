/**
 * Phase 149.9 — Adaptive Prefetch Daemon status panel in Query Diagnose.
 *
 * Tests:
 *  - Status fetched on mount + rendered (enabled/interval chips, next_run_at)
 *  - Recent ticks table shows when data is present
 *  - "Run tick now" button POSTs to /api/admin/iceberg/prefetch/tick
 *  - "No ticks recorded yet" Alert renders when ring is empty
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import QueryDiagnosticSection from '../QueryDiagnosticSection';


const baseStatus = {
  enabled: true,
  interval_hours: 24,
  lookback_hours: 168,
  top_n: 20,
  max_files_per_target: 2000,
  daily_budget_bytes: 0,
  dry_run: false,
  next_run_at: '2026-06-10T00:00:00Z',
  job_registered: true,
  recent_ticks: [],
};

const emptyRecent = { queries: [] };
const baseSysRes = {
  ram_mb_total: 16000, ram_mb_available: 8000, ram_mb_used: 8000,
  cpu_count: 8, cpu_load_pct: 30, source: 'psutil',
};


describe('QueryDiagnosticSection — 149.9 prefetch daemon panel', () => {
  beforeEach(() => {
    server.use(
      http.get('/api/admin/queries/diagnose/recent', () =>
        HttpResponse.json(emptyRecent)),
      http.get('/api/admin/system-resources', () =>
        HttpResponse.json(baseSysRes)),
    );
  });

  it('renders the prefetch daemon Accordion with config chips', async () => {
    server.use(
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json(baseStatus)),
    );
    render(<QueryDiagnosticSection />);
    await waitFor(() => {
      expect(screen.getByText(/Adaptive Prefetch Daemon/i)).toBeInTheDocument();
    });
    // Status chips: enabled + every 24h (interval label)
    expect(screen.getByText(/enabled/i)).toBeInTheDocument();
    // "every 24h" may match multiple labels in the Accordion summary —
    // use getAllByText to confirm at least one match.
    expect(screen.getAllByText(/every 24h/i).length).toBeGreaterThan(0);
  });

  it('shows "No ticks recorded yet" Alert when ring is empty', async () => {
    server.use(
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json(baseStatus)),
    );
    render(<QueryDiagnosticSection />);
    // Expand the Accordion so its body renders
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    await waitFor(() => {
      expect(screen.getByText(/No ticks recorded yet/i)).toBeInTheDocument();
    });
  });

  it('renders the recent ticks table when ring has entries', async () => {
    server.use(
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json({
          ...baseStatus,
          recent_ticks: [
            {
              started_at: '2026-06-09T12:00:00Z',
              elapsed_s: 42.3,
              targets_total: 5,
              enqueued: 3,
              supplement_jobs: 2,
              bloom_jobs: 1,
              skipped_budget: 1,
              skipped_dry_run: 0,
              errors: [],
              targets_preview: [
                {
                  bucket: 'finance-prod',
                  table_prefix: 'iceberg/fact_balance',
                  column: 'system_id',
                  occurrence_count: 50,
                  needs_supplement: true,
                  needs_bloom: true,
                  reason: 'supplement gap, bloom gap',
                },
              ],
            },
          ],
        })),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    await waitFor(() => {
      expect(screen.getByText(/Recent ticks/i)).toBeInTheDocument();
    });
    // Elapsed time renders
    expect(screen.getByText(/42\.3s/)).toBeInTheDocument();
    // Targets preview renders the column
    expect(screen.getByText(/system_id/)).toBeInTheDocument();
    // Reason chip
    expect(screen.getByText(/supplement gap, bloom gap/)).toBeInTheDocument();
  });

  it('"Run tick now" POSTs to /tick endpoint', async () => {
    let tickCalled = false;
    server.use(
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json(baseStatus)),
      http.post('/api/admin/iceberg/prefetch/tick', () => {
        tickCalled = true;
        return HttpResponse.json({ plan: { targets: [] }, summary: { enqueued: 0 } });
      }),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    const tickBtn = await screen.findByRole('button', { name: /Run tick now/i });
    await userEvent.click(tickBtn);
    await waitFor(() => {
      expect(tickCalled).toBe(true);
    });
  });

  it('flags job-not-registered when scheduler init failed', async () => {
    server.use(
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json({
          ...baseStatus,
          job_registered: false,
          next_run_at: null,
        })),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    await waitFor(() => {
      expect(
        screen.getByText(/job NOT registered/i),
      ).toBeInTheDocument();
    });
  });
});
