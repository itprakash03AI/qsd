/**
 * BF-312 — CustomJobsSection render + interaction tests.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import CustomJobsSection from '../CustomJobsSection';

const mockJobs = [
  {
    id: 1,
    name: 'daily-iceberg-sync',
    description: 'Force-sync fact_tetb every morning',
    job_type: 'iceberg_sync' as const,
    parameters: {
      connection_id: 7,
      bucket: 'claude-eu-west-1',
      table_prefix: 'claudestore/fins/fact_tetb/',
    },
    cron_expression: '0 6 * * *',
    enabled: true,
    last_run_at: '2026-05-06T06:00:00Z',
    last_status: 'ok' as const,
    last_error: null,
    last_duration_seconds: 12.3,
    last_output: '{"snapshot_id": "2788...", "files_count": 14023}',
    next_run_at: '2026-05-07T06:00:00Z',
    run_count: 30,
    error_count: 0,
    created_by: 'admin',
    created_at: '2026-04-06T00:00:00Z',
  },
  {
    id: 2,
    name: 'webhook-status-ping',
    description: null,
    job_type: 'webhook' as const,
    parameters: { url: 'https://example.com/hook', method: 'POST' },
    cron_expression: '*/15 * * * *',
    enabled: false,
    last_run_at: '2026-05-06T09:45:00Z',
    last_status: 'error' as const,
    last_error: 'ConnectionError: timeout',
    last_duration_seconds: 30.0,
    last_output: null,
    next_run_at: null,
    run_count: 5,
    error_count: 5,
    created_by: 'admin',
    created_at: '2026-05-06T09:00:00Z',
  },
];

beforeEach(() => {
  server.use(
    http.get('*/api/admin/custom-jobs', () => HttpResponse.json({ jobs: mockJobs })),
    http.post('*/api/admin/custom-jobs/preview-cron', () =>
      HttpResponse.json({
        valid: true,
        cron: '*/5 * * * *',
        next_runs: [
          '2026-05-06T10:05:00Z',
          '2026-05-06T10:10:00Z',
          '2026-05-06T10:15:00Z',
        ],
      }),
    ),
  );
});

describe('CustomJobsSection', () => {
  it('renders header + cronmaker.com link', async () => {
    render(<CustomJobsSection />);
    expect(await screen.findByText(/Custom Jobs/i)).toBeInTheDocument();
    const cronLink = screen.getByRole('link', { name: /cronmaker\.com/i });
    expect(cronLink).toHaveAttribute('href', 'https://cronmaker.com/');
  });

  it('lists every custom job', async () => {
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('daily-iceberg-sync')).toBeInTheDocument();
      expect(screen.getByText('webhook-status-ping')).toBeInTheDocument();
    });
  });

  it('shows ok status chip for healthy jobs', async () => {
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('ok')).toBeInTheDocument();
    });
  });

  it('shows error chip + truncated error for failing jobs', async () => {
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('error')).toBeInTheDocument();
      expect(screen.getByText(/ConnectionError: timeout/)).toBeInTheDocument();
    });
  });

  it('shows cron expression in monospace', async () => {
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('0 6 * * *')).toBeInTheDocument();
      expect(screen.getByText('*/15 * * * *')).toBeInTheDocument();
    });
  });

  it('shows run/error count summary', async () => {
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText(/30 runs · 0 err/)).toBeInTheDocument();
      expect(screen.getByText(/5 runs · 5 err/)).toBeInTheDocument();
    });
  });

  it('opens the create-job dialog when "New Job" is clicked', async () => {
    const user = userEvent.setup();
    render(<CustomJobsSection />);
    await waitFor(() => screen.getByText('daily-iceberg-sync'));
    await user.click(screen.getByRole('button', { name: /New Job/i }));
    await waitFor(() => {
      expect(screen.getByText('New custom job')).toBeInTheDocument();
    });
  });

  it('shows empty-state when no jobs', async () => {
    server.use(
      http.get('*/api/admin/custom-jobs', () => HttpResponse.json({ jobs: [] })),
    );
    render(<CustomJobsSection />);
    await waitFor(() => {
      expect(screen.getByText(/No custom jobs yet/i)).toBeInTheDocument();
    });
  });
});
