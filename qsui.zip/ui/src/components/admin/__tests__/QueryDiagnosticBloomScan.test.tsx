/**
 * Phase 149.8 — Bloom Scan inline action in Query Diagnose panel.
 *
 * Tests:
 *  - "Scan bloom" button appears only when the table has eq/in filters
 *  - Button extracts columns from filters_received and POSTs to the
 *    /api/admin/iceberg/bloom/scan endpoint with the right body
 *  - Success state renders the inline result Alert
 *  - bloom_sidecar stage_drops chip renders alongside the legacy bloom chip
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import QueryDiagnosticSection from '../QueryDiagnosticSection';


/** One diagnose entry with a scan plan containing a table with eq + in
 *  filters — the exact shape the user described
 *  (Business_close_date='2025-09-30' AND system_id IN ('ABC', 'XYZ'))
 *  so the test exercises the home-run case end-to-end. */
const baseEntry = {
  execution_id: 'exec-bloom-test-001',
  fetched_at: Date.now(),
  engine_router: {
    decisions: [], total_decisions: 0,
    final_engine: 'multi_worker', skip_reasons: [],
  },
  multi_worker: {
    dispatches: [], active_workers: [],
    is_running: false, n_dispatches: 0,
  },
  config: { multi_worker: {}, query_engine: {}, scan_strategy: {}, iceberg: {} },
  worker_progress: [],
  bottleneck_hints: [],
};

const mockDiagnoseRecent = {
  queries: [
    {
      ...baseEntry,
      pruning: {
        available: true,
        summary: {
          files_before_prune: 5000,
          files_after_prune:  5000,
          stage_drops: {
            partition:     0,
            column_stats:  0,
            supplement:    0,
            bloom_sidecar: 0,   // not yet populated
            bloom:         0,
          },
          filter_breakdown: [],
        },
        blockers: [],
      },
      scan_plan: {
        execution_id: 'exec-bloom-test-001',
        total_files_before: 5000,
        total_files_after:  5000,
        created_at: '2026-06-09T10:00:00Z',
        tables: [
          {
            table_name: 'fact_balance',
            connection_id: 42,
            bucket: 'finance-prod',
            table_prefix: 'iceberg/fact_balance',
            snapshot_id: '1234567890',
            partition_columns: ['business_close_date'],
            files_before: 5000,
            files_final:  5000,
            decisions: [],
            pruning_source: 'l3_manifest',
            needs_self_heal: [],
            filters_received: [
              { col: 'business_close_date', op: '=',  val: '2025-09-30' },
              { col: 'system_id',           op: 'IN', val: ['ABC', 'XYZ'] },
            ],
          },
        ],
        joins: [],
      },
    },
  ],
};


const mockSystemResources = {
  ram_mb_total: 16000, ram_mb_available: 8000, ram_mb_used: 8000,
  cpu_count: 8, cpu_load_pct: 30, source: 'psutil',
};


describe('QueryDiagnosticSection — 149.8 bloom scan inline action', () => {
  beforeEach(() => {
    server.use(
      http.get('/api/admin/queries/diagnose/recent', () =>
        HttpResponse.json(mockDiagnoseRecent),
      ),
      http.get('/api/admin/system-resources', () =>
        HttpResponse.json(mockSystemResources),
      ),
    );
  });

  it('renders the Scan bloom button when table has eq/in filters', async () => {
    render(<QueryDiagnosticSection />);
    // The Brain Scan Plan section is inside the first entry's Accordion
    // which is defaultExpanded.  Wait for the recent-list fetch + render.
    // findByText auto-retries up to 5s.
    await screen.findByText(/Brain Scan Plan/i, {}, { timeout: 5000 });
    // 'fact_balance' shows in multiple places (Brain Scan Plan header + scan
    // table body + filters_received chip refs) — use getAllByText.
    expect(screen.getAllByText(/fact_balance/i).length).toBeGreaterThan(0);
    // The button label includes the count of eq/in cols extracted.
    // business_close_date '=' counts → 1; system_id 'IN' → 1.  Total: 2.
    expect(
      screen.getByRole('button', { name: /Scan bloom for 2 col\(s\)/i })
    ).toBeInTheDocument();
  });

  it('clicking the button POSTs the right body to /api/admin/iceberg/bloom/scan', async () => {
    let receivedBody: any = null;
    server.use(
      http.post('/api/admin/iceberg/bloom/scan', async ({ request }) => {
        receivedBody = await request.json();
        return HttpResponse.json({
          job_id: 'bloom-42-fact_balance-abc12345',
          scanned: 4900,
          skipped: 100,
          failed:  0,
          rows_inserted: 9800,
          elapsed_seconds: 30.5,
          files_total: 5000,
          snapshot_id: '1234567890',
        });
      }),
    );
    render(<QueryDiagnosticSection />);
    const btn = await screen.findByRole(
      'button', { name: /Scan bloom for 2 col\(s\)/i }, { timeout: 5000 },
    );
    await userEvent.click(btn);

    await waitFor(() => {
      expect(receivedBody).not.toBeNull();
    });
    expect(receivedBody.connection_id).toBe(42);
    expect(receivedBody.table_name).toBe('fact_balance');
    // Columns extracted from the WHERE: business_close_date + system_id
    expect(new Set(receivedBody.columns)).toEqual(
      new Set(['business_close_date', 'system_id']),
    );
    expect(receivedBody.force).toBe(false);

    // Success alert should render
    await waitFor(() => {
      expect(screen.getByText(/Scan complete/i)).toBeInTheDocument();
    });
    expect(screen.getByText(/4900 files scanned/)).toBeInTheDocument();
  });

  it('does NOT render the Scan bloom button when no eq/in filters', async () => {
    server.use(
      http.get('/api/admin/queries/diagnose/recent', () =>
        HttpResponse.json({
          queries: [
            {
              ...baseEntry,
              pruning: mockDiagnoseRecent.queries[0].pruning,
              scan_plan: {
                ...mockDiagnoseRecent.queries[0].scan_plan,
                tables: [{
                  ...mockDiagnoseRecent.queries[0].scan_plan.tables[0],
                  // Only a range filter → bloom can't help
                  filters_received: [
                    { col: 'amount', op: '>', val: 1000 },
                    { col: 'description', op: 'LIKE', val: '%foo%' },
                  ],
                }],
              },
            },
          ],
        }),
      ),
    );
    render(<QueryDiagnosticSection />);
    // Wait for the per-table Filters Received row to render — proves the
    // scan-plan section finished rendering before we assert button-absent.
    await screen.findByText(/Filters received:/i, {}, { timeout: 5000 });
    // Should NOT find a Scan bloom button — bloom can't help range/LIKE filters
    expect(
      screen.queryByRole('button', { name: /Scan bloom for/i })
    ).not.toBeInTheDocument();
  });

  it('renders bloom_sidecar in stage_drops chip row when count > 0', async () => {
    server.use(
      http.get('/api/admin/queries/diagnose/recent', () =>
        HttpResponse.json({
          queries: [
            {
              ...baseEntry,
              scan_plan: mockDiagnoseRecent.queries[0].scan_plan,
              pruning: {
                ...mockDiagnoseRecent.queries[0].pruning,
                summary: {
                  files_before_prune: 5000,
                  files_after_prune:  200,
                  stage_drops: {
                    partition:     0,
                    column_stats:  0,
                    supplement:    0,
                    bloom_sidecar: 4800,   // 149.4 win — surfaces in UI
                    bloom:         0,
                  },
                  filter_breakdown: [],
                },
                blockers: [],
              },
            },
          ],
        }),
      ),
    );
    render(<QueryDiagnosticSection />);
    await waitFor(() => {
      expect(screen.getByText(/bloom_sidecar: −4,800/i)).toBeInTheDocument();
    });
  });
});
