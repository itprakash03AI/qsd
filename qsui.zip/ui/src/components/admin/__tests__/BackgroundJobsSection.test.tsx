/**
 * BF-308 — BackgroundJobsSection render + interaction tests.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import BackgroundJobsSection from '../BackgroundJobsSection';

const mockJobs = [
  {
    name: 'iceberg_metadata_sync',
    description: 'BF-299 — periodically reconciles iceberg metadata.',
    autostart: true,
    controllable: true,
    running: true,
    paused: false,
    status: 'running' as const,
    started_at: '2026-05-06T10:00:00Z',
    stopped_at: null,
    paused_at: null,
    last_error: null,
  },
  {
    name: 'custom_jobs_scheduler',
    description: 'BF-312 — runs admin-defined custom jobs.',
    autostart: true,
    controllable: true,
    running: false,
    paused: true,
    status: 'paused' as const,
    started_at: '2026-05-06T09:00:00Z',
    stopped_at: null,
    paused_at: '2026-05-06T10:30:00Z',
    last_error: null,
  },
  {
    name: 'ws_heartbeat',
    description: 'WebSocket heartbeat — non-controllable.',
    autostart: true,
    controllable: false,
    running: true,
    paused: false,
    status: 'running' as const,
    started_at: '2026-05-06T08:00:00Z',
    stopped_at: null,
    paused_at: null,
    last_error: null,
  },
];

beforeEach(() => {
  server.use(
    http.get('*/api/admin/background-jobs', () =>
      HttpResponse.json({ jobs: mockJobs }),
    ),
  );
});

afterEach(() => {
  vi.useRealTimers();
});

describe('BackgroundJobsSection', () => {
  it('renders the header + section description', async () => {
    render(<BackgroundJobsSection />);
    expect(await screen.findByText('Background Jobs')).toBeInTheDocument();
    expect(screen.getByText(/start \/ stop each individually/i)).toBeInTheDocument();
  });

  it('lists every registered job', async () => {
    render(<BackgroundJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('iceberg_metadata_sync')).toBeInTheDocument();
      expect(screen.getByText('custom_jobs_scheduler')).toBeInTheDocument();
      expect(screen.getByText('ws_heartbeat')).toBeInTheDocument();
    });
  });

  it('shows the status chip with the right colour for each state', async () => {
    render(<BackgroundJobsSection />);
    await waitFor(() => {
      expect(screen.getAllByText('running')).toHaveLength(2);   // 2 running
      expect(screen.getByText('paused')).toBeInTheDocument();
    });
  });

  it('marks non-controllable jobs with a "locked" chip', async () => {
    render(<BackgroundJobsSection />);
    await waitFor(() => {
      expect(screen.getByText('locked')).toBeInTheDocument();
    });
  });

  it('calls pause endpoint when pause button is clicked', async () => {
    const onPause = vi.fn();
    server.use(
      http.post('*/api/admin/background-jobs/iceberg_metadata_sync/pause', () => {
        onPause();
        return HttpResponse.json({ status: 'paused' });
      }),
    );
    const user = userEvent.setup();
    const { container } = render(<BackgroundJobsSection />);
    await waitFor(() => screen.getByText('iceberg_metadata_sync'));

    // Click the first Pause icon button (TooltipTitle="Pause — keep status as paused")
    const pauseButtons = container.querySelectorAll('[data-testid="PauseIcon"]');
    if (pauseButtons.length > 0) {
      await user.click(pauseButtons[0].closest('button')!);
      await waitFor(() => expect(onPause).toHaveBeenCalled());
    }
  });

  it('shows last_error when a job is errored', async () => {
    server.use(
      http.get('*/api/admin/background-jobs', () =>
        HttpResponse.json({
          jobs: [{
            ...mockJobs[0],
            running: false,
            status: 'errored' as const,
            last_error: 'RuntimeError: connection refused on initial sync',
          }],
        }),
      ),
    );
    render(<BackgroundJobsSection />);
    await waitFor(() => {
      expect(screen.getByText(/connection refused/)).toBeInTheDocument();
    });
  });

  it('shows the "no jobs" alert when registry is empty', async () => {
    server.use(
      http.get('*/api/admin/background-jobs', () => HttpResponse.json({ jobs: [] })),
    );
    render(<BackgroundJobsSection />);
    await waitFor(() => {
      expect(screen.getByText(/No background jobs registered/i)).toBeInTheDocument();
    });
  });
});
