/**
 * BF-296/298/299/300/318 — IcebergMetadataSyncSection render + interaction tests.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import IcebergMetadataSyncSection from '../IcebergMetadataSyncSection';

const mockTables = [
  {
    id: 1,
    connection_id: 7,
    bucket: 'claude-eu-west-1',
    table_prefix: 'claudestore/fins/fact_tetb/',
    last_snapshot_id: '2788254716930226868',
    last_synced_at: '2026-05-06T10:00:00Z',
    last_sync_status: 'ok',
    last_sync_error: null,
    last_sync_seconds: 1.5,
    last_files_count: 14023,
    pinned: true,
    enabled: true,
    predownload_rule: null,
    created_at: '2026-05-06T08:00:00Z',
    last_queried_at: '2026-05-06T10:30:00Z',
  },
  {
    id: 2,
    connection_id: 7,
    bucket: 'claude-eu-west-1',
    table_prefix: 'claudestore/fins/dim_customer/',
    last_snapshot_id: '1234567890',
    last_synced_at: '2026-05-06T10:00:00Z',
    last_sync_status: 'ok',
    last_sync_error: null,
    last_sync_seconds: 0.3,
    last_files_count: 50,
    pinned: false,
    enabled: true,
    predownload_rule: { strategy: 'recent_dates', partition_column: 'd', lookback_days: 30 },
    created_at: '2026-05-06T08:00:00Z',
    last_queried_at: '2026-05-06T10:00:00Z',
  },
];

const mockStatus = {
  summary: {
    reconciled: 2,
    ok: 2,
    errors: 0,
    ran_at: '2026-05-06T10:00:00Z',
    interval_seconds: 300,
  },
  tables: mockTables,
};

const mockStats = {
  enabled: true,
  pointer_hits: 142,
  pointer_misses: 8,
  contents_l1_hits: 89,
  contents_l2_hits: 53,
  contents_misses: 1,
  manifest_l1_hits: 412,
  manifest_l2_hits: 211,
  manifest_misses: 4,
  manifest_stores: 215,
  pointer_count: 7,
  contents_l1_count: 12,
  l2_row_count: 31,
};

beforeEach(() => {
  server.use(
    http.get('*/api/admin/iceberg-sync/status', () => HttpResponse.json(mockStatus)),
    http.get('*/api/admin/iceberg-snapshot-cache/stats', () => HttpResponse.json(mockStats)),
  );
});

describe('IcebergMetadataSyncSection', () => {
  it('renders the section title + warning callout', async () => {
    render(<IcebergMetadataSyncSection />);
    expect(await screen.findByText('Iceberg Metadata Sync')).toBeInTheDocument();
    // Note callout has formatted text spans — check via a tag we know
    expect(screen.getByText('Note on naming')).toBeInTheDocument();
  });

  it('lists every watched table', async () => {
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText('claudestore/fins/fact_tetb/')).toBeInTheDocument();
      expect(screen.getByText('claudestore/fins/dim_customer/')).toBeInTheDocument();
    });
  });

  it('shows pinned chip on pinned tables', async () => {
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText('pinned')).toBeInTheDocument();
    });
  });

  it('renders the cache stats panel with hit/miss breakdown', async () => {
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText('Snapshot pointer (L1)')).toBeInTheDocument();
      expect(screen.getByText(/142 hits/)).toBeInTheDocument();
      expect(screen.getByText('Per-manifest (BF-298)')).toBeInTheDocument();
      expect(screen.getByText(/412 L1/)).toBeInTheDocument();
    });
  });

  it('renders sync summary alert when ran_at is present', async () => {
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText(/Last run at/)).toBeInTheDocument();
      expect(screen.getByText(/2 reconciled/)).toBeInTheDocument();
    });
  });

  it('shows file count + duration per table', async () => {
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText('14023')).toBeInTheDocument();
      expect(screen.getByText(/1\.5s/)).toBeInTheDocument();
    });
  });

  it('shows empty-state when no tables are watched', async () => {
    server.use(
      http.get('*/api/admin/iceberg-sync/status', () =>
        HttpResponse.json({ summary: {}, tables: [] }),
      ),
    );
    render(<IcebergMetadataSyncSection />);
    await waitFor(() => {
      expect(screen.getByText(/No tables watched yet/i)).toBeInTheDocument();
    });
  });
});
