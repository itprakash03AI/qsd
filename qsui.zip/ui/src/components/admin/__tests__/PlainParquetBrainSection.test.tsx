/**
 * Phase 151 — Plain Parquet Brain admin section render test.
 *
 * Closes the "render test for plain_parquet panel" caveat — verifies the
 * full UI surface boots without exploding given the canonical /api/admin/
 * parquet/* shapes, the sort_by autocomplete kicks off the
 * sort-analysis chip, and Build Mirror is gated on mirror.build_enabled.
 *
 * MSW intercepts all 5 mount-time GETs + the sort-analysis GET.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import PlainParquetBrainSection from '../PlainParquetBrainSection';


const tablesPayload = {
  tables: [
    {
      connection_id:   1,
      connection_name: 'finance-prod',
      bucket:          'finance-bucket',
      table_prefix:    'parquet/fact_balance',
      table_name:      'fact_balance',
    },
  ],
};

const catalogPayload = {
  cache_ttl_seconds:   300,
  max_files_per_table: 5000,
  total_cached_tables: 1,
  tables: [{
    bucket:          'finance-bucket',
    prefix:          'parquet/fact_balance',
    file_count:      42,
    snapshot_token:  'tok-1',
    enumerated_at:   1717000000,
    elapsed_seconds: 0.3,
    truncated:       false,
  }],
};

const mirrorStatePayloadDisabled = {
  build_enabled:    false,
  routing_enabled:  false,
  cron_enabled:     false,
  min_source_files: 16,
  by_status:        {},
  total:            0,
  routing_on:       0,
};

const mirrorStatePayloadEnabled = {
  ...mirrorStatePayloadDisabled,
  build_enabled:   true,
  routing_enabled: true,
};


describe('PlainParquetBrainSection — Phase 151 render', () => {

  beforeEach(() => {
    server.use(
      http.get('/api/admin/parquet/discoverable-tables', () =>
        HttpResponse.json(tablesPayload)),
      http.get('/api/admin/parquet/catalog/state', () =>
        HttpResponse.json(catalogPayload)),
      http.get('/api/admin/parquet/sync/recent-ticks', () =>
        HttpResponse.json({ ticks: [] })),
      http.get('/api/admin/parquet/mirror/state', () =>
        HttpResponse.json(mirrorStatePayloadDisabled)),
      http.get('/api/admin/parquet/mirror/list', () =>
        HttpResponse.json({ mirrors: [] })),
    );
  });

  it('renders the Phase-151 header + posture chips', async () => {
    render(<PlainParquetBrainSection />);
    expect(await screen.findByText('Plain Parquet Brain')).toBeInTheDocument();
    expect(screen.getByText('Phase 151')).toBeInTheDocument();
    // Discoverable-tables chip with the right count
    await waitFor(() => {
      expect(
        screen.getByText(/Discoverable tables: 1/),
      ).toBeInTheDocument();
    });
    // Catalog cached chip
    expect(screen.getByText(/Catalog cached: 1/)).toBeInTheDocument();
  });

  it('disables Build Mirror when mirror.build_enabled is false', async () => {
    render(<PlainParquetBrainSection />);
    const buildBtn = await screen.findByRole('button', { name: /Build Mirror/i });
    expect(buildBtn).toBeDisabled();
    // Warning chip surfaced explaining why
    expect(screen.getByText(/Mirror build disabled/i)).toBeInTheDocument();
  });

  it('enables Build Mirror when build_enabled flips true', async () => {
    server.use(
      http.get('/api/admin/parquet/mirror/state', () =>
        HttpResponse.json(mirrorStatePayloadEnabled)),
    );
    render(<PlainParquetBrainSection />);
    // Wait for state to load — the disabled-chip should NOT render
    await waitFor(() => {
      expect(
        screen.queryByText(/Mirror build disabled/i),
      ).not.toBeInTheDocument();
    });
    // Build button enabled only after a table is selected, but the
    // build_enabled gate is what we're testing — verify the warning
    // chip is gone is sufficient here.
  });

  it('selecting a sort_by column triggers sort-analysis chip', async () => {
    let analysisCalled = false;
    server.use(
      http.get('/api/admin/parquet/mirror/state', () =>
        HttpResponse.json(mirrorStatePayloadEnabled)),
      http.get('/api/admin/mirror/sort-analysis', () => {
        analysisCalled = true;
        return HttpResponse.json({
          verdict:        'unsorted',
          monotonic_pct:  0.0,
          recommendation: 'Mirror sort_by would unlock row-group skipping.',
        });
      }),
    );
    render(<PlainParquetBrainSection />);
    // Pick the registered table first
    const tableInput = await screen.findByLabelText(/Registered parquet table/i);
    await userEvent.click(tableInput);
    await userEvent.type(tableInput, 'fact_balance');
    const opt = await screen.findByText(/fact_balance/);
    await userEvent.click(opt);
    // Find the sort_by autocomplete + type a column name
    const sortByInput = screen.getByLabelText(/Mirror sort_by/i);
    await userEvent.type(sortByInput, 'system_id');
    await userEvent.keyboard('{Enter}');
    await waitFor(() => {
      expect(analysisCalled).toBe(true);
    });
    // Verdict chip rendered
    await waitFor(() => {
      expect(
        screen.getByText(/UNSORTED \(0%\)/i),
      ).toBeInTheDocument();
    });
  });

  it('renders error alert when discoverable-tables fails', async () => {
    server.use(
      http.get('/api/admin/parquet/discoverable-tables', () =>
        new HttpResponse(null, { status: 500, statusText: 'boom' })),
    );
    render(<PlainParquetBrainSection />);
    // safeFetch surfaces an error message into the Alert
    await waitFor(() => {
      const alerts = screen.queryAllByRole('alert');
      expect(alerts.length).toBeGreaterThan(0);
    });
  });
});
