/**
 * Phase 116 — Component tests for extracted Admin sections and hooks.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderWithProviders, screen, waitFor } from '../../../test/utils';
import StatCard from '../StatCard';
import StatusChip from '../StatusChip';

// ── StatCard ────────────────────────────────────────────────────────────────
describe('StatCard', () => {
  it('renders label and value', () => {
    renderWithProviders(<StatCard label="Active" value={42} />);
    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(screen.getByText('42')).toBeInTheDocument();
  });

  it('renders sub text when provided', () => {
    renderWithProviders(<StatCard label="Disk" value="10 GB" sub="50% used" />);
    expect(screen.getByText('50% used')).toBeInTheDocument();
  });

  it('applies warning color when warn=true', () => {
    renderWithProviders(<StatCard label="Errors" value={5} warn />);
    const value = screen.getByText('5');
    // MUI error.main color is applied
    expect(value).toBeInTheDocument();
  });
});

// ── StatusChip ──────────────────────────────────────────────────────────────
describe('StatusChip', () => {
  it('renders OK when ok=true', () => {
    renderWithProviders(<StatusChip ok={true} />);
    expect(screen.getByText('OK')).toBeInTheDocument();
  });

  it('renders Error when ok=false', () => {
    renderWithProviders(<StatusChip ok={false} />);
    expect(screen.getByText('Error')).toBeInTheDocument();
  });

  it('renders custom label', () => {
    renderWithProviders(<StatusChip ok={true} label="HEALTHY" />);
    expect(screen.getByText('HEALTHY')).toBeInTheDocument();
  });
});
