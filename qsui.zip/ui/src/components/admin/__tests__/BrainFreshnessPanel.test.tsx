/**
 * Phase 149.10 — Brain Freshness panel within the Adaptive Prefetch
 * Accordion of Query Diagnose.
 *
 * Tests:
 *  - GET /api/admin/iceberg/freshness fetched on mount; ledger rendered
 *  - In-sync vs stale vs never-scanned chips render correctly
 *  - Refresh button POSTs to /api/admin/iceberg/freshness/refresh with the
 *    right (bucket, table_prefix) body
 *  - "No tables tracked yet" Alert renders when ledger empty
 *  - Recent events log renders when present
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import QueryDiagnosticSection from '../QueryDiagnosticSection';


const baseStatus = {
  enabled: true,
  interval_hours: 1,
  lookback_hours: 168,
  top_n: 20,
  max_files_per_target: 2000,
  daily_budget_bytes: 0,
  dry_run: false,
  next_run_at: '2026-06-10T00:00:00Z',
  job_registered: true,
  recent_ticks: [],
};

const baseSysRes = {
  ram_mb_total: 16000, ram_mb_available: 8000, ram_mb_used: 8000,
  cpu_count: 8, cpu_load_pct: 30, source: 'psutil',
};


describe('QueryDiagnosticSection — 149.10 Brain Freshness panel', () => {
  beforeEach(() => {
    server.use(
      http.get('/api/admin/queries/diagnose/recent', () =>
        HttpResponse.json({ queries: [] })),
      http.get('/api/admin/system-resources', () =>
        HttpResponse.json(baseSysRes)),
      http.get('/api/admin/iceberg/prefetch/status', () =>
        HttpResponse.json(baseStatus)),
    );
  });

  it('renders ledger rows with in-sync/stale chips', async () => {
    server.use(
      http.get('/api/admin/iceberg/freshness', () =>
        HttpResponse.json({
          ledger: [
            {
              bucket: 'finance-prod',
              table_prefix: 'iceberg/fact_balance',
              current_snapshot: 'snap-200',
              last_scanned_snapshot: 'snap-200',
              snapshot_in_sync: true,
              cols_covered: ['sup:system_id', 'bloom:system_id'],
              last_check_at: '2026-06-09T15:00:00Z',
              last_check_source: 'cron',
              last_action: 'noop',
            },
            {
              bucket: 'finance-prod',
              table_prefix: 'iceberg/fact_journal',
              current_snapshot: 'snap-201',
              last_scanned_snapshot: 'snap-198',
              snapshot_in_sync: false,
              cols_covered: ['bloom:account_id'],
              last_check_at: '2026-06-09T14:30:00Z',
              last_check_source: 'watcher',
              last_action: 'dispatched',
            },
            {
              bucket: 'finance-prod',
              table_prefix: 'iceberg/new_table',
              current_snapshot: 'snap-1',
              last_scanned_snapshot: null,
              snapshot_in_sync: false,
              cols_covered: [],
              last_check_at: '2026-06-09T14:00:00Z',
              last_check_source: 'cron',
              last_action: 'noop',
            },
          ],
          recent_events: [],
        })),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    // Each chip variant renders
    await waitFor(() => {
      expect(screen.getByText('in sync')).toBeInTheDocument();
    });
    expect(screen.getByText('stale')).toBeInTheDocument();
    expect(screen.getByText('never scanned')).toBeInTheDocument();
  });

  it('Refresh button POSTs the right body', async () => {
    let receivedBody: any = null;
    server.use(
      http.get('/api/admin/iceberg/freshness', () =>
        HttpResponse.json({
          ledger: [{
            bucket: 'finance-prod',
            table_prefix: 'iceberg/fact_balance',
            current_snapshot: 'snap-200',
            last_scanned_snapshot: 'snap-198',
            snapshot_in_sync: false,
            cols_covered: ['bloom:system_id'],
            last_check_at: '2026-06-09T15:00:00Z',
            last_check_source: 'cron',
            last_action: 'dispatched',
          }],
          recent_events: [],
        })),
      http.post('/api/admin/iceberg/freshness/refresh', async ({ request }) => {
        receivedBody = await request.json();
        return HttpResponse.json({
          action: 'dispatched',
          current_snapshot: 'snap-200',
          last_scanned_snapshot: 'snap-198',
        });
      }),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    // Multiple "Refresh" buttons exist (daemon status, ledger reload,
    // per-row).  Pick the LAST one — the per-row text button.
    const refreshBtns = await screen.findAllByRole('button', { name: /^Refresh$/ });
    const perRow = refreshBtns[refreshBtns.length - 1];
    await userEvent.click(perRow);
    await waitFor(() => {
      expect(receivedBody).not.toBeNull();
    });
    expect(receivedBody.bucket).toBe('finance-prod');
    expect(receivedBody.table_prefix).toBe('iceberg/fact_balance');
    expect(receivedBody.blocking).toBe(false);
  });

  it('renders "No tables tracked yet" Alert when ledger is empty', async () => {
    server.use(
      http.get('/api/admin/iceberg/freshness', () =>
        HttpResponse.json({ ledger: [], recent_events: [] })),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    await waitFor(() => {
      expect(
        screen.getByText(/No tables tracked yet/i),
      ).toBeInTheDocument();
    });
  });

  it('renders the recent freshness events log', async () => {
    server.use(
      http.get('/api/admin/iceberg/freshness', () =>
        HttpResponse.json({
          ledger: [],
          recent_events: [
            {
              at: '2026-06-09T15:00:00Z',
              bucket: 'finance-prod',
              table_prefix: 'iceberg/fact_balance',
              source: 'watcher',
              action: 'dispatched',
              reason: 'snapshot drift snap-198→snap-200',
            },
            {
              at: '2026-06-09T15:01:00Z',
              bucket: 'finance-prod',
              table_prefix: 'iceberg/fact_balance',
              source: 'lazy',
              action: 'in_flight',
              reason: 'throttled by in-flight scan',
            },
          ],
        })),
    );
    render(<QueryDiagnosticSection />);
    const acc = await screen.findByRole(
      'button', { name: /Adaptive Prefetch Daemon/i },
    );
    await userEvent.click(acc);
    await waitFor(() => {
      expect(screen.getByText(/Recent freshness events/i)).toBeInTheDocument();
    });
    // Source chips
    expect(screen.getByText('watcher')).toBeInTheDocument();
    expect(screen.getByText('lazy')).toBeInTheDocument();
    // Action chips
    expect(screen.getByText('dispatched')).toBeInTheDocument();
    expect(screen.getByText('in_flight')).toBeInTheDocument();
  });
});
