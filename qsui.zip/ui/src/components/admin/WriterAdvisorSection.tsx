/**
 * Phase 149 (charter P2) — Writer Advisor admin UI.
 *
 * Surfaces actionable per-table recommendations that close the
 * pruning brain feedback loop.  The brain currently optimises READS;
 * Writer Advisor recommends WRITER-side spec changes (partition /
 * bucket / sort-order) so the source table starts pruning well
 * without QueryStudio having to layer mirrors / sidecars on top.
 *
 * Endpoints used:
 *   GET  /api/admin/brain/writer-advisor/recommendations
 *   POST /api/admin/brain/writer-advisor/decision
 *   GET  /api/admin/brain/writer-advisor/decisions
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Accordion,
  AccordionSummary, AccordionDetails, Divider,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  CheckCircle as AcceptIcon,
  Block as DismissIcon,
  ExpandMore as ExpandMoreIcon,
  Lightbulb as IdeaIcon,
  ContentCopy as CopyIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface Evidence {
  execution_id:        string;
  created_at:          string | null;
  files_before_prune:  number;
  files_after_prune:   number;
  prune_pct:           number;
}


interface Recommendation {
  bucket:                  string;
  table_prefix:            string;
  column:                  string;
  kind:                    string;
  proposed_transform:      string;
  reason:                  string;
  queries_observed:        number;
  avg_files_before:        number;
  avg_files_after:         number;
  current_avg_prune_pct:   number;
  est_files_after:         number;
  est_speedup_x:           number;
  est_leverage_pct:        number;
  evidence:                Evidence[];
  spark_ddl:               string;
  iceberg_ddl:             string;
  status:                  string;
  decision_at?:            string | null;
  decision_by?:            string | null;
  decision_reason?:        string | null;
  generated_at:            string;
  dedup_key:               [string, string, string, string];
}


interface RecommendationsResponse {
  recommendations: Recommendation[];
  total:           number;
  computed_at:     string;
}


interface Decision {
  bucket:       string;
  table_prefix: string;
  column:       string;
  kind:         string;
  status:       string;
  decided_at:   string;
  decided_by:   string | null;
  reason:       string | null;
}


const kindLabels: Record<string, string> = {
  add_partition:           'ADD PARTITION',
  add_bucket:              'ADD BUCKET',
  add_truncate:            'ADD TRUNCATE',
  change_partition_grain:  'CHANGE GRAIN',
  add_sort_order:          'ADD SORT ORDER',
};


const leverageColor = (pct: number): 'success' | 'warning' | 'error' => {
  if (pct >= 80) return 'success';
  if (pct >= 40) return 'warning';
  return 'error';
};


const WriterAdvisorSection: React.FC = () => {
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [computedAt, setComputedAt] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<Decision[]>([]);
  const [bucketFilter, setBucketFilter] = useState<string>('');
  const [working, setWorking] = useState<string | null>(null);
  const [decisionDialog, setDecisionDialog] = useState<{
    open: boolean; rec: Recommendation | null; mode: 'accepted' | 'dismissed' | null;
    reason: string;
  }>({ open: false, rec: null, mode: null, reason: '' });

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const url = '/api/admin/brain/writer-advisor/recommendations'
        + (bucketFilter.trim()
            ? `?bucket=${encodeURIComponent(bucketFilter.trim())}`
            : '');
      const r = await safeFetch(url, { timeoutMs: 60000 });
      setRecs(r?.recommendations || []);
      setComputedAt(r?.computed_at || '');
      const hist = await safeFetch(
        '/api/admin/brain/writer-advisor/decisions?limit=50',
        { timeoutMs: 15000 },
      ).catch(() => null);
      setHistory(hist?.decisions || []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [bucketFilter]);

  useEffect(() => { load(); }, [load]);

  const openDecision = useCallback(
    (rec: Recommendation, mode: 'accepted' | 'dismissed') => {
      setDecisionDialog({ open: true, rec, mode, reason: '' });
    },
    [],
  );

  const submitDecision = useCallback(async () => {
    if (!decisionDialog.rec || !decisionDialog.mode) return;
    const rec = decisionDialog.rec;
    setWorking(`${rec.dedup_key.join(':')}-${decisionDialog.mode}`);
    try {
      await safeFetch('/api/admin/brain/writer-advisor/decision', {
        method: 'POST',
        body: JSON.stringify({
          bucket:       rec.bucket,
          table_prefix: rec.table_prefix,
          column:       rec.column,
          kind:         rec.kind,
          status:       decisionDialog.mode,
          reason:       decisionDialog.reason || null,
        }),
      });
      setDecisionDialog({ open: false, rec: null, mode: null, reason: '' });
      await load();
    } catch (e: any) {
      alert(`Failed to record decision: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [decisionDialog, load]);

  const copyDdl = useCallback((ddl: string) => {
    try {
      navigator.clipboard.writeText(ddl);
    } catch {
      /* clipboard may be locked in some browsers — silent best-effort */
    }
  }, []);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <IdeaIcon fontSize="small" />
        <Typography variant="h6">Writer Advisor</Typography>
        <Box sx={{ flex: 1 }} />
        <TextField
          size="small" label="Bucket filter (optional)"
          value={bucketFilter}
          onChange={(e) => setBucketFilter(e.target.value)}
          sx={{ minWidth: 220 }}
        />
        <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                onClick={load} disabled={loading}>
          {loading ? <CircularProgress size={14} /> : 'Refresh'}
        </Button>
      </Stack>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          <b>What this is:</b> per-table recommendations for writer-side
          partition / bucket / sort-order changes, derived from{' '}
          <code>query_pruning_history</code>.  When the brain consistently
          sees the same column filtered with non-supported verdicts on a
          table whose queries scan many files, it proposes a transform the
          writer team can adopt so the SOURCE table starts pruning well.
          {' '}<b>This is the highest-leverage intervention</b> — a
          re-partition can take a 5000-file scan to 50 at source, with no
          mirror needed.  Recommendations are RANKED by estimated leverage
          (avg files after the proposed transform vs current).
        </Typography>
        {computedAt && (
          <Typography variant="caption" sx={{ display: 'block', mt: 1 }}>
            Computed at: {computedAt} · {recs.length} recommendation(s)
          </Typography>
        )}
      </Paper>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {!loading && !error && recs.length === 0 && (
        <Alert severity="info" sx={{ mb: 2 }}>
          No recommendations yet.  Either the lookback window
          ({' '}<code>writer_advisor.lookback_hours</code>{' '}default 168h)
          has no qualifying queries, or every signal-worthy
          (table, column) is already in the dismissal ledger.  Run a few
          large-scan queries and re-check.
        </Alert>
      )}

      {recs.map((r, i) => (
        <Paper key={r.dedup_key.join(':')} sx={{ p: 2, mb: 1.5 }}>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Chip size="small" color="primary" variant="outlined"
                  label={kindLabels[r.kind] || r.kind.toUpperCase()} />
            <Typography variant="subtitle1"
                        sx={{ fontFamily: 'monospace' }}>
              {r.bucket}/{r.table_prefix} · {r.column}
            </Typography>
            <Box sx={{ flex: 1 }} />
            <Chip size="small"
                  color={leverageColor(r.est_leverage_pct)}
                  label={`leverage ${r.est_leverage_pct.toFixed(0)}%`} />
            <Chip size="small" variant="outlined"
                  label={`speedup ${r.est_speedup_x.toFixed(1)}×`} />
            {r.status === 'accepted' && (
              <Chip size="small" color="success" label="accepted" />
            )}
            {r.status === 'dismissed' && (
              <Chip size="small" color="default" label="dismissed" />
            )}
          </Stack>

          <Typography variant="body2" sx={{ mb: 1 }}>
            <b>Proposed transform:</b>{' '}
            <code style={{ background: '#f3f4f6', padding: '2px 6px',
                            borderRadius: 3 }}>
              {r.proposed_transform}
            </code>
          </Typography>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            {r.reason}
          </Typography>

          <Stack direction="row" spacing={2} sx={{ mb: 1 }}>
            <Typography variant="caption" color="text.secondary">
              queries observed: <b>{r.queries_observed}</b>
            </Typography>
            <Typography variant="caption" color="text.secondary">
              current avg files: <b>{r.avg_files_after.toFixed(0)}</b>
            </Typography>
            <Typography variant="caption" color="text.secondary">
              predicted avg files: <b>{r.est_files_after.toFixed(0)}</b>
            </Typography>
            <Typography variant="caption" color="text.secondary">
              current prune %: <b>{r.current_avg_prune_pct.toFixed(1)}%</b>
            </Typography>
          </Stack>

          <Accordion sx={{ mb: 1 }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="caption">
                Worst-pruning evidence ({r.evidence.length})
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Execution</TableCell>
                    <TableCell>When</TableCell>
                    <TableCell align="right">Before</TableCell>
                    <TableCell align="right">After</TableCell>
                    <TableCell align="right">Prune %</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {r.evidence.map((e) => (
                    <TableRow key={e.execution_id} hover>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                        {e.execution_id}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>
                        {e.created_at?.slice(0, 19)}
                      </TableCell>
                      <TableCell align="right">
                        {e.files_before_prune.toLocaleString()}
                      </TableCell>
                      <TableCell align="right">
                        {e.files_after_prune.toLocaleString()}
                      </TableCell>
                      <TableCell align="right">
                        {e.prune_pct.toFixed(1)}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </AccordionDetails>
          </Accordion>

          <Accordion sx={{ mb: 1 }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="caption">DDL snippets</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Stack spacing={1}>
                <Box>
                  <Stack direction="row" alignItems="center" spacing={1}>
                    <Typography variant="caption" sx={{ fontWeight: 700 }}>
                      Spark / pyiceberg
                    </Typography>
                    <Tooltip title="Copy to clipboard">
                      <IconButton size="small"
                                  onClick={() => copyDdl(r.spark_ddl)}>
                        <CopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                  <pre style={{
                    background: '#0f172a', color: '#e2e8f0',
                    padding: 8, borderRadius: 4, fontSize: 12,
                    margin: 0, overflow: 'auto',
                  }}>{r.spark_ddl}</pre>
                </Box>
                <Box>
                  <Stack direction="row" alignItems="center" spacing={1}>
                    <Typography variant="caption" sx={{ fontWeight: 700 }}>
                      Iceberg SQL
                    </Typography>
                    <Tooltip title="Copy to clipboard">
                      <IconButton size="small"
                                  onClick={() => copyDdl(r.iceberg_ddl)}>
                        <CopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                  <pre style={{
                    background: '#0f172a', color: '#e2e8f0',
                    padding: 8, borderRadius: 4, fontSize: 12,
                    margin: 0, overflow: 'auto',
                  }}>{r.iceberg_ddl}</pre>
                </Box>
              </Stack>
            </AccordionDetails>
          </Accordion>

          <Stack direction="row" spacing={1}>
            <Button size="small" variant="outlined" color="success"
                    startIcon={<AcceptIcon />}
                    disabled={r.status === 'accepted' || !!working}
                    onClick={() => openDecision(r, 'accepted')}>
              {r.status === 'accepted' ? 'Already accepted' : 'Mark accepted'}
            </Button>
            <Button size="small" variant="outlined" color="warning"
                    startIcon={<DismissIcon />}
                    disabled={r.status === 'dismissed' || !!working}
                    onClick={() => openDecision(r, 'dismissed')}>
              {r.status === 'dismissed' ? 'Dismissed' : 'Dismiss'}
            </Button>
            {r.decision_by && (
              <Typography variant="caption" sx={{ alignSelf: 'center' }}>
                · {r.status} by {r.decision_by}
                {r.decision_at ? ` at ${r.decision_at.slice(0, 19)}` : ''}
              </Typography>
            )}
          </Stack>
        </Paper>
      ))}

      {history.length > 0 && (
        <Accordion sx={{ mt: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">
              Decision history ({history.length})
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Table</TableCell>
                  <TableCell>Column</TableCell>
                  <TableCell>Kind</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>By</TableCell>
                  <TableCell>Reason</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {history.map((d, i) => (
                  <TableRow key={i}>
                    <TableCell sx={{ fontSize: 12 }}>
                      {d.decided_at?.slice(0, 19)}
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {d.bucket}/{d.table_prefix}
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {d.column}
                    </TableCell>
                    <TableCell>{d.kind}</TableCell>
                    <TableCell>
                      <Chip size="small"
                            color={d.status === 'accepted' ? 'success' : 'default'}
                            label={d.status} />
                    </TableCell>
                    <TableCell>{d.decided_by}</TableCell>
                    <TableCell>{d.reason}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* Decision dialog */}
      <Dialog open={decisionDialog.open}
              onClose={() => setDecisionDialog({ open: false, rec: null, mode: null, reason: '' })}
              maxWidth="sm" fullWidth>
        <DialogTitle>
          {decisionDialog.mode === 'accepted'
            ? 'Mark recommendation accepted'
            : 'Dismiss recommendation'}
        </DialogTitle>
        <DialogContent>
          {decisionDialog.rec && (
            <>
              <Typography variant="body2" sx={{ mb: 1 }}>
                <b>Table:</b>{' '}
                <code>{decisionDialog.rec.bucket}/{decisionDialog.rec.table_prefix}</code>
              </Typography>
              <Typography variant="body2" sx={{ mb: 1 }}>
                <b>Transform:</b>{' '}
                <code>{decisionDialog.rec.proposed_transform}</code>
              </Typography>
              <Divider sx={{ my: 1 }} />
              <TextField
                size="small" fullWidth multiline minRows={2}
                label="Reason (optional)"
                value={decisionDialog.reason}
                onChange={(e) =>
                  setDecisionDialog((d) => ({ ...d, reason: e.target.value }))}
                helperText={
                  decisionDialog.mode === 'dismissed'
                    ? `Dismissals suppress the same recommendation for ${30} days (writer_advisor.dismissal_ttl_days).`
                    : 'Useful for downstream — what JIRA / RFC tracks the writer-side change?'
                }
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDecisionDialog({ open: false, rec: null, mode: null, reason: '' })}>
            Cancel
          </Button>
          <Button onClick={submitDecision} variant="contained"
                  color={decisionDialog.mode === 'accepted' ? 'success' : 'warning'}
                  disabled={!!working}>
            {decisionDialog.mode === 'accepted' ? 'Accept' : 'Dismiss'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};


export default WriterAdvisorSection;
