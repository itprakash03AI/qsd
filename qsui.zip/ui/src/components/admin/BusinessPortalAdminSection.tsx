import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, Button, CircularProgress, TextField } from '@mui/material';
import api from '../../services/api';

const BusinessPortalAdminSection: React.FC = () => {
  const [cfg, setCfg] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const data = await api.getBusinessPortalConfig();
        setCfg(data);
      } finally { setLoading(false); }
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = await api.setBusinessPortalConfig(cfg);
      setCfg(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally { setSaving(false); }
  };

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress /></Box>;

  const toggles = [
    { key: 'enabled', label: 'Portal Enabled' },
    { key: 'quick_actions_enabled', label: 'Quick Actions' },
    { key: 'kpi_cards_enabled', label: 'KPI Cards' },
  ];

  const numbers = [
    { key: 'recent_reports_limit', label: 'Recent Reports Limit' },
    { key: 'favorites_limit', label: 'Favorites Limit' },
    { key: 'certified_templates_limit', label: 'Certified Templates Limit' },
    { key: 'recent_activity_limit', label: 'Recent Activity Limit' },
  ];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>Business Portal Configuration</Typography>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {toggles.map(t => (
          <Paper key={t.key} variant="outlined" sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
            <input type="checkbox" checked={!!cfg[t.key]}
              onChange={e => setCfg((prev: any) => ({ ...prev, [t.key]: e.target.checked }))} />
            <Typography variant="body2">{t.label}</Typography>
          </Paper>
        ))}
      </Box>

      <TextField
        label="Welcome Message" size="small" fullWidth sx={{ mb: 2 }}
        value={cfg.welcome_message || ''}
        onChange={e => setCfg((prev: any) => ({ ...prev, welcome_message: e.target.value }))}
      />
      <TextField
        label="Welcome Subtitle" size="small" fullWidth sx={{ mb: 3 }}
        value={cfg.welcome_subtitle || ''}
        onChange={e => setCfg((prev: any) => ({ ...prev, welcome_subtitle: e.target.value }))}
      />

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {numbers.map(n => (
          <TextField key={n.key} label={n.label} type="number" size="small"
            value={cfg[n.key] ?? ''} fullWidth
            onChange={e => setCfg((prev: any) => ({ ...prev, [n.key]: parseInt(e.target.value) || 0 }))} />
        ))}
      </Box>

      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : saved ? 'Saved!' : 'Save Changes'}
        </Button>
      </Box>
    </Box>
  );
};

export default BusinessPortalAdminSection;
