/**
 * BF-428G — S3 Readers admin section.
 *
 * Surfaces the pluggable S3 reader system: master switch, default
 * reader, per-connection overrides, Athena settings, per-strategy
 * caps + a synthetic dry-run tester.
 *
 * Standards: TypeScript strict, no @ts-nocheck, no `any` in props,
 * uses safeFetch + safeStringify (BF-426/427), error display via
 * snackbar pattern.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Divider, FormControlLabel,
  Grid, IconButton, MenuItem, Paper, Select, Stack, Switch,
  Table, TableBody, TableCell, TableHead, TableRow, TextField,
  Tooltip, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import SaveIcon from '@mui/icons-material/Save';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import AddIcon from '@mui/icons-material/Add';
import {
  s3Readers, S3ReadersStatus, S3ReadersConfigUpdate, ReaderMetadata,
} from '../../services/api/s3Readers';

// BF-428K MEDIUM-4 — descriptions live in the backend metadata
// endpoint now (single source of truth).  Adding a reader requires
// touching only the backend; no frontend code changes.

interface TelemetryByReader { [name: string]: Record<string, unknown> }
interface TelemetryResponse { overall: Record<string, unknown>; by_reader: TelemetryByReader }

const S3ReadersAdminSection: React.FC = () => {
  const [status, setStatus] = useState<S3ReadersStatus | null>(null);
  const [metadata, setMetadata] = useState<ReaderMetadata[]>([]);
  const [telemetry, setTelemetry] = useState<TelemetryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [draft, setDraft] = useState<Partial<S3ReadersStatus>>({});
  // Test panel
  const [testReader, setTestReader] = useState<string>('');
  const [testResult, setTestResult] = useState<unknown | null>(null);
  // Per-connection table
  const [newConnId, setNewConnId] = useState('');
  const [newConnReader, setNewConnReader] = useState('');

  const descriptionFor = (name: string): string => {
    const m = metadata.find(x => x.name === name);
    return m?.description || '';
  };

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [s, meta, tel] = await Promise.all([
        s3Readers.status(),
        s3Readers.metadata().catch(() => [] as ReaderMetadata[]),
        s3Readers.telemetry().catch(() => null),
      ]);
      setStatus(s);
      setMetadata(meta);
      setTelemetry(tel);
      setDraft(s);
    } catch (e) {
      setError((e as Error).message);
    } finally { setLoading(false); }
  }, []);

  const handleResetTelemetry = async () => {
    try {
      await s3Readers.resetTelemetry();
      setSuccess('Telemetry counters reset');
      await load();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  useEffect(() => { load(); }, [load]);

  const dirty = status && Object.keys(draft).some(
    k => (draft as unknown as Record<string, unknown>)[k] !==
         (status as unknown as Record<string, unknown>)[k]
  );

  const save = async () => {
    if (!status) return;
    setSaving(true); setError(null); setSuccess(null);
    const changes: S3ReadersConfigUpdate = {};
    (Object.keys(draft) as (keyof S3ReadersStatus)[]).forEach(k => {
      const dv = (draft as unknown as Record<string, unknown>)[k];
      const sv = (status as unknown as Record<string, unknown>)[k];
      if (JSON.stringify(dv) !== JSON.stringify(sv)) {
        (changes as Record<string, unknown>)[k] = dv;
      }
    });
    try {
      await s3Readers.updateConfig(changes);
      setSuccess('Configuration saved');
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally { setSaving(false); }
  };

  const runTest = async () => {
    if (!testReader) return;
    setTestResult(null); setError(null);
    try {
      const r = await s3Readers.test(testReader);
      setTestResult(r);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  if (loading && !status) {
    return <Box sx={{ p: 2 }}><CircularProgress size={24} /></Box>;
  }
  if (!status) {
    return <Alert severity="error">Failed to load S3 readers status</Alert>;
  }

  const setDraftField = <K extends keyof S3ReadersStatus>(
    k: K, v: S3ReadersStatus[K],
  ) => setDraft(d => ({ ...d, [k]: v }));

  const addPerConn = () => {
    if (!newConnId.trim() || !newConnReader) return;
    const next = { ...(draft.per_connection || {}) };
    next[newConnId.trim()] = newConnReader;
    setDraftField('per_connection', next);
    setNewConnId(''); setNewConnReader('');
  };
  const removePerConn = (cid: string) => {
    const next = { ...(draft.per_connection || {}) };
    delete next[cid];
    setDraftField('per_connection', next);
  };

  return (
    <Box>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <Typography variant="h6">S3 Readers (BF-428)</Typography>
        <Tooltip title="Reload from server">
          <IconButton size="small" onClick={load}><RefreshIcon /></IconButton>
        </Tooltip>
        {dirty && (
          <Button variant="contained" size="small" startIcon={<SaveIcon />}
                  onClick={save} disabled={saving}>
            Save changes
          </Button>
        )}
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 1 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Master switch + default</Typography>
        <FormControlLabel
          control={
            <Switch
              checked={draft.integration_enabled ?? false}
              onChange={(_, v) => setDraftField('integration_enabled', v)}
            />
          }
          label="Integration enabled (route queries through new system)"
        />
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
          When OFF, all queries use the legacy direct/predownload path
          regardless of other settings.  Flip ON only after smoke testing.
        </Typography>
        <FormControlLabel
          control={
            <Switch
              checked={draft.auto_route_enabled ?? true}
              onChange={(_, v) => setDraftField('auto_route_enabled', v)}
            />
          }
          label="Auto-route enabled (cost-based router picks per query)"
        />
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" gutterBottom>Default reader (when no override):</Typography>
          <Select
            size="small" fullWidth
            value={draft.default ?? 'auto'}
            onChange={e => setDraftField('default', e.target.value)}
          >
            <MenuItem value="auto">auto (router decides)</MenuItem>
            {(status.available || []).map(r => (
              <MenuItem key={r} value={r}>{r}</MenuItem>
            ))}
          </Select>
          <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 1 }}>
            {descriptionFor(draft.default || '')}
          </Typography>
        </Box>
      </Paper>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Per-connection overrides</Typography>
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
          Pin a specific reader to a connection.  Useful when one connection
          has Iceberg in Glue (Athena candidate) but others don't.
        </Typography>
        <Table size="small">
          <TableHead>
            <TableRow><TableCell>Connection ID</TableCell><TableCell>Reader</TableCell><TableCell></TableCell></TableRow>
          </TableHead>
          <TableBody>
            {Object.entries(draft.per_connection || {}).map(([cid, r]) => (
              <TableRow key={cid}>
                <TableCell>{cid}</TableCell>
                <TableCell>{r}</TableCell>
                <TableCell>
                  <IconButton size="small" onClick={() => removePerConn(cid)}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            <TableRow>
              <TableCell>
                <TextField size="small" placeholder="42" value={newConnId}
                            onChange={e => setNewConnId(e.target.value)} />
              </TableCell>
              <TableCell>
                <Select size="small" value={newConnReader}
                         onChange={e => setNewConnReader(e.target.value)}
                         displayEmpty fullWidth>
                  <MenuItem value="" disabled>(select reader)</MenuItem>
                  {(status.available || []).map(r => (
                    <MenuItem key={r} value={r}>{r}</MenuItem>
                  ))}
                </Select>
              </TableCell>
              <TableCell>
                <IconButton size="small" onClick={addPerConn}>
                  <AddIcon fontSize="small" />
                </IconButton>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Paper>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Athena settings</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small" label="Workgroup"
                        value={draft.athena_workgroup ?? ''}
                        onChange={e => setDraftField('athena_workgroup', e.target.value)} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small" label="Database (required to enable)"
                        value={draft.athena_database ?? ''}
                        onChange={e => setDraftField('athena_database', e.target.value)} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <TextField fullWidth size="small" label="Output location s3:// (required to enable)"
                        value={draft.athena_output_location ?? ''}
                        onChange={e => setDraftField('athena_output_location', e.target.value)} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small" label="Poll interval (s)" type="number"
                        value={draft.athena_poll_interval_seconds ?? 1.0}
                        onChange={e => setDraftField('athena_poll_interval_seconds', parseFloat(e.target.value))} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small" label="Timeout (s)" type="number"
                        value={draft.athena_timeout_seconds ?? 300}
                        onChange={e => setDraftField('athena_timeout_seconds', parseInt(e.target.value, 10))} />
          </Grid>
        </Grid>
      </Paper>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Per-strategy caps</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small"
                        label="S3 Select max file bytes" type="number"
                        value={draft.s3_select_max_file_bytes ?? 5368709120}
                        onChange={e => setDraftField('s3_select_max_file_bytes', parseInt(e.target.value, 10))} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small"
                        label="PyArrow max rows (memory cap)" type="number"
                        value={draft.pyarrow_max_rows ?? 50000000}
                        onChange={e => setDraftField('pyarrow_max_rows', parseInt(e.target.value, 10))} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth size="small"
                        label="PyArrow default region"
                        value={draft.pyarrow_default_region ?? 'us-east-1'}
                        onChange={e => setDraftField('pyarrow_default_region', e.target.value)} />
          </Grid>
        </Grid>
      </Paper>

      {/* BF-430C — Telemetry: per-reader counters + roll-up.  Updates
          on each Refresh.  Reset button clears in-process counters
          (useful when measuring effect of a config change). */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          <Typography variant="subtitle1">Telemetry (BF-430C)</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Button size="small" onClick={handleResetTelemetry}
                  disabled={!telemetry}>
            Reset counters
          </Button>
        </Stack>
        {!telemetry || Object.keys(telemetry.by_reader || {}).length === 0 ? (
          <Typography variant="caption" color="text.secondary">
            No reader activity yet.  Counters appear once queries route
            through readers (master switch must be on).
          </Typography>
        ) : (
          <>
            <Typography variant="caption" color="text.secondary"
                        display="block" sx={{ mb: 1 }}>
              Uptime {String(telemetry.overall.uptime_seconds)}s ·
              {' '}{String(telemetry.overall.total_calls)} calls ·
              {' '}{String(telemetry.overall.total_bytes_read)} bytes ·
              {' '}{String(telemetry.overall.total_cache_hits)} cache hits
            </Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Reader</TableCell>
                  <TableCell align="right">Calls</TableCell>
                  <TableCell align="right">Success%</TableCell>
                  <TableCell align="right">Files</TableCell>
                  <TableCell align="right">Bytes</TableCell>
                  <TableCell align="right">Cache hits</TableCell>
                  <TableCell align="right">Avg dur (s)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {Object.entries(telemetry.by_reader).map(([name, s]) => (
                  <TableRow key={name}>
                    <TableCell><code>{name}</code></TableCell>
                    <TableCell align="right">{String(s.calls)}</TableCell>
                    <TableCell align="right">
                      {Math.round(Number(s.success_rate || 0) * 100)}%
                    </TableCell>
                    <TableCell align="right">{String(s.total_files)}</TableCell>
                    <TableCell align="right">{String(s.total_bytes_read)}</TableCell>
                    <TableCell align="right">{String(s.total_cache_hits)}</TableCell>
                    <TableCell align="right">{String(s.avg_duration_seconds)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </>
        )}
      </Paper>

      <Paper sx={{ p: 2 }}>
        <Typography variant="subtitle1" gutterBottom>Test reader (dry-run)</Typography>
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
          Validates can_handle without burning S3 calls.
        </Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Select size="small" value={testReader}
                   onChange={e => setTestReader(e.target.value)}
                   displayEmpty sx={{ minWidth: 220 }}>
            <MenuItem value="" disabled>(select a reader)</MenuItem>
            {(status.available || []).map(r => (
              <MenuItem key={r} value={r}>{r}</MenuItem>
            ))}
          </Select>
          <Button variant="outlined" startIcon={<PlayArrowIcon />}
                  onClick={runTest} disabled={!testReader}>
            Run dry-run
          </Button>
        </Stack>
        {testResult ? (
          <Box sx={{ mt: 2, fontFamily: 'monospace', fontSize: 12,
                      backgroundColor: 'action.hover', p: 1, borderRadius: 1 }}>
            <pre style={{ margin: 0 }}>{JSON.stringify(testResult, null, 2)}</pre>
          </Box>
        ) : null}
      </Paper>
    </Box>
  );
};

export default S3ReadersAdminSection;
