/**
 * Aggregation Cache section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Shows cache stats, pending suggestions, status distribution.
 * Uses api service for agg cache endpoints.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Button, Stack, Chip,
} from '@mui/material';
import api from '../../services/api';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

type ChipColor = 'success' | 'warning' | 'error' | 'info' | 'default';

const STATUS_COLORS: Record<string, ChipColor> = {
  ready: 'success',
  building: 'info',
  stale: 'warning',
  expired: 'error',
  failed: 'error',
  pending: 'default',
};

const AggCacheSection: React.FC<Props> = ({ addNotification }) => {
  const [aggCacheStats, setAggCacheStats] = useState<any>(null);
  const [aggCacheSuggestions, setAggCacheSuggestions] = useState<any[]>([]);

  const loadAggCache = useCallback(async () => {
    try {
      const [stats, suggs] = await Promise.all([
        api.getAggCacheStats().catch(() => ({})),
        api.listAggCacheSuggestions().catch(() => ({ suggestions: [] })),
      ]);
      setAggCacheStats(stats);
      setAggCacheSuggestions(suggs.suggestions || []);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadAggCache(); }, [loadAggCache]);

  const handleCleanup = async () => {
    try {
      await api.triggerAggCacheCleanup();
      loadAggCache();
    } catch { /* ignore */ }
  };

  const handleAnalyze = async () => {
    try {
      const result = await api.triggerAggCacheAnalysis();
      loadAggCache();
      addNotification({ type: 'info', title: 'Analysis', message: result.detail || 'Analysis complete' });
    } catch { /* ignore */ }
  };

  const handleApprove = async (id: number) => {
    try {
      await api.approveAggCacheSuggestion(id);
      loadAggCache();
    } catch { /* ignore */ }
  };

  const handleReject = async (id: number) => {
    try {
      await api.rejectAggCacheSuggestion(id);
      loadAggCache();
    } catch { /* ignore */ }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Aggregation Cache</Typography>
        <Stack direction="row" spacing={1}>
          <Button size="small" variant="outlined" onClick={loadAggCache}>
            Refresh
          </Button>
          <Button size="small" variant="outlined" color="warning" onClick={handleCleanup}>
            Cleanup
          </Button>
          <Button size="small" variant="outlined" color="info" onClick={handleAnalyze}>
            Analyze Usage
          </Button>
        </Stack>
      </Box>

      {aggCacheStats && (
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 3 }}>
          <StatCard label="Total Entries" value={aggCacheStats.total_entries ?? '\u2014'} />
          <StatCard label="Cache Size" value={`${aggCacheStats.total_size_mb ?? 0} MB / ${aggCacheStats.quota_mb ?? 0} MB`} />
          <StatCard label="Hit Rate" value={`${aggCacheStats.hit_rate_percent ?? 0}%`} />
          <StatCard label="Datasets Cached" value={aggCacheStats.datasets_cached ?? 0} />
          <StatCard label="Pending Suggestions" value={aggCacheStats.suggestions_pending ?? 0} />
        </Stack>
      )}
      {!aggCacheStats && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Loading stats...
        </Typography>
      )}

      {aggCacheSuggestions.length > 0 && (
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Pending Suggestions</Typography>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Dataset</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Dims</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Measures</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Queries</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Est. Speedup</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {aggCacheSuggestions.filter((s: any) => s.status === 'pending').map((s: any) => (
                  <TableRow key={s.id} hover>
                    <TableCell>Dataset #{s.dataset_id}</TableCell>
                    <TableCell>{(s.dimension_col_ids || []).length}</TableCell>
                    <TableCell>{(s.measure_col_ids || []).length}</TableCell>
                    <TableCell>{s.query_count}</TableCell>
                    <TableCell>{s.estimated_speedup}x</TableCell>
                    <TableCell>
                      <Button size="small" color="success" sx={{ mr: 0.5 }}
                        onClick={() => handleApprove(s.id)}>
                        Approve
                      </Button>
                      <Button size="small" color="error"
                        onClick={() => handleReject(s.id)}>
                        Reject
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {aggCacheStats && (aggCacheStats.entries_by_status || null) && (
        <Box>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Status Distribution</Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            {Object.entries(aggCacheStats.entries_by_status).map(([status, count]: [string, any]) => (
              <Chip key={status} label={`${status}: ${count}`} size="small"
                color={STATUS_COLORS[status] || 'default'} variant="outlined" />
            ))}
          </Stack>
        </Box>
      )}
    </Paper>
  );
};

export default AggCacheSection;
