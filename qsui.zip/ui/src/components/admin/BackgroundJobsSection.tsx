/**
 * BF-308 — Background-jobs admin panel.
 *
 * Lists every registered background task and lets the admin start/stop
 * each one.  Non-controllable jobs (e.g. WS heartbeat) are shown for
 * visibility but their buttons are disabled.
 *
 * "Create new job" — admin can request a new periodic job (BF-310, in
 * progress).  For now the section explains the capability and points
 * to the existing places where periodic work can be set up (Schedules,
 * Materialized Views, Feeds).
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton,
  Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow,
  Tooltip, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import StopIcon from '@mui/icons-material/Stop';
import PauseIcon from '@mui/icons-material/Pause';
import { safeFetch } from '../../services/api/core';

interface JobInfo {
  name: string;
  description: string;
  autostart: boolean;
  controllable: boolean;
  running: boolean;
  paused: boolean;
  status: 'running' | 'stopped' | 'errored' | 'completed' | 'paused';
  started_at: string | null;
  stopped_at: string | null;
  paused_at: string | null;
  last_error: string | null;
}

export default function BackgroundJobsSection() {
  const [jobs, setJobs] = useState<JobInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const reload = useCallback(async () => {
    setLoading(true); setErr(null);
    try {
      const j: any = await safeFetch('/api/admin/background-jobs');
      setJobs(j?.jobs || []);
    } catch (e) {
      setErr(`Failed to load: ${e}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);
  // Live status polling
  useEffect(() => {
    const t = setInterval(reload, 10_000);
    return () => clearInterval(t);
  }, [reload]);

  const handleStart = useCallback(async (name: string) => {
    setBusy(name); setErr(null); setMsg(null);
    try {
      await safeFetch(`/api/admin/background-jobs/${encodeURIComponent(name)}/start`,
                       { method: 'POST' });
      setMsg(`Started ${name}`);
      reload();
    } catch (e) {
      setErr(`Start failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const handleStop = useCallback(async (name: string) => {
    setBusy(name); setErr(null); setMsg(null);
    try {
      await safeFetch(`/api/admin/background-jobs/${encodeURIComponent(name)}/stop`,
                       { method: 'POST' });
      setMsg(`Stopped ${name}`);
      reload();
    } catch (e) {
      setErr(`Stop failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  const handlePause = useCallback(async (name: string) => {
    setBusy(name); setErr(null); setMsg(null);
    try {
      await safeFetch(`/api/admin/background-jobs/${encodeURIComponent(name)}/pause`,
                       { method: 'POST' });
      setMsg(`Paused ${name} — click Resume to continue`);
      reload();
    } catch (e) {
      setErr(`Pause failed: ${e}`);
    } finally {
      setBusy(null);
    }
  }, [reload]);

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Typography variant="h6">Background Jobs</Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Tooltip title="Refresh">
          <IconButton onClick={reload} disabled={loading || !!busy}>
            <RefreshIcon />
          </IconButton>
        </Tooltip>
      </Stack>

      <Typography variant="body2" sx={{ mb: 2, color: 'text.secondary' }}>
        Every long-running task QueryStudio runs in the background.
        Admins can start / stop each individually here.  Some jobs
        (e.g. WebSocket heartbeat) are non-controllable because the
        platform depends on them — they&apos;re shown for visibility.
      </Typography>

      <Alert severity="info" sx={{ mb: 2, fontSize: 12 }}>
        <strong>Create custom jobs</strong> — you can already schedule periodic
        SQL queries via <em>Schedules</em>, refresh queries via
        <em> Materialized Views</em>, and run periodic exports via
        <em> Feeds</em>.  A unified &quot;custom periodic job&quot; creator
        (any type) is on the roadmap as BF-310.
      </Alert>

      {msg && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setMsg(null)}>{msg}</Alert>}
      {err && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setErr(null)}>{err}</Alert>}

      {loading && jobs.length === 0 ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
          <CircularProgress size={28} />
        </Box>
      ) : jobs.length === 0 ? (
        <Alert severity="info">
          No background jobs registered yet.  Jobs register themselves
          on backend startup — restart the API and reload.
        </Alert>
      ) : (
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Name</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Description</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Status</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }}>Started</TableCell>
              <TableCell sx={{ fontSize: 12, fontWeight: 600 }} align="right">Controls</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {jobs.map((j) => {
              const statusColor = j.status === 'running' ? 'success'
                                : j.status === 'errored' ? 'error'
                                : j.status === 'paused' ? 'warning'
                                : j.status === 'completed' ? 'info'
                                : 'default';
              return (
                <TableRow key={j.name} hover>
                  <TableCell sx={{ fontSize: 12, fontFamily: 'monospace' }}>
                    {j.name}
                    {!j.autostart && <Chip size="small" label="manual" sx={{ ml: 1, fontSize: 9, height: 16 }} />}
                    {!j.controllable && <Chip size="small" label="locked" color="warning" sx={{ ml: 1, fontSize: 9, height: 16 }} />}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                    {j.description}
                  </TableCell>
                  <TableCell>
                    <Chip size="small" label={j.status} color={statusColor as any}
                           sx={{ fontSize: 10, height: 18 }} />
                    {j.last_error && (
                      <Tooltip title={j.last_error}>
                        <Typography variant="caption" sx={{ display: 'block', fontSize: 9, color: 'error.main' }}>
                          {j.last_error.slice(0, 60)}…
                        </Typography>
                      </Tooltip>
                    )}
                  </TableCell>
                  <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>
                    {j.started_at ? new Date(j.started_at).toLocaleTimeString() : '—'}
                  </TableCell>
                  <TableCell align="right">
                    {j.running ? (
                      <>
                        <Tooltip title={j.controllable ? 'Pause — keep status as paused' : 'Non-controllable'}>
                          <span>
                            <IconButton size="small" color="warning"
                                         disabled={!j.controllable || busy === j.name}
                                         onClick={() => handlePause(j.name)}>
                              {busy === j.name ? <CircularProgress size={14} /> : <PauseIcon fontSize="small" />}
                            </IconButton>
                          </span>
                        </Tooltip>
                        <Tooltip title={j.controllable ? 'Stop — clear status to stopped' : 'Non-controllable'}>
                          <span>
                            <IconButton size="small"
                                         disabled={!j.controllable || busy === j.name}
                                         onClick={() => handleStop(j.name)}>
                              <StopIcon fontSize="small" />
                            </IconButton>
                          </span>
                        </Tooltip>
                      </>
                    ) : (
                      <Tooltip title={
                        !j.controllable ? 'Non-controllable' :
                        j.paused ? 'Resume this paused job' : 'Start this job'
                      }>
                        <span>
                          <IconButton size="small" color="success"
                                       disabled={!j.controllable || busy === j.name}
                                       onClick={() => handleStart(j.name)}>
                            {busy === j.name ? <CircularProgress size={14} /> : <PlayArrowIcon fontSize="small" />}
                          </IconButton>
                        </span>
                      </Tooltip>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
    </Paper>
  );
}
