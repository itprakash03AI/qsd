/**
 * Scan Strategy Admin (2026-06-01)
 *
 * Single page for all per-scan execution decisions — replaces the
 * scattered legacy knobs (max_workers, BF-535 ordering, prewarm,
 * DuckDB pragmas, boto3 pool) that used to live across S3 Performance,
 * Multi-Worker, and Iceberg admin panels.
 *
 * Design mirrors the backend ScanStrategist:
 *   * Pick ONE profile (auto / bulk_scan / interactive / low_latency)
 *   * Optionally override individual fields per profile
 *   * Built-in defaults render alongside so operators can see what the
 *     plan *would* be before they touch anything.
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Typography, Paper, TextField, Select, MenuItem, FormControl,
  FormControlLabel, Switch, Button, Alert, Grid, Chip, LinearProgress,
  InputLabel, Stack, Divider, Accordion, AccordionSummary, AccordionDetails,
  Tooltip,
} from '@mui/material';
import {
  Speed as SpeedIcon, ExpandMore as ExpandMoreIcon,
  Save as SaveIcon, Info as InfoIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

type ProfileName = 'bulk_scan' | 'interactive' | 'low_latency';
const PROFILE_NAMES: ProfileName[] = ['bulk_scan', 'interactive', 'low_latency'];
const TOP_PROFILES = ['auto', ...PROFILE_NAMES] as const;
const FILE_ORDERS = [
  'manifest_order', 'largest_first', 'smallest_first', 'size_balanced',
] as const;

interface ProfilePlan {
  file_order: string;
  max_workers: number;
  min_files_to_split: number;
  max_files_per_worker: number;
  prewarm_footers: boolean;
  prewarm_concurrency: number;
  duckdb_threads: number;
  duckdb_object_cache: boolean;
  duckdb_http_keep_alive: boolean;
  boto3_max_pool_connections: number;
  wait_for_supplement: boolean;
  rationale: string;
}

interface ConfigResponse {
  profile: string;
  default_file_order: string;
  profile_overrides: Record<string, Partial<ProfilePlan>>;
  built_in_defaults: Record<string, ProfilePlan>;
  valid_profiles: string[];
  valid_file_orders: string[];
}

const PROFILE_LABELS: Record<string, string> = {
  auto:         'Auto (recommended)',
  bulk_scan:    'Bulk Scan',
  interactive:  'Interactive',
  low_latency:  'Low Latency',
};

const PROFILE_HINTS: Record<string, string> = {
  auto: 'ScanStrategist picks per call: feed gen / reports → Bulk Scan, BQB with LIMIT → Interactive, published API → Low Latency.',
  bulk_scan: 'Full-table scans (feed gen, reports). Largest-first ordering, 16 workers, parallel footer pre-warm. Best for 1000+ file workloads on VPC link.',
  interactive: 'BQB / CQB ad-hoc with LIMIT. Smallest-first so DuckDB LIMIT pushdown trips before opening the giant partitions.',
  low_latency: 'Published-API reads. Cache-first, size-balanced order, no blocking pre-warm.',
};

const ScanStrategyAdminSection: React.FC = () => {
  const [data, setData] = useState<ConfigResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const resp = await safeFetch('/api/admin/scan-strategy/config');
      setData(resp);
    } catch (e: any) {
      setError(e.message || 'Failed to load scan-strategy config');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!data) return;
    setSaving(true); setError(''); setSuccess('');
    try {
      await safeFetch('/api/admin/scan-strategy/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile: data.profile,
          default_file_order: data.default_file_order,
          profile_overrides: data.profile_overrides,
        }),
      });
      setSuccess('Scan strategy saved');
    } catch (e: any) {
      setError(e.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const setProfile = (p: string) =>
    data && setData({ ...data, profile: p });

  const setDefaultOrder = (o: string) =>
    data && setData({ ...data, default_file_order: o });

  const setOverride = (
    profile: ProfileName, key: keyof ProfilePlan, value: any,
  ) => {
    if (!data) return;
    const next = { ...data.profile_overrides };
    next[profile] = { ...(next[profile] || {}), [key]: value };
    setData({ ...data, profile_overrides: next });
  };

  const clearOverrideKey = (profile: ProfileName, key: keyof ProfilePlan) => {
    if (!data) return;
    const next = { ...data.profile_overrides };
    const block = { ...(next[profile] || {}) };
    delete block[key];
    next[profile] = block;
    setData({ ...data, profile_overrides: next });
  };

  if (loading) return <LinearProgress />;
  if (!data) return <Alert severity="error">Failed to load scan-strategy config</Alert>;

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
        <SpeedIcon /> Scan Strategy
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Single source of truth for per-scan decisions: file ordering, worker count, parallel
        footer pre-warm, DuckDB pragmas, boto3 pool. Replaces a dozen scattered legacy
        flags. Pick a <b>profile</b> below; the strategist picks the rest per call.
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setError('')}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 1 }} onClose={() => setSuccess('')}>{success}</Alert>}

      {/* ── Profile picker + global fallback order ─────────────────────── */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Grid container spacing={2}>
          <Grid size={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Active profile</InputLabel>
              <Select value={data.profile} label="Active profile"
                onChange={(e) => setProfile(String(e.target.value))}>
                {TOP_PROFILES.map((p) => (
                  <MenuItem key={p} value={p}>
                    {PROFILE_LABELS[p]}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              {PROFILE_HINTS[data.profile]}
            </Typography>
          </Grid>
          <Grid size={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Fallback file order (legacy callers)</InputLabel>
              <Select value={data.default_file_order} label="Fallback file order (legacy callers)"
                onChange={(e) => setDefaultOrder(String(e.target.value))}>
                {FILE_ORDERS.map((o) => (
                  <MenuItem key={o} value={o}>{o}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              Used when a caller hasn’t been migrated to pass an explicit ScanPlan yet. Default
              <code> manifest_order </code> (no implicit sort) preserves legacy DuckDB parallel-
              scanner behaviour. Flip to <code>largest_first</code> if old-path bulk scans still
              hit straggler-tail problems.
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      {/* ── Per-profile overrides ──────────────────────────────────────── */}
      {PROFILE_NAMES.map((p) => {
        const defaults = data.built_in_defaults[p];
        const overrides = data.profile_overrides[p] || {};
        const isActive = data.profile === p || data.profile === 'auto';

        return (
          <Accordion key={p} sx={{ mb: 1 }} defaultExpanded={p === 'bulk_scan'}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="subtitle1">{PROFILE_LABELS[p]}</Typography>
                {isActive && <Chip size="small" color="primary" label="reachable" />}
                {Object.keys(overrides).length > 0 && (
                  <Chip size="small" color="warning"
                    label={`${Object.keys(overrides).length} override${Object.keys(overrides).length === 1 ? '' : 's'}`} />
                )}
              </Stack>
            </AccordionSummary>
            <AccordionDetails>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 2, display: 'block' }}>
                {PROFILE_HINTS[p]} <br />
                <i>Built-in rationale: {defaults?.rationale}</i>
              </Typography>

              <Grid container spacing={2}>
                {/* File order */}
                <Grid size={4}>
                  <ProfileOrderField
                    label="File order"
                    overrideValue={overrides.file_order}
                    defaultValue={defaults?.file_order || 'manifest_order'}
                    onSet={(v) => setOverride(p, 'file_order', v)}
                    onClear={() => clearOverrideKey(p, 'file_order')}
                  />
                </Grid>

                {/* Int knobs */}
                <ProfileIntField
                  label="Max workers" k="max_workers"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileIntField
                  label="Min files to split" k="min_files_to_split"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileIntField
                  label="Max files per worker" k="max_files_per_worker"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileIntField
                  label="Prewarm concurrency" k="prewarm_concurrency"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileIntField
                  label="DuckDB threads / worker" k="duckdb_threads"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileIntField
                  label="boto3 pool size" k="boto3_max_pool_connections"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />

                {/* Bool knobs */}
                <ProfileBoolField
                  label="Pre-warm footers (parallel HEAD)" k="prewarm_footers"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileBoolField
                  label="DuckDB object cache" k="duckdb_object_cache"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileBoolField
                  label="HTTP keep-alive" k="duckdb_http_keep_alive"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
                <ProfileBoolField
                  label="Block on supplement scan" k="wait_for_supplement"
                  p={p} overrides={overrides} defaults={defaults}
                  onSet={setOverride} onClear={clearOverrideKey}
                />
              </Grid>
            </AccordionDetails>
          </Accordion>
        );
      })}

      <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
        <Button onClick={load} disabled={saving}>Reload</Button>
        <Button variant="contained" startIcon={<SaveIcon />} disabled={saving}
          onClick={save}>
          {saving ? 'Saving…' : 'Save'}
        </Button>
      </Box>
    </Box>
  );
};


// ── Helper fields ──────────────────────────────────────────────────────────

interface ProfileFieldBase {
  p: ProfileName;
  overrides: Partial<ProfilePlan>;
  defaults: ProfilePlan | undefined;
  onSet: (p: ProfileName, k: keyof ProfilePlan, v: any) => void;
  onClear: (p: ProfileName, k: keyof ProfilePlan) => void;
}

const ProfileIntField: React.FC<ProfileFieldBase & {
  label: string; k: keyof ProfilePlan;
}> = ({ label, k, p, overrides, defaults, onSet, onClear }) => {
  const overriden = overrides[k];
  const effective = (overriden ?? (defaults as any)?.[k]) as number | undefined;
  const isOverride = overriden !== undefined;
  return (
    <Grid size={4}>
      <TextField fullWidth size="small" type="number"
        label={label}
        value={effective ?? ''}
        onChange={(e) => onSet(p, k, Number(e.target.value))}
        InputProps={{
          endAdornment: isOverride ? (
            <Tooltip title="Override active — click to revert to built-in default">
              <Chip size="small" label="override" color="warning"
                onDelete={() => onClear(p, k)} />
            </Tooltip>
          ) : (
            <Tooltip title="Using built-in default"><InfoIcon fontSize="small" color="disabled" /></Tooltip>
          ),
        }}
      />
    </Grid>
  );
};

const ProfileBoolField: React.FC<ProfileFieldBase & {
  label: string; k: keyof ProfilePlan;
}> = ({ label, k, p, overrides, defaults, onSet, onClear }) => {
  const overriden = overrides[k];
  const effective = (overriden ?? (defaults as any)?.[k]) as boolean | undefined;
  const isOverride = overriden !== undefined;
  return (
    <Grid size={4}>
      <Stack direction="row" spacing={1} alignItems="center">
        <FormControlLabel
          control={<Switch checked={!!effective}
            onChange={(e) => onSet(p, k, e.target.checked)} />}
          label={label}
        />
        {isOverride && (
          <Chip size="small" label="override" color="warning"
            onDelete={() => onClear(p, k)} />
        )}
      </Stack>
    </Grid>
  );
};

const ProfileOrderField: React.FC<{
  label: string;
  overrideValue: string | undefined;
  defaultValue: string;
  onSet: (v: string) => void;
  onClear: () => void;
}> = ({ label, overrideValue, defaultValue, onSet, onClear }) => {
  const effective = overrideValue ?? defaultValue;
  const isOverride = overrideValue !== undefined;
  return (
    <Stack direction="row" spacing={1} alignItems="center">
      <FormControl fullWidth size="small">
        <InputLabel>{label}</InputLabel>
        <Select value={effective} label={label}
          onChange={(e) => onSet(String(e.target.value))}>
          {FILE_ORDERS.map((o) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
        </Select>
      </FormControl>
      {isOverride && (
        <Chip size="small" label="override" color="warning"
          onDelete={onClear} />
      )}
    </Stack>
  );
};


export default ScanStrategyAdminSection;
