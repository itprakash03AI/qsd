import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Alert, Switch, FormControlLabel, Stack,
} from '@mui/material';
import { GppGood as GppGoodIcon, Save as SaveIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

interface NumInputProps {
  k: string;
  label: string;
  helperText?: string;
  min?: number;
  max?: number;
}

const GovernanceAdminSection: React.FC = () => {
  const [cfg, setCfg]       = useState<any>(null);
  const [draft, setDraft]   = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving]   = useState(false);
  const [saved, setSaved]     = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const d = await safeFetch('/api/admin/governance/config');
      setCfg(d);
      setDraft({ ...d });
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const set = (k: string, v: boolean | number | string) => {
    setDraft((d: Record<string, any> | null) => (d ? { ...d, [k]: v } : d));
    setSaved(false);
  };

  const dirty = cfg && draft && Object.keys(draft).some(k => draft[k] !== cfg[k]);

  const save = async () => {
    if (!dirty) return;
    setSaving(true);
    setError(null);
    try {
      // Send only changed keys
      const diff: Record<string, any> = {};
      for (const k of Object.keys(draft)) {
        if (draft[k] !== cfg[k]) diff[k] = draft[k];
      }
      await safeFetch('/api/admin/governance/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(diff),
      });
      setSaved(true);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  };

  const reset = () => { if (cfg) { setDraft({ ...cfg }); setSaved(false); } };

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress size={24} /></Box>;
  if (!draft) return <Alert severity="error">{error || 'Failed to load'}</Alert>;

  const roles = ['admin', 'analyst', 'viewer'];

  // Helper for numeric input
  const NumInput = ({ k, label, helperText, min = 0, max = 100000 }: NumInputProps) => (
    <TextField
      size="small"
      label={label}
      type="number"
      value={draft[k] ?? 0}
      onChange={e => set(k, parseInt(e.target.value) || 0)}
      inputProps={{ min, max }}
      helperText={helperText}
      sx={{ minWidth: 160 }}
    />
  );

  // Export format checkboxes (formats as CSV string)
  const EXPORT_FORMATS = ['csv', 'excel', 'json', 'pdf'];
  const toggleFormat = (role: string, fmt: string) => {
    const key = `export_formats_${role}`;
    const current = (draft[key] || '').split(',').map((s: string) => s.trim()).filter(Boolean);
    const next = current.includes(fmt) ? current.filter((f: string) => f !== fmt) : [...current, fmt];
    set(key, next.join(','));
  };
  const hasFormat = (role: string, fmt: string) => {
    const val = draft[`export_formats_${role}`] || '';
    return val.split(',').map((s: string) => s.trim()).includes(fmt);
  };

  return (
    <Box sx={{ p: 1 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <GppGoodIcon color="action" />
        <Typography variant="h6" fontWeight={600}>Admin Governance</Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" onClick={reset} disabled={!dirty || saving}>Reset</Button>
        <Button size="small" variant="contained" startIcon={<SaveIcon />}
                onClick={save} disabled={!dirty || saving}>
          {saving ? 'Saving…' : 'Save Changes'}
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {saved && !dirty && <Alert severity="success" sx={{ mb: 2 }}>Governance config saved.</Alert>}

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Per-role rate limits, daily quotas, export controls, and resource caps. When disabled, all
        limits are bypassed (backwards-compatible mode).
      </Typography>

      {/* Master switch */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <FormControlLabel
          control={<Switch checked={!!draft.enabled}
                           onChange={e => set('enabled', e.target.checked)}
                           color="primary" />}
          label={<Typography fontWeight={600}>Governance enforcement enabled</Typography>}
        />
        <Typography variant="caption" display="block" color="text.secondary" sx={{ ml: 5 }}>
          Master switch — when off, no rate-limits / quotas / ACLs are enforced.
        </Typography>
      </Paper>

      {/* Rate limits (per-minute) */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Rate Limits (queries per minute)</Typography>
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          {roles.map(r => (
            <NumInput key={r} k={`rate_limit_${r}`} label={`${r} / min`}
                      helperText="0 = blocked" min={0} max={10000} />
          ))}
        </Stack>
      </Paper>

      {/* Daily quotas */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Daily Query Quotas</Typography>
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          {roles.map(r => (
            <NumInput key={r} k={`daily_quota_${r}`} label={`${r} / day`}
                      helperText="0 = unlimited" min={0} max={100000} />
          ))}
        </Stack>
      </Paper>

      {/* Export controls */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Export Controls</Typography>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Role</TableCell>
                {EXPORT_FORMATS.map(f => (
                  <TableCell key={f} align="center" sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.7rem' }}>
                    {f}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {roles.map(r => (
                <TableRow key={r} hover>
                  <TableCell sx={{ textTransform: 'capitalize', fontWeight: 500 }}>{r}</TableCell>
                  {EXPORT_FORMATS.map(f => (
                    <TableCell key={f} align="center">
                      <Switch size="small" checked={hasFormat(r, f)}
                              onChange={() => toggleFormat(r, f)} color="primary" />
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Stack direction="row" spacing={2} sx={{ mt: 2 }} flexWrap="wrap" useFlexGap>
          <NumInput k="export_rate_limit_per_minute" label="Export rate limit/min"
                    helperText="All roles" min={1} max={1000} />
          <NumInput k="export_max_file_size_mb" label="Max file size (MB)"
                    helperText="Per-export cap" min={1} max={10000} />
        </Stack>
      </Paper>

      {/* Resource quotas */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Per-User Resource Quotas</Typography>
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          <NumInput k="max_connections_per_user" label="Max connections"
                    helperText="Per user" min={1} max={1000} />
          <NumInput k="max_schedules_per_user" label="Max schedules"
                    helperText="Per user" min={1} max={1000} />
          <NumInput k="max_published_views_per_user" label="Max published views"
                    helperText="Per user" min={1} max={1000} />
        </Stack>
      </Paper>

      {/* Misc */}
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Advanced</Typography>
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          <NumInput k="audit_log_max_results" label="Audit log max results"
                    helperText="Per query" min={10} max={10000} />
          <NumInput k="daily_quota_cache_ttl_seconds" label="Quota cache TTL (sec)"
                    helperText="In-proc cache" min={1} max={3600} />
        </Stack>
      </Paper>
    </Box>
  );
};

export default GovernanceAdminSection;
