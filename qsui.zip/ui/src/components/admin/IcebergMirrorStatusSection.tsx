/**
 * Phase 150 — Iceberg Mirror Status admin UI.
 *
 * Read-side mirror: consolidated parquet rewrite of an iceberg snapshot,
 * written to QS-internal bucket.  Routing is OFF by default — Stage 1
 * ships SHADOW builds only.  Operator flips per-row routing_enabled
 * after observing zero divergence in the Layer-3 dual-run canary log.
 *
 * Endpoints used:
 *   GET  /api/admin/iceberg/mirror/list
 *   GET  /api/admin/iceberg/mirror/events
 *   POST /api/admin/iceberg/mirror/build
 *   POST /api/admin/iceberg/mirror/analyse
 *   POST /api/admin/iceberg/mirror/{id}/routing
 *   POST /api/admin/iceberg/mirror/{id}/invalidate
 *   DELETE /api/admin/iceberg/mirror/{id}
 *   POST /api/admin/iceberg/mirror/tick
 *   POST /api/admin/iceberg/mirror/cleanup
 *   GET  /api/admin/iceberg/mirror/{id}/dual-run
 */
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert, Switch,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, FormControlLabel,
  Accordion, AccordionSummary, AccordionDetails, Autocomplete,
  Grid,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as PlayIcon,
  Delete as DeleteIcon,
  Block as BlockIcon,
  Build as BuildIcon,
  CleaningServices as CleaningIcon,
  ExpandMore as ExpandMoreIcon,
  Storage as StorageIcon,
  Compare as CompareIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface MirrorRow {
  id:                       number;
  source_bucket:            string;
  source_prefix:            string;
  source_snapshot_id:       string;
  source_schema_hash:       string;
  source_row_count:         number;
  source_file_count:        number;
  source_total_bytes:       number;
  mirror_root_uri:          string;
  mirror_manifest_uri:      string;
  mirror_file_count:        number;
  mirror_total_bytes:       number;
  mirror_row_count:         number;
  status:                   string;
  routing_enabled:          boolean;
  built_at:                 string | null;
  last_route_at:            string | null;
  invalidated_at:           string | null;
  build_duration_seconds:   number | null;
  dual_run_samples:         number;
  dual_run_divergences:     number;
  dual_run_last_at:         string | null;
  route_hit_count:          number;
  last_error:               string;
  notes:                    string;
}


interface DualRunEvent {
  id:                number;
  mirror_id:         number;
  occurred_at:       string | null;
  diverged:          boolean;
  source_row_count:  number;
  mirror_row_count:  number;
  source_hash:       string | null;
  mirror_hash:       string | null;
  query_signature:   string | null;
  notes:             string;
}


interface TickRecord {
  started_at:       string;
  elapsed_seconds:  number;
  cleanup?:         { scanned?: number; deleted?: number; errors?: number; retained?: number };
  builds?:          { considered?: number; built?: number; skipped?: number; errors?: number };
  skipped_reason?:  string;
  error?:           string;
}


interface EventRecord {
  at:        string;
  kind:      string;
  [k: string]: any;
}


interface DiscoverableTable {
  connection_id:        number;
  connection_name:      string;
  bucket:               string;
  table_prefix:         string;
  table_name:           string;
  mirror_id:            number | null;
  mirror_status:        string | null;
  mirror_snapshot_id:   string | null;
  mirror_built_at:      string | null;
  routing_enabled:      boolean;
  mirror_row_count:     number;
  mirror_file_count:    number;
  queries_last_168h:    number;
  eligible_to_build:    boolean;
}


interface DiscoverableResponse {
  tables:          DiscoverableTable[];
  total:           number;
  ready_mirrors:   number;
  eligible_count:  number;
}


interface BrainComponentStatus {
  name:                     string;
  purpose:                  string;
  enabled:                  boolean;
  interval_hours?:          number;
  routing_enabled_global?:  boolean;
  serve_enabled?:           boolean;
  storage:                  string;
  scheduler: {
    registered:             boolean;
    next_run_time?:         string | null;
    trigger?:               string;
    error?:                 string;
  };
  last_tick?:               any;
  config_keys:              string[];
}


interface BrainStatus {
  components: BrainComponentStatus[];
  storage:    Record<string, any>;
  computed_at: string;
  summary: {
    total_components:   number;
    enabled_count:      number;
    registered_count:   number;
  };
}


interface ConnectionRecord {
  id:               number;
  name:             string;
  connection_type:  string;
  config:           any;
}


interface PartitionColumn {
  column:                  string;
  coverage_pct:            number;
  distinct_value_count:    number;
  distinct_values_sample:  string[];
}


interface PartitionDetectResponse {
  table:           string;
  snapshot_id:     string;
  files_total:     number;
  columns:         PartitionColumn[];
}


const relativeAge = (iso: string | null | undefined): string => {
  if (!iso) return '—';
  const ms = Date.now() - new Date(iso).getTime();
  if (Number.isNaN(ms) || ms < 0) return String(iso).slice(0, 19);
  const s = Math.round(ms / 1000);
  if (s < 60)    return `${s}s ago`;
  if (s < 3600)  return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
};


const fmtBytes = (n: number): string => {
  if (!n) return '0';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = n, u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u += 1; }
  return `${v.toFixed(v < 10 ? 2 : 1)} ${units[u]}`;
};


const statusChipColor = (status: string): 'success' | 'warning' | 'error' | 'default' | 'info' => {
  switch (status) {
    case 'ready':    return 'success';
    case 'building': return 'info';
    case 'stale':    return 'warning';
    case 'invalid':  return 'error';
    case 'failed':   return 'error';
    default:         return 'default';
  }
};


const IcebergMirrorStatusSection: React.FC = () => {
  const [rows, setRows] = useState<MirrorRow[]>([]);
  const [events, setEvents] = useState<EventRecord[]>([]);
  const [ticks, setTicks] = useState<TickRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [working, setWorking] = useState<string | null>(null);
  const [buildDialogOpen, setBuildDialogOpen] = useState(false);
  const [buildConnId, setBuildConnId] = useState<number | ''>('');
  const [buildTable, setBuildTable] = useState<string>('');
  const [buildForce, setBuildForce] = useState<boolean>(false);
  // Phase 151 follow-up — partition-scoped builds.  Detected on
  // demand from /api/admin/iceberg/mirror/partition-detect; operator
  // picks col + value(s).  Empty col → full-table build (legacy
  // behaviour).  The top (highest-coverage) column is auto-selected
  // so the operator typically only picks values — column name is
  // data-driven from the table's actual partition layout, never
  // hardcoded.
  const [buildPartitionCols, setBuildPartitionCols] = useState<PartitionColumn[]>([]);
  const [buildPartitionColName, setBuildPartitionColName] = useState<string>('');
  const [buildPartitionValues, setBuildPartitionValues] = useState<string[]>([]);
  const [detectingPart, setDetectingPart] = useState<boolean>(false);
  // sort_by — ORDER BY columns added to the COPY's SELECT.  Tight
  // row-group min/max bounds on these cols → DuckDB skips entire
  // row-groups for WHERE filters at read time.  Same data, just
  // laid out for the actual query pattern.
  const [buildSortBy, setBuildSortBy] = useState<string[]>([]);
  // Sortedness diagnostics — surfaces the brain's verdict on whether
  // sort_by would actually unlock new pruning vs duplicate data for
  // no gain.
  const [sortednessByCol, setSortednessByCol] = useState<Record<string, {
    verdict: string;
    monotonic_pct: number;
    recommendation: string;
  }>>({});
  const [analysingCol, setAnalysingCol] = useState<string | null>(null);
  const [dualRunDialog, setDualRunDialog] = useState<{ open: boolean; mirrorId: number | null; events: DualRunEvent[] }>({
    open: false, mirrorId: null, events: [],
  });

  // Phase 150 follow-up — real connection picker + cascading table
  // picker drives the Build dialog (replaces the typed-id text box).
  const [connections, setConnections] = useState<ConnectionRecord[]>([]);
  // Discoverable tables view replaces "table empty" empty state and
  // powers the table-name dropdown when a connection is chosen.
  const [discoverable, setDiscoverable] = useState<DiscoverableResponse | null>(null);
  const [discoverLoading, setDiscoverLoading] = useState(false);
  // Brain pipeline status panel — single source of truth for "what
  // is/will be running" question.
  const [brain, setBrain] = useState<BrainStatus | null>(null);
  const [brainLoading, setBrainLoading] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true); setError(null);
    setDiscoverLoading(true);
    setBrainLoading(true);
    try {
      // Five parallel reads — mirror list + event ring + tick ring +
      // discoverable iceberg tables + brain pipeline status.
      const [listRes, evRes, discRes, brainRes, connsRes] = await Promise.all([
        safeFetch('/api/admin/iceberg/mirror/list', { timeoutMs: 30000 }),
        safeFetch('/api/admin/iceberg/mirror/events?limit=100', { timeoutMs: 15000 }),
        safeFetch('/api/admin/iceberg/mirror/discoverable-tables', { timeoutMs: 30000 })
          .catch(() => null),
        safeFetch('/api/admin/brain/status', { timeoutMs: 15000 })
          .catch(() => null),
        safeFetch('/api/connections', { timeoutMs: 15000 })
          .catch(() => null),
      ]);
      setRows(listRes?.mirrors ?? []);
      setEvents(evRes?.events ?? []);
      setTicks(evRes?.ticks ?? []);
      setDiscoverable(discRes as DiscoverableResponse | null);
      setBrain(brainRes as BrainStatus | null);
      // Connection list shape: bare-array or {connections: [...]}.
      const rawConns = (connsRes as any)?.connections ?? connsRes ?? [];
      const conns: ConnectionRecord[] = Array.isArray(rawConns) ? rawConns : [];
      setConnections(conns.filter((c) => c.connection_type === 's3'));
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
      setDiscoverLoading(false);
      setBrainLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  // Cascading table picker — the registered iceberg tables of the
  // chosen connection drive the second Autocomplete in the Build dialog.
  const availableTables = useMemo((): string[] => {
    if (typeof buildConnId !== 'number') return [];
    const conn = connections.find((c) => c.id === buildConnId);
    const regs: any[] = conn?.config?.registered_tables || [];
    return regs
      .filter((rt: any) => rt?.format === 'iceberg' && rt?.name)
      .map((rt: any) => rt.name as string)
      .sort();
  }, [buildConnId, connections]);

  // Pre-fill Build dialog from a Discoverable-tables row click.
  const buildFromDiscoverable = useCallback((row: DiscoverableTable) => {
    setBuildConnId(row.connection_id);
    setBuildTable(row.table_name);
    setBuildForce(false);
    setBuildDialogOpen(true);
  }, []);

  const setRouting = useCallback(async (row: MirrorRow, enabled: boolean) => {
    setWorking(`route-${row.id}`);
    try {
      await safeFetch(`/api/admin/iceberg/mirror/${row.id}/routing`, {
        method: 'POST',
        body: JSON.stringify({ enabled, reason: enabled ? 'admin opt-in' : 'admin opt-out' }),
      });
      await loadAll();
    } catch (e: any) {
      alert(`Could not toggle routing: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const invalidate = useCallback(async (row: MirrorRow) => {
    if (!confirm(`Mark mirror ${row.id} for ${row.source_bucket}/${row.source_prefix} as stale?`)) return;
    setWorking(`inv-${row.id}`);
    try {
      await safeFetch(`/api/admin/iceberg/mirror/${row.id}/invalidate`, {
        method: 'POST',
        body: JSON.stringify({ reason: 'admin' }),
      });
      await loadAll();
    } catch (e: any) {
      alert(`Invalidate failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const hardDelete = useCallback(async (row: MirrorRow) => {
    if (!confirm(`HARD DELETE mirror ${row.id}? S3 files + DB row will be removed.`)) return;
    setWorking(`del-${row.id}`);
    try {
      await safeFetch(`/api/admin/iceberg/mirror/${row.id}?hard=true`, { method: 'DELETE' });
      await loadAll();
    } catch (e: any) {
      alert(`Delete failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const analyseColumnSort = useCallback(async (col: string) => {
    if (typeof buildConnId !== 'number' || !buildTable || !col) return;
    if (sortednessByCol[col]) return;  // already cached this column
    setAnalysingCol(col);
    try {
      const url = (
        `/api/admin/mirror/sort-analysis?connection_id=${buildConnId}` +
        `&table_name=${encodeURIComponent(buildTable)}` +
        `&column=${encodeURIComponent(col)}`
      );
      const resp = await safeFetch(url);
      setSortednessByCol((prev) => ({
        ...prev,
        [col]: {
          verdict:        resp.verdict ?? 'unknown',
          monotonic_pct:  resp.monotonic_pct ?? 0,
          recommendation: resp.recommendation ?? '',
        },
      }));
    } catch (e: any) {
      setSortednessByCol((prev) => ({
        ...prev,
        [col]: {
          verdict: 'unknown',
          monotonic_pct: 0,
          recommendation: `Analysis failed: ${e?.message ?? String(e)}`,
        },
      }));
    } finally {
      setAnalysingCol(null);
    }
  }, [buildConnId, buildTable, sortednessByCol]);

  const detectBuildPartitions = useCallback(async () => {
    if (typeof buildConnId !== 'number' || !buildTable) return;
    setDetectingPart(true);
    setBuildPartitionCols([]);
    setBuildPartitionColName('');
    setBuildPartitionValues([]);
    try {
      const url = (
        `/api/admin/iceberg/mirror/partition-detect?connection_id=` +
        `${buildConnId}&table_name=${encodeURIComponent(buildTable)}`
      );
      const resp: PartitionDetectResponse = await safeFetch(url);
      const cols = resp.columns ?? [];
      setBuildPartitionCols(cols);
      // Auto-pick the top (highest-coverage) column.  The detector
      // returns columns sorted by coverage desc, so cols[0] is the
      // most universal partition.  Operator then only picks values.
      if (cols.length > 0) {
        setBuildPartitionColName(cols[0].column);
      }
    } catch (e: any) {
      alert(`Partition detect failed: ${e?.message || String(e)}`);
    } finally {
      setDetectingPart(false);
    }
  }, [buildConnId, buildTable]);

  const triggerBuild = useCallback(async () => {
    if (typeof buildConnId !== 'number' || !buildTable) {
      alert('Please pick a connection and a registered iceberg table.');
      return;
    }
    setWorking('build');
    try {
      const body: any = {
        connection_id: buildConnId,
        table_name:    buildTable,
        force:         buildForce,
      };
      if (buildPartitionColName && buildPartitionValues.length > 0) {
        body.partition_filters = {
          [buildPartitionColName]: buildPartitionValues.length === 1
            ? buildPartitionValues[0]
            : buildPartitionValues,
        };
      }
      if (buildSortBy.length > 0) {
        body.sort_by = buildSortBy;
      }
      const r = await safeFetch('/api/admin/iceberg/mirror/build', {
        method: 'POST',
        timeoutMs: 600000,  // 10min — mirror builds can take a while
        body: JSON.stringify(body),
      });
      alert(`Build result: ${JSON.stringify(r ?? {}, null, 2).slice(0, 600)}`);
      setBuildDialogOpen(false);
      await loadAll();
    } catch (e: any) {
      alert(`Build failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [
    buildConnId, buildTable, buildForce,
    buildPartitionColName, buildPartitionValues, buildSortBy, loadAll,
  ]);

  const forceTick = useCallback(async () => {
    setWorking('tick');
    try {
      const r = await safeFetch('/api/admin/iceberg/mirror/tick', {
        method: 'POST', timeoutMs: 600000,
      });
      alert(`Tick result: ${JSON.stringify(r ?? {}, null, 2).slice(0, 600)}`);
      await loadAll();
    } catch (e: any) {
      alert(`Tick failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const forceCleanup = useCallback(async () => {
    setWorking('cleanup');
    try {
      const r = await safeFetch('/api/admin/iceberg/mirror/cleanup', {
        method: 'POST', body: JSON.stringify({}),
      });
      alert(`Cleanup: ${JSON.stringify(r ?? {}, null, 2)}`);
      await loadAll();
    } catch (e: any) {
      alert(`Cleanup failed: ${e?.message || String(e)}`);
    } finally {
      setWorking(null);
    }
  }, [loadAll]);

  const openDualRun = useCallback(async (row: MirrorRow) => {
    setDualRunDialog({ open: true, mirrorId: row.id, events: [] });
    try {
      const r = await safeFetch(`/api/admin/iceberg/mirror/${row.id}/dual-run?limit=200`);
      setDualRunDialog({ open: true, mirrorId: row.id, events: r?.events ?? [] });
    } catch (e: any) {
      setDualRunDialog({ open: true, mirrorId: row.id, events: [] });
    }
  }, []);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <StorageIcon fontSize="small" />
        <Typography variant="h6">Iceberg Mirror Status</Typography>
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<BuildIcon />} variant="contained" size="small"
                onClick={() => setBuildDialogOpen(true)} disabled={!!working}>
          Build mirror
        </Button>
        <Button startIcon={<PlayIcon />} variant="outlined" size="small"
                onClick={forceTick} disabled={!!working}>
          {working === 'tick' ? <CircularProgress size={14} /> : 'Run tick now'}
        </Button>
        <Button startIcon={<CleaningIcon />} variant="outlined" size="small"
                onClick={forceCleanup} disabled={!!working}>
          {working === 'cleanup' ? <CircularProgress size={14} /> : 'Cleanup stale'}
        </Button>
        <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                onClick={loadAll} disabled={loading}>
          {loading ? <CircularProgress size={14} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Brain pipeline status — single source of truth for "how is /
          will the brain function".  Each row shows whether the daemon
          is registered with APScheduler, whether the feature flag is
          on, where storage lives, and when the next tick fires. */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          <Typography variant="subtitle1">Brain pipeline status</Typography>
          {brain?.summary && (
            <>
              <Chip size="small" color="primary" variant="outlined"
                    label={`${brain.summary.enabled_count}/${brain.summary.total_components} enabled`} />
              <Chip size="small" color="success" variant="outlined"
                    label={`${brain.summary.registered_count}/${brain.summary.total_components} cron registered`} />
            </>
          )}
          <Box sx={{ flex: 1 }} />
          {brainLoading && <CircularProgress size={14} />}
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
          Every brain component below shares the same signal — the rolling{' '}
          <code>query_pruning_history</code> table.  When users query an iceberg
          table, that table&apos;s (bucket, prefix) and per-filter column usage are
          recorded.  Each daemon reads from that ring and pre-computes the
          structure (file min/max bounds, bloom sidecars, file-list rewrite,
          result cache) that future queries on the same shape will benefit from.
          All cron jobs auto-register on pod start so flipping the feature flag
          via config takes effect on the next tick — no restart needed.
        </Typography>
        {brain?.components && brain.components.length > 0 ? (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Component</TableCell>
                <TableCell>Purpose</TableCell>
                <TableCell>Storage</TableCell>
                <TableCell align="center">Enabled</TableCell>
                <TableCell align="center">Cron</TableCell>
                <TableCell>Next run</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {brain.components.map((c) => (
                <TableRow key={c.name}>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                    {c.name}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{c.purpose}</TableCell>
                  <TableCell sx={{ fontSize: 11, fontFamily: 'monospace' }}>
                    {c.storage}
                  </TableCell>
                  <TableCell align="center">
                    <Chip size="small"
                          color={c.enabled ? 'success' : 'default'}
                          variant={c.enabled ? 'filled' : 'outlined'}
                          label={c.enabled ? 'on' : 'off'} />
                  </TableCell>
                  <TableCell align="center">
                    {c.scheduler?.registered ? (
                      <Tooltip title={c.scheduler.trigger || 'interval'}>
                        <Chip size="small" color="primary" variant="outlined" label="registered" />
                      </Tooltip>
                    ) : (
                      <Tooltip title={c.scheduler?.error || 'No APScheduler job for this id'}>
                        <Chip size="small" color="warning" variant="outlined" label="missing" />
                      </Tooltip>
                    )}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>
                    {c.scheduler?.next_run_time
                      ? relativeAge(c.scheduler.next_run_time).replace(' ago', ' from now')
                      : '—'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <Alert severity="info">
            Brain status unavailable — admin endpoint may not be reachable.
          </Alert>
        )}
      </Paper>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          <b>What this does:</b> a mirror is a consolidated parquet rewrite of an
          iceberg snapshot, stored in the QS-internal bucket.  When the source
          has many small data files, routing to the mirror feeds DuckDB a much
          smaller file set with the same logical contents.
          {' '}
          <b>Routing is OFF by default</b> — Stage 1 ships SHADOW builds only.
          Flip <code>routing_enabled</code> per row after observing zero
          divergence in the Layer-3 canary log (the Compare icon).
          {' '}
          Master kill switches: <code>iceberg.mirror.enabled</code> (build),
          {' '}<code>iceberg.mirror.routing_enabled</code> (route).  Per-table
          mirrors auto-invalidate when the source snapshot rolls forward, then
          get cleaned up after <code>iceberg.mirror.stale_retention_days</code>
          {' '}(default 7).
        </Typography>
      </Paper>

      {/* Recent ticks */}
      {ticks.length > 0 && (
        <Accordion sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">
              Recent daemon ticks ({ticks.length})
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Started</TableCell>
                  <TableCell>Elapsed</TableCell>
                  <TableCell>Cleanup</TableCell>
                  <TableCell>Builds</TableCell>
                  <TableCell>Note</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {ticks.map((t, i) => (
                  <TableRow key={i}>
                    <TableCell>{relativeAge(t.started_at)}</TableCell>
                    <TableCell>{t.elapsed_seconds?.toFixed(2)}s</TableCell>
                    <TableCell>
                      {t.cleanup
                        ? `scanned=${t.cleanup.scanned ?? 0} del=${t.cleanup.deleted ?? 0}`
                        : '—'}
                    </TableCell>
                    <TableCell>
                      {t.builds
                        ? `considered=${t.builds.considered ?? 0} built=${t.builds.built ?? 0} skip=${t.builds.skipped ?? 0} err=${t.builds.errors ?? 0}`
                        : '—'}
                    </TableCell>
                    <TableCell>{t.skipped_reason || t.error || ''}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* Recent events */}
      {events.length > 0 && (
        <Accordion sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">
              Recent events ({events.length})
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Kind</TableCell>
                  <TableCell>Payload</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {events.slice(0, 30).map((e, i) => (
                  <TableRow key={i}>
                    <TableCell>{relativeAge(e.at)}</TableCell>
                    <TableCell>
                      <Chip size="small" label={e.kind} />
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {JSON.stringify({ ...e, at: undefined, kind: undefined }).slice(0, 200)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {/* Mirror rows */}
      {rows.length === 0 && !loading && !error && (
        <Alert severity="info" sx={{ mb: 2 }}>
          No mirrors built yet.  Mirror cron runs every{' '}
          <code>iceberg.mirror.cron_interval_hours</code> hours (default 6) and
          builds candidates ranked by last-168h query activity from{' '}
          <code>query_pruning_history</code>.  Until the first cron tick fires,
          the table below stays empty — use the Build button on any{' '}
          <b>eligible</b> Discoverable table to seed a row now.
        </Alert>
      )}

      {/* Discoverable tables — always shown so the page never reads as
          "empty / nothing to do".  Lists every registered iceberg table
          across active S3 connections, annotated with its current mirror
          state + last-168h query count.  Click "Build" to pre-fill the
          dialog from a row. */}
      <Paper sx={{ mb: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1}
               sx={{ p: 1.5, borderBottom: '1px solid #e5e7eb' }}>
          <Typography variant="subtitle1">Discoverable iceberg tables</Typography>
          {discoverable && (
            <>
              <Chip size="small" variant="outlined"
                    label={`${discoverable.total} registered`} />
              <Chip size="small" color="success" variant="outlined"
                    label={`${discoverable.ready_mirrors} mirrored`} />
              <Chip size="small" color="primary" variant="outlined"
                    label={`${discoverable.eligible_count} eligible to build`} />
            </>
          )}
          <Box sx={{ flex: 1 }} />
          {discoverLoading && <CircularProgress size={14} />}
        </Stack>
        {!discoverable || discoverable.tables.length === 0 ? (
          <Alert severity="info" variant="outlined" sx={{ m: 2 }}>
            No iceberg tables registered across active S3 connections.
            Add an S3 connection in Admin → Connections and register an
            iceberg-format table to seed this list.
          </Alert>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Connection</TableCell>
                <TableCell>Table name</TableCell>
                <TableCell>Bucket / prefix</TableCell>
                <TableCell align="right">Queries (168h)</TableCell>
                <TableCell>Mirror status</TableCell>
                <TableCell align="right">Mirror rows</TableCell>
                <TableCell align="right">Mirror files</TableCell>
                <TableCell align="center">Build</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {discoverable.tables.slice(0, 100).map((t) => (
                <TableRow key={`${t.connection_id}::${t.bucket}::${t.table_prefix}`} hover>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                    {t.connection_name}<br/>
                    <span style={{ color: '#666' }}>id={t.connection_id}</span>
                  </TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                    {t.table_name}
                  </TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                    {t.bucket}<br/>
                    <span style={{ color: '#666' }}>{t.table_prefix}</span>
                  </TableCell>
                  <TableCell align="right">
                    {t.queries_last_168h > 0
                      ? <Chip size="small" color="primary" variant="outlined"
                              label={t.queries_last_168h.toLocaleString()} />
                      : <span style={{ color: '#999' }}>0</span>}
                  </TableCell>
                  <TableCell>
                    {t.mirror_status ? (
                      <Chip size="small"
                            color={statusChipColor(t.mirror_status)}
                            label={t.mirror_status} />
                    ) : (
                      <Chip size="small" variant="outlined" label="no mirror" />
                    )}
                    {t.routing_enabled && (
                      <Chip size="small" color="success" variant="outlined"
                            label="routing on" sx={{ ml: 0.5 }} />
                    )}
                  </TableCell>
                  <TableCell align="right">
                    {t.mirror_row_count.toLocaleString()}
                  </TableCell>
                  <TableCell align="right">
                    {t.mirror_file_count.toLocaleString()}
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title={t.eligible_to_build
                      ? 'Pre-fills the Build dialog for this table.'
                      : 'A ready mirror already exists for the current snapshot.  Pass force=true in the dialog to rebuild.'}>
                      <span>
                        <Button size="small" variant="outlined"
                                disabled={!!working}
                                color={t.eligible_to_build ? 'primary' : 'inherit'}
                                onClick={() => buildFromDiscoverable(t)}>
                          Build
                        </Button>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Paper>

      {rows.length > 0 && (
        <Paper>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Source bucket / prefix</TableCell>
                <TableCell>Snapshot</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Source files</TableCell>
                <TableCell align="right">Mirror files</TableCell>
                <TableCell align="right">Mirror size</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell>Built</TableCell>
                <TableCell align="right">Routes</TableCell>
                <TableCell align="center">Routing</TableCell>
                <TableCell align="center">Dual-run</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                    {r.source_bucket}<br/>
                    <span style={{ color: '#666' }}>{r.source_prefix}</span>
                  </TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                    {r.source_snapshot_id?.slice(0, 14)}…
                  </TableCell>
                  <TableCell>
                    <Chip size="small" color={statusChipColor(r.status)} label={r.status} />
                    {r.last_error && (
                      <Tooltip title={r.last_error}>
                        <span style={{ marginLeft: 6, color: '#c00', cursor: 'help' }}>!</span>
                      </Tooltip>
                    )}
                  </TableCell>
                  <TableCell align="right">{r.source_file_count.toLocaleString()}</TableCell>
                  <TableCell align="right">{r.mirror_file_count.toLocaleString()}</TableCell>
                  <TableCell align="right">{fmtBytes(r.mirror_total_bytes)}</TableCell>
                  <TableCell align="right">{r.mirror_row_count.toLocaleString()}</TableCell>
                  <TableCell>{relativeAge(r.built_at)}</TableCell>
                  <TableCell align="right">{r.route_hit_count.toLocaleString()}</TableCell>
                  <TableCell align="center">
                    <Switch
                      size="small"
                      checked={r.routing_enabled}
                      disabled={r.status !== 'ready' || working === `route-${r.id}`}
                      onChange={(e) => setRouting(r, e.target.checked)}
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title={`samples=${r.dual_run_samples} diverged=${r.dual_run_divergences}`}>
                      <IconButton size="small" onClick={() => openDualRun(r)}>
                        <CompareIcon fontSize="small" color={r.dual_run_divergences > 0 ? 'error' : 'inherit'} />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title="Mark stale (files deleted by cleanup)">
                      <IconButton size="small" disabled={!!working}
                                  onClick={() => invalidate(r)}>
                        <BlockIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Hard delete (S3 + DB row)">
                      <IconButton size="small" disabled={!!working}
                                  onClick={() => hardDelete(r)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}

      {/* Build dialog */}
      <Dialog open={buildDialogOpen} onClose={() => setBuildDialogOpen(false)}
              maxWidth="sm" fullWidth>
        <DialogTitle>Build mirror</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Alert severity="info">
              Builds the mirror for the table&apos;s current iceberg snapshot.
              Streams via DuckDB COPY directly to the QS-internal bucket;
              honours Iceberg V2 merge-on-read semantics.  May take several
              minutes for tables with thousands of files.
            </Alert>
            <Autocomplete
              size="small"
              options={connections}
              getOptionLabel={(c) => `${c.name} (id=${c.id}, bucket=${c.config?.bucket_name || '?'})`}
              isOptionEqualToValue={(a, b) => a.id === b.id}
              value={connections.find((c) => c.id === buildConnId) || null}
              onChange={(_, v) => {
                setBuildConnId(v ? v.id : '');
                // Reset cascading dependent so we don't keep a stale name
                // bound to a different connection.
                setBuildTable('');
              }}
              renderInput={(params) => (
                <TextField {...params} label="S3 Iceberg connection" fullWidth />
              )}
              noOptionsText={
                connections.length === 0
                  ? 'No active S3 connections — add one in Admin → Connections'
                  : 'No match'
              }
            />
            <Autocomplete
              size="small"
              options={availableTables}
              disabled={typeof buildConnId !== 'number'}
              value={buildTable || null}
              onChange={(_, v) => setBuildTable(v || '')}
              renderInput={(params) => (
                <TextField {...params}
                  label={
                    typeof buildConnId !== 'number'
                      ? 'Registered iceberg table (pick a connection first)'
                      : `Registered iceberg table (${availableTables.length} available)`
                  }
                  fullWidth
                />
              )}
              noOptionsText={
                typeof buildConnId !== 'number'
                  ? 'Pick a connection first'
                  : 'This connection has no registered iceberg tables. Register one under Admin → Connections → S3 → Tables.'
              }
            />
            <FormControlLabel
              control={<Switch checked={buildForce}
                               onChange={(e) => setBuildForce(e.target.checked)} />}
              label="Force rebuild (ignore any existing ready mirror for this snapshot)"
            />

            {/* Phase 151 follow-up — partition picker.  Lets operators
                exclude today's still-evolving partition (e.g. mirror
                only yesterday + earlier business_date values).  Empty
                column → full-table build (legacy behaviour). */}
            <Box sx={{ pt: 1, borderTop: '1px dashed #ccc' }}>
              <Stack direction="row" spacing={1} alignItems="center"
                     sx={{ mb: 1 }}>
                <Typography variant="subtitle2" sx={{ flex: 1 }}>
                  Partition scope (optional)
                </Typography>
                <Button
                  size="small" variant="outlined"
                  startIcon={detectingPart
                    ? <CircularProgress size={14} color="inherit" />
                    : null}
                  onClick={detectBuildPartitions}
                  disabled={
                    typeof buildConnId !== 'number'
                    || !buildTable || detectingPart
                  }
                >
                  Detect top partitions
                </Button>
              </Stack>
              <Alert severity="info" sx={{ mb: 1 }}>
                Mirror only a slice of the table.  The source-file cap
                (<code>iceberg.mirror.max_build_source_files</code>)
                applies to the FILTERED count, so a huge table can
                still build per-partition mirrors.  After Detect, the
                top-coverage column is auto-picked; choose values to
                INCLUDE.  Empty column = full table.
              </Alert>
              <Autocomplete
                size="small"
                options={buildPartitionCols.map((c) => c.column)}
                value={buildPartitionColName || null}
                onChange={(_, v) => {
                  setBuildPartitionColName(v || '');
                  setBuildPartitionValues([]);
                }}
                renderInput={(params) => (
                  <TextField {...params}
                    label="Partition column (top auto-picked)"
                    helperText={(() => {
                      const c = buildPartitionCols.find(
                        (x) => x.column === buildPartitionColName,
                      );
                      return c
                        ? (`coverage ${c.coverage_pct}% · ` +
                           `${c.distinct_value_count} distinct values`)
                        : 'Click "Detect top partitions" first';
                    })()}
                    fullWidth
                  />
                )}
                disabled={buildPartitionCols.length === 0}
              />
              <Autocomplete
                multiple freeSolo
                size="small"
                options={(
                  buildPartitionCols.find(
                    (c) => c.column === buildPartitionColName,
                  )?.distinct_values_sample ?? []
                )}
                value={buildPartitionValues}
                onChange={(_, v) => setBuildPartitionValues(v as string[])}
                disabled={!buildPartitionColName}
                renderInput={(params) => (
                  <TextField {...params}
                    label="Partition value(s) to INCLUDE"
                    helperText={(() => {
                      const c = buildPartitionCols.find(
                        (x) => x.column === buildPartitionColName,
                      );
                      const sample = c?.distinct_values_sample ?? [];
                      return (
                        'Pick from detected samples or type any value. ' +
                        'Leave blank to skip partition scoping. ' +
                        (sample.length > 0
                          ? `Sample values: ${sample.slice(0, 3).join(', ')}${sample.length > 3 ? '…' : ''}`
                          : '')
                      );
                    })()}
                    fullWidth
                  />
                )}
                sx={{ mt: 1 }}
              />
              <Autocomplete
                multiple freeSolo
                size="small"
                options={[]}
                value={buildSortBy}
                onChange={(_, v) => {
                  const cols = v as string[];
                  setBuildSortBy(cols);
                  // Fire analysis for the newly added column
                  cols.forEach((c) => {
                    if (c && !sortednessByCol[c]) analyseColumnSort(c);
                  });
                }}
                renderInput={(params) => (
                  <TextField {...params}
                    label="Sort by column(s) — optional"
                    helperText={
                      'Type the columns your queries filter on most. ' +
                      'DuckDB writes parquet row-groups in this order so ' +
                      'tight min/max bounds let WHERE filters skip whole ' +
                      'row-groups at read time.  Same data, just laid out ' +
                      'for the actual query pattern.  Brain checks if the ' +
                      "column is ALREADY sorted in source — if so, mirror's " +
                      'sort_by adds little.'
                    }
                    fullWidth
                  />
                )}
                sx={{ mt: 1 }}
              />
              {/* Sortedness chips for each picked sort_by column */}
              {buildSortBy.length > 0 && (
                <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mt: 1 }}>
                  {buildSortBy.map((c) => {
                    const r = sortednessByCol[c];
                    if (!r) {
                      return (
                        <Chip key={c} size="small" variant="outlined"
                              label={
                                analysingCol === c
                                  ? `${c}: analysing…`
                                  : `${c}: not yet analysed`
                              } />
                      );
                    }
                    const color =
                      r.verdict === 'sorted' ? 'warning' :
                      r.verdict === 'unsorted' ? 'success' :
                      r.verdict === 'partially_sorted' ? 'info' :
                      'default';
                    const label =
                      r.verdict === 'sorted'
                        ? `${c}: already sorted in source (${r.monotonic_pct}%) — mirror sort_by may not help`
                      : r.verdict === 'unsorted'
                        ? `${c}: UNSORTED in source (${r.monotonic_pct}%) — sort_by would unlock skipping`
                      : r.verdict === 'partially_sorted'
                        ? `${c}: partially sorted (${r.monotonic_pct}%) — mixed signal`
                      : `${c}: ${r.verdict}`;
                    return (
                      <Tooltip key={c} title={r.recommendation || ''}>
                        <Chip size="small" color={color} label={label} />
                      </Tooltip>
                    );
                  })}
                </Stack>
              )}
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBuildDialogOpen(false)}>Cancel</Button>
          <Button onClick={triggerBuild} variant="contained" disabled={working === 'build'}>
            {working === 'build' ? <CircularProgress size={16} /> : 'Build'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dual-run dialog */}
      <Dialog open={dualRunDialog.open}
              onClose={() => setDualRunDialog({ open: false, mirrorId: null, events: [] })}
              maxWidth="md" fullWidth>
        <DialogTitle>Layer-3 dual-run canary — mirror {dualRunDialog.mirrorId}</DialogTitle>
        <DialogContent>
          {dualRunDialog.events.length === 0 ? (
            <Alert severity="info">
              No samples yet.  The canary fires on a random
              {' '}<code>iceberg.mirror.dual_run_canary_percent</code>%
              {' '}of routed queries.
            </Alert>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Diverged?</TableCell>
                  <TableCell align="right">Source rows</TableCell>
                  <TableCell align="right">Mirror rows</TableCell>
                  <TableCell>Query signature</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {dualRunDialog.events.map((ev) => (
                  <TableRow key={ev.id}>
                    <TableCell>{relativeAge(ev.occurred_at)}</TableCell>
                    <TableCell>
                      <Chip size="small"
                            color={ev.diverged ? 'error' : 'success'}
                            label={ev.diverged ? 'DIVERGED' : 'match'} />
                    </TableCell>
                    <TableCell align="right">{ev.source_row_count.toLocaleString()}</TableCell>
                    <TableCell align="right">{ev.mirror_row_count.toLocaleString()}</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {ev.query_signature || '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDualRunDialog({ open: false, mirrorId: null, events: [] })}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};


export default IcebergMirrorStatusSection;
