/**
 * Phase 139 (Tier 2.3) — Cache Telemetry admin panel.
 *
 * Shows real-time hit/miss/eviction stats for every LocalCache layer
 * (result, base_data, file_listing, schema, partition, etc.). Backed by
 * /api/admin/cache/layer-stats which returns the per-cache CacheStats from
 * core.cache_layer.get_all_cache_stats().
 *
 * Two views:
 *   - Per-layer hit-rate table (sortable by hit rate, size, evictions)
 *   - Recent misses ring buffer (helps spot trivial-whitespace patterns)
 */
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Box, Typography, Paper, Button, Alert, Chip, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  LinearProgress, Tooltip, IconButton,
} from '@mui/material';
import {
  Cached as CachedIcon, Refresh as RefreshIcon,
  History as HistoryIcon, TrendingUp as TrendIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';

interface CacheStats {
  name: string;
  hits: number;
  misses: number;
  sets: number;
  deletes: number;
  evictions: number;
  size: number;
  max_entries: number;
  ttl_seconds: number;
  hit_rate: number;
}

interface RecentMiss {
  layer: string;
  key: string;
  username?: string;
  ts: string;  // ISO timestamp
}

const fmtPct = (n: number) => `${(n * 100).toFixed(1)}%`;
const fmtNum = (n: number) => n.toLocaleString();

const hitRateColor = (rate: number, totalLookups: number): 'success' | 'warning' | 'error' | 'default' => {
  if (totalLookups < 10) return 'default';  // not enough signal
  if (rate >= 0.7) return 'success';
  if (rate >= 0.4) return 'warning';
  return 'error';
};

const CacheTelemetrySection: React.FC = () => {
  const [stats, setStats] = useState<CacheStats[]>([]);
  const [misses, setMisses] = useState<RecentMiss[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const loadStats = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data: any = await safeFetch('/api/admin/cache/layer-stats');
      const _caches: CacheStats[] = toArray<CacheStats>(data, 'caches');  // BF-430E
      setStats(_caches.sort((a, b) => (b.hits + b.misses) - (a.hits + a.misses)));
      setLastRefresh(new Date());
    } catch (e: any) {
      setError(e?.message || 'Failed to load cache stats');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadRecentMisses = useCallback(async () => {
    try {
      const data: any = await safeFetch('/api/admin/cache/recent-misses');
      const _misses: RecentMiss[] = toArray<RecentMiss>(data, 'misses');  // BF-430E
      setMisses(_misses);
    } catch {
      // recent-misses endpoint may not be available — silent
    }
  }, []);

  useEffect(() => {
    loadStats();
    loadRecentMisses();
  }, [loadStats, loadRecentMisses]);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(() => {
      loadStats();
      loadRecentMisses();
    }, 5000);
    return () => clearInterval(id);
  }, [autoRefresh, loadStats, loadRecentMisses]);

  const totals = useMemo(() => {
    let hits = 0, misses = 0, evictions = 0, size = 0;
    for (const s of stats) {
      hits += s.hits; misses += s.misses; evictions += s.evictions; size += s.size;
    }
    const total = hits + misses;
    return { hits, misses, evictions, size, hitRate: total > 0 ? hits / total : 0 };
  }, [stats]);

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
        <CachedIcon color="primary" />
        <Typography variant="h6" sx={{ flexGrow: 1 }}>Cache Telemetry</Typography>
        <Tooltip title={autoRefresh ? 'Pause auto-refresh' : 'Resume auto-refresh (5s)'}>
          <Button
            size="small"
            variant={autoRefresh ? 'contained' : 'outlined'}
            onClick={() => setAutoRefresh(v => !v)}
          >
            {autoRefresh ? 'Live' : 'Paused'}
          </Button>
        </Tooltip>
        <IconButton size="small" onClick={() => { loadStats(); loadRecentMisses(); }} disabled={loading}>
          <RefreshIcon />
        </IconButton>
      </Stack>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>
      )}

      {/* Aggregate hit rate across all layers */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" spacing={3} alignItems="center" flexWrap="wrap">
          <Box>
            <Typography variant="caption" color="text.secondary">Aggregate hit rate</Typography>
            <Stack direction="row" alignItems="baseline" spacing={1}>
              <Typography variant="h4" sx={{ fontWeight: 700,
                color: totals.hitRate >= 0.5 ? 'success.main' :
                       totals.hitRate >= 0.25 ? 'warning.main' : 'error.main' }}>
                {fmtPct(totals.hitRate)}
              </Typography>
              <TrendIcon fontSize="small" color="action" />
            </Stack>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Total lookups</Typography>
            <Typography variant="h6">{fmtNum(totals.hits + totals.misses)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Hits</Typography>
            <Typography variant="h6" color="success.main">{fmtNum(totals.hits)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Misses</Typography>
            <Typography variant="h6" color="warning.main">{fmtNum(totals.misses)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Total entries</Typography>
            <Typography variant="h6">{fmtNum(totals.size)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Evictions</Typography>
            <Typography variant="h6" color="error.main">{fmtNum(totals.evictions)}</Typography>
          </Box>
        </Stack>
        {lastRefresh && (
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
            Last updated: {lastRefresh.toLocaleTimeString()}
          </Typography>
        )}
      </Paper>

      {/* Per-layer table */}
      <Paper variant="outlined" sx={{ mb: 2 }}>
        <Typography variant="subtitle2" sx={{ p: 1.5, borderBottom: '1px solid', borderColor: 'divider' }}>
          Per-layer breakdown
        </Typography>
        {loading && <LinearProgress />}
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Layer</TableCell>
                <TableCell align="right">Hit rate</TableCell>
                <TableCell align="right">Hits</TableCell>
                <TableCell align="right">Misses</TableCell>
                <TableCell align="right">Sets</TableCell>
                <TableCell align="right">Entries</TableCell>
                <TableCell align="right">Max</TableCell>
                <TableCell align="right">Evictions</TableCell>
                <TableCell align="right">TTL (s)</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {stats.length === 0 && !loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ color: 'text.secondary' }}>
                    No cache layers registered yet — metrics appear after the first lookup.
                  </TableCell>
                </TableRow>
              ) : stats.map(s => {
                const total = s.hits + s.misses;
                return (
                  <TableRow key={s.name} hover data-cache-row={s.name}>
                    <TableCell><code style={{ fontSize: 12 }}>{s.name}</code></TableCell>
                    <TableCell align="right">
                      <Chip
                        size="small"
                        label={total > 0 ? fmtPct(s.hit_rate) : '—'}
                        color={hitRateColor(s.hit_rate, total)}
                        sx={{ fontWeight: 600, minWidth: 56 }}
                      />
                    </TableCell>
                    <TableCell align="right">{fmtNum(s.hits)}</TableCell>
                    <TableCell align="right">{fmtNum(s.misses)}</TableCell>
                    <TableCell align="right">{fmtNum(s.sets)}</TableCell>
                    <TableCell align="right">{fmtNum(s.size)}</TableCell>
                    <TableCell align="right" sx={{ color: 'text.secondary' }}>
                      {s.max_entries === 0 ? '∞' : fmtNum(s.max_entries)}
                    </TableCell>
                    <TableCell align="right">{fmtNum(s.evictions)}</TableCell>
                    <TableCell align="right" sx={{ color: 'text.secondary' }}>
                      {s.ttl_seconds === 0 ? '∞' : s.ttl_seconds}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Recent misses */}
      {misses.length > 0 && (
        <Paper variant="outlined">
          <Stack direction="row" alignItems="center" spacing={1} sx={{
            p: 1.5, borderBottom: '1px solid', borderColor: 'divider'
          }}>
            <HistoryIcon fontSize="small" />
            <Typography variant="subtitle2">Recent cache misses</Typography>
            <Chip size="small" label={`${misses.length} entries`} variant="outlined" />
            <Box sx={{ flexGrow: 1 }} />
            <Typography variant="caption" color="text.secondary">
              Look for trivial-whitespace or near-duplicate keys — those are wasted misses.
            </Typography>
          </Stack>
          <TableContainer sx={{ maxHeight: 400 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Layer</TableCell>
                  <TableCell>User</TableCell>
                  <TableCell>Cache key (truncated)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {misses.map((m, idx) => (
                  <TableRow key={`${m.ts}-${idx}`} hover>
                    <TableCell sx={{ whiteSpace: 'nowrap', fontSize: 11 }}>
                      {new Date(m.ts).toLocaleTimeString()}
                    </TableCell>
                    <TableCell><code style={{ fontSize: 11 }}>{m.layer}</code></TableCell>
                    <TableCell>{m.username || '—'}</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11,
                                     maxWidth: 600, overflow: 'hidden', textOverflow: 'ellipsis',
                                     whiteSpace: 'nowrap' }}>
                      {m.key}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}
    </Box>
  );
};

export default CacheTelemetrySection;
