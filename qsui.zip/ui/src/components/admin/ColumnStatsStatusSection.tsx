/**
 * Column-Stats Status — admin UI (2026-06-03).
 *
 * Lists every (bucket, table_prefix, snapshot_id) tuple that has at
 * least one row in iceberg_column_stats_supplement_v2, with counts +
 * freshness, so admins can answer:
 *   * Which tables have supplement coverage?
 *   * When was the last scan?
 *   * How many files / columns are covered?
 *   * Is the running scan actually making progress (vs the silent
 *     "done with 0/3030 files scanned" symptom the user reported)?
 *
 * Reads /api/admin/iceberg/column-stats/status (GET).
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, TextField,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as PlayIcon,
  Storage as StorageIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface StatusRow {
  bucket:             string;
  table_prefix:       string;
  snapshot_id:        string;
  // 2026-06-04 — fast endpoint returns null for file/column counts
  // (only the row count is computed in the cheap path).  UI must
  // distinguish "not computed (—)" from "actually zero (0)".
  file_count:         number | null;
  column_count:       number | null;
  row_count:          number;
  last_scanned_at:    string | null;
  last_connection_id: number | null;
  last_table_name:    string | null;
}


const relativeAge = (iso: string | null): string => {
  if (!iso) return '—';
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < 0) return iso;
  const s = Math.round(ms / 1000);
  if (s < 60)        return `${s}s ago`;
  if (s < 3600)      return `${Math.round(s / 60)}m ago`;
  if (s < 86400)     return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
};


const ageSeverity = (iso: string | null): 'success' | 'warning' | 'error' => {
  if (!iso) return 'error';
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < 3600 * 1000)        return 'success';   // < 1h fresh
  if (ms < 24 * 3600 * 1000)   return 'warning';   // < 1d stale-ish
  return 'error';                                    // > 1d stale
};


const ColumnStatsStatusSection: React.FC = () => {
  const [rows, setRows] = useState<StatusRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      // 2026-06-03 — the live /column-stats/status endpoint returns
      // {rows, _cache_age_seconds, _status}.  Old duplicate handler
      // returned {entries, total_entries} and got removed; previous
      // frontend kept reading `entries` → always empty array → user
      // saw "no supplement rows yet" even when supplement was full.
      // 2026-06-04 — call with include_distinct_counts=true so the user
      // sees the actual file + column counts in the table instead of
      // always-zero ("today's date but column=0 file=0 rows=0").
      // The cost is 5-30s on a 13M-row supplement; cached by the
      // backend for 30s so cumulative impact under polling is bounded.
      const r = await safeFetch('/api/admin/iceberg/column-stats/status?include_distinct_counts=true', {
        timeoutMs: 60000,   // give the slow-path a wider budget
      });
      const list = r?.rows ?? r?.entries ?? [];
      // Map the live endpoint's row shape into the table-expected shape.
      // Use ?? to preserve null/undefined (NOT a bare ||) so the UI can
      // distinguish "not yet computed" (null) from "actually zero" (0).
      setRows(list.map((row: any) => ({
        bucket:             row.bucket ?? '',
        table_prefix:       row.table_prefix ?? '',
        snapshot_id:        row.snapshot_id ?? '',
        file_count:         row.files ?? row.file_count ?? null,
        column_count:       row.columns ?? row.column_count ?? null,
        row_count:          row.rows ?? row.row_count ?? 0,
        last_scanned_at:    row.last_scanned ?? row.last_scanned_at ?? null,
        last_connection_id: row.last_connection_id ?? row.connection_id ?? null,
        last_table_name:    row.last_table_name ?? row.table_name ?? null,
      })));
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const triggerRescan = useCallback(async (row: StatusRow) => {
    if (!row.last_connection_id || !row.last_table_name) {
      alert('Cannot rescan: this supplement row has no connection/table telemetry.  Trigger from Admin → Iceberg Metadata Sync instead.');
      return;
    }
    const key = `${row.bucket}/${row.table_prefix}`;
    setScanning(key);
    try {
      const r = await safeFetch('/api/admin/iceberg/column-stats/scan', {
        method: 'POST',
        body: JSON.stringify({
          connection_id: row.last_connection_id,
          table_name:    row.last_table_name,
          force:         true,
        }),
      });
      alert(`Scan triggered: ${JSON.stringify(r ?? {}, null, 2).slice(0, 400)}`);
      await load();
    } catch (e: any) {
      alert(`Rescan failed: ${e?.message || String(e)}`);
    } finally {
      setScanning(null);
    }
  }, [load]);

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <StorageIcon fontSize="small" />
        <Typography variant="h6">Column Stats — Supplement Status</Typography>
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<RefreshIcon />} onClick={load} disabled={loading}
                variant="outlined" size="small">
          {loading ? <CircularProgress size={16} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          Rows from <code>iceberg_column_stats_supplement_v2</code> — populated
          by the background sync (<code>iceberg.column_stats_sync_enabled</code>)
          OR by manual <code>POST /api/admin/iceberg/column-stats/scan</code>.
          When the table is empty for an iceberg query you're filtering on,
          BQB falls back to manifest-only bounds — if the iceberg writer
          didn't track bounds for your filter column, the query scans every
          file in the snapshot.  Trigger a manual scan with the Rescan
          button below.
        </Typography>
      </Paper>

      {rows.length === 0 && !loading && !error && (
        <Alert severity="warning">
          No supplement rows yet.  Either the supplement is disabled
          (<code>iceberg.column_stats_sync_enabled</code> defaults false),
          OR no scans have completed successfully (check
          Admin → Background Jobs → iceberg_metadata_sync state, OR
          POST <code>/api/admin/iceberg/column-stats/scan</code> with a
          specific table to populate it).
        </Alert>
      )}

      {rows.length > 0 && (
        <Paper>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Bucket / Prefix</TableCell>
                <TableCell>Table (last)</TableCell>
                <TableCell>Snapshot</TableCell>
                <TableCell align="right">Files</TableCell>
                <TableCell align="right">Cols</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell>Last scan</TableCell>
                <TableCell align="right">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((r, i) => (
                <TableRow key={i}>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                    {r.bucket}<br/>
                    <span style={{ color: '#666' }}>{r.table_prefix}</span>
                  </TableCell>
                  <TableCell>{r.last_table_name || '—'}</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                    {r.snapshot_id?.slice(0, 12)}…
                  </TableCell>
                  <TableCell align="right">{r.file_count === null ? '—' : r.file_count.toLocaleString()}</TableCell>
                  <TableCell align="right">{r.column_count === null ? '—' : r.column_count}</TableCell>
                  <TableCell align="right">{r.row_count.toLocaleString()}</TableCell>
                  <TableCell>
                    <Chip size="small"
                          label={relativeAge(r.last_scanned_at)}
                          color={ageSeverity(r.last_scanned_at)}
                          variant="outlined" />
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="Force a fresh scan for this snapshot (writes new rows, replaces existing)">
                      <span>
                        <IconButton size="small"
                                    disabled={scanning !== null
                                              || !r.last_connection_id
                                              || !r.last_table_name}
                                    onClick={() => triggerRescan(r)}>
                          {scanning === `${r.bucket}/${r.table_prefix}`
                            ? <CircularProgress size={16} />
                            : <PlayIcon fontSize="small" />}
                        </IconButton>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}
    </Box>
  );
};

export default ColumnStatsStatusSection;
