/**
 * System Health monitoring section — extracted from AdminPage.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Alert, LinearProgress,
  Stack, Chip, Button, Divider,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Warning as WarnIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import StatCard from './StatCard';
import StatusChip from './StatusChip';

const SystemHealthSection: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [health, setHealth] = useState<any>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [circuitBreakers, setCircuitBreakers] = useState<any[]>([]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await safeFetch('/health');
      setHealth(data);
      setHealthError(null);
    } catch (e: any) {
      setHealthError(e.message);
    } finally { setLoading(false); }

    try {
      const cbData = await safeFetch('/api/admin/circuit-breakers');
      // BF-428P — toArray helper normalises any of:
      //   array | {circuit_breakers: [...]} | {circuit_breakers: {id: {...}}}
      // into a flat list so the .map() below never crashes.
      setCircuitBreakers(toArray<any>(cbData, {
        key: 'circuit_breakers',
        mapValueObjects: true,
      }));
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  useEffect(() => {
    const t = setInterval(loadData, 15_000);
    return () => clearInterval(t);
  }, [loadData]);

  const totalActive = health?.queries?.active ?? 0;

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {healthError && (
        <Alert severity="error" sx={{ mb: 2 }} action={
          <Button size="small" onClick={loadData}>Retry</Button>
        }>
          Failed to load health data: {healthError}
        </Alert>
      )}
      {!loading && !health && !healthError && (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <Typography color="text.secondary">No health data — click Refresh to load.</Typography>
          <Button size="small" startIcon={<RefreshIcon />} onClick={loadData} sx={{ mt: 1 }}>
            Refresh
          </Button>
        </Box>
      )}
      {health && (
        <>
          <Stack direction="row" spacing={1} mb={2} flexWrap="wrap" useFlexGap>
            <StatusChip ok={health.status === 'healthy'} label={health.status?.toUpperCase()} />
            <StatusChip ok={health.database?.ok} label={`DB: ${health.database?.ok ? 'OK' : 'Error'}`} />
            <StatusChip ok={health.s3?.status === 'connected'} label={`S3: ${health.s3?.status || 'n/a'}`} />
            {health.disk?.warning && <Chip size="small" icon={<WarnIcon />} label="Low Disk" color="warning" />}
          </Stack>
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Active Queries" value={health.queries?.active ?? totalActive}
              warn={(health.queries?.active ?? totalActive) >= (health.queries?.max_concurrent_global ?? 99)} />
            <StatCard label="Global Limit" value={health.queries?.max_concurrent_global ?? '—'} />
            <StatCard label="Per-User Limit" value={health.queries?.per_user_limit ?? '—'} />
            <StatCard label="Queue Waiting" value={health.queries?.queue_waiting ?? 0}
              warn={(health.queries?.queue_waiting ?? 0) > 0} />
            <StatCard label="Disk Free"
              value={`${health.disk?.free_gb ?? '—'} GB`}
              warn={health.disk?.warning}
              sub={`${health.disk?.used_pct ?? '—'}% used`} />
          </Stack>
          <Divider sx={{ my: 2 }} />
          <Typography variant="h6" sx={{ mb: 1 }}>Connection Health</Typography>
          {(!Array.isArray(circuitBreakers) || circuitBreakers.length === 0) ? (
            <Typography variant="body2" color="text.secondary">No circuit breaker data yet</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {circuitBreakers.map((cb: any) => (
                <Chip
                  key={cb.connection_id}
                  label={`${cb.connection_name || `Conn #${cb.connection_id}`}: ${cb.state}`}
                  size="small"
                  color={cb.state === 'closed' ? 'success' : cb.state === 'open' ? 'error' : 'warning'}
                  variant="outlined"
                />
              ))}
            </Box>
          )}
        </>
      )}
    </Paper>
  );
};

export default SystemHealthSection;
