/**
 * Feed Backend Failover — Admin Section
 *
 * Phase 130 hotfix-13.  Surfaces the global feed backend override,
 * Airflow + native worker health probes, circuit breaker states, and
 * the failover agent's auto-flip thresholds.  Every value is DB-driven
 * via /api/admin/feed-generation/* — no hardcoded constants in this
 * component.
 *
 * Failure modes covered:
 *   - Airflow down       -> set override = native_only
 *   - Native worker down -> set override = airflow_only
 *   - Both down          -> set override = halt
 *   - Maintenance window -> admin sets halt manually
 *
 * Per-execution rerun-via-X is handled on the dashboard row UI, not here.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Divider,
  Grid,
  MenuItem,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import PauseCircleIcon from '@mui/icons-material/PauseCircle';
import RefreshIcon from '@mui/icons-material/Refresh';
import SaveIcon from '@mui/icons-material/Save';
import { safeFetch } from '../../services/api/core';

// ── Types ─────────────────────────────────────────────────────────────────────

type OverrideValue = 'auto' | 'native_only' | 'airflow_only' | 'halt';

interface PersistedMeta {
  key:         string;
  value:       unknown;
  description: string | null;
  updated_by:  string | null;
  updated_at:  string | null;
}

interface OverrideResponse {
  value:        string;
  valid_values: OverrideValue[];
  persisted:    PersistedMeta | null;
}

interface ProbeResult {
  backend:    string;
  healthy:    boolean;
  detail:     string;
  checked_at: string;
  extras?:    Record<string, unknown>;
}

interface BreakerState {
  name:      string;
  state:     string;
  failures:  number;
  threshold: number;
  cooldown:  number;
}

interface HealthSnapshot {
  checked_at: string;
  override: {
    value:                       string;
    airflow_failover_to_native:  boolean;
  };
  probes: {
    checked_at: string;
    airflow:    ProbeResult;
    native:     ProbeResult;
  };
  circuit_breakers: BreakerState[];
  agent?: {
    agent_enabled:               boolean;
    interval_seconds:            number;
    unhealthy_streak_required:   number;
    healthy_streak_required:     number;
    current_override:            string;
    streaks: {
      airflow_unhealthy: number;
      airflow_healthy:   number;
      native_unhealthy:  number;
      native_healthy:    number;
    };
    last_snapshot:   Record<string, unknown>;
    error?:          string;
  };
}

interface Tunable {
  key:             string;
  type:            'bool' | 'int' | string;
  effective_value: unknown;
  persisted:       PersistedMeta | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const OVERRIDE_DESCRIPTIONS: Record<OverrideValue, string> = {
  auto:           'Honour per-feed setting + size-based routing (default).',
  native_only:    'Force every feed onto the native DuckDB worker. Use when Airflow is down.',
  airflow_only:   'Force every feed onto Airflow / Spark. Use when the native worker is degraded.',
  halt:           'Block all new feed executions. Pending rows wait; nothing fires until you flip the override back.',
};

const PROBE_BADGE = (healthy: boolean, detail: string): React.ReactElement => {
  if (healthy) {
    return (
      <Chip icon={<CheckCircleIcon />} label={`Healthy — ${detail}`}
            color="success" size="small" variant="outlined" />
    );
  }
  if (detail === 'integration_disabled' || detail === 'queue_worker_disabled') {
    return (
      <Chip icon={<PauseCircleIcon />} label={`Not configured — ${detail}`}
            color="default" size="small" variant="outlined" />
    );
  }
  return (
    <Chip icon={<ErrorIcon />} label={`Down — ${detail}`}
          color="error" size="small" variant="outlined" />
  );
};

const BREAKER_BADGE = (state: string): React.ReactElement => {
  const color = state === 'closed' ? 'success' : state === 'open' ? 'error' : 'warning';
  return <Chip label={state} color={color} size="small" />;
};

// ── Component ─────────────────────────────────────────────────────────────────

export const FeedFailoverSection: React.FC = () => {
  const [override, setOverride]       = useState<OverrideResponse | null>(null);
  const [health, setHealth]           = useState<HealthSnapshot | null>(null);
  const [tunables, setTunables]       = useState<Tunable[]>([]);
  const [draftOverride, setDraftOverride] = useState<OverrideValue>('auto');
  const [draftTunables, setDraftTunables] = useState<Record<string, string>>({});
  const [loading, setLoading]         = useState(false);
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState<string | null>(null);
  const [success, setSuccess]         = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [ov, hl, tn] = await Promise.all([
        safeFetch('/api/admin/feed-generation/backend-override') as Promise<OverrideResponse>,
        safeFetch('/api/admin/feed-generation/health') as Promise<HealthSnapshot>,
        safeFetch('/api/admin/feed-generation/failover-tunables') as Promise<{ items: Tunable[] }>,
      ]);
      setOverride(ov);
      setHealth(hl);
      setTunables(tn.items);
      setDraftOverride((ov.value as OverrideValue) || 'auto');
      // Seed tunable drafts from effective values so the inputs show
      // the current state on first render.
      const seed: Record<string, string> = {};
      for (const t of tn.items) {
        // Booleans render as "True"/"False" so the Select options match.
        if (t.type === 'bool') {
          seed[t.key] = t.effective_value ? 'True' : 'False';
        } else if (t.type === 'list') {
          // Lists serialise as a JSON array so the user can edit a
          // multi-line representation safely.
          seed[t.key] = JSON.stringify(t.effective_value ?? [], null, 0);
        } else {
          seed[t.key] = String(t.effective_value);
        }
      }
      setDraftTunables(seed);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAll();
    const id = setInterval(() => { void loadAll(); }, 15_000);
    return () => clearInterval(id);
  }, [loadAll]);

  const saveOverride = useCallback(async () => {
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      await safeFetch('/api/admin/feed-generation/backend-override', {
        method: 'POST',
        body:   JSON.stringify({ value: draftOverride }),
      });
      setSuccess(`Backend override set to "${draftOverride}".`);
      await loadAll();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  }, [draftOverride, loadAll]);

  const saveTunable = useCallback(async (key: string) => {
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const raw = draftTunables[key];
      // The backend coerces via the registered type (bool/int) — we
      // pass the raw string and let the server validate.
      await safeFetch('/api/admin/feed-generation/failover-tunables', {
        method: 'PUT',
        body:   JSON.stringify({ key, value: raw }),
      });
      setSuccess(`Saved ${key.split('.').pop()} = ${raw}.`);
      await loadAll();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  }, [draftTunables, loadAll]);

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <Paper sx={{ p: 3 }} elevation={1}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <Box>
          <Typography variant="h6">Feed Backend Failover</Typography>
          <Typography variant="body2" color="text.secondary">
            Switch all feeds between the native worker and Airflow when one side is unhealthy.
            Settings here are stored in the database and apply to every pod within 5 seconds.
          </Typography>
        </Box>
        <Button startIcon={<RefreshIcon />} onClick={() => void loadAll()} disabled={loading}>
          Refresh
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      {loading && !health && (
        <Box display="flex" justifyContent="center" py={4}><CircularProgress /></Box>
      )}

      {health && (
        <Grid container spacing={3}>
          {/* ── Health panel ──────────────────────────────────────────────── */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Typography variant="subtitle2" gutterBottom>Backend health</Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Backend</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>Airflow</TableCell>
                  <TableCell>{PROBE_BADGE(health.probes.airflow.healthy, health.probes.airflow.detail)}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Native worker</TableCell>
                  <TableCell>{PROBE_BADGE(health.probes.native.healthy, health.probes.native.detail)}</TableCell>
                </TableRow>
              </TableBody>
            </Table>

            <Box mt={2}>
              <Typography variant="subtitle2" gutterBottom>Circuit breakers</Typography>
              {health.circuit_breakers.length === 0 ? (
                <Typography variant="body2" color="text.secondary">No breakers registered.</Typography>
              ) : (
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>State</TableCell>
                      <TableCell>Failures</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {health.circuit_breakers.map((b) => (
                      <TableRow key={b.name}>
                        <TableCell>{b.name}</TableCell>
                        <TableCell>{BREAKER_BADGE(b.state)}</TableCell>
                        <TableCell>{b.failures} / {b.threshold}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </Box>
          </Grid>

          {/* ── Override control ──────────────────────────────────────────── */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Typography variant="subtitle2" gutterBottom>Global backend override</Typography>
            <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
              Current: <strong>{override?.value ?? '...'}</strong>
              {override?.persisted?.updated_by && (
                <> &middot; set by {override.persisted.updated_by}
                  {override.persisted.updated_at && (
                    <> at {new Date(override.persisted.updated_at).toLocaleString()}</>
                  )}
                </>
              )}
            </Typography>
            <TextField
              select fullWidth size="small" value={draftOverride}
              onChange={(e) => setDraftOverride(e.target.value as OverrideValue)}
              sx={{ mt: 1 }}
            >
              {(override?.valid_values ?? ['auto', 'native_only', 'airflow_only', 'halt']).map((v) => (
                <MenuItem key={v} value={v}>{v}</MenuItem>
              ))}
            </TextField>
            <Typography variant="caption" display="block" mt={1}>
              {OVERRIDE_DESCRIPTIONS[draftOverride]}
            </Typography>
            <Button
              variant="contained" sx={{ mt: 1 }} startIcon={<SaveIcon />}
              disabled={saving || draftOverride === override?.value}
              onClick={() => void saveOverride()}
            >
              Apply override
            </Button>

            {health.agent && (
              <Box mt={3}>
                <Typography variant="subtitle2" gutterBottom>Failover agent</Typography>
                <Typography variant="body2" color="text.secondary">
                  Agent is {health.agent.agent_enabled ? 'ENABLED' : 'OFF'} &middot; ticks every {health.agent.interval_seconds}s
                </Typography>
                <Box mt={1}>
                  <Tooltip title="Consecutive unhealthy probes before the agent flips the override">
                    <Chip size="small" variant="outlined"
                          label={`AF unhealthy ${health.agent.streaks.airflow_unhealthy} / ${health.agent.unhealthy_streak_required}`}
                          sx={{ mr: 1, mb: 1 }} />
                  </Tooltip>
                  <Tooltip title="Consecutive unhealthy probes before the agent flips the override">
                    <Chip size="small" variant="outlined"
                          label={`Native unhealthy ${health.agent.streaks.native_unhealthy} / ${health.agent.unhealthy_streak_required}`}
                          sx={{ mr: 1, mb: 1 }} />
                  </Tooltip>
                  <Tooltip title="Consecutive healthy probes before the agent reverts to 'auto'">
                    <Chip size="small" variant="outlined"
                          label={`AF healthy ${health.agent.streaks.airflow_healthy} / ${health.agent.healthy_streak_required}`}
                          sx={{ mr: 1, mb: 1 }} />
                  </Tooltip>
                  <Tooltip title="Consecutive healthy probes before the agent reverts to 'auto'">
                    <Chip size="small" variant="outlined"
                          label={`Native healthy ${health.agent.streaks.native_healthy} / ${health.agent.healthy_streak_required}`}
                          sx={{ mr: 1, mb: 1 }} />
                  </Tooltip>
                </Box>
              </Box>
            )}
          </Grid>
        </Grid>
      )}

      <Divider sx={{ my: 3 }} />

      {/* ── Tunables ───────────────────────────────────────────────────────── */}
      <Typography variant="subtitle2" gutterBottom>Failover tunables</Typography>
      <Typography variant="caption" color="text.secondary" display="block" mb={1}>
        Persisted in the database. Changes take effect on every pod within 5 seconds.
      </Typography>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Key</TableCell>
            <TableCell>Type</TableCell>
            <TableCell>Effective value</TableCell>
            <TableCell>New value</TableCell>
            <TableCell>Last set</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {tunables.map((t) => {
            const leaf = t.key.split('.').pop() ?? t.key;
            const draft = draftTunables[t.key] ?? '';
            // For lists, compare against the JSON form so re-saving the
            // same array doesn't show as "dirty".
            const baseline = t.type === 'list'
              ? JSON.stringify(t.effective_value ?? [], null, 0)
              : String(t.effective_value);
            const dirty = draft !== baseline;
            // Lists render either as a comma-separated summary (read-only)
            // or as the underlying JSON in the input.
            const displayValue = t.type === 'list'
              ? (Array.isArray(t.effective_value) && t.effective_value.length > 0
                  ? (t.effective_value as unknown[]).join(', ')
                  : '(empty)')
              : String(t.effective_value);
            return (
              <TableRow key={t.key}>
                <TableCell>
                  <Tooltip title={t.key}>
                    <span>{leaf}</span>
                  </Tooltip>
                </TableCell>
                <TableCell>{t.type}</TableCell>
                <TableCell>{displayValue}</TableCell>
                <TableCell>
                  {t.type === 'bool' ? (
                    <TextField select size="small" value={draft}
                                onChange={(e) => setDraftTunables({ ...draftTunables, [t.key]: e.target.value })}>
                      <MenuItem value="True">True</MenuItem>
                      <MenuItem value="False">False</MenuItem>
                    </TextField>
                  ) : t.type === 'list' ? (
                    <TextField size="small" multiline minRows={2}
                                placeholder='["C:\\\\path\\\\one", "/data/exports"]'
                                value={draft}
                                helperText="JSON array of absolute paths"
                                onChange={(e) => setDraftTunables({ ...draftTunables, [t.key]: e.target.value })}
                                sx={{ minWidth: 320 }} />
                  ) : (
                    <TextField size="small" value={draft}
                                onChange={(e) => setDraftTunables({ ...draftTunables, [t.key]: e.target.value })} />
                  )}
                </TableCell>
                <TableCell>
                  {t.persisted?.updated_at ? (
                    <Tooltip title={`by ${t.persisted.updated_by ?? 'unknown'}`}>
                      <span>{new Date(t.persisted.updated_at).toLocaleString()}</span>
                    </Tooltip>
                  ) : (
                    <span style={{ color: '#888' }}>config default</span>
                  )}
                </TableCell>
                <TableCell>
                  <Button size="small" disabled={!dirty || saving}
                          onClick={() => void saveTunable(t.key)}>
                    Save
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Paper>
  );
};

export default FeedFailoverSection;
