/**
 * Phase 131-A — ETL Dependencies admin UI (operator surface).
 *
 * Three management surfaces — all OPERATOR-focused:
 *   1. Dependency-type catalogue (KAFKA / ORACLE_TABLE / FILE / API + custom).
 *      Admin-only because changing the catalogue affects every feed.
 *   2. Tracking record (manual operator backfill — RESET / SKIP / COMPLETE).
 *   3. Poll status inspector — pending feed_runs gated on deps.
 *
 * Per-feed dependency MAPPINGS are NOT managed here — end users set
 * those on the Feed config page directly (Production Controls section).
 *
 * No hardcoded values — types / actions / thresholds all come from
 * the backend.  Triggers are generic: any external system, Kafka,
 * file landing, or API event.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Stack, Typography, Paper, Table, TableHead, TableBody, TableRow,
  TableCell, TextField, Button, IconButton, Chip,
  FormControl, InputLabel, Select, MenuItem, Alert, CircularProgress,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { safeFetch } from '../../services/api/core';

type DepType = {
  id: number;
  dependency_type: string;
  description?: string | null;
  server?: string | null;
  param_value?: string | null;
  is_active: boolean;
};

type PollRow = {
  id: number;
  feed_config_id: number;
  etl_id: number;
  business_date: string;
  action_decision?: string;
  action_reason?: string | null;
  status?: string;
};

const ACTIONS = ['COMPLETE', 'SKIP', 'PENDING', 'RESET'] as const;

const FeedEtlDependenciesAdminSection: React.FC = () => {
  const [types, setTypes] = useState<DepType[]>([]);
  const [pollRows, setPollRows] = useState<PollRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');

  // ── Add-type form ───────────────────────────────────────────────────
  const [newTypeName, setNewTypeName] = useState('');
  const [newTypeDesc, setNewTypeDesc] = useState('');

  // ── Record-tracking form (operator backfill) ────────────────────────
  const [trackTypeId, setTrackTypeId] = useState<number | ''>('');
  const [trackKey, setTrackKey] = useState('');
  const [trackDate, setTrackDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [trackAction, setTrackAction] = useState<typeof ACTIONS[number]>('COMPLETE');
  const [trackComments, setTrackComments] = useState('');

  const loadTypes = useCallback(async () => {
    try {
      const r = await safeFetch('/api/admin/etl-dependencies/types') as { items: DepType[] };
      setTypes(r.items || []);
    } catch (e: any) {
      setError(`Failed to load dependency types: ${e?.message || e}`);
    }
  }, []);

  const loadPollStatus = useCallback(async () => {
    try {
      const r = await safeFetch('/api/admin/etl-dependencies/poll-status') as { items: PollRow[]; count: number };
      setPollRows(r.items || []);
    } catch (e: any) {
      setError(`Failed to load poll status: ${e?.message || e}`);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    Promise.all([loadTypes(), loadPollStatus()]).finally(() => setLoading(false));
  }, [loadTypes, loadPollStatus]);

  const handleAddType = async () => {
    if (!newTypeName.trim()) return;
    setError('');
    try {
      await safeFetch('/api/admin/etl-dependencies/types', {
        method: 'POST',
        body: JSON.stringify({
          dependency_type: newTypeName.trim().toUpperCase(),
          description: newTypeDesc || null,
          is_active: true,
        }),
      });
      setNewTypeName(''); setNewTypeDesc('');
      await loadTypes();
    } catch (e: any) {
      setError(e?.message || 'Failed to add dependency type');
    }
  };

  const handleRecordTracking = async () => {
    if (!trackTypeId || !trackKey.trim() || !trackDate) return;
    setError('');
    try {
      await safeFetch('/api/admin/etl-dependencies/tracking', {
        method: 'POST',
        body: JSON.stringify({
          dependency_type_id: Number(trackTypeId),
          dependency_key: trackKey.trim(),
          business_date: trackDate,
          action: trackAction,
          comments: trackComments || null,
        }),
      });
      setTrackComments('');
      await loadPollStatus();
    } catch (e: any) {
      setError(e?.message || 'Failed to record tracking');
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, p: 1 }}>
      <Typography variant="h6">ETL Dependencies (Phase 131-A)</Typography>
      <Typography variant="body2" color="text.secondary">
        Generic trigger gating for feeds.  Any external system — Kafka topic
        landing, Oracle table partition load, file arrival, API event — can
        block a feed's queue claim until its tracking row arrives.
        <br />
        End users add per-feed dependencies in <b>Feeds → Production Controls</b>;
        this page is the operator/admin surface for the catalogue + manual backfill.
      </Typography>

      {error && <Alert severity="error" onClose={() => setError('')}>{error}</Alert>}
      {loading && <CircularProgress size={20} />}

      {/* ── 1. Dependency types ──────────────────────────────────── */}
      <Paper sx={{ p: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          <Typography variant="subtitle1">Dependency type catalogue</Typography>
          <IconButton size="small" onClick={loadTypes}><RefreshIcon fontSize="small" /></IconButton>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          Catalogue is shared across all feeds.  Add new types here when a new
          trigger source comes online (e.g. <code>SFTP_LANDING</code>).
        </Typography>

        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Type</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Active</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {types.map((t) => (
              <TableRow key={t.id}>
                <TableCell>{t.id}</TableCell>
                <TableCell><code>{t.dependency_type}</code></TableCell>
                <TableCell>{t.description || ''}</TableCell>
                <TableCell>
                  <Chip size="small"
                    label={t.is_active ? 'active' : 'disabled'}
                    color={t.is_active ? 'success' : 'default'}
                    variant="outlined" />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <TextField label="New type name (e.g. KAFKA, ORACLE_TABLE, FILE, API)" size="small"
            value={newTypeName}
            onChange={(e) => setNewTypeName(e.target.value)} />
          <TextField label="Description (optional)" size="small" sx={{ flex: 1 }}
            value={newTypeDesc}
            onChange={(e) => setNewTypeDesc(e.target.value)} />
          <Button variant="contained" onClick={handleAddType}
            disabled={!newTypeName.trim()}>Add / Update</Button>
        </Stack>
      </Paper>

      {/* ── 2. Tracking record (operator backfill) ───────────────── */}
      <Paper sx={{ p: 2 }}>
        <Typography variant="subtitle1" sx={{ mb: 1 }}>
          Record tracking (operator backfill)
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          The production path is your Kafka consumer / ETL writing to
          <code> etl_dependency_tracking</code> directly.  Use this form for
          manual backfill, or to <code>SKIP</code> a dependency that won't arrive today,
          or <code>RESET</code> after a bad load.
        </Typography>

        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel id="track-type-label">Dependency type</InputLabel>
            <Select labelId="track-type-label" label="Dependency type"
              value={trackTypeId === '' ? '' : String(trackTypeId)}
              onChange={(e) => setTrackTypeId(
                e.target.value === '' ? '' : Number(e.target.value),
              )}>
              {types.map((t) => (
                <MenuItem key={t.id} value={String(t.id)}>{t.dependency_type}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField label="Dependency key" size="small"
            value={trackKey}
            onChange={(e) => setTrackKey(e.target.value)} />
          <TextField label="Business date" type="date" size="small"
            value={trackDate}
            onChange={(e) => setTrackDate(e.target.value)}
            InputLabelProps={{ shrink: true }} />
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <InputLabel id="track-action-label">Action</InputLabel>
            <Select labelId="track-action-label" label="Action"
              value={trackAction}
              onChange={(e) => setTrackAction(e.target.value as typeof ACTIONS[number])}>
              {ACTIONS.map((a) => <MenuItem key={a} value={a}>{a}</MenuItem>)}
            </Select>
          </FormControl>
          <TextField label="Comments (optional)" size="small" sx={{ flex: 1, minWidth: 200 }}
            value={trackComments}
            onChange={(e) => setTrackComments(e.target.value)} />
          <Button variant="contained" onClick={handleRecordTracking}
            disabled={!trackTypeId || !trackKey.trim() || !trackDate}>
            Record
          </Button>
        </Stack>
      </Paper>

      {/* ── 3. Pending feed_runs needing dep check ────────────────── */}
      <Paper sx={{ p: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          <Typography variant="subtitle1">Current pending runs gated on deps</Typography>
          <IconButton size="small" onClick={loadPollStatus}><RefreshIcon fontSize="small" /></IconButton>
        </Stack>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Run ID</TableCell>
              <TableCell>Feed config</TableCell>
              <TableCell>ETL ID</TableCell>
              <TableCell>Business date</TableCell>
              <TableCell>Decision</TableCell>
              <TableCell>Reason</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pollRows.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{r.id}</TableCell>
                <TableCell>{r.feed_config_id}</TableCell>
                <TableCell>{r.etl_id}</TableCell>
                <TableCell>{r.business_date}</TableCell>
                <TableCell>
                  <Chip size="small"
                    label={r.action_decision || 'RUN'}
                    color={r.action_decision === 'WAIT' ? 'warning' : 'success'}
                    variant="outlined" />
                </TableCell>
                <TableCell>{r.action_reason || ''}</TableCell>
              </TableRow>
            ))}
            {pollRows.length === 0 && (
              <TableRow>
                <TableCell colSpan={6}>
                  <Typography variant="body2" color="text.secondary">
                    No pending feed_runs currently have an etl_id requiring a dep check.
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default FeedEtlDependenciesAdminSection;
