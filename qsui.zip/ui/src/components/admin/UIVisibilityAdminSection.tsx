import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Alert, Switch,
} from '@mui/material';
import { Refresh as RefreshIcon, Save as SaveIcon, VisibilityOff as VisibilityOffIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';

interface VisibilityRow {
  component_key: string;
  role: string;
  enabled: boolean;
}

interface ComponentEntry {
  key: string;
  label: string;
  group: string;
}

const UIVisibilityAdminSection: React.FC = () => {
  const [matrix, setMatrix]     = useState<VisibilityRow[]>([]);
  const [components, setComponents] = useState<[string, string, string][]>([]);
  const [roles, setRoles]       = useState<string[]>([]);
  const [saving, setSaving]     = useState(false);
  const [saved, setSaved]       = useState(false);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const d = await safeFetch('/api/admin/ui-visibility');
      setMatrix(d.visibility || []);
      setComponents(d.components || []);
      // Phase 107-I: super_admin always sees everything — hide the column
      // from the matrix to avoid suggesting it's a per-component toggle.
      setRoles((d.roles || []).filter((r: string) => r !== 'super_admin'));
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Build a mutable map: { componentKey_role: enabled }
  const [overrides, setOverrides] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const map: Record<string, boolean> = {};
    for (const row of matrix) {
      map[`${row.component_key}__${row.role}`] = row.enabled;
    }
    setOverrides(map);
  }, [matrix]);

  const getValue = (key: string, role: string) => {
    const k = `${key}__${role}`;
    return k in overrides ? overrides[k] : true;
  };

  const toggle = (key: string, role: string) => {
    const k = `${key}__${role}`;
    setOverrides(prev => ({ ...prev, [k]: !(prev[k] ?? true) }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      // Only send rows that differ from default (true) or are explicitly set
      const rules: Array<{ component_key: string; role: string; enabled: boolean }> = [];
      for (const [k, v] of Object.entries(overrides)) {
        const [componentKey, role] = k.split('__');
        rules.push({ component_key: componentKey, role, enabled: v });
      }
      await safeFetch('/api/admin/ui-visibility', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rules }),
      });
      setSaved(true);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  };

  // Group components by group
  const grouped: Record<string, ComponentEntry[]> = {};
  for (const [key, label, group] of components) {
    if (!grouped[group]) grouped[group] = [];
    grouped[group].push({ key, label, group });
  }

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress size={24} /></Box>;

  return (
    <Box sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <VisibilityOffIcon color="action" />
        <Typography variant="h6" fontWeight={600}>UI Component Visibility</Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
        <Button size="small" variant="contained" startIcon={<SaveIcon />} onClick={handleSave} disabled={saving || components.length === 0}>
          {saving ? 'Saving…' : 'Save Changes'}
        </Button>
      </Box>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {saved && <Alert severity="success" sx={{ mb: 2 }}>Visibility settings saved.</Alert>}

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Toggle which pages/features are accessible to each role. Admins always retain full access.
        Changes take effect on the user's next page load.
      </Typography>

      {Object.entries(grouped).map(([group, items]) => (
        <Box key={group} sx={{ mb: 3 }}>
          <Typography variant="overline" color="text.disabled" sx={{ letterSpacing: 1.2 }}>{group}</Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ mt: 0.5 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600, width: 220 }}>Component</TableCell>
                  {roles.map(r => (
                    <TableCell key={r} align="center" sx={{ fontWeight: 600, textTransform: 'capitalize' }}>
                      {r}
                      {r === 'admin' && (
                        <Typography variant="caption" display="block" color="text.disabled">(always on)</Typography>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {items.map(({ key, label }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{label}</TableCell>
                    {roles.map(role => (
                      <TableCell key={role} align="center">
                        <Switch
                          size="small"
                          checked={role === 'admin' ? true : getValue(key, role)}
                          disabled={role === 'admin'}
                          onChange={() => toggle(key, role)}
                          color="primary"
                        />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      ))}
    </Box>
  );
};

export default UIVisibilityAdminSection;
