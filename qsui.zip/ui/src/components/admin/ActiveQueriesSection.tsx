/**
 * Active Queries monitoring section — extracted from AdminPage.
 * Self-contained: manages own state, polling, and data fetching.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Alert, LinearProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Avatar, Chip, Tooltip, IconButton, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions, Button,
  useTheme,
} from '@mui/material';
import {
  Cancel as CancelIcon,
  PlayCircleOutline as ActiveIcon,
  Block as BlockedIcon,
  HourglassTop as RunningIcon,
  AccessTime as DurationIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import { fmtDate, fmtDuration, WARN_SECS } from './adminUtils';

/** Live duration ticker component.
 *
 * BF-465 hardening — pause when the browser tab is hidden.  Browsers
 * throttle background setIntervals to ~1/min anyway, but we ALSO want
 * the ticker not to fire setState (which forces a re-render) when no
 * one is looking.  Saves cycles on admins who park this tab in the
 * background with 50+ active queries.
 */
const LiveDuration: React.FC<{ seconds: number; warn: boolean }> = ({ seconds: initial, warn }) => {
  const [secs, setSecs] = useState(initial);
  const [visible, setVisible] = useState(
    typeof document === 'undefined' ? true : document.visibilityState !== 'hidden',
  );
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const onVis = () => setVisible(document.visibilityState !== 'hidden');
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);
  useEffect(() => {
    setSecs(initial);
    if (!visible) return;
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [initial, visible]);
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <DurationIcon sx={{ fontSize: 14, color: warn ? 'error.main' : 'text.secondary' }} />
      <Typography variant="body2" fontWeight={warn ? 700 : 400}
        color={warn ? 'error.main' : 'text.primary'}>
        {fmtDuration(secs)}
      </Typography>
    </Box>
  );
};

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const ActiveQueriesSection: React.FC<Props> = ({ addNotification }) => {
  const theme = useTheme();
  const [loading, setLoading] = useState(true);
  const [activeQ, setActiveQ] = useState<any[]>([]);
  const [cancelTarget, setCancelTarget] = useState<any>(null);
  const [cancelBusy, setCancelBusy] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/active-queries');
      setActiveQ(toArray(data));  // BF-430E
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  useEffect(() => {
    const t = setInterval(loadData, 10_000);
    return () => clearInterval(t);
  }, [loadData]);

  const longRunning = activeQ.filter(q => q.duration_seconds >= WARN_SECS);

  const handleCancel = async () => {
    if (!cancelTarget) return;
    setCancelBusy(true);
    try {
      const body = await safeFetch(`/api/admin/queries/${cancelTarget.execution_id}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Query Cancelled', message: body.message });
      setCancelTarget(null);
      loadData();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cancel Failed', message: e.message });
    } finally { setCancelBusy(false); }
  };

  return (
    <>
      <Paper variant="outlined" sx={{ p: 2.5 }}>
        {longRunning.length > 0 && (
          <Alert severity="warning" sx={{ mb: 2 }} icon={<BlockedIcon />}>
            <strong>{longRunning.length}</strong> quer{longRunning.length > 1 ? 'ies' : 'y'} running
            longer than {WARN_SECS / 60} minutes — consider cancelling to free resources.
          </Alert>
        )}
        {loading && <LinearProgress sx={{ mb: 1 }} />}
        {!loading && activeQ.length === 0 ? (
          <Box sx={{ py: 4, textAlign: 'center', color: 'text.secondary' }}>
            <RunningIcon sx={{ fontSize: 36, mb: 1, opacity: 0.3 }} />
            <Typography variant="body2">No active queries — system is idle</Typography>
          </Box>
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {['User', 'Status', 'Duration', 'Progress', 'Connection', 'Started', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {activeQ.map((row) => {
                  const isWarn = row.duration_seconds >= WARN_SECS;
                  const progress = row.chunks_processed > 0
                    ? Math.min(99, Math.round(row.chunks_processed * 5)) : null;
                  return (
                    <TableRow key={row.execution_id} hover
                      sx={isWarn ? { bgcolor: 'rgba(255,152,0,0.06)' } : {}}>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                          <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                            bgcolor: theme.palette.primary.light }}>
                            {(row.executed_by || 'G')[0].toUpperCase()}
                          </Avatar>
                          <Typography variant="body2">{row.executed_by || 'guest'}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status}
                          color={row.status === 'processing' ? 'primary' : 'default'}
                          variant="outlined"
                          icon={row.status === 'processing'
                            ? <RunningIcon sx={{ fontSize: '12px !important',
                                animation: 'spin 1.4s linear infinite',
                                '@keyframes spin': { '0%': { transform: 'rotate(0deg)' }, '100%': { transform: 'rotate(360deg)' } } }} />
                            : undefined}
                          sx={{ fontSize: '0.7rem', height: 20 }}
                        />
                      </TableCell>
                      <TableCell><LiveDuration seconds={row.duration_seconds} warn={isWarn} /></TableCell>
                      <TableCell sx={{ minWidth: 110 }}>
                        {progress != null ? (
                          <Box>
                            <LinearProgress variant="determinate" value={progress}
                              sx={{ height: 6, borderRadius: 3, mb: 0.3 }} />
                            <Typography variant="caption" color="text.secondary">
                              {row.chunks_processed} chunks
                            </Typography>
                          </Box>
                        ) : (
                          <LinearProgress sx={{ height: 6, borderRadius: 3 }} />
                        )}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                        {row.connection_name || '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap', color: 'text.secondary' }}>
                        {fmtDate(row.started_at)}
                      </TableCell>
                      <TableCell>
                        <Tooltip title="Cancel this query (admin override)">
                          <IconButton size="small" color="error"
                            onClick={() => setCancelTarget(row)}>
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {/* Cancel confirmation dialog */}
      <Dialog open={!!cancelTarget} onClose={() => setCancelTarget(null)}>
        <DialogTitle>Cancel Query?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            This will forcefully cancel the query by <strong>{cancelTarget?.executed_by || 'guest'}</strong> running
            for {cancelTarget ? fmtDuration(cancelTarget.duration_seconds) : ''}.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelTarget(null)} disabled={cancelBusy}>Keep Running</Button>
          <Button onClick={handleCancel} color="error" variant="contained" disabled={cancelBusy}>
            {cancelBusy ? 'Cancelling…' : 'Cancel Query'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ActiveQueriesSection;
