/**
 * Operations Dashboard — single consolidated view (2026-06-03).
 *
 * User: "arrange these UIs ... its scattered ... turned on background jobs
 * for iceberg metadata sync and prewarm_background but whats happening at
 * background jobs hard to know on UI".
 *
 * One screen shows:
 *   1. All registered background jobs (running / stopped / errored)
 *   2. Live column-stats scan progress (per-pod, in-flight + finished)
 *   3. Iceberg metadata sync status (last sync, next cycle)
 *   4. Memory_guard watchdog state (admission_blocked / inflight_total)
 *
 * Auto-refreshes every 5 seconds.  Read-only — to control jobs, click into
 * the specialized section linked from each card.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Chip, CircularProgress, Paper, Stack, Typography,
  Table, TableHead, TableRow, TableCell, TableBody, LinearProgress,
} from '@mui/material';
import {
  PlayArrow as RunningIcon,
  CheckCircle as DoneIcon,
  Error as ErrorIcon,
  Pause as PausedIcon,
  HourglassEmpty as IdleIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';


interface BgJob {
  name:         string;
  description:  string;
  running:      boolean;
  paused:       boolean;
  status:       string;
  started_at:   string | null;
  last_error:   string | null;
}

interface ScanJob {
  job_id:           string;
  connection_id:    number | null;
  table_name:       string | null;
  bucket:           string;
  table_prefix:     string;
  total:            number;
  total_pre_prune?: number | null;
  files_pruned?:    number;
  done:             number;
  scanned:          number;
  skipped:          number;
  failed:           number;
  files_per_sec:    number;
  eta_seconds:      number | null;
  status:           string;
  started_at:       number;
  finished_at?:     number;
  summary?:         {
    failure_categories?: Record<string, number>;
    rows_inserted?:      number;
  };
  error?:           string | null;
}

interface MemGuardStatus {
  running:                boolean;
  admission_blocked:      boolean;
  admission_blocks_total: number;
  last_sample_mb:         number | null;
  inflight_total_mb:      number;
  inflight_count:         number;
}

interface MetaSyncStatus {
  summary?: {
    finished_at?: string;
    reconciled?:  number;
    skipped?:     number;
    errored?:     number;
    elapsed_seconds?: number;
  };
  manual?:  { running: boolean; elapsed_seconds: number | null };
  progress?: {
    current_table?: { bucket: string; table_prefix: string; connection_id?: number } | null;
    completed_count: number;
    total_count: number;
  };
  recent_runs?: Array<{ finished_at: string; reconciled: number; errored: number; elapsed_seconds: number }>;
}


const statusIcon = (s: string) => {
  if (s === 'running') return <RunningIcon fontSize="small" color="primary" />;
  if (s === 'done')    return <DoneIcon fontSize="small" color="success" />;
  if (s === 'error' || s === 'errored') return <ErrorIcon fontSize="small" color="error" />;
  if (s === 'paused')  return <PausedIcon fontSize="small" color="warning" />;
  return <IdleIcon fontSize="small" color="disabled" />;
};


const OperationsDashboardSection: React.FC = () => {
  const [bgJobs, setBgJobs] = useState<BgJob[]>([]);
  const [scanJobs, setScanJobs] = useState<ScanJob[]>([]);
  const [memGuard, setMemGuard] = useState<MemGuardStatus | null>(null);
  const [metaSync, setMetaSync] = useState<MetaSyncStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  // 2026-06-04 audit fix — guard setState against unmount race.
  // Without isMounted ref the 5s polling fetch can resolve after the
  // component unmounts (e.g. operator navigates away mid-poll), calling
  // setBgJobs/setScanJobs/setMemGuard/setMetaSync on an unmounted
  // component and producing the React unmount warning.
  const isMountedRef = React.useRef(true);
  React.useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  const load = useCallback(async () => {
    try {
      // retryOnTimeout=false — this section polls every 5s; if any
      // endpoint legitimately slow-runs once, the retry would generate
      // 3 overlapping requests, compounding the load.  Better to drop
      // a poll than amplify pressure.
      const opts = { retryOnTimeout: false } as const;
      const [bg, scan, mg, ms] = await Promise.all([
        safeFetch('/api/admin/background-jobs', opts).catch(() => null),
        safeFetch('/api/admin/iceberg/column-stats/scan-progress', opts).catch(() => null),
        safeFetch('/api/admin/memory-guard/status', opts).catch(() => null),
        safeFetch('/api/admin/iceberg-sync/status?page=1&page_size=1', opts).catch(() => null),
      ]);
      if (!isMountedRef.current) return;
      setBgJobs(bg?.jobs ?? []);
      setScanJobs(scan?.jobs ?? []);
      setMemGuard(mg ?? null);
      setMetaSync(ms ?? null);
      setError(null);
    } catch (e: any) {
      if (!isMountedRef.current) return;
      setError(e?.message || String(e));
    }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load]);

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Operations Dashboard</Typography>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Memory guard banner */}
      {memGuard && (
        <Alert
          severity={memGuard.admission_blocked ? 'warning' : 'success'}
          sx={{ mb: 2 }}
          icon={memGuard.admission_blocked ? <ErrorIcon /> : <DoneIcon />}
        >
          <Stack direction="row" spacing={2} alignItems="center" sx={{ flexWrap: 'wrap' }}>
            <Typography variant="body2" fontWeight={700}>
              {memGuard.admission_blocked
                ? 'Memory_guard: admission BLOCKED — new queries refused until RAM recovers'
                : 'Memory_guard: admission OK'}
            </Typography>
            <Chip size="small" label={`available: ${memGuard.last_sample_mb ?? '?'} MB`} />
            <Chip size="small" label={`inflight: ${memGuard.inflight_count} queries (${memGuard.inflight_total_mb} MB)`} />
            <Chip size="small" label={`blocks lifetime: ${memGuard.admission_blocks_total}`} variant="outlined" />
          </Stack>
        </Alert>
      )}

      {/* Background jobs panel */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
          Background Jobs ({bgJobs.length})
        </Typography>
        {bgJobs.length === 0 ? (
          <Typography variant="caption" color="text.secondary">No registered jobs.</Typography>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Job</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Started</TableCell>
                <TableCell>Last Error</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {bgJobs.map((j) => (
                <TableRow key={j.name}>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      {statusIcon(j.status)}
                      <Box>
                        <Typography variant="body2">{j.name}</Typography>
                        <Typography variant="caption" color="text.secondary">{j.description}</Typography>
                      </Box>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip size="small"
                          label={j.status}
                          color={j.running ? 'success' : j.status === 'errored' ? 'error' : 'default'}
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">
                      {j.started_at ? new Date(j.started_at).toLocaleTimeString() : '—'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {j.last_error
                      ? <Typography variant="caption" color="error">{j.last_error.slice(0, 80)}</Typography>
                      : <Typography variant="caption" color="text.secondary">—</Typography>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Paper>

      {/* Iceberg metadata sync detail */}
      {metaSync && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="subtitle1" fontWeight={700}>
              Iceberg Metadata Sync
            </Typography>
            {metaSync.manual?.running && (
              <Chip size="small" color="primary" label="MANUAL RUN IN PROGRESS" />
            )}
            {metaSync.progress && metaSync.progress.total_count > 0 && (
              <Chip size="small" color="primary" variant="outlined"
                    label={`tables: ${metaSync.progress.completed_count}/${metaSync.progress.total_count}`} />
            )}
          </Stack>
          {metaSync.progress?.current_table && (
            <Alert severity="info" sx={{ mb: 1 }}>
              <Typography variant="caption">
                Now syncing: <b>{metaSync.progress.current_table.bucket}/{metaSync.progress.current_table.table_prefix}</b>
                {metaSync.progress.current_table.connection_id !== undefined
                  ? ` (conn ${metaSync.progress.current_table.connection_id})` : ''}
              </Typography>
            </Alert>
          )}
          {metaSync.summary?.finished_at && (
            <Stack direction="row" spacing={1} sx={{ mb: 1, flexWrap: 'wrap' }}>
              <Chip size="small" label={`last finished: ${new Date(metaSync.summary.finished_at).toLocaleTimeString()}`} />
              <Chip size="small" color="success" label={`reconciled: ${metaSync.summary.reconciled ?? 0}`} />
              {(metaSync.summary.errored ?? 0) > 0 && (
                <Chip size="small" color="error" label={`errored: ${metaSync.summary.errored}`} />
              )}
              <Chip size="small" variant="outlined"
                    label={`elapsed: ${(metaSync.summary.elapsed_seconds ?? 0).toFixed(1)}s`} />
            </Stack>
          )}
          {metaSync.recent_runs && metaSync.recent_runs.length > 0 && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                Recent runs ({metaSync.recent_runs.length})
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Finished</TableCell>
                    <TableCell>Reconciled</TableCell>
                    <TableCell>Errors</TableCell>
                    <TableCell>Elapsed</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {metaSync.recent_runs.slice(0, 5).map((r, i) => (
                    <TableRow key={i}>
                      <TableCell><Typography variant="caption">
                        {r.finished_at ? new Date(r.finished_at).toLocaleString() : '—'}
                      </Typography></TableCell>
                      <TableCell><Typography variant="caption">{r.reconciled}</Typography></TableCell>
                      <TableCell>
                        <Typography variant="caption" color={r.errored > 0 ? 'error' : 'text.secondary'}>
                          {r.errored}
                        </Typography>
                      </TableCell>
                      <TableCell><Typography variant="caption">{r.elapsed_seconds.toFixed(1)}s</Typography></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          )}
        </Paper>
      )}

      {/* Column-stats scan progress */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
          Column-Stats Scans (in-flight + recent)
        </Typography>
        {scanJobs.length === 0 ? (
          <Typography variant="caption" color="text.secondary">
            No scans running.  Trigger one from the Column Stats section.
          </Typography>
        ) : (
          <Stack spacing={1.5}>
            {scanJobs.map((s) => {
              const pct = s.total > 0 ? Math.round((s.done / s.total) * 100) : 0;
              const failCats = s.summary?.failure_categories ?? {};
              const failPairs = Object.entries(failCats).filter(([_, n]) => n > 0);
              return (
                <Box key={s.job_id} sx={{ borderLeft: 4,
                                          borderColor: s.status === 'error' ? 'error.main'
                                                       : s.status === 'done'  ? 'success.main'
                                                       : 'primary.main',
                                          pl: 1.5 }}>
                  <Stack direction="row" spacing={1} alignItems="center" sx={{ flexWrap: 'wrap', mb: 0.5 }}>
                    {statusIcon(s.status)}
                    <Typography variant="body2" fontWeight={700}>
                      {s.table_name ?? `${s.bucket}/${s.table_prefix}`}
                    </Typography>
                    <Chip size="small" label={`${s.done}/${s.total} (${pct}%)`} />
                    <Chip size="small" label={`${s.files_per_sec.toFixed(1)} files/s`} variant="outlined" />
                    {s.eta_seconds !== null && (
                      <Chip size="small" label={`ETA ${Math.round(s.eta_seconds)}s`} variant="outlined" />
                    )}
                    {s.scanned > 0 && (
                      <Chip size="small" color="success" label={`${s.scanned} scanned`} variant="outlined" />
                    )}
                    {s.skipped > 0 && (
                      <Chip size="small" label={`${s.skipped} skipped`} variant="outlined" />
                    )}
                    {s.failed > 0 && (
                      <Chip size="small" color="error" label={`${s.failed} failed`} variant="outlined" />
                    )}
                  </Stack>
                  <LinearProgress
                    variant="determinate"
                    value={pct}
                    color={s.status === 'error' ? 'error' : 'primary'}
                    sx={{ mb: 0.5 }}
                  />
                  {failPairs.length > 0 && (
                    <Typography variant="caption" color="error" sx={{ display: 'block' }}>
                      Failure categories: {failPairs.map(([k, n]) => `${k}=${n}`).join(', ')}
                    </Typography>
                  )}
                  {s.error && (
                    <Typography variant="caption" color="error" sx={{ display: 'block' }}>
                      Error: {s.error.slice(0, 200)}
                    </Typography>
                  )}
                  {s.summary?.rows_inserted !== undefined && (
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                      Rows inserted: {s.summary.rows_inserted}
                    </Typography>
                  )}
                </Box>
              );
            })}
          </Stack>
        )}
      </Paper>
    </Box>
  );
};

export default OperationsDashboardSection;
