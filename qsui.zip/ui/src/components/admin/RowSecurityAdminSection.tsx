/**
 * Row & Column Security admin section — Phase 141.
 *
 * Provides CRUD + dry-run + audit + LF sync UI for the Lake-Formation-equivalent
 * row & column-level security system.
 *
 *   - Config card        GET /api/admin/row-security/config
 *   - Row Policies       /api/admin/row-security/policies
 *   - Column Policies    /api/admin/row-security/column-policies
 *   - Bindings           /api/admin/row-security/bindings
 *   - Dry-Run Test       /api/admin/row-security/test
 *   - Audit Log          /api/admin/row-security/audit
 *   - LF Sync            /api/admin/row-security/lake-formation/sync
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, MenuItem, FormControl, InputLabel, Select,
  Dialog, DialogTitle, DialogContent, DialogActions,
  Alert, CircularProgress, IconButton, Tooltip, Tab, Tabs,
  Switch, FormControlLabel,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  PlayArrow as TestIcon,
  Sync as SyncIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import { fmtDate } from './adminUtils';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const ENFORCEMENT_OPTIONS = ['rewrite', 'view', 'native_lf', 'audit_only'];
const PRINCIPAL_TYPES = ['user', 'role', 'group', 'system_account', 'all'];
const COLUMN_MODES = ['include', 'exclude', 'mask'];

const RowSecurityAdminSection: React.FC<Props> = ({ addNotification }) => {
  const [tab, setTab] = useState(0);

  // Config
  const [cfg, setCfg] = useState<any>(null);

  // Row policies
  const [rowPolicies, setRowPolicies] = useState<any[]>([]);
  const [colPolicies, setColPolicies] = useState<any[]>([]);
  const [bindings, setBindings] = useState<any[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Dialogs
  const [rowDialog, setRowDialog] = useState(false);
  const [colDialog, setColDialog] = useState(false);
  const [bindDialog, setBindDialog] = useState(false);
  const [testDialog, setTestDialog] = useState(false);
  const [syncDialog, setSyncDialog] = useState(false);

  // Forms
  const [rowForm, setRowForm] = useState({
    name: '', table_pattern: '', filter_sql: '',
    description: '', enforcement: 'rewrite', enabled: true, priority: 100,
  });
  const [colForm, setColForm] = useState({
    name: '', table_pattern: '', mode: 'exclude', columns: '',
    mask_expr: '', description: '', enforcement: 'rewrite', enabled: true, priority: 100,
  });
  const [bindForm, setBindForm] = useState({
    policy_kind: 'row', policy_id: 0, principal_type: 'role',
    principal_id: '', priority: 100,
  });
  const [testForm, setTestForm] = useState({
    sql: 'SELECT * FROM orders', username: 'alice',
    role: 'analyst', groups: '', connection_id: '', dialect: 'duckdb',
  });
  const [testResult, setTestResult] = useState<any>(null);
  const [syncForm, setSyncForm] = useState({ connection_id: '', databases: '' });

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const [c, rp, cp, bs] = await Promise.all([
        safeFetch('/api/admin/row-security/config').catch(() => null),
        safeFetch('/api/admin/row-security/policies').catch(() => []),
        safeFetch('/api/admin/row-security/column-policies').catch(() => []),
        safeFetch('/api/admin/row-security/bindings').catch(() => []),
      ]);
      setCfg(c);
      setRowPolicies(toArray(rp));   // BF-430E
      setColPolicies(toArray(cp));   // BF-430E
      setBindings(toArray(bs));      // BF-430E
    } finally {
      setLoading(false);
    }
  }, []);

  const loadAudit = useCallback(async () => {
    try {
      const a = await safeFetch('/api/admin/row-security/audit?limit=200');
      setAudit(toArray(a));  // BF-430E
    } catch {
      setAudit([]);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);
  useEffect(() => { if (tab === 3) loadAudit(); }, [tab, loadAudit]);

  // ── Row policy actions ──────────────────────────────────────────────
  const submitRowPolicy = async () => {
    try {
      await safeFetch('/api/admin/row-security/policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rowForm),
      });
      setRowDialog(false);
      setRowForm({ name: '', table_pattern: '', filter_sql: '',
        description: '', enforcement: 'rewrite', enabled: true, priority: 100 });
      reload();
      addNotification({ type: 'success', title: 'Row policy created', message: rowForm.name });
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Create failed', message: e.message });
    }
  };

  const deleteRowPolicy = async (id: number) => {
    if (!window.confirm('Delete this row policy and its bindings?')) return;
    try {
      await safeFetch(`/api/admin/row-security/policies/${id}`, { method: 'DELETE' });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Delete failed', message: e.message });
    }
  };

  const toggleRowPolicy = async (p: any) => {
    try {
      await safeFetch(`/api/admin/row-security/policies/${p.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !p.enabled }),
      });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Update failed', message: e.message });
    }
  };

  // ── Column policy actions ───────────────────────────────────────────
  const submitColPolicy = async () => {
    const payload = {
      ...colForm,
      columns: colForm.columns.split(',').map((c) => c.trim()).filter(Boolean),
    };
    try {
      await safeFetch('/api/admin/row-security/column-policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      setColDialog(false);
      setColForm({ name: '', table_pattern: '', mode: 'exclude', columns: '',
        mask_expr: '', description: '', enforcement: 'rewrite', enabled: true, priority: 100 });
      reload();
      addNotification({ type: 'success', title: 'Column policy created', message: colForm.name });
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Create failed', message: e.message });
    }
  };

  const deleteColPolicy = async (id: number) => {
    if (!window.confirm('Delete this column policy and its bindings?')) return;
    try {
      await safeFetch(`/api/admin/row-security/column-policies/${id}`, { method: 'DELETE' });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Delete failed', message: e.message });
    }
  };

  // ── Binding actions ─────────────────────────────────────────────────
  const submitBinding = async () => {
    try {
      await safeFetch('/api/admin/row-security/bindings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bindForm),
      });
      setBindDialog(false);
      setBindForm({ policy_kind: 'row', policy_id: 0, principal_type: 'role',
        principal_id: '', priority: 100 });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Bind failed', message: e.message });
    }
  };

  const deleteBinding = async (id: number) => {
    try {
      await safeFetch(`/api/admin/row-security/bindings/${id}`, { method: 'DELETE' });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Delete failed', message: e.message });
    }
  };

  // ── Test ────────────────────────────────────────────────────────────
  const runTest = async () => {
    try {
      const r = await safeFetch('/api/admin/row-security/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sql: testForm.sql,
          username: testForm.username,
          role: testForm.role,
          groups: testForm.groups.split(',').map((g) => g.trim()).filter(Boolean),
          connection_id: testForm.connection_id ? Number(testForm.connection_id) : null,
          dialect: testForm.dialect,
        }),
      });
      setTestResult(r);
    } catch (e: any) {
      setTestResult({ ok: false, error: e.message });
    }
  };

  // ── LF sync ─────────────────────────────────────────────────────────
  const runLfSync = async () => {
    if (!syncForm.connection_id) return;
    try {
      const r = await safeFetch('/api/admin/row-security/lake-formation/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          connection_id: Number(syncForm.connection_id),
          databases: syncForm.databases ? syncForm.databases.split(',').map((s) => s.trim()) : null,
        }),
      });
      setSyncDialog(false);
      addNotification({
        type: 'success',
        title: 'LF sync done',
        message: `Imported ${r.imported}, errors ${r.errors?.length || 0}`,
      });
      reload();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'LF sync failed', message: e.message });
    }
  };

  // ── Render ──────────────────────────────────────────────────────────
  const enabledChip = cfg?.enabled
    ? <Chip label="Enabled" color="success" size="small" />
    : <Chip label="Disabled" color="default" size="small" />;
  const modeChip = (m: string) => (
    <Chip
      label={m}
      size="small"
      color={m === 'rewrite' ? 'primary' : m === 'audit_only' ? 'warning' : 'default'}
    />
  );

  return (
    <Box>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h6">Row & Column Security</Typography>
        {enabledChip}
        {cfg && modeChip(cfg.default_mode)}
        <Box flex={1} />
        <Tooltip title="Reload">
          <IconButton onClick={reload} disabled={loading}><RefreshIcon /></IconButton>
        </Tooltip>
      </Stack>

      {cfg && (
        <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
          <StatCard label="Row Policies"     value={rowPolicies.length} />
          <StatCard label="Column Policies"  value={colPolicies.length} />
          <StatCard label="Bindings"         value={bindings.length} />
          <StatCard label="Cache TTL (s)"    value={cfg.cache_resolver_seconds} />
        </Stack>
      )}

      {cfg && !cfg.enabled && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Row-security is currently <strong>disabled</strong> in config (<code>row_security.enabled=false</code>).
          Policies are stored but the rewriter is a no-op.  Enable via{' '}
          <strong>App Config</strong> when you're ready to enforce.
        </Alert>
      )}

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab label={`Row Policies (${rowPolicies.length})`} />
        <Tab label={`Column Policies (${colPolicies.length})`} />
        <Tab label={`Bindings (${bindings.length})`} />
        <Tab label="Audit Log" />
        <Tab label="Test / Dry-Run" />
      </Tabs>

      {tab === 0 && (
        <Paper sx={{ p: 2 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <Button startIcon={<AddIcon />} variant="contained" onClick={() => setRowDialog(true)}>
              New Row Policy
            </Button>
            <Box flex={1} />
            <Button startIcon={<SyncIcon />} onClick={() => setSyncDialog(true)}>
              Sync from Lake Formation
            </Button>
          </Stack>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Table pattern</TableCell>
                  <TableCell>Filter</TableCell>
                  <TableCell>Source</TableCell>
                  <TableCell>Mode</TableCell>
                  <TableCell>Enabled</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rowPolicies.map((p) => (
                  <TableRow key={p.id} hover>
                    <TableCell>{p.name}</TableCell>
                    <TableCell><code>{p.table_pattern}</code></TableCell>
                    <TableCell sx={{ maxWidth: 320 }}>
                      <Tooltip title={p.filter_sql}>
                        <Typography variant="body2" sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {p.filter_sql}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell><Chip label={p.source} size="small" /></TableCell>
                    <TableCell>{modeChip(p.enforcement)}</TableCell>
                    <TableCell>
                      <Switch
                        size="small"
                        checked={p.enabled}
                        onChange={() => toggleRowPolicy(p)}
                      />
                    </TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => deleteRowPolicy(p.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {rowPolicies.length === 0 && (
                  <TableRow><TableCell colSpan={7} align="center">No row policies — click "New Row Policy" to create one.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {tab === 1 && (
        <Paper sx={{ p: 2 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <Button startIcon={<AddIcon />} variant="contained" onClick={() => setColDialog(true)}>
              New Column Policy
            </Button>
          </Stack>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Table pattern</TableCell>
                  <TableCell>Mode</TableCell>
                  <TableCell>Columns</TableCell>
                  <TableCell>Mask</TableCell>
                  <TableCell>Enabled</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {colPolicies.map((p) => (
                  <TableRow key={p.id} hover>
                    <TableCell>{p.name}</TableCell>
                    <TableCell><code>{p.table_pattern}</code></TableCell>
                    <TableCell>{modeChip(p.mode)}</TableCell>
                    <TableCell>{(p.columns || []).join(', ')}</TableCell>
                    <TableCell><code>{p.mask_expr || '—'}</code></TableCell>
                    <TableCell>{p.enabled ? 'Yes' : 'No'}</TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => deleteColPolicy(p.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {colPolicies.length === 0 && (
                  <TableRow><TableCell colSpan={7} align="center">No column policies.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {tab === 2 && (
        <Paper sx={{ p: 2 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <Button startIcon={<AddIcon />} variant="contained" onClick={() => setBindDialog(true)}>
              New Binding
            </Button>
          </Stack>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Policy</TableCell>
                  <TableCell>Kind</TableCell>
                  <TableCell>Principal</TableCell>
                  <TableCell>Priority</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {bindings.map((b) => (
                  <TableRow key={b.id} hover>
                    <TableCell>#{b.policy_id}</TableCell>
                    <TableCell>{b.policy_kind}</TableCell>
                    <TableCell><code>{b.principal_type}:{b.principal_id}</code></TableCell>
                    <TableCell>{b.priority}</TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => deleteBinding(b.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {bindings.length === 0 && (
                  <TableRow><TableCell colSpan={5} align="center">No bindings — policies need at least one binding to be active.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {tab === 3 && (
        <Paper sx={{ p: 2 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <Button startIcon={<RefreshIcon />} onClick={loadAudit}>Refresh</Button>
            <Typography variant="body2" sx={{ alignSelf: 'center' }}>
              {audit.length} entries
            </Typography>
          </Stack>
          <TableContainer sx={{ maxHeight: 500 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>Time</TableCell>
                  <TableCell>User</TableCell>
                  <TableCell>Table</TableCell>
                  <TableCell>Mode</TableCell>
                  <TableCell>Row policies</TableCell>
                  <TableCell>Col policies</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {audit.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell>{fmtDate(a.ts)}</TableCell>
                    <TableCell>{a.username}</TableCell>
                    <TableCell><code>{a.table_ref}</code></TableCell>
                    <TableCell>{modeChip(a.mode)}</TableCell>
                    <TableCell>{(a.row_policies || []).map((p: any) => p.name).join(', ')}</TableCell>
                    <TableCell>{(a.column_policies || []).map((p: any) => p.name).join(', ')}</TableCell>
                  </TableRow>
                ))}
                {audit.length === 0 && (
                  <TableRow><TableCell colSpan={6} align="center">No audit entries.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {tab === 4 && (
        <Paper sx={{ p: 2 }}>
          <Typography variant="subtitle1" gutterBottom>Dry-run a query against a synthetic principal</Typography>
          <Stack spacing={2}>
            <TextField
              label="SQL"
              multiline minRows={4}
              value={testForm.sql}
              onChange={(e) => setTestForm({ ...testForm, sql: e.target.value })}
              fullWidth
            />
            <Stack direction="row" spacing={2}>
              <TextField label="Username" value={testForm.username}
                onChange={(e) => setTestForm({ ...testForm, username: e.target.value })} />
              <TextField label="Role" value={testForm.role}
                onChange={(e) => setTestForm({ ...testForm, role: e.target.value })} />
              <TextField label="Groups (comma)" value={testForm.groups}
                onChange={(e) => setTestForm({ ...testForm, groups: e.target.value })} />
              <TextField label="Connection ID" value={testForm.connection_id}
                onChange={(e) => setTestForm({ ...testForm, connection_id: e.target.value })} />
              <TextField label="Dialect" value={testForm.dialect}
                onChange={(e) => setTestForm({ ...testForm, dialect: e.target.value })} />
            </Stack>
            <Button variant="contained" startIcon={<TestIcon />} onClick={runTest}>
              Run rewrite
            </Button>
            {testResult && (
              <Alert severity={testResult.ok ? (testResult.changed ? 'success' : 'info') : 'error'}>
                {testResult.ok ? (
                  <>
                    <Typography variant="body2">
                      <strong>{testResult.changed ? 'Rewritten:' : 'No policy matched — unchanged'}</strong>
                    </Typography>
                    {testResult.changed && (
                      <pre style={{ marginTop: 8, whiteSpace: 'pre-wrap', fontSize: 12 }}>{testResult.rewritten}</pre>
                    )}
                    <Typography variant="caption">Principal IDs tried: {(testResult.principal_ids || []).join(', ')}</Typography>
                  </>
                ) : testResult.error}
              </Alert>
            )}
          </Stack>
        </Paper>
      )}

      {/* ── Row policy dialog ─────────────────────────────────────────── */}
      <Dialog open={rowDialog} onClose={() => setRowDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>New Row Policy</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" value={rowForm.name}
              onChange={(e) => setRowForm({ ...rowForm, name: e.target.value })} />
            <TextField label="Table pattern (glob)" placeholder="orders OR public.orders OR db.*"
              value={rowForm.table_pattern}
              onChange={(e) => setRowForm({ ...rowForm, table_pattern: e.target.value })} />
            <TextField label="Filter SQL" placeholder="region IN ${user.groups}"
              multiline minRows={3}
              value={rowForm.filter_sql}
              onChange={(e) => setRowForm({ ...rowForm, filter_sql: e.target.value })}
              helperText="Use ${user.username}, ${user.role}, ${user.groups}, ${user.<attr>} to reference the caller." />
            <TextField label="Description"
              value={rowForm.description}
              onChange={(e) => setRowForm({ ...rowForm, description: e.target.value })} />
            <FormControl>
              <InputLabel>Enforcement</InputLabel>
              <Select label="Enforcement" value={rowForm.enforcement}
                onChange={(e) => setRowForm({ ...rowForm, enforcement: String(e.target.value) })}>
                {ENFORCEMENT_OPTIONS.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
              </Select>
            </FormControl>
            <FormControlLabel
              control={<Switch checked={rowForm.enabled}
                onChange={(e) => setRowForm({ ...rowForm, enabled: e.target.checked })} />}
              label="Enabled"
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRowDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={submitRowPolicy}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* ── Column policy dialog ──────────────────────────────────────── */}
      <Dialog open={colDialog} onClose={() => setColDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>New Column Policy</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" value={colForm.name}
              onChange={(e) => setColForm({ ...colForm, name: e.target.value })} />
            <TextField label="Table pattern" value={colForm.table_pattern}
              onChange={(e) => setColForm({ ...colForm, table_pattern: e.target.value })} />
            <FormControl>
              <InputLabel>Mode</InputLabel>
              <Select label="Mode" value={colForm.mode}
                onChange={(e) => setColForm({ ...colForm, mode: String(e.target.value) })}>
                {COLUMN_MODES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField label="Columns (comma-separated)" value={colForm.columns}
              onChange={(e) => setColForm({ ...colForm, columns: e.target.value })} />
            {colForm.mode === 'mask' && (
              <TextField label="Mask expression" placeholder="REGEXP_REPLACE(${col}, '@.*', '@***')"
                value={colForm.mask_expr}
                onChange={(e) => setColForm({ ...colForm, mask_expr: e.target.value })}
                helperText="Use ${col} to reference the column being masked." />
            )}
            <FormControl>
              <InputLabel>Enforcement</InputLabel>
              <Select label="Enforcement" value={colForm.enforcement}
                onChange={(e) => setColForm({ ...colForm, enforcement: String(e.target.value) })}>
                {ENFORCEMENT_OPTIONS.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
              </Select>
            </FormControl>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setColDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={submitColPolicy}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* ── Binding dialog ────────────────────────────────────────────── */}
      <Dialog open={bindDialog} onClose={() => setBindDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>New Binding</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <FormControl>
              <InputLabel>Policy kind</InputLabel>
              <Select label="Policy kind" value={bindForm.policy_kind}
                onChange={(e) => setBindForm({ ...bindForm, policy_kind: String(e.target.value) })}>
                <MenuItem value="row">row</MenuItem>
                <MenuItem value="column">column</MenuItem>
              </Select>
            </FormControl>
            <TextField label="Policy ID" type="number"
              value={bindForm.policy_id || ''}
              onChange={(e) => setBindForm({ ...bindForm, policy_id: Number(e.target.value) || 0 })} />
            <FormControl>
              <InputLabel>Principal type</InputLabel>
              <Select label="Principal type" value={bindForm.principal_type}
                onChange={(e) => setBindForm({ ...bindForm, principal_type: String(e.target.value) })}>
                {PRINCIPAL_TYPES.map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField label="Principal ID"
              placeholder='username for "user", role name for "role", group name for "group", "*" for all'
              value={bindForm.principal_id}
              onChange={(e) => setBindForm({ ...bindForm, principal_id: e.target.value })} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBindDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={submitBinding}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* ── LF sync dialog ────────────────────────────────────────────── */}
      <Dialog open={syncDialog} onClose={() => setSyncDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Sync from AWS Lake Formation</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Alert severity="info">
              Imports LF data-cells filters into <code>row_level_policies</code> with
              <code> source='lake_formation'</code>.  Bindings derive from LF Permissions.
            </Alert>
            <TextField label="Connection ID" type="number"
              value={syncForm.connection_id}
              onChange={(e) => setSyncForm({ ...syncForm, connection_id: e.target.value })} />
            <TextField label="Databases (optional, comma-separated)"
              value={syncForm.databases}
              onChange={(e) => setSyncForm({ ...syncForm, databases: e.target.value })}
              helperText="Empty = all Glue databases reachable by this connection's AWS credentials." />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSyncDialog(false)}>Cancel</Button>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={runLfSync}>Run sync</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default RowSecurityAdminSection;
