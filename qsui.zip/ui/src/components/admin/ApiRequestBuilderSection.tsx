/**
 * API Request Builder — generic Postman/Insomnia-style endpoint runner.
 *
 * Why this exists:
 *   Operators kept hitting auth-token friction when trying curl from
 *   the shell.  Swagger at /api-docs is too verbose; ApiExplorerPage is
 *   Published-Views–specific.  This panel lets you fire ANY backend
 *   endpoint with the SAME session cookie the rest of the app uses —
 *   zero token paste, zero CORS dance.
 *
 * What it does:
 *   * Method dropdown (GET/POST/PUT/PATCH/DELETE)
 *   * URL field (relative paths preferred — they auto-prepend API_BASE_URL)
 *   * Key-value editors for query params + custom headers
 *   * JSON body editor (hidden on GET)
 *   * Quick-pick presets for the admin endpoints operators use most
 *   * Response panel: status chip + latency + pretty-JSON body + headers
 *   * Last-20 history persisted to localStorage (click to reload)
 *
 * Auth model:
 *   Uses ``fetch(url, { credentials: 'include' })`` so the session cookie
 *   the SPA already holds attaches automatically — no Authorization header
 *   to copy.  401 from the backend means your QS session expired; log
 *   back in via the normal Login page.
 */
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, Stack, Chip, Alert, TextField, Select,
  MenuItem, FormControl, InputLabel, IconButton, Tooltip, Tabs, Tab,
  Divider, List, ListItemButton, ListItemText, CircularProgress,
} from '@mui/material';
import {
  Send as SendIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  ContentCopy as CopyIcon,
  History as HistoryIcon,
  Bookmark as BookmarkIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { API_BASE_URL } from '../../services/api/core';
import { getAuthHeader } from '../../services/authState';


// ── Types ────────────────────────────────────────────────────────────────

type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

interface KvPair { id: string; key: string; value: string; enabled: boolean; }

interface RequestSnapshot {
  method: HttpMethod;
  path: string;
  queryParams: KvPair[];
  headers: KvPair[];
  body: string;
}

interface HistoryEntry extends RequestSnapshot {
  ts: number;
  status?: number;
  durationMs?: number;
}

interface ResponseInfo {
  status: number;
  statusText: string;
  durationMs: number;
  headers: Record<string, string>;
  bodyText: string;
  bodyJson?: unknown;
}


// ── Presets — admin endpoints operators hit most ─────────────────────────

const PRESETS: { label: string; method: HttpMethod; path: string; body?: string }[] = [
  // Per-query diagnostic (Recommended first stop for "why was my query slow?")
  { label: '🔎 Query diagnostic — last 10 queries (RECOMMENDED)',
    method: 'GET', path: '/api/admin/queries/diagnose/recent?limit=10' },
  { label: '🔎 Query diagnostic — one query by execution_id',
    method: 'GET', path: '/api/admin/queries/diagnose/REPLACE_WITH_EXECUTION_ID' },
  // Pruning history (Phase H/I) — per-table file counts + stage drops + filter breakdown
  { label: '📉 Pruning history — last 100 iceberg reads',
    method: 'GET', path: '/api/admin/queries/pruning-history?limit=100' },
  { label: '📉 Pruning history — one query by execution_id',
    method: 'GET', path: '/api/admin/queries/pruning-history?execution_id=REPLACE_WITH_EXECUTION_ID' },
  // Iceberg manifest watcher (Phase C)
  { label: '⏱ Iceberg watcher — current status + recent changes',
    method: 'GET', path: '/api/admin/iceberg-watcher/status' },
  { label: '⏱ Iceberg watcher — force tick now',
    method: 'POST', path: '/api/admin/iceberg-watcher/run' },
  { label: '⚙ Iceberg watcher — list all settings (with descriptions)',
    method: 'GET', path: '/api/admin/iceberg-watcher/settings' },
  { label: '⚙ Iceberg watcher — update setting (e.g. enable db_first)',
    method: 'PATCH', path: '/api/admin/iceberg-watcher/settings/iceberg_db_first.enabled',
    body: JSON.stringify({ value: true }, null, 2) },
  { label: '⚙ Iceberg watcher — update interval seconds',
    method: 'PATCH', path: '/api/admin/iceberg-watcher/settings/iceberg_watcher.interval_seconds',
    body: JSON.stringify({ value: 1800 }, null, 2) },
  { label: '🔎 Pruning probe — dry-run filters against a table (no query)',
    method: 'POST', path: '/api/admin/queries/pruning-probe',
    body: JSON.stringify({ connection_id: 1, bucket: 'YOUR_BUCKET',
      table_prefix: 'path/to/table',
      filters: [ { column: 'business_close_date', operator: '=', value: '2025-09-30' } ],
    }, null, 2) },
  // ── BRAIN DIAGNOSTIC (Phase A–Q) — full visibility into the pruning chain ──
  { label: '🧠 BRAIN — UNIFIED scan-plan for execution_id (Phase P — RECOMMENDED)',
    method: 'GET', path: '/api/admin/queries/scan-plan/REPLACE_WITH_EXECUTION_ID' },
  { label: '🧠 BRAIN — recent scan plans (in-mem + DB combined)',
    method: 'GET', path: '/api/admin/queries/scan-plan-recent?limit=20' },
  { label: '🧠 BRAIN — pruning-history for execution_id (legacy per-table view)',
    method: 'GET', path: '/api/admin/queries/pruning-history?execution_id=REPLACE_WITH_EXECUTION_ID' },
  { label: '🧠 BRAIN — iceberg sync status (all watched tables, last snapshot)',
    method: 'GET', path: '/api/admin/iceberg-sync/status' },
  { label: '🧠 BRAIN — kick a sync now (refresh all supplement bounds)',
    method: 'POST', path: '/api/admin/iceberg-sync/run' },
  { label: '🧠 BRAIN — refresh ONE table\'s supplement + manifest cache',
    method: 'POST', path: '/api/admin/iceberg-sync/refresh-table',
    body: JSON.stringify({ connection_id: 1, table_name: 'YOUR_TABLE' }, null, 2) },
  { label: '🧠 BRAIN — column-stats status (which cols cached per table)',
    method: 'GET', path: '/api/admin/iceberg/column-stats/status' },
  { label: '🧠 BRAIN — snapshot cache stats (L1 in-process cache size)',
    method: 'GET', path: '/api/admin/iceberg-snapshot-cache/stats' },
  { label: '🧠 BRAIN — snapshot cache LIST (what tables are warm)',
    method: 'GET', path: '/api/admin/iceberg-snapshot-cache/list' },
  { label: '🧠 BRAIN — snapshot cache inspect ONE entry',
    method: 'GET', path: '/api/admin/iceberg-snapshot-cache/inspect?connection_id=1&table_prefix=YOUR_PREFIX' },
  { label: '🧠 BRAIN — verify snapshot integrity (compare manifest vs cache)',
    method: 'POST', path: '/api/admin/iceberg-snapshot-cache/verify',
    body: JSON.stringify({ connection_id: 1, table_prefix: 'YOUR_PREFIX' }, null, 2) },
  { label: '🧠 BRAIN — column-stats SCAN one table now (populate supplement)',
    method: 'POST', path: '/api/admin/iceberg/column-stats/scan',
    body: JSON.stringify({ connection_id: 1, bucket: 'YOUR_BUCKET',
      table_prefix: 'path/to/table', columns: null, max_files: 0 }, null, 2) },
  { label: '🧠 BRAIN — bootstrap rule for a table (which cols to auto-scan)',
    method: 'POST', path: '/api/admin/iceberg-sync/column-stats-rule',
    body: JSON.stringify({ table: 'YOUR_TABLE', enabled: true,
      columns: ['business_close_date', 'system_id'] }, null, 2) },
  { label: '🧠 BRAIN — pin a watched table (force sync regardless of usage)',
    method: 'POST', path: '/api/admin/iceberg-sync/watched',
    body: JSON.stringify({ connection_id: 1, bucket: 'YOUR_BUCKET',
      table_prefix: 'path/to/table', pinned: true }, null, 2) },
  { label: '🧠 BRAIN — cache stats (all iceberg L1/L2 caches)',
    method: 'GET', path: '/api/admin/iceberg-cache/stats' },
  { label: '🧠 BRAIN — clear iceberg cache (force fresh reads)',
    method: 'DELETE', path: '/api/admin/iceberg-cache/clear' },
  // Resource admission
  { label: '🛡 System resources — live RAM/CPU snapshot',
    method: 'GET', path: '/api/admin/system-resources' },
  { label: '🛡 Admission test — what would happen if I run X files now?',
    method: 'POST', path: '/api/admin/queries/admission-test',
    body: JSON.stringify({ file_count: 2800, n_workers: 4, per_worker_mem_mb: 2048 }, null, 2) },
  // Column stats supplement
  { label: '📊 Column stats — what is cached + last scan times',
    method: 'GET', path: '/api/admin/iceberg/column-stats/status' },
  // Pruning observability
  { label: 'Iceberg sync — status (all tables)', method: 'GET', path: '/api/admin/iceberg-sync/status' },
  { label: 'Iceberg snapshot cache — stats',     method: 'GET', path: '/api/admin/iceberg-snapshot-cache/stats' },
  { label: 'Iceberg snapshot cache — list',      method: 'GET', path: '/api/admin/iceberg-snapshot-cache/list' },
  { label: 'Iceberg sync — refresh ONE table',   method: 'POST', path: '/api/admin/iceberg-sync/refresh-table',
    body: JSON.stringify({ connection_id: 1, table_name: 'YOUR_TABLE' }, null, 2) },
  { label: 'Iceberg sync — column-stats rule',   method: 'POST', path: '/api/admin/iceberg-sync/column-stats-rule',
    body: JSON.stringify({ table: 'YOUR_TABLE', enabled: true, columns: ['business_date', 'region'] }, null, 2) },
  // Scan strategy
  { label: 'Scan strategy — current config',     method: 'GET', path: '/api/admin/scan-strategy/config' },
  { label: 'Scan strategy — update',             method: 'PUT', path: '/api/admin/scan-strategy/config',
    body: JSON.stringify({ profile: 'auto', prewarm: { enabled: true } }, null, 2) },
  // S3 readers
  { label: 'S3 readers — status',                method: 'GET', path: '/api/admin/s3-readers/status' },
  { label: 'S3 readers — telemetry',             method: 'GET', path: '/api/admin/s3-readers/telemetry' },
  // Spark Connect
  { label: 'Spark Connect — status',             method: 'GET', path: '/api/admin/spark-connect/status' },
  { label: 'Spark Connect — test (SELECT 1)',    method: 'POST', path: '/api/admin/spark-connect/test' },
  { label: 'Spark Connect — reset breaker',      method: 'POST', path: '/api/admin/spark-connect/circuit-breaker/reset' },
  // Execution / health
  { label: 'System — health',                    method: 'GET', path: '/api/admin/health' },
  { label: 'System — config get section',        method: 'GET', path: '/api/admin/config?section=scan_strategy' },
];


// ── Helpers ──────────────────────────────────────────────────────────────

const HISTORY_KEY = 'qs.adminApiBuilder.history.v1';
const SAVED_KEY   = 'qs.adminApiBuilder.saved.v1';
const HISTORY_MAX = 20;

const newPair = (): KvPair => ({
  id: Math.random().toString(36).slice(2),
  key: '', value: '', enabled: true,
});

const emptySnapshot = (): RequestSnapshot => ({
  method: 'GET',
  path: '/api/admin/iceberg-sync/status',
  queryParams: [newPair()],
  headers: [{ ...newPair(), key: 'Content-Type', value: 'application/json' }],
  body: '',
});

const loadHistory = (): HistoryEntry[] => {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
  catch { return []; }
};
const saveHistory = (h: HistoryEntry[]) =>
  localStorage.setItem(HISTORY_KEY, JSON.stringify(h.slice(0, HISTORY_MAX)));

const buildFullUrl = (path: string, params: KvPair[]): string => {
  const enabled = params.filter(p => p.enabled && p.key.trim());
  const qs = enabled
    .map(p => `${encodeURIComponent(p.key)}=${encodeURIComponent(p.value)}`)
    .join('&');
  const sep = qs ? (path.includes('?') ? '&' : '?') : '';
  // Relative paths get API_BASE_URL prefix.  Absolute URLs pass through.
  const base = path.startsWith('http') ? path : `${API_BASE_URL}${path}`;
  return `${base}${sep}${qs}`;
};

const prettyJson = (raw: string): { json?: unknown; text: string } => {
  try { return { json: JSON.parse(raw), text: JSON.stringify(JSON.parse(raw), null, 2) }; }
  catch { return { text: raw }; }
};

const statusColor = (status: number): 'success' | 'warning' | 'error' | 'default' => {
  if (status >= 200 && status < 300) return 'success';
  if (status >= 300 && status < 400) return 'default';
  if (status >= 400 && status < 500) return 'warning';
  if (status >= 500) return 'error';
  return 'default';
};


// ── KV pair editor ───────────────────────────────────────────────────────

const KvEditor: React.FC<{
  rows: KvPair[];
  onChange: (rows: KvPair[]) => void;
  placeholderKey?: string;
  placeholderValue?: string;
}> = ({ rows, onChange, placeholderKey = 'key', placeholderValue = 'value' }) => {
  const update = (id: string, patch: Partial<KvPair>) =>
    onChange(rows.map(r => (r.id === id ? { ...r, ...patch } : r)));
  const remove = (id: string) =>
    onChange(rows.filter(r => r.id !== id));
  const add = () => onChange([...rows, newPair()]);
  return (
    <Stack spacing={1}>
      {rows.map(r => (
        <Stack key={r.id} direction="row" spacing={1} alignItems="center">
          <TextField
            size="small" placeholder={placeholderKey} value={r.key}
            onChange={e => update(r.id, { key: e.target.value })}
            sx={{ flex: 1 }}
          />
          <TextField
            size="small" placeholder={placeholderValue} value={r.value}
            onChange={e => update(r.id, { value: e.target.value })}
            sx={{ flex: 2 }}
          />
          <Tooltip title={r.enabled ? 'Disable' : 'Enable'}>
            <Chip
              size="small" label={r.enabled ? 'on' : 'off'}
              color={r.enabled ? 'primary' : 'default'}
              onClick={() => update(r.id, { enabled: !r.enabled })}
            />
          </Tooltip>
          <IconButton size="small" onClick={() => remove(r.id)}>
            <DeleteIcon fontSize="small" />
          </IconButton>
        </Stack>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={add} sx={{ alignSelf: 'flex-start' }}>
        Add row
      </Button>
    </Stack>
  );
};


// ── Main section component ──────────────────────────────────────────────

const ApiRequestBuilderSection: React.FC = () => {
  const [snap, setSnap] = useState<RequestSnapshot>(emptySnapshot);
  const [tab, setTab] = useState<'params' | 'headers' | 'body' | 'presets' | 'history'>('params');
  const [running, setRunning] = useState(false);
  const [response, setResponse] = useState<ResponseInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [responseTab, setResponseTab] = useState<'body' | 'headers' | 'raw'>('body');
  const [history, setHistory] = useState<HistoryEntry[]>(loadHistory);

  const previewUrl = useMemo(
    () => buildFullUrl(snap.path, snap.queryParams),
    [snap.path, snap.queryParams],
  );

  const send = useCallback(async () => {
    setRunning(true); setError(null); setResponse(null);
    const t0 = performance.now();
    try {
      const url = previewUrl;
      // Start from the auth headers the rest of the app uses (Bearer
      // token from authState + workspace + request id), then overlay
      // the user's custom headers so they can override if needed.
      // This matches safeFetch in services/api/core.ts.
      const headerObj: Record<string, string> = {};
      const authHeader = getAuthHeader();
      if (authHeader) headerObj['Authorization'] = authHeader;
      const wsId = localStorage.getItem('qs_workspace_id');
      if (wsId) headerObj['X-Workspace-ID'] = wsId;
      headerObj['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
      // User-supplied headers overlay last so they can override (e.g.
      // bypass content type or test a different Authorization).
      snap.headers.filter(h => h.enabled && h.key.trim()).forEach(h => {
        headerObj[h.key] = h.value;
      });
      const isGet = snap.method === 'GET';
      const init: RequestInit = {
        method: snap.method,
        credentials: 'include',                    // for any cookie-mode endpoints
        headers: headerObj,
      };
      if (!isGet && snap.body.trim()) init.body = snap.body;
      const resp = await fetch(url, init);
      const dur = Math.round(performance.now() - t0);
      const bodyText = await resp.text();
      const respHeaders: Record<string, string> = {};
      resp.headers.forEach((v, k) => { respHeaders[k] = v; });
      const { json, text } = prettyJson(bodyText);
      const info: ResponseInfo = {
        status: resp.status,
        statusText: resp.statusText,
        durationMs: dur,
        headers: respHeaders,
        bodyText: text,
        bodyJson: json,
      };
      setResponse(info);
      // Persist to history
      const entry: HistoryEntry = { ...snap, ts: Date.now(), status: resp.status, durationMs: dur };
      const next = [entry, ...history].slice(0, HISTORY_MAX);
      setHistory(next); saveHistory(next);
    } catch (e: any) {
      setError(`Network error: ${e?.message || String(e)}`);
    } finally {
      setRunning(false);
    }
  }, [snap, previewUrl, history]);

  const loadHistoryEntry = (entry: HistoryEntry) => {
    const { ts: _ts, status: _s, durationMs: _d, ...rest } = entry;
    setSnap(rest);
    setTab('params');
  };

  const loadPreset = (p: typeof PRESETS[number]) => {
    setSnap({
      method: p.method,
      path: p.path,
      queryParams: [newPair()],
      headers: [{ ...newPair(), key: 'Content-Type', value: 'application/json' }],
      body: p.body || '',
    });
    setTab(p.body ? 'body' : 'params');
  };

  const copyAsCurl = () => {
    // Include the in-memory Bearer + workspace headers so the copied
    // command actually authenticates outside the browser.
    const auth = getAuthHeader();
    const wsId = localStorage.getItem('qs_workspace_id');
    const autoHeaders: string[] = [];
    if (auth) autoHeaders.push(`-H 'Authorization: ${auth}'`);
    if (wsId) autoHeaders.push(`-H 'X-Workspace-ID: ${wsId}'`);
    const userHeaders = snap.headers.filter(h => h.enabled && h.key.trim())
      .map(h => `-H '${h.key}: ${h.value}'`);
    const methodArg = snap.method === 'GET' ? '' : `-X ${snap.method}`;
    const bodyArg = (!['GET'].includes(snap.method) && snap.body.trim())
      ? `--data '${snap.body.replace(/'/g, `'\\''`)}'`
      : '';
    const curl = `curl -s ${methodArg} ${[...autoHeaders, ...userHeaders].join(' ')} ${bodyArg} '${previewUrl}'`
      .replace(/\s+/g, ' ').trim();
    navigator.clipboard.writeText(curl);
  };

  return (
    <Box sx={{ display: 'flex', gap: 2, flexDirection: { xs: 'column', md: 'row' } }}>

      {/* ── Left: request builder + response ──────────────────────────── */}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" sx={{ mb: 1 }}>API Request Builder</Typography>
          <Typography variant="caption" color="text.secondary">
            Auto-attaches the same Bearer token + workspace headers the rest of
            the SPA uses (from your in-memory login). Relative paths
            auto-prepend <code>{API_BASE_URL}</code>.
          </Typography>

          {/* Method + URL row */}
          <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
            <FormControl size="small" sx={{ minWidth: 100 }}>
              <InputLabel>Method</InputLabel>
              <Select
                value={snap.method} label="Method"
                onChange={e => setSnap(s => ({ ...s, method: e.target.value as HttpMethod }))}
              >
                {(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] as HttpMethod[]).map(m => (
                  <MenuItem key={m} value={m}>{m}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              size="small" fullWidth value={snap.path}
              onChange={e => setSnap(s => ({ ...s, path: e.target.value }))}
              placeholder="/api/admin/iceberg-sync/status"
              onKeyDown={e => { if (e.key === 'Enter' && !running) send(); }}
            />
            <Button
              variant="contained" startIcon={running ? <CircularProgress size={16} color="inherit" /> : <SendIcon />}
              onClick={send} disabled={running}
            >
              {running ? 'Sending' : 'Send'}
            </Button>
          </Stack>

          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, wordBreak: 'break-all' }}>
            → {previewUrl}
          </Typography>

          {/* Request tabs */}
          <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mt: 2, borderBottom: 1, borderColor: 'divider' }}>
            <Tab value="params" label={`Query Params (${snap.queryParams.filter(p => p.enabled && p.key).length})`} />
            <Tab value="headers" label={`Headers (${snap.headers.filter(h => h.enabled && h.key).length})`} />
            <Tab value="body" label="Body" disabled={snap.method === 'GET'} />
            <Tab value="presets" label="Presets" icon={<BookmarkIcon fontSize="small" />} iconPosition="start" />
            <Tab value="history" label={`History (${history.length})`} icon={<HistoryIcon fontSize="small" />} iconPosition="start" />
          </Tabs>

          <Box sx={{ mt: 2, minHeight: 180 }}>
            {tab === 'params' && (
              <KvEditor
                rows={snap.queryParams}
                onChange={r => setSnap(s => ({ ...s, queryParams: r }))}
              />
            )}
            {tab === 'headers' && (
              <KvEditor
                rows={snap.headers}
                onChange={r => setSnap(s => ({ ...s, headers: r }))}
                placeholderKey="Header" placeholderValue="value"
              />
            )}
            {tab === 'body' && (
              <TextField
                multiline minRows={8} fullWidth value={snap.body}
                onChange={e => setSnap(s => ({ ...s, body: e.target.value }))}
                placeholder='{ "key": "value" }'
                sx={{ fontFamily: 'monospace' }}
                InputProps={{ sx: { fontFamily: 'monospace', fontSize: 13 } }}
              />
            )}
            {tab === 'presets' && (
              <List dense sx={{ maxHeight: 320, overflow: 'auto' }}>
                {PRESETS.map((p, i) => (
                  <ListItemButton key={i} onClick={() => loadPreset(p)}>
                    <Chip
                      label={p.method} size="small"
                      color={p.method === 'GET' ? 'primary' : 'secondary'}
                      sx={{ mr: 1, minWidth: 56 }}
                    />
                    <ListItemText primary={p.label} secondary={p.path} />
                  </ListItemButton>
                ))}
              </List>
            )}
            {tab === 'history' && (
              <Box>
                {history.length === 0 && (
                  <Typography variant="caption" color="text.secondary">
                    No requests yet — send one to populate.
                  </Typography>
                )}
                <List dense sx={{ maxHeight: 320, overflow: 'auto' }}>
                  {history.map((h, i) => (
                    <ListItemButton key={i} onClick={() => loadHistoryEntry(h)}>
                      <Chip
                        label={h.method} size="small"
                        color={h.method === 'GET' ? 'primary' : 'secondary'}
                        sx={{ mr: 1, minWidth: 56 }}
                      />
                      <ListItemText
                        primary={h.path}
                        secondary={`${h.status ?? '?'} · ${h.durationMs ?? '?'}ms · ${new Date(h.ts).toLocaleTimeString()}`}
                      />
                    </ListItemButton>
                  ))}
                </List>
                {history.length > 0 && (
                  <Button size="small" startIcon={<DeleteIcon />}
                    onClick={() => { setHistory([]); saveHistory([]); }}>
                    Clear history
                  </Button>
                )}
              </Box>
            )}
          </Box>

          <Box sx={{ mt: 1, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            <Button size="small" startIcon={<CopyIcon />} onClick={copyAsCurl}>
              Copy as curl
            </Button>
            <Button size="small" startIcon={<RefreshIcon />} onClick={() => setSnap(emptySnapshot())}>
              Reset
            </Button>
          </Box>
        </Paper>

        {/* ── Response panel ──────────────────────────────────────────── */}
        <Paper sx={{ p: 2, mt: 2 }}>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="h6">Response</Typography>
            {response && (
              <>
                <Chip
                  label={`${response.status} ${response.statusText}`}
                  color={statusColor(response.status)} size="small"
                />
                <Chip label={`${response.durationMs} ms`} size="small" variant="outlined" />
              </>
            )}
          </Stack>

          {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}

          {!response && !error && (
            <Typography variant="caption" color="text.secondary">
              Click Send to fire the request.
            </Typography>
          )}

          {response && (
            <>
              <Tabs value={responseTab} onChange={(_, v) => setResponseTab(v)} sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tab value="body" label="Body" />
                <Tab value="headers" label={`Headers (${Object.keys(response.headers).length})`} />
                <Tab value="raw" label="Raw" />
              </Tabs>
              <Box sx={{ mt: 1 }}>
                {responseTab === 'body' && (
                  <Box component="pre" sx={{
                    background: '#1a202c', color: '#e2e8f0',
                    p: 2, borderRadius: 1, overflow: 'auto',
                    maxHeight: 480, fontSize: 12,
                    fontFamily: '"Consolas", "Monaco", monospace',
                  }}>
                    {response.bodyText || '(empty)'}
                  </Box>
                )}
                {responseTab === 'headers' && (
                  <Box sx={{ maxHeight: 320, overflow: 'auto' }}>
                    {Object.entries(response.headers).map(([k, v]) => (
                      <Stack key={k} direction="row" spacing={1} sx={{ py: 0.5, borderBottom: '1px solid #eee' }}>
                        <Typography variant="caption" sx={{ minWidth: 200, fontWeight: 600 }}>{k}</Typography>
                        <Typography variant="caption" sx={{ wordBreak: 'break-all' }}>{v}</Typography>
                      </Stack>
                    ))}
                  </Box>
                )}
                {responseTab === 'raw' && (
                  <Box component="pre" sx={{
                    background: '#1a202c', color: '#e2e8f0',
                    p: 2, borderRadius: 1, overflow: 'auto',
                    maxHeight: 480, fontSize: 11,
                    fontFamily: '"Consolas", "Monaco", monospace',
                  }}>
{`HTTP/1.1 ${response.status} ${response.statusText}\n${Object.entries(response.headers).map(([k, v]) => `${k}: ${v}`).join('\n')}\n\n${response.bodyText}`}
                  </Box>
                )}
              </Box>
            </>
          )}
        </Paper>
      </Box>
    </Box>
  );
};

export default ApiRequestBuilderSection;
