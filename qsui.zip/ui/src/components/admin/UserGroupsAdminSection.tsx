/**
 * User Groups Admin Section — Phase 130 hotfix-13.
 *
 * Manage entitlement groups and per-member resource access flavour.
 * Replaces the legacy "ownership = full access" model with explicit
 * read_only / read_write per member.
 *
 * No hardcoded role names — the support role label is fetched from
 * /api/app-settings so a rename in DB is reflected here.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  MenuItem,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import EmailIcon from '@mui/icons-material/Email';
import GroupIcon from '@mui/icons-material/Group';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import LockIcon from '@mui/icons-material/Lock';
import RefreshIcon from '@mui/icons-material/Refresh';
import { safeFetch } from '../../services/api/core';

// ── Types ─────────────────────────────────────────────────────────────────

interface UserGroup {
  id:                 number;
  name:               string;
  description:        string | null;
  is_active:          boolean;
  notification_email: string | null;
  created_by:         string | null;
  created_at:         string | null;
  updated_at:         string | null;
}

interface UserGroupMember {
  id:                     number;
  group_id:               number;
  username:               string;
  role_in_group:          string;    // 'member' | 'owner' | 'admin'
  resource_access_level:  string;    // 'read_only' | 'read_write'
  added_by:               string | null;
  added_at:               string | null;
}

interface GroupDraft {
  name:               string;
  description:        string;
  notification_email: string;
  is_active:          boolean;
}

// ── Component ─────────────────────────────────────────────────────────────

export const UserGroupsAdminSection: React.FC = () => {
  const [groups, setGroups]                     = useState<UserGroup[]>([]);
  const [selectedGroup, setSelectedGroup]       = useState<UserGroup | null>(null);
  const [members, setMembers]                   = useState<UserGroupMember[]>([]);
  const [loading, setLoading]                   = useState(false);
  const [membersLoading, setMembersLoading]     = useState(false);
  const [error, setError]                       = useState<string | null>(null);
  const [success, setSuccess]                   = useState<string | null>(null);

  // Edit dialog state
  const [editOpen, setEditOpen] = useState(false);
  const [editDraft, setEditDraft] = useState<GroupDraft>({
    name: '', description: '', notification_email: '', is_active: true,
  });
  const [editGroupId, setEditGroupId] = useState<number | null>(null);

  // Add-member input
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('member');
  const [newMemberAccess, setNewMemberAccess] = useState('read_write');

  // Phase 131 deep-dive #6 — user catalogue from activity history.
  // Source: /api/admin/users/known — distinct usernames from audit_log
  // (any action including login) + users already in groups.  Users are
  // auto-created on first login by the auth layer; admin doesn't add
  // them manually, just maps them to groups.
  type KnownUser = {
    username:  string;
    last_seen: string | null;   // ISO timestamp; null = never logged in but in some group
    in_groups: number;          // count of groups this user is already in
  };
  const [knownUsers, setKnownUsers] = useState<KnownUser[]>([]);

  // Per-user reverse lookup — pick a username, see all their group
  // memberships across the entire system.  Closes the "I can't see
  // user-to-group mapping" UX gap.
  const [reverseLookupUser, setReverseLookupUser] = useState<string>('');
  const [reverseLookupGroups, setReverseLookupGroups] = useState<UserGroup[]>([]);
  const [reverseLookupLoading, setReverseLookupLoading] = useState(false);

  // ── Loaders ───────────────────────────────────────────────────────────

  const loadGroups = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await safeFetch('/api/admin/user-groups') as UserGroup[];
      setGroups(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  // Load the user catalogue once — powers the Autocomplete picker in
  // both Add-Member and Per-User-View.  Source: /api/admin/users/known
  // which reads activity history (audit_log) + existing memberships.
  // Fail-open: when the endpoint is unavailable, the Autocomplete just
  // behaves like a free-text input (admin can still type a username).
  const loadUsers = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/users/known') as
        { items: KnownUser[]; count: number };
      setKnownUsers(Array.isArray(data?.items) ? data.items : []);
    } catch {
      setKnownUsers([]);
    }
  }, []);

  const loadGroupsForUser = useCallback(async (username: string) => {
    if (!username.trim()) {
      setReverseLookupGroups([]);
      return;
    }
    setReverseLookupLoading(true);
    try {
      const data = await safeFetch(
        `/api/admin/users/${encodeURIComponent(username.trim())}/groups`,
      ) as UserGroup[];
      setReverseLookupGroups(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setReverseLookupGroups([]);
    } finally {
      setReverseLookupLoading(false);
    }
  }, []);

  const loadMembers = useCallback(async (groupId: number) => {
    setMembersLoading(true);
    try {
      const data = await safeFetch(`/api/admin/user-groups/${groupId}/members`) as UserGroupMember[];
      setMembers(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setMembersLoading(false);
    }
  }, []);

  useEffect(() => { void loadGroups(); }, [loadGroups]);
  useEffect(() => { void loadUsers(); }, [loadUsers]);
  useEffect(() => {
    if (selectedGroup) { void loadMembers(selectedGroup.id); }
    else                { setMembers([]); }
  }, [selectedGroup, loadMembers]);

  // ── Group CRUD ────────────────────────────────────────────────────────

  const openCreate = () => {
    setEditGroupId(null);
    setEditDraft({ name: '', description: '', notification_email: '', is_active: true });
    setEditOpen(true);
  };

  const openEdit = (g: UserGroup) => {
    setEditGroupId(g.id);
    setEditDraft({
      name: g.name,
      description: g.description ?? '',
      notification_email: g.notification_email ?? '',
      is_active: g.is_active,
    });
    setEditOpen(true);
  };

  const saveGroup = useCallback(async () => {
    setError(null);
    try {
      const body = JSON.stringify({
        name: editDraft.name,
        description: editDraft.description || null,
        notification_email: editDraft.notification_email || null,
        is_active: editDraft.is_active,
      });
      if (editGroupId === null) {
        await safeFetch('/api/admin/user-groups', { method: 'POST', body });
        setSuccess(`Group "${editDraft.name}" created.`);
      } else {
        await safeFetch(`/api/admin/user-groups/${editGroupId}`, { method: 'PUT', body });
        setSuccess(`Group "${editDraft.name}" updated.`);
      }
      setEditOpen(false);
      await loadGroups();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [editDraft, editGroupId, loadGroups]);

  const deleteGroup = useCallback(async (g: UserGroup) => {
    if (!confirm(`Delete group "${g.name}" and all its memberships?`)) return;
    setError(null);
    try {
      await safeFetch(`/api/admin/user-groups/${g.id}`, { method: 'DELETE' });
      setSuccess(`Group "${g.name}" deleted.`);
      if (selectedGroup?.id === g.id) setSelectedGroup(null);
      await loadGroups();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [loadGroups, selectedGroup]);

  // ── Member CRUD ───────────────────────────────────────────────────────

  const addMember = useCallback(async () => {
    if (!selectedGroup || !newMemberName.trim()) return;
    setError(null);
    try {
      await safeFetch(`/api/admin/user-groups/${selectedGroup.id}/members`, {
        method: 'POST',
        body: JSON.stringify({
          username: newMemberName.trim(),
          role_in_group: newMemberRole,
          resource_access_level: newMemberAccess,
        }),
      });
      setSuccess(`Added ${newMemberName} to "${selectedGroup.name}".`);
      setNewMemberName('');
      await loadMembers(selectedGroup.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [selectedGroup, newMemberName, newMemberRole, newMemberAccess, loadMembers]);

  const updateMember = useCallback(async (m: UserGroupMember, updates: Partial<UserGroupMember>) => {
    setError(null);
    try {
      await safeFetch(`/api/admin/user-groups/${m.group_id}/members/${encodeURIComponent(m.username)}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      });
      await loadMembers(m.group_id);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [loadMembers]);

  const removeMember = useCallback(async (m: UserGroupMember) => {
    if (!confirm(`Remove ${m.username} from group?`)) return;
    setError(null);
    try {
      await safeFetch(`/api/admin/user-groups/${m.group_id}/members/${encodeURIComponent(m.username)}`, {
        method: 'DELETE',
      });
      await loadMembers(m.group_id);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [loadMembers]);

  // ── Render ────────────────────────────────────────────────────────────

  const groupsBy = useMemo(() => groups.filter(g => g.is_active), [groups]);

  return (
    <Paper sx={{ p: 3 }} elevation={1}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <Box>
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography variant="h6">User Groups &amp; Entitlements</Typography>
            <Tooltip title={
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }}>
                  "User Group" = "Entitlement Group" (same thing).
                </Typography>
                <Typography variant="caption" sx={{ display: 'block' }}>
                  Operational groups — orthogonal to app-level auth roles.  Attach a group
                  to a feed/report via <b>owner_group_id</b> and every member gets access
                  per their <b>resource_access_level</b> (read_only or read_write).
                </Typography>
                <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                  One user can be a member of MANY groups (data model:
                  UNIQUE(group_id, username) — max one row per user per group).
                </Typography>
                <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                  <b>Users are auto-created on first login</b> — admins don't add users,
                  they just map them into groups.  The picker below lists every user the
                  system has seen (audit_log) plus any pre-mapped to a group.
                </Typography>
              </Box>
            } arrow placement="bottom-start">
              <InfoOutlinedIcon fontSize="small" color="action" sx={{ cursor: 'help' }} />
            </Tooltip>
          </Stack>
          <Typography variant="body2" color="text.secondary">
            Create groups, map users (one user can join many groups), and control per-user
            access flavour (read-only vs read-write) on feeds and reports.  Group email is
            used for failure notifications.
          </Typography>
        </Box>
        <Stack direction="row" gap={1}>
          <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => void loadGroups()}>Refresh</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>New Group</Button>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      {loading ? (
        <Box display="flex" justifyContent="center" py={4}><CircularProgress /></Box>
      ) : (
        <Box>
          <Typography variant="subtitle2" gutterBottom>Groups ({groups.length})</Typography>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell width={40}></TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Notification email</TableCell>
                <TableCell>Active</TableCell>
                <TableCell>Created by</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {groupsBy.length === 0 && (
                <TableRow><TableCell colSpan={6}><em>No groups yet.</em></TableCell></TableRow>
              )}
              {groupsBy.map(g => (
                <TableRow key={g.id}
                          hover
                          selected={selectedGroup?.id === g.id}
                          onClick={() => setSelectedGroup(g)}
                          sx={{ cursor: 'pointer' }}>
                  <TableCell><GroupIcon fontSize="small" color={selectedGroup?.id === g.id ? 'primary' : 'inherit'} /></TableCell>
                  <TableCell>
                    <strong>{g.name}</strong>
                    {g.description && <Typography variant="caption" display="block" color="text.secondary">{g.description}</Typography>}
                  </TableCell>
                  <TableCell>
                    {g.notification_email ? (
                      <Tooltip title={g.notification_email}>
                        <Chip size="small" icon={<EmailIcon />} label={g.notification_email.split(',')[0]} variant="outlined" />
                      </Tooltip>
                    ) : <Typography variant="caption" color="text.secondary">—</Typography>}
                  </TableCell>
                  <TableCell>{g.is_active ? <Chip size="small" color="success" label="active" /> : <Chip size="small" label="inactive" />}</TableCell>
                  <TableCell><Typography variant="caption">{g.created_by ?? '—'}</Typography></TableCell>
                  <TableCell align="right">
                    <IconButton size="small" onClick={(e) => { e.stopPropagation(); openEdit(g); }}><EditIcon fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={(e) => { e.stopPropagation(); void deleteGroup(g); }}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {selectedGroup && (
            <Box mt={4}>
              <Typography variant="subtitle2" gutterBottom>
                Members of "{selectedGroup.name}" ({members.length})
              </Typography>
              <Box display="flex" gap={1} mb={1} flexWrap="wrap" alignItems="center">
                <Autocomplete
                  size="small"
                  options={knownUsers.map((u) => u.username)}
                  value={newMemberName || null}
                  onChange={(_e, v) => setNewMemberName(v || '')}
                  onInputChange={(_e, v) => setNewMemberName(v || '')}
                  freeSolo
                  sx={{ minWidth: 280 }}
                  renderOption={(props, option) => {
                    const ku = knownUsers.find((x) => x.username === option);
                    const lastSeen = ku?.last_seen
                      ? new Date(ku.last_seen).toLocaleDateString()
                      : 'never logged in';
                    return (
                      <li {...props} key={option}>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Typography variant="body2">{option}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            last seen {lastSeen}
                            {ku && ku.in_groups > 0 && ` · in ${ku.in_groups} group${ku.in_groups === 1 ? '' : 's'}`}
                          </Typography>
                        </Box>
                      </li>
                    );
                  }}
                  renderInput={(params) => (
                    <TextField {...params} label="Username"
                                placeholder={
                                  knownUsers.length > 0
                                    ? `Pick from ${knownUsers.length} known users…`
                                    : 'Type username (user added on first login)'
                                } />
                  )}
                />
                <TextField select size="small" label="Role in group"
                            value={newMemberRole}
                            onChange={(e) => setNewMemberRole(e.target.value)}
                            helperText="Group-internal membership authority"
                            sx={{ minWidth: 130 }}>
                  <MenuItem value="member">member</MenuItem>
                  <MenuItem value="owner">owner</MenuItem>
                  <MenuItem value="admin">admin</MenuItem>
                </TextField>
                <TextField select size="small" label="Resource access"
                            value={newMemberAccess}
                            onChange={(e) => setNewMemberAccess(e.target.value)}
                            helperText="Feed/report permission"
                            sx={{ minWidth: 150 }}>
                  <MenuItem value="read_only">read_only</MenuItem>
                  <MenuItem value="read_write">read_write</MenuItem>
                </TextField>
                <Button variant="contained" startIcon={<AddIcon />}
                  onClick={() => void addMember()}
                  disabled={!newMemberName.trim()}>
                  Add Member
                </Button>
              </Box>

              {membersLoading ? (
                <Box display="flex" justifyContent="center" py={3}><CircularProgress size={24} /></Box>
              ) : (
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Username</TableCell>
                      <TableCell>Role in group</TableCell>
                      <TableCell>Resource access</TableCell>
                      <TableCell>Added by</TableCell>
                      <TableCell align="right"></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {members.length === 0 && (
                      <TableRow><TableCell colSpan={5}><em>No members yet.</em></TableCell></TableRow>
                    )}
                    {members.map(m => (
                      <TableRow key={m.id}>
                        <TableCell><strong>{m.username}</strong></TableCell>
                        <TableCell>
                          <TextField select size="small"
                                      value={m.role_in_group}
                                      onChange={(e) => void updateMember(m, { role_in_group: e.target.value })}
                                      sx={{ minWidth: 100 }}>
                            <MenuItem value="member">member</MenuItem>
                            <MenuItem value="owner">owner</MenuItem>
                            <MenuItem value="admin">admin</MenuItem>
                          </TextField>
                        </TableCell>
                        <TableCell>
                          <Tooltip title={
                            m.resource_access_level === 'read_write'
                              ? 'Can view + edit + rerun group-owned feeds & reports'
                              : 'Can only view group-owned resources — cannot edit or rerun'
                          }>
                            <TextField select size="small"
                                        value={m.resource_access_level}
                                        onChange={(e) => void updateMember(m, { resource_access_level: e.target.value })}
                                        InputProps={{
                                          startAdornment: m.resource_access_level === 'read_only'
                                            ? <LockIcon fontSize="small" sx={{ mr: 0.5, color: 'warning.main' }} />
                                            : <LockOpenIcon fontSize="small" sx={{ mr: 0.5, color: 'success.main' }} />,
                                        }}
                                        sx={{ minWidth: 160 }}>
                              <MenuItem value="read_only">read_only</MenuItem>
                              <MenuItem value="read_write">read_write</MenuItem>
                            </TextField>
                          </Tooltip>
                        </TableCell>
                        <TableCell><Typography variant="caption">{m.added_by ?? '—'}</Typography></TableCell>
                        <TableCell align="right">
                          <IconButton size="small" color="error" onClick={() => void removeMember(m)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </Box>
          )}
        </Box>
      )}

      {/* ── Per-user reverse lookup (Phase 131 deep-dive #5) ── */}
      <Divider sx={{ my: 3 }} />
      <Box>
        <Stack direction="row" alignItems="center" spacing={1} mb={1}>
          <PersonSearchIcon color="primary" />
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            Per-user view — all groups for a user
          </Typography>
          <Tooltip title="Reverse lookup: pick a user, see every group they belong to.">
            <InfoOutlinedIcon fontSize="small" color="action" sx={{ cursor: 'help' }} />
          </Tooltip>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          A user can belong to many groups.  This panel shows all memberships for
          one user across the whole system — useful when triaging "why does X have
          access to feed Y?" or auditing a user's effective permissions.
        </Typography>
        <Box display="flex" gap={1} mb={1} flexWrap="wrap" alignItems="center">
          <Autocomplete
            size="small"
            options={knownUsers.map((u) => u.username)}
            value={reverseLookupUser || null}
            onChange={(_e, v) => {
              setReverseLookupUser(v || '');
              if (v) void loadGroupsForUser(v);
              else setReverseLookupGroups([]);
            }}
            onInputChange={(_e, v) => setReverseLookupUser(v || '')}
            freeSolo
            sx={{ minWidth: 320 }}
            renderOption={(props, option) => {
              const ku = knownUsers.find((x) => x.username === option);
              const lastSeen = ku?.last_seen
                ? new Date(ku.last_seen).toLocaleDateString()
                : 'never logged in';
              return (
                <li {...props} key={option}>
                  <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                    <Typography variant="body2">{option}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      last seen {lastSeen}
                      {ku && ku.in_groups > 0 && ` · in ${ku.in_groups} group${ku.in_groups === 1 ? '' : 's'}`}
                    </Typography>
                  </Box>
                </li>
              );
            }}
            renderInput={(params) => (
              <TextField {...params} label="Pick user"
                          placeholder={`Search ${knownUsers.length} users…`} />
            )}
          />
          <Button variant="outlined"
            onClick={() => reverseLookupUser && void loadGroupsForUser(reverseLookupUser)}
            disabled={!reverseLookupUser.trim() || reverseLookupLoading}>
            {reverseLookupLoading ? 'Loading…' : 'Show groups'}
          </Button>
        </Box>
        {reverseLookupUser && !reverseLookupLoading && (
          <Table size="small" sx={{ mt: 1 }}>
            <TableHead>
              <TableRow>
                <TableCell>Group</TableCell>
                <TableCell>Description</TableCell>
                <TableCell>Notification email</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {reverseLookupGroups.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4}>
                    <em>{reverseLookupUser} is not a member of any group.</em>
                  </TableCell>
                </TableRow>
              ) : reverseLookupGroups.map((g) => (
                <TableRow key={g.id} hover sx={{ cursor: 'pointer' }}
                  onClick={() => { setSelectedGroup(g); void loadMembers(g.id); }}>
                  <TableCell><strong>{g.name}</strong></TableCell>
                  <TableCell><Typography variant="caption">{g.description || ''}</Typography></TableCell>
                  <TableCell>
                    {g.notification_email
                      ? <Chip size="small" icon={<EmailIcon fontSize="small" />} label={g.notification_email} variant="outlined" />
                      : <Typography variant="caption" color="text.secondary">—</Typography>}
                  </TableCell>
                  <TableCell>
                    <Chip size="small" color={g.is_active ? 'success' : 'default'}
                      label={g.is_active ? 'active' : 'inactive'} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {reverseLookupGroups.length > 0 && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            Click any row to jump to that group's member list above.
          </Typography>
        )}
      </Box>

      {/* ── Group create/edit dialog ── */}
      <Dialog open={editOpen} onClose={() => setEditOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>{editGroupId === null ? 'New User Group' : `Edit group #${editGroupId}`}</DialogTitle>
        <DialogContent>
          <Stack gap={2} mt={1}>
            <TextField label="Name" required value={editDraft.name}
                        onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })} />
            <TextField label="Description" multiline minRows={2}
                        value={editDraft.description}
                        onChange={(e) => setEditDraft({ ...editDraft, description: e.target.value })} />
            <TextField label="Notification email"
                        helperText="Comma-separated emails — group-wide alerts on feed failure / SLA breach.  Leave blank to fall back to per-feed recipients."
                        value={editDraft.notification_email}
                        onChange={(e) => setEditDraft({ ...editDraft, notification_email: e.target.value })} />
            <TextField select label="Status"
                        value={editDraft.is_active ? 'active' : 'inactive'}
                        onChange={(e) => setEditDraft({ ...editDraft, is_active: e.target.value === 'active' })}>
              <MenuItem value="active">active</MenuItem>
              <MenuItem value="inactive">inactive</MenuItem>
            </TextField>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!editDraft.name.trim()} onClick={() => void saveGroup()}>Save</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default UserGroupsAdminSection;
