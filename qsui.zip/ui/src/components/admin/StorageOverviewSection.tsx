/**
 * Storage & Caches Overview — unified per-layer view of every cache + storage
 * subsystem on this pod.  Replaces the 8-section admin maze where each cache
 * had its own page but no single view answered "what is the storage footprint
 * of all caches on this pod, and which one is actually being used?"
 *
 * One table, one source of truth:
 *   Result Cache | Query Result Cache | Cache Layer (schema/partition/br) |
 *   Iceberg Snapshot Cache | Iceberg File Cache | Iceberg Column-Stats |
 *   S3 Local File Cache (NFS PVC, previously orphaned with no UI) |
 *   Aggregate Cache | AWS Portal Credential Cache.
 *
 * Each row reports: enabled? | entries | size on disk | hit rate | hits/misses
 * | a 'Clear' button when the layer supports it.
 *
 * Backend: GET /api/admin/storage-overview returns the uniform shape.  Per-
 * layer failures degrade independently — one broken cache never blanks the
 * whole page.
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Paper, Box, Typography, Button, Stack, LinearProgress, Alert, Chip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import BlockIcon from '@mui/icons-material/Block';
import ErrorIcon from '@mui/icons-material/Error';
import InfoIcon from '@mui/icons-material/InfoOutlined';
import { safeFetch } from '../../services/api/core';
import { fmtSize } from './adminUtils';
import StatCard from './StatCard';

interface Layer {
  key: string;
  name: string;
  status: 'ok' | 'disabled' | 'unavailable' | string;
  enabled: boolean;
  entries: number | null;
  size_bytes: number | null;
  hit_rate: number | null;
  hits: number | null;
  misses: number | null;
  extra: Record<string, any>;
  clear_url: string | null;
  clear_method: string;
  error?: string;
}

interface Overview {
  layers: Layer[];
  total_entries: number;
  total_size_bytes: number;
  layer_count: number;
  ok_count: number;
  unavailable_count: number;
}

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const fmtNum = (n: number | null | undefined): string =>
  (n == null) ? '—' : n.toLocaleString();

const fmtPct = (r: number | null | undefined): string => {
  if (r == null) return '—';
  return `${Math.round(r * 1000) / 10}%`;
};

const statusChip = (l: Layer) => {
  if (l.status === 'disabled' || !l.enabled) {
    return <Chip size="small" icon={<BlockIcon />} label="disabled" color="default" />;
  }
  if (l.status === 'unavailable') {
    return <Chip size="small" icon={<ErrorIcon />} label="unavailable" color="error" />;
  }
  return <Chip size="small" icon={<CheckCircleIcon />} label="ok" color="success" />;
};

const StorageOverviewSection: React.FC<Props> = ({ addNotification }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Overview | null>(null);
  const [clearTarget, setClearTarget] = useState<Layer | null>(null);
  const [extraTarget, setExtraTarget] = useState<Layer | null>(null);
  const [clearing, setClearing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await safeFetch('/api/admin/storage-overview');
      setData(d as Overview);
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Load failed',
        message: e?.message || 'storage-overview endpoint unavailable',
      });
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  useEffect(() => { load(); }, [load]);

  // Auto-refresh every 30s so admin sees changes from background eviction
  useEffect(() => {
    const t = setInterval(load, 30_000);
    return () => clearInterval(t);
  }, [load]);

  const handleClear = async () => {
    if (!clearTarget?.clear_url) return;
    setClearing(true);
    try {
      await safeFetch(clearTarget.clear_url, { method: clearTarget.clear_method as any });
      addNotification({
        type: 'success', title: 'Cleared',
        message: `${clearTarget.name} cleared`,
      });
      setClearTarget(null);
      load();
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Clear failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setClearing(false);
    }
  };

  // Largest layers — helpful for spotting the dominant storage consumer
  const topBySize = useMemo(() => {
    if (!data) return [];
    return [...data.layers]
      .filter(l => l.status === 'ok' && (l.size_bytes ?? 0) > 0)
      .sort((a, b) => (b.size_bytes ?? 0) - (a.size_bytes ?? 0))
      .slice(0, 3);
  }, [data]);

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Box>
          <Typography variant="h6">Storage & Caches Overview</Typography>
          <Typography variant="caption" color="text.secondary">
            One page, every cache layer.  Click a layer name for details, or use the
            individual section (Result Cache, Iceberg, etc.) for advanced editing.
          </Typography>
        </Box>
        <Button size="small" variant="outlined" startIcon={<RefreshIcon />} onClick={load}>
          Refresh
        </Button>
      </Box>

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {data && (
        <>
          {/* Top-line totals */}
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
            <StatCard label="Cache Layers" value={data.layer_count} />
            <StatCard label="OK" value={data.ok_count} />
            <StatCard label="Unavailable" value={data.unavailable_count}
              warn={data.unavailable_count > 0} />
            <StatCard label="Total Entries" value={fmtNum(data.total_entries)} />
            <StatCard label="Total On-Disk" value={fmtSize(data.total_size_bytes || 0)} />
          </Stack>

          {/* Dominant consumers — visible only when something has size */}
          {topBySize.length > 0 && (
            <Alert severity="info" sx={{ mb: 2 }}>
              <strong>Biggest storage consumers:</strong>{' '}
              {topBySize.map((l, i) => (
                <span key={l.key}>
                  {i > 0 ? ' · ' : ''}
                  <strong>{l.name}</strong> ({fmtSize(l.size_bytes || 0)})
                </span>
              ))}
            </Alert>
          )}

          {data.unavailable_count > 0 && (
            <Alert severity="warning" sx={{ mb: 2 }}>
              {data.unavailable_count} layer(s) reported errors.  Their rows are
              marked "unavailable" — check backend logs for the underlying cause.
              Other layers continue to work normally.
            </Alert>
          )}

          {/* The unified per-layer table */}
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Layer</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Entries</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Size</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Hit Rate</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Hits</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="right">Misses</TableCell>
                  <TableCell sx={{ fontWeight: 700 }} align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.layers.map(l => (
                  <TableRow key={l.key} hover
                    sx={{ opacity: l.status === 'unavailable' || l.status === 'disabled' ? 0.6 : 1 }}>
                    <TableCell sx={{ fontSize: '0.85rem' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Typography variant="body2" fontWeight={500}>{l.name}</Typography>
                        {Object.keys(l.extra || {}).length > 0 && (
                          <Tooltip title="Show layer-specific details">
                            <IconButton size="small" onClick={() => setExtraTarget(l)}>
                              <InfoIcon sx={{ fontSize: 14 }} />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Box>
                      {l.error && (
                        <Typography variant="caption" color="error.main"
                          sx={{ display: 'block', fontSize: '0.7rem' }}>
                          {l.error}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>{statusChip(l)}</TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>
                      {fmtNum(l.entries)}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>
                      {l.size_bytes != null ? fmtSize(l.size_bytes) : '—'}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>
                      {fmtPct(l.hit_rate)}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>
                      {fmtNum(l.hits)}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>
                      {fmtNum(l.misses)}
                    </TableCell>
                    <TableCell align="center">
                      {l.clear_url ? (
                        <Tooltip title={l.key === 's3_local_cache'
                            ? 'Trigger LRU eviction pass now'
                            : 'Clear all entries'}>
                          <span>
                            <IconButton size="small" color="error"
                              disabled={l.status !== 'ok' || !l.enabled}
                              onClick={() => setClearTarget(l)}>
                              <DeleteSweepIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </span>
                        </Tooltip>
                      ) : (
                        <Typography variant="caption" color="text.disabled">—</Typography>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Typography variant="caption" color="text.secondary"
            sx={{ display: 'block', mt: 2 }}>
            Refreshes every 30 s.  S3 Local Cache (NFS PVC) "Clear" triggers an LRU
            eviction pass — it doesn't wipe everything, just files past the size cap.
            All other layers are wiped completely on clear.
          </Typography>
        </>
      )}

      {/* Clear-confirmation dialog */}
      <Dialog open={!!clearTarget} onClose={() => setClearTarget(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Clear {clearTarget?.name}?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 1 }}>
            This will {clearTarget?.key === 's3_local_cache'
              ? 'run an LRU eviction pass — files past the size cap will be deleted.'
              : 'remove all entries from this cache.'} Next queries will rebuild
            the cache from source, which may be slower until it warms back up.
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Layer: <code>{clearTarget?.key}</code><br />
            Current size: {clearTarget?.size_bytes != null
              ? fmtSize(clearTarget.size_bytes) : '—'}<br />
            Endpoint: {clearTarget?.clear_method} <code>{clearTarget?.clear_url}</code>
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setClearTarget(null)} disabled={clearing}>Cancel</Button>
          <Button color="error" variant="contained"
            onClick={handleClear} disabled={clearing}>
            {clearing ? 'Clearing...' : 'Clear'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Per-layer extras dialog (shows the JSON blob from backend) */}
      <Dialog open={!!extraTarget} onClose={() => setExtraTarget(null)} maxWidth="md" fullWidth>
        <DialogTitle>{extraTarget?.name} — layer details</DialogTitle>
        <DialogContent>
          <Box component="pre" sx={{
            fontSize: '0.75rem', m: 0, p: 1.5,
            bgcolor: 'background.default', borderRadius: 1,
            overflow: 'auto', maxHeight: 400,
          }}>
            {JSON.stringify(extraTarget?.extra || {}, null, 2)}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setExtraTarget(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default StorageOverviewSection;
