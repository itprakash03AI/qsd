/**
 * Phase 148 — Pruning Health admin dashboard.
 *
 * Hero card: cluster snapshot (avg / p50 / p95 / p99 prune % over
 * chosen window).
 * Below: top-N worst tables (sortable) + top-N worst queries (with
 * deep-link to /api/admin/queries/diagnose).
 *
 * Endpoints used:
 *   GET /api/admin/pruning/cluster-snapshot?window=24h
 *   GET /api/admin/pruning/table-card?bucket=X&table_prefix=Y&window=7d
 *   GET /api/admin/pruning/supplement-coverage?bucket=X&table_prefix=Y
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Paper, Typography, Button, Chip, Stack, Alert,
  Table, TableHead, TableRow, TableCell, TableBody,
  IconButton, Tooltip, CircularProgress, ToggleButton,
  ToggleButtonGroup, Accordion, AccordionSummary,
  AccordionDetails, Grid, LinearProgress,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  ExpandMore as ExpandMoreIcon,
  TrendingDown as TrendingDownIcon,
  Warning as WarningIcon,
  HealthAndSafety as HealthIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';
import {
  LineChart, Line, XAxis, YAxis, Tooltip as RTooltip,
  ResponsiveContainer,
} from 'recharts';
import { safeFetch } from '../../services/api/core';


// ── Types ───────────────────────────────────────────────────────────


interface FilterBreakdownEntry {
  column?:         string;
  operator?:       string;
  value?:          any;
  support?:        'supported' | 'weak' | 'unsupported' | 'unknown';
  support_reason?: string;
}


interface QueryHealth {
  execution_id:        string;
  created_at:          string | null;
  bucket:              string;
  table_prefix:        string;
  snapshot_id:         string | null;
  files_before_prune:  number;
  files_after_prune:   number;
  prune_pct:           number;
  filter_breakdown:    FilterBreakdownEntry[];
}


interface TableHealth {
  bucket:                  string;
  table_prefix:            string;
  query_count:             number;
  avg_prune_pct:           number;
  p50_prune_pct:           number;
  p95_prune_pct:           number;
  p99_prune_pct:           number;
  avg_metadata_seconds:    number;
  avg_manifests_seconds:   number;
  stage_drops_total:       Record<string, number>;
  supplement_coverage_pct: number;
  bloom_hit_rate_pct:      number;
  top_unprunable_columns:  Array<{ column: string; count: number }>;
  trend_series:            Array<{ day: string; query_count: number; avg_prune_pct: number }>;
  week_over_week_delta:    number | null;
  is_degrading:            boolean;
}


interface ClusterHealth {
  window:             string;
  total_queries:      number;
  total_tables:       number;
  avg_prune_pct:      number;
  p50_prune_pct:      number;
  p95_prune_pct:      number;
  p99_prune_pct:      number;
  stage_drops_total:  Record<string, number>;
  top_worst_tables:   TableHealth[];
  top_worst_queries:  QueryHealth[];
  truncated?:         boolean;
  rows_in_window?:    number;
  alerts: Array<{
    kind:             string;
    bucket:           string;
    table_prefix:     string;
    current_avg_pct:  number;
    previous_avg_pct: number;
    delta_pct_points: number;
    threshold_pct:    number;
  }>;
  computed_at:        string;
}


interface CoverageReport {
  bucket:               string;
  table_prefix:         string;
  queried_columns:      Array<{ column: string; query_count: number; covered: boolean; bloom: boolean }>;
  covered_columns:      string[];
  uncovered_columns:    Array<{ column: string; query_count: number }>;
  bloom_covered_columns: string[];
}


// ── Helpers ─────────────────────────────────────────────────────────


const fmtPct = (n: number | null | undefined): string =>
  n == null ? '—' : `${n.toFixed(1)}%`;


const pruneColor = (pct: number): 'success' | 'warning' | 'error' => {
  if (pct >= 80) return 'success';
  if (pct >= 50) return 'warning';
  return 'error';
};


// ── Component ──────────────────────────────────────────────────────


const PruningHealthSection: React.FC = () => {
  const [timeWindow, setTimeWindow] = useState<string>('24h');
  const [snapshot, setSnapshot] = useState<ClusterHealth | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [tableCards, setTableCards] = useState<Record<string, TableHealth>>({});
  const [coverageReports, setCoverageReports] = useState<Record<string, CoverageReport>>({});
  // Bug C fix — per-row load state so a transient fetch failure shows a
  // "retry" affordance instead of spinning forever.
  const [cardLoadState, setCardLoadState] = useState<Record<string, 'idle' | 'loading' | 'error'>>({});
  // Phase 148.C — scan state per row for the "Scan uncovered columns" button.
  const [scanState, setScanState] = useState<Record<string, 'idle' | 'scanning' | 'done' | 'error'>>({});
  const [scanError, setScanError] = useState<Record<string, string>>({});

  const load = useCallback(async (forceRefresh = false) => {
    setLoading(true); setError(null);
    try {
      const r = await safeFetch(
        `/api/admin/pruning/cluster-snapshot?window=${encodeURIComponent(timeWindow)}&cache_ok=${!forceRefresh}`,
        { timeoutMs: 60000 },
      );
      setSnapshot(r as ClusterHealth);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [timeWindow]);

  useEffect(() => { load(); }, [load]);

  const loadTableCard = useCallback(async (bucket: string, prefix: string) => {
    const key = `${bucket}::${prefix}`;
    // Bug C — allow retry: skip ONLY if the fetch is already in flight or
    // resolved.  Errored rows must be re-fetchable on user click.
    if (cardLoadState[key] === 'loading') return;
    if (tableCards[key]) return;
    setCardLoadState((m) => ({ ...m, [key]: 'loading' }));
    try {
      const r = await safeFetch(
        `/api/admin/pruning/table-card?bucket=${encodeURIComponent(bucket)}` +
        `&table_prefix=${encodeURIComponent(prefix)}&window=7d`,
        { timeoutMs: 30000 },
      );
      setTableCards((m) => ({ ...m, [key]: r as TableHealth }));
      setCardLoadState((m) => ({ ...m, [key]: 'idle' }));
    } catch {
      // Surface the failure so the user gets a retry button, not a
      // forever-spinning LinearProgress.
      setCardLoadState((m) => ({ ...m, [key]: 'error' }));
    }
  }, [tableCards, cardLoadState]);

  const loadCoverage = useCallback(async (bucket: string, prefix: string) => {
    const key = `${bucket}::${prefix}`;
    if (coverageReports[key]) return;
    try {
      const r = await safeFetch(
        `/api/admin/pruning/supplement-coverage?bucket=${encodeURIComponent(bucket)}` +
        `&table_prefix=${encodeURIComponent(prefix)}&window=30d`,
        { timeoutMs: 30000 },
      );
      setCoverageReports((m) => ({ ...m, [key]: r as CoverageReport }));
    } catch { /* best-effort — coverage is secondary to card */ }
  }, [coverageReports]);

  const toggleTableExpanded = useCallback(
    (bucket: string, prefix: string) => {
      const key = `${bucket}::${prefix}`;
      setExpanded((m) => ({ ...m, [key]: !m[key] }));
      if (!expanded[key]) {
        loadTableCard(bucket, prefix);
        loadCoverage(bucket, prefix);
      }
    },
    [expanded, loadTableCard, loadCoverage],
  );

  // Phase 148.C — POST the uncovered columns to the new resolver
  // endpoint.  Server resolves (bucket, prefix) to a registered iceberg
  // table and re-issues into the existing scan path, so progress polling
  // (already wired in Column Stats Status) picks up the job too.
  const scanUncoveredColumns = useCallback(
    async (bucket: string, prefix: string, columns: string[]) => {
      const key = `${bucket}::${prefix}`;
      if (!columns.length) return;
      setScanState((m) => ({ ...m, [key]: 'scanning' }));
      setScanError((m) => {
        const { [key]: _drop, ...rest } = m;
        return rest;
      });
      try {
        await safeFetch('/api/admin/pruning/scan-uncovered-columns', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bucket, table_prefix: prefix, columns }),
          timeoutMs: 300000,  // 5 min — supplement scan of a single
                              // table can take a while; the existing
                              // /scan endpoint waits for completion.
        });
        setScanState((m) => ({ ...m, [key]: 'done' }));
      } catch (e: any) {
        setScanState((m) => ({ ...m, [key]: 'error' }));
        setScanError((m) => ({ ...m, [key]: e?.message || String(e) }));
      }
    },
    [],
  );

  const retryCard = useCallback(
    (bucket: string, prefix: string) => {
      const key = `${bucket}::${prefix}`;
      setCardLoadState((m) => {
        const { [key]: _drop, ...rest } = m;
        return rest;
      });
      loadTableCard(bucket, prefix);
      loadCoverage(bucket, prefix);
    },
    [loadTableCard, loadCoverage],
  );

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <HealthIcon fontSize="small" />
        <Typography variant="h6">Pruning Health</Typography>
        <Box sx={{ flex: 1 }} />
        <ToggleButtonGroup
          size="small" value={timeWindow} exclusive
          onChange={(_, v) => v && setTimeWindow(v)}>
          <ToggleButton value="1h">1h</ToggleButton>
          <ToggleButton value="24h">24h</ToggleButton>
          <ToggleButton value="7d">7d</ToggleButton>
          <ToggleButton value="30d">30d</ToggleButton>
        </ToggleButtonGroup>
        <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                onClick={() => load(true)} disabled={loading}>
          {loading ? <CircularProgress size={14} /> : 'Refresh'}
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          Aggregates <code>query_pruning_history</code> into actionable views.
          Cluster snapshot is cached per-pod for{' '}
          <code>pruning_health.snapshot_cache_seconds</code> (default 60s) —
          click <b>Refresh</b> to force a fresh aggregation.  A table is flagged
          as <b>degrading</b> when its avg prune % drops more than{' '}
          <code>pruning_health.degradation_threshold_pct</code> (default 20pp)
          between the current window and the prior window of the same length.
        </Typography>
      </Paper>

      {/* Hero — cluster snapshot ------------------------------------ */}
      {snapshot && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 1 }}>
            Cluster snapshot · window {snapshot.window} · {snapshot.total_queries.toLocaleString()} queries · {snapshot.total_tables} tables
            {snapshot.truncated && (
              <Tooltip title={`Aggregation truncated: the window contains ${(snapshot.rows_in_window ?? 0).toLocaleString()} rows but the loader cap was hit — averages are biased toward the most-recent ${snapshot.total_queries.toLocaleString()}. Narrow the window or raise the pruning_health row cap to see the full picture.`}>
                <Chip size="small" color="warning"
                      sx={{ ml: 1, verticalAlign: 'middle' }}
                      label={`truncated · ${(snapshot.rows_in_window ?? 0).toLocaleString()} rows in window`} />
              </Tooltip>
            )}
          </Typography>
          <Grid container spacing={2}>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Typography variant="caption" color="text.secondary">avg prune %</Typography>
              <Box>
                <Chip size="small"
                      color={pruneColor(snapshot.avg_prune_pct)}
                      label={fmtPct(snapshot.avg_prune_pct)} />
              </Box>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              {/* Bug H — prune % is "higher is better".  p50 reads
                  cleanly as median; p95/p99 readers trained on
                  latency dashboards expect "high = bad".  Label them
                  explicitly with the direction so there's no risk of
                  inverting the interpretation. */}
              <Tooltip title="median prune % — half of queries pruned less than this">
                <Typography variant="caption" color="text.secondary">
                  median (p50)
                </Typography>
              </Tooltip>
              <Box>
                <Chip size="small" variant="outlined"
                      label={fmtPct(snapshot.p50_prune_pct)} />
              </Box>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Tooltip title="top 5% best-pruning queries hit at LEAST this prune % — high is good">
                <Typography variant="caption" color="text.secondary">
                  top-5% (p95, higher is better)
                </Typography>
              </Tooltip>
              <Box>
                <Chip size="small" variant="outlined"
                      color={pruneColor(snapshot.p95_prune_pct)}
                      label={fmtPct(snapshot.p95_prune_pct)} />
              </Box>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Tooltip title="top 1% best-pruning queries hit at LEAST this prune % — high is good">
                <Typography variant="caption" color="text.secondary">
                  top-1% (p99, higher is better)
                </Typography>
              </Tooltip>
              <Box>
                <Chip size="small" variant="outlined"
                      color={pruneColor(snapshot.p99_prune_pct)}
                      label={fmtPct(snapshot.p99_prune_pct)} />
              </Box>
            </Grid>
          </Grid>

          {/* Per-stage drops ---------------------------------------- */}
          {snapshot.stage_drops_total && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="caption" color="text.secondary">
                Per-stage file drops:
              </Typography>
              <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', mt: 0.5 }}>
                {Object.entries(snapshot.stage_drops_total).map(([k, v]) => (
                  v > 0 ? (
                    <Chip key={k} size="small" variant="outlined"
                          label={`${k}: ${v.toLocaleString()}`} />
                  ) : null
                ))}
              </Stack>
            </Box>
          )}

          {/* Alerts ---------------------------------------------- */}
          {snapshot.alerts.length > 0 && (
            <Alert severity="warning" sx={{ mt: 2 }}
                   icon={<TrendingDownIcon />}>
              <Typography variant="body2" fontWeight={700}>
                {snapshot.alerts.length} table(s) degrading vs prior window
              </Typography>
              {snapshot.alerts.slice(0, 5).map((a, i) => (
                <Typography key={i} variant="caption" sx={{ display: 'block' }}>
                  <code>{a.bucket}/{a.table_prefix}</code>{' '}
                  {fmtPct(a.previous_avg_pct)} → {fmtPct(a.current_avg_pct)}{' '}
                  (Δ −{a.delta_pct_points.toFixed(1)}pp, threshold {a.threshold_pct}pp)
                </Typography>
              ))}
            </Alert>
          )}
        </Paper>
      )}

      {/* Top worst tables ---------------------------------------- */}
      {snapshot && snapshot.top_worst_tables.length > 0 && (
        <Paper sx={{ mb: 2 }}>
          <Typography variant="subtitle1" sx={{ p: 1.5, borderBottom: '1px solid #e5e7eb' }}>
            Worst-pruning tables (bottom {snapshot.top_worst_tables.length})
          </Typography>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell />
                <TableCell>Bucket / prefix</TableCell>
                <TableCell align="right">Queries</TableCell>
                <TableCell align="right">Avg prune %</TableCell>
                <TableCell align="right">
                  <Tooltip title="top 5% best-pruning queries hit at least this prune %">
                    <span>top-5%</span>
                  </Tooltip>
                </TableCell>
                <TableCell align="right">Supplement %</TableCell>
                <TableCell align="right">Bloom %</TableCell>
                <TableCell align="right">WoW Δ</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {snapshot.top_worst_tables.map((t) => {
                const key = `${t.bucket}::${t.table_prefix}`;
                const expand = !!expanded[key];
                const card = tableCards[key];
                const coverage = coverageReports[key];
                return (
                  <React.Fragment key={key}>
                    <TableRow hover>
                      <TableCell sx={{ width: 28 }}>
                        <IconButton size="small"
                                    onClick={() => toggleTableExpanded(t.bucket, t.table_prefix)}>
                          <ExpandMoreIcon fontSize="small"
                            sx={{ transform: expand ? 'rotate(180deg)' : 'none',
                                  transition: 'transform 0.2s' }} />
                        </IconButton>
                      </TableCell>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                        {t.bucket}<br/>
                        <span style={{ color: '#666' }}>{t.table_prefix}</span>
                        {t.is_degrading && (
                          <Tooltip title="Avg prune % dropped > threshold vs prior window">
                            <WarningIcon fontSize="small" color="warning" sx={{ ml: 0.5, verticalAlign: 'middle' }} />
                          </Tooltip>
                        )}
                      </TableCell>
                      <TableCell align="right">{t.query_count.toLocaleString()}</TableCell>
                      <TableCell align="right">
                        <Chip size="small" color={pruneColor(t.avg_prune_pct)}
                              label={fmtPct(t.avg_prune_pct)} />
                      </TableCell>
                      <TableCell align="right">{fmtPct(t.p95_prune_pct)}</TableCell>
                      <TableCell align="right">{fmtPct(t.supplement_coverage_pct)}</TableCell>
                      <TableCell align="right">{fmtPct(t.bloom_hit_rate_pct)}</TableCell>
                      <TableCell align="right">
                        {t.week_over_week_delta == null
                          ? '—'
                          : (
                            <Chip size="small"
                                  color={t.week_over_week_delta > 0 ? 'error' : 'success'}
                                  label={`${t.week_over_week_delta > 0 ? '−' : '+'}${Math.abs(t.week_over_week_delta).toFixed(1)}pp`} />
                          )}
                      </TableCell>
                      <TableCell />
                    </TableRow>
                    {expand && (
                      <TableRow>
                        <TableCell colSpan={9} sx={{ background: 'rgba(0,0,0,0.02)' }}>
                          {/* Trend sparkline */}
                          {card && card.trend_series && card.trend_series.length > 0 && (
                            <Box sx={{ mb: 1 }}>
                              <Typography variant="caption" color="text.secondary">
                                7-day trend
                              </Typography>
                              <Box sx={{ width: '100%', height: 80 }}>
                                <ResponsiveContainer width="100%" height="100%">
                                  <LineChart data={card.trend_series}>
                                    <XAxis dataKey="day" fontSize={10} />
                                    <YAxis domain={[0, 100]} fontSize={10} />
                                    <RTooltip />
                                    <Line type="monotone" dataKey="avg_prune_pct"
                                          stroke="#3b82f6" strokeWidth={2} dot />
                                  </LineChart>
                                </ResponsiveContainer>
                              </Box>
                            </Box>
                          )}
                          {/* Top unprunable columns */}
                          {card && card.top_unprunable_columns?.length > 0 && (
                            <Box sx={{ mb: 1 }}>
                              <Typography variant="caption" color="text.secondary">
                                Top filter columns with weak / unsupported pruning:
                              </Typography>
                              <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', mt: 0.5 }}>
                                {card.top_unprunable_columns.map((c) => (
                                  <Chip key={c.column} size="small" variant="outlined"
                                        color="warning"
                                        label={`${c.column} ×${c.count}`} />
                                ))}
                              </Stack>
                            </Box>
                          )}
                          {/* Supplement coverage gap */}
                          {coverage && coverage.uncovered_columns?.length > 0 && (
                            <Box sx={{ mb: 1 }}>
                              <Typography variant="caption" color="text.secondary">
                                Frequently-filtered columns lacking supplement / bloom coverage —
                                consider running a scan:
                              </Typography>
                              <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', mt: 0.5 }}>
                                {coverage.uncovered_columns.slice(0, 10).map((c) => (
                                  <Chip key={c.column} size="small" variant="outlined"
                                        color="error"
                                        label={`${c.column} (${c.query_count} queries)`} />
                                ))}
                              </Stack>
                              {/* Phase 148.C — one-click scan of uncovered cols.
                                  Resolves (bucket, prefix) to the registered table
                                  server-side and hands the column list to the
                                  existing column-stats scanner. */}
                              <Box sx={{ mt: 1 }}>
                                <Button
                                  size="small" variant="outlined" color="primary"
                                  disabled={scanState[key] === 'scanning'}
                                  onClick={() => scanUncoveredColumns(
                                    t.bucket, t.table_prefix,
                                    coverage.uncovered_columns.slice(0, 10).map((c) => c.column),
                                  )}
                                >
                                  {scanState[key] === 'scanning'
                                    ? <><CircularProgress size={12} sx={{ mr: 1 }} /> Scanning…</>
                                    : `Scan top ${Math.min(10, coverage.uncovered_columns.length)} uncovered columns now`}
                                </Button>
                                {scanState[key] === 'done' && (
                                  <Typography variant="caption" sx={{ ml: 1, color: 'success.main' }}>
                                    Scan complete — refresh the dashboard to see updated coverage.
                                  </Typography>
                                )}
                                {scanState[key] === 'error' && scanError[key] && (
                                  <Typography variant="caption" sx={{ ml: 1, color: 'error.main' }}>
                                    {scanError[key]}
                                  </Typography>
                                )}
                              </Box>
                            </Box>
                          )}
                          {!card && cardLoadState[key] === 'loading' && (
                            <LinearProgress sx={{ my: 1 }} />
                          )}
                          {!card && cardLoadState[key] === 'error' && (
                            <Alert severity="error"
                                   sx={{ my: 1 }}
                                   action={
                                     <Button size="small" color="inherit"
                                             onClick={() => retryCard(t.bucket, t.table_prefix)}>
                                       Retry
                                     </Button>
                                   }>
                              Could not load detail for this table.
                              The aggregator may be slow or the connection
                              may have dropped — click Retry.
                            </Alert>
                          )}
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
        </Paper>
      )}

      {/* Top worst queries -------------------------------------- */}
      {snapshot && snapshot.top_worst_queries.length > 0 && (
        <Accordion sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">
              Worst-pruning queries ({snapshot.top_worst_queries.length})
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Execution</TableCell>
                  <TableCell>Bucket / prefix</TableCell>
                  <TableCell align="right">Files before</TableCell>
                  <TableCell align="right">Files after</TableCell>
                  <TableCell align="right">Prune %</TableCell>
                  <TableCell align="right">Diagnose</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {snapshot.top_worst_queries.map((q) => (
                  <TableRow key={q.execution_id} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {q.execution_id.slice(0, 16)}…
                    </TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                      {q.bucket}/{q.table_prefix}
                    </TableCell>
                    <TableCell align="right">{q.files_before_prune.toLocaleString()}</TableCell>
                    <TableCell align="right">{q.files_after_prune.toLocaleString()}</TableCell>
                    <TableCell align="right">
                      <Chip size="small" color={pruneColor(q.prune_pct)}
                            label={fmtPct(q.prune_pct)} />
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Open in Query Diagnostics">
                        <IconButton
                          size="small"
                          onClick={() => {
                            // Bug D fix — pushState + dispatch popstate so
                            // AdminPage's URL listener swaps the active
                            // section without a full reload, and
                            // QueryDiagnosticSection's listener seeds the
                            // highlight target.
                            try {
                              const url = `${window.location.pathname}?section=queryDiagnostic&execution_id=${encodeURIComponent(q.execution_id)}`;
                              window.history.pushState({}, '', url);
                              window.dispatchEvent(new PopStateEvent('popstate'));
                            } catch {
                              window.location.href =
                                `/admin?section=queryDiagnostic&execution_id=${encodeURIComponent(q.execution_id)}`;
                            }
                          }}>
                          <VisibilityIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </AccordionDetails>
        </Accordion>
      )}

      {snapshot && snapshot.total_queries === 0 && !loading && (
        <Alert severity="info">
          No <code>query_pruning_history</code> rows in the {timeWindow} window.
          Run a few queries against iceberg tables, then refresh — the history
          table is populated post-execution.
        </Alert>
      )}
    </Box>
  );
};


export default PruningHealthSection;
