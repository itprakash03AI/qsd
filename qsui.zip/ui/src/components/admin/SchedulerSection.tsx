/**
 * Scheduler section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Covers: Scheduler status, Pause/Resume, Jobs table.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Button, CircularProgress, Stack, Chip,
} from '@mui/material';
import {
  PlayCircleOutline as ActiveIcon,
  PauseCircle as PauseIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { fmtDate } from './adminUtils';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

const SchedulerSection: React.FC<Props> = ({ addNotification }) => {
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null);
  const [schedulerBusy, setSchedulerBusy] = useState(false);

  const loadScheduler = useCallback(async () => {
    try {
      const data = await safeFetch('/api/admin/scheduler');
      setSchedulerStatus(data);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadScheduler(); }, [loadScheduler]);
  useEffect(() => {
    const t = setInterval(loadScheduler, 15_000);
    return () => clearInterval(t);
  }, [loadScheduler]);

  const handleSchedulerToggle = async () => {
    if (!schedulerStatus) return;
    setSchedulerBusy(true);
    try {
      const action = schedulerStatus.paused ? 'resume' : 'pause';
      const body = await safeFetch(`/api/admin/scheduler/${action}`, { method: 'POST' });
      addNotification({
        type: 'success',
        title: `Scheduler ${action === 'pause' ? 'Paused' : 'Resumed'}`,
        message: body.message,
      });
      loadScheduler();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Scheduler Toggle Failed', message: e.message });
    } finally { setSchedulerBusy(false); }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {schedulerStatus ? (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Status"
              value={!schedulerStatus.initialized ? 'Not Init' : schedulerStatus.paused ? 'Paused' : 'Running'}
              warn={schedulerStatus.paused} />
            <StatCard label="Jobs" value={schedulerStatus.job_count ?? 0} />
          </Stack>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Button
              size="small" variant="contained"
              color={schedulerStatus.paused ? 'success' : 'warning'}
              startIcon={schedulerBusy
                ? <CircularProgress size={14} />
                : schedulerStatus.paused ? <ActiveIcon /> : <PauseIcon />}
              onClick={handleSchedulerToggle}
              disabled={schedulerBusy || !schedulerStatus.initialized}
            >
              {schedulerStatus.paused ? 'Resume Scheduler' : 'Pause Scheduler'}
            </Button>
            <Typography variant="caption" color="text.secondary">
              {schedulerStatus.paused
                ? 'All scheduled jobs are paused. Running jobs will finish normally.'
                : 'Scheduler is active. Pause to stop new job triggers.'}
            </Typography>
          </Box>

          {schedulerStatus.jobs?.length > 0 && (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Job Name', 'Next Run', 'Status'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {schedulerStatus.jobs.map((j: any) => (
                    <TableRow key={j.id} hover>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{j.name}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem' }}>{j.next_run ? fmtDate(j.next_run) : '\u2014'}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        <Chip size="small" label={j.paused ? 'Paused' : 'Active'}
                          color={j.paused ? 'warning' : 'success'} variant="outlined"
                          sx={{ height: 20, fontSize: 11 }} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </>
      ) : (
        <Typography variant="body2" color="text.secondary">Loading scheduler status...</Typography>
      )}
    </Paper>
  );
};

export default SchedulerSection;
