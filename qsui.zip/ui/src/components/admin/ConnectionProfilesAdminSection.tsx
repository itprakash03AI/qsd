import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Chip, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, FormControl, Select, MenuItem,
  Tooltip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, Alert,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, SwapHoriz as SwapHorizIcon, Edit as EditIconMui } from '@mui/icons-material';
import api from '../../services/api';

const ConnectionProfilesAdminSection: React.FC = () => {
  const [profiles, setProfiles]         = useState<any[]>([]);
  const [connections, setConnections]   = useState<any[]>([]);
  const [loading, setLoading]           = useState(false);
  const [profileDlgOpen, setProfileDlgOpen] = useState(false);
  const [profileForm, setProfileForm]   = useState({ name: '', description: '' });
  const [mappingProfile, setMappingProfile] = useState<any>(null);
  const [mappings, setMappings]         = useState<any[]>([]);
  const [mappingLoading, setMappingLoading] = useState(false);

  const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 'oracle'];

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([
      api.listConnectionProfiles(),
      api.listConnections(true),
    ]).then(([pr, cr]: any[]) => {
      setProfiles((pr?.profiles || pr) || []);
      setConnections((cr || []).filter((c: any) => SQL_TYPES.includes(c.connection_type)));
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleActivate = async (id: number) => {
    await api.activateConnectionProfile(id);
    load();
  };
  const handleDeactivate = async () => {
    await api.deactivateAllProfiles();
    load();
  };
  const handleDelete = async (id: number) => {
    await api.deleteConnectionProfile(id);
    load();
  };
  const handleCreate = async () => {
    if (!profileForm.name.trim()) return;
    await api.createConnectionProfile(profileForm);
    setProfileDlgOpen(false);
    setProfileForm({ name: '', description: '' });
    load();
  };
  const openMappings = async (profile: any) => {
    setMappingProfile(profile);
    setMappingLoading(true);
    try {
      const r: any = await api.getProfileMappings(profile.id);
      setMappings((r?.mappings || r) || []);
    } finally { setMappingLoading(false); }
  };
  const handleSaveMappings = async () => {
    await api.setProfileMappings(mappingProfile.id, mappings);
    setMappingProfile(null);
    load();
  };

  const connName = (id: number) => connections.find((c: any) => c.id === id)?.name || `ID ${id}`;

  return (
    <Box sx={{ display: 'flex', height: '100%', gap: 2, p: 2 }}>
      {/* Profile list */}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography variant="subtitle1" fontWeight={600}>Connection Profiles</Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button size="small" variant="outlined" onClick={handleDeactivate}>Clear Active</Button>
            <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => setProfileDlgOpen(true)}>
              New Profile
            </Button>
          </Box>
        </Box>
        {loading ? <CircularProgress size={24} /> : (
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Description</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {profiles.length === 0 && (
                  <TableRow><TableCell colSpan={4} align="center"><Typography variant="caption" color="text.disabled">No profiles yet</Typography></TableCell></TableRow>
                )}
                {profiles.map((p: any) => (
                  <TableRow key={p.id} selected={p.is_active}>
                    <TableCell><Typography variant="body2" fontWeight={p.is_active ? 700 : 400}>{p.name}</Typography></TableCell>
                    <TableCell>
                      {p.is_active
                        ? <Chip label="ACTIVE" size="small" color="success" />
                        : <Chip label="inactive" size="small" variant="outlined" />}
                    </TableCell>
                    <TableCell><Typography variant="caption" color="text.secondary">{p.description || '—'}</Typography></TableCell>
                    <TableCell align="right">
                      <Tooltip title="Edit mappings">
                        <IconButton size="small" onClick={() => openMappings(p)}><EditIconMui fontSize="small" /></IconButton>
                      </Tooltip>
                      {!p.is_active && (
                        <Tooltip title="Activate this profile">
                          <IconButton size="small" color="primary" onClick={() => handleActivate(p.id)}>
                            <SwapHorizIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Delete profile">
                        <IconButton size="small" color="error" onClick={() => handleDelete(p.id)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
        <Alert severity="info" sx={{ mt: 1, fontSize: 12 }}>
          When a profile is active, all report executions swap matched connections to their targets. Only one profile can be active at a time.
        </Alert>
      </Box>

      {/* New profile dialog */}
      <Dialog open={profileDlgOpen} onClose={() => setProfileDlgOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>New Connection Profile</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
          <TextField label="Profile Name" size="small" fullWidth value={profileForm.name}
            onChange={e => setProfileForm(f => ({ ...f, name: e.target.value }))}
            placeholder="e.g. Production, Development, Staging" />
          <TextField label="Description (optional)" size="small" fullWidth value={profileForm.description}
            onChange={e => setProfileForm(f => ({ ...f, description: e.target.value }))} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setProfileDlgOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!profileForm.name.trim()}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* Mapping editor dialog */}
      <Dialog open={!!mappingProfile} onClose={() => setMappingProfile(null)} maxWidth="md" fullWidth>
        <DialogTitle>Edit Mappings — {mappingProfile?.name}</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            Each row maps a source connection to a target. When this profile is active, any report using the source will instead use the target.
          </Typography>
          {mappingLoading ? <CircularProgress size={24} /> : (
            <TableContainer component={Paper} variant="outlined">
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Source Connection</TableCell>
                    <TableCell>→</TableCell>
                    <TableCell>Target Connection</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell />
                  </TableRow>
                </TableHead>
                <TableBody>
                  {mappings.map((m: any, idx: number) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <FormControl size="small" fullWidth>
                          <Select value={m.source_connection_id || ''} onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, source_connection_id: Number(e.target.value) } : r))}>
                            {connections.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name} ({c.connection_type})</MenuItem>)}
                          </Select>
                        </FormControl>
                      </TableCell>
                      <TableCell>→</TableCell>
                      <TableCell>
                        <FormControl size="small" fullWidth>
                          <Select value={m.target_connection_id || ''} onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, target_connection_id: Number(e.target.value) } : r))}>
                            {connections.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name} ({c.connection_type})</MenuItem>)}
                          </Select>
                        </FormControl>
                      </TableCell>
                      <TableCell>
                        <TextField size="small" placeholder="optional note" value={m.description || ''}
                          onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, description: e.target.value } : r))} />
                      </TableCell>
                      <TableCell>
                        <IconButton size="small" color="error" onClick={() => setMappings(ms => ms.filter((_, i) => i !== idx))}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={5}>
                      <Button size="small" startIcon={<AddIcon />}
                        onClick={() => setMappings(ms => [...ms, { source_connection_id: '', target_connection_id: '', description: '' }])}>
                        Add Mapping
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setMappingProfile(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveMappings}>Save Mappings</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ConnectionProfilesAdminSection;
