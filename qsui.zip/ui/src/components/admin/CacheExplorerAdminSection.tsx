import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Stack, Chip, IconButton, Divider, Drawer,
} from '@mui/material';
import { InfoOutlined as InfoOutlinedIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { useNotifications } from '../../context/NotificationContext';

const CacheExplorerAdminSection: React.FC = () => {
  const { addNotification } = useNotifications();
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [connFilter, setConnFilter] = useState('');
  const [tableFilter, setTableFilter] = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [detailEntry, setDetailEntry] = useState<any | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (connFilter) params.append('connection_id', connFilter);
      if (tableFilter) params.append('table', tableFilter);
      const data = await safeFetch(`/api/admin/cache/entries?${params}`);
      setEntries(data?.entries || []);
    } catch (e) {
      addNotification({ type: 'error', title: 'Load Failed', message: 'Failed to load cache entries' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openDetail = async (entry: any) => {
    setDrawerOpen(true);
    setDetailEntry(null);
    setDetailLoading(true);
    try {
      const detail = await safeFetch(`/api/admin/cache/entries/${entry.cache_key}`);
      setDetailEntry(detail);
    } catch {
      setDetailEntry(entry);
    } finally {
      setDetailLoading(false);
    }
  };

  const evict = async (cacheKey: string) => {
    try {
      await safeFetch(`/api/admin/cache/entries/${cacheKey}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Evicted', message: 'Cache entry evicted' });
      setDrawerOpen(false);
      load();
    } catch {
      addNotification({ type: 'error', title: 'Eviction Failed', message: 'Eviction failed' });
    }
  };

  const stalenessColor = (s: string) => {
    if (s === 'fresh') return 'success';
    if (s === 'stale') return 'error';
    if (s === 'legacy') return 'default';
    return 'warning';
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>Cache Explorer</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        View, inspect, and evict query result cache entries. Cache fingerprints track partition
        snapshots for automatic staleness detection.
      </Typography>

      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <TextField size="small" label="Connection ID" value={connFilter}
          onChange={e => setConnFilter(e.target.value)} sx={{ width: 160 }} />
        <TextField size="small" label="Table name" value={tableFilter}
          onChange={e => setTableFilter(e.target.value)} sx={{ width: 200 }} />
        <Button variant="outlined" size="small" onClick={load} disabled={loading}>
          {loading ? 'Loading…' : 'Refresh'}
        </Button>
        <Typography variant="caption" color="text.secondary">
          {entries.length} entries
        </Typography>
      </Stack>

      <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 500 }}>
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell>Key</TableCell>
              <TableCell>Connection</TableCell>
              <TableCell>Tables</TableCell>
              <TableCell>Cached</TableCell>
              <TableCell>Size</TableCell>
              <TableCell>Hits</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {entries.map(e => (
              <TableRow key={e.cache_key} hover>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 11 }}>
                  {e.cache_key.slice(0, 12)}…
                </TableCell>
                <TableCell>{e.connection_name || e.connection_id || '—'}</TableCell>
                <TableCell>{(e.tables || []).join(', ') || '—'}</TableCell>
                <TableCell>
                  {e.age_seconds != null ? `${Math.round(e.age_seconds / 60)}m ago` : '—'}
                </TableCell>
                <TableCell>{e.size_mb} MB</TableCell>
                <TableCell>{e.hit_count}</TableCell>
                <TableCell>
                  <Chip size="small" label={e.staleness || 'unknown'}
                    color={stalenessColor(e.staleness) as any} />
                </TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    <IconButton size="small" title="View details" onClick={() => openDetail(e)}>
                      <InfoOutlinedIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" title="Evict" onClick={() => evict(e.cache_key)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Stack>
                </TableCell>
              </TableRow>
            ))}
            {!loading && entries.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                    No cache entries found.
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: 480, p: 2 } }}>
        {detailLoading ? (
          <Typography>Loading…</Typography>
        ) : detailEntry ? (
          <Box>
            <Typography variant="h6" gutterBottom>Cache Entry Detail</Typography>
            <Typography variant="caption" sx={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
              {detailEntry.cache_key}
            </Typography>
            <Divider sx={{ my: 1.5 }} />
            <Stack spacing={0.5}>
              <Typography variant="body2"><strong>Cached at:</strong> {detailEntry.created_at || '—'}</Typography>
              <Typography variant="body2"><strong>Expires at:</strong> {detailEntry.expires_at || '—'}</Typography>
              <Typography variant="body2"><strong>Size:</strong> {Math.round((detailEntry.file_size_bytes || 0) / 1048576 * 100) / 100} MB</Typography>
              <Typography variant="body2"><strong>Rows:</strong> {detailEntry.row_count?.toLocaleString() || '—'}</Typography>
              <Typography variant="body2"><strong>Hits:</strong> {detailEntry.hit_count || 0}</Typography>
            </Stack>

            {(detailEntry.source_tables_json || []).length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>Tables</Typography>
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Table</TableCell>
                        <TableCell>Format</TableCell>
                        <TableCell>Snapshot / Hash</TableCell>
                        <TableCell>Files</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(detailEntry.source_tables_json || []).map((t: any, i: number) => (
                        <TableRow key={i}>
                          <TableCell>{t.table_name}</TableCell>
                          <TableCell>{t.format}</TableCell>
                          <TableCell sx={{ fontFamily: 'monospace', fontSize: 10 }}>
                            {t.snapshot_id || (t.file_list_hash ? t.file_list_hash.slice(0, 12) + '…' : '—')}
                          </TableCell>
                          <TableCell>{t.file_count ?? '—'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            )}

            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" gutterBottom>Staleness</Typography>
              <Chip size="small" label={detailEntry.staleness || 'unknown'}
                color={stalenessColor(detailEntry.staleness || 'unknown') as any} />
              {detailEntry.staleness_detail && (
                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                  {detailEntry.staleness_detail}
                </Typography>
              )}
            </Box>

            <Stack direction="row" spacing={1} sx={{ mt: 3 }}>
              <Button variant="outlined" color="error" size="small"
                onClick={() => evict(detailEntry.cache_key)}>
                Evict
              </Button>
              <Button variant="text" size="small" onClick={() => setDrawerOpen(false)}>
                Close
              </Button>
            </Stack>
          </Box>
        ) : null}
      </Drawer>
    </Box>
  );
};

export default CacheExplorerAdminSection;
