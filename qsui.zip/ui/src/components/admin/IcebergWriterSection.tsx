/**
 * Phase 139 honest-fix Fix 5 — Iceberg Writer admin UI.
 *
 * Surface for the four /api/admin/iceberg/{insert,delete,update,compact}
 * endpoints. Forms accept JSON-pasted rows / filters; results echoed back.
 *
 * Gated server-side by iceberg_writer.enabled=true + admin role + pyiceberg
 * installed in the runtime image. We just render forms that hit the endpoints
 * and surface the response.
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Typography, Paper, Tab, Tabs, TextField, Button, Alert, Stack, Chip,
  CircularProgress, MenuItem, Divider,
} from '@mui/material';
import {
  Storage as StorageIcon, Add as AddIcon, Delete as DeleteIcon,
  Edit as EditIcon, Compress as CompactIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';

interface Connection {
  id:    number;
  name:  string;
  connection_type: string;
}

const IcebergWriterSection: React.FC = () => {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [tab, setTab] = useState<'insert' | 'delete' | 'update' | 'compact'>('insert');
  const [connId, setConnId] = useState<number | ''>('');
  const [tablePrefix, setTablePrefix] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Per-tab form state
  const [rowsJson, setRowsJson] = useState('[\n  {"col1": "value", "col2": 42}\n]');
  const [filterJson, setFilterJson] = useState('{"col": "id", "op": "eq", "val": 123}');
  const [matchFilterJson, setMatchFilterJson] = useState('{"col": "id", "op": "eq", "val": 123}');
  const [newRowsJson, setNewRowsJson] = useState('[\n  {"col1": "new value", "col2": 99}\n]');
  const [partitionFilterJson, setPartitionFilterJson] = useState('null');
  const [targetMb, setTargetMb] = useState(256);

  useEffect(() => {
    (async () => {
      try {
        const data: any = await safeFetch('/api/connections');
        // BF-430E — toArray with explicit "connections" key handles both
        // bare-array and {connections: [...]} response shapes.
        const all = toArray<Connection>(data, 'connections');
        setConnections(all.filter((c: Connection) => c.connection_type === 's3'));
      } catch (e: any) {
        setError(e?.message || 'Failed to load connections');
      }
    })();
  }, []);

  const runOp = useCallback(async () => {
    setBusy(true);
    setResult(null);
    setError(null);
    try {
      let body: any = { connection_id: connId, table_prefix: tablePrefix };
      let endpoint = '';
      if (tab === 'insert') {
        body.rows = JSON.parse(rowsJson);
        endpoint = '/api/admin/iceberg/insert';
      } else if (tab === 'delete') {
        body.filter = JSON.parse(filterJson);
        endpoint = '/api/admin/iceberg/delete';
      } else if (tab === 'update') {
        body.match_filter = JSON.parse(matchFilterJson);
        body.new_rows = JSON.parse(newRowsJson);
        endpoint = '/api/admin/iceberg/update';
      } else if (tab === 'compact') {
        const pf = partitionFilterJson.trim();
        body.partition_filter = (pf && pf !== 'null') ? JSON.parse(pf) : null;
        body.target_file_size_mb = targetMb;
        endpoint = '/api/admin/iceberg/compact';
      }
      const resp: any = await safeFetch(endpoint, { method: 'POST', body });
      setResult(resp);
    } catch (e: any) {
      setError(e?.message || 'Operation failed');
    } finally {
      setBusy(false);
    }
  }, [tab, connId, tablePrefix, rowsJson, filterJson, matchFilterJson, newRowsJson, partitionFilterJson, targetMb]);

  const formValid = connId !== '' && tablePrefix.trim().length > 0;

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <StorageIcon color="primary" />
        <Typography variant="h6">Iceberg Writer</Typography>
        <Chip size="small" label="ADMIN" color="warning" />
        <Chip size="small" label="opt-in: iceberg_writer.enabled=true" variant="outlined" />
      </Stack>

      <Alert severity="info" sx={{ mb: 2 }}>
        These operations modify Iceberg tables in S3. Requires
        <code style={{ margin: '0 4px' }}>iceberg_writer.enabled=true</code>
        in config + pyiceberg installed in the runtime image. Works on AWS
        S3 and on-prem S3 (MinIO/Ceph) via the same connection's
        <code style={{ margin: '0 4px' }}>endpoint_url</code>.
      </Alert>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" spacing={2} flexWrap="wrap" alignItems="center">
          <TextField
            select size="small" label="S3 Connection" value={connId}
            onChange={e => setConnId(Number(e.target.value))}
            sx={{ minWidth: 220 }}
          >
            {connections.map(c => (
              <MenuItem key={c.id} value={c.id}>{c.name} (id={c.id})</MenuItem>
            ))}
          </TextField>
          <TextField
            size="small" label="Table prefix (S3 key path)"
            placeholder="e.g. data/sales/"
            value={tablePrefix} onChange={e => setTablePrefix(e.target.value)}
            sx={{ flex: 1, minWidth: 280 }}
          />
        </Stack>
      </Paper>

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab icon={<AddIcon />} iconPosition="start" label="INSERT" value="insert" />
        <Tab icon={<DeleteIcon />} iconPosition="start" label="DELETE" value="delete" />
        <Tab icon={<EditIcon />} iconPosition="start" label="UPDATE" value="update" />
        <Tab icon={<CompactIcon />} iconPosition="start" label="COMPACT" value="compact" />
      </Tabs>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        {tab === 'insert' && (
          <Stack spacing={1}>
            <Typography variant="body2" color="text.secondary">
              Rows to append (JSON array of dicts). Schema must match the table.
            </Typography>
            <TextField
              multiline rows={10} fullWidth value={rowsJson}
              onChange={e => setRowsJson(e.target.value)}
              sx={{ fontFamily: 'monospace', '& textarea': { fontFamily: 'monospace', fontSize: 13 } }}
            />
          </Stack>
        )}
        {tab === 'delete' && (
          <Stack spacing={1}>
            <Typography variant="body2" color="text.secondary">
              Equality-delete filter. Operators: <code>eq</code>, <code>in</code>.
              Writes a V2 equality-delete file (reader must opt into MoR).
            </Typography>
            <TextField
              multiline rows={4} fullWidth value={filterJson}
              onChange={e => setFilterJson(e.target.value)}
              sx={{ '& textarea': { fontFamily: 'monospace', fontSize: 13 } }}
            />
          </Stack>
        )}
        {tab === 'update' && (
          <Stack spacing={2}>
            <Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                Match filter (rows to update):
              </Typography>
              <TextField
                multiline rows={3} fullWidth value={matchFilterJson}
                onChange={e => setMatchFilterJson(e.target.value)}
                sx={{ '& textarea': { fontFamily: 'monospace', fontSize: 13 } }}
              />
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                New rows (replacements):
              </Typography>
              <TextField
                multiline rows={6} fullWidth value={newRowsJson}
                onChange={e => setNewRowsJson(e.target.value)}
                sx={{ '& textarea': { fontFamily: 'monospace', fontSize: 13 } }}
              />
            </Box>
          </Stack>
        )}
        {tab === 'compact' && (
          <Stack spacing={2}>
            <Typography variant="body2" color="text.secondary">
              Compact small files into one large file per partition. Uses
              pyiceberg's <code>rewrite_data_files</code>.
            </Typography>
            <TextField
              size="small" type="number" label="Target file size (MB)"
              value={targetMb} onChange={e => setTargetMb(Number(e.target.value))}
              sx={{ maxWidth: 220 }}
            />
            <Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                Partition filter (JSON or <code>null</code> for whole table):
              </Typography>
              <TextField
                multiline rows={3} fullWidth value={partitionFilterJson}
                onChange={e => setPartitionFilterJson(e.target.value)}
                sx={{ '& textarea': { fontFamily: 'monospace', fontSize: 13 } }}
              />
            </Box>
          </Stack>
        )}

        <Divider sx={{ my: 2 }} />
        <Stack direction="row" spacing={1}>
          <Button
            variant="contained" onClick={runOp}
            disabled={!formValid || busy}
            startIcon={busy ? <CircularProgress size={16} color="inherit" /> : null}
          >
            {busy ? 'Running…' : `Run ${tab.toUpperCase()}`}
          </Button>
        </Stack>
      </Paper>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {result && (
        <Paper variant="outlined" sx={{ p: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Result</Typography>
          <pre style={{ fontFamily: 'monospace', fontSize: 12, overflow: 'auto', margin: 0 }}>
            {JSON.stringify(result, null, 2)}
          </pre>
        </Paper>
      )}
    </Box>
  );
};

export default IcebergWriterSection;
