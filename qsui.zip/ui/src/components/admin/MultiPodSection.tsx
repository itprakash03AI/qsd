/**
 * BF-384 — Multi-Pod Query Worker admin panel (Option G).
 * Configure worker pod discovery, view alive pods, manage HMAC auth.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, Stack, TextField, FormControlLabel, Switch,
  Alert, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Divider, MenuItem,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import api from '../../services/api';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface MPConfig {
  enabled: boolean;
  worker_urls: string[];
  k8s_service: string;
  k8s_service_port: number;
  worker_port: number;
  shared_secret_set: boolean;
  per_worker_timeout_seconds: number;
  fallback_on_error: boolean;
  // BF-393 — SQL connector sharding
  sql_connector_enabled: boolean;
  sql_connector_shard_count: number;
  sql_connector_shard_strategy: string;
  sql_connector_default_shard_column: string;
}

const DEFAULT_CFG: MPConfig = {
  enabled: false, worker_urls: [], k8s_service: '', k8s_service_port: 8000,
  worker_port: 8000, shared_secret_set: false,
  per_worker_timeout_seconds: 1800, fallback_on_error: true,
  sql_connector_enabled: false,
  sql_connector_shard_count: 4,
  sql_connector_shard_strategy: 'bucket',
  sql_connector_default_shard_column: '',
};

const CONNECTOR_TYPES = [
  'snowflake', 'trino', 'starburst', 'databricks', 'oracle', 'athena',
];

interface DryRunShard {
  shard_index: number;
  predicate: string;
  partial_sql: string;
}
interface DryRunResult {
  splittable: boolean;
  skip_reason: string;
  shard_strategy: string;
  shard_column: string;
  merge_strategy: string;
  shards: DryRunShard[];
}

const MultiPodSection: React.FC<Props> = ({ addNotification }) => {
  const [config, setConfig] = useState<MPConfig>(DEFAULT_CFG);
  const [editing, setEditing] = useState<MPConfig>(DEFAULT_CFG);
  const [pods, setPods] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [newSecret, setNewSecret] = useState('');
  const [newUrl, setNewUrl] = useState('');
  // BF-393 — dry-run shard preview
  const [dryRunSql, setDryRunSql] = useState('SELECT id, region, SUM(amount) FROM orders WHERE created_at > \'2024-01-01\' GROUP BY id, region');
  const [dryRunConnector, setDryRunConnector] = useState('snowflake');
  const [dryRunColumn, setDryRunColumn] = useState('id');
  const [dryRunResult, setDryRunResult] = useState<DryRunResult | null>(null);
  const [dryRunBusy, setDryRunBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [c, p] = await Promise.all([
        api.getMultiPodConfig().catch(() => DEFAULT_CFG),
        api.getMultiPodPods().catch(() => ({ pods: [] })),
      ]);
      setConfig(c as MPConfig);
      setEditing(c as MPConfig);
      setPods((p as any).pods || []);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload: any = {};
      (Object.keys(editing) as (keyof MPConfig)[]).forEach(k => {
        if (k === 'shared_secret_set') return; // read-only flag
        if (JSON.stringify(editing[k]) !== JSON.stringify(config[k])) {
          payload[k] = editing[k];
        }
      });
      if (newSecret) payload.shared_secret = newSecret;
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No changes', message: '' });
      } else {
        await api.setMultiPodConfig(payload);
        setNewSecret('');
        addNotification({
          type: 'success', title: 'Config saved',
          message: `Updated: ${Object.keys(payload).join(', ')}`,
        });
        load();
      }
    } catch (e: any) {
      addNotification({
        type: 'error', title: 'Save failed',
        message: e?.message || 'Unknown error',
      });
    } finally {
      setSaving(false);
    }
  };

  const alivePods = pods.filter(p => p.alive).length;

  return (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Multi-Pod Query Workers (Option G)</Typography>
        <Button size="small" variant="outlined" onClick={load}>Refresh</Button>
      </Box>

      {!config.enabled && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Multi-pod dispatch is disabled. Enable to distribute query chunks across
          SEPARATE worker pods over HTTP. Workers are discovered via static URLs,
          K8s headless service DNS, or the worker registry. Falls back to in-pod F
          when no pods reachable.
        </Alert>
      )}

      {config.enabled && !config.shared_secret_set && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          <strong>HMAC secret not set.</strong> Workers will accept unauthenticated
          requests — DEV ONLY. Set <code>QS_WORKER_SECRET</code> env var on every
          coordinator + worker pod, OR set <code>shared_secret</code> below (then
          save) so the secret persists in config.json (less secure than env var).
        </Alert>
      )}

      {/* Stats */}
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 3 }}>
        <StatCard label="Total Pods" value={pods.length} />
        <StatCard label="Alive" value={alivePods} />
        <StatCard label="Down" value={pods.length - alivePods} />
        <StatCard label="HMAC Secret" value={config.shared_secret_set ? 'SET' : '—'} />
      </Stack>

      {/* Configuration */}
      <Typography variant="subtitle2" sx={{ mb: 1, mt: 1 }}>Configuration</Typography>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <FormControlLabel
          control={<Switch checked={editing.enabled}
                            onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })} />}
          label="Enabled"
        />
        <TextField
          label="K8s headless service"
          size="small"
          value={editing.k8s_service}
          onChange={(e) => setEditing({ ...editing, k8s_service: e.target.value })}
          placeholder="qs-worker.default.svc.cluster.local"
          sx={{ width: 360 }}
        />
        <TextField
          label="K8s port"
          size="small" type="number"
          value={editing.k8s_service_port}
          onChange={(e) => setEditing({ ...editing, k8s_service_port: Number(e.target.value) })}
          sx={{ width: 120 }}
        />
        <TextField
          label="Per-worker timeout (s)"
          size="small" type="number"
          value={editing.per_worker_timeout_seconds}
          onChange={(e) => setEditing({ ...editing, per_worker_timeout_seconds: Number(e.target.value) })}
          sx={{ width: 180 }}
        />
        <FormControlLabel
          control={<Switch checked={editing.fallback_on_error}
                            onChange={(e) => setEditing({ ...editing, fallback_on_error: e.target.checked })} />}
          label="Fallback on error"
        />
      </Stack>

      {/* HMAC secret */}
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
        HMAC shared secret (write-only — never displayed). Set via env var
        <code>QS_WORKER_SECRET</code> in production for better security.
      </Typography>
      <TextField
        label="New shared secret"
        size="small" type="password"
        value={newSecret}
        onChange={(e) => setNewSecret(e.target.value)}
        placeholder={config.shared_secret_set ? 'Currently set (leave blank to keep)' : 'Not set'}
        sx={{ width: 360, mb: 2 }}
      />

      {/* Static worker URLs */}
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
        Static worker URLs (used when K8s service is blank)
      </Typography>
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1 }}>
        {editing.worker_urls.map((u, i) => (
          <Chip key={`${u}-${i}`} label={u} size="small"
                onDelete={() => setEditing({
                  ...editing,
                  worker_urls: editing.worker_urls.filter((_, idx) => idx !== i),
                })}
                sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }} />
        ))}
      </Stack>
      <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
        <TextField
          size="small"
          value={newUrl}
          onChange={(e) => setNewUrl(e.target.value)}
          placeholder="http://qs-worker-1:8000"
          sx={{ flex: 1, fontFamily: 'monospace' }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && newUrl.trim()) {
              setEditing({ ...editing, worker_urls: [...editing.worker_urls, newUrl.trim()] });
              setNewUrl('');
            }
          }}
        />
        <Button variant="outlined" size="small" onClick={() => {
          if (!newUrl.trim()) return;
          setEditing({ ...editing, worker_urls: [...editing.worker_urls, newUrl.trim()] });
          setNewUrl('');
        }}>Add URL</Button>
      </Stack>

      <Button variant="contained" size="small" onClick={handleSave} disabled={saving}>
        {saving ? 'Saving...' : 'Save Config'}
      </Button>

      {/* BF-393 — SQL-connector parallelism panel.  Different from the parquet
          path above: workers run a connector (Snowflake / Trino / Starburst /
          Databricks / Oracle / Athena) instead of DuckDB.  Coordinator splits
          the SQL into N predicate-restricted shards and dispatches them. */}
      <Divider sx={{ my: 3 }} />
      <Typography variant="subtitle2" sx={{ mb: 1 }}>
        SQL-Connector Parallelism (Snowflake / Trino / Starburst / Databricks / Oracle / Athena)
      </Typography>
      <Alert severity="info" sx={{ mb: 2, fontSize: '0.78rem' }}>
        Coordinator splits a connector query into N predicate-restricted shards
        (bucket via MOD-HASH, or range via BETWEEN bounds) and dispatches them
        across the same worker pool configured above.  Workers look up the
        connection in the shared DB — credentials never travel in the chunk
        payload.
        {' '}<strong>Athena warning:</strong> bucket strategy causes N× the
        billed bytes scanned because the predicate is not a partition prune —
        use range strategy on a Glue partition column for Athena tables.
      </Alert>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <FormControlLabel
          control={<Switch checked={editing.sql_connector_enabled}
                            onChange={(e) => setEditing({ ...editing, sql_connector_enabled: e.target.checked })} />}
          label="SQL-connector parallelism enabled"
        />
        <TextField
          select
          label="Default shard strategy"
          size="small"
          value={editing.sql_connector_shard_strategy}
          onChange={(e) => setEditing({ ...editing, sql_connector_shard_strategy: e.target.value })}
          sx={{ width: 200 }}
          helperText="bucket = MOD-HASH; range = BETWEEN bounds"
        >
          <MenuItem value="bucket">bucket (MOD-HASH)</MenuItem>
          <MenuItem value="range">range (BETWEEN)</MenuItem>
        </TextField>
        <TextField
          label="Default shard count"
          size="small" type="number"
          inputProps={{ min: 1, max: 64 }}
          value={editing.sql_connector_shard_count}
          onChange={(e) => setEditing({ ...editing, sql_connector_shard_count: Math.max(1, Number(e.target.value) || 4) })}
          sx={{ width: 160 }}
        />
        <TextField
          label="Default shard column hint"
          size="small"
          value={editing.sql_connector_default_shard_column}
          onChange={(e) => setEditing({ ...editing, sql_connector_default_shard_column: e.target.value })}
          placeholder="e.g. id, user_id, order_date"
          helperText="Per-query override always wins"
          sx={{ width: 260 }}
        />
      </Stack>

      {/* Dry-run preview — paste a SQL + connector + shard config and see
          what would be dispatched to each worker.  Doesn't execute anything. */}
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5, mt: 1 }}>
        Dry-run shard preview (validates your shard column + strategy without executing)
      </Typography>
      <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
        <TextField
          select
          label="Connector"
          size="small"
          value={dryRunConnector}
          onChange={(e) => setDryRunConnector(e.target.value)}
          sx={{ width: 160 }}
        >
          {CONNECTOR_TYPES.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
        </TextField>
        <TextField
          label="Shard column"
          size="small"
          value={dryRunColumn}
          onChange={(e) => setDryRunColumn(e.target.value)}
          placeholder="id"
          sx={{ width: 200 }}
        />
        <Button
          variant="outlined" size="small"
          disabled={dryRunBusy || !dryRunSql.trim() || !dryRunColumn.trim()}
          onClick={async () => {
            setDryRunBusy(true);
            setDryRunResult(null);
            try {
              const r = await api.multiPodSqlShardDryRun({
                sql: dryRunSql,
                connector_type: dryRunConnector,
                shard_count: editing.sql_connector_shard_count,
                shard_strategy: editing.sql_connector_shard_strategy,
                shard_column: dryRunColumn,
              });
              setDryRunResult(r as DryRunResult);
            } catch (e: any) {
              addNotification({
                type: 'error', title: 'Dry-run failed',
                message: e?.message || 'Unknown error',
              });
            } finally {
              setDryRunBusy(false);
            }
          }}
        >
          {dryRunBusy ? 'Running…' : 'Preview shards'}
        </Button>
      </Stack>
      <TextField
        multiline
        fullWidth
        size="small"
        minRows={3}
        maxRows={8}
        value={dryRunSql}
        onChange={(e) => setDryRunSql(e.target.value)}
        sx={{
          mb: 1,
          '& .MuiInputBase-input': { fontFamily: 'monospace', fontSize: '0.78rem' },
        }}
      />
      {dryRunResult && (
        <Box sx={{ mb: 2 }}>
          {dryRunResult.splittable ? (
            <Alert severity="success" sx={{ mb: 1, fontSize: '0.78rem' }}>
              Splittable into <strong>{dryRunResult.shards.length}</strong> shards
              via <code>{dryRunResult.shard_strategy}</code> on
              <code> {dryRunResult.shard_column}</code> — merge strategy:{' '}
              <code>{dryRunResult.merge_strategy}</code>
            </Alert>
          ) : (
            <Alert severity="warning" sx={{ mb: 1, fontSize: '0.78rem' }}>
              Not splittable: {dryRunResult.skip_reason}
            </Alert>
          )}
          {dryRunResult.shards.map((s) => (
            <Paper key={s.shard_index} variant="outlined" sx={{ p: 1.25, mb: 0.75 }}>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
                <Chip label={`shard ${s.shard_index}`} size="small" />
                <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>
                  predicate: {s.predicate}
                </Typography>
              </Stack>
              <Box sx={{
                fontFamily: 'monospace', fontSize: '0.74rem',
                whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                bgcolor: 'action.hover', p: 1, borderRadius: 0.5,
              }}>
                {s.partial_sql}
              </Box>
            </Paper>
          ))}
        </Box>
      )}

      {pods.length > 0 && (
        <>
          <Divider sx={{ my: 3 }} />
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Worker Pod Health</Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 360 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Pod URL</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Last Request</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Error</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pods.map((p, i) => (
                  <TableRow key={`${p.url}-${i}`} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>{p.url}</TableCell>
                    <TableCell>
                      {p.alive ? (
                        <Chip icon={<CheckCircleIcon />} label="alive" color="success" size="small" />
                      ) : (
                        <Chip icon={<ErrorIcon />} label="down" color="error" size="small" />
                      )}
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.75rem' }}>
                      {p.last_request ? new Date(p.last_request * 1000).toLocaleString() : '—'}
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.75rem', color: 'error.main' }}>
                      {p.error || ''}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </Paper>
  );
};

export default MultiPodSection;
