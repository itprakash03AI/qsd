import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, Button, CircularProgress, TextField } from '@mui/material';
import api from '../../services/api';

const ReportCatalogAdminSection: React.FC = () => {
  const [cfg, setCfg] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const data = await api.getReportCatalogConfig();
        setCfg(data);
      } finally { setLoading(false); }
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = await api.setReportCatalogConfig(cfg);
      setCfg(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally { setSaving(false); }
  };

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress /></Box>;

  const toggles = [
    { key: 'enabled', label: 'Catalog Enabled' },
    { key: 'certification_enabled', label: 'Certification' },
    { key: 'template_gallery_enabled', label: 'Template Gallery' },
    { key: 'sharing_enabled', label: 'Report Sharing' },
    { key: 'embed_enabled', label: 'Report Embedding' },
  ];

  const numbers = [
    { key: 'max_shares_per_report', label: 'Max Shares per Report' },
    { key: 'max_embed_tokens_per_report', label: 'Max Embed Tokens per Report' },
    { key: 'share_default_expiry_hours', label: 'Share Default Expiry (hours)' },
    { key: 'embed_default_expiry_days', label: 'Embed Default Expiry (days)' },
    { key: 'embed_max_row_limit', label: 'Embed Max Row Limit' },
  ];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>Report Catalog Configuration</Typography>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {toggles.map(t => (
          <Paper key={t.key} variant="outlined" sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
            <input type="checkbox" checked={!!cfg[t.key]}
              onChange={e => setCfg((prev: any) => ({ ...prev, [t.key]: e.target.checked }))} />
            <Typography variant="body2">{t.label}</Typography>
          </Paper>
        ))}
      </Box>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
        {numbers.map(n => (
          <TextField key={n.key} label={n.label} type="number" size="small"
            value={cfg[n.key] ?? ''} fullWidth
            onChange={e => setCfg((prev: any) => ({ ...prev, [n.key]: parseInt(e.target.value) || 0 }))} />
        ))}
      </Box>

      <TextField
        label="Template Categories (comma-separated)"
        size="small" fullWidth sx={{ mb: 3 }}
        value={(cfg.template_categories || []).join(', ')}
        onChange={e => setCfg((prev: any) => ({
          ...prev,
          template_categories: e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean),
        }))}
      />

      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : saved ? 'Saved!' : 'Save Changes'}
        </Button>
      </Box>
    </Box>
  );
};

export default ReportCatalogAdminSection;
