/**
 * AWS Portal section — extracted from AdminPage.
 * Self-contained: manages own state and data fetching.
 * Shows portal status, configuration form (13 fields), Save/Test/Clear actions.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Typography, TextField, Button, CircularProgress,
  Stack, Chip, Alert, Switch, FormControlLabel,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';
import api from '../../services/api';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

interface FieldDef {
  key: string;
  label: string;
  type: 'text' | 'number' | 'password' | 'bool';
  help?: string;
}

const FIELDS: FieldDef[] = [
  { key: 'enabled', label: 'Enabled', type: 'bool' },
  { key: 'portal_base_url', label: 'Portal Base URL', type: 'text', help: 'e.g. https://awsportal.company.com \u2014 derives JWT, roles, creds endpoints' },
  { key: 'account_id', label: 'AWS Account ID', type: 'text' },
  { key: 'role_name', label: 'IAM Role Name (optional)', type: 'text', help: 'Filter for role lookup \u2014 leave blank to auto-discover from portal' },
  { key: 'service_username', label: 'Global Service Account Username (optional)', type: 'text', help: 'Fallback when a connection has no portal_username set. Leave blank to disable the global service account.' },
  { key: 'service_password', label: 'Global Service Account Password (optional)', type: 'password', help: 'Password for the global fallback service account.' },
  { key: 'proxy_host', label: 'Proxy Host', type: 'text', help: 'e.g. proxy.corp.com (leave empty if no proxy)' },
  { key: 'proxy_port', label: 'Proxy Port', type: 'number' },
  { key: 'proxy_username', label: 'Proxy Username', type: 'text' },
  { key: 'proxy_password', label: 'Proxy Password', type: 'password' },
  { key: 'verify_ssl', label: 'Verify SSL', type: 'bool' },
  { key: 'creds_ttl_seconds', label: 'Credential TTL (seconds)', type: 'number' },
  { key: 'timeout_seconds', label: 'Request Timeout (seconds)', type: 'number' },
];

const AWSPortalSection: React.FC<Props> = ({ addNotification }) => {
  const [awsPortalCfg, setAwsPortalCfg] = useState<Record<string, any> | null>(null);
  const [awsPortalStatus, setAwsPortalStatus] = useState<any>(null);
  const [awsPortalTestResult, setAwsPortalTestResult] = useState<any>(null);
  const [awsPortalSaving, setAwsPortalSaving] = useState(false);

  const loadAwsPortalData = useCallback(async () => {
    try {
      const [cfg, status] = await Promise.all([
        api.getAWSPortalConfig(),
        api.getAWSPortalStatus(),
      ]);
      setAwsPortalCfg(cfg);
      setAwsPortalStatus(status);
    } catch (e) {
      console.error('AWS portal load error', e);
    }
  }, []);

  useEffect(() => { loadAwsPortalData(); }, [loadAwsPortalData]);

  const handleSave = async () => {
    if (!awsPortalCfg) return;
    setAwsPortalSaving(true);
    try {
      const payload = { ...awsPortalCfg };
      if (payload.service_password === '********') delete payload.service_password;
      if (payload.proxy_password === '********') delete payload.proxy_password;
      await api.setAWSPortalConfig(payload);
      addNotification({ type: 'success', title: 'Saved', message: 'AWS portal config saved' });
      loadAwsPortalData();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save Failed', message: e.message || 'Save failed' });
    }
    setAwsPortalSaving(false);
  };

  const handleTest = async () => {
    setAwsPortalTestResult(null);
    try {
      const res = await api.testAWSPortalConfig();
      setAwsPortalTestResult(res);
    } catch (e: any) {
      setAwsPortalTestResult({ success: false, message: e.message });
    }
  };

  const handleClearCache = async () => {
    await api.clearAWSPortalCache();
    addNotification({ type: 'info', title: 'Cache Cleared', message: 'Portal credential cache cleared' });
    loadAwsPortalData();
  };

  if (!awsPortalCfg) {
    return <CircularProgress size={24} />;
  }

  return (
    <Stack spacing={2.5}>
      {/* Status card */}
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} gutterBottom>Portal Status</Typography>
        <Stack direction="row" spacing={2} alignItems="center">
          <Chip size="small" label={awsPortalStatus?.enabled ? 'Enabled' : 'Disabled'}
            color={awsPortalStatus?.enabled ? 'success' : 'default'} />
          <Chip size="small" label={`Mode: ${awsPortalStatus?.mode || 'N/A'}`} />
          {awsPortalStatus?.authenticated && (
            <Chip size="small" label={`Creds active \u2014 expires in ${Math.round((awsPortalStatus?.expires_in_seconds || 0) / 60)}m`}
              color="info" />
          )}
          {!awsPortalStatus?.authenticated && awsPortalStatus?.enabled && (
            <Chip size="small" label="Not authenticated" color="warning" />
          )}
        </Stack>
      </Paper>

      {/* Config form */}
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle2" fontWeight={700} gutterBottom>Configuration</Typography>
        <Stack spacing={1.5}>
          {FIELDS.map(f => f.type === 'bool' ? (
            <FormControlLabel key={f.key} label={f.label}
              control={<Switch checked={!!awsPortalCfg[f.key]}
                onChange={e => setAwsPortalCfg({ ...awsPortalCfg, [f.key]: e.target.checked })} />} />
          ) : (
            <TextField key={f.key} size="small" fullWidth label={f.label}
              type={f.type === 'password' ? 'password' : f.type === 'number' ? 'number' : 'text'}
              value={awsPortalCfg[f.key] ?? ''}
              helperText={f.help || ''}
              onChange={e => setAwsPortalCfg({ ...awsPortalCfg, [f.key]: f.type === 'number' ? Number(e.target.value) : e.target.value })} />
          ))}
        </Stack>
        <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
          <Button variant="contained" size="small" startIcon={<SaveIcon />} disabled={awsPortalSaving}
            onClick={handleSave}>Save</Button>
          <Button variant="outlined" size="small" onClick={handleTest}>Test Connection</Button>
          <Button variant="outlined" size="small" color="warning" onClick={handleClearCache}>Clear Cache</Button>
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
          Test Connection works WITHOUT a service account &mdash; runs a reachability check (URL + proxy + SSL)
          and reports the result.  Set service account credentials for a full auth test.
        </Typography>
        {awsPortalTestResult && (
          <Alert severity={awsPortalTestResult.success ? 'success' : 'error'} sx={{ mt: 1.5 }}>
            {awsPortalTestResult.mode === 'reachability' && (
              <Chip size="small" label="Reachability mode" sx={{ mr: 1, mb: 0.5 }} />
            )}
            {awsPortalTestResult.mode === 'full_auth' && (
              <Chip size="small" color="info" label="Full auth mode" sx={{ mr: 1, mb: 0.5 }} />
            )}
            <span>{awsPortalTestResult.message}</span>
            {awsPortalTestResult.access_key_prefix && ` (Key: ${awsPortalTestResult.access_key_prefix})`}
            {/* BF-395: per-step diagnostic table for full-auth mode */}
            {Array.isArray(awsPortalTestResult.steps) && awsPortalTestResult.steps.length > 0 && (
              <Stack sx={{ mt: 1.5 }} spacing={0.5}>
                {awsPortalTestResult.steps.map((s: any, i: number) => (
                  <Paper key={i} variant="outlined" sx={{ p: 1, bgcolor: 'background.default' }}>
                    <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                      <Chip
                        size="small"
                        label={s.ok ? '✓' : '✗'}
                        color={s.ok ? 'success' : 'error'}
                      />
                      <Typography variant="body2" fontWeight={600}>
                        {`Step ${i + 1}: ${s.name}`}
                      </Typography>
                      {s.http_status > 0 && (
                        <Chip size="small" variant="outlined" label={`HTTP ${s.http_status}`} />
                      )}
                    </Stack>
                    <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'text.secondary' }}>
                      {s.message}
                    </Typography>
                    {s.response_preview && (
                      <Typography variant="caption" sx={{
                        display: 'block', mt: 0.5, fontFamily: 'monospace',
                        fontSize: '0.7rem', whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                        color: 'text.disabled', maxHeight: 100, overflow: 'auto',
                      }}>
                        {s.response_preview}
                      </Typography>
                    )}
                  </Paper>
                ))}
              </Stack>
            )}
          </Alert>
        )}
      </Paper>
    </Stack>
  );
};

export default AWSPortalSection;
