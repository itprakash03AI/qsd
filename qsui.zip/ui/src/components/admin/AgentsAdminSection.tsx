/**
 * Self-Healing Agents admin section — Phase 120 + BF-352 + BF-364.
 *
 * Sections (top → bottom):
 *   1. Agent Configuration         GET    /api/admin/agents/config
 *   2. Agent Health (24h)          GET    /api/admin/agents/health   — BF-352
 *   3. Rules                       GET    /api/admin/agents/rules    — BF-352
 *      add / edit / delete         POST   /api/admin/agents/rules
 *                                  DELETE /api/admin/agents/rules/{id}
 *   4. Decision Stats              GET    /api/admin/agents/stats
 *   5. Decision History            GET    /api/admin/agents/history
 *   6. Dry-Run Test                POST   /api/admin/agents/test
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Paper, Box, Typography, Button, CircularProgress,
  LinearProgress, Stack, Chip, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TextField, Divider,
  Tooltip, TablePagination, IconButton, Switch,
  Dialog, DialogTitle, DialogContent, DialogActions,
  MenuItem, FormControl, InputLabel, Select, FormControlLabel, Checkbox,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  PlayArrow as TestIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import { toArray } from '../../utils/toArray';
import { fmtDate } from './adminUtils';
import StatCard from './StatCard';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

// Whitelist mirrors backend _AUTO_RETRY_STRATEGIES — admin can only pick a
// strategy the engine actually knows how to dispatch.
const STRATEGY_OPTIONS = [
  'add_partition_filter',
  'refresh_credentials',
  'reinstall_extension',
  'reduce_memory',
  'add_group_by',
  'qualify_ambiguous_columns',
  'refresh_schema',
  'check_permissions',
  'check_proxy_config',
  'retry_with_backoff',
  'check_disk_space',
  'check_sql_syntax',
  'verify_path',
  'none',
];

const SEVERITY_OPTIONS = ['info', 'warning', 'critical'];
const ACTION_OPTIONS = ['alert', 'notify', 'none'];
const OP_OPTIONS = ['>', '<', '>=', '<=', '=='];

interface AgentRule {
  id?: number;
  kind: 'query_fix' | 'dq';
  enabled: boolean;
  priority: number;
  name?: string | null;
  description: string;
  severity?: string | null;
  action?: string | null;
  pattern?: string | null;
  strategy?: string | null;
  max_retries?: number | null;
  metric?: string | null;
  op?: string | null;
  threshold?: number | null;
  message?: string | null;
  is_seed?: boolean;
  updated_at?: string | null;
  updated_by?: string | null;
}

const emptyRule = (kind: 'query_fix' | 'dq' = 'query_fix'): AgentRule => ({
  kind, enabled: true, priority: 100, description: '',
  pattern: '', strategy: 'verify_path', max_retries: 0,
  metric: '', op: '>', threshold: 0, message: '',
});

const AgentsAdminSection: React.FC<Props> = ({ addNotification }) => {
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [stats, setStats] = useState<any[]>([]);
  const [histPage, setHistPage] = useState(0);
  const [histPerPage, setHistPerPage] = useState(25);

  // BF-364: Health + Rules
  const [health, setHealth] = useState<any>(null);
  const [rules, setRules] = useState<AgentRule[]>([]);
  const [rulesKindFilter, setRulesKindFilter] = useState<'query_fix' | 'dq' | ''>('query_fix');
  const [rulesEnabledOnly, setRulesEnabledOnly] = useState(false);
  const [rulesLoading, setRulesLoading] = useState(false);
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [ruleDraft, setRuleDraft] = useState<AgentRule>(emptyRule());
  const [ruleSaving, setRuleSaving] = useState(false);
  const [ruleDeleting, setRuleDeleting] = useState<number | null>(null);

  // Dry-run test state
  const [testMsg, setTestMsg] = useState('');
  const [testType, setTestType] = useState('Exception');
  const [testResult, setTestResult] = useState<any>(null);
  const [testBusy, setTestBusy] = useState(false);

  const loadRules = useCallback(async (kind: string, enabledOnly: boolean) => {
    setRulesLoading(true);
    try {
      const params = new URLSearchParams();
      if (kind) params.set('kind', kind);
      if (enabledOnly) params.set('enabled_only', 'true');
      const data: any = await safeFetch(`/api/admin/agents/rules?${params}`);
      setRules(toArray(data));  // BF-430E
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Rules load failed', message: e.message });
    } finally {
      setRulesLoading(false);
    }
  }, [addNotification]);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [cfg, hist, st, hl] = await Promise.all([
        safeFetch('/api/admin/agents/config'),
        safeFetch('/api/admin/agents/history?limit=200'),
        safeFetch('/api/admin/agents/stats'),
        safeFetch('/api/admin/agents/health').catch(() => null),
      ]);
      setConfig(cfg);
      setHistory(toArray(hist));  // BF-430E
      setStats(toArray(st));      // BF-430E
      setHealth(hl);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Load Failed', message: e.message });
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  useEffect(() => { loadAll(); }, [loadAll]);
  useEffect(() => { loadRules(rulesKindFilter, rulesEnabledOnly); }, [loadRules, rulesKindFilter, rulesEnabledOnly]);

  // Poll every 30s
  useEffect(() => {
    const t = setInterval(loadAll, 30_000);
    return () => clearInterval(t);
  }, [loadAll]);

  const handleTest = async () => {
    if (!testMsg.trim()) return;
    setTestBusy(true);
    setTestResult(null);
    try {
      const res = await safeFetch('/api/admin/agents/test', {
        method: 'POST',
        body: JSON.stringify({ error_message: testMsg, error_type: testType }),
      });
      setTestResult(res);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Test Failed', message: e.message });
    } finally {
      setTestBusy(false);
    }
  };

  const openRuleDialog = (rule?: AgentRule) => {
    setRuleDraft(rule
      ? { ...rule }
      : emptyRule(rulesKindFilter || 'query_fix'));
    setRuleDialogOpen(true);
  };

  const closeRuleDialog = () => {
    setRuleDialogOpen(false);
    setRuleDraft(emptyRule());
  };

  const saveRule = async () => {
    // Client-side validation matching backend rules
    if (!ruleDraft.description?.trim()) {
      addNotification({ type: 'error', title: 'Rule invalid', message: 'Description is required' });
      return;
    }
    if (ruleDraft.kind === 'query_fix') {
      if (!ruleDraft.pattern?.trim() || !ruleDraft.strategy) {
        addNotification({ type: 'error', title: 'Rule invalid',
          message: 'query_fix rule requires pattern AND strategy' });
        return;
      }
      try { new RegExp(ruleDraft.pattern); }
      catch (e: any) {
        addNotification({ type: 'error', title: 'Invalid regex', message: e.message });
        return;
      }
    } else if (ruleDraft.kind === 'dq') {
      if (!ruleDraft.metric?.trim() || !ruleDraft.op || ruleDraft.threshold == null) {
        addNotification({ type: 'error', title: 'Rule invalid',
          message: 'dq rule requires metric, op, threshold' });
        return;
      }
    }

    setRuleSaving(true);
    try {
      const body: any = {
        kind: ruleDraft.kind,
        enabled: ruleDraft.enabled,
        priority: ruleDraft.priority,
        description: ruleDraft.description,
      };
      if (ruleDraft.id) body.id = ruleDraft.id;
      if (ruleDraft.name?.trim()) body.name = ruleDraft.name;
      if (ruleDraft.severity) body.severity = ruleDraft.severity;
      if (ruleDraft.action) body.action = ruleDraft.action;
      if (ruleDraft.kind === 'query_fix') {
        body.pattern = ruleDraft.pattern;
        body.strategy = ruleDraft.strategy;
        if (ruleDraft.max_retries != null) body.max_retries = ruleDraft.max_retries;
      } else {
        body.metric = ruleDraft.metric;
        body.op = ruleDraft.op;
        body.threshold = ruleDraft.threshold;
        if (ruleDraft.message?.trim()) body.message = ruleDraft.message;
      }
      await safeFetch('/api/admin/agents/rules', {
        method: 'POST',
        body: JSON.stringify(body),
      });
      addNotification({ type: 'success', title: ruleDraft.id ? 'Rule updated' : 'Rule created',
        message: ruleDraft.description.slice(0, 80) });
      closeRuleDialog();
      loadRules(rulesKindFilter, rulesEnabledOnly);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save failed', message: e.detail || e.message });
    } finally {
      setRuleSaving(false);
    }
  };

  const toggleRule = async (rule: AgentRule) => {
    try {
      await safeFetch('/api/admin/agents/rules', {
        method: 'POST',
        body: JSON.stringify({ id: rule.id, kind: rule.kind, enabled: !rule.enabled }),
      });
      loadRules(rulesKindFilter, rulesEnabledOnly);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Toggle failed', message: e.detail || e.message });
    }
  };

  const deleteRule = async (rule: AgentRule) => {
    if (!rule.id) return;
    if (!window.confirm(`Delete rule "${rule.description.slice(0, 60)}"?`)) return;
    setRuleDeleting(rule.id);
    try {
      await safeFetch(`/api/admin/agents/rules/${rule.id}`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Rule deleted', message: '' });
      loadRules(rulesKindFilter, rulesEnabledOnly);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Delete failed', message: e.detail || e.message });
    } finally {
      setRuleDeleting(null);
    }
  };

  const actionColor = (action: string) => {
    switch (action) {
      case 'retry_with_fix': return 'info';
      case 'notify_user': return 'warning';
      case 'escalate': return 'error';
      default: return 'default';
    }
  };

  return (
    <Box>
      {/* ── Config Overview ─────────────────────────────────────────────── */}
      <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="subtitle1" fontWeight={700}>Agent Configuration</Typography>
          <Button size="small" startIcon={<RefreshIcon />} onClick={loadAll} disabled={loading}>
            Refresh
          </Button>
        </Box>
        {loading && <LinearProgress sx={{ mb: 2 }} />}
        {config && (
          <>
            <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
              <StatCard label="Status" value={config.enabled ? 'Enabled' : 'Disabled'}
                warn={!config.enabled} />
              <StatCard label="Decision Engine" value={config.decision_engine || 'rules'} />
              <StatCard label="Registered Agents" value={config.agents?.length ?? 0} />
              {config.auto_retry_enabled != null && (
                <StatCard label="Auto-Retry" value={config.auto_retry_enabled ? 'On' : 'Off'} />
              )}
              {config.decision_engine === 'llm' && (
                <>
                  <StatCard label="LLM Provider" value={config.llm_provider || '—'} />
                  <StatCard label="LLM Model" value={config.llm_model || '—'} />
                </>
              )}
            </Stack>
            {config.agents?.length > 0 && (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['Agent', 'Description', 'Status', 'Reason'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {config.agents.map((a: any) => (
                      <TableRow key={a.name} hover>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontFamily: 'monospace' }}>{a.name}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem' }}>{a.description}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          <Chip size="small" label={a.enabled ? 'Active' : 'Disabled'}
                            color={a.enabled ? 'success' : 'default'} variant="outlined"
                            sx={{ height: 20, fontSize: 11 }} />
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.7rem', color: 'text.secondary' }}>
                          {a.reason || '—'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </Paper>

      {/* ── Health (24h) — BF-352 ─────────────────────────────────────── */}
      {health?.agents && health.agents.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1.5 }}>
            Agent Health <Typography component="span" variant="caption" color="text.secondary">— last 24 hours</Typography>
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {['Agent', 'Decisions 24h', 'Successes', 'Errors', 'Pending', 'Success rate', 'Last action', 'Last reason', 'Last seen'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {health.agents.map((a: any) => (
                  <TableRow key={a.name} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontFamily: 'monospace' }}>{a.name}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontWeight: 700 }}>
                      {(a.decisions_24h ?? 0).toLocaleString()}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', color: 'success.main' }}>
                      {(a.successes_24h ?? 0).toLocaleString()}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', color: (a.errors_24h ?? 0) > 0 ? 'error.main' : 'text.secondary' }}>
                      {(a.errors_24h ?? 0).toLocaleString()}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', color: 'text.secondary' }}>
                      {(a.pending_24h ?? 0).toLocaleString()}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>
                      {a.success_rate != null ? `${a.success_rate}%` : '—'}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      {a.last_action
                        ? <Chip size="small" label={a.last_action} color={actionColor(a.last_action) as any}
                            variant="outlined" sx={{ height: 20, fontSize: 11 }} />
                        : '—'}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.7rem', maxWidth: 280 }}>
                      <Tooltip title={a.last_reason || ''} arrow>
                        <Typography variant="body2" noWrap sx={{ fontSize: '0.7rem', maxWidth: 280 }}>
                          {a.last_reason || '—'}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.7rem', whiteSpace: 'nowrap' }}>
                      {a.last_decision_at ? fmtDate(a.last_decision_at) : '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* ── Rules CRUD — BF-352 ────────────────────────────────────────── */}
      <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5, flexWrap: 'wrap', gap: 1 }}>
          <Typography variant="subtitle1" fontWeight={700}>
            Rules
            <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
              ({rules.length} {rulesKindFilter || 'all'}{rulesEnabledOnly ? ' · enabled only' : ''})
            </Typography>
          </Typography>
          <Stack direction="row" spacing={1} alignItems="center">
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>Kind</InputLabel>
              <Select
                label="Kind"
                value={rulesKindFilter}
                onChange={(e) => setRulesKindFilter(e.target.value as any)}
                sx={{ fontSize: '0.8rem' }}
              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="query_fix">query_fix</MenuItem>
                <MenuItem value="dq">dq</MenuItem>
              </Select>
            </FormControl>
            <FormControlLabel
              control={<Checkbox size="small" checked={rulesEnabledOnly}
                onChange={(e) => setRulesEnabledOnly(e.target.checked)} />}
              label={<Typography sx={{ fontSize: '0.78rem' }}>Enabled only</Typography>}
            />
            <Button size="small" startIcon={<RefreshIcon />}
              onClick={() => loadRules(rulesKindFilter, rulesEnabledOnly)}
              disabled={rulesLoading}>
              Refresh
            </Button>
            <Button size="small" variant="contained" startIcon={<AddIcon />}
              onClick={() => openRuleDialog()}>
              Add rule
            </Button>
          </Stack>
        </Box>

        {rulesLoading && <LinearProgress sx={{ mb: 1 }} />}

        {rules.length === 0 && !rulesLoading ? (
          <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
            No rules — backend may not have seeded yet (restart) or filter excludes everything.
          </Typography>
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {['', 'Kind', 'Pri', 'Pattern / Metric', 'Strategy / Op·Threshold', 'Description', 'Retries', 'Source', 'Updated', 'Actions'].map((h, i) => (
                    <TableCell key={i} sx={{ fontWeight: 700, fontSize: '0.7rem', py: 0.5, px: 1 }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rules.map((r) => (
                  <TableRow key={r.id} hover sx={{ opacity: r.enabled ? 1 : 0.6 }}>
                    <TableCell sx={{ py: 0.25, px: 1 }}>
                      <Tooltip title={r.enabled ? 'Disable rule' : 'Enable rule'}>
                        <Switch size="small" checked={r.enabled} onChange={() => toggleRule(r)} />
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1 }}>
                      <Chip size="small" label={r.kind}
                        color={r.kind === 'query_fix' ? 'primary' : 'secondary'}
                        variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.72rem' }}>{r.priority}</TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.72rem', fontFamily: 'monospace', maxWidth: 280 }}>
                      <Tooltip title={r.kind === 'query_fix' ? (r.pattern || '') : (r.metric || '')} arrow>
                        <Typography variant="body2" noWrap sx={{ fontSize: '0.72rem', fontFamily: 'monospace', maxWidth: 280 }}>
                          {r.kind === 'query_fix' ? r.pattern : r.metric}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.72rem' }}>
                      {r.kind === 'query_fix'
                        ? <Chip size="small" label={r.strategy} variant="outlined"
                            sx={{ height: 18, fontSize: 10 }} />
                        : `${r.op} ${r.threshold}`}
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.72rem', maxWidth: 320 }}>
                      <Tooltip title={r.description || ''} arrow>
                        <Typography variant="body2" noWrap sx={{ fontSize: '0.72rem', maxWidth: 320 }}>
                          {r.description}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.72rem' }}>
                      {r.kind === 'query_fix' ? (r.max_retries ?? 0) : '—'}
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1 }}>
                      <Chip size="small" label={r.is_seed ? 'seed' : 'custom'}
                        color={r.is_seed ? 'default' : 'success'} variant="outlined"
                        sx={{ height: 18, fontSize: 10 }} />
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, fontSize: '0.7rem', whiteSpace: 'nowrap' }}>
                      {r.updated_at ? fmtDate(r.updated_at) : '—'}
                      {r.updated_by && (
                        <Typography component="div" variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                          by {r.updated_by}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell sx={{ py: 0.25, px: 1, whiteSpace: 'nowrap' }}>
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => openRuleDialog(r)}>
                          <EditIcon sx={{ fontSize: 16 }} />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <span>
                          <IconButton size="small" color="error" onClick={() => deleteRule(r)}
                            disabled={ruleDeleting === r.id}>
                            {ruleDeleting === r.id
                              ? <CircularProgress size={14} />
                              : <DeleteIcon sx={{ fontSize: 16 }} />}
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {/* ── Stats ───────────────────────────────────────────────────────── */}
      {stats.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1.5 }}>Decision Stats</Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {['Agent', 'Action', 'Count'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {stats.map((s: any, i: number) => (
                  <TableRow key={i} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontFamily: 'monospace' }}>{s.agent_name}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <Chip size="small" label={s.action} color={actionColor(s.action) as any}
                        variant="outlined" sx={{ height: 20, fontSize: 11 }} />
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontWeight: 700 }}>{s.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* ── Decision History ─────────────────────────────────────────────── */}
      <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
        <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1.5 }}>Decision History</Typography>
        {history.length === 0 && !loading ? (
          <Typography variant="body2" color="text.secondary">No agent decisions recorded yet.</Typography>
        ) : (
          <>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Time', 'Agent', 'Event', 'Action', 'Outcome', 'Reason', 'Confidence'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {history.slice(histPage * histPerPage, (histPage + 1) * histPerPage).map((d: any, i: number) => (
                    <TableRow key={d.id ?? i} hover>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', whiteSpace: 'nowrap' }}>
                        {fmtDate(d.created_at)}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem', fontFamily: 'monospace' }}>{d.agent_name}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem' }}>{d.event_type}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        <Chip size="small" label={d.action} color={actionColor(d.action) as any}
                          variant="outlined" sx={{ height: 20, fontSize: 11 }} />
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {d.success === true && <Chip size="small" label="Success" color="success" variant="outlined" sx={{ height: 20, fontSize: 11 }} />}
                        {d.success === false && <Chip size="small" label="Failed" color="error" variant="outlined" sx={{ height: 20, fontSize: 11 }} />}
                        {d.success == null && d.action === 'retry_with_fix' && <Chip size="small" label="Pending" color="default" variant="outlined" sx={{ height: 20, fontSize: 11 }} />}
                        {d.success == null && d.action !== 'retry_with_fix' && '—'}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', maxWidth: 300 }}>
                        <Tooltip title={d.reason || ''} arrow>
                          <Typography variant="body2" noWrap sx={{ fontSize: '0.72rem', maxWidth: 300 }}>
                            {d.reason}
                          </Typography>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem' }}>
                        {d.confidence != null ? `${Math.round(d.confidence * 100)}%` : '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              component="div" count={history.length} page={histPage}
              onPageChange={(_, p) => setHistPage(p)}
              rowsPerPage={histPerPage}
              onRowsPerPageChange={e => { setHistPerPage(+e.target.value); setHistPage(0); }}
              rowsPerPageOptions={[10, 25, 50, 100]}
              sx={{ '.MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows': { fontSize: '0.72rem' } }}
            />
          </>
        )}
      </Paper>

      {/* ── Dry-Run Test ─────────────────────────────────────────────────── */}
      <Paper variant="outlined" sx={{ p: 2.5 }}>
        <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1.5 }}>Dry-Run Test</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Test how the rules engine classifies an error message. Does NOT execute any fix.
        </Typography>
        <Stack direction="row" spacing={1.5} alignItems="flex-start" sx={{ mb: 2 }}>
          <TextField size="small" label="Error Message" value={testMsg}
            onChange={e => setTestMsg(e.target.value)}
            placeholder="e.g. timeout exceeded 300s"
            sx={{ flex: 2 }} />
          <TextField size="small" label="Error Type" value={testType}
            onChange={e => setTestType(e.target.value)}
            sx={{ flex: 1 }} />
          <Button variant="contained" size="small"
            startIcon={testBusy ? <CircularProgress size={14} /> : <TestIcon />}
            onClick={handleTest} disabled={testBusy || !testMsg.trim()}>
            Test
          </Button>
        </Stack>
        {testResult && (
          <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
            <Typography variant="caption" fontWeight={700} sx={{ mb: 1, display: 'block' }}>
              Classification Result
            </Typography>
            <Box component="pre" sx={{
              fontSize: '0.75rem', fontFamily: 'monospace', whiteSpace: 'pre-wrap',
              wordBreak: 'break-all', m: 0,
            }}>
              {JSON.stringify(testResult, null, 2)}
            </Box>
          </Paper>
        )}
      </Paper>

      {/* ── Rule Editor Dialog ──────────────────────────────────────────── */}
      <Dialog open={ruleDialogOpen} onClose={closeRuleDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {ruleDraft.id ? `Edit rule #${ruleDraft.id}` : 'Add rule'}
          {ruleDraft.is_seed && (
            <Typography variant="caption" color="warning.main" sx={{ display: 'block', fontSize: 11 }}>
              Editing a seed rule — your changes survive restart but next major release may re-seed.
              Consider adding a custom rule with priority 0 instead.
            </Typography>
          )}
        </DialogTitle>
        <DialogContent dividers>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <FormControl size="small" fullWidth>
              <InputLabel>Kind</InputLabel>
              <Select label="Kind" value={ruleDraft.kind}
                onChange={(e) => setRuleDraft({ ...ruleDraft, kind: e.target.value as any })}
                disabled={!!ruleDraft.id}>
                <MenuItem value="query_fix">query_fix — match an error pattern, dispatch a fix strategy</MenuItem>
                <MenuItem value="dq">dq — DQ threshold rule (metric op threshold)</MenuItem>
              </Select>
            </FormControl>

            <Stack direction="row" spacing={2}>
              <FormControlLabel
                control={<Switch checked={ruleDraft.enabled}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, enabled: e.target.checked })} />}
                label={ruleDraft.enabled ? 'Enabled' : 'Disabled'}
              />
              <TextField size="small" label="Priority" type="number"
                value={ruleDraft.priority}
                onChange={(e) => setRuleDraft({ ...ruleDraft, priority: parseInt(e.target.value, 10) || 0 })}
                helperText="Lower = checked first. 0 beats all built-ins."
                sx={{ flex: 1 }} />
              <TextField size="small" label="Name (optional)"
                value={ruleDraft.name || ''}
                onChange={(e) => setRuleDraft({ ...ruleDraft, name: e.target.value })}
                sx={{ flex: 1 }} />
            </Stack>

            <TextField size="small" label="Description" required
              value={ruleDraft.description}
              onChange={(e) => setRuleDraft({ ...ruleDraft, description: e.target.value })}
              multiline minRows={2} maxRows={4}
              helperText="Surfaced to admin/agent. Include the corrective action." />

            {ruleDraft.kind === 'query_fix' ? (
              <>
                <TextField size="small" label="Pattern (regex, case-insensitive)" required
                  value={ruleDraft.pattern || ''}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, pattern: e.target.value })}
                  helperText='Python regex. Multiple alternates with | (e.g. "timeout|exceeded \d+s")'
                  sx={{ fontFamily: 'monospace' }} />
                <FormControl size="small" fullWidth required>
                  <InputLabel>Strategy</InputLabel>
                  <Select label="Strategy" value={ruleDraft.strategy || 'verify_path'}
                    onChange={(e) => setRuleDraft({ ...ruleDraft, strategy: e.target.value })}>
                    {STRATEGY_OPTIONS.map((s) => (
                      <MenuItem key={s} value={s}>{s}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <TextField size="small" label="Max retries" type="number"
                  value={ruleDraft.max_retries ?? 0}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, max_retries: parseInt(e.target.value, 10) || 0 })}
                  helperText="0 = classify only, no auto-retry. 1-3 = auto-retry up to N times." />
              </>
            ) : (
              <>
                <TextField size="small" label="Metric" required
                  value={ruleDraft.metric || ''}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, metric: e.target.value })}
                  helperText="e.g. null_pct, row_count_ratio, freshness_hours, schema_columns_added" />
                <Stack direction="row" spacing={2}>
                  <FormControl size="small" required sx={{ minWidth: 100 }}>
                    <InputLabel>Op</InputLabel>
                    <Select label="Op" value={ruleDraft.op || '>'}
                      onChange={(e) => setRuleDraft({ ...ruleDraft, op: e.target.value })}>
                      {OP_OPTIONS.map((o) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <TextField size="small" label="Threshold" type="number" required
                    value={ruleDraft.threshold ?? 0}
                    onChange={(e) => setRuleDraft({ ...ruleDraft, threshold: parseFloat(e.target.value) || 0 })}
                    sx={{ flex: 1 }} />
                  <FormControl size="small" sx={{ minWidth: 130 }}>
                    <InputLabel>Severity</InputLabel>
                    <Select label="Severity" value={ruleDraft.severity || 'warning'}
                      onChange={(e) => setRuleDraft({ ...ruleDraft, severity: e.target.value })}>
                      {SEVERITY_OPTIONS.map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Stack>
                <Stack direction="row" spacing={2}>
                  <FormControl size="small" sx={{ minWidth: 130 }}>
                    <InputLabel>Action</InputLabel>
                    <Select label="Action" value={ruleDraft.action || 'alert'}
                      onChange={(e) => setRuleDraft({ ...ruleDraft, action: e.target.value })}>
                      {ACTION_OPTIONS.map((a) => <MenuItem key={a} value={a}>{a}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <TextField size="small" label="Message (optional)"
                    value={ruleDraft.message || ''}
                    onChange={(e) => setRuleDraft({ ...ruleDraft, message: e.target.value })}
                    sx={{ flex: 1 }} />
                </Stack>
              </>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeRuleDialog} disabled={ruleSaving}>Cancel</Button>
          <Button onClick={saveRule} variant="contained"
            disabled={ruleSaving || !ruleDraft.description?.trim()}
            startIcon={ruleSaving ? <CircularProgress size={14} /> : null}>
            {ruleDraft.id ? 'Save changes' : 'Create rule'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AgentsAdminSection;
