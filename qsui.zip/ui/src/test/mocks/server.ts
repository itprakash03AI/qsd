/**
 * Phase 121C — MSW test server.
 * Import and use server.use() in individual tests for per-test overrides.
 */
import { setupServer } from 'msw/node';
import { handlers } from './handlers';

export const server = setupServer(...handlers);
