/**
 * Phase 121C — Default MSW request handlers for tests.
 * Returns well-typed mock data matching backend API responses.
 * Per-test overrides via server.use() in individual test files.
 */
import { http, HttpResponse } from 'msw';

// ── Mock data ───────────────────────────────────────────────────────────────

export const mockConnections = [
  {
    id: 1,
    name: 'Test S3 Connection',
    type: 's3',
    config: { bucket: 'test-bucket', prefix: 'data/', region: 'us-east-1' },
    is_active: true,
    test_status: 'success',
    test_message: null,
    last_tested_at: '2024-06-01T10:00:00Z',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-06-01T10:00:00Z',
  },
  {
    id: 2,
    name: 'Test Snowflake',
    type: 'snowflake',
    config: { account: 'test.snowflakecomputing.com', database: 'ANALYTICS', schema: 'PUBLIC' },
    is_active: true,
    test_status: null,
    test_message: null,
    last_tested_at: null,
    created_at: '2024-02-15T00:00:00Z',
    updated_at: '2024-02-15T00:00:00Z',
  },
];

export const mockHealth = {
  status: 'ok',
  version: '1.0.0-test',
  uptime_seconds: 3600,
  database: 'sqlite',
  queue_backend: 'sqlite',
  worker_pool: { active: 0, max: 4 },
};

export const mockExecution = {
  id: 1,
  execution_id: 'exec-test-001',
  status: 'completed',
  query_config: { files: ['data/test.parquet'], columns: ['id', 'name', 'amount'] },
  connection_id: 1,
  row_count: 5,
  error_message: null,
  duration_ms: 120,
  created_at: '2024-06-15T12:00:00Z',
};

export const mockResults = {
  columns: ['id', 'name', 'amount'],
  rows: [
    { id: 1, name: 'Alice', amount: 100 },
    { id: 2, name: 'Bob', amount: 200 },
    { id: 3, name: 'Charlie', amount: 300 },
    { id: 4, name: 'Diana', amount: 400 },
    { id: 5, name: 'Eve', amount: 500 },
  ],
  total_rows: 5,
  page: 1,
  page_size: 100,
};

export const mockQueries = [
  {
    id: 1,
    name: 'Test Query',
    description: 'A test saved query',
    query_config: { files: ['data/test.parquet'] },
    connection_id: 1,
    created_by: 'testuser',
    is_active: true,
    is_favorite: false,
    folder: null,
    tags: ['test'],
    created_at: '2024-06-01T00:00:00Z',
    updated_at: '2024-06-01T00:00:00Z',
  },
];

// ── Handlers ────────────────────────────────────────────────────────────────

export const handlers = [
  // Connections
  http.get('*/api/connections', () => HttpResponse.json(mockConnections)),

  http.get('*/api/connections/:id', ({ params }) => {
    const conn = mockConnections.find(c => c.id === Number(params.id));
    return conn ? HttpResponse.json(conn) : HttpResponse.json({ detail: 'Not found' }, { status: 404 });
  }),

  http.post('*/api/connections/test', () =>
    HttpResponse.json({ status: 'success', message: 'Connection successful' }),
  ),

  // Execution
  http.post('*/api/execute', () => HttpResponse.json(mockExecution)),

  http.get('*/api/executions/:id', () => HttpResponse.json(mockExecution)),

  http.get('*/api/executions/:id/results', () => HttpResponse.json(mockResults)),

  // Queries
  http.get('*/api/queries', () => HttpResponse.json(mockQueries)),

  // Health
  http.get('*/health', () => HttpResponse.json(mockHealth)),

  // Admin health
  http.get('*/api/admin/health', () => HttpResponse.json(mockHealth)),

  // Auth config (needed by AuthContext)
  http.get('*/auth/config', () =>
    HttpResponse.json({ type: 'none', ad_server: null, ad_domain: null }),
  ),

  // ── CATCHALL safety net (Phase 133-G deep-dive) ────────────────────────
  // Prevents ECONNREFUSED on cross-test state-pollution: when a prior
  // test leaves a pending fetch and per-test handlers reset, the
  // leftover request would fall through ``onUnhandledRequest='bypass'``
  // and hit the real network.  Catchall returns an empty 200 JSON so
  // the request resolves cleanly without breaking the next test.
  // Per-test handlers added via ``server.use(...)`` always take
  // precedence over these defaults.
  http.get('*/api/*', () => HttpResponse.json({})),
  http.post('*/api/*', () => HttpResponse.json({})),
  http.put('*/api/*', () => HttpResponse.json({})),
  http.delete('*/api/*', () => HttpResponse.json({})),
];
