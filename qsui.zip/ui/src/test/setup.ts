import '@testing-library/jest-dom/vitest';
import { beforeAll, afterAll, afterEach } from 'vitest';
import { cleanup } from '@testing-library/react';
import { server } from './mocks/server';

// Start MSW server before all tests, reset handlers between tests, close after
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => {
  // Phase 133-G deep-dive — Unmount any leftover React components
  // BEFORE resetting MSW handlers.  Without explicit cleanup, a
  // pending fetch from a still-mounted component from the prior
  // test fires AFTER handlers reset → MSW bypasses → real network
  // attempt → ECONNREFUSED on the next test run.  Explicit cleanup
  // forces unmount + effect cleanup so all pending requests are
  // aborted before MSW handlers are swapped.
  cleanup();
  server.resetHandlers();
});
afterAll(() => server.close());
