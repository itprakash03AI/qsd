import React, { type ReactElement } from 'react';
import { render, type RenderOptions } from '@testing-library/react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { MemoryRouter } from 'react-router-dom';

const theme = createTheme();

// ── Mock context values for component tests ─────────────────────────────────
// Use with vi.mock() in individual test files:
//   vi.mock('../../context/AuthContext', () => ({ useAuth: () => mockUser }));

export const mockUser = {
  user: {
    username: 'testuser',
    display_name: 'Test User',
    email: 'test@example.com',
    groups: ['admin'],
    is_admin: true,
    role: 'admin',
  },
  authEnabled: false,
  isLoading: false,
  login: async () => {},
  logout: () => {},
  isSuperAdmin: false,
};

export const mockNotifications = {
  notifications: [],
  runningCount: 0,
  execLogs: [],
  unreadLogCount: 0,
  unreadNotifCount: 0,
  addNotification: () => {},
  removeNotification: () => {},
  clearAll: () => {},
  refreshUnreadCount: () => {},
  markLogsRead: () => {},
  clearLogs: () => {},
};

export const mockAppSettings = {
  limits: {
    col_auto_project: 50,
    default_query_limit: 1000,
    streaming_default_on: false,
    stream_bg_download_default: true,
    max_display_cols: 50,
    stream_query_limit_max: 5000,
    max_stream_files: 200,
  },
  features: {
    streaming_mode: 'all',
    streaming_enabled: true,
    export_enabled: true,
    sql_editor_enabled: true,
    scheduler_enabled: true,
    connections_enabled: true,
    upload_enabled: true,
    max_query_limit: 0,
  },
  query_guardrails: {
    enabled: true,
    max_files_warn: 500,
    max_files_block: 5000,
    max_rows_warn: 10000000,
    max_rows_block: 100000000,
    require_partition_filter: false,
    warn_no_partition: true,
    warn_no_limit: true,
    default_limit_suggestion: 1000,
  },
  role: 'admin',
  loaded: true,
  component_visibility: {},
};

// ── MSW server re-export for per-test overrides ─────────────────────────────
export { server } from './mocks/server';

/**
 * Render helper that wraps component with ThemeProvider + MemoryRouter.
 * For context mocking (Auth, Notifications, AppSettings), use vi.mock()
 * in your test file — see mockUser, mockNotifications, mockAppSettings above.
 */
export function renderWithProviders(
  ui: ReactElement,
  options?: RenderOptions & { route?: string },
) {
  const { route = '/', ...renderOptions } = options ?? {};
  function Wrapper({ children }: { children: React.ReactNode }) {
    return (
      <MemoryRouter initialEntries={[route]}>
        <ThemeProvider theme={theme}>{children}</ThemeProvider>
      </MemoryRouter>
    );
  }
  return render(ui, { wrapper: Wrapper, ...renderOptions });
}

export { render, screen, within, waitFor, act } from '@testing-library/react';
export { default as userEvent } from '@testing-library/user-event';
