/**
 * API Service — re-exports from domain modules in api/ directory.
 *
 * All consumers continue to use: `import api from '../services/api'`
 * Domain modules: api/core.ts, api/connections.ts, api/queries.ts,
 *   api/execution.ts, api/reports.ts, api/datasets.ts,
 *   api/businessReports.ts, api/admin.ts
 */

export { ApiError, safeFetch, sharedFetch, openDownload, toBackendQueryConfig, API_BASE_URL } from './api/core';
export type {
  QueryConfig, Connection, SavedQuery, Execution, Dataset,
  BusinessReport, DashboardItem, Widget, Schedule, Notification,
} from './api/core';

export { default } from './api/index';
