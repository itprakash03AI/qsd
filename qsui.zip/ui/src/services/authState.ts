/**
 * Auth state — leaf module with zero imports.
 * Breaks the circular dependency between core.ts and AuthContext.tsx.
 * Both modules import from here instead of from each other.
 */
let _authHeader: string | null = null;
export const getAuthHeader = () => _authHeader;
export const setAuthHeader = (h: string | null) => { _authHeader = h; };
