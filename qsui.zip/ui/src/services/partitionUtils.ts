/**
 * Partition utility functions (Phase 73).
 * Date detection, range generation, and bulk selection helpers.
 */

/** Patterns that indicate a partition column contains date-like values. */
const DATE_PATTERNS = [
  /^\d{4}-\d{2}-\d{2}$/,       // 2024-01-15
  /^\d{4}-\d{2}$/,              // 2024-01
  /^\d{8}$/,                    // 20240115
  /^\d{4}$/,                    // 2024 (year)
  /^\d{2}$/,                    // 01 (month or day)
];

const MONTH_NAMES = ['01','02','03','04','05','06','07','08','09','10','11','12'];

/**
 * Detect if a list of partition values looks like dates.
 * Returns the detected pattern type or null.
 */
export function detectDatePattern(values: string[]): 'date' | 'year-month' | 'year' | 'month' | null {
  if (!values.length) return null;
  const sample = values.slice(0, 10);

  if (sample.every(v => /^\d{4}-\d{2}-\d{2}$/.test(v))) return 'date';
  if (sample.every(v => /^\d{4}-\d{2}$/.test(v))) return 'year-month';
  if (sample.every(v => /^\d{4}$/.test(v) && +v >= 1990 && +v <= 2099)) return 'year';
  if (sample.every(v => /^\d{2}$/.test(v) && +v >= 1 && +v <= 12)) return 'month';

  return null;
}

/**
 * Generate a date range selection from allValues.
 * Returns the subset of allValues that fall within the range.
 */
export function selectDateRange(
  allValues: string[],
  rangeType: 'last7d' | 'last30d' | 'thisMonth' | 'lastMonth' | 'thisYear',
  pattern: 'date' | 'year-month' | 'year' | 'month',
): string[] {
  const now = new Date();
  const today = now.toISOString().slice(0, 10); // YYYY-MM-DD

  if (pattern === 'date') {
    const sorted = [...allValues].sort();
    let start: string;
    switch (rangeType) {
      case 'last7d': {
        const d = new Date(now);
        d.setDate(d.getDate() - 7);
        start = d.toISOString().slice(0, 10);
        return sorted.filter(v => v >= start && v <= today);
      }
      case 'last30d': {
        const d = new Date(now);
        d.setDate(d.getDate() - 30);
        start = d.toISOString().slice(0, 10);
        return sorted.filter(v => v >= start && v <= today);
      }
      case 'thisMonth': {
        start = today.slice(0, 7) + '-01';
        return sorted.filter(v => v >= start && v <= today);
      }
      case 'lastMonth': {
        const d = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        start = d.toISOString().slice(0, 10);
        const end = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().slice(0, 10);
        return sorted.filter(v => v >= start && v <= end);
      }
      case 'thisYear': {
        start = `${now.getFullYear()}-01-01`;
        return sorted.filter(v => v >= start && v <= today);
      }
      default: return allValues;
    }
  }

  if (pattern === 'year-month') {
    const sorted = [...allValues].sort();
    const thisYM = today.slice(0, 7);
    switch (rangeType) {
      case 'last7d':
      case 'last30d':
      case 'thisMonth':
        return sorted.filter(v => v === thisYM);
      case 'lastMonth': {
        const d = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const ym = d.toISOString().slice(0, 7);
        return sorted.filter(v => v === ym);
      }
      case 'thisYear': {
        const prefix = `${now.getFullYear()}-`;
        return sorted.filter(v => v.startsWith(prefix) && v <= thisYM);
      }
      default: return allValues;
    }
  }

  if (pattern === 'year') {
    const thisYear = String(now.getFullYear());
    switch (rangeType) {
      case 'last7d':
      case 'last30d':
      case 'thisMonth':
      case 'thisYear':
        return allValues.filter(v => v === thisYear);
      case 'lastMonth':
        return allValues.filter(v => v === thisYear);
      default: return allValues;
    }
  }

  // month pattern — just return all
  return allValues;
}

/**
 * Invert selection: return values that are NOT currently selected.
 */
export function invertSelection(allValues: string[], selected: string[]): string[] {
  const selectedSet = new Set(selected);
  return allValues.filter(v => !selectedSet.has(v));
}
