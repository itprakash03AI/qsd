/**
 * Login password encryption — RSA-OAEP-SHA256 via Web Crypto API.
 *
 * WHY:
 *   HTTPS hides the password from the network, but the plaintext is still
 *   visible in DevTools → Network → request payload (a regulator-flag in
 *   operational reviews even when transport is TLS).  Encrypting the
 *   password with the server's public key BEFORE sending closes that gap.
 *
 * FLOW:
 *   1. On first login attempt, fetch /auth/public-key (PEM + short fingerprint).
 *      Cache both in-memory for the session.
 *   2. Import the PEM into a `CryptoKey` via `crypto.subtle.importKey`.
 *   3. Encrypt the password via `crypto.subtle.encrypt({name:"RSA-OAEP"}, ...)`.
 *   4. POST { username, password_encrypted: <base64>, key_fingerprint } to
 *      /auth/login.  Server decrypts with its private key.
 *
 *   If /auth/login responds 400 ``login_crypto_stale_key`` (pod restart →
 *   key rotated), wipe the in-memory cache, refetch /auth/public-key, and
 *   retry the login transparently.  Called the "stale-key one-shot
 *   recovery" — the user never sees a failure.
 *
 * FALLBACK:
 *   If /auth/public-key returns 503 (cryptography package missing on the
 *   backend) OR `window.crypto.subtle` is unavailable (very old browser or
 *   non-HTTPS dev origin), fall back to sending the plaintext `password`
 *   field with a one-time console warning.  /auth/login still accepts
 *   plaintext for curl / Postman / mobile.
 */
import { API_BASE_URL } from './api/core';

interface PublicKeyResponse {
  algorithm:      string;
  hash:           string;
  key_size:       number;
  public_key_pem: string;
  fingerprint:    string;
}

// In-memory cache.  Cleared on hard reload / explicit reset on stale-key 400.
// Not persisted — re-fetching is one cheap GET per session.
let cachedKey:   CryptoKey | null = null;
let cachedFpr:   string | null = null;
let warnedNoCrypto = false;

function _pemToArrayBuffer(pem: string): ArrayBuffer {
  // Strip PEM header/footer + whitespace, base64-decode.  This is the
  // SubjectPublicKeyInfo DER blob the Web Crypto API expects for RSA-OAEP.
  const cleaned = pem
    .replace(/-----BEGIN PUBLIC KEY-----/g, '')
    .replace(/-----END PUBLIC KEY-----/g, '')
    .replace(/\s+/g, '');
  const bin = atob(cleaned);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
}

function _bufToBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let s = '';
  // Build the binary string in chunks so we don't blow the stack with
  // String.fromCharCode.apply on large buffers (RSA-2048 ciphertext is 256
  // bytes so this is overkill — but harmless and future-proof).
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    s += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
  }
  return btoa(s);
}

/** Best-effort detection that Web Crypto subtle API + RSA-OAEP are usable
 *  in the current context.  Web Crypto requires a secure context (https://
 *  or localhost) — falls back gracefully when not.  */
export function isLoginCryptoAvailable(): boolean {
  try {
    return typeof window !== 'undefined'
      && typeof window.crypto !== 'undefined'
      && typeof window.crypto.subtle !== 'undefined'
      && typeof window.crypto.subtle.importKey === 'function';
  } catch {
    return false;
  }
}

async function _fetchAndImportKey(): Promise<{ key: CryptoKey; fingerprint: string } | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/auth/public-key`, {
      method: 'GET',
      cache: 'no-cache',
    });
    if (!res.ok) {
      // 503 = backend doesn't have cryptography installed; any other
      // non-200 we treat the same way — fall back to plaintext.
      if (!warnedNoCrypto) {
        console.warn(
          `[loginCrypto] /auth/public-key returned ${res.status} — falling back to plaintext password ` +
          `over HTTPS.  This is safe in transit but the password will appear in DevTools Network tab.`,
        );
        warnedNoCrypto = true;
      }
      return null;
    }
    const body = (await res.json()) as PublicKeyResponse;
    if (!body?.public_key_pem || !body?.fingerprint) return null;

    const key = await window.crypto.subtle.importKey(
      'spki',
      _pemToArrayBuffer(body.public_key_pem),
      { name: 'RSA-OAEP', hash: 'SHA-256' },
      false, // not extractable — we only use it to encrypt
      ['encrypt'],
    );
    return { key, fingerprint: body.fingerprint };
  } catch (err) {
    if (!warnedNoCrypto) {
      console.warn(
        '[loginCrypto] failed to fetch/import public key — falling back to plaintext:', err,
      );
      warnedNoCrypto = true;
    }
    return null;
  }
}

/** Force a refetch of the server public key.  Called by the login flow
 *  when /auth/login returns 400 login_crypto_stale_key (pod restart or
 *  key rotation race). */
export function resetLoginCryptoCache(): void {
  cachedKey = null;
  cachedFpr = null;
}

/** Returned to the login caller so it can POST the right body shape. */
export interface EncryptedPasswordPayload {
  password_encrypted: string;
  key_fingerprint:    string;
}

/** Encrypt the password using the cached/refreshed public key.  Returns
 *  null when crypto is unavailable end-to-end (caller falls back to the
 *  plaintext `password` field). */
export async function encryptPassword(password: string): Promise<EncryptedPasswordPayload | null> {
  if (!isLoginCryptoAvailable()) return null;

  if (cachedKey === null || cachedFpr === null) {
    const fetched = await _fetchAndImportKey();
    if (!fetched) return null;
    cachedKey = fetched.key;
    cachedFpr = fetched.fingerprint;
  }

  try {
    const plain = new TextEncoder().encode(password);
    const cipher = await window.crypto.subtle.encrypt(
      { name: 'RSA-OAEP' },
      cachedKey,
      plain,
    );
    return {
      password_encrypted: _bufToBase64(cipher),
      key_fingerprint:    cachedFpr,
    };
  } catch (err) {
    console.warn('[loginCrypto] encrypt failed — falling back to plaintext:', err);
    // Invalidate cache so the next attempt refetches (the imported key
    // may be the source of the failure rather than the runtime).
    resetLoginCryptoCache();
    return null;
  }
}
