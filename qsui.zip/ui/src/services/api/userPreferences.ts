/**
 * Phase 100 — User Preferences API client.
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const userPreferences = {
  listUserPreferences: () =>
    safeFetch('/api/user-preferences'),
  getUserPreference: (key: string) =>
    safeFetch(`/api/user-preferences/${encodeURIComponent(key)}`),
  setUserPreference: (key: string, value: string | null) =>
    safeFetch('/api/user-preferences', {
      method: 'PUT',
      body: safeStringify({ key, value }),
    }),
  setUserPreferencesBulk: (preferences: Record<string, string | null>) =>
    safeFetch('/api/user-preferences/bulk', {
      method: 'PUT',
      body: safeStringify({ preferences }),
    }),
  deleteUserPreference: (key: string) =>
    safeFetch(`/api/user-preferences/${encodeURIComponent(key)}`, { method: 'DELETE' }),
};

export default userPreferences;
