/**
 * API — DataFlow Engine (Phase 132).
 *
 * Wraps every endpoint exposed by backend/api/workflow_api.py.
 * Public surface mirrors the FastAPI routes 1:1 for predictability.
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

// ── Types ────────────────────────────────────────────────────────────────

export interface StageDef {
  stage_alias: string;
  stage_type: string;
  seq: number;
  predecessors?: string[];
  config?: Record<string, any>;
  retry_policy?: Record<string, any>;
  timeout_seconds?: number | null;
  on_failure?: 'halt' | 'continue' | 'branch_to';
  on_failure_target?: string | null;
}


/** Phase 133-E follow-up — collect every Dynamic WHERE-clause row
 *  across all stages in a DataFlow.  Returned rows tell the caller
 *  which columns the user should be prompted to override before
 *  starting a run.  Static rows are excluded (they always apply).
 */
export interface DynamicDataflowRow {
  stageAlias: string;
  column: string;
  operator: string;
  value: any;
  /** Phase 133-H — stage's connection_id (or source_connection_id /
   *  src_connection_id), used by the override dialog to drive
   *  ``/api/sql/distinct-values`` for the value picker. */
  connectionId?: number | null;
  /** Phase 133-H — first FROM table out of the stage's SQL, used
   *  alongside connectionId for the distinct-values lookup. */
  table?: string | null;
}

const _SQL_KEYS_FOR_HINT = ['sql', 'query', 'raw_sql', 'source_query',
                            'secondary_raw_sql', 'select_sql'];

function _extractFirstFromTable(stageConfig: Record<string, any>): string | null {
  const blob = _SQL_KEYS_FOR_HINT
    .map(k => (typeof stageConfig[k] === 'string' ? stageConfig[k] : ''))
    .filter(Boolean)
    .join('\n');
  if (!blob) return null;
  const m = blob.match(/\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i);
  return m ? m[1].replace(/[\s"`\[\]]/g, '') : null;
}

export function collectDataflowDynamicRows(
  df: { stages?: StageDef[] | null } | null | undefined,
): DynamicDataflowRow[] {
  if (!df || !Array.isArray(df.stages)) return [];
  const out: DynamicDataflowRow[] = [];
  for (const stage of df.stages) {
    const cfg = stage?.config || {};
    const wc: any = cfg['where_clauses'];
    if (!Array.isArray(wc)) continue;
    const cid = (
      cfg['connection_id']
      ?? cfg['source_connection_id']
      ?? cfg['src_connection_id']
      ?? null
    );
    const cidNum = (typeof cid === 'number' && Number.isFinite(cid)) ? cid : null;
    const tableHint = _extractFirstFromTable(cfg);
    for (const r of wc) {
      if (!r || (r.mode || 'static') !== 'dynamic') continue;
      const col = (r.column || '').trim();
      if (!col) continue;
      out.push({
        stageAlias: stage.stage_alias || '(stage)',
        column: col,
        operator: r.operator || 'eq',
        value: r.value,
        connectionId: cidNum,
        table: tableHint,
      });
    }
  }
  return out;
}

export interface DataFlowDef {
  id: number;
  name: string;
  version: number;
  status: 'draft' | 'active' | 'archived';
  description?: string | null;
  trigger_type: string;
  trigger_config?: Record<string, any>;
  default_context?: Record<string, any>;
  stages: StageDef[];
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  // Phase 132.20
  is_paused?:        boolean;
  sla_seconds?:      number | null;
  is_template?:      boolean;
  template_category?: string | null;
  template_label?:    string | null;
  // Phase 132.21
  tags?:             string[];
  depends_on_previous?: boolean;
  // Phase 132.25
  max_run_seconds?:  number | null;
  // Phase 132.26
  workspace_id?:     number | null;
}

export interface DataFlowNotificationPolicy {
  id: number;
  name: string;
  event: 'run_failed' | 'run_succeeded' | 'run_partial' | 'run_cancelled' | 'sla_breached' | 'schedule_missed';
  channel: 'email' | 'webhook' | 'ws';
  dataflow_id?: number | null;
  tag?: string | null;
  config?: Record<string, any>;
  is_active: boolean;
  cooldown_seconds: number;
  last_fired_at?: string | null;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface DataFlowRunStage {
  id: number;
  run_id: number;
  stage_alias: string;
  stage_type: string;
  seq: number;
  status: 'not_started' | 'running' | 'succeeded' | 'failed' | 'skipped' | 'cancelled';
  attempts: number;
  inputs?: Record<string, any>;
  outputs?: Record<string, any>;
  error?: string | null;
  log_lines?: string[];
  started_at?: string | null;
  ended_at?: string | null;
  duration_seconds?: number | null;
  worker_node?: string | null;
}

export interface DataFlowRun {
  id: number;
  dataflow_id: number;
  dataflow_version: number;
  dataflow_name: string;
  status: 'pending' | 'running' | 'succeeded' | 'failed' | 'cancelled' | 'partial';
  triggered_by?: string | null;
  run_as?: string | null;
  trigger_payload?: Record<string, any>;
  context?: Record<string, any>;
  outputs?: Record<string, any>;
  error?: string | null;
  started_at?: string | null;
  ended_at?: string | null;
  duration_seconds?: number | null;
  worker_node?: string | null;
  parent_run_id?: number | null;
  expected_completion_at?: string | null;
  sla_breached?: boolean;
  created_at?: string | null;
  stages?: DataFlowRunStage[];
}

export interface DataFlowSchedule {
  id: number;
  dataflow_id: number;
  name: string;
  cron_expression: string;
  calendar_rule?: Record<string, any> | null;
  timezone: string;
  context_overrides?: Record<string, any>;
  is_active: boolean;
  last_run_at?: string | null;
  next_run_at?: string | null;
  created_by?: string | null;
}

export interface StageTypeManifest {
  name: string;
  display_name?: string;
  category: string;
  class_path: string;
  description?: string;
  config_schema?: Record<string, any>;
  inputs_schema?: Record<string, any>;
  outputs_schema?: Record<string, any>;
  is_control_flow: boolean;
  idempotency: string;
}

export interface DataFlowTemplate {
  name: string;
  description?: string;
  stage_count: number;
  trigger_type: string;
}

export interface ApprovalRequest {
  id: number;
  run_id: number;
  stage_alias: string;
  dataflow_name: string;
  title?: string;
  description?: string;
  requested_by?: string | null;
  decided_by?: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  decision_notes?: string | null;
  payload?: Record<string, any>;
  created_at?: string;
  decided_at?: string | null;
  expires_at?: string | null;
}

// ── DataFlow CRUD ────────────────────────────────────────────────────────

const dataflows = {
  listDataFlows: (params?: { name?: string; status?: string }) => {
    const qs = new URLSearchParams();
    if (params?.name)   qs.set('name', params.name);
    if (params?.status) qs.set('status', params.status);
    const q = qs.toString();
    return safeFetch(`/api/dataflows${q ? '?' + q : ''}`);
  },

  getDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}`),

  createDataFlow: (body: Omit<DataFlowDef,
    'id' | 'version' | 'status' | 'created_by' | 'created_at' | 'updated_at'>) =>
    safeFetch('/api/dataflows', {
      method: 'POST', body: safeStringify(body),
    }),

  addVersion: (id: number, body: Omit<DataFlowDef,
    'id' | 'version' | 'status' | 'created_by' | 'created_at' | 'updated_at'>) =>
    safeFetch(`/api/dataflows/${id}/versions`, {
      method: 'POST', body: safeStringify(body),
    }),

  promoteDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/promote`, { method: 'POST' }),

  archiveDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/archive`, { method: 'POST' }),

  // Phase 132.20 — soft-pause / resume (separate from archive)
  pauseDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/pause`, { method: 'POST' }),

  resumeDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/resume`, { method: 'POST' }),

  setDataFlowSla: (id: number, slaSeconds: number | null) =>
    safeFetch(`/api/dataflows/${id}/sla`, {
      method: 'PATCH',
      body: safeStringify({ sla_seconds: slaSeconds }),
    }),

  // Phase 132.25 — hard timeout (cancels the run; vs. SLA which only flags)
  setDataFlowMaxRunSeconds: (id: number, maxRunSeconds: number | null) =>
    safeFetch(`/api/dataflows/${id}/max-run-seconds`, {
      method: 'PATCH',
      body: safeStringify({ max_run_seconds: maxRunSeconds }),
    }),

  // Pre-run cost estimate (Airflow-style "estimate before run")
  estimateDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/estimate`),

  // Phase 132.21 — cost history (observed vs static)
  dataflowCostHistory: (id: number, limit = 20) =>
    safeFetch(`/api/dataflows/${id}/cost-history?limit=${limit}`),

  // Tags + run-to-run dependency
  setDataFlowTags: (id: number, tags: string[]) =>
    safeFetch(`/api/dataflows/${id}/tags`, {
      method: 'PATCH', body: safeStringify({ tags }),
    }),

  setDependsOnPrevious: (id: number, dependsOnPrevious: boolean) =>
    safeFetch(`/api/dataflows/${id}/depends-on-previous`, {
      method: 'PATCH',
      body: safeStringify({ depends_on_previous: dependsOnPrevious }),
    }),

  listAllTags: () =>
    safeFetch('/api/dataflows/tags'),

  // Bulk actions
  bulkResumeRuns: (runIds: number[]) =>
    safeFetch('/api/dataflow-runs/bulk-resume', {
      method: 'POST', body: safeStringify({ run_ids: runIds }),
    }),

  bulkPauseDataFlows: (dataflowIds: number[]) =>
    safeFetch('/api/dataflows/bulk-pause', {
      method: 'POST', body: safeStringify({ dataflow_ids: dataflowIds }),
    }),

  bulkResumeDataFlows: (dataflowIds: number[]) =>
    safeFetch('/api/dataflows/bulk-resume', {
      method: 'POST', body: safeStringify({ dataflow_ids: dataflowIds }),
    }),

  // Notification policies
  listNotificationPolicies: () =>
    safeFetch('/api/dataflows/notification-policies'),

  createNotificationPolicy: (body: {
    name: string; event: string; channel: string;
    dataflow_id?: number | null; tag?: string | null;
    config?: Record<string, any>; is_active?: boolean;
    cooldown_seconds?: number;
  }) =>
    safeFetch('/api/dataflows/notification-policies', {
      method: 'POST', body: safeStringify(body),
    }),

  updateNotificationPolicy: (id: number, body: any) =>
    safeFetch(`/api/dataflows/notification-policies/${id}`, {
      method: 'PATCH', body: safeStringify(body),
    }),

  deleteNotificationPolicy: (id: number) =>
    safeFetch(`/api/dataflows/notification-policies/${id}`, { method: 'DELETE' }),

  // Phase 132.22 — schedule preview
  previewSchedule: (body: {
    cron_expression?: string; calendar_rule?: Record<string, any>;
    timezone?: string; count?: number;
  }) =>
    safeFetch('/api/dataflows/schedules/preview', {
      method: 'POST', body: safeStringify(body),
    }),

  // Webhook triggers
  listWebhookTriggers: (dataflowId?: number) => {
    const qs = dataflowId != null ? `?dataflow_id=${dataflowId}` : '';
    return safeFetch(`/api/dataflows/webhook-triggers${qs}`);
  },

  createWebhookTrigger: (body: {
    dataflow_id: number; name: string;
    allowed_ips?: string[]; is_active?: boolean;
    require_signature?: boolean;
  }) =>
    safeFetch('/api/dataflows/webhook-triggers', {
      method: 'POST', body: safeStringify(body),
    }),

  deleteWebhookTrigger: (id: number) =>
    safeFetch(`/api/dataflows/webhook-triggers/${id}`, { method: 'DELETE' }),

  // Project Variables
  listVariables: (dataflowId?: number) => {
    const qs = dataflowId != null ? `?dataflow_id=${dataflowId}` : '';
    return safeFetch(`/api/dataflows/variables${qs}`);
  },

  createVariable: (body: {
    name: string; value: string;
    dataflow_id?: number | null; description?: string;
    is_secret?: boolean;
  }) =>
    safeFetch('/api/dataflows/variables', {
      method: 'POST', body: safeStringify(body),
    }),

  updateVariable: (id: number, body: any) =>
    safeFetch(`/api/dataflows/variables/${id}`, {
      method: 'PATCH', body: safeStringify(body),
    }),

  deleteVariable: (id: number) =>
    safeFetch(`/api/dataflows/variables/${id}`, { method: 'DELETE' }),

  // Connection compat check
  checkConnections: (dataflowId: number) =>
    safeFetch(`/api/dataflows/${dataflowId}/check-connections`, { method: 'POST' }),

  // Phase 132.23
  dryRun: (dataflowId: number) =>
    safeFetch(`/api/dataflows/${dataflowId}/dry-run`),

  exportBundle: (dataflowId: number) =>
    safeFetch(`/api/dataflows/${dataflowId}/bundle`),

  importBundle: (bundle: any, opts?: { name_override?: string; overwrite?: boolean }) =>
    safeFetch('/api/dataflows/bundle-import', {
      method: 'POST',
      body: safeStringify({ bundle, ...(opts || {}) }),
    }),

  listRunAnnotations: (runId: number) =>
    safeFetch(`/api/dataflow-runs/${runId}/annotations`),

  addRunAnnotation: (runId: number, body: { note: string; severity?: string }) =>
    safeFetch(`/api/dataflow-runs/${runId}/annotations`, {
      method: 'POST', body: safeStringify(body),
    }),

  exportDataFlow: (id: number) =>
    safeFetch(`/api/dataflows/${id}/export`, { method: 'POST' }),

  importDataFlow: (body: any) =>
    safeFetch('/api/dataflows/import', {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Stage type catalogue & templates ───────────────────────────────────

  listStageTypes: () =>
    safeFetch('/api/dataflows/stage-types'),

  listTemplates: () =>
    safeFetch('/api/dataflows/templates'),

  listJobTypes: () =>
    safeFetch('/api/dataflows/job-types'),

  getTemplate: (name: string) =>
    safeFetch(`/api/dataflows/templates/${encodeURIComponent(name)}`),

  cloneDataFlow: (id: number, nameOverride?: string) =>
    safeFetch(`/api/dataflows/${id}/clone`, {
      method: 'POST',
      body: safeStringify({ name_override: nameOverride }),
    }),

  checkNameAvailable: (name: string) =>
    safeFetch(`/api/dataflows/names/check?name=${encodeURIComponent(name)}`),

  applyTemplate: (name: string, override?: string) =>
    safeFetch(`/api/dataflows/templates/${encodeURIComponent(name)}/apply`, {
      method: 'POST',
      body: safeStringify({ name_override: override }),
    }),

  // ── Custom Stage Types (admin can register new ETL bridges via UI) ──

  listCustomStageTypes: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/dataflows/custom-stage-types${q ? '?' + q : ''}`);
  },

  createCustomStageType: (body: {
    name: string;
    category: string;
    description?: string;
    etl_module: string;
    etl_class: string;
    config_schema?: Record<string, any>;
    idempotency?: string;
    is_active?: boolean;
  }) =>
    safeFetch('/api/dataflows/custom-stage-types', {
      method: 'POST', body: safeStringify(body),
    }),

  updateCustomStageType: (id: number, body: any) =>
    safeFetch(`/api/dataflows/custom-stage-types/${id}`, {
      method: 'PATCH', body: safeStringify(body),
    }),

  deleteCustomStageType: (id: number) =>
    safeFetch(`/api/dataflows/custom-stage-types/${id}`, { method: 'DELETE' }),

  // ── Runs ───────────────────────────────────────────────────────────────

  startRun: (workflowName: string, body: {
    context?: any;
    trigger_payload?: any;
    run_as?: string | null;
    allow_paused?: boolean;
  } = {}) =>
    safeFetch(`/api/dataflows/${encodeURIComponent(workflowName)}/runs`, {
      method: 'POST', body: safeStringify(body),
    }),

  backfillDataFlow: (dataflowName: string, body: {
    start_date:     string;
    end_date:       string;
    skip_weekends?: boolean;
    extra_context?: Record<string, any>;
    pacing_seconds?: number;
    run_as?:        string | null;
  }) =>
    safeFetch(`/api/dataflows/${encodeURIComponent(dataflowName)}/backfill`, {
      method: 'POST', body: safeStringify(body),
    }),

  listRuns: (params?: { dataflow_id?: number; status?: string; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.dataflow_id !== undefined) qs.set('dataflow_id', String(params.dataflow_id));
    if (params?.status)                     qs.set('status', params.status);
    if (params?.limit !== undefined)        qs.set('limit', String(params.limit));
    const q = qs.toString();
    return safeFetch(`/api/dataflow-runs${q ? '?' + q : ''}`);
  },

  getRun: (id: number) =>
    safeFetch(`/api/dataflow-runs/${id}`),

  cancelRun: (id: number) =>
    safeFetch(
      `/api/dataflow-runs/${id}/cancel`, { method: 'POST' },
    ),

  resumeRun: (id: number) =>
    safeFetch(
      `/api/dataflow-runs/${id}/resume`, { method: 'POST' },
    ),

  rerunStage: (id: number, stageAlias: string, forceUnsafe = false) =>
    safeFetch(
      `/api/dataflow-runs/${id}/rerun-stage`, {
        method: 'POST',
        body: safeStringify({ stage_alias: stageAlias, force_unsafe: forceUnsafe }),
      },
    ),

  // ── Schedules ──────────────────────────────────────────────────────────

  listSchedules: (params?: { dataflow_id?: number; is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.dataflow_id !== undefined) qs.set('dataflow_id', String(params.dataflow_id));
    if (params?.is_active !== undefined)   qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/dataflows/schedules${q ? '?' + q : ''}`);
  },

  createSchedule: (body: {
    dataflow_id: number; name: string;
    cron_expression?: string | null;
    calendar_rule?: Record<string, any> | null;
    timezone?: string;
    context_overrides?: Record<string, any>;
    is_active?: boolean;
  }) =>
    safeFetch('/api/dataflows/schedules', {
      method: 'POST', body: safeStringify(body),
    }),

  updateSchedule: (id: number, body: Partial<DataFlowSchedule>) =>
    safeFetch(`/api/dataflows/schedules/${id}`, {
      method: 'PATCH', body: safeStringify(body),
    }),

  deleteSchedule: (id: number) =>
    safeFetch(
      `/api/dataflows/schedules/${id}`, { method: 'DELETE' },
    ),

  schedulerTickDebug: () =>
    safeFetch('/api/dataflows/scheduler/tick', { method: 'POST' }),

  schedulerStart: () =>
    safeFetch('/api/dataflows/scheduler/start', { method: 'POST' }),

  schedulerStop: () =>
    safeFetch('/api/dataflows/scheduler/stop', { method: 'POST' }),

  // ── Approvals ──────────────────────────────────────────────────────────

  listApprovals: (params?: { status?: string; run_id?: number; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.status)               qs.set('status', params.status);
    if (params?.run_id !== undefined) qs.set('run_id', String(params.run_id));
    if (params?.limit !== undefined)  qs.set('limit', String(params.limit));
    const q = qs.toString();
    return safeFetch(`/api/dataflows/approvals${q ? '?' + q : ''}`);
  },

  decideApproval: (id: number, decision: 'approve' | 'reject', notes?: string) =>
    safeFetch(`/api/dataflows/approvals/${id}/decide`, {
      method: 'POST',
      body: safeStringify({ decision, decision_notes: notes }),
    }),
};

export default dataflows;
