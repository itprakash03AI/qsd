/**
 * API — Parametric Reports, Catalog, Folders, Tags, Bookmarks, Formatting,
 *        Alerts, Bursting, RLS, PDF, Embed
 */
import { safeFetch, openDownload } from './core';
import { safeStringify } from '../../utils/safeStringify';

const reports = {
  // ── Reports ─────────────────────────────────────────────────────────────
  listReports: (activeOnly = true) =>
    safeFetch(`/api/reports?active_only=${activeOnly}`).catch(() => []),
  createReport: (data: object) => safeFetch('/api/reports', { method: 'POST', body: safeStringify(data) }),
  getReport: (id: string) => safeFetch(`/api/reports/${id}`),
  updateReport: (id: string, data: object) =>
    safeFetch(`/api/reports/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteReport: (id: string) => safeFetch(`/api/reports/${id}`, { method: 'DELETE' }),
  executeReport: (id: string, paramValues: object = {}, rowLimit: number | null = null, executedBy: string | null = null) =>
    safeFetch(`/api/reports/${id}/execute`, {
      method: 'POST',
      body: safeStringify({ param_values: paramValues, row_limit: rowLimit, executed_by: executedBy }),
    }),
  getReportSourceInfo: (id: string) => safeFetch(`/api/reports/${id}/source-info`),
  getReportColumns: (id: string) =>
    safeFetch(`/api/reports/${id}/columns`).catch(() => ({ columns: [], date_shortcuts: [] })),
  getPreviewColumns: (savedQueryId?: number) => {
    const qs = savedQueryId ? `?saved_query_id=${savedQueryId}` : '';
    return safeFetch(`/api/reports/preview-columns${qs}`).catch(() => ({ columns: [] }));
  },
  getReportParamValues: (id: string, paramName: string, limit = 1000) =>
    safeFetch(`/api/reports/${id}/param-values?param_name=${encodeURIComponent(paramName)}&limit=${limit}`)
      .catch(() => ({ values: [], total: 0, truncated: false })),
  downloadReportDirect: (id: string, paramValues: Record<string, string> = {}, format = 'csv') => {
    const params = { ...paramValues, format };
    const qs = new URLSearchParams(params).toString();
    openDownload(`/api/reports/${id}/download${qs ? '?' + qs : ''}`);
  },
  suggestReportParams: (data: object) =>
    safeFetch('/api/reports/suggest-params', { method: 'POST', body: safeStringify(data) })
      .catch(() => ({ suggested_params: [], raw_partitions: [] })),
  getReportHistory: (id: string, limit = 20) =>
    safeFetch(`/api/reports/${id}/history?limit=${limit}`)
      .catch(() => ({ executions: [], total: 0 })),
  scheduleReport: (id: string, config: object) =>
    safeFetch(`/api/reports/${id}/schedule`, { method: 'POST', body: safeStringify(config) }),
  unscheduleReport: (id: string) =>
    safeFetch(`/api/reports/${id}/schedule`, { method: 'DELETE' }),
  previewDownloadFile: (fileId: string, page = 1, pageSize = 100) =>
    safeFetch(`/api/downloads/${fileId}/preview?page=${page}&page_size=${pageSize}`),

  // ── Report Catalog ──────────────────────────────────────────────────────
  getReportCatalog: () =>
    safeFetch('/api/report-catalog').catch(() => ({ folders: [], tags: [], favorites: [], recent: [] })),
  listReportFolders: (parentId?: number) =>
    safeFetch(`/api/report-folders${parentId != null ? `?parent_id=${parentId}` : ''}`).catch(() => ({ folders: [] })),
  createReportFolder: (data: object) =>
    safeFetch('/api/report-folders', { method: 'POST', body: safeStringify(data) }),
  updateReportFolder: (id: number, data: object) =>
    safeFetch(`/api/report-folders/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteReportFolder: (id: number) =>
    safeFetch(`/api/report-folders/${id}`, { method: 'DELETE' }),
  assignReportFolder: (reportId: number, folderId: number | null, reportType = 'parametric') =>
    safeFetch(`/api/reports/${reportId}/folder`, { method: 'POST', body: safeStringify({ folder_id: folderId, report_type: reportType }) }),
  listReportTags: () =>
    safeFetch('/api/report-tags').catch(() => ({ tags: [] })),
  createReportTag: (data: object) =>
    safeFetch('/api/report-tags', { method: 'POST', body: safeStringify(data) }),
  deleteReportTag: (id: number) =>
    safeFetch(`/api/report-tags/${id}`, { method: 'DELETE' }),
  assignReportTags: (reportId: number, tagIds: number[], reportType = 'parametric') =>
    safeFetch(`/api/reports/${reportId}/tags?report_type=${reportType}`, { method: 'POST', body: safeStringify({ tag_ids: tagIds }) }),
  getReportTags: (reportId: number, reportType = 'parametric') =>
    safeFetch(`/api/reports/${reportId}/tags?report_type=${reportType}`),
  toggleReportFavorite: (reportId: number, reportType = 'parametric') =>
    safeFetch(`/api/reports/${reportId}/favorite?report_type=${reportType}`, { method: 'POST' }),
  getReportFavorites: (reportType?: string) =>
    safeFetch(`/api/reports/favorites${reportType ? `?report_type=${reportType}` : ''}`),
  recordReportView: (reportId: number, reportType = 'parametric') =>
    safeFetch(`/api/reports/${reportId}/view?report_type=${reportType}`, { method: 'POST' }).catch(() => {}),
  getRecentReports: (limit = 10, reportType?: string) =>
    safeFetch(`/api/reports/recent?limit=${limit}${reportType ? `&report_type=${reportType}` : ''}`),
  searchReportCatalog: (q: string, limit = 30) =>
    safeFetch(`/api/reports/search?q=${encodeURIComponent(q)}&limit=${limit}`).catch(() => ({ results: [], count: 0 })),
  searchReportsUnified: (q: string, limit = 30) =>
    safeFetch(`/api/reports/search?q=${encodeURIComponent(q)}&limit=${limit}`),

  // ── PDF Export ──────────────────────────────────────────────────────────
  downloadReportPDF: (reportId: number, paramValues: Record<string, string> = {}) => {
    const qs = new URLSearchParams(paramValues).toString();
    openDownload(`/api/reports/${reportId}/download-pdf${qs ? '?' + qs : ''}`);
  },
  getReportPDFConfig: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/pdf-config`).catch(() => ({})),
  updateReportPDFConfig: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/pdf-config`, { method: 'PUT', body: safeStringify(data) }),

  // ── Bookmarks ───────────────────────────────────────────────────────────
  listReportBookmarks: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/bookmarks`).catch(() => ({ bookmarks: [] })),
  saveReportBookmark: (reportId: number, name: string, paramValues: object) =>
    safeFetch(`/api/reports/${reportId}/bookmarks`, {
      method: 'POST',
      body: safeStringify({ name, param_values: paramValues }),
    }),
  deleteReportBookmark: (bookmarkId: number) =>
    safeFetch(`/api/reports/bookmarks/${bookmarkId}`, { method: 'DELETE' }),

  // ── Conditional Formatting ──────────────────────────────────────────────
  getConditionalFormats: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/formatting`).catch(() => ({ rules: [] })),
  saveConditionalFormats: (reportId: number, rules: object[]) =>
    safeFetch(`/api/reports/${reportId}/formatting`, { method: 'PUT', body: safeStringify({ rules }) }),

  // ── Alert Rules ─────────────────────────────────────────────────────────
  listAlertRules: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/alerts`).catch(() => ({ rules: [] })),
  createAlertRule: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/alerts`, { method: 'POST', body: safeStringify(data) }),
  updateAlertRule: (ruleId: number, data: object) =>
    safeFetch(`/api/reports/alerts/${ruleId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteAlertRule: (ruleId: number) =>
    safeFetch(`/api/reports/alerts/${ruleId}`, { method: 'DELETE' }),
  getAlertHistory: (ruleId: number, limit = 50) =>
    safeFetch(`/api/reports/alerts/${ruleId}/history?limit=${limit}`).catch(() => ({ history: [] })),

  // ── Report Bursting ─────────────────────────────────────────────────────
  triggerBurst: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/burst`, { method: 'POST', body: safeStringify(data) }),
  getBurstJob: (jobId: number) =>
    safeFetch(`/api/reports/burst/${jobId}`),
  cancelBurstJob: (jobId: number) =>
    safeFetch(`/api/reports/burst/${jobId}/cancel`, { method: 'POST' }),
  listBurstJobs: (reportId: number, limit = 20) =>
    safeFetch(`/api/reports/${reportId}/burst-jobs?limit=${limit}`).catch(() => ({ jobs: [] })),

  // ── RLS Policies ────────────────────────────────────────────────────────
  listRLSPolicies: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/rls`).catch(() => ({ policies: [] })),
  createRLSPolicy: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/rls`, { method: 'POST', body: safeStringify(data) }),
  updateRLSPolicy: (policyId: number, data: object) =>
    safeFetch(`/api/reports/rls/${policyId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteRLSPolicy: (policyId: number) =>
    safeFetch(`/api/reports/rls/${policyId}`, { method: 'DELETE' }),
  previewRLS: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/rls/preview`, { method: 'POST', body: '{}' }).catch(() => ({ where_clauses: [] })),

  // ── Embedded Reports ────────────────────────────────────────────────────
  createEmbedToken: (reportId: number, expiresInDays: number | null = null) =>
    safeFetch(`/api/reports/${reportId}/embed-tokens`, {
      method: 'POST',
      body: safeStringify({ expires_in_days: expiresInDays }),
    }),
  listEmbedTokens: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/embed-tokens`).catch(() => ({ tokens: [] })),
  revokeEmbedToken: (token: string) =>
    safeFetch(`/api/reports/embed-tokens/${token}`, { method: 'DELETE' }),
  getEmbeddedReport: (token: string) =>
    safeFetch(`/api/embedded-report/${token}`),
  executeEmbeddedReport: (token: string, paramValues: object = {}, limit = 1000) =>
    safeFetch(`/api/embedded-report/${token}/execute`, {
      method: 'POST',
      body: safeStringify({ param_values: paramValues, limit }),
    }),
};

export default reports;
