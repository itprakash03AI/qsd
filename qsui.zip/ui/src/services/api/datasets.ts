/**
 * API — Datasets, Semantic Layer, Federation, Aggregation Cache
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const datasets = {
  // ── Datasets ────────────────────────────────────────────────────────────
  listDatasets: (subject?: string) =>
    safeFetch(`/api/datasets${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`),
  createDataset: (data: Record<string, any>) =>
    safeFetch('/api/datasets', { method: 'POST', body: safeStringify(data) }),
  getDataset: (id: number) =>
    safeFetch(`/api/datasets/${id}`),
  updateDataset: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDataset: (id: number) =>
    safeFetch(`/api/datasets/${id}`, { method: 'DELETE' }),
  toggleDatasetPublish: (id: number) =>
    safeFetch(`/api/datasets/${id}/publish`, { method: 'POST' }),
  autoDetectColumns: (id: number) =>
    safeFetch(`/api/datasets/${id}/auto-detect`, { method: 'POST' }),
  previewDatasetColumns: (connectionId: number, tablePath: string) =>
    safeFetch('/api/datasets/preview-columns', {
      method: 'POST', body: safeStringify({ connection_id: connectionId, table_path: tablePath }),
    }),
  // Phase 85E: preview endpoint for wizard live data preview
  previewDatasetSource: (body: {
    connection_id: number;
    sql?: string;
    table_name?: string;
    columns?: string[];
    limit?: number;
  }) =>
    safeFetch('/api/datasets/preview', { method: 'POST', body: safeStringify(body) }),
  // Phase 85E: schema inference with typed columns for a table
  getDatasetTableSchema: (connectionId: number, tableName: string) =>
    safeFetch(`/api/datasets/connections/${connectionId}/schema/${encodeURIComponent(tableName)}`),

  // ── Dataset Classes ─────────────────────────────────────────────────────
  listDatasetClasses: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/classes`),
  createDatasetClass: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/classes`, { method: 'POST', body: safeStringify(data) }),
  updateDatasetClass: (classId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/classes/${classId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDatasetClass: (classId: number) =>
    safeFetch(`/api/datasets/classes/${classId}`, { method: 'DELETE' }),

  // ── Dataset Columns ─────────────────────────────────────────────────────
  listDatasetColumns: (datasetId: number, columnType?: string) =>
    safeFetch(`/api/datasets/${datasetId}/columns${columnType ? `?column_type=${columnType}` : ''}`),
  createDatasetColumn: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/columns`, { method: 'POST', body: safeStringify(data) }),
  bulkCreateDatasetColumns: (datasetId: number, columns: Record<string, any>[]) =>
    safeFetch(`/api/datasets/${datasetId}/columns/bulk`, { method: 'POST', body: safeStringify({ columns }) }),
  updateDatasetColumn: (columnId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/columns/${columnId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDatasetColumn: (columnId: number) =>
    safeFetch(`/api/datasets/columns/${columnId}`, { method: 'DELETE' }),

  // ── Dataset Relationships ───────────────────────────────────────────────
  listDatasetRelationships: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/relationships`),
  createDatasetRelationship: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/relationships`, { method: 'POST', body: safeStringify(data) }),
  updateDatasetRelationship: (relId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/relationships/${relId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDatasetRelationship: (relId: number) =>
    safeFetch(`/api/datasets/relationships/${relId}`, { method: 'DELETE' }),

  // ── Drill Hierarchies ──────────────────────────────────────────────────
  listDrillHierarchies: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/hierarchies`),
  createDrillHierarchy: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/hierarchies`, { method: 'POST', body: safeStringify(data) }),
  updateDrillHierarchy: (hierarchyId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/hierarchies/${hierarchyId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDrillHierarchy: (hierarchyId: number) =>
    safeFetch(`/api/datasets/hierarchies/${hierarchyId}`, { method: 'DELETE' }),

  // ── Pre-defined Conditions ──────────────────────────────────────────────
  listPreDefinedConditions: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/conditions`),
  createPreDefinedCondition: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/conditions`, { method: 'POST', body: safeStringify(data) }),
  updatePreDefinedCondition: (condId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/conditions/${condId}`, { method: 'PUT', body: safeStringify(data) }),
  deletePreDefinedCondition: (condId: number) =>
    safeFetch(`/api/datasets/conditions/${condId}`, { method: 'DELETE' }),

  // ── Aggregation Awareness ───────────────────────────────────────────────
  listAggAwareness: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/agg-awareness`),
  createAggAwareness: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/agg-awareness`, { method: 'POST', body: safeStringify(data) }),
  deleteAggAwareness: (aggId: number) =>
    safeFetch(`/api/datasets/agg-awareness/${aggId}`, { method: 'DELETE' }),

  // ── Federation Engine ───────────────────────────────────────────────────
  executeDataset: (datasetId: number, body: {
    column_ids: number[];
    filters?: any[];
    condition_ids?: number[];
    order_by?: any[];
    limit?: number;
  }) =>
    safeFetch(`/api/datasets/${datasetId}/execute`, { method: 'POST', body: safeStringify(body) }),
  executeMergedDatasets: (body: {
    primary_dataset_id: number;
    secondary_dataset_id: number;
    primary_column_ids: number[];
    secondary_column_ids: number[];
    merge_keys: { left: string; right: string }[];
    merge_type?: string;
    primary_filters?: any[];
    secondary_filters?: any[];
    primary_condition_ids?: number[];
    secondary_condition_ids?: number[];
    limit?: number;
  }) =>
    safeFetch('/api/datasets/federation/execute', { method: 'POST', body: safeStringify(body) }),
  previewDataset: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/preview`),
  getColumnValues: (datasetId: number, body: {
    column_id: number;
    parent_filters?: any[];
    limit?: number;
  }) =>
    safeFetch(`/api/datasets/${datasetId}/column-values`, { method: 'POST', body: safeStringify(body) }),
  listDatasetExecutions: (datasetId: number, limit?: number) =>
    safeFetch(`/api/datasets/${datasetId}/executions${limit ? `?limit=${limit}` : ''}`),
  getFederationExecutionDetail: (executionId: string) =>
    safeFetch(`/api/datasets/executions/${executionId}`),
  getFederationExecutionResults: (executionId: string, offset?: number, limit?: number) => {
    const params = new URLSearchParams();
    if (offset !== undefined) params.set('offset', String(offset));
    if (limit !== undefined) params.set('limit', String(limit));
    const qs = params.toString();
    return safeFetch(`/api/datasets/executions/${executionId}/results${qs ? `?${qs}` : ''}`);
  },

  // ── Merged Dimensions ───────────────────────────────────────────────────
  listMergedDimensions: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/merged-dimensions`),
  createMergedDimension: (body: {
    primary_dataset_id: number;
    secondary_dataset_id: number;
    name: string;
    merge_keys: { left: string; right: string }[];
    merge_type?: string;
    is_active?: boolean;
  }) =>
    safeFetch('/api/datasets/merged-dimensions', { method: 'POST', body: safeStringify(body) }),
  updateMergedDimension: (mdId: number, body: Record<string, any>) =>
    safeFetch(`/api/datasets/merged-dimensions/${mdId}`, { method: 'PUT', body: safeStringify(body) }),
  deleteMergedDimension: (mdId: number) =>
    safeFetch(`/api/datasets/merged-dimensions/${mdId}`, { method: 'DELETE' }),

  // ── Aggregation Cache ───────────────────────────────────────────────────
  listAggCacheEntries: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/agg-cache`),
  createAggCacheEntry: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/agg-cache`, { method: 'POST', body: safeStringify(data) }),
  getAggCacheEntry: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`),
  updateAggCacheEntry: (entryId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteAggCacheEntry: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`, { method: 'DELETE' }),
  triggerAggCacheBuild: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}/build`, { method: 'POST' }),
};

export default datasets;
