/**
 * Phase 130 — Business Query Builder API service.
 *
 * Auto-maps raw column names to business-friendly names with categories.
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

export interface MappedColumn {
  physical_name: string;
  friendly_name: string;
  category: string;
  column_type: 'dimension' | 'measure';
  data_type: 'string' | 'number' | 'date' | 'boolean';
  aggregation: string;
  is_partition: boolean;
  description: string;
  source_table: string;
  sort_order: number;
}

export interface ColumnCategory {
  name: string;
  count: number;
  sort_order: number;
}

export interface AutoMapResponse {
  columns: MappedColumn[];
  categories: ColumnCategory[];
  partition_columns: string[];
}

const businessQueryBuilderService = {
  /** Auto-map raw columns to business-friendly names with categories.
   *
   * ``refresh: true`` bypasses the L1 + L2 schema cache and forces a
   * fresh live S3 read.  Matches the CQB schema-refresh semantic.  If
   * the live read fails (S3 503, expired creds, etc) and a cached
   * entry exists, the backend returns the cached entry rather than
   * 5xx-ing the request — stale-while-revalidate.
   */
  autoMapColumns: (body: {
    connection_id: number;
    table_paths: string[];
    include_partitions?: boolean;
    refresh?: boolean;
  }): Promise<AutoMapResponse> =>
    safeFetch('/api/columns/auto-map', {
      method: 'POST',
      body: safeStringify(body),
    }),

  /** Save a user correction to a column's friendly name. */
  saveColumnOverride: (body: {
    physical_name: string;
    friendly_name: string;
    category?: string;
  }): Promise<{ status: string }> =>
    safeFetch('/api/columns/override', {
      method: 'POST',
      body: safeStringify(body),
    }),
};

export default businessQueryBuilderService;
