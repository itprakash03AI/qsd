/**
 * Reconciliation API client (Phase 133).
 *
 * Same request shape the backend's Pydantic ``ReconciliationCreate``
 * accepts.  Two query shapes supported:
 *   * ``query`` — single SQL used on BOTH sides (preferred for recon
 *     reports where the SQL is portable).
 *   * ``source_query`` + ``dest_query`` — used when dialects differ
 *     (e.g. Starburst-side vs Oracle-side).
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';


/** Per-row WhereClauseMapping — same shape as Published Views, Feed
 *  Generation, and DataFlow stages.  See backend
 *  ``core.where_clause_mapping.WhereClauseMapping``. */
export interface WhereClauseMappingRow {
  column: string;
  operator?: 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte'
            | 'in' | 'not_in' | 'contains' | 'not_contains'
            | 'between' | 'is_null' | 'is_not_null';
  value?: any;
  mode?: 'static' | 'dynamic';
}


export interface ReconciliationEntity {
  id: number;
  name: string;
  description?: string | null;
  is_active: boolean;
  source_connection_id: number;
  dest_connection_id: number;
  etl_connection_id?: number | null;
  sql_file_id?: number | null;
  /** Phase 133-F UX — independent .sql file per side (higher
   *  precedence than sql_file_id).  When both are set the runner
   *  loads source from source_sql_file_id and destination from
   *  dest_sql_file_id, no -- PRIMARY/-- SECONDARY markers needed. */
  source_sql_file_id?: number | null;
  dest_sql_file_id?:   number | null;
  query?: string | null;
  source_query?: string | null;
  dest_query?: string | null;
  comparison_mode: 'row_count' | 'row_count_sum' | 'row_by_row' | 'checksum';
  comparison_columns: string[];
  key_columns: string[];
  max_rows_compared: number;
  tolerance: number;
  tolerance_pct: number;
  dag_ids: (number | string)[];
  business_date_template: string;
  auto_reload_on_break: boolean;
  reload_package_template?: string | null;
  schedule_enabled: boolean;
  check_interval_hours: number;
  /** Phase 133-E — dynamic parameterize.  Static rows always apply;
   *  Dynamic rows are overrideable per trigger via
   *  ``checkNow({ queryParamOverrides })``. */
  where_clauses_mapping?: WhereClauseMappingRow[] | null;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  last_checked_at?: string | null;
  last_status?: 'ok' | 'break' | 'error' | null;
  last_source_row_count?: number | null;
  last_dest_row_count?: number | null;
  last_break_details?: Record<string, any>;
  last_reload_triggered_at?: string | null;
}


export interface ReconciliationRun {
  id: number;
  entity_id: number;
  triggered_by: string;
  triggered_by_user?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  status: 'running' | 'completed' | 'failed';
  business_date?: string | null;
  source_row_count?: number | null;
  dest_row_count?: number | null;
  source_sums?: Record<string, any>;
  dest_sums?: Record<string, any>;
  break_detected: boolean;
  break_details?: Record<string, any>;
  source_query_ms?: number | null;
  dest_query_ms?: number | null;
  reload_triggered: boolean;
  reload_error?: string | null;
  error_message?: string | null;
}


const reconciliation = {
  dashboard: () =>
    safeFetch('/api/reconciliation/dashboard'),

  list: (params?: { is_active?: boolean; status?: string }) => {
    const q = new URLSearchParams();
    if (params?.is_active !== undefined) {
      q.set('is_active', String(params.is_active));
    }
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return safeFetch(
      `/api/reconciliation/entities${qs ? `?${qs}` : ''}`,
    ) as Promise<ReconciliationEntity[]>;
  },

  get: (id: number) =>
    safeFetch(`/api/reconciliation/entities/${id}`) as
      Promise<ReconciliationEntity>,

  create: (data: Partial<ReconciliationEntity>) =>
    safeFetch('/api/reconciliation/entities',
              { method: 'POST', body: safeStringify(data) }) as
      Promise<ReconciliationEntity>,

  update: (id: number, data: Partial<ReconciliationEntity>) =>
    safeFetch(`/api/reconciliation/entities/${id}`,
              { method: 'PUT', body: safeStringify(data) }) as
      Promise<ReconciliationEntity>,

  deactivate: (id: number) =>
    safeFetch(`/api/reconciliation/entities/${id}`,
              { method: 'DELETE' }),

  runs: (id: number, limit = 50) =>
    safeFetch(
      `/api/reconciliation/entities/${id}/runs?limit=${limit}`,
    ) as Promise<ReconciliationRun[]>,

  /** Run the comparison NOW (synchronous) and return the run row.
   *
   *  @param businessDate         Optional YYYY-MM-DD override.
   *  @param queryParamOverrides  Phase 133-E — per-trigger overrides for
   *                              Dynamic rows on the entity's
   *                              ``where_clauses_mapping``.  Keyed by
   *                              column name.  Static rows ignore this.
   */
  checkNow: (
    id: number,
    businessDate?: string,
    queryParamOverrides?: Record<string, any>,
  ) => {
    const body: Record<string, any> = {};
    if (businessDate) body.business_date = businessDate;
    if (queryParamOverrides && Object.keys(queryParamOverrides).length) {
      body.query_param_overrides = queryParamOverrides;
    }
    return safeFetch(`/api/reconciliation/entities/${id}/check`, {
      method: 'POST',
      body: safeStringify(body),
    }) as Promise<{ run: ReconciliationRun; break_detected: boolean }>;
  },

  /** Fire the Oracle reload PL/SQL package (owner or admin only). */
  reloadNow: (id: number, businessDate?: string) =>
    safeFetch(`/api/reconciliation/entities/${id}/reload`, {
      method: 'POST',
      body: safeStringify(
        businessDate ? { business_date: businessDate } : {},
      ),
    }) as Promise<{ ok: boolean; elapsed_ms: number;
                     business_date: string; dag_ids: any[] }>,
};

export default reconciliation;
