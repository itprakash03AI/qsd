/**
 * API — Metadata Catalog (Phase 88 / Phase 92)
 *
 * Phase 88: GET /api/catalog/tables — list all registered tables
 * Phase 92: favorites, descriptions, preview, health
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const metadataCatalog = {
  /** Get catalog for all connections (or a specific one). */
  getCatalogTables: (connectionId?: number) => {
    const qs = connectionId !== undefined ? `?connection_id=${connectionId}` : '';
    return safeFetch(`/api/catalog/tables${qs}`);
  },

  /** Get full Iceberg metadata JSON for a specific table. */
  getTableMetadata: (connectionId: number, tableName: string) =>
    safeFetch(`/api/catalog/tables/${connectionId}/${encodeURIComponent(tableName)}/metadata`),

  /** Get top-N rows preview for a registered table. Phase 92. */
  getTablePreview: (connectionId: number, tableName: string, limit = 10) =>
    safeFetch(
      `/api/catalog/tables/${connectionId}/${encodeURIComponent(tableName)}/preview?limit=${limit}`,
    ),

  /** Get file health analysis (size, freshness, score). Phase 92. */
  getTableHealth: (connectionId: number, tableName: string) =>
    safeFetch(
      `/api/catalog/tables/${connectionId}/${encodeURIComponent(tableName)}/health`,
    ),

  /** Admin: update the description for a registered table. Phase 92. */
  updateTableDescription: (connectionId: number, tableName: string, description: string) =>
    safeFetch(
      `/api/catalog/tables/${connectionId}/${encodeURIComponent(tableName)}/description`,
      {
        method: 'PUT',
        body: safeStringify({ description }),
      },
    ),

  /** Toggle a table as favorite/unfavorite for the current user. Phase 92. */
  toggleCatalogFavorite: (connectionId: number, tableName: string) =>
    safeFetch('/api/catalog/favorites/toggle', {
      method: 'POST',
      body: safeStringify({
        connection_id: connectionId,
        table_name: tableName,
        table_path: `__registered__:${tableName}`,
      }),
    }),

  /** List current user's favorited catalog tables. Phase 92. */
  listCatalogFavorites: (connectionId?: number) => {
    const qs = connectionId !== undefined ? `?connection_id=${connectionId}` : '';
    return safeFetch(`/api/catalog/favorites${qs}`);
  },
};

export default metadataCatalog;
