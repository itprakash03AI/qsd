/**
 * API — Data Quality Monitoring (Phase 99)
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const dataQuality = {
  // ── Rules CRUD ────────────────────────────────────────────────────────────
  listDQRules: (params?: { target_type?: string; target_id?: number; enabled_only?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.target_type) qs.set('target_type', params.target_type);
    if (params?.target_id != null) qs.set('target_id', String(params.target_id));
    if (params?.enabled_only) qs.set('enabled_only', 'true');
    const q = qs.toString();
    return safeFetch(`/api/data-quality/rules${q ? '?' + q : ''}`);
  },

  getDQRule: (ruleId: number) =>
    safeFetch(`/api/data-quality/rules/${ruleId}`),

  createDQRule: (data: {
    name: string;
    description?: string;
    rule_type: 'freshness' | 'schema_drift' | 'null_rate' | 'row_count' | 'custom_sql';
    target_type?: string;
    target_id?: number;
    target_table?: string;
    column_name?: string;
    config?: Record<string, any>;
    schedule_cron?: string;
    enabled?: boolean;
    severity?: 'info' | 'warning' | 'critical';
  }) =>
    safeFetch('/api/data-quality/rules', { method: 'POST', body: safeStringify(data) }),

  updateDQRule: (ruleId: number, data: Record<string, any>) =>
    safeFetch(`/api/data-quality/rules/${ruleId}`, { method: 'PUT', body: safeStringify(data) }),

  deleteDQRule: (ruleId: number) =>
    safeFetch(`/api/data-quality/rules/${ruleId}`, { method: 'DELETE' }),

  // ── Run ───────────────────────────────────────────────────────────────────
  runDQRule: (ruleId: number) =>
    safeFetch(`/api/data-quality/rules/${ruleId}/run`, { method: 'POST' }),

  runAllDQRules: () =>
    safeFetch('/api/data-quality/run-all', { method: 'POST' }),

  // ── Results ───────────────────────────────────────────────────────────────
  listDQResults: (params?: { rule_id?: number; passed?: boolean; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.rule_id != null) qs.set('rule_id', String(params.rule_id));
    if (params?.passed != null) qs.set('passed', String(params.passed));
    if (params?.limit != null) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return safeFetch(`/api/data-quality/results${q ? '?' + q : ''}`);
  },

  getLatestDQResult: (ruleId: number) =>
    safeFetch(`/api/data-quality/results/latest/${ruleId}`),

  acknowledgeDQResult: (resultId: number, username?: string) =>
    safeFetch(`/api/data-quality/results/${resultId}/acknowledge`, {
      method: 'POST',
      body: safeStringify(username ? { username } : {}),
    }),

  // ── Summary ───────────────────────────────────────────────────────────────
  getDQSummary: (params?: { target_type?: string; target_id?: number }) => {
    const qs = new URLSearchParams();
    if (params?.target_type) qs.set('target_type', params.target_type);
    if (params?.target_id != null) qs.set('target_id', String(params.target_id));
    const q = qs.toString();
    return safeFetch(`/api/data-quality/summary${q ? '?' + q : ''}`);
  },

  // ── Admin config ──────────────────────────────────────────────────────────
  getDQConfig: () =>
    safeFetch('/api/admin/data-quality/config'),

  updateDQConfig: (data: Record<string, any>) =>
    safeFetch('/api/admin/data-quality/config', { method: 'PUT', body: safeStringify(data) }),

  cleanupDQResults: (retentionDays?: number) =>
    safeFetch(`/api/admin/data-quality/cleanup?retention_days=${retentionDays || 90}`, { method: 'POST' }),

  // ── Trend (Phase 114-F) ─────────────────────────────────────────────────
  getDQRuleTrend: (ruleId: number, limit: number = 30) =>
    safeFetch(`/api/data-quality/rules/${ruleId}/trend?limit=${limit}`),

  // ── Alerts (Phase 114-E) ────────────────────────────────────────────────
  listDQAlerts: (params?: { rule_id?: number; status?: string; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.rule_id != null) qs.set('rule_id', String(params.rule_id));
    if (params?.status) qs.set('status', params.status);
    if (params?.limit != null) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return safeFetch(`/api/data-quality/alerts${q ? '?' + q : ''}`);
  },

  getDQAlertSummary: () =>
    safeFetch('/api/data-quality/alerts/summary'),
};

export default dataQuality;
