/**
 * API — Business Reports, Portal, Delivery & Subscriptions
 */
import { safeFetch, openDownload } from './core';
import { safeStringify } from '../../utils/safeStringify';

const businessReports = {
  // ── Business Reports ────────────────────────────────────────────────────
  listBusinessReports: (params?: { owner?: string; dataset_id?: number; published_only?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.owner) qs.set('owner', params.owner);
    if (params?.dataset_id) qs.set('dataset_id', String(params.dataset_id));
    if (params?.published_only) qs.set('published_only', 'true');
    const q = qs.toString();
    return safeFetch(`/api/business-reports${q ? '?' + q : ''}`);
  },
  createBusinessReport: (data: any) =>
    safeFetch('/api/business-reports', { method: 'POST', body: safeStringify(data) }),
  getBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}`),
  updateBusinessReport: (id: number, data: any) =>
    safeFetch(`/api/business-reports/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}`, { method: 'DELETE' }),
  executeBusinessReport: (id: number, body: any) =>
    safeFetch(`/api/business-reports/${id}/execute`, { method: 'POST', body: safeStringify(body) }),

  // ── Phase 81: Async execution ───────────────────────────────────────────
  executeBusinessReportAsync: (id: number, body: any) =>
    safeFetch(`/api/business-reports/${id}/execute-async`, { method: 'POST', body: safeStringify(body) }),
  getBusinessReportAsyncStatus: (reportId: number, execId: string) =>
    safeFetch(`/api/business-reports/${reportId}/execution/${execId}/status`),
  getBusinessReportPagedResults: (reportId: number, execId: string, page: number, pageSize: number, sortColumn?: string | null, sortDirection?: string | null) => {
    const qs = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) qs.set('sort_column', sortColumn);
    if (sortDirection) qs.set('sort_direction', sortDirection);
    return safeFetch(`/api/business-reports/${reportId}/results/${execId}?${qs}`);
  },
  cancelBusinessReportAsync: (reportId: number, execId: string) =>
    safeFetch(`/api/business-reports/${reportId}/execution/${execId}`, { method: 'DELETE' }),
  downloadBusinessReportPDF: (id: number, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/${id}/download-pdf${qs}`);
  },
  downloadBusinessReportExcel: (id: number, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/${id}/download-excel${qs}`);
  },
  downloadBusinessReportCSV: (id: number, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/${id}/download-csv${qs}`);
  },
  duplicateBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/duplicate`, { method: 'POST' }),
  publishBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/publish`, { method: 'POST' }),

  // ── Business Report Parameters ──────────────────────────────────────────
  listBusinessReportParams: (reportId: number) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`),
  createBusinessReportParam: (reportId: number, data: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`, { method: 'POST', body: safeStringify(data) }),
  updateBusinessReportParam: (paramId: number, data: any) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteBusinessReportParam: (paramId: number) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'DELETE' }),
  getBusinessReportParamValues: (reportId: number, body: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  batchSaveBusinessReportParams: (reportId: number, parameters: any[]) =>
    safeFetch(`/api/business-reports/${reportId}/parameters/batch`, { method: 'PUT', body: safeStringify({ parameters }) }),

  // ── Certification & Templates ───────────────────────────────────────────
  certifyBusinessReport: (id: number, templateCategory: string) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'POST', body: safeStringify({ template_category: templateCategory }) }),
  uncertifyBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'DELETE' }),
  listTemplates: (category?: string, limit = 50) =>
    safeFetch(`/api/business-reports/templates?limit=${limit}${category ? `&category=${encodeURIComponent(category)}` : ''}`),
  listTemplateCategories: () =>
    safeFetch('/api/business-reports/template-categories'),
  cloneBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/clone`, { method: 'POST' }),

  // ── Share Tokens ────────────────────────────────────────────────────────
  createBusinessReportShare: (id: number, expiresHours?: number) =>
    safeFetch(`/api/business-reports/${id}/share`, { method: 'POST', body: safeStringify({ expires_hours: expiresHours }) }),
  listBusinessReportShares: (id: number) =>
    safeFetch(`/api/business-reports/${id}/shares`),
  revokeBusinessReportShare: (id: number, token: string) =>
    safeFetch(`/api/business-reports/${id}/shares/${token}`, { method: 'DELETE' }),
  getSharedBusinessReport: (token: string) =>
    safeFetch(`/api/shared-business-report/${token}`),
  executeSharedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/shared-business-report/${token}/execute`, { method: 'POST', body: safeStringify(body) }),
  getSharedReportParamValues: (token: string, body: any) =>
    safeFetch(`/api/shared-business-report/${token}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  getEmbeddedReportParamValues: (token: string, body: any) =>
    safeFetch(`/api/embedded-business-report/${token}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  downloadSharedReportPDF: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-pdf${qs}`);
  },
  downloadSharedReportExcel: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-excel${qs}`);
  },
  downloadSharedReportCSV: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-csv${qs}`);
  },

  // ── Embed Tokens ────────────────────────────────────────────────────────
  createBusinessReportEmbed: (id: number, expiresInDays?: number) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`, { method: 'POST', body: safeStringify({ expires_in_days: expiresInDays }) }),
  listBusinessReportEmbeds: (id: number) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`),
  revokeBusinessReportEmbed: (token: string) =>
    safeFetch(`/api/business-reports/embed-tokens/${token}`, { method: 'DELETE' }),
  getEmbeddedBusinessReport: (token: string) =>
    safeFetch(`/api/embedded-business-report/${token}`),
  executeEmbeddedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/embedded-business-report/${token}/execute`, { method: 'POST', body: safeStringify(body) }),
  downloadEmbeddedReportPDF: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-pdf${qs}`);
  },
  downloadEmbeddedReportExcel: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-excel${qs}`);
  },
  downloadEmbeddedReportCSV: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-csv${qs}`);
  },

  // ── Business Portal ─────────────────────────────────────────────────────
  getPortalSummary: () =>
    safeFetch('/api/portal/summary'),

  // ── Delivery & Subscriptions ────────────────────────────────────────────
  createSubscription: (data: any) =>
    safeFetch('/api/subscriptions', { method: 'POST', body: safeStringify(data) }),
  listSubscriptions: (reportId?: number, reportType?: string) => {
    const params = new URLSearchParams();
    if (reportId != null) params.set('report_id', String(reportId));
    if (reportType) params.set('report_type', reportType);
    const qs = params.toString();
    return safeFetch(`/api/subscriptions${qs ? '?' + qs : ''}`);
  },
  getSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`),
  updateSubscription: (id: number, data: any) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'DELETE' }),
  testSendSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/test-send`, { method: 'POST' }),
  pauseSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/pause`, { method: 'POST' }),
  resumeSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/resume`, { method: 'POST' }),
  getSubscriptionHistory: (id: number, limit = 50) =>
    safeFetch(`/api/subscriptions/${id}/history?limit=${limit}`),

  // ── Viewer Preferences ─────────────────────────────────────────────────
  updateViewerPrefs: (id: number, prefs: { column_order?: string[] }) =>
    safeFetch(`/api/business-reports/${id}/viewer-prefs`, { method: 'PATCH', body: safeStringify(prefs) }),

  // ── Execution History ──────────────────────────────────────────────────
  getExecutionHistory: (reportId: number, page = 1, pageSize = 20) =>
    safeFetch(`/api/business-reports/${reportId}/execution-history?page=${page}&page_size=${pageSize}`),

  // ── Phase 111: Seed Sample Reports ──────────────────────────────────────
  seedSampleReports: () =>
    safeFetch('/api/admin/seed-sample-reports', { method: 'POST' }),
};

export default businessReports;
