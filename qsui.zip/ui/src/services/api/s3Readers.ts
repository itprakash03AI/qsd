/**
 * BF-428G — Pluggable S3 reader admin API client.
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

export interface S3ReadersStatus {
  available: string[];
  default: string;
  per_connection: Record<string, string>;
  auto_route_enabled: boolean;
  integration_enabled: boolean;
  athena_workgroup: string;
  athena_database: string;
  athena_output_location: string;
  athena_poll_interval_seconds: number;
  athena_timeout_seconds: number;
  s3_select_max_file_bytes: number;
  pyarrow_max_rows: number;
  pyarrow_default_region: string;
}

export interface S3ReadersConfigUpdate {
  default?: string;
  per_connection?: Record<string, string>;
  auto_route_enabled?: boolean;
  integration_enabled?: boolean;
  athena_workgroup?: string;
  athena_database?: string;
  athena_output_location?: string;
  athena_poll_interval_seconds?: number;
  athena_timeout_seconds?: number;
  s3_select_max_file_bytes?: number;
  pyarrow_max_rows?: number;
  pyarrow_default_region?: string;
}

export interface S3ReadersTestResponse {
  reader: string;
  can_handle: boolean;
  can_handle_error?: string | null;
  config_summary: Record<string, unknown>;
}

export interface ReaderMetadata {
  name: string;
  output_kind: string;
  label: string;
  description: string;
}

export const s3Readers = {
  status: (): Promise<S3ReadersStatus> =>
    safeFetch('/api/admin/s3-readers/status'),

  /** BF-428K — UI-facing reader metadata.  Frontend dropdowns/chips
   *  consume this instead of hardcoding the reader list. */
  metadata: (): Promise<ReaderMetadata[]> =>
    safeFetch('/api/admin/s3-readers/readers'),

  /** BF-430C — telemetry: per-reader counters + roll-up.  Used for
   *  observability + tuning cost_overrides. */
  telemetry: (): Promise<{overall: Record<string, unknown>; by_reader: Record<string, Record<string, unknown>>}> =>
    safeFetch('/api/admin/s3-readers/telemetry'),

  resetTelemetry: (): Promise<{reset: number}> =>
    safeFetch('/api/admin/s3-readers/telemetry/reset', { method: 'POST' }),

  updateConfig: (changes: S3ReadersConfigUpdate): Promise<{ updated: Record<string, unknown> }> =>
    safeFetch('/api/admin/s3-readers/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      // BF-427: safeStringify defends against pollution from form fields
      body: safeStringify(changes),
    }),

  test: (reader: string, opts: {
    bucket?: string; s3_keys?: string[];
    sql?: string | null; projection?: string[] | null;
  } = {}): Promise<S3ReadersTestResponse> =>
    safeFetch('/api/admin/s3-readers/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify({
        reader,
        bucket: opts.bucket || 'test-bucket',
        s3_keys: opts.s3_keys || ['test-key.parquet'],
        sql: opts.sql,
        projection: opts.projection,
      }),
    }),
};
