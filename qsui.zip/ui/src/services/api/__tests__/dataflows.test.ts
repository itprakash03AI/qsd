/**
 * Vitest contract tests for the dataflow API client.
 *
 * Uses MSW handlers to capture requests and assert URL + method shape;
 * no actual backend is needed.
 */
import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import { setupServer } from 'msw/node';
import { http, HttpResponse } from 'msw';
import dataflows, { collectDataflowDynamicRows } from '../dataflows';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('dataflows API client', () => {
  it('lists dataflows with status filter as query param', async () => {
    let captured: URL | null = null;
    server.use(http.get('*/api/dataflows', ({ request }) => {
      captured = new URL(request.url);
      return HttpResponse.json([]);
    }));
    await dataflows.listDataFlows({ status: 'active' });
    expect(captured).not.toBeNull();
    expect(captured!.searchParams.get('status')).toBe('active');
  });

  it('promote calls POST', async () => {
    let method: string | null = null;
    server.use(http.post('*/api/dataflows/42/promote', ({ request }) => {
      method = request.method;
      return HttpResponse.json({ id: 42, name: 'x', version: 1, status: 'active',
                                  trigger_type: 'manual', stages: [] });
    }));
    await dataflows.promoteDataFlow(42);
    expect(method).toBe('POST');
  });

  it('startRun encodes dataflow name in path', async () => {
    let url: URL | null = null;
    server.use(http.post('*/api/dataflows/:wf/runs', ({ request }) => {
      url = new URL(request.url);
      return HttpResponse.json({ id: 1, dataflow_id: 1, dataflow_version: 1,
                                  dataflow_name: 'has spaces', status: 'pending' });
    }));
    await dataflows.startRun('has spaces', {});
    expect(url!.pathname).toContain('/api/dataflows/has%20spaces/runs');
  });

  it('rerunStage posts force_unsafe', async () => {
    let body: any = null;
    server.use(http.post('*/api/dataflow-runs/:id/rerun-stage', async ({ request }) => {
      body = await request.json();
      return HttpResponse.json({ run_id: 1, stage_alias: 'a', rerun_started: true });
    }));
    await dataflows.rerunStage(1, 'a', true);
    expect(body.stage_alias).toBe('a');
    expect(body.force_unsafe).toBe(true);
  });

  it('decideApproval posts decision + notes', async () => {
    let body: any = null;
    server.use(http.post('*/api/dataflows/approvals/:id/decide', async ({ request }) => {
      body = await request.json();
      return HttpResponse.json({ id: 1, run_id: 1, stage_alias: 'a',
                                  dataflow_name: 'w', status: 'approved' });
    }));
    await dataflows.decideApproval(1, 'reject', 'no thanks');
    expect(body.decision).toBe('reject');
    expect(body.decision_notes).toBe('no thanks');
  });

  it('createSchedule supports calendar_rule', async () => {
    let body: any = null;
    server.use(http.post('*/api/dataflows/schedules', async ({ request }) => {
      body = await request.json();
      return HttpResponse.json({ id: 1, dataflow_id: 1, name: 't',
                                  cron_expression: '', calendar_rule: body.calendar_rule,
                                  timezone: 'UTC', is_active: true });
    }));
    await dataflows.createSchedule({
      dataflow_id: 1, name: 'wd6',
      calendar_rule: { type: 'workday_n', n: 6, hour: 10 },
      timezone: 'UTC',
    });
    expect(body.calendar_rule.type).toBe('workday_n');
    expect(body.calendar_rule.n).toBe(6);
  });
});


describe('collectDataflowDynamicRows', () => {
  const baseDf = (stages: any[]) => ({
    id: 1, name: 'f', version: 1, status: 'active' as const,
    trigger_type: 'manual', stages,
  });

  it('returns [] for empty / missing stages', () => {
    expect(collectDataflowDynamicRows(null)).toEqual([]);
    expect(collectDataflowDynamicRows(undefined)).toEqual([]);
    expect(collectDataflowDynamicRows({ stages: [] })).toEqual([]);
  });

  it('returns [] when no stage declares where_clauses', () => {
    const df = baseDf([
      { stage_alias: 'a', stage_type: 'sql', seq: 1, config: {} },
    ]);
    expect(collectDataflowDynamicRows(df as any)).toEqual([]);
  });

  it('skips Static rows (only Dynamic rows show up)', () => {
    const df = baseDf([{
      stage_alias: 'a', stage_type: 'sql', seq: 1,
      config: { where_clauses: [
        { column: 'year', operator: 'eq', value: 2026, mode: 'static' },
        { column: 'region', operator: 'eq', value: 'US', mode: 'dynamic' },
      ] },
    }]);
    const rows = collectDataflowDynamicRows(df as any);
    expect(rows).toHaveLength(1);
    expect(rows[0].column).toBe('region');
    expect(rows[0].stageAlias).toBe('a');
  });

  it('flattens Dynamic rows across multiple stages', () => {
    const df = baseDf([
      { stage_alias: 'extract', stage_type: 'sql', seq: 1,
        config: { where_clauses: [
          { column: 'business_date', operator: 'eq',
            value: '{{business_date}}', mode: 'dynamic' },
        ] } },
      { stage_alias: 'load', stage_type: 'sql', seq: 2,
        config: { where_clauses: [
          { column: 'region', operator: 'in', value: ['US'], mode: 'dynamic' },
        ] } },
    ]);
    const rows = collectDataflowDynamicRows(df as any);
    expect(rows).toHaveLength(2);
    expect(rows.map(r => r.stageAlias)).toEqual(['extract', 'load']);
    expect(rows.map(r => r.column)).toEqual(['business_date', 'region']);
  });

  it('drops Dynamic rows with empty column', () => {
    const df = baseDf([{
      stage_alias: 'a', stage_type: 'sql', seq: 1,
      config: { where_clauses: [
        { column: '', operator: 'eq', value: 'x', mode: 'dynamic' },
        { column: '  ', operator: 'eq', value: 'y', mode: 'dynamic' },
      ] },
    }]);
    expect(collectDataflowDynamicRows(df as any)).toEqual([]);
  });

  it('defaults missing mode to static (treated as not-dynamic)', () => {
    const df = baseDf([{
      stage_alias: 'a', stage_type: 'sql', seq: 1,
      config: { where_clauses: [
        { column: 'region', operator: 'eq', value: 'US' },  // no mode field
      ] },
    }]);
    expect(collectDataflowDynamicRows(df as any)).toEqual([]);
  });
});
