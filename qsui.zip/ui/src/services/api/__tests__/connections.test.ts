/**
 * Phase 121C — MSW smoke tests for connections API service.
 * Proves that MSW intercepts real fetch calls and returns mock data.
 */
import { describe, it, expect } from 'vitest';
import { http, HttpResponse } from 'msw';
import { server } from '../../../test/mocks/server';
import { mockConnections } from '../../../test/mocks/handlers';

// Import the actual API service — safeFetch will hit MSW, not a real server
import connections from '../connections';

describe('connections API (via MSW)', () => {
  it('listConnections returns mock connection list', async () => {
    const result = await connections.listConnections();
    expect(result).toEqual(mockConnections);
  });

  it('getConnection returns a single connection by ID', async () => {
    const result = await connections.getConnection('1');
    expect(result.id).toBe(1);
    expect(result.name).toBe('Test S3 Connection');
    expect(result.type).toBe('s3');
  });

  it('getConnection returns 404 for nonexistent ID', async () => {
    await expect(connections.getConnection('999')).rejects.toThrow();
  });

  it('testConnection returns success', async () => {
    const result = await connections.testConnection({ type: 's3', config: {} });
    expect(result.status).toBe('success');
  });

  it('per-test override: server.use() overrides default handler', async () => {
    server.use(
      http.get('*/api/connections', () =>
        HttpResponse.json([{ id: 99, name: 'Override', type: 'local', config: {}, is_active: true }]),
      ),
    );
    const result = await connections.listConnections();
    expect(result).toHaveLength(1);
    expect(result[0].name).toBe('Override');
  });

  it('server error returns empty array (listConnections has .catch(() => []))', async () => {
    server.use(
      http.get('*/api/connections', () =>
        HttpResponse.json({ detail: 'Internal error' }, { status: 500 }),
      ),
    );
    const result = await connections.listConnections();
    expect(result).toEqual([]);
  });
});
