/**
 * BF-428G — Tests for the s3Readers API client.
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { s3Readers } from '../s3Readers';

describe('s3Readers API client', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('status() calls the right endpoint', async () => {
    const mockResp = {
      available: ['direct_httpfs', 'pyarrow_s3fs'],
      default: 'auto',
      per_connection: {},
      auto_route_enabled: true,
      integration_enabled: false,
      athena_workgroup: 'primary',
      athena_database: '',
      athena_output_location: '',
      athena_poll_interval_seconds: 1,
      athena_timeout_seconds: 300,
      s3_select_max_file_bytes: 5368709120,
      pyarrow_max_rows: 50000000,
      pyarrow_default_region: 'us-east-1',
    };
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify(mockResp), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    );
    const r = await s3Readers.status();
    expect(r.available).toContain('direct_httpfs');
    expect(r.default).toBe('auto');
    expect(fetchSpy).toHaveBeenCalledWith(
      expect.stringContaining('/api/admin/s3-readers/status'),
      expect.any(Object)
    );
  });

  it('updateConfig() PUTs JSON body', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify({ updated: { default: 'pyarrow_s3fs' } }), {
        status: 200, headers: { 'Content-Type': 'application/json' },
      })
    );
    await s3Readers.updateConfig({ default: 'pyarrow_s3fs' });
    expect(fetchSpy).toHaveBeenCalled();
    const call = fetchSpy.mock.calls[0];
    expect(call[0]).toContain('/api/admin/s3-readers/config');
    expect(call[1]?.method).toBe('PUT');
    expect(call[1]?.body).toContain('pyarrow_s3fs');
  });

  it('updateConfig uses safeStringify (defends against pollution)', async () => {
    // safeStringify replaces window/Event refs with sentinels; native
    // JSON.stringify would throw.  Smoke-test by passing a circular
    // object — should not throw.
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response('{}', { status: 200,
                            headers: { 'Content-Type': 'application/json' } })
    );
    const circular: Record<string, unknown> = { default: 'pyarrow_s3fs' };
    circular.self = circular;
    // Cast to bypass TS shape check — simulating a polluted setter
    await expect(
      s3Readers.updateConfig(circular as unknown as { default: string })
    ).resolves.toBeDefined();
    // The body should contain the [Circular] sentinel (safeStringify)
    const body = fetchSpy.mock.calls[0][1]?.body as string;
    expect(body).toContain('[Circular]');
  });

  it('test() POSTs reader name + defaults', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify({
        reader: 'pyarrow_s3fs',
        can_handle: false,
        config_summary: { name: 'pyarrow_s3fs', output_kind: 'arrow_table' },
      }), { status: 200, headers: { 'Content-Type': 'application/json' } })
    );
    const r = await s3Readers.test('pyarrow_s3fs');
    expect(r.reader).toBe('pyarrow_s3fs');
    expect(r.can_handle).toBe(false);
    const body = JSON.parse(fetchSpy.mock.calls[0][1]?.body as string);
    expect(body.reader).toBe('pyarrow_s3fs');
    expect(body.bucket).toBe('test-bucket');
    expect(body.s3_keys).toEqual(['test-key.parquet']);
  });

  it('metadata() returns reader UI metadata array', async () => {
    const mockMeta = [
      { name: 'direct_httpfs', output_kind: 's3_paths',
        label: 'Direct httpfs', description: 'DuckDB native...' },
      { name: 'athena', output_kind: 'arrow_table',
        label: 'Athena (server-side)', description: 'Server-side SQL' },
    ];
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify(mockMeta), {
        status: 200, headers: { 'Content-Type': 'application/json' },
      })
    );
    const r = await s3Readers.metadata();
    expect(r).toHaveLength(2);
    expect(r[0].name).toBe('direct_httpfs');
    expect(r[0].label).toBe('Direct httpfs');
    expect(r[0].output_kind).toBe('s3_paths');
    expect(fetchSpy).toHaveBeenCalledWith(
      expect.stringContaining('/api/admin/s3-readers/readers'),
      expect.any(Object)
    );
  });

  it('test() forwards custom bucket/keys/sql', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify({
        reader: 'athena',
        can_handle: true,
        config_summary: {},
      }), { status: 200, headers: { 'Content-Type': 'application/json' } })
    );
    await s3Readers.test('athena', {
      bucket: 'my-bucket',
      s3_keys: ['k1.parquet', 'k2.parquet'],
      sql: 'SELECT 1',
    });
    const body = JSON.parse(fetchSpy.mock.calls[0][1]?.body as string);
    expect(body.bucket).toBe('my-bucket');
    expect(body.s3_keys).toEqual(['k1.parquet', 'k2.parquet']);
    expect(body.sql).toBe('SELECT 1');
  });
});
