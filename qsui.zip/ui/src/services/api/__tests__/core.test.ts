/**
 * Phase 121A — Tests for core API utilities: _parseError, ApiError, toBackendQueryConfig.
 * These are the highest-value contract tests — they verify the data shape flowing
 * between frontend state and backend API, the exact class of bugs (BF-89-92).
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { _parseError, ApiError, toBackendQueryConfig, uploadFetch, rawFetch, type QueryConfig } from '../core';
import { setAuthHeader } from '../../authState';

// ── _parseError ─────────────────────────────────────────────────────────────

describe('_parseError', () => {
  const makeResponse = (body: any, status = 400) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { 'Content-Type': 'application/json' },
    });

  it('extracts string detail', async () => {
    const r = makeResponse({ detail: 'Connection not found' });
    const { detail } = await _parseError(r);
    expect(detail).toBe('Connection not found');
  });

  it('extracts array detail (Pydantic validation errors)', async () => {
    const r = makeResponse({
      detail: [
        { msg: 'field required', loc: ['body', 'name'] },
        { msg: 'not a valid integer', loc: ['body', 'limit'], input: 'abc' },
      ],
    });
    const { detail } = await _parseError(r);
    expect(detail).toContain('field required');
    expect(detail).toContain('[field: body.name]');
    expect(detail).toContain('not a valid integer');
    expect(detail).toContain('[field: body.limit]');
    expect(detail).toContain('[got: "abc"]');
  });

  it('extracts object detail with error_code and connection_id', async () => {
    const r = makeResponse({
      detail: {
        message: 'Token expired',
        error_code: 'TOKEN_EXPIRED',
        connection_id: 42,
      },
    });
    const { detail, errorCode, connectionId } = await _parseError(r);
    expect(detail).toBe('Token expired');
    expect(errorCode).toBe('TOKEN_EXPIRED');
    expect(connectionId).toBe(42);
  });

  it('falls back to message field when detail is missing', async () => {
    const r = makeResponse({ message: 'Something went wrong' });
    const { detail } = await _parseError(r);
    expect(detail).toBe('Something went wrong');
  });

  it('falls back to HTTP status when body is not JSON', async () => {
    const r = new Response('Internal Server Error', { status: 500 });
    const { detail } = await _parseError(r);
    expect(detail).toBe('HTTP 500');
  });

  it('falls back to HTTP status when detail is a number', async () => {
    const r = makeResponse({ detail: 123 });
    const { detail } = await _parseError(r);
    expect(detail).toBe('HTTP 400');
  });

  it('serializes object detail without message field', async () => {
    const r = makeResponse({ detail: { code: 'UNKNOWN', extra: 'info' } });
    const { detail } = await _parseError(r);
    expect(detail).toContain('UNKNOWN');
    expect(detail).toContain('info');
  });
});

// ── ApiError ────────────────────────────────────────────────────────────────

describe('ApiError', () => {
  it('creates an error with message only', () => {
    const err = new ApiError('fail');
    expect(err.message).toBe('fail');
    expect(err.name).toBe('ApiError');
    expect(err.errorCode).toBeUndefined();
    expect(err.connectionId).toBeUndefined();
  });

  it('propagates errorCode and connectionId', () => {
    const err = new ApiError('Token expired', 'TOKEN_EXPIRED', 42);
    expect(err.errorCode).toBe('TOKEN_EXPIRED');
    expect(err.connectionId).toBe(42);
  });

  it('is instanceof Error', () => {
    const err = new ApiError('test');
    expect(err).toBeInstanceOf(Error);
  });
});

// ── toBackendQueryConfig ────────────────────────────────────────────────────

describe('toBackendQueryConfig', () => {
  it('passes through config that already has files key', () => {
    const qc: QueryConfig = { files: ['a.parquet', 'b.parquet'] };
    const result = toBackendQueryConfig(qc);
    expect(result).toBe(qc); // same reference — no transformation
  });

  it('maps selectedTables to files', () => {
    const qc: QueryConfig = {
      selectedTables: [{ path: 'data/a.parquet' }, { path: 'data/b.csv' }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.files).toEqual(['data/a.parquet', 'data/b.csv']);
  });

  it('produces empty files when selectedTables is empty', () => {
    const result = toBackendQueryConfig({});
    expect(result.files).toEqual([]);
  });

  it('normalizes joins: leftTable→left_file, joinType→how', () => {
    const qc: QueryConfig = {
      selectedTables: [{ path: 'a.parquet' }],
      joins: [{
        leftTable: 'a.parquet',
        rightTable: 'b.parquet',
        leftColumn: 'id',
        rightColumn: 'a_id',
        joinType: 'left',
      }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.joins).toEqual([{
      left_file: 'a.parquet',
      right_file: 'b.parquet',
      left_on: ['id'],
      right_on: ['a_id'],
      how: 'left',
    }]);
  });

  it('preserves array left_on/right_on', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      joins: [{
        left_file: 'a.parquet',
        right_file: 'b.parquet',
        left_on: ['col1', 'col2'],
        right_on: ['col3', 'col4'],
        how: 'inner',
      }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.joins![0].left_on).toEqual(['col1', 'col2']);
    expect(result.joins![0].right_on).toEqual(['col3', 'col4']);
  });

  it('returns null joins when empty', () => {
    const result = toBackendQueryConfig({ selectedTables: [] });
    expect(result.joins).toBeNull();
  });

  it('splits string value for "in" operator filter', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      filters: [{ column: 'status', operator: 'in', value: 'active, pending, done' }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.filters![0].value).toEqual(['active', 'pending', 'done']);
  });

  it('passes array value through for "in" operator filter', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      filters: [{ column: 'status', operator: 'in', value: ['active', 'pending'] }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.filters![0].value).toEqual(['active', 'pending']);
  });

  it('keeps string value for non-"in" operators', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      filters: [{ column: 'amount', operator: '>', value: '100' }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.filters![0].value).toBe('100');
  });

  it('returns null filters when empty', () => {
    const result = toBackendQueryConfig({ selectedTables: [] });
    expect(result.filters).toBeNull();
  });

  it('maps selectedColumns objects to column names', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      selectedColumns: [{ columnName: 'id' }, { columnName: 'name' }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.columns).toEqual(['id', 'name']);
  });

  it('passes string selectedColumns through', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      selectedColumns: ['id', 'name'] as any,
    };
    const result = toBackendQueryConfig(qc);
    expect(result.columns).toEqual(['id', 'name']);
  });

  it('returns null columns when empty', () => {
    const result = toBackendQueryConfig({ selectedTables: [] });
    expect(result.columns).toBeNull();
  });

  it('maps orderBy to order_by', () => {
    const qc: QueryConfig = {
      selectedTables: [],
      orderBy: [{ column: 'name', direction: 'desc' }],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.order_by).toEqual([{ column: 'name', direction: 'desc' }]);
  });

  it('defaults limit to null and offset to 0', () => {
    const result = toBackendQueryConfig({ selectedTables: [] });
    expect(result.limit).toBeNull();
    expect(result.offset).toBe(0);
  });

  it('preserves explicit limit and offset', () => {
    const qc: QueryConfig = { selectedTables: [], limit: 500, offset: 100 };
    const result = toBackendQueryConfig(qc);
    expect(result.limit).toBe(500);
    expect(result.offset).toBe(100);
  });

  it('handles Excel sheet paths with :: convention', () => {
    const qc: QueryConfig = {
      selectedTables: [
        { path: 'report.xlsx::Finance' },
        { path: 'report.xlsx::Budget' },
      ],
    };
    const result = toBackendQueryConfig(qc);
    expect(result.files).toEqual(['report.xlsx::Finance', 'report.xlsx::Budget']);
  });
});

// ── uploadFetch ──────────────────────────────────────────────────────────────

describe('uploadFetch', () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    setAuthHeader('Bearer test-token');
    localStorage.setItem('qs_workspace_id', 'ws-42');
    fetchSpy = vi.spyOn(globalThis, 'fetch');
  });

  afterEach(() => {
    setAuthHeader(null);
    localStorage.removeItem('qs_workspace_id');
    fetchSpy.mockRestore();
  });

  it('sends FormData with auth + workspace + request-id, no Content-Type', async () => {
    fetchSpy.mockResolvedValueOnce(new Response(JSON.stringify({ ok: true }), { status: 200 }));
    const form = new FormData();
    form.append('file', new Blob(['test']), 'test.csv');
    await uploadFetch('/api/upload', form);
    const [, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    const headers = init.headers as Record<string, string>;
    expect(headers['Authorization']).toBe('Bearer test-token');
    expect(headers['X-Workspace-ID']).toBe('ws-42');
    expect(headers['X-Request-ID']).toBeDefined();
    expect(headers['Content-Type']).toBeUndefined();
    expect(init.body).toBeInstanceOf(FormData);
  });

  it('parses JSON response', async () => {
    fetchSpy.mockResolvedValueOnce(new Response(JSON.stringify({ id: 1 }), { status: 200 }));
    const result = await uploadFetch('/api/upload', new FormData());
    expect(result).toEqual({ id: 1 });
  });

  it('throws ApiError on non-ok response', async () => {
    fetchSpy.mockResolvedValueOnce(new Response(JSON.stringify({ detail: 'Too large' }), { status: 413 }));
    await expect(uploadFetch('/api/upload', new FormData())).rejects.toThrow('Too large');
  });
});

// ── rawFetch ─────────────────────────────────────────────────────────────────

describe('rawFetch', () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    setAuthHeader('Bearer raw-token');
    localStorage.setItem('qs_workspace_id', 'ws-99');
    fetchSpy = vi.spyOn(globalThis, 'fetch');
  });

  afterEach(() => {
    setAuthHeader(null);
    localStorage.removeItem('qs_workspace_id');
    fetchSpy.mockRestore();
  });

  it('returns raw Response with injected auth headers', async () => {
    const body = new ReadableStream();
    fetchSpy.mockResolvedValueOnce(new Response(body, { status: 200 }));
    const res = await rawFetch('/api/stream');
    expect(res).toBeInstanceOf(Response);
    const [, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    const headers = init.headers as Record<string, string>;
    expect(headers['Authorization']).toBe('Bearer raw-token');
    expect(headers['X-Workspace-ID']).toBe('ws-99');
    expect(headers['X-Request-ID']).toBeDefined();
  });

  it('auto-prepends API_BASE_URL for relative paths', async () => {
    fetchSpy.mockResolvedValueOnce(new Response('', { status: 200 }));
    await rawFetch('/api/data');
    const [url] = fetchSpy.mock.calls[0] as [string, RequestInit];
    // API_BASE_URL is empty in test env, so url should be '/api/data'
    expect(url).toContain('/api/data');
  });

  it('passes signal through for abort', async () => {
    const ac = new AbortController();
    fetchSpy.mockResolvedValueOnce(new Response('', { status: 200 }));
    await rawFetch('/api/data', { signal: ac.signal });
    const [, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    expect(init.signal).toBe(ac.signal);
  });

  it('works without auth header', async () => {
    setAuthHeader(null);
    fetchSpy.mockResolvedValueOnce(new Response('', { status: 200 }));
    await rawFetch('/api/public');
    const [, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    const headers = init.headers as Record<string, string>;
    expect(headers['Authorization']).toBeUndefined();
  });
});
