/**
 * Phase 121H — Frontend contract tests.
 *
 * Verifies that mock data matching backend Pydantic/SQLAlchemy shapes
 * parse correctly through the TypeScript interfaces. If a backend response
 * shape changes, these tests ensure the frontend catches it.
 */
import { describe, it, expect } from 'vitest';
import type {
  Connection,
  QueryResult,
  HealthStatus,
  BusinessReport,
  PublishedView,
  User,
  AuditEntry,
} from '../../../types/api';

// ── Connection contract ─────────────────────────────────────────────────────

describe('Connection contract', () => {
  const mockConnection: Connection = {
    id: 1,
    name: 'Test S3 Connection',
    connection_type: 's3',
    config: { bucket_name: 'test-bucket', region: 'us-east-1' },
    is_active: true,
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-06-15T12:00:00Z',
    created_by: 'admin',
  };

  it('has all required fields', () => {
    expect(mockConnection.id).toBeDefined();
    expect(mockConnection.name).toBeDefined();
    expect(mockConnection.connection_type).toBeDefined();
    expect(mockConnection.config).toBeDefined();
    expect(typeof mockConnection.is_active).toBe('boolean');
    expect(mockConnection.created_at).toBeDefined();
    expect(mockConnection.updated_at).toBeDefined();
  });

  it('connection_type is a valid enum value', () => {
    const validTypes = ['s3', 'snowflake', 'databricks', 'trino', 'oracle', 'rest_api', 'postgresql'];
    expect(validTypes).toContain(mockConnection.connection_type);
  });

  it('config is a record', () => {
    expect(typeof mockConnection.config).toBe('object');
    expect(mockConnection.config).not.toBeNull();
  });
});

// ── QueryResult contract ────────────────────────────────────────────────────

describe('QueryResult contract', () => {
  const mockResult: QueryResult = {
    execution_id: 'abc-123-def',
    status: 'completed',
    columns: ['id', 'name', 'amount'],
    rows: [[1, 'Alice', 100], [2, 'Bob', 200]],
    row_count: 2,
    execution_time_ms: 450,
    cache_hit: false,
  };

  it('has required fields', () => {
    expect(mockResult.execution_id).toBeDefined();
    expect(mockResult.status).toBeDefined();
    expect(mockResult.columns).toBeDefined();
    expect(mockResult.rows).toBeDefined();
    expect(mockResult.row_count).toBeDefined();
    expect(mockResult.execution_time_ms).toBeDefined();
  });

  it('status is a valid enum value', () => {
    const validStatuses = ['completed', 'failed', 'processing', 'queued'];
    expect(validStatuses).toContain(mockResult.status);
  });

  it('columns is string array', () => {
    expect(Array.isArray(mockResult.columns)).toBe(true);
    mockResult.columns.forEach(col => expect(typeof col).toBe('string'));
  });

  it('rows is 2D array matching column count', () => {
    mockResult.rows.forEach(row => {
      expect(row.length).toBe(mockResult.columns.length);
    });
  });
});

// ── HealthStatus contract ───────────────────────────────────────────────────

describe('HealthStatus contract', () => {
  const mockHealth: HealthStatus = {
    status: 'healthy',
    database: { ok: true },
    s3: { status: 'connected' },
    disk: { free_gb: 50.2, used_pct: 45.0, warning: false },
    queries: {
      active: 3,
      max_concurrent_global: 20,
      per_user_limit: 5,
      queue_waiting: 0,
    },
  };

  it('has all top-level sections', () => {
    expect(mockHealth.status).toBeDefined();
    expect(mockHealth.database).toBeDefined();
    expect(mockHealth.s3).toBeDefined();
    expect(mockHealth.disk).toBeDefined();
    expect(mockHealth.queries).toBeDefined();
  });

  it('database section has ok boolean', () => {
    expect(typeof mockHealth.database.ok).toBe('boolean');
  });

  it('disk section has numeric values', () => {
    expect(typeof mockHealth.disk.free_gb).toBe('number');
    expect(typeof mockHealth.disk.used_pct).toBe('number');
    expect(typeof mockHealth.disk.warning).toBe('boolean');
  });

  it('queries section has numeric values', () => {
    expect(typeof mockHealth.queries.active).toBe('number');
    expect(typeof mockHealth.queries.max_concurrent_global).toBe('number');
  });
});

// ── BusinessReport contract ─────────────────────────────────────────────────

describe('BusinessReport contract', () => {
  const mockReport: BusinessReport = {
    id: 1,
    name: 'Monthly Sales',
    description: 'Sales by region',
    data_source_type: 'dataset',
    dataset_id: 5,
    layout_config: { sections: [], columns: [] },
    owner: 'admin',
    is_published: true,
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-06-15T12:00:00Z',
  };

  it('has required fields', () => {
    expect(mockReport.id).toBeDefined();
    expect(mockReport.name).toBeDefined();
    expect(mockReport.data_source_type).toBeDefined();
    expect(mockReport.layout_config).toBeDefined();
    expect(mockReport.owner).toBeDefined();
    expect(mockReport.created_at).toBeDefined();
    expect(mockReport.updated_at).toBeDefined();
  });

  it('data_source_type is a valid enum', () => {
    const validTypes = ['dataset', 'raw_sql', 'published_view', 'pivot'];
    expect(validTypes).toContain(mockReport.data_source_type);
  });

  it('layout_config is an object', () => {
    expect(typeof mockReport.layout_config).toBe('object');
  });
});

// ── User contract ───────────────────────────────────────────────────────────

describe('User contract', () => {
  const mockUser: User = {
    username: 'testuser',
    role: 'analyst',
    is_admin: false,
    display_name: 'Test User',
    email: 'test@example.com',
  };

  it('has required fields', () => {
    expect(mockUser.username).toBeDefined();
    expect(mockUser.role).toBeDefined();
  });

  it('role is a valid enum', () => {
    const validRoles = ['admin', 'analyst', 'viewer', 'super_admin'];
    expect(validRoles).toContain(mockUser.role);
  });
});

// ── AuditEntry contract ─────────────────────────────────────────────────────

describe('AuditEntry contract', () => {
  const mockAudit: AuditEntry = {
    id: 1,
    timestamp: '2024-06-15T12:00:00Z',
    username: 'admin',
    action: 'query_executed',
    resource_type: 'connection',
    resource_id: '42',
  };

  it('has required fields', () => {
    expect(mockAudit.id).toBeDefined();
    expect(mockAudit.timestamp).toBeDefined();
    expect(mockAudit.username).toBeDefined();
    expect(mockAudit.action).toBeDefined();
  });
});
