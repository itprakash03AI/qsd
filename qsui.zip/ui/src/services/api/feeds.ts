/**
 * API — Feed File Generation (Phase 76)
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const feeds = {
  // ── Feed Configs CRUD ─────────────────────────────────────────────────────
  createFeed: (data: {
    name: string;
    source_type: string;
    source_id: number;
    connection_id?: number;
    query_params?: Record<string, any>;
    output_format?: string;
    output_filename_template?: string;
    output_options?: Record<string, any>;
    destination_type?: string;
    destination_config?: Record<string, any>;
    execution_backend?: string;
    backend_config?: Record<string, any>;
    size_threshold_rows?: number;
    schedule_enabled?: boolean;
    cron_expression?: string;
    timezone?: string;
    notify_on_success?: boolean;
    notify_on_failure?: boolean;
    notify_emails?: string;
    notify_webhook?: string;
    max_retries?: number;
    retry_delay_seconds?: number;
  }) =>
    safeFetch('/api/feeds', { method: 'POST', body: safeStringify(data) }),

  listFeeds: (params?: { source_type?: string; is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.source_type) qs.set('source_type', params.source_type);
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const query = qs.toString();
    return safeFetch(`/api/feeds${query ? '?' + query : ''}`);
  },

  getFeed: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}`),

  updateFeed: (feedId: number, data: Record<string, any>) =>
    safeFetch(`/api/feeds/${feedId}`, { method: 'PUT', body: safeStringify(data) }),

  deleteFeed: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}`, { method: 'DELETE' }),

  // ── Execution ─────────────────────────────────────────────────────────────
  //
  // Phase 132.38 — ``queryParams`` lets the dashboard caller pass
  // per-trigger overrides for Dynamic WHERE rows the publisher declared
  // on the feed config.  Same primitive Published Views uses; Static
  // rows remain locked.  Optional — legacy callers that pass nothing
  // get the unchanged manual-trigger behaviour.
  executeFeed: (feedId: number, queryParams?: Record<string, any>) =>
    safeFetch(`/api/feeds/${feedId}/execute`, {
      method: 'POST',
      body: queryParams ? safeStringify({ query_params: queryParams }) : undefined,
    }),

  enableSchedule: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/enable-schedule`, { method: 'POST' }),

  disableSchedule: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/disable-schedule`, { method: 'POST' }),

  testDestination: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/test-destination`, { method: 'POST' }),

  quickCreateFeed: (data: {
    source_type: string;
    source_id: number;
    connection_id?: number;
    output_format?: string;
    destination_type?: string;
    destination_config?: Record<string, any>;
    execute_now?: boolean;
  }) =>
    safeFetch('/api/feeds/quick-create', { method: 'POST', body: safeStringify(data) }),

  // ── History ───────────────────────────────────────────────────────────────
  listFeedExecutions: (feedId: number, limit = 50, offset = 0) =>
    safeFetch(`/api/feeds/${feedId}/executions?limit=${limit}&offset=${offset}`),

  getFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}`),

  retryFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/retry`, { method: 'POST' }),

  cancelFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/cancel`, { method: 'POST' }),

  downloadFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/download`),

  // ── Webhook ───────────────────────────────────────────────────────────────
  webhookFeedComplete: (data: {
    execution_id: string;
    state: string;
    dag_id?: string;
    batch_id?: string;
    error?: string;
    output_path?: string;
  }) =>
    safeFetch('/api/webhooks/feed-complete', { method: 'POST', body: safeStringify(data) }),

  // ── Admin Config ──────────────────────────────────────────────────────────
  getFeedGenerationConfig: () =>
    safeFetch('/api/admin/feed-generation/config'),

  updateFeedGenerationConfig: (data: Record<string, any>) =>
    safeFetch('/api/admin/feed-generation/config', { method: 'PUT', body: safeStringify(data) }),

  getFeedBackends: () =>
    safeFetch('/api/admin/feed-generation/backends'),

  resetFeedBackend: (name: string) =>
    safeFetch(`/api/admin/feed-generation/backends/${name}/reset`, { method: 'POST' }),

  // ── Phase 130: Calendars + Holidays + Today's runs + SOD/SLA ─────────────
  listFeedCalendars: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/feed-calendars${q ? '?' + q : ''}`);
  },

  createFeedCalendar: (data: {
    name: string;
    description?: string;
    weekend_days?: number[];
    is_active?: boolean;
  }) =>
    safeFetch('/api/admin/feed-calendars', {
      method: 'POST', body: safeStringify(data),
    }),

  getFeedCalendar: (id: number) =>
    safeFetch(`/api/admin/feed-calendars/${id}`),

  updateFeedCalendar: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/feed-calendars/${id}`, {
      method: 'PUT', body: safeStringify(data),
    }),

  deleteFeedCalendar: (id: number) =>
    safeFetch(`/api/admin/feed-calendars/${id}`, { method: 'DELETE' }),

  addFeedHoliday: (calendarId: number, data: {
    holiday_date: string; holiday_name?: string; recurring?: boolean;
  }) =>
    safeFetch(`/api/admin/feed-calendars/${calendarId}/holidays`, {
      method: 'POST', body: safeStringify(data),
    }),

  deleteFeedHoliday: (holidayId: number) =>
    safeFetch(`/api/admin/feed-holidays/${holidayId}`, { method: 'DELETE' }),

  listTodaysFeedRuns: (params?: {
    business_date?: string; status?: string;
    limit?: number; offset?: number;
  }) => {
    const qs = new URLSearchParams();
    if (params?.business_date) qs.set('business_date', params.business_date);
    if (params?.status)        qs.set('status', params.status);
    if (params?.limit  != null) qs.set('limit',  String(params.limit));
    if (params?.offset != null) qs.set('offset', String(params.offset));
    const q = qs.toString();
    return safeFetch(`/api/feed-runs${q ? '?' + q : ''}`);
  },

  runSodNow: (business_date?: string) => {
    // Backend reads business_date as a query parameter (FastAPI signature).
    // Sending it in the JSON body silently no-ops the date — caller would
    // see today's runs created instead of the requested date.  Always send
    // as query string when provided.
    const qs = business_date ? `?business_date=${encodeURIComponent(business_date)}` : '';
    return safeFetch(`/api/admin/feeds/sod/run-now${qs}`, { method: 'POST' });
  },

  cancelFeedRun: (runId: number) =>
    safeFetch(`/api/feed-runs/${runId}/cancel`, { method: 'POST' }),

  rerunFeedRun: (runId: number, opts?: { backend?: 'native' | 'airflow' }) => {
    const qs = opts?.backend ? `?backend=${encodeURIComponent(opts.backend)}` : '';
    return safeFetch(`/api/feed-runs/${runId}/rerun${qs}`, { method: 'POST' });
  },

  bulkRerunFeedRuns: (data: {
    business_date?: string;
    statuses?: string[];
    run_ids?: number[];
  }, opts?: { backend?: 'native' | 'airflow' }) => {
    const qs = opts?.backend ? `?backend=${encodeURIComponent(opts.backend)}` : '';
    return safeFetch(`/api/feed-runs/bulk-rerun${qs}`, {
      method: 'POST', body: safeStringify(data),
    });
  },

  // Phase 130 hotfix-13 — backend override admin
  getFeedBackendOverride: () =>
    safeFetch('/api/admin/feed-generation/backend-override') as Promise<{
      value: string;
      valid_values: string[];
      persisted: { updated_by?: string | null; updated_at?: string | null } | null;
    }>,

  slaSweepNow: () =>
    safeFetch('/api/admin/feeds/sla/sweep-now', { method: 'POST' }),

  // ── Phase 130 hotfix-4 — Control File Formats ─────────────────────────
  listControlFileFormats: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/feed-control-file-formats${q ? '?' + q : ''}`);
  },

  createControlFileFormat: (data: Record<string, any>) =>
    safeFetch('/api/admin/feed-control-file-formats', {
      method: 'POST', body: safeStringify(data),
    }),

  getControlFileFormat: (id: number) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`),

  updateControlFileFormat: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`, {
      method: 'PUT', body: safeStringify(data),
    }),

  deleteControlFileFormat: (id: number) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`, { method: 'DELETE' }),

  seedDefaultControlFileFormats: () =>
    safeFetch('/api/admin/feed-control-file-formats/seed-defaults', { method: 'POST' }),

  listChecksumAlgorithms: () =>
    safeFetch('/api/admin/feed-control-file-formats/algorithms/list'),

  // ── Phase 130 hotfix-7 — Entitlement (User) Groups ───────────────────
  listUserGroups: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/user-groups${q ? '?' + q : ''}`);
  },

  createUserGroup: (data: { name: string; description?: string; is_active?: boolean }) =>
    safeFetch('/api/admin/user-groups', { method: 'POST', body: safeStringify(data) }),

  getUserGroup: (id: number) =>
    safeFetch(`/api/admin/user-groups/${id}`),

  updateUserGroup: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/user-groups/${id}`, { method: 'PUT', body: safeStringify(data) }),

  deleteUserGroup: (id: number) =>
    safeFetch(`/api/admin/user-groups/${id}`, { method: 'DELETE' }),

  addUserGroupMember: (gid: number, data: { username: string; role_in_group?: string }) =>
    safeFetch(`/api/admin/user-groups/${gid}/members`, {
      method: 'POST', body: safeStringify(data),
    }),

  removeUserGroupMember: (gid: number, username: string) =>
    safeFetch(`/api/admin/user-groups/${gid}/members/${encodeURIComponent(username)}`, {
      method: 'DELETE',
    }),

  listMyUserGroups: () => safeFetch('/api/user-groups/my'),
};

export default feeds;
