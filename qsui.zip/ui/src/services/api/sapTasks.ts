/**
 * Phase 132.36 hotfix-2 — SAP task config client.
 *
 * Backs the ``lookup: "sap_tasks"`` annotation on DataFlow stage
 * schemas so admins can pick a SapTaskConfig from a dropdown instead
 * of typing the integer id by hand.
 *
 * Backend routes live in ``backend/api/sap_tasks_api.py`` (admin-only).
 */
import { safeFetch } from './core';

export interface SapTask {
  id: number;
  name: string;
  is_active: boolean;
  sap_connection_id: number;
  odata_service_path: string;
  company_code_endpoint: string;
  entity_set: string;
  filter_style: string;
  period_mode: string;
  output_dir: string;
  passthrough_enabled?: boolean;
  passthrough_partition_field?: string;
  passthrough_required_filters?: string[];
  passthrough_rate_limit_rpm?: number;
  passthrough_max_rows?: number;
}

const sapTasks = {
  list: (): Promise<SapTask[]> => safeFetch('/api/sap-tasks'),
  get: (id: number): Promise<SapTask> => safeFetch(`/api/sap-tasks/${id}`),
  getResolved: (id: number): Promise<Record<string, unknown>> =>
    safeFetch(`/api/sap-tasks/${id}/resolved`),
};

export default sapTasks;
