/**
 * Phase 122C: SQL File Management API service
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

export interface SqlFileCreate {
  name: string;
  sql: string;
  description?: string;
  connection_id?: number;
  // Phase 124-B: Cross-connection
  secondary_connection_id?: number;
  secondary_sql?: string;
  combine_mode?: 'union' | 'join';
  join_config?: { how: string; left_on: string[]; right_on: string[]; suffixes?: string[] };
  is_shared?: boolean;
  tags?: string[];
}

export interface SqlFileUpdate {
  sql?: string;
  name?: string;
  description?: string;
  // Phase 124-B: Cross-connection
  secondary_sql?: string;
  secondary_connection_id?: number;
  combine_mode?: string;
  join_config?: Record<string, unknown>;
  is_shared?: boolean;
  tags?: string[];
}

export interface SqlFile {
  id: number;
  name: string;
  description: string | null;
  file_path: string;
  connection_id: number | null;
  secondary_connection_id: number | null;
  combine_mode: string | null;
  join_config: Record<string, unknown> | null;
  version: number;
  content_hash: string | null;
  file_size: number;
  is_shared: boolean;
  is_active: boolean;
  tags: string[] | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  content?: string;
  secondary_content?: string;
}

const sqlFiles = {
  create: (data: SqlFileCreate): Promise<SqlFile> =>
    safeFetch('/api/sql-files', { method: 'POST', body: safeStringify(data) }),

  list: (params?: { connection_id?: number; limit?: number; offset?: number }): Promise<SqlFile[]> => {
    const qs = new URLSearchParams();
    if (params?.connection_id) qs.set('connection_id', String(params.connection_id));
    if (params?.limit) qs.set('limit', String(params.limit));
    if (params?.offset) qs.set('offset', String(params.offset));
    const query = qs.toString();
    return safeFetch(`/api/sql-files${query ? '?' + query : ''}`);
  },

  get: (id: number): Promise<SqlFile & { content: string }> =>
    safeFetch(`/api/sql-files/${id}`),

  update: (id: number, data: SqlFileUpdate): Promise<SqlFile> =>
    safeFetch(`/api/sql-files/${id}`, { method: 'PUT', body: safeStringify(data) }),

  delete: (id: number): Promise<{ status: string; id: number }> =>
    safeFetch(`/api/sql-files/${id}`, { method: 'DELETE' }),

  validate: (id: number): Promise<{ valid: boolean; tables: string[]; errors: string[]; warnings?: string[] }> =>
    safeFetch(`/api/sql-files/${id}/validate`, { method: 'POST' }),
};

export default sqlFiles;
