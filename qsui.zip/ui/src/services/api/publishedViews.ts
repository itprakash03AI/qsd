/**
 * API — Published Views & API Keys (Phase 75)
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const publishedViews = {
  // ── Published Views Management ────────────────────────────────────────────
  publishView: (data: {
    query_id?: number;
    slug: string;
    name: string;
    description?: string;
    allowed_filters?: string[];
    default_limit?: number;
    max_limit?: number;
    cache_ttl_seconds?: number;
    param_definitions?: any[];
    allowed_ad_groups?: string[];
    // Backend (api/published_views/management.py:publish_view) accepts
    // saved_query | business_report | federation | sql_file.  The
    // frontend type was lagging — sql_file was usable from curl but
    // not from the UI.
    source_type?: 'saved_query' | 'business_report' | 'federation' | 'sql_file';
    business_report_id?: number;
    federation_view_id?: number;
    sql_file_id?: number;
    reader_override?: string;
    // Phase 132.37 — explicit WHERE-clause mapping per published view.
    // Static rows freeze a value into the snapshot; Dynamic rows let
    // consumers override via ``?col=value``.
    where_clauses?: {
      column: string;
      operator: string;
      value: any;
      mode: 'dynamic' | 'static';
    }[];
    // Phase 133-J — publisher-time credential routing.  Publisher picks
    // which connection consumer calls run against and whose credentials
    // resolve at runtime, so curl callers never get a credential prompt.
    //   consumer  — caller's vault (legacy default; private connections
    //               will return structured 401 portal_password_required)
    //   publisher — publisher's vault, frozen at publish time
    //   shared    — connection's system_account (no per-user vault needed)
    execution_connection_id?: number;
    credential_mode?: 'consumer' | 'publisher' | 'shared';
  }) =>
    safeFetch('/api/published-views', { method: 'POST', body: safeStringify(data) }),

  listPublishedViews: () =>
    safeFetch('/api/published-views'),

  getPublishedView: (viewId: number) =>
    safeFetch(`/api/published-views/${viewId}`),

  updatePublishedView: (viewId: number, data: Record<string, any>) =>
    safeFetch(`/api/published-views/${viewId}`, { method: 'PUT', body: safeStringify(data) }),

  deletePublishedView: (viewId: number) =>
    safeFetch(`/api/published-views/${viewId}`, { method: 'DELETE' }),

  republishView: (viewId: number) =>
    safeFetch(`/api/published-views/${viewId}/republish`, { method: 'POST' }),

  getPublishedViewUsage: (viewId: number, limit = 100) =>
    safeFetch(`/api/published-views/${viewId}/usage?limit=${limit}`),

  // ── API Keys Management ───────────────────────────────────────────────────
  createApiKey: (data: {
    name: string;
    scoped_view_ids?: number[];
    rate_limit?: string;
    expires_hours?: number;
  }) =>
    safeFetch('/api/api-keys', { method: 'POST', body: safeStringify(data) }),

  listApiKeys: () =>
    safeFetch('/api/api-keys'),

  revokeApiKey: (keyId: number) =>
    safeFetch(`/api/api-keys/${keyId}`, { method: 'DELETE' }),

  revealApiKey: (keyId: number): Promise<{ raw_key: string; key_prefix: string; name: string }> =>
    safeFetch(`/api/api-keys/${keyId}/reveal`),

  // ── Partition Detection ──────────────────────────────────────────────────
  detectPartitions: (data: { query_config: Record<string, any>; connection_id?: number }) =>
    safeFetch('/api/published-views/detect-partitions', { method: 'POST', body: safeStringify(data) }),

  // ── Self-Service API Key Requests ────────────────────────────────────────
  requestApiKey: (data: {
    key_name: string;
    scoped_view_ids: number[];
    rate_limit?: string;
    expires_hours?: number;
    justification?: string;
  }) =>
    safeFetch('/api/api-key-requests', { method: 'POST', body: safeStringify(data) }),

  listApiKeyRequests: (status?: string) =>
    safeFetch(`/api/api-key-requests${status ? `?status=${status}` : ''}`),

  pendingRequestCount: () =>
    safeFetch('/api/api-key-requests/pending-count') as Promise<{ count: number }>,

  approveApiKeyRequest: (requestId: number, data?: { note?: string; rate_limit_override?: string; expires_hours_override?: number }) =>
    safeFetch(`/api/api-key-requests/${requestId}/approve`, { method: 'POST', body: safeStringify(data || {}) }),

  denyApiKeyRequest: (requestId: number, data?: { note?: string }) =>
    safeFetch(`/api/api-key-requests/${requestId}/deny`, { method: 'POST', body: safeStringify(data || {}) }),

  // ── Admin Config ──────────────────────────────────────────────────────────
  getPublishedViewsConfig: () =>
    safeFetch('/api/admin/published-views/config'),

  updatePublishedViewsConfig: (data: Record<string, any>) =>
    safeFetch('/api/admin/published-views/config', { method: 'PUT', body: safeStringify(data) }),
};

export default publishedViews;
