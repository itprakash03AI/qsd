/**
 * API barrel — composes all domain modules into a single `api` object.
 * Maintains backward compatibility: `import api from '../services/api'` still works.
 */

// Re-export shared types and utilities for direct imports
export { ApiError, safeFetch, sharedFetch, openDownload, uploadFetch, rawFetch, toBackendQueryConfig, API_BASE_URL, PUBLISHED_API_BASE_URL } from './core';
export type {
  QueryConfig, Connection, SavedQuery, Execution, Dataset,
  BusinessReport, DashboardItem, Widget, Schedule, Notification,
} from './core';

import connections from './connections';
import queries from './queries';
import execution from './execution';
import reports from './reports';
import datasets from './datasets';
import businessReports from './businessReports';
import admin from './admin';
import publishedViews from './publishedViews';
import feeds from './feeds';
// Phase 133 — source-vs-destination reconciliation reports
import reconciliation from './reconciliation';
import federationViews from './federationViews';
import metadataCatalog from './metadataCatalog';
import dataQuality from './dataQuality';
import userPreferences from './userPreferences';
import sqlFilesService from './sqlFiles';
import sapTasksService from './sapTasks';
import businessQueryBuilder from './businessQueryBuilder';
import dataflows from './dataflows';
// BF-430A — namespaced access to the S3 reader admin endpoints (used by
// PublishViewDialog + MV admin to populate the reader_override dropdown).
import { s3Readers } from './s3Readers';
import { _setApiRef as _setQueryApiRef } from './queries';
import { _setApiRef as _setExecApiRef } from './execution';
import { safeFetch } from './core';

const api = {
  ...admin,
  ...connections,
  ...queries,
  ...execution,
  ...reports,
  ...datasets,
  ...businessReports,
  ...publishedViews,
  ...feeds,
  ...federationViews,
  ...metadataCatalog,
  ...dataQuality,
  ...userPreferences,
  sqlFiles: sqlFilesService,
  sapTasks: sapTasksService,
  businessQueryBuilder,
  dataflows,
  s3Readers,  // BF-430A
  reconciliation,  // Phase 133 — source vs destination recon reports

  // Raw HTTP shortcut methods — used by components that need ad-hoc endpoints
  get: (url: string, options?: RequestInit) =>
    safeFetch(url, { method: 'GET', ...options }),
  post: (url: string, data?: any, options?: RequestInit) =>
    safeFetch(url, { method: 'POST', body: data !== undefined ? JSON.stringify(data) : undefined, ...options }),
  put: (url: string, data?: any, options?: RequestInit) =>
    safeFetch(url, { method: 'PUT', body: data !== undefined ? JSON.stringify(data) : undefined, ...options }),
  delete: (url: string, options?: RequestInit) =>
    safeFetch(url, { method: 'DELETE', ...options }),
};

// Wire up cross-references (getExecutionStatus → listDownloads, getSavedQueries → listQueries)
_setQueryApiRef(api);
_setExecApiRef(api);

export default api;
