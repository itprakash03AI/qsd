/**
 * API — Admin, Config, Intelligence, Lineage, Misc
 */
import { safeFetch, uploadFetch, rawFetch, openDownload, API_BASE_URL } from './core';
import { safeStringify } from '../../utils/safeStringify';

const admin = {
  // ── Health ──────────────────────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: (err as Error).message })),

  // ── Files ───────────────────────────────────────────────────────────────
  listFiles: (storageType: string | null = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },
  getFileSchema: (filePath: string) =>
    safeFetch(`/api/files/${filePath}/schema`).catch(err => {
      console.warn(`Schema failed for ${filePath}:`, (err as Error).message);
      return { file: filePath, columns: [], num_rows: 0 };
    }),
  uploadFile: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return uploadFetch('/api/files/upload', form);
  },

  // ── S3 ──────────────────────────────────────────────────────────────────
  configureS3: (config: object) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: safeStringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Schedules ───────────────────────────────────────────────────────────
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),
  createSchedule: (data: object) =>
    safeFetch('/api/schedules', { method: 'POST', body: safeStringify(data) }),
  getSchedule: (id: string) => safeFetch(`/api/schedules/${id}`),
  updateSchedule: (id: string, data: object) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteSchedule: (id: string) => safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),
  pauseSchedule: (id: string) => safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),
  resumeSchedule: (id: string) => safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),
  runScheduleNow: (id: string) => safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),
  getSchedulerStatus: () => safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),
  getScheduleRunStats: (scheduleId: number, limit: number = 20): Promise<any> =>
    safeFetch(`/api/schedules/${scheduleId}/run-stats?limit=${limit}`),
  getAnomalies: (limit: number = 50): Promise<any> =>
    safeFetch(`/api/admin/anomalies?limit=${limit}`),

  // ── App Settings ────────────────────────────────────────────────────────
  getAppSettings: () => safeFetch('/api/app-settings'),
  getAdminAppConfig: () => safeFetch('/api/admin/app-config'),
  updateAdminAppConfig: (data: { limits?: Record<string, any>; features?: Record<string, any> }) =>
    safeFetch('/api/admin/app-config', { method: 'PUT', body: safeStringify(data) }),

  // ── UI Component Visibility ─────────────────────────────────────────────
  getUIVisibility: () => safeFetch('/api/admin/ui-visibility'),
  setUIVisibility: (rules: Array<{ component_key: string; role: string; enabled: boolean }>) =>
    safeFetch('/api/admin/ui-visibility', { method: 'PUT', body: safeStringify({ rules }) }),

  // ── Dashboards ──────────────────────────────────────────────────────────
  listDashboards: () => safeFetch('/api/dashboards').catch(() => []),
  createDashboard: (data: object) =>
    safeFetch('/api/dashboards', { method: 'POST', body: safeStringify(data) }),
  getDashboard: (id: string | number) => safeFetch(`/api/dashboards/${id}`),
  updateDashboard: (id: string | number, data: object) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteDashboard: (id: string | number) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'DELETE' }),
  listDashboardWidgets: (dashId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`).catch(() => []),
  createWidget: (dashId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`, { method: 'POST', body: safeStringify(data) }),
  updateWidget: (dashId: string | number, widgetId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteWidget: (dashId: string | number, widgetId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'DELETE' }),
  updateDashboardLayout: (dashId: string | number, layouts: object[]) =>
    safeFetch(`/api/dashboards/${dashId}/layout`, { method: 'PUT', body: safeStringify({ layouts }) }),
  getSharedDashboard: (token: string) =>
    safeFetch(`/api/shared-dashboard/${token}`),
  createDashboardShare: (dashboardId: string | number, expiresHours?: number) =>
    safeFetch(`/api/dashboards/${dashboardId}/share`, {
      method: 'POST', body: safeStringify({ expires_hours: expiresHours ?? null }),
    }),

  // ── Cache ───────────────────────────────────────────────────────────────
  getCacheStats: () => safeFetch('/api/cache/stats').catch(() => ({})),
  clearCache: () => safeFetch('/api/cache', { method: 'DELETE' }),
  getCacheLayerStats: () => safeFetch('/api/admin/cache/layer-stats').catch(() => ({})),

  // ── Query ETA ───────────────────────────────────────────────────────────
  getQueryEta: (connectionId?: number | string | null): Promise<{ p75_seconds: number | null }> => {
    const qs = connectionId ? `?connection_id=${connectionId}` : '';
    return safeFetch(`/api/admin/query-eta${qs}`).catch(() => ({ p75_seconds: null }));
  },

  // ── Webhooks ────────────────────────────────────────────────────────────
  testWebhook: (url: string) =>
    safeFetch('/api/webhooks/test', { method: 'POST', body: safeStringify({ url }) }),

  // ── Materialized Views ─────────────────────────────────────────────────
  listMaterializedViews: (connectionId?: number) =>
    safeFetch(`/api/materialized-views${connectionId ? `?connection_id=${connectionId}` : ''}`).catch(() => []),
  getMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`),
  createMaterializedView: (data: object) =>
    safeFetch('/api/materialized-views', { method: 'POST', body: safeStringify(data) }),
  updateMaterializedView: (id: number, data: object) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'DELETE' }),
  refreshMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/refresh`, { method: 'POST' }),
  getMaterializedViewStatus: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/status`),
  getMaterializedViewsStorage: () =>
    safeFetch('/api/materialized-views/storage').catch(() => ({})),
  getMaterializedViewSchema: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/schema`),

  // ── Local Tables ────────────────────────────────────────────────────────
  listLocalTables: (params?: { visibility?: string; created_by?: string }) =>
    safeFetch(`/api/local-tables${params ? '?' + new URLSearchParams(params as any).toString() : ''}`),
  getLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`),
  createLocalTable: (data: object) =>
    safeFetch('/api/local-tables', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(data) }),
  updateLocalTable: (id: number, data: object) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: safeStringify(data) }),
  deleteLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'DELETE' }),
  promoteToLocalTable: (data: object) =>
    safeFetch('/api/local-tables/promote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(data) }),
  uploadLocalTable: (formData: FormData): Promise<any> =>
    uploadFetch('/api/local-tables/upload', formData),
  appendToLocalTable: (id: number, formData: FormData): Promise<any> =>
    uploadFetch(`/api/local-tables/${id}/append`, formData),
  listExcelSheets: async (file: File): Promise<string[]> => {
    const formData = new FormData();
    formData.append('file', file);
    const data = await uploadFetch('/api/local-tables/excel-sheets', formData);
    return data?.sheets || [];
  },
  listExcelSheetsByPath: async (filePath: string): Promise<string[]> => {
    const data = await safeFetch(`/api/local-tables/excel-sheets?file_path=${encodeURIComponent(filePath)}`);
    return data?.sheets || [];
  },
  getLocalTableSchema: (id: number) =>
    safeFetch(`/api/local-tables/${id}/schema`),
  getLocalTablesStorage: () =>
    safeFetch('/api/local-tables/storage').catch(() => ({})),

  // ── Table UX ────────────────────────────────────────────────────────────
  previewTable: (payload: { table_path: string; connection_id?: number; limit?: number }) =>
    safeFetch('/api/tables/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(payload) }),
  profileTable: (payload: { table_path: string; connection_id?: number; columns?: string[]; sample_size?: number }) =>
    safeFetch('/api/tables/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(payload) }),
  toggleTableFavorite: (payload: { table_path: string; table_name: string; connection_id?: number; table_type?: string }) =>
    safeFetch('/api/tables/favorite', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(payload) }),
  listTableFavorites: (connectionId?: number) =>
    safeFetch(`/api/tables/favorites${connectionId ? `?connection_id=${connectionId}` : ''}`),

  // ── Notifications ───────────────────────────────────────────────────────
  listNotifications: (unreadOnly = false, limit = 50, offset = 0) =>
    safeFetch(`/api/notifications?unread_only=${unreadOnly}&limit=${limit}&offset=${offset}`),
  getUnreadCount: () =>
    safeFetch('/api/notifications/unread-count'),
  markNotificationRead: (id: number) =>
    safeFetch(`/api/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () =>
    safeFetch('/api/notifications/read-all', { method: 'PUT' }),

  // ── Workspaces ──────────────────────────────────────────────────────────
  listWorkspaces: () =>
    safeFetch('/api/workspaces').catch(() => ({ workspaces: [] })),
  createWorkspace: (data: object) =>
    safeFetch('/api/workspaces', { method: 'POST', body: safeStringify(data) }),
  updateWorkspace: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteWorkspace: (id: number) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'DELETE' }),
  listWorkspaceMembers: (id: number) =>
    safeFetch(`/api/workspaces/${id}/members`).catch(() => ({ members: [] })),
  addWorkspaceMember: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}/members`, { method: 'POST', body: safeStringify(data) }),
  updateWorkspaceMemberRole: (id: number, username: string, data: object) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'PUT', body: safeStringify(data) }),
  removeWorkspaceMember: (id: number, username: string) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'DELETE' }),

  // ── Data Lineage ────────────────────────────────────────────────────────
  getConnectionLineage: (id: number) =>
    safeFetch(`/api/lineage/connection/${id}`),
  getReportLineage: (id: number) =>
    safeFetch(`/api/lineage/report/${id}`),
  getQueryLineage: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}?type=${encodeURIComponent(type)}`),
  getFullLineageGraph: () =>
    safeFetch('/api/lineage/graph').catch(() => ({ nodes: [], edges: [] })),
  getTableLineage: (catalog: string, schema: string, table: string) =>
    safeFetch(`/api/lineage/table/${encodeURIComponent(catalog)}/${encodeURIComponent(schema)}/${encodeURIComponent(table)}`),
  searchTableLineage: (q: string, limit: number = 50) =>
    safeFetch(`/api/lineage/table/search?q=${encodeURIComponent(q)}&limit=${limit}`),
  getQueryTables: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}/tables?type=${encodeURIComponent(type)}`),
  reparseAllLineage: () =>
    safeFetch('/api/lineage/reparse', { method: 'POST' }),
  getQueryColumnLineage: (query_id: number, query_type = 'sql_query') =>
    safeFetch(`/api/lineage/query/${query_id}/columns?query_type=${query_type}`),
  getColumnImpact: (table: string, column: string) =>
    safeFetch(`/api/lineage/column/impact?table=${encodeURIComponent(table)}&column=${encodeURIComponent(column)}`),
  getLineageSnapshots: (params?: { query_type?: string; query_id?: number; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.query_type) qs.set('query_type', params.query_type);
    if (params?.query_id != null) qs.set('query_id', String(params.query_id));
    if (params?.limit != null)    qs.set('limit', String(params.limit));
    return safeFetch(`/api/lineage/snapshots?${qs}`);
  },
  getLineageSnapshot: (id: number) =>
    safeFetch(`/api/lineage/snapshots/${id}`),
  diffLineageSnapshots: (a: number, b: number) =>
    safeFetch(`/api/lineage/snapshots/diff?a=${a}&b=${b}`),
  getDataFreshness: () =>
    safeFetch('/api/lineage/freshness'),
  getStaleTables: () =>
    safeFetch('/api/lineage/freshness/stale'),
  updateFreshnessThreshold: (table_fqn: string, stale_threshold_hours: number) =>
    safeFetch('/api/lineage/freshness/threshold', {
      method: 'PUT',
      body: safeStringify({ table_fqn, stale_threshold_hours }),
    }),
  markTableRefreshed: (table_fqn: string) =>
    safeFetch('/api/lineage/freshness/mark-refreshed', {
      method: 'POST',
      body: safeStringify({ table_fqn }),
    }),
  getLineageAdminConfig: () =>
    safeFetch('/api/admin/lineage/config'),
  setLineageAdminConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/lineage/config', {
      method: 'PUT',
      body: safeStringify(config),
    }),

  // ── Audit & Compliance ──────────────────────────────────────────────────
  getAuditLogFiltered: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string; limit?: number; offset?: number;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    return safeFetch(`/api/admin/audit-log?${qs.toString()}`);
  },
  exportAuditLog: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    const base = API_BASE_URL.replace(/\/$/, '');
    const a = document.createElement('a');
    a.href = `${base}/api/admin/audit-log/export?${qs.toString()}`;
    a.download = 'audit_log.csv';
    a.click();
    return Promise.resolve();
  },
  getDataAccessSummary: () =>
    safeFetch('/api/admin/audit-log/data-access-summary').catch(() => ({ summary: [] })),
  generateSubjectExport: (username: string) =>
    rawFetch('/api/admin/compliance/subject-export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify({ username }),
    }).then(async res => {
      if (!res.ok) throw new Error(await res.text());
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `subject_export_${username}.zip`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }),

  // ── Intelligence & NL-to-SQL ────────────────────────────────────────────
  getSuggestedTables: (params: { prefix?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.prefix) q.set('prefix', params.prefix);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/tables?${q}`);
  },
  getSuggestedColumns: (params: { table_name?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.table_name) q.set('table_name', params.table_name);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/columns?${q}`);
  },
  getTopTables: (connection_id?: number) =>
    safeFetch(`/api/suggest/top-tables${connection_id != null ? `?connection_id=${connection_id}` : ''}`),
  analyzeQuery: (sql: string, connection_type = 'duckdb', partition_columns: string[] = []) =>
    safeFetch('/api/analyze-query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify({ sql, connection_type, partition_columns }),
    }),
  nlToSql: (payload: {
    question: string;
    connection_id?: number;
    tables?: string[];
    columns?: Record<string, string[]>;
    connection_type?: string;
    default_schema?: string;
    dataset_id?: number;
    use_schema_cache?: boolean;
    conversation_context?: string[];
  }) =>
    safeFetch('/api/nl-to-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify(payload),
    }),
  nlToSqlSemantic: (payload: {
    question: string;
    dataset_id: number;
    connection_type?: string;
    default_schema?: string;
  }) =>
    safeFetch('/api/nl-to-sql/semantic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify(payload),
    }),
  getNlToSqlExamples: (dataset_id?: number) =>
    safeFetch(`/api/nl-to-sql/examples${dataset_id ? `?dataset_id=${dataset_id}` : ''}`),
  getChatbotPatterns: () => safeFetch('/api/suggest/chatbot-patterns'),
  getChatbotConfig: () => safeFetch('/api/admin/chatbot/config'),
  setChatbotConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/chatbot/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify(config),
    }),
  getSuggestSchema: (q: string, connection_id?: number) =>
    safeFetch(`/api/suggest/schema?q=${encodeURIComponent(q)}${connection_id != null ? `&connection_id=${connection_id}` : ''}`),
  getLastResultInfo: () => safeFetch('/api/suggest/last-result'),
  getSuggestDocs: (q: string) => safeFetch(`/api/suggest/docs?q=${encodeURIComponent(q)}`),
  dataQuery: (question: string, columns: string[] = [], execution_id?: string, file_id?: string) =>
    safeFetch('/api/suggest/data-query', {
      method: 'POST',
      body: safeStringify({ question, columns, execution_id, file_id }),
    }),
  saveNlFeedback: (question: string, sql: string, rating: 1 | -1, connection_type = 'duckdb', tables_hint?: string) =>
    safeFetch('/api/suggest/feedback', {
      method: 'POST',
      body: safeStringify({ question, sql, rating, connection_type, tables_hint }),
    }),
  // Phase 84D: learning-engine feedback (includes history_id)
  saveNlLearningFeedback: (payload: {
    history_id: number;
    was_edited: boolean;
    executed_sql?: string;
    execution_success: boolean;
    feedback_score: 1 | -1;
  }) =>
    safeFetch('/api/suggest/nl-feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: safeStringify(payload),
    }),
  getNlPatterns: () => safeFetch('/api/suggest/nl-patterns'),
  deleteNlPattern: (patternId: number) =>
    safeFetch(`/api/suggest/nl-patterns/${patternId}`, { method: 'DELETE' }),
  getNlSynonyms: () => safeFetch('/api/suggest/nl-synonyms'),
  getNlHistory: (limit = 50) => safeFetch(`/api/suggest/nl-history?limit=${limit}`),
  saveSuggestionCorrection: (payload: {
    correction_type: 'agg' | 'join' | 'chart' | 'pivot';
    context_key: string;
    corrected_value: string;
    original_value?: string;
    context_extra?: string;
  }) =>
    safeFetch('/api/suggest/correction', {
      method: 'POST',
      body: safeStringify(payload),
    }),
  getAggCorrections: () => safeFetch('/api/suggest/corrections/agg'),
  getJoinCorrections: () => safeFetch('/api/suggest/corrections/join'),
  getPopularJoins: (leftTable: string, rightTable: string, connectionId?: number) =>
    safeFetch(`/api/suggest/popular-joins?left_table=${encodeURIComponent(leftTable)}&right_table=${encodeURIComponent(rightTable)}${connectionId ? `&connection_id=${connectionId}` : ''}`),
  getPopularAggs: (table: string, connectionId?: number) =>
    safeFetch(`/api/suggest/popular-aggs?table=${encodeURIComponent(table)}${connectionId ? `&connection_id=${connectionId}` : ''}`),
  // ── Phase 77: Smart Predictions ──────────────────────────────────────────
  dataProfile: (executionId?: string, fileId?: string, columns?: string[]) =>
    safeFetch('/api/suggest/data-profile', {
      method: 'POST',
      body: safeStringify({ execution_id: executionId, file_id: fileId, columns: columns || [] }),
    }),
  chartRecommendations: (columns: any[], connectionId?: number, max?: number) =>
    safeFetch('/api/suggest/chart-recommendations', {
      method: 'POST',
      body: safeStringify({ columns, connection_id: connectionId, max_suggestions: max || 5 }),
    }),
  getChartCorrections: (connectionId?: number) =>
    safeFetch(`/api/suggest/corrections/chart${connectionId ? `?connection_id=${connectionId}` : ''}`),
  getPivotCorrections: (connectionId?: number) =>
    safeFetch(`/api/suggest/corrections/pivot${connectionId ? `?connection_id=${connectionId}` : ''}`),

  // ── Admin Configs ───────────────────────────────────────────────────────
  getSemanticLayerConfig: () =>
    safeFetch('/api/admin/semantic-layer/config'),
  setSemanticLayerConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/semantic-layer/config', { method: 'PUT', body: safeStringify(config) }),
  getFederationConfig: () =>
    safeFetch('/api/admin/federation/config'),
  setFederationConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/federation/config', { method: 'PUT', body: safeStringify(config) }),
  // BF-382 — Result Cache (Option D) admin endpoints
  getResultCacheStats: () =>
    safeFetch('/api/admin/result-cache/stats'),
  getResultCacheEntries: (limit = 50) =>
    safeFetch(`/api/admin/result-cache/entries?limit=${limit}`),
  clearResultCache: () =>
    safeFetch('/api/admin/result-cache/clear', { method: 'POST' }),
  invalidateResultCacheEntry: (key: string) =>
    safeFetch(`/api/admin/result-cache/entries/${encodeURIComponent(key)}`, { method: 'DELETE' }),
  getResultCacheConfig: () =>
    safeFetch('/api/admin/result-cache/config'),
  setResultCacheConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/result-cache/config', { method: 'PUT', body: safeStringify(config) }),
  // BF-383 — Multi-Worker Query Execution (Option F)
  getMultiWorkerConfig: () =>
    safeFetch('/api/admin/multi-worker/config'),
  setMultiWorkerConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/multi-worker/config', { method: 'PUT', body: safeStringify(config) }),
  getMultiWorkerStats: () =>
    safeFetch('/api/admin/multi-worker/stats'),
  testMultiWorkerSplit: (sql: string, file_count: number = 100) =>
    safeFetch('/api/admin/multi-worker/test-split', {
      method: 'POST',
      body: safeStringify({ sql, file_count }),
    }),
  getMultiWorkerHistory: (limit: number = 50) =>
    safeFetch(`/api/admin/multi-worker/history?limit=${limit}`),
  // BF-405: live workers grid for admin UI
  getMultiWorkerActive: () =>
    safeFetch('/api/admin/multi-worker/active'),
  // BF-384 — Multi-Pod (Option G) admin endpoints
  getMultiPodConfig: () =>
    safeFetch('/api/admin/multi-pod/config'),
  setMultiPodConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/multi-pod/config', { method: 'PUT', body: safeStringify(config) }),
  getMultiPodPods: () =>
    safeFetch('/api/admin/multi-pod/pods'),
  // BF-393 — Preview SQL-connector shard SQL without executing.
  multiPodSqlShardDryRun: (payload: {
    sql: string;
    connector_type: string;
    shard_count: number;
    shard_strategy: string;
    shard_column: string;
    shard_bounds?: any[][] | null;
  }) =>
    safeFetch('/api/admin/multi-pod/sql-shard-dry-run', {
      method: 'POST',
      body: safeStringify(payload),
    }),
  // BF-385 — Engine Router
  getEngineRouterConfig: () =>
    safeFetch('/api/admin/engine-router/config'),
  setEngineRouterConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/engine-router/config', { method: 'PUT', body: safeStringify(config) }),
  getEngineRouterHistory: (limit: number = 50) =>
    safeFetch(`/api/admin/engine-router/history?limit=${limit}`),
  testEngineRouter: (sql: string, file_count: number = 100, row_estimate: number = 0, is_cross_source: boolean = false) =>
    safeFetch('/api/admin/engine-router/test', {
      method: 'POST',
      body: safeStringify({ sql, file_count, row_estimate, is_cross_source }),
    }),

  getAggCacheStats: () =>
    safeFetch('/api/admin/agg-cache/stats'),
  getAggCacheDatasetStats: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/stats/${datasetId}`),
  listAggCacheSuggestions: () =>
    safeFetch('/api/admin/agg-cache/suggestions'),
  triggerAggCacheAnalysis: () =>
    safeFetch('/api/admin/agg-cache/analyze', { method: 'POST' }),
  approveAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/approve`, { method: 'POST' }),
  rejectAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/reject`, { method: 'POST' }),
  getAggCacheConfig: () =>
    safeFetch('/api/admin/agg-cache/config'),
  setAggCacheConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/agg-cache/config', { method: 'PUT', body: safeStringify(config) }),
  triggerAggCacheCleanup: () =>
    safeFetch('/api/admin/agg-cache/cleanup', { method: 'POST' }),
  invalidateAggCache: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/invalidate/${datasetId}`, { method: 'POST' }),
  getAWSPortalConfig: () =>
    safeFetch('/api/admin/aws-portal/config'),
  setAWSPortalConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/aws-portal/config', { method: 'PUT', body: safeStringify(config) }),
  testAWSPortalConfig: () =>
    safeFetch('/api/admin/aws-portal/test', { method: 'POST' }),
  getAWSPortalCacheStats: () =>
    safeFetch('/api/admin/aws-portal/cache'),
  clearAWSPortalCache: (username?: string) =>
    safeFetch(`/api/admin/aws-portal/cache${username ? `?username=${username}` : ''}`, { method: 'DELETE' }),
  // BF-PORTAL-CONN-OVERRIDES: pass the connection_id when the modal is
  // triggered DURING a query so the backend uses that connection's
  // portal_base_url / proxy_url / role_name / account_id / sf_ref_no
  // overrides instead of the global defaults.  Fixes the "modal succeeds
  // for global creds but query connection still fails with SSL wrong
  // version number" class of bug.
  authenticateAWSPortal: (username: string, password: string, connectionId?: number) => {
    const body: Record<string, unknown> = { username, password };
    if (connectionId != null) body.connection_id = connectionId;
    return safeFetch('/api/aws-portal/authenticate', { method: 'POST', body: safeStringify(body) });
  },
  getAWSPortalStatus: () =>
    safeFetch('/api/aws-portal/status'),
  // BF-285: vault-status check + clear-password endpoints used by the
  // PortalPasswordModal.  Status is cheap (just a vault presence check)
  // and lets the frontend decide whether to prompt preemptively.
  getAWSPortalPasswordStatus: () =>
    safeFetch('/api/aws-portal/password-status'),
  clearAWSPortalPassword: () =>
    safeFetch('/api/aws-portal/clear-password', { method: 'POST' }),
  getBusinessReportsConfig: () =>
    safeFetch('/api/admin/reports/config'),
  setBusinessReportsConfig: (data: any) =>
    safeFetch('/api/admin/reports/config', { method: 'PUT', body: safeStringify(data) }),
  getReportCatalogConfig: () =>
    safeFetch('/api/admin/report-catalog/config'),
  setReportCatalogConfig: (data: any) =>
    safeFetch('/api/admin/report-catalog/config', { method: 'PUT', body: safeStringify(data) }),
  getBusinessPortalConfig: () =>
    safeFetch('/api/admin/business-portal/config'),
  setBusinessPortalConfig: (data: any) =>
    safeFetch('/api/admin/business-portal/config', { method: 'PUT', body: safeStringify(data) }),
  getDeliveryConfig: () =>
    safeFetch('/api/admin/delivery/config'),
  setDeliveryConfig: (data: any) =>
    safeFetch('/api/admin/delivery/config', { method: 'PUT', body: safeStringify(data) }),
  getQueryGuardrailsConfig: () =>
    safeFetch('/api/admin/query-guardrails/config'),
  setQueryGuardrailsConfig: (data: any) =>
    safeFetch('/api/admin/query-guardrails/config', { method: 'PUT', body: safeStringify(data) }),

  // ── Phase 114-G: NL Conversation Memory ─────────────────────────────────
  listConversations: (limit: number = 50) =>
    safeFetch(`/api/assistant/conversations?limit=${limit}`),
  getOrCreateConversation: () =>
    safeFetch('/api/assistant/conversations/current'),
  updateConversation: (convId: number, data: { messages?: any[]; title?: string; context?: any }) =>
    safeFetch(`/api/assistant/conversations/${convId}`, { method: 'PUT', body: safeStringify(data) }),
  createConversation: (data: { messages?: any[]; title?: string; context?: any }) =>
    safeFetch('/api/assistant/conversations', { method: 'POST', body: safeStringify(data) }),

  // ── Phase 114-I: Explain Data ───────────────────────────────────────────
  explainData: (data: { columns: string[]; sample_data: any[]; column_types?: Record<string, string> }) =>
    safeFetch('/api/assistant/explain-data', { method: 'POST', body: safeStringify(data) }),

  // ── Phase 114-J: Report Comments ────────────────────────────────────────
  listReportComments: (reportId: number) =>
    safeFetch(`/api/business-reports/${reportId}/comments`),
  createReportComment: (reportId: number, data: { text: string; parent_id?: number }) =>
    safeFetch(`/api/business-reports/${reportId}/comments`, { method: 'POST', body: safeStringify(data) }),
  updateReportComment: (reportId: number, commentId: number, data: { text?: string; is_resolved?: boolean }) =>
    safeFetch(`/api/business-reports/${reportId}/comments/${commentId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteReportComment: (reportId: number, commentId: number) =>
    safeFetch(`/api/business-reports/${reportId}/comments/${commentId}`, { method: 'DELETE' }),
  countReportComments: (reportId: number) =>
    safeFetch(`/api/business-reports/${reportId}/comments/count`),

  // ── Phase 114-K: Report Change History ──────────────────────────────────
  getReportChangeHistory: (reportId: number, limit: number = 50) =>
    safeFetch(`/api/business-reports/${reportId}/change-history?limit=${limit}`),
};

export default admin;
