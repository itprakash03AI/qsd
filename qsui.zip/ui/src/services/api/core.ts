/**
 * API Core — shared infrastructure for all API domain modules.
 * Provides safeFetch, sharedFetch, openDownload, error parsing, and shared types.
 */

import { getAuthHeader } from '../authState';

// Runtime config: main.tsx fetches /config.json (ConfigMap-mounted in prod,
// public/config.json in dev) BEFORE evaluating this module. So window.APP_CONFIG
// is guaranteed set by the time API_BASE_URL is computed.
// Local dev: public/config.json has {"apiUrl": ""} → falls through to empty → Vite proxy.
declare global { interface Window { APP_CONFIG?: { apiUrl?: string; publishedApiUrl?: string } } }
const _raw = window.APP_CONFIG?.apiUrl ?? import.meta.env.VITE_API_URL ?? '';
export const API_BASE_URL: string = _raw.startsWith('http') ? _raw.replace(/\/+$/, '') : '';
if (_raw && !_raw.startsWith('http')) {
  console.warn(`[api/core] config.json apiUrl "${_raw}" ignored — must start with http:// or https://. Using Vite proxy (empty base).`);
}
if (API_BASE_URL) {
  console.info(`[api/core] API_BASE_URL resolved to: ${API_BASE_URL}`);
}

// Dedicated Published API URL — when publishedApi.enabled=true in the API Helm chart,
// the Published API runs on a separate pod with its own route. Users should test and
// consume published views via this URL, not the main API URL.
// Falls back to API_BASE_URL if not configured (shared mode).
const _pubRaw = window.APP_CONFIG?.publishedApiUrl ?? '';
export const PUBLISHED_API_BASE_URL: string = _pubRaw.startsWith('http') ? _pubRaw.replace(/\/+$/, '') : '';
if (PUBLISHED_API_BASE_URL) {
  console.info(`[api/core] PUBLISHED_API_BASE_URL resolved to: ${PUBLISHED_API_BASE_URL}`);
}

export class ApiError extends Error {
  errorCode?: string;
  connectionId?: number;
  constructor(message: string, errorCode?: string, connectionId?: number) {
    super(message);
    this.name = 'ApiError';
    this.errorCode = errorCode;
    this.connectionId = connectionId;
  }
}

const RETRY_STATUSES = new Set([502, 503, 504]);
const MAX_RETRIES = 2;
const RETRY_DELAYS = [1000, 3000];

export const _parseError = async (response: Response): Promise<{ detail: string; errorCode?: string; connectionId?: number }> => {
  let detail = `HTTP ${response.status}`;
  let errorCode: string | undefined;
  let connectionId: number | undefined;
  try {
    const e = await response.json() as { detail?: any; message?: string };
    if (typeof e.detail === 'string') {
      detail = e.detail;
    } else if (Array.isArray(e.detail)) {
      // BF-428M — safeStringify defends against polluted error payloads
      // (e.g., a Pydantic error whose `input` field carries a complex
      // object) — native JSON.stringify would crash with circular ref.
      const { safeStringify } = await import('../../utils/safeStringify');
      detail = (e.detail as { msg?: string; loc?: any[]; input?: any }[]).map(d => {
        let s = d.msg || safeStringify(d);
        if (d.loc) s += ` [field: ${d.loc.join('.')}]`;
        if (d.input !== undefined) s += ` [got: ${safeStringify(d.input)}]`;
        return s;
      }).join('; ');
    } else if (e.detail && typeof e.detail === 'object') {
      detail = e.detail.message || JSON.stringify(e.detail);
      errorCode = e.detail.error_code;
      connectionId = e.detail.connection_id;
    } else if (e.message) {
      detail = e.message;
    }
  } catch {}
  return { detail, errorCode, connectionId };
};

export const safeFetch = async (
  url: string,
  // 2026-06-04 audit — added retryOnTimeout (default true).  Polling
  // callers (Operations Dashboard, Query Diagnostic) should pass false
  // so a slow endpoint doesn't generate 3 overlapping requests within
  // the polling interval.  GET retries on network TypeError still fire
  // regardless.
  options: RequestInit & { timeoutMs?: number; retryOnTimeout?: boolean } = {},
): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string>),
  };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  // Phase 83D: add correlation ID for end-to-end request tracing in logs
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  const method = (options.method || 'GET').toUpperCase();
  const canRetry = method === 'GET';

  let lastError: Error | null = null;
  const attempts = canRetry ? MAX_RETRIES + 1 : 1;

  // BF-406: per-request timeout so a single slow request doesn't appear
  // as "backend dead" (which the old reload-on-401 used to wreck UI for).
  // 2026-06-03 — bumped default 60s → 120s after operator hit AbortError
  // on admin listing endpoints (background jobs, metadata sync, column
  // stats status) that legitimately take 60-90s on hot caches.  Callers
  // can override via the new ``timeoutMs`` option.
  const REQUEST_TIMEOUT_MS = options.timeoutMs ?? 120000;
  for (let attempt = 0; attempt < attempts; attempt++) {
    // Declared per-iteration but OUTSIDE the try block so the catch
    // handler can read it.  Reset on every attempt.
    let didTimeout = false;
    try {
      // Honour caller-supplied signal — combine with our timeout
      let signal = options.signal as AbortSignal | undefined;
      let timeoutId: ReturnType<typeof setTimeout> | null = null;
      if (!signal) {
        const ctrl = new AbortController();
        timeoutId = setTimeout(() => {
          didTimeout = true;
          ctrl.abort();
        }, REQUEST_TIMEOUT_MS);
        signal = ctrl.signal;
      }
      const response = await fetch(fullUrl, { ...options, headers, signal });
      if (timeoutId) clearTimeout(timeoutId);
      if (!response.ok) {
        if (response.status === 401) {
          const { detail, errorCode: ec, connectionId: cid } = await _parseError(response);
          if (ec === 'TOKEN_EXPIRED' && cid) {
            throw new ApiError(detail, ec, cid);
          }
          // BF-403: REMOVED window.location.reload() — it destroyed all
          // React state including in-flight queries.  Now we dispatch a
          // custom event that AuthContext listens to + flips isAuth=false.
          // The route guard re-renders LoginPage; BQB and any other
          // mounted components keep their state in memory.  After re-auth
          // the user lands back on their current page with state intact.
          //
          // Architectural principle: HTTP errors NEVER reload the page.
          // Long queries (5+ min) + transient backend slowness must be
          // tolerated without nuking the user's typed query / open tabs.
          try {
            sessionStorage.setItem('qs_post_login_redirect',
              window.location.pathname + window.location.search);
          } catch { /* sessionStorage disabled */ }
          try {
            localStorage.removeItem('qs_auth');
            sessionStorage.removeItem('qs_auth');
            window.dispatchEvent(new CustomEvent('qs:auth-expired', {
              detail: { reason: detail || 'Session expired' },
            }));
          } catch { /* event API may not exist in older browsers */ }
          throw new ApiError(
            detail || 'Authentication required — please log in again',
            ec || 'AUTH_EXPIRED',
            cid,
          );
        }
        if (canRetry && attempt < MAX_RETRIES && RETRY_STATUSES.has(response.status)) {
          await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
          continue;
        }
        const { detail, errorCode: ec, connectionId: cid } = await _parseError(response);
        throw new ApiError(detail, ec, cid);
      }
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        return null;
      }
      // Phase 130 hotfix — defend against the stale-deploy case where
      // the SPA HTML fallback (Vite proxy / k8s ingress) returns
      // index.html with a 200 status code for an unknown /api/* path.
      // Without this guard, ``response.json()`` raises the cryptic
      // "Unexpected token '<', '<!DOCTYPE ..." error that masks the
      // real root cause (backend doesn't know this route yet).
      const _ct = (response.headers.get('content-type') || '').toLowerCase();
      if (_ct && !_ct.includes('json') && !_ct.includes('javascript') && !_ct.includes('text/plain')) {
        const _body = await response.text().catch(() => '');
        const _isHtml = /^\s*<(!DOCTYPE|html)/i.test(_body);
        throw new ApiError(
          _isHtml
            ? `Backend returned HTML instead of JSON for ${url} ` +
              `(likely the API pod hasn't loaded this route — restart or redeploy).`
            : `Backend returned non-JSON response (content-type=${_ct || 'unset'}).`,
          'NON_JSON_RESPONSE',
        );
      }
      return response.json();
    } catch (err) {
      lastError = err as Error;
      // 2026-06-03 — also retry on our own AbortController timeout
      // (didTimeout=true).  Previously the retry loop only caught
      // TypeError (network), so an admin endpoint that legitimately
      // takes 60-90s would abort once and never retry, surfacing
      // as the user-reported "signal is aborted without reason".
      const isOurTimeout = didTimeout
        || (err instanceof DOMException && err.name === 'AbortError' && !options.signal);
      const isNetwork = err instanceof TypeError;
      // 2026-06-04 — polling callers opt out via retryOnTimeout=false.
      const allowTimeoutRetry = options.retryOnTimeout !== false;
      const shouldRetry = isNetwork || (isOurTimeout && allowTimeoutRetry);
      if (canRetry && attempt < MAX_RETRIES && shouldRetry) {
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
        continue;
      }
      // Rewrite the opaque AbortError into something actionable.
      if (isOurTimeout) {
        throw new Error(
          `Request to ${url} timed out after ${REQUEST_TIMEOUT_MS}ms.  ` +
          `If this is an admin listing endpoint, pass timeoutMs: 300000 ` +
          `on safeFetch, OR check the backend logs for a sync-call-in-async stall.`
        );
      }
      throw err;
    }
  }
  // Phase 141 honest-fix: previously a SINGLE TypeError ("Failed to fetch")
  // immediately dispatched qs:api-offline which flipped the entire app to
  // a full-screen "Backend API Unavailable" screen — destroying typed SQL,
  // in-flight queries, and open tabs.  That is exactly what a long-running
  // query through a corporate proxy will look like after a brief network
  // blip.  We now keep the signal (so the periodic health check is forced
  // immediately) but the receiver (AuthContext) requires multiple
  // consecutive failures before flipping apiOnline.  The banner replaces
  // the takeover so user context is preserved either way.
  if (lastError instanceof TypeError) {
    window.dispatchEvent(new CustomEvent('qs:api-offline'));
  }
  throw lastError || new ApiError('Request failed after retries');
};

/**
 * Authenticated file download — fetches as blob with auth headers, then triggers
 * browser download via temporary object URL.  Replaces the old window.open()
 * approach which could not carry the Authorization header.
 */
export const openDownload = async (path: string): Promise<void> => {
  const fullUrl = path.startsWith('http') ? path : `${API_BASE_URL}${path}`;
  const headers: Record<string, string> = {};
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;

  const response = await fetch(fullUrl, { headers });
  if (!response.ok) {
    const { detail } = await _parseError(response);
    throw new ApiError(detail);
  }

  const blob = await response.blob();
  const blobUrl = URL.createObjectURL(blob);

  // Extract filename from Content-Disposition header, or derive from path
  const cd = response.headers.get('Content-Disposition') || '';
  const fnMatch = cd.match(/filename="?([^";\n]+)"?/);
  const filename = fnMatch?.[1] || path.split('/').pop() || 'download';

  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(blobUrl);
};

export const sharedFetch = async (shareToken: string, url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Share-Token': shareToken,
    ...(options.headers as Record<string, string>),
  };
  const response = await fetch(fullUrl, { ...options, headers });
  if (!response.ok) {
    const { detail } = await _parseError(response);
    throw new ApiError(detail);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

/**
 * Authenticated FormData upload — injects auth + workspace + request-id headers.
 * Does NOT set Content-Type (browser auto-sets multipart/form-data with boundary).
 * Returns parsed JSON response.
 */
export const uploadFetch = async (url: string, formData: FormData, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = { ...(options.headers as Record<string, string>) };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  const response = await fetch(fullUrl, { method: 'POST', ...options, headers, body: formData });
  if (!response.ok) {
    const { detail, errorCode, connectionId } = await _parseError(response);
    throw new ApiError(detail, errorCode, connectionId);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

/**
 * Raw authenticated fetch — injects auth + workspace + request-id headers,
 * returns the raw Response object. Use for streaming, blobs, or fire-and-forget.
 */
export const rawFetch = async (url: string, options: RequestInit = {}): Promise<Response> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = { ...(options.headers as Record<string, string>) };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  return fetch(fullUrl, { ...options, headers });
};

// ── Shared types ──────────────────────────────────────────────────────────────

export interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
}

export const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
  };
};

// ── Response interfaces ───────────────────────────────────────────────────────

export interface Connection {
  id: number;
  name: string;
  type: string;
  config: Record<string, any>;
  is_active: boolean;
  test_status?: string;
  test_message?: string;
  last_tested_at?: string;
  created_at?: string;
  updated_at?: string;
}

export interface SavedQuery {
  id: number;
  name: string;
  description?: string;
  query_config: Record<string, any>;
  connection_id?: number;
  created_by?: string;
  is_active: boolean;
  is_favorite?: boolean;
  folder?: string | null;
  tags?: string[] | null;
  created_at?: string;
  updated_at?: string;
}

export interface Execution {
  id: number;
  execution_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  query_config?: Record<string, any>;
  connection_id?: number;
  file_id?: string;
  row_count?: number;
  error_message?: string;
  duration_ms?: number;
  created_at?: string;
}

export interface Dataset {
  id: number;
  name: string;
  subject: string;
  description?: string;
  is_published: boolean;
  owner?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BusinessReport {
  id: number;
  name: string;
  description?: string;
  dataset_id: number;
  owner?: string;
  is_published: boolean;
  is_certified?: boolean;
  template_category?: string;
  config: Record<string, any>;
  created_at?: string;
  updated_at?: string;
}

export interface DashboardItem {
  id: number;
  name: string;
  description?: string;
  owner?: string;
  is_shared: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Widget {
  id: number;
  dashboard_id: number;
  title: string;
  chart_type: string;
  config: Record<string, any>;
  layout?: Record<string, any>;
}

export interface Schedule {
  id: number;
  name: string;
  cron_expression: string;
  query_id?: number;
  report_id?: number;
  is_active: boolean;
  last_run_at?: string;
  next_run_at?: string;
}

export interface Notification {
  id: number;
  type: string;
  message: string;
  is_read: boolean;
  created_at: string;
  metadata?: Record<string, any>;
}
