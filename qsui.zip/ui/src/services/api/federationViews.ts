/**
 * API — Federation Views (Phase 93)
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const federationViews = {
  listFederationViews: (activeOnly = false) => {
    const qs = activeOnly ? '?active_only=true' : '';
    return safeFetch(`/api/federation-views${qs}`);
  },

  createFederationView: (data: {
    name: string;
    description?: string;
    primary_conn_id: number;
    primary_query: Record<string, any>;
    secondary_conn_id: number;
    secondary_query: Record<string, any>;
    combine_mode?: string;
    join_on?: Array<{ left: string; right: string }>;
    join_how?: string;
    output_columns?: string[];
    is_active?: boolean;
  }) => safeFetch('/api/federation-views', { method: 'POST', body: safeStringify(data) }),

  getFederationView: (viewId: number) =>
    safeFetch(`/api/federation-views/${viewId}`),

  updateFederationView: (viewId: number, data: Record<string, any>) =>
    safeFetch(`/api/federation-views/${viewId}`, { method: 'PUT', body: safeStringify(data) }),

  deleteFederationView: (viewId: number) =>
    safeFetch(`/api/federation-views/${viewId}`, { method: 'DELETE' }),

  previewFederationView: (viewId: number) =>
    safeFetch(`/api/federation-views/${viewId}/preview`, { method: 'POST' }),

  // Phase 97: Materialization + Schema
  materializeFederationView: (viewId: number) =>
    safeFetch(`/api/federation-views/${viewId}/materialize`, { method: 'POST' }),

  getFederationViewSchema: (viewId: number) =>
    safeFetch(`/api/federation-views/${viewId}/schema`),

  listMaterializedFederationViews: () =>
    safeFetch('/api/federation-views/materialized'),
};

export default federationViews;
