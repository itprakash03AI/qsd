/**
 * Tests for services/loginCrypto.ts — RSA-OAEP encrypt path for /auth/login.
 *
 * We stub /auth/public-key with a known 2048-bit RSA key, run encryptPassword,
 * then decrypt the resulting ciphertext using Node's crypto module to verify
 * the Web-Crypto path produced a valid RSA-OAEP-SHA256 payload.
 *
 * Also verifies:
 *   - Cache is populated after first call (subsequent calls don't refetch).
 *   - resetLoginCryptoCache() forces a refetch (used by stale-key 400 recovery).
 *   - encryptPassword() returns null when /auth/public-key returns 503
 *     (cryptography missing on backend) — caller falls back to plaintext.
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { generateKeyPairSync, privateDecrypt, constants as cryptoConstants, createPublicKey } from 'crypto';

import {
  encryptPassword,
  resetLoginCryptoCache,
  isLoginCryptoAvailable,
} from '../loginCrypto';

// ── Generate a stable RSA-2048 keypair once for the whole suite ──────────────
const { publicKey, privateKey } = generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding:  { type: 'spki',  format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

// vitest's jsdom env doesn't ship a working window.crypto.subtle — bind
// Node's webcrypto so importKey/encrypt work.  Note: window.crypto is
// already defined by jsdom for randomUUID etc., so we replace only .subtle.
import { webcrypto } from 'crypto';
Object.defineProperty(window.crypto, 'subtle', {
  configurable: true,
  value: (webcrypto as unknown as Crypto).subtle,
});

function _b64ToBuf(b64: string): Buffer {
  return Buffer.from(b64, 'base64');
}

beforeEach(() => {
  resetLoginCryptoCache();
  vi.restoreAllMocks();
});

describe('isLoginCryptoAvailable', () => {
  it('returns true in jsdom with webcrypto bound', () => {
    expect(isLoginCryptoAvailable()).toBe(true);
  });
});

describe('encryptPassword — happy path', () => {
  it('encrypts a password the server can decrypt with the matching private key', async () => {
    // Stub /auth/public-key to return our test PEM + a fingerprint.
    const fingerprint = 'deadbeefcafe1234';
    const fetchSpy = vi.spyOn(window, 'fetch').mockResolvedValue(new Response(
      JSON.stringify({
        algorithm: 'RSA-OAEP', hash: 'SHA-256', key_size: 2048,
        public_key_pem: publicKey,
        fingerprint,
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    ) as Response);

    const out = await encryptPassword('hunter2-correct-horse');
    expect(out).not.toBeNull();
    expect(out!.key_fingerprint).toBe(fingerprint);

    // Round-trip: decrypt with the matching private key.
    const plain = privateDecrypt(
      {
        key: createPublicKey(publicKey) && privateKey,
        padding: cryptoConstants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      _b64ToBuf(out!.password_encrypted),
    );
    expect(plain.toString('utf-8')).toBe('hunter2-correct-horse');

    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it('caches the imported key — second encrypt does not refetch', async () => {
    const fetchSpy = vi.spyOn(window, 'fetch').mockResolvedValue(new Response(
      JSON.stringify({
        algorithm: 'RSA-OAEP', hash: 'SHA-256', key_size: 2048,
        public_key_pem: publicKey, fingerprint: 'fpr1234567890abc',
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    ) as Response);

    await encryptPassword('one');
    await encryptPassword('two');
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it('refetches after resetLoginCryptoCache()', async () => {
    // Factory: every call returns a fresh Response so .json() doesn't trip
    // the happy-dom "Body has already been used" guard the second time.
    const _mkResp = () => new Response(
      JSON.stringify({
        algorithm: 'RSA-OAEP', hash: 'SHA-256', key_size: 2048,
        public_key_pem: publicKey, fingerprint: 'cachefpr00000000',
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    ) as Response;
    const fetchSpy = vi.spyOn(window, 'fetch')
      .mockImplementation(() => Promise.resolve(_mkResp()));

    const a = await encryptPassword('first');
    expect(a).not.toBeNull();
    resetLoginCryptoCache();
    const b = await encryptPassword('second');
    expect(b).not.toBeNull();
    expect(fetchSpy).toHaveBeenCalledTimes(2);
  });
});

describe('encryptPassword — fallback paths', () => {
  it('returns null when /auth/public-key returns 503 (cryptography missing)', async () => {
    vi.spyOn(window, 'fetch').mockResolvedValue(new Response(
      JSON.stringify({ detail: 'login crypto unavailable' }),
      { status: 503 },
    ) as Response);

    const out = await encryptPassword('whatever');
    expect(out).toBeNull();
  });

  it('returns null when the network throws', async () => {
    vi.spyOn(window, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'));
    const out = await encryptPassword('whatever');
    expect(out).toBeNull();
  });

  it('returns null when the PEM is malformed', async () => {
    vi.spyOn(window, 'fetch').mockResolvedValue(new Response(
      JSON.stringify({
        algorithm: 'RSA-OAEP', hash: 'SHA-256', key_size: 2048,
        public_key_pem: 'NOT-A-PEM',
        fingerprint: 'badpemfpr0000000',
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    ) as Response);

    const out = await encryptPassword('x');
    expect(out).toBeNull();
  });
});
