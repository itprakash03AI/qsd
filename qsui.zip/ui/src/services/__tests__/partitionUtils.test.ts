/**
 * Phase 121A — Tests for partition utility functions.
 * Pure functions: detectDatePattern, selectDateRange, invertSelection.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { detectDatePattern, selectDateRange, invertSelection } from '../partitionUtils';

// ── detectDatePattern ───────────────────────────────────────────────────────

describe('detectDatePattern', () => {
  it('returns null for empty values', () => {
    expect(detectDatePattern([])).toBeNull();
  });

  it('detects date pattern (YYYY-MM-DD)', () => {
    expect(detectDatePattern(['2024-01-15', '2024-02-20', '2024-03-10'])).toBe('date');
  });

  it('detects year-month pattern (YYYY-MM)', () => {
    expect(detectDatePattern(['2024-01', '2024-02', '2024-03'])).toBe('year-month');
  });

  it('detects year pattern (YYYY)', () => {
    expect(detectDatePattern(['2020', '2021', '2022', '2023'])).toBe('year');
  });

  it('detects month pattern (MM)', () => {
    expect(detectDatePattern(['01', '02', '03', '12'])).toBe('month');
  });

  it('returns null for non-date values', () => {
    expect(detectDatePattern(['active', 'pending', 'done'])).toBeNull();
  });

  it('returns null for mixed formats', () => {
    expect(detectDatePattern(['2024-01-15', '2024-02', 'abc'])).toBeNull();
  });

  it('does not detect months > 12 as month pattern', () => {
    expect(detectDatePattern(['13', '25', '99'])).toBeNull();
  });

  it('does not detect years outside 1990-2099 as year pattern', () => {
    expect(detectDatePattern(['1800', '1900', '1989'])).toBeNull();
  });

  it('samples only first 10 values', () => {
    const dates = Array.from({ length: 20 }, (_, i) =>
      `2024-01-${String(i + 1).padStart(2, '0')}`
    );
    // Replace 15th value with junk — should still detect as date (only first 10 sampled)
    dates[14] = 'not-a-date';
    expect(detectDatePattern(dates)).toBe('date');
  });
});

// ── selectDateRange ─────────────────────────────────────────────────────────

describe('selectDateRange', () => {
  // Use fixed date for deterministic tests
  const realDate = Date;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2024-06-15T12:00:00Z'));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('date pattern', () => {
    const values = [
      '2024-05-01', '2024-05-15', '2024-06-01',
      '2024-06-10', '2024-06-15', '2024-06-20',
      '2024-07-01',
    ];

    it('last7d returns dates within 7 days', () => {
      const result = selectDateRange(values, 'last7d', 'date');
      expect(result).toEqual(['2024-06-10', '2024-06-15']);
    });

    it('last30d returns dates within 30 days', () => {
      // June 15 - 30 days = May 16; May 15 is NOT included
      const result = selectDateRange(values, 'last30d', 'date');
      expect(result).toEqual(['2024-06-01', '2024-06-10', '2024-06-15']);
    });

    it('thisMonth returns dates from start of current month', () => {
      const result = selectDateRange(values, 'thisMonth', 'date');
      expect(result).toEqual(['2024-06-01', '2024-06-10', '2024-06-15']);
    });

    it('lastMonth returns dates from previous month', () => {
      const result = selectDateRange(values, 'lastMonth', 'date');
      expect(result).toEqual(['2024-05-01', '2024-05-15']);
    });

    it('thisYear returns dates from start of current year', () => {
      const result = selectDateRange(values, 'thisYear', 'date');
      expect(result).toEqual([
        '2024-05-01', '2024-05-15', '2024-06-01',
        '2024-06-10', '2024-06-15',
      ]);
    });
  });

  describe('year-month pattern', () => {
    const values = ['2024-04', '2024-05', '2024-06', '2024-07'];

    it('thisMonth returns current year-month', () => {
      const result = selectDateRange(values, 'thisMonth', 'year-month');
      expect(result).toEqual(['2024-06']);
    });

    it('lastMonth returns previous year-month', () => {
      const result = selectDateRange(values, 'lastMonth', 'year-month');
      expect(result).toEqual(['2024-05']);
    });

    it('thisYear returns all months in current year up to now', () => {
      const result = selectDateRange(values, 'thisYear', 'year-month');
      expect(result).toEqual(['2024-04', '2024-05', '2024-06']);
    });
  });

  describe('year pattern', () => {
    const values = ['2022', '2023', '2024', '2025'];

    it('thisYear returns current year', () => {
      const result = selectDateRange(values, 'thisYear', 'year');
      expect(result).toEqual(['2024']);
    });

    it('lastMonth returns current year (year-level granularity)', () => {
      const result = selectDateRange(values, 'lastMonth', 'year');
      expect(result).toEqual(['2024']);
    });
  });

  describe('month pattern', () => {
    const values = ['01', '02', '06', '12'];

    it('returns all values (no date range filtering for month pattern)', () => {
      const result = selectDateRange(values, 'thisMonth', 'month');
      expect(result).toEqual(values);
    });
  });
});

// ── invertSelection ─────────────────────────────────────────────────────────

describe('invertSelection', () => {
  it('returns unselected values', () => {
    expect(invertSelection(['a', 'b', 'c', 'd'], ['a', 'c'])).toEqual(['b', 'd']);
  });

  it('returns all when nothing selected', () => {
    expect(invertSelection(['a', 'b'], [])).toEqual(['a', 'b']);
  });

  it('returns empty when all selected', () => {
    expect(invertSelection(['a', 'b'], ['a', 'b'])).toEqual([]);
  });

  it('handles empty allValues', () => {
    expect(invertSelection([], ['a'])).toEqual([]);
  });
});
