/**
 * Phase 121A — Tests for column intelligence: classification, chart/pivot
 * suggestions, join key suggestions, and aggregation function suggestions.
 */
import { describe, it, expect } from 'vitest';
import {
  classifyColumns,
  suggestChart,
  suggestPivot,
  suggestJoins,
  suggestAggFunction,
  reorderPresets,
  generateChartPresets,
  generatePivotPresets,
  type ClassifiedColumn,
} from '../columnIntelligence';

// ── Helper: build a classified column for test convenience ──────────────────

function col(name: string, role: ClassifiedColumn['role'], distinct = 5, nullPct = 0, opts?: Partial<ClassifiedColumn>): ClassifiedColumn {
  return { name, role, duckdbType: '', distinctEstimate: distinct, nullPct, ...opts };
}

// ── classifyColumns ─────────────────────────────────────────────────────────

describe('classifyColumns', () => {
  it('classifies numeric columns by DuckDB type', () => {
    const result = classifyColumns(['amount'], [], { amount: 'DOUBLE' });
    expect(result[0].role).toBe('numeric');
  });

  it.each([
    'INT', 'INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT', 'HUGEINT',
    'UBIGINT', 'USMALLINT', 'UINT', 'UINTEGER', 'UTINYINT',
    'FLOAT', 'DOUBLE', 'REAL', 'DECIMAL', 'NUMERIC', 'DECIMAL(18,2)',
    'int8', 'int16', 'int32', 'int64', 'uint8', 'uint16', 'uint32', 'uint64',
    'float32', 'float64', 'decimal128', 'int96', 'NUMBER',
  ])('classifies DuckDB type "%s" as numeric', (duckdbType) => {
    const result = classifyColumns(['col'], [], { col: duckdbType });
    expect(result[0].role).toBe('numeric');
  });

  it('classifies temporal columns by DuckDB type', () => {
    const result = classifyColumns(['created_at'], [], { created_at: 'TIMESTAMP' });
    expect(result[0].role).toBe('temporal');
  });

  it('classifies boolean columns by DuckDB type', () => {
    const result = classifyColumns(['is_active'], [], { is_active: 'BOOLEAN' });
    expect(result[0].role).toBe('boolean');
  });

  it('classifies VARCHAR as categorical', () => {
    const result = classifyColumns(['status'], [], { status: 'VARCHAR' });
    expect(result[0].role).toBe('categorical');
  });

  it('infers numeric from data when no type provided', () => {
    const rows = [{ price: 100 }, { price: 200 }, { price: 300 }];
    const result = classifyColumns(['price'], rows);
    expect(result[0].role).toBe('numeric');
  });

  it('infers temporal from date strings in data', () => {
    const rows = [{ dt: '2024-01-01' }, { dt: '2024-02-01' }];
    const result = classifyColumns(['dt'], rows);
    expect(result[0].role).toBe('temporal');
  });

  it('infers categorical from string data', () => {
    const rows = [{ status: 'active' }, { status: 'pending' }];
    const result = classifyColumns(['status'], rows);
    expect(result[0].role).toBe('categorical');
  });

  it('detects ID columns by name pattern + high cardinality', () => {
    const rows = Array.from({ length: 10 }, (_, i) => ({ user_id: i + 1 }));
    const result = classifyColumns(['user_id'], rows, { user_id: 'INTEGER' });
    expect(result[0].role).toBe('id');
  });

  it('computes null percentage from first page', () => {
    const rows = [{ x: 1 }, { x: null }, { x: 3 }, { x: null }];
    const result = classifyColumns(['x'], rows, { x: 'INTEGER' });
    expect(result[0].nullPct).toBe(0.5);
  });

  it('marks partition columns', () => {
    const rows = [{ year: '2024' }];
    const result = classifyColumns(['year'], rows, { year: 'VARCHAR' }, ['year']);
    expect(result[0].isPartition).toBe(true);
  });

  it('returns unknown for all-null column', () => {
    const rows = [{ x: null }, { x: null }];
    const result = classifyColumns(['x'], rows);
    expect(result[0].role).toBe('unknown');
  });
});

// ── suggestChart ────────────────────────────────────────────────────────────

describe('suggestChart', () => {
  it('suggests line chart for temporal + numeric', () => {
    const classified = [
      col('date', 'temporal'),
      col('amount', 'numeric'),
    ];
    const result = suggestChart(classified);
    expect(result.chartType).toBe('line');
    expect(result.xCol).toBe('date');
    expect(result.yCol).toBe('amount');
  });

  it('suggests scatter for two numerics without categoricals', () => {
    const classified = [
      col('price', 'numeric'),
      col('quantity', 'numeric'),
    ];
    const result = suggestChart(classified);
    expect(result.chartType).toBe('scatter');
  });

  it('suggests pie for very low cardinality categorical + numeric', () => {
    const classified = [
      col('region', 'categorical', 4),
      col('sales', 'numeric'),
    ];
    const result = suggestChart(classified);
    expect(result.chartType).toBe('pie');
  });

  it('suggests bar for moderate cardinality categorical', () => {
    const classified = [
      col('product', 'categorical', 12),
      col('revenue', 'numeric'),
    ];
    const result = suggestChart(classified);
    expect(result.chartType).toBe('bar');
  });

  it('excludes columns with >80% nulls', () => {
    const classified = [
      col('date', 'temporal', 5, 0.9),  // >80% nulls — excluded
      col('category', 'categorical', 5),
      col('amount', 'numeric'),
    ];
    const result = suggestChart(classified);
    // Should NOT pick temporal (excluded), should fall through to categorical + numeric
    expect(result.xCol).toBe('category');
  });

  it('returns fallback when no clear pattern', () => {
    const classified = [col('x', 'unknown'), col('y', 'unknown')];
    const result = suggestChart(classified);
    expect(result.chartType).toBe('bar');
  });
});

// ── suggestPivot ────────────────────────────────────────────────────────────

describe('suggestPivot', () => {
  it('uses temporal for row field when available', () => {
    const classified = [
      col('date', 'temporal'),
      col('region', 'categorical', 5),
      col('sales', 'numeric'),
    ];
    const result = suggestPivot(classified);
    expect(result.rowFields[0]).toBe('date');
  });

  it('uses numeric columns for values with SUM', () => {
    const classified = [
      col('region', 'categorical', 5),
      col('sales', 'numeric'),
      col('cost', 'numeric'),
    ];
    const result = suggestPivot(classified);
    expect(result.values).toEqual([
      { column: 'sales', function: 'sum' },
      { column: 'cost', function: 'sum' },
    ]);
  });

  it('falls back to count when no numeric columns', () => {
    const classified = [
      col('status', 'categorical', 3),
      col('region', 'categorical', 5),
    ];
    const result = suggestPivot(classified);
    expect(result.values).toEqual([{ column: '*', function: 'count' }]);
  });
});

// ── suggestJoins ────────────────────────────────────────────────────────────

describe('suggestJoins', () => {
  it('finds exact name match with same type', () => {
    const left = [{ name: 'customer_id', type: 'INTEGER' }];
    const right = [{ name: 'customer_id', type: 'INTEGER' }];
    const result = suggestJoins(left, right);
    expect(result).toHaveLength(1);
    expect(result[0]).toEqual({
      leftColumn: 'customer_id',
      rightColumn: 'customer_id',
      confidence: 'exact',
    });
  });

  it('finds pattern match: left "customer_id" → right table "customer" with column "id"', () => {
    const left = [{ name: 'customer_id', type: 'INTEGER' }];
    const right = [{ name: 'id', type: 'INTEGER' }];
    const result = suggestJoins(left, right, 'orders', 'customer');
    expect(result).toHaveLength(1);
    expect(result[0].confidence).toBe('pattern');
    expect(result[0].rightColumn).toBe('id');
  });

  it('finds pattern match: left table "customer" with "id" → right "customer_id"', () => {
    const left = [{ name: 'id', type: 'INTEGER' }];
    const right = [{ name: 'customer_id', type: 'INTEGER' }];
    const result = suggestJoins(left, right, 'customer', 'orders');
    expect(result).toHaveLength(1);
    expect(result[0].rightColumn).toBe('customer_id');
  });

  it('does not match columns with different types', () => {
    const left = [{ name: 'id', type: 'INTEGER' }];
    const right = [{ name: 'id', type: 'VARCHAR' }];
    const result = suggestJoins(left, right);
    expect(result).toHaveLength(0);
  });

  it('normalizes INT/INTEGER/BIGINT to same type', () => {
    const left = [{ name: 'id', type: 'INTEGER' }];
    const right = [{ name: 'id', type: 'BIGINT' }];
    const result = suggestJoins(left, right);
    expect(result).toHaveLength(1);
  });

  it('sorts exact matches before pattern matches', () => {
    const left = [
      { name: 'region', type: 'VARCHAR' },
      { name: 'customer_id', type: 'INTEGER' },
    ];
    const right = [
      { name: 'region', type: 'VARCHAR' },
      { name: 'id', type: 'INTEGER' },
    ];
    const result = suggestJoins(left, right, 'orders', 'customer');
    expect(result[0].confidence).toBe('exact');
    expect(result[1].confidence).toBe('pattern');
  });
});

// ── suggestAggFunction ──────────────────────────────────────────────────────

describe('suggestAggFunction', () => {
  it('suggests SUM for amount-like columns', () => {
    expect(suggestAggFunction('total_amount', 'DOUBLE').fn).toBe('SUM');
  });

  it('suggests AVG for rate-like columns', () => {
    // 'conversion_rate' has no SUM-pattern keyword, hits AVG via 'rate'
    expect(suggestAggFunction('conversion_rate', 'DOUBLE').fn).toBe('AVG');
  });

  it('suggests COUNT DISTINCT for ID columns', () => {
    const result = suggestAggFunction('customer_id', 'INTEGER');
    expect(result.fn).toBe('COUNT');
    expect(result.distinct).toBe(true);
  });

  it('suggests MAX for date columns', () => {
    expect(suggestAggFunction('created_date', 'DATE').fn).toBe('MAX');
  });

  it('falls back to SUM for generic numeric columns', () => {
    const result = suggestAggFunction('col1', 'DOUBLE');
    expect(result.fn).toBe('SUM');
    expect(result.source).toBe('default');
  });

  it('falls back to COUNT for generic non-numeric columns', () => {
    const result = suggestAggFunction('col1', 'VARCHAR');
    expect(result.fn).toBe('COUNT');
    expect(result.source).toBe('default');
  });

  it('uses corrections cache when provided', () => {
    const corrections = new Map([['total_amount', { fn: 'AVG' }]]);
    const result = suggestAggFunction('total_amount', 'DOUBLE', corrections);
    expect(result.fn).toBe('AVG');
    expect(result.source).toBe('correction');
  });
});

// ── reorderPresets ──────────────────────────────────────────────────────────

describe('reorderPresets', () => {
  const presets = [
    { label: 'A' },
    { label: 'B' },
    { label: 'C' },
  ];
  const keyFn = (p: { label: string }) => p.label;

  it('returns unchanged when no feedback', () => {
    expect(reorderPresets(presets, new Map(), keyFn)).toEqual(presets);
  });

  it('promotes liked presets to top', () => {
    const feedback = new Map([['C', 1]]);
    const result = reorderPresets(presets, feedback, keyFn);
    expect(result[0].label).toBe('C');
  });

  it('removes disliked presets', () => {
    const feedback = new Map([['B', -1]]);
    const result = reorderPresets(presets, feedback, keyFn);
    expect(result.map(p => p.label)).not.toContain('B');
  });
});

// ── generateChartPresets ────────────────────────────────────────────────────

describe('generateChartPresets', () => {
  it('generates time series preset when temporal + numeric exist', () => {
    const classified = [
      col('date', 'temporal'),
      col('amount', 'numeric'),
    ];
    const presets = generateChartPresets(classified);
    expect(presets.length).toBeGreaterThan(0);
    expect(presets[0].chartType).toBe('line');
  });

  it('caps at 7 presets', () => {
    const classified = [
      col('date', 'temporal', 10),
      col('category', 'categorical', 5),
      col('region', 'categorical', 3),
      col('amount', 'numeric', 100),
      col('price', 'numeric', 100),
    ];
    const presets = generateChartPresets(classified);
    expect(presets.length).toBeLessThanOrEqual(7);
  });

  it('deduplicates by label', () => {
    const classified = [
      col('date', 'temporal'),
      col('amount', 'numeric'),
    ];
    const presets = generateChartPresets(classified);
    const labels = presets.map(p => p.label);
    expect(new Set(labels).size).toBe(labels.length);
  });
});

// ── generatePivotPresets ────────────────────────────────────────────────────

describe('generatePivotPresets', () => {
  it('generates at least one preset with categorical + numeric', () => {
    const classified = [
      col('region', 'categorical', 5),
      col('sales', 'numeric'),
    ];
    const presets = generatePivotPresets(classified);
    expect(presets.length).toBeGreaterThan(0);
  });

  it('caps at 4 presets', () => {
    const classified = [
      col('date', 'temporal', 10),
      col('category', 'categorical', 5),
      col('region', 'categorical', 3),
      col('amount', 'numeric'),
    ];
    const presets = generatePivotPresets(classified);
    expect(presets.length).toBeLessThanOrEqual(4);
  });
});

// ── isNumericCol from types.ts (Phase 125-A: single source of truth) ──────

import { isNumericCol } from '../../components/query-builder/types';

describe('isNumericCol (types.ts)', () => {

  it.each([
    'INT', 'INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT', 'HUGEINT',
    'UBIGINT', 'USMALLINT', 'UINT', 'UINTEGER', 'UTINYINT',
    'FLOAT', 'DOUBLE', 'REAL', 'DECIMAL', 'NUMERIC', 'NUMBER',
    'DECIMAL(18,2)', 'DECIMAL(38,10)', 'NUMERIC(10)',
    'int8', 'int16', 'int32', 'int64', 'int96',
    'uint8', 'uint16', 'uint32', 'uint64',
    'float32', 'float64', 'decimal128',
  ])('returns true for numeric type "%s"', (type) => {
    expect(isNumericCol(type)).toBe(true);
  });

  it.each([
    'VARCHAR', 'TEXT', 'BOOLEAN', 'DATE', 'TIMESTAMP', 'BLOB',
    'UUID', 'ENUM', 'JSON', 'INTERVAL', '',
  ])('returns false for non-numeric type "%s"', (type) => {
    expect(isNumericCol(type)).toBe(false);
  });

  it('handles null/undefined gracefully', () => {
    expect(isNumericCol(null as any)).toBe(false);
    expect(isNumericCol(undefined as any)).toBe(false);
    expect(isNumericCol('')).toBe(false);
  });
});
