/**
 * Phase 121B — Tests for useReportEngine hook.
 * Tests aggregation, section banding, running calculations, slicer filtering,
 * drill grouping, and sorting via renderHook.
 */
import { describe, it, expect } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useReportEngine, type ReportEngineInput, type SectionDef, type RunningCalcDef } from '../useReportEngine';

// ── Helper: default input ───────────────────────────────────────────────────

function makeInput(overrides: Partial<ReportEngineInput> = {}): ReportEngineInput {
  return {
    rows: [],
    columns: [],
    sectionDefs: [],
    runningCalcs: [],
    slicerValues: {},
    drillState: { level: 0, filters: [] },
    ...overrides,
  };
}

const sampleRows = [
  { region: 'East', product: 'A', amount: 100, qty: 10 },
  { region: 'East', product: 'B', amount: 200, qty: 20 },
  { region: 'West', product: 'A', amount: 300, qty: 30 },
  { region: 'West', product: 'B', amount: 400, qty: 40 },
  { region: 'West', product: 'C', amount: 500, qty: 50 },
];

const columns = ['region', 'product', 'amount', 'qty'];

// ── Empty input ─────────────────────────────────────────────────────────────

describe('useReportEngine — empty input', () => {
  it('returns empty output for no rows', () => {
    const { result } = renderHook(() => useReportEngine(makeInput()));
    expect(result.current.bandedRows).toEqual([]);
    expect(result.current.grandTotals).toEqual({});
    expect(result.current.totalRowCount).toBe(0);
    expect(result.current.activeColumns).toEqual([]);
  });

  it('returns columns in activeColumns when provided', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({ columns: ['a', 'b'] })),
    );
    expect(result.current.activeColumns).toEqual(['a', 'b']);
  });
});

// ── No sections (flat data) ─────────────────────────────────────────────────

describe('useReportEngine — flat data (no sections)', () => {
  it('returns data rows without banding for no sections', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({ rows: sampleRows, columns })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    expect(dataRows).toHaveLength(5);
    expect(result.current.totalRowCount).toBe(5);
  });

  it('each row has _rowType=data', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({ rows: sampleRows, columns })),
    );
    for (const row of result.current.bandedRows) {
      expect(row._rowType).toBe('data');
    }
  });

  it('preserves original data values', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({ rows: sampleRows, columns })),
    );
    expect(result.current.bandedRows[0].region).toBe('East');
    expect(result.current.bandedRows[0].amount).toBe(100);
  });
});

// ── Section breaks (banding) ────────────────────────────────────────────────

describe('useReportEngine — section breaks', () => {
  const sectionDef: SectionDef = {
    name: 'Region',
    break_column_id: 0,
    break_column_name: 'region',
    subtotal_measure_ids: [2],
    subtotal_measure_names: ['amount'],
  };

  it('creates header + data + subtotal rows per section', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sectionDefs: [sectionDef],
      })),
    );
    const types = result.current.bandedRows.map(r => r._rowType);
    expect(types).toContain('header');
    expect(types).toContain('data');
    expect(types).toContain('subtotal');
  });

  it('header rows have section value', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sectionDefs: [sectionDef],
      })),
    );
    const headers = result.current.bandedRows.filter(r => r._rowType === 'header');
    const sectionValues = headers.map(h => h._sectionValue);
    expect(sectionValues).toContain('East');
    expect(sectionValues).toContain('West');
  });

  it('subtotal rows have correct SUM for each section', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sectionDefs: [sectionDef],
      })),
    );
    const subtotals = result.current.bandedRows.filter(r => r._rowType === 'subtotal');
    // East: 100 + 200 = 300, West: 300 + 400 + 500 = 1200
    const amounts = subtotals.map(s => s.amount);
    expect(amounts).toContain(300);
    expect(amounts).toContain(1200);
  });

  it('includes grand_total row', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sectionDefs: [sectionDef],
      })),
    );
    const grandTotal = result.current.bandedRows.find(r => r._rowType === 'grand_total');
    expect(grandTotal).toBeDefined();
    expect(grandTotal!.amount).toBe(1500); // 100+200+300+400+500
  });
});

// ── Grand totals ────────────────────────────────────────────────────────────

describe('useReportEngine — grand totals', () => {
  it('computes grand totals for measure columns', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        measureColumns: ['amount', 'qty'],
      })),
    );
    expect(result.current.grandTotals.amount).toBe(1500);
    expect(result.current.grandTotals.qty).toBe(150);
  });
});

// ── Slicer filtering ────────────────────────────────────────────────────────

describe('useReportEngine — slicer filtering', () => {
  it('filters rows by slicer values', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        slicerValues: { region: ['East'] },
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    expect(dataRows).toHaveLength(2);
    expect(dataRows.every(r => r.region === 'East')).toBe(true);
  });

  it('empty slicer values do not filter', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        slicerValues: { region: [] },
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    expect(dataRows).toHaveLength(5);
  });

  it('slicer options are extracted from data', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        slicerValues: { region: [] },
      })),
    );
    expect(result.current.slicerOptions.region).toContain('East');
    expect(result.current.slicerOptions.region).toContain('West');
  });
});

// ── Running calculations ────────────────────────────────────────────────────

describe('useReportEngine — running calculations', () => {
  const runningSum: RunningCalcDef = {
    name: 'running_amount',
    calc_type: 'running_sum',
    measure_col_name: 'amount',
  };

  it('computes running sum across data rows', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        runningCalcs: [runningSum],
      })),
    );
    expect(result.current.calculatedColumns).toContain('running_amount');
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    // Running sum: 100, 300, 600, 1000, 1500
    expect(dataRows[0].running_amount).toBe(100);
    expect(dataRows[1].running_amount).toBe(300);
    expect(dataRows[4].running_amount).toBe(1500);
  });

  it('computes rank (descending — highest value = rank 1)', () => {
    const rank: RunningCalcDef = {
      name: 'rank_amount',
      calc_type: 'rank',
      measure_col_name: 'amount',
    };
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        runningCalcs: [rank],
      })),
    );
    expect(result.current.calculatedColumns).toContain('rank_amount');
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    // Dense rank descending: 500→1, 400→2, 300→3, 200→4, 100→5
    expect(dataRows[0].rank_amount).toBe(5);  // amount=100 → rank 5
    expect(dataRows[4].rank_amount).toBe(1);  // amount=500 → rank 1
  });

  it('computes percent of total', () => {
    const pct: RunningCalcDef = {
      name: 'pct_amount',
      calc_type: 'percent_of_total',
      measure_col_name: 'amount',
    };
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        runningCalcs: [pct],
        measureColumns: ['amount'],
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    // 100/1500 ≈ 6.67%, 200/1500 ≈ 13.33%
    expect(dataRows[0].pct_amount).toBeCloseTo(100 / 1500 * 100, 1);
  });

  it('computes previous value', () => {
    const prev: RunningCalcDef = {
      name: 'prev_amount',
      calc_type: 'previous_value',
      measure_col_name: 'amount',
    };
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        runningCalcs: [prev],
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    expect(dataRows[0].prev_amount).toBeNull(); // first row has no previous
    expect(dataRows[1].prev_amount).toBe(100);
    expect(dataRows[2].prev_amount).toBe(200);
  });
});

// ── Drill grouping ──────────────────────────────────────────────────────────

describe('useReportEngine — drill grouping', () => {
  it('groups by first hierarchy level (level=0)', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        drillState: { level: 0, filters: [] },
        drillHierarchyLevels: [
          { column_name: 'region', label: 'Region' },
          { column_name: 'product', label: 'Product' },
        ],
        measureColumns: ['amount', 'qty'],
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    // Grouped by region: East (2 rows → 1 group), West (3 rows → 1 group)
    expect(dataRows).toHaveLength(2);
    // East: amount = 100+200=300
    const east = dataRows.find(r => r.region === 'East');
    expect(east?.amount).toBe(300);
  });

  it('drill filter narrows data', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        drillState: {
          level: 0,
          filters: [{ column: 'region', value: 'West' }],
        },
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    expect(dataRows).toHaveLength(3);
    expect(dataRows.every(r => r.region === 'West')).toBe(true);
  });

  it('drill breadcrumb reflects filters', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        drillState: {
          level: 0,
          filters: [{ column: 'region', value: 'East' }],
        },
      })),
    );
    expect(result.current.drillBreadcrumb).toEqual(['region: East']);
  });
});

// ── Sorting ─────────────────────────────────────────────────────────────────

describe('useReportEngine — sorting', () => {
  it('sorts by column ascending', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sortColumn: 'amount',
        sortDirection: 'asc',
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    const amounts = dataRows.map(r => r.amount);
    expect(amounts).toEqual([100, 200, 300, 400, 500]);
  });

  it('sorts by column descending', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sortColumn: 'amount',
        sortDirection: 'desc',
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    const amounts = dataRows.map(r => r.amount);
    expect(amounts).toEqual([500, 400, 300, 200, 100]);
  });

  it('null sortDirection does not change order', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: sampleRows,
        columns,
        sortColumn: 'amount',
        sortDirection: null,
      })),
    );
    const dataRows = result.current.bandedRows.filter(r => r._rowType === 'data');
    // Original order preserved
    expect(dataRows[0].amount).toBe(100);
  });
});

// ── Edge cases ──────────────────────────────────────────────────────────────

describe('useReportEngine — edge cases', () => {
  it('handles single row', () => {
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows: [{ x: 1 }],
        columns: ['x'],
      })),
    );
    expect(result.current.bandedRows).toHaveLength(1);
    expect(result.current.bandedRows[0].x).toBe(1);
  });

  it('handles rows with null values', () => {
    const rows = [
      { region: 'East', amount: null },
      { region: 'West', amount: 100 },
    ];
    const { result } = renderHook(() =>
      useReportEngine(makeInput({
        rows,
        columns: ['region', 'amount'],
        measureColumns: ['amount'],
      })),
    );
    // Grand total should handle null gracefully
    expect(result.current.grandTotals.amount).toBe(100);
  });
});
