/**
 * Hook that manages open/close state for all query builder modal dialogs.
 * Extracted from CompleteQueryBuilder to reduce useState noise.
 */
import { Dispatch, SetStateAction, useState } from 'react';

export interface QueryBuilderModals {
  showTableSelector: boolean;
  setShowTableSelector: Dispatch<SetStateAction<boolean>>;
  showJoinBuilder: boolean;
  setShowJoinBuilder: Dispatch<SetStateAction<boolean>>;
  showColumnSelector: boolean;
  setShowColumnSelector: Dispatch<SetStateAction<boolean>>;
  showFilterBuilder: boolean;
  setShowFilterBuilder: Dispatch<SetStateAction<boolean>>;
  showSaveDialog: boolean;
  setShowSaveDialog: Dispatch<SetStateAction<boolean>>;
  showAggBuilder: boolean;
  setShowAggBuilder: Dispatch<SetStateAction<boolean>>;
  showHavingBuilder: boolean;
  setShowHavingBuilder: Dispatch<SetStateAction<boolean>>;
  showComputedBuilder: boolean;
  setShowComputedBuilder: Dispatch<SetStateAction<boolean>>;
  showCaseBuilder: boolean;
  setShowCaseBuilder: Dispatch<SetStateAction<boolean>>;
  showWindowBuilder: boolean;
  setShowWindowBuilder: Dispatch<SetStateAction<boolean>>;
  showPreview: boolean;
  setShowPreview: Dispatch<SetStateAction<boolean>>;
}

const useQueryBuilderModals = (): QueryBuilderModals => {
  const [showTableSelector, setShowTableSelector] = useState(false);
  const [showJoinBuilder, setShowJoinBuilder] = useState(false);
  const [showColumnSelector, setShowColumnSelector] = useState(false);
  const [showFilterBuilder, setShowFilterBuilder] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showAggBuilder, setShowAggBuilder] = useState(false);
  const [showHavingBuilder, setShowHavingBuilder] = useState(false);
  const [showComputedBuilder, setShowComputedBuilder] = useState(false);
  const [showCaseBuilder, setShowCaseBuilder] = useState(false);
  const [showWindowBuilder, setShowWindowBuilder] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  return {
    showTableSelector, setShowTableSelector,
    showJoinBuilder, setShowJoinBuilder,
    showColumnSelector, setShowColumnSelector,
    showFilterBuilder, setShowFilterBuilder,
    showSaveDialog, setShowSaveDialog,
    showAggBuilder, setShowAggBuilder,
    showHavingBuilder, setShowHavingBuilder,
    showComputedBuilder, setShowComputedBuilder,
    showCaseBuilder, setShowCaseBuilder,
    showWindowBuilder, setShowWindowBuilder,
    showPreview, setShowPreview,
  };
};

export default useQueryBuilderModals;
