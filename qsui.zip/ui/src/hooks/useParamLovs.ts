/**
 * Shared hook for loading parameter LOV (List of Values) for business/pivot reports.
 * Supports parallel independent loading + sequential cascade loading.
 * Extracted from BusinessReportViewer for reuse in PivotReportViewer.
 */
import { useState, useEffect, useRef } from 'react';
import api from '../services/api';

/** Function signature for fetching parameter LOV values. */
export type ParamLovFetchFn = (body: { parameter_id: number; parent_values: Record<string, any> }) => Promise<{ values?: string[] }>;

export interface UseParamLovsOptions {
  reportId: number;
  parameters: any[] | undefined;
  paramValues: Record<string, any>;
  /** Optional custom fetch function (e.g. for shared/embedded token-based endpoints). */
  fetchFn?: ParamLovFetchFn;
}

export function useParamLovs({ reportId, parameters, paramValues, fetchFn }: UseParamLovsOptions) {
  const [paramLovs, setParamLovs] = useState<Record<number, string[]>>({});
  const prevParentValsRef = useRef<Record<string, any>>({});
  const lovsLoadedRef = useRef(false);
  const prevReportIdRef = useRef<number>(reportId);

  // Reset refs when reportId changes (e.g., navigating between reports)
  useEffect(() => {
    if (prevReportIdRef.current !== reportId) {
      lovsLoadedRef.current = false;
      prevParentValsRef.current = {};
      setParamLovs({});
      prevReportIdRef.current = reportId;
    }
  }, [reportId]);

  useEffect(() => {
    if (!parameters) return;
    const params = parameters as any[];
    let cancelled = false;

    // Build a map of param_id → parent param name (for cascade tracking)
    const parentNameMap: Record<number, string> = {};
    for (const p of params) {
      if (p.depends_on_param_id) {
        const parent = params.find((pp: any) => pp.id === p.depends_on_param_id);
        if (parent) parentNameMap[p.id] = parent.name;
      }
    }

    // Determine which params need LOV refresh
    const toFetch: any[] = [];
    for (const p of params) {
      if (!['dropdown', 'multi_select'].includes(p.parameter_type) || !p.lov_column_id) continue;
      const parentName = parentNameMap[p.id];
      if (!lovsLoadedRef.current) {
        toFetch.push(p);
      } else if (parentName) {
        const curVal = JSON.stringify(paramValues[parentName] ?? '');
        const prevVal = JSON.stringify(prevParentValsRef.current[parentName] ?? '');
        if (curVal !== prevVal) toFetch.push(p);
      }
    }

    if (toFetch.length === 0 && lovsLoadedRef.current) {
      const snap: Record<string, any> = {};
      for (const pn of Object.values(parentNameMap)) snap[pn] = paramValues[pn];
      prevParentValsRef.current = snap;
      return;
    }

    const loadLovs = async () => {
      const independent = toFetch.filter(p => !parentNameMap[p.id]);
      const cascade = toFetch.filter(p => !!parentNameMap[p.id]);
      const doFetch = fetchFn || ((body: any) => api.getBusinessReportParamValues(reportId, body));

      // Load independent params in parallel
      if (independent.length > 0) {
        const results = await Promise.allSettled(
          independent.map(p =>
            doFetch({ parameter_id: p.id, parent_values: {} })
              .then(res => ({ id: p.id, values: res.values || [] }))
          )
        );
        if (cancelled) return;
        for (let i = 0; i < results.length; i++) {
          const r = results[i];
          if (r.status === 'fulfilled') {
            setParamLovs(prev => ({ ...prev, [r.value.id]: r.value.values }));
          } else {
            setParamLovs(prev => ({ ...prev, [independent[i].id]: ['(failed to load)'] }));
          }
        }
      }

      // Load cascade params sequentially (order matters for chained cascades)
      for (const p of cascade) {
        if (cancelled) return;
        try {
          const parentValues: Record<string, any> = {};
          const parentName = parentNameMap[p.id];
          if (parentName) parentValues[parentName] = paramValues[parentName];
          const res = await doFetch({
            parameter_id: p.id,
            parent_values: parentValues,
          });
          if (cancelled) return;
          setParamLovs(prev => ({ ...prev, [p.id]: res.values || [] }));
        } catch {
          if (cancelled) return;
          setParamLovs(prev => ({ ...prev, [p.id]: prev[p.id] || ['(failed to load)'] }));
        }
      }

      lovsLoadedRef.current = true;
      const snap: Record<string, any> = {};
      for (const pn of Object.values(parentNameMap)) snap[pn] = paramValues[pn];
      prevParentValsRef.current = snap;
    };
    loadLovs();

    return () => { cancelled = true; };
  }, [parameters, paramValues, reportId, fetchFn]);

  return paramLovs;
}

export default useParamLovs;
