/**
 * useServerDraft — Phase 142 — Enterprise context preservation.
 *
 * Replaces ALL per-component localStorage patches in the product with
 * a single coherent server-side draft store.  Drafts persist in the
 * QueryStudio DB tied to the user — they survive refresh, browser
 * close, laptop switch, cookie clear, pod restart.
 *
 * Drop-in shape:
 *
 *   const [sql, setSql, { loading, reset }] =
 *     useServerDraft<string>('cqb.sql.' + connId, '');
 *
 * Behaviour:
 *   - GET /api/user/drafts/{key} on mount → fills initial state from server
 *   - PUT /api/user/drafts/{key} on every change (debounced 2s) → persists
 *   - Falls back to in-memory-only if the API is unreachable (graceful
 *     degradation; user can still type, just doesn't survive refresh)
 *   - Cross-tab live sync is NOT implemented (Phase 144) — each tab
 *     keeps its own state; refresh to see updates from another tab.
 *
 * Key naming convention (frontend-owned, but please keep stable across
 * releases so users don't lose drafts after a deploy):
 *
 *   cqb.sql.<connId>                — CQB raw SQL
 *   sqlpage.primary.<connId>        — SqlQueryPage primary SQL
 *   sqlpage.secondary.<connId>      — SqlQueryPage secondary SQL
 *   bqb.<connId>                    — BusinessQueryBuilder full state
 *   dashboard.<dashboardId>         — DashboardEditor draft
 *   report.<reportId>               — BusinessReportEditor draft
 *   pivot.<reportId>                — PivotReportEditor draft
 *   fed.<viewId>                    — FederationViewEditor draft
 *   pv.<viewId>                     — PublishedViewEditor draft
 *   schedule.<scheduleId>           — ScheduleEditor draft
 *   conn.new                        — ConnectionManager new-connection form
 *   nl.assistant                    — NL chatbot panel history
 *   admin.<sectionId>               — Admin form drafts (e.g. admin.app-config)
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { safeFetch } from '../services/api/core';
import { safeStringify } from '../utils/safeStringify';

export interface UseServerDraftOptions {
  /** Debounce ms before sending the PUT.  Default 2000 (industry standard). */
  debounceMs?: number;
  /** Skip persistence entirely — useful for tests / SSR. */
  disabled?: boolean;
  /** Called once after the initial GET completes (success or 404). */
  onLoad?: (loaded: boolean) => void;
}

export interface UseServerDraftMeta {
  loading: boolean;
  reset: () => void;
  /** Manually force a save now (bypass debounce).  Useful before navigating. */
  flush: () => Promise<void>;
}

const _DEFAULT_DEBOUNCE = 2000;

export function useServerDraft<T>(
  key: string,
  fallback: T,
  options: UseServerDraftOptions = {},
): [T, React.Dispatch<React.SetStateAction<T>>, UseServerDraftMeta] {
  const debounceMs = options.debounceMs ?? _DEFAULT_DEBOUNCE;
  const disabled = !!options.disabled;

  // Always start with the fallback — we'll overwrite from the server
  // in the mount effect below.  This avoids a flash of "empty" before
  // the server response arrives.
  const [value, _setValueRaw] = useState<T>(fallback);
  const [loading, setLoading] = useState<boolean>(!disabled);
  const writeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The initial load must not trigger a save (it overwrites with what the
  // server already has — no point round-tripping).
  const isFirstWriteRef = useRef(true);
  // Bug-fix: track whether the user has modified state BEFORE the server
  // GET resolved.  If they have, the late server response must NOT
  // overwrite their typing.  This prevents the race where slow GET +
  // fast typing → typed text vanishes when the server response lands.
  const userModifiedBeforeLoadRef = useRef(false);
  const latestValueRef = useRef<T>(value);
  latestValueRef.current = value;

  // Wrapped setter — every external call goes through here so we can
  // observe user-initiated changes during the loading window.
  const setValue = useCallback<React.Dispatch<React.SetStateAction<T>>>((updater) => {
    if (loading) userModifiedBeforeLoadRef.current = true;
    _setValueRaw(updater);
  }, [loading]);

  // ── Mount: load from server ───────────────────────────────────────────
  useEffect(() => {
    if (disabled) {
      setLoading(false);
      return;
    }
    // Reset the user-modified flag for each fresh key change
    userModifiedBeforeLoadRef.current = false;
    // BQB-FIX: drop the stale value the moment the key changes.  Without
    // this, a user who switches connection (or any other input that flips
    // the draft key) sees the PREVIOUS key's content for the duration of
    // the GET — and, on a 404 for the new key, sees it forever, because
    // the catch path below never overwrites.  Reset to fallback now;
    // the GET will optionally hydrate from the server when it lands.
    _setValueRaw(fallback);
    setLoading(true);
    isFirstWriteRef.current = true;
    let cancelled = false;
    (async () => {
      try {
        const data = await safeFetch(
          `/api/user/drafts/${encodeURIComponent(key)}`,
        );
        if (cancelled) return;
        // Apply server value ONLY if the user hasn't typed yet.  If they
        // have, their in-progress edits win — server response is dropped.
        if (data && data.content !== undefined && !userModifiedBeforeLoadRef.current) {
          _setValueRaw(data.content as T);
        }
        options.onLoad?.(true);
      } catch (exc: any) {
        // 404 is the expected case for a new draft — silently fall through
        // with the fallback.  Network errors also silent-fall-through so
        // the user can keep working in-memory.
        if (cancelled) return;
        options.onLoad?.(false);
      } finally {
        if (!cancelled) {
          // The first state set from the server load shouldn't trigger
          // a save back to the server.  Mark loading complete AFTER
          // we set isFirstWrite so the next user-initiated change saves.
          setLoading(false);
          isFirstWriteRef.current = false;
        }
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, disabled]);

  // ── On value change: debounced PUT ───────────────────────────────────
  //
  // Bug-fix: track the (key, value) pair the PENDING timer would PUT.
  // When the effect re-runs due to KEY CHANGE (e.g. user switched
  // connections in CQB before the 2s debounce fired), flush the pending
  // write to the OLD key BEFORE the new key takes over.  Without this,
  // typed-but-not-yet-saved text was silently lost on connection switch.
  const pendingWriteRef = useRef<{ key: string; value: T } | null>(null);
  useEffect(() => {
    if (disabled) return;
    if (loading) return;                // mid-load — don't bounce back
    if (isFirstWriteRef.current) {
      isFirstWriteRef.current = false;
      return;
    }
    if (writeTimerRef.current) clearTimeout(writeTimerRef.current);
    pendingWriteRef.current = { key, value };
    writeTimerRef.current = setTimeout(() => {
      _putDraft(key, value).catch(() => {
        // Already silent — safeFetch will surface real errors via banner
      });
      pendingWriteRef.current = null;
    }, debounceMs);
    return () => {
      if (writeTimerRef.current) {
        clearTimeout(writeTimerRef.current);
        writeTimerRef.current = null;
      }
      // If a pending write was scheduled for the OLD key and the effect is
      // re-running because the key changed (or component is unmounting),
      // FLUSH the pending write now so typed text isn't lost.
      const pending = pendingWriteRef.current;
      if (pending) {
        _putDraft(pending.key, pending.value).catch(() => {});
        pendingWriteRef.current = null;
      }
    };
  }, [key, value, disabled, debounceMs, loading]);

  // Cross-tab sync: we DON'T listen to localStorage 'storage' events
  // because drafts are server-backed.  Cross-tab live sync would require
  // a WebSocket push from the backend whenever a user's draft updates
  // from another tab — that's Phase 144 work.  For now: refresh the
  // other tab to see updates (or wait for the 2s debounce + the other
  // tab's next mount-load).

  // ── Flush + reset helpers ────────────────────────────────────────────
  const flush = useCallback(async () => {
    if (disabled) return;
    if (writeTimerRef.current) {
      clearTimeout(writeTimerRef.current);
      writeTimerRef.current = null;
    }
    await _putDraft(key, latestValueRef.current);
  }, [key, disabled]);

  const reset = useCallback(() => {
    setValue(fallback);
    if (disabled) return;
    safeFetch(`/api/user/drafts/${encodeURIComponent(key)}`,
                { method: 'DELETE' }).catch(() => {});
  }, [key, fallback, disabled]);

  return [value, setValue, { loading, reset, flush }];
}


async function _putDraft<T>(key: string, value: T): Promise<void> {
  // BF-427: safeStringify defends every useServerDraft consumer (CQB tab
  // snapshots, BQB drafts, raw SQL editors) against state pollution by a
  // misrouted setter — would otherwise crash the autosave AND corrupt the
  // server draft so the next page load would re-crash on restore.
  await safeFetch(`/api/user/drafts/${encodeURIComponent(key)}`, {
    method: 'PUT',
    body: safeStringify({ content: value }),
  });
}


/**
 * useBeforeUnloadGuard — show OS-native "Leave site?" prompt when there
 * is unsaved state that hasn't been flushed yet.  Pairs with useServerDraft's
 * flush() to guarantee no work is lost on browser close.
 */
export function useBeforeUnloadGuard(
  isDirty: () => boolean,
  flushAll: () => Promise<void>,
): void {
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!isDirty()) return undefined;
      // Best-effort: kick off the flush.  Browsers don't actually wait
      // for the Promise, but most modern Node clients (Chrome) do honour
      // the sync XHR / sendBeacon style.  We use safeFetch's PUT which
      // is async — the prompt at least gives the user a chance to choose.
      flushAll().catch(() => {});
      e.preventDefault();
      e.returnValue = 'You have unsaved work. Are you sure you want to leave?';
      return e.returnValue;
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [isDirty, flushAll]);
}
