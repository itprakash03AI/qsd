/**
 * Phase 56+113 — Client-side Report Engine Hook
 *
 * Takes raw result rows + report definition and produces:
 * - Banded rows (section headers, data rows, subtotal rows, grand totals)
 *   → Multi-level section breaks (Region → Store → nested subtotals)
 * - Running calculations (RunningSum, Rank, PercentOfTotal, PreviousValue)
 *   → Partition-aware: resets per section/partition column
 * - Slicer filtering (client-side cross-filter)
 * - Drill grouping (client-side GROUP BY + aggregation per hierarchy level)
 *   → Supports SUM, AVG, COUNT, MIN, MAX, COUNT_DISTINCT
 * - Client-side sorting (section-aware: sorts within sections, not across)
 */
import { useMemo } from 'react';

// ── Types ────────────────────────────────────────────────────────────────────

export type AggregationType = 'sum' | 'avg' | 'count' | 'min' | 'max' | 'count_distinct';

export interface SectionDef {
  name: string;
  break_column_id: number;
  break_column_name: string;   // resolved physical/friendly name
  subtotal_measure_ids: number[];
  subtotal_measure_names: string[];  // resolved names
  show_count?: boolean;
}

export interface RunningCalcDef {
  name: string;
  calc_type: 'running_sum' | 'rank' | 'percent_of_total' | 'previous_value';
  measure_col_name: string;    // column to compute on
  partition_col_name?: string; // partition by this column (optional)
  format_pattern?: string;
}

export interface DrillState {
  level: number;
  filters: Array<{ column: string; value: any }>;
  hierarchy_levels?: Array<{ column_name: string; label: string }>;
}

export type BandedRowType = 'header' | 'data' | 'subtotal' | 'grand_total';

export interface BandedRow {
  _rowType: BandedRowType;
  _sectionValue?: string;
  _sectionCount?: number;
  _sectionLevel?: number;     // nesting depth for multi-level breaks
  [key: string]: any;
}

/** Per-measure aggregation override for drill grouping */
export interface MeasureAggConfig {
  column: string;
  aggregation: AggregationType;
}

export interface ReportEngineInput {
  rows: any[];
  columns: string[];
  sectionDefs: SectionDef[];
  runningCalcs: RunningCalcDef[];
  slicerValues: Record<string, any[]>;  // columnName → selected values
  drillState: DrillState;
  // Client-side drill grouping
  drillHierarchyLevels?: Array<{ column_name: string; label: string }>;
  measureColumns?: string[];    // physical names of measure/kpi columns
  measureAggConfigs?: MeasureAggConfig[];  // per-measure aggregation overrides
  expandedLevels?: number;      // additional hierarchy levels to expand alongside current
  // Client-side sorting
  sortColumn?: string;
  sortDirection?: 'asc' | 'desc' | null;
}

export interface ReportEngineOutput {
  bandedRows: BandedRow[];
  calculatedColumns: string[];
  grandTotals: Record<string, number>;
  slicerOptions: Record<string, string[]>;
  drillBreadcrumb: string[];
  activeColumns: string[];    // columns to display (may differ during drill grouping)
  totalRowCount: number;      // total data rows before banding (for client-side pagination)
}

// ── Aggregation helpers ─────────────────────────────────────────────────────

function aggregateValues(
  rows: any[],
  column: string,
  aggType: AggregationType,
): number {
  // count_distinct works on raw values (including strings), not Number-coerced
  if (aggType === 'count_distinct') {
    const s = new Set<any>();
    for (const r of rows) {
      const v = r[column];
      if (v != null && v !== '') s.add(v);
    }
    return s.size;
  }
  const nums: number[] = [];
  for (const r of rows) {
    const v = Number(r[column]);
    if (!isNaN(v)) nums.push(v);
  }
  if (nums.length === 0) return 0;
  switch (aggType) {
    case 'sum':
      return nums.reduce((a, b) => a + b, 0);
    case 'avg':
      return nums.reduce((a, b) => a + b, 0) / nums.length;
    case 'count':
      return nums.length;
    case 'min':
      return nums.reduce((a, b) => Math.min(a, b), Infinity);
    case 'max':
      return nums.reduce((a, b) => Math.max(a, b), -Infinity);
    default:
      return nums.reduce((a, b) => a + b, 0);
  }
}

/** Get aggregation type for a measure column from configs (default: sum) */
function getAggType(
  column: string,
  configs?: MeasureAggConfig[],
): AggregationType {
  if (!configs) return 'sum';
  const cfg = configs.find(c => c.column === column);
  return cfg?.aggregation || 'sum';
}

// ── Computation helpers ──────────────────────────────────────────────────────

function applySlicerFilters(rows: any[], slicerValues: Record<string, any[]>): any[] {
  let filtered = rows;
  for (const [col, vals] of Object.entries(slicerValues)) {
    if (vals && vals.length > 0) {
      const valSet = new Set(vals.map(String));
      filtered = filtered.filter(r => valSet.has(String(r[col])));
    }
  }
  return filtered;
}

function applyDrillFilters(rows: any[], drillState: DrillState): any[] {
  let filtered = rows;
  for (const df of drillState.filters) {
    filtered = filtered.filter(r => String(r[df.column]) === String(df.value));
  }
  return filtered;
}

function extractSlicerOptions(rows: any[], slicerColumns: string[]): Record<string, string[]> {
  // Single-pass extraction for all slicer columns
  const sets: Record<string, Set<string>> = {};
  for (const col of slicerColumns) sets[col] = new Set();
  for (const r of rows) {
    for (const col of slicerColumns) {
      if (r[col] != null) sets[col].add(String(r[col]));
    }
  }
  const opts: Record<string, string[]> = {};
  for (const col of slicerColumns) {
    opts[col] = Array.from(sets[col]).sort();
  }
  return opts;
}

function computeGrandTotals(
  rows: any[],
  measureNames: string[],
  measureAggConfigs?: MeasureAggConfig[],
): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const m of measureNames) {
    totals[m] = aggregateValues(rows, m, getAggType(m, measureAggConfigs));
  }
  return totals;
}

// ── Multi-level section banding ─────────────────────────────────────────────

function buildBandedRows(
  rows: any[],
  sectionDefs: SectionDef[],
  grandTotals: Record<string, number>,
  measureAggConfigs?: MeasureAggConfig[],
): BandedRow[] {
  if (sectionDefs.length === 0) {
    // No sections — just wrap as data rows + grand total
    const banded: BandedRow[] = rows.map(r => ({ ...r, _rowType: 'data' as BandedRowType }));
    if (Object.keys(grandTotals).length > 0) {
      const gt: BandedRow = { _rowType: 'grand_total' };
      for (const [k, v] of Object.entries(grandTotals)) gt[k] = v;
      banded.push(gt);
    }
    return banded;
  }

  // Recursive multi-level section break
  return buildSectionLevel(rows, sectionDefs, 0, grandTotals, measureAggConfigs);
}

function buildSectionLevel(
  rows: any[],
  sectionDefs: SectionDef[],
  level: number,
  grandTotals: Record<string, number>,
  measureAggConfigs?: MeasureAggConfig[],
): BandedRow[] {
  const def = sectionDefs[level];
  const breakCol = def.break_column_name;
  const isLastLevel = level >= sectionDefs.length - 1;

  // Sort by break column
  const sorted = [...rows].sort((a, b) => {
    const va = a[breakCol] ?? '';
    const vb = b[breakCol] ?? '';
    return String(va).localeCompare(String(vb));
  });

  // Group by break column value
  const groups: Array<{ value: any; rows: any[] }> = [];
  let currentVal: any = undefined;
  let currentRows: any[] = [];
  for (const row of sorted) {
    const val = row[breakCol];
    if (val !== currentVal && currentRows.length > 0) {
      groups.push({ value: currentVal, rows: currentRows });
      currentRows = [];
    }
    currentVal = val;
    currentRows.push(row);
  }
  if (currentRows.length > 0) {
    groups.push({ value: currentVal, rows: currentRows });
  }

  const banded: BandedRow[] = [];
  for (const group of groups) {
    // Section header
    banded.push({
      _rowType: 'header',
      _sectionValue: String(group.value),
      _sectionCount: group.rows.length,
      _sectionLevel: level,
    });

    if (isLastLevel) {
      // Leaf level — emit data rows
      for (const r of group.rows) {
        banded.push({ ...r, _rowType: 'data' });
      }
    } else {
      // Recurse into next section level
      const childBanded = buildSectionLevel(
        group.rows, sectionDefs, level + 1, grandTotals, measureAggConfigs,
      );
      banded.push(...childBanded);
    }

    // Subtotal row for this level
    const subtotal: BandedRow = {
      _rowType: 'subtotal',
      _sectionValue: String(group.value),
      _sectionLevel: level,
    };
    for (const mName of def.subtotal_measure_names) {
      const aggType = getAggType(mName, measureAggConfigs);
      subtotal[mName] = aggregateValues(group.rows, mName, aggType);
    }
    if (def.show_count) {
      subtotal['_count'] = group.rows.length;
    }
    banded.push(subtotal);
  }

  // Grand total only at the outermost level
  if (level === 0 && Object.keys(grandTotals).length > 0) {
    const gt: BandedRow = { _rowType: 'grand_total' };
    for (const [k, v] of Object.entries(grandTotals)) gt[k] = v;
    banded.push(gt);
  }

  return banded;
}

// ── Partition-aware running calculations ────────────────────────────────────

function applyRunningCalculations(
  bandedRows: BandedRow[],
  runningCalcs: RunningCalcDef[],
  grandTotals: Record<string, number>,
): { rows: BandedRow[]; calculatedColumns: string[] } {
  if (runningCalcs.length === 0) return { rows: bandedRows, calculatedColumns: [] };

  const calcCols: string[] = [];
  const result = bandedRows.map(r => ({ ...r }));

  for (const calc of runningCalcs) {
    const colName = calc.name;
    calcCols.push(colName);
    const partCol = calc.partition_col_name;

    if (calc.calc_type === 'running_sum') {
      // Partition-aware: reset cumulative sum when partition value changes
      const cumSums: Record<string, number> = {};
      for (const r of result) {
        if (r._rowType !== 'data') continue;
        const partKey = partCol ? String(r[partCol] ?? '__all__') : '__all__';
        if (!(partKey in cumSums)) cumSums[partKey] = 0;
        const v = Number(r[calc.measure_col_name]);
        if (!isNaN(v)) cumSums[partKey] += v;
        r[colName] = cumSums[partKey];
      }
    } else if (calc.calc_type === 'rank') {
      // Partition-aware dense rank (descending)
      const dataRows = result.filter(r => r._rowType === 'data');
      if (partCol) {
        // Group by partition, rank within each group
        const partGroups = new Map<string, BandedRow[]>();
        for (const r of dataRows) {
          const pk = String(r[partCol] ?? '__all__');
          if (!partGroups.has(pk)) partGroups.set(pk, []);
          partGroups.get(pk)!.push(r);
        }
        for (const group of partGroups.values()) {
          const sorted = [...group].sort((a, b) => {
            return (Number(b[calc.measure_col_name]) || 0) - (Number(a[calc.measure_col_name]) || 0);
          });
          let rank = 0;
          let prevVal: number | null = null;
          for (const r of sorted) {
            const v = Number(r[calc.measure_col_name]) || 0;
            if (v !== prevVal) { rank++; prevVal = v; }
            r[colName] = rank;
          }
        }
      } else {
        // Global rank
        const sorted = [...dataRows].sort((a, b) => {
          return (Number(b[calc.measure_col_name]) || 0) - (Number(a[calc.measure_col_name]) || 0);
        });
        let rank = 0;
        let prevVal: number | null = null;
        const rankMap = new Map<any, number>();
        for (const r of sorted) {
          const v = Number(r[calc.measure_col_name]) || 0;
          if (v !== prevVal) { rank++; prevVal = v; }
          rankMap.set(r, rank);
        }
        for (const r of result) {
          if (r._rowType === 'data') r[colName] = rankMap.get(r) ?? null;
        }
      }
    } else if (calc.calc_type === 'percent_of_total') {
      // Partition-aware: % of partition total (or grand total if no partition)
      if (partCol) {
        // Compute partition totals first
        const partTotals = new Map<string, number>();
        for (const r of result) {
          if (r._rowType !== 'data') continue;
          const pk = String(r[partCol] ?? '__all__');
          const v = Number(r[calc.measure_col_name]) || 0;
          partTotals.set(pk, (partTotals.get(pk) || 0) + v);
        }
        for (const r of result) {
          if (r._rowType !== 'data') continue;
          const pk = String(r[partCol] ?? '__all__');
          const total = partTotals.get(pk) || 0;
          const v = Number(r[calc.measure_col_name]) || 0;
          r[colName] = total > 0 ? Math.round((v / total) * 10000) / 100 : 0;
        }
      } else {
        // Always use sum for percent_of_total denominator (not the configured agg type)
        let total = 0;
        for (const r of result) {
          if (r._rowType !== 'data') continue;
          total += Number(r[calc.measure_col_name]) || 0;
        }
        for (const r of result) {
          if (r._rowType !== 'data') continue;
          const v = Number(r[calc.measure_col_name]) || 0;
          r[colName] = total > 0 ? Math.round((v / total) * 10000) / 100 : 0;
        }
      }
    } else if (calc.calc_type === 'previous_value') {
      // Partition-aware: previous value resets per partition
      const prevMap: Record<string, number | null> = {};
      for (const r of result) {
        if (r._rowType !== 'data') continue;
        const pk = partCol ? String(r[partCol] ?? '__all__') : '__all__';
        r[colName] = pk in prevMap ? prevMap[pk] : null;
        prevMap[pk] = Number(r[calc.measure_col_name]) || 0;
      }
    }
  }

  return { rows: result, calculatedColumns: calcCols };
}

// ── Drill grouping (client-side GROUP BY for hierarchy levels) ───────────────

function groupByDrillLevel(
  rows: any[],
  hierarchyLevels: Array<{ column_name: string; label: string }>,
  measureColumns: string[],
  measureAggConfigs: MeasureAggConfig[] | undefined,
  drillLevel: number,
  expandedLevels: number,
  allColumns: string[],
): { groupedRows: any[]; activeColumns: string[] } {
  if (hierarchyLevels.length === 0 || drillLevel >= hierarchyLevels.length) {
    return { groupedRows: rows, activeColumns: allColumns };
  }

  const endLevel = Math.min(drillLevel + expandedLevels, hierarchyLevels.length - 1);
  const dimColumns: string[] = [];
  for (let i = drillLevel; i <= endLevel; i++) {
    dimColumns.push(hierarchyLevels[i].column_name);
  }

  // Expanded to deepest level → show detail rows with all columns
  if (endLevel >= hierarchyLevels.length - 1) {
    return { groupedRows: rows, activeColumns: allColumns };
  }

  // GROUP BY dimColumns, aggregate measureColumns using per-measure agg type
  const groups = new Map<string, { row: any; sourceRows: any[] }>();
  for (const row of rows) {
    const key = dimColumns.map(d => String(row[d] ?? '')).join('\x00');
    if (!groups.has(key)) {
      const grouped: any = {};
      for (const d of dimColumns) grouped[d] = row[d];
      for (const m of measureColumns) grouped[m] = 0;
      grouped['_group_count'] = 0;
      groups.set(key, { row: grouped, sourceRows: [] });
    }
    groups.get(key)!.sourceRows.push(row);
  }

  // Apply proper aggregation per measure
  const groupedRows: any[] = [];
  for (const { row, sourceRows } of groups.values()) {
    for (const m of measureColumns) {
      row[m] = aggregateValues(sourceRows, m, getAggType(m, measureAggConfigs));
    }
    row['_group_count'] = sourceRows.length;
    groupedRows.push(row);
  }

  return {
    groupedRows,
    activeColumns: [...dimColumns, ...measureColumns],
  };
}

// ── Client-side sorting (section-aware) ──────────────────────────────────────

/** Create a comparator for sorting rows by a given column + direction */
function createComparator(
  col: string,
  dir: 'asc' | 'desc',
): (a: any, b: any) => number {
  return (a, b) => {
    const va = a[col];
    const vb = b[col];
    if (va == null && vb == null) return 0;
    if (va == null) return 1;
    if (vb == null) return -1;
    if (typeof va === 'number' && typeof vb === 'number') {
      return dir === 'asc' ? va - vb : vb - va;
    }
    const cmp = String(va).localeCompare(String(vb));
    return dir === 'asc' ? cmp : -cmp;
  };
}

function applySorting(
  rows: any[],
  sortColumn: string | undefined,
  sortDirection: 'asc' | 'desc' | null | undefined,
): any[] {
  if (!sortColumn || !sortDirection) return rows;
  return [...rows].sort(createComparator(sortColumn, sortDirection));
}

/** Sort banded rows within sections (preserves section structure) */
function applySortingWithinSections(
  bandedRows: BandedRow[],
  sortColumn: string | undefined,
  sortDirection: 'asc' | 'desc' | null | undefined,
): BandedRow[] {
  if (!sortColumn || !sortDirection) return bandedRows;
  const cmp = createComparator(sortColumn, sortDirection);

  // Split into segments: [header?, data*, subtotal?, ...]
  const result: BandedRow[] = [];
  let currentDataBlock: BandedRow[] = [];

  const flushDataBlock = () => {
    if (currentDataBlock.length > 0) {
      currentDataBlock.sort(cmp);
      result.push(...currentDataBlock);
      currentDataBlock = [];
    }
  };

  for (const row of bandedRows) {
    if (row._rowType === 'data') {
      currentDataBlock.push(row);
    } else {
      flushDataBlock();
      result.push(row);
    }
  }
  flushDataBlock();
  return result;
}

// ── Main hook ────────────────────────────────────────────────────────────────

export function useReportEngine(input: ReportEngineInput): ReportEngineOutput {
  return useMemo(() => {
    const {
      rows, columns, sectionDefs, runningCalcs, slicerValues, drillState,
      drillHierarchyLevels, measureColumns, measureAggConfigs, expandedLevels,
      sortColumn, sortDirection,
    } = input;

    if (!rows || rows.length === 0) {
      return {
        bandedRows: [],
        calculatedColumns: [],
        grandTotals: {},
        slicerOptions: {},
        drillBreadcrumb: [],
        activeColumns: columns || [],
        totalRowCount: 0,
      };
    }

    // 1. Drill filter (filter by clicked dimension values)
    const drilled = applyDrillFilters(rows, drillState);

    // 2. Slicer filter
    const filtered = applySlicerFilters(drilled, slicerValues);

    // 3. Extract slicer options (from drilled but not slicer-filtered — so other slicers show all options)
    const slicerCols = Object.keys(slicerValues);
    const slicerOptions = extractSlicerOptions(drilled, slicerCols);

    // 4. Client-side drill grouping (GROUP BY hierarchy dims + proper aggregation)
    const { groupedRows, activeColumns: activeCols } = groupByDrillLevel(
      filtered,
      drillHierarchyLevels || [],
      measureColumns || [],
      measureAggConfigs,
      drillState.level,
      expandedLevels || 0,
      columns,
    );

    // 5. Pre-section sort (for non-sectioned reports)
    const preSorted = sectionDefs.length === 0
      ? applySorting(groupedRows, sortColumn, sortDirection)
      : groupedRows;

    const totalRowCount = preSorted.length;

    // 6. Compute grand totals from all measure columns
    const measureNames = new Set<string>();
    for (const s of sectionDefs) {
      for (const mn of s.subtotal_measure_names) measureNames.add(mn);
    }
    for (const rc of runningCalcs) {
      measureNames.add(rc.measure_col_name);
    }
    for (const mc of (measureColumns || [])) {
      measureNames.add(mc);
    }
    const grandTotals = computeGrandTotals(
      preSorted, Array.from(measureNames), measureAggConfigs,
    );

    // 7. Build banded rows (multi-level section breaks)
    const banded = buildBandedRows(preSorted, sectionDefs, grandTotals, measureAggConfigs);

    // 8. Apply within-section sorting (preserves section structure)
    const sortedBanded = sectionDefs.length > 0
      ? applySortingWithinSections(banded, sortColumn, sortDirection)
      : banded;

    // 9. Apply running calculations (partition-aware)
    const { rows: finalRows, calculatedColumns } = applyRunningCalculations(
      sortedBanded, runningCalcs, grandTotals,
    );

    // 10. Drill breadcrumb
    const drillBreadcrumb = drillState.filters.map(
      f => `${f.column}: ${f.value}`
    );

    return {
      bandedRows: finalRows,
      calculatedColumns,
      grandTotals,
      slicerOptions,
      drillBreadcrumb,
      activeColumns: activeCols,
      totalRowCount,
    };
  }, [
    input.rows, input.columns, input.sectionDefs, input.runningCalcs,
    input.slicerValues, input.drillState,
    input.drillHierarchyLevels, input.measureColumns, input.measureAggConfigs,
    input.expandedLevels, input.sortColumn, input.sortDirection,
  ]);
}

export default useReportEngine;
