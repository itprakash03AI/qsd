import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// 2026-06-17 — Runtime config strategy.
//
// PRIMARY (synchronous): index.html loads /config.js via a regular
// <script> tag BEFORE this module evaluates.  config.js sets
// window.APP_CONFIG synchronously.  When main.tsx runs (and every
// downstream module like services/api/core.ts), window.APP_CONFIG is
// guaranteed to be set.
//
// FALLBACK (async, backward-compat): if config.js failed to load — for
// example because the deploy environment is still serving the legacy
// /config.json — we attempt a content-type-guarded fetch as a one-shot
// rescue.  The content-type check prevents the historical failure mode
// where a static-server SPA catch-all returned <!doctype html>... and
// JSON.parse threw a confusing "Unexpected token '<'" error.
//
// In ANY failure scenario, window.APP_CONFIG falls back to an empty
// apiUrl (same-origin fetches), and a console warning explains why.
//
// Why not just keep the old async-fetch bootstrap?
//   - Async fetch raced against ES-module pre-evaluation by the browser.
//   - SPA catch-all returning HTML caused silent fallback to empty URL
//     (a bug that only surfaced as "Unexpected token '<'" much later).
//   - Helm ConfigMap mounting works identically for .js vs .json files,
//     so deploying the synchronous variant has zero infra cost.

declare global {
  interface Window {
    APP_CONFIG?: { apiUrl?: string; publishedApiUrl?: string };
  }
}

async function ensureAppConfig(): Promise<void> {
  if (window.APP_CONFIG && typeof window.APP_CONFIG === 'object') {
    // config.js ran successfully — sync path, nothing to do.
    return;
  }

  console.warn(
    '[bootstrap] window.APP_CONFIG missing — config.js did not load. ' +
    'Falling back to legacy /config.json fetch.  Update index.html to ' +
    'include <script src="/config.js"></script> for race-free config loading.'
  );

  try {
    const res = await fetch('/config.json', { cache: 'no-cache' });
    if (!res.ok) {
      console.warn(`[bootstrap] /config.json fetch failed: HTTP ${res.status}`);
    } else {
      // Content-type guard: a static-file server's SPA catch-all
      // typically returns the index.html shell (text/html) for any
      // unmapped path — which would then JSON.parse as <!doctype>...
      // Reject anything that isn't JSON BEFORE attempting to parse.
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      if (!ct.includes('application/json') && !ct.includes('text/json')) {
        console.warn(
          `[bootstrap] /config.json returned non-JSON content-type "${ct}" ` +
          '— SPA catch-all likely hijacked the route.  Using empty fallback.'
        );
      } else {
        const text = await res.text();
        try {
          window.APP_CONFIG = JSON.parse(text);
        } catch (parseErr) {
          console.warn('[bootstrap] /config.json JSON parse failed:', parseErr);
        }
      }
    }
  } catch (fetchErr) {
    console.warn('[bootstrap] /config.json fetch threw:', fetchErr);
  }

  if (!window.APP_CONFIG) {
    window.APP_CONFIG = { apiUrl: '' };
  }
}

ensureAppConfig().then(() => {
  ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
