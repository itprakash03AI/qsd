"""Phase 134-P — DB-polling entry point for the ``s3_query`` pipeline.

Structural clone of ``oracle_standalone.py``.  Every code path here
mirrors Oracle's standalone shape exactly (inline polling in
``main()``, no per-RUN_ID claim, lowercase-only column normalisation,
``break``-on-step-failure, ``task_id = run_id``).  The only
intentional differences are:

  * Loads ``polling_query_s3_query`` instead of
    ``polling_query_sb_to_oracle`` (different query, same shape).
  * Uses ``S3QueryWorker`` instead of ``OracleWorker`` (no
    StarburstDataSource — S3 is the source).
  * Log filename prefix is ``s3_query_…`` so log routing tools can
    distinguish the workflows.

Triggered exclusively by Airflow's ``SparkSubmitOperator`` — see
``airflow_dag/s3_query_dag.py``.  CLI contract:

    spark-submit … s3_query_standalone.py \
        --report_id 42 --business_date 02-06-26 \
        --dag_id S3_QUERY_RUNNER \
        --config_path /usr/local/spark/pvc/code/configs/oracle_config.yaml

Same arg names + defaults as ``oracle_standalone.py`` so operators
can swap application paths without changing the SparkSubmit
arguments.
"""
from __future__ import annotations

# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
# 2026-06-21 bug #13.  See file_standalone.py for full explanation.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="s3_query",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    pass
# === END PREFLIGHT BOOTSTRAP ===

import argparse
import asyncio
import logging
import os
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import yaml

# Make the ETL tree importable when run as a script via spark-submit.
# spark-submit drops only this script into a temp /spark-upload-<uuid>/
# dir -- probe well-known prod roots for the log_config sentinel before
# falling back to __file__.parent (local-dev only).  See
# file_standalone.py for the rationale.
_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",
    "/usr/local/spark/pvc/code/etl",
    "/usr/local/spark/pvc",
    str(Path(__file__).resolve().parent),
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from managers.oracle_metadata_manager import OracleMetadataManager
from workers.s3_query_worker import S3QueryWorker


from log_config import get_log_dir as _get_log_dir, set_run_log_file, set_workflow_name
LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Hard-coded queries path — matches oracle_standalone.py exactly.
# Operators switch this via the spark-submit image build, not CLI.
QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"

SPARK_UPLOAD_ROOT = Path("/usr/local/spark/gvc/jars")
MAX_AGE_HOURS = 1
PREFIX = "spark-upload-"

# Console-only logger at startup (file handler added after args parsed).
logger = logging.getLogger("s3_query_standalone")
logger.setLevel(logging.INFO)
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter(LOG_FMT))
logger.addHandler(_sh)


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that identifies this batch execution.

    Format: ``s3_query_{dag_id}_{report_id}_{business_date}_{HHMMSS}.log``

    2026-07-02 -- retention sweep BEFORE returning: keep 1 previous
    ``s3_query_{dag}_{report}_*.log`` so the newly-created log makes
    exactly 2 total per (dag, report) tuple.  User directive:
    "keep only last 2 run logs and delete old ones".  Fail-open.
    """
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"s3_query_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    log_path = os.path.join(LOG_DIR, filename)
    try:
        from log_retention import prune_old_logs
        prune_old_logs(
            log_dir=LOG_DIR,
            prefix=f"s3_query_{safe_dag}_{report_id}_",
            keep=1,
            logger=logger,
        )
    except Exception as exc:
        try:
            logger.warning("Log retention sweep failed (ignored): %s", exc)
        except Exception:
            pass
    return log_path


def _attach_file_handler(log_file: str) -> None:
    """Add file handler to the module logger after we know the batch context.

    encoding='utf-8' is mandatory on Windows (cp1252 default crashes
    on any non-ASCII log line).
    """
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} — console only")


def cleanup_old_spark_uploads() -> None:
    """Delete old spark-upload-* directories older than MAX_AGE_HOURS."""
    cutoff_timestamp = time.time() - (MAX_AGE_HOURS * 3600)
    try:
        for item in SPARK_UPLOAD_ROOT.iterdir():
            if item.is_dir() and item.name.startswith(PREFIX):
                if item.stat().st_atime < cutoff_timestamp:
                    logger.info(f"Deleting: {item}")
                    try:
                        shutil.rmtree(item)
                    except Exception as e:
                        logger.error(f"Failed to delete {item}: {e}")
    except Exception as e:
        logger.error(f"cleanup_old_spark_uploads failed with error: {str(e)}")


async def execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    run_report=None,
    artifacts=None,
) -> None:
    """Execute all s3_query task steps for a given RUN_ID based on
    dynamic sequence.

    2026-06-20 -- accepts optional ``run_report`` + ``artifacts`` from the
    StandaloneRunLifecycle so this pipeline has the SAME operator-facing
    visibility as the file flow (result.html, start/finish email,
    cleanup-on-failure).
    """
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError(
            "Tasks, worker_connection_string, and dest_connection_string are required"
        )

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Create S3QueryWorker ONCE — reused for all steps in this run.
    worker = S3QueryWorker(oracle_data_manager, logger)

    # 2026-06-26 -- release Spark right after the LAST Spark-using step
    # so the tail (Compress / CTL / Deliver / ClearStaging) doesn't
    # hold Spark resources.
    from spark_lifecycle import install_pipeline_spark_release
    maybe_release_spark = install_pipeline_spark_release(tasks, logger)

    for i, task in enumerate(tasks):
        task["log_file"] = log_file
        if run_report is not None:
            task["_run_report"] = run_report
        if artifacts is not None:
            task["_run_artifacts"] = artifacts

        logger.info(
            f"Executing task {task.get('run_id')} with DAG_ID: {task.get('fk_dag_id')} "
            f"and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} "
            f"(SEQ: {task.get('seq')})"
        )

        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}"
            )
            # 2026-06-20 -- propagate so StandaloneRunLifecycle catches
            # the failure, runs cleanup, sends the failure email.
            raise
        finally:
            maybe_release_spark(i)


async def main() -> None:
    """Main function — mirrors ``oracle_standalone.main`` exactly."""
    cleanup_old_spark_uploads()

    parser = argparse.ArgumentParser(
        description="Execute an s3_query task for a specific report ID and business date.",
    )
    parser.add_argument(
        "--report_id", type=int, required=True,
        help="The report ID to process.",
    )
    parser.add_argument(
        "--business_date", type=str, required=True,
        help='The business date to process (e.g., "2025-07-10").',
    )
    parser.add_argument(
        "--dag_id", type=str, required=True,
        help="The DAG ID to process.",
    )
    parser.add_argument(
        "--config_path", type=str,
        default="/usr/local/spark/pvc/code/configs/oracle_config.yaml",
        help="Path to the configuration file.",
    )
    parser.add_argument("--no-auto-install", action="store_true",
                          help="Skip auto-install of missing REQUIRED packages")
    parser.add_argument("--no-install-optional", action="store_true",
                          help="Skip auto-install of OPTIONAL packages")

    # 2026-06-27 -- --machine / --vault-token-method for qs_credentials.
    from runtime_env import add_runtime_env_args, apply_runtime_env_args
    add_runtime_env_args(parser)

    args = parser.parse_args()

    # Export to env BEFORE any qs_credentials import fires.
    apply_runtime_env_args(args, logger=logger)

    # 2026-06-21 -- preflight already ran at top-of-file bootstrap.
    # Honour CLI opt-outs for explicit re-check.
    if args.no_auto_install or args.no_install_optional:
        try:
            from preflight import preflight_check
            preflight_check(
                workflow="s3_query",
                auto_install=not args.no_auto_install,
                install_optional=not args.no_install_optional,
            )
        except ImportError:
            pass

    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    try:
        set_run_log_file(log_file)
    except Exception:
        pass
    set_workflow_name("s3_query")
    os.environ["ETL_WORKFLOW_NAME"] = "s3_query"

    logger.info(
        f"Starting s3_query batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    # Load queries from YAML — hard-coded path, matches Oracle standalone.
    queries_path = QUERIES_PATH
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")

    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)

    if "polling_query_s3_query" not in queries:
        raise ValueError(
            "polling_query_s3_query not found in etl_polling_task_query.yaml"
        )

    # Establish database connections via the canonical resolver so:
    #   * vault-mode prod: creds filled from vault (secret_ref path)
    #   * dev without vault: literal creds in yaml served + cached
    #   * env-var fallback path also honoured
    # 2026-07-01 (operator report) -- was reading raw yaml which broke
    # both prod (secret_ref not expanded) and dev (would have worked
    # only by accident when creds happened to be embedded).
    from oracle_config_loader import (
        resolve_etl_connection_string,
        resolve_dest_connection_string,
    )
    worker_connection_string = resolve_etl_connection_string(config)
    dest_connection_string = resolve_dest_connection_string(config)
    if not worker_connection_string:
        raise ValueError(
            "Oracle ETL connection string could not be resolved.  "
            "Check oracle_config.yaml -> oracle.etl_connection_string OR "
            "oracle.etl.{host,port,service,username,password} OR "
            "oracle.etl.secret_ref (vault) OR ETL_ORACLE_CONN env var."
        )
    if not dest_connection_string:
        raise ValueError(
            "Oracle destination connection string could not be resolved.  "
            "Check oracle_config.yaml -> oracle.dest_connection_string OR "
            "oracle.destination.{host,port,service,username,password} OR "
            "oracle.destination.secret_ref (vault) OR DEST_ORACLE_CONN env var."
        )

    # Fetch all tasks from database using OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # execute_query_asynch returns a DataFrame — convert to list of dicts
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_s3_query"],
        {
            "1": args.report_id,
            "2": args.business_date,
            "3": args.dag_id,
        },
        worker_connection_string,
    )

    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    # Convert DataFrame rows to list of dicts for downstream consumption
    tasks = tasks_df.to_dict(orient='records')

    # Normalize column names to lowercase for consistent access
    tasks = [{k.lower(): v for k, v in row.items()} for row in tasks]

    # Normalize tasks
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    # 2026-06-20 -- StandaloneRunLifecycle gives this pipeline operator-
    # facing parity with the file flow: result.html, start/finish email,
    # cleanup-on-failure registry.
    from standalone_lifecycle import StandaloneRunLifecycle
    # 2026-06-26 -- Spark teardown lifted from per-step finally blocks
    # to this pipeline-level finally.  See spark_lifecycle.py header.
    from spark_lifecycle import stop_active_spark_session
    try:
        async with StandaloneRunLifecycle(
            pipeline="s3_query",
            dag_id=args.dag_id,
            report_id=args.report_id,
            business_date=args.business_date,
            log_file=log_file,
            config=config,
            sample=tasks[0],
            logger=logger,
        ) as lc:
            await execute_tasks(
                tasks, config, worker_connection_string, dest_connection_string,
                log_file, run_report=lc.run_report, artifacts=lc.artifacts,
            )
    finally:
        stop_active_spark_session(logger)


if __name__ == "__main__":
    asyncio.run(main())
