"""BF-595 (2026-05-30) — lightweight Starburst→Oracle step base (NO Spark).

Designed for the background polling-service path where the strategic
workload is < 500K rows per run.  Skipping Spark removes:
  * ~13 GB of JVM heap reservation per concurrent Spark step
    (10g executor + 3g driver) — eliminates the 5-concurrent-runs ×
    13 GB memory bomb at max_concurrent_runs = 5.
  * 5-20 s SparkSession start-up per step.
  * JDBC JAR download / classpath plumbing (no `/opt/spark/jars/...`).
  * The `apache/spark-py:3.5.3` base image (~2 GB) — slim Python
    base image is ~150 MB.

Trade-offs vs ``StarburstBase`` (the Spark variant):
  * Single-threaded read/write from one Python process.  ``trino``
    + ``oracledb`` are both fast at the < 500K-row scale; benchmarks
    show ~30-60K rows/sec for executemany inserts on Oracle with
    arraysize=10000.  For 500K rows that's ~8-17 s — well under
    the 5-minute Spark equivalent (most of which is JVM startup).
  * Memory is bounded by ``batch_size`` (default 50K rows) +
    fetchsize (default 50K).  Peak memory ≈ 2 × batch_size × row_size
    + Trino result-set buffer ~50 MB.  For 1KB rows = ~150 MB peak,
    vs 13 GB JVM reservation in Spark.

Public contract is identical to ``StarburstBase``:
  * Same JSON config file format (``task['sql_query_path']``)
  * Same required config fields: ``trino_user``, ``trino_password``,
    ``oracle_url``, ``oracle_user``, ``oracle_password``, ``query_on_*``,
    ``trino_*_url``
  * Same task-dict contract (``business_date``, ``system_entity``,
    ``eventcode`` for templating; ``dest_table`` for target)
  * Same async ``_execute_step`` signature
  * Same per-task log file via ``task['log_file']``
  * Same STATUS lifecycle via ``oracle_data_manager.update_otg_etl_batch_status``

NEW config fields (all optional; sensible defaults):
  * ``light_batch_size`` (int, default 50000) — rows per Oracle executemany
  * ``light_fetch_size`` (int, default 50000) — rows per Trino fetchmany
  * ``light_max_rows`` (int, default 500000) — refuse-to-run cap; if
    Trino COUNT(*) exceeds this, the step raises a clear error
    pointing the operator to the Spark variant in step_mapping.yaml
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from steps.BaseStep import BaseStep

# Import lazily so test environments without trino/oracledb installed
# can still import the module — actual run will fail at runtime with
# a clear error.
try:
    import trino  # type: ignore
    from trino.auth import BasicAuthentication  # type: ignore
except ImportError:
    trino = None
    BasicAuthentication = None

try:
    import oracledb  # type: ignore
except ImportError:
    oracledb = None


LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


class LightStarburstBase(BaseStep):
    """Lightweight Starburst→Oracle base — direct JDBC, no Spark.

    Subclasses override ``QUERY_KEY`` and ``TRINO_URL_KEY`` to point at
    the cloud / on-prem config keys, exactly mirroring ``StarburstBase``.
    """

    # ── Subclass overrides ──────────────────────────────────────────
    QUERY_KEY: str = "query_on_cloud"
    TRINO_URL_KEY: str = "trino_oncloud_url"
    LOG_PREFIX: str = "light_sb_to_oracle"

    # ── Required config fields (subset of StarburstBase — no spark_jars) ─
    COMMON_REQUIRED_FIELDS: List[str] = [
        "trino_user", "trino_password",
        "oracle_url", "oracle_user", "oracle_password",
    ]

    # ── Defaults ─────────────────────────────────────────────────────
    DEFAULT_BATCH_SIZE: int = 50_000
    DEFAULT_FETCH_SIZE: int = 50_000
    DEFAULT_MAX_ROWS: int = 500_000

    # ── Helpers ──────────────────────────────────────────────────────

    def _get_required_fields(self) -> List[str]:
        return [self.QUERY_KEY, self.TRINO_URL_KEY] + self.COMMON_REQUIRED_FIELDS

    def _load_and_validate_config(self, task: Dict) -> Dict:
        """Load JSON config from ``task['sql_query_path']`` and validate.

        2026-06-12 — credentials and TRINO_URL fall back to the shared
        ``configs/starburst_config.yaml`` when the per-job JSON omits
        them.  That lets job JSONs drop the duplicated ``trino_user``
        / ``trino_password`` / ``trino_<endpoint>_url`` keys — operators
        manage Starburst creds in ONE file.

        Resolution order per field:
          1. Per-job JSON (``trino_user`` etc.)        — explicit override
          2. Shared starburst_config.yaml + env vars   — single source

        Per-job JSON still wins to preserve back-compat with existing
        job JSONs that carry inline credentials.
        """
        config_path = task.get("sql_query_path")
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")
        try:
            with open(config_path, "r") as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        # ── Shared Starburst credentials fallback ───────────────────
        # 2026-06-26 -- catch narrowed to ImportError ONLY.  Vault
        # loud-fail RuntimeError / ValueError must propagate.
        try:
            from starburst_config_loader import merge_shared_into_job_config as _merge_sb
        except ImportError:
            pass
        else:
            _merge_sb(config, trino_url_key=self.TRINO_URL_KEY)

        # ── Shared destination Oracle credentials fallback ──────────
        # Pulls oracle_user / oracle_password / oracle_url from
        # configs/oracle_config.yaml's dest_connection_string when the
        # per-job JSON omits them.  Same back-compat contract — per-job
        # JSON wins.
        try:
            from oracle_config_loader import merge_shared_into_job_config as _merge_ora
        except ImportError:
            pass
        else:
            _merge_ora(config)

        # Treat empty strings as missing so a blank ``trino_user`` field
        # in the per-job JSON falls through to the shared resolver above
        # (after this point) and, if still empty, surfaces a clear error.
        missing = [f for f in self._get_required_fields() if not config.get(f)]
        if missing:
            raise ValueError(
                f"Missing required config fields: {missing}. "
                f"Set them in the per-job JSON ({config_path}) OR in the "
                f"shared configs/starburst_config.yaml + STARBURST_* env vars."
            )
        return config

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Same template-substitution rules as StarburstBase."""
        replacements = {
            "{BUSINESSDATE}":  str(task.get("business_date", "")),
            "{SYSTEM_ENTITY}": str(task.get("system_entity", "")),
            "{EventCode}":     str(task.get("eventcode", "")),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        return query

    def _setup_logging(self, task: Dict) -> None:
        """Configure named logger; single-file-per-run via
        ``log_config.attach_step_logger`` so every oracle-workflow step
        appends to the ONE run-log the standalone pinned."""
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"etl.{self.LOG_PREFIX}", task, workflow="oracle_standalone",
        )

    # ── Trino read ──────────────────────────────────────────────────

    @staticmethod
    def _parse_trino_url(url: str) -> Dict[str, Any]:
        """Parse JDBC-style Trino URL into trino-python-client kwargs.

        Accepts both:
          jdbc:trino://host:443/catalog/schema?SSL=true&...
          trino://host:443/catalog/schema
        """
        from urllib.parse import urlparse, parse_qs
        # Strip jdbc: prefix if present
        if url.startswith("jdbc:"):
            url = url[5:]
        parsed = urlparse(url)
        path_parts = [p for p in (parsed.path or "").strip("/").split("/") if p]
        catalog = path_parts[0] if path_parts else None
        schema = path_parts[1] if len(path_parts) > 1 else None
        query = parse_qs(parsed.query or "")
        ssl = (query.get("SSL", ["false"])[0]).lower() in ("true", "1", "yes")
        return {
            "host":    parsed.hostname or "",
            "port":    parsed.port or (443 if ssl else 8080),
            "catalog": catalog,
            "schema":  schema,
            "http_scheme": "https" if ssl else "http",
        }

    def _count_rows(self, conn, query: str, task: Optional[Dict] = None) -> int:
        """COUNT(*) pushdown — same pattern as StarburstBase.

        2026-06-12 — also registers a cancellable so a timeout during
        the COUNT(*) pre-flight (which CAN take minutes on a large
        unfiltered scan) cancels server-side.
        """
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable, unregister_starburst_cancellable,
        )
        count_query = f"SELECT COUNT(*) FROM ({query}) t"
        self.logger.info("Fetching record count from Trino via COUNT(*) pushdown...")
        cur = conn.cursor()
        handle = StarburstCancellable(
            KIND_TRINO_CURSOR, cursor=cur, label=f"{self.LOG_PREFIX}.count",
        )
        if task is not None:
            register_starburst_cancellable(task, handle)
        try:
            cur.execute(count_query)
            row = cur.fetchone()
            return int(row[0]) if row and row[0] is not None else 0
        finally:
            if task is not None:
                unregister_starburst_cancellable(task, handle)
            try:
                cur.close()
            except Exception:
                pass

    def _read_from_trino_streaming(
        self, conn, query: str, fetch_size: int, task: Optional[Dict] = None,
    ):
        """Yield (columns, batch_of_rows) tuples until exhausted.

        Streams rows in chunks of ``fetch_size`` — caller writes each
        batch to Oracle then drops it from memory.  Peak memory is
        bounded by one batch.

        2026-06-12 — registers the trino cursor as a
        ``StarburstCancellable`` on the task so the WorkflowRunner can
        cancel the query on Starburst when the run is timed out / the
        pod is shutting down.  Without this the query keeps consuming
        coordinator slots after the Python client has given up.
        """
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable, unregister_starburst_cancellable,
        )
        cur = conn.cursor()
        handle = StarburstCancellable(
            KIND_TRINO_CURSOR, cursor=cur, label=f"{self.LOG_PREFIX}.stream",
        )
        if task is not None:
            register_starburst_cancellable(task, handle)
        try:
            self.logger.info("Reading data from Trino (streaming)...")
            cur.execute(query)
            # trino cursor.description: list of (name, type_code, ...) tuples
            columns = [d[0] for d in (cur.description or [])]
            if not columns:
                return
            while True:
                rows = cur.fetchmany(fetch_size)
                if not rows:
                    break
                yield columns, rows
        finally:
            if task is not None:
                unregister_starburst_cancellable(task, handle)
            try:
                cur.close()
            except Exception:
                pass

    # ── Oracle write ────────────────────────────────────────────────

    def _write_batch_to_oracle(
        self, conn, table: str, columns: List[str], rows: List[tuple],
        batch_size: int,
    ) -> int:
        """Bulk-insert a batch into Oracle via executemany.

        ``oracledb`` executemany with ``arraysize`` and ``batcherrors=False``
        is roughly 10x faster than per-row execute().  We commit per
        batch so a mid-stream failure doesn't roll back hours of work.
        """
        if not rows:
            return 0
        col_list = ", ".join(columns)
        placeholders = ", ".join([f":{i + 1}" for i in range(len(columns))])
        insert_sql = f"INSERT INTO {table} ({col_list}) VALUES ({placeholders})"
        cur = conn.cursor()
        try:
            cur.arraysize = max(1000, batch_size // 10)
            # Insert in slices of batch_size in case the row buffer is huge.
            total = 0
            for i in range(0, len(rows), batch_size):
                slice_ = rows[i:i + batch_size]
                cur.executemany(insert_sql, slice_)
                total += len(slice_)
            conn.commit()
            return total
        except oracledb.Error:  # type: ignore[union-attr]
            conn.rollback()
            raise
        finally:
            cur.close()

    # ── Main entry — matches BaseStep contract ──────────────────────

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        """Read Starburst → write Oracle.  Returns total rows written.

        Behaviour mirrors ``StarburstBase._execute_step`` byte-for-byte
        on the OUTSIDE (status updates, return value, error semantics)
        but the INSIDE uses direct JDBC instead of Spark.
        """
        if trino is None:
            raise RuntimeError(
                "trino-python-client not installed — cannot run "
                "LightStarburstBase.  Install: pip install trino"
            )
        if oracledb is None:
            raise RuntimeError(
                "oracledb not installed — cannot run LightStarburstBase. "
                "Install: pip install oracledb"
            )

        self._setup_logging(task)
        config = self._load_and_validate_config(task)

        raw_query = config[self.QUERY_KEY]
        trino_query = self._parameterize_query(raw_query, task)

        # 2026-06-12 — feed the parameterised SQL to the run report (if
        # one is wired into the task dict).  ``FileRunReport`` writes it
        # to ``queries/<job_id>.sql`` and renders a download link in the
        # HTML so end-users can grab the exact query that ran.
        # No-ops silently when no run-report is attached (current oracle
        # standalone path) — the wiring is harmless extra plumbing
        # waiting for a report to land on the task dict.
        run_report = task.get("_run_report")
        if run_report is not None:
            try:
                job_id = (
                    task.get("fk_dag_id")
                    or task.get("dag_id")
                    or task.get("run_id")
                    or self.LOG_PREFIX
                )
                run_report.add_sql_summary(str(job_id), trino_query)
            except Exception as exc:
                self.logger.warning(
                    "Could not feed SQL to run_report: %s", exc,
                )

        batch_size = int(config.get("light_batch_size", self.DEFAULT_BATCH_SIZE))
        fetch_size = int(config.get("light_fetch_size", self.DEFAULT_FETCH_SIZE))
        max_rows = int(config.get("light_max_rows", self.DEFAULT_MAX_ROWS))
        oracle_table = task["dest_table"]

        trino_kwargs = self._parse_trino_url(config[self.TRINO_URL_KEY])
        trino_auth = BasicAuthentication(  # type: ignore[union-attr]
            config["trino_user"], config["trino_password"],
        )

        # Connect to Trino
        self.logger.info(
            f"Connecting to Trino: host={trino_kwargs['host']} "
            f"catalog={trino_kwargs['catalog']} schema={trino_kwargs['schema']}"
        )
        tconn = trino.dbapi.connect(  # type: ignore[union-attr]
            host=trino_kwargs["host"],
            port=trino_kwargs["port"],
            user=config["trino_user"],
            catalog=trino_kwargs.get("catalog"),
            schema=trino_kwargs.get("schema"),
            http_scheme=trino_kwargs["http_scheme"],
            auth=trino_auth if trino_kwargs["http_scheme"] == "https" else None,
        )

        # Parse Oracle JDBC URL → oracledb dsn
        oracle_dsn = self._oracle_url_to_dsn(config["oracle_url"])
        self.logger.info(f"Connecting to Oracle dsn={oracle_dsn}")
        oconn = oracledb.connect(  # type: ignore[union-attr]
            user=config["oracle_user"],
            password=config["oracle_password"],
            dsn=oracle_dsn,
        )

        read_start = datetime.now()
        total_rows = 0
        try:
            # Pre-flight: refuse to run if dataset exceeds the configured cap.
            row_count = self._count_rows(tconn, trino_query, task=task)
            self.logger.info(f"Trino COUNT(*) = {row_count}")
            if row_count > max_rows:
                raise RuntimeError(
                    f"LightStarburst refuses to run: {row_count} rows > "
                    f"light_max_rows={max_rows}.  Use the Spark variant "
                    f"(StarburstToOracleOnCloud / OnPrem in step_mapping.yaml "
                    f"createJob section) for larger workloads."
                )
            task["totalcount"] = row_count

            # Stream batches Trino → Oracle.
            for columns, batch in self._read_from_trino_streaming(
                tconn, trino_query, fetch_size, task=task,
            ):
                written = self._write_batch_to_oracle(
                    oconn, oracle_table, columns, batch, batch_size,
                )
                total_rows += written
                self.logger.info(
                    f"Wrote batch: {written} rows (running total: {total_rows})"
                )

            elapsed = (datetime.now() - read_start).total_seconds()
            self.logger.info(
                f"LightStarburst completed: {total_rows} rows in {elapsed:.2f}s "
                f"(no Spark)"
            )

            # Record-count status update — same call as Spark path.
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"),
                task.get("run_detail_id"),
                "UPDATE_TASK_RECORDCOUNT",
                step_name,
                total_rows,
                "",
                worker_connection_string,
            )
            return total_rows

        except Exception as exc:
            self.logger.error(f"LightStarburst FAILED: {exc}", exc_info=True)
            raise
        finally:
            try:
                tconn.close()
            except Exception:
                pass
            try:
                oconn.close()
            except Exception:
                pass

    @staticmethod
    def _oracle_url_to_dsn(jdbc_url: str) -> str:
        """Convert an Oracle JDBC URL to an oracledb-acceptable DSN.

        Accepts:
          * ``jdbc:oracle:thin:@host:1521/svc``       → EZ-connect (strip prefix)
          * ``jdbc:oracle:thin:@//host:1521/svc``     → EZ-connect (strip prefix)
          * ``jdbc:oracle:thin:@(DESCRIPTION=...)``   → TNS descriptor
            (strip ``jdbc:oracle:thin:@`` but PRESERVE the parenthesised
            descriptor — oracledb accepts it as ``dsn=`` directly)
          * ``jdbc:oracle:thin:@TNS_ALIAS``           → TNS alias name
            (strip prefix, pass alias unchanged — oracledb resolves
            against TNS_ADMIN / tnsnames.ora)
          * ``host:1521/svc``                         → already EZ-connect
          * ``(DESCRIPTION=...)``                     → already TNS form

        BF-597: previous version would silently mangle TNS DESCRIPTION
        URLs into a useless ``(DESCRIPTION=...)`` fragment after stripping
        ``jdbc:oracle:thin:`` (no ``@`` boundary check).  Now correctly
        detects the descriptor and preserves it.

        Raises ValueError on empty input.
        """
        if not jdbc_url:
            raise ValueError("Empty oracle_url")
        url = jdbc_url.strip()
        # Strip JDBC prefix forms in order — longest match first.
        for prefix in (
            "jdbc:oracle:thin:@//",
            "jdbc:oracle:thin:@",
            "jdbc:oracle:thin:",
            "jdbc:oracle:",
        ):
            if url.startswith(prefix):
                url = url[len(prefix):]
                break
        # At this point ``url`` is one of:
        #   host:port/svc   (EZ-connect)
        #   (DESCRIPTION=…) (TNS descriptor — pass to oracledb as-is)
        #   TNS_ALIAS       (TNS alias name — pass to oracledb as-is)
        # All three forms are accepted by oracledb.connect(dsn=...).
        return url
