"""ONE cancel signal per run, and the record of what it reached (2026-10-26).

The owner: *"if any feed is running and we need to cancel, we should be able
to cancel in case something is wrong ... the same cancellation should be done
at the source also"*.

Before this module a run's cancel was a bare ``threading.Event``: every lane
watched it (the connector watchdogs, the DuckDB child's wait loop, the Spark
await) but nothing wrote down WHAT it stopped -- a cancel that reached Trino
and one that met a dead cursor both ended the run as ``cancelled`` with the
same words.  Unknown is not "stopped": a statement the cancel could not reach
keeps running at the source, and the record must say so.

``RunCancel`` IS a ``threading.Event`` (every existing ``.is_set()`` /
``.set()`` / ``.wait()`` keeps working) plus:

* ``request(by=, at=)`` -- who asked and when (the first request wins);
* ``note(source, reached=, detail=)`` -- what each watchdog did at ITS source
  (``note_cancel`` below is the call every watchdog makes; on a plain Event
  it is a no-op, so a lane handed an ordinary event is unchanged);
* ``record()`` -- the dict the execution row carries
  (``files_metadata.cancel``) and ``sentence()`` -- the words the run shows.

The STOP SCOPE (``bound`` / ``stop_requested`` / ``stop_check``) hands the
run's event to code that has no parameter for it -- the delivery transport
under the hop runner, the CSV worker loop -- without threading a kwarg
through five signatures.  It is a ContextVar: ``asyncio.to_thread`` copies
the context, and a scope bound inside a thread stays in that thread.
"""
from __future__ import annotations

import threading
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterator, List, Optional

__all__ = [
    "RunCancel", "note_cancel", "bound", "call_bound", "current",
    "stop_requested", "stop_check", "cancel_sentence", "scrub_text", "describe",
]

#: plain words per source kind (the record keeps the kind; the screen shows
#: these)
SOURCE_WORDS: Dict[str, str] = {
    "trino": "Trino / Starburst query",
    "starburst": "Starburst query",
    "snowflake": "Snowflake query",
    "oracle": "Oracle statement",
    "databricks": "Databricks query",
    "athena": "Athena query",
    "duckdb": "DuckDB statement",
    "duckdb_child": "DuckDB child process",
    "csv_workers": "CSV writer processes",
    "spark_k8s": "Spark pod",
    "airflow": "Airflow run",
    "delivery": "delivery",
}


def _iso(dt: Any) -> Optional[str]:
    if dt is None:
        return None
    if isinstance(dt, datetime):
        return dt.isoformat()
    return str(dt)


def scrub_text(text: Any) -> str:
    """``text`` with credentials, connection URLs, paths and presigned-URL
    signing parameters masked (the platform's sanitiser, then the S3
    scrubber) -- EVERY string that reaches the cancel record passes here.
    A watchdog's ``detail`` is often built from a driver's exception, and a
    driver repeats the connection URL (``user:password@host``) or the
    presigned URL it was reading.  Never raises: a scrubber that fails
    masks the whole text rather than leaking it."""
    s = "" if text is None else str(text)
    if not s:
        return s
    try:
        from core.error_sanitizer import sanitize_error
        from core.s3_http_errors import scrub as _scrub_presigned
        return _scrub_presigned(sanitize_error(s))
    except Exception:  # noqa: BLE001
        return "[text withheld: the sanitiser failed]"


def describe(exc: BaseException) -> str:
    """An exception as the sentence the record keeps: the source's own
    verdict when it is one (``core.error_sanitizer.describe_exception``),
    scrubbed again for presigned-URL parameters."""
    try:
        from core.error_sanitizer import describe_exception
        text = describe_exception(exc)
    except Exception:  # noqa: BLE001
        text = f"{type(exc).__name__}: {exc}"
    return scrub_text(text)


class RunCancel(threading.Event):
    """THE cancel signal of one run (an Event) plus its record."""

    def __init__(self, execution_id: str = ""):
        super().__init__()
        self.execution_id = str(execution_id or "")
        self.requested_by: Optional[str] = None
        self.requested_at: Optional[datetime] = None
        self._notes: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    # ── the request ──────────────────────────────────────────────────
    def request(self, by: Optional[str] = None, at: Any = None) -> None:
        """Record who asked (the first request wins) and set the event."""
        with self._lock:
            if self.requested_at is None:
                self.requested_by = str(by) if by else self.requested_by
                self.requested_at = (at if isinstance(at, datetime)
                                     else datetime.now(timezone.utc))
            elif by and not self.requested_by:
                self.requested_by = str(by)
        self.set()

    # ── what each watchdog did ───────────────────────────────────────
    def note(self, source: str, *, reached: Optional[bool], detail: str = "",
             statement: Optional[str] = None) -> None:
        """``reached`` True = the source was told to stop and did not refuse;
        False = the cancel was tried and failed (the statement may still be
        running there); None = nothing was running at that source."""
        # every string that lands in the record is SCRUBBED here, once, for
        # every caller: a detail built from a driver's exception may carry
        # the connection URL or a presigned URL's signature
        entry = {"source": str(source or "unknown"), "reached": reached,
                 "detail": scrub_text(detail)[:500],
                 "statement": (scrub_text(statement)[:120] if statement else None),
                 "at": datetime.now(timezone.utc).isoformat()}
        with self._lock:
            self._notes.append(entry)

    @property
    def notes(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [dict(n) for n in self._notes]

    # ── the record ───────────────────────────────────────────────────
    def record(self) -> Dict[str, Any]:
        notes = self.notes
        tried = [n for n in notes if n["reached"] is not None]
        return {
            "requested_by": self.requested_by,
            "requested_at": _iso(self.requested_at),
            "sources": notes,
            # None = no source statement was running when the cancel landed
            "all_reached": (all(n["reached"] for n in tried) if tried else None),
        }

    def sentence(self) -> str:
        return cancel_sentence(self.record())


def cancel_sentence(record: Dict[str, Any]) -> str:
    """The run's words, from a ``record()`` dict (also used when the record
    was read back from the row)."""
    by = record.get("requested_by") or "an operator"
    at = record.get("requested_at")
    when = ""
    if at:
        try:
            dt = datetime.fromisoformat(str(at))
            when = " at " + dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except ValueError:
            when = f" at {at}"
    parts = [f"Cancelled by {by}{when}."]
    stopped, failed = [], []
    for n in record.get("sources") or []:
        word = SOURCE_WORDS.get(str(n.get("source")), str(n.get("source")))
        stmt = f" {n['statement']}" if n.get("statement") else ""
        det = f" ({n['detail']})" if n.get("detail") else ""
        if n.get("reached") is True:
            stopped.append(f"{word}{stmt}{det}")
        elif n.get("reached") is False:
            failed.append(f"{word}{stmt}{det}")
    if stopped:
        parts.append("Stopped at the source: " + "; ".join(stopped) + ".")
    if failed:
        parts.append("The query may still be running on: " + "; ".join(failed)
                     + " -- check the source and stop it there.")
    if not stopped and not failed:
        parts.append("No source statement was running when the cancel landed.")
    return " ".join(parts)


def note_cancel(cancel_event: Any, source: str, *, reached: Optional[bool],
                detail: str = "", statement: Optional[str] = None) -> None:
    """The one call every watchdog makes after trying to stop its statement.
    A plain ``threading.Event`` (or None) is a no-op; never raises."""
    fn = getattr(cancel_event, "note", None)
    if not callable(fn):
        return
    try:
        fn(source, reached=reached, detail=detail, statement=statement)
    except Exception:  # noqa: BLE001 -- a note must never break the cancel
        pass


# ── the stop scope ───────────────────────────────────────────────────
_scope: ContextVar[Optional[Any]] = ContextVar("qs_run_cancel_scope", default=None)


@contextmanager
def bound(cancel_event: Any) -> Iterator[None]:
    """Make ``cancel_event`` the stop scope for everything called inside."""
    token = _scope.set(cancel_event)
    try:
        yield
    finally:
        _scope.reset(token)


def call_bound(cancel_event: Any, fn: Callable, *args: Any, **kwargs: Any) -> Any:
    """``fn(*args, **kwargs)`` with ``cancel_event`` as the stop scope -- the
    shape ``asyncio.to_thread`` takes."""
    with bound(cancel_event):
        return fn(*args, **kwargs)


def current() -> Optional[Any]:
    return _scope.get()


def stop_requested() -> bool:
    """True when the run this code works for has been cancelled."""
    ev = _scope.get()
    try:
        return bool(ev is not None and ev.is_set())
    except Exception:  # noqa: BLE001
        return False


def stop_check(what: str = "the run was cancelled") -> None:
    """Raise ``InterruptedError`` when a stop was requested (for transfer
    callbacks and loops that cannot return a value)."""
    if stop_requested():
        raise InterruptedError(what)
