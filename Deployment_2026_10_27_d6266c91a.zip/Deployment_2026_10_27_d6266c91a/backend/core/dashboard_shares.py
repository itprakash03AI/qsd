"""Dashboard share-token lifecycle helpers.

2026-08-23 (Phase 2B, F-033).  A dashboard share token (``POST
/api/dashboards/{id}/share`` -> public ``GET /api/shared-dashboard/{token}``)
could be CREATED but never LISTED or REVOKED: ``DashboardShare`` had only
create / get-by-token / increment-access.  A leaked or over-shared public
dashboard link was therefore PERMANENT (no API, no DB method, no UI) unless it
happened to carry an expiry — the exact opposite of the "token revocation is a
first-class control" requirement, and the concrete lever an admin needs when
the user who minted a share leaves.

The QueryShare twin has ``list_shares`` / ``deactivate_share`` on the
DatabaseManager; these two functions are the DashboardShare equivalents.  They
live here (a core dashboard module) rather than on the DatabaseManager to keep
the change off ``database.py``, but reuse the SAME session factory and ORM
model so persistence is not modelled a second way.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List


def validate_dashboard_share_token(db_manager, token: str) -> Dict[str, Any]:
    """THE rule for a dashboard share link a caller presents (2026-10-26).

    Unknown or revoked -> 404; expired -> 410 -- the same answers a report
    share link gives (``business_reports_api._validate_business_share_token``).
    Used by the public dashboard GET and by the finance-report tile routes a
    dashboard link may run, so "is this link still good" is decided once.
    """
    from fastapi import HTTPException
    share = db_manager.get_dashboard_share_by_token(token) if token else None
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    expires = share.get("expires_at")
    if expires:
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if getattr(expires, "tzinfo", None) is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(status_code=410, detail="Share link has expired")
    return share


def list_dashboard_shares(db_manager, dashboard_id: int) -> List[Dict[str, Any]]:
    """Return every share token minted for ``dashboard_id`` (newest first).

    Includes revoked/expired rows so an owner can see and audit them, exactly
    like ``list_shares`` for query shares.
    """
    from core.db.models import DashboardShare
    with db_manager.get_session(read_only=True) as session:
        rows = (session.query(DashboardShare)
                .filter(DashboardShare.dashboard_id == dashboard_id)
                .order_by(DashboardShare.created_at.desc())
                .all())
        return [r.to_dict() for r in rows]


def deactivate_dashboard_share(db_manager, token: str) -> bool:
    """Revoke a dashboard share token (``is_active = False``).

    Returns True if a matching token existed, False otherwise.  Idempotent:
    revoking an already-revoked token still returns True.  The token row is
    kept (not deleted) so its ``access_count`` history survives the revoke,
    matching ``deactivate_share``.
    """
    from core.db.models import DashboardShare
    with db_manager.get_session() as session:
        s = (session.query(DashboardShare)
             .filter(DashboardShare.token == token)
             .first())
        if not s:
            return False
        s.is_active = False
        return True
