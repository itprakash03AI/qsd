"""
Phase 132.37 — generic SQL filter wrapper for raw_sql / sql_file published views.

When a published view is backed by a raw SQL string (sql_file source or
saved_query with custom_sql), the engine cannot inject the snapshot
``query_config.filters`` list at WHERE-build time the way it does for
structured QueryConfig sources.  Without this wrapper, Static rows set
at publish time AND Dynamic rows submitted by the consumer at request
time would be silently dropped — the SQL would run as-written, ignoring
every per-PV WHERE mapping.

This module closes that gap with no shortcuts:

  * Every engine operator supported by ``parquet_engine_v2._build_where``
    is reproduced here, in a form every target engine parses the same way.
    2026-09-05 — this used to say "in ANSI SQL form so the wrap is
    dialect-agnostic ... all parse the result identically", and that claim
    is what the identifier bug below was built on.  The OPERATORS are
    dialect-agnostic; the IDENTIFIERS are not, and never were.
  * Value literals are type-formatted: ``None`` → ``NULL``, ``bool`` →
    ``TRUE``/``FALSE``, ``int``/``float`` → bare numeric, ``str`` →
    single-quoted with quote-doubling (SQL-injection-safe), explicit
    typed-prefix literals (``date '2026-01-01'``, ``timestamp '...'``,
    ``time '...'``, ``interval '...'``) are passed through unchanged so
    the publisher can use them in static values.
  * Column refs are rendered for the TARGET DIALECT by
    :func:`quote_identifier_for_dialect` — bare where that is legal, and
    otherwise with that engine's own delimiters.  There is no quote
    character every engine recognises: the ANSI double quote this line used
    to name is a STRING LITERAL on Spark SQL, MySQL and BigQuery, so a
    reserved-word or special-character column became a constant and the
    predicate silently changed meaning.  Qualified refs
    (``trades.region``) are still stripped to the bare column (``region``)
    because the wrap re-selects the inner result as a derived table and the
    original table aliases no longer apply at the outer scope.
  * Wrap form: ``SELECT * FROM ( <raw_sql> ) AS _qs_pv_wrap WHERE
    <conds>``.  Trailing semicolons on the inner SQL are stripped so
    engines that reject ``( ... ; ) AS x`` don't fail.  When the filter
    list is empty (or yields no usable conditions) the wrap is a no-op
    and the original SQL is returned unchanged so existing PVs are not
    affected at upgrade time.
  * A small set of "would-not-produce-WHERE" filter shapes (missing
    column, unknown operator, missing value when one is required) are
    skipped rather than raising — the wrap is best-effort defence in
    depth, the engine still surfaces any genuine column-not-found error
    when the SQL runs.

The wrapper does NOT introspect raw_sql for column existence — that
would require parsing every dialect's grammar.  Instead it trusts the
publisher to map columns the inner SQL actually exposes; if a Dynamic
column doesn't exist on the inner query, the engine produces a clear
"column not found" error which is far easier to debug than a silently
ignored filter.
"""
from __future__ import annotations

import os
import re
import threading
from functools import lru_cache
from typing import Any, Dict, Iterable, List, Optional, Tuple


# Typed-prefix literals (``date '2026-01-01'``, ``timestamp '...'``,
# etc.) are pre-formed SQL — we pass them through untouched so the
# publisher's static values can use the engine's typed-literal syntax
# (essential for Snowflake / Trino which reject implicit string→date
# coercion in strict mode).  Mirrors parquet_engine_v2._literal.
#
# 2026-08-03 SECURITY — this regex was PREFIX-only:
#     r"^\s*(date|timestamp|time|interval)\s*'"
# It matched the opening of a typed literal and then returned the WHOLE
# string unescaped, so everything after the literal was injected verbatim:
#
#     "timestamp '2020-01-01' UNION SELECT * FROM secrets --"
#         -> timestamp '2020-01-01' UNION SELECT * FROM secrets --
#
# That is reachable from an EXTERNAL Published-API consumer: filter values
# arrive over HTTP and reach ``wrap_sql_with_filters``
# (api/published_views_api.py:898).  The column name is allow-listed, but
# the VALUE was not escaped on this branch -- so allow-listing gave no
# protection.  The docstring above claiming quote-doubling makes this
# injection-safe was wrong for exactly this path.
#
# Now anchored at BOTH ends and the quoted body may not contain a quote,
# so the value must be a COMPLETE typed literal and nothing else.  The
# optional trailing word preserves the ``INTERVAL '1' DAY`` form that this
# passthrough exists to support.
_TYPED_PREFIX_RE = re.compile(
    r"^\s*(date|timestamp|time|interval)\s*'[^']*'(\s+[A-Za-z]+)?\s*$",
    re.IGNORECASE,
)


# Reserved-word lookup so identifiers that happen to match a SQL
# keyword still get explicitly quoted.  Kept conservative — covers
# the SQL92 + SQL99 reserved words that EVERY target engine reserves.
_SQL_RESERVED_WORDS = frozenset({
    "select", "from", "where", "and", "or", "not", "in", "is", "null",
    "between", "like", "as", "on", "join", "left", "right", "inner",
    "outer", "full", "cross", "group", "order", "by", "asc", "desc",
    "having", "limit", "offset", "union", "intersect", "except",
    "distinct", "case", "when", "then", "else", "end", "true", "false",
    "with", "recursive", "all", "any", "some", "exists",
    "insert", "update", "delete", "merge", "create", "drop", "alter",
    "table", "view", "index", "schema", "database", "column",
    "primary", "foreign", "key", "references", "constraint",
    "default", "check", "unique", "values", "into", "set",
    "user", "role", "grant", "revoke", "commit", "rollback",
    "begin", "transaction", "savepoint",
    "current_date", "current_time", "current_timestamp",
    "order", "level", "size", "type", "value", "name", "date", "time",
    "timestamp", "year", "month", "day", "hour", "minute", "second",
})

# Identifier must start with letter/underscore, contain only
# letter/digit/underscore.  Anything else needs quoting.  Used ONLY as the
# fallback bare-safety test when ``core.connectors.base`` cannot be imported
# — see :func:`_ident_is_bare_safe`.
_SAFE_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


# ── THE identifier renderer ────────────────────────────────────────────────
#
# 2026-09-05 — an identifier rendered for the WRONG dialect is not a style
# problem, it is FABRICATED DATA WITH A 200.  On Spark SQL (Databricks),
# MySQL and BigQuery a double-quoted token is a STRING LITERAL, so
#
#     SELECT "id", "region", "ssn", "amt" FROM sales.fact WHERE "region" = 'EMEA'
#
# selects four CONSTANTS and compares two constants.  Measured on the emitted
# text: right row count, right column count, right column NAMES, every value
# fabricated —
#
#     TRUTH    : [(1,'EMEA','123-45',10), (2,'EMEA','999-99',20)]
#     DELIVERED: [('id','region','ssn','amt'), ('id','region','ssn','amt')]
#
# — which passes a row-count completeness gate perfectly.  The same shape in a
# predicate is worse in one direction: ``'order' = 'x'`` is constant FALSE
# (zero rows) but ``NOT 'order' IN (…)`` is constant TRUE, i.e. the filter is
# silently DROPPED and the caller gets MORE rows than they asked for.
#
# FOUR renderers were deciding this: ``_quote_ident`` here,
# ``core.row_security.rewriter._q``, ``api.reports_api._auto_append_sql_where``
# (which got the backtick branch right, for databricks and mysql, on the same
# day the other two were shipping the bug), and
# ``core.connectors.base.quote_identifier`` — which renders correctly but is
# TOLD its quote character by the caller, so it can be neither right nor wrong
# on its own.  A decision made twice is a bug.
#
# This is the one that knows the DIALECT, and it DERIVES the answer instead of
# declaring it: the quote characters and the bare-identifier case fold are
# PROBED out of sqlglot, so no table here can drift from what sqlglot actually
# emits, and a dialect sqlglot learns tomorrow needs no edit.  The rendering
# rule itself is still ``core.connectors.base``'s — a guard asserts the two
# agree character-for-character on every same-quote dialect.

#: Probe name used to read a dialect's identifier quoting out of sqlglot.
#: Bare-safe and not reserved anywhere, so nothing but the quoting can change.
_IDENT_PROBE = "qs_ident_probe"

#: (open, close, bare-fold) per sqlglot dialect — used ONLY when sqlglot is
#: not importable.  Every entry is asserted equal to sqlglot's own answer by
#: tests/test_identifier_dialect_rendering_2026_09_05.py, so this copy cannot
#: silently drift into a second vocabulary.
_FALLBACK_IDENT_SYNTAX: Dict[str, Tuple[str, str, str]] = {
    "duckdb":     ('"', '"', "lower"),
    "trino":      ('"', '"', "lower"),
    "presto":     ('"', '"', "lower"),
    "athena":     ('"', '"', "lower"),
    "postgres":   ('"', '"', "lower"),
    "redshift":   ('"', '"', "lower"),
    "snowflake":  ('"', '"', "upper"),
    "oracle":     ('"', '"', "upper"),
    "databricks": ("`", "`", "lower"),
    "mysql":      ("`", "`", "lower"),
    "bigquery":   ("`", "`", "lower"),
    "tsql":       ("[", "]", "lower"),
}

#: Dialects on which the closing quote character CANNOT appear inside a
#: quoted identifier by DOUBLING it.  BigQuery is the one we know: its
#: backtick escape is ``\```, and sqlglot emits a doubled backtick, which
#: BigQuery reads as an empty identifier followed by junk.  A name containing
#: the quote character is REFUSED on these dialects rather than rendered into
#: something that means a different thing — the same posture as
#: ``core.sql_connector_dialect.transpile_for_connector``, which refuses
#: where verbatim would be silently wrong and falls back only where the shape
#: is genuinely valid.
_QUOTE_NOT_ESCAPABLE_BY_DOUBLING = frozenset({"bigquery"})


class IdentifierRenderError(ValueError):
    """An identifier cannot be rendered so ``dialect`` reads it AS AN
    IDENTIFIER.

    Never downgraded to text.  Emitting a token the engine will silently read
    as a constant is the exact failure this renderer exists to prevent, so
    every caller turns this into a refusal: a filter raises
    :class:`FilterWrapError` (dropping it would WIDEN the result set) and the
    row-security rewriter raises ``UnexpressiblePolicyError`` (fail-opening it
    would serve a governed table).
    """


def _ident_is_bare_safe(s: str) -> bool:
    """Character-wise bare legality.  ``core.connectors.base`` owns this
    answer; the regex is the fallback for the (defensive) case where that
    module cannot be imported.  Imported lazily because
    ``core.connectors.base`` imports :data:`_SQL_RESERVED_WORDS` from here."""
    try:
        from core.connectors.base import ident_is_bare_safe
    except Exception:      # pragma: no cover - defensive
        return bool(_SAFE_IDENT_RE.match(s))
    return ident_is_bare_safe(s)


@lru_cache(maxsize=256)
def _ident_syntax(dialect: str) -> Tuple[str, str, str]:
    """``(open_quote, close_quote, bare_fold)`` for ``dialect``.

    PROBED from sqlglot, not declared: render a known-bare name as a quoted
    identifier and read the delimiters off either side of it.  ``bare_fold``
    is the case a BARE identifier folds to on that engine (Snowflake and
    Oracle upper-fold, everything else lower-folds), taken from the dialect's
    normalization strategy.
    """
    try:
        from sqlglot import exp as _exp
        from sqlglot.dialects.dialect import Dialect as _Dialect
        rendered = _exp.to_identifier(_IDENT_PROBE, quoted=True).sql(dialect=dialect)
        head, sep, tail = rendered.partition(_IDENT_PROBE)
        if not sep or not head or not tail:
            raise ValueError(
                f"could not read identifier quoting for {dialect!r} from "
                f"{rendered!r}")
        strategy = str(getattr(_Dialect.get_or_raise(dialect),
                               "NORMALIZATION_STRATEGY", "")).upper()
        return (head, tail, "upper" if "UPPERCASE" in strategy else "lower")
    except Exception:
        return _FALLBACK_IDENT_SYNTAX.get(dialect, ('"', '"', "lower"))


# ── The ENGINE's own answer, where the engine is in-process ────────────────
#
# 2026-09-06 — THE VERIFIER COULD NOT SEE THE FAILURE IT EXISTS TO PREVENT.
#
# ``_verify_reads_back_as_identifier`` below is the whole safety argument for
# rendering a name BARE.  It asked sqlglot whether the bare token reads back as
# a Column.  sqlglot's DuckDB grammar says ``SELECT array`` is a Column.  The
# ENGINE says::
#
#     Parser Error: syntax error at or near "FROM"
#     LINE 1: SELECT array FROM t
#                          ^
#
# So the renderer's oracle was MORE PERMISSIVE than the engine it renders for,
# and every local test agreed with the renderer BY CONSTRUCTION — the same
# "a fixture kinder than reality proves nothing about reality" shape as
# 2026-09-03, one level below where anyone was looking.  Sweeping DuckDB's own
# ``duckdb_keywords()`` found 39 ordinary column names rendered BARE and
# rejected by DuckDB: ``array``, ``at``, ``to``, ``binary``, ``window``,
# ``describe``, ``show``, ``natural``, ``cast``, ``collate``, ``overlaps``,
# ``isnull``, ``pivot``, ``semi``, ``anti``, ``asof`` and more.  DuckDB is the
# in-process engine for EVERY parquet/S3 query in this product and is
# :data:`DEFAULT_DIALECT`, so this was live on the hot path.
#
# WHY THIS SHAPE, AND NOT A BIGGER LIST
# -------------------------------------
# The obvious fix — add the 39 to ``_SQL_RESERVED_WORDS`` — is the wrong one,
# and the previous agent was right to refuse it.  That list serves TWELVE
# grammars; quoting changes case-folding semantics (a bare name folds, a quoted
# one does not); and validating on one engine then shipping the result as a
# claim about the class is a mistake this repo has already paid for more than
# once.  Quoting ``array`` on Oracle because DuckDB dislikes it is a different
# defect wearing the first one's clothes.
#
# It is also the wrong LEVEL.  "The list is missing 39 words" is 39 instances;
# "the verifier's oracle is weaker than the engine" is the CLASS.  So the fix
# is to ASK THE ENGINE, PER ENGINE, WHERE THE ENGINE IS AVAILABLE — and to say
# plainly where it is not.
#
# DuckDB can answer for itself, on a private in-memory connection that touches
# no user data, no catalog and no file.  The probe is the SAME SHAPE the
# real-source harness sends to the operator's own engines
# (``scripts/verify_against_real_source.py``, check ``identifiers``)::
#
#     SELECT <rendered> FROM (SELECT '<sentinel>' AS <rendered>) qs_ident_probe_rel
#
# and the verdict is read off the ROW, not off a parse tree.  That answers both
# halves of the question with one statement: a token the engine will not parse
# raises, and a token the engine reads as a STRING comes back as itself instead
# of the sentinel — which is the "column names delivered as data" shape, caught
# by VALUE rather than by inspection.
#
# The alternative was ``json_serialize_sql``, DuckDB's pure-parse entry point.
# It agrees with this probe on all 998 name x quoting shapes swept (the test
# asserts that, using json_serialize_sql as an INDEPENDENT second opinion so
# production still carries only one), but its first call autoloads the JSON
# extension: 470 ms, once, on the first identifier anyone renders.  This probe
# is 0.10 ms with no first-call penalty.  Measuring the latency you add is not
# optional here — a parse inside a per-(table,column) loop cost this repo
# 530 ms/query once already.
#
# WHAT IS STILL WEAKER, SAID OUT LOUD
# -----------------------------------
# Trino, Snowflake, Oracle, BigQuery, Databricks, MySQL and T-SQL are NOT
# in-process.  sqlglot remains the only local oracle for them and it is, by
# this file's own demonstration, capable of being more permissive than the
# engine.  No per-engine keyword list is fabricated for them here: inventing
# one for an engine that cannot be asked is exactly the "verify one case, write
# the claim as the class" failure.  ``scripts/verify_against_real_source.py``
# (check ``identifiers``) is what closes that gap, because it sends the exact
# emitted text to the operator's OWN engine and reads the answer off the rows.
# :func:`engine_oracle_status` reports which dialects are engine-backed in THIS
# process, so the weakness is machine-readable rather than prose.
#
# THE ORACLE CALIBRATES ITSELF BEFORE IT IS TRUSTED
# -------------------------------------------------
# An oracle that answered "no" to everything would quote every ordinary column,
# which changes case folding on names that were fine — a NEW OUTAGE, and the
# exact thing an ``always_quote=True`` attempt on this path caused on
# 2026-09-05 (32 failing DataFlow / calendar tests, reverted the same hour).
# So before it is believed, it must get a KNOWN-GOOD name right, a name the
# engine will not PARSE wrong, and a token the engine reads as DATA wrong.  If
# a valid input also produces the "broken" verdict, the rig is wrong — and a
# future DuckDB that changes any of this degrades to yesterday's behaviour
# instead of quoting the world.

#: Alias for the derived table in the probe.  Bare-safe and reserved nowhere.
_ORACLE_REL = "qs_ident_probe_rel"

#: The value the probe expects back.  A token the engine read as a STRING
#: returns ITSELF instead of this, which is how "read as data" is detected by
#: value rather than by inspecting a parse tree.
_ORACLE_SENTINEL = "qs_ident_probe_sentinel"

#: ``(rendered, must the engine call it a column)`` — and all three rows are
#: load-bearing:
#:   an ordinary name  must be True  — an oracle that refuses valid names would
#:                     make this renderer quote EVERY column.
#:   ``array``         must be False — the defect this section exists for; if it
#:                     ever passes bare, nothing is being measured.
#:   a string constant must be False — proves the probe reads the VALUE and not
#:                     merely "did it parse". Without this row the oracle could
#:                     be a pure syntax check and still calibrate clean.
_ORACLE_CALIBRATION: Tuple[Tuple[str, bool], ...] = (
    ("qs_ident_probe", True),
    ("array", False),
    ("'qs_ident_probe'", False),
)

_ORACLE_LOCK = threading.Lock()

#: ``None`` until first consulted; then a DuckDB connection, or ``False`` with
#: :data:`_duckdb_oracle_why` naming why it could not be built or trusted.
_duckdb_oracle: Any = None
_duckdb_oracle_why: str = "not yet consulted"

#: The PID the connection was opened under.  A DuckDB connection is a NATIVE
#: handle and does not survive ``fork()``: a gunicorn/uvicorn worker that
#: inherited a parent's handle would be using a resource the parent still owns.
#: The oracle is built lazily, so a pre-fork parent that never renders an
#: identifier never opens one — but "usually not built before the fork" is a
#: timing argument, and a timing argument is not a guarantee.  Cheaper to check.
_duckdb_oracle_pid: int = -1


def _duckdb_reads_as_column_uncached(con: Any, rendered: str) -> bool:
    """Does DuckDB read ``rendered`` as a COLUMN REFERENCE?

    Asked by execution, on a private in-memory connection whose only relation
    is the one this statement builds::

        SELECT <rendered> FROM (SELECT '<sentinel>' AS <rendered>) qs_ident_probe_rel

    A name DuckDB will not parse raises.  A token DuckDB reads as a STRING
    returns itself rather than the sentinel.  Both are False, and the two are
    distinguished only in the message a caller writes — what matters here is
    that neither may be rendered.

    NO ``expected`` PARAMETER, deliberately.  The sqlglot check takes one and
    compares it against the parsed column's name; the symmetric thing here
    would be to compare DuckDB's reported column name — and on a one-column
    derived table this statement aliases itself, so that comparison is TRUE by
    construction.  A check that cannot fail is worse than no check, because a
    reader counts it.  The sentinel is the whole verdict: it can only come back
    if the token addressed the column.
    """
    sql = ("SELECT %s FROM (SELECT '%s' AS %s) %s"
           % (rendered, _ORACLE_SENTINEL, rendered, _ORACLE_REL))
    try:
        rows = con.execute(sql).fetchall()
    except Exception:
        return False
    return (len(rows) == 1 and len(rows[0]) == 1
            and rows[0][0] == _ORACLE_SENTINEL)


def _duckdb_oracle_conn() -> Optional[Any]:
    """The calibrated DuckDB parse oracle, or ``None`` — with a reason kept.

    Built lazily on FIRST CONSULTATION, so a process that never renders an
    identifier pays nothing at all, and built once per process thereafter —
    per PROCESS, re-checked by PID, because the handle is native and a forked
    worker must not use its parent's.

    Every failure path — duckdb absent, the probe shape no longer accepted, a
    calibration row disagreeing — returns ``None``, which leaves the
    sqlglot-only behaviour exactly as it was.  The oracle can only ever make
    this renderer STRICTER; it can never be the reason an ordinary column stops
    rendering.
    """
    global _duckdb_oracle, _duckdb_oracle_why, _duckdb_oracle_pid
    pid = os.getpid()
    if _duckdb_oracle is not None and _duckdb_oracle_pid == pid:
        return _duckdb_oracle or None
    with _ORACLE_LOCK:
        if _duckdb_oracle is not None and _duckdb_oracle_pid == pid:
            return _duckdb_oracle or None
        _duckdb_oracle = None
        try:
            import duckdb as _duckdb
            con = _duckdb.connect(":memory:")
            for rendered, want in _ORACLE_CALIBRATION:
                got = _duckdb_reads_as_column_uncached(con, rendered)
                if got is not want:
                    raise ValueError(
                        "calibration: asked whether DuckDB reads %r as a "
                        "column, expected %s and got %s. This oracle's "
                        "verdicts cannot be trusted, so it is not used: "
                        "over-quoting an ordinary column changes its case "
                        "folding and is a worse outage than the one being "
                        "prevented." % (rendered, want, got))
        except Exception as exc:
            _duckdb_oracle = False
            _duckdb_oracle_why = "%s: %s" % (type(exc).__name__, exc)
            _duckdb_oracle_pid = pid
            return None
        _duckdb_oracle = con
        _duckdb_oracle_why = "ready"
        _duckdb_oracle_pid = pid
        return con


@lru_cache(maxsize=8192)
def _engine_reads_as_column(dialect: str, rendered: str) -> Optional[bool]:
    """``True`` / ``False`` from the ENGINE itself, or ``None`` — NOT ASKED.

    The three answers are deliberately distinct, because "the engine says no"
    and "there is no engine here to ask" lead to opposite actions, and this
    codebase's standing rule is that UNKNOWN is not EMPTY.  Only DuckDB is
    in-process; every other dialect returns ``None`` and is governed by sqlglot
    alone — which this file has just demonstrated can be too permissive.
    """
    if dialect != "duckdb":
        return None
    con = _duckdb_oracle_conn()
    if con is None:
        return None
    try:
        with _ORACLE_LOCK:
            return _duckdb_reads_as_column_uncached(con, rendered)
    except Exception:
        # One unanswerable probe is not evidence ABOUT THE IDENTIFIER.
        # Returning False here would over-quote or refuse an ordinary column
        # because of an oracle hiccup, which is the worse failure.
        return None


def engine_oracle_status() -> Dict[str, str]:
    """Which dialects are verified against the REAL engine in this process.

    Diagnostic, and deliberately not prose.  The honest statement about this
    renderer is that exactly ONE of the twelve dialects it serves can be
    checked locally against the thing it renders for, and a reader should be
    able to get that from the code rather than from a comment that may rot.

    ``"engine"`` — the engine's own parser holds a veto over sqlglot here.
    ``"sqlglot-only: <why>"`` — no local engine, so sqlglot is the only oracle;
    ``scripts/verify_against_real_source.py`` closes that gap on the operator's
    own systems.
    """
    _duckdb_oracle_conn()
    out: Dict[str, str] = {}
    for d in sorted(_FALLBACK_IDENT_SYNTAX):
        if d == "duckdb":
            out[d] = ("engine" if _duckdb_oracle
                      else "sqlglot-only: %s" % _duckdb_oracle_why)
        else:
            out[d] = ("sqlglot-only: not an in-process engine; verify with "
                      "scripts/verify_against_real_source.py")
    return out


def _verify_reads_back_as_identifier(rendered: str, expected: str,
                                     dialect: str, original: str) -> None:
    """Parse ``rendered`` back in ``dialect`` and require an IDENTIFIER.

    This is the gate, and it is executable rather than declarative: the whole
    defect class is "the engine read our identifier as something else", so the
    check is to hand the exact emitted text back to a parser for that engine
    and confirm it comes out a column of the intended name.  ANSI ``"region"``
    on databricks/mysql/bigquery reads back as a Literal and is refused here.

    TWO oracles, and the order is the point.  sqlglot answers for all twelve
    dialects and is asked first because it is the only one that can answer for
    eleven of them.  Then, where the engine is IN-PROCESS, the engine gets a
    VETO — see :func:`_engine_reads_as_column`.  2026-09-06: sqlglot's DuckDB
    grammar reads ``SELECT array`` as a Column and DuckDB itself will not parse
    it, so for a whole day this check certified 39 ordinary column names that
    the engine rejects.  A verifier whose oracle is more permissive than the
    engine it is verifying for is not a gate; it is a second opinion from the
    same source, which is how "every local test agrees with the renderer BY
    CONSTRUCTION" happens.

    ``None`` from the engine oracle means NOT ASKED — no in-process engine for
    this dialect, or the oracle failed its own calibration — and is treated as
    silence, not as assent and not as refusal.  The engine can only ever make
    this stricter.

    Skipped (not failed) when sqlglot is unavailable — the renderer still used
    the correct delimiters from :data:`_FALLBACK_IDENT_SYNTAX`; without a
    parser there is simply nothing to verify against.
    """
    try:
        import sqlglot
        from sqlglot import exp
    except Exception:      # pragma: no cover - sqlglot is a hard dep
        return
    if _engine_reads_as_column(dialect, rendered) is False:
        raise IdentifierRenderError(
            f"Column {original!r} cannot be referenced on '{dialect}': "
            f"rendered as {rendered!r}, the ENGINE ITSELF does not read that "
            f"as the column {expected!r}. sqlglot's grammar for '{dialect}' "
            f"accepts it, which is why this had to be asked of the engine "
            f"rather than of a model of it."
        )
    try:
        tree = sqlglot.parse_one(
            f"SELECT {rendered} FROM qs_ident_probe_rel", read=dialect)
        proj = tree.expressions[0]
    except Exception as exc:
        raise IdentifierRenderError(
            f"Column {original!r} cannot be used on '{dialect}': the rendered "
            f"identifier {rendered!r} is not parseable there ({exc}). "
            f"Refusing rather than emitting SQL with undefined meaning."
        ) from exc
    if not isinstance(proj, exp.Column) or proj.name != expected:
        raise IdentifierRenderError(
            f"Column {original!r} cannot be referenced on '{dialect}': "
            f"rendered as {rendered!r} the engine reads it as "
            f"{type(proj).__name__} {proj.sql(dialect=dialect)!r}, not the "
            f"column {expected!r}. Refusing — emitting it would run a query "
            f"whose result looks right and is fabricated."
        )


@lru_cache(maxsize=256)
def _dialect_is_known(dialect: str) -> bool:
    """True when sqlglot has a grammar for ``dialect``.

    Checked EXPLICITLY, and before anything is rendered, so an unrecognised
    dialect fails with a message naming the dialect instead of a refusal for
    every column in the query.  Refusing is the posture rather than quietly
    defaulting to ANSI: emitting ANSI for an engine nobody identified is the
    exact failure this renderer exists to prevent, and it is the same
    "UNKNOWN = UNSAFE" gate as
    ``core.sql_connector_dialect.transpile_for_connector``.
    """
    try:
        from sqlglot.dialects.dialect import Dialect
        Dialect.get_or_raise(dialect)
        return True
    except ImportError:      # pragma: no cover - sqlglot is a hard dep
        return dialect in _FALLBACK_IDENT_SYNTAX
    except Exception:
        return False


def quote_identifier_for_dialect(name: Any, dialect: Optional[str] = None,
                                 *, always_quote: bool = False,
                                 fold_reserved: bool = False) -> str:
    """Render ``name`` as an identifier ``dialect`` will read as an identifier.

    ``dialect`` is a sqlglot dialect (resolve a QueryStudio connection type
    through :func:`dialect_for_connection_type` first).  Absent / empty means
    :data:`DEFAULT_DIALECT`; a dialect sqlglot does not recognise is REFUSED,
    not defaulted.

    Bare when the name is bare-legal, not a reserved word, AND the target's
    own grammar reads the bare form as a column — bare works on every engine
    and leaves the engine's own case folding alone.  That third condition is
    the round-trip check, which asks sqlglot on all twelve dialects and then
    asks THE ENGINE ITSELF wherever the engine is in-process (DuckDB only —
    see :func:`engine_oracle_status`, and the section above
    :func:`_verify_reads_back_as_identifier` for why the sqlglot answer alone
    was not enough: it vouched for 39 names DuckDB will not parse).  It is
    load-bearing rather than belt-and-braces:
    ``_SQL_RESERVED_WORDS`` is one 95-word list serving twelve grammars, and a
    sweep found 18 ordinary column names it misses (``current_user``,
    ``fetch``, ``lateral``, ``qualify``, ``using``, ``tablesample``,
    ``localtimestamp``, Oracle's ``prior``, MySQL's ``ignore``, T-SQL's
    ``top`` …) that were being emitted BARE and silently meaning a function or
    a clause keyword.  Anything else is quoted with the DIALECT's delimiters
    (backticks on Databricks / MySQL / BigQuery, brackets on T-SQL, ANSI
    double quotes elsewhere).

    ``always_quote=True`` skips the bare branch: the row-security rewriter
    projects the schema's exact stored spelling.

    ``fold_reserved`` HAS NO PRODUCTION CALLER, AND THAT IS DELIBERATE.

    CORRECTION, same day, from an audit of this very paragraph: an earlier
    version of it claimed this renderer is "BYTE-IDENTICAL" to
    ``core.connectors.base.quote_identifier``.  That is FALSE.  Measured
    over 144 name x dialect shapes with each dialect's own delimiters and
    fold, they differ on 11 -- and every one is a case where THIS renderer
    is deliberately STRICTER: an empty name (it refuses; base emits an
    empty quoted identifier), a dotted name like ``a.b`` on backtick
    dialects (it refuses the ambiguity; base quotes it whole), and the
    reserved-word fold on Snowflake/Oracle.  The parity test could not see
    any of them because it does ``except IdentifierRenderError: return`` --
    it SWALLOWS precisely the divergences.  A claim of equivalence whose
    proof discards the counter-examples is worse than no claim, because a
    reader stops looking.

    So the honest statement: they AGREE on every name either will render,
    and this one REFUSES three shapes base renders.  That is what the
    parity test now asserts.
    Two independent reviewers on 2026-09-05 read it as dead weight and
    recommended deleting it; it is not, and this paragraph exists so a
    third does not.  It is the parameter that lets
    ``test_identifier_dialect_rendering_2026_09_05`` prove this renderer is
    BYTE-IDENTICAL to ``core.connectors.base.quote_identifier`` across every
    same-quote dialect.  Delete it and the two implementations can still be
    correct, but nothing can demonstrate they AGREE -- which is how this
    codebase acquired eight copies of the dialect vocabulary in the first
    place.  A knob whose only caller is the proof of equivalence earns its
    keep; it just has to say so.

    It is also the one place this differs from
    ``core.connectors.base.quote_identifier``, and the difference is a knob
    rather than a divergence.  Base folds a reserved word that WOULD have been
    bare to the dialect's bare case before quoting, because bare ``Order``
    addresses ``ORDER`` on Snowflake and quoting it as ``"Order"`` would
    address a different CATALOG OBJECT.  That reasoning is right for the
    schema-browsing call sites base serves and wrong for the three here, which
    all carry a name that already means something exact: the schema's stored
    spelling, a filter column supplied by the caller, and a correlation alias
    lifted out of a parsed AST that the rest of the tree still references by
    its original spelling.  Default OFF keeps this change about delimiters
    only; pass True and the two functions are byte-identical (asserted).

    Raises :class:`IdentifierRenderError` when no rendering is safe.
    """
    s = str(name)
    if not s:
        raise IdentifierRenderError(
            "Empty column name — refusing to render an identifier for it.")
    d = (str(dialect or "").strip().lower() or DEFAULT_DIALECT)
    if not _dialect_is_known(d):
        raise IdentifierRenderError(
            f"No SQL dialect named {d!r} is known, so an identifier cannot be "
            f"rendered for it — refusing rather than guessing ANSI quotes, "
            f"which are STRING LITERALS on Spark SQL, MySQL and BigQuery. "
            f"Resolve the connection type through "
            f"dialect_for_connection_type() first.")
    return _render_identifier(s, d, bool(always_quote), bool(fold_reserved))


@lru_cache(maxsize=8192)
def _render_identifier(s: str, dialect: str, always_quote: bool,
                       fold_reserved: bool) -> str:
    """Memoised body of :func:`quote_identifier_for_dialect`.

    Cached because the verification re-parses the rendered text, and on DuckDB
    also round-trips it through the engine.  MEASURED 2026-09-06, both engines
    warm: the DuckDB oracle is opened once in 9.4 ms; an UNSEEN name costs
    0.26 ms on duckdb against 0.07 ms on a sqlglot-only dialect, so the engine
    adds 0.20 ms; a REPEATED name costs 0.0004 ms.  A 200-column projection is
    therefore ~40 ms extra once per process and nothing per query.

    Note the second cache, on :func:`_engine_reads_as_column`.  It is not
    redundant with this one: this cache holds 8192 entries and a wide schema
    evicts, after which the inner cache is the only thing standing between a
    re-render and a fresh engine round trip.
    """
    open_q, close_q, fold = _ident_syntax(dialect)
    bare_ok = _ident_is_bare_safe(s)
    if not always_quote and bare_ok and s.lower() not in _SQL_RESERVED_WORDS:
        try:
            _verify_reads_back_as_identifier(s, s, dialect, s)
            return s
        except IdentifierRenderError:
            # QUOTE, do not refuse.  Reached from two places now: sqlglot
            # saying the bare token is not a column on this dialect, and (on
            # DuckDB) the ENGINE saying so over sqlglot's objection — the 39
            # names of 2026-09-06.  The handling is identical because the
            # conclusion is: an ordinary column whose bare form means
            # something else is a QUOTING problem, never a reason to fail a
            # query.
            #
            # The bare form does not mean a column on THIS engine, and the
            # 95-word ``_SQL_RESERVED_WORDS`` list could not have known: it is
            # one static list serving twelve grammars.  ``current_user``,
            # ``fetch``, ``lateral``, ``qualify``, ``tablesample``, ``using``,
            # ``localtimestamp``, Oracle's ``prior``, MySQL's ``ignore``,
            # T-SQL's ``top`` — 18 plausible column names in one sweep, each
            # of which used to be emitted BARE and silently mean a function,
            # a clause keyword or a parse error.  Quoting is the right answer,
            # not refusal, so fall through and quote.  This is the round-trip
            # check earning its cost twice: it is a gate AND the only thing
            # here that knows each dialect's actual vocabulary.
            pass
    body = s
    if fold_reserved and not always_quote and bare_ok:
        body = s.upper() if fold == "upper" else s.lower()
    expected = body
    if close_q in body:
        if dialect in _QUOTE_NOT_ESCAPABLE_BY_DOUBLING:
            raise IdentifierRenderError(
                f"Column {s!r} contains {close_q!r}, which cannot be "
                f"escaped inside a quoted identifier on '{dialect}'. "
                f"Refusing — any rendering would address a different "
                f"column or fail to parse."
            )
        body = body.replace(close_q, close_q * 2)
    rendered = open_q + body + close_q
    _verify_reads_back_as_identifier(rendered, expected, dialect, s)
    return rendered


def _quote_ident(name: str, dialect: Optional[str] = None) -> str:
    """Identifier rendering for the filter-wrap path.

    Thin alias for :func:`quote_identifier_for_dialect` kept because the name
    reads better at the call sites in this module.  ``dialect`` was added
    2026-09-05: this function used to hardcode the ANSI double quote, so a
    reserved-word or special-character column became a STRING LITERAL on
    Databricks / MySQL / BigQuery — a ``not_in`` filter on such a column
    turned into ``NOT 'order' IN (…)``, constant TRUE, and the predicate was
    silently dropped.  ``FilterWrapError``'s docstring says that must never
    happen, so an unrenderable identifier now raises.

    BARE WHERE SAFE, deliberately -- ``always_quote=True`` was tried here
    on 2026-09-05 and REVERTED the same hour.  The argument for it was that
    a column stored as ``MixedCase`` renders bare and folds to upper on
    Oracle/Snowflake; the argument against it is 32 failing tests across the
    DataFlow where-wrap and calendar-token suites, which assert the wrapped
    predicate an operator actually reads.  A narrow hypothesis does not
    outrank measured behaviour, and the renderer already VERIFIES the bare
    form by parsing it back with the target's own grammar -- a name that
    would not read back as a column is quoted automatically.  The
    catalog-case concern belongs where the catalog is read, not here.
    """
    return quote_identifier_for_dialect(name, dialect)


# Placeholder syntax that survives the rewrite ONLY through the
# subquery-wrap path (sqlglot rewrites :name to $name on round-trip,
# breaking JDBC/Oracle named-parameter binding).
_PLACEHOLDER_RE = re.compile(
    r"(?<![:\w])(?::[A-Za-z_][A-Za-z0-9_]*|@[A-Za-z_][A-Za-z0-9_]*)",
)


def _has_named_placeholders(sql: str) -> bool:
    """Return True if ``sql`` contains ``:name`` or ``@name`` style
    placeholder parameters.  ``?`` positional placeholders are safe
    (they survive AST round-trip on every dialect)."""
    if not sql or ":" not in sql and "@" not in sql:
        return False
    return bool(_PLACEHOLDER_RE.search(sql))


def _bare_column(raw: str) -> str:
    """Strip table prefix and surrounding quotes.

    The wrap selects from a derived table (``SELECT * FROM (...) AS
    _qs_pv_wrap``), so the inner table aliases are not addressable in
    the outer WHERE — we must reference the column by its bare name
    only.  Handles double-quoted, back-ticked, and bare identifiers.
    """
    if raw is None:
        return ""
    s = str(raw).strip()
    # Drop surrounding quoting so the prefix-strip can find the dot.
    if (s.startswith('"') and s.endswith('"')) or \
       (s.startswith("`") and s.endswith("`")):
        s = s[1:-1]
    if "." in s:
        s = s.rsplit(".", 1)[-1]
    # Inner identifier may have been quoted around just the table or
    # just the column — be defensive about residual quote chars.
    return s.strip().strip('"').strip("`")


def _sql_literal(v: Any, data_type: str = "") -> str:
    """Format a Python value as an inline SQL literal.

    Safe against SQL injection because all string values are
    single-quote escaped via quote-doubling (the only sequence that
    can break out of a SQL string literal in ANSI SQL is an unescaped
    ``'``).  Type-aware so numeric / boolean values render in their
    native form — important because Snowflake, Trino, and Postgres
    reject ``WHERE int_col = '42'`` in strict mode.
    """
    # 2026-08-13 -- DELEGATES to core.query_compiler.sql_literal.  This was
    # the "twin fix" the parquet_engine_v2 docstring refers to: one renderer
    # maintained in two places, which became THREE when federation_engine
    # grew its own.  That third copy had no typed-prefix passthrough and
    # broke Starburst date filters in production, so the copies are
    # collapsed.  The anchored typed-literal regex -- the 2026-08-03
    # injection fix documented above -- lives in the chokepoint and is
    # byte-identical to _TYPED_PREFIX_RE, so this path's security behaviour
    # is unchanged.
    #
    # ``data_type`` renders a date-typed column as a TYPED literal
    # (``DATE '2025-09-30'``), which Trino/Starburst, Snowflake and Oracle
    # require and DuckDB accepts.  Empty = unchanged behaviour.
    from core.query_compiler import sql_literal as _sql_lit
    return _sql_lit(v, data_type)


def _coerce_list(v: Any) -> List[Any]:
    """Normalise a filter value into a non-empty list.

    Bare-form filters parse ``?col=A,B,C`` into ``["A","B","C"]`` and
    ``?col=X`` into ``"X"`` — the operator decides which shape the
    value should take.  This helper makes the wrap robust against a
    scalar passed to an IN-like operator.  Empty lists return ``[]``
    so the caller can short-circuit and skip the condition entirely.
    """
    if v is None:
        return []
    if isinstance(v, (list, tuple, set)):
        out = [x for x in v if x is not None and x != ""]
        return out
    if isinstance(v, str):
        # Permit a single comma-separated string for IN-list operators.
        if "," in v:
            return [s.strip() for s in v.split(",") if s.strip() != ""]
        return [v] if v != "" else []
    return [v]


class FilterWrapError(ValueError):
    """A filter was requested but cannot be rendered into SQL.

    Raised instead of silently omitting the predicate.  Omission is not a
    degraded answer -- it is a WRONG one, in the dangerous direction: more
    rows than the caller asked for, returned as a success.
    """


class FilterValueRefused(FilterWrapError):
    """A filter VALUE that is not a value of its column's TYPE (2026-10-05).

    The CALLER's error: ``?dt=15/03/1995`` on a DATE column.  Rendering it
    as a quoted string would hand the source ``date = varchar`` (a TYPE_MISMATCH
    on Trino/Starburst, a 500 to the consumer); dropping it would return MORE
    rows.  So it refuses, naming the column, the type and the accepted
    formats -- answered 400 by ``api.connector_errors``.
    """

    def __init__(self, column: str, expected: str, value: Any, accepted: str):
        self.column = column
        self.expected = expected
        self.value = value
        self.accepted = accepted
        super().__init__(
            f"Filter value {value!r} for column '{column}' is not a "
            f"{expected}. '{column}' is a {expected} column; accepted "
            f"formats: {accepted}.")


#: How a caller spells a value of each non-temporal kind, for the 400.
_KIND_FORMATS = {
    "number": "a plain number (e.g. 42, -1.5, 1e3)",
    "boolean": "true / false (also t / f, yes / no, y / n, 1 / 0)",
}


def filter_value_kind(data_type: Any) -> str:
    """The rendering kind of a column type: ``date`` | ``timestamp`` |
    ``number`` | ``boolean`` | ``""`` (string, or unknown -- quoted, exactly
    as before).  Engine spellings (``timestamp(6)``, ``TIMESTAMP_NTZ``,
    ``NUMBER(38,0)``, ``decimal(18,2)``) and the product vocabulary
    (``date``, ``datetime``, ``integer``) go through ONE normaliser,
    ``core.column_types.normalise_sql_type``."""
    raw = str(data_type or "").strip().lower()
    if not raw:
        return ""
    try:
        from core.column_types import normalise_sql_type
        kind = normalise_sql_type(raw)
    except Exception:                                      # noqa: BLE001
        kind = ""
    return kind if kind in ("date", "timestamp", "number", "boolean") else ""


def typed_filter_literal(value: Any, data_type: Any, *,
                         dialect: Optional[str] = None,
                         column: str = "") -> str:
    """ONE filter value as a literal of its COLUMN's type, for ``dialect``.

    2026-10-05 -- the raw-SQL published view rendered every consumer value as
    a string literal whatever the column was, so every filter on a DATE /
    TIMESTAMP column of a SQL-sourced view on Trino was a 500
    (``Cannot apply operator: date = varchar(10)``).  The type comes from the
    COLUMN (the caller resolves it: the view's recorded schema, else the
    source's own description of the statement), never from the value's
    shape -- a varchar column holding '1995-03-15' stays a string compare.

    * unknown / string type -> today's rendering (``sql_literal``), never a
      refusal: an unknown type must not turn a working string filter into a 400;
    * a pre-formed typed literal (``DATE '2025-09-30'``, a publisher's static
      value) passes through;
    * date / timestamp -> :func:`core.query_compiler.typed_temporal_literal`
      (per dialect); number -> the bare digits; boolean -> TRUE / FALSE;
    * a value that is NOT of the type -> :class:`FilterValueRefused`.
    """
    from core.query_compiler import (
        TEMPORAL_FORMATS, _TYPED_LITERAL_RE, _numeric_literal, _parse_bool,
        typed_temporal_literal,
    )
    kind = filter_value_kind(data_type)
    if not kind or value is None:
        return _sql_literal(value, str(data_type or ""))
    if isinstance(value, str) and _TYPED_LITERAL_RE.match(value):
        return value
    if kind in ("date", "timestamp"):
        out = typed_temporal_literal(value, kind, dialect)
        if out is None:
            raise FilterValueRefused(column, kind, value, TEMPORAL_FORMATS[kind])
        return out
    if kind == "number":
        if isinstance(value, bool):
            raise FilterValueRefused(column, kind, value, _KIND_FORMATS[kind])
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                raise FilterValueRefused(column, kind, value, _KIND_FORMATS[kind])
            return repr(value)
        out = _numeric_literal(str(value))
        if out is None:
            raise FilterValueRefused(column, kind, value, _KIND_FORMATS[kind])
        return out
    # boolean
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    parsed = _parse_bool(str(value))
    if parsed is None:
        raise FilterValueRefused(column, kind, value, _KIND_FORMATS[kind])
    return "TRUE" if parsed else "FALSE"


def _column_type_for(column_types: Optional[dict], bare: str) -> str:
    """The type ``column_types`` gives ``bare`` -- exact spelling first, then
    case-insensitively (Trino reports ``dt``, Snowflake ``DT``; the
    consumer's key is whatever the URL said).  "" when not known."""
    if not column_types or not bare:
        return ""
    hit = column_types.get(bare)
    if hit:
        return str(hit)
    low = bare.lower()
    for k, v in column_types.items():
        if str(k).strip().strip('"').lower() == low and v:
            return str(v)
    return ""


def _build_condition(
    filt: Any,
    column_types: Optional[dict] = None,
    dialect: Optional[str] = None,
) -> Optional[str]:
    """Return one SQL condition for a single filter row, or ``None``
    when the filter is ABSENT rather than broken.

    ``dialect`` is the sqlglot dialect the condition will be executed on.
    2026-09-05: the condition used to be ANSI-only and was then handed to a
    reader for another dialect, so on Databricks / MySQL / BigQuery a quoted
    column name became a STRING LITERAL — ``'order' = 'x'`` (constant false,
    zero rows) and ``NOT 'order' IN (…)`` (constant true, the filter silently
    DROPPED and MORE rows returned).  Omitting the dialect keeps
    :data:`DEFAULT_DIALECT`, which is what every pre-existing caller meant.

    ``None`` means "nobody supplied a value for this optional filter" --
    a missing column, or no value on an operator that needs one.  A filter
    that WAS requested but cannot be expressed (unknown operator, a
    half-supplied BETWEEN) raises :class:`FilterWrapError` instead, because
    omitting it would widen the result set rather than narrow it.

    ``column_types`` maps bare column name -> semantic type
    (``string|number|date|boolean``).  A ``date`` column renders a TYPED
    literal (``DATE '2025-09-30'``) instead of a quoted string, because
    Trino/Starburst, Snowflake and Oracle reject
    ``date_col = '2025-09-30'`` in strict mode while DuckDB silently
    coerces it -- the ``Cannot apply operator: date = varchar(27)``
    reported 2026-08-13.  A filter row carrying its own ``data_type``
    wins over the map.  Unknown column, or no map, keeps the quoted
    string, so every existing caller is byte-identical.
    """
    # Accept dict OR Pydantic FilterModel-like object — defensive about
    # both shapes because the runtime mixes them along the publish ↔
    # execute path.
    if filt is None:
        return None
    _dt = ""
    if isinstance(filt, dict):
        col = filt.get("column")
        op = filt.get("operator") or "eq"
        val = filt.get("value")
        _dt = str(filt.get("data_type") or filt.get("type") or "")
    else:
        col = getattr(filt, "column", None)
        op = getattr(filt, "operator", "eq") or "eq"
        val = getattr(filt, "value", None)
        _dt = str(getattr(filt, "data_type", "") or "")

    bare = _bare_column(col)
    if not bare:
        return None
    try:
        qcol = _quote_ident(bare, dialect)
    except IdentifierRenderError as exc:
        # The column cannot be REFERENCED on this engine.  Skipping the
        # predicate is not a degraded answer, it is a wider one -- the exact
        # thing FilterWrapError exists to forbid.
        raise FilterWrapError(
            f"Filter on column '{bare}' cannot be rendered for this engine: "
            f"{exc}  Refusing to run the query without it -- dropping the "
            f"filter would return more rows than requested."
        ) from exc
    op = str(op).lower().strip()
    if not _dt and column_types:
        _dt = _column_type_for(column_types, bare)

    def _lit(v: Any) -> str:
        """Every literal on this row carries the COLUMN's type, rendered for
        this dialect; a value that is not of that type refuses (2026-10-05)."""
        return typed_filter_literal(v, _dt, dialect=dialect, column=bare)

    if op == "eq":
        if val is None:
            # Treat eq+None as IS NULL — matches what most consumers
            # mean when they write ``?col=`` against a nullable col.
            return f"{qcol} IS NULL"
        return f"{qcol} = {_lit(val)}"

    if op == "ne":
        if val is None:
            return f"{qcol} IS NOT NULL"
        return f"{qcol} <> {_lit(val)}"

    if op in ("gt", "gte", "lt", "lte"):
        if val is None:
            return None
        sym = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[op]
        return f"{qcol} {sym} {_lit(val)}"

    if op == "contains":
        if val is None:
            return None
        # 2026-08-19 -- this emitted ILIKE, which TRINO DOES NOT HAVE (nor
        # does Oracle).  The pushdown path hid it, because sqlglot transpiles
        # ILIKE to LOWER(..) LIKE LOWER(..) on the way out; the FALLBACK path
        # (named placeholders, unparseable SQL, PIVOT/MATCH_RECOGNIZE)
        # concatenates this string verbatim into the outer WHERE, so a
        # published view on Starburst died with a parse error.
        #
        # ``LOWER(col) LIKE LOWER('%v%')`` is the canonical portable spelling
        # already used by core.query_compiler._op_contains -- DuckDB, Trino,
        # Snowflake, Databricks, Oracle and Athena all accept it, so no
        # dialect branch is needed on either path.
        v = str(val).replace("'", "''")
        return f"LOWER({qcol}) LIKE LOWER('%{v}%')"

    if op == "not_contains":
        if val is None:
            return None
        v = str(val).replace("'", "''")
        return f"LOWER({qcol}) NOT LIKE LOWER('%{v}%')"

    if op in ("in", "not_in"):
        if val is None:
            # No value at all -- an optional Dynamic filter nobody filled
            # in (the merge keeps unfilled publisher rows with value=None).
            # Same ABSENT-vs-BROKEN split as gt/contains above: absent is
            # skipped, broken raises.
            return None
        items = _coerce_list(val)
        if not items:
            # 2026-08-20 -- a value WAS supplied but held nothing usable
            # ("" from ``?region__in=``, [], or a list of blanks).  This
            # used to ``return None``: the constraint was REMOVED with no
            # log, and a Published-API caller got the UNCONSTRAINED set
            # with HTTP 200 instead of an answer to the question they
            # asked.
            #
            # Semantics decision -- RAISE, do not render ``1=0`` / ``1=1``:
            #   * The other two renderers already promise an error for this
            #     input: core.query_compiler._require_nonempty_list
            #     (code "filter_empty_in_list") and
            #     federation_engine._filter_to_sql ("no usable values").
            #     The same request must not 400 on the compiler-backed
            #     route and 200 on the raw-SQL route.
            #   * ``IN ()`` matching nothing is defensible, but at THIS
            #     layer "" / [] is indistinguishable from a broken upstream
            #     expansion (a parameter substitution that produced
            #     nothing) -- and zero rows with HTTP 200 for a glitch is
            #     the same "indistinguishable from a correct answer"
            #     failure, just inverted.  The error tells the caller how
            #     to say what they meant.
            raise FilterWrapError(
                f"Filter '{op}' on column '{bare}' has no usable values "
                f"({val!r}).  An empty IN () is invalid SQL — supply at "
                f"least one value or omit the filter.  Refusing to run "
                f"the query without it: dropping the filter would return "
                f"more rows than requested."
            )
        rendered = ", ".join(_lit(x) for x in items)
        op_word = "NOT IN" if op == "not_in" else "IN"
        return f"{qcol} {op_word} ({rendered})"

    if op == "between":
        items = _coerce_list(val)
        if not items:
            # No bounds supplied at all -- an optional filter nobody filled in.
            return None
        if len(items) < 2:
            # But a HALF-supplied BETWEEN is a broken request, not an absent
            # one: silently dropping it returns every row outside the range
            # the caller asked for.
            raise FilterWrapError(
                f"Filter 'between' on column '{bare}' needs a [low, high] "
                f"pair; got {val!r}."
            )
        lo, hi = items[0], items[1]
        return f"{qcol} BETWEEN {_lit(lo)} AND {_lit(hi)}"

    if op == "is_null":
        return f"{qcol} IS NULL"

    if op == "is_not_null":
        return f"{qcol} IS NOT NULL"

    # 2026-08-19 -- this used to `return None` and call itself "the safer
    # fail-open".  It is not safe.  Dropping a filter does not degrade the
    # answer, it WIDENS it: the query returns MORE rows than the caller
    # asked for, and the Published API serves them with HTTP 200.  A filter
    # is a correctness gate, and a correctness gate must FAIL -- only a cap
    # may quietly throttle.
    #
    # The old reasoning (a malformed snapshot must not break every request)
    # is answered by the split above: a filter nobody supplied a value for
    # is still skipped, because that is an ABSENT filter rather than an
    # unrenderable one.  What raises here is a filter that was asked for and
    # cannot be expressed.
    raise FilterWrapError(
        f"Unsupported filter operator '{op}' on column '{bare}'. "
        f"Refusing to run the query without it -- dropping the filter would "
        f"return more rows than requested."
    )


def _select_is_safe_for_pushdown(select_node) -> bool:
    """Return True if the given SELECT can safely receive an extra
    AND'd predicate without changing semantics.

    Unsafe shapes:
      - GROUP BY (filter without the grouped column would HAVING-shift)
      - HAVING already present (predicate is on aggregates)
      - Window functions in the projection (filter ordering matters)
      - Aggregate functions in the projection without GROUP BY (still
        changes semantics if the predicate is on a non-aggregated col)
      - LIMIT / OFFSET / FETCH — pushdown filters rows BEFORE the row
        cap, which changes what the cap actually returns.  E.g.
        ``SELECT * FROM t ORDER BY ts DESC LIMIT 100`` + filter
        ``region='EU'`` would become "top 100 EU rows", not "top 100
        rows of which some happen to be EU" (the original).  Fall back
        to the subquery wrap so the row cap stays applied to the
        publisher's intended row set.

    Safe:
      - Plain SELECT * / SELECT col1, col2 with no GROUP BY / agg /
        window / row-cap — partition pruning works correctly.
      - SELECT with an existing WHERE (predicate is AND'd, no semantic
        change).
      - SELECT DISTINCT — distinct values among the filtered set IS
        the user-expected behaviour.
      - ORDER BY without LIMIT (sort doesn't change which rows are
        returned, only their order).
    """
    try:
        from sqlglot import exp
    except ImportError:
        return False
    if select_node.args.get("group") is not None:
        return False
    if select_node.args.get("having") is not None:
        return False
    # Row caps — applying a filter BEFORE the cap changes which rows
    # the cap returns.  Skip pushdown here; outer wrap preserves the
    # publisher's "top N" semantics.
    if select_node.args.get("limit") is not None:
        return False
    if select_node.args.get("offset") is not None:
        return False
    # Window functions
    if any(e.find(exp.Window) is not None
           for e in (select_node.expressions or [])):
        return False
    # Bare aggregate in projection without GROUP BY = whole-table agg.
    aggregate_classes = (exp.Sum, exp.Count, exp.Avg, exp.Min, exp.Max)
    if any(e.find(aggregate_classes) is not None
           for e in (select_node.expressions or [])):
        return False
    return True


def _and_predicate_onto_select(select_node, predicate_node) -> None:
    """Mutate ``select_node`` so its WHERE clause picks up
    ``predicate_node`` as an additional AND term.  Creates the WHERE
    when there isn't one.

    Bug fix: the existing predicate is wrapped in ``Paren(...)`` before
    AND-ing.  Without this, an existing ``WHERE a='US' OR b='EU'``
    became ``WHERE a='US' OR b='EU' AND year=2026`` — and SQL
    precedence binds AND tighter than OR, so the result evaluated as
    ``a='US' OR (b='EU' AND year=2026)`` — completely wrong.  Wrapping
    the existing condition (and the new predicate) in parens enforces
    the intended ``(<existing>) AND (<new>)`` semantics regardless of
    either side's internal precedence.
    """
    try:
        from sqlglot import exp
    except ImportError:
        return
    existing_where = select_node.args.get("where")
    if existing_where is not None and existing_where.this is not None:
        merged = exp.And(
            this=exp.Paren(this=existing_where.this),
            expression=exp.Paren(this=predicate_node),
        )
        select_node.set("where", exp.Where(this=merged))
    else:
        # Single predicate — paren it anyway for symmetry + safety
        # against future AND-merge passes.
        select_node.set("where",
                          exp.Where(this=exp.Paren(this=predicate_node)))


# Phase 134-M (audit follow-up) — REPLACE semantics for Dynamic columns.
# Pre-fix code only AND-ed the consumer-supplied predicate onto the
# existing WHERE, so a hardcoded ``WHERE business_close_date='2025-09-30'``
# in the publisher's raw_sql + a consumer override of
# ``?business_close_date=2025-09-29`` produced
# ``WHERE (business_close_date='2025-09-30') AND (business_close_date='2025-09-29')``
# → 0 rows.  Dynamic columns must REPLACE the existing predicate, not
# AND with it.


def _node_predicate_target_columns(node) -> set:
    """Return the set of (lowercased, prefix-stripped) column names a
    predicate node references on either side.

    Only looks at IMMEDIATE column refs — ``func(col) = X`` doesn't
    count because the publisher meant something specific by the
    transform (we'd corrupt their intent if we removed it on a bare
    column name match).
    """
    try:
        from sqlglot import exp
    except ImportError:
        return set()
    cols: set = set()
    # Predicates we recognise as "replaceable" — leaf comparisons /
    # membership / range / null tests.  Function calls and CASE
    # expressions are intentionally OUT of scope (they're not bare
    # column comparisons; removing them would silently corrupt the
    # publisher's intended logic).
    REPLACEABLE = (
        exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE,
        exp.In, exp.Between, exp.Like, exp.ILike, exp.Is,
    )
    if not isinstance(node, REPLACEABLE):
        return set()
    # Both sides — handles `col = 'x'` AND `'x' = col` (the latter is
    # unusual but valid).
    for side in (node.args.get("this"), node.args.get("expression")):
        if isinstance(side, exp.Column):
            name = side.name
            # Strip quoting + table prefix to match the col_key contract.
            bare = name.split(".")[-1].replace('"', "").replace("`", "")
            cols.add(bare.lower())
    return cols


def _node_predicate_qualifiers(node) -> dict:
    """Phase 132.38 deep-dive R5 (2026-06-26) -- map ``{col_lower:
    table_alias}`` for every leaf-referenced column in the predicate.
    Empty alias when the column is referenced unqualified.  Used by
    the REPLACE path to re-qualify the new predicate so JOINs that
    expose the same column on both sides don't become "ambiguous
    reference" BinderExceptions at execute time.
    """
    try:
        from sqlglot import exp
    except ImportError:
        return {}
    out: dict = {}
    REPLACEABLE = (
        exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE,
        exp.In, exp.Between, exp.Like, exp.ILike, exp.Is,
    )
    if not isinstance(node, REPLACEABLE):
        return out
    for side in (node.args.get("this"), node.args.get("expression")):
        if isinstance(side, exp.Column):
            bare = side.name.split(".")[-1].replace('"', "").replace("`", "").lower()
            table = side.table or ""
            # Only record when we DON'T already have a qualifier for
            # this column (don't clobber a prior strip that had one).
            if bare and bare not in out:
                out[bare] = table
    return out


def _strip_predicates_for_columns(where_root, dynamic_cols: set) -> tuple:
    """Walk an AND/OR/Paren tree rooted at ``where_root`` and return
    ``(new_root, removed_count)`` where ``new_root`` is the tree minus
    every leaf predicate that references a column in ``dynamic_cols``.

    Removal rules:
      * Top-level AND chain — drop matching leaves; if all drop, the
        whole WHERE goes away.
      * OR branches — we DON'T descend into OR because removing one
        branch of ``(a=1 OR business_close_date='2025-09-30')`` would
        widen the result set (publisher meant either-or; we'd turn
        it into just ``a=1`` which is more permissive).  OR branches
        stay intact.
      * Paren — descend into the inner expression.

    Conservative on purpose: when in doubt KEEP the predicate, never
    silently drop one that might preserve meaning.
    """
    try:
        from sqlglot import exp
    except ImportError:
        return (where_root, 0)
    if where_root is None or not dynamic_cols:
        return (where_root, 0)

    dyn_lower = {c.lower() for c in dynamic_cols}

    # Phase 132.38 R5 -- collect qualifiers from stripped predicates
    # so the push site can re-qualify the new predicate (avoids
    # JOIN ambiguity).
    stripped_qualifiers: dict = {}

    def _walk(node):
        if isinstance(node, exp.Paren):
            inner, n = _walk(node.this)
            if inner is None:
                return (None, n)
            return (exp.Paren(this=inner), n)
        if isinstance(node, exp.And):
            left, ln = _walk(node.this)
            right, rn = _walk(node.expression)
            removed = ln + rn
            if left is None and right is None:
                return (None, removed)
            if left is None:
                return (right, removed)
            if right is None:
                return (left, removed)
            return (exp.And(this=left, expression=right), removed)
        # OR — do NOT descend (see docstring rationale).
        if isinstance(node, exp.Or):
            return (node, 0)
        # Leaf predicate — drop if it targets a dynamic column.
        target_cols = _node_predicate_target_columns(node)
        if target_cols & dyn_lower:
            # Capture qualifiers for the dropped column(s) so the
            # push site can re-qualify the new predicate.
            for col, qual in _node_predicate_qualifiers(node).items():
                if col in dyn_lower and col not in stripped_qualifiers:
                    stripped_qualifiers[col] = qual
            return (None, 1)
        return (node, 0)

    new_root, removed = _walk(where_root)
    # Stash qualifiers on the function attribute so the caller can
    # read them.  (Tuple-return would propagate through too many
    # call sites; module-attribute stash is fail-OPEN -- absence
    # means empty.)
    _strip_predicates_for_columns._last_qualifiers = stripped_qualifiers  # type: ignore
    return (new_root, removed)


def _remove_dynamic_predicates(select_node, dynamic_cols: set) -> int:
    """Convenience wrapper — strip predicates from ``select_node``'s
    WHERE clause for every column in ``dynamic_cols``.  Returns the
    removed-predicate count (0 when nothing matched).
    """
    try:
        from sqlglot import exp
    except ImportError:
        return 0
    where = select_node.args.get("where")
    if where is None or where.this is None or not dynamic_cols:
        return 0
    new_root, removed = _strip_predicates_for_columns(where.this, dynamic_cols)
    if removed == 0:
        return 0
    if new_root is None:
        # WHERE wholly emptied — drop the clause.  sqlglot accepts
        # set('where', None) to remove the arg.
        select_node.set("where", None)
    else:
        select_node.set("where", exp.Where(this=new_root))
    return removed


def _collect_safe_select_positions(tree):
    """Whitelist of SELECT nodes that can safely receive an extra
    AND'd predicate.

    A SELECT is safe IF AND ONLY IF it appears in a COMPOSITIONAL
    position — meaning the rows it produces are the rows the outer
    consumer sees (modulo joins / set ops).  Unsafe positions are
    EXPRESSION positions where the SELECT is being used as a value
    or a row-existence test:

      ✓ Top-level SELECT (the consumer's query).
      ✓ Branches of a top-level UNION / INTERSECT / EXCEPT.
      ✓ CTE bodies — but ONLY non-recursive ones (recursive CTE
        bodies repeat themselves and the filter column may not exist
        in the base case).
      ✓ Subqueries used as derived tables in FROM (``FROM (SELECT…) sub``).
      ✓ Subqueries used in JOIN ON's right side (``JOIN (SELECT…) j ON …``).

      ✗ Subqueries in WHERE / HAVING expressions:
        - ``WHERE col IN (SELECT …)`` — that inner SELECT is doing a
          lookup, not producing the user's rows.
        - ``WHERE EXISTS (SELECT …)`` — same.
        - ``WHERE col = (SELECT … LIMIT 1)`` — scalar subquery.
      ✗ Scalar subqueries in the SELECT projection list:
        - ``SELECT (SELECT MAX(x) FROM …) AS max_x FROM …``
      ✗ Recursive CTE bodies (``WITH RECURSIVE``).

    Pushing into any unsafe position changes semantics: the IN-subquery
    table likely doesn't have the override column, the recursive base
    case shouldn't be filtered, etc.

    Returns a set of safe Select nodes.  Use object identity for set
    membership — sqlglot AST nodes are hashable by object id.
    """
    try:
        from sqlglot import exp
    except ImportError:
        return set()

    safe = set()

    def _visit(node, in_safe_position: bool, in_recursive_cte: bool):
        """Recursively classify each SELECT's position."""
        if isinstance(node, exp.Select):
            if in_safe_position and not in_recursive_cte:
                safe.add(id(node))

            # CTE definitions on this SELECT — sqlglot stores them on
            # ``Select.args["with_"]`` (trailing underscore because
            # ``with`` is a Python keyword).  Each CTE body is a safe
            # position UNLESS the WITH is recursive.
            with_node = node.args.get("with_") or node.args.get("with")
            if with_node is not None:
                _visit(with_node, True, in_recursive_cte)

            # Walk into the FROM clause (``from_`` for same keyword
            # reason) — subqueries there are safe.
            from_clause = node.args.get("from_") or node.args.get("from")
            if from_clause is not None:
                _visit(from_clause, True, in_recursive_cte)

            # JOINS — their right-side tables are also safe positions.
            for join in (node.args.get("joins") or []):
                _visit(join, True, in_recursive_cte)

            # WHERE / HAVING — any subqueries inside are UNSAFE.
            for key in ("where", "having", "qualify"):
                sub = node.args.get(key)
                if sub is not None:
                    _visit(sub, False, in_recursive_cte)

            # Projection list (SELECT … ,) — subqueries here are
            # SCALAR, UNSAFE.
            for proj in (node.expressions or []):
                _visit(proj, False, in_recursive_cte)

            # ORDER BY / GROUP BY expressions — also unsafe positions
            # if they contain a subquery.
            for key in ("group", "order", "limit", "offset"):
                sub = node.args.get(key)
                if sub is not None:
                    _visit(sub, False, in_recursive_cte)
            return

        if isinstance(node, exp.With):
            # CTEs.  Each CTE body is a safe position UNLESS this WITH
            # is RECURSIVE — then the body refers to itself and the
            # column may not exist in the base case.
            recursive = bool(node.args.get("recursive"))
            for cte in (node.expressions or []):
                _visit(cte, True, in_recursive_cte or recursive)
            return

        if isinstance(node, exp.CTE):
            # The CTE's inner expression is what we want to recurse into.
            inner = node.this
            if inner is not None:
                _visit(inner, True, in_recursive_cte)
            return

        if isinstance(node, exp.Union):
            # Top-level UNION / INTERSECT / EXCEPT — each side is a
            # branch the outer consumer sees, so safe.  Recurse.
            for side in (node.this, node.expression):
                if side is not None:
                    _visit(side, in_safe_position, in_recursive_cte)
            return

        # Generic recursion — walk into args but DON'T promote unsafe
        # positions to safe.  This is the catch-all for everything not
        # handled explicitly above (Subquery, In, Exists, scalar
        # expressions, etc.).
        for child in node.args.values():
            if isinstance(child, exp.Expression):
                _visit(child, in_safe_position, in_recursive_cte)
            elif isinstance(child, list):
                for c in child:
                    if isinstance(c, exp.Expression):
                        _visit(c, in_safe_position, in_recursive_cte)

    _visit(tree, True, False)
    return safe


def _push_predicate_to_all_safe_selects(
    tree, predicate_text: str, dialect: str,
    dynamic_cols: Optional[set] = None,
) -> bool:
    """Walk ``tree`` and AND ``predicate_text`` onto every safe SELECT —
    where "safe" is the whitelist defined in
    ``_collect_safe_select_positions``.  Outermost + CTE bodies (non-
    recursive) + FROM-clause subqueries + UNION branches.  IN /
    EXISTS / scalar subqueries are SKIPPED to preserve correctness.

    Phase 134-M — ``dynamic_cols`` carries the lowercased column names
    of Dynamic-mode WHERE rows.  For every safe SELECT, we FIRST
    remove any existing leaf predicate referencing those columns (so
    the publisher's hardcoded value doesn't AND with the consumer's
    override), THEN add the new predicate.  ``dynamic_cols=None`` /
    empty preserves pre-fix behaviour (pure AND, no removal).

    Returns True if at least one SELECT was mutated.
    """
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        return False

    # Parse the predicate ONCE; clone per insertion site so each
    # SELECT gets an independent AST node (sqlglot trees don't like
    # sharing nodes across parents).
    #
    # CRITICAL: if the predicate text doesn't parse cleanly into a
    # boolean expression, we MUST NOT fall back to ``exp.Anonymous`` —
    # Anonymous renders as a function call (``("region" = 'EU')()``),
    # producing invalid SQL.  Instead, return False so the caller
    # uses the subquery wrap, which concatenates the predicate text
    # directly into the outer WHERE without re-parsing.
    pred_root = None
    try:
        pred_root = sqlglot.parse_one(predicate_text, read=dialect)
        if isinstance(pred_root, exp.Select) and pred_root.args.get("where"):
            pred_root = pred_root.args["where"].this
    except Exception:
        pred_root = None
    if pred_root is None or isinstance(pred_root, exp.Anonymous):
        # Predicate can't be embedded into the AST safely — let the
        # caller use the subquery-wrap fallback.
        return False

    safe_ids = _collect_safe_select_positions(tree)
    if not safe_ids:
        return False

    # Phase 132.38 deep-dive R4 (2026-06-26) -- collect CTE alias names
    # so we can skip pushdown into SELECTs whose FROM source is a CTE
    # alias that may not expose the dynamic column in its projection.
    # CTE body pushdown still happens (the body's SELECT is also in
    # safe_ids).  Pushing into the outer SELECT that pulls FROM the
    # CTE alias would reference a column not in the CTE's projection
    # -> BinderException at execute time.
    cte_names: set = set()
    try:
        for cte in tree.find_all(exp.CTE):
            _alias = cte.alias_or_name
            if _alias:
                cte_names.add(_alias.lower())
    except Exception:
        pass

    def _from_source_is_cte_only(select) -> bool:
        """True when EVERY FROM source on this SELECT references a
        CTE alias (no real base tables).  In that case the column
        being pushed must exist in the CTE's projection -- we can't
        safely assume it does."""
        if not cte_names:
            return False
        # sqlglot uses ``from_`` (trailing underscore -- ``from`` is a
        # Python keyword).  Some older versions used ``from`` directly.
        from_node = select.args.get("from_") or select.args.get("from")
        if from_node is None:
            return False
        # sqlglot stores the From with .this (single source) or
        # .expressions (multi-source comma-style).  Walk all
        # immediate Table children.
        tables = list(from_node.find_all(exp.Table))
        if not tables:
            return False
        for t in tables:
            # If ANY source is NOT a CTE alias, the SELECT has a real
            # table base -- pushdown is safe (column likely exists).
            if (t.name or "").lower() not in cte_names:
                return False
        return True

    def _select_projects_column(select, col_lower: str) -> bool:
        """True when the SELECT's projection (or ``SELECT *``) exposes
        the named column to a consumer.  ``SELECT *`` returns True
        because the outer caller can reference any column from the
        FROM source."""
        for proj in (select.expressions or []):
            if isinstance(proj, exp.Star):
                return True
            # Strip any Alias wrapper to find the underlying expression.
            inner = proj.this if isinstance(proj, exp.Alias) else proj
            if isinstance(inner, exp.Column):
                col = (inner.name or "").lower()
                if col == col_lower:
                    return True
            elif isinstance(inner, exp.Star):
                return True
        return False

    dyn = dynamic_cols or set()
    dyn_lower = {c.lower() for c in dyn}
    pushed = False
    for select in tree.find_all(exp.Select):
        if id(select) not in safe_ids:
            continue
        # Phase 132.38 deep-dive R3 (2026-06-26) -- "Dynamic-column
        # pushdown is always safe" exception.  When the caller marked
        # a column Dynamic, it's by-definition a filter column (NOT
        # an aggregate or window).  Pushing ``WHERE dyn_col = X``
        # BEFORE GROUP BY / HAVING / ORDER BY / LIMIT is mathematically
        # safe SQL semantics -- it filters rows before any aggregation
        # / row-cap / window happens.
        is_dyn_push_safe = False
        stripped_qualifiers: dict = {}
        if dyn:
            # Phase 132.38 R4 -- gate by CTE-source check.  If THIS
            # SELECT's FROM is ENTIRELY CTE aliases, only push when
            # the CTE projection exposes the dynamic column (so the
            # outer reference resolves at execute time).  Otherwise
            # the inner CTE body pushdown is enough.
            if _from_source_is_cte_only(select):
                # Check each CTE body in the WITH for whether it
                # projects ANY of the dynamic columns.
                projects_any_dyn = False
                for cte in tree.find_all(exp.CTE):
                    body = cte.this
                    if not isinstance(body, exp.Select):
                        continue
                    for dl in dyn_lower:
                        if _select_projects_column(body, dl):
                            projects_any_dyn = True
                            break
                    if projects_any_dyn:
                        break
                if not projects_any_dyn:
                    # CTE doesn't expose the dynamic col -- pushing
                    # here would BinderException.  Skip the outer
                    # SELECT; the inner CTE body still gets the push.
                    continue
            # Strip any existing leaf predicates first (REPLACE).
            _remove_dynamic_predicates(select, dyn)
            # Phase 132.38 R5 -- capture qualifiers from the strip
            # so the new predicate can be re-qualified to avoid
            # JOIN ambiguity ("Ambiguous reference to column ...").
            stripped_qualifiers = dict(
                getattr(_strip_predicates_for_columns,
                         "_last_qualifiers", None) or {}
            )
            # Greenlight pushdown for THIS SELECT because dyn_cols is
            # set + the CTE source guard above passed.
            is_dyn_push_safe = True
        if not is_dyn_push_safe and not _select_is_safe_for_pushdown(select):
            continue
        # Each SELECT gets its own clone so the AST stays tree-shaped.
        # Phase 132.38 R5 -- re-qualify the predicate's column refs
        # using the qualifiers we captured from the strip.  Only
        # touches column refs whose table alias is empty AND who
        # match a stripped column -- preserves the publisher's
        # original FROM identity for the override.
        pred_clone = pred_root.copy()
        if stripped_qualifiers:
            try:
                for col_node in pred_clone.find_all(exp.Column):
                    bare = (col_node.name or "").lower()
                    qual = stripped_qualifiers.get(bare)
                    if qual and not col_node.table:
                        col_node.set("table", exp.to_identifier(qual))
            except Exception:
                pass
        # 2026-10-24 (rig, the owner's cross-source API): a filter names the
        # column the CONSUMER sees -- often an output ALIAS
        # (``sap_company_id AS co``), which no engine resolves in the same
        # SELECT's WHERE (Trino: "Column 'co' cannot be resolved" -> 500).
        # An alias of a plain column is pushed as that column (pruning
        # kept); an alias of an EXPRESSION cannot be pushed here, so this
        # SELECT is skipped (none pushed -> the caller's subquery wrap).
        pred_clone = _resolve_projection_aliases(select, pred_clone)
        if pred_clone is None:
            # ALL or nothing (security review): a SELECT that cannot take the
            # predicate must not leave it applied to only SOME branches (a
            # UNION branch unfiltered = more rows).  The caller re-parses the
            # ORIGINAL text and applies the subquery wrap to everything.
            return False
        _and_predicate_onto_select(select, pred_clone)
        pushed = True
    return pushed


def _resolve_projection_aliases(select, pred):
    """``pred`` with each unqualified column that names one of ``select``'s
    projection ALIASES replaced by the aliased plain column; None when a
    referenced alias stands for an expression (not pushable into WHERE).
    A name that is a real column of the projection as well stays as is."""
    from sqlglot import exp
    aliases, plain = {}, set()
    for proj in (select.expressions or []):
        if isinstance(proj, exp.Alias):
            aliases[(proj.alias or "").lower()] = proj.this
        elif isinstance(proj, exp.Column):
            plain.add((proj.name or "").lower())
    if not aliases:
        return pred
    for col in list(pred.find_all(exp.Column)):
        name = (col.name or "").lower()
        if col.table or name not in aliases or name in plain:
            continue
        target = aliases[name]
        if not isinstance(target, exp.Column):
            return None
        if (target.name or "").lower() == name and not target.table:
            continue
        col.replace(target.copy())
    return pred


def _inject_filters_into_select(
    raw_sql: str,
    conditions: List[str],
    glue: str,
    dialect: str = "duckdb",
    dynamic_cols: Optional[set] = None,
) -> Optional[str]:
    """sqlglot-based PUSHDOWN at EVERY safe level: outermost SELECT +
    every CTE body + every FROM-clause subquery + every UNION branch.

    Returns ``None`` when sqlglot is unavailable OR the SQL doesn't
    parse cleanly — the caller falls back to the subquery wrap.

    Why all levels (not just outer)
    --------------------------------
    Modern engines DO push outer predicates through simple subqueries
    automatically, BUT:
      - CTEs are an optimizer barrier on many engines (Trino doesn't
        inline non-trivial CTEs; Snowflake materialises some).
      - Sub-selects with DISTINCT, LIMIT, or specific dialects break
        automatic pushdown.
      - Iceberg manifest pruning only kicks in when the filter is
        attached to the SELECT that actually scans the table.

    So we explicitly walk the tree and AND the predicate onto every
    SAFE SELECT (no GROUP BY, no HAVING, no window funcs, no bare
    aggregates in projection — see _select_is_safe_for_pushdown).

    For multi-statement scripts or anything that doesn't have a
    parseable outermost SELECT (DDL, CTAS, INSERT...SELECT, top-level
    UNION needing per-branch pushdown into branches that themselves
    aren't simple), this returns None and the caller uses the
    subquery wrap.
    """
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        return None
    try:
        tree = sqlglot.parse_one(raw_sql, read=dialect)
    except Exception:
        return None
    if tree is None:
        return None

    # Top-level statement must be SELECT-like.  DDL / DML / CTAS go to
    # the subquery wrap so we don't accidentally rewrite the wrong scope.
    if not isinstance(tree, (exp.Select, exp.Union)):
        return None

    glue_upper = glue.strip().upper() or "AND"

    # Build the combined predicate text once (for all-levels insertion).
    if glue_upper == "AND":
        combined_text = " AND ".join(f"({c})" for c in conditions)
    else:
        combined_text = " OR ".join(f"({c})" for c in conditions)

    pushed = _push_predicate_to_all_safe_selects(
        tree, combined_text, dialect, dynamic_cols=dynamic_cols,
    )
    if not pushed:
        # Top-level was unsafe AND no inner SELECT was safe either —
        # caller falls back to the subquery wrap.
        return None

    try:
        return tree.sql(dialect=dialect)
    except Exception:
        return None


#: The dialect answered for a connection type nobody has mapped.
#:
#: "Cannot tell" must NOT become "refuse" here.  This resolver feeds a
#: REWRITE (filter injection, RLS, lineage) whose failure mode is a
#: dropped predicate, so its posture is a cap: pick the broadest grammar
#: and keep working.  The sibling question -- "may generated SQL be
#: SHIPPED to this engine at all" -- is a correctness GATE and lives in
#: :mod:`core.sql_connector_dialect`, which refuses an unknown type.
#: Same word ("dialect"), two questions, two deliberate postures.
DEFAULT_DIALECT = "duckdb"

#: THE connection-type -> sqlglot dialect vocabulary.  One map, one answer.
#:
#: 2026-09-05 -- there were several.  ``core/feed/rls.py`` carried a second
#: copy and ``api/published_views_api.py`` a third, both citing
#: ``api/reports_api._RS_DIALECT_MAP`` as their origin.  They DISAGREED on
#: ``athena`` and each omitted types the others knew, so the same saved
#: query was parsed as three different languages depending on which
#: surface ran it -- reports, feeds or the published API.  A decision made
#: twice is a bug: two ENGINES is fine, two ANSWERS to the same question
#: is not.  Every consumer resolves through
#: :func:`dialect_for_connection_type`; nothing may re-declare this map
#: (``tests/test_query_dialect_contract_2026_09_05.py`` fails the build on
#: a second one).
#:
#: ATHENA -- the convergence, decided rather than voted.  The copies said
#: ``trino`` ("Presto grammar"), a workaround from before sqlglot had an
#: Athena dialect.  It has one now, and it is not a Trino alias: sqlglot's
#: ``Athena`` is a ROUTER that tokenizes, parses and generates DML (SELECT
#: / INSERT / UPDATE / DELETE / MERGE) with Trino's implementation and DDL
#: with Hive's -- because that is what the AWS service itself does.  Every
#: consumer of this map rewrites SELECT statements only (DML/DDL is
#: refused by ``_is_dml_statement`` before a dialect is ever chosen), so
#: ``athena`` and ``trino`` emit BYTE-IDENTICAL SQL: converging changes no
#: query any deployed feed or view runs today.  ``athena`` is still the
#: right answer -- it names the engine actually being addressed, so an
#: Athena-specific divergence in a future sqlglot lands on the dialect
#: that carries the name instead of silently riding on Trino's.
CONNECTION_TYPE_DIALECTS: Dict[str, str] = {
    "trino":          "trino",
    "starburst":      "trino",
    "snowflake":      "snowflake",
    "databricks":     "databricks",
    "oracle":         "oracle",
    "athena":         "athena",
    "presto":         "presto",
    "redshift":       "redshift",
    "bigquery":       "bigquery",
    "postgresql":     "postgres",
    "postgres":       "postgres",
    "mysql":          "mysql",
    "sqlserver":      "tsql",
    "mssql":          "tsql",
    "duckdb":         "duckdb",
    # s3 / aws_s3 / local / upload / parquet / csv are read by DuckDB in
    # this process, so they take DEFAULT_DIALECT via the fallback -- the
    # same answer the deleted copies spelled out entry by entry.
}


def dialect_for_connection_type(connection_type: Optional[str]) -> str:
    """Map a QueryStudio connection-type slug to a sqlglot dialect.

    THE resolver.  Reports, feeds and the published-view API all reach
    this function; a caller that keeps its own map will drift from the
    other two and the same query will mean different things on different
    surfaces.

    Returns :data:`DEFAULT_DIALECT` (``"duckdb"``) when the type is
    unknown or absent -- sqlglot's duckdb grammar is closest to ANSI SQL
    and accepts the broadest set of inputs, so it is the safest fallback
    for a rewrite.  Callers should pass the result via the ``dialect``
    kwarg on ``wrap_sql_with_filters`` so the rewriter:
      - preserves dialect-specific syntax (Oracle hints, Snowflake
        named-arg function calls, Trino lambda syntax)
      - renders identifiers in the dialect's native casing /
        quoting (Oracle case-folds, Snowflake quoted = case-sensitive)
      - keeps engine-specific keywords intact through the round-trip
    """
    if not connection_type:
        return DEFAULT_DIALECT
    t = str(connection_type).strip().lower()
    return CONNECTION_TYPE_DIALECTS.get(t, DEFAULT_DIALECT)


def _is_dml_statement(raw_sql: str, dialect: str = "duckdb") -> bool:
    """Return True if ``raw_sql`` is a DML / DDL statement at the top
    level (INSERT, UPDATE, DELETE, MERGE, CREATE TABLE AS, ...).

    Wrapping a DML statement as ``SELECT * FROM (<dml>)`` produces
    invalid SQL on every engine, so the caller must return the
    publisher's SQL UNCHANGED for these shapes — silently dropping the
    consumer filter is the lesser evil compared to a 100% runtime
    syntax error.

    Detection is best-effort.  When sqlglot is missing or the SQL
    doesn't parse, fall back to a quick keyword sniff on the first
    non-comment token.
    """
    if not raw_sql:
        return False
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        # Fallback: keyword sniff on the first non-comment word.
        stripped = raw_sql.lstrip()
        # Strip leading -- ... comments
        while stripped.startswith("--"):
            nl = stripped.find("\n")
            stripped = (stripped[nl + 1:].lstrip() if nl >= 0 else "")
        first = stripped.split(None, 1)[0].upper() if stripped else ""
        return first in {"INSERT", "UPDATE", "DELETE", "MERGE",
                         "CREATE", "DROP", "ALTER", "TRUNCATE"}
    try:
        tree = sqlglot.parse_one(raw_sql, read=dialect)
    except Exception:
        return False
    if tree is None:
        return False
    # DML / DDL class names vary across sqlglot versions (AlterTable
    # was collapsed into Alter in newer releases).  Resolve at runtime
    # so the check stays robust across upgrades.
    DML_CLASS_NAMES = ("Insert", "Update", "Delete", "Merge",
                       "Create", "Drop", "Alter", "AlterTable",
                       "TruncateTable", "Truncate")
    dml_types = tuple(
        cls for cls in (getattr(exp, name, None) for name in DML_CLASS_NAMES)
        if cls is not None and isinstance(cls, type)
    )
    return bool(dml_types) and isinstance(tree, dml_types)


def wrap_sql_with_filters(
    raw_sql: Optional[str],
    filters: Optional[Iterable[Any]],
    *,
    alias: str = "_qs_pv_wrap",
    filter_logic: str = "AND",
    dialect: str = "duckdb",
    dynamic_columns: Optional[Iterable[str]] = None,
    column_types: Optional[dict] = None,
) -> Optional[str]:
    """Apply filters to ``raw_sql`` so the engine can prune partitions.

    Two strategies, picked in order:

    1. PUSHDOWN (preferred — preserves partition pruning):
       Parse the SQL via sqlglot, AND the filters into the outermost
       SELECT's WHERE clause, render back in the target dialect.

    2. SUBQUERY WRAP (fallback — correctness-only):
       ``SELECT * FROM ( <raw> ) AS _qs_pv_wrap WHERE <conds>``.
       Used when sqlglot is unavailable, the SQL doesn't parse, or
       the top-level statement isn't a SELECT (DDL / INSERT / UNION).

    Args:
        raw_sql:       The publisher's literal SQL.  ``None`` passes
                        through unchanged.
        filters:       Iterable of filter dicts / FilterModel objects.
        alias:         Derived-table alias for the fallback wrap.
        filter_logic:  ``AND`` or ``OR``.  Defaults to ``AND``.
        dialect:       sqlglot dialect for the pushdown render
                        (``duckdb`` / ``trino`` / ``snowflake`` /
                        ``oracle`` / ``databricks`` / ``athena``).
                        Defaults to ``duckdb`` which most engines
                        accept verbatim.
        column_types:  2026-08-13 — map of bare column name -> semantic
                        type (``string|number|date|boolean``).  A ``date``
                        column renders ``DATE '2025-09-30'`` rather than a
                        quoted string, which Trino/Starburst, Snowflake and
                        Oracle require in strict mode and DuckDB accepts.
                        Omitted = every literal quoted exactly as before,
                        so existing callers are unchanged.  A filter row
                        carrying its own ``data_type`` wins over this map.
        dynamic_columns: Phase 134-M (audit follow-up) — set of column
                        names marked Dynamic in the PV's
                        ``_where_clauses_mapping``.  For each, the
                        rewriter REMOVES any existing leaf predicate in
                        the publisher's raw_sql before AND-ing the new
                        predicate.  Without this, a hardcoded
                        ``WHERE business_close_date = '2025-09-30'`` +
                        a consumer override of
                        ``?business_close_date=2025-09-29`` produced
                        ``WHERE (… = '2025-09-30') AND (… = '2025-09-29')``
                        — 0 rows.  Pass empty / ``None`` for pre-fix
                        AND-only behaviour (still useful for Static
                        rows where the publisher actually wants both
                        the original predicate AND the static
                        override to apply).

    Returns:
        SQL string with filters applied (pushdown form when possible,
        subquery wrap otherwise), or ``raw_sql`` unchanged when no
        conditions would be produced.
    """
    if not raw_sql or not str(raw_sql).strip():
        return raw_sql
    if not filters:
        return raw_sql

    conditions: List[str] = []
    for f in filters:
        # 2026-09-05 -- the dialect reaches the CONDITION builder, not just
        # the pushdown renderer.  Both strategies below embed this text: the
        # pushdown re-PARSES it with ``read=dialect`` and the subquery wrap
        # concatenates it verbatim into the outer WHERE.  ANSI text handed to
        # either on a backtick dialect turns the column into a constant.
        cond = _build_condition(f, column_types, dialect)
        if cond:
            conditions.append(cond)
    if not conditions:
        return raw_sql

    glue = f" {filter_logic.upper().strip() or 'AND'} "

    # Strip trailing semicolons so both paths can embed the SQL.
    inner = str(raw_sql).rstrip()
    while inner.endswith(";"):
        inner = inner[:-1].rstrip()

    # GUARD: DML / DDL at top level can't be wrapped — ``SELECT * FROM
    # (INSERT INTO …)`` is invalid SQL on every engine.  Return the
    # publisher's SQL unchanged + log a warning.  Silently dropping
    # the filter is the lesser evil compared to a runtime syntax error.
    if _is_dml_statement(inner, dialect=dialect):
        import logging as _l
        _l.getLogger(__name__).warning(
            "[wrap_sql] top-level statement is DML/DDL; filter NOT "
            "applied (would produce invalid SQL).  Move the filter "
            "into the inner SELECT inside the DML if you need it."
        )
        return raw_sql

    # GUARD: named placeholders (``:name`` / ``@name``) survive ONLY
    # through the subquery-wrap path.  sqlglot rewrites them to
    # ``$name`` during AST round-trip on the duckdb / postgres
    # dialects, which breaks JDBC parameter binding at execution.
    # Skip the pushdown path entirely when we detect them.
    skip_pushdown = _has_named_placeholders(inner)

    # GUARD: PIVOT / UNPIVOT / MATCH_RECOGNIZE / LATERAL VIEW change
    # the visible column set in dialect-specific ways the AST walker
    # can't reason about safely — fall back to the subquery wrap so
    # the outer filter applies to the post-PIVOT row set.
    if not skip_pushdown:
        try:
            import sqlglot as _sg
            from sqlglot import exp as _exp
            _t = _sg.parse_one(inner, read=dialect)
            if _t is not None:
                _UNSAFE_NODE_NAMES = ("Pivot", "Unpivot", "MatchRecognize",
                                       "LateralView", "Lateral")
                _unsafe_types = tuple(
                    cls for cls in (getattr(_exp, n, None)
                                     for n in _UNSAFE_NODE_NAMES)
                    if cls is not None and isinstance(cls, type)
                )
                if _unsafe_types and _t.find(_unsafe_types) is not None:
                    skip_pushdown = True
        except Exception:
            pass

    # Normalise dynamic_columns to a lowercased set so identifier
    # casing differences (``business_close_date`` in raw_sql vs
    # ``BUSINESS_CLOSE_DATE`` from the polling row) don't defeat the
    # match.  None / empty preserves pre-fix behaviour.
    dyn_cols: Optional[set] = None
    if dynamic_columns:
        dyn_cols = {
            (str(c) or "").strip().split(".")[-1].lower()
            for c in dynamic_columns
            if c
        }
        dyn_cols.discard("")

    # Strategy 1 — PUSHDOWN.  Preserves partition pruning.
    if not skip_pushdown:
        pushed = _inject_filters_into_select(
            inner, conditions, glue, dialect=dialect,
            dynamic_cols=dyn_cols,
        )
        if pushed:
            return pushed

    # Strategy 2 — subquery wrap (legacy, correctness-only).
    # Phase 134-M — even on the fallback path, we strip the inner SQL's
    # hardcoded predicates on Dynamic columns BEFORE wrapping, so the
    # outer wrap's predicate isn't fighting an inner contradictory
    # one.  When dyn_cols is empty this is a no-op (legacy behaviour).
    inner_for_wrap = inner
    if dyn_cols:
        try:
            import sqlglot
            from sqlglot import exp
            _t = sqlglot.parse_one(inner, read=dialect)
            if _t is not None and isinstance(_t, (exp.Select, exp.Union)):
                for sel in _t.find_all(exp.Select):
                    _remove_dynamic_predicates(sel, dyn_cols)
                inner_for_wrap = _t.sql(dialect=dialect)
        except Exception:
            # Best-effort — if sqlglot can't parse, fall back to the
            # un-modified inner SQL.  The outer WHERE will still
            # constrain to the consumer's value, just with the
            # publisher's old predicate also in scope.
            inner_for_wrap = inner

    where_sql = glue.join(conditions)
    if str(dialect or "").strip().lower() == "oracle":
        # Oracle refuses ``AS`` before a table alias (ORA-00933) and an
        # unquoted identifier that starts with ``_`` (ORA-00911): the
        # fallback wrap could never run there.  Found 2026-10-05.
        return (f"SELECT * FROM (\n{inner_for_wrap}\n) "
                f"{alias.lstrip('_') or 'qs_pv_wrap'} WHERE {where_sql}")
    return f"SELECT * FROM (\n{inner_for_wrap}\n) AS {alias} WHERE {where_sql}"
