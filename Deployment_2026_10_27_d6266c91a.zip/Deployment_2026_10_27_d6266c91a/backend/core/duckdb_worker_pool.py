"""Phase 168c — warm DuckDB subprocess pool (implementation).

Reuses long-lived worker processes so the DuckDB cold start (interpreter
spawn + ``import duckdb``/pyarrow/boto3 + the first ``LOAD httpfs``) is
paid ONCE per worker instead of once per query.

Isolation by construction
-------------------------
Each request runs through ``duckdb_subprocess._child_main`` which opens
its OWN fresh ``:memory:`` connection.  A virgin connection has no
secrets, views, or settings, so query B can never see query A's S3
credentials or registered views.  There is NO cross-request connection
reuse and therefore NO reset contract to get wrong -- the scariest risk
in the design doc is engineered out.

Never a hard dependency
-----------------------
``submit`` raises :class:`PoolUnavailable` ONLY when the request has not
yet been sent to a worker (no worker free within the checkout timeout, or
the frame failed to deliver).  In that case the caller safely falls
through to the legacy per-query subprocess -- the query has not run, so
there is no double execution.  Once a frame IS sent, any failure raises a
``DuckDBEngineError`` (like the legacy crash path) instead of falling
through, so a query never runs twice.

Crash / cancel / recycle
------------------------
A crashed worker is detected (dead process / closed pipe) and dropped;
the next checkout spawns a replacement.  Cancellation kills the worker
(which stops its DuckDB query) and respawns.  Workers recycle after
``max_requests_per_worker``.

DEFAULT ON since 2026-08-22 (env kill-switch ``QS_DUCKDB_POOL=off``) --
see PHASE_168_WARM_POOL_DESIGN.md.

Progressive delivery (2026-09-25)
---------------------------------
``submit`` carries the caller's ARMED progressive COPY (``progressive_
parts_dir`` + ``progressive_fallback_copy_sql``, stamped on the request
payload only when armed, so the unarmed payload is unchanged) and calls
``on_tick`` on every 0.5 s wait slice so the caller can tail sealed parts
into the progressive manifest and emit its heartbeat.  The worker runs the
same ``_child_main`` as the per-query path, which reads the same keys.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import subprocess
import sys
import threading
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class PoolUnavailable(Exception):
    """Request has NOT run on the pool (no worker / send failed).  Caller
    MUST fall through to the legacy per-query subprocess path."""


class _AckTimeout(Exception):
    pass


class _WorkerDied(Exception):
    pass


class _Cancelled(Exception):
    pass


# ── config helpers ──────────────────────────────────────────────────────


def is_enabled() -> bool:
    try:
        from core.config import duckdb_pool as _cfg
        return bool(_cfg.enabled)
    except Exception:                                               # pragma: no cover
        return False


def _pod_size() -> int:
    """Warm workers per POD (``duckdb_pool.size``; 0 = auto)."""
    try:
        from core.config import duckdb_pool as _cfg
        n = int(_cfg.size or 0)
        if n > 0:
            return n
    except Exception:                                               # pragma: no cover
        pass
    try:
        return max(1, min(4, (os.cpu_count() or 2) - 2))
    except Exception:                                               # pragma: no cover
        return 1


def _auto_size() -> int:
    """Warm workers THIS process may run: its share of the pod's
    (2026-10-03, ``core.process_topology``).  An N-process server would
    otherwise run N pools of ``_pod_size()`` DuckDB children, each of which
    sizes its memory as one of ``_pod_size()`` -- N x the pod's budget.
    One process: the pod size itself, unchanged."""
    from core.process_topology import per_process_share
    return per_process_share(_pod_size())


def _max_requests() -> int:
    try:
        from core.config import duckdb_pool as _cfg
        return int(_cfg.max_requests_per_worker or 200)
    except Exception:                                               # pragma: no cover
        return 200


def _checkout_timeout() -> float:
    try:
        from core.config import duckdb_pool as _cfg
        return float(_cfg.checkout_timeout_seconds or 5)
    except Exception:                                               # pragma: no cover
        return 5.0


def _max_rss_mb() -> int:
    """RSS ceiling per worker (MiB); <=0 disables the RSS retire trigger."""
    try:
        from core.config import duckdb_pool as _cfg
        return int(_cfg.max_worker_rss_mb or 0)
    except Exception:                                               # pragma: no cover
        return 0


def _idle_ttl() -> float:
    """Max seconds a worker may sit idle before being retired; <=0 disables."""
    try:
        from core.config import duckdb_pool as _cfg
        return float(_cfg.worker_idle_ttl_seconds or 0)
    except Exception:                                               # pragma: no cover
        return 0.0


# ── worker ──────────────────────────────────────────────────────────────


class _Worker:
    """One warm DuckDB worker process + a background stdout reader thread
    (a thread, not select(), so ack reads work on Windows and Linux)."""

    _WORKER_STARTUP_TIMEOUT = 30.0

    def __init__(self) -> None:
        # Per-worker BF-542 sidecar: the child appends each predownload
        # temp path to it (via DUCKDB_SUBPROCESS_SIDECAR); the worker loop
        # truncates it per request; kill() drains it so a hard-killed
        # request's predownloaded parquet doesn't orphan on the spill PVC.
        import tempfile
        self._sidecar = ""
        try:
            _sfd = tempfile.NamedTemporaryFile(
                suffix=".worker-sidecar.tmp", delete=False,
            )
            self._sidecar = _sfd.name
            _sfd.close()
        except Exception:                                          # pragma: no cover
            self._sidecar = ""
        env = os.environ.copy()
        env["DUCKDB_SUBPROCESS_POOL"] = "1"
        # BF-558b: warm-pool workers are LONG-LIVED — they copy the env once
        # here, so the per-query QS_DUCKDB_CONCURRENT_CHILDREN stamp that the
        # multi-worker fan-out sets later can never reach them, and each
        # pool-served child would claim 75% of the WHOLE pod.  For a
        # fixed-size pool the correct divisor is known right here: up to
        # ``_auto_size()`` workers run concurrently, so each may claim
        # 1/_auto_size() of the pod budget.  Fail-open: on any error the
        # child falls back to its normal resolution (divisor 1 = today).
        # 2026-10-03 -- the divisor is the POD's concurrent children (every
        # process's pool together), not this process's share of them.
        try:
            env["QS_DUCKDB_CONCURRENT_CHILDREN"] = str(max(1, _pod_size()))
        except Exception:                                          # pragma: no cover
            pass
        if self._sidecar:
            env["DUCKDB_SUBPROCESS_SIDECAR"] = self._sidecar
        # Phase 3 (2026-08-22) — stamp the child-side persistent-instance
        # policy at spawn.  The child deliberately reads ENV, not config
        # (no config import on its hot path); a config change therefore
        # reaches workers as they recycle (max_requests / idle TTL / RSS),
        # never mid-life.  Fail-SAFE direction: any error stamps reuse
        # OFF, which is exactly today's fresh-instance-per-request
        # behaviour.
        try:
            from core.config import duckdb_pool as _cfg3
            if bool(_cfg3.db_instance_reuse):
                env["QS_DUCKDB_POOL_DB_REUSE"] = "1"
                env["QS_DUCKDB_POOL_CACHE_MODE"] = str(
                    _cfg3.metadata_cache_mode)
                env["QS_DUCKDB_POOL_DB_MAX_AGE_S"] = str(
                    int(_cfg3.db_instance_max_age_seconds))
        except Exception:                                          # pragma: no cover
            env.pop("QS_DUCKDB_POOL_DB_REUSE", None)
        self.proc = subprocess.Popen(
            [sys.executable, "-m", "core.duckdb_subprocess"],
            cwd=_BACKEND_DIR,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            text=True,
            bufsize=1,
        )
        self.request_count = 0
        # Lifecycle stamps drive idle-TTL recycling.  ``last_used`` is
        # refreshed on every check-in; a worker that sits in the idle list
        # longer than ``worker_idle_ttl_seconds`` is retired at next touch.
        _now = time.monotonic()
        self.created_at = _now
        self.last_used = _now
        self._alive = True
        self._acks: "queue.Queue[Optional[dict]]" = queue.Queue()
        self._reader = threading.Thread(
            target=self._read_loop, name="duckdb-pool-worker-reader",
            daemon=True,
        )
        self._reader.start()
        # CRITICAL: the child writes voluminous diagnostics to stderr
        # (per-file predownload lines + all native fd-1 output, which the
        # worker funnels to stderr).  If nobody drains the stderr PIPE its
        # OS buffer (~64 KB) fills and the child BLOCKS on its next stderr
        # write -> the worker hangs.  A dedicated drain thread consumes it
        # continuously and keeps a bounded tail for post-mortem debugging.
        import collections
        self._stderr_tail: "collections.deque[str]" = collections.deque(maxlen=300)
        self._stderr_reader = threading.Thread(
            target=self._drain_stderr, name="duckdb-pool-worker-stderr",
            daemon=True,
        )
        self._stderr_reader.start()
        # Await the worker's READY ack so we don't hand it a request
        # before its interpreter + imports are warm.
        ready = self._acks.get(timeout=self._WORKER_STARTUP_TIMEOUT)
        if not (isinstance(ready, dict) and ready.get("ready")):
            self.kill()
            raise RuntimeError(f"worker did not report ready (got {ready!r})")

    def _drain_stderr(self) -> None:
        """Continuously drain the child's stderr so its pipe buffer can
        never fill and wedge the worker.  Keeps the last N lines for
        debugging; discards the rest."""
        try:
            for line in self.proc.stderr:                          # blocks in thread
                self._stderr_tail.append(line.rstrip("\n"))
        except Exception:                                          # pragma: no cover
            pass

    def _read_loop(self) -> None:
        try:
            for line in self.proc.stdout:                          # blocks in thread
                line = line.strip()
                if not line:
                    continue
                try:
                    self._acks.put(json.loads(line))
                except Exception:
                    # Non-JSON on stdout should not happen (child prints
                    # diagnostics to stderr); ignore defensively.
                    pass
        except Exception:                                          # pragma: no cover
            pass
        finally:
            self._alive = False
            self._acks.put(None)                                   # stream-closed sentinel

    def is_alive(self) -> bool:
        return self._alive and self.proc.poll() is None

    def rss_mb(self) -> Optional[float]:
        """Resident-set size of the worker process in MiB, or ``None`` when
        it cannot be measured.  ``None`` means "unknown" -> the RSS retire
        trigger is skipped (fail-open: we never churn a worker on a bad
        reading, and max_requests + idle_ttl still bound its lifetime)."""
        try:
            pid = self.proc.pid
        except Exception:                                          # pragma: no cover
            return None
        # Preferred: psutil (cross-platform, accurate).
        try:
            import psutil                                          # type: ignore
            return float(psutil.Process(pid).memory_info().rss) / (1024.0 * 1024.0)
        except Exception:
            pass
        # Linux fallback: /proc/<pid>/statm field 2 = resident pages.
        try:
            with open(f"/proc/{pid}/statm", "r") as _f:
                _resident_pages = int(_f.read().split()[1])
            _page = os.sysconf("SC_PAGE_SIZE")                     # type: ignore[attr-defined]
            return float(_resident_pages * _page) / (1024.0 * 1024.0)
        except Exception:
            return None

    def send(self, args_path: str, result_path: str) -> None:
        self.proc.stdin.write(
            json.dumps({"args": args_path, "result": result_path}) + "\n"
        )
        self.proc.stdin.flush()

    def wait_ack(self, timeout: float, cancel_event: Any = None,
                 on_tick: Optional[Callable[[float], None]] = None) -> dict:
        """Block until the worker acks this request.

        ``on_tick(elapsed_seconds)`` (2026-09-25) is called on every wait
        slice that passes WITHOUT an ack (about every 0.5 s), after the
        cancel check -- the caller's progressive-parts tailer + heartbeat.
        FAIL-OPEN: a tick that raises is logged and never fails the
        request; the ack, the timeout and the cancel are decided here,
        never by the tick."""
        start = time.monotonic()
        deadline = start + max(0.0, float(timeout))
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise _AckTimeout()
            try:
                ack = self._acks.get(timeout=min(remaining, 0.5))
            except queue.Empty:
                if cancel_event is not None and _is_set(cancel_event):
                    raise _Cancelled()
                if on_tick is not None:
                    try:
                        on_tick(time.monotonic() - start)
                    except Exception as _tick_exc:
                        logger.debug("[pool] on_tick raised (fail-open, "
                                     "request unaffected): %s", _tick_exc)
                continue
            if ack is None:
                raise _WorkerDied()
            return ack

    def kill(self) -> None:
        self._alive = False
        for step in (self.proc.stdin,):
            try:
                if step:
                    step.close()
            except Exception:
                pass
        try:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except Exception:
                self.proc.kill()
        except Exception:                                          # pragma: no cover
            pass
        # Drain the sidecar so an in-flight request's predownload temp
        # files (the child's finally didn't get to run under SIGKILL)
        # don't orphan.  Best-effort; then remove the sidecar itself.
        _sc = self._sidecar
        self._sidecar = ""
        if _sc:
            try:
                with open(_sc, "r") as _f:
                    _paths = [ln.strip() for ln in _f if ln.strip()]
                for _p in _paths:
                    try:
                        if os.path.isdir(_p):
                            import shutil as _sh
                            _sh.rmtree(_p, ignore_errors=True)
                        elif os.path.exists(_p):
                            os.unlink(_p)
                    except OSError:
                        pass
            except OSError:
                pass
            try:
                os.unlink(_sc)
            except OSError:
                pass


def _is_set(cancel_event: Any) -> bool:
    try:
        fn = getattr(cancel_event, "is_set", None)
        return bool(fn()) if callable(fn) else False
    except Exception:                                              # pragma: no cover
        return False


# ── pool ────────────────────────────────────────────────────────────────


class DuckDbWorkerPool:
    """Per-pod pool of warm workers.  Singleton via :func:`get_pool`."""

    def __init__(self) -> None:
        self._cond = threading.Condition()
        self._idle: List[_Worker] = []
        self._total = 0                 # live workers (idle + checked out)
        self._size = _auto_size()
        self._closed = False
        self._prewarm_started = False
        self._prewarm_thread: Optional[threading.Thread] = None
        self._reaper_started = False
        self._reaper_thread: Optional[threading.Thread] = None
        self._reaped_total = 0          # workers retired by the reaper
        # Boot prewarm off the request path: __init__ only LAUNCHES the
        # thread (instant); the thread does the actual spawning.  If it
        # fails the pool simply has fewer/zero warm workers and callers
        # fall through to on-demand spawn -- prewarm NEVER raises.
        self._start_prewarm()
        # 2026-08-22 -- idle-TTL and RSS recycling used to fire only at the
        # NEXT checkout, so a pod with no query traffic kept every idle
        # worker (and its cache RSS) forever: two knobs that could not
        # fire on an idle pod are ghost knobs.  The reaper makes them
        # real: a daemon thread retires idle workers that _should_retire
        # flags (TTL / RSS / request budget), with the same accounting a
        # checkout-retire uses.
        self._start_reaper()

    # ── recycle policy ─────────────────────────────────────────────────

    def _should_retire(self, worker: _Worker) -> bool:
        """True when ``worker`` must be discarded instead of reused.

        Triggers (any one): dead process, served >= max_requests, idle
        longer than worker_idle_ttl_seconds, or RSS over max_worker_rss_mb.
        Evaluated cheaply (poll / clock / one RSS read) so it is safe to
        call while holding the pool lock.  On ANY doubt it stays fail-safe:
        an unreadable RSS is treated as "don't retire" (no false churn)."""
        try:
            if not worker.is_alive():
                return True
            if worker.request_count >= _max_requests():
                return True
            ttl = _idle_ttl()
            if ttl > 0 and (time.monotonic() - worker.last_used) > ttl:
                return True
            cap = _max_rss_mb()
            if cap > 0:
                rss = worker.rss_mb()
                if rss is not None and rss > cap:
                    return True
        except Exception:                                          # pragma: no cover
            # A policy-evaluation glitch must never wedge a checkout; treat
            # the worker as usable (the legacy behaviour) rather than churn.
            return False
        return False

    # ── prewarm ────────────────────────────────────────────────────────

    def _start_prewarm(self) -> None:
        """Launch (once) a daemon thread that spawns the MIN pool workers
        so the first real queries meet warm workers instead of paying cold
        start.  Idempotent and fail-open."""
        try:
            if not is_enabled():
                return
        except Exception:                                          # pragma: no cover
            return
        with self._cond:
            if self._prewarm_started or self._closed:
                return
            self._prewarm_started = True
        t = threading.Thread(
            target=self._prewarm_run, name="duckdb-pool-prewarm", daemon=True,
        )
        self._prewarm_thread = t
        t.start()

    def _prewarm_run(self) -> None:
        try:
            target = max(0, int(self._size))
            for _ in range(target):
                # Reserve a slot under the lock (same accounting as
                # _checkout) so prewarm can never overshoot ``_size`` even
                # while real checkouts race alongside it.
                with self._cond:
                    if self._closed or self._total >= self._size:
                        break
                    self._total += 1
                worker: Optional[_Worker] = None
                try:
                    worker = _Worker()                             # off the request path
                except Exception as exc:
                    with self._cond:
                        self._total = max(0, self._total - 1)
                        self._cond.notify()
                    logger.warning(
                        "duckdb pool prewarm: worker spawn failed "
                        "(callers fall through to on-demand): %s", exc,
                    )
                    continue
                stash = False
                with self._cond:
                    if self._closed:
                        # Raced with shutdown -- give the slot back and kill
                        # the worker below so it can't leak.
                        self._total = max(0, self._total - 1)
                    else:
                        self._idle.append(worker)
                        stash = True
                    self._cond.notify()
                if not stash:
                    try:
                        worker.kill()
                    except Exception:                              # pragma: no cover
                        pass
        except Exception as exc:                                   # never raise from a daemon
            logger.warning("duckdb pool prewarm aborted (non-fatal): %s", exc)

    # -- reaper ---------------------------------------------------------

    def _start_reaper(self) -> None:
        """Launch (once) the idle-worker reaper.  Idempotent, fail-open,
        and started only when the pool is enabled (same gate as prewarm)."""
        try:
            if not is_enabled():
                return
        except Exception:                                          # pragma: no cover
            return
        with self._cond:
            if self._reaper_started or self._closed:
                return
            self._reaper_started = True
        t = threading.Thread(
            target=self._reaper_run, name="duckdb-pool-reaper", daemon=True,
        )
        self._reaper_thread = t
        t.start()

    def _reaper_tick(self) -> int:
        """One reap pass: retire every IDLE worker _should_retire flags.
        Returns how many were retired.  Same slot accounting as a
        checkout-retire; kill() runs OUTSIDE the lock."""
        to_kill: List[_Worker] = []
        with self._cond:
            if self._closed:
                return 0
            keep: List[_Worker] = []
            for w in self._idle:
                if self._should_retire(w):
                    self._total -= 1
                    to_kill.append(w)
                else:
                    keep.append(w)
            self._idle = keep
            if to_kill:
                self._reaped_total += len(to_kill)
                self._cond.notify_all()
        for w in to_kill:
            try:
                w.kill()
            except Exception:                                      # pragma: no cover
                pass
        if to_kill:
            logger.info(
                "duckdb pool reaper: retired %d idle worker(s) "
                "(ttl/rss/request-budget); %d live remain",
                len(to_kill), self._total,
            )
        return len(to_kill)

    def _reaper_run(self) -> None:
        try:
            while True:
                with self._cond:
                    if self._closed:
                        return
                # Cadence: quarter of the idle TTL, clamped to [5s, 60s];
                # TTL disabled (<=0) still reaps RSS / request-budget
                # violations at the 60s cadence.
                try:
                    ttl = _idle_ttl()
                    interval = (min(60.0, max(5.0, ttl / 4.0))
                                if ttl > 0 else 60.0)
                except Exception:                                  # pragma: no cover
                    interval = 60.0
                time.sleep(interval)
                try:
                    self._reaper_tick()
                except Exception as exc:                           # pragma: no cover
                    logger.warning("duckdb pool reaper tick failed "
                                   "(non-fatal): %s", exc)
        except Exception as exc:                                   # never raise from a daemon
            logger.warning("duckdb pool reaper aborted (non-fatal): %s", exc)

    # ── checkout / checkin ─────────────────────────────────────────────

    def _checkout(self, timeout: float) -> _Worker:
        deadline = time.monotonic() + max(0.0, timeout)
        to_kill: List[_Worker] = []
        try:
            with self._cond:
                while True:
                    if self._closed:
                        raise PoolUnavailable("pool closed")
                    while self._idle:
                        w = self._idle.pop()
                        if not self._should_retire(w):
                            return w     # healthy warm worker
                        # Retire: account for it now, kill AFTER releasing
                        # the lock (kill() can block up to 3s on terminate).
                        self._total -= 1
                        to_kill.append(w)
                    if self._total < self._size:
                        self._total += 1
                        break            # reserve a slot; spawn below
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise PoolUnavailable(
                            "no warm worker available within checkout timeout"
                        )
                    self._cond.wait(timeout=remaining)
        finally:
            # Runs on the return, break, and raise paths -- always with the
            # lock already released by the ``with`` exit.
            for w in to_kill:
                try:
                    w.kill()
                except Exception:                                  # pragma: no cover
                    pass
            if to_kill:
                with self._cond:
                    self._cond.notify()
        # Spawn outside the lock (Popen + warm-up can take a moment).
        try:
            return _Worker()
        except Exception as exc:
            with self._cond:
                self._total -= 1
                self._cond.notify()
            raise PoolUnavailable(f"worker spawn failed: {exc}")

    def _checkin(self, worker: _Worker, *, healthy: bool) -> None:
        # Stamp idle-entry time BEFORE the lock so idle-TTL is measured from
        # the moment the worker stopped serving.
        worker.last_used = time.monotonic()
        with self._cond:
            if healthy and not self._closed:
                reusable = not self._should_retire(worker)
            else:
                reusable = False
            if reusable:
                self._idle.append(worker)
            elif not self._closed:
                # After shutdown, _total was already zeroed -- don't drive
                # it negative when a mid-flight request finally checks in.
                self._total = max(0, self._total - 1)
            self._cond.notify()
        if not reusable:
            worker.kill()                                          # outside the lock

    # ── public: run one request ─────────────────────────────────────────

    def submit(
        self,
        *,
        conn_config: dict,
        registered_tables: list,
        bucket: str,
        setup_sql: str,
        copy_sql: str,
        output_path: str,
        connection_id: Optional[int] = None,
        timeout: int = 600,
        execution_id: Optional[str] = None,
        cancel_event: Any = None,
        plan_all_iceberg: Optional[bool] = None,
        progressive_parts_dir: Optional[str] = None,
        progressive_fallback_copy_sql: Optional[str] = None,
        on_tick: Optional[Callable[[float], None]] = None,
        remote_io: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run one COPY request on a warm worker.

        ``remote_io`` (2026-10-06): the child's remote-I/O inputs (the
        dispatch's fan-out and the parent's measured file sizes -- see
        ``duckdb_subprocess._remote_io_hint_for``).  Stamped only when set.

        ``progressive_parts_dir`` / ``progressive_fallback_copy_sql``
        (2026-09-25): the caller's ARMED progressive COPY -- ``copy_sql``
        already targets the parts dir, the fallback is the canonical
        single-file COPY the child reverts to on a spool failure.  Both
        keys are stamped on the payload ONLY when armed; an unarmed
        request's payload is byte-identical to before.  ``on_tick`` is
        called on every 0.5 s wait slice (see ``_Worker.wait_ack``)."""
        if self._closed or not is_enabled():
            raise PoolUnavailable("pool disabled")

        # First-use safety net: if __init__ ran before the pool was enabled
        # (env flip), kick prewarm + reaper now.  Idempotent + off the
        # request path.
        self._start_prewarm()
        self._start_reaper()

        import tempfile

        # ── PRE-SEND setup.  Any failure here means the query did NOT run,
        # so raise PoolUnavailable to fall through to the legacy path.
        args_path = ""
        try:
            args_payload = {
                "conn_config": conn_config,
                "registered_tables": registered_tables,
                "bucket": bucket,
                "setup_sql": setup_sql,
                "copy_sql": copy_sql,
                "output_path": output_path,
                "connection_id": connection_id,
                # Phase 3 — immutability proof for the child's metadata-
                # cache policy ("auto" mode trusts caches ONLY under this
                # stamp).  Strictly True/False; absent => not proven.
                "plan_all_iceberg": bool(plan_all_iceberg is True),
            }
            # Progressive COPY keys — present ONLY when armed, so the
            # unarmed payload stays byte-identical (same rule as the legacy
            # payload in duckdb_subprocess.run_duckdb_copy_to).  The child
            # disarms itself when the fallback is missing, so both go
            # together or not at all.
            if remote_io:
                args_payload["remote_io"] = dict(remote_io)
            if progressive_parts_dir:
                args_payload["progressive_parts_dir"] = str(
                    progressive_parts_dir)
                args_payload["progressive_fallback_copy_sql"] = (
                    progressive_fallback_copy_sql)
            # F2 (2026-07-25) — same size/etag hint handoff as the legacy
            # Popen path (see duckdb_subprocess.py); omitted when empty.
            try:
                from core.onprem_file_cache import export_expected_meta_for_sql
                _exp_meta = export_expected_meta_for_sql(setup_sql)
                if _exp_meta:
                    args_payload["onprem_expected_meta"] = _exp_meta
            except Exception as _exp_exc:
                logger.debug("onprem expected-meta export skipped "
                             "(non-fatal): %s", _exp_exc)
            fd = tempfile.NamedTemporaryFile(
                mode="w", suffix=".poolargs.json", delete=False,
            )
            args_path = fd.name
            try:
                json.dump(args_payload, fd)   # may raise on non-serializable
            finally:
                fd.close()
            result_path = args_path + ".result.json"
        except Exception as exc:
            # Don't leak the temp file if json.dump raised mid-write.
            if args_path:
                try:
                    os.unlink(args_path)
                except OSError:
                    pass
            raise PoolUnavailable(f"pool arg-file setup failed (did not run): {exc}")

        # Outer finally guarantees temp-file cleanup even if _checkout
        # raises PoolUnavailable (fix: no arg-file leak on checkout timeout).
        try:
            wall_start = time.monotonic()
            worker = self._checkout(_checkout_timeout())   # raises PoolUnavailable
            healthy = True
            # Resource Governor (2026-08-02, default OFF): while serving
            # THIS request the worker process IS the query — register it so
            # the governor's sampler attributes its RSS to this execution.
            # The declared ceiling mirrors what the worker child resolves
            # (pod share / pool size — see the QS_DUCKDB_CONCURRENT_CHILDREN
            # stamp in _Worker.__init__).  Fail-open.
            try:
                from core import resource_governor as _rg
                _rg.register_child(
                    worker.proc.pid, execution_id=execution_id or "",
                    popen=worker.proc,
                    spawn_env={"QS_DUCKDB_CONCURRENT_CHILDREN":
                               str(max(1, _pod_size()))},
                )
            except Exception as _rg_exc:
                logger.debug("[resource-governor] pool register skipped "
                             "(fail-open): %s", _rg_exc)
            try:
                # From here the request may RUN on the worker, so a failure
                # must NOT fall through (no double execution): raise a
                # non-PoolUnavailable error instead.
                try:
                    worker.send(args_path, result_path)
                except Exception as exc:
                    healthy = False
                    # Frame not delivered -> query did not run -> safe to
                    # fall through to the legacy path.
                    raise PoolUnavailable(f"worker send failed (did not run): {exc}")

                # ``on_tick`` is forwarded only when given, so a worker
                # double with the pre-2026-09-25 wait_ack shape still fits.
                _wait_kw: Dict[str, Any] = {"cancel_event": cancel_event}
                if on_tick is not None:
                    _wait_kw["on_tick"] = on_tick
                try:
                    ack = worker.wait_ack(timeout, **_wait_kw)
                except _Cancelled:
                    healthy = False
                    # 2026-10-26 -- what the cancel reached is RECORDED on
                    # the run (core/cancel_scope.py); ``healthy = False``
                    # is what gets this worker process killed below
                    try:
                        from core.cancel_scope import note_cancel as _note_cancel
                        _note_cancel(cancel_event, "duckdb_child", reached=True,
                                     statement=f"pid {getattr(worker.proc, 'pid', '?')}",
                                     detail="the pooled DuckDB worker process is stopped")
                    except Exception:  # noqa: BLE001
                        pass
                    raise RuntimeError("DuckDB query cancelled by user")
                except (_AckTimeout, _WorkerDied) as exc:
                    healthy = False
                    # Resource Governor (2026-08-02): if the governor killed
                    # this worker, surface its user-facing verdict instead
                    # of a generic pool failure.  Fail-open.
                    _rg_note = None
                    try:
                        from core import resource_governor as _rg
                        _rg_note = _rg.consume_kill_note(
                            worker.proc.pid, execution_id or "")
                    except Exception as _rg_note_exc:
                        logger.debug("[resource-governor] pool kill-note "
                                     "lookup failed (fail-open): %s",
                                     _rg_note_exc)
                    from core.duckdb_subprocess import DuckDBEngineError
                    raise DuckDBEngineError(
                        _rg_note
                        or f"pooled DuckDB worker failed ({type(exc).__name__})"
                    )

                if isinstance(ack, dict) and ack.get("recycle"):
                    healthy = False

                try:
                    with open(result_path, "r") as rf:
                        result = json.load(rf)
                except Exception as exc:
                    healthy = False
                    from core.duckdb_subprocess import DuckDBEngineError
                    raise DuckDBEngineError(
                        f"pooled DuckDB worker produced no result file: {exc}"
                    )

                if result.get("error"):
                    from core.proxy_utils import sanitize_proxy_error
                    # 2026-10-02 -- the worker runs the same _child_main, so
                    # a declared refusal arrives as the same verdict and is
                    # re-raised as the same TYPE on this transport too.
                    from core.duckdb_subprocess import refusal_from_child_verdict
                    _refusal = refusal_from_child_verdict(
                        sanitize_proxy_error(result["error"]))
                    if _refusal is not None:
                        raise _refusal
                    raise RuntimeError(
                        f"DuckDB query error: {sanitize_proxy_error(result['error'])}"
                    )

                wall_elapsed = round(time.monotonic() - wall_start, 2)
                result.setdefault("timing", {})["wall_s"] = wall_elapsed
                # Phase 164 latency attribution (parity with legacy path).
                try:
                    from core.duckdb_subprocess import _attribute_child_latency
                    _attribute_child_latency(result.get("timing", {}), wall_elapsed)
                except Exception:                                  # pragma: no cover
                    pass
                worker.request_count += 1
                return result
            finally:
                # Resource Governor (2026-08-02): request over — stop
                # attributing this worker's RSS to the execution.  The
                # governor also reaps by liveness, so a miss here only
                # delays finalization by one sample tick.  Fail-open.
                try:
                    from core import resource_governor as _rg_dereg
                    _rg_dereg.deregister_child(worker.proc.pid)
                except Exception as _rg_dereg_exc:
                    logger.debug("[resource-governor] pool deregister "
                                 "skipped (fail-open): %s", _rg_dereg_exc)
                self._checkin(worker, healthy=healthy)
        finally:
            for p in (args_path, result_path):
                try:
                    os.unlink(p)
                except OSError:
                    pass

    # ── admin / lifecycle ───────────────────────────────────────────────

    def health(self) -> Dict[str, Any]:
        with self._cond:
            return {
                "enabled": is_enabled(),
                "configured_size": self._size,
                "live_workers": self._total,
                "idle_workers": len(self._idle),
                "max_requests_per_worker": _max_requests(),
                "max_worker_rss_mb": _max_rss_mb(),
                "worker_idle_ttl_seconds": _idle_ttl(),
                "prewarm_started": self._prewarm_started,
                "reaper_started": self._reaper_started,
                "reaped_total": self._reaped_total,
                "status": "ready",
                "started": self._total > 0,
            }

    def shutdown(self) -> None:
        with self._cond:
            self._closed = True
            idle = list(self._idle)
            self._idle.clear()
            self._total = 0
            self._cond.notify_all()
        for w in idle:
            try:
                w.kill()
            except Exception:                                      # pragma: no cover
                pass


# ── singleton ───────────────────────────────────────────────────────────

_pool_singleton: Optional[DuckDbWorkerPool] = None
_pool_lock = threading.Lock()


def get_pool() -> DuckDbWorkerPool:
    global _pool_singleton
    if _pool_singleton is not None:
        return _pool_singleton
    with _pool_lock:
        if _pool_singleton is None:
            _pool_singleton = DuckDbWorkerPool()
        return _pool_singleton


def shutdown_pool() -> None:
    """Shut the pool down AND forget it.

    2026-09-15 -- this left ``_pool_singleton`` pointing at the dead pool,
    so the next ``get_pool()`` returned a corpse instead of building a live
    one.  Unlike ``worker_pool.get_pool`` (which is explicitly initialised
    and must RAISE), this accessor constructs lazily -- so the right answer
    here is to clear the global and let the next caller get a working pool.
    Same defect, different correct fix, because the two have different
    contracts.
    """
    global _pool_singleton
    with _pool_lock:
        p = _pool_singleton
        _pool_singleton = None
    if p is not None:
        try:
            p.shutdown()
        except Exception:                                          # pragma: no cover
            pass


def reset_pool_for_tests() -> None:
    global _pool_singleton
    with _pool_lock:
        if _pool_singleton is not None:
            try:
                _pool_singleton.shutdown()
            except Exception:
                pass
        _pool_singleton = None


__all__ = [
    "PoolUnavailable", "DuckDbWorkerPool", "is_enabled",
    "get_pool", "shutdown_pool", "reset_pool_for_tests",
]
