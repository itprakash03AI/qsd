"""Public API for row & column security.

Single entry point ``secure_sql`` used by every query-execution path
(execute, stream, published views, business reports, federation, NL).

Initialisation: call ``set_db_manager(db)`` once at startup AFTER the
DatabaseManager is created.  Without it ``secure_sql`` is a no-op (so
imports during early startup are safe).
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Callable, Dict, List, Optional

from concurrent.futures import ThreadPoolExecutor

from core.row_security.resolver import (
    PolicyResolver,
    UserContext,
)
from core.row_security.principal import api_key_id_of
from core.row_security.rewriter import (
    EmptyPolicyFilterError,
    PolicyParseError,
    PolicyRewriteError,
    SchemaLookupError,
    SqlRewriter,
    UnexpressiblePolicyError,
    UnresolvedPrincipalError,
)
from core.row_security.entitlement import EntitlementRefused

# Fire-and-forget pool for audit writes — same pattern as core.audit so
# that row-security audit never blocks the request thread.  Bounded small;
# audit rows are tiny and frequent so 4 daemon threads is plenty.
_audit_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="rs-audit-")

logger = logging.getLogger(__name__)


class PolicyResolutionError(RuntimeError):
    """Raised when policies cannot be resolved (DB unavailable, etc.)."""


class RowSecurityRefused(ValueError):
    """Row security refused to run this query for this principal.

    2026-09-24.  The engine's chokepoint
    (``FederationEngine._apply_rls_all_connections``) wrapped every refusal
    as a bare ``ValueError``, so a caller could not tell "row security said
    no" from "the query broke": the published API answered an API key on a
    governed table with a generic 500 "contact support" while the log held
    the precise reason.  A ``ValueError`` subclass, so every existing
    ``except ValueError`` keeps its behaviour; a caller that can say 403 now
    can tell.
    """


# ── Module state ────────────────────────────────────────────────────────────

_db_manager = None
_resolver: Optional[PolicyResolver] = None
_init_lock = threading.RLock()


def set_db_manager(db) -> None:
    """Bind the DatabaseManager singleton.  Idempotent."""
    global _db_manager, _resolver
    with _init_lock:
        _db_manager = db
        try:
            from core.config import row_security as _rs_cfg
            cache_seconds = int(_rs_cfg.cache_resolver_seconds)
        except Exception:
            cache_seconds = 30
        _resolver = PolicyResolver(db, cache_seconds=cache_seconds)
        # 2026-09-26 (F0) -- the cache-scope memo describes THIS store.
        try:
            from core.row_security.cache_scope import reset_policy_set_memo
            reset_policy_set_memo()
        except Exception:                        # pragma: no cover
            pass


def _is_enabled() -> bool:
    try:
        from core.config import row_security as _rs_cfg
        return bool(_rs_cfg.enabled)
    except Exception:
        return False


def engine_state() -> Dict[str, Any]:
    """AQD-07 (2026-09-23) -- the engine's state, and WHY it would not act.

    ``secure_sql_report`` short-circuits on three different conditions with
    one line -- enforcement switched off, no database manager bound, no
    policy resolver -- and all three returned the same ``(sql, None)`` as
    "no policy matched you".  The dry run, the one tool an admin uses to
    convince themselves a data boundary works, therefore answered a disabled
    or mis-wired engine with what read as a clean "nothing applies".  This
    names the state so every caller can say which it is.

    ``enabled`` is None when the config could not be READ -- unknown is not
    the same as off.
    """
    try:
        from core.config import row_security as _rs_cfg
        enabled: Optional[bool] = bool(_rs_cfg.enabled)
        mode = getattr(_rs_cfg, "default_mode", None)
    except Exception as exc:
        enabled, mode = None, None
        config_error = f"{type(exc).__name__}: {exc}"
    else:
        config_error = None
    not_wired = [name for name, obj in (("db_manager", _db_manager),
                                        ("resolver", _resolver)) if obj is None]
    if config_error:
        reason = f"row_security config could not be read ({config_error})"
    elif not_wired:
        reason = ("the row-security engine is not wired in this process "
                  f"(missing: {', '.join(not_wired)})")
    elif not enabled:
        reason = ("row_security.enabled is false -- policies are NOT enforced "
                  "on real queries")
    else:
        reason = None
    return {
        "enabled": enabled,
        "wired": not not_wired,
        "not_wired": not_wired,
        "default_mode": mode,
        "enforcing": bool(enabled) and not not_wired,
        "reason": reason,
    }


#: Environment names that mean "real production data is behind this".
#: Matched case-insensitively against EVERY declared signal — not against
#: the single resolved label.  See :func:`deployment_is_production`.
_PRODUCTION_NAMES = ("prod", "production")


def production_signal_source() -> Optional[str]:
    """WHICH declaration says this is production, or ``None``.

    Returned rather than a bare bool so the override can name its evidence:
    an operator told "your fail_open switch was ignored" needs to know it
    was ``$ENVIRONMENT`` and not the config file, or the only way to find
    out is to read precedence rules off a wiki.  (The system logs what it
    DID; it must also log what it DECLINED to do, and why.)
    """
    try:
        from core.config import deploy_environment_signals as _signals
        signals = _signals()
    except Exception:                              # noqa: BLE001
        # Unknown, not unsafe-by-invention: see the docstring below.  A
        # config module that cannot be imported at all is a startup
        # failure that will surface far more loudly than this.
        return None
    for value, source in signals:
        if str(value).strip().lower() in _PRODUCTION_NAMES:
            return source
    return None


def deployment_is_production() -> bool:
    """Could this deployment be production?  — a SECURITY question.

    2026-09-07 — this body used to be a FOURTH hand-copy of the deploy
    environment precedence chain, consulting the three config keys and NOT
    ``$QUERYSTUDIO_ENV`` / ``$ENVIRONMENT``.  On a deployment that declares
    production only through the ambient variable the two readers disagreed:

        core.config.deploy_environment()                  -> "prod"
        core.row_security.api.deployment_is_production()  -> False

    …so ``fail_open_in_force()`` returned True with the switch armed, the
    ``PolicyRewriteError`` handler continued past a failed policy rewrite,
    and governed tables were served UNFILTERED under a green status.
    FR-SEC-03's production half silently did not fire.  A decision made
    twice is a bug; this one was the environment decision, one level up.

    IT IS DELIBERATELY NOT ``deploy_environment() in {prod, production}``.
    That resolver answers "what is this deployment CALLED", and its
    precedence — config BEATS the ambient ``$ENVIRONMENT`` — is correct for
    that question: an inherited generic variable relabelling every alert is
    the FOREIGN-BUT-PRESENT failure this codebase has already paid for, and
    for the ALERT-LABELLING use an explicit config value must win.

    This gate asks a different question of the SAME enumeration
    (``core.config.deploy_environment_signals`` — one list, two
    predicates).  Not "which label wins" but "does ANY source say
    production", because the costs are not comparable:

      * a false POSITIVE refuses a query in a non-production environment,
        and only on a deployment that deliberately armed a documented RLS
        bypass (``row_security.fail_open`` defaults False).  Loud,
        immediate, diagnosable, and named in the log line below.
      * a false NEGATIVE serves governed rows to the wrong principal under
        a green status.  Silent, and invisible to every test.

    When two authz predicates disagree, converge on the STRICTER.

    So ``app.environment=UAT`` alongside ``$ENVIRONMENT=prod`` is UAT to
    the console and PRODUCTION to this gate, on purpose.  The two sources
    disagreeing about whether real data is behind this process IS the
    unsafe state; resolving it towards a refused diagnostic query is the
    cheap resolution, and the expensive one cannot be detected after the
    fact.  Neither the label nor any alert routing moves — only this gate.

    Unknown is still NOT production, unchanged: a deployment that declares
    no environment ANYWHERE has stated nothing, and inventing production
    for it would override a configured posture on no evidence at all.
    That is a different case from the one above, where production WAS
    declared and this reader could not see the channel it arrived on.
    """
    return production_signal_source() is not None


def fail_open_in_force() -> bool:
    """Is the row-security fail-open switch in force RIGHT NOW?

    2026-09-05 -- THE SINGLE ANSWER.  FR-SEC-03 ("the RLS fail-open switch
    must be reviewed and, IN PRODUCTION, closed") was implemented in
    ``core/feed/rls._rls_fail_open``, which gates exactly ONE caller: the
    Spark-path table assertion.  The gate that actually decides whether the
    SQL rewrite is skipped -- the ``PolicyRewriteError`` handler below --
    read the raw config and had no production override.  So in production
    with ``fail_open=true`` declared the two functions disagreed:

        core.feed.rls._rls_fail_open()      -> False   (FR-SEC-03 honoured)
        core.row_security.api._fail_open()  -> True    (the deciding gate)

    A decision made twice is a bug.  The requirement now lives on the
    function that decides, and ``core.feed.rls`` delegates here.

    A default of False satisfies the review half of FR-SEC-03 and not the
    production half -- a default is what you get when nobody decides, and
    this requirement is about what happens when somebody decides wrongly.
    Continuing UNFILTERED past a policy lookup that failed is a silent RLS
    bypass, and no incident is worth shipping one.

    Deliberately loud, and deliberately at the point of USE rather than at
    startup: an operator who set this expects it to be in force, and must
    find out at the moment it is ignored.
    """
    try:
        from core.config import row_security as _rs_cfg
        declared = bool(_rs_cfg.fail_open)
    except Exception:
        return False
    if not declared:
        return declared
    # The PREDICATE is ``deployment_is_production`` — one function decides,
    # and ``core.feed.rls`` delegates to that same one.  The source is
    # looked up separately, and only to say WHY, so the decision cannot
    # start depending on the shape of the evidence.
    if deployment_is_production():
        logger.error(
            "row_security.fail_open=true is IGNORED in production "
            "(FR-SEC-03): continuing past a failed policy rewrite would "
            "serve governed tables unfiltered under a green status. "
            "Treating the switch as CLOSED for this call — set it in a "
            "non-production environment if you need the degraded "
            "behaviour for diagnosis. Production was declared by %s — if "
            "that is not this deployment, that declaration is the bug.",
            production_signal_source() or "the deployment environment")
        return False
    return declared


def _fail_open() -> bool:
    """Internal alias kept for call sites and tests that already name it."""
    return fail_open_in_force()


# ── User context builder ───────────────────────────────────────────────────

def build_user_ctx(user: Dict[str, Any]) -> UserContext:
    """Convert the FastAPI user dict into a :class:`UserContext`.

    Tolerant of missing fields — the rewriter degrades gracefully
    (the principal still gets ``user:<name>`` + ``role:<role>`` + ``all:*``
    so policies can match).
    """
    if not user:
        return UserContext(username="anonymous", role="viewer")
    groups = user.get("groups") or user.get("ad_groups") or []
    if isinstance(groups, str):
        groups = [g.strip() for g in groups.split(",") if g.strip()]
    return UserContext(
        username=str(user.get("username") or "anonymous"),
        role=str(user.get("role") or "viewer"),
        groups=tuple(str(g) for g in groups),
        # 2026-09-05 -- ``live_caller`` joins the exclusion for the same
        # reason ``rls_unresolved`` is here: it is a MARKER about how this
        # principal was obtained, not an attribute of the person.  Left in,
        # ``${user.live_caller}`` would resolve in report SQL and the token
        # would appear in the "available:" list of an unresolvable-token
        # error, inviting an author to key a filter on our plumbing.
        attrs={k: v for k, v in user.items()
                if k not in ("username", "role", "groups", "ad_groups",
                              "is_admin", "password", "rls_unresolved",
                              "live_caller", "entitlement_scope")},
        # 2026-10-24 -- the surface a data entitlement is decided for
        # (core/row_security/entitlement.py::scope_of); absent = a person.
        entitlement_scope=user.get("entitlement_scope"),
        # 2026-10-25 -- an API key is the RESOLVED principal ``api_key:<id>``
        # (core/row_security/principal.py): its bindings and its entitlement
        # values are its own; a group binding never matches it.
        api_key_id=api_key_id_of(user),
        is_admin=bool(user.get("is_admin")),
        # Carried from the caller: see UserContext.unresolved.  A fabricated
        # principal must not be mistaken for a real one with no groups.
        #
        # 2026-10-25 -- and ONLY from the caller.  From 2026-09-05 to today
        # this chokepoint ALSO marked a groupless api_key / basic_noauth dict
        # unresolved ("nobody looked its groups up"), which made every API
        # key a 403 on every table carrying any row policy.  A credentialed
        # principal is resolved (principal.py has the decision); the marker
        # is stamped where a scope was NOT established -- a lookup that
        # raised, a fabricated background principal -- and read here as it
        # arrives.  FB-45's composition (no grant held = no rows) is what
        # keeps a resolved principal that matches no binding from reading a
        # governed table unfiltered.
        unresolved=bool(user.get("rls_unresolved")),
    )


# ── Schema lookup wiring ───────────────────────────────────────────────────

_schema_lookup_fn: Optional[Callable[[str, Optional[int]], List[str]]] = None


def set_schema_lookup(fn: Callable[[str, Optional[int]], List[str]]) -> None:
    """Register a callable used by the rewriter for column expansion.

    Signature: ``fn(table_ref: str, connection_id: int|None) -> List[str]``.
    The default is no schema lookup — column policies fall back to
    DuckDB ``EXCLUDE`` or naked ``*``.
    """
    global _schema_lookup_fn
    _schema_lookup_fn = fn


def _schema_lookup_adapter(connection_id: Optional[int]):
    """Adapt the registered lookup to the rewriter's ``(table_ref) -> cols``.

    2026-09-05 — this used to ``return []`` on any exception.  UNKNOWN IS NOT
    EMPTY: "the catalog could not be reached" and "this table has no columns"
    lead to opposite investigations, and both reached the projection builder
    as the same value, so a policy refusal blamed the policy for a catalog
    outage and the surviving DuckDB fallback took the schema-free branch with
    nothing logged above DEBUG.

    The failure is now raised as :class:`SchemaLookupError` and the rewriter
    decides what it means — for an include/mask policy a refusal naming the
    catalog, for the DuckDB EXCLUDE/REPLACE forms the same (correct) SQL as
    before plus a WARNING that it degraded.  Deliberately NOT a refusal in
    that second case: those forms express the policy exactly without a schema
    and DuckDB errors loudly on a missing column, so a catalog outage cannot
    turn them into a disclosure.
    """
    if _schema_lookup_fn is None:
        return None
    def _lookup(table_ref: str) -> List[str]:
        try:
            return _schema_lookup_fn(table_ref, connection_id) or []
        except Exception as exc:
            raise SchemaLookupError(
                f"schema lookup failed for {table_ref!r} on connection "
                f"{connection_id!r}: {type(exc).__name__}: {exc}") from exc
    return _lookup


# ── Public helper ──────────────────────────────────────────────────────────

def secure_sql(
    sql: str,
    *,
    dialect: str = "duckdb",
    user_ctx: Any = None,
    connection_id: Optional[int] = None,
    request_id: Optional[str] = None,
) -> str:
    """Return ``sql`` rewritten to enforce row + column policies.

    No-op when the feature is disabled, when the user is an admin (admins
    bypass security so they can author policies), or when no policy
    matches any table in the query.

    Always records an audit row when a policy WOULD have applied — even
    in ``audit_only`` mode — so admins can see the dry-run impact.
    """
    return secure_sql_report(
        sql, dialect=dialect, user_ctx=user_ctx,
        connection_id=connection_id, request_id=request_id)[0]


def secure_sql_report(
    sql: str,
    *,
    dialect: str = "duckdb",
    user_ctx: Any = None,
    connection_id: Optional[int] = None,
    request_id: Optional[str] = None,
    simulate: bool = False,
):
    """:func:`secure_sql` plus the :class:`RewriteResult` it acted on.

    FB-45 (2026-09-20): the dry-run endpoint shows WHICH policies matched,
    each one's class and how they combined -- that endpoint is what made
    the composition question visible at all.  ``None`` as the second
    element means no rewrite ran (feature off, admin bypass, parse
    passthrough, fail-open).  Same audit side effects as ``secure_sql``.

    ``simulate`` (AQD-07, 2026-09-23) is the DRY RUN: it answers "what would
    the engine do to this SQL for this principal" even while enforcement is
    switched off -- which is exactly when an admin needs to ask, before
    turning it on -- and it writes NO audit rows, because the principal is
    one the admin typed in and an audit row would record an enforcement that
    never happened.  It still needs the engine WIRED (a db manager and a
    resolver); :func:`engine_state` says which, and the dry run reports it.
    """
    if not sql:
        return sql, None
    # 2026-10-24 -- the entitlement DISCLOSURE (core/row_security/disclosure.py)
    # is recorded where the decision is made: here for the three branches
    # that never reach the compiler (engine off / not wired, the admin
    # bypass, a parse passthrough with no dimension active); the compiler
    # records its own.  A dry run records nothing (it enforced nothing).
    from core.row_security import disclosure as _disc
    if (not simulate and not _is_enabled()) or _db_manager is None or _resolver is None:
        if not simulate:
            _disc.record(_disc.KIND_ROW_SECURITY_OFF, note=engine_state().get("reason"))
        return sql, None
    _audit = _audit_one if not simulate else (lambda *a, **k: None)

    # Normalise user_ctx
    ctx: UserContext
    if isinstance(user_ctx, UserContext):
        ctx = user_ctx
    elif isinstance(user_ctx, dict):
        ctx = build_user_ctx(user_ctx)
    elif user_ctx is None:
        ctx = UserContext(username="anonymous", role="viewer")
    else:
        # Unknown type — convert what we can
        ctx = UserContext(username=str(user_ctx), role="viewer")

    # Admins bypass — they must be able to author + test policies.
    # 2026-10-24 (the owner's decision 2: "admins bypass, AUDITED") -- when a
    # data-entitlement dimension is active, the bypass of a table it would
    # govern is recorded (one row per table, mode admin_bypass).
    if ctx.is_admin or ctx.role in ("admin", "super_admin"):
        if not simulate:
            _audit_admin_entitlement_bypass(ctx, sql, dialect, connection_id, request_id)
            _disc.record(_disc.KIND_ADMIN_BYPASS)
        return sql, None

    from core.row_security.composition import composition_mode as _comp_mode
    _mode = _comp_mode()
    rewriter = SqlRewriter(_resolver)
    try:
        result = rewriter.rewrite(
            sql,
            dialect=dialect,
            user_ctx=ctx,
            connection_id=connection_id,
            schema_lookup=_schema_lookup_adapter(connection_id),
        )
    except EntitlementRefused as exc:
        # 2026-10-24 -- a data entitlement could not be certified (store
        # unreadable, a table whose columns are unknown, a value list over the
        # inline cap ...).  MUST be caught before PolicyRewriteError below:
        # fail-open would serve the governed table unfiltered.
        logger.error("row_security: refusing to run for user=%s -- data entitlement: %s",
                     ctx.username, exc)
        _audit(
            ctx, "*ENTITLEMENT_REFUSED*", connection_id, [], [], "refused",
            sql_before=sql, sql_after=None, request_id=request_id,
            notes=str(exc)[:500], composition=_mode,
        )
        raise PolicyResolutionError(str(exc)) from exc
    except UnresolvedPrincipalError as exc:
        # MUST be caught before PolicyRewriteError below, which fail-opens.
        # This error means the opposite of a recoverable rewrite problem:
        # continuing would serve a governed table UNFILTERED to a principal
        # we could not identify.  Re-raised as PolicyResolutionError so every
        # caller's existing fail-closed branch (403 / failed execution)
        # handles it without new wiring.
        logger.error(
            "row_security: refusing to run for unresolved principal %s: %s",
            ctx.username, exc)
        _audit(
            ctx, "*UNRESOLVED_PRINCIPAL*", connection_id, [], [], "refused",
            sql_before=sql, sql_after=None, request_id=request_id,
            notes=str(exc)[:500], composition=_mode,
        )
        raise PolicyResolutionError(str(exc)) from exc
    except EmptyPolicyFilterError as exc:
        # 2026-08-20 — MUST also be caught before PolicyRewriteError below:
        # a matched policy whose rendered filter_sql is EMPTY means the
        # rewrite would be ``WHERE TRUE`` (table served unfiltered while
        # audited as enforced).  Letting ``row_security.fail_open``
        # downgrade this to passthrough would grant the exact same
        # unfiltered access the empty filter would have — so it never
        # fail-opens, same posture as UnresolvedPrincipalError.
        logger.error(
            "row_security: refusing to run for user=%s — a matched row "
            "policy rendered an EMPTY filter: %s", ctx.username, exc)
        _audit(
            ctx, "*EMPTY_FILTER*", connection_id, [], [], "refused",
            sql_before=sql, sql_after=None, request_id=request_id,
            notes=str(exc)[:500], composition=_mode,
        )
        raise PolicyResolutionError(str(exc)) from exc
    except UnexpressiblePolicyError as exc:
        # 2026-09-05 — MUST also be caught before PolicyRewriteError below.
        # A policy MATCHED this principal and this table, and the rewriter
        # could not express it in the target dialect (a mask/include with no
        # resolvable schema; a subquery the dialect would not accept).
        # Fail-opening that returns the ORIGINAL sql — i.e. the masked column
        # in CLEARTEXT — while the audit trail records a policy hit.  A cap
        # may throttle; a security gate must FAIL.
        #
        # This became reachable in bulk on 2026-09-05: feeds/reports on
        # postgres/mysql/sqlserver/redshift/bigquery now resolve their real
        # dialect instead of duckdb, and the no-schema mask fallback
        # (``* REPLACE (…)``) is DuckDB-only.  The schema side is very
        # reachable too — ``_schema_lookup_adapter`` swallows any lookup
        # failure and returns [], so "the catalog could not answer" lands
        # exactly on that branch.
        logger.error(
            "row_security: refusing to run for user=%s — a matched policy "
            "cannot be expressed on this dialect: %s", ctx.username, exc)
        _audit(
            ctx, "*UNEXPRESSIBLE_POLICY*", connection_id, [], [], "refused",
            sql_before=sql, sql_after=None, request_id=request_id,
            notes=str(exc)[:500], composition=_mode,
        )
        raise PolicyResolutionError(str(exc)) from exc
    except PolicyParseError as exc:
        if simulate:
            raise  # a dry run shows the admin the error, not a passthrough
        # 2026-10-24 -- with a data-entitlement dimension active, "the SQL did
        # not parse, so no policy applies" cannot be certified: no leaf was
        # examined.  Refused for a non-admin (the design's one posture change).
        try:
            from core.row_security.entitlement import any_active as _ent_any
            _ent_on = _ent_any(_db_manager)
        except Exception:
            _ent_on = True
        if _ent_on:
            _audit(
                ctx, "*PARSE_ERROR*", connection_id, [], [], "refused",
                sql_before=sql, sql_after=None, request_id=request_id,
                notes=("data entitlement active: an unparsed query is refused -- "
                       + str(exc))[:500], composition=_mode,
            )
            raise PolicyResolutionError(
                "This query could not be read by the data-entitlement check, so it cannot be "
                f"certified as filtered: {exc}") from exc
        # The SQL didn't even parse — no policy could possibly apply.
        # Hand the original SQL back so the downstream engine raises a
        # native parse error.  Audit the event so admins notice if a
        # consumer is repeatedly probing with malformed input.
        _disc.record(_disc.KIND_NO_DIMENSION)      # the any_active call above said so
        logger.info("row_security: parse error, passing SQL through to engine: %s", exc)
        # _audit_one is fire-and-forget; it logs its own failures.  No
        # surrounding try/except needed.
        _audit(
            ctx, "*PARSE_ERROR*", connection_id, [], [], "passthrough",
            sql_before=sql, sql_after=None, request_id=request_id,
            notes=str(exc)[:500], composition=_mode,
        )
        return sql, None
    except PolicyRewriteError as exc:
        if simulate:
            raise  # fail-open is an enforcement policy; a dry run reports the failure
        logger.error("row_security rewrite failed for user=%s: %s", ctx.username, exc)
        if _fail_open():
            _audit(
                ctx, "*REWRITE_ERROR*", connection_id, [], [], "fail_open",
                sql_before=sql, sql_after=None, request_id=request_id,
                notes=str(exc)[:500], composition=_mode,
            )
            return sql, None
        raise PolicyResolutionError(
            "Query refused — row-security rewrite failed (fail-closed). "
            f"Underlying cause: {exc}"
        ) from exc

    # Persist audit rows (best-effort)
    for entry in result.applied:
        try:
            _comp = entry.get("composition") or {}
            _notes = None
            if _comp:
                _notes = (f"composition outcome={_comp.get('outcome')} "
                          f"permissive={_comp.get('permissive_ids')} "
                          f"restrictive={_comp.get('restrictive_ids')}")[:500]
            _audit(
                ctx,
                entry.get("table") or "?",
                connection_id,
                entry.get("row_policies", []),
                entry.get("column_policies", []),
                entry.get("enforcement", "rewrite"),
                sql_before=sql if entry.get("rewritten") else None,
                sql_after=result.sql if entry.get("rewritten") else None,
                request_id=request_id,
                notes=_notes,
                composition=_mode,
            )
        except Exception as exc:
            logger.debug("row_security audit insert failed: %s", exc)

    return result.sql, result


def _audit_admin_entitlement_bypass(ctx: UserContext, sql: str, dialect: str,
                                    connection_id: Optional[int], request_id: Optional[str]) -> None:
    """An admin's query over a table a data-entitlement dimension governs:
    one audit row per such table (mode ``admin_bypass``), naming the dimension
    and the filter the admin would otherwise have had.  Observation: never
    blocks or fails the admin's query."""
    try:
        from core.row_security.entitlement import (
            REWRITE_DIALECT, active_dimensions, compile_for, enabled)
        if not enabled() or not active_dimensions(_db_manager):
            return
        import sqlglot
        from sqlglot import exp as _exp
        tree = sqlglot.parse_one(sql, dialect=dialect or None)
        token = REWRITE_DIALECT.set(dialect or "")
        try:
            plain = UserContext(username=ctx.username, role="viewer", groups=ctx.groups,
                                entitlement_scope=ctx.entitlement_scope)
            seen = set()
            for tbl in tree.find_all(_exp.Table):
                from core.row_security.rewriter import _resolved_table_ref
                tref = _resolved_table_ref(tbl)
                if not tref or tref in seen:
                    continue
                seen.add(tref)
                try:
                    pols = compile_for(plain, connection_id, tref, _db_manager)
                except Exception as exc:          # the admin would have been refused
                    pols = [{"id": "ent:?", "name": "entitlement:refused",
                             "filter_sql": str(exc)[:200], "policy_class": "restrictive"}]
                if pols:
                    _audit_one(ctx, tref, connection_id, pols, [], "admin_bypass",
                               sql_before=sql, sql_after=None, request_id=request_id,
                               notes="admin bypassed data entitlement: "
                                     + "; ".join(f"{p.get('name')} -> {p.get('filter_sql')}" for p in pols)[:450])
        finally:
            REWRITE_DIALECT.reset(token)
    except Exception as exc:
        logger.debug("row_security: admin entitlement bypass audit skipped: %s", exc)


def _audit_one(
    ctx: UserContext,
    table_ref: str,
    connection_id: Optional[int],
    row_policies: List[Dict[str, Any]],
    column_policies: List[Dict[str, Any]],
    mode: str,
    sql_before: Optional[str] = None,
    sql_after: Optional[str] = None,
    request_id: Optional[str] = None,
    notes: Optional[str] = None,
    composition: Optional[str] = None,
) -> None:
    """Fire-and-forget audit insert — never blocks the calling thread.

    Submitted to a dedicated 4-thread pool so async handlers don't pay
    DB latency on every secured query.  Failure is logged via the worker.
    """
    if _db_manager is None:
        return
    db = _db_manager
    def _do_insert():
        try:
            db.record_row_security_audit(
                username=ctx.username,
                role=ctx.role,
                table_ref=table_ref,
                connection_id=connection_id,
                row_policies=row_policies,
                column_policies=column_policies,
                mode=mode,
                sql_before=sql_before,
                sql_after=sql_after,
                request_id=request_id,
                notes=notes,
                composition=composition,
            )
        except Exception as exc:
            logger.warning("row_security audit insert failed (non-fatal): %s", exc)
    try:
        _audit_pool.submit(_do_insert)
    except Exception as exc:
        logger.debug("row_security audit submit failed (non-fatal): %s", exc)


def flush_audit_pool(timeout: float = 5.0) -> None:
    """Test-only helper: wait for pending audit writes.  Production code
    should never call this — the whole point is fire-and-forget."""
    global _audit_pool
    _audit_pool.shutdown(wait=True)
    # Re-create the pool for any subsequent writes (tests may run in series)
    _audit_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="rs-audit-")


# ── Cache invalidation hook ─────────────────────────────────────────────────

# Phase 131 deep-dive #13 — monotonically-increasing policy version.
# Bumped on every invalidate_cache() so external caches (the Published
# View result cache in particular) can mix this into their cache key and
# automatically invalidate when a policy is added/changed/removed.  The
# RLS resolver itself doesn't need this — it uses the cache TTL — but
# downstream consumers benefit from a stronger guarantee.
import threading as _t  # noqa: E402
_policy_version_lock = _t.Lock()
_policy_version: int = 0


def current_policy_version() -> int:
    """Return the in-process row-security policy version counter.

    Bumped by every invalidate_cache() call.  Used by callers that
    maintain their own result caches (e.g. published-view result cache)
    to invalidate when policies change without redesigning their key
    schema.  Reset to 0 on process restart — combine with TTL or a
    persistent monotone source if cross-process consistency is required.
    """
    return _policy_version


def invalidate_cache() -> None:
    """Drop the resolver cache.  Called by the admin API after policy edits.

    Multi-pod note: the cache is in-process, so invalidating on this pod
    does NOT clear sibling pods' caches.  Sibling pods see the new policy
    after ``row_security.cache_resolver_seconds`` (default 30 s).  For
    enterprise deployments this latency is bounded and acceptable; if
    sub-second propagation is required, add a Redis pub/sub listener that
    calls invalidate_cache() on every pod (TODO Phase 142).

    Phase 131 deep-dive #13: also bumps ``_policy_version`` so external
    caches (PV result cache) auto-invalidate.
    """
    global _policy_version
    if _resolver is not None:
        _resolver.invalidate()
    # 2026-10-24 -- the data-entitlement memos (dimensions, compiled filters)
    try:
        from core.row_security.entitlement import invalidate as _ent_invalidate
        _ent_invalidate()
    except Exception as exc:                                  # noqa: BLE001
        logger.debug("entitlement invalidate skipped: %s", exc)
    with _policy_version_lock:
        _policy_version += 1

    # 2026-08-09 (reporting rewire Phase 5) — demote RLS-aware aggregate cubes
    # eagerly on THIS pod.  Correctness does NOT depend on this firing: a
    # secured serve re-checks the content-derived policy fingerprint (and, for
    # scoped entries, exact live signature equality) on every routing pass, so
    # a sibling pod that never sees this call still fails closed to the live
    # path.  This only avoids the wasted routing pass on the pod that took the
    # edit.  Late import + fail-open: agg_cache is optional, and a cache
    # hygiene step must never break a policy write.
    try:
        from core.agg_cache import invalidate_rls_entries as _inv_rls
        _inv_rls()
    except Exception as _exc:      # pragma: no cover - hygiene only
        logger.debug("agg-cache RLS demotion skipped after policy edit: %s", _exc)
