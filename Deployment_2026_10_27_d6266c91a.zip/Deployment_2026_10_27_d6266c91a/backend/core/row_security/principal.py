"""The ONE definition of "who this principal is" for row security.

2026-10-25 -- THE RULE CHANGED, by the owner's decision ("if no AD groups it
should work ... no one should get 403 ... config will decide which published
API should have data policies on it"):

    A principal minted from a PRESENTED CREDENTIAL is RESOLVED.  Its groups
    are whatever the credential's directory returned -- possibly none.  An
    API key is the resolved principal ``api_key:<row id>``: it holds the
    row policies bound to it and its own entitlement values, and nothing
    bound to a group.  Whether a published API applies ANY data policy to
    its keys is the API's own switch (``published_views.entitlement_mode``,
    read as the data-policy switch -- api/published_views/helpers.py::
    with_entitlement_scope, core/row_security/entitlement.py::
    data_policies_off).

``rls_unresolved`` is therefore stamped ONLY where a scope was NOT
established: a group lookup that raised, and the fabricated background
principals (a scheduled report whose owner could not be resolved, a feed
run, a share link with no identity, a federation side with no caller).
Those keep failing CLOSED on a governed table -- nobody is on the other
end of them to read a disclosure, and widening them was never asked for.

What this replaces (2026-09-05 .. 2026-10-25): ``groups_are_unresolvable``
marked a groupless ``api_key`` / ``basic_noauth`` principal unresolved
because "nobody looked its groups up", and ``api/deps.py`` marked an AD
user whose bind returned no memberships the same way.  Measured on the rig:
every API key calling a published view over a table carrying ANY row policy
-- even one bound to some other group -- was refused 403 "Row-security
policies exist for '<table>' but the requesting principal could not be
resolved", and so was a person whose directory simply places them in no
group.  The refusal protected against a GRANT-shaped engine SKIPPING a
governed table for a principal that matched no binding; FB-45 (2026-09-20,
core/row_security/composition.py) closed that hole at its root -- a
principal holding no grant on a table that carries grants reads NO ROWS --
so the marker no longer buys safety for a credentialed principal, only the
403.

ONE MARKER MUST NOT CARRY TWO PROPOSITIONS
------------------------------------------

2026-09-05.  ``rls_unresolved`` acquired a SECOND reader that asks a
DIFFERENT question.  ``core/reports/user_sql_vars.py`` read it as *"there is
no interactive caller, so render ``${user.*}`` against the report OWNER"* --
and stamping the marker on an API-key principal therefore re-pointed
user-variable rendering from the caller to the owner.  A security fix became
a WIDENING: measured, an API-key caller went from ``region IN (NULL)`` to
``region IN ('FINANCE-ALL', 'PAYROLL-EMEA')``.

The two propositions are genuinely different:

    (a) this principal's scope could not be established  -- the rewriter's
    (b) there is NO CALLER to render ${user.*} against   -- user_sql_vars'

A scheduled report or a feed run is (a) TRUE and (b) TRUE.  An interactive
AD user and an API key are (a) FALSE and (b) FALSE.  No single flag can say
all of that.

So (b) gets its own named field, :data:`LIVE_CALLER_KEY`, stamped where
the fact is KNOWN -- ``api/deps.py``, the only module that turns a
PRESENTED CREDENTIAL into a principal.  Nothing else can know it: a
fabricated background principal is a plain dict that nobody authenticated.

Deliberately a POSITIVE marker on the live side rather than a negative one
on the background side.  The background placeholders are minted in six
modules (scheduler, feed, reports, business reports, federation views,
reports authorization); marking those instead would mean the failure mode
of a site that FORGETS the flag is "renders as the owner" -- the widening
this exists to stop.  Marking the live callers makes a forgotten flag
render against the caller's own (empty) scope: ``(NULL)``, zero rows, a
loud log.  Fail-closed in the direction that matters.

:func:`has_live_caller` therefore also accepts a CREDENTIAL TELL --
``auth_method`` / ``api_key_id`` / ``auth_source`` -- because the published-
view and business-report bridges REBUILD consumer dicts and can drop a key
in transit.  That is a safety net, not a second decision: every tell can
only move rendering TOWARDS the caller (narrower), never towards the owner.
"""
from __future__ import annotations

from typing import Any, Optional

#: The binding / entitlement principal TYPE an API key is.  A row policy
#: bound to ``api_key:<row id>`` applies to that key (and to a try-as of it,
#: which IS that key -- core/published_api/try_as.py); a group binding never
#: matches a key, because a key has no directory identity.
API_KEY_PRINCIPAL_TYPE = "api_key"


def api_key_id_of(ctx: Any) -> Optional[str]:
    """The API key's ROW ID as a string when ``ctx`` is an API-key principal,
    else None.

    Read from ``api_key_id`` (what ``api/deps.py::api_key_principal`` mints
    and the PV / BR bridges carry) and, as a second tell, from an
    ``entitlement_scope`` of surface ``api`` (what
    ``api/published_views/helpers.py::with_entitlement_scope`` stamps) -- a
    dict a bridge rebuilt without the first field still names its key.  The
    ``key_prefix`` its ``username`` carries is NOT an identity (8-12 chars
    "for display"; two keys may share one) and is never read here.
    """
    if not isinstance(ctx, dict):
        return None
    kid = ctx.get("api_key_id")
    if kid not in (None, ""):
        return str(kid)
    sc = ctx.get("entitlement_scope")
    if isinstance(sc, (tuple, list)) and len(sc) >= 3 and sc[0] == "api" and sc[2] not in (None, ""):
        return str(sc[2])
    if isinstance(sc, dict) and sc.get("surface") == "api" and sc.get("id") not in (None, ""):
        return str(sc["id"])
    return None


#: Set by ``api/deps.py`` on every principal minted from a PRESENTED
#: CREDENTIAL.  Answers proposition (b) in the module docstring -- "is there
#: a caller?" -- which ``rls_unresolved`` does NOT answer.
LIVE_CALLER_KEY = "live_caller"

#: Fields only an authenticated mint can put on a principal.  Read as a
#: fallback for :data:`LIVE_CALLER_KEY` so a ctx a bridge rebuilt without the
#: flag is still recognised as a caller.  Each of these can only move a
#: decision TOWARDS the caller's own scope, i.e. narrower.
CREDENTIAL_TELLS = ("auth_method", "api_key_id", "auth_source")


def mark_live_caller(ctx: Any) -> Any:
    """Return ``ctx`` stamped :data:`LIVE_CALLER_KEY`.

    Non-mutating and idempotent.  Called only from ``api/deps.py``: a
    principal that did not come out of an authentication step must never
    acquire this flag.
    """
    if not isinstance(ctx, dict):
        return ctx
    if ctx.get(LIVE_CALLER_KEY) is True:
        return ctx
    out = dict(ctx)
    out[LIVE_CALLER_KEY] = True
    return out


def has_live_caller(ctx: Any) -> bool:
    """Is somebody actually on the other end of this principal?

    TRUE for an interactive user, a session, an API key, an AD Basic caller
    and the ``auth.type='none'`` guest -- every one of which arrived on a
    credential, whatever its groups turned out to be.

    FALSE for a fabricated background principal: a scheduled report, a feed
    run, a delivery job.  Those dicts were built server-side from an owner
    name; there is no caller whose scope could be rendered.
    """
    if not isinstance(ctx, dict):
        return False
    if ctx.get(LIVE_CALLER_KEY) is True:
        return True
    return any(str(ctx.get(k) or "").strip() for k in CREDENTIAL_TELLS)
