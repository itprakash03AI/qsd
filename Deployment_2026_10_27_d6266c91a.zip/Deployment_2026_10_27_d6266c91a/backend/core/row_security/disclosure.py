"""Entitlement DISCLOSURE: what the one row-security resolution of a request
decided about data entitlement, told to the consumer (2026-10-24;
docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html section 4 "Disclosure", built
after section 12 listed it as "not in this delivery").

The rule this module exists for: the disclosure comes from the SAME
resolution the query used.  The compiler (``entitlement.compile_for``) and
the engine's entry (``api.secure_sql_report``) RECORD what they decided into
a per-request sink while they decide it; nothing here resolves a dimension,
reads a value or asks the store a second time -- a value computed for a
security gate and then re-derived for the envelope would, one day, disagree
with what the system did.

Three honest states, never conflated:

* ``applied``      -- a dimension narrowed the result: which dimension, on
                      which columns, to which values (or how many);
* ``not_applied``  -- and WHY: ``admin_bypass``, ``row_security_off``,
                      ``entitlement_disabled`` (the kill switch),
                      ``data_policies_off`` (the API's data-policy switch is
                      off for its keys: no row policy, no dimension),
                      ``mode_off`` (a feed's dimension switch), ``no_active_dimension``,
                      ``no_entitled_column`` (dimensions exist, none of the
                      tables this result read carries their columns);
* ``unknown``      -- nothing was observed for this result (``not_observed``:
                      the stored dataset predates the disclosure, or no
                      row-security resolution ran where this process could
                      see it).  Unknown is not empty.

The sink is a ``ContextVar`` holding a LIST: ``asyncio.to_thread`` and the
worker pool (``WorkerPool._start_task``, ``contextvars.copy_context()``) run
their work in a COPY of the context that holds the SAME list object, so a
rewrite on a pool thread appends where the awaiting request reads.

A cached page carries the disclosure of the dataset it came from: the
summary is stamped on the ``DatasetManifest`` sidecar at publish time and
read back on every HIT (``api/published_views/envelope.py``).  The per-
consumer cache scope folds the key / mode and the policy fingerprint, so a
slot is never read by a principal whose resolution would differ.  The
PRINCIPAL is never stored with the dataset: the shared slot (no dimension
anywhere) is read by everyone, and the identity is the request's --
``for_response`` adds it from the consumer the exit already holds, through
``with_entitlement_scope`` -> ``scope_of``, the ONE surface rule.
"""
from __future__ import annotations

import contextlib
import contextvars
import re
from typing import Any, Dict, Iterator, List, Optional
from urllib.parse import quote

__all__ = [
    "collecting", "record", "summarise", "for_response", "headers_for",
    "STATE_APPLIED", "STATE_NOT_APPLIED", "STATE_UNKNOWN", "VALUES_SHOWN_MAX",
    "HEADER_STATE", "HEADER_REASON", "HEADER_DIMENSIONS", "HEADER_MODE",
]

STATE_APPLIED = "applied"
STATE_NOT_APPLIED = "not_applied"
STATE_UNKNOWN = "unknown"

#: at most this many values are LISTED per dimension; beyond it the count
#: alone is disclosed (``value_count`` is always present)
VALUES_SHOWN_MAX = 50
#: ... and in a header (every format): fewer, the header stays readable
HEADER_VALUES_MAX = 10

HEADER_STATE = "X-QS-Entitlement"
HEADER_REASON = "X-QS-Entitlement-Reason"
HEADER_DIMENSIONS = "X-QS-Entitlement-Dimensions"
HEADER_MODE = "X-QS-Entitlement-Mode"

# kinds a recorder may write; the precedence ``summarise`` applies is the
# order of ``_NOT_APPLIED_PRECEDENCE`` below
KIND_APPLIED = "applied"
KIND_ADMIN_BYPASS = "admin_bypass"
KIND_ROW_SECURITY_OFF = "row_security_off"
KIND_DISABLED = "entitlement_disabled"
#: 2026-10-25 -- the published API's data-policy switch is off for its keys:
#: no row policy and no dimension applied (core/row_security/entitlement.py::
#: data_policies_off).  ``mode_off`` stays the FEED's word (its switch
#: governs dimensions only).
KIND_DATA_POLICIES_OFF = "data_policies_off"
KIND_MODE_OFF = "mode_off"
KIND_NO_DIMENSION = "no_active_dimension"
KIND_NOT_ENTITLED = "no_entitled_column"

_NOT_APPLIED_PRECEDENCE = (KIND_ADMIN_BYPASS, KIND_ROW_SECURITY_OFF, KIND_DISABLED,
                           KIND_DATA_POLICIES_OFF, KIND_MODE_OFF, KIND_NO_DIMENSION, KIND_NOT_ENTITLED)

_SINK: contextvars.ContextVar = contextvars.ContextVar("qs_entitlement_disclosure", default=None)


@contextlib.contextmanager
def collecting() -> Iterator[List[Dict[str, Any]]]:
    """Collect every entitlement decision made while the block runs (in this
    task and in the threads it hands work to).  Nested blocks collect into
    the innermost sink."""
    sink: List[Dict[str, Any]] = []
    token = _SINK.set(sink)
    try:
        yield sink
    finally:
        _SINK.reset(token)


def record(kind: str, *, table: Optional[str] = None,
           policies: Optional[List[Dict[str, Any]]] = None, note: Optional[str] = None) -> None:
    """A recorder's one call.  No sink (no request collecting) = nothing."""
    sink = _SINK.get()
    if sink is None:
        return
    entry: Dict[str, Any] = {"kind": str(kind)}
    if table is not None:
        entry["table"] = str(table)
    if policies:
        entry["policies"] = [dict(p) for p in policies]
    if note:
        entry["note"] = str(note)[:300]
    sink.append(entry)


def _access_of(shown: Any) -> Dict[str, Any]:
    """The compiler's ``values`` spelling -> (access, values).  The compiler
    writes a LIST of values, ``"ALL"``, ``"none"`` or
    ``"see_everything (no value)"`` (core/row_security/entitlement.py)."""
    if isinstance(shown, (list, tuple)):
        vals = [str(v) for v in shown]
        return {"access": "values", "values": vals}
    s = str(shown or "")
    if s == "ALL":
        return {"access": "all", "values": []}
    if s.startswith("see_everything"):
        return {"access": "everything_by_rule", "values": []}
    return {"access": "none", "values": []}


def summarise(entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """The identity-free summary of a result's resolution -- what is stored
    beside the dataset and read back on a HIT.

    ``{"state", "applied", "reason", "dimensions": [...]}``; a dimension is
    ``{"name", "access", "values", "value_count", "values_listed"}`` with
    ``access`` one of ``values`` (the list, cut at VALUES_SHOWN_MAX), ``all``
    (an ``is_all`` row), ``none`` (no value, the dimension says see nothing --
    0 rows), ``everything_by_rule`` (no value, see everything).

    Security review of 226c9cdb1: the summary names the DIMENSION only --
    never the tables the filter landed on nor the physical column names.  An
    external consumer must not learn the schema behind an API; the audit row
    (``row_security_audit``) keeps that detail for the admin.
    """
    kinds = [str(e.get("kind") or "") for e in entries]
    if KIND_ADMIN_BYPASS in kinds:
        # the admin's audit (``_audit_admin_entitlement_bypass``) compiles the
        # filter the admin WOULD have had and the compiler records it as
        # applied -- the admin's rows were not filtered: the bypass wins
        return {"state": STATE_NOT_APPLIED, "applied": False, "reason": KIND_ADMIN_BYPASS, "dimensions": []}
    dims: Dict[str, Dict[str, Any]] = {}
    for e in entries:
        if e.get("kind") == KIND_APPLIED:
            for p in e.get("policies") or []:
                _fold_policy(dims, e, p)
    if dims:
        return {"state": STATE_APPLIED, "applied": True, "reason": None,
                "dimensions": [_finish_dimension(d) for d in dims.values()]}
    for reason in _NOT_APPLIED_PRECEDENCE:
        if reason in kinds:
            return {"state": STATE_NOT_APPLIED, "applied": False, "reason": reason, "dimensions": []}
    return {"state": STATE_UNKNOWN, "applied": None, "reason": "not_observed", "dimensions": []}


def _add_unique(target: List[str], items: Any) -> None:
    for x in items or []:
        if x is not None and str(x) not in target:
            target.append(str(x))


def _fold_policy(dims: Dict[str, Dict[str, Any]], entry: Dict[str, Any], policy: Any) -> None:
    """One synthesised policy (the compiler's dict, with its ``entitlement``
    block) folded into the per-dimension summary -- the dimension's name and
    the principal's access, nothing about the table or its columns."""
    del entry          # the table it landed on is not disclosed
    ent = policy.get("entitlement") if isinstance(policy, dict) else None
    if not isinstance(ent, dict):
        return
    name = str(ent.get("dimension") or policy.get("name") or "?")
    d = dims.setdefault(name, {"name": name, "access": None, "values": [], "value_count": 0})
    acc = _access_of(ent.get("values"))
    # one dimension, one access: the SAME principal's values on every table (a
    # second table repeats them); keep the first, union the values
    if d["access"] is None:
        d["access"] = acc["access"]
    _add_unique(d["values"], acc["values"])


def _finish_dimension(d: Dict[str, Any]) -> Dict[str, Any]:
    n = len(d["values"])
    d["value_count"] = n
    d["values_listed"] = n <= VALUES_SHOWN_MAX
    if not d["values_listed"]:
        d["values"] = []                 # the count alone: a long list is not a disclosure
    return d


_REASON_WORDS = {
    "admin_bypass": "an administrator's queries are not filtered by data entitlement (audited)",
    "row_security_off": "row security is switched off in this deployment, so no entitlement is enforced",
    "entitlement_disabled": "data entitlement is switched off (row_security.entitlement_enabled)",
    "data_policies_off": "this API's data-policy switch is off: API keys read the data with no row policy "
                         "and no entitlement dimension applied",
    "mode_off": "this feed's entitlement switch is off: the feed's data is not narrowed by a dimension",
    "no_active_dimension": "no data-entitlement dimension is active",
    "no_entitled_column": "dimensions exist, but none of the tables this result read carries their columns",
    "not_observed": "no entitlement decision was recorded for this result -- it may have been stored "
                    "before disclosure existed; treat the filtering as undetermined, not as absent",
}


def _principal_of(consumer: Optional[Dict[str, Any]], pv: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """``{"type", "id", "mode"}`` from the consumer the exit holds, through
    THE surface rule (``helpers.with_entitlement_scope`` -> ``entitlement.
    scope_of``); never from the stored dataset."""
    from core.row_security.entitlement import scope_of
    if not isinstance(consumer, dict):
        return {"type": "unknown", "id": None, "mode": "apply"}
    scoped = dict(consumer)
    if pv is not None:
        try:
            from api.published_views.helpers import with_entitlement_scope
            scoped = with_entitlement_scope(consumer, pv)
        except Exception:
            scoped = dict(consumer)
    surface, mode, ident = scope_of(type("_Ctx", (), {"entitlement_scope": scoped.get("entitlement_scope")})())
    if surface == "api":
        return {"type": "api_key", "id": ident, "mode": mode}
    if surface == "feed":
        return {"type": "feed_owner_group", "id": ident, "mode": mode}
    return {"type": "user", "id": str(consumer.get("username") or ""), "mode": "apply"}


def for_response(summary: Optional[Dict[str, Any]], *, consumer: Optional[Dict[str, Any]],
                 pv: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """The envelope block: the stored summary (or ``unknown`` when none) plus
    the caller's principal and the surface's mode, plus a sentence."""
    base = summary if isinstance(summary, dict) and summary.get("state") else summarise([])
    principal = _principal_of(consumer, pv)
    dims = [dict(d) for d in (base.get("dimensions") or [])]
    state = str(base.get("state") or STATE_UNKNOWN)
    reason = base.get("reason")
    if state == STATE_APPLIED:
        parts = []
        for d in dims:
            acc = d.get("access")
            if acc == "values":
                vals = d.get("values") or []
                what = ("in (" + ", ".join(vals) + ")") if d.get("values_listed", True) and vals \
                    else f"limited to {int(d.get('value_count') or 0)} values"
            elif acc == "all":
                what = "every value"
            elif acc == "everything_by_rule":
                what = "every value (no value held; the dimension's rule)"
            else:
                what = "no value held -- no rows"
            parts.append(f"{d.get('name')}: {what}")
        note = "Filtered by data entitlement: " + "; ".join(parts)
    elif state == STATE_NOT_APPLIED:
        note = "Not filtered by data entitlement: " + _REASON_WORDS.get(str(reason), str(reason))
    else:
        note = "Entitlement filtering could not be determined: " + _REASON_WORDS.get(str(reason), str(reason))
    return {
        "state": state,
        "applied": base.get("applied"),
        "reason": reason,
        "mode": principal["mode"],
        "principal": {"type": principal["type"], "id": principal["id"]},
        "dimensions": dims,
        "note": note,
    }


_HEADER_UNSAFE = re.compile(r"[^\x20-\x7e]")


def _header_safe(text: str) -> str:
    """A header value: ASCII, no control characters (a value with anything
    else is percent-encoded, never dropped)."""
    if _HEADER_UNSAFE.search(text) or "," in text or ";" in text or "=" in text:
        return quote(text, safe="")
    return text


def headers_for(block: Dict[str, Any]) -> Dict[str, str]:
    """The same disclosure for csv / parquet / excel consumers, who see only
    headers.  ``X-QS-Entitlement`` is one of ``applied`` / ``not-applied`` /
    ``unknown``; the reason and the dimensions follow."""
    state = str(block.get("state") or STATE_UNKNOWN)
    out = {HEADER_STATE: {STATE_APPLIED: "applied", STATE_NOT_APPLIED: "not-applied"}.get(state, "unknown"),
           HEADER_MODE: str(block.get("mode") or "apply")}
    if block.get("reason"):
        out[HEADER_REASON] = str(block["reason"])
    dims = block.get("dimensions") or []
    if dims:
        rendered = []
        for d in dims:
            name = _header_safe(str(d.get("name") or "?"))
            acc = d.get("access")
            if acc == "values":
                vals = [str(v) for v in (d.get("values") or [])]
                n = int(d.get("value_count") or len(vals))
                if vals and d.get("values_listed", True) and n <= HEADER_VALUES_MAX:
                    rendered.append(f"{name}={','.join(_header_safe(v) for v in vals)}")
                else:
                    rendered.append(f"{name}={n} values")
            elif acc == "all":
                rendered.append(f"{name}=all")
            elif acc == "everything_by_rule":
                rendered.append(f"{name}=all (no value; rule)")
            else:
                rendered.append(f"{name}=none")
        out[HEADER_DIMENSIONS] = "; ".join(rendered)
    return out
