"""Data entitlement by column (2026-10-24; docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html).

The owner: "user level entitlement on data ... let's say I am executing on
BQB and that query has sap_company_id and I am entitled to see
sap_company_id = xyz, then the filter should be applied automatically ...
think in generic ways".

ONE sentence: an entitlement DIMENSION compiles, per principal and per
table, into a RESTRICTIVE row policy that the existing resolver hands to the
existing rewriter.  The dimension says which COLUMN NAMES carry it
(``entitlement_dimension_columns``); the column catalog says which TABLES
carry those names (``core/schema_catalog.ColumnCatalog`` -- never the source);
``entitlement_values`` say which values this principal holds.  Everything
after -- composition (restrictive = AND), the leaf wrap, quoting, audit, the
dry run, cache scope, signatures -- is the row-security engine's unchanged
code, so it applies on every path that already runs it (BQB, SQL page,
datasets, reports, dashboards, published APIs, feeds).

Who the principal is (``UserContext.entitlement_scope``):
  * none            a PERSON: ``user:<name>`` + its directory groups + its
                    QueryStudio user groups -- always on;
  * ("api", mode, key_id)       a published-API consumer: governed only when
                    the view's ``entitlement_mode`` is ``apply``; then the
                    KEY's own values;
  * ("feed", mode, group_id)    a feed run: governed only on ``apply``; then
                    the feed OWNER GROUP's values (no owner group = refused).

Fail CLOSED everywhere, with ONE named exception: a principal with NO value
row on a dimension whose rule says ``see_everything``.  An unreadable store,
a table whose columns are unknown, a value list over the inline cap are
REFUSALS (``EntitlementRefused`` -- a rewrite error that never fail-opens),
never "see everything".  Admins bypass (``secure_sql``), audited.
"""
from __future__ import annotations

import contextvars
import logging
import threading
import time
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from core.row_security.rewriter import PolicyRewriteError

logger = logging.getLogger(__name__)

SEE_NOTHING = "see_nothing"
SEE_EVERYTHING = "see_everything"
NO_VALUE_RULES = (SEE_NOTHING, SEE_EVERYTHING)
VALUE_TYPES = ("text", "integer")
PRINCIPAL_TYPES = ("user", "group", "api_key", "feed_owner_group")
MODES = ("off", "apply")

#: the dialect of the rewrite in progress (set by SqlRewriter.rewrite) --
#: the predicate is quoted for THIS dialect, never a cached other one
REWRITE_DIALECT: contextvars.ContextVar = contextvars.ContextVar("qs_entitlement_dialect", default="")
#: True while the rewriter resolves a table whose name had a QUOTED part --
#: the catalog lookup then matches the exact spelling only (quoting changes
#: case folding per dialect; the dotted string has lost it).
REF_QUOTED: contextvars.ContextVar = contextvars.ContextVar("qs_entitlement_ref_quoted", default=False)


#: the KINDS a refusal declares (2026-10-24, "test as feed"): a reader that must
#: say "could not be determined" apart from "refused by the feed's shape" reads
#: ``EntitlementRefused.kind`` -- never the sentence.
KIND_REFUSED = "refused"                  # a certified refusal (cap, shape)
KIND_NO_PRINCIPAL = "no_principal"        # apply with no owner group / no key
KIND_STORE_UNREADABLE = "store_unreadable"  # the store / catalog could not be READ
KIND_SCHEMA_UNKNOWN = "schema_unknown"    # the table's columns are not known yet
KIND_TOO_MANY_VALUES = "too_many_values"
UNDETERMINED_KINDS = frozenset({KIND_STORE_UNREADABLE, KIND_SCHEMA_UNKNOWN})


class EntitlementRefused(PolicyRewriteError):
    """A query an entitlement cannot certify -- refused, never fail-open.

    ``kind`` says WHY in one word (the ``KIND_*`` vocabulary above); the
    default is a plain refusal."""

    def __init__(self, message: str, kind: str = KIND_REFUSED):
        super().__init__(message)
        self.kind = kind


def _cfg(name: str, default: Any) -> Any:
    try:
        from core.config import get as _get
        v = _get("row_security", name, default)
        return default if v is None else v
    except Exception:
        return default


def enabled() -> bool:
    """The kill switch (``row_security.entitlement_enabled``, default true)."""
    return bool(_cfg("entitlement_enabled", True))


def inline_max_values() -> int:
    try:
        return max(1, int(_cfg("entitlement_inline_max_values", 1000)))
    except (TypeError, ValueError):
        return 1000


# ── the active dimensions (memoised like the resolver, invalidated on write) ──

_lock = threading.RLock()
_dims_memo: Dict[str, Any] = {"at": 0.0, "dims": None, "db": None, "marker": None}
_compile_memo: Dict[Tuple, Tuple[float, List[dict]]] = {}


def _ttl() -> float:
    try:
        from core.config import row_security as _rs
        return float(max(0, int(_rs.cache_resolver_seconds)))
    except Exception:
        return 30.0


def _policy_marker(db: Any) -> str:
    """The policy set's marker (fingerprint incl. entitlement values) as the
    cache keys see it; undecidable -> a value that never matches a memo."""
    try:
        from core.row_security.cache_scope import policy_set_marker
        return policy_set_marker(db)
    except Exception:                                   # noqa: BLE001 -- never a stale hit
        return f"unverified:{time.monotonic()}"


def invalidate() -> None:
    """Every entitlement write calls this (with the policy cache's own
    invalidation) -- a value edit is seen at once on this pod, and within the
    TTL on another (the fingerprint moves every scoped cache key)."""
    with _lock:
        _dims_memo.update({"at": 0.0, "dims": None, "db": None, "marker": None})
        _compile_memo.clear()


def active_dimensions(db: Any) -> List[Dict[str, Any]]:
    """The ACTIVE dimensions with their columns.  A store that cannot be read
    REFUSES (raises ``EntitlementRefused``) -- never "there are none"."""
    if db is None or not hasattr(db, "list_entitlement_dimensions"):
        return []           # a pre-entitlement store (stand-ins): nothing to govern
    now = time.monotonic()
    # keyed by the policy set's marker as well (2026-10-25): a dimension
    # created or retired on another pod moves the marker the cache keys fold;
    # this memo must not answer the old set under the new key
    marker = _policy_marker(db) if _ttl() > 0 else None
    with _lock:
        if (_dims_memo["dims"] is not None and _dims_memo["db"] is db
                and _dims_memo["marker"] == marker
                and now - _dims_memo["at"] < _ttl()):
            return _dims_memo["dims"]
    try:
        dims = [d for d in db.list_entitlement_dimensions(active_only=True) if d.get("columns")]
    except Exception as exc:
        raise EntitlementRefused(
            f"data entitlements could not be read ({type(exc).__name__}: {exc}) -- "
            f"refusing rather than serving unfiltered data") from exc
    with _lock:
        _dims_memo.update({"at": now, "dims": dims, "db": db, "marker": marker})
    return dims


def any_active(db: Any) -> bool:
    """Is any dimension active?  For the cache-scope decision; an unreadable
    store answers True (scope per principal -- the closed direction)."""
    if not enabled():
        return False
    try:
        return bool(active_dimensions(db))
    except EntitlementRefused:
        return True


# ── the switch: stored, or config ─────────────────────────────────────────

#: the config key whose value a surface's UNSET switch takes
DEFAULT_MODE_KEYS = {"api": ("published_views", "default_data_policy_mode", "apply"),
                     "feed": ("feed_generation", "default_entitlement_mode", "off")}


def default_mode(surface: str) -> str:
    """The config default for ``surface`` ("api" | "feed"), read live."""
    section, key, fallback = DEFAULT_MODE_KEYS[surface]
    try:
        from core.config import get as _get
        v = str(_get(section, key, fallback) or fallback).strip().lower()
    except Exception:                                  # noqa: BLE001 -- the declared value
        v = fallback
    return v if v in MODES else fallback


def effective_mode(stored: Any, surface: str) -> str:
    """THE data-policy switch of one published API / feed (2026-10-25, the
    owner: "everything should be based on config"): its OWN switch when one
    was set (``off`` | ``apply``), else the config default for its surface --
    read on every call, so a config change moves every API / feed nobody
    pinned.  Every reader of ``entitlement_mode`` comes through here."""
    s = str(stored or "").strip().lower()
    return s if s in MODES else default_mode(surface)


def mode_face(stored: Any, surface: str) -> Dict[str, Any]:
    """What a row shows: the effective mode, what is stored, and whose
    decision it is (``api`` / ``feed`` = set on the object, ``config``)."""
    s = str(stored or "").strip().lower()
    pinned = s in MODES
    return {"entitlement_mode": s if pinned else default_mode(surface),
            "entitlement_mode_stored": s if pinned else None,
            "entitlement_mode_source": surface if pinned else "config",
            "entitlement_mode_default": default_mode(surface)}


def may_set_switch(user: Optional[Dict[str, Any]]) -> bool:
    """May ``user`` SET an object's own switch (``row_security.
    data_policy_switch_roles``; "admin" = admin and super_admin)."""
    roles = _cfg("data_policy_switch_roles", ["admin"])
    roles = [str(r).strip().lower() for r in ([roles] if isinstance(roles, str) else roles or [])]
    if not user:
        return False
    if "admin" in roles:
        from core.roles import is_admin_like
        if is_admin_like(user):
            return True
    return str(user.get("role") or "").strip().lower() in roles


# ── who is asking ─────────────────────────────────────────────────────────

def scope_of(ctx: Any) -> Tuple[str, str, Optional[str]]:
    """``(surface, mode, id)``: ("person", "apply", None) | ("api", mode,
    key_id) | ("feed", mode, owner_group_id)."""
    sc = getattr(ctx, "entitlement_scope", None)
    if not sc:
        return ("person", "apply", None)
    if isinstance(sc, dict):
        surface, mode, ident = sc.get("surface"), sc.get("mode"), sc.get("id")
    else:
        surface, mode, ident = (tuple(sc) + (None, None, None))[:3]
    surface = str(surface or "person")
    mode = str(mode or "off").lower()
    return (surface, mode if mode in MODES else "off", None if ident in (None, "") else str(ident))


def data_policies_off(ctx: Any) -> bool:
    """THE published API's data-policy switch, read for one principal
    (2026-10-25; the owner: "config will decide which published API should
    have data policies on it").

    True when ``ctx`` calls through a published API (surface ``api``) whose
    ``entitlement_mode`` is ``off``: the key reads the API's data with NO row
    policy and NO entitlement dimension applied -- the resolver returns no
    row policy for it, the rewriter skips the table (never WHERE FALSE,
    never a refusal), the disclosure says ``data_policies_off``.  Under
    ``apply`` the key is the resolved principal ``api_key:<id>``: its own
    bindings and values, FB-45's composition for what it does not hold.

    Never True for a person (a signed-in person is governed as a person on
    every road, whatever the API's switch -- security review 2026-10-24) nor
    for a feed (a feed's switch governs its DIMENSIONS only; its stored row
    policies and its fail-closed principal are the feed's own rules).
    """
    surface, mode, _ident = scope_of(ctx)
    return surface == "api" and mode != "apply"


def principals_of(ctx: Any, db: Any, scope: Tuple[str, str, Optional[str]]) -> List[Tuple[str, str]]:
    surface, _mode, ident = scope
    if surface == "api":
        if not ident:
            raise EntitlementRefused("entitlement applies to this API but the caller has no API key "
                                     "-- refusing rather than guessing whose values apply",
                                     kind=KIND_NO_PRINCIPAL)
        return [("api_key", ident)]
    if surface == "feed":
        if not ident:
            raise EntitlementRefused("entitlement applies to this feed but the feed has no owner group "
                                     "-- set the feed's owner group (its values are the feed's)",
                                     kind=KIND_NO_PRINCIPAL)
        return [("feed_owner_group", ident)]
    out: List[Tuple[str, str]] = []
    name = str(getattr(ctx, "username", "") or "")
    if name:
        out.append(("user", name))
    groups = list(getattr(ctx, "groups", ()) or ())
    if name and hasattr(db, "local_groups_of"):
        try:
            groups += list(db.local_groups_of(name))
        except Exception as exc:
            raise EntitlementRefused(f"the user's groups could not be read ({exc}) -- refusing",
                                     kind=KIND_STORE_UNREADABLE) from exc
    for g in dict.fromkeys(str(g) for g in groups if str(g).strip()):
        out.append(("group", g))
    return out


# ── does this table carry a dimension's column? ───────────────────────────

def table_columns(db: Any, connection_id: Optional[int], table_ref: str) -> Optional[List[str]]:
    """The table's column NAMES from the column catalog (never the source),
    or None when nothing is known (the caller refuses).

    Only names that CERTAINLY denote the same object are tried: the
    reference as written; the same name with the CONNECTION'S OWN default
    catalog / schema removed or filled in (``<its catalog>.<its schema>.t``
    = ``<its schema>.t`` = ``t``); a local table's logical name
    (``__lt__orders`` -> ``orders``).  Never an arbitrary shorter suffix
    (security review 2026-10-24): ``evil.sales.orders`` read through a
    ``sales.orders`` entry -- another catalog's table -- would compile no
    filter for a column the real table has."""
    if connection_id is None:
        return None
    from core.schema_catalog import ColumnCatalog
    cat = ColumnCatalog(db)
    parts = [p.strip('"`[]') for p in str(table_ref).split(".") if p.strip('"`[]')]
    if not parts:
        return None
    for c in _same_object_names(db, int(connection_id), parts):
        entry = cat.get_entry(int(connection_id), c)
        cols = (entry or {}).get("columns") or []
        names = [str(x.get("name")) for x in cols if isinstance(x, dict) and x.get("name")]
        if names:
            return names
    return None


# The connector types whose session default CATALOG is the ``database``
# setting -- read from the connectors themselves (2026-10-24, security
# review): only core/connectors/snowflake_connector.py passes ``database`` to
# its session; Trino, Athena and Databricks use ``catalog`` / ``schema``.  On
# every other type ``database`` names no default here (exact spelling only).
_DATABASE_IS_CATALOG = frozenset({"snowflake"})


def _connection_defaults(db: Any, connection_id: int) -> Tuple[str, str]:
    """(default catalog, default schema) of the connection, lower-cased ('' unknown)."""
    try:
        conn = db.get_connection(connection_id) or {}
    except Exception:
        return "", ""
    cfg = conn.get("config") or {}
    ctype = str(conn.get("connection_type") or "").lower()
    cat_d = str(cfg.get("catalog") or "").strip()
    sch_d = str(cfg.get("schema") or "").strip()
    database = str(cfg.get("database") or "").strip()
    if database and ctype in _DATABASE_IS_CATALOG and not cat_d:
        cat_d = database
    return cat_d.lower(), sch_d.lower()


def _same_object_names(db: Any, connection_id: int, parts: List[str]) -> List[str]:
    """Every spelling of ``parts`` that names the SAME object on this
    connection, the reference as written first.  The defaults are dropped or
    filled in only for an UNQUOTED name (``REF_QUOTED``): unquoted parts fold
    the same way as the configured default on every dialect; a quoted part
    may not (security review 2026-10-24)."""
    out = [".".join(parts)]
    if REF_QUOTED.get():
        return out
    cat_d, sch_d = _connection_defaults(db, connection_id)
    low = [p.lower() for p in parts]
    if len(parts) == 3 and cat_d and low[0] == cat_d:
        out.append(".".join(parts[1:]))
        if sch_d and low[1] == sch_d:
            out.append(parts[2])
    elif len(parts) == 2:
        if cat_d:           # a two-part name resolves under the connection's catalog
            out.append(f"{cat_d}.{'.'.join(parts)}")
        if sch_d and low[0] == sch_d:
            out.append(parts[1])
    elif len(parts) == 1:
        if sch_d:
            out.append(f"{sch_d}.{parts[0]}")
            if cat_d:
                out.append(f"{cat_d}.{sch_d}.{parts[0]}")
    if parts[-1].startswith("__lt__") and len(parts) == 1:
        out.append(parts[-1][len("__lt__"):])
    return list(dict.fromkeys(out))


def tables_carrying(db: Any, dim: Dict[str, Any], limit: int = 1000) -> Dict[str, Any]:
    """The catalogued tables that carry one of ``dim``'s columns -- where its
    filter WILL land (the admin page's "applies to").  The catalog only."""
    from core.db.models import CatalogTableColumn
    wanted: Dict[str, List[Optional[int]]] = {}
    for c in dim.get("columns") or []:
        wanted.setdefault(str(c["column_name"]).lower(), []).append(c.get("connection_id"))
    out: List[Dict[str, Any]] = []
    truncated = False
    with db.get_session(read_only=True) as session:
        q = session.query(CatalogTableColumn.connection_id, CatalogTableColumn.table_name,
                          CatalogTableColumn.columns_json).order_by(
            CatalogTableColumn.connection_id, CatalogTableColumn.table_name)
        for conn_id, table, cols in q.yield_per(500):
            for col in cols or []:
                name = str((col or {}).get("name") or "") if isinstance(col, dict) else ""
                conns = wanted.get(name.lower())
                if conns is None or not (None in conns or conn_id in conns):
                    continue
                if len(out) >= limit:
                    truncated = True
                    break
                out.append({"connection_id": conn_id, "table": table, "column": name})
                break
            if truncated:
                break
    return {"tables": out, "truncated": truncated}


# ── rendering ─────────────────────────────────────────────────────────────

def _quote_ident(name: str, dialect: str) -> str:
    from core.row_security.rewriter import UnexpressiblePolicyError
    from core.sql_filter_wrapper import IdentifierRenderError, quote_identifier_for_dialect
    try:
        return quote_identifier_for_dialect(name, dialect or None, always_quote=True)
    except IdentifierRenderError as exc:
        raise UnexpressiblePolicyError(
            f"entitlement column {name!r} cannot be written on dialect {dialect or 'unknown'!r}: {exc}") from exc


def render_value(value: Any, value_type: str) -> str:
    """One literal.  ``integer``: a whole number or refused; ``text``: quoted,
    quotes doubled (the resolver's own literal rule)."""
    if value_type == "integer":
        try:
            return str(int(str(value).strip()))
        except (TypeError, ValueError):
            raise EntitlementRefused(f"entitlement value {value!r} is not a whole number "
                                     f"but its column is declared integer")
    s = str(value).replace("'", "''")
    return f"'{s}'"


def _valid_today(row: Dict[str, Any], today: date) -> bool:
    def _d(x):
        if not x:
            return None
        if isinstance(x, date):
            return x
        try:
            return date.fromisoformat(str(x)[:10])
        except ValueError:
            return None
    vf, vt = _d(row.get("valid_from")), _d(row.get("valid_to"))
    return (vf is None or vf <= today) and (vt is None or vt >= today)


def _disclose_compiled(table_ref: str, out: List[Dict[str, Any]]) -> None:
    """Tell the request's disclosure sink what THIS compile decided for
    ``table_ref`` (core/row_security/disclosure.py) -- the one resolution the
    query used, recorded as it is made.  No sink = nothing."""
    from core.row_security import disclosure as _disc
    if out:
        _disc.record(_disc.KIND_APPLIED, table=table_ref, policies=out)
    else:
        _disc.record(_disc.KIND_NOT_ENTITLED, table=table_ref)


def compile_for(ctx: Any, connection_id: Optional[int], table_ref: str, db: Any) -> List[Dict[str, Any]]:
    """The synthesised RESTRICTIVE row policies this principal gets on this
    table -- [] when no dimension governs it (or the surface is ``off``).

    Every branch RECORDS its decision for the disclosure (2026-10-24,
    ``core/row_security/disclosure.py``): applied with the policies, or why
    nothing applied -- the envelope says what this very call decided, never
    what a second look would."""
    from core.row_security import disclosure as _disc
    if not enabled():
        _disc.record(_disc.KIND_DISABLED)
        return []
    if db is None:
        return []
    scope = scope_of(ctx)
    if scope[0] == "api" and scope[1] != "apply":
        # the API's data-policy switch (data_policies_off): the resolver also
        # drops the stored row policies for this key; said as ONE reason --
        # and FIRST (2026-10-25): for an API switched off the switch is why
        # nothing applied, whether or not a dimension exists
        _disc.record(_disc.KIND_DATA_POLICIES_OFF)
        return []
    dims = active_dimensions(db)
    if not dims:
        _disc.record(_disc.KIND_NO_DIMENSION)
        return []
    if scope[0] == "feed" and scope[1] != "apply":
        _disc.record(_disc.KIND_MODE_OFF)
        return []
    relevant = []
    for d in dims:
        cols = [c for c in d["columns"]
                if c.get("connection_id") is None or (connection_id is not None
                                                      and int(c["connection_id"]) == int(connection_id))]
        if cols:
            relevant.append((d, cols))
    if not relevant:
        _disc.record(_disc.KIND_NOT_ENTITLED, table=table_ref)
        return []
    dialect = REWRITE_DIALECT.get() or ""
    # 2026-10-25 (rig): keyed by the policy set's FINGERPRINT too -- the SAME
    # memo the scoped cache keys fold (core/row_security/cache_scope.py).  On
    # its own 30 s clock this memo outlived a value edit made on another pod
    # while the fingerprint had already moved: the published-API pod ran a
    # fresh query under the NEW cache key with the OLD (empty) values and
    # served that slot for good.  Now the two move together.
    key = (tuple(getattr(ctx, "principal_ids", lambda: [])()), scope, connection_id, table_ref, dialect,
           bool(REF_QUOTED.get()), _policy_marker(db) if _ttl() > 0 else None)
    now = time.monotonic()
    with _lock:
        hit = _compile_memo.get(key)
        if hit and now - hit[0] < _ttl():
            _disclose_compiled(table_ref, hit[1])
            return hit[1]
    try:
        names = table_columns(db, connection_id, table_ref)
    except Exception as exc:
        raise EntitlementRefused(
            f"the columns of '{table_ref}' could not be read from the catalog ({exc}) -- refusing: "
            f"it may carry an entitled column", kind=KIND_STORE_UNREADABLE) from exc
    if names is None:
        raise EntitlementRefused(
            f"'{table_ref}' may carry an entitled column, but its columns are not known to QueryStudio "
            f"yet -- an admin can refresh the schema of this connection (Data Catalog -> refresh); "
            f"until then the query is refused rather than served unfiltered", kind=KIND_SCHEMA_UNKNOWN)
    lower = {n.lower(): n for n in names}
    governed = []
    for d, cols in relevant:
        hit_cols = [(lower[c["column_name"].lower()], c.get("value_type") or "text")
                    for c in cols if c["column_name"].lower() in lower]
        if hit_cols:
            # one filter per column (a table carrying two aliases is filtered on both)
            governed.append((d, list(dict.fromkeys(hit_cols))))
    if not governed:
        out: List[Dict[str, Any]] = []
    else:
        principals = principals_of(ctx, db, scope)
        try:
            rows = db.values_for_principals([d["id"] for d, _ in governed], principals)
        except Exception as exc:
            raise EntitlementRefused(f"entitlement values could not be read ({exc}) -- refusing",
                                     kind=KIND_STORE_UNREADABLE) from exc
        today = datetime.now(timezone.utc).date()
        held: Dict[int, Dict[str, Any]] = {}
        for r in rows:
            if not _valid_today(r, today):
                continue
            h = held.setdefault(int(r["dimension_id"]), {"all": False, "values": []})
            if r.get("is_all"):
                h["all"] = True
            elif r.get("value") is not None:
                h["values"].append(str(r["value"]))
        out = []
        for d, cols in governed:
            h = held.get(int(d["id"]))
            if h and h["all"]:
                filt, shown = "1 = 1", "ALL"
            elif h and h["values"]:
                vals = list(dict.fromkeys(h["values"]))
                if len(vals) > inline_max_values():
                    raise EntitlementRefused(
                        f"{len(vals)} values of '{d['name']}' exceed the inline limit of "
                        f"{inline_max_values()} (row_security.entitlement_inline_max_values) -- "
                        f"grant ALL, or split the values across groups", kind=KIND_TOO_MANY_VALUES)
                preds = []
                for col, vt in cols:
                    preds.append(f"{_quote_ident(col, dialect)} IN ("
                                 + ", ".join(render_value(v, vt) for v in vals) + ")")
                filt, shown = " AND ".join(preds), vals
            elif str(d.get("no_value_behaviour")) == SEE_EVERYTHING:
                filt, shown = "1 = 1", "see_everything (no value)"
            else:
                filt, shown = "1 = 0", "none"
            out.append({
                "id": f"ent:{d['id']}", "name": f"entitlement:{d['name']}", "source": "entitlement",
                "table_pattern": table_ref, "filter_sql": filt, "policy_class": "restrictive",
                "enforcement": "rewrite", "priority": 0, "enabled": True,
                "entitlement": {"dimension": d["name"], "columns": [c for c, _ in cols],
                                "values": shown, "principals": [f"{t}:{i}" for t, i in principals]},
            })
        if out:
            try:   # a synthesised policy is a policy: the shared cache slot must close
                from core.row_security.cache_scope import note_policies_exist
                note_policies_exist()
            except Exception as exc:
                logger.debug("cache-scope note skipped: %s", exc)
    with _lock:
        _compile_memo[key] = (now, out)
        if len(_compile_memo) > 4000:
            _compile_memo.clear()
    _disclose_compiled(table_ref, out)
    return out


def explain_for(ctx: Any, db: Any) -> List[Dict[str, Any]]:
    """What THIS principal holds, per active dimension -- ``/api/me/entitlements``."""
    dims = active_dimensions(db)
    if not dims:
        return []
    scope = scope_of(ctx)
    principals = principals_of(ctx, db, scope)
    rows = db.values_for_principals([d["id"] for d in dims], principals)
    today = datetime.now(timezone.utc).date()
    out = []
    for d in dims:
        mine = [r for r in rows if int(r["dimension_id"]) == int(d["id"]) and _valid_today(r, today)]
        allv = any(r.get("is_all") for r in mine)
        vals = sorted({str(r["value"]) for r in mine if r.get("value") is not None and not r.get("is_all")})
        out.append({"dimension": d["name"], "columns": [c["column_name"] for c in d["columns"]],
                    "values": "all" if allv else vals,
                    "no_value_rule": d.get("no_value_behaviour") or SEE_NOTHING,
                    "you_see": ("everything" if allv else
                                (f"{len(vals)} value(s)" if vals else
                                 ("everything (no value; the dimension's rule)"
                                  if d.get("no_value_behaviour") == SEE_EVERYTHING else "nothing")))})
    return out
