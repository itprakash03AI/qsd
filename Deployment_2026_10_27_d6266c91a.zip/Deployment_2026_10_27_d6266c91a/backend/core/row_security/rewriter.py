"""sqlglot-based SQL rewriter — wraps protected tables in WHERE-filtered
subqueries and applies column include/exclude/mask transformations.

Architecture:
    secure_sql(...) parses the query, walks every Table node, and replaces
    each one with a subquery of the form

        (SELECT <projection> FROM <original_table_or_subquery>
         WHERE <combined_row_filter>) AS <original_alias>

    Nothing else about the query is touched — joins, CTEs, set operations,
    window functions, aggregates all continue to work because the rewrite
    happens at the leaf relations.

Threat model:
    - filter_sql is admin-authored.  We do NOT sanitise it; an admin who
      can create policies could already write any SQL.
    - ``${user.<attr>}`` substitutions are SQL-escaped (single-quote
      doubling) so untrusted user data never escapes a string literal.
    - Parse failures are surfaced as ``PolicyRewriteError`` so the calling
      layer can decide whether to fail-closed (refuse query) or fail-open
      (run original).  Default is fail-closed per ``row_security.fail_open``.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

try:
    import sqlglot
    from sqlglot import exp
    _HAS_SQLGLOT = True
except Exception:  # pragma: no cover - sqlglot is a hard dep but be defensive
    _HAS_SQLGLOT = False
    sqlglot = None
    exp = None

from core.row_security.resolver import (
    PolicyResolver,
    UserContext,
    substitute_vars,
)
from core.row_security.composition import (
    OUTCOME_CEILING_UNBOUND,
    OUTCOME_UNGOVERNED,
    compose_row_filters,
    effective_class,
)

#: 2026-10-25 -- a table skipped because the published API the caller holds a
#: key for switches its data policies OFF (core/row_security/entitlement.py::
#: data_policies_off): no row policy, no dimension, never WHERE FALSE.
OUTCOME_DATA_POLICIES_OFF = "data_policies_off"

logger = logging.getLogger(__name__)


class PolicyRewriteError(RuntimeError):
    """Raised when the rewriter cannot safely apply policies."""


class SchemaLookupError(RuntimeError):
    """The registered schema lookup could not answer "what columns does this
    table have".

    2026-09-05.  ``core.row_security.api._schema_lookup_adapter`` used to
    catch every exception and return ``[]``, so a catalog that was DOWN and a
    table that genuinely has no known columns arrived at the projection
    builder as the same value — the invariant this repo keeps being bitten
    by.  The adapter now raises this instead, and
    :func:`SqlRewriter.rewrite` carries the reason into the projection so a
    refusal names the catalog rather than the policy, and the surviving
    DuckDB fallback logs that it degraded.

    NOT a :class:`PolicyRewriteError`: it says nothing about whether a policy
    can be applied, only that one input was unavailable."""


class UnresolvedPrincipalError(PolicyRewriteError):
    """A governed table was reached with a principal we could not resolve.

    Distinct from :class:`PolicyRewriteError` because it must NEVER be
    fail-opened: the whole point is that continuing would serve unfiltered
    rows.  ``core.row_security.api`` re-raises it as PolicyResolutionError so
    callers turn it into a hard 403.
    """


class PolicyParseError(PolicyRewriteError):
    """Raised specifically when sqlglot fails to parse the input SQL.

    Separate subclass so the API layer can let the bad SQL through to the
    underlying engine — which will emit a clearer parse error than us
    blaming row-security.  Without this distinction users see HTTP 403
    "row-security failed" for what is actually plain bad SQL.
    """


class EmptyPolicyFilterError(PolicyRewriteError):
    """A row policy MATCHED this principal but its rendered ``filter_sql``
    is EMPTY (empty/whitespace template, or substitution collapsed it).

    2026-08-20 — before this class existed the empty clause was silently
    dropped, the combined WHERE degraded to ``WHERE TRUE``, and the audit
    trail recorded the table as ``rewritten`` — the policy served the table
    UNFILTERED while claiming enforcement.  That is fail-open in the
    security direction, so this error must NEVER be fail-opened:
    ``core.row_security.api`` catches it BEFORE the generic
    ``PolicyRewriteError`` handler (which honours ``row_security.fail_open``)
    and always refuses the query, exactly like
    :class:`UnresolvedPrincipalError`.
    """


class UnexpressiblePolicyError(PolicyRewriteError):
    """A policy MATCHED this principal and table, and could not be expressed.

    2026-09-05.  The no-schema column-policy fallback emits
    ``* REPLACE (…)`` / ``* EXCLUDE (…)`` only for DuckDB; on every other
    dialect an include/mask policy without a resolvable schema raised the
    GENERIC :class:`PolicyRewriteError`, whose handler honours
    ``row_security.fail_open`` and returns the ORIGINAL sql — the masked
    column in cleartext, with a policy hit in the audit trail.

    That is the same shape as :class:`EmptyPolicyFilterError`: the
    "degraded" outcome grants exactly the access the policy exists to
    prevent, so it must never fail open.  ``core.row_security.api`` catches
    this BEFORE the fail-open handler and always refuses.

    Note the asymmetry, which is deliberate: a rewriter that cannot run AT
    ALL (sqlglot missing) resolves no policies and stays under the operator's
    fail-open switch.  This class is only for "a policy applies and we could
    not apply it".
    """


@dataclass
class RewriteResult:
    sql: str
    applied: List[Dict[str, Any]]            # per-table policy info for audit
    skipped: List[Dict[str, Any]]            # per-table tables where no policy applied
    mode_per_table: Dict[str, str]           # rewrite | audit_only | view | native_lf

    @property
    def changed(self) -> bool:
        return any(t.get("rewritten") for t in self.applied)


# ── Column projection helpers ──────────────────────────────────────────────

def _build_column_projection(
    dialect: str,
    cols_in_table: Optional[List[str]],
    column_policies: List[Dict[str, Any]],
    schema_error: Optional[str] = None,
) -> str:
    """Return a SELECT-list string applying the union of column policies.

    ``cols_in_table`` is the list of columns we know belong to this table.
    For ``include``/``exclude`` policies we need this so we can expand the
    allow/denylist.  When unknown (caller couldn't introspect schema), we
    fall back to ``*`` for include/exclude and rely on the DB to error if
    the policy references missing columns.

    ``mask`` policies don't need the column list — they emit explicit
    ``mask_expr AS col`` projections; everything else stays as ``*`` or
    the include/exclude projection.

    ``schema_error`` (2026-09-05) separates the two ways ``cols_in_table``
    arrives empty.  "The catalog answered and knows no columns" and "the
    catalog lookup FAILED" lead to opposite investigations, and until now
    both arrived here as ``None`` — ``core.row_security.api``'s lookup
    adapter caught every exception and returned ``[]``.  Unknown is not
    empty: the refusal message below names which one happened.
    """
    include_lists: List[set] = []
    exclude_set: set = set()
    masks: Dict[str, str] = {}

    for p in column_policies:
        mode = (p.get("mode") or "").lower()
        cols = [str(c) for c in (p.get("columns") or [])]
        if mode == "include":
            include_lists.append({c.lower() for c in cols})
        elif mode == "exclude":
            exclude_set.update(c.lower() for c in cols)
        elif mode == "mask":
            expr = p.get("mask_expr") or "NULL"
            for c in cols:
                masks[c.lower()] = expr

    # If we don't know the columns, we can still emit EXCLUDE for DuckDB and
    # fall back to * for other dialects.
    base_cols: Optional[List[str]]
    if cols_in_table:
        base_cols = list(cols_in_table)
    else:
        base_cols = None

    # 2026-09-05 — this used to hardcode the ANSI double quote:
    #
    #     def _q(name): return '"' + name.replace('"', '""') + '"'
    #
    # On Spark SQL (Databricks), MySQL and BigQuery a double-quoted token is a
    # STRING LITERAL, so the secured subquery selected CONSTANTS.  Measured on
    # the emitted text, with NO column policy at all — a matched ROW policy
    # plus a resolvable schema is enough:
    #
    #   SELECT * FROM (SELECT 'id','region','ssn','amt' FROM sales.fact
    #                  WHERE region = 'EMEA') AS f
    #   TRUTH    : [(1,'EMEA','123-45',10), (2,'EMEA','999-99',20)]
    #   DELIVERED: [('id','region','ssn','amt'), ('id','region','ssn','amt')]
    #
    # Right row count, right column count, right column NAMES, entirely
    # fabricated content, status 200 — invisible to any row-count gate.
    #
    # ``always_quote`` because these names are the SCHEMA's exact stored
    # spelling: bare would case-fold and address a different column on
    # Snowflake / Oracle.  Escaping and the refusal posture live in the one
    # renderer (core.sql_filter_wrapper), which verifies by parsing the
    # rendered text back in the target dialect.
    def _q(name: str) -> str:
        from core.sql_filter_wrapper import (
            IdentifierRenderError, quote_identifier_for_dialect,
        )
        try:
            return quote_identifier_for_dialect(
                name, dialect or None, always_quote=True)
        except IdentifierRenderError as exc:
            # We are here only because a policy MATCHED this table.  Emitting
            # a token the engine reads as a constant, or fail-opening to the
            # original SQL, both serve the governed table — so refuse.
            raise UnexpressiblePolicyError(
                f"column {name!r} cannot be projected on dialect "
                f"{dialect or 'unknown'!r}: {exc}"
            ) from exc

    if base_cols is None:
        # No schema info — use dialect-specific tricks where possible.
        if not exclude_set and not include_lists and not masks:
            return "*"
        # SECURITY AUDIT 2026-08-03 (S7): the old fallback returned a naked
        # "*" for any mask/include (and non-DuckDB exclude) policy — i.e. the
        # column policy was silently NOT applied and the protected column
        # went out in cleartext.  Policies must never degrade to full
        # disclosure:
        #   * DuckDB masks map to  * REPLACE (expr AS col)  (value replaced,
        #     column kept — exact mask semantics, no schema needed);
        #   * DuckDB excludes keep using * EXCLUDE (...);
        #   * include policies (allow-lists) cannot be expanded without the
        #     schema, and non-DuckDB dialects have no EXCLUDE/REPLACE —
        #     fail CLOSED.
        #
        # 2026-09-05: "fail closed" used to mean "raise PolicyRewriteError so
        # row_security.fail_open decides".  It decided wrong: with
        # fail_open=true the caller got the ORIGINAL sql back — the very
        # cleartext projection this branch exists to refuse.  A policy that
        # cannot be EXPRESSED must not silently become NO policy, so the
        # error is now UnexpressiblePolicyError, which never fail-opens.
        # A failed lookup reaching here is deliberately NOT a refusal.  ``*
        # EXCLUDE (ssn)`` / ``* REPLACE (…)`` express the policy exactly
        # WITHOUT a schema — the column is dropped or replaced whatever the
        # table holds, and DuckDB errors loudly if the named column is absent
        # — so a catalog outage cannot turn either form into a disclosure, and
        # refusing would break a path that is working correctly.  It is still
        # a degradation the operator must be able to see; ``SqlRewriter
        # .rewrite`` logs that, once, at WARNING, naming the table and the
        # cause.  Not repeated here: the same fact announced from two places
        # is the shape where silencing one of them goes unnoticed.
        if dialect == "duckdb" and not include_lists:
            parts = []
            if exclude_set:
                ex = ", ".join(_q(c) for c in sorted(exclude_set))
                parts.append(f"EXCLUDE ({ex})")
            if masks:
                repl = ", ".join(
                    f'{masks[c].replace("${col}", _q(c))} AS {_q(c)}'
                    for c in sorted(masks)
                    if c not in exclude_set
                )
                if repl:
                    parts.append(f"REPLACE ({repl})")
            return "* " + " ".join(parts) if parts else "*"
        # Unknown is not empty — say which one happened.  "The catalog could
        # not be reached" and "this table has no columns" send an operator to
        # opposite places, and this refusal message is the only place the
        # difference surfaces.
        _why = (f"the schema LOOKUP FAILED ({schema_error})" if schema_error
                else "the table schema could not be resolved")
        raise UnexpressiblePolicyError(
            f"column policy (include/mask) on dialect {dialect or 'unknown'!r} "
            f"requires the table schema, and {_why} — "
            "refusing to emit an unprotected projection (fail-closed)"
        )

    # We know the columns — produce an explicit list.
    keep: List[str] = []
    for c in base_cols:
        cl = c.lower()
        # exclude wins over include? Choose 'most restrictive': drop if excluded.
        if cl in exclude_set:
            continue
        # If any include list exists, keep only when present in ALL include sets
        if include_lists and not all(cl in s for s in include_lists):
            continue
        keep.append(c)

    parts: List[str] = []
    for c in keep:
        cl = c.lower()
        if cl in masks:
            mask_sql = masks[cl].replace("${col}", _q(c))
            parts.append(f'{mask_sql} AS {_q(c)}')
        else:
            parts.append(_q(c))
    return ", ".join(parts) if parts else "NULL AS __empty__"


def _data_policies_off(user_ctx: Any) -> bool:
    """THE published API's data-policy switch for this principal
    (core/row_security/entitlement.py::data_policies_off); a context stand-in
    without the surface answers False (a person: governed)."""
    from core.row_security.entitlement import data_policies_off
    try:
        return data_policies_off(user_ctx)
    except Exception:          # noqa: BLE001 -- a stand-in ctx: governed, never widened
        return False


def _any_part_quoted(tbl: "exp.Table") -> bool:
    for k in ("catalog", "db", "this"):
        part = tbl.args.get(k)
        if isinstance(part, exp.Identifier) and part.quoted:
            return True
    return False


def _resolved_table_ref(tbl: "exp.Table") -> str:
    """Return a dot-qualified reference for ``tbl`` (without alias)."""
    parts = []
    if tbl.args.get("catalog"):
        parts.append(tbl.args["catalog"].name)
    if tbl.args.get("db"):
        parts.append(tbl.args["db"].name)
    parts.append(tbl.name)
    return ".".join(p for p in parts if p)


# ── Main rewriter ──────────────────────────────────────────────────────────

class SqlRewriter:
    """Single-shot rewriter; cheap to construct and stateless."""

    def __init__(self, resolver: PolicyResolver):
        self._resolver = resolver

    def _table_classes(self, connection_id: Optional[int], tref: str):
        """``(has_any_row_policy, has_permissive)`` for the table, from the
        resolver.  A resolver stand-in without the FB-45 lookup (a test
        double predating it) carries no classes: all legacy, no grants."""
        fn = getattr(self._resolver, "table_row_policy_classes", None)
        if not callable(fn):
            return False, False
        answer = fn(connection_id, tref)
        # A resolver that CLAIMS the lookup and answers something that is
        # not (has_any, has_permissive) is a broken store, not a stand-in:
        # fail CLOSED (grants may exist and we could not tell), and say so.
        # Measured 2026-09-20: a MagicMock resolver in an older test unpacked
        # to zero values and the rewrite CRASHED on the security path.
        if (isinstance(answer, (tuple, list)) and len(answer) == 2
                and all(isinstance(x, bool) for x in answer)):
            return bool(answer[0]), bool(answer[1])
        logger.warning(
            "row_security: %s.table_row_policy_classes(%r, %r) answered %r, "
            "not (has_any, has_permissive) -- treating the table as carrying "
            "grants (fail closed)", type(self._resolver).__name__,
            connection_id, tref, answer)
        return True, True

    def rewrite(
        self,
        sql: str,
        dialect: str,
        user_ctx: UserContext,
        connection_id: Optional[int],
        schema_lookup: Optional[Any] = None,
    ) -> RewriteResult:
        """2026-10-24 -- the dialect of THIS rewrite is published for the data-
        entitlement compiler (core/row_security/entitlement.py), which quotes
        its column in it; then the rewrite proper (``_rewrite_impl``)."""
        from core.row_security.entitlement import REWRITE_DIALECT
        token = REWRITE_DIALECT.set(dialect or "")
        try:
            return self._rewrite_impl(sql, dialect, user_ctx, connection_id, schema_lookup)
        finally:
            REWRITE_DIALECT.reset(token)

    def _rewrite_impl(
        self,
        sql: str,
        dialect: str,
        user_ctx: UserContext,
        connection_id: Optional[int],
        schema_lookup: Optional[Any] = None,
    ) -> RewriteResult:
        """Rewrite ``sql`` and return a :class:`RewriteResult`.

        ``schema_lookup`` is an optional callable ``(table_ref) -> List[str]``
        returning known columns for a table; when supplied we can emit
        explicit column projections.  Without it we fall back to ``*``
        (rows are still filtered; columns are best-effort).
        """
        if not _HAS_SQLGLOT:
            raise PolicyRewriteError("sqlglot not installed — cannot rewrite")
        if not sql or not sql.strip():
            return RewriteResult(sql=sql, applied=[], skipped=[], mode_per_table={})

        # Parse — fail with a distinct error type so the API layer can
        # let a syntactically-bad query through to the underlying engine
        # (which produces a clearer error than blaming row-security).
        try:
            tree = sqlglot.parse_one(sql, dialect=dialect or None)
        except Exception as exc:
            raise PolicyParseError(f"sqlglot parse error: {exc}") from exc

        applied: List[Dict[str, Any]] = []
        skipped: List[Dict[str, Any]] = []
        modes: Dict[str, str] = {}

        # Walk every Table node.  We collect first then mutate to avoid
        # mutating during iteration.
        table_nodes: List["exp.Table"] = list(tree.find_all(exp.Table))
        for tbl in table_nodes:
            # Skip CTE references — they were already filtered when the CTE
            # body was processed (the CTE body itself contains Table nodes
            # for the base relations).
            parent = tbl.parent
            if isinstance(parent, exp.CTE):
                continue
            # Skip references where the resolved name matches a CTE alias
            # in the same query — sqlglot represents CTE refs as Table too.
            tref = _resolved_table_ref(tbl)
            if is_cte_reference(tbl):
                continue

            # 2026-10-24 -- whether any part of the name was QUOTED (the
            # string loses it): the entitlement catalog lookup then matches
            # the exact spelling only (core/row_security/entitlement.py).
            from core.row_security.entitlement import REF_QUOTED
            _qtok = REF_QUOTED.set(_any_part_quoted(tbl))
            try:
                policies = self._resolver.resolve(user_ctx, connection_id, tref)
            finally:
                REF_QUOTED.reset(_qtok)
            rows = policies["row"]
            cols = policies["column"]
            if not rows and not cols:
                # 2026-08-19 -- "no policy matched" is NOT always "no policy
                # applies".  When the principal was FABRICATED rather than
                # resolved (AD lookup failed, share token, report with no
                # owner) its bindings are missing, so a governed table looks
                # exactly like an ungoverned one -- and this `continue` then
                # ships it UNFILTERED.  That is how a fallback documented as
                # "can only ever restrict further, never leak extra rows"
                # leaked: a policy bound to `group:emea-only` simply stopped
                # matching once the groups were dropped.
                #
                # Only refuse when the table really is governed; a table with
                # no policies at all is not an RLS concern and still runs.
                #
                # 2026-10-25 -- an API key and a credentialed person are
                # RESOLVED principals (core/row_security/principal.py) and
                # never reach this refusal; it stands for the fabricated
                # background principals (a scheduled report with no owner
                # scope, a feed run, a share link, a federation side with no
                # caller) and for a group lookup that RAISED.
                if getattr(user_ctx, "unresolved", False):
                    if self._resolver.table_has_any_policy(connection_id, tref):
                        raise UnresolvedPrincipalError(
                            f"Row-security policies exist for '{tref}' but the "
                            f"requesting principal could not be resolved "
                            f"(user={user_ctx.username!r}). Refusing to run: "
                            f"an unresolved principal matches no binding, and "
                            f"in this engine that would return the table "
                            f"UNFILTERED rather than restrict it."
                        )
                # 2026-10-25 -- THE published API's data-policy switch: a key
                # on an API switched OFF reads the table with no row policy
                # (the resolver handed none) and is never judged by FB-45's
                # classes -- a table carrying grants the key does not hold
                # would otherwise render WHERE FALSE.  Said in ``skipped`` so
                # the audit row names the switch.
                if _data_policies_off(user_ctx):
                    skipped.append({"table": tref, "reason": OUTCOME_DATA_POLICIES_OFF})
                    continue
                # FB-45 (2026-09-20) -- "no policy matched" is TWO questions
                # (core/row_security/composition.py, "the empty-set
                # decisions").  A table that carries a PERMISSIVE policy this
                # principal does not hold is NOT skipped: under a grant model
                # holding no grant is no access, and the composition below
                # renders WHERE FALSE.  A table with only ceilings, or none,
                # is served unrestricted -- declared here, not by
                # fall-through.
                has_any, has_perm = self._table_classes(connection_id, tref)
                if not has_perm:
                    skipped.append({
                        "table": tref,
                        "reason": OUTCOME_CEILING_UNBOUND if has_any else OUTCOME_UNGOVERNED,
                    })
                    continue

            # Determine the strongest enforcement mode for this table —
            # if ANY policy says "rewrite" we apply, otherwise honour the
            # least-active mode in the set.
            enforcement = _strongest_mode([p.get("enforcement") for p in rows + cols])
            modes[tref] = enforcement

            audit_row = {
                "table": tref,
                "row_policies": [_summarise(p) for p in rows],
                "column_policies": [_summarise(p) for p in cols],
                "enforcement": enforcement,
                "rewritten": False,
                "composition": None,
            }

            if enforcement in ("audit_only", "native_lf"):
                # Don't touch the SQL; caller logs the decision.
                applied.append(audit_row)
                continue

            # Build combined WHERE -- FB-45: the composition is ONE decision
            # (core/row_security/composition.py): permissives OR, restrictives
            # AND, the two groups AND; a principal holding no grant on a
            # table that has grants gets FALSE.
            rendered_pairs: List[tuple] = []
            for p in rows:
                tpl = p.get("filter_sql") or ""
                rendered = substitute_vars(tpl, user_ctx).strip()
                if not rendered:
                    # 2026-08-20 — an empty rendered clause used to be
                    # silently DROPPED; with a single policy that meant
                    # ``WHERE TRUE`` audited as "rewritten".  A row policy
                    # that matched but restricts NOTHING is a broken policy,
                    # and in a security engine a broken policy must refuse,
                    # not grant (same posture as the unresolved-principal
                    # and column-without-schema refusals around this loop).
                    raise EmptyPolicyFilterError(
                        f"Row policy {p.get('id')!r} ({p.get('name')!r}) on "
                        f"'{tref}' rendered an EMPTY filter_sql for user "
                        f"{user_ctx.username!r}. Refusing to run: applying "
                        f"it would serve the table UNFILTERED (WHERE TRUE) "
                        f"while auditing the query as policy-enforced. Fix "
                        f"the policy's filter_sql template."
                    )
                rendered_pairs.append((p, rendered))
            # Only when no PERMISSIVE policy matched does the table's own
            # set of classes matter; the resolver caches that fact.
            _has_perm = any(effective_class(p) == "permissive" for p in rows)
            # 2026-10-25 -- a key on an API switched OFF is here only for a
            # COLUMN policy bound to it (the resolver handed no row policy);
            # the table's grants do not judge it (data_policies_off).
            if not _has_perm and not _data_policies_off(user_ctx):
                _has_any, _has_perm = self._table_classes(connection_id, tref)
            comp = compose_row_filters(
                rendered_pairs, table_has_permissive=_has_perm, table_has_any=True)
            # No row policies at all (column-only governance) on a table with
            # no grants is the ONLY path that leaves the row filter wide open.
            where_sql = comp.where_sql
            audit_row["composition"] = comp.to_audit()

            # Build SELECT-list (column projection)
            known_cols: Optional[List[str]] = None
            schema_error: Optional[str] = None
            if schema_lookup is not None:
                try:
                    known_cols = list(schema_lookup(tref) or []) or None
                except Exception as exc:
                    # 2026-09-05 — a FAILED lookup used to be logged at DEBUG
                    # and then be indistinguishable from "the table has no
                    # columns": both left ``known_cols=None``.  Carry the
                    # reason so the projection builder can say which happened
                    # (and so a refusal names the catalog, not the policy).
                    schema_error = f"{type(exc).__name__}: {exc}"
                    logger.warning(
                        "row_security: schema lookup FAILED for %s (%s) — the "
                        "column projection falls back to the schema-free "
                        "form; this is a catalog failure, not an empty table.",
                        tref, schema_error)
            select_list = _build_column_projection(
                dialect or "", known_cols, cols, schema_error)

            # Build replacement subquery preserving alias
            alias = tbl.alias_or_name
            try:
                # The Table's SQL representation may include alias — strip it
                tbl_copy = tbl.copy()
                tbl_copy.set("alias", None)
                table_sql = tbl_copy.sql(dialect=dialect or None)
                # 2026-09-05 — the alias goes through the same renderer as the
                # projection.  ``exp.to_identifier(alias)`` leaves a RESERVED
                # word bare (``…) AS order``), which is a parse error, and
                # every piece of this string is about to be re-read with
                # ``dialect``: it must all be written in that dialect or the
                # reader means something else by it.
                from core.sql_filter_wrapper import (
                    quote_identifier_for_dialect as _qident,
                )
                secured_sql = (
                    f"(SELECT {select_list} FROM {table_sql} "
                    f"WHERE {where_sql}) AS {_qident(alias, dialect or None)}"
                )
                secured = sqlglot.parse_one(secured_sql, dialect=dialect or None)
            except Exception as exc:
                # 2026-09-05 — same class as the projection refusal above:
                # we are HERE only because a policy matched this table, so
                # handing the original SQL back under fail_open serves the
                # governed table unfiltered.
                raise UnexpressiblePolicyError(
                    f"could not build secure subquery for {tref}: {exc}"
                ) from exc

            tbl.replace(secured)
            audit_row["rewritten"] = True
            applied.append(audit_row)

        # 2026-09-26 (F0, row security ON by default) -- a NO-OP rewrite
        # returns the caller's SQL BYTE-IDENTICAL.  This used to re-emit the
        # parsed tree whatever happened, so with the feature on every query
        # on an UNGOVERNED table came back re-rendered (``read_parquet`` ->
        # ``READ_PARQUET``, newlines collapsed, dialect re-spelt).  Three
        # callers read "the text changed" as "a policy applied" and switched
        # execution path: ``execute_query_background`` diverted a structured
        # local-parquet query into the raw-SQL subprocess lane (which could
        # not find the file -- "No data files found", measured on the shared
        # -dashboard journey); ``_run_parquet_report`` executed the re-spelt
        # text itself instead of its engine; and the shared-report surface
        # lost its honest total (3 instead of 10).  The contract every one of
        # those callers was written against is "no policy => identical
        # SQL", so it is honoured here, once, rather than taught to each
        # caller.  Only a table that was actually secured needs the emit.
        if not any(a.get("rewritten") for a in applied):
            return RewriteResult(
                sql=sql,
                applied=applied,
                skipped=skipped,
                mode_per_table=modes,
            )

        try:
            out_sql = tree.sql(dialect=dialect or None)
        except Exception as exc:
            # 2026-09-05 — an emit failure AFTER at least one table was
            # secured cannot fail open: the fallback is the original,
            # un-rewritten SQL for a table we just proved is governed.
            # (The nothing-rewritten case returns above and never emits.)
            raise UnexpressiblePolicyError(
                f"sqlglot emit error after applying policies to "
                f"{[a.get('table') for a in applied]}: {exc}") from exc

        return RewriteResult(
            sql=out_sql,
            applied=applied,
            skipped=skipped,
            mode_per_table=modes,
        )


def _with_of(node: "exp.Expression"):
    # sqlglot >= 30 keeps the WITH clause under ``with_`` (``with`` before):
    # read both, as core/sql_filter_wrapper.py does.
    args = getattr(node, "args", None) or {}
    return args.get("with_") or args.get("with")


def is_cte_reference(tbl: "exp.Table") -> bool:
    """True when this Table node names a CTE VISIBLE where it stands.

    2026-10-24 -- scoped, never "the name appears in some WITH": in
    ``WITH t AS (SELECT * FROM t) SELECT * FROM t`` the inner ``t`` is the
    BASE table (a non-recursive CTE cannot see itself), and a CTE sees only
    the CTEs listed BEFORE it.  Reading the name against the whole tree
    would skip the inner ``t`` and serve the base table UNFILTERED (security
    review of the entitlement commit).  A qualified name is never a CTE.
    Ambiguity resolves to "a table" -- filtered, or refused -- never skipped.
    """
    if tbl.args.get("db") or tbl.args.get("catalog"):
        return False
    ident = tbl.this if isinstance(tbl.this, exp.Identifier) else None
    if ident is None or not ident.this:
        return False
    child: "exp.Expression" = tbl
    node = tbl.parent
    while node is not None:
        w = _with_of(node)
        if w is not None:
            ctes = [c for c in w.expressions if isinstance(c, exp.CTE)]
            if child is w:
                # inside this WITH's own list: only the CTEs before the one
                # holding the node (and itself when RECURSIVE) are visible
                idx = next((i for i, c in enumerate(ctes) if _contains(c, tbl)), len(ctes))
                ctes = ctes[:idx + (1 if w.args.get("recursive") else 0)]
            if any(_same_identifier(c.args.get("alias"), ident) for c in ctes):
                return True
        child, node = node, node.parent
    return False


def _same_identifier(alias: Any, ident: "exp.Identifier") -> bool:
    """The CTE's name and the reference are CERTAINLY the same name: both
    unquoted and equal ignoring case (every dialect folds both the same
    way), or both quoted and equal exactly.  Mixed quoting depends on the
    dialect's folding (``"orders"`` is not ``orders`` on Snowflake, ``"T"``
    is not ``t`` on PostgreSQL) -- uncertain, so NOT a CTE: the reference is
    then filtered or refused as a table, never skipped (security review
    2026-10-24)."""
    a = getattr(alias, "this", None)
    if not isinstance(a, exp.Identifier) or not a.this:
        return False
    if a.quoted != ident.quoted:
        return False
    return a.this == ident.this if a.quoted else a.this.lower() == ident.this.lower()


def _contains(root: "exp.Expression", node: "exp.Expression") -> bool:
    p = node
    while p is not None:
        if p is root:
            return True
        p = p.parent
    return False


_MODE_PRIORITY = {
    "audit_only": 0,
    "view":       1,
    "native_lf":  2,
    "rewrite":    3,
}


def _strongest_mode(modes: List[Optional[str]]) -> str:
    """Pick the most-active enforcement mode from a list."""
    seen = [m for m in modes if m]
    if not seen:
        return "rewrite"
    return max(seen, key=lambda m: _MODE_PRIORITY.get(m, 0))


def _summarise(policy: Dict[str, Any]) -> Dict[str, Any]:
    """Pluck the small fields we want to keep in the audit row.

    2026-10-24 -- a SYNTHESISED entitlement policy (``core/row_security/
    entitlement.py::compile_for``) carries ``source = "entitlement"`` and an
    ``entitlement`` block (dimension / columns / values / principals); both
    ride into the record, so a reader of ``RewriteResult.applied`` -- "test
    as feed", the dry run -- can say WHICH dimension and values applied
    without re-deriving them.  A stored policy has neither key and its
    summary is unchanged."""
    out = {
        "id": policy.get("id"),
        "name": policy.get("name"),
        "filter_sql": (policy.get("filter_sql") or "")[:500] or None,
        "mode": policy.get("mode"),
        "columns": policy.get("columns"),
        "mask_expr": policy.get("mask_expr"),
        "enforcement": policy.get("enforcement"),
        "priority": policy.get("priority"),
        "policy_class": effective_class(policy),
    }
    if policy.get("source") is not None:
        out["source"] = policy.get("source")
    if isinstance(policy.get("entitlement"), dict):
        out["entitlement"] = policy["entitlement"]
    return out
