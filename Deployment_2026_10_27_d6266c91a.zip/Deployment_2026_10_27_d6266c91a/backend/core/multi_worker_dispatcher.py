"""BF-383 — Multi-worker dispatch wrapper for execute_api.

Bridges the gap between ``setup_registered_views`` (which produces a
combined setup SQL string with embedded file lists) and
``multi_worker_executor.execute_multi_worker`` (which needs a callable
that builds per-chunk setup SQL).

Public API:
  ``maybe_dispatch_multi_worker(sql, setup_sql_combined, output_file, ...) -> Optional[dict]``

    * Returns ``{"total_rows", "file_size_bytes", "status", "merge_strategy",
       "worker_count", ...}`` on success — caller treats this exactly like
       an ``s3_full_copy`` result.
    * Returns ``None`` when multi-worker can't / shouldn't run.  Caller
       transparently falls back to the existing single-worker path.

Only handles single-table queries in v1 (one ``CREATE VIEW`` in the
setup SQL).  Multi-table queries fall back automatically.
"""
from __future__ import annotations

import logging
import os
import re
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── SCAN-PLAN broadcast callback (2026-06-01) ───────────────────────────────
#
# Mirrors ``multi_worker_executor._STATE_CHANGE_CALLBACK`` (BF-599) so the
# dispatcher can publish *which profile the strategist picked* without
# importing execute_api / _ws_manager (which would create a circular
# dependency).  execute_api registers a callback at startup that broadcasts
# the event as ``scan_plan_decided`` to the execution's owner.  Frontend
# listens and renders a profile chip alongside the existing engine chip.
_SCAN_PLAN_CALLBACK: Optional[Callable[[Dict[str, Any]], None]] = None


def set_scan_plan_callback(
    fn: Optional[Callable[[Dict[str, Any]], None]],
) -> None:
    """Register the dispatcher's scan-plan-decided callback.

    Called once at app startup from execute_api.  Pass ``None`` to clear
    (atexit unregister).  Any exception inside the callback is swallowed
    — broadcast is best-effort, never blocks query execution.
    """
    global _SCAN_PLAN_CALLBACK
    _SCAN_PLAN_CALLBACK = fn


# Round 9 — prewarm stage broadcasts (structured, not strings).  Frontend
# routes ``stage`` field to a distinct chip instead of lumping into
# "executing".  Callback signature: ``fn({execution_id, stage,
# files_total, concurrency, warmed, errors, timed_out, elapsed_s, ...})``.
_PREWARM_PROGRESS_CALLBACK: Optional[Callable[[Dict[str, Any]], None]] = None


def set_prewarm_progress_callback(
    fn: Optional[Callable[[Dict[str, Any]], None]],
) -> None:
    """Register the dispatcher's prewarm-stage callback.  Mirrors
    ``set_scan_plan_callback`` — wired once at startup; clears to None
    on shutdown."""
    global _PREWARM_PROGRESS_CALLBACK
    _PREWARM_PROGRESS_CALLBACK = fn


def _emit_scan_plan_decision(*, execution_id: str, caller: str,
                              file_count: int, scan_plan: Any,
                              per_table_file_counts: Optional[Dict[str, int]] = None) -> None:
    """Best-effort broadcast of the dispatcher's scan-plan decision.

    Called once per query, immediately after ``ScanStrategist.plan()``
    returns.  Includes the profile, the chosen file_order, the worker
    cap, prewarm flag, and the human-readable rationale string from the
    plan so the UI can show users *why* they got the chosen execution
    shape ("BULK_SCAN: full feed/report scan — largest-first + 16
    workers + prewarm").

    2026-06-04 — also forwards ``per_table_file_counts`` (mapping of
    table_name → file_count) so the BQB chip tooltip can render
    "table_A: 3000 files · table_B: 5 files" alongside the aggregate.
    Re-emitted by the dispatcher_skip path when n_views > 1 so users
    can see why single-worker fired on a JOIN.  None when single-table
    or when the file-list extractor failed.
    """
    if _SCAN_PLAN_CALLBACK is None or not execution_id:
        return
    try:
        payload = {
            "execution_id":              execution_id,
            "caller":                    caller,
            "file_count":                file_count,
            "profile":                   scan_plan.profile.value,
            "file_order":                scan_plan.file_order.value,
            "max_workers":               scan_plan.max_workers,
            "prewarm_footers":           scan_plan.prewarm_footers,
            "prewarm_concurrency":       scan_plan.prewarm_concurrency,
            "duckdb_threads":            scan_plan.duckdb_threads,
            "boto3_max_pool_connections": scan_plan.boto3_max_pool_connections,
            "rationale":                 scan_plan.rationale,
        }
        if per_table_file_counts:
            payload["per_table_file_counts"] = dict(per_table_file_counts)
        _SCAN_PLAN_CALLBACK(payload)
    except Exception as _emit_exc:
        logger.debug("[scan-strategy] plan-decision callback raised: %s",
                     _emit_exc)


def _qsb_infer_format(iceberg_snapshot_id) -> str:
    """Deep-dive #6 (2026-06-30) -- decide 'iceberg' vs 'parquet' for
    the QueryStudio brain's supplement DB lookup.  Iceberg snapshot
    ids are positive int64 timestamps; any zero / null / empty value
    means 'no iceberg snapshot' -> plain parquet table.

    Numeric-aware zero check.  ALL of these become 'parquet':
      None, "", "  ", 0, 0.0, "0", "00", "000", "0.0", " 0 ", b""
    """
    if iceberg_snapshot_id is None:
        return "parquet"
    if isinstance(iceberg_snapshot_id, (int, float)):
        return "iceberg" if int(iceberg_snapshot_id) != 0 else "parquet"
    try:
        s = str(iceberg_snapshot_id).strip()
    except Exception:
        return "parquet"
    if not s:
        return "parquet"
    # Try numeric coercion -- catches "0", "00", "0.0", "+0", etc.
    try:
        if int(float(s)) == 0:
            return "parquet"
        return "iceberg"
    except (ValueError, TypeError):
        # Not numeric -- treat any non-empty non-numeric string as
        # iceberg (a UUID-style snapshot id, hex, etc).
        return "iceberg"


def _httpfs_load_prefix() -> str:
    """BF-599f (2026-05-31) — return the SQL prefix that loads the httpfs
    extension, honouring the ``QS_AUTOINSTALL_EXTENSIONS`` env var.

    The legacy ``INSTALL httpfs; LOAD httpfs;`` worked in dev (with
    internet) and on prod (where INSTALL was a no-op because the
    extension was pre-staged), but on air-gapped OpenShift it triggered
    a ``extensions.duckdb.org`` lookup that blocked for the corporate
    proxy connect-timeout per worker — adding 30-120 s per chunk to
    every multi-worker query.

    Modes:
      * ``QS_AUTOINSTALL_EXTENSIONS=false`` (production / OpenShift NFS
        pre-staged):  emit ``LOAD httpfs;\\n`` only.  Pairs with
        ``autoinstall_known_extensions=false`` set on the connection
        (duckdb_factory).  ``DUCKDB_EXTENSION_DIR`` MUST point at the
        NFS-mounted extensions directory or ``LOAD`` will fail.
      * unset / ``true`` (dev):  emit
        ``INSTALL httpfs; LOAD httpfs;\\n`` (back-compat).

    Returns a ``;\\n``-terminated string suitable for direct
    concatenation with a setup_sql block.
    """
    flag = (os.environ.get("QS_AUTOINSTALL_EXTENSIONS") or "").strip().lower()
    if flag in ("false", "0", "no", "off"):
        return "LOAD httpfs;\n"
    return "INSTALL httpfs; LOAD httpfs;\n"


# ─────────────────────────────────────────────────────────────────────────────
# Setup-SQL parsing
# ─────────────────────────────────────────────────────────────────────────────


# Match the first ``read_parquet([...])`` clause (single-table case).
# Captures the inner file list (group 1) so we can splice each chunk's slice
# back in.  Uses ``re.DOTALL`` so newlines inside the list (some callers
# pretty-print) don't break the match.
_READ_PARQUET_RE = re.compile(
    r"read_parquet\s*\(\s*\[(.+?)\]",
    re.IGNORECASE | re.DOTALL,
)

# BF-394: also match GLOB-form setup SQL.
#   read_parquet('s3://bucket/prefix/**/*.parquet', hive_partitioning=true)
# When the engine couldn't enumerate files at setup time, it falls back to a
# wildcard URI.  Without dispatcher support for this form, F could NEVER fire
# on plain-prefix S3 tables.  We detect it, enumerate via boto3 LIST, then
# rewrite the setup SQL to the array form so the regular chunk machinery
# takes over.
_READ_PARQUET_GLOB_RE = re.compile(
    r"read_parquet\s*\(\s*'(s3://[^']+)'",
    re.IGNORECASE,
)


def _extract_file_list(setup_sql: str) -> Tuple[Optional[str], List[str]]:
    """Find the ``read_parquet([...])`` array in setup_sql.

    Returns ``(match_substring, [path1, path2, ...])`` or ``(None, [])``
    when no match (multi-statement or unexpected shape).
    """
    if not setup_sql:
        return None, []
    m = _READ_PARQUET_RE.search(setup_sql)
    if not m:
        return None, []
    inner = m.group(1)
    paths: List[str] = []
    # Split on commas at the top level (no nested parens in file URLs).
    for token in inner.split(","):
        t = token.strip()
        if not t:
            continue
        # Strip surrounding single quotes
        if t.startswith("'") and t.endswith("'"):
            t = t[1:-1]
        paths.append(t)
    return inner, paths


def _extract_glob_url(setup_sql: str) -> Optional[Tuple[str, str]]:
    """Find a glob-form ``read_parquet('s3://...')`` in setup_sql.

    Returns ``(original_quoted_string, s3_url)`` so the caller can
    substring-replace.  Returns None when no glob form is present.
    """
    if not setup_sql:
        return None
    m = _READ_PARQUET_GLOB_RE.search(setup_sql)
    if not m:
        return None
    return (f"'{m.group(1)}'", m.group(1))


def _list_s3_glob(s3_url: str, conn_config: Dict[str, Any]) -> List[str]:
    """List parquet files matching an s3:// glob URI via boto3.

    Supports common patterns:
      s3://bucket/prefix/**/*.parquet  → list everything under prefix/
      s3://bucket/prefix/*.parquet     → list one level under prefix/
      s3://bucket/prefix/              → list everything under prefix/
    """
    if not s3_url.startswith("s3://"):
        return []
    try:
        # Parse bucket + prefix.  Strip glob suffix to get the LIST prefix.
        stripped = s3_url[len("s3://"):]
        parts = stripped.split("/", 1)
        bucket = parts[0]
        path = parts[1] if len(parts) > 1 else ""
        # Find the prefix up to the first wildcard
        for wildcard in ("**/", "*/", "*"):
            idx = path.find(wildcard)
            if idx >= 0:
                path = path[:idx].rstrip("/")
                break
        prefix = path.rstrip("/") + "/" if path else ""

        import boto3
        # BF-396: enforce connect + read timeouts so a slow proxy can't
        # silently burn 60+ seconds during glob enumeration.  We also cap
        # total pagination time below (line ~159) via a wall-clock guard.
        cfg_kw: Dict[str, Any] = {
            "connect_timeout": 10,
            "read_timeout":    15,
            "retries":         {"max_attempts": 2, "mode": "standard"},
        }
        try:
            from core.proxy_utils import get_boto_proxies
            px = get_boto_proxies(endpoint_url=conn_config.get("endpoint_url", ""))
            if px:
                cfg_kw["proxies"] = px
        except Exception as _px_err:
            logger.debug("[multi-worker] proxy resolution skipped: %s", _px_err)
        # 2026-10-26 -- region / endpoint / addressing style / TLS / keys
        # from THE resolver (core.s3_access), as the cached handler builds
        # them.  This site set no addressing style and parsed ssl_verify
        # by hand, so a VPCE listing went virtual-hosted here and
        # path-style everywhere else.  The caller already resolved
        # profile / assume_role into keys on conn_config.
        from core.s3_access import resolve_s3_access
        client_kw = resolve_s3_access(conn_config, proxy=False).boto3_client_kwargs(
            conn_config, config_kwargs=cfg_kw)

        s3 = boto3.client(**client_kw)
        urls: List[str] = []
        # BF-396: wall-clock budget for the WHOLE enumeration (max 30s).
        # Without this, a slow proxy + large bucket could hang the
        # dispatcher indefinitely before F even gets to dispatch.
        import time as _t
        MAX_ENUMERATE_SECONDS = 30.0
        MAX_FILES = 10000
        _t0 = _t.monotonic()
        _capped = False
        _timed_out = False
        try:
            paginator = s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents") or []:
                    key = obj.get("Key", "")
                    if key.lower().endswith(".parquet"):
                        urls.append(f"s3://{bucket}/{key}")
                    if len(urls) >= MAX_FILES:
                        _capped = True
                        break
                if _capped:
                    break
                if _t.monotonic() - _t0 > MAX_ENUMERATE_SECONDS:
                    _timed_out = True
                    break
            if _capped:
                logger.warning(
                    "[multi-worker] glob enumeration capped at %d files for %s "
                    "— S3 prefix has more files than dispatcher can handle "
                    "(F will run on the first %d only; consider tightening the "
                    "WHERE clause to prune before F)",
                    MAX_FILES, s3_url, MAX_FILES,
                )
            if _timed_out:
                logger.warning(
                    "[multi-worker] glob enumeration exceeded %ds budget for %s "
                    "— returning %d files found so far (set tighter prefix or "
                    "use Iceberg table for faster metadata)",
                    int(MAX_ENUMERATE_SECONDS), s3_url, len(urls),
                )
        finally:
            try:
                s3.close()
            except Exception as _close_err:
                logger.debug("[multi-worker] s3 client close failed: %s", _close_err)
        return urls
    except Exception as exc:
        logger.warning("[multi-worker] glob enumeration for %s failed: %s",
                       s3_url, exc)
        return []


def _count_create_view_statements(setup_sql: str) -> int:
    """Approximate: count CREATE VIEW / CREATE OR REPLACE VIEW occurrences."""
    if not setup_sql:
        return 0
    return len(re.findall(r"\bCREATE\s+(?:OR\s+REPLACE\s+)?VIEW\b",
                           setup_sql, re.IGNORECASE))


def _referenced_table_names(sql: str) -> set:
    """Return lowercase table names referenced in SQL (via sqlglot).
    Fail-open returns empty set on parse error → caller treats as
    'unknown / can't trim'.
    """
    if not sql:
        return set()
    try:
        import sqlglot
        from sqlglot import exp
        parsed = sqlglot.parse_one(sql, read="duckdb",
                                    error_level=sqlglot.ErrorLevel.IGNORE)
        if not parsed:
            return set()
        out = set()
        for tbl in parsed.find_all(exp.Table):
            name = tbl.name
            if name:
                out.add(name.lower())
        return out
    except Exception as exc:
        logger.debug("[multi-worker] SQL parse for refs failed: %s", exc)
        return set()


# Pattern that matches a full `CREATE [OR REPLACE] VIEW "name" AS ...` statement
# up to the next `CREATE VIEW` or end of string.  Used for surgical removal of
# unused views from a combined setup SQL.
_CREATE_VIEW_BLOCK_RE = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+"?(?P<name>[^"\s(]+)"?\s+AS\s+'
    r'(?P<body>(?:(?!\bCREATE\s+(?:OR\s+REPLACE\s+)?VIEW\b).)+?)(?=(?:\s*;\s*)?'
    r'(?:CREATE\s+(?:OR\s+REPLACE\s+)?VIEW|\Z))',
    re.IGNORECASE | re.DOTALL,
)


# Phase 141 broadcast-JOIN — Iceberg support.  An Iceberg table view is
# typically registered as ``SELECT * FROM iceberg_scan('s3://bucket/prefix')``
# (no file list).  When the metadata sync has run and the data files are
# enumerated, the view may instead use ``read_parquet([...])`` against the
# Iceberg manifest's data files.  We support BOTH forms — iceberg_scan is
# treated as a small-or-big table whose file count we estimate downstream.
_READ_PARQUET_OR_ICEBERG_RE = re.compile(
    r"(?:read_parquet|iceberg_scan)\s*\(\s*\[(.+?)\]",
    re.IGNORECASE | re.DOTALL,
)


def _worker_memory_floor_mb() -> int:
    try:
        from core.config import get_section as _gs
        return int((_gs("query_admission") or {}).get(
            "min_memory_mb_when_throttled") or 512)
    except Exception:
        return 512


def plan_worker_memory(n_workers: int, admitted_mb: int, *,
                       overhead_mb: int = 256):
    """``(workers, memory_limit_mb)`` for an admission-throttled dispatch.

    2026-10-06, measured on AWS: admission offered 4 workers at ~590 MB, the
    dispatcher then took the min with the executor's pod share (256 MB on a
    2 GiB container) and a heavy GROUP BY failed with ``OutOfMemoryException
    ... (244.2 MiB/244.1 MiB used)`` instead of running.  A worker below the
    floor (``query_admission.min_memory_mb_when_throttled``, 512) is not a
    smaller worker, it is a failing one: keep the admitted TOTAL
    (``n x (mb + overhead)``) and spend it on FEWER workers -- smaller
    chunks per query, never a smaller-than-floor engine.  Never more than
    the configured per-worker limit or the executor's pod share for that
    worker count.  At one worker the best available is returned even if it
    is below the floor (the engine spills).
    """
    floor = _worker_memory_floor_mb()
    n_a = max(1, int(n_workers or 1))
    total = n_a * (max(1, int(admitted_mb)) + overhead_mb)
    try:
        from core.config import get_section as _gs
        cfg_mb = int((_gs("query_engine") or {}).get(
            "duckdb_memory_limit_mb", 2048) or 2048)
    except Exception:
        cfg_mb = 2048
    try:
        from core.multi_worker_executor import (
            _compute_per_worker_memory_mb as _pw_share,
        )
    except Exception:
        _pw_share = None
    best = (1, max(1, int(admitted_mb)))
    for n in range(n_a, 0, -1):
        mb = min(cfg_mb if cfg_mb > 0 else total, total // n - overhead_mb)
        share = None
        if _pw_share is not None:
            try:
                share = _pw_share(n)
            except Exception:
                share = None
        if share:
            mb = min(mb, int(share))
        best = (n, max(1, int(mb)))
        if mb >= floor:
            break
    if best[0] < n_a or best[1] < floor:
        logger.warning(
            "[resource-admission] worker memory floor %d MB: %d worker(s) x "
            "%d MB admitted -> %d worker(s) x %d MB%s", floor, n_a,
            int(admitted_mb), best[0], best[1],
            " (BELOW the floor even at one worker -- it will spill)"
            if best[1] < floor else "")
    return best


ARRAY_DATA = "data"
ARRAY_DELETE = "delete"
ARRAY_UNKNOWN = "unknown"


def _array_files(inner: str) -> List[str]:
    out: List[str] = []
    for token in inner.split(","):
        t = token.strip()
        if not t:
            continue
        if t.startswith("'") and t.endswith("'"):
            t = t[1:-1]
        out.append(t)
    return out


def _classify_parquet_arrays(sql: str, pattern=None) -> List[Dict[str, Any]]:
    """THE classifier of the ``read_parquet([...])`` arrays in a setup SQL.

    Not every array is DATA.  ``iceberg_mor.build_mor_view_sql`` emits the
    data scan with a ``hive_partitioning=`` option (either value -- see
    ``core.iceberg_read_plan``) and the position-delete scan with
    ``union_by_name=true`` and no ``hive_partitioning``.  Slicing a delete
    array like data resurrects deleted rows in every worker that misses a
    delete file; preserving a data array like a delete array duplicates its
    rows in every worker.  Both are silent.

    Returns one dict per array OUTSIDE a SQL string literal, in order:
    ``{"start", "end"}`` (offsets of the inner list in ``sql``), ``"files"``,
    ``"kind"`` (``data`` / ``delete`` / ``unknown``).  The caller decides what
    an ``unknown`` means; a scope with exactly ONE array may treat it as data
    (that has always been the single-array contract).

    2026-10-06 -- extracted from the single-view path so the JOIN paths
    (partition-aligned, broadcast) classify with the SAME rule.  They used
    the FIRST array of each view, which for a MoR view is its DELETE array:
    measured live, ``fact_tetb_ext`` (673 data files + 9 deletes) was
    planned as a 9-file table -- the broadcast gate's "small side <= 50
    files" passed on the miscount, and partition alignment saw the deletes'
    single partition tuple and refused to split.
    """
    out: List[Dict[str, Any]] = []
    if not sql:
        return out
    lit = _string_literal_ranges(sql)
    for m in (pattern or _READ_PARQUET_OR_ICEBERG_RE).finditer(sql):
        if _inside_any_range(m.start(), lit):
            continue
        # The options follow the closing ']' -- the window runs to the
        # closing paren of the call (2026-08-21: a window ending at ']'
        # could never see them and every array read as unclassifiable).
        _opt_end = sql.find(")", m.end())
        _call_flat = sql[m.start():(_opt_end + 1) if _opt_end != -1
                         else m.end()].replace(" ", "")
        # 2026-09-25 -- classify on the OPTION, not its value: the data scan
        # carries hive_partitioning whichever way it is set
        # (core.iceberg_read_plan emits =false when partition values come
        # from the files); delete arrays never name it.
        _is_data = "hive_partitioning=" in _call_flat
        if _is_data or _call_flat.lower().startswith("iceberg_scan"):
            kind = ARRAY_DATA
        elif "union_by_name=true" in _call_flat:
            kind = ARRAY_DELETE
        else:
            kind = ARRAY_UNKNOWN
        out.append({"start": m.start(1), "end": m.end(1),
                    "files": _array_files(m.group(1)), "kind": kind})
    return out


def _extract_file_lists_per_view(
    setup_sql: str,
) -> Dict[str, Tuple[int, int, str, List[str]]]:
    """Phase 141 broadcast-JOIN — extract the file list under each CREATE VIEW.

    For setup SQL like::

        CREATE OR REPLACE VIEW "fact" AS SELECT * FROM read_parquet(['s3://...', 's3://...']);
        CREATE OR REPLACE VIEW "dim"  AS SELECT * FROM read_parquet(['s3://...']);

    Returns::

        {
            "fact": (start_offset, end_offset, "'s3://...', 's3://...'", ["s3://...", "s3://..."]),
            "dim":  (start_offset, end_offset, "'s3://...'",              ["s3://..."]),
        }

    The ``start_offset`` and ``end_offset`` are byte positions INTO the
    ORIGINAL ``setup_sql`` so the chunk builder can do an offset-precise
    replacement.  This prevents the bug where two views happen to share
    identical file lists and ``str.replace(..., 1)`` would corrupt the
    wrong one.  The third element is the inner substring (for diagnostics).

    Returns an empty dict when no CREATE VIEW matches the expected shape.

    2026-10-06 -- the list returned for a view is its DATA array, chosen by
    ``_classify_parquet_arrays`` (the single-view path's rule).  It used to
    be the view's FIRST array, which for a merge-on-read view is the
    position-DELETE array: the join paths then planned, sliced and counted
    the delete files as the table (live: a 673-file MoR table planned as 9
    files).  A view whose data array cannot be identified uniquely -- more
    than one data array (partition-spec evolution) or an unclassifiable one
    -- is LEFT OUT: the builders then leave its SQL untouched, so every
    worker reads it whole, which is the broadcast contract and correct for
    the INNER joins these paths accept.  Delete arrays are never returned,
    so no builder can slice them.
    """
    out: Dict[str, Tuple[int, int, str, List[str]]] = {}
    if not setup_sql:
        return out
    for m in _CREATE_VIEW_BLOCK_RE.finditer(setup_sql):
        name = (m.group("name") or "").strip().strip('"').lower()
        body = m.group("body") or ""
        body_start_in_sql = m.start("body")
        arrays = _classify_parquet_arrays(body)
        if not arrays:
            continue  # this VIEW doesn't use a recognised array form — skip
        if len(arrays) == 1:
            chosen = arrays[0]          # one array: it IS the data (legacy)
        else:
            data = [a for a in arrays if a["kind"] == ARRAY_DATA]
            unknown = [a for a in arrays if a["kind"] == ARRAY_UNKNOWN]
            if len(data) != 1 or unknown:
                logger.info(
                    "[multi-worker] view '%s': %d read_parquet arrays "
                    "(%d data, %d delete, %d unclassified) — no single data "
                    "array to slice; the view is read WHOLE by every worker",
                    name, len(arrays), len(data),
                    sum(1 for a in arrays if a["kind"] == ARRAY_DELETE),
                    len(unknown),
                )
                continue
            chosen = data[0]
        # Absolute offsets into the ORIGINAL setup_sql so the chunk builder
        # can splice precisely (the classifier's offsets are body-relative).
        inner_start = body_start_in_sql + chosen["start"]
        inner_end   = body_start_in_sql + chosen["end"]
        inner = setup_sql[inner_start:inner_end]
        paths = list(chosen["files"])
        if name and inner and paths:
            out[name] = (inner_start, inner_end, inner, paths)
    return out


def _isolate_create_view(setup_sql: str, keep_name: str) -> Optional[str]:
    """Return setup_sql with only the CREATE VIEW for ``keep_name`` retained.

    Other CREATE VIEW statements are removed.  Non-view DDL (LOAD/INSTALL
    extension, SET statements) is preserved.  Returns None when the keep
    view isn't found (caller falls back to skip).
    """
    if not setup_sql or not keep_name:
        return None
    keep_lower = keep_name.lower()
    blocks = list(_CREATE_VIEW_BLOCK_RE.finditer(setup_sql))
    if not blocks:
        return None
    # Build the output: keep everything BETWEEN view blocks (preamble +
    # inter-view stmts + postamble), plus the ONE matching view.
    pieces: List[str] = []
    last_end = 0
    found = False
    for m in blocks:
        # Append non-view content between previous block and this one
        pieces.append(setup_sql[last_end:m.start()])
        if m.group("name").lower() == keep_lower:
            pieces.append(m.group(0))
            found = True
        last_end = m.end()
    pieces.append(setup_sql[last_end:])
    if not found:
        return None
    return "".join(pieces).strip()


# ─────────────────────────────────────────────────────────────────────────────
# Per-chunk setup SQL builder
# ─────────────────────────────────────────────────────────────────────────────


def _build_chunk_setup_builder(
    setup_sql_original: str,
    inner_match: str,
    httpfs_required: bool,
):
    """Returns ``(chunk) -> str`` — the setup SQL for one chunk's slice.

    Implementation: search-and-replace the original file list in
    ``setup_sql_original`` with the chunk's slice, then prepend
    ``LOAD httpfs;`` so HTTPS/S3 URLs work in the per-worker connection.
    """
    def _builder(chunk) -> str:
        # Build chunk's file list in the same format the original used
        chunk_paths = []
        for f in chunk.files:
            if isinstance(f, dict):
                p = f.get("url") or f.get("path") or f.get("key") or ""
            else:
                p = str(f)
            p = p.replace("'", "''")  # SQL-escape
            chunk_paths.append(f"'{p}'")
        chunk_inner = ", ".join(chunk_paths)
        chunked_setup = setup_sql_original.replace(inner_match, chunk_inner, 1)

        # Prepend extension load — httpfs is required for https:// and s3:// reads.
        # Use INSTALL first (cheap no-op when already installed) so air-gapped
        # containers with pre-installed extensions still work.
        prefix = ""
        if httpfs_required:
            prefix = _httpfs_load_prefix()
        return prefix + chunked_setup

    return _builder


# BF-589 (2026-05-29): SQL string-literal mask for safe regex finditer.
# The legacy _READ_PARQUET_RE.finditer was matching INSIDE single-quoted
# SQL string literals — same class of bug BF-573 fixed for the format
# normaliser.  Mask string literals to placeholders, finditer on the
# masked SQL, then map matches back to the original offsets.
# BF-591: extended to handle backslash escapes (Spark / Hive / Trino
# accept ``'it\'s'``).  The original regex closed early on the embedded
# ``\'`` and mis-tagged offsets for the rest of the SQL.  The new pattern
# accepts three escape forms inside a single-quoted literal:
#   - ``''``   (SQL doubled-quote escape)
#   - ``\.``   (backslash-followed-by-any-char escape — Spark / Trino)
#   - any other char that is not a backslash or quote
_SQL_STRING_LIT = re.compile(r"'(?:[^'\\]|''|\\.)*'")


def _string_literal_ranges(sql: str) -> list[tuple[int, int]]:
    """Return sorted [(start, end)) ranges of every SQL string literal."""
    return [(m.start(), m.end()) for m in _SQL_STRING_LIT.finditer(sql)]


def _inside_any_range(pos: int, ranges: list[tuple[int, int]]) -> bool:
    for s, e in ranges:
        if s <= pos < e:
            return True
        if s > pos:
            break
    return False


def _normalise_file_uri_for_arrays(f) -> str:
    """URI string out of a dispatcher file entry (str / dict / tagged
    tuple) — mirrors ``_normalise_file`` inside the multi-array builder."""
    if isinstance(f, tuple) and len(f) == 2:
        return str(f[1])
    if isinstance(f, dict):
        return str(f.get("url") or f.get("path") or f.get("key") or "")
    return str(f)


def _build_chunk_setup_builder_multi_array(
    setup_sql_original: str,
    httpfs_required: bool,
    data_file_uris=None,
):
    """BF-587/BF-589 — chunk builder for setup_sql with MULTIPLE
    ``read_parquet([...])`` arrays (BF-494 partition-spec evolution).

    BF-589 hardening over BF-587:
      * Skips ``read_parquet`` mentions INSIDE SQL string literals
        (BF-573 regression that BF-587 reintroduced).
      * Tags each file with its source-array INDEX, not just URI.
        Duplicate URIs across arrays no longer cause double-emission
        on chunks that own one URI under both array indices.

    2026-08-04 AUXILIARY-ARRAY GUARD (MoR correctness): not every
    ``read_parquet`` array in a setup SQL is DATA.  A merge-on-read view
    carries a POSITION-DELETE array (``build_mor_view_sql``'s ``_pd``
    CTE) whose files are never in the dispatcher's file list — the old
    builder sliced it like data, producing ``read_parquet([])`` in every
    chunk: either a binder error, or (had DuckDB tolerated it) deletes
    silently NOT applied per worker — a row-level overcount.  When the
    caller supplies ``data_file_uris`` (the dispatcher's post-pruning
    file list), any array DISJOINT from it is auxiliary and is preserved
    INTACT in every chunk; each worker applies the FULL delete set to its
    slice of data, which is exactly the MoR contract.

    Returns a builder ``(chunk) -> setup_sql`` where the chunk's
    ``files`` list MAY be tagged tuples ``(array_index, uri)`` or
    plain URIs.  Both forms work; tagged form gives correct results
    when the same URI legitimately appears in two arrays.
    """
    # Pre-compute string-literal ranges of the input SQL.  Any
    # _READ_PARQUET_RE match whose start falls inside a literal is
    # ignored (BF-589 hardening).
    _lit_ranges = _string_literal_ranges(setup_sql_original)
    # Pre-extract each array's file LIST (ordered, not a set —
    # BF-589: a URI can legitimately appear twice within one array
    # under unusual partition-spec evolution).
    arrays: list[tuple[int, int, list[str]]] = []
    for m in _READ_PARQUET_RE.finditer(setup_sql_original):
        if _inside_any_range(m.start(), _lit_ranges):
            continue  # match was inside a string literal — skip
        inner_start = m.start(1)
        inner_end = m.end(1)
        files_in_array: list[str] = []
        for token in m.group(1).split(","):
            t = token.strip()
            if not t:
                continue
            if t.startswith("'") and t.endswith("'"):
                t = t[1:-1]
            files_in_array.append(t)
        arrays.append((inner_start, inner_end, files_in_array))

    def _normalise_file(f) -> tuple[int | None, str]:
        """Return ``(array_index_or_None, uri)`` from a chunk file
        entry.  Tagged tuples take priority; bare strings/dicts get
        ``array_index=None`` meaning "match in any array"."""
        if isinstance(f, tuple) and len(f) == 2 and isinstance(f[0], int):
            return f[0], str(f[1])
        if isinstance(f, dict):
            tag = f.get("array_index")
            uri = f.get("url") or f.get("path") or f.get("key") or ""
            return (int(tag) if tag is not None else None), str(uri)
        return None, str(f)

    # 2026-08-04 — classify arrays once: an array none of whose files
    # appear in the dispatcher's file list is AUXILIARY (MoR delete files,
    # path maps) and must survive slicing untouched.  No file list
    # supplied → every array is treated as data (legacy behaviour).
    _known_data_uris: set = set()
    if data_file_uris:
        for _f in data_file_uris:
            try:
                _known_data_uris.add(_normalise_file_uri_for_arrays(_f))
            except Exception:
                continue
    _aux_array: list[bool] = []
    for _ai, (_s, _e, _files_in_arr) in enumerate(arrays):
        if not _known_data_uris:
            _aux_array.append(False)
        else:
            _aux_array.append(
                not any(u in _known_data_uris for u in _files_in_arr))
    if any(_aux_array):
        logger.info(
            "[multi-worker] BF-587 auxiliary-array guard: %d of %d "
            "read_parquet arrays are NOT data (MoR deletes/aux) — "
            "preserved intact in every chunk",
            sum(_aux_array), len(arrays),
        )

    def _builder(chunk) -> str:
        # Walk arrays right-to-left so byte offsets stay valid as we
        # splice (replacing earlier bytes would shift later offsets).
        out_chars = list(setup_sql_original)
        for arr_idx, (inner_start, inner_end, files_in_array) in enumerate(reversed(arrays)):
            real_arr_idx = len(arrays) - 1 - arr_idx
            if _aux_array[real_arr_idx]:
                continue   # auxiliary (delete/aux) array — keep intact
            # Build a multiset of THIS array's files for membership +
            # remaining-count tracking (BF-589: handle duplicate URIs).
            remaining_in_array: dict[str, int] = {}
            for uri in files_in_array:
                remaining_in_array[uri] = remaining_in_array.get(uri, 0) + 1

            new_paths: list[str] = []
            for f in chunk.files:
                tag, uri = _normalise_file(f)
                # Skip if tagged for a DIFFERENT array.
                if tag is not None and tag != real_arr_idx:
                    continue
                # Skip if not in this array (or already drained).
                if remaining_in_array.get(uri, 0) <= 0:
                    continue
                remaining_in_array[uri] -= 1
                new_paths.append(uri.replace("'", "''"))
            new_inner = ", ".join(f"'{p}'" for p in new_paths)
            out_chars[inner_start:inner_end] = list(new_inner)
        chunked_setup = "".join(out_chars)

        prefix = _httpfs_load_prefix() if httpfs_required else ""
        return prefix + chunked_setup

    return _builder


def _build_split_plan_for_dispatch(sql: str, file_list: List[Any],
                                     mw_cfg: Dict[str, Any]):
    """Re-run decide_split() to produce a fresh SplitPlan to pass to the
    multi-pod dispatcher.  Same code path as the in-pod F decision."""
    from core.query_splitter import decide_split
    return decide_split(
        sql,
        file_list,
        max_workers=int(mw_cfg.get("max_workers", 4) or 4),
        min_files_to_split=int(mw_cfg.get("min_files_to_split", 50) or 50),
        max_files_per_worker=int(mw_cfg.get("max_files_per_worker", 5000) or 5000),
    )


def _build_partition_aligned_setup_builder(
    setup_sql_original: str,
    per_view_offsets: Dict[str, tuple],
    slice_files_by_chunk: List[Dict[str, List[Any]]],
    httpfs_required: bool,
):
    """Phase 144 — Build a per-chunk setup SQL builder for partition-aligned JOIN.

    Each worker (chunk) gets a SLICE of EVERY table's files where partition
    values align.  This is different from broadcast-JOIN where only the BIG
    table's file list is sliced; here EVERY table's list is sliced.

    Args:
      setup_sql_original: the original multi-CREATE-VIEW SQL.
      per_view_offsets: ``{table_name: (start, end, inner, files)}`` from
                         ``_extract_file_lists_per_view``.
      slice_files_by_chunk: index N = the dict
                              ``{table_name: [files_for_this_worker]}``.
      httpfs_required: prepend LOAD httpfs;

    Returns a builder fn ``(chunk) -> str`` that splices the chunk's
    per-table file slices into the setup SQL.  Uses offset-precise replacement
    going RIGHT-TO-LEFT so earlier offsets stay valid as we mutate.
    """
    # Sort views by descending offset so we replace from the END first —
    # keeps earlier offsets valid for the still-to-replace views.
    views_sorted = sorted(per_view_offsets.items(),
                          key=lambda kv: kv[1][0], reverse=True)

    def _builder(chunk) -> str:
        idx = chunk.chunk_index
        if idx < 0 or idx >= len(slice_files_by_chunk):
            raise ValueError(
                f"partition-aligned builder: chunk_index={idx} out of range "
                f"(0..{len(slice_files_by_chunk)-1})"
            )
        slice_for_me = slice_files_by_chunk[idx]
        sql = setup_sql_original
        for tname, (start, end, _inner, _files) in views_sorted:
            my_files = slice_for_me.get(tname, [])
            if not my_files:
                # Deep-dive: refuse to emit a CREATE VIEW with an empty file
                # list — DuckDB would either fail with "no files" or treat
                # the empty list as a NULL view (silently wrong results).
                # The planner is supposed to guarantee every slice has files
                # from every table; if we reach here, something upstream broke.
                raise ValueError(
                    f"partition-aligned chunk {idx}: table '{tname}' has 0 "
                    "files — planner invariant violated"
                )
            paths = []
            for f in my_files:
                if isinstance(f, dict):
                    p = f.get("url") or f.get("path") or f.get("key") or ""
                else:
                    p = str(f)
                p = p.replace("'", "''")
                paths.append(f"'{p}'")
            new_inner = ", ".join(paths)
            sql = sql[:start] + new_inner + sql[end:]
        prefix = _httpfs_load_prefix() if httpfs_required else ""
        return prefix + sql

    return _builder


def _build_broadcast_chunk_setup_builder(
    setup_sql_original: str,
    big_table: str,
    big_inner_start: int,
    big_inner_end: int,
    httpfs_required: bool,
):
    """Phase 141 — Build a per-chunk setup SQL builder for broadcast-JOIN.

    Each chunk holds the BIG table's slice of files.  The small tables'
    file lists are LEFT UNCHANGED in the setup SQL — every worker reads
    the full small-table file list (broadcast).  The query SQL itself
    is unchanged: each worker runs the same JOIN locally.

    Uses OFFSET-PRECISE splicing rather than ``str.replace(..., 1)``: this
    avoids the bug where two views happen to share identical file lists
    and the naive replace would corrupt the WRONG view's list.
    """
    prefix_text = setup_sql_original[:big_inner_start]
    suffix_text = setup_sql_original[big_inner_end:]

    def _builder(chunk) -> str:
        chunk_paths = []
        for f in chunk.files:
            if isinstance(f, dict):
                p = f.get("url") or f.get("path") or f.get("key") or ""
            else:
                p = str(f)
            p = p.replace("'", "''")
            chunk_paths.append(f"'{p}'")
        chunk_inner = ", ".join(chunk_paths)
        chunked_setup = prefix_text + chunk_inner + suffix_text
        prefix = _httpfs_load_prefix() if httpfs_required else ""
        return prefix + chunked_setup
    return _builder


def _try_broadcast_join_dispatch(
    *,
    sql: str,
    setup_sql_combined: str,
    output_file: str,
    mw_cfg: Dict[str, Any],
    cancel_event: Optional[threading.Event],
    progress_cb: Optional[Callable[[int, int, str], None]],
    httpfs_required: bool,
    duckdb_settings: Optional[Dict[str, str]],
    conn_config: Optional[Dict[str, Any]],
    execution_id: str = "",
) -> Optional[Dict[str, Any]]:
    """Phase 141 — Try broadcast-JOIN dispatch for a multi-table query.

    Returns the same success dict shape as the single-table path, or None
    when broadcast-JOIN can't apply (caller continues to the regular skip).

    Steps:
      1. Extract per-table file lists from the multi-CREATE-VIEW setup SQL
      2. Call decide_broadcast_join_split() to classify big vs small + chunk
      3. Build a SplitPlan from the big-table chunks
      4. Build the broadcast-aware setup_sql_builder (replaces only the
         big table's file list; small tables' lists ride along unchanged)
      5. Run execute_multi_worker
      6. Write the merged result + return the success dict

    Fail-open: any error returns None so the caller proceeds to the
    standard skip path.  We DO record the engine-router decision so
    admins can see whether the rejection was deliberate or a bug.
    """
    from core.query_splitter import (
        BroadcastJoinPlan, SplitPlan,
        decide_broadcast_join_split,
    )

    def _record_skip(reason: str):
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="single", reason=f"broadcast-JOIN: {reason}",
                rule="broadcast_join_skip",
            ), execution_id=execution_id)
        except Exception as _rec_err:
            logger.debug("[engine-router] could not record bj skip: %s", _rec_err)

    try:
        # 1. Extract per-table file lists from the setup SQL.
        # New tuple shape: (start_offset, end_offset, inner_substring, files)
        per_view = _extract_file_lists_per_view(setup_sql_combined)
        if len(per_view) < 2:
            _record_skip(f"only {len(per_view)} parseable view(s) — need ≥2 for JOIN")
            return None

        files_per_table = {t: files for t, (_s, _e, _inner, files) in per_view.items()}

        # 2. Decide split — uses the same INNER-JOIN-only safety inside
        plan: BroadcastJoinPlan = decide_broadcast_join_split(
            sql,
            files_per_table=files_per_table,
            max_workers=int(mw_cfg.get("max_workers", 4) or 4),
            broadcast_max_rows=int(mw_cfg.get("broadcast_max_rows", 10_000_000) or 10_000_000),
            min_files_to_split=int(mw_cfg.get("min_files_to_split", 50) or 50),
        )
        if not plan.splittable:
            _record_skip(plan.skip_reason or "no splittable broadcast plan")
            return None

        # Reject when the small side has too many files (broadcast cost
        # explodes when each worker has to scan 10K dim files).
        small_files_cap = int(mw_cfg.get("broadcast_max_small_files", 50) or 50)
        for tname in plan.small_tables:
            small_n = plan.tables[tname].total_files
            if small_n > small_files_cap:
                _record_skip(
                    f"small table '{tname}' has {small_n} files (>{small_files_cap} cap) — "
                    "broadcast cost too high, route to Spark Connect for shuffle JOIN"
                )
                return None

        # 3. Build the SplitPlan that execute_multi_worker consumes.
        # Phase 141 v2 — merge_strategy is set by decide_broadcast_join_split
        # based on the SQL: union for non-aggregate, sum_count_avg for
        # top-level aggregates, group_by_rollup for GROUP BY queries.
        # The rewritten partial_sql (AVG → SUM/COUNT) is what each worker
        # actually runs against its (big-chunk × broadcast-small-tables).
        big = plan.big_tables[0]
        big_chunks = plan.tables[big].chunks
        # Carry through the broadcast-JOIN-specific metadata for diagnostics
        # while preserving avg_replacements / agg_aliases the merger needs.
        merge_meta = dict(plan.merge_metadata or {})
        merge_meta.update({
            "broadcast_join": True,
            "big_table":      big,
            "small_tables":   plan.small_tables,
        })
        split_plan = SplitPlan(
            splittable=True,
            chunks=big_chunks,
            partial_sql=plan.partial_sql,
            merge_strategy=plan.merge_strategy,
            merge_metadata=merge_meta,
        )

        # 4. Build the broadcast-aware per-chunk setup SQL builder using
        # the offset-precise splicer (avoids the wrong-replace bug when
        # two views share identical file lists).
        big_start, big_end, _big_inner, _big_files = per_view[big]
        builder = _build_broadcast_chunk_setup_builder(
            setup_sql_combined, big, big_start, big_end, httpfs_required,
        )

        # 5. Run.  Merge DuckDB connection settings (S3 creds etc.) so
        # each worker can read the small + big file lists.
        from core.multi_worker_executor import execute_multi_worker
        merged_settings = dict(duckdb_settings or {})
        merged_settings.update(_duckdb_settings_from_conn_config(
            conn_config, setup_sql=setup_sql_combined, partial_sql=sql,
        ))

        # Phase 142 v2 — subprocess mode now supported.  The subprocess
        # child at duckdb_subprocess.py:1111 already iterates over
        # multi-statement setup SQL ("for stmt in setup_sql.split(';\n')"),
        # so multi-CREATE-VIEW (one per JOINed table) executes correctly
        # in subprocess mode.  Honor the admin-configured mode — subprocess
        # gives crash isolation (DuckDB segfaults take down the worker, not
        # the whole pod), which matters more for memory-heavy broadcast-JOIN
        # than for single-table SELECTs.
        configured_mode = str(mw_cfg.get("executor_mode", "thread") or "thread")

        logger.info(
            "[multi-worker] broadcast-JOIN dispatch: big=%s(%d files split %d ways) "
            "+ small=%s, mode=%s — workers will replicate small file lists",
            big, plan.tables[big].total_files, plan.n_workers,
            {t: plan.tables[t].total_files for t in plan.small_tables},
            configured_mode,
        )

        # Fire an immediate progress callback so the BQB chip lights up
        # AT DISPATCH START — not after the first worker completes (which
        # can take minutes).
        if progress_cb is not None:
            try:
                progress_cb(0, plan.n_workers, "dispatching broadcast-JOIN workers")
            except Exception as _pg_err:
                logger.debug("[multi-worker] initial progress_cb failed: %s", _pg_err)

        outcome = execute_multi_worker(
            split_plan,
            builder,
            final_sql=sql,
            executor_mode=configured_mode,
            max_workers=plan.n_workers,
            per_worker_timeout_s=int(mw_cfg.get("per_worker_timeout_seconds", 1800) or 1800),
            fallback_on_error=bool(mw_cfg.get("fallback_on_error", True)),
            cancel_event=cancel_event,
            progress_cb=progress_cb,
            duckdb_settings=merged_settings,
            correlation_id="broadcast-join",
            # 2026-06-09 — was ``cancellable=cancellable`` but this
            # function takes no such parameter and the local var was
            # undefined → NameError crashed broadcast-JOIN dispatch
            # on EVERY query, forcing single-worker fallback.  User
            # log showed it explicitly:
            #   "[multi-worker] partition-aligned dispatch raised
            #    (name 'cancellable' is not defined) — fall back"
            # Hardcoded True (sensible default; no caller ever asked
            # for non-cancellable).
            cancellable=True,
        )
        if outcome is None or outcome.fell_back:
            logger.info(
                "[multi-worker] broadcast-JOIN outcome unusable (fell_back=%s, reason=%s) — "
                "caller falls back to single-worker",
                getattr(outcome, "fell_back", "n/a"),
                getattr(outcome, "fallback_reason", "n/a"),
            )
            # 149.0 (2026-06-09): record EngineDecision on broadcast-JOIN
            # fall-back too — pre-fix only partition-aligned recorded one,
            # so admins inspecting broadcast-JOIN fallback had no UI breadcrumb
            # (had to grep server logs).  Mirrors the partition-aligned path.
            try:
                from core.engine_router import EngineDecision, record_decision
                record_decision(EngineDecision(
                    engine="single",
                    reason=f"broadcast-JOIN workers failed/fell back: "
                            f"{getattr(outcome, 'fallback_reason', 'unknown')}",
                    rule="broadcast_join_failed",
                ), execution_id=execution_id)
            except Exception as _rec_fail_err:
                logger.debug("[engine-router] broadcast-JOIN failure record failed: %s", _rec_fail_err)
            return None

        # 6. Write merged result + return success dict (same shape as single-table)
        import pyarrow.parquet as pq
        out_dir = os.path.dirname(str(output_file))
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        pq.write_table(outcome.table, str(output_file), compression="zstd")

        try:
            file_size = os.path.getsize(str(output_file))
        except OSError:
            file_size = 0

        logger.info(
            "[multi-worker] broadcast-JOIN success: %d rows, %d workers, big=%s, "
            "small=%s, %.1fs total",
            outcome.table.num_rows, outcome.worker_count, big,
            plan.small_tables, outcome.total_elapsed_s,
        )

        # Record an engine-router success so admins see the broadcast-JOIN
        # dispatch in Recent Decisions.
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_broadcast_join",
                reason=f"broadcast-JOIN: big={big} ({plan.tables[big].total_files} files) "
                        f"× small={plan.small_tables}",
                rule="broadcast_join_dispatch",
            ), execution_id=execution_id)
        except Exception as _rec_exc:
            logger.debug("[engine-router] broadcast-JOIN decision-record failed: %s", _rec_exc)

        return {
            "total_rows":         int(outcome.table.num_rows),
            "file_size_bytes":    int(file_size),
            "status":             "completed",
            "merge_strategy":     "union_broadcast_join",
            "worker_count":       outcome.worker_count,
            "elapsed_s":          outcome.total_elapsed_s,
            "from_multi_worker":  True,
            "broadcast_join":     True,
            "broadcast_big_table":   big,
            "broadcast_small_tables": list(plan.small_tables),
            "per_worker_summary": outcome.to_dict().get("per_worker", []),
        }
    except Exception as exc:
        logger.warning("[multi-worker] broadcast-JOIN dispatch raised (%s) — fall back", exc, exc_info=True)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Phase 144 — Partition-aligned JOIN dispatch
# ─────────────────────────────────────────────────────────────────────────────
def _try_partition_aligned_dispatch(
    *,
    sql: str,
    setup_sql_combined: str,
    output_file: str,
    mw_cfg: Dict[str, Any],
    cancel_event: Optional[threading.Event],
    progress_cb: Optional[Callable[[int, int, str], None]],
    httpfs_required: bool,
    duckdb_settings: Optional[Dict[str, str]],
    conn_config: Optional[Dict[str, Any]],
    execution_id: str = "",
) -> Optional[Dict[str, Any]]:
    """Phase 144 — Try partition-aligned JOIN: each worker gets files from
    ALL tables that share the same partition tuple.  Each worker runs the
    JOIN locally on its slice, merger UNIONs the results.

    Works when both tables share Hive partitioning AND data is co-located
    (related rows share partition values).  Admin opts in via
    ``multi_worker.allow_partition_aligned_join``.

    Returns the standard success dict or None when not applicable.
    Fail-open: any error returns None.
    """
    from core.partition_aligned_join import (
        decide_partition_aligned_join, PartitionAlignedJoinPlan,
    )
    from core.query_splitter import (
        SplitPlan, FileChunk, _rewrite_partial_sql,
    )

    def _record_skip(reason: str):
        try:
            from core.engine_router import EngineDecision, record_decision
            logger.info(
                "[multi-worker] partition_aligned_skip exec=%s reason=%s",
                execution_id or "n/a", reason,
            )
            record_decision(EngineDecision(
                engine="single", reason=f"partition-aligned: {reason}",
                rule="partition_aligned_skip",
            ), execution_id=execution_id)
        except Exception as _rec_err:
            logger.debug("[engine-router] could not record pa skip: %s", _rec_err)

    try:
        per_view = _extract_file_lists_per_view(setup_sql_combined)
        if len(per_view) < 2:
            _record_skip(f"only {len(per_view)} parseable view(s) — need ≥2")
            return None

        files_per_table = {t: files for t, (_s, _e, _inner, files) in per_view.items()}

        # 2026-06-04 — pre-compute per-table breakdown string so EVERY
        # skip reason from this function includes it.  User pain was
        # "partition align skipped single ... no other details" — admins
        # couldn't tell which table had how many files without grep-ing
        # the dispatcher logs separately.  Uses the same dedup-by-index
        # rendering as the dispatcher_skip path so self-joins (where
        # both CREATE VIEW statements lowercase to the same name) show
        # as "fact_left=2,224, fact_left#2=2,224" instead of two
        # identical-looking entries.
        _per_table_str = ""
        if files_per_table:
            ordered = sorted(files_per_table.items(),
                             key=lambda kv: len(kv[1]), reverse=True)
            shown = ordered[:6]
            _seen_names: Dict[str, int] = {}
            _display_pairs: List[str] = []
            for name, files in shown:
                _idx = _seen_names.get(name, 0)
                _seen_names[name] = _idx + 1
                _disp = f"{name}#{_idx + 1}" if _idx > 0 else name
                _display_pairs.append(f"{_disp}={len(files):,}")
            _per_table_str = (
                f" · {len(files_per_table)} tables, "
                f"top {len(shown)}: " + ", ".join(_display_pairs)
            )
            if len(ordered) > 6:
                _per_table_str += f" (+{len(ordered) - 6} more)"

        # Run the planner.  trust_colocation (admin assertion): the tables are
        # co-located so a join on the natural key is partition-local even when
        # the key isn't the partition column — relaxes the join-key correctness
        # gate.  Default False = safe (only splits on proven partition-key joins).
        plan: PartitionAlignedJoinPlan = decide_partition_aligned_join(
            sql,
            files_per_table=files_per_table,
            max_workers=int(mw_cfg.get("max_workers", 4) or 4),
            min_total_files=int(mw_cfg.get("min_files_to_split", 50) or 50),
            trust_colocation=bool(mw_cfg.get("partition_aligned_trust_colocation", False)),
        )
        if not plan.splittable:
            _record_skip((plan.skip_reason or "planner refused") + _per_table_str)
            return None

        # Build a SplitPlan + FileChunk list.  Each chunk's `files` field is
        # set to the FLATTENED list (sum of all tables' files for this worker)
        # only so executor logging can report a sensible count; the actual
        # file list per table is carried by the builder closure.
        chunks: List[FileChunk] = []
        slice_files_by_chunk: List[Dict[str, List[Any]]] = []
        for idx, sl in enumerate(plan.slices):
            slice_files_by_chunk.append(sl["files_per_table"])
            flat = [f for fl in sl["files_per_table"].values() for f in fl]
            chunks.append(FileChunk(
                files=flat,
                total_size_bytes=0,
                chunk_index=idx,
            ))

        # Rewrite the SQL so per-worker partials emit aggregable rows
        # (same logic as broadcast-JOIN).  Default to union when the SQL
        # has no GROUP BY / aggregates — workers emit raw JOIN rows and
        # the merger UNIONs.  Detect aggregates by running the rewriter
        # in group_by_rollup mode; if no aggregates are found we drop
        # back to union.
        from core.query_splitter import detect_unsupported_for_broadcast_join, _classify_aggregate
        unsup = detect_unsupported_for_broadcast_join(sql)
        if unsup:
            _record_skip(f"SQL unsupported feature: {unsup}" + _per_table_str)
            return None

        try:
            import sqlglot
            from sqlglot import exp
            tree = sqlglot.parse_one(sql, dialect="duckdb")
            select = tree.find(exp.Select)
            has_aggregate = bool(select) and any(
                _classify_aggregate(p.this if isinstance(p, exp.Alias) else p) is not None
                for p in select.expressions
            )
            has_groupby = bool(select) and select.args.get("group") is not None
        except Exception:
            has_aggregate = False
            has_groupby = False

        if has_groupby:
            merge_strategy = "group_by_rollup"
        elif has_aggregate:
            merge_strategy = "sum_count_avg"
        else:
            merge_strategy = "union"

        partial_sql, meta = _rewrite_partial_sql(sql, merge_strategy)
        if meta.get("needs_fallback"):
            _record_skip(f"rewriter signalled fallback: {meta}" + _per_table_str)
            return None

        # Carry through diagnostics for the merger / engine router
        merge_meta = dict(meta or {})
        merge_meta.update({
            "partition_aligned":  True,
            "partition_columns":  plan.partition_columns,
            "n_partition_tuples": sum(sl["tuple_count"] for sl in plan.slices),
        })

        split_plan = SplitPlan(
            splittable=True,
            chunks=chunks,
            partial_sql=partial_sql,
            merge_strategy=merge_strategy,
            merge_metadata=merge_meta,
        )

        # Build the per-chunk setup SQL builder
        builder = _build_partition_aligned_setup_builder(
            setup_sql_combined, per_view, slice_files_by_chunk, httpfs_required,
        )

        from core.multi_worker_executor import execute_multi_worker
        merged_settings = dict(duckdb_settings or {})
        merged_settings.update(_duckdb_settings_from_conn_config(
            conn_config, setup_sql=setup_sql_combined, partial_sql=sql,
        ))
        configured_mode = str(mw_cfg.get("executor_mode", "thread") or "thread")

        logger.info(
            "[multi-worker] partition-aligned dispatch: %d workers, "
            "partition_cols=%s, %d unique partition tuples, %d total files, mode=%s",
            plan.n_workers, plan.partition_columns,
            sum(sl["tuple_count"] for sl in plan.slices),
            sum(sum(len(fl) for fl in sl["files_per_table"].values()) for sl in plan.slices),
            configured_mode,
        )

        # Record decision at dispatch START so admin UI shows the query is
        # "currently using partition-aligned" mid-flight — not only after
        # all workers complete.  On worker failure we'll record a refusal
        # below; on success the success record overwrites this with the
        # final outcome.
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_partition_aligned",
                reason=f"partition-aligned JOIN dispatched: {plan.n_workers} workers, "
                        f"{sum(sl['tuple_count'] for sl in plan.slices)} partition tuples",
                rule="partition_aligned_dispatch_started",
            ), execution_id=execution_id)
        except Exception as _rec_start_err:
            logger.debug("[engine-router] dispatch-start record failed: %s", _rec_start_err)

        # Fire an immediate progress_cb call so the frontend BQB chip renders
        # "Multi-worker (N workers)" AT DISPATCH START — not only after the
        # first worker completes (which can take minutes on big-data JOINs).
        # `done=0` indicates "not done yet"; `total=n_workers` tells the chip
        # how many workers are active.
        if progress_cb is not None:
            try:
                progress_cb(0, plan.n_workers, "dispatching partition-aligned workers")
            except Exception as _pg_err:
                logger.debug("[multi-worker] initial progress_cb failed: %s", _pg_err)

        outcome = execute_multi_worker(
            split_plan,
            builder,
            final_sql=sql,
            executor_mode=configured_mode,
            max_workers=plan.n_workers,
            per_worker_timeout_s=int(mw_cfg.get("per_worker_timeout_seconds", 1800) or 1800),
            fallback_on_error=bool(mw_cfg.get("fallback_on_error", True)),
            cancel_event=cancel_event,
            progress_cb=progress_cb,
            duckdb_settings=merged_settings,
            correlation_id="partition-aligned-join",
            # 2026-06-09 — see note at the broadcast-join site above.
            # Same NameError crashed THIS dispatch path on every JOIN
            # query that reached partition-aligned mode.
            cancellable=True,
        )
        if outcome is None or outcome.fell_back:
            logger.info(
                "[multi-worker] partition-aligned outcome unusable (fell_back=%s, reason=%s)",
                getattr(outcome, "fell_back", "n/a"),
                getattr(outcome, "fallback_reason", "n/a"),
            )
            # Record the failure so admin can see WHY partition-aligned fell
            # back rather than guessing.  The dispatch-start record above
            # already showed an attempt; this record adds the outcome.
            try:
                from core.engine_router import EngineDecision, record_decision
                record_decision(EngineDecision(
                    engine="single",
                    reason=f"partition-aligned workers failed/fell back: "
                            f"{getattr(outcome, 'fallback_reason', 'unknown')}",
                    rule="partition_aligned_failed",
                ), execution_id=execution_id)
            except Exception as _rec_fail_err:
                logger.debug("[engine-router] failure record failed: %s", _rec_fail_err)
            return None

        # Deep-dive round 3: guard against None / missing table.  If every
        # worker emitted zero rows or the merger returned None, return None
        # so the caller falls back to single-worker rather than writing a
        # broken parquet file.
        if outcome.table is None:
            logger.warning(
                "[multi-worker] partition-aligned outcome.table is None — "
                "falling through to single-worker"
            )
            return None

        import pyarrow.parquet as pq
        out_dir = os.path.dirname(str(output_file))
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        pq.write_table(outcome.table, str(output_file), compression="zstd")

        try:
            file_size = os.path.getsize(str(output_file))
        except OSError:
            file_size = 0

        logger.info(
            "[multi-worker] partition-aligned JOIN success: %d rows, %d workers, "
            "%.1fs total",
            outcome.table.num_rows, outcome.worker_count, outcome.total_elapsed_s,
        )

        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_partition_aligned",
                reason=f"partition-aligned JOIN on {plan.partition_columns} "
                        f"({sum(sl['tuple_count'] for sl in plan.slices)} tuples, "
                        f"{plan.n_workers} workers)",
                rule="partition_aligned_dispatch",
            ), execution_id=execution_id)
        except Exception as _rec_exc:
            logger.debug("[engine-router] partition-aligned decision-record failed: %s", _rec_exc)

        return {
            "total_rows":          int(outcome.table.num_rows),
            "file_size_bytes":     int(file_size),
            "status":              "completed",
            "merge_strategy":      merge_strategy,
            "worker_count":        outcome.worker_count,
            "elapsed_s":           outcome.total_elapsed_s,
            "from_multi_worker":   True,
            "partition_aligned":   True,
            "partition_columns":   plan.partition_columns,
            "per_worker_summary":  outcome.to_dict().get("per_worker", []),
        }
    except Exception as exc:
        logger.warning(
            "[multi-worker] partition-aligned dispatch raised (%s) — fall back",
            exc, exc_info=True,
        )
        return None


def _try_exchange_b0_dispatch(
    *,
    sql: str,
    setup_sql_combined: str,
    inner_match: Optional[str],
    file_list: List[Any],
    multi_array_mode: bool,
    output_file: str,
    mw_cfg: Dict[str, Any],
    cancel_event: Optional[threading.Event],
    progress_cb: Optional[Callable[[int, int, str], None]],
    httpfs_required: bool,
    duckdb_settings: Optional[Dict[str, str]],
    conn_config: Optional[Dict[str, Any]],
    execution_id: str = "",
    cancellable: bool = True,
) -> Optional[Dict[str, Any]]:
    """Phase 2a (2026-07-26) — B0 zero-copy exchange: partition-aligned
    AGGREGATION for the single-table shapes the splitter (correctly)
    refuses today — exact COUNT(DISTINCT) / MEDIAN / PERCENTILE per group,
    window OVER (PARTITION BY k), GROUP BY with aggregate HAVING — when the
    grouping/window key is a SUPERSET of the table's hive partition
    columns.  Whole partition tuples are LPT-assigned to workers (each
    worker owns ALL rows for its partition values, reusing the PA-JOIN
    grouping + LPT mechanics via core.exchange_planner), every worker runs
    the ORIGINAL SQL, and the merge is a plain union.  Zero data movement.

    Called ONLY from the ``should_use_multi_worker`` refusal branch of
    ``maybe_dispatch_multi_worker`` — i.e. only for queries that would
    otherwise run single-worker, so a None return here is byte-for-byte
    today's behaviour.

    Flag-gated: ``multi_worker.exchange_enabled`` (inline default False —
    no config.py change).  Flag OFF ⇒ immediate None, zero side effects.
    Fail-closed / fail-open contract: any planner refusal, worker failure
    or error returns None ⇒ the caller's single-worker fallback runs
    (always correct).  RLS: only re-arranges ownership WITHIN the already
    post-RLS ``file_list`` — never widens it.
    """
    # Flag gate FIRST — OFF must be indistinguishable from today's code.
    if not bool(mw_cfg.get("exchange_enabled", False)):
        return None
    if not bool(mw_cfg.get("enabled", True)):
        return None
    if not sql or not setup_sql_combined or not output_file or not file_list:
        return None

    def _record_skip(reason: str):
        try:
            from core.engine_router import EngineDecision, record_decision
            logger.info(
                "[multi-worker] exchange_b0_skip exec=%s reason=%s",
                execution_id or "n/a", reason,
            )
            record_decision(EngineDecision(
                engine="single", reason=f"exchange-b0: {reason}",
                rule="exchange_b0_skip",
            ), execution_id=execution_id)
        except Exception as _rec_err:
            logger.debug("[engine-router] could not record b0 skip: %s",
                         _rec_err)

    try:
        # BF-494 partition-spec evolution (multiple read_parquet arrays in
        # one view) is planner-uncertain territory for a partition-tuple
        # OWNERSHIP argument — refuse (fail-closed), single-worker stands.
        if multi_array_mode:
            _record_skip("setup SQL has multiple read_parquet arrays "
                         "(partition-spec evolution) — B0 refuses")
            return None
        if not inner_match:
            _record_skip("setup SQL has no parseable read_parquet([...]) "
                         "array — B0 refuses")
            return None

        from core.exchange_planner import plan_exchange
        plan = plan_exchange(
            sql,
            file_list,
            max_workers=int(mw_cfg.get("max_workers", 4) or 4),
            min_files=int(mw_cfg.get("min_files_to_split", 50) or 50),
        )
        if not plan.splittable:
            _record_skip(plan.skip_reason or "planner refused")
            return None

        from core.query_splitter import SplitPlan, FileChunk
        chunks: List[FileChunk] = []
        for idx, sl in enumerate(plan.slices):
            chunks.append(FileChunk(
                files=list(sl["files"]),
                total_size_bytes=0,
                chunk_index=idx,
            ))

        split_plan = SplitPlan(
            splittable=True,
            chunks=chunks,
            # THE point of B0: the worker runs the ORIGINAL SQL verbatim —
            # it owns whole key groups, so no partial rewrite is needed and
            # the union of per-worker results is exact.
            partial_sql=sql,
            merge_strategy="union",
            merge_metadata={
                "exchange_b0":        True,
                "exchange_shape":     plan.shape,
                "partition_columns":  plan.partition_columns,
                "key_columns":        plan.key_columns,
                "n_partition_tuples": sum(sl["tuple_count"]
                                          for sl in plan.slices),
            },
        )

        # Reuse the standard single-array chunk builder — each worker's
        # setup SQL is the original CREATE VIEW with ONLY its slice's
        # files spliced into the read_parquet([...]) array.
        builder = _build_chunk_setup_builder(
            setup_sql_combined, inner_match, httpfs_required,
        )

        merged_settings = dict(duckdb_settings or {})
        merged_settings.update(_duckdb_settings_from_conn_config(
            conn_config, setup_sql=setup_sql_combined, partial_sql=sql,
        ))
        configured_mode = str(mw_cfg.get("executor_mode", "thread")
                              or "thread")

        logger.info(
            "[multi-worker] exchange-B0 dispatch: %d workers, shape=%s, "
            "key=%s ⊇ partition_cols=%s, %d partition tuples, %d files",
            plan.n_workers, plan.shape, plan.key_columns,
            plan.partition_columns,
            sum(sl["tuple_count"] for sl in plan.slices), len(file_list),
        )
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_exchange_b0",
                reason=(f"B0 zero-copy exchange dispatched: {plan.n_workers}"
                        f" workers, shape={plan.shape}, key="
                        f"{plan.key_columns} ⊇ {plan.partition_columns}"),
                rule="exchange_b0_dispatch_started",
            ), execution_id=execution_id)
        except Exception as _rec_start_err:
            logger.debug("[engine-router] b0 dispatch-start record "
                         "failed: %s", _rec_start_err)

        if progress_cb is not None:
            try:
                progress_cb(0, plan.n_workers,
                            "dispatching exchange-B0 workers")
            except Exception as _pg_err:
                logger.debug("[multi-worker] initial progress_cb "
                             "failed: %s", _pg_err)

        from core.multi_worker_executor import execute_multi_worker
        outcome = execute_multi_worker(
            split_plan,
            builder,
            final_sql=sql,
            executor_mode=configured_mode,
            max_workers=plan.n_workers,
            per_worker_timeout_s=int(
                mw_cfg.get("per_worker_timeout_seconds", 1800) or 1800),
            fallback_on_error=bool(mw_cfg.get("fallback_on_error", True)),
            cancel_event=cancel_event,
            progress_cb=progress_cb,
            duckdb_settings=merged_settings,
            correlation_id=execution_id or "exchange-b0",
            cancellable=cancellable,
        )
        if outcome is None or outcome.fell_back or outcome.table is None:
            _record_skip(
                "workers failed/fell back: "
                f"{getattr(outcome, 'fallback_reason', 'no outcome')}")
            return None

        import pyarrow.parquet as pq
        out_dir = os.path.dirname(str(output_file))
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        pq.write_table(outcome.table, str(output_file), compression="zstd")
        try:
            file_size = os.path.getsize(str(output_file))
        except OSError:
            file_size = 0

        logger.info(
            "[multi-worker] exchange-B0 success: %d rows, %d workers, "
            "%.1fs total (shape=%s)",
            outcome.table.num_rows, outcome.worker_count,
            outcome.total_elapsed_s, plan.shape,
        )
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_exchange_b0",
                reason=(f"B0 exchange on {plan.partition_columns} "
                        f"({sum(sl['tuple_count'] for sl in plan.slices)} "
                        f"tuples, {plan.n_workers} workers, "
                        f"shape={plan.shape})"),
                rule="exchange_b0_dispatch",
            ), execution_id=execution_id)
        except Exception as _rec_exc:
            logger.debug("[engine-router] b0 decision-record failed: %s",
                         _rec_exc)

        return {
            "total_rows":          int(outcome.table.num_rows),
            "file_size_bytes":     int(file_size),
            "status":              "completed",
            "merge_strategy":      "union_exchange_b0",
            "worker_count":        outcome.worker_count,
            "elapsed_s":           outcome.total_elapsed_s,
            "from_multi_worker":   True,
            "exchange_b0":         True,
            "exchange_shape":      plan.shape,
            "partition_columns":   plan.partition_columns,
            "key_columns":         plan.key_columns,
            "per_worker_summary":  outcome.to_dict().get("per_worker", []),
        }
    except Exception as exc:
        logger.warning(
            "[multi-worker] exchange-B0 dispatch raised (%s) — fall back",
            exc, exc_info=True,
        )
        return None


def _try_exchange_b1_dispatch(
    *,
    sql: str,
    setup_sql_combined: str,
    inner_match: Optional[str],
    file_list: List[Any],
    multi_array_mode: bool,
    output_file: str,
    mw_cfg: Dict[str, Any],
    cancel_event: Optional[threading.Event],
    progress_cb: Optional[Callable[[int, int, str], None]],
    httpfs_required: bool,
    duckdb_settings: Optional[Dict[str, str]],
    conn_config: Optional[Dict[str, Any]],
    execution_id: str = "",
    cancellable: bool = True,
) -> Optional[Dict[str, Any]]:
    """Phase 2b (2026-07-26) — B1 hash-repartition LOCAL-SPOOL exchange:
    exact COUNT(DISTINCT) / MEDIAN / percentile-per-group / window /
    aggregate-HAVING for keys that are NOT hive-partition-aligned (the case
    B0 refuses).  Stage 1 hash(K)-spools referenced columns to a
    per-execution local-disk tree (COPY … PARTITION_BY(__qs_bucket), atomic
    manifest commit); after the row-conservation hard gate + the
    bucket-partition assertion, stage-2 workers each own a disjoint set of
    buckets (⇒ ALL rows for their keys), run the ORIGINAL SQL verbatim, and
    the merge is a plain union.  See core.exchange_b1_executor for the full
    gate set (§4 of the design).

    Called ONLY from the ``should_use_multi_worker`` refusal branch, AFTER
    ``_try_exchange_b0_dispatch`` returned None — B0 (zero-copy) always
    gets first refusal.  Flag-gated by the same
    ``multi_worker.exchange_enabled`` (inline default False; knobs
    ``exchange_bucket_factor``/``exchange_max_spool_gb``/
    ``exchange_min_files`` also via mw_cfg — no config.py change).  Any
    refusal / abort / failure returns None ⇒ the caller's single-worker
    fallback runs (always correct).  RLS: the spool is per-execution and
    only re-arranges rows WITHIN the already post-RLS ``file_list``.
    """
    # Flag gate FIRST — OFF must be indistinguishable from today's code.
    if not bool(mw_cfg.get("exchange_enabled", False)):
        return None
    if not bool(mw_cfg.get("enabled", True)):
        return None
    if not sql or not setup_sql_combined or not output_file or not file_list:
        return None

    def _record_skip(reason: str):
        try:
            from core.engine_router import EngineDecision, record_decision
            logger.info(
                "[multi-worker] exchange_b1_skip exec=%s reason=%s",
                execution_id or "n/a", reason,
            )
            record_decision(EngineDecision(
                engine="single", reason=f"exchange-b1: {reason}",
                rule="exchange_b1_skip",
            ), execution_id=execution_id)
        except Exception as _rec_err:
            logger.debug("[engine-router] could not record b1 skip: %s",
                         _rec_err)

    try:
        # BF-494 partition-spec evolution (multiple read_parquet arrays) —
        # the stage-1 chunk builder can only splice a single array; refuse
        # (fail-closed), single-worker stands.
        if multi_array_mode:
            _record_skip("setup SQL has multiple read_parquet arrays "
                         "(partition-spec evolution) — B1 refuses")
            return None
        if not inner_match:
            _record_skip("setup SQL has no parseable read_parquet([...]) "
                         "array — B1 refuses")
            return None

        from core.exchange_planner import plan_exchange_b1
        plan = plan_exchange_b1(
            sql,
            file_list,
            max_workers=int(mw_cfg.get("max_workers", 4) or 4),
            min_files=int(mw_cfg.get("exchange_min_files", 200) or 200),
            bucket_factor=int(mw_cfg.get("exchange_bucket_factor", 2) or 2),
        )
        if not plan.splittable:
            _record_skip(plan.skip_reason or "planner refused")
            return None

        # Stage-1 chunk views reuse the standard single-array builder —
        # each worker's setup SQL is the original CREATE VIEW with ONLY its
        # chunk's files spliced into the read_parquet([...]) array (same
        # reader path ⇒ the Completeness Certificate's file accounting
        # sources from stage 1 only, §4.5).
        builder = _build_chunk_setup_builder(
            setup_sql_combined, inner_match, httpfs_required,
        )
        merged_settings = dict(duckdb_settings or {})
        merged_settings.update(_duckdb_settings_from_conn_config(
            conn_config, setup_sql=setup_sql_combined, partial_sql=sql,
        ))

        logger.info(
            "[multi-worker] exchange-B1 dispatch: %d workers × %d buckets, "
            "shape=%s, key=%s, cols=%s, %d files",
            plan.n_workers, plan.n_buckets, plan.shape, plan.key_columns,
            plan.referenced_columns, len(file_list),
        )
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_exchange_b1",
                reason=(f"B1 hash-spool exchange dispatched: {plan.n_workers}"
                        f" workers × {plan.n_buckets} buckets, shape="
                        f"{plan.shape}, key={plan.key_columns}"),
                rule="exchange_b1_dispatch_started",
            ), execution_id=execution_id)
        except Exception as _rec_start_err:
            logger.debug("[engine-router] b1 dispatch-start record "
                         "failed: %s", _rec_start_err)

        from core.exchange_b1_executor import (
            run_exchange_b1, conservation_receipt,
        )
        outcome = run_exchange_b1(
            plan,
            setup_sql_builder=builder,
            original_sql=sql,
            mw_cfg=mw_cfg,
            duckdb_settings=merged_settings,
            cancel_event=cancel_event,
            progress_cb=progress_cb,
            execution_id=execution_id,
            cancellable=cancellable,
        )
        if outcome is None or outcome.table is None:
            _record_skip("exchange aborted / workers fell back — "
                         "single-worker fallback")
            return None

        import pyarrow.parquet as pq
        out_dir = os.path.dirname(str(output_file))
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        pq.write_table(outcome.table, str(output_file), compression="zstd")
        try:
            file_size = os.path.getsize(str(output_file))
        except OSError:
            file_size = 0

        logger.info(
            "[multi-worker] exchange-B1 success: %d rows, %d workers, "
            "%.1fs total (stage1=%.1fs stage2=%.1fs, %d buckets, "
            "spool=%.1f MB, conservation %d==%d==%d)",
            outcome.table.num_rows, outcome.worker_count,
            outcome.total_elapsed_s, outcome.stage1_elapsed_s,
            outcome.stage2_elapsed_s, outcome.n_buckets,
            outcome.spool_bytes / 1e6,
            outcome.conservation.get("input_rows", -1),
            outcome.conservation.get("stage1_rows_written", -1),
            outcome.conservation.get("stage2_rows_read", -1),
        )
        try:
            from core.engine_router import EngineDecision, record_decision
            record_decision(EngineDecision(
                engine="multi_worker_exchange_b1",
                reason=(f"B1 exchange on key={plan.key_columns} "
                        f"({outcome.n_buckets} buckets, "
                        f"{outcome.worker_count} workers, "
                        f"shape={plan.shape}, row-conservation verified)"),
                rule="exchange_b1_dispatch",
            ), execution_id=execution_id)
        except Exception as _rec_exc:
            logger.debug("[engine-router] b1 decision-record failed: %s",
                         _rec_exc)
        # §4.5 audit trail — the VERIFIED conservation evidence rides the
        # per-execution diagnostic store next to the certificate.
        try:
            from core.query_diagnostic_store import record_pruning
            record_pruning(str(execution_id or ""), {
                "exchange_b1_conservation":
                    conservation_receipt(outcome.conservation),
            })
        except Exception:
            pass

        return {
            "total_rows":          int(outcome.table.num_rows),
            "file_size_bytes":     int(file_size),
            "status":              "completed",
            "merge_strategy":      "union_exchange_b1",
            "worker_count":        outcome.worker_count,
            "elapsed_s":           outcome.total_elapsed_s,
            "from_multi_worker":   True,
            "exchange_b1":         True,
            "exchange_shape":      plan.shape,
            "key_columns":         plan.key_columns,
            "n_buckets":           outcome.n_buckets,
            "spool_dir":           outcome.spool_dir,
            "spool_bytes":         outcome.spool_bytes,
            "conservation":        dict(outcome.conservation),
            "per_worker_summary":  outcome.per_worker_summary,
        }
    except Exception as exc:
        logger.warning(
            "[multi-worker] exchange-B1 dispatch raised (%s) — fall back",
            exc, exc_info=True,
        )
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Public dispatcher
# ─────────────────────────────────────────────────────────────────────────────


def _duckdb_settings_from_conn_config(
    conn_config: Optional[Dict[str, Any]],
    *,
    setup_sql: Optional[str] = None,
    partial_sql: Optional[str] = None,
) -> Dict[str, Any]:
    """Translate a connection config (S3 creds + endpoint + region) into the
    ``SET key=value`` pairs each worker's DuckDB connection needs to read
    ``s3://`` URLs.

    Strategic decision (2026-06-23): when ``setup_sql`` / ``partial_sql``
    already contain presigned ``https://…?X-Amz-Signature=…`` URLs (smart-
    VPC fast path), the worker MUST NOT have ``s3_endpoint`` or
    credentials set on its DuckDB connection -- httpfs would otherwise
    apply SigV4 on top of the already-signed querystring -> HTTP 0 /
    403 SignatureDoesNotMatch.  Same root cause and same planner-driven
    fix as the subprocess (see ``core.duckdb_s3_plan.plan_s3_setup``).

    Detection happens HERE at the producer (the dispatcher) so the
    workers stay simple: they apply whatever settings they receive
    and never have to second-guess.  This mirrors how the planner
    works inside the subprocess -- one decision point, no scattered
    guards.

    Behaviour:
      * Plan kind ``PRESIGNED_URLS_IN_SQL``: ``s3_endpoint``,
        ``s3_access_key_id``, ``s3_secret_access_key``,
        ``s3_session_token`` are intentionally OMITTED from the
        returned dict.  Workers' libcurl handles the HTTPS GETs
        against the VPCE host with the URL's embedded signature.
      * All other plan kinds: full credential set returned.  No
        change from pre-2026-06-23 behaviour.
      * Planner failure (import error etc.): degrade gracefully to
        emitting all settings -- legacy behaviour, may double-sign,
        logged at WARNING.  User invariant: 'subprocess should never
        be crashed'.

    Mirrors the credential setup that happens in
    ``duckdb_views.s3_full_copy`` / ``duckdb_subprocess._child_main`` so
    worker-side query execution behaves identically.
    """
    if not conn_config:
        return {}

    # Consult the planner -- single decision point for "are presigned
    # URLs already baked into the SQL?".  Fail-safe: if the planner
    # raises (import error, etc.), fall through with full settings
    # (legacy behaviour) so the dispatcher never crashes the query.
    _suppress_endpoint_and_creds = False
    try:
        from core.duckdb_s3_plan import plan_s3_setup, PRESIGNED_URLS_IN_SQL
        _plan = plan_s3_setup(
            conn_config, setup_sql=setup_sql, copy_sql=partial_sql,
        )
        if _plan.kind == PRESIGNED_URLS_IN_SQL:
            _suppress_endpoint_and_creds = True
            logger.info(
                "_duckdb_settings_from_conn_config: presigned URLs "
                "detected in worker SQL -- omitting s3_endpoint + "
                "credentials so workers don't double-sign.",
            )
    except Exception as _plan_exc:
        logger.warning(
            "_duckdb_settings_from_conn_config: planner unavailable "
            "(%s) -- falling back to legacy full-settings emission.  "
            "Workers may double-sign if setup_sql carries presigned "
            "URLs.", _plan_exc,
        )

    # Mixed types intentional — strings get single-quoted, booleans get
    # bare ``true``/``false`` tokens by ``_quote_setting_value`` in the
    # executor.  DuckDB rejects quoted booleans (``SET s3_use_ssl='false'``)
    # so the type discipline here matters.
    # AWS-native mode: the caller has already resolved profile/assume_role
    # into raw keys (worker threads can't safely re-run STS); the ONE
    # resolver (core.s3_access, 2026-09-26) reads them off conn_config and
    # decides region / endpoint / ssl / url-style exactly as every SET site.
    # 2026-06-23 -- the credential-bearing settings AND the endpoint are
    # omitted when the planner identifies PRESIGNED_URLS_IN_SQL (region stays
    # -- it cannot trip the double-sign trap).  Before 2026-09-26 this site
    # emitted ``s3_use_ssl=False`` / ``s3_url_style='path'`` for a config with
    # NO endpoint at all (its ``if not ep.startswith("https://")`` was true
    # for ""), i.e. plain HTTP against AWS; the resolver emits them only for
    # a custom endpoint.
    from core.s3_access import resolve_s3_access
    out: Dict[str, Any] = resolve_s3_access(conn_config, proxy=False).duckdb_settings(
        credentials=not _suppress_endpoint_and_creds,
        endpoint=not _suppress_endpoint_and_creds,
    )

    # 2026-06-24 -- SSL cert verification: route through the shared
    # ``duckdb_settings_for_ssl`` helper so the operator's
    # ``ssl_verify=<path-to-pem>`` is HONORED, ``ssl_verify=True`` falls
    # back to system CA (NOT silently disabled), and ``ssl_verify=False``
    # explicitly disables.  Prior inline logic forced cert verification
    # OFF whenever ssl_verify was boolean -- silently breaking operators
    # who set ``ssl_verify=True`` and expected ENFORCEMENT, and ignoring
    # ``.pem`` paths that didn't pass the type-check.
    try:
        from core.ssl_config import duckdb_settings_for_ssl
        out.update(duckdb_settings_for_ssl(conn_config))
    except Exception as _ssl_exc:
        logger.warning(
            "_duckdb_settings_from_conn_config: SSL resolver failed "
            "(%s) -- emitting no SSL settings (DuckDB defaults will "
            "apply).", _ssl_exc,
        )

    # Worker-side parquet metadata cache mirror (BF-253)
    out["enable_http_metadata_cache"] = True
    out["enable_object_cache"]        = True

    return out


def maybe_dispatch_multi_worker(
    sql: str,
    setup_sql_combined: str,
    output_file: str,
    *,
    cancel_event: Optional[threading.Event] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    httpfs_required: bool = True,
    duckdb_settings: Optional[Dict[str, str]] = None,
    conn_config: Optional[Dict[str, Any]] = None,
    execution_id: str = "",
    # SCAN-STRATEGY (2026-06-01): caller identity drives the AUTO profile
    # selection inside ScanStrategist.  "feed_gen" / "report" / "recon"
    # → BULK_SCAN profile (largest-first, prewarm, 16 workers).  "bqb" /
    # "cqb" with a LIMIT → INTERACTIVE profile.  "published_api" →
    # LOW_LATENCY.  Unknown callers fall through to AUTO's safer
    # interactive default.  Default left as "unknown" so existing call
    # sites keep compiling; feed_engine + execute_api pass the right
    # label so the strategist can choose intelligently.
    caller: str = "unknown",
    # 2026-06-03 — feed-gen / published-API / scheduled-report queries
    # MUST run to completion regardless of how long they take.  No
    # heartbeat-budget cancel, no BF-586 outer-timeout cancel, no
    # memory_guard watchdog cancel.  Set by caller (execute_api +
    # feed_engine) based on caller tag.  Interactive BQB/CQB queries
    # still cancellable so the user can click "Cancel" + the watchdog
    # can recover RAM.
    cancellable: bool = True,
    # Phase 156 (2026-06-25) -- when the caller knows the iceberg
    # snapshot the query is bound to, pass it so brain_router's
    # memo + route-history sensors can key on it.  Optional; missing
    # input just means brain skips the memo (still records outcomes).
    iceberg_snapshot_id: str = "",
) -> Optional[Dict[str, Any]]:
    """Attempt fan-out across N workers.  Returns success dict or None.

    Caller (execute_query_background) treats ``None`` as "fall through to
    single-worker s3_full_copy".  The non-None return contains the same
    keys ``s3_full_copy`` produces, so the caller's downstream code is
    unchanged.

    Fail-open: any error returns None so the regular path runs.

    Phase 144 deep-dive fix — execution_id is now tagged on every recorded
    engine-router decision so concurrent queries don't pollute each other's
    BF-417 detection.  Without this, query A's broadcast-JOIN skip could
    cause query B to incorrectly route to Spark.

    2026-06-03 — stamp execution_id into the diagnostic-store thread
    local so deep modules (iceberg_reader's pruning capture) can attach
    their snapshots to this execution without every call signature
    growing a new arg.  Next dispatcher call overwrites it.
    """
    try:
        from core.query_diagnostic_store import set_current_execution_id
        set_current_execution_id(execution_id or None)
    except Exception:
        pass

    # 2026-06-03 — register the cancel_event with memory_guard at
    # function entry so the watchdog can cancel this query regardless
    # of which sub-path runs (broadcast-join, partition-aligned,
    # standard multi-worker, OR single-worker fall-through later).
    # Memory_limit is 0 here; the admission block below updates it
    # to the actual planned allocation if admission runs.
    try:
        from core.memory_guard import register_query as _mg_register_early
        _mg_register_early(
            execution_id or "",
            0,                  # placeholder; admission updates
            label=f"mw:{caller}",
            cancel_hook=cancel_event,
        )
    except Exception:
        pass
    # BF-393: ALWAYS record a router decision (even on early-return) so the
    # admin Engine Router → Recent Decisions panel shows EVERY query.
    # Without this, queries that bypass F (multi-view setup, glob form,
    # below threshold, etc.) just silently took the single-worker path
    # with no visible reason for the user.
    def _record_skip(skip_reason: str, engine_name: str = "single"):
        # BF-416 — ALSO log to file so admins can grep dispatcher_skip
        # lines without hitting the in-memory engine-router history.
        # Previously this only stashed in _HISTORY, making
        # "why didn't multi-worker fire?" hard to diagnose from logs alone.
        logger.info(
            "[multi-worker] dispatcher_skip engine=%s exec=%s reason=%s",
            engine_name, execution_id or "n/a", skip_reason,
        )
        # P5 (2026-08-04) — one greppable [GATE] line per engine decision.
        # A single-worker outcome is a BLOCK of the split (the decision that
        # turned the operator's 31x900-column scan into one engine); any
        # other engine is a PASS.  The marker lives in the message text so
        # it survives JSON logging identically.
        try:
            from core.log_style import gate as _g5
            # ``file_list`` is extracted from setup_sql LATER in this
            # function — a skip recorded before extraction must not lose
            # its gate line to a NameError, so probe defensively.
            try:
                _g5_files = len(file_list) if file_list else 0
            except NameError:
                _g5_files = None
            _g5(
                logger, "engine.split",
                "BLOCK" if engine_name == "single" else "PASS",
                skip_reason,
                engine=engine_name,
                exec=execution_id or "n/a",
                files=_g5_files,
            )
        except Exception:
            pass
        # 2026-06-03 — when single-worker is the outcome AND file count
        # is over the warn threshold, escalate to WARNING so admins
        # immediately see "you fell back to 1 thread on N files".
        # This is the "1 worker on 3000 files" symptom captured loudly
        # in pod logs without requiring an admin to open the UI.
        try:
            mw_cfg_l = _cfg_section("multi_worker") or {}
            _swt = int(mw_cfg_l.get(
                "single_worker_large_file_warn_threshold", 100) or 0)
            _fc = locals().get("_early_file_count") if "_early_file_count" in locals() else None
            if _swt > 0 and engine_name == "single" \
                    and isinstance(_fc, int) and _fc > _swt:
                logger.warning(
                    "[multi-worker] SINGLE-WORKER on %d files (>%d threshold) "
                    "— exec=%s reason=%s — query may take minutes per file "
                    "× file_count; consider rewriting to avoid the guard "
                    "(no DISTINCT/WINDOW/WITH/ORDER-no-LIMIT/FULL-OUTER) "
                    "OR enable multi_worker.allow_partition_aligned_join "
                    "after verifying partition alignment.",
                    _fc, _swt, execution_id or "n/a", skip_reason,
                )
        except Exception:
            pass
        try:
            from core.engine_router import (
                EngineDecision, record_decision,
            )
            record_decision(EngineDecision(
                engine=engine_name,
                reason=skip_reason,
                rule="dispatcher_skip",
            ), execution_id=execution_id)
        except Exception as _rec_err:
            logger.debug("[engine-router] could not record skip: %s", _rec_err)

    try:
        from core.config import get_section as _cfg_section
        mw_cfg = _cfg_section("multi_worker") or {}
        # BF-391: default True mirrors core/config.py _DEFAULTS — admins
        # who want to roll back set enabled=false explicitly.
        if not mw_cfg.get("enabled", True):
            _record_skip("multi_worker.enabled = false → single-worker")
            return None

        if not sql or not setup_sql_combined or not output_file:
            _record_skip("missing sql / setup_sql / output_file (dispatcher inputs incomplete)")
            return None

        # ── SCAN-STRATEGY Phase 1 — EARLY plan build (2026-06-01 deep-dive fix) ──
        # Build the ScanPlan BEFORE the multi-view / broadcast-JOIN /
        # partition-aligned branches so those paths read the strategist's
        # max_workers / min_files / max_files_per_worker via the mutated
        # mw_cfg.  Pre-fix this block lived AFTER the n_views check, so any
        # JOIN query that took the broadcast-JOIN early-return at line ~1380
        # silently used legacy 4-worker config.
        #
        # File count is estimated from setup_sql_combined via a quoted-S3-URI
        # regex.  For literal file arrays the estimate is exact; for glob
        # form it's conservative (Phase 2 below refines after enumeration).
        scan_plan = None
        try:
            from core.scan_strategy import (
                ScanStrategist, WorkloadContext,
            )
            import re as _sp_re_e
            _sql_upper_e = (sql or "").upper()
            # ── 2026-08-21 — COUNT FILES, NOT TEXT OCCURRENCES ───────────
            # This was len(findall(...)) over the setup SQL: every quoted
            # 's3://' TOKEN, counted once per appearance.  A MoR view carries
            # each file at least twice (the read_parquet array AND the
            # _pm(_rp, _orig) original-path map), spec-evolved tables repeat
            # the arrays per spec, and the number is unbounded by anything
            # real — the operator's log shows files=22,485,762 for a query
            # with 2,880 data files.
            #
            # It is not only a log line: line ~2243 feeds this same number to
            # resource admission as `file_count`, so the cost model sized a
            # query at four orders of magnitude too large and auto-throttled
            # to n_workers=2 / 512 MB — which then persists fleet-wide.
            # A wrong input to a safety controller is worse than no input.
            #
            # DISTINCT collapses the duplicate references; a data file appears
            # once however many times the SQL names it.
            _early_uris = set(_sp_re_e.findall(
                r"'s3[a-z]*://[^']+'", setup_sql_combined or "",
                _sp_re_e.IGNORECASE,
            ))
            _early_file_count = len(_early_uris)
            _early_raw_refs = len(_sp_re_e.findall(
                r"'s3[a-z]*://[^']+'", setup_sql_combined or "",
                _sp_re_e.IGNORECASE,
            ))
            if _early_raw_refs > _early_file_count:
                logger.debug(
                    "[scan-strategy] %d s3 reference(s) in setup SQL collapse "
                    "to %d distinct file(s) (MoR path-map / per-spec arrays "
                    "name each file more than once).",
                    _early_raw_refs, _early_file_count,
                )
            _wc_e = WorkloadContext(
                caller=caller or "unknown",
                file_count=_early_file_count,
                total_bytes=0,
                has_limit=bool(_sp_re_e.search(r"\bLIMIT\s+\d+", _sql_upper_e)),
                has_aggregation=bool(_sp_re_e.search(
                    r"\b(SUM|COUNT|AVG|MIN|MAX|GROUP\s+BY)\b", _sql_upper_e,
                )),
                has_group_by=bool(_sp_re_e.search(r"\bGROUP\s+BY\b", _sql_upper_e)),
                has_join=bool(_sp_re_e.search(r"\bJOIN\b", _sql_upper_e)),
                has_order_by=bool(_sp_re_e.search(r"\bORDER\s+BY\b", _sql_upper_e)),
            )
            scan_plan = ScanStrategist().plan(workload=_wc_e)
            logger.info(
                "[scan-strategy] EARLY caller=%s files≈%d → profile=%s "
                "order=%s workers=%d prewarm=%s (reason: %s)",
                _wc_e.caller, _wc_e.file_count, scan_plan.profile.value,
                scan_plan.file_order.value, scan_plan.max_workers,
                scan_plan.prewarm_footers, scan_plan.rationale,
            )
            _emit_scan_plan_decision(
                execution_id=execution_id,
                caller=_wc_e.caller,
                file_count=_wc_e.file_count,
                scan_plan=scan_plan,
            )
            # Mutate mw_cfg with plan values so every downstream path
            # (n_views!=1 JOIN dispatch, single-view, multi-pod, engine
            # router) picks up the strategist's decisions automatically.
            mw_cfg = dict(mw_cfg)
            mw_cfg["max_workers"]          = scan_plan.max_workers
            mw_cfg["min_files_to_split"]   = scan_plan.min_files_to_split
            mw_cfg["max_files_per_worker"] = scan_plan.max_files_per_worker
            # 2026-06-03 — stash scan_plan.file_order in the thread
            # local so iceberg_reader._apply_scan_order picks it up
            # without a new kwarg threaded through 4 layers.  Cleared
            # in execute_api / feed_engine finally blocks (same finally
            # that releases the memory_guard accountant entry).  This
            # is the LAST mile of the ScanStrategist end-to-end wiring
            # — without it the dispatcher computes the plan but no
            # downstream reader honours it.
            try:
                from core.scan_strategy import set_current_file_order
                set_current_file_order(scan_plan.file_order)
            except Exception:
                pass
        except Exception as _ss_early_exc:
            logger.warning(
                "[scan-strategy] EARLY plan build failed (%s) — falling "
                "back to legacy mw_cfg", _ss_early_exc, exc_info=True,
            )

        # ── Resource admission (2026-06-03, user request) ──────────────
        # 'should run query whatever resources available'.  Probe live
        # system memory + CPU and compute the LARGEST safe
        # (max_workers, per_worker_memory_limit_mb) pair.  Default
        # policy 'auto_throttle' ALWAYS produces a runnable plan —
        # never refuses, never crashes the box.  Per-file overhead is
        # estimated conservatively so we'd rather under-utilise than
        # OOM/BSOD.  Mutates mw_cfg in-place when the proposed plan is
        # safer than the current one.
        try:
            from core.config import get_section as _ra_get
            from core.resource_admission import preflight as _ra_preflight
            _ra_cfg = _ra_get("query_admission") or {}
            if _ra_cfg.get("enabled", True):
                _ra_policy        = _ra_cfg.get("policy",       "auto_throttle")
                _ra_headroom      = float(_ra_cfg.get("headroom_factor",      0.7) or 0.7)
                _ra_min_free      = int(_ra_cfg.get("min_free_ram_mb",      2048) or 2048)
                _ra_overhead      = float(_ra_cfg.get("per_file_overhead_mb", 2.0) or 2.0)
                # Phase 150 — OS-level mmap overhead per file (BSOD vector
                # on Windows).  None = let resource_admission pick the
                # platform default (4 MB on Windows, 0.5 elsewhere).
                _ra_mmap_overhead = _ra_cfg.get("mmap_overhead_mb_per_file")
                if _ra_mmap_overhead is not None:
                    _ra_mmap_overhead = float(_ra_mmap_overhead)
                _ra_per_worker_mb = int(
                    (_cfg_section("query_engine") or {}).get(
                        "duckdb_memory_limit_mb", 2048) or 2048
                )
                _ra_n_workers = int(mw_cfg.get("max_workers", 4) or 4)
                # File count for admission — pre-split, we know it
                # only conservatively from the early sql parse.  The
                # ScanStrategist already computed _early_file_count
                # via the same regex; reuse for consistency.
                # 2026-10-06 -- and the BYTES the pruner measured for those
                # same files (manifest / LIST sizes).  Live: 1,354 files of
                # ~96 MB were sized at 15,481 MB from a per-file constant
                # and ran on ONE worker.  Unknown sizes stay unknown (the
                # constant applies to them), never zero.
                # Every REMOTE file (s3:// AND presigned https://): the early
                # count sees s3:// only, so on a presigned / VPCE lane it is
                # 0.  When EVERY file's size is known the measured count is
                # used; otherwise the early count stands, exactly as before.
                _ra_measured = None
                try:
                    from core.measured_file_bytes import bytes_for_uris
                    from core.s3_http_transport import remote_file_uris
                    _ra_measured = bytes_for_uris(
                        remote_file_uris(setup_sql_combined))
                except Exception as _mfb_exc:
                    logger.debug("[resource-admission] measured bytes "
                                 "unavailable: %s", _mfb_exc)
                _ra_file_count = int(_wc_e.file_count) if "_wc_e" in dir() else 0
                if _ra_measured is not None and _ra_measured.complete:
                    _ra_file_count = max(_ra_file_count, _ra_measured.files)
                _ra_decision = _ra_preflight(
                    file_count=_ra_file_count,
                    n_workers=_ra_n_workers,
                    per_worker_mem_mb=_ra_per_worker_mb,
                    policy=_ra_policy,
                    headroom_factor=_ra_headroom,
                    min_free_ram_mb=_ra_min_free,
                    per_file_overhead_mb=_ra_overhead,
                    mmap_overhead_mb_per_file=_ra_mmap_overhead,
                    measured_bytes=(_ra_measured.known_bytes
                                    if _ra_measured else None),
                    measured_files=(_ra_measured.known_files
                                    if _ra_measured else None),
                )
                logger.info(
                    "[resource-admission] %s — %s (system: %d/%d MB %s, "
                    "headroom %d MB)",
                    _ra_decision.decision, _ra_decision.reason[:300],
                    _ra_decision.system.ram_mb_available,
                    _ra_decision.system.ram_mb_total,
                    _ra_decision.system.source,
                    _ra_decision.headroom_mb,
                )
                # P5 (2026-08-04) — greppable [GATE] rendering of the same
                # decision (allow=PASS, throttle=SKIP, reject=BLOCK).
                try:
                    from core.log_style import gate as _ra_gate
                    _ra_gate(
                        logger, "admission.memory",
                        {"allow": "PASS", "reject": "BLOCK"}.get(
                            str(_ra_decision.decision), "SKIP"),
                        _ra_decision.reason[:200],
                        files=_ra_file_count,
                        workers=_ra_n_workers,
                        headroom_mb=_ra_decision.headroom_mb,
                        measured=(f"{_ra_measured.known_files}/"
                                  f"{_ra_measured.files} files "
                                  f"{_ra_measured.known_bytes / 1048576:.1f}MB"
                                  if _ra_measured else "unavailable"),
                        exec=execution_id or "n/a",
                    )
                except Exception:
                    pass
                # Stash on execution_id so the per-query diagnostic
                # surfaces this decision in /api/admin/queries/
                # diagnose/{execution_id}.
                try:
                    from core.engine_router import (
                        EngineDecision as _ED, record_decision as _RD,
                    )
                    _RD(_ED(
                        engine=_ra_decision.decision,
                        reason=f"resource_admission: {_ra_decision.reason[:280]}",
                        rule="resource_admission",
                    ), execution_id=execution_id or "")
                except Exception:
                    pass
                if _ra_decision.decision == "reject":
                    _record_skip(
                        f"resource_admission rejected: "
                        f"{_ra_decision.reason[:200]}"
                    )
                    raise RuntimeError(_ra_decision.reason)
                if _ra_decision.decision == "auto_throttle":
                    for k, v in _ra_decision.proposed_overrides.items():
                        if k.startswith("multi_worker."):
                            mw_cfg[k.split(".", 1)[1]] = v
                    # 2026-10-06 -- THIS QUERY'S memory limit, carried in
                    # THIS dispatch's settings.  It used to be written with
                    # config.set into query_engine.duckdb_memory_limit_mb:
                    # a per-query throttle that then became every later
                    # factory connection's limit (federation, workers) and
                    # the NEXT admission's starting point -- a ratchet that
                    # only ever went down ("persists fleet-wide", 2026-08-21).
                    # Now the executor applies it to these workers only, and
                    # never above its own per-worker pod share.
                    _ra_mem = _ra_decision.proposed_overrides.get(
                        "query_engine.duckdb_memory_limit_mb")
                    if _ra_mem and "memory_limit" not in (duckdb_settings or {}):
                        try:
                            _n, _ra_mem = plan_worker_memory(
                                int(mw_cfg.get("max_workers", 4) or 4),
                                int(_ra_mem))
                            mw_cfg["max_workers"] = _n
                            duckdb_settings = dict(duckdb_settings or {})
                            duckdb_settings["memory_limit"] = f"{_ra_mem}MB"
                        except (TypeError, ValueError):
                            pass
                    logger.warning(
                        "[resource-admission] auto-throttled to "
                        "max_workers=%s mem_limit_mb=%s",
                        _ra_decision.proposed_overrides.get(
                            "multi_worker.max_workers"),
                        _ra_decision.proposed_overrides.get(
                            "query_engine.duckdb_memory_limit_mb"),
                    )

                # 2026-06-03 — register this query against the pod's
                # inflight memory budget so subsequent admission checks
                # see the reservation.  Released in finally on the
                # dispatch path (execute_api).  Total reservation =
                # n_workers × per_worker_mb (after any auto_throttle
                # adjustment).  cancel_hook=cancel_event so the memory
                # watchdog can cooperatively cancel this query when RAM
                # falls below critical_low.
                try:
                    from core.memory_guard import register_query
                    _registered_total_mb = (
                        int(mw_cfg.get("max_workers", 4))
                        * int(_ra_decision.proposed_overrides.get(
                            "query_engine.duckdb_memory_limit_mb")
                            or _ra_decision.cost.per_worker_mem_mb)
                    )
                    register_query(
                        execution_id or "",
                        _registered_total_mb,
                        label=f"mw:{caller}",
                        cancel_hook=cancel_event,
                    )
                except Exception as _reg_exc:
                    logger.debug(
                        "[memory_guard] register_query swallowed: %s",
                        _reg_exc,
                    )
        except RuntimeError:
            raise   # propagate reject
        except Exception as _ra_exc:
            logger.warning(
                "[resource-admission] check failed (%s) — proceeding "
                "without admission gate", _ra_exc, exc_info=True,
            )

        # BF-402: v1 supported only single-CREATE-VIEW setup.  But many
        # setups register multiple tables even when the query only uses
        # ONE — we'd skip F unnecessarily.  Now we parse the SQL to find
        # ACTUALLY-referenced tables; if exactly one, we strip the
        # unused CREATE VIEW statements so the dispatcher can split that
        # one table's files.
        n_views = _count_create_view_statements(setup_sql_combined)
        if n_views > 1:
            referenced = _referenced_table_names(sql)
            if len(referenced) == 1:
                # Reduce setup to just the one CREATE VIEW we need
                only_table = next(iter(referenced))
                trimmed = _isolate_create_view(setup_sql_combined, only_table)
                if trimmed and _count_create_view_statements(trimmed) == 1:
                    logger.info(
                        "[multi-worker] %d CREATE VIEWs registered but SQL only "
                        "references '%s' — trimming setup to enable F",
                        n_views, only_table,
                    )
                    setup_sql_combined = trimmed
                    n_views = 1
        if n_views != 1:
            # 2026-06-04 — compute per-table file counts ONCE so every
            # downstream skip path (PA / BJ / final dispatcher_skip) can
            # surface the same breakdown without re-parsing setup_sql.
            # User pain: "on BQB we used to get file counts from both
            # tables, now it's not showing" — single-worker on a 2-table
            # JOIN was rendering with a generic chip and no per-table
            # info, so the user could not tell which side was the bulk
            # of the 3000-file scan.  We compute it here and pipe it
            # through the scan_plan re-emit + the skip reason text.
            try:
                _pv_for_diag = _extract_file_lists_per_view(setup_sql_combined)
                per_table_file_counts: Dict[str, int] = {
                    t: len(files) for t, (_s, _e, _inner, files) in _pv_for_diag.items()
                }
            except Exception as _pv_exc:
                logger.debug(
                    "[multi-worker] per-table file count extract failed: %s",
                    _pv_exc,
                )
                per_table_file_counts = {}

            # Re-emit scan_plan with the per-table breakdown so the BQB
            # chip tooltip can show "table_A: 3000 files · table_B: 5
            # files" alongside the existing total.  Without this the chip
            # only shows the aggregate which hides which side dominates.
            if scan_plan is not None and per_table_file_counts:
                try:
                    _emit_scan_plan_decision(
                        execution_id=execution_id,
                        caller=(_wc_e.caller if "_wc_e" in locals() else (caller or "unknown")),
                        file_count=sum(per_table_file_counts.values()) or _early_file_count,
                        scan_plan=scan_plan,
                        per_table_file_counts=per_table_file_counts,
                    )
                except Exception as _pte_exc:
                    logger.debug(
                        "[scan-strategy] per-table re-emit failed: %s", _pte_exc,
                    )

            # Phase 144 — partition-aligned JOIN path.  When admin opted in
            # and both tables share Hive partition columns, slice each
            # table's file list by partition tuple and give one worker
            # per tuple.  Works for big × big when data is co-partitioned.
            allow_pa = bool(mw_cfg.get("allow_partition_aligned_join", True))
            pa_attempted = False
            if allow_pa:
                pa_attempted = True
                pa_result = _try_partition_aligned_dispatch(
                    sql=sql,
                    setup_sql_combined=setup_sql_combined,
                    output_file=output_file,
                    mw_cfg=mw_cfg,
                    cancel_event=cancel_event,
                    progress_cb=progress_cb,
                    httpfs_required=httpfs_required,
                    duckdb_settings=duckdb_settings,
                    conn_config=conn_config,
                    execution_id=execution_id,
                )
                if pa_result is not None:
                    return pa_result
                # pa_result None → partition-aligned didn't apply; try
                # broadcast-JOIN next (if enabled).

            # Phase 141 — broadcast-JOIN path.  Multi-view setup means the
            # query references multiple registered tables; if it's an INNER
            # JOIN and one side is small enough to broadcast, we can still
            # split the BIG side across workers.  Opt-in via
            # multi_worker.allow_broadcast_join.
            allow_bj = bool(mw_cfg.get("allow_broadcast_join", True))
            bj_attempted = False
            if allow_bj:
                bj_attempted = True
                bj_result = _try_broadcast_join_dispatch(
                    sql=sql,
                    setup_sql_combined=setup_sql_combined,
                    output_file=output_file,
                    mw_cfg=mw_cfg,
                    cancel_event=cancel_event,
                    progress_cb=progress_cb,
                    httpfs_required=httpfs_required,
                    duckdb_settings=duckdb_settings,
                    conn_config=conn_config,
                    execution_id=execution_id,
                )
                if bj_result is not None:
                    return bj_result
                # bj_result None → broadcast-JOIN inapplicable; fall through
                # to the skip path below with the original reason.

            # 2026-06-04 — richer skip reason.  Old text said only "2
            # CREATE VIEW statements (v1 supports 1; query references 2
            # tables, F cannot safely split JOINs/UNIONs)" — gave the user
            # no idea WHICH tables, how many files each, or whether the
            # PA/BJ strategies were even attempted.  User had been
            # debugging the same query for 4 days because the reason
            # text was uninformative.  Now we append:
            #   * per-table file counts (top 4 tables by size)
            #   * PA/BJ attempt status (enabled vs disabled, attempted
            #     vs not, fell-through reason if attempted)
            _ref_tables = _referenced_table_names(sql)
            _per_table_str = ""
            if per_table_file_counts:
                # Show ALL tables ordered by file count desc; cap to 6
                # so reason stays readable on a single chip tooltip.
                # 2026-06-04 — prefix with "N tables" + index-tag any
                # duplicate display names.  User report showed
                # "fact_left=2,224, fact_left=2,224" which is what
                # happens when a self-join has two CREATE VIEW
                # statements with the same view name (DuckDB allows
                # this in CREATE OR REPLACE; the dict can carry both
                # entries when the regex captures the same lowercased
                # name twice through subtle whitespace/quote
                # differences pre-normalisation).  Adding the count
                # prefix + per-instance suffix makes the breakdown
                # honest about what was actually parsed.
                ordered = sorted(per_table_file_counts.items(),
                                 key=lambda kv: kv[1], reverse=True)
                shown = ordered[:6]
                _seen_names: Dict[str, int] = {}
                _display_pairs: List[str] = []
                for name, count in shown:
                    _idx = _seen_names.get(name, 0)
                    _seen_names[name] = _idx + 1
                    _disp = f"{name}#{_idx + 1}" if _idx > 0 else name
                    _display_pairs.append(f"{_disp}={count:,}")
                _per_table_str = (
                    f" · {len(per_table_file_counts)} tables, "
                    f"top {len(shown)}: " + ", ".join(_display_pairs)
                )
                if len(ordered) > 6:
                    _per_table_str += f" (+{len(ordered) - 6} more)"
            _pa_status = (
                "PA=disabled (enable multi_worker.allow_partition_aligned_join)"
                if not allow_pa else
                "PA=attempted-not-applicable (see partition_aligned_skip row above for reason)"
            )
            _bj_status = (
                "BJ=disabled (enable multi_worker.allow_broadcast_join)"
                if not allow_bj else
                "BJ=attempted-not-applicable (see broadcast_join_skip row above for reason)"
            )
            _record_skip(
                f"{n_views} CREATE VIEW statements (v1 supports 1; query references "
                f"{len(_ref_tables)} tables, F cannot safely split JOINs/UNIONs)"
                f"{_per_table_str} · {_pa_status} · {_bj_status}"
            )
            return None

        # BF-587 (2026-05-29): when setup_sql has MULTIPLE
        # ``read_parquet([...])`` arrays (BF-494 partition-spec
        # evolution produces UNION ALL with one array per spec),
        # the legacy single-array slicer left every array but the
        # first un-chunked.  Every worker scanned the same un-sliced
        # arrays in parallel → "files not distributed".  Detect the
        # multi-array case and route to the per-array builder.
        # BF-589: skip matches inside SQL string literals (BF-573-class
        # bug — BF-587 originally walked every match including ones
        # that lived in user data).
        _lit_ranges_detect = _string_literal_ranges(setup_sql_combined)
        # Function-scope: set on BOTH the multi-array and single-array
        # paths below, and read much later at the builder call.  Declared
        # inside a branch it would be undefined on the other path — the
        # exact NameError class that bit this file's author three times
        # today, hidden each time by a fail-open handler.
        _mw_data_uris: list = []
        _mw_unclassified_arrays = 0
        _all_arrays = [
            m for m in _READ_PARQUET_RE.finditer(setup_sql_combined)
            if not _inside_any_range(m.start(), _lit_ranges_detect)
        ]
        if len(_all_arrays) > 1:
            logger.info(
                "[multi-worker] BF-587: setup_sql has %d read_parquet "
                "arrays (likely BF-494 partition-spec evolution).  "
                "Slicing EACH array per chunk so files distribute.",
                len(_all_arrays),
            )
            # Build a flat union of all arrays' files for the SplitPlan
            # decision (file count, splittability).  Each chunk's
            # builder then slices each array proportionally.
            #
            # ── 2026-08-21 — AND SEPARATE DATA FROM MoR DELETE ARRAYS ─────
            # The auxiliary-array guard below is handed `data_file_uris` so it
            # can preserve delete arrays intact per chunk.  It was handed THIS
            # flat union — built from EVERY array, deletes included — so its
            # test ("none of my files are in the data set") could never be
            # true, and the pos-delete array was SLICED like data.
            #
            # Proven: with the union, a chunk's SQL contains 0 of 2 delete
            # files; the worker applies NO deletes and RETURNS DELETED ROWS.
            # Silent corruption on every merge-on-read table under
            # multi-worker dispatch.
            #
            # iceberg_mor.build_mor_view_sql emits data arrays with
            # `hive_partitioning=true` (lines 304, 443) and pos-delete arrays
            # with `union_by_name=true) pd` (402, 414), so the shapes are
            # distinguishable at the call site.  Classify on that, and when we
            # CANNOT prove which arrays are data, refuse to split rather than
            # guess — slicing the wrong array resurrects deleted rows, and
            # preserving the wrong one duplicates live ones.  Single-worker is
            # slower; both wrong answers are silent.
            file_list = []
            # 2026-10-06 -- ONE classifier (``_classify_parquet_arrays``),
            # shared with the JOIN paths' per-view extraction, which used the
            # first array of each view and so planned a MoR view's DELETE
            # files as the table.  The rule is unchanged: the options window
            # runs to the call's closing paren (2026-08-21) and data is
            # recognised by the hive_partitioning OPTION, not its value
            # (2026-09-25).
            for _arr in _classify_parquet_arrays(
                    setup_sql_combined, pattern=_READ_PARQUET_RE):
                _is_data = _arr["kind"] == ARRAY_DATA
                if _arr["kind"] == ARRAY_UNKNOWN:
                    _mw_unclassified_arrays += 1
                for t in _arr["files"]:
                    file_list.append(t)
                    if _is_data:
                        _mw_data_uris.append(t)
            inner_match = "__BF587_MULTI__"  # sentinel; not used by builder below
            _multi_array_mode = True
            # FAIL CLOSED.  If any array's shape is unrecognised, or no array
            # looks like data at all, we cannot say which to slice and which
            # to preserve — and BOTH wrong answers are silent: slicing a
            # delete array resurrects deleted rows, preserving a data array
            # duplicates live ones.  Refuse to split; single-worker is slower
            # and correct.
            if _mw_unclassified_arrays or not _mw_data_uris:
                _record_skip(
                    f"multi-array setup SQL with "
                    f"{_mw_unclassified_arrays} unclassifiable read_parquet "
                    f"array(s) and {len(_mw_data_uris)} identified data "
                    f"file(s) — refusing to split, because slicing a MoR "
                    f"delete array returns deleted rows")
                logger.warning(
                    "[multi-worker] REFUSING to split %d read_parquet arrays: "
                    "%d could not be classified as data or delete (data "
                    "arrays carry hive_partitioning=true, pos-delete arrays "
                    "union_by_name=true).  Running single-worker — slicing "
                    "the wrong array corrupts results silently.",
                    len(_all_arrays), _mw_unclassified_arrays,
                )
                return None
        else:
            inner_match, file_list = _extract_file_list(setup_sql_combined)
            _multi_array_mode = False
            # One array => it is the data array; the guard is a no-op here but
            # must still receive a real list rather than an undefined name.
            _mw_data_uris = list(file_list or [])
        if not inner_match or not file_list:
            # BF-394: try the glob-form fallback before giving up.  Enumerate
            # the s3:// URI via boto3 LIST, then rewrite the setup SQL to the
            # array form so the rest of the dispatcher (chunk builder etc.)
            # works unchanged.
            glob_info = _extract_glob_url(setup_sql_combined)
            if glob_info and conn_config:
                quoted_orig, glob_url = glob_info
                logger.info(
                    "[multi-worker] setup SQL uses glob form (%s) — "
                    "enumerating via boto3 LIST to enable F", glob_url,
                )
                glob_files = _list_s3_glob(glob_url, conn_config)
                if glob_files:
                    # Build new file-list string and splice it in
                    file_list_str = ", ".join(f"'{u}'" for u in glob_files)
                    new_setup = setup_sql_combined.replace(
                        quoted_orig, f"[{file_list_str}]", 1,
                    )
                    inner_match = file_list_str
                    file_list = glob_files
                    setup_sql_combined = new_setup
                    logger.info(
                        "[multi-worker] glob enumeration found %d parquet files",
                        len(file_list),
                    )
                else:
                    _record_skip(
                        f"glob enumeration of {glob_url} returned 0 files — "
                        "check S3 prefix, credentials, or boto3 LIST permissions"
                    )
                    return None
            else:
                _record_skip(
                    "setup SQL has no read_parquet([...]) array AND no s3:// glob — "
                    "dispatcher can't enumerate chunks"
                )
                return None

        # ── SCAN-STRATEGY Phase 2 — REFINE plan with real file_list ─────
        # The EARLY plan (above) used a regex-estimated file_count.  For
        # literal file arrays that estimate is exact.  For glob form,
        # the estimate is 1 (a single quoted glob URI) but post-
        # enumeration we have the real count — sometimes thousands of
        # files.  Re-evaluate when the estimate was materially wrong
        # so glob queries don't get locked into INTERACTIVE when they
        # should be BULK_SCAN.
        try:
            from core.scan_strategy import (
                ScanStrategist, WorkloadContext, order_files,
            )
            import re as _sp_re_l
            _real_count = len(file_list)
            # Re-plan if count is materially different OR the early
            # phase failed (scan_plan is None).  ``_wc_e`` may not exist
            # if the EARLY try-block exited via the regex import — use
            # locals() to probe safely.
            _early_count_est = (
                locals().get("_wc_e").file_count
                if scan_plan is not None and "_wc_e" in locals()
                else 0
            )
            _materially_different = (
                scan_plan is None
                or (_real_count >= 200 and _early_count_est < 50)
                or (_real_count < 50 and _early_count_est >= 500)
            )
            if _materially_different:
                _sql_upper_l = (sql or "").upper()
                _wc_l = WorkloadContext(
                    caller=caller or "unknown",
                    file_count=_real_count,
                    total_bytes=0,
                    has_limit=bool(_sp_re_l.search(r"\bLIMIT\s+\d+", _sql_upper_l)),
                    has_aggregation=bool(_sp_re_l.search(
                        r"\b(SUM|COUNT|AVG|MIN|MAX|GROUP\s+BY)\b", _sql_upper_l,
                    )),
                    has_group_by=bool(_sp_re_l.search(r"\bGROUP\s+BY\b", _sql_upper_l)),
                    has_join=bool(_sp_re_l.search(r"\bJOIN\b", _sql_upper_l)),
                    has_order_by=bool(_sp_re_l.search(r"\bORDER\s+BY\b", _sql_upper_l)),
                )
                scan_plan = ScanStrategist().plan(workload=_wc_l)
                logger.info(
                    "[scan-strategy] REFINED caller=%s files=%d → profile=%s "
                    "order=%s workers=%d (was estimated %d files)",
                    _wc_l.caller, _wc_l.file_count, scan_plan.profile.value,
                    scan_plan.file_order.value, scan_plan.max_workers,
                    _early_count_est,
                )
                # Re-emit so the chip updates with refined data.
                _emit_scan_plan_decision(
                    execution_id=execution_id,
                    caller=_wc_l.caller,
                    file_count=_wc_l.file_count,
                    scan_plan=scan_plan,
                )
                mw_cfg = dict(mw_cfg)
                mw_cfg["max_workers"]          = scan_plan.max_workers
                mw_cfg["min_files_to_split"]   = scan_plan.min_files_to_split
                mw_cfg["max_files_per_worker"] = scan_plan.max_files_per_worker

            # Re-order file_list per plan.file_order BEFORE chunking so
            # the splitter sees the workload in optimal order.  When the
            # plan says MANIFEST_ORDER (default for back-compat callers),
            # this is a no-op and the original order survives.
            if scan_plan is not None:
                file_list = [str(f) for f in order_files(file_list, scan_plan.file_order)]
                # Mirror the new file_list back into the setup SQL so each
                # worker's chunk slice respects the chosen order.
                if not _multi_array_mode and inner_match:
                    new_inner = ", ".join(f"'{u}'" for u in file_list)
                    setup_sql_combined = setup_sql_combined.replace(
                        inner_match, new_inner, 1,
                    )
                    inner_match = new_inner
        except Exception as _ss_late_exc:
            logger.warning(
                "[scan-strategy] LATE refine failed (%s) — using EARLY "
                "plan + manifest order", _ss_late_exc, exc_info=True,
            )

        # ── Phase 7 Part 1 — adaptive degree off the fleet running-count ──
        # industrialization.adaptive_duckdb (default OFF).  Makes the
        # scan-strategy profile an OUTPUT of live fleet load instead of a
        # fixed caller choice: a quiet fleet keeps today's split + up-to-4
        # -threads behaviour (latency mode); a busy fleet forces a single
        # subprocess at a lower thread count and skips multi-worker
        # entirely (throughput mode) so N concurrent users share the pod
        # instead of each grabbing 4 threads and starving each other.
        # Chosen ONCE here, held for the rest of this query (no mid-query
        # re-evaluation — stability over reactivity, per the Phase 7
        # edge-case contract).  Correctness-NEUTRAL: this only throttles
        # HOW MUCH parallelism a query gets; it never touches which rows
        # a query is splittable into (that safety gate — non-decomposable
        # aggregates never split — lives untouched in query_splitter and
        # fires exactly as it does today, before or after this block).
        # Fail-open: flag OFF or ANY error here leaves scan_plan / mw_cfg
        # untouched = today's fixed behaviour.
        try:
            from core.industrialization.flags import is_enabled as _adv_enabled
            if _adv_enabled("adaptive_duckdb") and scan_plan is not None:
                from core.industrialization.adaptive_duckdb import compute_degree
                _degree = compute_degree()
                logger.info("[adaptive-duckdb] %s", _degree.rationale)
                if _degree.mode == "throughput":
                    # NO split — the clearest, safest way to guarantee
                    # "single subprocess" is to not enter multi-worker at
                    # all; the caller's existing single-worker fallback
                    # (s3_full_copy / run_duckdb_copy_to) then runs, and
                    # THAT chokepoint applies the adaptive thread count
                    # (see core.duckdb_subprocess.run_duckdb_copy_to).
                    _record_skip(
                        f"adaptive_duckdb: {_degree.rationale}",
                        engine_name="single",
                    )
                    return None
                mw_cfg = dict(mw_cfg)
                mw_cfg["max_workers"] = max(1, min(
                    int(mw_cfg.get("max_workers", 4) or 4), _degree.max_workers))
        except Exception as _adv_exc:
            logger.debug(
                "[adaptive-duckdb] degree override skipped (fail-open, "
                "today's fixed scan_plan/mw_cfg stays in effect): %s",
                _adv_exc,
            )

        # Cheap pre-check: feature flag + splittability + size threshold
        #
        # 2026-07-26 — partial-aggregate decomposition (opt-in, inline
        # default False; no config.py change).  When the flag is ON and the
        # SQL is a PROVABLY-decomposable aggregate expression
        # (SUM(a)/SUM(b), MAX(x)-MIN(x), CASE/COALESCE over aggregates,
        # ...), decide_split() will produce a partial→final plan instead of
        # refusing — so the ``detect_unsupported`` refusal inside
        # should_use_multi_worker() must not veto dispatch for those
        # shapes.  Everything else about the gate (enabled / file count /
        # worker count) still applies.  _pad_plan is reused further down to
        # (a) override an engine-router SINGLE verdict caused by the same
        # refusal and (b) run the final aggregation over the merged
        # partials before the parquet write.
        _pad_plan = None
        if bool(mw_cfg.get("partial_agg_decomposition", False)):
            try:
                from core.query_splitter import plan_partial_agg_decomposition
                _pad_plan = plan_partial_agg_decomposition(sql or "")
            except Exception as _pad_plan_exc:
                logger.debug("[partial-agg] planner unavailable (%s) — "
                             "flag treated as OFF", _pad_plan_exc)
                _pad_plan = None
        # 2026-07-26 audit fix (WIRING GAP): the sketch phase (1a/1b) was
        # planner-complete but dispatcher-unreachable — decide_split honours
        # ``multi_worker.sketch_partials``, but this veto-override only
        # consulted the partial-agg plan, so ``approx_count_distinct`` /
        # ``approx_quantile`` always skipped to single-worker.  Mirror
        # decide_split's EXACT order (partial-agg plan first, sketch second)
        # so the plan the dispatcher holds for the final-aggregation step is
        # byte-identical to the plan the workers will run.
        if _pad_plan is None and bool(mw_cfg.get("sketch_partials", False)):
            try:
                from core.query_splitter import plan_sketch_decomposition
                _pad_plan = plan_sketch_decomposition(sql or "")
            except Exception as _sk_plan_exc:
                logger.debug("[sketch] planner unavailable (%s) — flag "
                             "treated as OFF", _sk_plan_exc)
        from core.query_cache_integration import should_use_multi_worker
        if not should_use_multi_worker(sql, file_list):
            _pad_gate_ok = False
            if _pad_plan is not None:
                try:
                    # 2026-08-04 — workload-aware gate (bytes/width), same
                    # helper as decide_split/should_use_multi_worker.
                    from core.query_splitter import (
                        effective_split_workload as _esw_pad,
                    )
                    _pad_gate_ok = (
                        bool(file_list)
                        and _esw_pad(file_list, sql or "")[0] >= int(
                            mw_cfg.get("min_files_to_split", 50) or 50)
                        and int(mw_cfg.get("max_workers", 4) or 4) > 1
                    )
                except Exception:
                    _pad_gate_ok = False
            if _pad_gate_ok:
                logger.info(
                    "[partial-agg] splittability veto overridden — SQL is a "
                    "decomposable aggregate expression and "
                    "multi_worker.partial_agg_decomposition is ON "
                    "(exec=%s files=%d)",
                    execution_id or "n/a", len(file_list),
                )
            else:
                # ── Phase 2a (2026-07-26) — B0 zero-copy exchange ────────
                # The splittability veto stands for the legacy paths, but
                # when ``multi_worker.exchange_enabled`` is ON (inline
                # default False) AND the refused shape's grouping/window
                # key is provably a superset of the island's hive
                # partition columns, dispatch it partition-aligned: each
                # worker owns whole partition tuples and runs the ORIGINAL
                # SQL; the merge is a plain union.  Exact — no sketch, no
                # shuffle.  Any refusal/failure inside returns None and
                # execution continues into the existing skip path below,
                # byte-for-byte today's behaviour.
                _b0_result = _try_exchange_b0_dispatch(
                    sql=sql,
                    setup_sql_combined=setup_sql_combined,
                    inner_match=inner_match,
                    file_list=file_list,
                    multi_array_mode=_multi_array_mode,
                    output_file=output_file,
                    mw_cfg=mw_cfg,
                    cancel_event=cancel_event,
                    progress_cb=progress_cb,
                    httpfs_required=httpfs_required,
                    duckdb_settings=duckdb_settings,
                    conn_config=conn_config,
                    execution_id=execution_id,
                    cancellable=cancellable,
                )
                if _b0_result is not None:
                    return _b0_result
                # ── Phase 2b (2026-07-26) — B1 hash-spool exchange ───────
                # B0 refused (key not partition-aligned / no hive cols):
                # try the local-spool hash repartition.  Same flag; extra
                # knobs (exchange_min_files / bucket_factor / max_spool_gb)
                # read inline from mw_cfg.  Every refusal / abort / gate
                # failure inside returns None ⇒ execution continues into
                # the existing skip path below, byte-for-byte today's
                # behaviour.  B0 ALWAYS gets first refusal — zero-copy
                # beats a spool whenever the key is partition-aligned.
                _b1_result = _try_exchange_b1_dispatch(
                    sql=sql,
                    setup_sql_combined=setup_sql_combined,
                    inner_match=inner_match,
                    file_list=file_list,
                    multi_array_mode=_multi_array_mode,
                    output_file=output_file,
                    mw_cfg=mw_cfg,
                    cancel_event=cancel_event,
                    progress_cb=progress_cb,
                    httpfs_required=httpfs_required,
                    duckdb_settings=duckdb_settings,
                    conn_config=conn_config,
                    execution_id=execution_id,
                    cancellable=cancellable,
                )
                if _b1_result is not None:
                    return _b1_result
                from core.query_splitter import (
                    detect_unsupported, effective_split_workload,
                )
                unsup = detect_unsupported(sql or "")
                mw_min = int(mw_cfg.get("min_files_to_split", 50) or 50)
                # 2026-08-04 — report the WORKLOAD-scaled count, not the raw
                # one: with the cost-aware gate a refusal here means the
                # effective workload (count, or bytes/width when known) is
                # genuinely under the threshold.
                _eff_fc, _eff_axis = (len(file_list), "count")
                try:
                    _eff_fc, _eff_axis = effective_split_workload(
                        file_list, sql or "")
                except Exception:
                    pass
                if unsup:
                    _record_skip(f"SQL not splittable: {unsup}")
                elif _eff_fc < mw_min:
                    _record_skip(
                        f"workload={_eff_fc} effective files "
                        f"(raw file_count={len(file_list)}, axis={_eff_axis})"
                        f" < min_files_to_split={mw_min} "
                        "(set min_files_to_split lower in admin if you want F to fire on smaller queries)"
                    )
                else:
                    _record_skip("should_use_multi_worker returned False (config check)")
                return None

        # BF-587: pick the multi-array builder when setup_sql had
        # multiple read_parquet arrays (per-spec UNION ALL).  The
        # single-array builder only sliced the first array; this one
        # slices EVERY array proportionally so workers see disjoint
        # files end-to-end.
        if _multi_array_mode:
            builder = _build_chunk_setup_builder_multi_array(
                setup_sql_combined, httpfs_required,
                # 2026-08-04 — lets the builder tell DATA arrays from
                # AUXILIARY ones (MoR delete files): auxiliary arrays are
                # preserved intact per chunk instead of sliced to [].
                # DATA arrays only — see the classification above.  Passing
                # the flat union made this guard vacuous and sliced the
                # delete array.
                data_file_uris=(list(_mw_data_uris) if _mw_data_uris else None),
            )
        else:
            builder = _build_chunk_setup_builder(
                setup_sql_combined, inner_match, httpfs_required,
            )

        # ── BF-385 — Engine Router (relocated round 11, 2026-06-02) ───────
        # Pre-round-11: engine_router decision fired AFTER prewarm (~line
        # 1770), so during the 30s-250s of prewarm HEAD storms the
        # engine_router chip on the UI was DARK — user couldn't tell why
        # the query was taking so long.
        #
        # Round 11 fix: decide engine FIRST, record decision (chip lights
        # up immediately), THEN prewarm if we're actually using
        # multi-worker.  Bonus correctness: if router says SINGLE or
        # SPARK_CONNECT, we skip prewarm entirely instead of wasting
        # 30s-250s on a HEAD storm we'll never benefit from.
        #
        # Round 12 deep-audit fix: hard-code engine name fallbacks
        # OUTSIDE the try block so an ImportError on engine_router
        # doesn't cascade into a NameError in the except handler /
        # downstream comparisons.  String values match engine_router's
        # public constants.
        ENGINE_SINGLE         = "single"
        ENGINE_MULTI_WORKER   = "multi_worker"
        ENGINE_MULTI_POD      = "multi_pod"
        ENGINE_SPARK_CONNECT  = "spark_connect"
        # 2026-10-08 -- the brain-cache hit THIS dispatcher resolved and
        # will serve (declared outside the try: a failure before the lookup
        # must read as "no hit", never as a NameError in the serve branch).
        _brain_hit = None
        _qf_kwargs: Optional[Dict[str, Any]] = None
        try:
            from core.engine_router import (
                decide_engine, record_decision, QueryFeatures,
                ENGINE_SINGLE as _ER_SINGLE,
                ENGINE_MULTI_WORKER as _ER_MW,
                ENGINE_MULTI_POD as _ER_MP,
                ENGINE_SPARK_CONNECT as _ER_SC,
            )
            # Trust the module's actual constants if import succeeded —
            # protects against the unlikely case engine_router renames
            # a constant string without updating callers.
            ENGINE_SINGLE        = _ER_SINGLE
            ENGINE_MULTI_WORKER  = _ER_MW
            ENGINE_MULTI_POD     = _ER_MP
            ENGINE_SPARK_CONNECT = _ER_SC
            # Phase 155 -- enrich features so the brain's manifest /
            # cache / hostile / cost sensors actually fire.  All optional;
            # missing inputs make brain skip the corresponding gate.
            _brain_bucket = ""
            _brain_prefix = ""
            try:
                if file_list:
                    _first = str(file_list[0])
                    if _first.startswith("s3://"):
                        _u = _first[len("s3://"):]
                        _slash = _u.find("/")
                        if _slash > 0:
                            _brain_bucket = _u[:_slash]
                            # prefix = path-to-table (drop trailing "/data/...parquet")
                            _key = _u[_slash + 1:]
                            _data_idx = _key.rfind("/data/")
                            if _data_idx > 0:
                                _brain_prefix = _key[:_data_idx]
            except Exception:
                pass
            _brain_sql_hash = ""
            try:
                from core.agg_cache import make_sql_hash as _mk_sh
                _brain_sql_hash = _mk_sh(sql) if sql else ""
            except Exception:
                pass
            # 2026-10-08 -- ONE lookup of the brain's sql-hash RESULT cache,
            # made here because this is the one place that can SERVE it.
            # The router used to look it up on its own, assert "agg_cache
            # hit" for a snapshot it did not know (``snapshot=?``) and route
            # to SINGLE -- where this function returned None and the caller
            # read every file (live: 42 s cold -> 245 s "warm", 17 times in
            # 90 minutes).  Now the hit object travels into the decision
            # (``QueryFeatures.cached_result``) and, on rule=brain_cache, is
            # served below.  No snapshot = no lookup (unknown is unsafe);
            # a bypass/refresh request asked for the newest data = no serve.
            try:
                from core.agg_cache import lookup_brain_cache as _lookup_bc
                from core.iceberg_freshness_bound import (
                    newest_snapshot_is_required as _newest_req,
                )
                if not _brain_sql_hash:
                    pass
                elif not iceberg_snapshot_id:
                    logger.info(
                        "[brain-cache] snapshot unknown for exec=%s -- no "
                        "cache lookup (a snapshot-less entry is never a hit)",
                        execution_id or "n/a",
                    )
                elif _newest_req():
                    logger.info(
                        "[brain-cache] newest data required (bypass/refresh) "
                        "for exec=%s -- no cache lookup", execution_id or "n/a",
                    )
                else:
                    _brain_hit = _lookup_bc(
                        _brain_sql_hash, str(iceberg_snapshot_id))
            except Exception as _bc_exc:
                logger.debug("[brain-cache] lookup skipped: %s", _bc_exc)
                _brain_hit = None
            # 2026-06-30 deep-dive fix: route through the single
            # ``QueryFeatureBuilder`` chokepoint so the brain receives
            # predicates + partition-column classification + manifest
            # stats from the iceberg-in-DB cache.  Before this change
            # the brain ALWAYS saw manifest_stats=None and
            # where_predicates=[] which made every pruning gate a
            # no-op (silent perf regression).
            try:
                from core.query_feature_builder import QueryFeatureBuilder
                _table_meta = {
                    "bucket":            _brain_bucket,
                    "table_prefix":      _brain_prefix,
                    "snapshot_id":       iceberg_snapshot_id or None,
                    # KNOWN-DEAD (2026-08-09 lint audit):
                    # `_table_meta_partition_cols` is assigned NOWHERE in this
                    # module, so `locals().get(...)` is always None and this
                    # always evaluates to [].  Runtime-safe (the guard means
                    # no NameError) but the brain never receives the
                    # partition-column classification this block was added to
                    # deliver.  Left as-is deliberately: sourcing the real
                    # column list is a behaviour change, not a lint fix.
                    "partition_columns": list(_table_meta_partition_cols)  # noqa: F821
                                          if isinstance(locals().get("_table_meta_partition_cols"), (list, tuple))
                                          else [],
                    # Deep-dive #3 (2026-06-30): supplement DB has a
                    # format column ('iceberg' vs 'parquet'); querying
                    # with the wrong format returns zero rows.  Infer
                    # from the snapshot_id presence -- iceberg always
                    # has one, plain-parquet brain rows never do.
                    # Deep-dive #6 (2026-06-30): use a numeric-aware
                    # zero check.  Pre-fix the bare ``!= "0"`` accepted
                    # "00", "0000", "0.0", float 0.0, int 0 -- all
                    # zero variants leaked through as iceberg.  Now we
                    # try-coerce to int(float(x)) and compare to 0.
                    "format":            _qsb_infer_format(iceberg_snapshot_id),
                }
                _bundle = QueryFeatureBuilder.build(
                    sql=sql,
                    table_metadata=_table_meta,
                    file_count=len(file_list),
                    # Strategic: pass file_paths so the supplement DB
                    # query narrows to just our files instead of scanning
                    # the entire (bucket, prefix) supplement table.
                    file_paths=list(file_list) if file_list else None,
                    row_estimate=0,
                    is_cross_source=False,
                )
                _qf_kwargs = dict(_bundle.to_query_features_kwargs())
                _qf_kwargs["cached_result"] = _brain_hit
                decision = decide_engine(QueryFeatures(**_qf_kwargs))
            except Exception as _qfb_exc:
                # Fail-OPEN: if the builder explodes we DON'T want the
                # caller to crash on dispatch.  Fall back to the old
                # field-by-field construction so the engine_router can
                # still make a SAFE decision (just without brain pruning).
                logger.debug(
                    "[engine-router] QueryFeatureBuilder fallback "
                    "(%s) -- building minimal QueryFeatures",
                    _qfb_exc,
                )
                _qf_kwargs = dict(
                    sql=sql,
                    file_count=len(file_list),
                    row_estimate=0,
                    is_cross_source=False,
                    sql_hash=_brain_sql_hash,
                    snapshot_id=iceberg_snapshot_id or None,
                    bucket=_brain_bucket,
                    table_prefix=_brain_prefix,
                    cached_result=_brain_hit,
                )
                decision = decide_engine(QueryFeatures(**_qf_kwargs))
            record_decision(decision, execution_id=execution_id)
            logger.info(
                "[engine-router] chose %s (rule=%s, reason=%s, exec=%s)",
                decision.engine, decision.rule, decision.reason,
                execution_id or "n/a",
            )
        except Exception as router_err:
            logger.debug("[engine-router] decision failed (%s) — defaulting to multi_worker",
                         router_err)
            class _D:
                engine = ENGINE_MULTI_WORKER
                rule = "fallback"
                reason = "engine_router import or decide_engine raised"
            decision = _D()

        # 2026-10-08 -- rule=brain_cache means THIS call serves the hit it
        # routed on: the cached parquet is copied to ``output_file``, no
        # data file is read, and the pruning record says so.  Returning the
        # served dict is what makes the caller NOT fall through to its
        # single-worker full scan (returning None is exactly the live
        # defect).  If the entry vanished between the decision and the
        # serve, decide AGAIN without it -- never run the old SINGLE verdict.
        if str(getattr(decision, "rule", "") or "") == "brain_cache":
            _served = None
            if _brain_hit is not None:
                try:
                    from core.agg_cache import serve_brain_cache_hit as _serve_bc
                    _served = _serve_bc(
                        _brain_hit, output_file, execution_id=execution_id)
                except Exception as _serve_exc:
                    logger.warning("[brain-cache] serve raised (%s) -- "
                                   "re-deciding without the hit", _serve_exc)
                    _served = None
            if _served is not None:
                logger.info(
                    "[engine-router] brain_cache SERVED exec=%s rows=%d "
                    "snapshot=%s age=%.1fs -- 0 data files read",
                    execution_id or "n/a", int(_served.get("total_rows") or 0),
                    _served.get("snapshot_id"),
                    float(_served.get("cache_age_seconds") or 0.0),
                )
                return _served
            logger.warning(
                "[engine-router] brain_cache hit could not be served "
                "(exec=%s) -- re-deciding without it", execution_id or "n/a",
            )
            _brain_hit = None
            try:
                from core.engine_router import (
                    decide_engine as _decide_again,
                    record_decision as _record_again,
                    QueryFeatures as _QF_again,
                )
                _again = dict(_qf_kwargs or {})
                if not _again:
                    _again = dict(sql=sql, file_count=len(file_list),
                                  sql_hash=_brain_sql_hash,
                                  snapshot_id=iceberg_snapshot_id or None)
                _again["cached_result"] = None
                decision = _decide_again(_QF_again(**_again))
                _record_again(decision, execution_id=execution_id)
                logger.info(
                    "[engine-router] chose %s (rule=%s, reason=%s, exec=%s) "
                    "[re-decided without the brain-cache hit]",
                    decision.engine, decision.rule, decision.reason,
                    execution_id or "n/a",
                )
            except Exception as _again_exc:
                logger.debug("[engine-router] re-decision failed (%s) -- "
                             "defaulting to multi_worker", _again_exc)
                decision = _D()

        # Bail-out BEFORE prewarm when we're routing elsewhere.
        if decision.engine == ENGINE_SINGLE:
            # 2026-07-26 — the router's _is_splittable_sql uses the plain
            # detect_unsupported() gate, which (by design — the SQL-connector
            # sharder shares it) still refuses decomposable aggregate
            # expressions.  When the decomposition flag is ON and the shape
            # is provably decomposable, proceed on the multi-worker path
            # instead of honouring the SINGLE verdict.
            if _pad_plan is not None:
                logger.info(
                    "[partial-agg] engine_router=SINGLE overridden → "
                    "multi_worker (partial_agg_decomposition eligible, "
                    "exec=%s)", execution_id or "n/a",
                )
            else:
                logger.info(
                    "[scan-strategy] engine_router=SINGLE → skipping prewarm "
                    "(would be wasted on single-worker path)"
                )
                return None
        if decision.engine == ENGINE_SPARK_CONNECT:
            logger.info(
                "[scan-strategy] engine_router=SPARK_CONNECT → skipping "
                "prewarm (Spark Connect is a different code path)"
            )
            return None

        # ── SCAN-STRATEGY Phase 3 — PREWARM after splittability + router check ──
        # Deep-dive fix: pre-fix, the prewarm fired BEFORE
        # should_use_multi_worker(), so small queries that the dispatcher
        # was going to skip anyway still incurred 1-3s of HEAD-storm
        # latency.  Now prewarm only runs when (a) the plan asked for it,
        # (b) we've passed the splittability gate, AND (c) the engine
        # router actually chose multi-worker (round 11).
        if scan_plan is not None and scan_plan.prewarm_footers:
            def _build_prewarm_client():
                """Construct an S3 client honouring conn_config's
                endpoint_url + region + credentials.  Falls back to
                default boto3 chain for auth modes (assume_role,
                iam_role) where the dispatcher hasn't pre-resolved keys
                — the default chain works in most pod IAM setups.  Any
                exception raised here causes prewarm to silently no-op
                (logged at DEBUG); never blocks the actual scan."""
                import boto3
                cc = conn_config or {}
                # 2026-10-26 -- THE resolver's boto3 kwargs (region, the
                # VPCE-normalised endpoint, addressing style, TLS, keys):
                # this client had no addressing style and the RAW
                # endpoint, so on a VPCE it warmed nothing, silently.
                from core.s3_access import resolve_s3_access
                kwargs = resolve_s3_access(cc, proxy=False).boto3_client_kwargs(
                    cc, config_kwargs={
                        "max_pool_connections": scan_plan.boto3_max_pool_connections,
                        "retries": {"max_attempts": 2, "mode": "standard"},
                    })
                kwargs.pop("service_name", None)
                return boto3.client("s3", **kwargs)

            try:
                from core.scan_strategy import prewarm_footers_parallel
                # Round 9 — wire BOTH callbacks:
                #   * progress_cb (string message) → still fired so the
                #     legacy progressLog updates
                #   * _PREWARM_PROGRESS_CALLBACK (structured event) →
                #     fires the new ``prewarm_stage`` WS event so the
                #     frontend can render a DISTINCT chip with files_total,
                #     concurrency, warmed, elapsed_s etc.
                def _prewarm_progress(_evt: Dict[str, Any]) -> None:
                    # Structured fan-out to UI chip.
                    try:
                        if _PREWARM_PROGRESS_CALLBACK is not None and execution_id:
                            _PREWARM_PROGRESS_CALLBACK({
                                "execution_id": execution_id,
                                **_evt,
                            })
                    except Exception:
                        pass
                    # String fan-out to legacy progressLog.
                    try:
                        if progress_cb is not None:
                            progress_cb(0, 0, _evt.get("message") or _evt.get("stage", ""))
                    except Exception:
                        pass
                prewarm_footers_parallel(
                    file_list, scan_plan,
                    boto3_client_factory=_build_prewarm_client,
                    cancel_event=cancel_event,
                    progress_cb=_prewarm_progress,
                )
            except Exception as _pw_exc:
                logger.debug("[scan-strategy] prewarm raised: %s", _pw_exc)

        # Merge caller-supplied duckdb_settings with auto-resolved S3
        # credentials.  Worker connections need s3_region / s3_access_key /
        # s3_secret_access_key / s3_endpoint when setup_sql contains raw
        # ``s3://`` URLs.  When setup_sql contains presigned URLs instead
        # (smart-VPC fast path), ``_duckdb_settings_from_conn_config``
        # consults the planner and intentionally OMITS s3_endpoint +
        # credentials so workers don't double-sign.  Single decision
        # point, no per-worker patching needed.
        merged_settings: Dict[str, Any] = {}
        merged_settings.update(_duckdb_settings_from_conn_config(
            conn_config,
            setup_sql=setup_sql_combined,
            partial_sql=sql,
        ))
        if duckdb_settings:
            merged_settings.update(duckdb_settings)  # caller wins on conflict

        # NOTE round 11: BF-385 engine router was MOVED to fire BEFORE
        # prewarm (above the Phase 3 block).  The chip lights up
        # immediately on dispatch decision instead of waiting for
        # prewarm's 30s-250s of HEAD storms.  ENGINE_SINGLE and
        # ENGINE_SPARK_CONNECT already returned None above — no need
        # to re-check here.  decision.engine is now either
        # MULTI_WORKER (continue below) or MULTI_POD (handled next).

        if decision.engine == ENGINE_MULTI_POD:
            from core.multi_pod_dispatcher import dispatch_chunks_to_pods
            # BF-583: fire initial progress_cb so the BQB / CQB chip
            # renders "multi_pod (N workers)" immediately on dispatch
            # decision, not after the first pod returns.
            if progress_cb is not None:
                try:
                    _initial_workers = int(mw_cfg.get("max_workers", 4) or 4)
                    progress_cb(0, _initial_workers, "dispatching multi-pod workers")
                except Exception as _pg_err:
                    logger.debug(
                        "[multi-worker] initial progress_cb failed: %s",
                        _pg_err,
                    )
            mp_outcome = dispatch_chunks_to_pods(
                _build_split_plan_for_dispatch(sql, file_list, mw_cfg),
                builder,
                final_sql=sql,
                duckdb_settings=merged_settings,
                cancel_event=cancel_event,
                progress_cb=progress_cb,
                correlation_id=execution_id,        # use real execution_id for traceability
                per_worker_timeout_s=int(mw_cfg.get("per_worker_timeout_seconds", 1800) or 1800),
                fallback_on_error=bool(mw_cfg.get("fallback_on_error", True)),
                execution_id=execution_id,          # propagate for engine-router decision tagging
            )
            if mp_outcome is not None and not mp_outcome.fell_back:
                outcome = mp_outcome
            else:
                # Multi-pod unavailable or fell back → in-pod F as backup.
                # execute_with_multi_worker may return None too (e.g. config
                # disables in-pod F) — guarded by the later None check.
                logger.info("[engine-router] multi_pod returned %s — falling back to in-pod F",
                            "fell_back" if mp_outcome else "None")
                from core.query_cache_integration import execute_with_multi_worker
                outcome = execute_with_multi_worker(
                    sql, file_list, builder,
                    cancel_event=cancel_event, progress_cb=progress_cb,
                    duckdb_settings=merged_settings,
                    cancellable=cancellable,
                )
        else:
            # ENGINE_MULTI_WORKER (default for splittable+enabled queries)
            from core.query_cache_integration import execute_with_multi_worker
            # BF-583 (2026-05-29): fire an immediate progress_cb so the
            # BQB / CQB chip lights up "multi-worker (N workers)"
            # AS SOON AS the dispatcher decides — not after the first
            # worker completes (which could be 5-30s in for a 3000-file
            # scan).  Mirrors what the broadcast-JOIN and partition-
            # aligned paths already do.  Worker count = max_workers cap
            # since the actual plan is built inside execute_with_multi_worker.
            if progress_cb is not None:
                try:
                    _initial_workers = int(mw_cfg.get("max_workers", 4) or 4)
                    progress_cb(0, _initial_workers, "dispatching multi-worker")
                except Exception as _pg_err:
                    logger.debug(
                        "[multi-worker] initial progress_cb failed: %s",
                        _pg_err,
                    )
            outcome = execute_with_multi_worker(
                sql,
                file_list,
                builder,
                cancel_event=cancel_event,
                progress_cb=progress_cb,
                duckdb_settings=merged_settings,
                cancellable=cancellable,
            )
        if outcome is None or outcome.fell_back:
            logger.info(
                "[multi-worker] no usable outcome (fell_back=%s, reason=%s) — "
                "caller will fall back to single-worker",
                getattr(outcome, "fell_back", "n/a"),
                getattr(outcome, "fallback_reason", "n/a"),
            )
            # 149.0 (2026-06-09): record EngineDecision for standard
            # multi-worker fall-back too, so admins see the underlying
            # cause in the diagnose UI instead of a generic
            # "single-worker chosen".
            try:
                from core.engine_router import EngineDecision, record_decision
                record_decision(EngineDecision(
                    engine="single",
                    reason=f"multi-worker fell back to single-worker: "
                            f"{getattr(outcome, 'fallback_reason', 'unknown')}",
                    rule="multi_worker_fell_back",
                ), execution_id=execution_id)
            except Exception as _rec_fail_err:
                logger.debug("[engine-router] multi-worker failure record failed: %s", _rec_fail_err)
            return None

        # 2026-07-26 — partial-aggregate decomposition: the workers emitted
        # PARTIAL aggregate columns (__pd_*) and the merger only UNION'd
        # them.  Apply the coordinator's final aggregation (the plan's
        # final_agg_sql: SUM/MIN/MAX over partials + the original
        # surrounding expression, re-grouped by the original keys) BEFORE
        # anything is written.  FAIL-CLOSED: any problem — including the
        # expected partial columns being absent (i.e. workers did NOT run
        # the decomposed SQL, e.g. a config-flag race) — falls back to
        # single-worker instead of persisting partial rows as if they were
        # the answer.
        _final_table = outcome.table
        if _pad_plan is not None:
            try:
                from core.query_splitter import apply_partial_agg_final
                # 2026-07-26 audit fix (CRITICAL): the plan's
                # ``hugeint_restore`` markers MUST reach the final step —
                # without them a // or % plan runs DECIMAL(38,0)//DECIMAL
                # (true division → DOUBLE, e.g. 181//2 = 90.5) instead of
                # restoring HUGEINT//HUGEINT (= 90) — silent wrong data.
                # The test harnesses always passed the kwarg; this call
                # site didn't (tested-but-not-wired).
                _final_table = apply_partial_agg_final(
                    outcome.table,
                    _pad_plan.final_sql,
                    list(_pad_plan.partial_columns),
                    hugeint_restore=(list(_pad_plan.hugeint_restore)
                                     if _pad_plan.hugeint_restore else None),
                )
                logger.info(
                    "[partial-agg] final aggregation applied: %d partial "
                    "rows → %d final rows (exec=%s)",
                    outcome.table.num_rows, _final_table.num_rows,
                    execution_id or "n/a",
                )
            except Exception as _pad_final_exc:
                logger.warning(
                    "[partial-agg] final aggregation failed (%s) — "
                    "falling back to single-worker for correctness",
                    _pad_final_exc,
                )
                try:
                    from core.engine_router import EngineDecision, record_decision
                    record_decision(EngineDecision(
                        engine="single",
                        reason=(f"partial-agg final aggregation failed: "
                                f"{_pad_final_exc}"),
                        rule="partial_agg_final_failed",
                    ), execution_id=execution_id)
                except Exception as _pad_rec_err:
                    logger.debug("[partial-agg] record_decision failed: %s",
                                 _pad_rec_err)
                return None

        # Write the merged Arrow table → parquet at output_file
        import pyarrow.parquet as pq
        out_dir = os.path.dirname(str(output_file))
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        pq.write_table(
            _final_table,
            str(output_file),
            compression="zstd",
        )

        try:
            file_size = os.path.getsize(str(output_file))
        except OSError:
            file_size = 0

        logger.info(
            "[multi-worker] success: %d rows, %d workers (%d ok/%d fail), "
            "%.1fs total, merge=%s, output=%.1fMB",
            _final_table.num_rows, outcome.worker_count,
            outcome.succeeded, outcome.failed,
            outcome.total_elapsed_s,
            (outcome.merge_strategy + "+partial_agg_final"
             if _pad_plan is not None else outcome.merge_strategy),
            file_size / (1024 * 1024) if file_size else 0,
        )

        return {
            "total_rows":      int(_final_table.num_rows),
            "file_size_bytes": int(file_size),
            "status":          "completed",
            "merge_strategy":  (outcome.merge_strategy + "+partial_agg_final"
                                if _pad_plan is not None
                                else outcome.merge_strategy),
            "worker_count":    outcome.worker_count,
            "elapsed_s":       outcome.total_elapsed_s,
            "from_multi_worker": True,
            "per_worker_summary": outcome.to_dict().get("per_worker", []),
        }
    except Exception as exc:
        logger.warning(
            "[multi-worker] dispatch wrapper raised (%s) — falling back",
            exc, exc_info=True,
        )
        return None
