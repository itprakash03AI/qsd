"""What S3 answered when a read failed -- in one plain sentence (2026-10-26).

The owner's feed worker on AWS S3 (a VPC endpoint in eu-west-1) failed with
``HTTP GET error reading 'https://bucket.vpce-....s3.eu-west-1.vpce.amazonaws.com/
<bucket>/<a 250-character key>`` -- and nothing else: DuckDB puts the URL FIRST
and the status, the region it signed with and S3's own reason AFTER it, and the
platform cut the text at 300-500 characters, so the one fact that tells a
refused read (403) from a missing file (404) from a wrong region was always
gone.

DuckDB's ``HTTPException`` carries the facts as attributes (``status_code``,
``reason``, ``body`` -- S3's XML ``<Code>`` / ``<Message>``); the text says
``in region 'X'``.  ``describe(exc)`` puts them in the order a person reads:
what S3 said, what it usually means, the file (its name, not the URL), the
region the request was signed for.  None = not an S3 HTTP answer (the caller
keeps its own text).
"""
from __future__ import annotations

import re
from typing import Optional

#: S3's error code -> what it usually means, in plain words
MEANING = {
    "AccessDenied": "the connection's credentials may not read this file -- check the bucket policy, "
                    "the IAM role or the KMS key that encrypts it",
    "AllAccessDisabled": "all access to this bucket is turned off",
    "InvalidAccessKeyId": "the access key is not known to S3 -- check the connection's key (or the role it assumes)",
    "SignatureDoesNotMatch": "the secret key does not match the access key -- check the connection's secret",
    "ExpiredToken": "the session token has expired -- the connection's temporary credentials need renewing",
    "InvalidToken": "the session token is not valid",
    "TokenRefreshRequired": "the session token must be refreshed",
    "AuthorizationHeaderMalformed": "the request was signed for the wrong region",
    "PermanentRedirect": "the bucket is in another region than the endpoint -- set the endpoint of the bucket's region",
    "NoSuchKey": "the file the table's metadata names does not exist any more (files removed or a snapshot expired)",
    "NoSuchBucket": "the bucket does not exist (or the endpoint points elsewhere)",
    "SlowDown": "S3 is throttling the reads -- too many requests at once",
    "RequestTimeTooSkewed": "this server's clock is too far from S3's -- check the pod's time",
    "KMS.DisabledException": "the KMS key that encrypts this file is disabled",
    "KMS.AccessDeniedException": "the connection may not use the KMS key that encrypts this file",
}
BY_STATUS = {
    "403": "S3 refused the read -- usually permissions, a KMS key or the endpoint policy of the VPC endpoint",
    "404": "the file was not found",
    "400": "S3 rejected the request",
    "301": "the bucket answers from another region",
    "503": "S3 is busy -- the read can be retried",
}


def _tag(body: str, name: str) -> Optional[str]:
    m = re.search(rf"<{name}>(.*?)</{name}>", body or "", re.S)
    return m.group(1).strip() if m else None


def describe(exc: BaseException) -> Optional[str]:
    """One sentence for an S3 HTTP failure, or None when ``exc`` is not one."""
    status = str(getattr(exc, "status_code", "") or "").strip()
    text = str(exc)
    if not status:
        m = re.search(r"\(HTTP (\d{3})", text)
        status = m.group(1) if m else ""
    if not status or "HTTP" not in text and not hasattr(exc, "status_code"):
        return None
    reason = str(getattr(exc, "reason", "") or "").strip()
    body = str(getattr(exc, "body", "") or "")
    code = _tag(body, "Code")
    s3_message = _tag(body, "Message")
    expected_region = _tag(body, "Region")
    signed = re.search(r"in region '([^']*)'", text)
    url = re.search(r"reading '([^']+)'", text)
    parts = [f"S3 answered HTTP {status}{(' ' + reason) if reason else ''}"]
    if code:
        parts[0] += f" ({code}{': ' + s3_message if s3_message else ''})"
    meaning = MEANING.get(code or "") or BY_STATUS.get(status)
    if code == "AuthorizationHeaderMalformed" and expected_region:
        meaning = f"the request was signed for the wrong region -- S3 expected {expected_region!r}"
    if meaning:
        parts.append(meaning)
    if url:
        # the PATH's last part only: a presigned URL's query string carries
        # X-Amz-Credential / X-Amz-Signature (security review 2026-10-26)
        from urllib.parse import unquote, urlparse
        name = unquote(urlparse(url.group(1)).path.rsplit("/", 1)[-1])
        parts.append(f"file {name}")
    if signed and signed.group(1):
        parts.append(f"signed for region {signed.group(1)!r}")
    return "; ".join(parts)


#: a presigned URL's signing parameters -- never in a log or a record
_AMZ_PARAM = re.compile(r"(X-Amz-(?:Credential|Signature|Security-Token)=)[^&'\s\"]+", re.I)


def scrub(text: str) -> str:
    """``text`` with any presigned-URL credential / signature / token masked."""
    return _AMZ_PARAM.sub(lambda m: m.group(1) + "***", text or "")


def failure_text(exc: BaseException, limit: int = 600) -> str:
    """The text a registration failure records: the S3 sentence when it is
    one (never cut -- it is short), else the exception's own text, cut --
    with presigned-URL signing parameters masked either way."""
    d = describe(exc)
    return scrub(d if d else str(exc)[:limit])
