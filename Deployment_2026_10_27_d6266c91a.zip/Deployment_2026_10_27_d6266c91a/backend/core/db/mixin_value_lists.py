"""Value lists -- storage (2026-10-24; the rules are core/value_lists.py)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.db.models import ValueList, ValueListItem

_DEF_FIELDS = ("name", "description", "source_type", "connection_id", "source_sql",
               "key_column", "label_column", "sync_mode", "sync_every_hours")


class ValueListsMixin:

    def list_value_lists(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [v.to_dict() for v in session.query(ValueList).order_by(ValueList.name).all()]

    def get_value_list(self, list_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.get(ValueList, int(list_id))
            return v.to_dict() if v else None

    def get_value_list_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(ValueList).filter(ValueList.name == str(name)).first()
            return v.to_dict() if v else None

    def create_value_list(self, data: Dict[str, Any], by: str = "") -> Dict[str, Any]:
        with self.get_session() as session:
            v = ValueList(**{k: data.get(k) for k in _DEF_FIELDS if k in data},
                          created_by=by, updated_by=by)
            if not v.source_type:
                v.source_type = "query"
            if not v.sync_mode:
                v.sync_mode = "manual"
            session.add(v)
            session.flush()
            return v.to_dict()

    def update_value_list(self, list_id: int, data: Dict[str, Any], by: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            v = session.get(ValueList, int(list_id))
            if v is None:
                return None
            for k in _DEF_FIELDS:
                if k in data:
                    setattr(v, k, data[k])
            v.updated_by = by
            session.flush()
            return v.to_dict()

    def delete_value_list(self, list_id: int) -> bool:
        with self.get_session() as session:
            session.query(ValueListItem).filter(ValueListItem.list_id == int(list_id)).delete()
            return bool(session.query(ValueList).filter(ValueList.id == int(list_id)).delete())

    def record_value_list_failure(self, list_id: int, error: str, by: str = "") -> Dict[str, Any]:
        """A sync that failed: the reason, and NOTHING else changes (the
        previous values stay and are served, said stale)."""
        with self.get_session() as session:
            v = session.get(ValueList, int(list_id))
            v.last_status = "failed"
            v.last_error = error
            v.last_sync_summary = {"at": datetime.now(timezone.utc).isoformat(), "by": by,
                                   "failed": True, "kept_values": v.value_count or 0}
            session.flush()
            return v.to_dict()

    def replace_value_list_items(self, list_id: int, items: List[Dict[str, Any]], *, by: str = "",
                                 seconds: Optional[float] = None) -> Dict[str, Any]:
        """ONE transaction: the list's values become exactly ``items`` --
        new keys added, changed labels / order / attrs updated, missing keys
        removed -- and the version moves.  Returns the list with the summary."""
        with self.get_session() as session:
            v = session.get(ValueList, int(list_id))
            have = {i.key: i for i in session.query(ValueListItem)
                    .filter(ValueListItem.list_id == int(list_id)).all()}
            want = {i["key"]: i for i in items}
            # the removed keys FIRST, as objects, flushed: a bulk delete left
            # them in the identity map and a new row reusing a freed id then
            # collided with the ghost (SQLite reuses ids)
            gone = [k for k in have if k not in want]
            for k in gone:
                session.delete(have.pop(k))
            session.flush()
            added = changed = 0
            for k, it in want.items():
                row = have.get(k)
                if row is None:
                    session.add(ValueListItem(list_id=int(list_id), key=k, label=it.get("label"),
                                              sort_order=int(it.get("sort_order") or 0), attrs=it.get("attrs")))
                    added += 1
                else:
                    # a CHANGE is a new label or attrs; a new position is not
                    if (row.label, row.attrs) != (it.get("label"), it.get("attrs")):
                        changed += 1
                    row.label, row.sort_order, row.attrs = it.get("label"), int(it.get("sort_order") or 0), it.get("attrs")
            v.value_count = len(want)
            v.values_version = int(v.values_version or 0) + 1
            v.last_synced_at = datetime.now(timezone.utc)
            v.last_status = "ok"
            v.last_error = None
            v.last_sync_summary = {"at": v.last_synced_at.isoformat(), "by": by, "values": len(want),
                                   "added": added, "changed": changed, "removed": len(gone),
                                   "seconds": seconds}
            session.flush()
            return v.to_dict()

    def list_value_list_items(self, list_id: int, *, search: Optional[str] = None,
                              keys: Optional[set] = None, limit: int = 500,
                              offset: int = 0) -> List[Dict[str, Any]]:
        """The stored values, in list order; ``search`` = "contains" on key OR
        label (case-insensitive); ``keys`` = only these (the viewer's
        entitlement; an EMPTY set = none)."""
        from sqlalchemy import func, or_
        if keys is not None and not keys:
            return []
        with self.get_session(read_only=True) as session:
            q = session.query(ValueListItem).filter(ValueListItem.list_id == int(list_id))
            if search:
                like = f"%{search.lower()}%"
                q = q.filter(or_(func.lower(ValueListItem.key).like(like),
                                 func.lower(ValueListItem.label).like(like)))
            if keys is not None:
                q = q.filter(ValueListItem.key.in_([str(k) for k in keys]))
            rows = q.order_by(ValueListItem.sort_order, ValueListItem.key).offset(int(offset)).limit(int(limit)).all()
            return [{"key": r.key, "label": r.label} for r in rows]
