"""
Oracle Database connector.
Uses python-oracledb (thin mode — no Oracle Client installation required).

Required config keys:
  host        – Oracle DB host
  port        – int, default 1521
  service_name – Oracle service name (preferred) OR
  sid         – Oracle SID (legacy)
  user        – DB username
  password    – DB password
  dsn         – full DSN string (overrides host/port/service_name if set)

Optional:
  wallet_location – path to Oracle wallet (for mTLS / Autonomous DB)
  wallet_password – wallet password
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector, DriverNotInstalled

logger = logging.getLogger(__name__)


class OracleConnector(SqlConnector):
    """Connector for Oracle Database (via python-oracledb thin mode)."""

    #: 2026-09-16 — declared reusable after an audit of what an instance
    #: holds between calls.  ``_conn`` (the oracledb connection) is the only
    #: instance state; ``_cursor()`` returns a NEW cursor per call and keeps
    #: none; there is no ALTER SESSION, no temp table, no retained
    #: transaction.  The base's ``_qs_execution_id`` is the one per-caller
    #: field, and ``reset_for_reuse`` below clears it.
    #:
    #: Oracle is the first connector to opt in because it is the one this
    #: deployment leans on and the one whose connection setup costs most.
    #: The other five stay at the inherited ``POOL_SAFE = False`` until
    #: someone reads them the same way — unknown is unsafe.
    POOL_SAFE = True

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    def reset_for_reuse(self) -> None:
        """Clear per-caller state, then roll back.

        Reads do not open a transaction in oracledb, so the rollback is
        normally a no-op — which is the point: it costs nothing and it
        means a connector that somehow DID leave one open cannot hand it to
        the next caller.  A rollback that fails is a broken connection, so
        it propagates and the pool discards this instance rather than
        pooling it.
        """
        super().reset_for_reuse()
        if self._conn is not None:
            self._conn.rollback()

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            return self._conn
        try:
            import oracledb
        except ImportError:
            raise DriverNotInstalled(
                "oracledb",
                "python-oracledb is not installed. "
                "Run: pip install oracledb  then restart the backend."
            )

        oracledb.defaults.fetch_lobs = False  # return LOBs as strings/bytes directly

        user     = self.config["user"]
        password = self.config["password"]
        dsn      = self.config.get("dsn")

        if not dsn:
            host         = self.config["host"]
            port         = int(self.config.get("port", 1521))
            service_name = self.config.get("service_name")
            sid          = self.config.get("sid")
            if service_name:
                dsn = oracledb.makedsn(host, port, service_name=service_name)
            elif sid:
                dsn = oracledb.makedsn(host, port, sid=sid)
            else:
                raise ValueError("Oracle config must include 'service_name', 'sid', or 'dsn'.")

        connect_kwargs: Dict[str, Any] = dict(user=user, password=password, dsn=dsn)

        wallet_loc = self.config.get("wallet_location")
        if wallet_loc:
            connect_kwargs["wallet_location"] = wallet_loc
            wallet_pw = self.config.get("wallet_password")
            if wallet_pw:
                connect_kwargs["wallet_password"] = wallet_pw

        self._conn = oracledb.connect(**connect_kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    def _fetchall_as_dicts(self, cursor) -> List[Dict]:
        """Rows as dicts -- EMPTY for a statement that returns none.

        2026-09-17 (FB-1).  ``cursor.description`` is ``None`` after a
        statement that produces no result set (ALTER, DDL, a CALL), so this
        raised ``DPY-1003: the executed statement does not return rows`` --
        at the FETCH, AFTER Oracle had already run it.  The product then
        reported failure for something that had SUCCEEDED, which is the
        mirror of the usual defect and just as misleading: a user re-runs a
        statement that already took effect.

        The guard already existed two lines below, at the caller
        (``... if cur.description else []``).  The right check at the wrong
        site -- same shape as the driver mapping and the row-limit guard
        found the same week.

        This only became reachable once the row-limit guard stopped wrapping
        such statements in ``SELECT * FROM (...) WHERE ROWNUM``; before that
        they failed earlier, in Oracle, for a different reason.
        """
        if cursor.description is None:
            return []
        cols = [d[0].lower() for d in cursor.description]
        return [dict(zip(cols, row)) for row in cursor.fetchall()]

    @staticmethod
    def _column_type_name(driver_type: Any) -> str:
        """Render a cursor-description type as a TYPE NAME, not a repr.

        2026-09-15 -- both description readers did ``str(d[1])``, and
        ``str()`` of an ``oracledb.DbType`` is its repr:
        ``"<DbType DB_TYPE_NUMBER>"``.  That string is what the connector
        contract calls ``"type": str``, so it travelled intact into
        ``/api/datasets/preview``'s ``column_types`` and onto the wizard's
        column list -- an Oracle column whose type read
        ``<DbType DB_TYPE_NUMBER>``.  The driver already carries the name;
        use it, and drop the driver's ``DB_TYPE_`` prefix so the value reads
        as a type (``NUMBER``, ``VARCHAR``, ``TIMESTAMP``).  One helper for
        both readers, so the two cannot drift.
        """
        name = getattr(driver_type, "name", None)
        if not name:
            return str(driver_type)
        name = str(name)
        prefix = "DB_TYPE_"
        return name[len(prefix):] if name.startswith(prefix) else name

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        try:
            cur = self._cursor()
            cur.execute("SELECT 1 FROM DUAL")
            cur.fetchone()
            cur.execute("SELECT * FROM v$version WHERE ROWNUM = 1")
            row = cur.fetchone()
            version = row[0] if row else "unknown"
            return {
                "success": True,
                "message": f"Connected to Oracle: {version}",
                "details": {"version": version, "host": self.config.get("host")},
            }
        except Exception as e:
            logger.exception("Oracle test_connection failed")
            return self._test_failure(e)

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "oracle_connector", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        """Oracle has no catalog concept — return the current schema owner."""
        cur = self._cursor()
        cur.execute("SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') FROM DUAL")
        row = cur.fetchone()
        return [row[0]] if row else []

    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._cursor()
        cur.execute(
            "SELECT DISTINCT OWNER FROM ALL_TABLES ORDER BY OWNER"
        )
        return [r[0] for r in cur.fetchall()]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(
            "SELECT TABLE_NAME, 'TABLE' AS TABLE_TYPE FROM ALL_TABLES WHERE OWNER = :owner "
            "UNION ALL "
            "SELECT VIEW_NAME, 'VIEW' FROM ALL_VIEWS WHERE OWNER = :owner "
            "ORDER BY 1",
            owner=schema.upper(),
        )
        return [
            {"name": r[0], "type": r[1], "catalog": catalog, "schema": schema}
            for r in cur.fetchall()
        ]

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(
            "SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, COLUMN_ID "
            "FROM ALL_TAB_COLUMNS "
            "WHERE OWNER = :owner AND TABLE_NAME = :tname "
            "ORDER BY COLUMN_ID",
            owner=schema.upper(), tname=table.upper(),
        )
        return [
            {
                "name": r[0],
                "type": r[1],
                "nullable": r[2] == "Y",
                "ordinal": r[3],
            }
            for r in cur.fetchall()
        ]

    # ── Partition detection ──────────────────────────────────────────────────

    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Detect partition key columns via ALL_PART_KEY_COLUMNS.

        2026-08-20 -- this connector had NO override, so the base default []
        was returned for EVERY table: indistinguishable from
        "unpartitioned", so no partition filter was ever offered and every
        query against a partitioned Oracle table was a candidate full scan.
        One bound query answers it.  Bind variables, matching the posture of
        every other browse query in this file -- identifiers here are data,
        never interpolated.
        """
        try:
            cur = self._cursor()
            cur.execute(
                "SELECT k.COLUMN_NAME, tc.DATA_TYPE, pt.PARTITIONING_TYPE "
                "FROM ALL_PART_KEY_COLUMNS k "
                "JOIN ALL_PART_TABLES pt "
                "  ON pt.OWNER = k.OWNER AND pt.TABLE_NAME = k.NAME "
                "LEFT JOIN ALL_TAB_COLUMNS tc "
                "  ON tc.OWNER = k.OWNER AND tc.TABLE_NAME = k.NAME "
                " AND tc.COLUMN_NAME = k.COLUMN_NAME "
                # OBJECT_TYPE is 'TABLE' but CHAR-padded on some versions
                "WHERE k.OWNER = :owner AND k.NAME = :tname "
                "  AND TRIM(k.OBJECT_TYPE) = 'TABLE' "
                "ORDER BY k.COLUMN_POSITION",
                owner=schema.upper(), tname=table.upper(),
            )
            return [
                {
                    "name": r[0],
                    "type": str(r[1]) if r[1] else "string",
                    "transform": str(r[2]).lower() if r[2] else "identity",
                }
                for r in cur.fetchall()
            ]
        except Exception:
            # WARNING, not DEBUG: [] means both "not partitioned" and
            # "could not find out", and the second silently disables
            # partition prompting so queries full-scan.
            logger.warning(
                "detect_partitions failed for %s.%s.%s -- treating as "
                "unpartitioned, so no partition filter will be offered",
                catalog, schema, table, exc_info=True)
            return []

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        # Oracle uses FETCH FIRST n ROWS ONLY (12c+) or ROWNUM for older versions
        # 2026-08-19 -- 0 MEANS UNLIMITED, everywhere in this product.  This
        # branch tested `limit is not None`, so an explicit "no restriction"
        # became `WHERE ROWNUM <= 0`, i.e. ZERO ROWS reported as a successful
        # empty result.  Oracle bypasses connectors.base._apply_limit (it has
        # no LIMIT keyword), which is why the 2026-08-17 sweep of that helper
        # never reached it.
        if limit is not None and int(limit) > 0:
            stripped = sql.strip().rstrip(";")
            upper = stripped.upper()
            # 2026-08-20 -- "FETCH NEXT" ADDED.  query_compiler emits
            # OFFSET m ROWS FETCH NEXT n ROWS ONLY for Oracle, and the
            # duckdb->oracle transpile preserves that spelling -- so this
            # guard never recognised the window this product actually
            # generates, and re-wrapped an already-limited query in a
            # SECOND, undisclosed ROWNUM cap.  Every other engine uses the
            # shared anchored regex in connectors/base.py; this was a bare
            # substring test against one of the two ANSI spellings.
            # 2026-08-20 (second pass) -- USE THE SHARED DETECTOR.
            # The earlier fix today added "FETCH NEXT" to the substring
            # tests, which was an improvement and still the wrong mechanism:
            # a bare `"ROWNUM" in upper` matches inside a STRING LITERAL, so
            # `WHERE note = 'we use ROWNUM here'` made this believe a window
            # was already present and skip the cap entirely -- an unbounded
            # result reported as the capped answer.
            from core.connectors.base import (
                sql_declares_row_window, sql_takes_row_limit,
            )
            # 2026-09-17 -- SAME predicate the shared _apply_limit asks.
            # Oracle deliberately bypasses that helper (its window is a
            # ROWNUM wrap, not a trailing clause), so a guard added only
            # there would leave this path wrapping DDL and DML in
            # ``SELECT * FROM (CREATE TABLE ...)``.  Building the right
            # tool and wiring it into one caller is the defect this file's
            # own history keeps recording.
            if (sql_takes_row_limit(stripped)
                    and not sql_declares_row_window(stripped, include_rownum=True)):
                stripped = (
                    f"SELECT * FROM ({stripped}) WHERE ROWNUM <= {int(limit)}"
                )
            sql = stripped

        cur = self._cursor()
        cur.execute(sql)
        rows = self._fetchall_as_dicts(cur)
        cols = [{"name": d[0].lower(), "type": self._column_type_name(d[1])}
                 for d in cur.description] if cur.description else []
        return {"columns": cols, "rows": rows, "total_rows": len(rows)}

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Phase 139 (Tier 2.1) — cursor streaming via cx_Oracle fetchmany.

        BF-262 follow-up: ``cancel_event`` watchdog calls
        ``connection.cancel()`` (oracledb / cx_Oracle).  Oracle's per-cursor
        cancel is `cursor.close()` but the running query keeps going; the
        connection-level cancel actually aborts the in-flight statement.
        """
        import threading as _th
        # 0 means unlimited -- see execute_query above.
        if limit is not None and int(limit) > 0:
            stripped = sql.strip().rstrip(";")
            upper = stripped.upper()
            # 2026-08-20 -- "FETCH NEXT" ADDED.  query_compiler emits
            # OFFSET m ROWS FETCH NEXT n ROWS ONLY for Oracle, and the
            # duckdb->oracle transpile preserves that spelling -- so this
            # guard never recognised the window this product actually
            # generates, and re-wrapped an already-limited query in a
            # SECOND, undisclosed ROWNUM cap.  Every other engine uses the
            # shared anchored regex in connectors/base.py; this was a bare
            # substring test against one of the two ANSI spellings.
            # 2026-08-20 (second pass) -- USE THE SHARED DETECTOR.
            # The earlier fix today added "FETCH NEXT" to the substring
            # tests, which was an improvement and still the wrong mechanism:
            # a bare `"ROWNUM" in upper` matches inside a STRING LITERAL, so
            # `WHERE note = 'we use ROWNUM here'` made this believe a window
            # was already present and skip the cap entirely -- an unbounded
            # result reported as the capped answer.
            from core.connectors.base import (
                sql_declares_row_window, sql_takes_row_limit,
            )
            # 2026-09-17 -- SAME predicate the shared _apply_limit asks.
            # Oracle deliberately bypasses that helper (its window is a
            # ROWNUM wrap, not a trailing clause), so a guard added only
            # there would leave this path wrapping DDL and DML in
            # ``SELECT * FROM (CREATE TABLE ...)``.  Building the right
            # tool and wiring it into one caller is the defect this file's
            # own history keeps recording.
            if (sql_takes_row_limit(stripped)
                    and not sql_declares_row_window(stripped, include_rownum=True)):
                stripped = f"SELECT * FROM ({stripped}) WHERE ROWNUM <= {int(limit)}"
            sql = stripped

        cur = self._cursor()
        # 2026-09-26 (F6) -- ONE ROUND TRIP PER CHUNK.  Measured live
        # (oracledb 26.0.1 thin, Oracle Free 23): the driver's defaults are
        # arraysize=100 / prefetchrows=2, so every fetchmany(1000) was TEN
        # round trips to the database, and a 6M-row drain took 2x the time
        # of the same drain with the cursor sized to the chunk.  Streaming
        # itself was never in doubt (first chunk at 0.05-0.09 s, RSS +10 MB
        # flat, whatever the row count) -- this is throughput, not a buffer.
        # prefetchrows is arraysize + 1 on the driver's own advice: the
        # extra row lets the driver see end-of-result without one more
        # trip.  Both must be set BEFORE execute() -- prefetch happens
        # during it.  Memory bound stays (chunk + 1) rows.
        _rows_per_trip = max(1, int(chunk_size))
        cur.arraysize = _rows_per_trip
        cur.prefetchrows = _rows_per_trip + 1
        _stop = _th.Event()
        if cancel_event is not None:
            def _wd():
                while not _stop.is_set():
                    if cancel_event.is_set():
                        # 2026-10-26 -- what the cancel reached is RECORDED
                        # on the run (core/cancel_scope.py::note_cancel).
                        # Only the CONNECTION's cancel() stops the statement
                        # in the database; a cursor close does not.
                        from core.cancel_scope import note_cancel
                        try:
                            # cx_Oracle / oracledb expose cancel() on the connection
                            conn = getattr(cur, "connection", None)
                            if conn and hasattr(conn, "cancel"):
                                conn.cancel()
                                note_cancel(cancel_event, "oracle", reached=True,
                                            detail="the in-flight statement was cancelled "
                                                   "on the connection")
                            else:
                                cur.close()
                                note_cancel(cancel_event, "oracle", reached=False,
                                            detail="the driver has no connection.cancel(); "
                                                   "the cursor was closed and the statement "
                                                   "may still be running in the database")
                        except Exception as _wd_exc:  # noqa: BLE001
                            note_cancel(cancel_event, "oracle", reached=False,
                                        detail=f"the cancel raised: {_wd_exc}")
                        return
                    _stop.wait(0.5)
            _th.Thread(target=_wd, name="qs-oracle-cancel", daemon=True).start()
        _drained = False
        try:
            cur.execute(sql)
            cols = (
                [{"name": d[0].lower(), "type": self._column_type_name(d[1])}
                 for d in cur.description]
                if cur.description else []
            )
            col_names = [c["name"] for c in cols]
            yielded_any = False
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    break
                batch = cur.fetchmany(chunk_size)
                if not batch:
                    break
                yielded_any = True
                # Oracle fetchmany returns tuples — convert to dict-of-cols
                yield cols, [dict(zip(col_names, row)) for row in batch]
            if not yielded_any:
                yield cols, []
            _drained = True
        finally:
            # 2026-08-21 — CANCEL AT THE SOURCE ON ANY EARLY EXIT.
            #
            # Oracle has no per-cursor cancel: cur.close() leaves the statement
            # running server-side, and the connection-level cancel() is what
            # actually aborts it (see the watchdog above).  _stop.set() killed
            # that watchdog before it could act, so a consumer that stopped
            # reading — user cancel, a write-side failure, GeneratorExit on GC —
            # left the statement burning a session on the database.
            if not _drained:
                try:
                    _conn = getattr(cur, "connection", None)
                    if _conn is not None and hasattr(_conn, "cancel"):
                        _conn.cancel()
                        logger.info("Oracle: result set abandoned before "
                                    "completion — cancelled the in-flight "
                                    "statement on the connection")
                except Exception as _cxl:
                    logger.debug("Oracle cancel on abandon failed: %s", _cxl)
            _stop.set()
            try:
                cur.close()
            except Exception:
                pass
