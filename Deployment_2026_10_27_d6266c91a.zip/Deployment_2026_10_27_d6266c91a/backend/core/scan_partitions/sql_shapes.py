"""SQL shape analysis + rewrites for the partition-scan planner.

ONE parse per plan.  ``analyze_split_shape`` parses the base statement
exactly once (memoised on ``(sql, column, dialect)``) and hands back a
:class:`SplitShape` that owns the tree; every bucket rewrite then COPIES
that tree instead of re-parsing.  This is deliberate: a sqlglot parse
inside a per-bucket loop is precisely the shape that cost this codebase
530 ms/query on 2026-08-22.  ``tests/test_progressive_partition_scan_
2026_09_05.py::TestLatency`` measures it and fails if a 200-bucket plan
parses more than once.

The rewrites are AST-only.  There is no ``SELECT * FROM (base) WHERE ...``
wrap fallback for bucket execution, for the reason ETL learned on
2026-07-03: a wrap forces Trino to materialise every projected column of
every row of the inner query before the outer WHERE runs, which OOMs
workers on exactly the tables partitioning exists to survive.  A shape
the AST cannot address is REFUSED (see ``refusals.py``), not wrapped.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, List, Optional, Sequence, Tuple

from core.scan_partitions.refusals import (
    AggregateNotSplittable, ColumnNotAddressable, Refusal, ShapeNotSplittable,
)

logger = logging.getLogger(__name__)

#: Aggregates whose partial results cannot be re-merged across buckets.
#: Recorded in the plan even when the split is safe (grouping key covers
#: the partition column, so nothing is ever re-merged) -- the operator
#: reading the artifact should be able to see WHY it was safe.
NON_DECOMPOSABLE_AGGREGATES = (
    "AVG", "MEDIAN", "MODE", "STDDEV", "STDDEV_POP", "STDDEV_SAMP",
    "VARIANCE", "VAR_POP", "VAR_SAMP", "PERCENTILE", "PERCENTILE_CONT",
    "PERCENTILE_DISC", "APPROX_DISTINCT", "APPROX_PERCENTILE",
    "ARRAY_AGG", "STRING_AGG", "GROUP_CONCAT", "LISTAGG", "CORR",
    "COVAR_POP", "COVAR_SAMP",
)

_SEMI_RE = re.compile(r";\s*$")


def strip_trailing_semicolon(sql: str) -> str:
    return _SEMI_RE.sub("", (sql or "").strip())


def _exp():
    from sqlglot import expressions as exp
    return exp


# -- sqlglot arg-name compatibility -----------------------------------
#
# sqlglot 30.x renamed the Select arg keys ``from`` -> ``from_`` and
# ``with`` -> ``with_``.  Reading the old spelling returns None, which is
# indistinguishable from "this statement has no FROM" -- and a discovery
# probe built from a None FROM renders as ``SELECT col AS qs_pv WHERE ...``,
# a syntactically plausible statement that asks the engine a DIFFERENT
# question.  Exactly the 2026-08-19 lesson (a dependency bump inverting a
# predicate) in a new place, so the accessor is version-tolerant AND
# ``build_discovery_sql`` re-checks that the FROM actually survived.

def sel_key(node, name: str) -> str:
    """The key ``node``'s class actually declares for logical arg ``name``."""
    types = getattr(node, "arg_types", None) or {}
    if name in types:
        return name
    alt = name + "_"
    if alt in types:
        return alt
    return name


def sel_arg(node, name: str):
    args = getattr(node, "args", None) or {}
    if name in args:
        return args[name]
    return args.get(name + "_")


def sel_set(node, name: str, value) -> None:
    node.set(sel_key(node, name), value)


# -- column identity --------------------------------------------------


def split_qualified(name: str) -> Tuple[str, str]:
    """``"FACT.SAP_ID"`` -> ``("fact", "sap_id")``; bare -> ``("", name)``.

    Case is folded for COMPARISON only; the original spelling is what
    gets rendered back into SQL, so a case-sensitive engine still sees
    exactly what the author wrote.
    """
    raw = (name or "").strip()
    if not raw:
        return "", ""
    parts = [p.strip('"').strip("`").strip("[]") for p in raw.split(".")]
    if len(parts) == 1:
        return "", parts[0].lower()
    return parts[-2].lower(), parts[-1].lower()


def split_columns(spec: Any) -> List[str]:
    """A partition key as its columns, in order (2026-10-14: the owner --
    "it can have multiple columns").  ``spec`` is one name, a
    comma-separated list, or a list/tuple of names."""
    if spec is None:
        return []
    if isinstance(spec, (list, tuple)):
        parts = [str(c) for c in spec]
    else:
        parts = str(spec).split(",")
    return [c.strip() for c in parts if c and c.strip()]


def column_spec(spec: Any) -> str:
    """The ONE spelling of a partition key: ``"A"`` or ``"A, B"`` -- what the
    plan records, fingerprints and memoises (a list is not hashable)."""
    return ", ".join(split_columns(spec))


@lru_cache(maxsize=512)
def _column_template(qualified: str):
    """The Column node for a partition column -- built ONCE per name.

    ``exp.to_column`` routes through ``maybe_parse``.  Called per
    discovered value (dedup renders a predicate for every one of them)
    that is one sqlglot parse per VALUE, which on a 400-value discovery
    is 400 parses before a single row is read.  Memoised here; every
    consumer copies before mutating.
    """
    exp = _exp()
    q = (qualified or "").strip()
    if not q:
        return exp.Column(this=exp.to_identifier(""))
    try:
        return exp.to_column(q)
    except Exception:
        tbl, col = split_qualified(q)
        if tbl:
            return exp.Column(this=exp.to_identifier(col),
                              table=exp.to_identifier(tbl))
        return exp.Column(this=exp.to_identifier(col))


def column_expr(qualified: str):
    """A sqlglot Column node that renders N-part names correctly.

    ``exp.Column(this=exp.to_identifier("T.C"))`` emits ``"T.C"`` as ONE
    identifier and every engine answers "Column not resolved" -- the ETL
    base hit this and fixed it the same way.

    Returns a COPY, so a caller that reparents the node cannot corrupt
    the memoised template every other caller shares.
    """
    return _column_template(qualified).copy()


def _node_matches_column(node, want_qual: str, want_name: str) -> bool:
    exp = _exp()
    if isinstance(node, exp.Alias):
        node = node.this
    if not isinstance(node, exp.Column):
        return False
    name = (node.name or "").lower()
    if name != want_name:
        return False
    qual = (node.table or "").lower()
    # An unqualified reference on either side matches: the engine
    # resolves it, and we only need to know it is THE SAME column.
    if want_qual and qual and want_qual != qual:
        return False
    return True


def _literal_for(value: Any):
    """A sqlglot literal for a discovered partition value.

    Numbers stay numbers (a numeric column compared against a STRING
    literal matches nothing on Trino and returns a cheerful 200 with zero
    rows -- the 2026-08-19 ``'007'`` defect); everything else is rendered
    through sqlglot's string builder, which escapes.
    """
    exp = _exp()
    import datetime as _dt
    import decimal as _dec
    if value is None:
        return exp.Null()
    if isinstance(value, bool):
        return exp.Boolean(this=value)
    if isinstance(value, (int, _dec.Decimal)):
        return exp.Literal.number(str(value))
    if isinstance(value, float):
        return exp.Literal.number(repr(value))
    # 2026-10-27 -- a DATE / TIMESTAMP value is a TYPED literal (CAST('...' AS
    # DATE), rendered per dialect by sqlglot): as a plain string it made
    # ``date_col IN ('2026-09-01', ...)``, which Trino / Starburst refuse --
    # "Cannot apply operator: date = varchar(10)" -- found live on the
    # 2M x 600 feed partitioned by a date column (the owner's business date
    # is the obvious key).  DuckDB casts the string silently, which is why
    # the S3 road never showed it (the same class as 2026-08-13's filter fix).
    if isinstance(value, _dt.datetime):
        return exp.cast(exp.Literal.string(value.isoformat(sep=" ")), exp.DataType.Type.TIMESTAMP)
    if isinstance(value, _dt.date):
        return exp.cast(exp.Literal.string(value.isoformat()), exp.DataType.Type.DATE)
    if isinstance(value, (bytes, bytearray)):
        return exp.Literal.string(bytes(value).decode("utf-8", "replace"))
    return exp.Literal.string(str(value))


def paren_if_loose(node):
    """Parenthesise a node whose TOP LEVEL binds looser than an ``AND``.

    sqlglot renders the tree it is handed; it does not re-derive
    precedence.  So ``And(this=<Or>, expression=p)`` comes back out as
    ``a OR b AND p``, which SQL reads as ``a OR (b AND p)`` -- the left
    operand ESCAPES the AND entirely.

    Measured on DuckDB 1.5.2, 2026-09-05, base
    ``SELECT id, amt, p FROM t WHERE amt > 2 OR flag = 'x'`` over 6 rows:

        whole query            6 rows, SUM(amt) =  66
        3 buckets, unparen'd  14 rows, SUM(amt) = 192
        3 buckets, parenthesised 6 rows, SUM(amt) = 66

    Every ``amt > 2`` row was returned by EVERY bucket.  No engine errors
    on it, and no row-count gate reads it as a loss -- it is a GAIN, and
    the gates that could see it (G2/G3) run at the END of the build,
    after ``on_part_complete`` has already served the duplicated rows.

    ``exp.Connector`` is And / Or / Xor.  AND does not strictly need the
    parentheses (it is associative) and XOR does (MySQL binds XOR looser
    than AND); wrapping every connector is ONE rule instead of three,
    and a redundant paren changes no answer.
    """
    exp = _exp()
    if isinstance(node, exp.Connector):
        return exp.Paren(this=node)
    return node


def _tuple_match(cols, values):
    """``c1 = v1 AND c2 IS NULL AND ...`` -- one composite value, exactly."""
    exp = _exp()
    node = None
    for c, v in zip(cols, values):
        p = (exp.Is(this=c.copy(), expression=exp.Null()) if v is None
             else exp.EQ(this=c.copy(), expression=_literal_for(v)))
        node = p if node is None else exp.And(this=node, expression=p)
    return node


def build_composite_predicate(cols, values):
    """A bucket of COMPOSITE values on several columns (2026-10-14).

    Tuples without a NULL: ``(c1, c2) IN ((v1, v2), ...)``.  A tuple holding a
    NULL can never match a row-value IN (NULL = NULL is unknown), so each is
    its own ``c1 = v1 AND c2 IS NULL`` -- a NULL is a VALUE, never a skip.
    An empty bucket selects NOTHING."""
    exp = _exp()
    members = [tuple(v) for v in values]
    if not members:
        return exp.EQ(this=exp.Literal.number(1), expression=exp.Literal.number(0))
    plain = [m for m in members if all(x is not None for x in m)]
    nulled = [m for m in members if any(x is None for x in m)]
    parts = []
    if len(plain) == 1:
        parts.append(_tuple_match(cols, plain[0]))
    elif plain:
        parts.append(exp.In(
            this=exp.Tuple(expressions=[c.copy() for c in cols]),
            expressions=[exp.Tuple(expressions=[_literal_for(x) for x in m]) for m in plain]))
    parts += [_tuple_match(cols, m) for m in nulled]
    node = None
    for p in parts:
        p = exp.Paren(this=p) if len(parts) > 1 else p
        node = p if node is None else exp.Or(this=node, expression=p)
    return node


def build_predicate(col, value):
    """``col = v`` / ``col IS NULL`` / ``col IN (...)`` / ``IN (...) OR IS NULL``.

    NULL is a VALUE here, never a skip: a discovered NULL partition
    dropped from the plan is silent row loss.  ``col`` may be a LIST of
    columns (a composite key): then ``value`` is one tuple or a list of
    tuples (``build_composite_predicate``).
    """
    exp = _exp()
    if isinstance(col, (list, tuple)):
        if isinstance(value, tuple) and len(value) == len(col) and not any(
                isinstance(x, tuple) for x in value):
            return _tuple_match(col, value)
        return build_composite_predicate(col, list(value))
    if not isinstance(value, (list, tuple, set, frozenset)):
        if value is None:
            return exp.Is(this=col.copy(), expression=exp.Null())
        return exp.EQ(this=col.copy(), expression=_literal_for(value))
    members = list(value)
    if not members:
        # Defensive: an empty bucket must select NOTHING, never everything.
        return exp.EQ(this=exp.Literal.number(1),
                      expression=exp.Literal.number(0))
    if len(members) == 1:
        return build_predicate(col, members[0])
    non_nulls = [v for v in members if v is not None]
    has_null = len(non_nulls) != len(members)
    if not non_nulls:
        return exp.Is(this=col.copy(), expression=exp.Null())
    in_expr = exp.In(this=col.copy(),
                     expressions=[_literal_for(v) for v in non_nulls])
    if not has_null:
        return in_expr
    return exp.Or(this=in_expr,
                  expression=exp.Is(this=col.copy(), expression=exp.Null()))


# -- shape analysis ---------------------------------------------------


@dataclass
class SplitShape:
    """What splitting this statement on this column would mean.

    ``refusal`` is None when the split is exact.  ``tree`` is SHARED
    (memoised) -- copy before mutating.
    """
    sql: str
    column: str
    dialect: str
    tree: Any = None
    refusal: Optional[Refusal] = None
    refusal_class: Optional[type] = None
    #: Set when the base aggregates/dedupes, so a discovery COUNT over
    #: FROM/JOIN/WHERE counts SOURCE rows, not OUTPUT rows.  Those counts
    #: size buckets; they can never gate completeness.
    shape_affecting_clause: Optional[str] = None
    group_keys: List[str] = field(default_factory=list)
    non_decomposable: List[str] = field(default_factory=list)
    #: Why the split is exact, in words, for the plan artifact.
    exactness_reason: str = ""

    @property
    def ok(self) -> bool:
        return self.refusal is None

    #: Built once, copied per bucket.  ``exp.to_column`` parses.
    _col_expr: Any = None

    @property
    def counts_are_output_rows(self) -> bool:
        return self.shape_affecting_clause is None

    @property
    def columns(self) -> List[str]:
        return split_columns(self.column)

    def cached_column_expr(self):
        """One Column node -- or, for a composite key, the list of them."""
        if self._col_expr is None:
            cols = self.columns
            self._col_expr = (_column_template(cols[0]) if len(cols) <= 1
                              else [_column_template(c) for c in cols])
        return self._col_expr

    def raise_refusal(self) -> None:
        if self.refusal is not None:
            raise (self.refusal_class or ShapeNotSplittable)(self.refusal)


def _collect_scope_qualifiers(tree) -> set:
    exp = _exp()
    out = set()
    with_ = sel_arg(tree, "with")
    if with_ is not None:
        for cte in with_.expressions:
            alias = cte.args.get("alias")
            if alias is not None and getattr(alias, "this", None) is not None:
                out.add(str(alias.this.name or "").lower())
    sources = []
    frm = sel_arg(tree, "from")
    if frm is not None:
        sources.append(frm.this if hasattr(frm, "this") else frm)
    for j in (tree.args.get("joins") or []):
        sources.append(j.this)
    for src in sources:
        if src is None:
            continue
        alias = src.args.get("alias") if hasattr(src, "args") else None
        aliased = False
        if alias is not None:
            nm = (alias.this.name
                  if getattr(alias, "this", None) is not None else alias.name)
            if nm:
                out.add(str(nm).lower())
                aliased = True
        # An ALIASED table hides its own name: after ``FROM fact ft``, the
        # handle is ``ft`` and ``fact.col`` does not resolve on Trino,
        # Snowflake or Oracle.  Adding the table name here anyway would
        # make the scope check pass and the engine fail at runtime -- or,
        # on a lenient engine, bind to something else entirely.
        if isinstance(src, exp.Table) and not aliased:
            if src.name:
                out.add(str(src.name).lower())
    return {q for q in out if q}


def _grouping_modifiers(grp) -> List[Any]:
    """Every ROLLUP / CUBE / GROUPING SETS node of a GROUP BY, whichever
    layout the installed sqlglot uses.

    sqlglot <= 30.17 parks them in ``Group.args["rollup" | "cube" |
    "grouping_sets"]``; 30.19 moved them into ``Group.expressions`` next to
    the plain keys.  requirements.txt allows both (``<31``).  Reading only
    the old slots made 30.19 see NO modifier: every such statement was
    refused under the wrong code and the proven-exact GROUPING SETS split
    became unreachable (measured 2026-09-25 in the CI image).  It refused
    rather than mis-split, but one reader for both layouts is the fix."""
    if grp is None:
        return []
    exp = _exp()
    mods: List[Any] = []
    for key in ("rollup", "cube", "grouping_sets"):
        mods.extend(grp.args.get(key) or [])
    mods.extend(g for g in (grp.expressions or [])
                if isinstance(g, (exp.Rollup, exp.Cube, exp.GroupingSets)))
    return mods


def _group_key_expressions(tree) -> List[Any]:
    """GROUP BY members, with positional ordinals resolved to the
    projection they name (``GROUP BY 1`` is the first select item).
    ROLLUP / CUBE / GROUPING SETS are modifiers, not keys -- they are read
    by ``_grouping_modifiers`` on every sqlglot layout."""
    exp = _exp()
    grp = tree.args.get("group")
    if grp is None:
        return []
    out = []
    projections = list(tree.expressions or [])
    for g in (grp.expressions or []):
        if isinstance(g, (exp.Rollup, exp.Cube, exp.GroupingSets)):
            continue
        if isinstance(g, exp.Literal) and g.is_int:
            idx = int(g.this) - 1
            if 0 <= idx < len(projections):
                out.append(projections[idx])
                continue
        out.append(g)
    return out


def _top_level_nodes(tree):
    """Projection + HAVING/QUALIFY nodes -- the expressions whose value is
    computed over the OUTPUT row set.  Anything under a derived table or
    CTE is computed over ITS OWN rows and is unaffected by a predicate
    injected at the outermost level (no engine pushes a filter through a
    window or an aggregate), so it is deliberately not walked."""
    nodes = list(tree.expressions or [])
    for key in ("having", "qualify"):
        node = tree.args.get(key)
        if node is not None:
            nodes.append(node)
    return nodes


def _find_windows(nodes) -> List[Any]:
    exp = _exp()
    out = []
    for n in nodes:
        out.extend(list(n.find_all(exp.Window)))
    return out


def _find_aggregates(nodes) -> List[Any]:
    exp = _exp()
    out = []
    for n in nodes:
        for agg in n.find_all(exp.AggFunc):
            # An aggregate inside a window (``SUM(x) OVER (...)``) is a
            # window problem, judged separately.
            if agg.find_ancestor(exp.Window) is not None:
                continue
            out.append(agg)
    return out


def _agg_name(agg) -> str:
    """``AVG`` / ``COUNT(DISTINCT)`` / ``SUM``...

    sqlglot spells DISTINCT inside an aggregate two ways depending on the
    function and the version -- an ``args["distinct"]`` flag, or a nested
    ``exp.Distinct`` as the argument.  Reading only the flag reports
    ``COUNT(DISTINCT id)`` as a plain ``COUNT``, i.e. as DECOMPOSABLE,
    which is the opposite of true.
    """
    exp = _exp()
    try:
        name = str(agg.sql_name()).upper()
    except Exception:
        name = type(agg).__name__.upper()
    distinct = bool(agg.args.get("distinct")) or isinstance(
        agg.this, exp.Distinct)
    if distinct:
        return f"{name}(DISTINCT)"
    return name


#: sqlglot dialects consulted when asking "what KIND of function is this
#: name?".  A name is Anonymous under one dialect and typed under another
#: far more often than not -- ``cardinality`` is ``ArraySize`` on trino and
#: Anonymous on duckdb; ``trunc`` is ``Trunc`` everywhere EXCEPT oracle;
#: ``format_datetime`` is ``TimeToStr`` only on bigquery.  Asking ONE
#: dialect and calling the answer "unclassifiable" is what made the
#: ungrouped-function refusal fire on ordinary flat projections.
_KIND_PROBE_DIALECTS = (
    None, "duckdb", "trino", "presto", "athena", "oracle", "snowflake",
    "databricks", "spark", "hive", "postgres", "bigquery", "mysql",
    "redshift", "tsql",
)

#: Argument shapes tried for the probe.  Several builders are arity- or
#: type-sensitive (bigquery's FORMAT_DATETIME wants two, trino's ELEMENT_AT
#: an integer), and a builder that raises falls back to Anonymous -- which
#: would read as "unknown" for a function sqlglot models perfectly well.
_KIND_PROBE_ARGS = ("x", "x, 'y'", "x, 1", "x, 'y', 'z'")

#: Names that AGGREGATE on at least one engine QueryStudio speaks and that
#: sqlglot 30.17 models on NO dialect -- so the probe below cannot see them
#: and they would fall through as merely "unknown".
#:
#: THIS LIST IS THE FAIL-CLOSED HALF and over-inclusion is nearly free: a
#: scalar listed here costs a lost split (the query still runs, whole,
#: because both call sites pass ``on_refusal="declare"``), while an
#: aggregate MISSING from here costs a WRONG ANSWER -- N rows of partial
#: aggregates where the statement returns one.  Measured on DuckDB 1.5.2:
#: ``SELECT product(v) FROM t`` is one row whole and three rows over three
#: buckets, and none of the three is the answer.
_KNOWN_AGGREGATE_NAMES = frozenset({
    # duckdb
    "product", "geomean", "fsum", "kahan_sum", "sum_no_overflow",
    "reservoir_quantile", "approx_quantile", "quantile_cont",
    "quantile_disc", "bitstring_agg", "arg_min", "arg_max", "arg_min_null",
    "arg_max_null", "favorite", "mad", "list", "histogram", "entropy",
    "count_star", "bit_and", "bit_or", "bit_xor", "bool_and", "bool_or",
    # trino / starburst
    "geometric_mean", "checksum", "numeric_histogram", "qdigest_agg",
    "tdigest_agg", "approx_set", "approx_most_frequent", "merge",
    "merge_set_digest", "map_agg", "map_union", "map_union_sum",
    "multimap_agg", "set_agg", "set_union", "reduce_agg", "every",
    "bitwise_and_agg", "bitwise_or_agg", "bitwise_xor_agg",
    "classification_miss_rate", "classification_fall_out",
    "regression_error", "learn_classifier", "learn_regressor",
    "convex_hull_agg", "geometry_union_agg",
    # snowflake
    "hll", "hll_accumulate", "hll_combine", "hll_estimate", "hll_export",
    "hll_import", "approx_top_k", "approx_top_k_accumulate",
    "approx_top_k_combine", "approx_percentile_accumulate",
    "approx_percentile_combine", "bitand_agg", "bitor_agg", "bitxor_agg",
    "booland_agg", "boolor_agg", "boolxor_agg", "object_agg",
    "array_union_agg", "array_unique_agg", "minhash", "minhash_combine",
    "regr_valx", "regr_valy", "kurtosis", "skew",
    # oracle
    "collect", "stats_mode", "xmlagg", "sys_xmlagg", "json_arrayagg",
    "json_objectagg", "approx_median", "approx_count_distinct_detail",
    "approx_count_distinct_agg", "approx_rank", "approx_sum",
    "group_id", "grouping", "grouping_id", "listagg", "median",
    # databricks / spark
    "collect_list", "collect_set", "percentile_approx", "percentile",
    "histogram_numeric", "hll_sketch_agg", "hll_union_agg",
    "try_sum", "try_avg", "any_value", "count_if", "count_min_sketch",
    "regr_avgx", "regr_avgy", "regr_count", "regr_r2", "regr_sxx",
    "regr_sxy", "regr_syy", "regr_slope", "regr_intercept",
    "std", "some", "bool_or_agg", "bitmap_construct_agg",
    "bitmap_or_agg", "max_by", "min_by", "arbitrary",
})

#: Names that are per-row SCALARS on at least one engine QueryStudio speaks,
#: are an aggregate on NONE of them, and that sqlglot models on no dialect
#: -- so the probe reports "unknown" and the fail-closed rule would refuse
#: an ordinary flat projection.
#:
#: THIS LIST IS THE FAIL-OPEN HALF, so it is short and every entry is a
#: function whose per-row-ness is a documented property of the engine, not
#: an inference from its name.  A name belongs here ONLY if no engine
#: QueryStudio speaks has an AGGREGATE of that name; when in doubt it goes
#: nowhere and "unknown" keeps its refusal.
_KNOWN_SCALAR_NAMES = frozenset({
    # hashes / fingerprints -- one value per input row on every engine
    "xxhash64", "xxhash32", "murmur3", "murmur3_x64_128", "crc32", "hash",
    "farm_fingerprint", "spooky_hash_v2_32", "spooky_hash_v2_64",
    "md5_number_lower64", "md5_number_upper64", "sha2", "shiftleft",
    "shiftright", "shiftrightunsigned",
    # spark / databricks per-row helpers
    "conv", "sentences", "bin", "hex", "unhex", "base64", "unbase64",
    "raise_error", "assert_true", "bit_get", "getbit", "java_method",
    "mask", "monotonically_increasing_id", "input_file_name",
    "schema_of_json", "schema_of_csv", "from_csv", "to_csv",
    "xpath_string", "xpath_int", "xpath_double", "xpath_boolean",
    # oracle per-row helpers
    "sys_context", "sys_guid", "userenv", "ora_hash", "standard_hash",
    "nls_lower", "nls_upper", "nls_initcap", "vsize", "dump",
    "regexp_substr", "regexp_instr", "regexp_count", "to_number",
    "to_binary_double", "to_binary_float", "to_yminterval",
    "to_dsinterval", "numtoyminterval", "numtodsinterval",
    "sessiontimezone", "dbtimezone",
    # trino / starburst per-row helpers
    "word_stem", "normalize", "codepoint", "from_base", "to_base",
    "to_iso8601", "from_iso8601_timestamp", "from_iso8601_date",
    "human_readable_seconds", "parse_duration", "url_extract_host",
    "url_extract_path", "url_extract_query", "url_extract_protocol",
    "url_extract_port", "url_extract_fragment", "url_extract_parameter",
    "url_encode", "url_decode", "at_timezone", "with_timezone",
    "typeof", "is_finite", "is_infinite", "is_nan", "infinity", "nan",
    "beta_cdf", "inverse_beta_cdf", "normal_cdf", "inverse_normal_cdf",
    "wilson_interval_lower", "wilson_interval_upper", "cosine_similarity",
    "st_point", "st_x", "st_y", "st_distance", "st_contains",
    # duckdb per-row helpers
    "list_value", "list_extract", "list_transform", "list_filter",
    "list_sort", "list_distinct", "list_concat", "list_position",
    "struct_pack", "struct_extract", "map_extract", "union_extract",
    "epoch_ms", "epoch_us", "epoch_ns", "make_timestamp", "make_date",
    "strftime", "strptime", "printf",
})


@lru_cache(maxsize=2048)
def _sqlglot_function_kind(name: str) -> str:
    """``"aggregate"`` / ``"scalar"`` / ``"unknown"`` for a function NAME,
    asked of sqlglot itself across every dialect it ships.

    ``exp.Anonymous`` means "THIS dialect's parser has no class for this
    name", which is a far weaker statement than "nobody knows what this
    is".  Re-asking under the other dialects turns most of the Anonymous
    surface into a definite answer, and a definite SCALAR answer is what
    lets an ordinary flat projection split instead of being refused.

    Aggregate wins over scalar when the dialects disagree: a name that
    aggregates ANYWHERE is treated as an aggregate everywhere, which
    over-refuses (safe) rather than over-splits (a wrong answer).

    Memoised on the name -- the probe is ~7 ms and would otherwise run per
    projection per plan, which is the 530 ms/query shape this module's
    header exists to prevent.
    """
    exp = _exp()
    import sqlglot as _sg

    agg = scalar = False
    for dialect in _KIND_PROBE_DIALECTS:
        for args in _KIND_PROBE_ARGS:
            try:
                tree = _sg.parse_one(
                    f"SELECT {name}({args}) AS _z FROM _t", read=dialect)
            except Exception:
                continue
            try:
                node = tree.expressions[0].this
            except Exception:            # pragma: no cover - defensive
                continue
            if isinstance(node, exp.Anonymous):
                continue
            if isinstance(node, exp.AggFunc):
                agg = True
            elif isinstance(node, (exp.Func, exp.Bracket)):
                scalar = True
    if agg:
        return "aggregate"
    return "scalar" if scalar else "unknown"


def _anonymous_function_kind(name: str) -> str:
    """What an ``Anonymous`` call NAME is, in three answers.

    Order is the safety order.  A name in the declared aggregate
    vocabulary, or one sqlglot models as an aggregate under ANY dialect, is
    an AGGREGATE.  Only then may a name be called SCALAR -- by sqlglot on
    some dialect, or by the declared scalar vocabulary.  Anything else
    stays ``"unknown"`` and keeps the refusal it has always had.

    Both vocabularies are DECLARED rather than inferred, for the reason
    ``core/filter_ops.py`` records: an unrecognised spelling and a
    deliberate refusal are indistinguishable to a caller unless the
    knowledge is written down.
    """
    key = (name or "").strip().lower()
    if not key:
        return "unknown"
    probe = _sqlglot_function_kind(key)
    if probe == "aggregate" or key in _KNOWN_AGGREGATE_NAMES:
        return "aggregate"
    if probe == "scalar" or key in _KNOWN_SCALAR_NAMES:
        return "scalar"
    return "unknown"


def _find_unclassifiable_functions(nodes) -> List[Any]:
    """Top-level calls sqlglot models as ``Anonymous`` -- i.e. functions it
    has NO typed class for, so it cannot tell us whether they aggregate.

    ``_find_aggregates`` walks ``exp.AggFunc`` and therefore sees only the
    aggregates sqlglot HAS a class for.  A UDAF, or a real engine
    aggregate sqlglot does not model, parses as ``exp.Anonymous`` and
    slips past ``ungrouped_aggregate`` -- measured on DuckDB 1.5.2,
    2026-09-05::

        SELECT product(v) AS total FROM t   whole: [(24.0,)]  ONE row
                                            3 buckets: 2.0 / 3.0 / 4.0

    Unknown must not read as "not an aggregate": that is the permissive
    answer to a cannot-tell, which is the exact fail-open this repo has
    been burned by.  ``checksum``, ``geometric_mean``, ``histogram`` and
    every ``my_udaf`` land here too.
    """
    exp = _exp()
    out = []
    for n in nodes:
        for fn in n.find_all(exp.Anonymous):
            if fn.find_ancestor(exp.Window) is not None:
                continue
            out.append(fn)
    return out


def _has_per_row_column_ref(nodes) -> bool:
    """True when a projection references a column OUTSIDE any aggregate
    candidate -- the evidence that the statement is per-row rather than
    collapsed to one row.

    An ungrouped aggregate returns ONE row, and on every engine
    QueryStudio speaks (Trino, Snowflake, Oracle, DuckDB) it is an ERROR
    for a bare column to sit beside an aggregate with no GROUP BY.  So a
    column reference outside the unclassifiable call is proof that
    whatever that function is, this statement emits a row per source row
    and the buckets are a disjoint cover.  ``SELECT id, cardinality(tags)``
    qualifies (``id`` is bare); ``SELECT product(v)`` does not (``v``
    lives inside the unclassifiable call).

    Measured, not assumed: under the ``duckdb`` dialect ``cardinality``,
    ``element_at``, ``sequence``, ``from_unixtime`` and ``format_datetime``
    are all ``Anonymous``.  Refusing every Anonymous outright would refuse
    a large slice of ordinary flat projections, which is why the posture
    is "unknown function AND no per-row evidence", not "unknown function".

    Deliberately NOT a rule about MySQL with ``ONLY_FULL_GROUP_BY`` off,
    which does allow the illegal shape and returns one row.  MySQL is not
    a QueryStudio source type; if it becomes one, revisit this.
    """
    exp = _exp()
    for n in nodes:
        for col in n.find_all(exp.Column):
            if col.find_ancestor(exp.AggFunc) is not None:
                continue
            if col.find_ancestor(exp.Anonymous) is not None:
                continue
            if col.find_ancestor(exp.Window) is not None:
                continue
            return True
    return False


def _grouping_set_members(node) -> List[Any]:
    exp = _exp()
    if isinstance(node, exp.Tuple):
        return list(node.expressions or [])
    if isinstance(node, exp.Paren):
        return [node.this] if node.this is not None else []
    return [node]


def _grouping_modifiers_cover(grp, base_covered: bool, want_qual: str,
                              want_name: str) -> Tuple[bool, str, str]:
    """Does the partition column appear in EVERY grouping set the GROUP BY
    generates?

    ``_group_key_expressions`` reads only ``Group.args["expressions"]``.
    ``GROUP BY p, x WITH ROLLUP`` parses as ``expressions=[p, x]`` PLUS a
    BARE ``Rollup()`` -- so ``p`` looks covered while the modifier quietly
    generates the ``(p)`` and ``()`` grouping sets, and the ``()`` grand
    total aggregates every row in the table.  Proven on DuckDB with the
    equivalent ``GROUPING SETS ((p,x),(p),())``: the whole query gives one
    ``(NULL, NULL, 15)`` row; two buckets give ``(NULL, NULL, 3)`` and
    ``(NULL, NULL, 12)`` -- two rows, neither of them the answer.

    Rules, each measured against sqlglot 30.17:
      * a BARE ``Rollup()`` / ``Cube()`` (the ``WITH ROLLUP`` / ``WITH
        CUBE`` form) erodes the base key list down to ``()`` -> never
        covered.
      * ``ROLLUP(x)`` / ``CUBE(x)`` WITH arguments keeps the whole base
        list in every generated set -> covered iff the base list covers.
      * ``GROUPING SETS (...)`` -> covered iff the base list covers, or
        every listed set names the column.

    Returns ``(covered, which_modifier, via)``.  ``which_modifier`` is
    empty when the GROUP BY is a plain key list and this check has no
    opinion; ``via`` is ``"grouping_sets"`` when the YES was earned by
    every listed grouping set naming the column, and empty otherwise.

    ``via`` EXISTS SO THE POSITIVE ANSWER CAN BE ACTED ON.  Until
    2026-09-05 round 2 it could not be: ``_group_key_expressions`` reads
    only ``Group.args["expressions"]``, which is EMPTY for
    ``GROUP BY GROUPING SETS (...)``, so a statement this function
    approved fell straight into the ungrouped-aggregate refusal one branch
    later and was declined anyway.  A verdict the code cannot act on is
    not a verdict; the caller now uses this flag to take the covered path.
    """
    exp = _exp()
    mods = _grouping_modifiers(grp)
    if not mods:
        return True, "", ""
    for m in mods:
        if isinstance(m, (exp.Rollup, exp.Cube)) and not (m.expressions or []):
            return False, ("WITH ROLLUP" if isinstance(m, exp.Rollup)
                           else "WITH CUBE"), ""
    if base_covered:
        return True, "", ""
    names = " + ".join(sorted({type(m).__name__.upper() for m in mods}))
    gsets = [m for m in mods if isinstance(m, exp.GroupingSets)]
    if len(gsets) != len(mods) or not gsets:
        return False, names, ""
    for gs in gsets:
        for st in (gs.expressions or []):
            if not any(_node_matches_column(m, want_qual, want_name)
                       for m in _grouping_set_members(st)):
                return False, "GROUPING SETS", ""
    return True, "", "grouping_sets"


#: Functions whose value is re-drawn on every evaluation.
_NONDETERMINISTIC_FUNCS = ("Rand", "Randn", "Uuid")


def _nondeterminism_refusal(tree):
    """``(code, detail, remedy)`` when the statement's answer is re-drawn
    on each evaluation, else None.

    Measured 2026-09-05 on DuckDB: ``WHERE random() < 0.3`` over the same
    table gave ~63 rows whole, ~60 bucketed, ~58 on a second whole run.

    The posture, decided deliberately: the single-stream answer is not
    reproducible either, so "it differs between runs" is NOT by itself
    the reason to refuse.  The reason is that a single stream is at least
    ONE evaluation of the statement the author wrote, whereas a bucketed
    run is N INDEPENDENT draws whose union is not a partition of any one
    of them -- rows the base evaluation would have returned are missing,
    rows it would not are present, and the completeness ledger cannot
    tell that apart from a lost bucket.  Refusing costs latency; accepting
    costs the answer, and correctness beats latency here.
    """
    exp = _exp()
    for _ in tree.find_all(exp.TableSample):
        return ("nondeterministic_sample",
                "the statement TABLESAMPLEs its source. Each bucket is a "
                "separate evaluation and draws its OWN sample, so the union "
                "of the buckets is not a sample of the base query -- and the "
                "row count moves on every run, which leaves the completeness "
                "gates unable to tell a correct build from a lost bucket.",
                "materialise the sample once and partition the result, or "
                "run the query whole.")
    for node in tree.find_all(exp.Func):
        if type(node).__name__ in _NONDETERMINISTIC_FUNCS:
            return ("nondeterministic_function",
                    f"the statement calls {type(node).__name__.upper()}(), "
                    f"whose value is re-drawn on every evaluation. N buckets "
                    f"are N evaluations, so their union is not a partition of "
                    f"any single evaluation of the base query: it can both "
                    f"miss rows the whole query would have returned and "
                    f"include rows it would not.",
                    "materialise the randomised result once and partition "
                    "that, or run the query whole.")
    for holder in (list(tree.find_all(exp.Subquery))
                   + list(tree.find_all(exp.CTE))):
        inner = holder.this
        if not isinstance(inner, exp.Select):
            continue
        if (inner.args.get("limit") is None
                and inner.args.get("offset") is None):
            continue
        if inner.args.get("order") is not None:
            # The author expressed an order, so WHICH n rows come back is
            # their statement's answer rather than the engine's whim.
            # Ties inside that order remain the author's to make total.
            continue
        return ("nondeterministic_inner_limit",
                "a derived table / CTE applies LIMIT or OFFSET with no ORDER "
                "BY, so which rows it yields is the engine's choice and that "
                "choice is re-made on every evaluation. Each bucket "
                "re-evaluates it, so the buckets can both miss rows the whole "
                "query returned and return rows it did not.",
                "add an ORDER BY to the inner LIMIT (so which rows it yields "
                "is defined), materialise it, or run the query whole.")
    return None


def _is_non_decomposable(agg) -> bool:
    name = _agg_name(agg)
    if "DISTINCT" in name:
        return True
    base = name.split("(")[0]
    return base in NON_DECOMPOSABLE_AGGREGATES


@lru_cache(maxsize=256)
def analyze_split_shape(sql: str, column: str,
                        dialect: str = "trino") -> SplitShape:
    """Decide whether the statement splits exactly on ``column`` -- one name
    or a composite key (``"A, B"`` / a list).  A composite key splits exactly
    iff EVERY column does on its own: then every column is projected under
    DISTINCT, inside every GROUP BY and every window's PARTITION BY, so no
    group or frame spans two buckets (2026-10-14)."""
    spec = column_spec(column)
    cols = split_columns(spec)
    if len(cols) <= 1:
        return _analyze_one_column(sql, cols[0] if cols else "", dialect)
    first = None
    for c in cols:
        one = _analyze_one_column(sql, c, dialect)
        if not one.ok:
            return SplitShape(sql=sql, column=spec, dialect=dialect, tree=one.tree,
                              refusal=one.refusal, refusal_class=one.refusal_class)
        first = first or one
    return SplitShape(
        sql=sql, column=spec, dialect=dialect, tree=first.tree,
        shape_affecting_clause=first.shape_affecting_clause,
        group_keys=list(first.group_keys), non_decomposable=list(first.non_decomposable),
        exactness_reason=(f"every column of the key ({spec}) splits exactly on its own"
                          + (f": {first.exactness_reason}" if first.exactness_reason else "")))


@lru_cache(maxsize=256)
def _analyze_one_column(sql: str, column: str,
                        dialect: str = "trino") -> SplitShape:
    """Decide -- ONCE per (sql, column, dialect) -- whether

        rows(base) == UNION ALL over buckets of rows(base WHERE col IN b)

    holds exactly, and say why not when it does not.

    Memoised because the planner asks the same question the executor and
    the ledger later ask, and because a per-bucket re-parse is the known
    latency regression in this repo.  The returned object holds a SHARED
    tree -- every rewrite copies it.
    """
    shape = SplitShape(sql=sql, column=column, dialect=dialect)
    want_qual, want_name = split_qualified(column)
    if not want_name:
        shape.refusal = Refusal(
            "no_partition_column", "(none)",
            "no partition column was declared, so there is nothing to split on.",
            "declare partition_config.column on the view / dataset.")
        shape.refusal_class = ColumnNotAddressable
        return shape

    try:
        import sqlglot
        exp = sqlglot.expressions
        tree = sqlglot.parse_one(strip_trailing_semicolon(sql), dialect=dialect)
    except Exception as exc:
        shape.refusal = Refusal(
            "unparseable", column,
            f"the base statement could not be parsed as {dialect}: {exc}. "
            f"Splitting requires rewriting the statement's WHERE clause, and "
            f"a statement that cannot be parsed cannot be rewritten.",
            "run it whole, or simplify the statement until it parses.")
        shape.refusal_class = ShapeNotSplittable
        return shape

    shape.tree = tree

    def _refuse(cls, code, detail, remedy):
        shape.refusal = Refusal(code, column, detail, remedy)
        shape.refusal_class = cls
        return shape

    if isinstance(tree, (exp.Union, exp.Intersect, exp.Except)):
        return _refuse(
            ShapeNotSplittable, "set_operation",
            "the statement's top level is a set operation. UNION dedupes "
            "across ALL branches and INTERSECT/EXCEPT are defined over the "
            "complete row sets, so a per-bucket rewrite is not the same "
            "query -- it can both drop and duplicate rows.",
            "materialise the set operation first (or UNION ALL into a view) "
            "and partition the result.")
    if not isinstance(tree, exp.Select):
        return _refuse(
            ShapeNotSplittable, "not_a_select",
            f"the statement's top level is {type(tree).__name__}, not a "
            f"SELECT; there is no outer WHERE to inject a bucket predicate "
            f"into.",
            "wrap the statement in a plain outer SELECT, or run it whole.")

    for key, code in (("limit", "top_level_limit"),
                      ("offset", "top_level_offset")):
        if tree.args.get(key) is not None:
            return _refuse(
                ShapeNotSplittable, code,
                f"the statement has a top-level {key.upper()}. That clause is "
                f"defined over the WHOLE result: N buckets each honouring it "
                f"return up to N times as many rows, and no engine reports an "
                f"error for it.",
                "remove the clause and cap rows at the read side (the bulk "
                "row cap / row_limit), which applies once to the merged set.")
    # UNREACHABLE ON THE INSTALLED PARSER, DELIBERATELY KEPT.
    # sqlglot 30.17 normalises ``FETCH FIRST n ROWS ONLY`` into ``limit``,
    # so the branch above always wins and this one never fires -- verified
    # by execution 2026-09-05.  It is a compatibility NET against a parser
    # that gives FETCH its own arg (a downgrade, or a dialect that keeps
    # the distinction), because falling through would mean a per-bucket
    # LIMIT.  Counted as DECLARED, not as coverage: a guard that cannot
    # fire is not one of this module's working refusals and must not be
    # advertised as one -- a count that overstates coverage is worse than
    # no count.  ``TestDeclaredButUnreachable`` pins both halves: FETCH is
    # still caught (as ``top_level_limit``), and this branch is marked.
    if sel_arg(tree, "fetch") is not None:
        return _refuse(
            ShapeNotSplittable, "top_level_fetch",
            "the statement has a top-level FETCH FIRST n ROWS, which is a "
            "LIMIT: applied per bucket it returns n rows PER BUCKET.",
            "remove it and cap rows at the read side.")
    if tree.args.get("order") is not None:
        return _refuse(
            ShapeNotSplittable, "top_level_order_by",
            "the statement has a top-level ORDER BY. Buckets complete out of "
            "order and are appended to the artifact as they land, so the "
            "served row order would be the completion order, not the "
            "requested one. Page 1 would not be the first rows.",
            "drop the ORDER BY (progressive delivery is unordered by "
            "construction), or sort at the read side.")

    nd = _nondeterminism_refusal(tree)
    if nd is not None:
        return _refuse(ShapeNotSplittable, nd[0], nd[1], nd[2])

    scope = _collect_scope_qualifiers(tree)
    if want_qual and scope and want_qual not in scope:
        return _refuse(
            ColumnNotAddressable, "qualifier_not_in_scope",
            f"the qualifier {want_qual!r} is not among the handles the "
            f"outermost FROM/JOIN exposes ({sorted(scope)}) -- most likely the "
            f"table is aliased. A predicate on a qualifier that is not in "
            f"scope does not resolve.",
            "qualify the column with an alias that IS in scope, or drop the "
            "qualifier.")

    # A QUALIFIED column (``FACT_TETB.SAP_COMPANY_CODE``) always names the
    # table's column -- SQL never resolves a qualified name to a select
    # alias -- so a same-named alias is no ambiguity (2026-10-14: the owner's
    # fact_tetb query aliases ``CAST(FACT_TETB.SAP_COMPANY_CODE AS VARCHAR)
    # AS "SAP_COMPANY_CODE"`` and the qualified source column was refused).
    # A BARE name keeps the refusal: it is the ambiguous case.
    for proj in (tree.expressions or []) if not want_qual else []:
        if isinstance(proj, exp.Alias) and (proj.alias or "").lower() == want_name:
            if not isinstance(proj.this, exp.Column):
                return _refuse(
                    ColumnNotAddressable, "computed_alias",
                    f"{column!r} is an alias of a computed expression "
                    f"({proj.this.sql(dialect=dialect)[:80]}). SQL forbids "
                    f"referencing a select alias from WHERE, so the bucket "
                    f"predicate would not resolve -- or would silently bind "
                    f"to a DIFFERENT column of the same name.",
                    "partition on the underlying source column instead of "
                    "the computed alias.")

    top_nodes = _top_level_nodes(tree)
    windows = _find_windows(top_nodes)
    if windows:
        uncovered = []
        for w in windows:
            pby = w.args.get("partition_by") or []
            if not any(_node_matches_column(p, want_qual, want_name)
                       for p in pby):
                uncovered.append(w.sql(dialect=dialect)[:80])
        if uncovered:
            return _refuse(
                AggregateNotSplittable, "window_not_partitioned",
                f"{len(uncovered)} top-level window function(s) are computed "
                f"over a frame that is not confined to one bucket "
                f"(e.g. {uncovered[0]}). ROW_NUMBER / RANK / running SUM "
                f"restart inside every bucket, so the numbers are per-bucket, "
                f"not per-result -- a wrong answer under a 200.",
                f"add {column} to each window's PARTITION BY, or run the "
                f"query whole.")

    group_keys = _group_key_expressions(tree)
    aggregates = _find_aggregates(top_nodes)
    shape.non_decomposable = sorted({_agg_name(a) for a in aggregates
                                     if _is_non_decomposable(a)})

    grp_node = tree.args.get("group")
    gsets_cover = False
    if grp_node is not None:
        base_covered = any(_node_matches_column(g, want_qual, want_name)
                           for g in group_keys)
        mods_ok, which, via = _grouping_modifiers_cover(
            grp_node, base_covered, want_qual, want_name)
        gsets_cover = mods_ok and via == "grouping_sets"
        if not mods_ok:
            return _refuse(
                AggregateNotSplittable, "grouping_set_spans_buckets",
                f"the GROUP BY carries a {which} modifier, which generates "
                f"grouping sets that do NOT include {column!r} -- the "
                f"grand-total set aggregates EVERY row, so that one output "
                f"row spans every bucket. Split into N buckets it becomes N "
                f"partial grand totals, each one wrong, and the plain key "
                f"list looks covered so nothing else notices.",
                f"drop the {which} (aggregate the totals at the read side), "
                f"or run the query whole.")

    if group_keys:
        shape.group_keys = [g.sql(dialect=dialect) for g in group_keys]
        covered = any(_node_matches_column(g, want_qual, want_name)
                      for g in group_keys)
        if not covered:
            names = sorted({_agg_name(a) for a in aggregates}) or ["(none)"]
            return _refuse(
                AggregateNotSplittable, "group_by_not_covered",
                f"the statement groups by {shape.group_keys} which does NOT "
                f"include {column!r}, so a single group's rows are spread "
                f"across buckets. Correct per-bucket execution would need "
                f"partial-aggregate re-merge; SUM/COUNT/MIN/MAX decompose but "
                f"{', '.join(names)} include(s) forms that do not, and "
                f"QueryStudio does not implement re-merge for any of them.",
                f"add {column} to the GROUP BY (then no group spans a "
                f"bucket), partition on a column that IS in the grouping key, "
                f"or run the query whole.")
        shape.shape_affecting_clause = "GROUP BY"
        shape.exactness_reason = (
            f"the grouping key includes {column!r}, so every group's rows "
            f"share one partition value and no group spans a bucket. Nothing "
            f"is re-merged across buckets, which is why the non-decomposable "
            f"aggregate(s) {shape.non_decomposable or ['(none)']} are still "
            f"exact here.")
        if tree.args.get("having") is not None:
            shape.exactness_reason += (
                " HAVING filters whole groups, which are likewise "
                "bucket-local; it can only make a bucket EMPTY, never split "
                "a group.")
    elif gsets_cover:
        # ``GROUP BY GROUPING SETS ((p, x), (p))`` with the partition
        # column ``p`` in EVERY listed set.  ``group_keys`` is empty here
        # (sqlglot parks grouping sets outside ``Group.expressions``), so
        # without this branch the statement fell into the
        # ungrouped-aggregate refusal below and was declined even though
        # ``_grouping_modifiers_cover`` had just approved it -- the
        # unreachable positive half, 2026-09-05 round 2.
        #
        # It is genuinely exact: every generated set names ``p``, so every
        # output row -- data row, subtotal, or set duplicate -- carries one
        # partition value and belongs to exactly one bucket.  Nothing is
        # re-merged across buckets, which is why a non-decomposable
        # aggregate is still exact.  Proved by execution against DuckDB in
        # ``TestGroupingSetModifiersAreRead``, not by inspection.
        shape.group_keys = [
            gs.sql(dialect=dialect)
            for gs in _grouping_modifiers(grp_node)
            if isinstance(gs, _exp().GroupingSets)]
        shape.shape_affecting_clause = "GROUP BY"
        shape.exactness_reason = (
            f"every grouping set the GROUP BY generates names {column!r}, so "
            f"every group -- including every subtotal -- is confined to one "
            f"partition value and no group spans a bucket. Nothing is "
            f"re-merged across buckets, which is why the non-decomposable "
            f"aggregate(s) {shape.non_decomposable or ['(none)']} are still "
            f"exact here.")
    elif aggregates:
        return _refuse(
            AggregateNotSplittable, "ungrouped_aggregate",
            f"the statement aggregates over the whole result "
            f"({', '.join(sorted({_agg_name(a) for a in aggregates}))}) with "
            f"no GROUP BY, so it returns ONE row. Split into N buckets it "
            f"returns N rows of partial aggregates.",
            f"add {column} to a GROUP BY if per-partition totals are wanted, "
            f"or run the query whole.")
    else:
        # No GROUP BY and no aggregate sqlglot has a class for.  An
        # ``Anonymous`` call is one THIS DIALECT's parser could not
        # classify -- which is not the same as one nobody can classify.
        #
        # 2026-09-05 round 2.  This branch used to refuse every Anonymous
        # call outright, and the measured cost was ordinary flat SQL:
        # ``SELECT TRUNC(order_date) FROM orders`` (oracle),
        # ``SELECT format_datetime(ts,'yyyy-MM'), format_datetime(ts,'HH')
        # FROM events`` (trino), ``SELECT cardinality(tags) FROM t``
        # (duckdb) and ``SELECT xxhash64(a) FROM t`` (databricks) were all
        # refused -- 11 of 26 sampled trino scalars are Anonymous.  The
        # rule was narrower than its own helper docstring believed: that
        # docstring offers ``SELECT id, cardinality(tags)`` as safe while
        # ``cardinality`` ALONE is exactly what tripped it.
        #
        # THE SAFETY PROPERTY IS UNCHANGED: an ungrouped AGGREGATE returns
        # ONE row and N buckets return N partial results, so a name that
        # aggregates anywhere -- and a name nothing can classify -- still
        # refuses.  What changed is that a name sqlglot models as a SCALAR
        # on some other dialect, or that this module DECLARES a scalar, is
        # no longer called "unclassifiable".  See
        # ``_anonymous_function_kind``.
        unknown_fns = _find_unclassifiable_functions(top_nodes)
        # A top-level WINDOW function is per-row by construction (it emits
        # one row per input row), and any window here has already been
        # checked to be confined to one bucket -- so it is per-row
        # evidence exactly like a bare column is.
        per_row = bool(windows) or _has_per_row_column_ref(top_nodes)
        kinds = {f: _anonymous_function_kind(f.name or "") for f in unknown_fns}
        suspect = [f for f, k in kinds.items() if k != "scalar"]
        if suspect and not per_row:
            agg_names = sorted({(f.name or "?").upper() for f in suspect
                                if kinds[f] == "aggregate"})
            unk_names = sorted({(f.name or "?").upper() for f in suspect
                                if kinds[f] == "unknown"})
            if agg_names and unk_names:
                what = (f"{', '.join(agg_names)} aggregate(s) on at least one "
                        f"engine, and {', '.join(unk_names)} cannot be "
                        f"classified at all")
            elif agg_names:
                what = (f"{', '.join(agg_names)} aggregate(s) on at least one "
                        f"engine QueryStudio speaks")
            else:
                what = (f"no dialect sqlglot ships, and no vocabulary this "
                        f"module declares, can say what "
                        f"{', '.join(unk_names)} do")
            return _refuse(
                AggregateNotSplittable, "unclassifiable_ungrouped_function",
                f"the statement has no GROUP BY and its projection is built "
                f"entirely from function(s) that may collapse it to one row "
                f"-- {what} -- with no bare column reference to prove it "
                f"emits a row per source row. If any of them aggregates -- a "
                f"UDAF, or an aggregate the {dialect} parser does not model "
                f"-- the statement returns ONE row and N buckets return N "
                f"partial results. Unknown is not 'not an aggregate'.",
                f"project a source column alongside it (which proves the "
                f"statement is per-row), add {column} to a GROUP BY if "
                f"per-partition results are wanted, or run the query whole.")

    if tree.args.get("distinct"):
        projected = any(_node_matches_column(p, want_qual, want_name)
                        for p in (tree.expressions or []))
        if not projected:
            return _refuse(
                ShapeNotSplittable, "distinct_without_partition_column",
                f"the statement is SELECT DISTINCT and does not project "
                f"{column!r}. Two buckets can therefore produce the SAME "
                f"output row, and appending them yields duplicates that a "
                f"whole-query DISTINCT would have collapsed.",
                f"project {column} (then buckets are disjoint by "
                f"construction), or run the query whole.")
        shape.shape_affecting_clause = shape.shape_affecting_clause or "DISTINCT"
        shape.exactness_reason = (
            f"{column!r} is projected under DISTINCT, so no output row can "
            f"belong to two buckets and the per-bucket DISTINCTs union "
            f"exactly.")

    if not shape.exactness_reason:
        shape.exactness_reason = (
            "the statement is a flat projection: every output row comes from "
            "exactly one source row, which carries exactly one partition "
            "value, so the buckets are a disjoint cover.")
    return shape


# -- rewrites (copy the shared tree; never re-parse) -------------------


def build_bucket_sql(shape: SplitShape, values: Sequence[Any],
                     order_by: Optional[str] = None) -> str:
    """``base`` + ``AND (col IN (values))`` injected into the OUTERMOST WHERE.

    Only the outermost SELECT is touched: a predicate pushed into a
    correlated subquery or a CTE body would filter an INTERMEDIATE
    computation, which is a different query.  Engines push the outer
    predicate down themselves when it is safe to.

    Deliberately parse-free.  ``Select.where(...)`` and
    ``exp.to_column(...)`` both route through ``maybe_parse``; called once
    per bucket that is ~3 sqlglot parses x N buckets, which is the same
    per-loop-parse shape that cost 530 ms/query here on 2026-08-22.  The
    column node is built ONCE per shape and the Where node is assembled
    by hand, so a 200-bucket plan parses the statement exactly once.
    """
    shape.raise_refusal()
    exp = _exp()
    tree = shape.tree.copy()
    col = shape.cached_column_expr()
    # BOTH operands go through the same guard.  The original code
    # parenthesised only the injected predicate and ANDed it onto an
    # UNPARENTHESISED base WHERE -- so a base whose top level was an OR
    # duplicated its rows into every bucket (see ``paren_if_loose``).
    # Guarding one side and not the other is the "one of two twins"
    # defect this repo keeps re-finding; there is one rule and one call
    # site for it now.
    pred = paren_if_loose(build_predicate(col, list(values)))
    existing = sel_arg(tree, "where")
    if existing is not None and existing.this is not None:
        merged = exp.And(this=paren_if_loose(existing.this), expression=pred)
    else:
        merged = pred
    sel_set(tree, "where", exp.Where(this=merged))
    # 2026-10-14 -- an ORDER BY over ONE bucket (a feed's ``order_within``):
    # each bucket is small and sorted on its own, in parallel, so a file's
    # row order is fixed without the whole-result sort the owner refused.
    # The base itself never carries one (``top_level_order_by`` refuses).
    order_cols = split_columns(order_by)
    if order_cols:
        sel_set(tree, "order", exp.Order(expressions=[
            exp.Ordered(this=column_expr(c), nulls_first=False) for c in order_cols]))
    return tree.sql(dialect=shape.dialect)


def build_discovery_sql(shape: SplitShape, *, with_counts: bool = True,
                        wrap: bool = False) -> str:
    """The distinct-values probe -- WITH THE BASE QUERY'S OWN WHERE CLAUSE.

    That is the operator's instruction verbatim ("you have to get unique
    values for defined partition columns along with where clause") and it
    is what makes discovery both cheap and CORRECT: a value set gathered
    without the base predicate is a superset (extra empty buckets, wasted
    queries), and one gathered from a different table is neither.

    ``wrap=False`` (default) keeps FROM/JOIN/WHERE and DROPS the
    projection, GROUP BY, ORDER BY and DISTINCT -- the engine sees a cheap
    source probe instead of the full transformation.  Its counts are then
    SOURCE-row counts; when the base aggregates, they size buckets and
    never gate completeness (``SplitShape.counts_are_output_rows``).

    ``wrap=True`` counts ``FROM (base) AS qs_base`` -- exact output rows,
    materially more expensive.  Offered because on a shape-affecting base
    it is the only way to get counts that G2/G4 may gate on.
    """
    shape.raise_refusal()
    exp = _exp()
    dialect = shape.dialect
    if len(shape.columns) > 1:
        return _build_composite_discovery_sql(shape, with_counts=with_counts, wrap=wrap)
    _, name = split_qualified(shape.column)

    if wrap:
        inner = shape.tree.copy()
        col = exp.column(exp.to_identifier(name))
        sel = exp.Select().from_(
            exp.Subquery(this=inner, alias=exp.TableAlias(
                this=exp.to_identifier("qs_base"))))
        if with_counts:
            sel.set("expressions", [
                exp.alias_(col.copy(), "qs_pv"),
                exp.alias_(exp.Count(this=exp.Star()), "qs_cnt"),
            ])
            sel.set("group", exp.Group(expressions=[col.copy()]))
        else:
            sel.set("expressions", [exp.alias_(col.copy(), "qs_pv")])
            sel.set("distinct", exp.Distinct())
        return sel.sql(dialect=dialect)

    src = shape.tree.copy()
    probe = exp.Select()
    for key in ("with", "from", "laterals"):
        node = sel_arg(src, key)
        if node is not None:
            sel_set(probe, key, node)
    joins = sel_arg(src, "joins")
    if joins:
        sel_set(probe, "joins", list(joins))
    where = sel_arg(src, "where")
    if where is not None:
        sel_set(probe, "where", where)
    col = column_expr(shape.column)
    if with_counts:
        sel_set(probe, "expressions", [
            exp.alias_(col.copy(), "qs_pv"),
            exp.alias_(exp.Count(this=exp.Star()), "qs_cnt"),
        ])
        sel_set(probe, "group", exp.Group(expressions=[col.copy()]))
    else:
        sel_set(probe, "expressions", [exp.alias_(col.copy(), "qs_pv")])
        sel_set(probe, "distinct", exp.Distinct())

    # The source-scan probe is a HAND-BUILT statement.  If the FROM did
    # not survive the transplant (a sqlglot arg-name change, an exotic
    # root), the probe still RENDERS -- as a different question, whose
    # answer would silently become the partition plan.  Refuse instead.
    if sel_arg(src, "from") is not None and sel_arg(probe, "from") is None:
        raise ShapeNotSplittable(Refusal(
            "discovery_from_lost", shape.column,
            "the source-scan discovery probe lost the base statement's FROM "
            "clause while being built, so it would ask the engine a "
            "different question than the base query answers.",
            "report this: the installed sqlglot's Select arg names are not "
            "the ones core/scan_partitions/sql_shapes.py knows."))
    return probe.sql(dialect=dialect)


def _build_composite_discovery_sql(shape: SplitShape, *, with_counts: bool, wrap: bool) -> str:
    """Discovery for a composite key: ``qs_pv0 .. qs_pv{n-1}`` [+ ``qs_cnt``],
    grouped by every column -- with the base query's own WHERE."""
    exp = _exp()
    names = shape.columns
    if wrap:
        cols = [exp.column(exp.to_identifier(split_qualified(c)[1])) for c in names]
        sel = exp.Select().from_(exp.Subquery(this=shape.tree.copy(), alias=exp.TableAlias(
            this=exp.to_identifier("qs_base"))))
    else:
        src = shape.tree.copy()
        sel = exp.Select()
        for key in ("with", "from", "laterals"):
            node = sel_arg(src, key)
            if node is not None:
                sel_set(sel, key, node)
        joins = sel_arg(src, "joins")
        if joins:
            sel_set(sel, "joins", list(joins))
        where = sel_arg(src, "where")
        if where is not None:
            sel_set(sel, "where", where)
        if sel_arg(src, "from") is not None and sel_arg(sel, "from") is None:
            raise ShapeNotSplittable(Refusal(
                "discovery_from_lost", shape.column,
                "the source-scan discovery probe lost the base statement's FROM clause.",
                "report this: the installed sqlglot's Select arg names changed."))
        cols = [column_expr(c) for c in names]
    proj = [exp.alias_(c.copy(), f"qs_pv{i}") for i, c in enumerate(cols)]
    if with_counts:
        proj.append(exp.alias_(exp.Count(this=exp.Star()), "qs_cnt"))
        sel_set(sel, "expressions", proj)
        sel_set(sel, "group", exp.Group(expressions=[c.copy() for c in cols]))
    else:
        sel_set(sel, "expressions", proj)
        sel_set(sel, "distinct", exp.Distinct())
    return sel.sql(dialect=shape.dialect)


def build_preflight_count_sql(shape: SplitShape) -> str:
    """``SELECT COUNT(*) FROM (base) AS qs_base`` -- G1.

    Deliberately a WRAP: G1 must count the rows the base query ACTUALLY
    emits (post GROUP BY / DISTINCT), because G3 compares it against rows
    written.  A source-side count would be a different number and the
    gate would fire on correct data.
    """
    exp = _exp()
    inner = shape.tree.copy() if shape.tree is not None else None
    if inner is None:
        raise ShapeNotSplittable(Refusal(
            "unparseable", shape.column,
            "no parsed statement is available to wrap for a pre-flight count.",
            "fix the statement so it parses, or disable the pre-flight count."))
    sel = exp.Select().from_(
        exp.Subquery(this=inner, alias=exp.TableAlias(
            this=exp.to_identifier("qs_base"))))
    sel.set("expressions", [exp.alias_(exp.Count(this=exp.Star()), "qs_total")])
    return sel.sql(dialect=shape.dialect)


def predicate_key(column: str, value: Any, dialect: str = "trino") -> str:
    """The rendered predicate for one value -- the dedup identity.

    Two discovered entries that render to the SAME predicate would run
    the SAME query twice and write the same rows twice.  Keying on the
    rendered text (not on the Python value) is what catches
    ``Decimal('1')`` vs ``'1'``.
    """
    try:
        cols = split_columns(column)
        tmpl = (_column_template(cols[0]) if len(cols) <= 1
                else [_column_template(c) for c in cols])
        return build_predicate(tmpl, _dedup_spelling(value)).sql(dialect=dialect)
    except Exception:
        return "\x00id\x00" + repr(value)


def _dedup_spelling(value: Any) -> Any:
    """The spelling a value is DEDUPLICATED by: a date / datetime as its ISO
    text, so a discovered ``datetime(2024, 1, 1)`` and the string
    ``'2024-01-01T00:00:00'`` (two sides spelling one value) stay ONE bucket
    now that the SQL literal itself is typed (``_literal_for``)."""
    import datetime as _dt
    if isinstance(value, (list, tuple)):
        return type(value)(_dedup_spelling(v) for v in value)
    if isinstance(value, (_dt.datetime, _dt.date)):
        return value.isoformat()
    return value


__all__ = [
    "SplitShape", "analyze_split_shape", "build_bucket_sql",
    "build_discovery_sql", "build_preflight_count_sql", "build_predicate",
    "column_expr", "paren_if_loose", "predicate_key", "split_qualified",
    "split_columns", "column_spec", "build_composite_predicate",
    "strip_trailing_semicolon", "NON_DECOMPOSABLE_AGGREGATES",
]
