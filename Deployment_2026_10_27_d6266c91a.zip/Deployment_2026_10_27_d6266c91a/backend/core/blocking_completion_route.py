"""The route that ALWAYS FINISHES a genuinely-too-big BLOCKING export.

WHAT PROBLEM THIS SOLVES
------------------------
Spill admission (``core.spill_admission`` + the stage-2 measured check in
``core.duckdb_subprocess``) can now refuse a blocking plan whose working
set cannot fit memory + spill.  Refusing beats dying at 40 GB — but a
17M-row x 900-column export is a LEGITIMATE request.  This module turns
an enforce-mode refusal into a completion: admission ROUTES here first,
and only when no route applies does the refusal stand.

MEASURED FACTS THIS DESIGN RESTS ON (2026-08-04, DuckDB 1.5.2, 900 cols
x 120k rows, 826 MB decoded, memory_limit=500MB, spill cap 6 GB —
``scripts/measure_blocking_completion_2026_08_04.py``):

  * Single-shot ``ORDER BY`` OOMs in 2.9 s — per-column sort buffers are
    UNSPILLABLE; no spill quota fixes it.
  * DuckDB re-sorting PRE-SORTED runs (``SELECT * FROM
    read_parquet([runs]) ORDER BY k``) OOMs identically in 0.5 s: the
    planner emits a full ``ORDER_BY`` again — DuckDB has no mechanism to
    exploit pre-sortedness, so the k-way merge MUST be orchestrated
    outside DuckDB.  That merge is ``core.sorted_run_merge``.
  * Per-chunk sorted runs (2 files/run, ~275 MB decoded each) at the
    SAME 500 MB limit: complete in 36.5 s.  Python k-way merge of those
    runs: 13.1 s, 9,188 rows/s (~63 MB/s decoded), bounded RSS.
  * Merged output is ROW-FOR-ROW IDENTICAL to the unlimited-memory
    single-shot (row_number-aligned comparison + hash digests).
  * GROUP BY at the same 500 MB limit completes single-shot (DuckDB's
    hash aggregate CAN spill, unlike its sort) — the GROUP BY route
    below exists for the admission-refused case, not because the engine
    always fails.

THE THREE ROUTES (all fail-closed — any doubt returns None and the
refusal stands):

  order_merge  — external merge sort.  Split the island's file list into
                 chunks whose decoded size fits the child's memory limit,
                 run the ORIGINAL query (ORDER BY intact) per chunk into
                 a sorted local run file, then k-way streaming-merge the
                 runs (``core.sorted_run_merge``) into the canonical
                 output.  ORDER BY keys must be plain output columns.
  partial_agg  — REUSES ``core.query_splitter.plan_partial_agg_decomposition``
                 (commit 50dab849; design
                 backend/docs/parallel_agg_next_tier_design_2026_07_26.md):
                 per-chunk partial SQL into run files, then the plan's
                 final SQL over a ``__qs_partials`` view of the runs.
                 The final aggregate's input is per-chunk partials —
                 far smaller than the island — and DuckDB's hash
                 aggregate spills (measured), so the combine is bounded.
                 Plans needing HUGEINT restore markers are refused (that
                 machinery is Arrow-table-based; parquet runs would
                 round-trip HUGEINT to DECIMAL(38,0) — wrong types).
  distinct     — per-chunk DISTINCT runs, then one final
                 ``SELECT DISTINCT`` over the runs (set semantics make
                 per-chunk + global dedup exactly the single-shot rows).

WHAT IS *NOT* ROUTED (refusal stands, honestly): JOINs, window
functions, set operations, CTEs, subqueries, LIMIT/OFFSET (the top-k
path in query_splitter already handles ORDER BY + LIMIT), GROUP BY
combined with ORDER BY the pad planner cannot prove, expression sort
keys, MoR views (multiple read_parquet arrays), sort keys not present
in the output columns.

MODES
-----
``spill_admission.completion_route`` (default **false** — new execution
machinery ships dark; the admission default is ``observe`` anyway, so
nothing routes until an operator turns on BOTH enforce and this flag).

CORRECTNESS POSTURE
-------------------
* The merge lane verifies every run is sorted while consuming it and
  enforces row conservation (runs vs output) — see sorted_run_merge.
* Runs are written by the SAME connection, SAME views, SAME WHERE as the
  single-shot COPY would have used — the chunk file lists are spliced by
  the SAME builder the multi-worker dispatcher uses in production.
* Any failure ANYWHERE cleans up and surfaces — the caller re-raises the
  original SpillRefused; the route never falls through to the lane that
  was measured to die, and never leaves a partial file at output_path
  (tmp + atomic os.replace).
"""
from __future__ import annotations

import logging
import math
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

LOG_TAG = "[completion-route]"

_RUNS_TABLE = "__qs_completion_runs"
_PARTIALS_VIEW = "__qs_partials"          # name plan_partial_agg final_sql uses

# Fraction of the child's memory_limit a chunk's DECODED size may occupy.
# The per-chunk sort needs working space beyond the data itself; 0.4 was
# the measured-safe shape (275 MB decoded sorted fine inside 500 MB).
_DEFAULT_CHUNK_FILL = 0.4
_DEFAULT_MAX_RUNS = 128
_DEFAULT_MERGE_BUDGET_MB = 256


class CompletionRouteError(RuntimeError):
    """The route was applicable but failed mid-flight.  The caller must
    surface the ORIGINAL refusal (chained) — never fall through to the
    execution lane that was refused."""


def _cfg(key: str, default):
    try:
        from core.config import get as _cfg_get
        return _cfg_get("spill_admission", key, default)
    except Exception as exc:                                # pragma: no cover
        logger.debug("%s config read failed for %s: %s", LOG_TAG, key, exc)
        return default


def completion_route_enabled() -> bool:
    """``spill_admission.completion_route`` — default OFF.  This is new
    execution machinery; it ships dark and is enabled per deployment."""
    return bool(_cfg("completion_route", False))


def _max_runs() -> int:
    try:
        v = int(_cfg("completion_max_runs", _DEFAULT_MAX_RUNS))
        return v if v > 1 else _DEFAULT_MAX_RUNS
    except (TypeError, ValueError):
        return _DEFAULT_MAX_RUNS


def _chunk_fill() -> float:
    try:
        v = float(_cfg("completion_chunk_fill", _DEFAULT_CHUNK_FILL))
        return v if 0.05 <= v <= 0.9 else _DEFAULT_CHUNK_FILL
    except (TypeError, ValueError):
        return _DEFAULT_CHUNK_FILL


def _merge_budget_bytes() -> int:
    try:
        v = int(_cfg("completion_merge_budget_mb", _DEFAULT_MERGE_BUDGET_MB))
        return max(32, v) * 1024 * 1024
    except (TypeError, ValueError):
        return _DEFAULT_MERGE_BUDGET_MB * 1024 * 1024


# ── Planning (pure, fail-closed) ─────────────────────────────────────────

@dataclass(frozen=True)
class CompletionPlan:
    route: str                       # "order_merge" | "partial_agg" | "distinct"
    run_sql: str                     # per-chunk SQL (chunk view spliced by setup)
    sort_keys: Tuple[Any, ...] = ()  # SortKeySpec for order_merge
    final_sql: str = ""              # partial_agg only — FROM __qs_partials
    reason: str = ""


def _output_name_set(select, exp) -> Optional[set]:
    """Names available in the run files' schema.  None = star projection
    (every source column present).  Fail-closed: a Star with EXCLUDE /
    REPLACE, or any un-aliased non-column expression, refuses by simply
    not contributing a name (keys must match a KNOWN name)."""
    names: set = set()
    for p in select.expressions:
        if isinstance(p, exp.Star):
            # sqlglot spells the EXCLUDE arg "except" or "except_"
            # depending on version — check both (fail-closed).
            if (p.args.get("except") or p.args.get("except_")
                    or p.args.get("replace") or p.args.get("rename")):
                return set()          # EXCLUDE/REPLACE star — refuse keys
            return None               # plain star: all source columns exist
        if isinstance(p, exp.Alias):
            if p.alias:
                names.add(p.alias)
        elif isinstance(p, exp.Column) and p.name:
            names.add(p.name)
        # non-aliased expressions get DuckDB auto-names — not matchable
    return names


def plan_completion_route(inner_sql: str) -> Optional[CompletionPlan]:
    """Classify the refused query into a completing route, or None.

    PURE — no I/O, no config.  Fail-closed on every unproven shape: a
    None here means the refusal stands, which is today's behaviour.
    """
    if not inner_sql or not str(inner_sql).strip():
        return None
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(inner_sql, read="duckdb")
    except Exception as e:
        logger.debug("%s unparseable SQL — no route: %s", LOG_TAG, e)
        return None

    if not isinstance(tree, exp.Select):
        return None
    select = tree

    # Structural gates — one plain table, no data-reshaping siblings.
    if (select.args.get("with_") or select.args.get("with")) is not None:   # sqlglot >= 30: with_
        return None
    if select.args.get("joins"):
        return None
    if select.args.get("laterals") or select.args.get("pivots"):
        return None
    if select.args.get("qualify") is not None:
        return None
    from_arg = select.args.get("from") or select.args.get("from_")
    if from_arg is None:
        return None
    src = from_arg.this
    if not isinstance(src, exp.Table) or not isinstance(src.this, exp.Identifier):
        return None                    # inline functions / subqueries — refuse
    if src.args.get("joins"):
        return None
    # No window functions, no subqueries anywhere.
    for node in tree.walk():
        if isinstance(node, (exp.Window, exp.Subquery)):
            return None
        if isinstance(node, exp.Select) and node is not select:
            return None
    # The chunk splice happens in the SETUP SQL — an inline read_parquet
    # in the query itself would silently NOT be chunked.  Refuse.
    if "read_parquet" in inner_sql.lower():
        return None

    order = select.args.get("order")
    group = select.args.get("group")
    having = select.args.get("having")
    distinct = select.args.get("distinct")
    limit = select.args.get("limit")
    offset = select.args.get("offset")
    has_agg = any(isinstance(n, exp.AggFunc) for p in select.expressions
                  for n in p.walk())

    # ── GROUP BY / aggregate → reuse the partial-agg decomposition ──────
    # (LIMIT/HAVING/ORDER over aggregates are legal here: the pad plan's
    # final SQL reproduces them AFTER the global combine, which is exactly
    # single-shot semantics.  Its own gates refuse anything unproven.)
    if has_agg or group is not None:
        try:
            from core.query_splitter import (
                plan_partial_agg_decomposition_for_runs,
            )
            pad = plan_partial_agg_decomposition_for_runs(inner_sql)
        except Exception as e:
            logger.debug("%s pad planner unavailable: %s", LOG_TAG, e)
            return None
        if pad is None:
            return None
        if pad.hugeint_restore:
            # Marker-based HUGEINT restore is Arrow-table machinery; our
            # runs are parquet (HUGEINT→DECIMAL(38,0) round trip) — the
            # restored types would diverge from single-shot.  Refuse.
            return None
        return CompletionPlan(
            route="partial_agg", run_sql=pad.partial_sql,
            final_sql=pad.final_sql,
            reason="partial->final aggregate decomposition over chunk runs")

    # Non-aggregate routes below: LIMIT/OFFSET shapes are refused — the
    # exact union-top-k path in query_splitter already owns ORDER+LIMIT.
    if limit is not None or offset is not None:
        return None

    # ── SELECT DISTINCT (row-level) ─────────────────────────────────────
    if distinct is not None:
        if getattr(distinct, "args", {}).get("on"):
            return None                       # DISTINCT ON is order-sensitive
        if order is not None or having is not None:
            return None
        return CompletionPlan(
            route="distinct", run_sql=inner_sql,
            reason="per-chunk DISTINCT runs + final DISTINCT combine")

    # ── Global ORDER BY (no LIMIT) → external merge sort ────────────────
    if order is None or having is not None:
        return None
    out_names = _output_name_set(select, exp)
    if out_names is not None and not out_names:
        return None                           # star EXCLUDE/REPLACE — refuse
    from core.sorted_run_merge import SortKeySpec
    keys: List[SortKeySpec] = []
    for o in order.expressions:
        key = o.this
        name = ""
        if isinstance(key, exp.Column) and key.name:
            name = key.name
        elif isinstance(key, exp.Literal) and not key.args.get("is_string"):
            # ordinal — resolve against EXPLICIT projections only
            if out_names is None:
                return None
            try:
                idx = int(key.name) - 1
            except (TypeError, ValueError):
                return None
            projs = select.expressions
            if idx < 0 or idx >= len(projs):
                return None
            p = projs[idx]
            if isinstance(p, exp.Alias) and p.alias:
                name = p.alias
            elif isinstance(p, exp.Column) and p.name:
                name = p.name
            else:
                return None
        else:
            return None                       # expression keys — refuse (v1)
        if out_names is not None and name not in out_names:
            return None    # key not in the run files' schema — cannot merge
        keys.append(SortKeySpec(
            column=name,
            descending=bool(o.args.get("desc")),
            nulls_first=o.args.get("nulls_first"),
        ))
    if not keys:
        return None
    return CompletionPlan(
        route="order_merge", run_sql=inner_sql, sort_keys=tuple(keys),
        reason="external merge sort: per-chunk sorted runs + k-way "
               "streaming merge")


# ── Chunking ─────────────────────────────────────────────────────────────

@dataclass
class _Chunk:
    files: List[str] = field(default_factory=list)


def _chunk_files(files: Sequence[str], island_bytes: int,
                 memory_limit_bytes: int, expansion: float,
                 fill: float, max_runs: int) -> Optional[List[_Chunk]]:
    """Contiguous file chunks whose DECODED size fits fill x memory_limit.

    Contiguous (not round-robin) on purpose: adjacent files usually share
    partition ranges, so runs overlap less and the merge takes bigger
    zero-copy slices.  Returns None when the shape is not routable
    (unknown sizes, too many runs for one merge pass, or nothing to
    split)."""
    n = len(files)
    if n < 2 or island_bytes <= 0 or memory_limit_bytes <= 0:
        return None
    if expansion <= 0:
        return None
    per_file = max(1, island_bytes // n)
    target = int(memory_limit_bytes * fill)
    fpc = max(1, int(target // int(per_file * expansion)))
    n_runs = math.ceil(n / fpc)
    if n_runs < 2:
        return None            # one chunk == the single-shot that was refused
    if n_runs > max_runs:
        logger.warning(
            "%s island needs %d runs (> completion_max_runs=%d) — route "
            "not applicable (cascade merging not built)", LOG_TAG, n_runs,
            max_runs)
        return None
    return [_Chunk(files=list(files[i:i + fpc])) for i in range(0, n, fpc)]


# ── Execution ────────────────────────────────────────────────────────────

def _exec_statements(con, sql_text: str) -> None:
    """Same statement-splitting contract the child uses for setup_sql."""
    for stmt in sql_text.split(";"):
        stmt = stmt.strip()
        if stmt:
            con.execute(stmt)


def _sql_path(p: str) -> str:
    return p.replace("\\", "/").replace("'", "''")


def execute_completion_route(
    *,
    con,
    setup_sql: str,
    inner_sql: str,
    output_path: str,
    island_bytes: int,
    island_files: int,
    expansion_factor: Optional[float] = None,
    row_group_clause: str = "",
    execution_id: str = "",
    sidecar_register: Optional[Callable[[str], None]] = None,
    temp_files: Optional[list] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Optional[dict]:
    """Execute the refused blocking export via a completing route.

    Returns ``{"route", "runs", "rows", "seconds"}`` on success (the
    canonical single parquet file is at ``output_path``), ``None`` when
    no route applies (caller lets the refusal stand), and raises
    :class:`CompletionRouteError` when a route was applicable but failed
    (caller re-raises the ORIGINAL SpillRefused, chained — never falls
    through to the refused lane).
    """
    def _say(msg: str) -> None:
        if log is not None:
            try:
                log(f"SUBPROCESS: completion-route {msg}")
            except Exception as say_exc:
                logger.debug("%s progress sink failed: %s", LOG_TAG, say_exc)
        logger.info("%s %s", LOG_TAG, msg)

    plan = plan_completion_route(inner_sql)
    if plan is None:
        _say("no route for this shape — refusal stands")
        return None

    # File list + chunk-splice builder: the SAME machinery the
    # multi-worker dispatcher uses in production (grep-master rule — do
    # not re-implement).  Lazy import to avoid module cycles.
    try:
        from core.multi_worker_dispatcher import (
            _extract_file_list,
            _build_chunk_setup_builder,
            _string_literal_ranges,
            _inside_any_range,
            _READ_PARQUET_RE,
        )
    except Exception as e:
        logger.debug("%s dispatcher helpers unavailable: %s", LOG_TAG, e)
        return None

    # Exactly ONE read_parquet array (outside string literals): MoR views
    # carry an auxiliary position-delete array whose files must NOT be
    # chunk-sliced — those shapes are refused here, not mangled.
    lit = _string_literal_ranges(setup_sql or "")
    arrays = [m for m in _READ_PARQUET_RE.finditer(setup_sql or "")
              if not _inside_any_range(m.start(), lit)]
    if len(arrays) != 1:
        _say(f"setup has {len(arrays)} read_parquet arrays (need exactly 1) "
             f"— refusal stands")
        return None
    inner_match, files = _extract_file_list(setup_sql)
    if not inner_match or len(files) < 2:
        _say("no splittable file list — refusal stands")
        return None

    # Budgets from GROUND TRUTH (the connection's effective settings).
    try:
        from core.duckdb_resource_limits import parse_memory_limit_to_bytes
        mem_bytes = int(parse_memory_limit_to_bytes(str(con.execute(
            "SELECT current_setting('memory_limit')").fetchone()[0])))
    except Exception as e:
        logger.debug("%s memory limit unreadable: %s", LOG_TAG, e)
        return None
    exp_factor = 0.0
    try:
        if expansion_factor is not None and float(expansion_factor) > 0:
            exp_factor = float(expansion_factor)
    except (TypeError, ValueError):
        exp_factor = 0.0
    if exp_factor <= 0:
        from core.spill_admission import expansion_factor as _cfg_exp
        exp_factor = _cfg_exp()

    chunks = _chunk_files(files, int(island_bytes), mem_bytes, exp_factor,
                          _chunk_fill(), _max_runs())
    if not chunks:
        _say("island not chunkable within budgets — refusal stands")
        return None

    _say(f"route={plan.route} — {len(files)} files -> {len(chunks)} runs "
         f"(mem={mem_bytes // (1024**2)}MB, expansion={exp_factor:.2f}x): "
         f"{plan.reason}")

    # RUN-file row groups are sized for the MERGE, not for the export:
    # pyarrow's batch reader buffers proportionally to the source file's
    # row-group size (MEASURED 2026-08-04: merging runs written with
    # 122,880-row groups peaked at 59.8 MB of Arrow memory vs 17.1 MB
    # with 2,000-row groups, same data, same 8 MB budget), so the k-way
    # merge is only as bounded as the runs' row groups.  The canonical
    # OUTPUT keeps the width-aware layout (row_group_clause / the merge's
    # own width-aware default).
    run_rg_clause = row_group_clause
    if plan.route == "order_merge":
        ncols = 0
        try:
            ncols = len(con.execute(
                f"DESCRIBE SELECT * FROM ({plan.run_sql}) AS __qs_probe"
            ).fetchall())
        except Exception as probe_exc:
            logger.debug("%s run width probe failed: %s", LOG_TAG, probe_exc)
        if ncols <= 0:
            ncols = 1024                       # fail-closed: assume wide
        # The merge budget scales with the child's memory limit — a fixed
        # small budget would refuse large-k merges that plainly fit.
        merge_budget = max(_merge_budget_bytes(), mem_bytes // 2)
        share = max(64 * 1024, merge_budget // (len(chunks) + 2))
        # MEASURED (2026-08-04, 902 cols): pyarrow's reader transiently
        # costs ~3x a row group's DECODED bytes (compressed + decoded +
        # arrow), and DuckDB rounds ROW_GROUP_SIZE up to vector multiples
        # (2048).  Size the run row groups so k x 3 x rg_decoded fits the
        # budget; x16/col covers doubles + string headroom.  Layout-only
        # — a wrong estimate costs granularity, never correctness.
        run_rg_rows = max(500, min(122_880, share // (ncols * 48)))
        run_rg_clause = f", ROW_GROUP_SIZE {run_rg_rows}"
        # Reader floor: DuckDB will not write groups under ~2048 rows, so
        # with k runs the merge cannot hold less than ~k x 3 x 2048 rows
        # decoded.  If that already exceeds the budget with headroom, the
        # merge would blow past its bound — refuse (fail-closed) instead
        # of completing by luck.
        reader_floor = len(chunks) * 3 * 2048 * ncols * 8
        if reader_floor > merge_budget * 1.5:
            _say(f"merge reader floor ~{reader_floor // (1024**2)}MB "
                 f"({len(chunks)} runs x {ncols} cols) exceeds the merge "
                 f"budget {merge_budget // (1024**2)}MB — route not "
                 f"applicable (raise memory or reduce island)")
            return None

    builder = _build_chunk_setup_builder(setup_sql, inner_match,
                                         httpfs_required=False)
    runs_dir = output_path + ".completion_runs"
    tmp_out = output_path + ".completion_tmp.parquet"
    for p in (runs_dir, tmp_out):
        if sidecar_register is not None:
            try:
                sidecar_register(p)
            except Exception:
                logger.debug("%s sidecar register failed for %s", LOG_TAG, p)
        if temp_files is not None:
            temp_files.append(p)

    import shutil
    t0 = time.monotonic()
    try:
        if os.path.isdir(runs_dir):
            shutil.rmtree(runs_dir, ignore_errors=True)
        os.makedirs(runs_dir, exist_ok=True)

        run_paths: List[str] = []
        for i, chunk in enumerate(chunks):
            rp = os.path.join(runs_dir, f"run_{i:05d}.parquet")
            _exec_statements(con, builder(chunk))
            con.execute(
                f"COPY ({plan.run_sql}) TO '{_sql_path(rp)}' "
                f"(FORMAT PARQUET, COMPRESSION ZSTD{run_rg_clause})")
            run_paths.append(rp)
            _say(f"run {i + 1}/{len(chunks)} written "
                 f"({len(chunk.files)} files, "
                 f"{os.path.getsize(rp) // (1024**2)} MB)")

        # RESTORE the original full-island views: a later statement on
        # this connection must never accidentally see the LAST chunk.
        _exec_statements(con, setup_sql)

        if plan.route == "order_merge":
            from core.sorted_run_merge import merge_sorted_runs
            rows = merge_sorted_runs(
                run_paths, list(plan.sort_keys), tmp_out,
                budget_bytes=max(_merge_budget_bytes(), mem_bytes // 2))
        elif plan.route == "partial_agg":
            run_csv = ", ".join(f"'{_sql_path(p)}'" for p in run_paths)
            con.execute(
                f"CREATE OR REPLACE TEMP VIEW {_PARTIALS_VIEW} AS "
                f"SELECT * FROM read_parquet([{run_csv}], "
                f"union_by_name=false)")
            try:
                con.execute(
                    f"COPY ({plan.final_sql}) TO '{_sql_path(tmp_out)}' "
                    f"(FORMAT PARQUET, COMPRESSION ZSTD{row_group_clause})")
            finally:
                try:
                    con.execute(f"DROP VIEW IF EXISTS {_PARTIALS_VIEW}")
                except Exception:
                    logger.debug("%s partials view drop failed", LOG_TAG)
            import pyarrow.parquet as pq
            rows = int(pq.read_metadata(tmp_out).num_rows)
        elif plan.route == "distinct":
            run_csv = ", ".join(f"'{_sql_path(p)}'" for p in run_paths)
            con.execute(
                f"COPY (SELECT DISTINCT * FROM read_parquet([{run_csv}], "
                f"union_by_name=false)) TO '{_sql_path(tmp_out)}' "
                f"(FORMAT PARQUET, COMPRESSION ZSTD{row_group_clause})")
            import pyarrow.parquet as pq
            rows = int(pq.read_metadata(tmp_out).num_rows)
        else:                                              # pragma: no cover
            raise CompletionRouteError(f"unknown route {plan.route!r}")

        os.replace(tmp_out, output_path)
        dt = time.monotonic() - t0
        _say(f"COMPLETED via {plan.route}: {rows:,} rows in {dt:.1f}s "
             f"({len(run_paths)} runs)")
        return {"route": plan.route, "runs": len(run_paths),
                "rows": int(rows), "seconds": round(dt, 2)}
    except Exception as exc:
        if isinstance(exc, CompletionRouteError):
            raise
        raise CompletionRouteError(
            f"{plan.route} route failed mid-flight: "
            f"{type(exc).__name__}: {exc}") from exc
    finally:
        shutil.rmtree(runs_dir, ignore_errors=True)
        try:
            if os.path.exists(tmp_out):
                os.unlink(tmp_out)
        except OSError:
            logger.debug("%s tmp cleanup failed for %s", LOG_TAG, tmp_out)
