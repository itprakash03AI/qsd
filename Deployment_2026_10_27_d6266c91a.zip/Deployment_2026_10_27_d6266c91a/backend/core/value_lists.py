"""Value lists -- a NAMED list of choices synced into OUR database (2026-10-24).

The owner: "why can't we create a table and get possible parameter values
saved in our db ... a sync-up option rather than calling at run time ...
some list with key value json"; "prod can get from prod queries".

A value list (``value_lists``) is a DEFINITION -- a query on a connection
naming a KEY column (what a choice filters by) and an optional LABEL column
(what a person reads), or a static list -- plus its VALUES
(``value_list_items``), synced into the metadata database.  Any report
parameter can offer it (``values_source = list``); one list serves every
report that names it.

* :func:`sync` runs the query on the list's connection through the engine's
  one execution road (S3 via DuckDB, SQL sources on their connector) and
  replaces the values in ONE transaction: added / changed / removed counted,
  ``values_version`` moved.  A failure changes NOTHING but the status: the
  previous values stay and are served, said stale (``last_status=failed``).
  A release carries the definition, never the values -- each environment
  syncs its own from its own connection.
* :func:`serve` answers "what may THIS viewer choose".  A stored list is a
  snapshot of EVERYTHING, so it is never served wider than the viewer could
  query:
    - an admin (who bypasses row security) gets the stored values;
    - when a source table of the list's query carries a row policy, or an
      entitlement dimension through a column OTHER than the key, the stored
      snapshot cannot be filtered faithfully: the list is served LIVE -- its
      query run under the viewer's row security, cached per viewer
      (core/column_value_cache.py);
    - a source table whose columns are unknown is served live too (live is
      always right, only slower);
    - otherwise the stored values, filtered by the viewer's data entitlement
      on the KEY column by NAME (generic, like every query).
"""
from __future__ import annotations

import logging
import time
import uuid
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

SOURCE_TYPES = ("query", "static")
SYNC_MODES = ("manual", "daily")
#: the most values one list holds (more is refused at sync -- a list is a
#: list of CHOICES; a larger one is a table, read live)
MAX_VALUES = 200_000


class ValueListError(ValueError):
    """A definition or a sync a person can fix -- the message says how."""


# ── definitions ─────────────────────────────────────────────────────────────

def problems(d: Dict[str, Any], *, creating: bool) -> List[str]:
    """Every reason a definition cannot be saved (ONE 422)."""
    out: List[str] = []
    if creating or "name" in d:
        if not str(d.get("name") or "").strip():
            out.append("name is required")
    st = d.get("source_type", "query" if creating else None)
    if st is not None and st not in SOURCE_TYPES:
        out.append(f"source_type must be one of {', '.join(SOURCE_TYPES)}")
    if st == "query":
        if not d.get("connection_id"):
            out.append("a query list needs a connection")
        if not str(d.get("source_sql") or "").strip():
            out.append("a query list needs its query")
        if not str(d.get("key_column") or "").strip():
            out.append("name the KEY column -- the value a choice filters by")
    sm = d.get("sync_mode")
    if sm is not None and sm not in SYNC_MODES:
        out.append(f"sync_mode must be one of {', '.join(SYNC_MODES)}")
    if sm == "daily" and d.get("sync_every_hours") is not None:
        try:
            if int(d["sync_every_hours"]) < 1:
                out.append("sync_every_hours must be at least 1")
        except (TypeError, ValueError):
            out.append("sync_every_hours must be a whole number of hours")
    return out


# ── sync ────────────────────────────────────────────────────────────────────

def _fed(db):
    from core.federation_engine import FederationEngine
    return FederationEngine(db)


def run_query(db, connection_id: int, sql: str, user_ctx: Optional[Dict[str, Any]] = None,
              fed=None) -> Tuple[List[str], List[Dict[str, Any]]]:
    """The list's query on its connection: ``(columns, rows)``.  ``user_ctx``
    given = run under that viewer's row security (the LIVE read); None = the
    SYNC (a snapshot of everything, filtered when served)."""
    fed = fed or _fed(db)
    conn = db.get_connection_raw(int(connection_id))
    if not conn:
        raise ValueListError(f"connection {connection_id} does not exist")
    connections = {int(connection_id): conn}
    run_sql = sql
    if user_ctx is not None:
        run_sql = fed._apply_rls_all_connections(sql, connections, user_ctx, label="value list")
    views = None
    if fed._get_connection_type(conn) == "s3":
        views = fed._registered_table_views_for_sql(run_sql, connections, [], base_query=run_sql) or None
    df = fed._execute_query(sql=run_sql, connections=connections, source_tables=[],
                            execution_id=str(uuid.uuid4()), table_views=views)
    return [str(c) for c in df.columns], df.to_dict(orient="records")


def _find(cols: List[str], name: Optional[str]) -> Optional[str]:
    if not name:
        return None
    want = str(name).strip().strip('"').lower()
    return next((c for c in cols if c.lower() == want), None)


def items_from_rows(cols: List[str], rows: List[Dict[str, Any]], key_column: str,
                    label_column: Optional[str]) -> List[Dict[str, Any]]:
    """Rows -> items: key / label / sort_order / attrs; first key wins, an
    empty key is skipped.  Names the missing column (never an empty list)."""
    kc = _find(cols, key_column)
    if kc is None:
        raise ValueListError(f"the query returns no column {key_column!r} (it returns: {', '.join(cols)})")
    lc = _find(cols, label_column) if label_column else None
    if label_column and lc is None:
        raise ValueListError(f"the query returns no column {label_column!r} (it returns: {', '.join(cols)})")
    seen, out = set(), []
    for r in rows:
        k = r.get(kc)
        if k is None or (isinstance(k, float) and k != k):
            continue
        k = _text(k)
        if k == "" or k in seen:
            continue
        seen.add(k)
        label = _text(r.get(lc)) if lc else None
        attrs = {c: _jsonable(v) for c, v in r.items() if c not in (kc, lc)} or None
        out.append({"key": k, "label": label, "sort_order": len(out), "attrs": attrs})
    if len(out) > MAX_VALUES:
        raise ValueListError(f"the query returns {len(out):,} distinct keys -- more than a list of "
                             f"choices should hold ({MAX_VALUES:,}); narrow the query")
    return out


def _ordered(vl: Dict[str, Any], items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """No ORDER BY in the list's query = no order: a DISTINCT comes back in
    any order, so the list is kept in KEY order (and a re-sync of the same
    rows changes nothing); with an ORDER BY the query's order is the list's."""
    if "order by" not in (vl.get("source_sql") or "").lower():
        items = sorted(items, key=lambda i: i["key"])
        for n, it in enumerate(items):
            it["sort_order"] = n
    return items


def _text(v: Any) -> str:
    # THE engine's rule for a date a filter can use (the S3 road hands a DATE
    # back as a midnight Timestamp): midnight -> YYYY-MM-DD, else
    # YYYY-MM-DD HH:MM:SS -- the same key on every road (rig 2026-10-24).
    if isinstance(v, (datetime, date)):
        from core.federation_engine import _lov_temporal_value
        return _lov_temporal_value(v)
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _jsonable(v: Any) -> Any:
    if v is None or isinstance(v, (str, int, bool)):
        return v
    if isinstance(v, float):
        return None if v != v else v
    return _text(v)


def sync(db, list_id: int, *, by: str = "", fed=None) -> Dict[str, Any]:
    """Sync one query list now.  Returns the stored list's status (with the
    summary).  A failure records the reason and keeps the previous values."""
    vl = db.get_value_list(int(list_id))
    if vl is None:
        raise ValueListError(f"value list {list_id} does not exist")
    if vl["source_type"] != "query":
        raise ValueListError("a static list is edited, not synced")
    t0 = time.monotonic()
    try:
        cols, rows = run_query(db, vl["connection_id"], vl["source_sql"], None, fed=fed)
        items = _ordered(vl, items_from_rows(cols, rows, vl["key_column"], vl.get("label_column")))
    except Exception as exc:                                  # noqa: BLE001
        msg = str(exc) if isinstance(exc, ValueListError) else f"{type(exc).__name__}: {exc}"
        logger.warning("[value-lists] sync of %r failed: %s", vl["name"], msg)
        return db.record_value_list_failure(int(list_id), msg[:2000], by=by)
    summary = db.replace_value_list_items(int(list_id), items, by=by,
                                          seconds=round(time.monotonic() - t0, 3))
    try:
        from core import column_value_cache
        column_value_cache.clear()      # a list a viewer was served live may have moved too
    except Exception:                   # noqa: BLE001
        pass
    return summary


def due(lists: List[Dict[str, Any]], now: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """The daily lists whose last sync is older than their interval (24 h by
    default), or that never synced / last FAILED (retried each tick)."""
    now = now or datetime.now(timezone.utc)
    out = []
    for vl in lists:
        if vl.get("source_type") != "query" or vl.get("sync_mode") != "daily":
            continue
        every = max(1, int(vl.get("sync_every_hours") or 24))
        last = vl.get("last_synced_at")
        if vl.get("last_status") in ("never", "failed") or not last:
            out.append(vl)
            continue
        ts = datetime.fromisoformat(last) if isinstance(last, str) else last
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        if (now - ts).total_seconds() >= every * 3600:
            out.append(vl)
    return out


def tick(db) -> Dict[str, Any]:
    """The scheduler's pass: sync every due daily list (one at a time)."""
    done, failed = 0, 0
    for vl in due(db.list_value_lists()):
        out = sync(db, vl["id"], by="value_list_sync")
        if out.get("last_status") == "ok":
            done += 1
        else:
            failed += 1
    return {"synced": done, "failed": failed}


# ── serve ───────────────────────────────────────────────────────────────────

def _is_admin(user: Optional[Dict[str, Any]]) -> bool:
    from core.roles import is_admin_like
    return is_admin_like(user)


def source_tables(sql: str, dialect: str) -> Optional[List[str]]:
    """The base tables the list's query reads (the rewriter's own walk);
    None when the query does not parse."""
    try:
        import sqlglot
        from sqlglot import exp
        from core.row_security.rewriter import _resolved_table_ref, is_cte_reference
        tree = sqlglot.parse_one(sql, read=dialect or None)
    except Exception:                                         # noqa: BLE001
        return None
    refs: List[str] = []
    for t in tree.find_all(exp.Table):
        if isinstance(t.parent, exp.CTE) or is_cte_reference(t):
            continue
        r = _resolved_table_ref(t)
        if r and r not in refs:
            refs.append(r)
    return refs


def needs_live(db, vl: Dict[str, Any]) -> Optional[str]:
    """Why the stored snapshot cannot be served filtered (-> serve live), or
    None.  Unknown = live."""
    if vl.get("source_type") != "query":
        return None
    conn = db.get_connection(int(vl["connection_id"])) or {}
    from core.sql_filter_wrapper import dialect_for_connection_type
    dialect = dialect_for_connection_type(conn.get("connection_type")) or "duckdb"
    tables = source_tables(vl.get("source_sql") or "", dialect)
    if tables is None:
        return "the list's query does not parse here"
    try:
        from core.row_security import api as rs_api
        from core.row_security import entitlement as ent
        resolver = rs_api._resolver
        dims = ent.active_dimensions(db) if ent.enabled() else []
        key = str(vl.get("key_column") or "").strip('"').lower()
        for t in tables:
            if resolver is not None and resolver.table_has_any_policy(int(vl["connection_id"]), t):
                return f"{t} carries a row policy"
            if not dims:
                continue
            cols = ent.table_columns(db, int(vl["connection_id"]), t)
            if cols is None:
                return f"the columns of {t} are not known"
            lower = {c.lower() for c in cols}
            for d in dims:
                for c in d["columns"]:
                    cn = str(c["column_name"]).lower()
                    if cn in lower and cn != key and (c.get("connection_id") in (None, vl["connection_id"])):
                        return f"{t} is entitled by {c['column_name']} (not the key)"
    except Exception as exc:                                  # noqa: BLE001
        return f"row security could not be checked ({type(exc).__name__})"
    return None


def entitled_keys(db, vl: Dict[str, Any], user: Dict[str, Any]) -> Optional[set]:
    """The keys THIS viewer may choose under the data entitlement of the KEY
    column (by name); None = no dimension names it (no filter)."""
    from core.row_security import entitlement as ent
    from core.row_security.api import build_user_ctx
    if not ent.enabled():
        return None
    key = str(vl.get("key_column") or "").strip('"').lower()
    dims = [d for d in ent.active_dimensions(db)
            if any(str(c["column_name"]).lower() == key
                   and c.get("connection_id") in (None, vl.get("connection_id")) for c in d["columns"])]
    if not dims:
        return None
    ctx = build_user_ctx(user)
    scope = ent.scope_of(ctx)
    principals = ent.principals_of(ctx, db, scope)
    rows = db.values_for_principals([d["id"] for d in dims], principals)
    today = datetime.now(timezone.utc).date()
    allowed: Optional[set] = None
    for d in dims:
        mine = [r for r in rows if int(r["dimension_id"]) == int(d["id"]) and ent._valid_today(r, today)]
        if any(r.get("is_all") for r in mine):
            continue                                     # every value of this one
        vals = {str(r["value"]) for r in mine if r.get("value") is not None}
        if not vals and d.get("no_value_behaviour") == ent.SEE_EVERYTHING:
            continue
        allowed = vals if allowed is None else (allowed & vals)
    return allowed if allowed is not None else None


def serve(db, list_id: int, user: Optional[Dict[str, Any]], *, search: Optional[str] = None,
          limit: int = 500) -> Dict[str, Any]:
    """What THIS viewer may choose from the list: ``{values: [{key, label}],
    truncated, source: list | list-live, synced_at, status, stale}``."""
    vl = db.get_value_list(int(list_id))
    if vl is None:
        raise ValueListError(f"value list {list_id} does not exist")
    meta = {"list": vl["name"], "synced_at": vl.get("last_synced_at"),
            "status": vl.get("last_status"), "stale": vl.get("last_status") == "failed",
            "values_version": vl.get("values_version")}
    q = (search or "").strip().lower() or None
    if not _is_admin(user):
        why = needs_live(db, vl)
        if why:
            return {**meta, **_live(db, vl, user, q, limit), "source": "list-live", "live_reason": why}
    allowed = None if _is_admin(user) else entitled_keys(db, vl, user or {})
    items = db.list_value_list_items(int(list_id), search=q, keys=allowed, limit=limit + 1)
    return {**meta, "values": items[:limit], "truncated": len(items) > limit, "source": "list"}


def _live(db, vl, user, q, limit) -> Dict[str, Any]:
    """The list's query under the viewer's row security, cached per viewer."""
    from core import column_value_cache as cvc
    k = cvc.key(vl["connection_id"], f"value_list:{vl['id']}", vl.get("key_column") or "",
                scope=cvc.scope_for(user or {}), qualifier=f"v{vl.get('values_version')}")
    items = cvc.get(k, 0)
    if items is None:
        cols, rows = run_query(db, vl["connection_id"], vl["source_sql"], user or {})
        items = _ordered(vl, items_from_rows(cols, rows, vl["key_column"], vl.get("label_column")))
        cvc.put(k, items, 0)
    if q:
        items = [i for i in items if q in i["key"].lower() or q in str(i.get("label") or "").lower()]
    return {"values": [{"key": i["key"], "label": i.get("label")} for i in items[:limit]],
            "truncated": len(items) > limit}
