"""Backend-side ``--feed-config`` payload builder for generic_feed.py.

PROMOTED (2026-08-22) from the conf-assembly half of
``airflow/dags/querystudio_feed_factory.py::_build_spark_application_spec``,
with the resolution upgraded from HTTP round-trips against the QS API to
DIRECT DB access:

* the DAG's ``_fetch_conn_config`` returned ``{}`` on ANY failure ("the
  Spark job will surface a clearer error") — a spec built with silently
  missing credentials submitted a pod doomed to fail.  Here a connection
  that cannot be resolved raises, at build time, naming the connection.
* the DAG's legacy (no-source-plan) branch shipped ``query_params.sql``
  RAW — no publisher WHERE-mapping wrap, no row-level security — while the
  QS-dispatched ``_execute_airflow`` path applied both.  "Works via
  Airflow, silently different via the other path" is the 2026-08-14 audit's
  dominant defect class; this builder applies the SAME wrap + RLS to the
  legacy branch that ``_execute_airflow`` applies, fail-closed.

The source plan itself still comes from the ONE chokepoint every backend
consumes (``core.feed.source_plan`` via ``core.feed.airflow_plan``), so
generic_feed.py remains a renderer, never a second brain.
"""
from __future__ import annotations

import logging
from datetime import date as _date
from datetime import datetime as _dt
from datetime import timedelta as _td
from datetime import timezone as _tz
from typing import Any, Dict, Optional

from core.feed.read_plan import TABLES_KIND as TABLES_SIDE
from core.spark_k8s.jdbc import build_jdbc_config, connection_principal

logger = logging.getLogger(__name__)


def build_calendar_feed_params(run_date=None, feed_config=None,
                               db=None) -> Dict[str, str]:
    """Calendar token dictionary consumed by generic_feed.py for
    ``{{business_date}}`` etc. substitution (E-M6 semantics: resolve
    against the RUN date, not build wall-clock).  ``None`` → today UTC.

    Phase 4 (2026-08-23): DELEGATES to ``core.feed.param_resolver`` --
    the SAME vocabulary the native path resolves.  The old inline
    arithmetic here was calendar-BLIND: ``prev_business_day`` was
    literally run_date-1 (a Monday run queried SUNDAY while native
    queried Friday -- an empty file delivered and certified complete),
    ``prev_eom``/``month_end`` were calendar month ends (May 31, a
    Sunday, instead of May 29), and the wd1..15/month_start tokens did
    not exist at all, shipping literally into JDBC SQL.  "Both
    submission paths resolve tokens identically" was true -- both were
    identically different from native.  The old arithmetic remains ONLY
    as the fallback when the resolver import itself fails.
    """
    _today = run_date or _dt.now(_tz.utc).date()
    try:
        from core.feed.param_resolver import resolve_feed_params
        _calendar = None
        _cal_name = (feed_config or {}).get("calendar_name")
        if _cal_name and db is not None:
            try:
                from core.feed.calendar import (
                    BusinessCalendar,
                    BusinessCalendarRepo,
                )
                _spec = BusinessCalendarRepo(db).get(str(_cal_name))
                if _spec is not None:
                    _calendar = BusinessCalendar(_spec)
            except Exception as _cal_exc:
                logger.warning(
                    "[spark_k8s] calendar %r resolution failed (%s) -- "
                    "tokens fall back to plain-day arithmetic",
                    _cal_name, _cal_exc,
                )
        params = resolve_feed_params(
            {"id": (feed_config or {}).get("id")},   # user params merged by caller
            feed_run={"run_date": _today, "business_date": _today},
            calendar=_calendar,
        )
        return {k: str(v) for k, v in params.items()}
    except Exception as _pr_exc:
        logger.warning(
            "[spark_k8s] param_resolver unavailable (%s) -- using the "
            "calendar-blind fallback arithmetic", _pr_exc,
        )
    _first_of_this_month = _today.replace(day=1)
    _prev_eom = _first_of_this_month - _td(days=1)
    # Last day of THIS month
    if _today.month == 12:
        _next_first = _date(_today.year + 1, 1, 1)
    else:
        _next_first = _date(_today.year, _today.month + 1, 1)
    _month_end = _next_first - _td(days=1)
    # Last day of NEXT month
    if _next_first.month == 12:
        _month_after_next_first = _date(_next_first.year + 1, 1, 1)
    else:
        _month_after_next_first = _date(_next_first.year, _next_first.month + 1, 1)
    _next_month_end = _month_after_next_first - _td(days=1)
    _prev_business_day = _today - _td(days=1)
    return {
        "business_date":              _today.isoformat(),
        "business_date_yyyymmdd":     _today.strftime("%Y%m%d"),
        "business_date_iso":          _today.isoformat(),
        "run_date":                   _today.isoformat(),
        "run_date_yyyymmdd":          _today.strftime("%Y%m%d"),
        "run_date_iso":               _today.isoformat(),
        "prev_business_day":            _prev_business_day.isoformat(),
        "prev_business_day_yyyymmdd":   _prev_business_day.strftime("%Y%m%d"),
        "prev_business_day_iso":        _prev_business_day.isoformat(),
        "prev_eom":                   _prev_eom.isoformat(),
        "prev_eom_yyyymmdd":          _prev_eom.strftime("%Y%m%d"),
        "prev_eom_iso":               _prev_eom.isoformat(),
        "month_end":                  _month_end.isoformat(),
        "month_end_yyyymmdd":         _month_end.strftime("%Y%m%d"),
        "month_end_iso":              _month_end.isoformat(),
        "next_month_end":             _next_month_end.isoformat(),
        "next_month_end_yyyymmdd":    _next_month_end.strftime("%Y%m%d"),
        "next_month_end_iso":         _next_month_end.isoformat(),
    }


class _ConnResolver:
    """Memoised per-build connection.config resolver (E-L: one DB read per
    connection id per spec build, matching the DAG's memoisation but
    against the DB).  A connection that cannot be resolved RAISES — a spec
    with silently missing credentials is a pod doomed to fail with a
    message that blames the wrong layer."""

    def __init__(self, db: Any):
        self._db = db
        self._cache: Dict[Any, dict] = {}

    def config(self, conn_id) -> dict:
        if not conn_id:
            return {}
        if conn_id in self._cache:
            return self._cache[conn_id]
        raw = self._db.get_connection_raw(conn_id)
        if not raw:
            raise ValueError(
                f"spark_k8s feed conf: connection {conn_id!r} not found — "
                f"refusing to build a SparkApplication with missing "
                f"credentials."
            )
        cfg = dict(raw.get("config") or {})
        # connection_type lives on the record, not always inside config —
        # carry it so build_jdbc_config sees the dialect.
        cfg.setdefault("_connection_type",
                       raw.get("connection_type")
                       or cfg.get("type") or cfg.get("connection_type") or "")
        self._cache[conn_id] = cfg
        return cfg

    def conn_type(self, conn_id) -> str:
        cfg = self.config(conn_id)
        return str(cfg.get("_connection_type") or "")


def _apply_legacy_wrap_and_rls(db: Any, feed_config: dict,
                               query_params: dict, execution_id: str,
                               conns: "_ConnResolver" = None, *,
                               params: Optional[dict] = None,
                               which: str = "primary") -> None:
    """Legacy-conf (no source plan) hardening -- THE securing sequence for
    a side that ships as SQL text, in the order the native, Spark Connect
    and union-pushdown lanes enforce (a ``{{token}}`` breaks the RLS
    parser, and a wrap-injected token must be resolved too):

    * publisher WHERE-mapping wrap of ``query_params.sql`` — FAIL-CLOSED:
      shipping unwrapped SQL hands a detached Spark job a query with the
      publisher's filters removed (2026-08-19 lesson).
    * calendar substitution (2026-10-08, ported from the engine's airflow
      branch of 2026-09-05 when that branch was retired): an unresolvable
      token REFUSES (``ValueError``) rather than shipping literal text --
      ``params`` is the SAME vocabulary the conf ships as ``feed_params``,
      so the job could not have resolved it either.
    * row-level security rewrite — FAIL-CLOSED: the detached job has no DB
      access and no principal; enforcement happens here or never
      (2026-08-17 F1).

    Called ONCE PER SIDE (``which``): the secondary of a legacy
    cross-source conf used to get nothing at all on this builder.
    """
    _raw_sql = query_params.get("sql")
    if not (isinstance(_raw_sql, str) and _raw_sql.strip()):
        return
    try:
        from core.feed_where_apply import apply_where_to_raw_sql as _wrap
        _wrapped = _wrap(_raw_sql, feed_config)
        if _wrapped and _wrapped != _raw_sql:
            query_params["sql"] = _wrapped
    except Exception as _aw_exc:
        # A declared refusal (ValueError, 2026-10-08): the spark-submit
        # route answers 422 and fails the row with it, so the engine's
        # airflow lane and an Airflow-scheduled run both see WHY.  It used
        # to be a RuntimeError, which the route turned into a 500 and the
        # row waited on forever.
        raise ValueError(
            f"Feed filter application failed before Spark submission: "
            f"{_aw_exc}. Refusing to submit a job whose filters were "
            f"dropped."
        ) from _aw_exc

    # ONE query, this side's tables renamed (core/feed/table_map.py) --
    # whether or not tokens render below
    from core.feed.table_map import apply_for_feed as _map_tables
    if query_params.get("sql"):
        query_params["sql"] = _map_tables(query_params["sql"], feed_config, side=which)
    if params is not None:
        from core.feed.airflow_plan import substitute_airflow_sql
        from core.feed.upstream_contract import contract_for
        query_params["sql"] = substitute_airflow_sql(
            query_params["sql"], params, which=which,
            feed_id=feed_config.get("id"),
            bindings=feed_config.get("token_bindings"),
            contract=contract_for(feed_config, params))
        # 2026-10-24 -- the text this side ships, on the run
        # (core/feed/executed_sql.py; observation, never raises)
        from core.feed.executed_sql import record as _record_sql
        _record_sql(feed_config, sql=query_params["sql"], params=params, side=which,
                    field="sql", lane="spark", db=db)

    from core.feed.rls import secure_feed_sql as _secure_feed_sql
    _conn_type = feed_config.get("connection_type")
    if not _conn_type and feed_config.get("connection_id"):
        try:
            # through the memoised resolver — the RLS dialect lookup must
            # not issue a second DB read for a connection the JDBC
            # injection already resolved (E-L, ported from the DAG).
            if conns is not None:
                _conn_type = conns.conn_type(feed_config.get("connection_id"))
            else:
                _conn_rec = db.get_connection_raw(
                    feed_config.get("connection_id"))
                _conn_type = (_conn_rec or {}).get("connection_type")
        except Exception:
            _conn_type = None
    query_params["sql"] = _secure_feed_sql(
        db,
        query_params["sql"], feed_config,
        connection_id=feed_config.get("connection_id"),
        connection_type=_conn_type,
        request_id=execution_id,
    )


def _refuse_unsecurable_downgrade(feed_config: dict,
                                  plan_exc: BaseException) -> None:
    """The plan builder CRASHED (not declined).  Whether the legacy conf
    may stand in is decided from the PAYLOAD, not the traceback -- the
    2026-09-05 rule the engine's airflow branch held, moved here with the
    ONE builder (2026-10-08).  Raises ``ValueError`` (a declared refusal:
    the spark-submit route answers 422 and fails the row with it).

    * A CROSS-source feed REFUSES.  The plan's secondary is a RESOLVED side
      (referenced-source inheritance, saved-query shapes, sql_file
      splitting); the legacy secondary is whatever ``query_params.
      secondary`` holds -- often no SQL at all, a source id the detached
      job resolves ITSELF where no rewrite of ours reaches.  No version
      of the legacy cross conf can be proven to carry what the plan would
      have, so cross-source-ness alone refuses.
    * A single-source feed whose SQL lives ONLY in a referenced source
      (``classify_legacy_conf`` -> not securable) REFUSES: there is no
      text for the securing sequence to act on.
    * Otherwise the legacy conf ships, SECURED (both sides).

    ``GET /api/feeds/legacy-fallback-security-audit`` (airflow_plan.
    audit_legacy_fallback_security) predicts this verdict for the whole
    feed population ahead of time; the refusals name it.
    """
    from core.feed import airflow_plan as _ap
    fid = feed_config.get("id")
    if feed_config.get("secondary_connection_id"):
        logger.error(
            "[spark_k8s] source-plan serialization crashed (%s: %s) on "
            "CROSS-SOURCE feed %s -- REFUSING to submit: the legacy conf "
            "cannot carry the plan's resolved+secured secondary side",
            type(plan_exc).__name__, plan_exc, fid)
        raise ValueError(
            f"Source-plan serialization failed for cross-source feed {fid} "
            f"({type(plan_exc).__name__}: {plan_exc}). Refusing to fall "
            f"back to the legacy conf: it cannot express the resolved, "
            f"row-security-rewritten secondary side, so the Spark job would "
            f"read the secondary source unfiltered. Fix the serialization "
            f"error, or run this feed on the native backend. Giving the feed "
            f"more query_params.sql will NOT lift this refusal -- it is "
            f"CROSS-SOURCE-ness, not missing SQL text. To list every feed "
            f"this would affect, call {_ap.AUDIT_ROUTE} (or "
            f"core.feed.airflow_plan.audit_legacy_fallback_security("
            f"db.list_feed_configs()) in a REPL); this feed appears there "
            f"with refuse_because={_ap.REFUSE_CROSS_SOURCE!r}."
        ) from plan_exc
    verdict = _ap.classify_legacy_conf(feed_config)
    if not verdict.securable:
        logger.error(
            "[spark_k8s] source-plan serialization crashed (%s: %s) on feed "
            "%s whose legacy conf CANNOT be secured (%s) -- REFUSING to "
            "submit", type(plan_exc).__name__, plan_exc, fid, verdict.reason)
        raise ValueError(
            f"Source-plan serialization failed for feed {fid} "
            f"({type(plan_exc).__name__}: {plan_exc}), and the legacy conf "
            f"cannot be secured for it: {verdict.reason} Refusing to submit "
            f"an unsecured job. Fix: correct the serialization error, run "
            f"this feed on the native backend, or give the feed an explicit "
            f"query_params.sql so the backend can wrap, substitute and "
            f"row-security rewrite it before submission. To list every feed "
            f"this would affect, call {_ap.AUDIT_ROUTE} (or "
            f"core.feed.airflow_plan.audit_legacy_fallback_security("
            f"db.list_feed_configs()) in a REPL); this feed appears there "
            f"with refuse_because={_ap.REFUSE_UNSECURABLE_SIDES!r}."
        ) from plan_exc


def _bounds_required_classes() -> tuple:
    """The size classes that REQUIRE JDBC partition bounds (H2).

    Declared under ``spark_k8s.require_partition_bounds_for_size_classes``.
    Falls back to the DECLARED default ("large", "xl") — never to an empty
    tuple, because an unreadable config silently disabling a correctness
    guard is the failure direction this guard exists to close.
    """
    try:
        from core.config import get as _get
        raw = _get("spark_k8s",
                   "require_partition_bounds_for_size_classes", None)
        if isinstance(raw, (list, tuple)):
            return tuple(str(c) for c in raw)
    except Exception:
        pass
    return ("large", "xl")


def _declares_delivery_chain(feed_config: dict) -> bool:
    """Whether this feed declares a MULTI-HOP delivery chain (FR-DEL-14).

    The Spark job knows only ``destination_type`` -- it has never heard of
    ``delivery_chain``.  A feed with an authored chain running pod-side
    would therefore deliver to the single legacy destination and report
    success, silently ignoring every hop the author declared: the
    counterparty at hop 2 simply never receives the file.  That is the
    "works on one lane, silently different on another" class this
    platform keeps paying for.
    """
    chain = (feed_config or {}).get("delivery_chain")
    return isinstance(chain, (list, tuple)) and len(chain) > 0


#: Where an artifacts-only job writes when no artifact bucket is
#: configured: pod-local, so NOT retrievable by the backend (the Spark
#: pods mount no shared volume -- see core/spark_k8s/manifest.py).
POD_LOCAL_ARTIFACT_DIR = "/tmp/qs-spark-artifacts"


def stored_delivery_suppression_for_submit(db: Any, feed_config: dict,
                                           execution_id: str):
    """The run's "do not deliver" decision for THIS submit: the value
    STORED on the execution row (``feed_executions.delivery_suppressed``)
    first -- the spark-submit route builds from the DB feed and the row,
    with no engine in between -- else the engine's stash
    (``feed_config['_delivery_suppressed']``, the same decision).  None =
    no run knowledge (a legacy row / Run Now): deliver as before.

    A row that exists but cannot be READ propagates: a gate against the
    re-delivery incident (FR-OPS-08) that cannot be read must not mean
    "send"."""
    from core.feed.delivery_hops import stored_delivery_suppression
    read = getattr(db, "get_feed_execution_by_exec_id", None)
    if callable(read) and execution_id:
        stored = stored_delivery_suppression(read(execution_id))
        if stored is not None:
            return stored
    stash = (feed_config or {}).get("_delivery_suppressed")
    return None if stash is None else bool(stash)


def job_delivers_in_pod(feed_config: dict, suppressed) -> bool:
    """``deliver_in_job`` -- does the JOB deliver, or QueryStudio from the
    webhook?  ONE decision: the conf builder carries it to the pod, the
    router reads it to know whether the run needs an artifact store.
    ONE rule with :func:`resolve_delivery_owner` (the output half of the
    lane contract, which also knows which (format, destination) pairs the
    job can render): this is its boolean, that carries the reason."""
    return bool(resolve_delivery_owner(
        feed_config or {}, suppressed=bool(suppressed))[0])


def job_writes_artifacts_only(destination_type, *, suppressed: bool,
                              deliver_in_job: bool) -> bool:
    """Will the job write ARTIFACTS ONLY -- parts + manifest that
    QueryStudio must read back -- instead of the counterparty
    destination?  The backend half of the job's ``write_output`` rule: a
    named destination the job does NOT deliver (``suppressed_run``, or
    ``deliver_in_job`` false) is written as artifacts only -- EVERY
    destination since 2026-10-07 (the output half of the lane contract:
    with a delivery chain declared on an s3/local feed the job wrote the
    counterparty itself AND QueryStudio delivered from the webhook, the
    same file twice).  The lifecycle matrix drives the job's own
    ``write_output`` against this predicate so the two cannot drift."""
    if not destination_type:
        return False
    return bool(suppressed) or not deliver_in_job


def run_needs_artifact_store(feed_config: dict, suppressed) -> bool:
    """K6 (2026-10-07): does THIS run's output have to come back to
    QueryStudio through the artifact store?  A suppressed run (a backfill
    launched without delivery) and a run QueryStudio delivers from the
    webhook both do: the job writes parts that the backend certifies,
    renders and keeps -- impossible from a pod-local directory."""
    fc = feed_config or {}
    dest_type = fc.get("destination_type", "local")
    return job_writes_artifacts_only(
        dest_type, suppressed=bool(suppressed),
        deliver_in_job=job_delivers_in_pod(fc, suppressed))


def _artifact_store_settings():
    """``(bucket, prefix, connection_id)`` of the DECLARED Spark artifact
    store (``spark_k8s.artifact_bucket`` / ``artifact_prefix`` /
    ``artifact_connection_id``)."""
    try:
        from core.config import spark_k8s as _sk
        bucket = str(getattr(_sk, "artifact_bucket", "") or "").strip()
        prefix = str(getattr(_sk, "artifact_prefix", "") or "").strip()
        conn_id = int(getattr(_sk, "artifact_connection_id", 0) or 0)
    except Exception as exc:
        logger.warning("[spark_k8s] artifact store settings unreadable "
                       "(%s) -- treated as NOT configured", exc)
        return "", "", 0
    return bucket, prefix.strip("/"), conn_id


def artifact_store_problem() -> Optional[str]:
    """Why the declared artifact store cannot be used, or None when it
    can.  Checked at ROUTING (cheap: config + one connection read) so a
    run that needs a store is refused before anything is created --
    unknown is unsafe."""
    bucket, _prefix, conn_id = _artifact_store_settings()
    if not bucket:
        return ("no artifact store is configured (spark_k8s.artifact_bucket "
                "is empty): a Spark run that does not deliver writes its "
                "file where QueryStudio can read it back, and a pod-local "
                "file is gone with the pod")
    if conn_id:
        try:
            conn = _artifact_store_connection_raw(conn_id)
        except Exception as exc:
            return (f"spark_k8s.artifact_connection_id={conn_id} could not "
                    f"be read ({type(exc).__name__}: {exc})")
        if not conn:
            return (f"spark_k8s.artifact_connection_id={conn_id} names no "
                    f"connection")
        if str(conn.get("connection_type") or "").lower() != "s3":
            return (f"spark_k8s.artifact_connection_id={conn_id} is a "
                    f"{conn.get('connection_type')!r} connection, not s3")
    return None


def _artifact_store_connection_raw(conn_id: int):
    from core.database import get_db_manager
    dbm = get_db_manager()
    if dbm is None:
        from core import feed_engine as _fe
        dbm = getattr(_fe, "_db_manager", None)
    if dbm is None:
        raise RuntimeError("no metadata database in this process")
    return dbm.get_connection_raw(conn_id)


def _artifact_store_connection() -> Optional[Dict[str, Any]]:
    """The artifact store's S3 identity, resolved through THE credential
    chokepoint (``credential_resolver.resolve_s3_for_consumer``):
    ``{endpoint_url, region, aws_access_key_id, aws_secret_access_key,
    aws_session_token}``.  None = no connection declared: both sides use
    their ambient identity (an IRSA role, an instance profile, s3a keys in
    ``spark_k8s.spark_conf``)."""
    _bucket, _prefix, conn_id = _artifact_store_settings()
    if not conn_id:
        return None
    conn = _artifact_store_connection_raw(conn_id)
    if not conn:
        raise ValueError(f"spark_k8s.artifact_connection_id={conn_id} "
                         f"names no connection")
    cfg = dict(conn.get("config") or {})
    from core.credential_resolver import resolve_s3_for_consumer
    from core.s3_access import resolve_s3_access
    resolved = resolve_s3_for_consumer(cfg, "spark_artifact_store",
                                       min_lifetime_seconds=600) or cfg
    # 2026-10-26 -- endpoint / region / path-style from THE access resolver
    # (the answers DuckDB signs with), not re-read off the row.
    ident = resolve_s3_access(resolved, proxy=False).s3a_identity()
    return {
        "endpoint_url": ident["endpoint"],
        "region": ident["region"],
        "path_style": ident["path_style"],
        "aws_access_key_id": ident["access_key_id"],
        "aws_secret_access_key": ident["secret_access_key"],
        "aws_session_token": ident["session_token"],
    }


def artifact_store_client_config() -> Dict[str, Any]:
    """The artifact store as a client config for the backend's ONE S3
    client builder (``feed_engine._build_s3_client``) -- the identity that
    READS the parts back.  ``{}`` = ambient credentials."""
    ident = _artifact_store_connection()
    if not ident:
        return {}
    out = {"endpoint_url": ident.get("endpoint_url"),
           "region": ident.get("region"),
           "access_key_id": ident.get("aws_access_key_id"),
           "secret_access_key": ident.get("aws_secret_access_key"),
           "session_token": ident.get("aws_session_token")}
    return {k: v for k, v in out.items() if v}


def artifact_store_bucket() -> str:
    """The declared artifact bucket ("" = none)."""
    return _artifact_store_settings()[0]


def _artifact_store_conf() -> Dict[str, Any]:
    """``artifact_store`` / ``artifact_config`` for an artifacts-only job:
    the DECLARED Spark artifact store (K6, 2026-10-07) -- NEVER the feed's
    destination_config, which is the counterparty.

    With a store connection declared, ``artifact_config.s3a`` carries the
    endpoint and credentials the job applies to THAT bucket only
    (``generic_feed._apply_artifact_store_s3a``).  The whole conf travels
    in the per-run Secret (FEED_CONFIG_JSON); the ``--feed-config``
    argument is ``redact_credentials``'d, which blanks the secret half.

    No store -> REFUSED (ValueError, a declared refusal): the router
    already refuses such a run (``backend_router.lane_availability``,
    ``no_artifact_store``); this is the guarantee under it.  It used to
    write pod-local (``POD_LOCAL_ARTIFACT_DIR``), where nothing could read
    it back."""
    problem = artifact_store_problem()
    if problem:
        raise ValueError(f"spark_k8s refused: {problem}")
    bucket, prefix, _conn_id = _artifact_store_settings()
    artifact_config: Dict[str, Any] = {"bucket": bucket, "prefix": prefix}
    ident = _artifact_store_connection()
    if ident:
        endpoint = ident.get("endpoint_url") or ""
        artifact_config["s3a"] = {
            "endpoint": endpoint,
            "region": ident.get("region") or "",
            # decided ONCE by core.s3_access (s3a_identity), as for the
            # feed's own source buckets
            "path_style": bool(ident.get("path_style")),
            "access_key_id": ident.get("aws_access_key_id") or "",
            "secret_access_key": ident.get("aws_secret_access_key") or "",
            "session_token": ident.get("aws_session_token") or "",
        }
    return {"artifact_store": "s3", "artifact_config": artifact_config}


def _pod_side_delivery() -> bool:
    """Whether the Spark job delivers its own output (H1).

    Fails toward TRUE — today's behaviour — on any config error.  The
    alternative failure direction is a job that writes artifacts and
    delivers nothing while reporting success, which is silent total
    data loss; a double delivery is at least visible.
    """
    try:
        from core.config import feed_generation as _fg
        return bool(_fg.pod_side_delivery)
    except Exception:
        return True


def resolve_delivery_owner(feed_config: dict, *, suppressed: bool = False):
    """``(deliver_in_job, reason)`` -- does the JOB deliver, or does
    QueryStudio deliver from the completion webhook (H1)?  Resolved ONCE at
    submit and carried in the payload, with the reason.

    QueryStudio delivers when:

    * the run is suppressed (a backfill without delivery) -- nothing is
      delivered at all, and the artifacts are kept;
    * the feed declares a multi-hop chain the job cannot run;
    * the job cannot render this (format, destination) with the shared
      rules (``core.feed.lane_output.job_renders``) -- e.g. parquet over
      SFTP (the image has no pyarrow to write one parquet file on the
      driver), or a LOCAL destination (Spark pods mount no shared volume:
      a file "delivered" there is lost with the pod, and was reported
      delivered);
    * pod-side delivery is switched off for the deployment.

    An Oracle destination is written by the job itself (staging table +
    one transaction, ``qs_oracle_destination_table``) unless one of the
    first two applies.
    """
    from core.feed.lane_output import job_renders
    dest_type = str(feed_config.get("destination_type") or "local").lower()
    fmt = str(feed_config.get("output_format") or "csv").lower()
    if suppressed:
        return False, "delivery suppressed for this run"
    if _declares_delivery_chain(feed_config):
        return False, "the feed declares a delivery chain"
    if dest_type != "oracle" and not job_renders(fmt, dest_type):
        return False, (f"the job does not render {fmt} for a {dest_type} "
                       f"destination; QueryStudio renders and delivers it")
    if not _pod_side_delivery():
        return False, "feed_generation.pod_side_delivery is off"
    return True, "the job renders and delivers itself"


def _resolved_execution_contract(feed_config: dict, *, run_date=None):
    """Every decision the engine needs, resolved once by
    ``core.feed.execution_contract``.

    ONE key, not a growing set.  This started as a csv_dialect key, then
    grew a delivery_filename key, and the next format decision would have
    grown a third -- which is patching one defect repeatedly rather than
    fixing the boundary.  The boundary is: the backend RESOLVES the
    contract, an engine APPLIES it.

    Returns None when the contract cannot be resolved -- what an older
    submitter effectively sends, so the job keeps its own fallbacks.  A
    ContractNotExpressible PROPAGATES: a term Spark cannot honour must
    refuse the submit, never be silently narrowed.
    """
    from core.feed.execution_contract import (
        ENGINE_SPARK,
        ContractNotExpressible,
        resolve_execution_contract,
    )
    try:
        return resolve_execution_contract(
            feed_config, engine=ENGINE_SPARK, business_date=run_date)
    except ContractNotExpressible:
        raise
    except Exception as exc:  # noqa: BLE001 -- stated, never silent
        logger.warning(
            "[spark_k8s] execution contract could not be resolved for feed "
            "%s (%s) -- the job falls back to its own derivation, which may "
            "differ from the native lane",
            (feed_config or {}).get("id"), exc)
        return None

#: The secondary side's OWN partition declaration.  The feed-level
#: ``spark_partition_column`` / bounds / ``spark_num_partitions`` describe the
#: PRIMARY source's shape; a cross-source feed's second side is usually a
#: different table with different columns (the common case is a small
#: dimension joined to a large fact).  2026-09-14: the secondary's jdbc_config
#: was built with the FEED-LEVEL backend_config, so it inherited the primary's
#: partition column and Spark refused the read outright --
#:   "User-defined partition column ID not found in the JDBC relation:
#:    struct<BUCKET: decimal(38,10), BUCKET_NAME: string, REGION: string ...>"
#: -- which kills EVERY hybrid feed whose two sides do not share the
#: partition column, i.e. essentially every real join.
_SECONDARY_PARTITION_ALIASES = {
    "spark_secondary_partition_column": "spark_partition_column",
    "spark_secondary_lower_bound":      "spark_lower_bound",
    "spark_secondary_upper_bound":      "spark_upper_bound",
    "spark_secondary_num_partitions":   "spark_num_partitions",
}

_PRIMARY_PARTITION_KEYS = (
    "spark_partition_column", "partition_column",
    "spark_lower_bound", "lower_bound",
    "spark_upper_bound", "upper_bound",
    "spark_num_partitions", "num_partitions",
)


def secondary_backend_config(backend_config):
    """Read-tuning for the SECONDARY side.

    Everything that is genuinely feed-wide (fetchsize, size class, ...)
    carries over; the four partition knobs do NOT -- they are replaced by the
    side's own ``spark_secondary_*`` declaration, or dropped entirely so the
    side reads single-partition.

    Dropping them is SAFE in the sense CLAUDE.md means: partitioning is a
    throughput optimisation, so falling back to one partition is slower and
    correct, whereas inheriting a column the relation does not have is a hard
    failure.  A secondary side big enough to need parallelism declares its own
    bounds and is still held to the H2 submit-time check.
    """
    bc = dict(backend_config or {})
    for k in _PRIMARY_PARTITION_KEYS:
        bc.pop(k, None)
    src = backend_config or {}
    for sec_key, canonical in _SECONDARY_PARTITION_ALIASES.items():
        if src.get(sec_key) is not None:
            bc[canonical] = src[sec_key]
    return bc

def _reported_side_rows_for_submit(db: Any, feed_config: dict,
                                   execution_id: str) -> dict:
    """The engine's stash when it submitted (``_reported_side_rows``), else
    the ledger resolved here against the execution's business date (the
    DAG road); an unreadable row is said as such, never ``{}``."""
    stashed = (feed_config or {}).get("_reported_side_rows")
    if isinstance(stashed, dict):
        return dict(stashed)
    from core.feed.etl_dependency import resolve_reported_side_rows
    bd = None
    try:
        row = db.get_feed_execution_by_exec_id(execution_id) if execution_id else None
        raw = (row or {}).get("business_date")
        if raw:
            from datetime import date as _date, datetime as _dt
            bd = (raw if isinstance(raw, _date) and not isinstance(raw, _dt)
                  else _date.fromisoformat(str(raw)[:10]))
    except Exception as exc:  # noqa: BLE001 -- a declared side with no date is uncertified, said
        logger.warning("[spark_k8s] %s: the execution's business date could not be "
                       "read for the reported-rows resolution (%s)", execution_id, exc)
    try:
        return resolve_reported_side_rows(db, feed_config, bd)
    except Exception as exc:  # noqa: BLE001
        return {"_unreadable": f"reported side rows could not be resolved ({exc})"}


def _plan_side_kind(source_plan: Optional[dict], which: str) -> str:
    """How the plan says ``which`` side is read ("sql", "tables", ...), or
    "" when there is no plan (the legacy conf decides from the source type)."""
    return str(((source_plan or {}).get(which) or {}).get("kind") or "")


def build_feed_conf(db: Any, feed_config: dict, execution_id: str,
                    *, run_date=None) -> dict:
    """Build the fully-resolved ``--feed-config`` payload for one execution.

    Deliberate fail-closed/fail-open split (same contract as
    ``core.feed.airflow_plan``):

    * ``ValueError`` / ``BackendCapabilityError`` from the plan builder
      PROPAGATE — running anyway would emit half the data and certify it
      COMPLETE.
    * an UNEXPECTED plan-serializer crash falls back to the legacy conf
      with a loud log — a plan-builder bug must not take down feeds that
      work today.  The legacy conf still gets WHERE-wrap + RLS (both
      fail-closed).
    """
    conns = _ConnResolver(db)
    dest_config = feed_config.get("destination_config") or {}
    dest_type = feed_config.get("destination_type", "local")
    _suppressed = bool(stored_delivery_suppression_for_submit(
        db, feed_config, execution_id))
    if dest_type == "sftp":
        dest_config = sftp_dest_config_for_pod(dest_config)

    # ── Is the LEGACY conf, for THIS feed, securable? ─────────────────
    # Decided from the PAYLOAD before anything is attempted, and logged on
    # EVERY submission (the system logs what it DID and what it would
    # DECLINE), so "this feed's fallback would refuse" is visible from the
    # first run rather than discovered the night a plan build crashes.
    # ``GET /api/feeds/legacy-fallback-security-audit`` answers the same
    # question over the whole feed population ahead of time.
    from core.feed.airflow_plan import classify_legacy_conf
    _legacy_verdict = classify_legacy_conf(feed_config)
    logger.info(
        "[spark_k8s] feed=%s legacy-conf fallback is %s -- %s",
        feed_config.get("id"),
        "SECURABLE" if _legacy_verdict.securable else "UNSECURABLE",
        _legacy_verdict.reason)

    # ── Serialized source plan (the ONE chokepoint) ───────────────────
    source_plan = None
    try:
        from core.feed.airflow_plan import build_serialized_plan
        source_plan = build_serialized_plan(db, feed_config)
    except ValueError:
        raise  # deliberate fail-closed refusal (incl. BackendCapabilityError)
    except Exception as _plan_exc:
        # This handler RECORDS the crash; whether the legacy conf may
        # stand in for the plan is decided from the PAYLOAD, below.
        _refuse_unsecurable_downgrade(feed_config, _plan_exc)
        logger.warning(
            "[spark_k8s] feed %s: source-plan serialization crashed "
            "(%s: %s) — building legacy conf without a plan; the legacy "
            "conf applies the SAME WHERE wrap, parameter substitution and "
            "row-security rewrite the plan would have applied",
            feed_config.get("id"), type(_plan_exc).__name__, _plan_exc,
        )

    # ── Calendar feed params (E-M6: run-date resolved) ────────────────
    # Built BEFORE any side is secured: the legacy securing sequence
    # substitutes tokens with exactly this vocabulary (what the job
    # receives as ``feed_params``), so what it refuses is what the job
    # could not have resolved either.
    feed_params = build_calendar_feed_params(run_date, feed_config=feed_config,
                                             db=db)
    for k, v in (feed_config.get("query_params") or {}).items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            feed_params[k] = v

    # ── Destination Oracle credentials ────────────────────────────────
    oracle_jdbc_config = {}
    if dest_type == "oracle":
        dest_conn_cfg = conns.config(dest_config.get("connection_id"))
        if dest_conn_cfg:
            # The principal comes through the SAME resolver the source
            # side uses (``connection_principal``): a UI-authored Oracle
            # connection stores it as ``user``, and reading ``username``
            # alone here shipped an empty login to the pod (2026-09-13).
            oracle_jdbc_config = {
                "host": dest_conn_cfg.get("host", ""),
                "port": int(dest_conn_cfg.get("port", 1521)),
                "service_name": dest_conn_cfg.get("service_name", ""),
                "username": connection_principal(dest_conn_cfg),
                "password": dest_conn_cfg.get("password", ""),
            }

    # ── Primary source credentials + JDBC config ──────────────────────
    primary_conn_id = feed_config.get("connection_id")
    primary_source_type = (feed_config.get("source_type") or "").lower()
    primary_query_params = dict(feed_config.get("query_params") or {})
    backend_config = feed_config.get("backend_config") or {}
    # A "tables" side (2026-10-14: an S3 connection -- Iceberg / Parquet
    # files the backend planned, core/feed/read_plan.py) is read by the job
    # FROM THE PLAN and has no JDBC URL.  Deciding from the source type alone
    # asked an S3 connection for a JDBC grammar and refused every S3 feed
    # pinned to Spark before a pod existed.
    _primary_is_tables = _plan_side_kind(source_plan, "primary") == TABLES_SIDE
    if (primary_source_type in ("raw_sql", "jdbc") and primary_conn_id
            and not _primary_is_tables):
        primary_conn_cfg = conns.config(primary_conn_id)
        if primary_conn_cfg and "jdbc_config" not in primary_query_params:
            primary_query_params["jdbc_config"] = build_jdbc_config(
                primary_conn_cfg, conns.conn_type(primary_conn_id),
                backend_config=backend_config,
            )
    elif primary_source_type == "iceberg":
        # FR-SRC-03/04 (2026-09-02) — resolve the catalog read config and
        # PIN THE SNAPSHOT ID here, at plan time.  The pinned id travels
        # inside query_params.iceberg; the Spark job REFUSES to run
        # without one, so a run can never read whatever HEAD is at
        # executor start.  Refusals (missing catalog URI / warehouse /
        # table, unpinnable snapshot) are IcebergConfigError, a
        # ValueError — deliberately fail-closed, same contract as the
        # plan builder above.
        from core.spark_k8s.iceberg import build_iceberg_query_params
        _ice_conn_cfg = (conns.config(primary_conn_id)
                         if primary_conn_id else {})
        primary_query_params["iceberg"] = build_iceberg_query_params(
            _ice_conn_cfg, feed_config)

    # Plan mode: resolved plan sides run as SQL over JDBC — inject the
    # plan connection's JDBC config + overlay resolved SQL onto the legacy
    # ``sql`` key so an OLD generic_feed.py image executes the SAME SQL.
    if source_plan and (source_plan.get("primary") or {}).get("kind") == "sql":
        _plan_primary = source_plan["primary"]
        # The legacy projection IS the plan -- ONE function says so
        # (core.feed.airflow_plan.overlay_legacy_projection), for the
        # primary here and the secondary below.
        from core.feed.airflow_plan import overlay_legacy_projection
        overlay_legacy_projection(primary_query_params, None, source_plan)
        _plan_pcid = _plan_primary.get("connection_id") or primary_conn_id
        if _plan_pcid and "jdbc_config" not in primary_query_params:
            _plan_pconn = conns.config(_plan_pcid)
            if _plan_pconn:
                primary_query_params["jdbc_config"] = build_jdbc_config(
                    _plan_pconn, conns.conn_type(_plan_pcid),
                    backend_config=backend_config,
                )
    elif source_plan is None:
        # Legacy conf: WHERE-mapping wrap + substitution + RLS, all
        # fail-closed (the plan path applies the same inside
        # airflow_plan._resolve_serialized_side).
        _apply_legacy_wrap_and_rls(db, feed_config, primary_query_params,
                                   execution_id, conns=conns,
                                   params=feed_params, which="primary")
        if not (isinstance(primary_query_params.get("sql"), str)
                and primary_query_params["sql"].strip()):
            # Unconditional, because the failure mode is an ABSENCE: this
            # side ships as a SOURCE REFERENCE (a hand-authored s3_parquet
            # / jdbc conf, a pre-extracted source_path) the detached job
            # resolves itself, so no rewrite of ours reaches it.  Refusing
            # would break feeds that have always run this way; an operator
            # must still be able to SEE it.
            logger.warning(
                "[spark_k8s] feed=%s ships its PRIMARY side (connection=%s, "
                "source_type=%s) with NO SQL text -- the detached Spark job "
                "resolves and executes it itself, so the WHERE mapping and "
                "the row-security rewrite could NOT be applied to that side",
                feed_config.get("id"), primary_conn_id, primary_source_type)

    # ── Partition bounds RESOLVED FROM THE SOURCE (2026-09-20) ────────
    # A declared spark_partition_column gets its lower/upper bound from
    # MIN/MAX over the feed's own SQL, plus the row count the job reconciles
    # its read against.  Refusals (non-integer key, NULLs, no rows, a bad
    # column) are PartitionBoundsError -- a ValueError, raised here before a
    # Secret or workload exists.  See core/spark_k8s/partition_bounds.py.
    # Declared bounds are TRUSTED (H2 below validates their shape): the
    # probe is one MIN/MAX/COUNT scan of the feed's own SQL, and a 160M-row
    # month-end feed whose author already declared its bounds must not pay
    # a second full scan at every submit.  A column declared WITHOUT bounds
    # is the new capability, and pays the probe once per submit.
    _jc = primary_query_params.get("jdbc_config") or {}
    if _jc.get("partition_column") and (
            _jc.get("lower_bound") is None or _jc.get("upper_bound") is None):
        from core.spark_k8s.partition_bounds import apply_source_bounds
        _pb_cid = primary_conn_id
        if source_plan and (source_plan.get("primary") or {}).get("connection_id"):
            _pb_cid = source_plan["primary"]["connection_id"]
        try:
            from core.config import spark_k8s as _sk_cfg
            _pb_default = int(_sk_cfg.num_executors) * 2
        except Exception:                                    # noqa: BLE001
            _pb_default = None
        apply_source_bounds(
            _jc, conns.config(_pb_cid), conns.conn_type(_pb_cid),
            primary_query_params.get("sql") or "",
            num_partitions_default=_pb_default,
        )

    # ── H2 — partition bounds validated at submit, not degraded in-pod ─
    if primary_query_params.get("jdbc_config"):
        from core.spark_k8s.jdbc import validate_jdbc_partition_bounds
        validate_jdbc_partition_bounds(
            primary_query_params["jdbc_config"],
            size_class=backend_config.get("spark_size_class"),
            required_classes=_bounds_required_classes(),
        )

    # ── Who delivers: the job, or QueryStudio from its artifacts ─────
    _deliver_in_job, _delivery_owner_reason = resolve_delivery_owner(
        feed_config, suppressed=_suppressed)

    feed_conf_dict = {
        "feed_config_id": feed_config.get("id"),
        "feed_name": feed_config.get("name"),
        "execution_id": execution_id,
        "source_type": feed_config.get("source_type"),
        "source_id": feed_config.get("source_id"),
        "connection_id": feed_config.get("connection_id"),
        "query_params": primary_query_params,
        "feed_params": feed_params,
        "output_format": feed_config.get("output_format", "csv"),
        "output_filename_template": feed_config.get("output_filename_template"),
        "output_options": feed_config.get("output_options") or {},
        # BRD D2 / §10.1 -- PASS THE FULL CONTRACT TO THE JOB.
        #
        # The engines differ (DuckDB here, Spark there) and must: you
        # cannot share "read with DuckDB" and "read with Spark" code.  What
        # they must NEVER do is make the same DECISION twice -- the two
        # answers drift and both lanes still report success.  So every
        # decision is resolved here and travels; the job applies it.
        #
        # The BRD rule for this class: a capability the author can DECLARE
        # must be honoured or REFUSED by every execution lane, never
        # quietly downgraded.
        "execution_contract": _resolved_execution_contract(
            feed_config, run_date=run_date),
        "destination_type": dest_type,
        "destination_config": dest_config,
        "oracle_jdbc_config": oracle_jdbc_config,
        # H1 (2026-09-02) — does the JOB deliver, or does QueryStudio?
        # Resolved at SUBMIT and carried in the payload so the answer is
        # pinned for this attempt: a config change mid-flight cannot make
        # the pod and the webhook disagree about who sends the file.
        # A DECLARED CHAIN forces engine-side delivery.  The job writes
        # artifacts (a supported path -- `_write_artifacts_only`), the
        # engine runs the hop plan, and every declared hop is honoured on
        # this lane exactly as on the native one.  Letting the job deliver
        # would silently collapse an N-hop chain to one destination and
        # still report success.
        "deliver_in_job": _deliver_in_job,
        "delivery_owner_reason": _delivery_owner_reason,
        # 2026-10-07 -- the run's "do not deliver" decision, STORED on the
        # execution when it was created (a backfill launched without
        # delivery).  The job reads it and writes ARTIFACTS ONLY, for every
        # destination type -- deliver_in_job=false alone stops only
        # sftp/oracle, and an s3/local destination is written by the job
        # itself.  Until today this lane never asked: a backfill the size
        # router sent to Spark DELIVERED.  The webhook-side delivery then
        # reads the same stored decision and records SUPPRESSED.
        "suppress_delivery": bool(_suppressed),
        # 2026-10-11 -- what every side is EXPECTED to count, resolved from
        # the dependency ledger ONCE (the engine stashes it at execution
        # start; a submission that did not come through the engine -- the
        # Airflow DAG's /spark-submit -- resolves it here from the
        # execution's business date).  The job judges its sides against it
        # through the mirror of core/feed/reported_rows_certification.py
        # BEFORE writing anything; a mismatch fails the job with the numbers.
        "reported_side_rows": _reported_side_rows_for_submit(
            db, feed_config, execution_id),
    }
    if not feed_conf_dict["deliver_in_job"]:
        # Where an artifacts-only job writes: QueryStudio's OWN declared
        # store (spark_k8s.artifact_bucket), never the counterparty
        # destination.  Required whenever the job will write artifacts
        # only (run_needs_artifact_store -- the rule the router refused
        # by); a job that still writes its own s3/local destination gets
        # the store too when one is declared, and nothing when not.
        if (run_needs_artifact_store(feed_config, _suppressed)
                or artifact_store_problem() is None):
            feed_conf_dict.update(_artifact_store_conf())
    elif artifact_store_problem() is None:
        # 2026-10-13 -- a job that DELIVERS renders a large CSV in PARTS on
        # its executors (generic_feed._render_csv_parts) and needs a place
        # for them: QueryStudio's declared store, never the counterparty's.
        # No store declared -> the driver renders the file as before.
        feed_conf_dict.update(_artifact_store_conf())
    if dest_type == "local":
        # K5: the allowed-roots rule travels with its roots, so a job that
        # is ever handed a local destination applies the SAME check native
        # does (core.feed.delivery_protocol.resolve_local_destination) --
        # it used to write /tmp/feed_output unchecked.
        from core.feed_engine import local_destination_roots
        _out_dir, _extra = local_destination_roots()
        feed_conf_dict["local_delivery"] = {"output_dir": _out_dir,
                                            "allowed_roots": _extra}

    # ── Secondary side (cross-source) ─────────────────────────────────
    _plan_secondary = (source_plan or {}).get("secondary") or {}
    secondary_conn_id = (
        _plan_secondary.get("connection_id")
        if (source_plan and source_plan.get("is_cross"))
        else feed_config.get("secondary_connection_id")
    )
    if secondary_conn_id:
        secondary_query_params = dict(
            (feed_config.get("query_params") or {}).get("secondary") or {}
        )
        secondary_source_type = (feed_config.get("secondary_source_type") or "").lower()
        _plan_sec_is_sql = _plan_secondary.get("kind") == "sql"
        _plan_sec_is_tables = _plan_secondary.get("kind") == TABLES_SIDE
        if not _plan_sec_is_tables and (
                secondary_source_type in ("raw_sql", "jdbc") or _plan_sec_is_sql):
            sec_conn_cfg = conns.config(secondary_conn_id)
            if sec_conn_cfg and "jdbc_config" not in secondary_query_params:
                secondary_query_params["jdbc_config"] = build_jdbc_config(
                    sec_conn_cfg, conns.conn_type(secondary_conn_id),
                    backend_config=secondary_backend_config(backend_config),
                )
        if _plan_sec_is_sql and _plan_secondary.get("sql"):
            from core.feed.airflow_plan import overlay_legacy_projection
            overlay_legacy_projection(None, secondary_query_params,
                                      source_plan)
        elif source_plan is None:
            # ── The SECONDARY side is secured EXACTLY like the primary ──
            # (2026-10-08, ported from the engine's airflow branch of
            # 2026-09-05 when that branch was retired.)  On THIS builder it
            # used to receive its JDBC config and nothing else: no publisher
            # WHERE wrap, no substitution, no row-security rewrite -- a
            # cross-source feed handed a DETACHED job half of its query
            # with row security missing.  Same helper, same order, against
            # the SECONDARY's OWN connection, never the primary's dialect.
            _sec_sql = secondary_query_params.get("sql")
            if isinstance(_sec_sql, str) and _sec_sql.strip():
                _sec_fc = dict(feed_config)
                _sec_fc["connection_id"] = secondary_conn_id
                _sec_fc.pop("connection_type", None)
                _sec_fc.pop("source_connection_type", None)
                _apply_legacy_wrap_and_rls(
                    db, _sec_fc, secondary_query_params, execution_id,
                    conns=conns, params=feed_params, which="secondary")
            else:
                logger.warning(
                    "[spark_k8s] feed=%s ships a secondary side "
                    "(connection=%s, source_type=%s) with NO SQL text -- "
                    "the detached Spark job resolves and executes it "
                    "itself, so the row-security rewrite could NOT be "
                    "applied to that side",
                    feed_config.get("id"), secondary_conn_id,
                    feed_config.get("secondary_source_type"))
        if secondary_query_params.get("jdbc_config"):
            # H2 — the secondary side is a JDBC read too; a heavy feed's
            # unbounded side is unbounded whichever side it is on.
            from core.spark_k8s.jdbc import validate_jdbc_partition_bounds
            validate_jdbc_partition_bounds(
                secondary_query_params["jdbc_config"],
                size_class=backend_config.get("spark_size_class"),
                required_classes=_bounds_required_classes(),
            )
        feed_conf_dict.update({
            "secondary_connection_id":   secondary_conn_id,
            "secondary_source_type":      feed_config.get("secondary_source_type"),
            "secondary_source_id":        feed_config.get("secondary_source_id"),
            "combine_mode":               (
                (source_plan or {}).get("combine_mode")
                or feed_config.get("combine_mode") or "union"
            ).lower(),
            "join_config":                (
                ((source_plan or {}).get("join_config") if source_plan else None)
                or feed_config.get("join_config") or {}
            ),
            "secondary_query_params":     secondary_query_params,
        })

    if source_plan:
        feed_conf_dict["source_plan"] = source_plan

    # BF-263 lineage: DB rows can carry datetime / Decimal — sanitize so
    # json.dumps in the manifest builder never TypeErrors.
    from core.json_utils import sanitize_for_json
    return sanitize_for_json(feed_conf_dict)


def sftp_dest_config_for_pod(dest_config: dict) -> dict:
    """AQD-11 (2026-09-23) -- the SFTP credential a Spark pod delivers with.

    The native lane resolves ``system_account_id`` / ``system_account_name``
    through ``core.qs_credentials`` at connect time.  The pod cannot: it has
    no metadata DB and no vault login.  This lane used to ship the
    destination config as authored, so a vault-backed SFTP destination
    reached the job with NO credential (its only fallback was the
    SFTP_USERNAME / SFTP_PASSWORD env vars nothing sets).

    Resolved HERE, on the backend, into the conf -- which travels only in the
    job's mounted K8s Secret (``FEED_CONFIG_JSON``); the CLI argument is the
    ``redact_credentials`` copy, and ``private_key`` / its passphrase are in
    ``SENSITIVE_KEYS``.  Literal values win, exactly as on the native lane.
    A lookup failure is NOT swallowed: the native lane names it in its
    refusal, and a pod started without the credential would fail later with
    less to say.
    """
    sa_ref = dest_config.get("system_account_id") or dest_config.get("system_account_name")
    if not sa_ref:
        return dest_config
    # The SAME condition the native lane uses (_sftp_connect): the account is
    # consulted only when a literal username or password is blank.  Without
    # it a destination carrying BOTH literals plus an account reference ran
    # on the native lane and REFUSED on the Spark lane whenever vault was
    # unreachable -- one destination, two answers by lane.
    if dest_config.get("username") and dest_config.get("password"):
        return dest_config
    from core.qs_credentials import resolve_system_account
    try:
        account = resolve_system_account(sa_ref) or {}
    except Exception as exc:
        raise ValueError(
            f"SFTP destination references system account {sa_ref!r}, which could "
            f"not be resolved for the Spark pod: {type(exc).__name__}: {exc}") from exc
    out = dict(dest_config)
    for key in ("username", "password", "private_key"):
        if not out.get(key) and account.get(key):
            out[key] = account[key]
    passphrase = account.get("private_key_passphrase") or account.get("passphrase")
    if passphrase and not out.get("key_passphrase"):
        out["key_passphrase"] = passphrase
    return out
