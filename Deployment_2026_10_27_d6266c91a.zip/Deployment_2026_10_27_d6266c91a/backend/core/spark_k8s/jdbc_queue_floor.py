"""The executor memory a JDBC read NEEDS, by the width of what it reads.

2026-10-13 -- found live: the owner's month-end feed (460 columns, both
sides on Starburst, 1M rows) was routed to a Spark pod and every executor
died ``OutOfMemoryError: Java heap space`` inside the Trino driver's JSON
decoding.  ``trino-jdbc`` (455, the jar in ``spark/Dockerfile``) buffers up
to 50,000 rows PER CONNECTION in ``TrinoResultSet$AsyncIterator`` -- the
JDBC fetch size does not bound it -- and 50,000 rows x 460 text columns is
over a gigabyte of strings before Spark does any work.  A 1g executor
cannot hold it, whatever the row count.

So the pod is sized by what it reads: for every side read through a driver
with a declared row queue, ``queue rows x columns x bytes per cell`` per
concurrent task (``executor_cores``) plus Spark's own working set.  A
configured size BELOW that floor is raised to it and the reason is logged;
a size above it is left alone (a floor, never a cap).  An unknown column
count raises nothing and says so -- this is sizing, not a gate.
"""
from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)

#: rows a JDBC driver buffers per connection regardless of fetch size, by
#: driver class.  trino-jdbc 455: ``TrinoResultSet$AsyncIterator`` holds a
#: queue of 50,000 rows (verified in the shipped jar's constant pool).
QUEUED_ROWS_BY_DRIVER = {"io.trino.jdbc.TrinoDriver": 50_000}

#: a decoded cell on the executor heap: a compact Java String (~40 B for a
#: short value) plus its slot in the driver's row list.  The owner's file
#: averages ~8 characters a cell (3.65 GB / 1M rows / 460 columns).
BYTES_PER_CELL = 64

#: Spark's own working set on an executor beside the driver's buffer.
SPARK_HEADROOM_MB = 768


def memory_mb(value) -> Optional[int]:
    """``"4g"`` / ``"512m"`` / ``"2048"`` (MiB) -> MiB; None if unreadable."""
    s = str(value or "").strip().lower()
    if not s:
        return None
    try:
        if s.endswith(("g", "gb", "gi")):
            return int(float(s.rstrip("bgi")) * 1024)
        if s.endswith(("m", "mb", "mi")):
            return int(float(s.rstrip("bmi")))
        return int(float(s))
    except ValueError:
        return None


def output_column_count(sql: str) -> Optional[int]:
    """The SQL's output width from its text, looking THROUGH an outer
    ``SELECT * FROM (<query>) alias`` (the owner's month-end shape); None
    when only the source could say (a bare ``*`` over a table)."""
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one((sql or "").strip().rstrip(";"), read="trino")
    except Exception:
        return None
    for _ in range(8):
        while isinstance(tree, exp.Union):
            tree = tree.this
        selects = list(getattr(tree, "selects", None) or [])
        if not selects:
            return None
        if any(isinstance(s, exp.Star) or (isinstance(s, exp.Column) and isinstance(s.this, exp.Star))
               for s in selects):
            if len(selects) != 1:
                return None
            src = tree.args.get("from") or tree.args.get("from_")   # sqlglot < 30 / >= 30
            inner = getattr(src, "this", None) if src is not None else None
            if isinstance(inner, exp.Subquery) and not tree.args.get("joins"):
                tree = inner.this
                continue
            return None
        return len(selects)
    return None


def _sides(feed_conf: dict):
    """(label, sql, driver) of every JDBC side the job reads."""
    plan = feed_conf.get("source_plan") or {}
    for label, qp_key in (("primary", "query_params"), ("secondary", "secondary_query_params")):
        qp = feed_conf.get(qp_key) or {}
        jdbc = qp.get("jdbc_config") or {}
        sql = ((plan.get(label) or {}).get("sql")) or qp.get("sql")
        if jdbc.get("driver") and sql:
            yield label, sql, jdbc["driver"]


def executor_memory_floor(feed_conf: dict, executor_cores: int) -> tuple:
    """``(floor_mb or None, detail)`` for the JDBC sides of this conf."""
    need = 0
    detail = []
    for label, sql, driver in _sides(feed_conf or {}):
        rows = QUEUED_ROWS_BY_DRIVER.get(driver)
        if not rows:
            continue
        cols = output_column_count(sql)
        if cols is None:
            detail.append(f"{label}: column count unknown from the SQL -- no floor")
            continue
        mb = math.ceil(rows * cols * BYTES_PER_CELL / (1024 * 1024))
        detail.append(f"{label}: {rows:,} queued rows x {cols} columns = {mb} MiB per connection")
        need = max(need, mb)
    if not need:
        return None, "; ".join(detail)
    floor = need * max(1, int(executor_cores or 1)) + SPARK_HEADROOM_MB
    return floor, "; ".join(detail)


def apply_floor(sizing: dict, feed_conf: dict) -> dict:
    """Raise ``sizing['executor_memory']`` to the floor when below it."""
    try:
        floor, detail = executor_memory_floor(feed_conf, int(sizing.get("executor_cores") or 1))
    except Exception as exc:  # noqa: BLE001 -- sizing advice; never blocks a submit
        logger.warning("[spark_k8s] executor memory floor not computed: %s", exc)
        return sizing
    have = memory_mb(sizing.get("executor_memory"))
    if floor is None or have is None or have >= floor:
        if detail:
            logger.info("[spark_k8s] executor memory %s kept (%s)", sizing.get("executor_memory"), detail)
        return sizing
    raised = f"{math.ceil(floor / 1024)}g"
    logger.warning("[spark_k8s] executor memory RAISED %s -> %s: the JDBC driver buffers rows "
                   "per connection whatever the fetch size (%s)",
                   sizing.get("executor_memory"), raised, detail)
    out = dict(sizing)
    out["executor_memory"] = raised
    reason = dict(out.get("reason") or {})
    reason["executor_memory"] = f"JDBC row-queue floor ({detail})"
    out["reason"] = reason
    return out


# ── the memory OUTSIDE the heap a wide read needs (2026-10-14) ──────────────
#
# Found on the rig's pods: the owner's 460-column table rendered to CSV by the
# job died OOMKilled (exit 137) on every 1g executor -- the JVM's off-heap
# (decompression buffers, metaspace, threads) plus the Python CSV renderer
# needed ~860 MiB beyond the heap, and Spark's default overhead for a PySpark
# job is max(384 MiB, 0.4 x executor memory) = 410 MiB at 1g.  Measured: the
# same 4M x 460 run PASSED with 1g heap + 1g overhead (peak 1,886 of 2,048
# MiB) as fast as with a 3g heap.  So the overhead is sized by WIDTH, per
# concurrent task -- a floor, never a cap; an unknown width raises nothing.
#
# 2026-10-27 -- TWO terms, measured on the rig's pods (600 columns, a read
# split by partition key, buckets rendered one after another on each
# executor): the executor JVM's own resident memory outside its heap was
# ~820 MiB at a 3g heap and ~730 MiB at a 4g heap -- it does NOT grow with
# the heap, and it is ONE per executor however many tasks run in it; the
# Python renderer peaked at 371 MiB per task (+ a 22 MiB daemon).  The single
# per-task constant (fitted at 460 columns) gave 1,134 MiB at 600 columns
# and one task against a measured ~1,230 MiB, and executors were OOM-killed
# at 3g heap + 1,228 MiB.  The JVM term is now counted once, the Python term
# per concurrent task.

#: Spark's own minimum overhead (spark.executor.memoryOverhead floor)
OVERHEAD_BASE_MB = 384
#: the executor JVM's memory outside its heap, per column read, ONCE per
#: executor (~820 MiB measured at 600 columns, with headroom)
OVERHEAD_JVM_MB_PER_COLUMN = 0.85
#: the Python renderer, per column read, per CONCURRENT task (371 + 22 MiB
#: measured at 600 columns, with headroom)
OVERHEAD_TASK_MB_PER_COLUMN = 1.0
#: the DRIVER's memory outside its heap: it renders the head and SENDS the
#: parts (copy each to local disk, read 8 MiB chunks, SFTP); measured at a 1g
#: heap its JVM alone held 331 MiB beyond the heap and its Python ~75 MiB,
#: and the 410 MiB Spark gives a 1g PySpark driver was exhausted the moment
#: delivery began (OOMKilled at 1,432 of 1,434 MiB).  With the floor the 2M x
#: 600 run delivered its 30 parts at a peak of 559 MiB beyond the heap -- the
#: floor keeps ~37 % above that.  Not width-dependent.
DRIVER_OVERHEAD_FLOOR_MB = 768
#: Spark on Kubernetes sizes a NON-JVM (PySpark) job's overhead at 0.4 x memory
PYSPARK_OVERHEAD_FACTOR = 0.4


def read_width(feed_conf: dict) -> tuple:
    """``(columns or None, detail)``: the widest side the job reads -- the
    SQL's output columns when its text says, else (a ``SELECT *``) the widest
    table the read plan measured."""
    plan = (feed_conf or {}).get("source_plan") or {}
    widths, detail = [], []
    for label in ("primary", "secondary"):
        side = plan.get(label) or {}
        qp = (feed_conf or {}).get("query_params" if label == "primary" else "secondary_query_params") or {}
        sql = side.get("sql") or qp.get("sql")
        if not sql and not side:
            continue
        cols = output_column_count(sql) if sql else None
        how = "the SQL's select list"
        if cols is None:
            tcols = [t.get("columns") for t in side.get("tables") or [] if t.get("columns")]
            cols = max(tcols) if tcols else None
            how = "the widest table read"
        if cols:
            widths.append(cols)
            detail.append(f"{label}: {cols} columns ({how})")
        else:
            detail.append(f"{label}: width unknown")
    return (max(widths) if widths else None), "; ".join(detail)


def overhead_floor_mb(feed_conf: dict, executor_cores: int) -> tuple:
    """``(floor_mb or None, detail)`` -- the executor memory OUTSIDE the heap
    this read needs."""
    cols, detail = read_width(feed_conf)
    if not cols:
        return None, detail
    tasks = max(1, int(executor_cores or 1))
    floor = OVERHEAD_BASE_MB + math.ceil(cols * OVERHEAD_JVM_MB_PER_COLUMN
                                         + cols * OVERHEAD_TASK_MB_PER_COLUMN * tasks)
    return floor, detail


def apply_overhead_floor(spark_conf: dict, feed_conf: dict, executor_cores: int,
                         executor_memory) -> dict:
    """``spark_conf`` with ``spark.executor.memoryOverhead`` raised to the
    floor when the overhead the pod WOULD get (an explicit setting, else
    Spark's PySpark default) is below it.  Logged either way."""
    try:
        floor, detail = overhead_floor_mb(feed_conf, executor_cores)
    except Exception as exc:  # noqa: BLE001 -- sizing advice; never blocks a submit
        logger.warning("[spark_k8s] executor overhead floor not computed: %s", exc)
        return spark_conf
    explicit = memory_mb(spark_conf.get("spark.executor.memoryOverhead"))
    heap = memory_mb(executor_memory) or 0
    have = explicit if explicit is not None else max(OVERHEAD_BASE_MB, int(heap * PYSPARK_OVERHEAD_FACTOR))
    if floor is None or have >= floor:
        if detail:
            logger.info("[spark_k8s] executor overhead %d MiB kept (%s)", have, detail)
        return spark_conf
    logger.warning("[spark_k8s] executor overhead RAISED %d -> %d MiB: a read this wide needs "
                   "memory outside the heap per task (%s)", have, floor, detail)
    out = dict(spark_conf)
    out["spark.executor.memoryOverhead"] = f"{floor}m"
    return out


def apply_driver_overhead_floor(spark_conf: dict, driver_memory) -> dict:
    """``spark_conf`` with ``spark.driver.memoryOverhead`` raised to
    :data:`DRIVER_OVERHEAD_FLOOR_MB` when the overhead the driver WOULD get
    (an explicit setting, else Spark's PySpark default) is below it.  A
    floor, never a cap; logged when it raises."""
    explicit = memory_mb(spark_conf.get("spark.driver.memoryOverhead"))
    heap = memory_mb(driver_memory) or 0
    have = explicit if explicit is not None else max(OVERHEAD_BASE_MB, int(heap * PYSPARK_OVERHEAD_FACTOR))
    if have >= DRIVER_OVERHEAD_FLOOR_MB:
        return spark_conf
    logger.warning("[spark_k8s] driver overhead RAISED %d -> %d MiB: the driver sends the rendered "
                   "parts and its JVM + Python need that much outside the heap",
                   have, DRIVER_OVERHEAD_FLOOR_MB)
    out = dict(spark_conf)
    out["spark.driver.memoryOverhead"] = f"{DRIVER_OVERHEAD_FLOOR_MB}m"
    return out
