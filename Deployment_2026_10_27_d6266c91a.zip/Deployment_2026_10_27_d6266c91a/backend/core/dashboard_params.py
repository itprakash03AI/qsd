"""Dashboard filters -> the parameters each tile actually runs with (2026-09-25).

A dashboard declares FILTERS (``dashboards.filters``: ``[{name, label, type,
default, options}]``).  Each tile's source declares PARAMETERS by name:

  * a finance report (``business_report``) -- its ``report_parameters`` rows;
  * a legacy parametric report (``report``) -- its ``parameters`` JSON;
  * a saved visual query (``saved_query``) -- the ``{name}`` placeholders
    standing WHOLE in its filter values (what ``/api/execute`` fills);
  * a SQL query (``sql_query``) -- none: nothing fills its text.

ONE rule, used by the live view (the dashboard GET hands each widget its
declared list, and the page applies the same overlay) and by the export:

    effective = widget.param_values, then every dashboard filter value whose
    NAME the tile declares, when that value is not empty.

Only DECLARED names are passed on.  A report refuses an undeclared parameter
by design (``_reject_unknown_parameters`` -- a mistyped name once returned
every row), so a filter a tile does not use must not reach it; and a filter
the tile DOES use must win over the value frozen into the widget, or the
dashboard's filter bar would say "EMEA" over a tile showing APAC.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from core.parameters import PARAM_RE

FILTER_TYPES = ("text", "number", "date", "select")
_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")


def _empty(v: Any) -> bool:
    return v is None or v == "" or (isinstance(v, (list, tuple)) and not v)


def validate_filters(filters: Optional[list]) -> List[dict]:
    """Normalise a dashboard's filter definitions; raise ValueError naming
    the problem.  A filter's name is the parameter name it binds to."""
    out: List[dict] = []
    seen = set()
    for i, f in enumerate(filters or []):
        if not isinstance(f, dict):
            raise ValueError(f"filters[{i}] must be an object")
        name = str(f.get("name") or "").strip()
        if not _NAME_RE.match(name):
            raise ValueError(
                f"filters[{i}].name {name!r} must be a parameter name: a letter "
                f"or '_', then letters, digits or '_' (max 64)")
        if name in seen:
            raise ValueError(f"filter {name!r} is declared twice")
        seen.add(name)
        ftype = str(f.get("type") or "text")
        if ftype not in FILTER_TYPES:
            raise ValueError(f"filter {name!r}: type must be one of {', '.join(FILTER_TYPES)}")
        options = f.get("options") or []
        if not isinstance(options, list):
            raise ValueError(f"filter {name!r}: options must be a list")
        lov = f.get("lov")
        if lov is not None:
            try:
                lov = {"report_id": int(lov["report_id"]),
                       "parameter_id": int(lov["parameter_id"])}
            except (TypeError, KeyError, ValueError):
                raise ValueError(f"filter {name!r}: lov must be "
                                 f"{{report_id, parameter_id}} integers")
        if ftype == "select" and not options and not lov:
            raise ValueError(f"filter {name!r}: a select filter needs its options")
        out.append({
            "name": name,
            "label": str(f.get("label") or name),
            "type": ftype,
            "default": f.get("default"),
            "options": [str(o) for o in options],
            "lov": lov,
        })
    return out


def _placeholders_in_filters(filters: Optional[list]) -> List[str]:
    names: List[str] = []
    for f in filters or []:
        v = (f or {}).get("value") if isinstance(f, dict) else None
        if isinstance(v, str):
            m = PARAM_RE.fullmatch(v.strip())
            if m and m.group(1) not in names:
                names.append(m.group(1))
    return names


def declared_widget_params(db, widget: dict) -> List[dict]:
    """The parameters a tile's source declares, as
    ``[{name, label, type, required, default, options}]``.  A source that
    cannot be read declares nothing (the tile then runs as saved; its own
    failure is reported by the tile, not here)."""
    wtype = widget.get("widget_type")
    sid = widget.get("source_id")
    try:
        if wtype == "business_report":
            rows = db.list_report_parameters(int(sid)) or []
            # 2026-10-23 -- a saved list or a lookup, by THE rule of where a
            # parameter's choices come from (core/reports/param_values.py)
            from core.reports.param_values import plan as _values_plan

            def _reads(p):
                try:
                    return _values_plan(p).read
                except ValueError:
                    return "data"
            return [{
                "name": p.get("name"),
                "label": p.get("label") or p.get("name"),
                "type": p.get("parameter_type") or "text",
                "required": bool(p.get("is_required")),
                "default": p.get("default_value"),
                "options": (list(p.get("static_values") or [])
                            if _reads(p) == "static" else []),
                # values looked up from a column (data or metadata): the page
                # fetches them (POST /api/business-reports/{id}/parameter-values)
                # when it shows the input -- never on every dashboard GET
                "lov": ({"report_id": int(sid), "parameter_id": p.get("id")}
                        if _reads(p) in ("data", "metadata") else None),
            } for p in rows if p.get("name")]
        # FB-60 (2026-09-26): a legacy ``report`` tile declares nothing -- the
        # entity is decommissioned and the tile itself reports the refusal.
        if wtype == "saved_query":
            q = db.get_query(int(sid)) or {}
            cfg = q.get("query_config") or {}
            return [{"name": n, "label": n, "type": "text", "required": True,
                     "default": None, "options": []}
                    for n in _placeholders_in_filters(cfg.get("filters"))]
    except Exception:
        return []
    return []


def effective_widget_params(widget: dict, declared: List[dict],
                            filter_values: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The values a tile runs with: its own, then each dashboard filter value
    for a name it DECLARES (non-empty only).  Undeclared names never pass."""
    out = {k: v for k, v in (widget.get("param_values") or {}).items()}
    names = {p.get("name") for p in declared or []}
    for k, v in (filter_values or {}).items():
        if k in names and not _empty(v):
            out[k] = v
    return out


def default_filter_values(filters: Optional[list]) -> Dict[str, Any]:
    return {f["name"]: f.get("default") for f in (filters or [])
            if isinstance(f, dict) and f.get("name") and not _empty(f.get("default"))}
