"""
Iceberg Service — PyIceberg wrapper for reading Iceberg table metadata.

Uses StaticTable.from_metadata() to load tables directly from S3
without needing a Glue/Hive/REST catalog.  Provides:
  - Schema introspection (column names, types, partition spec)
  - Active data file listing (latest snapshot only — no orphans)
  - Row count from manifest metadata (no full scan needed)
"""

import logging
import os
import threading
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Guard env-var mutations from concurrent requests
_env_lock = threading.Lock()


@dataclass
class IcebergTableInfo:
    """Metadata about an Iceberg table from its latest snapshot."""

    schema: List[Dict[str, Any]]      # [{name, type, nullable, field_id}]
    partition_spec: List[Dict]         # [{name, transform, source_column}]
    data_files: List[Dict[str, Any]]   # [{file_path, size_bytes, record_count}]
    snapshot_id: Optional[int]
    total_records: int
    format_version: int


def _configure_pyiceberg_s3(conn_config: dict):
    """Temporarily set environment variables for PyIceberg S3 access.

    PyIceberg's StaticTable uses boto3 under the hood, which reads
    credentials from environment variables when no catalog is configured.
    We guard with a lock to avoid races between concurrent requests.

    Supports all auth modes: keys, profile, iam_role, assume_role.

    Accepts either the inner config dict (with aws_access_key_id etc.)
    or the full connection dict (with config nested inside "config" key).
    """
    # Normalize: if full connection dict passed (has nested "config"), extract it
    if "config" in conn_config and isinstance(conn_config["config"], dict):
        conn_config = conn_config["config"]

    # Clear previous credential env vars to prevent stale creds leaking
    for var in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
                "AWS_SESSION_TOKEN", "AWS_PROFILE"):
        os.environ.pop(var, None)

    # 2026-10-26 -- keys through THE credential chain (portal, a vault
    # system account, STS, a profile, the instance role -- all frozen to
    # keys for this one read) and endpoint / region through THE access
    # resolver.  This function carried its own STS copy, read the SAVED
    # region (``region_name``) straight into AWS_DEFAULT_REGION -- so the
    # catalog's Iceberg metadata read signed with the contradicted region
    # every DuckDB road had already corrected -- and exported the RAW
    # endpoint, never VPCE-normalised.
    from core.credential_resolver import resolve_s3_credentials
    from core.s3_access import resolve_s3_access
    resolved = resolve_s3_credentials(dict(conn_config))
    access = resolve_s3_access(resolved, proxy=False)
    if access.key:
        os.environ["AWS_ACCESS_KEY_ID"] = access.key
    if access.secret:
        os.environ["AWS_SECRET_ACCESS_KEY"] = access.secret
    if access.token:
        os.environ["AWS_SESSION_TOKEN"] = access.token
    if not access.key and (resolved.get("auth_mode") or "").lower() == "profile" \
            and resolved.get("aws_profile"):
        os.environ["AWS_PROFILE"] = resolved["aws_profile"]

    # Region -- the one every road signs with
    os.environ["AWS_DEFAULT_REGION"] = access.region

    # Custom endpoint (MinIO, a VPC endpoint), VPCE-normalised
    if access.endpoint_url:
        os.environ["AWS_S3_ENDPOINT"] = access.endpoint_url

    # SSL / CA bundle — PyIceberg uses boto3 which respects AWS_CA_BUNDLE
    ssl_verify = conn_config.get("ssl_verify", True)
    if ssl_verify is False or str(ssl_verify).lower() == "false":
        os.environ.pop("AWS_CA_BUNDLE", None)
        # PyIceberg doesn't have a direct "skip SSL" env var;
        # set REQUESTS_CA_BUNDLE to empty to disable (some versions honour this)
        os.environ["PYICEBERG_S3__VERIFY_SSL"] = "false"
    elif isinstance(ssl_verify, str) and ssl_verify.lower() not in ("true", "false"):
        # Explicit CA bundle path
        os.environ["AWS_CA_BUNDLE"] = ssl_verify
        os.environ.pop("PYICEBERG_S3__VERIFY_SSL", None)
    else:
        # Check for auto-detected CA bundle (same logic as s3_storage.py)
        from pathlib import Path
        default_bundle = Path(__file__).resolve().parent.parent / "certs" / "tls_bundle.pem"
        if default_bundle.exists():
            os.environ["AWS_CA_BUNDLE"] = str(default_bundle)
        else:
            os.environ.pop("AWS_CA_BUNDLE", None)
        os.environ.pop("PYICEBERG_S3__VERIFY_SSL", None)


def load_iceberg_table_info(
    bucket: str,
    table_prefix: str,
    conn_config: dict,
    row_filter=None,
) -> IcebergTableInfo:
    """Load Iceberg table metadata and active data files using PyIceberg.

    Args:
        bucket: S3 bucket name
        table_prefix: S3 prefix to the Iceberg table root (e.g. "warehouse/db/sales/")
        conn_config: Raw S3 connection config dict (for credentials)
        row_filter: Optional PyIceberg filter expression for partition pruning

    Returns:
        IcebergTableInfo with schema, data files, partition spec
    """
    from pyiceberg.table import StaticTable

    prefix = table_prefix.rstrip("/")
    table_uri = f"s3://{bucket}/{prefix}"

    with _env_lock:
        # Save original env vars to restore after PyIceberg call
        _saved_env = {}
        _env_keys = ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
                      "AWS_SESSION_TOKEN", "AWS_PROFILE", "AWS_DEFAULT_REGION",
                      "AWS_S3_ENDPOINT", "AWS_CA_BUNDLE", "PYICEBERG_S3__VERIFY_SSL")
        for _k in _env_keys:
            _saved_env[_k] = os.environ.get(_k)
        try:
            _configure_pyiceberg_s3(conn_config)
            table = StaticTable.from_metadata(table_uri)
        finally:
            # Restore original env vars
            for _k, _v in _saved_env.items():
                if _v is None:
                    os.environ.pop(_k, None)
                else:
                    os.environ[_k] = _v

    # ── Schema ────────────────────────────────────────────────────────
    schema_fields = []
    for field in table.schema().fields:
        schema_fields.append({
            "name": field.name,
            "type": str(field.field_type),
            "nullable": not field.required,
            "field_id": field.field_id,
        })

    # ── Partition spec ────────────────────────────────────────────────
    partition_info = []
    for pf in table.spec().fields:
        try:
            source_field = table.schema().find_field(pf.source_id)
            source_name = source_field.name
        except Exception:
            source_name = str(pf.source_id)
        partition_info.append({
            "name": pf.name,
            "transform": str(pf.transform),
            "source_column": source_name,
        })

    # ── Plan files (with optional partition pruning) ──────────────────
    scan = table.scan(row_filter=row_filter) if row_filter else table.scan()
    planned = list(scan.plan_files())

    data_files = []
    total_records = 0
    for task in planned:
        df = task.file
        total_records += df.record_count
        data_files.append({
            "file_path": df.file_path,
            "size_bytes": df.file_size_in_bytes,
            "record_count": df.record_count,
        })

    snapshot = table.current_snapshot()

    return IcebergTableInfo(
        schema=schema_fields,
        partition_spec=partition_info,
        data_files=data_files,
        snapshot_id=snapshot.snapshot_id if snapshot else None,
        total_records=total_records,
        format_version=table.metadata.format_version,
    )


def get_iceberg_schema(
    bucket: str, table_prefix: str, conn_config: dict
) -> dict:
    """Quick schema fetch for a registered Iceberg table.

    Returns dict with columns, row count, partition spec, snapshot info.
    """
    info = load_iceberg_table_info(bucket, table_prefix, conn_config)
    return {
        "table_name": table_prefix.rstrip("/").rsplit("/", 1)[-1],
        "format": "iceberg",
        "s3_prefix": table_prefix,
        "columns": info.schema,
        "num_rows": info.total_records,
        "partition_spec": info.partition_spec,
        "snapshot_id": info.snapshot_id,
        "format_version": info.format_version,
        "data_file_count": len(info.data_files),
    }


def get_iceberg_active_files(
    bucket: str, table_prefix: str, conn_config: dict
) -> List[str]:
    """Return S3 URIs for active parquet files from the latest snapshot.

    Only files that are part of the current snapshot are returned —
    no orphaned files, no deleted-but-not-vacuumed files.
    """
    info = load_iceberg_table_info(bucket, table_prefix, conn_config)
    paths = []
    for df in info.data_files:
        fp = df["file_path"]
        # Normalize various URI schemes to s3://
        if fp.startswith("s3://") or fp.startswith("s3a://") or fp.startswith("s3n://"):
            # Rewrite s3a/s3n → s3
            fp = "s3://" + fp.split("://", 1)[1]
        else:
            fp = f"s3://{bucket}/{fp.lstrip('/')}"
        paths.append(fp)
    logger.info(
        "Iceberg table %s/%s: %d active files, %d total records",
        bucket, table_prefix, len(paths), info.total_records,
    )
    return paths
