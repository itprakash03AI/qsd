"""Try a published API AS one of its consumers (2026-10-24, the owner's plan
item 5: "the explorer can run as a chosen consumer key, so the tester sees
what that consumer sees").

NOT ``core.crypto.encrypt_value`` / ``decrypt_value``: those pass an
unprefixed string THROUGH (and encrypt_value stores plaintext when the
cryptography package is absent) -- right for a stored credential, fatal for a
bearer token: "qstry_" + hand-written JSON would have read as valid.  And NOT
the credential Fernet either (security review, same day): anyone who can get
a chosen text encrypted by it -- a credential field -- could have minted a
token.  The token key is DERIVED for this one purpose, HMAC-SHA256(master,
"qs-try-as-v1"), from the master every component shares; the payload carries
``typ`` and Fernet's own timestamp bounds the age as well as ``exp``.  No
master here = no token, refused (fail closed).

An admin cannot hold a consumer's raw key -- only its hash is stored -- so
the API Explorer used to run a "chosen" key as the ADMIN's own session: the
answer was the admin's rows under the consumer's name.  Now the admin asks
for a TRY-AS token for one key (``mint``): a short-lived, authenticated
token (``core.crypto`` -- the master every component shares, so the
published-api pod verifies what the main API minted) naming the key, the
admin and an expiry.  The Explorer calls the REAL endpoint with it in
``X-QS-Try-As``; the published-API door (``api.deps``) turns it into
exactly the principal that key gets (``api.deps.api_key_principal`` -- ONE
construction for the key and its try-as), so the key's scope, row security,
rate limit, lifecycle refusals and call record all apply as for the
consumer.  The principal carries ``tried_by`` so the trial is attributable.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any, Dict

PREFIX = "qstry_"
#: the purpose the token key is derived for -- never the credential key
_PURPOSE = b"qs-try-as-v1"
_TYP = "qs-try-as"
#: how long a try-as token lives -- a test session, not a credential
TTL_SECONDS = 300


class TryAsRefused(ValueError):
    """The token cannot be used -- the message says why."""


def _fernet():
    from core import crypto
    try:
        primary, _source, _previous = crypto._key_material()
    except Exception:
        primary = None
    if not primary:
        raise TryAsRefused("this component has no encryption key, so it can neither mint nor "
                           "verify a try-as token")
    from cryptography.fernet import Fernet
    derived = hmac.new(str(primary).encode(), _PURPOSE, hashlib.sha256).digest()
    return Fernet(base64.urlsafe_b64encode(derived))


def mint(api_key_id: int, admin_username: str, *, now: float | None = None,
         ttl: int = TTL_SECONDS) -> Dict[str, Any]:
    exp = int((now if now is not None else time.time()) + ttl)
    payload = json.dumps({"typ": _TYP, "k": int(api_key_id), "by": str(admin_username), "exp": exp},
                         separators=(",", ":"))
    token = _fernet().encrypt(payload.encode()).decode()
    return {"token": PREFIX + token, "expires_at": exp, "ttl_seconds": ttl}


def read(token: str, *, now: float | None = None) -> Dict[str, Any]:
    """The token's claims, or ``TryAsRefused`` (tampered, expired, malformed)."""
    if not isinstance(token, str) or not token.startswith(PREFIX):
        raise TryAsRefused("not a try-as token")
    f = _fernet()
    try:
        # Fernet's own timestamp bounds the age too (a payload cannot choose it)
        claims = json.loads(f.decrypt(token[len(PREFIX):].encode(), ttl=TTL_SECONDS + 60).decode())
        if claims.get("typ") != _TYP:
            raise ValueError("wrong purpose")
        key_id, by, exp = int(claims["k"]), str(claims["by"]), int(claims["exp"])
    except Exception:
        raise TryAsRefused("the try-as token is not valid (tampered, or minted with another key)")
    if (now if now is not None else time.time()) > exp:
        raise TryAsRefused("the try-as token has expired -- ask for a new one")
    return {"api_key_id": key_id, "tried_by": by, "expires_at": exp}
