"""The inventory's numbers from the call record (2026-10-17).

``inventory_numbers``: ``(api_kind, api_id) -> {"last_call_at", "calls_7d"}``
in ONE GROUP BY over ``api_access_log``.  Rows written before 2026-10-17
carry no ``api_kind``: a row with a ``view_id`` is a published_view call --
the only kind that wrote rows then -- so history is not lost.  The rollup
(core/published_api/rollup.py) answers the same question from its buckets
once it exists; this module is the raw-row reader both the inventory (the
tail newer than the watermark) and the detail route use.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import text


def inventory_numbers(db, *, days: int = 7) -> Dict[tuple, Dict[str, Any]]:
    """Last call and calls in the last ``days`` per API: the ROLLUPS up to
    their watermark (indexed buckets) plus the raw-row TAIL newer than it --
    the newer answer wins, the counts add.  With no rollup yet (a fresh
    install, the daemon not yet run) every row is raw."""
    from core.published_api.rollup import numbers_from_rollups
    rolled, tail_since = numbers_from_rollups(db, days=days)
    raw = raw_numbers(db, days=days, since=tail_since)
    out: Dict[tuple, Dict[str, Any]] = {k: dict(v) for k, v in rolled.items()}
    for key, r in raw.items():
        cur = out.get(key)
        if cur is None:
            out[key] = dict(r)
            continue
        cur["calls_7d"] = int(cur.get("calls_7d") or 0) + int(r.get("calls_7d") or 0)
        if r.get("last_call_at") and (not cur.get("last_call_at") or r["last_call_at"] > cur["last_call_at"]):
            cur["last_call_at"] = r["last_call_at"]
    return out


def raw_numbers(db, *, days: int = 7, since: Optional[datetime] = None) -> Dict[tuple, Dict[str, Any]]:
    """The raw-row leg: last call and calls in the last ``days`` per API over
    rows newer than ``since`` (default: every row), one GROUP BY."""
    # THE published-API clock (rollup._utcnow): the rollup leg of the same
    # "last 7 days" reads it, so the two legs cannot disagree on the window
    from core.published_api.rollup import _utcnow
    now = _utcnow()
    cutoff = now - timedelta(days=int(days))
    sql = ("SELECT COALESCE(api_kind, 'published_view') AS k, COALESCE(api_id, view_id) AS i, "
           "MAX(created_at) AS last_at, "
           "SUM(CASE WHEN created_at >= :cutoff THEN 1 ELSE 0 END) AS n7 "
           "FROM api_access_log WHERE COALESCE(api_id, view_id) IS NOT NULL ")
    params: Dict[str, Any] = {"cutoff": cutoff.replace(tzinfo=None)}
    if since is not None:
        sql += "AND created_at > :since "
        params["since"] = since.replace(tzinfo=None) if since.tzinfo else since
    sql += "GROUP BY COALESCE(api_kind, 'published_view'), COALESCE(api_id, view_id)"
    out: Dict[tuple, Dict[str, Any]] = {}
    with db.engine.connect() as conn:
        for k, i, last_at, n7 in conn.execute(text(sql), params).fetchall():
            if i is None:
                continue
            la = last_at
            if isinstance(la, str):
                try:
                    la = datetime.fromisoformat(la)
                except ValueError:
                    la = None
            if isinstance(la, datetime) and la.tzinfo is None:
                la = la.replace(tzinfo=timezone.utc)
            out[(str(k), int(i))] = {"last_call_at": la.isoformat() if isinstance(la, datetime) else None,
                                     "calls_7d": int(n7 or 0)}
    return out


def recent_calls(db, api_kind: str, api_id: int, *, limit: int = 100, status: Optional[int] = None,
                 consumer: Optional[str] = None, since: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """The raw rows of one API, newest first (the drill-down)."""
    from core.db.models import ApiAccessLog as A
    with db.get_session(read_only=True) as session:
        from sqlalchemy import or_
        q = session.query(A)
        if api_kind == "published_view":
            q = q.filter(or_(A.api_id == int(api_id), (A.api_id.is_(None)) & (A.view_id == int(api_id))))
            q = q.filter(or_(A.api_kind == api_kind, A.api_kind.is_(None)))
        else:
            q = q.filter(A.api_kind == api_kind, A.api_id == int(api_id))
        if status is not None:
            q = q.filter(A.status_code == int(status))
        if consumer:
            q = q.filter(A.consumer == str(consumer))
        if since is not None:
            q = q.filter(A.created_at >= (since.replace(tzinfo=None) if since.tzinfo else since))
        rows = q.order_by(A.id.desc()).limit(max(1, min(int(limit), 1000))).all()
        return [r.to_dict() for r in rows]


__all__ = ["inventory_numbers", "raw_numbers", "recent_calls"]
