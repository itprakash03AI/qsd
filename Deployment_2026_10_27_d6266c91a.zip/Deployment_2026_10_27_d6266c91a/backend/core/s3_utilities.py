"""
S3 utility functions — file listing, pre-signed URLs, hive partition extraction,
partition pruning, and S3 client factory.

Extracted from main.py for maintainability.

Usage:
    from core.s3_utilities import init_s3_utilities, list_s3_parquet_files, ...
    init_s3_utilities(conn_manager)   # call once at startup
"""
from __future__ import annotations

import logging
import time
from typing import Any, List, Optional
from urllib.parse import urlparse, unquote, urlunparse

logger = logging.getLogger(__name__)


class S3AccessDeniedError(Exception):
    """Raised when boto3 returns AccessDenied on an S3 prefix (Phase 78F)."""
    def __init__(self, message: str, prefix: str = ""):
        super().__init__(message)
        self.prefix = prefix


# ── Module-level dependency (set via init_s3_utilities) ──────────────────────
_conn_manager = None


def init_s3_utilities(conn_manager):
    """Inject the connection manager for S3 client factory."""
    global _conn_manager
    _conn_manager = conn_manager


# ── S3 access mode ──────────────────────────────────────────────────────────

def get_s3_access_mode(conn_config: dict) -> str:
    """Determine whether DuckDB should use native S3 credentials or pre-signed URLs.

    Returns 'native' or 'presigned'.

    2026-09-26 -- an ALIAS.  The decision lives in
    ``core.s3_access.access_mode_for`` (the ONE S3-access resolver, F2 of the
    2026-09-26 brief); this name stays for its callers and the tests that
    patch it.  Read that function for the rules (explicit override, VPC
    endpoints forced native, AWS native, on-prem path-style defaulting to
    ``s3.default_onprem_access_mode``).
    """
    from core.s3_access import access_mode_for
    return access_mode_for(conn_config)


# ── Parallel download config ──────────────────────────────────────────────

def _parallel_workers() -> int:
    """Return number of parallel S3 download workers from config.

    Honours ``s3.parallel_download_workers`` literally.  Operators
    who need a tighter ceiling on small pods set ``workers_per_cpu``
    (oversubscription multiplier) in config -- DEFAULT 0 means no
    clamping (preserves prior behaviour; no hidden CPU heuristics).
    """
    import os as _os
    try:
        from core.config import s3 as _s3_cfg
        configured = int(_s3_cfg.parallel_download_workers)
        per_cpu = float(getattr(_s3_cfg, "workers_per_cpu", 0) or 0)
        per_cpu_min = int(getattr(_s3_cfg, "workers_per_cpu_min", 2) or 2)
    except Exception:
        configured, per_cpu, per_cpu_min = 8, 0.0, 2
    # No clamp by default -- config says what config says.
    if per_cpu <= 0:
        return max(1, configured)
    # Operator opted into the cap; compute it from cgroup CPU quota.
    try:
        from core.duckdb_resource_limits import _read_cgroup_cpu_quota
        cpus = _read_cgroup_cpu_quota() or float(_os.cpu_count() or 1)
    except Exception:
        cpus = float(_os.cpu_count() or 1)
    cpu_ceiling = max(per_cpu_min, int(round(cpus * per_cpu)))
    return max(1, min(configured, cpu_ceiling))


# ── Hive partition helpers ───────────────────────────────────────────────────

def extract_hive_parts(path_str):
    """Extract hive partition key=value pairs from a path, excluding the filename.

    For 's3://bucket/data/year=2024/month=01/file.parquet' returns {'year':'2024','month':'01'}.
    Excludes the last segment (filename) to avoid misinterpreting filenames with '='.
    Skips protocol prefix segments (e.g. 's3:').

    BF-PRUNING-AUDIT-D2: URL-decode the value so partitions like
    'col=hello%20world' compare correctly against literal
    'hello world'.  Spark/Iceberg writers URL-encode partition values
    that contain reserved chars (space, /, =, %).
    """
    segments = path_str.split("/")
    # Exclude last segment (the filename, e.g. 'data.parquet')
    dirs = segments[:-1] if len(segments) > 1 else []
    parts = {}
    for seg in dirs:
        if "=" in seg and not seg.endswith(":"):  # skip 's3:'
            k, v = seg.split("=", 1)
            try:
                parts[k] = unquote(v)
            except Exception:
                parts[k] = v
    return parts


_RANGE_OPS = ("greater_than", "less_than", "greater_equals", "less_equals")


def _verdict_satisfies(op: str, c: int) -> bool:
    """Does one comparison verdict (-1/0/1) satisfy ``op``?"""
    if op == "greater_than":
        return c > 0
    if op == "greater_equals":
        return c >= 0
    if op == "less_than":
        return c < 0
    return c <= 0                                    # less_equals


def _all_readings_agree(fv, val, op: str) -> bool:
    """EXCLUSION policy — true only when EVERY viable reading satisfies ``op``.

    2026-08-19.  A caller that DROPS on a True cannot use "satisfiable under
    SOME reading": two separate bound comparisons can be satisfied by
    DIFFERENT readings and jointly justify a drop no single consistent reading
    supports.  Verified before this existed: partition ``v=10`` with
    ``v NOT BETWEEN '9' AND '9z'`` — ``ge`` True from the NUMERIC reading
    (10 >= 9), ``le`` True from the LEXICAL one (``float('9z')`` fails, so
    ``'10' <= '9z'``) — and the file was dropped though its value is outside
    [lo, hi] under either reading taken consistently.

    An incomparable pair returns False, i.e. contributes no drop.
    """
    try:
        from core.predicate_coerce import _candidates as _cands_all
        cands = _cands_all(fv, val)
    except Exception:                                # pragma: no cover
        return False
    return bool(cands) and all(_verdict_satisfies(op, c) for c in cands)


def _any_reading_satisfies(fv, val, op: str) -> bool:
    """INCLUSION policy — true when ANY viable reading satisfies ``op``.

    Consulted only when the strict string compare would DROP, so it can widen
    a verdict and never narrow one.  A hive token is a DATE
    (``dt=2026-08-19``) while a SQL literal is often a TIMESTAMP
    (``2026-08-19 00:00:00``), and ``'2026-08-19' >= '2026-08-19 00:00:00'``
    is False in string order because the shorter string is a prefix.  That
    dropped the boundary partition from every ``BETWEEN`` whose lower edge
    carried a time part: measured on tokens 18/19/20 with
    ``BETWEEN '2026-08-19 00:00:00' AND '2026-08-20 23:59:59'``, 1 of 3 files
    survived and the 19th vanished.

    Note the public ``le``/``lt`` helpers are keep-oriented for THEIR callers,
    so negating them would invert the fail-open direction; the candidate set
    is used directly instead.  An incomparable pair returns True (keep).
    """
    try:
        from core.predicate_coerce import _candidates as _cands_any
        cands = _cands_any(fv, val)
    except Exception:                                # pragma: no cover
        return False
    if not cands:
        return True                                  # incomparable -> keep
    return any(_verdict_satisfies(op, c) for c in cands)


def _numeric_verdict(fv, val, op: str):
    """``op`` under the NUMERIC reading, or None when either side isn't."""
    try:
        fv_num = float(fv)
        val_num = float(val)
    except (ValueError, TypeError):
        return None
    if fv_num == fv_num and val_num == val_num:      # reject NaN
        return _verdict_satisfies(op, (fv_num > val_num) - (fv_num < val_num))
    return None


def _smart_compare(fv: str, val, op: str, *, widen: bool = True) -> bool:
    """Compare a partition value with a filter value, auto-detecting type.

    Numeric reading first (so ``month=10 > month=5`` is true), then the raw
    string comparison, then — for inclusion callers only — the union of
    readings.

    ``widen`` (2026-08-19) selects the POLICY, and the choice is the whole
    safety property here:

      * ``True``  (``between``, plain ranges) — a softened True only ever
        KEEPS a file, so widening on doubt is free.
      * ``False`` (``not_between``) — a True DROPS the file, so every viable
        reading must agree.  See :func:`_all_readings_agree`.
    """
    if op not in _RANGE_OPS:
        # Unknown operator — include file (safe default), but log warning
        return _unknown_op(fv, val, op)

    if not widen:
        return _all_readings_agree(fv, val, op)

    numeric = _numeric_verdict(fv, val, op)
    if numeric is not None:
        return numeric

    if _verdict_satisfies(op, (str(fv) > str(val)) - (str(fv) < str(val))):
        return True
    return _any_reading_satisfies(fv, val, op)


def _hive_range_keeps(fv, val, op: str, literal_kind=None) -> bool:
    """INCLUSION verdict for one range comparison of a hive path token:
    True = the file may hold a matching row (KEEP).

    2026-10-06.  A hive partition column has NO declared type: DuckDB's
    ``hive_types_autocast`` types it from the values of the files it is
    handed, so ``code > '50'`` is a STRING comparison when 'SAP' is among
    them and a NUMERIC one when it is not.  ``_smart_compare`` returned the
    numeric verdict outright whenever both sides parsed, which DROPPED
    ``code=6`` for ``code > '50'`` -- a row the string comparison keeps.
    The decision is the ONE every pruner asks for a range on a string /
    undeclared partition (``core.filter_ops.string_partition_range_
    decision``, the island carver's rule): a token may be dropped only when
    every reading agrees -- or, for a NUMBER literal (``literal_kind``),
    when the numeric reading says so."""
    from core.filter_ops import string_partition_range_decision as _spd
    return not _spd(None, op, val, fv, fv, literal_kind=literal_kind).drop


def _unknown_op(fv, val, op: str) -> bool:
    # Unknown operator — include file (safe default), but log warning
    logger.warning("_smart_compare: unexpected operator '%s' — defaulting to include file", op)
    return True


def normalize_partition_filters(partition_filters):
    """Single chokepoint for hive-path filter normalisation.

    * Strips table qualifiers (``sales.business_date`` → ``business_date``)
      and lower-cases the column so it matches hive segment keys.
    * Canonicalises exact operator SYNONYMS (``=``/``eq`` → ``equals``,
      ``>=`` → ``greater_equals``, …) so every hive-path consumer — the
      post-listing pruner AND the island prefix planner — evaluates the
      same predicate identically.  ONLY exact synonyms are mapped (the
      reader's own funnel already treats each group as one operator);
      unknown operators pass through unchanged and fall open downstream.

    Used by ``filter_iceberg_files_by_partitions``,
    ``core.island_prefix_planner`` and the iceberg reader's island-scoped
    metadata loads.  Do NOT fork this logic — a drift between the planner
    (which selects prefixes to LIST) and the pruner (which drops files)
    would break the planner's superset-coverage proof.
    """
    _OP_SYNONYMS = {
        "=": "equals", "==": "equals", "eq": "equals",
        "!=": "not_equals", "ne": "not_equals",
        ">": "greater_than", "gt": "greater_than",
        "<": "less_than", "lt": "less_than",
        ">=": "greater_equals", "gte": "greater_equals",
        "<=": "less_equals", "lte": "less_equals",
        "nin": "not_in",
        "isnull": "is_null", "isnotnull": "is_not_null",
        "not_null": "is_not_null", "starts_with": "like_prefix",
    }
    _normalized = []
    for pf in (partition_filters or []):
        if not isinstance(pf, dict) or not pf.get("col"):
            _normalized.append(pf)
            continue
        col = pf["col"]
        bare_col = col.split(".")[-1] if "." in col else col
        op = pf.get("op")
        op = _OP_SYNONYMS.get(op, op)
        _normalized.append({**pf, "col": bare_col.lower(), "op": op})
    return _normalized


def hive_parts_could_match(parts_lower: dict, normalized_filters: list) -> bool:
    """Chokepoint predicate: can a file whose hive path segments are
    ``parts_lower`` (lower-cased keys, URL-decoded values) possibly contain
    a row matching every filter?

    Returns False ONLY when at least one filter provably excludes every row
    (the file's single partition value for that column fails the predicate).
    Any filter whose column is absent from the path, whose operator is
    unknown, or whose value is malformed contributes NO constraint
    (fail-open).  This is the EXACT per-file loop previously inline in
    ``filter_iceberg_files_by_partitions`` — extracted so the island prefix
    planner selects LIST prefixes with byte-identical semantics (a prefix
    is dropped only when this function would drop every file under it).
    """
    for pf in normalized_filters:
        if not isinstance(pf, dict) or not pf.get("col"):
            continue
        col = pf["col"]   # already lower-cased
        if col not in parts_lower:
            continue
        fv = parts_lower[col]
        op = pf.get("op")
        val = pf.get("val")
        if op == "equals" and str(fv) != str(val):
            # 2026-07-31 DATA-LOSS FIX (family C).  Plain string inequality
            # has ZERO reconciliation, so an ISO hive segment
            # ('2025-09-30') vs a non-ISO literal ('30 sep 2025') pruned
            # EVERY file including the matching one (executed: 0 of 3
            # survived).  ``_temporal_keep`` only ever PREVENTS this prune;
            # inclusion-only, so it cannot drop a matching file.
            # 2026-08-19 — and the NUMERIC reconciliation, same keep-only
            # contract: 'month=01' vs a filter of 1 is the same month, and
            # exact string compare alone returned ZERO ROWS for it.
            if not (_temporal_keep(fv, val) or _numeric_keep(fv, val)
                    or _bool_keep(fv, val)):
                return False
        elif op == "not_equals" and str(fv) == str(val):
            # EXCLUSION — deliberately NOT widened.  Treating two spellings
            # as equal here would DROP a file, which is the failure mode
            # this whole fix exists to prevent.
            return False
        elif op == "in" and str(fv) not in [str(v) for v in val]:
            _cands = val if isinstance(val, (list, tuple)) else [val]
            if not any(_temporal_keep(fv, v) or _numeric_keep(fv, v)
                       or _bool_keep(fv, v) for v in _cands):
                return False
        elif op == "not_in":
            # JOIN-PRUNER (2026-06-01 deep-audit round 7) — hive-path
            # NOT IN: prune file when its hive segment value IS in
            # the excluded list (file provably has only that value
            # for the partition column, so no row can satisfy NOT IN).
            if not isinstance(val, (list, tuple)):
                continue  # malformed → fail-open
            if str(fv) in [str(v) for v in val]:
                return False
        elif op == "not_between":
            # NOT BETWEEN low AND high: prune file when its hive
            # segment value falls IN [low, high] (every row in the
            # file is inside [low, high] → no row satisfies NOT
            # BETWEEN).  Same semantics as the column-stats reader.
            if not isinstance(val, (list, tuple)) or len(val) != 2:
                continue  # malformed → fail-open
            _nb_lo, _nb_hi = val
            if _nb_lo is None or _nb_hi is None:
                continue
            # Numeric/lexical compare via _smart_compare: fv ≥ lo AND fv ≤ hi
            # means file is entirely inside [lo, hi] → drop it.
            # widen=False: this is the ONE exclusion caller.  Here a True
            # from _smart_compare DROPS the file, and the widening answers
            # "satisfiable under SOME reading" — two calls could be satisfied
            # by DIFFERENT readings, which would drop a file no single
            # consistent reading places inside [lo, hi].  Widening is for
            # inclusion only; keeping a file here is the safe direction.
            if (_smart_compare(fv, _nb_lo, "greater_equals", widen=False)
                    and _smart_compare(fv, _nb_hi, "less_equals",
                                        widen=False)):
                return False
        elif op == "between":
            # JOIN-PRUNER (2026-06-01) — hive-path BETWEEN: keep file
            # when its segment value falls in [lo, hi].
            if not isinstance(val, (list, tuple)) or len(val) != 2:
                continue  # malformed → fail-open
            lo_v, hi_v = val
            if lo_v is None or hi_v is None:
                continue
            _lk = pf.get("literal_kind")
            if not _hive_range_keeps(fv, lo_v, "greater_equals", _lk):
                return False
            if not _hive_range_keeps(fv, hi_v, "less_equals", _lk):
                return False
        elif op in ("greater_than", "less_than", "greater_equals", "less_equals"):
            if not _hive_range_keeps(fv, val, op, pf.get("literal_kind")):
                return False
        elif op in ("like_prefix", "starts_with"):
            # Hive segments are single values per file, so "starts
            # with" is the same as "equals when truncated".
            if not isinstance(val, str) or not val:
                continue  # malformed / empty prefix → fail-open
            _prefix = val[:-1] if val.endswith("%") else val
            if not _prefix:
                continue  # "match anything" → fail-open
            # 2026-08-20 DATA-LOSS FIX: raw byte ``startswith`` had no
            # keep-side bridge (unlike the temporal/numeric/bool bridges
            # of its ``equals``/``in`` siblings), so a case-insensitively
            # extracted prefix ('apac' from ``LOWER(region) LIKE
            # 'apac%'``) pruned a segment spelled 'APAC1' — and this
            # helper also feeds the island prefix planner, so the
            # matching files were never even LISTED.  The case-folded
            # retry is keep-only widening: it can only PREVENT a prune,
            # never cause one — same contract as _temporal_keep.
            if (not str(fv).startswith(_prefix)
                    and not str(fv).casefold().startswith(
                        _prefix.casefold())):
                return False
        elif op in ("is_null", "isnull"):
            # Hive partition values are non-null by construction
            # (the segment IS the value); a NULL partition would
            # be `col=__HIVE_DEFAULT_PARTITION__` or similar.  If
            # the segment value is present and non-default, no row
            # in this file has NULL for the partition column → prune.
            _NULL_SENTINELS = {"__HIVE_DEFAULT_PARTITION__", "null", "NULL", ""}
            if str(fv) not in _NULL_SENTINELS:
                return False
        elif op in ("is_not_null", "isnotnull", "not_null"):
            # File's segment IS null/default → no row has non-null
            # value for partition column → prune.
            _NULL_SENTINELS = {"__HIVE_DEFAULT_PARTITION__", "null", "NULL", ""}
            if str(fv) in _NULL_SENTINELS:
                return False
    return True


def filter_iceberg_files_by_partitions(data_files, partition_filters, or_groups=None):
    """Filter Iceberg data files by partition values found in S3 key paths.

    Each file key has hive-style paths like .../year=2024/month=01/file.parquet.
    Matches query filters against those partition segments.

    2026-10-08 -- a DISJUNCTION (``or_groups`` = ``[[branch dicts], ...]``,
    or ONE inline ``{"op": "or", "or": [...]}`` group in
    ``partition_filters``) keeps a file that survives the AND-ed conjuncts
    AND any branch -- the union of per-branch islands -- but ONLY under
    ``core.filter_ops.disjunction_decision`` (every branch must carry a
    decidable predicate on a column this tree is partitioned by).  Declined
    = the AND-ed conjuncts alone prune (a superset), and the verdict is
    logged.  Before this, ANY OR made the pruner return every file -- even
    the AND conjuncts were not applied.
    """
    if not data_files:
        return data_files
    from core.filter_ops import (
        disjunction_decision as _disj, split_or_groups as _split_or)
    partition_filters, _or_groups = _split_or(partition_filters, or_groups)
    if not partition_filters and not _or_groups:
        return data_files

    # Phase 139 audit-fix Gap 8: detect hive partition columns by scanning
    # MORE than just the first 5 files. Buckets with mixed root-level files
    # (schema.parquet, _SUCCESS, .crc) followed by partition-prefix files
    # used to fail to detect partitions when the first 5 happened to be
    # root-level. Scan up to 50 files AND collect the UNION of partition
    # column sets across them — different hive layouts at different prefixes
    # are then merged so the filter check can match any of them.
    _partition_cols_lower: dict = {}
    _partition_cols: set = set()
    _MAX_SAMPLE = 50
    _sample_count = min(_MAX_SAMPLE, len(data_files))
    _samples_with_parts = 0
    for _si in range(_sample_count):
        _sample_key = data_files[_si]["key"] if isinstance(data_files[_si], dict) else data_files[_si]
        _raw_parts = extract_hive_parts(_sample_key)
        if _raw_parts:
            _samples_with_parts += 1
            for _k in _raw_parts.keys():
                _partition_cols_lower[_k.lower()] = _k
                _partition_cols.add(_k)
            # Once we have 5+ samples with parts, the union is stable enough
            if _samples_with_parts >= 5:
                break

    # Strip table-qualified prefixes from filter column names so
    # "sales_table.business_close_date" matches hive path segment "business_close_date".
    # Also normalise to lower-case so "Business_Date" filter matches "business_date" partition.
    _normalized_filters = normalize_partition_filters(partition_filters)

    # THE disjunction decision, asked with the columns THIS tree is
    # partitioned by (the sampled path keys).  Applies -> per-branch union;
    # declined -> the AND conjuncts alone, and the reason is on the log.
    _disj_branches: list = []
    if _or_groups:
        _dd = _disj(_or_groups, partition_columns=set(_partition_cols_lower))
        if _dd.applies:
            _disj_branches = [normalize_partition_filters(list(b)) for b in _dd.branches]
            logger.info(
                "[island] hive-path disjunction ENGAGED: %d branch(es) over "
                "partition col(s) %s -- a file survives the AND conjuncts and "
                "ANY branch (the union of per-branch islands)",
                _dd.n_branches, sorted(_partition_cols))
        else:
            logger.info(
                "[island] hive-path disjunction DECLINED (%s: %s) -- %d OR "
                "branch(es) not applied; the %d AND conjunct(s) alone prune, "
                "DuckDB applies the WHERE exactly",
                _dd.reason, _dd.reason_text,
                sum(len(g) for g in _or_groups), len(_normalized_filters))

    _filter_hits_partition = any(
        pf["col"] in _partition_cols_lower
        for pf in _normalized_filters + [d for b in _disj_branches for d in b]
        if isinstance(pf, dict) and pf.get("col"))

    if not _filter_hits_partition:
        # None of the query filters match partition columns — skip pruning entirely
        logger.info("Partition pruning: filter col(s) %s do NOT match partition col(s) %s "
                    "— returning all %d files (no pruning)",
                    [pf["col"] for pf in _normalized_filters if isinstance(pf, dict) and pf.get("col")],
                    sorted(_partition_cols), len(data_files))
        return data_files

    filtered = []
    for f in data_files:
        key = f["key"] if isinstance(f, dict) else f
        parts = extract_hive_parts(key)
        # Case-insensitive lookup: filter col → actual partition path value
        parts_lower = {k.lower(): v for k, v in parts.items()}
        # Per-file verdict via the shared chokepoint (see
        # hive_parts_could_match) so this pruner and the island prefix
        # planner can never drift apart.  A disjunction keeps the file when
        # ANY branch could match it (each branch judged by the same
        # chokepoint) -- the union of the per-branch islands.
        if not hive_parts_could_match(parts_lower, _normalized_filters):
            continue
        if _disj_branches and not any(
                hive_parts_could_match(parts_lower, _b) for _b in _disj_branches):
            continue
        filtered.append(f)

    _matched_filter_cols = [pf["col"] for pf in _normalized_filters if pf["col"] in _partition_cols_lower]
    if not filtered:
        logger.info("Partition pruning: 0/%d files match filter on partition column(s) %s — "
                     "no data exists for the requested values",
                     len(data_files), _matched_filter_cols)
        return []

    logger.info("Partition pruning: %d/%d files match filters on %s",
                 len(filtered), len(data_files), _matched_filter_cols)
    return filtered


def extract_partition_filters_from_query(query_config):
    """Extract partition filter dicts from a query config's filters list.

    Returns (filters, warnings) where:
    - filters: list of filter dicts (or None if no supported filters)
    - warnings: list of warning dicts for unsupported operators (78E)

    Callers that don't need warnings can still use the first element:
        filters = extract_partition_filters_from_query(cfg)[0]
    """
    if not query_config or not hasattr(query_config, "filters") or not query_config.filters:
        return None, []
    # 2026-06-18 -- mirror EVERY operator the downstream pruner supports
    # (see core/parquet_pruning.py:_OP_MAP + iceberg_reader / join_pruner).
    # Anything in this map gets forwarded to the pruner; anything NOT in
    # this map gets dropped + a warning.  The pruner is the source of
    # truth for what it can prune -- extraction must not gatekeep
    # narrower than the pruner accepts (the old map only knew six
    # operators, so BQB's `between` date-range -- the most common
    # partition filter! -- was silently dropped, producing a full scan
    # the user perceived as "brain is slow even with partition column
    # in WHERE").
    _OP_MAP = {
        "equals": "equals", "eq": "equals", "=": "equals",
        "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
        "greater_than": "greater_than", "gt": "greater_than", ">": "greater_than",
        "less_than": "less_than", "lt": "less_than", "<": "less_than",
        "greater_equals": "greater_equals", "gte": "greater_equals", ">=": "greater_equals",
        "less_equals": "less_equals", "lte": "less_equals", "<=": "less_equals",
        # Multi-value / range operators.  Validated below before adding to pf.
        "in": "in", "IN": "in",
        "not_in": "not_in", "NOT IN": "not_in", "nin": "not_in",
        "between": "between", "BETWEEN": "between",
        "not_between": "not_between", "NOT BETWEEN": "not_between",
        # Prefix match (pruner uses min/max bound trick).
        "starts_with": "starts_with", "STARTS_WITH": "starts_with",
        "like_prefix": "starts_with", "LIKE_PREFIX": "starts_with",
        # Null-only operators -- no value needed; pruner reads null_count.
        "is_null": "is_null", "isnull": "is_null", "IS NULL": "is_null",
        "is_not_null": "is_not_null", "isnotnull": "is_not_null",
        "IS NOT NULL": "is_not_null", "not_null": "is_not_null",
    }
    _NULL_ONLY_OPS = {"is_null", "is_not_null"}
    _LIST_OPS = {"in", "not_in"}
    _RANGE_OPS = {"between", "not_between"}
    pf = []
    warnings = []
    from core.config import s3_validation as _sv
    for flt in query_config.filters:
        f_op = flt["operator"] if isinstance(flt, dict) else flt.operator
        f_col = flt["column"] if isinstance(flt, dict) else flt.column
        f_val = flt["value"] if isinstance(flt, dict) else flt.value
        mapped = _OP_MAP.get(f_op)
        if not mapped:
            # Unsupported operator (e.g. `contains` / `not_contains` --
            # min/max bounds can't prove anything for substring match).
            # Warn so caller can surface to user.
            if _sv.warn_unsupported_partition_ops:
                warnings.append({
                    "col": f_col,
                    "op": f_op,
                    "message": (
                        f"Operator '{f_op}' on column '{f_col}' is not supported "
                        f"for partition pruning -- all partition files will be "
                        f"scanned for this predicate."
                    ),
                })
            continue
        # Null-only operators carry no value -- forward as-is.
        if mapped in _NULL_ONLY_OPS:
            pf.append({"col": f_col, "op": mapped, "val": None})
            continue
        # IN / NOT IN need a non-empty list.
        if mapped in _LIST_OPS:
            if isinstance(f_val, list) and len(f_val) > 0:
                pf.append({"col": f_col, "op": mapped, "val": f_val})
            else:
                if _sv.warn_unsupported_partition_ops:
                    warnings.append({
                        "col": f_col, "op": f_op,
                        "message": (
                            f"Operator '{f_op}' on column '{f_col}' needs a "
                            f"non-empty list value; got {type(f_val).__name__} "
                            f"-- partition pruning skipped for this predicate."
                        ),
                    })
            continue
        # BETWEEN / NOT BETWEEN need a 2-element [lo, hi] list/tuple.
        if mapped in _RANGE_OPS:
            if isinstance(f_val, (list, tuple)) and len(f_val) == 2 \
               and f_val[0] is not None and f_val[1] is not None:
                pf.append({"col": f_col, "op": mapped, "val": list(f_val)})
            else:
                if _sv.warn_unsupported_partition_ops:
                    warnings.append({
                        "col": f_col, "op": f_op,
                        "message": (
                            f"Operator '{f_op}' on column '{f_col}' needs a "
                            f"[lo, hi] 2-element value with non-null bounds; "
                            f"got {f_val!r} -- partition pruning skipped."
                        ),
                    })
            continue
        # Scalar operators -- value must be non-None.
        if f_val is None:
            if _sv.warn_unsupported_partition_ops:
                warnings.append({
                    "col": f_col, "op": f_op,
                    "message": (
                        f"Operator '{f_op}' on column '{f_col}' has value=None; "
                        f"use 'is_null' / 'is_not_null' for null checks -- "
                        f"partition pruning skipped."
                    ),
                })
            continue
        pf.append({"col": f_col, "op": mapped, "val": f_val})

    # ── filter_logic="OR" → emit an OR-GROUP so the pruner unions per-branch
    # survivors instead of AND-ing the disjuncts (which drops a single-region
    # file that satisfies only ONE branch → silent under-count).  The pruners
    # (parquet_pruning.file_matches_filters / s3_footer_stats._file_matches)
    # recognise ``{"op": "or", "or": [[branch], ...]}`` and keep a file that
    # survives ANY branch.
    #
    # SOUNDNESS: under OR, EVERY disjunct must be prunable for the union to be
    # sound — if any input filter was dropped (unsupported op / bad value),
    # a file could match via that un-modelled disjunct, so we MUST fail-open
    # and prune nothing (return None → caller full-scans).  ``len(pf) ==
    # len(filters)`` proves no disjunct was dropped.  A single surviving
    # filter (OR of one) needs no group.
    try:
        _logic = str(getattr(query_config, "filter_logic", "") or "AND").upper()
    except Exception:
        _logic = "AND"
    if _logic == "OR" and pf:
        if len(pf) != len(query_config.filters):
            # A disjunct was dropped → cannot safely OR-prune → keep all files.
            return None, warnings
        if len(pf) >= 2:
            or_group = {"col": None, "op": "or", "or": [[f] for f in pf]}
            return [or_group], warnings

    return (pf or None), warnings


def _numeric_keep(a, b) -> bool:
    """KEEP-ONLY: do two hive-segment/literal spellings denote the same NUMBER?

    2026-08-19 — the numeric sibling of :func:`_temporal_keep`, closing the
    same class of silent data loss on a different value type.

    THE BUG.  ``equals`` compared ``str(fv) != str(val)``, so on a zero-padded
    numeric partition (``month=01``, the standard layout) a filter of
    ``month = 1`` matched NO file and the query returned ZERO ROWS.  Measured
    on a synthetic table of 60 files (year=2024..2026 / month=01,02,10,11):

        month > 2    (int)  -> 30 files   numeric compare, correct
        month = 1    (int)  ->  0 files   exact string compare, WRONG
        month = '1'  (str)  ->  0 files   WRONG
        month = '01' (str)  -> 15 files   correct

    The range operators already reconcile numerically through
    ``_smart_compare``; only equality did not.  So the engine knew how to
    compare these values and simply did not, on the single most common
    predicate.

    ⚠ SAME CONTRACT AS ``_temporal_keep``: a True may ONLY be used to PREVENT
    a prune, on an INCLUSION predicate (``=``, ``IN``).  It must never be used
    on ``not_equals`` / ``not_in`` / ``not_between``, where "these are equal"
    would justify DROPPING a file — the failure mode this exists to prevent.
    Keeping an extra file is free (the engine still filters rows); dropping
    one is a wrong answer.

    Booleans are excluded deliberately: ``float(True) == 1.0`` would make a
    partition token ``1`` match a filter value of ``True``, which is a
    coincidence of representation rather than a shared meaning.
    """
    if isinstance(a, bool) or isinstance(b, bool):
        return False
    try:
        fa = float(str(a).strip())
        fb = float(str(b).strip())
    except (TypeError, ValueError):
        return False                     # not numeric → no opinion
    if fa != fa or fb != fb:             # NaN — never equal to anything
        return False
    return fa == fb


_BOOL_TRUE = {"true", "t", "yes", "y"}
_BOOL_FALSE = {"false", "f", "no", "n"}


def _bool_keep(a, b) -> bool:
    """KEEP-ONLY: do a Python bool and a partition token mean the same thing?

    2026-08-19.  ``WHERE active = true`` arrives as the Python ``True``, and
    ``str(True)`` is ``'True'`` while Spark/Hive writes the directory as
    ``active=true``.  Exact string equality therefore matched NO file and the
    query returned ZERO ROWS — measured: 0 of 2 files survived on a table
    partitioned ``active=true|false``.

    Fires ONLY when at least one side is a real ``bool``.  That restriction is
    the point: without it, ``'1'`` would have to be read as truthy, and a
    numeric partition token ``1`` would start matching a filter value of
    ``True`` — a coincidence of representation, not a shared meaning.

    ⚠ Same contract as ``_temporal_keep`` / ``_numeric_keep``: inclusion
    predicates only.
    """
    if not (isinstance(a, bool) or isinstance(b, bool)):
        return False

    def _norm(x):
        if isinstance(x, bool):
            return x
        s = str(x).strip().lower()
        if s in _BOOL_TRUE:
            return True
        if s in _BOOL_FALSE:
            return False
        return None

    na, nb = _norm(a), _norm(b)
    return na is not None and na == nb


def _temporal_keep(a, b) -> bool:
    """KEEP-ONLY: do two hive-segment/literal spellings denote the same time?

    2026-07-31 (family C).  Thin, fail-safe wrapper over
    ``predicate_coerce.temporal_eq_keep``.

    ⚠ CONTRACT: a True may ONLY be used to PREVENT a prune, on an INCLUSION
    predicate (=, IN).  It must never be used on ``not_equals`` / ``not_in`` /
    ``not_between``, where "these are equal" would justify DROPPING a file --
    the exact failure mode this fix exists to prevent.

    Returns False (i.e. "no opinion", preserving today's verdict) on any
    unparseable, ambiguous or non-temporal input.  Never raises, and never
    imports at module scope so a missing predicate_coerce cannot break S3
    listing.
    """
    try:
        from core.predicate_coerce import temporal_eq_keep as _teq
    except Exception:                                        # pragma: no cover
        return False
    try:
        if _teq(a, b):
            return True
    except Exception:                                        # pragma: no cover
        return False
    # 2026-07-31 -- UNDECIDABLE => KEEP.
    #
    # An ambiguous literal like '01/02/2025' (Jan-2 or Feb-1 by locale) is
    # deliberately NOT parsed -- guessing would prune the WRONG files.  But
    # refusing to parse is not the same as refusing to ACT: an unreadable
    # literal matches NO spelling, so it used to prune EVERY file, which is
    # silent data loss whenever a file really does hold that date.  Verified
    # at HEAD: hive segments 2025-09-30/2025-10-01/2025-09-29 with
    # `equals '01/02/2025'` -> 0 of 3 survived.
    #
    # Only fires when the STORED value is itself temporal, so genuine string
    # columns keep their normal prunable semantics.  Cost: a full scan for
    # DD/MM-vs-MM/DD spellings.  Correct-and-slow beats fast-and-wrong.
    try:
        from core.predicate_coerce import temporal_keep_undecidable as _tku
        return bool(_tku(a, b))
    except Exception:                                        # pragma: no cover
        return False


def _canonicalize_filter_temporals(filters):
    """Rewrite UNAMBIGUOUS month-name date literals to ISO.

    ⚠ DELIBERATELY **NOT WIRED**.  Do not call this from the extraction path
    without first fixing the matchers.  Kept only as the reference
    implementation for the eventual both-sides fix.

    2026-07-31 -- this WAS wired into ``extract_partition_filters_unified`` and
    was REVERTED the same day after an adversarial audit proved it introduces
    DATA LOSS.  Both halves of the original reasoning were wrong:

    1. WRONG ABOUT REACH.  ``extract_partition_filters_unified`` has ONE
       production caller (``query_feature_builder``, SQL-fallback branch only).
       The pruning pipelines that consume the incident literal call
       ``extract_combined_filters_for_iceberg`` / ``extract_partition_filters_
       from_query`` DIRECTLY, so canonicalising here never reached them.

    2. WRONG ABOUT SAFETY.  Rewriting the FILTER while the STATS/partition
       VALUES keep their original spelling BREAKS matches that previously
       worked.  Verified by execution: a VARCHAR column whose file bounds are
       lexicographic ``min='05 Jan 2020'``, ``max='10 Dec 2019'`` and a filter
       ``col = '05 Jan 2020'`` (which matches a real row byte-for-byte) --
       ``in_range3`` returns True (keep) with the raw literal, and False
       (PRUNE) once rewritten to ``'2020-01-05'``, because the rewrite destroys
       the lexicographic agreement that made string-typed columns safe.  Same
       flip for the identity/hive-island matchers (their date bridge requires
       BOTH sides to be ``^\\d{4}-\\d{2}-\\d{2}``) and for the files-table eq
       (plain ``str(fv) != str(val)``, zero reconciliation).

    So this fixed the DATE-typed direction and OPENED the VARCHAR-typed one.
    The correct fix is to make the MATCHERS reconcile BOTH sides (extend
    ``_partition_value_string_match``'s date bridge to month-name spellings of
    the decoded value, and give the files-table matcher any reconciliation at
    all), NOT to rewrite the user's literal.  The ``_to_datetime`` extension in
    ``predicate_coerce`` is the safe half and remains live: adding a READING is
    monotonically safe under the union-of-interpretations contract (keep-
    primitives keep if ANY reading permits; prune-primitives require ALL to
    agree), whereas REPLACING the value is not.

    Additional gaps if this is ever revived: it skips OR-group filter shapes
    (``{"col":None,"op":"or","or":[...]}`` has no "val" key), and it must
    exempt ``starts_with``/``like_prefix`` (rewriting a prefix inverts the
    prefix-range prune for text-timestamp columns).
    """
    if not filters:
        return filters
    try:
        from core.predicate_coerce import canonicalize_temporal_literal as _c
    except Exception:                                    # pragma: no cover
        return filters
    out = []
    for f in filters:
        if not isinstance(f, dict) or "val" not in f:
            out.append(f)
            continue
        v = f["val"]
        try:
            if isinstance(v, (list, tuple)):
                nv = type(v)(_c(x) for x in v)
            else:
                nv = _c(v)
        except Exception:                                # pragma: no cover
            out.append(f)
            continue
        if nv != v:
            logger.info(
                "Partition filter %r: canonicalised temporal literal %r -> %r "
                "so every downstream matcher sees a spelling it handles "
                "(non-ISO spellings can otherwise prune matching files)",
                f.get("col"), v, nv,
            )
            f = {**f, "val": nv}
        out.append(f)
    return out


def extract_partition_filters_unified(query_config, raw_sql=None,
                                       partition_columns=None):
    """Unified partition filter extraction — tries query_config.filters first,
    falls back to SQL WHERE clause parsing when filters are empty but
    ``raw_sql`` is present.

    Returns ``(filters, warnings, source)`` where ``source`` is
    ``"config_filters"`` or ``"sql_where"`` or ``None``.
    """
    # 1. Try config filters first (existing logic)
    filters, warnings = extract_partition_filters_from_query(query_config)
    if filters:
        return filters, warnings, "config_filters"

    # 2. Fall back to SQL WHERE parsing (Phase 122A)
    if raw_sql and partition_columns:
        try:
            from core.config import get as _cfg
            spi_cfg = _cfg("sql_partition_intelligence", {})
            if not spi_cfg.get("enabled", True):
                return None, warnings, None
            if not spi_cfg.get("fallback_to_sql_parsing", True):
                return None, warnings, None
            max_len = int(spi_cfg.get("max_sql_length", 50000))
            if len(raw_sql) > max_len:
                logger.debug("SQL too long for partition extraction (%d > %d)",
                             len(raw_sql), max_len)
                return None, warnings, None

            # BF-NON-PARTITION-PRUNE: combined helper extracts BOTH partition
            # AND non-partition WHERE-clause filters.  Non-partition filters
            # drive Iceberg column-stats pruning (file-level min/max bounds
            # via _file_matches_column_stats in core/iceberg_reader.py).
            from core.sql_partition_extractor import (
                extract_combined_filters_for_iceberg,
            )
            pf = extract_combined_filters_for_iceberg(raw_sql, partition_columns)
            if pf:
                logger.info("Filters extracted from SQL WHERE: %s",
                            [f"{f['col']} {f['op']}" for f in pf])
                return pf, warnings, "sql_where"
        except Exception as exc:
            logger.debug("SQL partition extraction failed (fail-open): %s", exc)

    return None, warnings, None


# ── S3 file listing ──────────────────────────────────────────────────────────

class S3FileListing(list):
    """A list of ``s3://bucket/key`` strings that CARRIES its own truncation
    verdict (2026-08-03 DATA-LOSS FIX).

    The old contract surfaced the ``max_files`` cap ONLY through the optional
    ``_out_meta`` dict — callers that didn't pass one (notably every consumer
    of ``list_s3_parquet_files_cached``) received a silently-truncated SUBSET
    of a >5000-file table and queried FEWER ROWS with no signal anywhere.
    Because this class IS a list, every existing caller keeps working; the
    verdict now travels WITH the value, so no caller can be cut off from it
    by a wrapper that forgot to thread ``_out_meta`` through.

    Check with ``getattr(files, "truncated", False)`` (safe on plain lists).

    ⚠ 2026-09-06 — THIS ATTRIBUTE IS NOT THE DISCLOSURE, and it never could
    have been.  ``__slots__`` on a ``list`` subclass survives nothing: a
    slice, ``list(files)``, ``sorted(files)`` and — the one that matters —
    the ``[f for f in files if ...]`` that EVERY pruning step in this
    codebase performs all yield a PLAIN list, whereupon the next
    ``getattr(files, "truncated", False)`` answers False, i.e. "this is the
    whole table".  Verified by execution; a truncated listing reports itself
    complete after one comprehension.  Unknown rendering as certainty is the
    inversion this repo keeps re-shipping.

    The authoritative disclosure is therefore stamped by the PRODUCER
    (``_finish_listing`` → ``scan_truncation.record_scan_truncation``) into
    the per-execution diagnostic store and the completeness certificate,
    where no copy and no forgetful caller can drop it.  ``truncated`` remains
    a convenience for code holding the original object; treat a False from it
    as "no opinion", never as proof of completeness.
    """
    #: 2026-09-06 — ``sizes`` rides along for the same reason ``truncated``
    #: does: the S3 LIST response ALREADY carries every object's ``Size``
    #: and this function threw it away, so anything downstream that needed a
    #: size had to buy it back with a HEAD.  It is used to decide whether a
    #: footer probe is worth issuing at all — a 64 KiB suffix read against
    #: an 84 KiB object fetches 76% of the file to avoid reading the file.
    #: Advisory only: an absent or partial ``sizes`` map means "no opinion"
    #: and every consumer must behave exactly as it did before.
    __slots__ = ("truncated", "sizes")

    def __init__(self, iterable=(), truncated: bool = False, sizes=None):
        super().__init__(iterable)
        self.truncated = bool(truncated)
        self.sizes = dict(sizes or {})


# ── Listing budget (2026-09-06) ─────────────────────────────────────────────
#
# THE DEFECT THIS REPLACES.  ``list_s3_parquet_files`` stopped at a hardcoded
# ``max_files=5000`` and returned the SUBSET it had walked so far.  The query
# then ran on that subset, returned FEWER ROWS than the table holds, and
# answered HTTP 200.  The verdict rode out on ``S3FileListing.truncated`` and
# a WARNING — a disclosure, not a prevention, and one that any
# ``[f for f in files]`` silently converts back into "complete", because a
# list COPY drops the attribute and every consumer reads it through
# ``getattr(files, "truncated", False)``.
#
# WHAT THE 5000 WAS PROTECTING — measured 2026-09-06, not guessed.  One
# method for every cell: the walk against a paginating stand-in (LIST round
# trips are len/1000, as S3 pages at 1,000 keys), the listing's own retained
# allocation via tracemalloc, the ``read_parquet([...])`` path literal built
# and parsed by DuckDB 1.5.2, and the presign loop across 8 threads (on-prem
# ``presigned`` access mode only — AWS/native never signs).
#
#     files   LIST RT   walk CPU   retained   path literal / DuckDB   presign
#                                             SQL         parse      (8 thr)
#      5,000       5      22 ms      0.8 MB   0.42 MB /   33 ms       1.4 s
#     20,000      20      32 ms      3.0 MB   1.68 MB /  143 ms       5.7 s
#     50,000      50      74 ms      8.4 MB   4.20 MB /  359 ms      14.3 s
#    200,000     200     299 ms     33.5 MB  16.80 MB / 1498 ms      57.0 s
#
# NOTHING BREAKS AT 5001.  Every cost is smooth and linear; DuckDB accepts a
# 200,000-element path list (16.8 MB of SQL) without complaint, so there is no
# argument limit behind the number and no memory cliff.  The genuinely
# expensive per-file work is DOWNSTREAM of the listing — the presign loop
# (292 us/URL even across 8 threads; it is GIL-bound HMAC) and DuckDB's
# per-file footer open — and neither can be honestly bounded by DROPPING
# FILES, because dropping files is precisely the row loss.  So the number was
# arbitrary, and a correctness loss was being traded for a resource guard the
# resource does not need.
#
# THE DESIGN.  Enumerate COMPLETELY inside a declared resource budget; above
# it, REFUSE.  A cap may THROTTLE; this is a correctness gate and it must
# FAIL.  ``s3.scan_budget_hard`` already sets this precedent one layer later
# on the duckdb_views path ("do NOT silently truncate ... FAIL LOUD"), with a
# config escape hatch for operators who accept partial results; this is the
# same shape at the only place that knows the table was never fully walked.
_DEFAULT_LISTING_MAX_FILES = 50_000
_DEFAULT_LISTING_MAX_SECONDS = 60.0

#: Sentinel for "caller wants the WHOLE prefix" — distinct from a caller that
#: explicitly asked for at most N keys.  That distinction is the whole safety
#: rule: if you asked for at most N, N keys is what you ordered; if you asked
#: for the TABLE, you get the table or an error.  ~20 call sites pass
#: ``max_files=1/3/5`` as cheap schema/sample probes and MUST NOT be turned
#: into an outage by this gate.
LISTING_BUDGET = "__qs_listing_budget__"

#: How many keys a SCHEMA PROBE lists.  Explicit (not LISTING_BUDGET) so it
#: asks for "at most N" and is flagged truncated instead of refusing -- a
#: schema read must stay cheap on a million-file prefix.  Whatever comes
#: back is a probe result, never the table's file count.
_LIST_PROBE_CAP = 500


def _s3_cfg_value(key: str, default):
    """Read one ``s3.<key>`` config value, fail-open to *default*."""
    try:
        from core.config import get as _get
        v = _get("s3", key, default)
        return default if v is None else v
    except Exception:
        return default


def resolve_listing_budget(max_files) -> tuple:
    """Resolve ``(limit, seconds, full_enumeration)`` for one listing walk.

    ``full_enumeration`` is True only when the caller asked for the WHOLE
    prefix (``LISTING_BUDGET`` / ``None``).  Only a full enumeration can
    refuse — an explicit ``max_files=3`` is a sample request, and three keys
    is the correct answer to it rather than a truncation of anything.
    """
    try:
        seconds = float(_s3_cfg_value("listing_max_seconds",
                                      _DEFAULT_LISTING_MAX_SECONDS))
    except (TypeError, ValueError):
        seconds = _DEFAULT_LISTING_MAX_SECONDS
    if seconds <= 0:
        seconds = float("inf")          # 0 = no wall-clock guard
    if max_files is LISTING_BUDGET or max_files is None:
        try:
            limit = int(_s3_cfg_value("listing_max_files",
                                      _DEFAULT_LISTING_MAX_FILES))
        except (TypeError, ValueError):
            limit = _DEFAULT_LISTING_MAX_FILES
        # A CAP OF 0 MEANS UNLIMITED and must not fold into "empty".  That
        # idiom has cost this codebase two incidents; it is written once,
        # here, where the value is resolved.
        return ((limit if limit > 0 else None), seconds, True)
    try:
        limit = int(max_files)
    except (TypeError, ValueError):
        return (_DEFAULT_LISTING_MAX_FILES, seconds, True)
    return ((limit if limit > 0 else None), seconds, False)


def is_parquet_data_key(key: str, prefix: str = "") -> bool:
    """THE rule for "is this object a data file of a Parquet table"
    (2026-10-14) -- Hive's own, which Spark and Trino follow:

    * hidden is never data: any path component under the table's folder
      that starts with ``_`` or ``.`` (``_SUCCESS``, ``_temporary/``,
      ``_metadata``, ``.part-0.crc``, ``.hive-staging``);
    * a data file is named ``*.parquet`` OR carries no extension at all --
      Hive (``000000_0``) and Trino (``20261014_193428_..._<uuid>``) write
      their data files with none.

    Found live: QueryStudio's ``count(*)`` over the owner's on-prem Hive
    table "completed" with no rows (Starburst: 20,000) -- every file was
    skipped for lacking ``.parquet``."""
    k = str(key or "")
    if k.endswith("/"):
        return False                     # a "folder" marker object, never data
    root = (prefix or "").rstrip("/")
    rel = k[len(root):].lstrip("/") if root and k.startswith(root) else k
    parts = [p for p in rel.split("/") if p]
    if not parts or any(p.startswith(("_", ".")) for p in parts):
        return False
    name = parts[-1]
    return name.lower().endswith(".parquet") or "." not in name


def _walk_s3_objects(s3_client, bucket: str, prefix: str, suffix: str,
                     limit, deadline):
    """Paginate *prefix*, collecting keys ending in *suffix*.

    Returns ``(files, sizes, over_budget, reason)``.  ``over_budget`` is True
    when the walk STOPPED EARLY — the key limit or the wall clock ran out —
    i.e. the result is a SUBSET and no caller may present it as the prefix's
    contents.
    """
    files: list = []
    sizes: dict = {}
    paginator = s3_client.get_paginator("list_objects_v2")
    clean_prefix = prefix.rstrip("/") + "/" if prefix else ""
    pages = 0
    for page in paginator.paginate(Bucket=bucket, Prefix=clean_prefix):
        # CHECKED BEFORE THE PAGE IS CONSUMED, AND NEVER ON THE FIRST — both
        # halves of that are the correctness of it.
        #
        #   * BEFORE: reaching here means the paginator HAS yielded another
        #     page, so abandoning it leaves keys unwalked and "incomplete" is
        #     a FACT.  Checked after the page instead, a listing that fitted
        #     in ONE slow page would be declared incomplete for having taken
        #     too long while having enumerated everything — the gate
        #     manufacturing the very "unknown" it exists to refuse to
        #     manufacture, and by default refusing a complete answer.
        #   * NEVER ON THE FIRST: the first page is already paid for, and
        #     bailing before consuming it yields ZERO files from a prefix we
        #     successfully listed.  A time budget may decline to buy MORE
        #     round trips; it may not discard one already bought.
        #
        # Per page rather than per key because what is bounded is ROUND
        # TRIPS, and a mid-page abort would buy nothing while making the stop
        # point depend on where in a page the clock happened to tick.
        if (pages and deadline is not None
                and time.monotonic() >= deadline):
            return files, sizes, True, "max_seconds"
        pages += 1
        for obj in page.get("Contents", []) or []:
            key = obj["Key"]
            if suffix == ".parquet":
                # Hive's rule (is_parquet_data_key), not the extension
                if not is_parquet_data_key(key, clean_prefix):
                    continue
            else:
                if not key.lower().endswith(suffix):
                    continue
                if key.split("/")[-1].startswith("."):
                    continue
            url = f"s3://{bucket}/{key}"
            files.append(url)
            try:
                if obj.get("Size") is not None:
                    sizes[url] = int(obj["Size"])
            except (TypeError, ValueError):
                pass
            # F2 (2026-07-25): register the object's CURRENT size/etag
            # (already in the listing page — free) as an authoritative hint
            # for the on-prem file cache, so a same-path overwrite becomes a
            # cache MISS -> refetch instead of a stale-bytes HIT.  No-op when
            # ``industrialization.local_file_cache`` is off.
            _register_onprem_cache_hint(bucket, key, obj)
            # ONE KEY PAST THE BUDGET, then step back.  Stopping AT the
            # budget cannot tell "the prefix holds exactly N files" from
            # "it holds more" — and a table of exactly ``listing_max_files``
            # files would then be refused as incomplete when it was fully
            # enumerated.  Unknown must not be manufactured: the extra key
            # is the PROOF that more exist, and it is discarded so callers
            # never see a key the budget did not buy.
            if limit is not None and len(files) > limit:
                extra = files.pop()
                sizes.pop(extra, None)
                return files, sizes, True, "max_files"
    return files, sizes, False, ""


def _over_budget_message(bucket: str, prefix: str, listed: int,
                         reason: str, seconds: float, kind: str) -> str:
    if reason == "max_seconds":
        what = (f"the {seconds:g}s listing time budget ran out after "
                f"{listed:,} keys")
        knob = "s3.listing_max_seconds"
    else:
        what = f"it reached the {listed:,}-key listing budget"
        knob = "s3.listing_max_files"
    return (
        f"S3 {kind} listing for s3://{bucket}/{prefix} is INCOMPLETE: {what}, "
        f"and S3 returns keys in LEXICOGRAPHIC order, so what was skipped is "
        f"unknown and is not a random sample.  Answering from this subset "
        f"would return FEWER ROWS than the table holds and report success.  "
        f"Refusing.  Fix by narrowing the table's S3 prefix, by registering "
        f"the table as Iceberg (enumeration is then island-scoped and this "
        f"budget stops applying), by raising {knob}, or — accepting "
        f"KNOWN-INCOMPLETE results — by setting "
        f"s3.refuse_truncated_listing=false."
    )


def _finish_listing(files, sizes, over_budget: bool, reason: str, *,
                    bucket: str, prefix: str, seconds: float,
                    full_enumeration: bool, kind: str,
                    _out_meta: dict | None):
    """Single exit for both listing functions: disclose, then decide.

    DISCLOSE FIRST, REFUSE SECOND, and disclose at the PRODUCER.  The
    2026-08-03 fix put the verdict on the returned value; the returned value
    is a ``list`` subclass, so ``[f for f in files]`` — which is what every
    pruning step in this codebase does — drops it, and the next
    ``getattr(files, "truncated", False)`` answers False, i.e. "this is the
    whole table".  Unknown must never render as certainty.  Stamping the
    per-execution diagnostic store HERE, at the only place that can still see
    the walk, means no copy, no wrapper, and no caller that forgot to call
    ``surface_truncated_listing`` can lose it.

    Losing the disclosure must not un-apply the gate, and vice versa — the
    recording is wrapped, the refusal is not.
    """
    # 2026-10-06 -- the LIST already carries every object's Size; keep it
    # where a sizing decision (resource admission) reads it instead of a
    # per-file constant.  Estimate input only; never decides which files.
    try:
        from core.measured_file_bytes import record_many as _mfb_record
        _mfb_record(None, (sizes or {}).items())
    except Exception as _mfb_exc:
        logger.debug("[measured-bytes] listing sizes skipped: %s", _mfb_exc)
    if not over_budget:
        return S3FileListing(files, truncated=False, sizes=sizes)

    logger.warning(
        "%s: s3://%s/%s stopped at the listing budget (%s, %d keys listed) — "
        "the result is a SUBSET of the prefix and the dropped count is "
        "unknown.", kind, bucket, prefix, reason, len(files))
    if _out_meta is not None:
        _out_meta["truncated"] = True

    # Producer-side disclosure — unlosable by any downstream copy.
    try:
        from core.scan_truncation import record_scan_truncation
        record_scan_truncation(
            table=f"s3://{bucket}/{prefix}",
            kind="listing_cap",
            reason=_over_budget_message(bucket, prefix, len(files), reason,
                                        seconds, kind),
            cap=len(files), files_before=None, files_registered=len(files),
            dropped=None, out_meta=_out_meta,
        )
    except Exception as exc:                              # pragma: no cover
        logger.warning(
            "%s: could not record the listing truncation for s3://%s/%s (%s) "
            "— the truncation itself still stands.", kind, bucket, prefix,
            exc)

    if full_enumeration and bool(_s3_cfg_value(
            "refuse_truncated_listing", True)):
        from core.scan_truncation import TruncatedScanRefusal
        raise TruncatedScanRefusal(
            _over_budget_message(bucket, prefix, len(files), reason, seconds,
                                 kind))
    return S3FileListing(files, truncated=True, sizes=sizes)


def probe_prefix_file_count(s3_client, bucket: str, prefix: str,
                            suffix: str = ".parquet",
                            ceiling: int | None = None) -> dict:
    """MIGRATION AID — how many data files live under *prefix*, and would a
    full enumeration of it now REFUSE?

    LIST-only: no presign, no footer read, no download.  Stops one key past
    the budget, so probing a ten-million-key prefix costs a bounded walk.
    Returns ``{"files", "budget", "over_budget", "exhaustive",
    "would_refuse"}``.

    An operator needs this BEFORE the gate starts refusing: a table already
    living with silent truncation emits no signal a user would notice, so
    "which of my tables break tomorrow" has to be answerable today.
    ``exhaustive=False`` means the count itself is a floor, not a total —
    unknown is reported as unknown.
    """
    budget, _sec, _full = resolve_listing_budget(None)
    if ceiling is not None:
        budget = int(ceiling)
    walk_to = None if budget is None else budget + 1
    files, _sizes, stopped, _reason = _walk_s3_objects(
        s3_client, bucket, prefix, suffix.lower(), walk_to, None)
    n = len(files)
    over = bool(budget is not None and n > budget)
    return {
        "files": n,
        "budget": budget,
        "over_budget": over,
        "exhaustive": not stopped,
        "would_refuse": over and bool(_s3_cfg_value(
            "refuse_truncated_listing", True)),
    }


def list_s3_csv_files(s3_client, bucket: str, prefix: str,
                      max_files=LISTING_BUDGET,
                      _out_meta: dict | None = None) -> list:
    """Recursively list all .csv files under an S3 prefix using boto3.

    Same contract as :func:`list_s3_parquet_files`, including the refusal on
    an over-budget FULL enumeration.  Used by on-prem S3 paths that can't use
    DuckDB's httpfs glob ('**/*.csv').  Returns an ``S3FileListing`` of
    's3://bucket/key' strings.
    """
    limit, seconds, full = resolve_listing_budget(max_files)
    deadline = None if seconds == float("inf") else time.monotonic() + seconds
    files, sizes, over, reason = _walk_s3_objects(
        s3_client, bucket, prefix, ".csv", limit, deadline)
    return _finish_listing(
        files, sizes, over, reason, bucket=bucket, prefix=prefix,
        seconds=seconds, full_enumeration=full, kind="list_s3_csv_files",
        _out_meta=_out_meta)


def list_s3_parquet_files(s3_client, bucket: str, prefix: str,
                          max_files=LISTING_BUDGET,
                          _out_meta: dict | None = None) -> list:
    """Recursively list all .parquet files under an S3 prefix using boto3.

    Uses the boto3 paginator (robust, no C-level crash risk) instead of
    DuckDB's httpfs glob ('**/*.parquet'), which can crash on on-prem S3 with
    many partitions.  Returns an ``S3FileListing`` of 's3://bucket/key'
    strings.

    THE CONTRACT (2026-09-06).  A returned listing is the COMPLETE contents
    of *prefix*.  When the walk cannot complete inside its resource budget
    (``s3.listing_max_files`` keys, ``s3.listing_max_seconds`` wall clock),
    the outcome depends on what the caller asked for:

      * ``max_files`` left at ``LISTING_BUDGET`` — the caller asked for the
        TABLE.  The truncation is recorded against the current execution
        (diagnostic store + completeness certificate) and
        ``TruncatedScanRefusal`` is raised.  Operators who accept partial
        results set ``s3.refuse_truncated_listing=false``, restoring the
        pre-2026-09-06 behaviour: a flagged subset.
      * an EXPLICIT ``max_files=N`` — the caller asked for at most N keys
        (schema probes pass 1/3/5).  N keys is the right answer; the result
        carries ``truncated=True`` and is still recorded, and nothing
        refuses.

    WARNING: Do NOT use this for Iceberg tables — it lists ALL .parquet files
    including orphaned files from old snapshots.  For Iceberg, use
    ``iceberg_service.get_iceberg_active_files()`` or
    ``iceberg_reader.get_iceberg_data_files()`` instead.
    """
    limit, seconds, full = resolve_listing_budget(max_files)
    deadline = None if seconds == float("inf") else time.monotonic() + seconds
    files, sizes, over, reason = _walk_s3_objects(
        s3_client, bucket, prefix, ".parquet", limit, deadline)
    return _finish_listing(
        files, sizes, over, reason, bucket=bucket, prefix=prefix,
        seconds=seconds, full_enumeration=full, kind="list_s3_parquet_files",
        _out_meta=_out_meta)


def _register_onprem_cache_hint(bucket: str, key: str, obj: dict) -> None:
    """F2 — feed the on-prem file cache's expected-metadata registry from
    a fresh boto3 listing entry.  Best-effort, never raises, no-op when
    ``industrialization.local_file_cache`` is off."""
    try:
        from core.onprem_file_cache import register_object_meta
        register_object_meta(f"s3://{bucket}/{key}",
                             size=obj.get("Size"), etag=obj.get("ETag"))
    except Exception as exc:
        logger.debug("onprem-cache hint registration skipped "
                     "(non-fatal): %s", exc)


# ── TTL cache for S3 file listings ──────────────────────────────────────
import threading as _threading  # noqa: E402

_listing_cache: dict[tuple, tuple[float, list]] = {}   # key → (expiry_ts, files)
_listing_cache_lock = _threading.Lock()
_LISTING_CACHE_TTL = 120   # seconds
_LISTING_CACHE_MAX = 50    # max entries


# ── Hive-layout memo (2026-09-06) ───────────────────────────────────────
#
# MEASURE THE LATENCY YOU ADD.  Wiring the island prefix planner onto the
# report route made every query on a FLAT (unpartitioned) prefix pay one
# extra delimiter LIST: the planner lists the first level, sees a .parquet
# file sitting directly there, stops with ``flat_data_file_at_level`` and
# returns None.  Correct, and useless — and the planner deliberately never
# caches a None (a TRANSIENT S3 failure must not pin "no island" onto a
# table), so the wasted probe repeated on EVERY query.  Measured: a flat
# 240-file report went 485 -> 486 round trips, warm as well as cold.
#
# Whether a prefix is hive-partitioned is a LAYOUT fact, and the full
# listing — which that same query has to run anyway — already contains the
# answer for free.  So the memo is populated from the listing rather than
# from the planner's refusal, and it holds for the SAME 120 s as the
# listing it was derived from, on the same invalidation hooks.
#
# It can only ever suppress an OPTIMISATION ATTEMPT.  A stale "flat"
# verdict costs a full enumeration (today's behaviour); it cannot drop a
# file, narrow a prefix, or change a single row.
_hive_layout_memo: dict[tuple, tuple[float, bool]] = {}
_hive_layout_lock = _threading.Lock()
_HIVE_MEMO_MAX = 200


def record_hive_layout(connection_id: int, bucket: str, prefix: str,
                       files, ttl: int = _LISTING_CACHE_TTL) -> bool:
    """Remember whether *prefix* looks hive-partitioned, from its listing.

    Returns the verdict.  A listing that produced no keys teaches nothing
    and is NOT memoised — "we saw no files" and "the files have no hive
    segments" are different observations, and conflating them would let an
    empty transient listing suppress the island walk on a real hive table.
    """
    sample = [f for f in (files or [])][:50]
    if not sample:
        return False
    verdict = any(extract_hive_parts(str(f)) for f in sample)
    key = (connection_id, bucket, prefix)
    with _hive_layout_lock:
        if len(_hive_layout_memo) >= _HIVE_MEMO_MAX:
            oldest = min(_hive_layout_memo,
                         key=lambda k: _hive_layout_memo[k][0])
            del _hive_layout_memo[oldest]
        _hive_layout_memo[key] = (time.monotonic() + ttl, verdict)
    return verdict


def looks_hive_partitioned(connection_id: int, bucket: str,
                           prefix: str) -> bool | None:
    """``True``/``False`` from a recent listing, or ``None`` for unknown.

    ``None`` means "no opinion" and callers MUST treat it as "try" — an
    unknown prefix has to be probed once or the island can never engage on
    a cold table.
    """
    key = (connection_id, bucket, prefix)
    with _hive_layout_lock:
        entry = _hive_layout_memo.get(key)
        if entry is None:
            return None
        expiry, verdict = entry
        if time.monotonic() >= expiry:
            del _hive_layout_memo[key]
            return None
        return verdict


def clear_hive_layout_memo(connection_id: int | None = None) -> None:
    with _hive_layout_lock:
        if connection_id is None:
            _hive_layout_memo.clear()
        else:
            for k in [k for k in _hive_layout_memo if k[0] == connection_id]:
                del _hive_layout_memo[k]


def list_s3_parquet_files_cached(
    connection_id: int, s3_client, bucket: str, prefix: str,
    max_files=LISTING_BUDGET, ttl: int = _LISTING_CACHE_TTL,
    _out_meta: dict | None = None,
) -> list:
    """Cached wrapper — reuses results within *ttl* seconds for same key.

    Use for hot-path callers (query execution, view registration).
    Do NOT use for browse/schema/catalog callers that need fresh data.
    Key: ``(connection_id, bucket, prefix, resolved_limit)``.

    2026-08-03 DATA-LOSS FIX: truncation is no longer swallowed here.

    2026-09-06 — AN INCOMPLETE LISTING IS NEVER CACHED.  Two reasons, and
    the second is the one that bites:

      * A cached subset OUTLIVES ITS WARNING.  The warning is emitted by the
        producer; a cache HIT does not run the producer, so for the rest of
        the TTL the subset is served by a code path that never re-derived the
        verdict.  The 2026-08-03 fix kept ``.truncated`` alive across the
        round trip, but the per-execution recording — the part the report
        envelope and the completeness certificate actually read — belongs to
        the EXECUTION, and a later execution served from cache would inherit
        the file list without inheriting the disclosure.
      * Refusal is now the default, so an entry that can only ever be
        re-derived into a refusal is not a cache entry; it is a stored
        wrong answer waiting for the operator to flip
        ``refuse_truncated_listing`` off.

    The key carries the RESOLVED limit, not the caller's sentinel, so a
    sample probe (``max_files=3``) and a full enumeration can never share an
    entry — a three-key listing must not be served to a caller that asked for
    the table.
    """
    _limit, _sec, _full = resolve_listing_budget(max_files)
    key = (connection_id, bucket, prefix, _limit)
    now = time.monotonic()

    def _surface(_files):
        """Make truncation visible on EVERY return path (hit or miss).

        Defensive: with truncated listings no longer stored, a cache HIT
        should never be truncated.  "Should never" is not "cannot", and a
        subset served silently is the whole defect — so the disclosure is
        re-derived rather than assumed, on the hit path too.
        """
        if getattr(_files, "truncated", False):
            if _out_meta is not None:
                _out_meta["truncated"] = True
            logger.warning(
                "list_s3_parquet_files_cached: serving a TRUNCATED listing "
                "(%d files, budget=%s) for %s/%s — the prefix has MORE files "
                "than the budget; results built on this subset can silently "
                "miss rows.", len(_files), _limit, bucket, prefix)
            try:
                from core.scan_truncation import surface_truncated_listing
                surface_truncated_listing(
                    _files, table=f"s3://{bucket}/{prefix}", bucket=bucket,
                    prefix=prefix, out_meta=_out_meta)
            except Exception as _exc:                     # pragma: no cover
                logger.warning(
                    "list_s3_parquet_files_cached: could not re-record the "
                    "truncation for %s/%s (%s)", bucket, prefix, _exc)
        return _files

    with _listing_cache_lock:
        entry = _listing_cache.get(key)
        if entry is not None:
            expiry, files = entry
            if now < expiry:
                return _surface(files)
            del _listing_cache[key]

    # Cache miss — fetch from S3.  A TruncatedScanRefusal propagates: a
    # refusal is the ANSWER, and swallowing it here would hand the caller a
    # subset by another route.
    files = list_s3_parquet_files(s3_client, bucket, prefix,
                                  max_files=max_files)

    if not getattr(files, "truncated", False):
        with _listing_cache_lock:
            if len(_listing_cache) >= _LISTING_CACHE_MAX:
                # Evict oldest entry
                oldest = min(_listing_cache,
                             key=lambda k: _listing_cache[k][0])
                del _listing_cache[oldest]
            _listing_cache[key] = (now + ttl, files)

    return _surface(files)


def clear_listing_cache(connection_id: int | None = None):
    """Clear cached file listings.  Pass *connection_id* to clear one connection."""
    with _listing_cache_lock:
        if connection_id is None:
            _listing_cache.clear()
        else:
            to_del = [k for k in _listing_cache if k[0] == connection_id]
            for k in to_del:
                del _listing_cache[k]
    # Island-targeted listings are keyed on the same connection — every
    # existing invalidation path (uploads, admin refresh) must bust both
    # caches together or a stale island survives a full-listing refresh.
    try:
        from core.island_prefix_planner import clear_island_cache
        clear_island_cache(connection_id)
    except Exception as _ic_exc:
        logger.debug("island cache clear skipped (non-fatal): %s", _ic_exc)
    # The hive-layout memo is derived FROM a listing, so it must expire with
    # it — a repartitioned table whose listing was refreshed while the memo
    # still said "flat" would keep the island walk suppressed.
    clear_hive_layout_memo(connection_id)


def get_parquet_file_list_fingerprint(s3_client, bucket: str, prefix: str,
                                      max_files=None,
                                      existing_file_list: list | None = None) -> tuple:
    """Return (hash_hex, file_count) fingerprint of all .parquet files under prefix.

    SHA-256 of sorted 's3://bucket/key' paths — changes when files are added or
    removed.  Used by Phase 104 partition-aware cache invalidation.

    If *existing_file_list* is provided (list of 's3://bucket/key' strings already
    fetched by ``list_s3_parquet_files``), the fingerprint is computed from those
    paths directly — **no additional S3 API call**.  This eliminates the duplicate
    listing that previously doubled per-table S3 overhead.

    Returns ('', 0) on error (fail-open — caller treats as unknown).

    2026-09-06: the slow path walks with an EXPLICIT limit so it can never
    raise the listing refusal.  A fingerprint is a cache-invalidation hint,
    not an answer to a user's question — refusing here would convert a
    staleness check into a query failure, and the broad ``except`` below
    would swallow it into ``("", 0)`` anyway, i.e. into a SILENTLY BLIND
    invalidator.  An over-budget walk instead returns a fingerprint of the
    prefix's first N keys, which still CHANGES when those keys change; the
    row-bearing paths do the refusing.
    """
    import hashlib
    try:
        # Fast path: compute from already-fetched file list (no S3 call)
        if existing_file_list is not None:
            if not existing_file_list:
                return ("", 0)
            entries = sorted(existing_file_list)
            digest = hashlib.sha256("\n".join(entries).encode()).hexdigest()
            return (digest, len(entries))

        # Slow path: list from S3 (used by staleness checks in snapshot_fingerprint)
        _fp_limit = max_files
        if _fp_limit is None:
            _fp_limit, _, _ = resolve_listing_budget(None)
            _fp_limit = _fp_limit or _DEFAULT_LISTING_MAX_FILES
        files = list_s3_parquet_files(s3_client, bucket, prefix,
                                      max_files=_fp_limit)
        if not files:
            return ("", 0)
        entries = sorted(files)
        digest = hashlib.sha256("\n".join(entries).encode()).hexdigest()
        return (digest, len(entries))
    except Exception as exc:
        logger.debug("get_parquet_file_list_fingerprint failed for %s/%s: %s", bucket, prefix, exc)
        return ("", 0)


def _sign_one_url(s3_client, url: str, expiry: int) -> str:
    """Sign a single s3:// URL to a pre-signed HTTPS URL.

    Thread-safe: boto3 client serialises internally with max_pool_connections.
    Returns the pre-signed URL with decoded path for hive partition support.
    """
    parts = url[5:].split("/", 1)
    bucket = parts[0]
    key = parts[1] if len(parts) > 1 else ""
    if not key:
        logger.warning("s3_urls_to_presigned: empty key in URL %s — skipping", url)
        return url

    ps_url = s3_client.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expiry,
    )
    # boto3 URL-encodes '=' to '%3D' in the URL path.  DuckDB's
    # hive_partitioning=true needs literal '=' in path segments
    # (e.g. year=2024/month=01/) to detect partition columns.
    # Decode the path portion only — leave query string untouched.
    parsed = urlparse(ps_url)
    decoded_path = unquote(parsed.path)
    if decoded_path != parsed.path:
        ps_url = urlunparse((parsed.scheme, parsed.netloc, decoded_path,
                             parsed.params, parsed.query, parsed.fragment))
    return ps_url


def vpc_presigned_rewrite_needed(conn_config: dict, s3_urls) -> bool:
    """True iff the in-process path should rewrite ``s3://`` URLs to
    boto3-signed HTTPS URLs to traverse a VPC interface endpoint
    without tripping DuckDB httpfs's libcurl URL-encoding bug on
    hive-partition segments (``key=value/``).

    Distinct from ``get_s3_access_mode == 'presigned'`` because on-prem
    presigned-mode triggers a Python-urllib PRE-DOWNLOAD (BF-200) —
    the right behaviour on-prem, the WRONG behaviour on VPC where the
    whole point is "use the VPC link, don't download".  When this
    helper returns True, the caller should rewrite URLs to presigned
    HTTPS and let DuckDB httpfs read them LAZILY over the VPC; no
    pre-download.

    On-prem Hive paths are excluded by the VPC-endpoint check —
    on-prem hostnames don't match ``.vpce.amazonaws.com``.
    """
    # 2026-06-24 -- smart-VPC presigning is now OPT-IN (default OFF).
    #
    # Background: the original smart-VPC fast path ASSUMED DuckDB
    # httpfs (libcurl) could reach the VPCE host directly.  In
    # practice many VPC setups have boto3 (Python urllib3) working
    # but libcurl returning HTTP 0 -- different HTTP stacks, different
    # behaviour against the same VPCE.  Operators with working
    # libcurl-to-VPCE see the speed benefit (no pre-download); those
    # without get HTTP 0 on every query and need pre-download.
    # Defaulting OFF means VPC + AWS users get the OLD proven path:
    # boto3 pre-downloads parquet files locally, DuckDB reads local
    # files, libcurl never touches the network.  Operators who want
    # the speed benefit and have verified libcurl works against
    # their VPCE set QS_ENABLE_VPC_PRESIGN=1 to opt in.
    # QS_DISABLE_VPC_PRESIGN=1 is still honored for back-compat with
    # the (very brief) window where it was the override.
    import os as _os
    _disable = _os.environ.get(
        "QS_DISABLE_VPC_PRESIGN", "").strip().lower()
    if _disable in ("1", "true", "yes", "on"):
        return False
    _enable = _os.environ.get(
        "QS_ENABLE_VPC_PRESIGN", "").strip().lower()
    if _enable not in ("1", "true", "yes", "on"):
        # DEFAULT path: smart-VPC presigning disabled -> boto3
        # pre-download via the subprocess's _force_boto3_for_vpc
        # branch (which has been the working path for VPC+AWS since
        # before smart-VPC ever existed).
        return False
    try:
        from core.ssl_config import is_vpc_endpoint_url
        ep = conn_config.get("endpoint_url") or conn_config.get("endpoint")
        if not is_vpc_endpoint_url(ep):
            return False
    except Exception:
        return False
    if not s3_urls:
        return False
    # Any URL with `/key=value/` segments triggers the libcurl bug.
    # Iceberg data files almost always have these; checking the actual
    # URL list (not the SQL) keeps the decision tight and avoids
    # false positives on metadata-only reads.
    for u in s3_urls:
        if not isinstance(u, str):
            continue
        if "=/" in u or "=" in u.rsplit("/", 1)[0].rsplit("/", 1)[-1]:
            # Cheap O(N) hive-segment heuristic: a `=` anywhere in any
            # path segment (NOT the filename) indicates hive partitioning.
            return True
        # Fallback regex for the rare case both above checks miss.
        import re as _re
        if _re.search(r"/[^/=]+=[^/]+/", u):
            return True
    return False


def s3_urls_to_presigned_vpc(s3_client, file_urls, conn_config, expiry=None):
    """Force-rewrite ``s3://`` URLs to boto3-signed HTTPS for the VPC +
    hive-partition case.  Unlike ``s3_urls_to_presigned`` which short-
    circuits when access mode is not "presigned", this helper ignores
    access mode — VPC + hive REQUIRES rewriting regardless because
    DuckDB httpfs's libcurl will URL-encode `=` and break SigV4.

    Signing hostname (2026-06-24 strategic fix): when the connection's
    endpoint is an AWS VPCE pattern AND Private DNS is enabled (the
    operator-confirmed default), this helper builds a SEPARATE boto3
    client WITHOUT ``endpoint_url`` so the signed URL embeds the
    STANDARD regional hostname ``<bucket>.s3.<region>.amazonaws.com``.
    Why: AWS's wildcard cert at the VPCE matches ``*.s3.<region>.
    amazonaws.com`` cleanly; with Private DNS that hostname resolves
    to the VPCE private IP; SigV4 aligns with the hostname libcurl
    GETs.  Passing ``endpoint_url=vpce-XXX...`` to boto3 had it sign
    against the VPCE hostname, which the user verified breaks libcurl
    (HTTP 0) AND boto3 (TLS verify) -- manual curl against the
    standard hostname succeeds.

    Opt out via ``QS_VPCE_PRIVATE_DNS=0`` for deployments without
    Private DNS (rare -- AWS recommends enabling it).

    Returns the URLs in the SAME ORDER as input (non-s3 URLs and
    already-presigned URLs pass through unchanged).

    Failure semantics: this helper is FAIL-CLOSED for VPC.  If ANY
    signing fails, RAISES — because a partially-rewritten list mixes
    presigned HTTPS (works via VPC) with raw ``s3://`` (DuckDB libcurl
    URL-encodes ``=`` -> SignatureDoesNotMatch 403).  The caller's
    try/except then sets ``_vpc_handled=False`` and falls back to
    pre-download.  This is intentionally DIFFERENT from the general
    on-prem ``s3_urls_to_presigned`` helper which is fail-open — the
    on-prem case has working raw-s3 paths through other code, but the
    VPC + hive case does NOT."""
    if not file_urls:
        return file_urls
    if s3_client is None:
        raise RuntimeError(
            "s3_urls_to_presigned_vpc: s3_client is None — cannot "
            "sign URLs for VPC.  Caller should fall back to "
            "pre-download path.")

    # 2026-06-24 -- single-chokepoint VPCE normalisation.  Build a
    # presign-only client whose ``endpoint_url`` has been normalised
    # via ``normalize_vpce_endpoint_for_s3_data`` (the helper that
    # owns the ``bucket.vpce-XXX...`` prefix rule).  The caller's
    # client may have been built before the helper existed and is
    # therefore re-built here from conn_config.
    #
    # Only rebuild when the normaliser ACTUALLY changes the endpoint
    # (i.e. operator entered the generic form).  When the operator
    # already entered the bucket-prefixed form OR opted out via
    # ``QS_VPCE_AUTO_BUCKET_PREFIX=0``, reuse the caller's client --
    # avoids re-doing the credentials dance for a no-op rewrite.
    _ep_in_cfg = (conn_config or {}).get("endpoint_url") or \
                 (conn_config or {}).get("endpoint") or ""
    _ep_is_vpce = ".vpce.amazonaws.com" in (_ep_in_cfg or "").lower()
    try:
        from core.ssl_config import (
            normalize_vpce_endpoint_for_s3_data as _check_normalize,
        )
        _ep_check_norm = _check_normalize(_ep_in_cfg) or _ep_in_cfg
    except Exception:
        _ep_check_norm = _ep_in_cfg
    _needs_client_rebuild = _ep_is_vpce and _ep_check_norm != _ep_in_cfg
    if _needs_client_rebuild:
        try:
            import boto3 as _boto3_p
            from botocore.config import Config as _BotoConfig_p
            from core.ssl_config import (
                resolve_ssl, as_boto3_verify,
                normalize_vpce_endpoint_for_s3_data as _normalize_vpce,
            )
            _ep_norm = _normalize_vpce(_ep_in_cfg) or _ep_in_cfg
            # Path-style addressing -- AWS S3 VPCE rejects virtual-
            # hosted requests against ``bucket.vpce-XXX...`` (the
            # bucket lives in the URL PATH).  This matches the
            # operator's verified working list_objects_v2 call.
            _cfg_kw = {
                "signature_version": "s3v4",
                "s3": {"addressing_style": "path"},
            }
            _presign_verify = as_boto3_verify(
                resolve_ssl((conn_config or {}).get("ssl_verify", True)))
            _presign_cfg = _BotoConfig_p(
                connect_timeout=30, read_timeout=60,
                retries={"max_attempts": 3, "mode": "adaptive"},
                **_cfg_kw,
            )
            # THE region resolver (2026-10-26: this was a re-inlined
            # ``or "us-east-1"`` -- a VPCE in eu-west-1 with the Region
            # field blank was presigned for us-east-1 here and read with
            # eu-west-1 everywhere else).
            from core.s3_storage import resolve_s3_region as _presign_region
            _client_kw = {
                "service_name": "s3",
                "region_name": _presign_region(conn_config or {}),
                "verify": _presign_verify, "config": _presign_cfg,
                "endpoint_url": _ep_norm,
            }
            _key = (conn_config or {}).get("aws_access_key_id") or \
                   (conn_config or {}).get("access_key_id")
            _sec = (conn_config or {}).get("aws_secret_access_key") or \
                   (conn_config or {}).get("secret_access_key")
            _tok = (conn_config or {}).get("aws_session_token") or \
                   (conn_config or {}).get("session_token")
            if _key:
                _client_kw["aws_access_key_id"] = _key
            if _sec:
                _client_kw["aws_secret_access_key"] = _sec
            if _tok:
                _client_kw["aws_session_token"] = _tok
            s3_client = _boto3_p.client(**_client_kw)
            if _ep_norm != _ep_in_cfg:
                logger.info(
                    "s3_urls_to_presigned_vpc: VPCE endpoint normalised "
                    "(%s -> %s) -- bucket-data sub-domain whose TLS "
                    "cert AWS designed for S3 bucket access.",
                    (_ep_in_cfg or "").lower(),
                    (_ep_norm or "").lower(),
                )
        except Exception as _build_exc:
            logger.warning(
                "s3_urls_to_presigned_vpc: failed to build presign-only "
                "client (%s) -- falling back to caller's client; signed "
                "URLs may carry the un-normalised VPCE hostname.",
                _build_exc,
            )
    if expiry is None:
        # 2026-06-23 — VPC reads are LAZY (DuckDB streams parquet over
        # the lifetime of the scan), so the URL must remain valid for
        # the whole query duration.  Prefer a dedicated
        # ``presigned_url.vpc_expiry_seconds`` knob (default 6h) over
        # the global ``expiry_seconds`` (default 15min, tuned for
        # on-prem download-and-read paths).  Large iceberg scans on
        # 10K+ files routinely exceed 15min on the slow path.
        try:
            from core.config import get as _cfg_get
            expiry = int(_cfg_get(
                "presigned_url", "vpc_expiry_seconds", 21600))
        except Exception:
            expiry = 21600
    from concurrent.futures import ThreadPoolExecutor, as_completed
    results = list(file_urls)
    s3_indices = [i for i, u in enumerate(file_urls)
                  if isinstance(u, str) and u.startswith("s3://")]
    if not s3_indices:
        return results
    workers = min(len(s3_indices), _parallel_workers())
    _failures: list = []
    if workers <= 1:
        for i in s3_indices:
            try:
                results[i] = _sign_one_url(s3_client, file_urls[i], expiry)
            except Exception as exc:
                _failures.append((file_urls[i], exc))
    else:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            future_to_idx = {
                ex.submit(_sign_one_url, s3_client, file_urls[i], expiry): i
                for i in s3_indices
            }
            for fut in as_completed(future_to_idx):
                idx = future_to_idx[fut]
                try:
                    results[idx] = fut.result()
                except Exception as exc:
                    _failures.append((file_urls[idx], exc))
    if _failures:
        # Fail-CLOSED: don't return a mixed list with raw s3:// in it.
        first_url, first_exc = _failures[0]
        raise RuntimeError(
            f"s3_urls_to_presigned_vpc: {len(_failures)} of "
            f"{len(s3_indices)} URL(s) failed to sign (first: "
            f"{first_url} -> {type(first_exc).__name__}: {first_exc}) "
            f"-- caller should fall back to pre-download."
        )
    return results


def s3_urls_to_presigned(s3_client, file_urls, conn_config, expiry=None):
    """Convert s3:// URLs to pre-signed HTTPS URLs for on-prem S3 connections.

    On-prem S3 servers (MinIO, NetApp, Ceph) may reject DuckDB httpfs requests
    where '=' in hive partition paths gets URL-encoded to '%3D', causing
    SignatureDoesNotMatch errors.

    Pre-signed URLs embed auth in query parameters, so DuckDB reads them
    as plain HTTPS — bypassing S3 auth and the encoding issue entirely.

    Only converts when access mode is 'presigned' (path_style + presigned mode).
    Returns URLs unchanged for standard AWS S3 or native on-prem mode.

    Phase 103-B: Uses ThreadPoolExecutor for parallel URL signing when there
    are multiple files.  boto3 clients are thread-safe (internal connection pool).
    """
    if expiry is None:
        from core import config as _cfg
        expiry = _cfg.presigned_url.expiry_seconds
    # Smart-VPC inline (2026-06-23) — transparent VPC + hive rewrite
    # for EVERY legacy caller of this helper (~17 sites across
    # duckdb_views / execute_api / federation_engine / MoR delete files
    # / schema fetches / cross-source paths).  Before this branch, the
    # caller silently dropped through to "return file_urls unchanged"
    # on access_mode=native -> DuckDB libcurl URL-encodes `=` -> 403.
    # Fail-open: on signing failure, return originals so caller
    # behaviour matches pre-2026-06-23 (still 403, but no NEW failure
    # mode introduced).  Callers that NEED the predownload-fallback
    # use the explicit `s3_urls_to_presigned_vpc` helper which is
    # fail-CLOSED.
    if file_urls:
        try:
            if vpc_presigned_rewrite_needed(conn_config, file_urls):
                try:
                    return s3_urls_to_presigned_vpc(
                        s3_client, file_urls, conn_config, expiry=expiry)
                except Exception as _vpc_inline_exc:
                    logger.warning(
                        "s3_urls_to_presigned: VPC presigned-rewrite "
                        "failed (%s) — falling through to native (will "
                        "likely 403 on hive `=` URL-encoding).  Caller "
                        "should switch to s3_urls_to_presigned_vpc + "
                        "predownload-fallback for VPC paths.",
                        _vpc_inline_exc,
                    )
        except Exception:
            # vpc_presigned_rewrite_needed itself raised (e.g.
            # is_vpc_endpoint_url import failed) — skip silently.
            pass
    if get_s3_access_mode(conn_config) != "presigned":
        return file_urls
    if not file_urls:
        return file_urls
    if s3_client is None:
        logger.warning("s3_urls_to_presigned: s3_client is None — returning original URLs")
        return file_urls

    # Separate s3:// URLs from non-s3 URLs (preserve order)
    s3_indices = []
    non_s3_results = {}
    for i, url in enumerate(file_urls):
        if url.startswith("s3://"):
            s3_indices.append(i)
        else:
            non_s3_results[i] = url

    if not s3_indices:
        return file_urls

    # Parallel signing via ThreadPoolExecutor
    from concurrent.futures import ThreadPoolExecutor, as_completed
    workers = min(len(s3_indices), _parallel_workers())
    results = [None] * len(file_urls)

    # Fill non-s3 results
    for i, url in non_s3_results.items():
        results[i] = url

    _converted = 0

    if workers <= 1:
        # Single file — no thread overhead
        for i in s3_indices:
            try:
                results[i] = _sign_one_url(s3_client, file_urls[i], expiry)
                _converted += 1
            except Exception as _ps_exc:
                logger.error("s3_urls_to_presigned: signing failed for %s: %s", file_urls[i], _ps_exc)
                raise RuntimeError(
                    f"Failed to generate pre-signed URL for {file_urls[i]}: {_ps_exc}. "
                    f"Check S3 credentials and endpoint configuration."
                ) from _ps_exc
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_to_idx = {
                pool.submit(_sign_one_url, s3_client, file_urls[i], expiry): i
                for i in s3_indices
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                    _converted += 1
                except Exception as _ps_exc:
                    logger.error("s3_urls_to_presigned: signing failed for %s: %s",
                                 file_urls[idx], _ps_exc)
                    raise RuntimeError(
                        f"Failed to generate pre-signed URL for {file_urls[idx]}: {_ps_exc}. "
                        f"Check S3 credentials and endpoint configuration."
                    ) from _ps_exc

    logger.info("Converted %d s3:// URLs to pre-signed HTTPS for on-prem S3 (%d workers)",
                 _converted, workers)
    return results


# ── Safe parquet schema reader (BF-69) ────────────────────────────────────────

def _download_one_presigned(presigned_url: str, conn_config: dict):
    """Download ONE presigned URL to a temp file via Python urllib.

    Returns (local_path, temp_dir).  Caller MUST clean up temp_dir in a finally block.
    Preserves hive partition directory structure so DuckDB can detect partition columns.
    Uses Python's SSL stack (same as boto3) — works on Dell ECS / on-prem S3.
    """
    import os
    import shutil
    import tempfile
    from urllib.parse import urlparse as _up, urlunparse as _uu, quote as _qt, unquote as _uq
    from urllib.request import urlopen as _uo, Request as _Rq

    temp_dir = tempfile.mkdtemp(prefix="qs_schema_")
    try:
        # Build SSL context matching connection's ssl_verify config
        from core.duckdb_views import _build_ssl_ctx
        ssl_ctx = _build_ssl_ctx(conn_config)

        parsed = _up(presigned_url)
        url_path = _uq(parsed.path)
        path_segs = url_path.lstrip("/").split("/", 1)
        rel_path = path_segs[1] if len(path_segs) > 1 else "file.parquet"

        local_file = os.path.join(temp_dir, rel_path)
        os.makedirs(os.path.dirname(local_file), exist_ok=True)

        # Re-encode path for SigV4 canonical form (same as _presigned_to_local)
        canonical_path = _qt(parsed.path, safe="/-._~")
        if canonical_path != parsed.path:
            download_url = _uu((parsed.scheme, parsed.netloc, canonical_path,
                                parsed.params, parsed.query, parsed.fragment))
        else:
            download_url = presigned_url

        req = _Rq(download_url, headers={"User-Agent": "QueryStudio/1.0"})
        try:
            from core.config import presigned_url as _pu_cfg
            timeout = _pu_cfg.download_timeout_seconds
        except Exception:
            timeout = 60

        with _uo(req, context=ssl_ctx, timeout=timeout) as resp:
            with open(local_file, "wb") as out:
                shutil.copyfileobj(resp, out)

        return local_file.replace("\\", "/"), temp_dir
    except Exception:
        # Clean up on failure
        import shutil as _sh
        _sh.rmtree(temp_dir, ignore_errors=True)
        raise


def _parquet_logical_columns(con, esc_path: str) -> list:
    """THE parquet column reader: each top-level column with its LOGICAL type,
    as the query engine will see it.

    2026-10-06 -- this read ``parquet_schema()``'s ``type`` column, which is
    the PHYSICAL storage type: a ``DATE`` is ``INT32``, a string is
    ``BYTE_ARRAY``, a ``DECIMAL(38,6)`` written by Trino / Spark / Hive is
    ``FIXED_LEN_BYTE_ARRAY`` (or INT32 / INT64 / BYTE_ARRAY), a timestamp is
    ``INT64`` or ``INT96``.  Measured on real AWS: ``fact_tetb_pq`` reported
    ``gbp_currency_amount FIXED_LEN_BYTE_ARRAY``; pre-validation turned that
    into a VARCHAR stub and REFUSED ``sum(gbp_currency_amount)`` with "No
    function matches 'sum(VARCHAR)'" (Trino: n=2400); the dataset wizard
    classified a DATE column as a numeric measure (``int32``).
    ``DESCRIBE`` over ``read_parquet`` is DuckDB's own reading of the footer
    -- the logical annotation, the legacy converted type, the decimal's
    precision/scale, the timestamp's unit and UTC flag, INT96 -- i.e. exactly
    the column types a query against the file binds to.  It reads the same
    footer ``parquet_schema()`` did, and only TOP-LEVEL columns (a nested
    struct is one ``STRUCT(...)`` column, not its leaves).
    ``hive_partitioning=false``: partition columns are merged from the PATH by
    the caller, as before.
    """
    rows = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet('{esc_path}', hive_partitioning=false)"
    ).fetchall()
    return [
        {"name": row[0], "type": row[1], "nullable": True}
        for row in rows
        if row[0] and row[1] and not str(row[0]).startswith("__")
        and row[0] != "duckdb_schema"
    ]


def _read_schema_from_local_parquet(local_path: str):
    """Read schema + row count from a local parquet file via DuckDB.

    Returns (columns, num_rows) where columns is a list of
    {"name": str, "type": str, "nullable": True} dicts.
    """
    from core.duckdb_factory import duckdb_connection
    with duckdb_connection() as con:
        esc = local_path.replace("'", "''")
        columns = _parquet_logical_columns(con, esc)
        num_rows = None
        try:
            meta = con.execute(
                f"SELECT num_rows FROM parquet_file_metadata('{esc}')"
            ).fetchone()
            if meta:
                num_rows = meta[0]
        except Exception:
            pass
        return columns, num_rows


def _read_schema_native_s3(s3_url: str, conn_config: dict):
    """Read schema from an s3:// URL using DuckDB native S3 credentials.

    For cloud AWS S3 where DuckDB httpfs works reliably.
    Returns (columns, num_rows).
    """
    from core.duckdb_factory import duckdb_connection
    with duckdb_connection() as con:
        # Factory already calls ensure_extension_directory
        # LOAD first (works with pre-downloaded extensions in air-gapped
        # environments), INSTALL as fallback.
        try:
            con.execute("LOAD httpfs;")
        except Exception:
            con.execute("INSTALL httpfs;")
            con.execute("LOAD httpfs;")
        try:
            # 2026-10-06 -- the shared S3 transport (connection caching +
            # the retry floor), after the LOAD; fail-open.
            from core.s3_http_transport import apply_s3_http_transport
            apply_s3_http_transport(con, label="schema read")
        except Exception:                      # noqa: BLE001
            pass

        # 2026-09-26 -- endpoint / ssl / url-style / region / proxy come from
        # the ONE resolver (core.s3_access); this site decides nothing.
        from core.s3_access import resolve_s3_access
        resolve_s3_access(conn_config).apply_to_duckdb(con, proxy=True)

        esc = s3_url.replace("'", "''")
        columns = _parquet_logical_columns(con, esc)
        num_rows = None
        try:
            meta = con.execute(
                f"SELECT num_rows FROM parquet_file_metadata('{esc}')"
            ).fetchone()
            if meta:
                num_rows = meta[0]
        except Exception:
            pass
        return columns, num_rows


def hive_key_depths(sample_url: str, bucket: str, prefix: str, keys) -> dict:
    """``{key: depth}`` -- the directory level (1 = directly under *prefix*)
    at which each of *keys* sits in one listed ``s3://bucket/key`` URL.  A
    key not found in it is left out."""
    want = set(keys or ())
    path = str(sample_url or "").split("?", 1)[0]
    head = f"s3://{bucket}/"
    if path.startswith(head):
        path = path[len(head):]
    clean = (prefix or "").strip("/")
    if clean and path.startswith(clean + "/"):
        path = path[len(clean) + 1:]
    out = {}
    for i, seg in enumerate(path.split("/")[:-1], start=1):
        k = seg.split("=", 1)[0] if "=" in seg else None
        if k in want and k not in out:
            out[k] = i
    return out


def enumerate_hive_key_values(s3_client, bucket: str, prefix: str, depths: dict):
    """Every value of the hive keys in *depths* (``{key: level}``) under
    *prefix*, from DIRECTORY listings (``Delimiter='/'``) -- never a file
    listing: a key at level 1 (``business_close_date=`` directly under the
    table) costs one paged LIST whatever the file count.  Walks every
    directory down to the deepest wanted level, inside the table listing
    budget (``s3.listing_max_files`` directories, ``s3.listing_max_seconds``).

    Returns ``(values_by_key, complete, reason)``; ``complete`` False when
    the budget ran out (the values are then a SUBSET -- the caller records
    the key as unknown, never decides from them)."""
    values = {k: set() for k in (depths or {})}
    if not values:
        return values, True, ""
    limit, seconds, _full = resolve_listing_budget(None)
    deadline = None if seconds == float("inf") else time.monotonic() + seconds
    paginator = s3_client.get_paginator("list_objects_v2")
    level = [(prefix or "").strip("/") + "/" if (prefix or "").strip("/") else ""]
    visited = pages = 0
    for _depth in range(1, max(depths.values()) + 1):
        nxt = []
        for base in level:
            for page in paginator.paginate(Bucket=bucket, Prefix=base, Delimiter="/"):
                if pages and deadline is not None and time.monotonic() >= deadline:
                    return values, False, "s3.listing_max_seconds ran out"
                pages += 1
                for cp in page.get("CommonPrefixes") or []:
                    sub = cp.get("Prefix") or ""
                    seg = sub[len(base):].rstrip("/")
                    if "=" in seg:
                        k, v = seg.split("=", 1)
                        if k in values:
                            values[k].add(unquote(v))
                    nxt.append(sub)
                    visited += 1
                    if limit is not None and visited > limit:
                        return values, False, f"more than {limit:,} partition directories"
        level = nxt
    return values, True, ""


def _decide_listed_partition_keys(s3_client, bucket: str, prefix: str, listed: list, *,
                                  listing_complete: bool, keys=None) -> dict:
    """``core.hive_partition_types.decide_partition_key_types`` over a probe
    listing of *prefix*, with the S3 directory walk as its complete-set
    source.  *keys* None = every hive key of the first listed file."""
    from core.hive_partition_types import decide_partition_key_types, hive_values_of
    if not listed:
        return {}
    sample = listed[0]
    if keys is None:
        keys = list(hive_values_of(sample).keys())
    return decide_partition_key_types(
        keys, listed, listing_complete=listing_complete,
        enumerate_values=lambda wanted: enumerate_hive_key_values(
            s3_client, bucket, prefix, hive_key_depths(sample, bucket, prefix, wanted)))


def decide_prefix_partition_key_types(s3_client, bucket: str, prefix: str) -> dict:
    """THE undeclared-key decision for a table nobody has recorded yet, from
    LIST requests only (the schema probe's listing + the directory walk) --
    no data file is read.  ``{key: (type, basis, known)}`` for every hive
    key of the first listed file."""
    # The walk itself, not ``list_s3_parquet_files``: this runs INSIDE a
    # query, and a probe that stops at its cap must not be disclosed as that
    # query's scan truncation -- it is not the scan, and nothing is dropped.
    listed, _sizes, stopped, _reason = _walk_s3_objects(
        s3_client, bucket, prefix, ".parquet", _LIST_PROBE_CAP, None)
    return _decide_listed_partition_keys(s3_client, bucket, prefix, list(listed),
                                         listing_complete=not stopped)


def safe_read_parquet_schema(conn_raw: dict, bucket: str, prefix: str,
                             s3_client=None, max_sample: int = 3) -> dict:
    """Read parquet file schema reliably from any S3 source (BF-69).

    Works for both cloud AWS S3 (native DuckDB httpfs) and on-prem S3
    (Dell ECS, MinIO, NetApp) by downloading a sample file locally first.

    Detects hive partition columns from file paths and merges them into
    the schema — catches partition-only columns (e.g. 'code', 'Business_Date')
    that exist in directory paths but not inside parquet data.

    Returns:
        {
            "columns": [{"name": str, "type": str, "nullable": bool}, ...],
            "num_rows": int | None,        # ONE sampled file — see the flag
            "num_rows_is_sample": True,
            "sampled_files": int,
            "num_files": int,              # at most ``num_files_probe_cap``
            "num_files_is_capped": bool,
            "num_files_probe_cap": int,
            "partition_columns": [str],
        }

    Neither ``num_rows`` nor ``num_files`` is a table-wide total, and the
    flags beside them say so.  Callers that need the real numbers must count;
    this function is a cheap schema probe by design.

    Raises ValueError if no parquet files found or schema unreadable.
    """
    import shutil as _shutil

    cfg = conn_raw.get("config", {})
    s3 = s3_client or make_s3_client_for_conn(conn_raw)

    # 1. List files via boto3 (always reliable) — single call, slice for sample
    #
    # 2026-09-17 — this is a PROBE, and it now says so.  ``max_files=500`` is
    # an explicit cap, which per list_s3_parquet_files' contract means "at
    # most 500 keys" and sets ``truncated`` rather than refusing.  That is the
    # right request to make for a schema read.  What was wrong is what came
    # back: ``len(all_files)`` was returned as ``num_files``, so a 7,300-file
    # table reported 500 and the picker showed it to the operator as fact.
    # The CSV branch of this endpoint already solved the identical problem
    # with ``num_rows_is_sample`` and its comment — "reporting a 5-file count
    # as the table's row count is a 200 with something untrue in it".  Same
    # rule, now applied to parquet: additive keys, no consumer changes.
    _listing_meta: dict = {}
    all_files = list_s3_parquet_files(s3, bucket, prefix, max_files=_LIST_PROBE_CAP,
                                      _out_meta=_listing_meta)
    if not all_files:
        raise ValueError(f"No parquet files found under s3://{bucket}/{prefix}")
    sample_files = all_files[:max_sample]

    # 2. Extract hive partition columns from file paths (pure string parsing)
    hive_parts = extract_hive_parts(sample_files[0])
    partition_col_names = list(hive_parts.keys())

    # 3. Read data columns with fallback across files
    access_mode = get_s3_access_mode(cfg)
    data_columns = None
    num_rows = None
    last_error = None

    for file_url in sample_files:
        try:
            if access_mode == "presigned":
                # On-prem: download via Python urllib, read schema from local file
                presigned = s3_urls_to_presigned(s3, [file_url], cfg, expiry=300)
                local_path, temp_dir = _download_one_presigned(presigned[0], cfg)
                try:
                    data_columns, num_rows = _read_schema_from_local_parquet(local_path)
                finally:
                    _shutil.rmtree(temp_dir, ignore_errors=True)
            else:
                # Cloud AWS: DuckDB reads s3:// directly (httpfs works)
                data_columns, num_rows = _read_schema_native_s3(file_url, cfg)
            break  # Success — stop trying more files
        except Exception as exc:
            last_error = exc
            logger.warning("safe_read_parquet_schema: file %s failed: %s", file_url, exc)
            continue

    if data_columns is None:
        raise ValueError(
            f"Failed to read parquet schema from {len(sample_files)} files "
            f"under s3://{bucket}/{prefix}: {last_error}"
        )

    # 4. Merge partition columns into data columns (catches partition-only cols)
    #
    # 2026-10-06 -- a partition-only key's type is DECIDED HERE, once, from
    # every value it has across the table (``core.hive_partition_types``:
    # all strict ISO dates -> DATE, else VARCHAR, unknown -> VARCHAR with the
    # reason), and every read is then handed this recorded type.  Until today
    # it was written VARCHAR unexamined, which was harmless only while DuckDB
    # autocast each read -- a ``dt=2026-01-01`` key came back a string.
    _capped = bool(_listing_meta.get("truncated")) or len(all_files) >= _LIST_PROBE_CAP
    data_col_names_lower = {c["name"].lower() for c in data_columns}
    undeclared = [p for p in partition_col_names if p.lower() not in data_col_names_lower]
    from core.hive_partition_types import PARTITION_TYPES_KEY, partition_types_record
    decisions = _decide_listed_partition_keys(s3, bucket, prefix, all_files,
                                              listing_complete=not _capped, keys=undeclared)
    for pcol in undeclared:
        data_columns.append({"name": pcol, "type": decisions[pcol][0], "nullable": True})

    # ``num_rows`` is ONE sampled file's count — the loop above stops at the
    # first file it can read.  It has never been the table's row count, and
    # on a partitioned table it is wrong by the file count (14.6M reported as
    # 2,000 on the 7,300-file rig).  Say which one it is rather than changing
    # it: a caller that wants the real total must count, and this read is
    # deliberately free.
    return {
        PARTITION_TYPES_KEY: partition_types_record(decisions),
        "columns": data_columns,
        "num_rows": num_rows,
        "num_rows_is_sample": True,
        "sampled_files": len(sample_files),
        "num_files": len(all_files),
        "num_files_is_capped": _capped,
        "num_files_probe_cap": _LIST_PROBE_CAP,
        "partition_columns": partition_col_names,
    }


# ── S3 circuit breaker (Phase 78C) ───────────────────────────────────────────

def _s3_cb_key(conn_id: int) -> int:
    """Return a circuit breaker key for an S3 connection.

    Uses a large negative offset to avoid collision with SQL connector IDs
    (which are always positive integers).
    conn 5 → -100005 (never collides with SQL connection_id=5).
    """
    return -(conn_id + 100_000)


def call_with_s3_circuit_breaker(fn, conn_id: int, conn_name: str, *args, **kwargs):
    """Wrap an S3 boto3 call with circuit-breaker protection.

    On 3 consecutive failures the circuit opens and subsequent calls fast-fail
    with CircuitOpenError (HTTP 503) until the cooldown expires.

    Pass conn_id=0 to skip the breaker (backward compatible).
    """
    if conn_id == 0:
        return fn(*args, **kwargs)
    from core.circuit_breaker import check_circuit, record_success, record_failure, CircuitOpenError
    key = _s3_cb_key(conn_id)
    check_circuit(key, conn_name)
    try:
        result = fn(*args, **kwargs)
        record_success(key)
        return result
    except Exception as exc:
        # 2026-09-06 -- A REFUSAL IS NOT AN S3 FAILURE.  The listing gate
        # raises ``TruncatedScanRefusal`` when a prefix cannot be enumerated
        # completely; S3 answered every request correctly.  Counting it here
        # would open this CONNECTION's breaker after three over-budget
        # queries and 503 every unrelated S3 call for the cooldown -- one
        # oversized table taking the whole connection down.  ``record_success``
        # is equally wrong (it would clear a real failure streak), so the
        # breaker is left exactly as it was: this call taught it nothing.
        try:
            from core.scan_truncation import TruncatedScanRefusal as _TSR
            _is_refusal = isinstance(exc, _TSR)
        except Exception:                                # pragma: no cover
            _is_refusal = False
        if not isinstance(exc, CircuitOpenError) and not _is_refusal:
            record_failure(key, str(exc), conn_name)
        raise


# ── S3 client factory ────────────────────────────────────────────────────────

def make_s3_client_for_config(s3_config: dict, portal_username: str = ""):
    """Build an S3 client from a bare S3 CONFIG dict (no connection record).

    2026-09-01 -- five call sites imported a ``get_s3_client_for_connection``
    that has never existed in this module, each passing a plain config dict.
    Every one raised ImportError: iceberg table registration failed outright,
    and three metadata-only COUNT fast paths in execute_api silently declined
    and fell back to reading the data.

    ``make_s3_client_for_conn`` is the real builder but takes a connection
    RECORD and reads ``["config"]`` off it, so handing it a config directly
    would have produced a client configured from ``{}`` -- working code with
    the wrong credentials, which is worse than the ImportError was.  This
    wraps it honestly: no id means no cached handler, so a fresh one is
    built from the config given.
    """
    return make_s3_client_for_conn({"id": None, "config": s3_config or {}},
                                   portal_username)


#: What every browser-safe view (``DatabaseManager.list_connections`` /
#: ``get_connection``, ``core.crypto.masked_for_client``) puts in a sensitive
#: field.  A config carrying it cannot authenticate anywhere.
MASKED_VALUE = "***"


def masked_fields(conn_config: Optional[dict]) -> List[str]:
    """The fields of ``conn_config`` whose value is the mask -- a config
    that came from a browser-safe view rather than ``get_connection_raw``."""
    return sorted(str(k) for k, v in (conn_config or {}).items()
                  if v == MASKED_VALUE)


def connection_for_bucket(db_manager: Any, bucket: str, *,
                          connection_type: str = "s3") -> Optional[dict]:
    """THE decrypted connection row that reads ``bucket`` -- for every
    background builder that is handed a bucket name rather than a
    connection id (the adaptive prefetcher, the mirror cron, the island
    materialiser).

    Matching reads the browser-safe listing (``bucket_name`` is not a
    sensitive field); the row RETURNED is ``get_connection_raw(id)`` --
    secrets decrypted -- so a client built from it signs with the
    connection's real credentials, exactly as the metadata sync's
    ``_build_s3_client`` and the query path do.  2026-10-08: the
    prefetcher's factory handed the masked listing row straight to
    :func:`make_s3_client_for_conn`; on the owner's real bucket every bloom
    read was ``access_denied`` while the supplement scan beside it (built
    from the raw row) read the same files.  ``None`` when no active S3
    connection names the bucket.
    """
    if db_manager is None or not bucket:
        return None
    for c in (db_manager.list_connections() or []):
        if (c or {}).get("connection_type") != connection_type:
            continue
        if ((c.get("config") or {}).get("bucket_name") or "") != bucket:
            continue
        raw = db_manager.get_connection_raw(c.get("id"))
        if raw:
            return raw
    return None


def make_s3_client_for_conn(conn_raw: dict, portal_username: str = ""):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.

    AWS portal credentials are injected automatically if the portal is
    enabled and the user has cached creds (via context var or explicit param).
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # 2026-10-08 -- a correctness gate, found live on real AWS: the bloom
    # scanner's client came from ``list_connections()`` -- the BROWSER-safe
    # view, every secret ``"***"`` -- and signed every GET with the literal
    # secret ``***``: 2,000 of 2,000 files ``access_denied`` while the tick
    # above said "built".  A config carrying a masked value cannot
    # authenticate under any auth mode; refusing here names the fault at the
    # caller instead of 403s at the wire.  Decrypted rows come from
    # ``get_connection_raw`` (``connection_for_bucket`` below).
    _masked = masked_fields(cfg)
    if _masked:
        raise ValueError(
            f"connection {conn_id}: config carries MASKED credentials "
            f"({', '.join(_masked)}='{MASKED_VALUE}') -- it came from a "
            f"browser-safe view (list_connections / get_connection); build "
            f"S3 clients from get_connection_raw "
            f"(core.s3_utilities.connection_for_bucket)")

    # ── Inject AWS portal credentials if available ────────────────────────
    _portal_user = ""  # track whether per-user creds were injected (skip handler cache)
    _s3u_auth_mode = (cfg.get("auth_mode") or "").lower()
    if _s3u_auth_mode == "portal":
        _portal_user = portal_username or f"s3_client:{conn_id}"
        try:
            from core.credential_manager import get_credential_manager
            _s3u_cm = get_credential_manager()
            if _s3u_cm:
                cfg = _s3u_cm.resolve_s3_credentials(dict(cfg), _portal_user)
        except Exception as _pe:
            logger.debug("CredentialManager resolution skipped: %s", _pe)
    else:
        _portal_user = portal_username
        if not _portal_user:
            try:
                from core.aws_portal_auth import _current_portal_user
                _portal_user = _current_portal_user.get("")
            except Exception:
                pass
        if _portal_user:
            try:
                from core.aws_portal_auth import inject_portal_creds
                cfg = inject_portal_creds(cfg, _portal_user)
            except Exception as _pe:
                logger.debug("Portal creds injection skipped: %s", _pe)

    # Try the cached handler first — same client the file browser uses
    # Skip cache when portal creds are injected (they're per-user + ephemeral)
    if conn_id is not None and not _portal_user:
        try:
            handler = _conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                # BF-278: tag the boto3 client with its owning connection_id
                # so downstream ExpiredToken handlers can invalidate the
                # cached handler without needing to thread conn_id through
                # every call site.  Safe — boto3 clients accept arbitrary
                # attribute assignment.
                try:
                    handler.s3_client._qs_connection_id = int(conn_id)
                except Exception:
                    pass
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler and cache it to avoid leaking clients
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        # Cache in connection manager so subsequent calls reuse it
        # Don't cache portal-injected handlers (per-user, ephemeral creds)
        if conn_id is not None and not _portal_user:
            try:
                _conn_manager._s3_handlers[conn_id] = (handler, time.monotonic())
            except Exception:
                pass
        # BF-278: tag client with conn_id (see comment above).
        if conn_id is not None:
            try:
                handler.s3_client._qs_connection_id = int(conn_id)
            except Exception:
                pass
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise
