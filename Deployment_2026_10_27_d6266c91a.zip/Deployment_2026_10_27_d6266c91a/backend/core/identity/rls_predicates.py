"""EffectiveRlsPredicates + the ``rls_key`` chokepoint (Phase 1, SECURITY).

The program's HARD gate 1 says: no shared-work feature may key on anything
less than ``(plan_hash, snapshot_id, rls_effective_predicates)`` — post-RLS,
never a username.  This module builds that third component:

  * :class:`EffectiveRlsPredicates` — a first-class, serializable snapshot
    of EVERY row filter and column rule that row-security would apply to a
    given query for a given verified identity (rendered, post
    ``${user.*}`` substitution — the exact semantic content of enforcement).
  * :func:`compute_rls_key` — THE one hashing chokepoint every future
    cache/dedup/artifact key must call.
  * :class:`EffectiveRlsComputer` — derives the predicates by walking the
    query with the SAME sqlglot machinery and the SAME policy resolution +
    variable substitution the enforcement rewriter uses, so key and
    enforcement can never disagree about what applies.

Trino/Starburst analogue: row filters and column masks are
``ViewExpression`` s resolved by ``SystemAccessControl`` at analysis time on
the coordinator; Starburst's cached results/materialized views are servable
to a session only when the session's resolved security context matches the
one the artifact was built under.  ``rls_key`` is that discriminator.

Why the key hashes RENDERED filters, not usernames (the safety theorem):
  the executed SQL differs between two identities **iff** their rendered
  predicate sets differ.  Hashing the rendered set therefore separates every
  pair of users with different row access (different filters → different
  canonical JSON → different SHA-256), while deliberately unifying users
  with identical access (identical enforced SQL → identical result bytes →
  sharing is safe *by construction*).  Collisions require a SHA-256 break.

FAIL-CLOSED asymmetry vs enforcement (deliberate, security-critical):
  * enforcement's resolver historically swallows DB errors into "no
    policies" (fail-open availability).  The key computer NEVER does — a
    resolution failure raises :class:`RlsComputationError`, so a DB blip can
    never mint an unfiltered key for a filtered user.
  * enforcement passes unparseable SQL through to the engine for a native
    parse error.  The key computer refuses (no key → no shared work for
    that query).  Inline execution is unaffected.

Opaque enforcement — tables whose enforcement we cannot (or choose not to)
prove locally are marked *opaque* and the caller's principal ids are folded
into the key ⇒ strictly per-principal keying, zero cross-user sharing.
Fail closed, never fail shared.  Two modes are opaque:
  * ``native_lf`` — Lake Formation filters rows engine-side under the
    caller's principal; our SQL is untouched yet results differ per user.
  * ``view`` — DELIBERATELY CONSERVATIVE: today's rewriter happens to
    inline-rewrite ``view``-strongest tables, but the mode's contract is
    "session-materialized secured views" (``view_builder``/Option B), whose
    enforcement surface can move outside the rewrite.  Per-principal keying
    costs sharing, never correctness — do not "optimize" this without
    proving both enforcement surfaces render identically.

``audit_only`` policies do not change executed SQL or results → excluded.

Portability: canonical serialization is plain JSON text (sorted keys, no
whitespace) — SQLite + PG safe, no JSONB operators anywhere.
"""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

from core.identity.effective import EffectiveIdentity

logger = logging.getLogger(__name__)

# Version stamped into the canonical form AND the hash domain — bump on any
# change to the serialization shape so old and new keys can never collide.
# v2 (FB-45, 2026-09-20): each row filter carries its composition CLASS and
# a table can be "no grant held" (WHERE FALSE) -- both change the executed
# SQL, so both must change the key.
RLS_PREDICATES_VERSION = 2
_HASH_DOMAIN = "qs-rls-key-v2\x00"

# Enforcement modes whose effect we can fully render locally.
_RENDERED_MODES = ("rewrite",)
# Modes enforced outside our SQL rewrite — results still differ per principal.
_OPAQUE_MODES = ("native_lf", "view")
# Modes with no effect on results.
_INERT_MODES = ("audit_only",)


class RlsComputationError(RuntimeError):
    """Raised when the effective predicates cannot be computed with
    certainty.  SECURITY: callers must treat this as "no rls_key exists" —
    the query may still run inline, but NOTHING derived from it may be
    shared, cached, or deduplicated."""


# ── The serializable predicate model ────────────────────────────────────

@dataclass(frozen=True)
class RenderedRowFilter:
    """One row policy, fully rendered for one identity.

    ``rendered_sql`` is the COMPLETE post-substitution filter text — never a
    truncated summary (the audit layer's 500-char ``_summarise`` must never
    feed a key: truncation would collide distinct policies)."""
    policy_id: Optional[int]
    rendered_sql: str
    #: FB-45 -- the class decides whether this filter ORs or ANDs with its
    #: neighbours; two identical filter sets with different classes execute
    #: different SQL and must not share a key.
    policy_class: str = "restrictive"

    def to_canonical(self) -> Dict[str, Any]:
        return {"id": self.policy_id, "sql": self.rendered_sql, "cls": self.policy_class}


@dataclass(frozen=True)
class RenderedColumnRule:
    """One column policy's semantic content (include/exclude/mask).

    Captured at the POLICY level (mode + columns + mask expression), not the
    emitted projection text — the projection can legitimately differ between
    pods (schema-lookup availability) while meaning the same thing."""
    policy_id: Optional[int]
    mode: str
    columns: Tuple[str, ...]
    mask_expr: Optional[str]

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "id": self.policy_id,
            "mode": self.mode,
            "columns": list(self.columns),
            "mask": self.mask_expr,
        }


@dataclass(frozen=True)
class TablePredicates:
    """Everything row-security does to one table for one identity."""
    table_ref: str
    row_filters: Tuple[RenderedRowFilter, ...] = ()
    column_rules: Tuple[RenderedColumnRule, ...] = ()
    opaque: bool = False   # native_lf / view — enforced outside our rewrite
    #: FB-45 -- the table carries permissive (grant) policies and this
    #: identity holds none: enforcement renders WHERE FALSE.  NOT empty: an
    #: unfiltered key here would let a cached full result be served to a
    #: principal who sees no rows.
    no_grant: bool = False

    @property
    def is_empty(self) -> bool:
        return not (self.row_filters or self.column_rules or self.opaque
                    or self.no_grant)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "table": self.table_ref,
            # Order preserved as resolved (priority asc, id asc) — the
            # enforced "(a) AND (b)" text is order-dependent, and the DB
            # order is deterministic across processes.
            "rows": [f.to_canonical() for f in self.row_filters],
            "cols": [c.to_canonical() for c in self.column_rules],
            "opaque": self.opaque,
            "no_grant": self.no_grant,
        }


@dataclass(frozen=True)
class EffectiveRlsPredicates:
    """The complete, serializable RLS effect of a query for one identity.

    ``principal_scope`` is empty unless some table is *opaque*; when set it
    carries the identity's canonical principal ids so the key becomes
    per-principal (no cross-user sharing where we cannot prove equality).
    """
    version: int = RLS_PREDICATES_VERSION
    tables: Tuple[TablePredicates, ...] = ()
    principal_scope: Tuple[str, ...] = ()

    @property
    def is_unfiltered(self) -> bool:
        """True when row-security changes nothing for this query+identity
        (feature disabled, admin bypass, or simply no matching policies) —
        all of which produce byte-identical executed SQL."""
        return not self.principal_scope and all(t.is_empty for t in self.tables)

    def to_canonical_dict(self) -> Dict[str, Any]:
        # Tables sorted by ref for order-independence across query shapes;
        # empty tables are dropped (a table with no effect contributes
        # nothing to semantics, so it must contribute nothing to the key).
        tables = sorted(
            (t for t in self.tables if not t.is_empty),
            key=lambda t: t.table_ref,
        )
        return {
            "v": self.version,
            "tables": [t.to_canonical() for t in tables],
            "principal_scope": list(self.principal_scope),
        }

    def canonical_json(self) -> str:
        return json.dumps(
            self.to_canonical_dict(),
            sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        )

    def rls_key(self) -> str:
        """Convenience — delegates to THE chokepoint."""
        return compute_rls_key(self)


# ── THE chokepoint ──────────────────────────────────────────────────────

def compute_rls_key(predicates: EffectiveRlsPredicates) -> str:
    """The one and only rls_key derivation.  Every future cache / dedup /
    artifact / single-flight key calls this — nothing else may hash
    predicates or (worse) substitute a username.

    Domain-separated SHA-256 over the injective canonical JSON.  Two
    identities collide iff their rendered predicate sets are identical —
    in which case their enforced SQL, and therefore their result bytes,
    are identical, and sharing is safe by construction.
    """
    if not isinstance(predicates, EffectiveRlsPredicates):
        raise RlsComputationError(
            "compute_rls_key requires an EffectiveRlsPredicates instance "
            f"(got {type(predicates).__name__}) — never hash ad-hoc data"
        )
    payload = _HASH_DOMAIN + predicates.canonical_json()
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ── Policy-set fingerprint (Phase 5 — key/enforcement TOCTOU fence) ─────

# v2 (2026-07-23 red-team M1): v1 folded per-table aggregates
# ``(COUNT, MAX(id), MAX(updated_at))`` — a content edit to a NON-max-id
# policy from a behind-clock pod left all three unchanged (updated_at is a
# client-side stamp), making the fingerprint BLIND to that edit.  v2 folds
# the FULL semantic content of every row, so ANY edit changes the digest
# regardless of any pod's clock; updated_at/created_at stay folded too so
# an exact edit-then-revert (ABA) is still caught via the stamp bump.
# Tables are small (admin-authored policies) — a full scan is cheap and
# only runs per SHARED execution.
_FP_DOMAIN = "qs-rls-policyset-fp-v2\x00"

_FP_COLUMNS = {
    "row_level_policies": ("id", "name", "source", "table_pattern",
                           "connection_id", "filter_sql", "enforcement",
                           "enabled", "priority", "updated_at",
                           "policy_class"),   # FB-45: a reclass changes the composed SQL
    "column_policies": ("id", "name", "source", "table_pattern",
                        "connection_id", "mode", "columns", "mask_expr",
                        "enforcement", "enabled", "priority", "updated_at"),
    "policy_bindings": ("id", "policy_kind", "policy_id", "principal_type",
                        "principal_id", "priority", "created_at"),
}


def compute_policy_fingerprint(db_manager) -> str:
    """DB-derived digest of the ENTIRE row-security configuration (row
    policies + column policies + bindings): folds the full row content of
    every policy table into a domain-separated SHA-256.

    Purpose (Phase 5 single-flight): the executor brackets a shared
    execution with two fingerprint reads (before and after).  ANY policy
    add/edit/delete/rebinding — including a non-max-id content edit from a
    behind-clock pod (M1) and an edit-then-revert (ABA, caught via the
    updated_at fold) — changes the digest, so sharing is refused whenever
    enforcement could have seen a different policy set than the one the
    rls_key hashed.

    STRICT (security asymmetry, same as the key computer): any error
    raises :class:`RlsComputationError` — an unreadable policy store must
    never look like "nothing changed".
    """
    try:
        from core.db.models import ColumnPolicy, PolicyBinding, RowLevelPolicy
        parts: List[str] = []
        with db_manager.get_session(read_only=True) as session:
            for model in (RowLevelPolicy, ColumnPolicy, PolicyBinding):
                cols = _FP_COLUMNS[model.__tablename__]
                rows = (session.query(model)
                        .order_by(model.id.asc()).all())
                parts.append(f"{model.__tablename__}:{len(rows)}")
                for r in rows:
                    vals = []
                    for c in cols:
                        v = getattr(r, c, None)
                        if hasattr(v, "isoformat"):
                            v = v.isoformat()
                        if c == "policy_class":
                            # FB-45: fold the EFFECTIVE class.  A NULL class
                            # composes exactly as "restrictive" (the
                            # migration rule), and the startup backfill
                            # stamps it so; two processes reading the same
                            # policy set before and after that stamp must
                            # agree -- the enforcement they would render is
                            # identical.  (Measured 2026-09-20 by
                            # test_signature_stable_across_processes.)
                            from core.row_security.composition import effective_class
                            v = effective_class({"policy_class": v})
                        vals.append(repr(v))
                    parts.append("\x1f".join(vals))
            # 2026-10-24 -- the data-entitlement configuration and values
            # (core/row_security/entitlement.py): a dimension, column or value
            # edit changes the composed SQL, so it moves the fingerprint.
            # Folded only when any exists, so an estate without entitlement
            # keeps the fingerprint it had (no invalidation on upgrade).
            try:
                from core.db.models import (
                    EntitlementDimension, EntitlementDimensionColumn, EntitlementValue)
                ent_models = ((EntitlementDimension, ("id", "name", "no_value_behaviour",
                                                      "is_active", "updated_at")),
                              (EntitlementDimensionColumn, ("id", "dimension_id", "column_name",
                                                            "connection_id", "value_type")),
                              (EntitlementValue, ("id", "dimension_id", "principal_type",
                                                  "principal_id", "value", "is_all", "valid_from",
                                                  "valid_to", "updated_at")))
                ent_rows = [(m, cols, session.query(m).order_by(m.id.asc()).all())
                            for m, cols in ent_models]
            except Exception as exc:
                # a database from before these tables existed carries none
                from core.schema_catalog import _is_missing_table_error
                if _is_missing_table_error(exc):
                    ent_rows = []
                else:
                    raise
            if any(rows for _m, _c, rows in ent_rows):
                for m, cols, rows in ent_rows:
                    parts.append(f"{m.__tablename__}:{len(rows)}")
                    for r in rows:
                        vals = []
                        for c in cols:
                            v = getattr(r, c, None)
                            if hasattr(v, "isoformat"):
                                v = v.isoformat()
                            vals.append(repr(v))
                        parts.append("".join(vals))
        payload = _FP_DOMAIN + "|".join(parts)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()
    except Exception as exc:
        raise RlsComputationError(
            f"policy fingerprint unavailable — refusing to certify the "
            f"policy set as unchanged: {exc}"
        ) from exc


# ── The computer (mirrors the enforcement rewriter, strictly) ───────────

class EffectiveRlsComputer:
    """Derives :class:`EffectiveRlsPredicates` for (sql, identity).

    Uses the SAME building blocks as the enforcement path:
      * table discovery — sqlglot ``find_all(exp.Table)`` with the
        rewriter's own CTE handling (imported, not re-implemented);
      * policy resolution — ``db.find_applicable_policies`` with the
        resolver's principal expansion + ``table_matches_pattern``;
      * rendering — ``substitute_vars`` on the FULL ``filter_sql``.

    STRICT: resolution errors raise (never "no policies"); parse errors
    raise.  See module docstring for the deliberate asymmetry vs
    enforcement.
    """

    def __init__(self, db_manager, enabled_fn=None):
        """``db_manager`` — the DatabaseManager (RowSecurityMixin host).
        ``enabled_fn`` — injectable "is row-security on?" (defaults to the
        production config read)."""
        self._db = db_manager
        self._enabled_fn = enabled_fn

    # -- public ----------------------------------------------------------

    def compute(
        self,
        sql: str,
        *,
        identity: EffectiveIdentity,
        dialect: str = "duckdb",
        connection_id: Optional[int] = None,
    ) -> EffectiveRlsPredicates:
        """Predicates for a SQL query.  Raises :class:`RlsComputationError`
        on any uncertainty (fail-closed)."""
        self._require_identity(identity)
        if not sql or not sql.strip():
            raise RlsComputationError("empty SQL — nothing to key")
        if not self._rls_enabled():
            return EffectiveRlsPredicates()          # feature off → SQL unmodified for everyone
        table_refs = self._extract_table_refs(sql, dialect)
        # 2026-10-24 -- the entitlement filters folded below are rendered in
        # the dialect the rewriter renders them in.
        from core.row_security.entitlement import REWRITE_DIALECT
        _tok = REWRITE_DIALECT.set(dialect or "")
        try:
            return self._compute_with_opacity_guard(table_refs, identity,
                                                    connection_id)
        finally:
            REWRITE_DIALECT.reset(_tok)

    def compute_for_tables(
        self,
        table_refs: Sequence[str],
        *,
        identity: EffectiveIdentity,
        connection_id: Optional[int] = None,
    ) -> EffectiveRlsPredicates:
        """Predicates for callers that already know the base relations
        (file-flow / query_config paths).  Same strict contract."""
        self._require_identity(identity)
        if not self._rls_enabled():
            return EffectiveRlsPredicates()
        refs = [str(t).strip() for t in (table_refs or []) if str(t).strip()]
        return self._compute_with_opacity_guard(refs, identity, connection_id)

    # -- internals -------------------------------------------------------

    def _compute_with_opacity_guard(
        self,
        table_refs: Sequence[str],
        identity: EffectiveIdentity,
        connection_id: Optional[int],
    ) -> EffectiveRlsPredicates:
        """L1-C1 (2026-07-25 red-team): opacity (native_lf / view) is a
        per-principal ENGINE property of the TABLE, not of the caller's
        bindings.  Lake Formation filters rows engine-side under the
        caller's principal even when OUR resolution finds no candidate
        policy for that caller (admin bypass, or a policy bound to
        principals the caller doesn't hold).  The old code returned an
        empty — SHAREABLE — key in both cases, letting one principal's
        bytes be served to another.

        Guard: BEFORE the admin bypass and independent of binding, detect
        whether ANY referenced table carries an enabled opaque-mode policy
        AT ALL.  If so, the request is NON-SHAREABLE: the caller's
        principal ids are folded into the key (per-principal keying).
        Admin bypass still zeroes rewrite-mode filters — that stays
        shareable, because enforcement rewrites nothing for admins and
        the executed SQL is byte-identical."""
        any_opaque_table = self._any_opaque_policy_for_refs(
            table_refs, connection_id)
        if identity.is_admin_like:
            if any_opaque_table:
                return EffectiveRlsPredicates(
                    principal_scope=tuple(sorted(identity.principal_ids())))
            return EffectiveRlsPredicates()   # mirrors secure_sql's admin bypass
        preds = self._compute_for_refs(table_refs, identity, connection_id)
        if any_opaque_table and not preds.principal_scope:
            # Caller's own principals didn't resolve the opaque marker
            # (unbound user) — the engine still filters per principal.
            preds = EffectiveRlsPredicates(
                tables=preds.tables,
                principal_scope=tuple(sorted(identity.principal_ids())),
            )
        return preds

    def _any_opaque_policy_for_refs(
        self,
        table_refs: Sequence[str],
        connection_id: Optional[int],
    ) -> bool:
        """Binding-INDEPENDENT scan: does any enabled native_lf / view
        policy target any of ``table_refs``?

        Uses the listing API (all enabled policies, any binding) when the
        DB exposes it — the real DatabaseManager does.  Test doubles that
        only expose ``find_applicable_policies`` are swept via the
        wildcard principal (default-bound policies), which is still
        independent of the CALLER's principals.

        STRICT: any error raises :class:`RlsComputationError` — an
        unreadable policy store must never be certified as opacity-free
        (that would mint a shareable key for a possibly-per-principal
        table)."""
        refs = [str(r).strip() for r in (table_refs or []) if str(r).strip()]
        if not refs:
            return False
        try:
            from core.row_security.resolver import table_matches_pattern
            pools: List[Dict[str, Any]] = []
            list_rows = getattr(self._db, "list_row_policies", None)
            list_cols = getattr(self._db, "list_column_policies", None)
            if callable(list_rows):
                pools.extend(list_rows(enabled_only=True,
                                       connection_id=connection_id) or [])
            if callable(list_cols):
                pools.extend(list_cols(enabled_only=True,
                                       connection_id=connection_id) or [])
            if not callable(list_rows) and not callable(list_cols):
                for kind in ("row", "column"):
                    pools.extend(self._db.find_applicable_policies(
                        ["all:*"], connection_id, kind) or [])
        except Exception as exc:
            raise RlsComputationError(
                f"opacity scan failed — refusing to certify the query as "
                f"shareable: {exc}"
            ) from exc
        for p in pools:
            if str(p.get("enforcement") or "").lower() not in _OPAQUE_MODES:
                continue
            if p.get("enabled") is False:
                continue
            pattern = p.get("table_pattern", "")
            if any(table_matches_pattern(r, pattern) for r in refs):
                return True
        return False

    def _table_has_permissive(self, tref: str, connection_id: Optional[int]) -> bool:
        """Does ANY enabled row policy on ``tref`` compose as permissive, for
        any principal?  STRICT like everything here: an unreadable policy
        store raises rather than answering "no"."""
        from core.row_security.resolver import table_matches_pattern
        from core.row_security.composition import PERMISSIVE, effective_class
        fn = getattr(self._db, "find_policies_any_principal", None)
        lst = getattr(self._db, "list_row_policies", None)
        if not callable(fn) and not callable(lst):
            # A store with no principal-independent lookup cannot carry a
            # class (every production store is the RowSecurityMixin, which
            # has both; this is a pre-FB-45 stand-in): all legacy, no grants.
            # Same rule as PolicyResolver.table_row_policy_classes.
            return False
        try:
            if callable(fn):
                pols = fn(connection_id, "row") or []
            else:
                pols = lst(enabled_only=True, connection_id=connection_id) or []
        except Exception as exc:
            raise RlsComputationError(
                f"policy-class scan failed for {tref} — no rls_key can be "
                f"issued: {exc}") from exc
        return any(
            p.get("enabled") is not False
            and table_matches_pattern(tref, p.get("table_pattern", ""))
            and effective_class(p) == PERMISSIVE
            for p in pols
        )

    @staticmethod
    def _require_identity(identity: Any) -> None:
        if not isinstance(identity, EffectiveIdentity):
            raise RlsComputationError(
                "predicates require a verified EffectiveIdentity (got "
                f"{type(identity).__name__}) — raw user dicts / usernames are "
                "forgeable and refused at this boundary"
            )

    def _rls_enabled(self) -> bool:
        if self._enabled_fn is not None:
            return bool(self._enabled_fn())
        try:
            from core.config import row_security as _rs_cfg
            return bool(_rs_cfg.enabled)
        except Exception as exc:
            # Cannot even determine whether RLS is on → no key.
            raise RlsComputationError(f"row_security config unreadable: {exc}") from exc

    def _extract_table_refs(self, sql: str, dialect: str) -> List[str]:
        """The rewriter's table walk, verbatim semantics."""
        try:
            import sqlglot
            from sqlglot import exp
            from core.row_security.rewriter import is_cte_reference, _resolved_table_ref
        except Exception as exc:  # pragma: no cover - sqlglot is a hard dep
            raise RlsComputationError(f"sqlglot unavailable: {exc}") from exc
        try:
            tree = sqlglot.parse_one(sql, dialect=dialect or None)
        except Exception as exc:
            raise RlsComputationError(
                f"SQL does not parse — no rls_key can be issued: {exc}"
            ) from exc
        refs: List[str] = []
        seen = set()
        for tbl in tree.find_all(exp.Table):
            if isinstance(tbl.parent, exp.CTE):
                continue
            tref = _resolved_table_ref(tbl)
            if is_cte_reference(tbl):
                continue
            if tref not in seen:
                seen.add(tref)
                refs.append(tref)
        return refs

    def _entitlement_rows(self, user_ctx, connection_id, tref) -> List[Dict[str, Any]]:
        from core.row_security import entitlement as _ent
        try:
            return list(_ent.compile_for(user_ctx, connection_id, tref, self._db))
        except _ent.EntitlementRefused as exc:
            raise RlsComputationError(f"data entitlement: {exc}") from exc

    def _compute_for_refs(
        self,
        table_refs: Sequence[str],
        identity: EffectiveIdentity,
        connection_id: Optional[int],
    ) -> EffectiveRlsPredicates:
        from core.row_security.resolver import substitute_vars, table_matches_pattern
        from core.row_security.rewriter import _strongest_mode
        from core.row_security.composition import (
            PERMISSIVE, compose_row_filters, effective_class,
        )

        principal_ids = identity.principal_ids()
        try:
            row_candidates = self._db.find_applicable_policies(
                principal_ids, connection_id, "row")
            col_candidates = self._db.find_applicable_policies(
                principal_ids, connection_id, "column")
        except Exception as exc:
            # STRICT — never degrade to "no policies" (that is how a DB blip
            # would mint an unfiltered key for a filtered user).
            raise RlsComputationError(
                f"policy resolution failed — no rls_key can be issued: {exc}"
            ) from exc

        user_ctx = identity.to_user_ctx()
        tables: List[TablePredicates] = []
        any_opaque = False

        for tref in table_refs:
            rows = [p for p in row_candidates
                    if table_matches_pattern(tref, p.get("table_pattern", ""))]
            # 2026-10-24 -- the DATA ENTITLEMENT policies enforcement adds
            # (PolicyResolver.resolve -> entitlement.compile_for) belong in
            # the key too.  Without them two readers holding different
            # values got the SAME key and a report's cached result was
            # served across them (rig proof: the analyst was handed the
            # admin's five regions).  A refusal is no key (fail-closed).
            rows = rows + self._entitlement_rows(user_ctx, connection_id, tref)
            cols = [p for p in col_candidates
                    if table_matches_pattern(tref, p.get("table_pattern", ""))]
            if not rows and not cols:
                # FB-45 -- mirror the rewriter's empty-set decision: a table
                # carrying a grant this identity does not hold executes
                # WHERE FALSE, which is not "unfiltered".
                if self._table_has_permissive(tref, connection_id):
                    tables.append(TablePredicates(table_ref=tref, no_grant=True))
                continue

            enforcement = _strongest_mode(
                [p.get("enforcement") for p in rows + cols])

            if enforcement in _INERT_MODES:
                continue    # audit_only — no effect on results, no effect on key

            if enforcement in _OPAQUE_MODES:
                any_opaque = True
                tables.append(TablePredicates(
                    table_ref=tref,
                    row_filters=(),
                    column_rules=(),
                    opaque=True,
                ))
                continue

            # rewrite — render exactly what enforcement renders.
            filters: List[RenderedRowFilter] = []
            for p in rows:
                tpl = p.get("filter_sql") or ""
                try:
                    rendered = substitute_vars(tpl, user_ctx).strip()
                except Exception as exc:
                    raise RlsComputationError(
                        f"filter rendering failed for policy {p.get('id')!r} "
                        f"on {tref}: {exc}"
                    ) from exc
                if not rendered:
                    # 2026-08-20 — the rewriter now REFUSES a row policy
                    # whose rendered filter is empty (it used to degrade to
                    # WHERE TRUE; see rewriter.EmptyPolicyFilterError).  The
                    # rendering theorem says this key must mirror what
                    # enforcement executes — and enforcement executes
                    # NOTHING.  Folding the policy away here would produce
                    # the shared UNFILTERED key, under which a cached
                    # no-policy result could be served to the governed
                    # principal.  RlsComputationError is already fail-closed
                    # at every consumer (unique key / cache MISS).
                    raise RlsComputationError(
                        f"row policy {p.get('id')!r} on {tref} rendered an "
                        f"EMPTY filter — enforcement refuses this query, so "
                        f"no shareable key exists for it"
                    )
                filters.append(RenderedRowFilter(
                    policy_id=p.get("id"),
                    rendered_sql=rendered,
                    policy_class=effective_class(p),
                ))
            # FB-45 -- the same composition the rewriter applies.  Only the
            # "holds no grant on a table that has grants" outcome changes the
            # shape here; the OR/AND text itself is a function of the
            # (id, sql, cls) triples already in the key.
            _has_perm = any(effective_class(p) == PERMISSIVE for p in rows)
            if not _has_perm:
                _has_perm = self._table_has_permissive(tref, connection_id)
            _comp = compose_row_filters(
                [(p, f.rendered_sql) for p, f in zip(rows, filters)],
                table_has_permissive=_has_perm, table_has_any=True)
            if _comp.is_no_rows:
                tables.append(TablePredicates(table_ref=tref, no_grant=True))
                continue
            rules: List[RenderedColumnRule] = []
            for p in cols:
                rules.append(RenderedColumnRule(
                    policy_id=p.get("id"),
                    mode=str(p.get("mode") or "").lower(),
                    columns=tuple(sorted(str(c).lower()
                                          for c in (p.get("columns") or []))),
                    mask_expr=p.get("mask_expr"),
                ))
            tp = TablePredicates(
                table_ref=tref,
                row_filters=tuple(filters),
                column_rules=tuple(rules),
                opaque=False,
            )
            if not tp.is_empty:
                tables.append(tp)

        principal_scope: Tuple[str, ...] = ()
        if any_opaque:
            # Enforcement happens outside our rewrite (LF / secured views):
            # results are principal-dependent in ways we cannot render, so
            # the key becomes strictly per-principal.  Never fail-shared.
            principal_scope = tuple(sorted(principal_ids))

        return EffectiveRlsPredicates(
            tables=tuple(tables),
            principal_scope=principal_scope,
        )
