"""EffectiveIdentity — the server-side identity boundary (Phase 1, SECURITY).

Closes the parked forgeable-identity finding: several API modules carry a
local ``_get_user`` that base64-decodes the ``Authorization: Basic`` header
and TRUSTS the username with no password / LDAP / session check.  Any
caller could become any user.  This module is the strategic replacement —
one chokepoint that derives identity **only** from verified, server-side
sources, and a typed object that later phases (job queue, caches, shared
work) capture *as data*.

Trino analogue: ``Identity`` is established by the coordinator's
authenticator once, then threaded through the engine as data — connectors
and access-control plugins receive it; nothing downstream re-derives it
from client bytes.

The four blessed producers (there are NO others):

  * :func:`derive_from_request`      — live HTTP request → the REAL
    ``api.deps.get_current_user`` (server-side session lookup, or actual
    AD/local password verification).  Never decodes headers itself.
  * :func:`derive_from_verified_user` — a user dict that ALREADY came out of
    the verified auth path (``get_current_user`` / ``authenticate_user`` /
    ``authenticate_interactive``).  Validates + canonicalizes.
  * :func:`derive_for_owner`          — background execution with no live
    request (scheduled reports, deliveries).  The username MUST come from a
    server-stored owner column; scope (role + groups) is re-resolved
    server-side, mirroring F1's ``core.scheduler._resolve_owner_user_ctx``:
    on any resolution failure it degrades to a LEAST-PRIVILEGE principal
    (viewer, no groups) — restricts, never widens.
  * :func:`system_identity`           — internal maintenance work that never
    serves user-visible rows (syncer, reaper).  Explicitly non-shareable.

FAIL-CLOSED contract (the one exemption from the program's fail-open rule):
every failure raises :class:`IdentityError`.  There is no guest fallback,
no anonymous fallback, no "best effort" identity.  Deny/withhold — never
fall open to a forgeable identity.

Serialization: :meth:`EffectiveIdentity.to_payload` /
:func:`identity_from_payload` exist for Phase 2's capture-at-enqueue
(identity as columns on the job row).  A payload is only as trustworthy as
the store it sits in (Postgres, server-side); payload round-trip marks the
source so consumers can audit provenance.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)


class IdentityError(RuntimeError):
    """Raised whenever a verified identity cannot be established.
    SECURITY: callers must treat this as a hard deny — never substitute a
    default/guest identity."""


class IdentitySource(str, Enum):
    """Provenance of a verified identity."""
    SESSION = "session"                 # Bearer token → server-side session store
    VERIFIED_BASIC = "verified_basic"   # Basic header → REAL authenticate_user (password checked)
    GUEST_NOAUTH = "guest_noauth"       # auth.type='none' dev mode (explicitly configured)
    OWNER_DERIVED = "owner_derived"     # server-stored owner + server-side scope resolution
    SYSTEM = "system"                   # internal maintenance principal
    CAPTURED = "captured"               # rehydrated from a job-row payload (Phase 2)


# Keys that must never ride along as RLS-substitutable attributes.
_SECRET_ATTR_KEYS = frozenset({
    "password", "passwd", "pwd", "secret", "token", "session_token",
    "access_token", "refresh_token", "api_key", "authorization",
})

# Fields lifted out of the user dict into first-class attributes.
_CORE_KEYS = frozenset({"username", "role", "groups", "ad_groups", "is_admin"})


@dataclass(frozen=True)
class EffectiveIdentity:
    """A verified principal, canonicalized and immutable.

    Invariants (enforced in ``__post_init__``):
      * ``username`` is non-empty;
      * ``source`` is an :class:`IdentitySource`;
      * ``groups`` is a deduped, sorted tuple (LDAP returns groups in
        nondeterministic order — canonical form keeps every derived hash
        stable);
      * ``attrs`` contains no secret-bearing keys.

    Direct construction is possible in Python, but the contract is that
    ALL production call sites use the module factories — the factories are
    the security boundary, this class is the evidence they produced.
    """
    username: str
    role: str
    groups: Tuple[str, ...]
    is_admin: bool
    source: IdentitySource
    attrs: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.username, str) or not self.username.strip():
            raise IdentityError("EffectiveIdentity requires a non-empty username")
        if not isinstance(self.source, IdentitySource):
            raise IdentityError("EffectiveIdentity requires a valid IdentitySource")
        canonical = _canonical_groups(self.groups)
        if tuple(self.groups) != canonical:
            object.__setattr__(self, "groups", canonical)
        # Strip secrets defensively even on direct construction.
        clean_attrs = {
            str(k): v for k, v in dict(self.attrs or {}).items()
            if str(k).lower() not in _SECRET_ATTR_KEYS
        }
        object.__setattr__(self, "attrs", clean_attrs)

    # ── derived views ───────────────────────────────────────────────────

    def principal_ids(self) -> List[str]:
        """Canonical principal list — same shape/order the row-security
        resolver uses (``user: role: group:* all:*``).

        L1-S2 (2026-07-25): an EMPTY role gets the same ``"viewer"``
        default :meth:`to_user_ctx` applies — otherwise the KEY (built
        from these principal ids) and ENFORCEMENT (which resolves via the
        UserContext with role='viewer') could desync: a policy bound to
        ``role:viewer`` would be enforced but not folded into the key."""
        ids: List[str] = [f"user:{self.username}"]
        ids.append(f"role:{self.role or 'viewer'}")
        ids.extend(f"group:{g}" for g in self.groups)
        ids.append("all:*")
        return ids

    def to_user_ctx(self):
        """Bridge to the existing row-security :class:`UserContext` so the
        SAME substitution / resolution code enforces and keys."""
        from core.row_security.resolver import UserContext
        attrs = dict(self.attrs)
        # 2026-10-24 -- the data-entitlement surface (an API key's / a
        # feed's) rides in attrs; it is a field of the context, never a
        # substitutable attribute.  A JSON round trip makes it a list.
        scope = attrs.pop("entitlement_scope", None)
        return UserContext(
            username=self.username,
            role=self.role or "viewer",
            groups=self.groups,
            attrs=attrs,
            is_admin=bool(self.is_admin),
            entitlement_scope=tuple(scope) if isinstance(scope, list) else scope,
        )

    @property
    def is_admin_like(self) -> bool:
        """Mirrors ``secure_sql``'s admin-bypass test exactly."""
        return bool(self.is_admin) or self.role in ("admin", "super_admin")

    # ── portable capture (Phase 2 job rows) ─────────────────────────────

    def to_payload(self) -> Dict[str, Any]:
        """Plain-JSON-safe capture (identity **as data** at enqueue)."""
        return {
            "identity_version": 1,
            "username": self.username,
            "role": self.role,
            "groups": list(self.groups),
            "is_admin": bool(self.is_admin),
            "source": self.source.value,
            "attrs": {k: v for k, v in self.attrs.items()},
        }


def identity_from_payload(payload: Dict[str, Any]) -> EffectiveIdentity:
    """Rehydrate a captured identity (executor side).  FAIL-CLOSED on any
    malformed payload.  Source becomes ``CAPTURED`` with the original
    provenance preserved in ``attrs['_captured_source']`` for audit."""
    if not isinstance(payload, dict):
        raise IdentityError("identity payload must be a dict")
    username = str(payload.get("username") or "").strip()
    if not username:
        raise IdentityError("identity payload has no username")
    attrs = dict(payload.get("attrs") or {})
    attrs["_captured_source"] = str(payload.get("source") or "unknown")
    return EffectiveIdentity(
        username=username,
        role=str(payload.get("role") or "viewer"),
        groups=_canonical_groups(payload.get("groups") or ()),
        is_admin=bool(payload.get("is_admin")),
        source=IdentitySource.CAPTURED,
        attrs=attrs,
    )


# ── Factories (THE blessed producers) ───────────────────────────────────

def derive_from_request(request: Any) -> EffectiveIdentity:
    """Derive the caller's identity from a live request — THE request-facing
    chokepoint.

    Delegates to the real ``api.deps.get_current_user`` (session lookup for
    Bearer, actual AD/local password verification for Basic).  This function
    NEVER reads or decodes ``Authorization`` itself and NEVER accepts a
    client-supplied username field.

    FAIL-CLOSED: any failure (401, LDAP outage, missing deps wiring) →
    :class:`IdentityError`.
    """
    try:
        from api.deps import get_current_user
    except Exception as exc:  # pragma: no cover - import failure is a deploy bug
        raise IdentityError(f"identity boundary unavailable: {exc}") from exc
    try:
        user = get_current_user(request)
    except IdentityError:
        raise
    except Exception as exc:
        # HTTPException(401/…) or any auth-backend failure → hard deny.
        raise IdentityError(f"identity verification failed: {exc}") from exc
    source = IdentitySource.GUEST_NOAUTH if _auth_disabled() else IdentitySource.SESSION
    return derive_from_verified_user(user, source=source)


def derive_from_verified_user(
    user: Optional[Dict[str, Any]],
    *,
    source: IdentitySource = IdentitySource.SESSION,
) -> EffectiveIdentity:
    """Canonicalize a user dict that ALREADY passed real authentication
    (``get_current_user`` / ``ad_auth.authenticate_user`` output shape).

    SECURITY contract for callers: ``user`` must be the untouched output of
    the verified auth path.  Passing a dict assembled from request headers
    or client-supplied JSON is a security bug — the adversarial test suite
    pins that the burst-style forged dict never reaches here through the
    factories.

    FAIL-CLOSED: empty/None user or blank username → :class:`IdentityError`.
    """
    if not user or not isinstance(user, dict):
        raise IdentityError("verified user payload is empty — refusing identity")
    username = str(user.get("username") or "").strip()
    if not username:
        raise IdentityError("verified user payload has no username — refusing identity")
    groups = user.get("groups") or user.get("ad_groups") or []
    if isinstance(groups, str):
        groups = [g.strip() for g in groups.split(",") if g.strip()]
    attrs = {
        str(k): v for k, v in user.items()
        if k not in _CORE_KEYS and str(k).lower() not in _SECRET_ATTR_KEYS
    }
    return EffectiveIdentity(
        username=username,
        role=str(user.get("role") or "viewer"),
        groups=_canonical_groups(groups),
        is_admin=bool(user.get("is_admin")),
        source=source,
        attrs=attrs,
    )


def derive_for_owner(owner_username: Optional[str]) -> EffectiveIdentity:
    """Background-execution identity for a server-stored owner (scheduled
    reports, deliveries, Phase 2 jobs re-run on behalf of their owner).

    ``owner_username`` MUST come from a server-side record (a DB ``owner`` /
    ``created_by`` column) — never from a request.  Scope is re-resolved
    server-side via F1's chokepoint (``core.scheduler._resolve_owner_user_ctx``
    → password-free AD lookup): the run reproduces exactly what the owner
    sees interactively.

    FAIL-CLOSED shape (mirrors F1): a missing owner raises; a failed scope
    resolution degrades to LEAST-PRIVILEGE (viewer, no groups) — it can only
    drop rows, never leak extra ones — and is never admin.
    """
    owner = (owner_username or "").strip()
    if not owner:
        raise IdentityError("no owner recorded — refusing to derive an identity")
    role, groups, attrs = "viewer", (), {}
    try:
        from core.scheduler import _resolve_owner_user_ctx
        ctx = _resolve_owner_user_ctx(owner) or {}
        role = str(ctx.get("role") or "viewer")
        groups = _canonical_groups(ctx.get("groups") or ())
        attrs = {
            str(k): v for k, v in ctx.items()
            if k not in _CORE_KEYS and str(k).lower() not in _SECRET_ATTR_KEYS
        }
        # F1 already never returns admin for a background principal; enforce
        # the same invariant here regardless of resolver drift.
        if role in ("admin", "super_admin"):
            logger.warning(
                "identity: owner scope resolver returned %r for %s — clamping "
                "to viewer (background runs never execute with admin bypass)",
                role, owner,
            )
            role = "viewer"
    except Exception as exc:
        logger.warning(
            "identity: owner scope resolution failed for %s — degrading to "
            "least-privilege viewer/no-groups (fail-closed): %s", owner, exc,
        )
        role, groups, attrs = "viewer", (), {}
    return EffectiveIdentity(
        username=owner,
        role=role,
        groups=tuple(groups),
        is_admin=False,
        source=IdentitySource.OWNER_DERIVED,
        attrs=attrs,
    )


def system_identity(component: str) -> EffectiveIdentity:
    """Internal maintenance principal (syncer, reaper, compactor).

    NEVER used to execute user-visible queries and NEVER shareable: its
    role is 'system' which matches no admin bypass and no user policy —
    downstream RLS keying treats it like any other non-admin principal.
    """
    component = (component or "").strip()
    if not component:
        raise IdentityError("system identity requires a component name")
    return EffectiveIdentity(
        username=f"__system__:{component}",
        role="system",
        groups=(),
        is_admin=False,
        source=IdentitySource.SYSTEM,
        attrs={},
    )


# ── helpers ─────────────────────────────────────────────────────────────

def _canonical_groups(groups: Any) -> Tuple[str, ...]:
    """Dedupe + sort — canonical, hash-stable group tuple."""
    if groups is None:
        return ()
    if isinstance(groups, str):
        groups = [g.strip() for g in groups.split(",")]
    # ``str(None).strip()`` is the truthy string "None", so a null member of
    # an LDAP group list used to survive as a group literally NAMED "None".
    # In this GRANT-shaped engine a fabricated principal can only be matched
    # by a policy bound to group:None -- but it is still a principal nobody
    # granted, and it silently changes every derived cache key.
    out = sorted({str(g).strip() for g in groups
                  if g is not None and str(g).strip()})
    return tuple(out)


def _auth_disabled() -> bool:
    """True only when auth is GENUINELY configured off (mirrors the
    fail-closed rule in api.deps: a config-load failure never counts)."""
    try:
        from core.config import auth as _auth, config_load_failed
        return _auth.type == "none" and not config_load_failed()
    except Exception:
        return False
