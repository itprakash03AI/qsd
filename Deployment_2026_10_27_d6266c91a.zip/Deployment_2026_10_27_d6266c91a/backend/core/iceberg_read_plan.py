"""THE chokepoint that decides how a set of Iceberg data files is READ and
PROJECTED by DuckDB (2026-09-25).

Measured on the Docker rig against Trino's ``iceberg.qs.trades``:

* Trino writes the identity partition directory as ``region=MIDDLE+EAST``
  (URL form-encoding).  Every view was built with ``hive_partitioning=true``,
  so DuckDB took the value from the PATH and overrode the column stored in
  the file: QueryStudio served ``MIDDLE+EAST`` and ``WHERE region = 'MIDDLE
  EAST'`` returned ZERO rows with status completed (Trino: 296,877).
* ``SELECT *`` carried three phantom columns -- ``dt_month`` (a hidden
  partition transform, not a table column) and, on merge-on-read views,
  ``filename`` / ``file_row_number`` (the view's own helper columns).
* ``desk``, a column ADDED to the schema and present in no data file, was
  missing: the Iceberg CURRENT schema is the authority for the column list.

Iceberg partition values live in the MANIFEST (and, for identity transforms,
in the data files themselves); the directory name is a writer convenience
and is not required to round-trip.  So a data file is read with
``hive_partitioning=false`` and the current schema is projected explicitly:
every declared column in schema order, ``NULL`` for a column no file carries,
and nothing else.

SAFETY -- a table migrated from Hive (``add_files`` / ``migrate``) may not
PHYSICALLY store its identity partition columns; for such a table the path is
the only source of the value.  The switch to file values is therefore gated on
proof from the manifest: every data file the query will read must record the
identity partition source column in its per-file metrics (``column_sizes`` is
written by every Iceberg writer for every physical column; ``value_counts`` /
``null_value_counts`` are the fallbacks).  Anything short of that proof --
metrics missing on any file, a file list substituted by a mirror or a
materialized island, a read-plan the reader could not export (cache entry
from before this module, db-first read) -- keeps TODAY's behaviour byte for
byte (``hive_partitioning=true`` + ``_build_iceberg_read_expr``) and says why
at INFO.  Never fewer rows than today.

Every Iceberg read route builds its SQL from :func:`plan_iceberg_read` --
the plain batch view (``setup_registered_views``), the streaming view
(``register_s3_views``), the deferred raw-SQL view (``execute_api``), the
merge-on-read view (``iceberg_mor.build_mor_view_sql`` via
``_apply_mor_view``), the mirror builder (``iceberg_mirror``) and, since
2026-10-26, the federation report road (``FederationEngine._table_to_
expression``: MoR tables since 2026-10-25, append-only tables too since
2026-10-26 -- its own ``read_parquet`` spelling typed a DATE identity key as
VARCHAR).  A decision made twice is a bug here.

Reader-side helpers (:func:`read_plan_inputs_from_metadata`,
:class:`ColumnPresenceAccumulator`) live in this module too so the producer
and the consumer of ``_out_meta["iceberg_read_plan"]`` cannot drift.

2026-10-06 -- SCHEMA EVOLUTION IS READ BY FIELD ID (found on real AWS against
a Trino 483 table: ``ALTER TABLE fact_tetb ADD COLUMN reporting_basis`` then a
fourth COB loaded; ``where business_close_date >= DATE '2025-10-01'`` failed
``Referenced column "reporting_basis" not found`` in every worker AND in the
single-process fallback; Trino answers NULL for the old COBs).  Two causes,
both here:

* the projection was a list of NAMES over a ``read_parquet`` whose column set
  is whatever the FILES carry.  A worker handed only pre-ALTER files (the
  multi-worker split is by partition) has no such column, and the column list
  came from the manifest's ``column_sizes`` -- which a writer omits for any
  column in metrics mode ``none`` (Iceberg's default past the first 100
  columns), so presence can say "stored nowhere" for a column every new file
  carries.
* ``union_by_name`` was decided from the schema HISTORY in metadata.json,
  which a table may no longer carry (expired metadata), so the route read
  "uniform schema" and the first old file fixed the column set.

Iceberg's rule is to project the CURRENT schema by FIELD ID: a column absent
from a file reads NULL, a renamed column follows its id, a dropped column is
not served, an ``int`` -> ``long`` / ``float`` -> ``double`` / decimal widening
is a cast.  DuckDB implements exactly that with ``read_parquet(...,
schema=MAP {field_id: {name, type, default_value}})``, which needs no
``union_by_name`` and binds identically for ANY subset of the files -- so a
worker's slice, the single-process read and the MoR data scan all see one
column list.  That is ``projection == "field_id"``, the files-mode read
whenever it is safe:

* the table declares no ``schema.name-mapping.default`` -- a name mapping is
  what every migrate / ``add_files`` implementation (Spark, Trino, pyiceberg)
  sets when it imports files WITHOUT field ids, and DuckDB reads an id-less
  file under ``schema=`` as all-NULL;
* every current top-level type maps exactly to a DuckDB type (nested types,
  ``timestamptz_ns`` and v3 types keep the name-based read).

Otherwise the read is by NAME (``projection == "name"``), made evolution-safe:
every current column is projected over the read UNION ALL BY NAME a typed
zero-row relation carrying the current schema, so a column no file in the
slice carries is NULL instead of a binder error, and ``union_by_name`` is
forced when evolution is POSSIBLE (history, ``current-schema-id`` > 0, or
``last-column-id`` above the current schema's ids) unless a type conflict
forbids it.  A RENAMED column is read as ``COALESCE("new", "old", ...)`` over
the names the schema history and the name mapping give its field id (only
names no other id ever carried); when the old schemas are expired and there
is no name mapping, an added column and a renamed one look the same, so the
pad is left off entirely -- a slice lacking a column then fails LOUDLY and the
query falls back to the whole file set, rather than serving a NULL that may be
a renamed column's value.  The hive-path read keeps ``SELECT *`` and gains the
same pad (``SELECT * REPLACE (COALESCE(...))`` for a rename).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

# The key under which the reader exports the plan inputs in ``_out_meta`` and
# under which the L1 file cache carries them across a cache hit.
META_KEY = "iceberg_read_plan"

FIDELITY_FILES = "files"          # values from the data files (hive_partitioning=false)
FIDELITY_HIVE_PATH = "hive_path"  # today's behaviour (hive_partitioning=true)


# ═══════════════════════════════════════════════════════════════════════════
# Reader side -- what the manifest walk exports
# ═══════════════════════════════════════════════════════════════════════════

def _current_schema(metadata: dict) -> Optional[dict]:
    schemas = metadata.get("schemas") or (
        [metadata["schema"]] if isinstance(metadata.get("schema"), dict) else [])
    cur_id = metadata.get("current-schema-id")
    cur = None
    if cur_id is not None:
        cur = next((s for s in schemas
                    if isinstance(s, dict) and s.get("schema-id") == cur_id), None)
    if cur is None and schemas:
        cur = schemas[0] if isinstance(schemas[0], dict) else None
    return cur


def _all_field_ids(fields, out: set) -> None:
    """Every field-id in a schema, nested included (to tell a DROPPED
    partition source from a NESTED one)."""
    for f in fields or []:
        if not isinstance(f, dict):
            continue
        fid = f.get("id") if f.get("id") is not None else f.get("field-id")
        if fid is not None:
            out.add(fid)
        t = f.get("type")
        if isinstance(t, dict):
            kind = t.get("type")
            if kind == "struct":
                _all_field_ids(t.get("fields"), out)
            elif kind == "list":
                if t.get("element-id") is not None:
                    out.add(t["element-id"])
                if isinstance(t.get("element"), dict):
                    _all_field_ids([{"id": t.get("element-id"), "type": t["element"]}], out)
            elif kind == "map":
                for k in ("key-id", "value-id"):
                    if t.get(k) is not None:
                        out.add(t[k])
                for k in ("key", "value"):
                    if isinstance(t.get(k), dict):
                        _all_field_ids([{"id": t.get(k + "-id"), "type": t[k]}], out)


def read_plan_inputs_from_metadata(metadata: dict) -> Optional[Dict[str, Any]]:
    """Pure function of ``metadata.json``: the current schema (name, type,
    field-id, in schema order), the field-ids of every IDENTITY partition
    source column across ALL specs (an older spec's identity column is still
    a data column the files must carry), and the cross-version type-conflict
    flag that forbids ``union_by_name`` (DuckDB 1.5.3 segfault).

    ``identity_unresolvable`` is True when an identity partition's source is
    not a TOP-LEVEL column of the current schema but still exists somewhere
    (nested): the value cannot be projected by name, so the planner keeps the
    path.  A source that exists in NO schema is a dropped column and is
    ignored -- it is not in the current schema, so it is not served.

    Returns None when there is no usable schema (the planner then keeps
    today's behaviour).
    """
    if not isinstance(metadata, dict):
        return None
    cur = _current_schema(metadata)
    if not isinstance(cur, dict):
        return None
    schema: List[Dict[str, Any]] = []
    top_ids: set = set()
    for f in cur.get("fields") or []:
        if not isinstance(f, dict) or not f.get("name"):
            continue
        fid = f.get("id") if f.get("id") is not None else f.get("field-id")
        schema.append({"name": f["name"], "type": f.get("type"), "id": fid})
        if fid is not None:
            top_ids.add(fid)
    if not schema:
        return None

    any_ids: set = set()
    for s in metadata.get("schemas") or []:
        if isinstance(s, dict):
            _all_field_ids(s.get("fields"), any_ids)
    if isinstance(metadata.get("schema"), dict):
        _all_field_ids(metadata["schema"].get("fields"), any_ids)

    specs = [s for s in (metadata.get("partition-specs") or []) if isinstance(s, dict)]
    if not specs and "partition-spec" in metadata:
        ps = metadata["partition-spec"]
        if isinstance(ps, list):
            specs = [{"fields": ps}]
        elif isinstance(ps, dict):
            specs = [ps]
    identity_fids: List[int] = []
    identity_parts: List[Dict[str, Any]] = []
    identity_unresolvable = False
    for spec in specs:
        for pf in spec.get("fields") or []:
            if not isinstance(pf, dict):
                continue
            transform = str(pf.get("transform") or "identity").strip().lower()
            if transform != "identity":
                continue
            src = pf.get("source-id") if pf.get("source-id") is not None else pf.get("source_id")
            if src is None:
                identity_unresolvable = True
                continue
            if src in top_ids:
                if src not in identity_fids:
                    identity_fids.append(src)
                if pf.get("name") and not any(
                        p["name"] == pf["name"] for p in identity_parts):
                    identity_parts.append({"name": str(pf["name"]), "source_id": src})
            elif src in any_ids:
                identity_unresolvable = True   # nested -- cannot project by name
            # else: dropped column -- not in the current schema, not served

    try:
        from core.iceberg_reader import detect_iceberg_type_conflicts
        type_conflict = bool(detect_iceberg_type_conflicts(metadata))
    except Exception:
        type_conflict = True   # unknown = unsafe for union_by_name forcing

    history = _schema_history(metadata)
    props = metadata.get("properties") if isinstance(metadata.get("properties"), dict) else {}
    _merge_name_mapping(props.get(NAME_MAPPING_PROPERTY), schema, history)
    return {
        "schema": schema,
        "identity_source_fids": identity_fids,
        # 2026-10-06 -- {name: directory key, source_id}: the hive-path read
        # DECLARES each key's type from the current schema (never a guess).
        "identity_partitions": identity_parts,
        "identity_unresolvable": identity_unresolvable,
        "type_conflict": type_conflict,
        "presence": None,
        "files_substituted": False,
        # 2026-10-06 -- the field-id read's inputs (see the module docstring).
        "schema_id": cur.get("schema-id"),
        "name_mapping": bool(props.get(NAME_MAPPING_PROPERTY)),
        "evolution_possible": _evolution_possible(metadata, schema, history),
        "renamed_fids": sorted(history["renamed_fids"]),
        "reused_names": sorted(history["reused_names"]),
        # {str(field id): [older names no other field id ever used]} -- what a
        # by-NAME read may COALESCE under the current name (a name mapping
        # lists the same names for the same id).
        "rename_sources": {str(k): v for k, v in sorted(history["rename_sources"].items())},
        # Every schema id from 0 to the highest listed is still listed: a
        # rename can be SEEN.  Without it (or a name mapping) a by-name read
        # cannot tell an added column from a renamed one, so it pads nothing.
        "history_complete": _history_complete(metadata),
    }


def _history_complete(metadata: dict) -> bool:
    ids = set()
    for s in metadata.get("schemas") or []:
        if isinstance(s, dict) and isinstance(s.get("schema-id"), int):
            ids.add(s["schema-id"])
    if not ids:
        return not metadata.get("schemas") and isinstance(metadata.get("schema"), dict)
    return ids >= set(range(0, max(ids) + 1))


def _merge_name_mapping(raw: Any, schema: List[Dict[str, Any]],
                        history: Dict[str, Any]) -> None:
    """A name mapping (``[{"field-id": 5, "names": ["old_name", "new_name"]}]``)
    is the table's own statement of every name a top-level field id is stored
    under in files without ids -- Iceberg's by-name read.  Its names join the
    rename sources when no other field id claims them."""
    if not raw:
        return
    try:
        import json as _json
        mapping = _json.loads(raw) if isinstance(raw, str) else raw
    except (TypeError, ValueError):
        return
    if not isinstance(mapping, list):
        return
    cur = {f.get("id"): str(f["name"]) for f in schema if isinstance(f, dict) and f.get("name")}
    claims: Dict[str, set] = {}
    by_id: Dict[Any, List[str]] = {}
    for entry in mapping:
        if not isinstance(entry, dict):
            continue
        fid = entry.get("field-id")
        for n in entry.get("names") or []:
            claims.setdefault(str(n).lower(), set()).add(fid)
            by_id.setdefault(fid, []).append(str(n))
    for fid, n in cur.items():
        claims.setdefault(n.lower(), set()).add(fid)
    sources = history["rename_sources"]
    for fid, names in by_id.items():
        if fid not in cur:
            continue
        for n in names:
            if n == cur[fid] or claims.get(n.lower()) != {fid}:
                continue
            lst = sources.setdefault(fid, [])
            if n not in lst:
                lst.append(n)
                history["renamed_fids"].add(fid)


#: The table property every migrate / ``add_files`` implementation sets when
#: it registers files that carry no Parquet field ids.
NAME_MAPPING_PROPERTY = "schema.name-mapping.default"


def _schema_history(metadata: dict) -> Dict[str, set]:
    """What the schemas still listed in ``metadata.json`` say about NAMES.

    ``renamed_fids``: current top-level field ids that carried a different
    name in an older schema.  ``reused_names``: lower-cased current names
    that an older schema gave to a DIFFERENT field id (drop + re-add).
    ``rename_sources``: per renamed id, its older names that NO other field
    id ever carried (safe to read by name as that id).  All are only as
    complete as the history the file keeps; an empty answer means "none
    seen", never "none happened".
    """
    cur = _current_schema(metadata) or {}
    cur_names: Dict[Any, str] = {}
    for f in cur.get("fields") or []:
        if isinstance(f, dict) and f.get("name"):
            fid = f.get("id") if f.get("id") is not None else f.get("field-id")
            cur_names[fid] = str(f["name"])
    renamed: set = set()
    reused: set = set()
    cur_by_lower = {n.lower(): fid for fid, n in cur_names.items()}
    owners: Dict[str, set] = {}                 # lower name -> every id that had it
    old_names: Dict[Any, List[str]] = {}
    for s in metadata.get("schemas") or []:
        if not isinstance(s, dict):
            continue
        for f in s.get("fields") or []:
            if not isinstance(f, dict) or not f.get("name"):
                continue
            fid = f.get("id") if f.get("id") is not None else f.get("field-id")
            name = str(f["name"])
            owners.setdefault(name.lower(), set()).add(fid)
            if fid in cur_names and cur_names[fid] != name:
                renamed.add(fid)
                if name not in old_names.setdefault(fid, []):
                    old_names[fid].append(name)
            owner = cur_by_lower.get(name.lower())
            if owner is not None and owner != fid:
                reused.add(name.lower())
    for fid, n in cur_names.items():
        owners.setdefault(n.lower(), set()).add(fid)
    sources = {fid: [n for n in names if owners.get(n.lower()) == {fid}]
               for fid, names in old_names.items()}
    return {"renamed_fids": renamed, "reused_names": reused,
            "rename_sources": {k: v for k, v in sources.items() if v}}


def _evolution_possible(metadata: dict, schema: List[Dict[str, Any]],
                        history: Dict[str, set]) -> bool:
    """True when the data files MAY differ in column set from each other or
    from the current schema.  Deliberately not only the listed history: a
    table's old schemas can be expired from ``metadata.json``, and the 2026-10-06
    rig read "uniform schema" for a table whose files plainly differed.
    Schema ids start at 0 and advance on every change; ``last-column-id``
    above every current id means a column was dropped."""
    schemas = [s for s in (metadata.get("schemas") or []) if isinstance(s, dict)]
    if len(schemas) > 1 or history["renamed_fids"] or history["reused_names"]:
        return True
    cur_id = metadata.get("current-schema-id")
    try:
        if cur_id is not None and int(cur_id) != 0:
            return True
    except (TypeError, ValueError):
        return True
    ids = [f.get("id") for f in schema if isinstance(f.get("id"), int)]
    last = metadata.get("last-column-id")
    if isinstance(last, int) and ids and last > max(ids):
        # nested ids also count toward last-column-id; only a top-level-only
        # schema makes this exact, and a false "possible" costs speed only.
        return True
    return False


class ColumnPresenceAccumulator:
    """Per-file column presence from the manifest's metrics maps.

    ``observe(keys)`` is called once per data file the query will read with
    the field-id keys of that file's ``column_sizes`` (or, when the writer
    omitted it, ``value_counts`` / ``null_value_counts``).  A file with none
    of those maps counts as a file WITHOUT metrics -- the planner then
    cannot prove anything about it and keeps today's behaviour.
    """

    __slots__ = ("files", "files_with_metrics", "present")

    def __init__(self) -> None:
        self.files = 0
        self.files_with_metrics = 0
        self.present: Dict[int, int] = {}

    def observe(self, keys: Optional[Iterable[Any]]) -> None:
        self.files += 1
        fids: set = set()
        for k in (keys or ()):
            try:
                fids.add(int(k))
            except (TypeError, ValueError):
                continue
        if not fids:
            return
        self.files_with_metrics += 1
        for fid in fids:
            self.present[fid] = self.present.get(fid, 0) + 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "files": self.files,
            "files_with_metrics": self.files_with_metrics,
            # JSON/L1-cache friendly: string keys
            "present": {str(k): v for k, v in self.present.items()},
        }


# ═══════════════════════════════════════════════════════════════════════════
# Consumer side -- the plan
# ═══════════════════════════════════════════════════════════════════════════

PROJECTION_FIELD_ID = "field_id"  # read_parquet(schema=MAP{field_id: ...})
PROJECTION_NAME = "name"          # current names over the read + a typed pad
PROJECTION_NONE = "none"          # hive-path SELECT * (+ pad)


@dataclass
class IcebergReadPlan:
    read_paths: List[str]
    fidelity: str                      # FIDELITY_FILES | FIDELITY_HIVE_PATH
    reason: str
    hive_partitioning: bool
    union_by_name: bool
    from_expr: str                     # the FROM expression (single read or UNION ALL BY NAME)
    select_list: str                   # explicit projection, or "*"
    projected: bool
    columns: List[str] = field(default_factory=list)      # projected names, schema order
    null_columns: List[str] = field(default_factory=list) # declared, absent from every file
    fallback_projection: Optional[List[str]] = None       # hive_path mode: today's optional projection
    # 2026-10-06 -- schema evolution (see the module docstring).
    projection: str = PROJECTION_NONE
    #: ``read_parquet`` option text carrying ``schema=MAP {...}`` (field-id
    #: mode only).  Kept AFTER ``hive_partitioning=`` in every emitted call:
    #: ``multi_worker_dispatcher`` classifies a data array by finding that
    #: option before the first ``)`` -- and a type such as ``DECIMAL(38, 6)``
    #: in the map has one.
    schema_option: str = ""
    #: ``SELECT <typed NULL> AS "col", ... WHERE FALSE`` -- UNION ALL BY NAME
    #: onto the read so every current column BINDS in any slice of the files.
    pad_select: str = ""
    #: field id -> (current name, DuckDB type) for every projected column
    #: (field-id mode); the MoR builder maps equality-delete files with it.
    field_types: Dict[int, Any] = field(default_factory=dict)
    #: `` REPLACE (COALESCE("new", "old") AS "new")`` for a ``SELECT *`` read
    #: by name (hive-path mode) -- a renamed column answered by every file.
    star_replace: str = ""

    @property
    def read_options(self) -> str:
        """The ``read_parquet`` options the MoR data CTE must use so it reads
        the files the same way the plain view does."""
        if self.projection == PROJECTION_FIELD_ID:
            return f"hive_partitioning=false, {self.schema_option}"
        return (f"hive_partitioning={'true' if self.hive_partitioning else 'false'}"
                f", union_by_name=true")


def _sql_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _esc(v: str) -> str:
    return str(v).replace("'", "''")


_ICEBERG_PRIMITIVE_TO_DUCKDB = {
    "boolean": "BOOLEAN",
    "int": "INTEGER",
    "integer": "INTEGER",
    "long": "BIGINT",
    "float": "FLOAT",
    "double": "DOUBLE",
    "date": "DATE",
    "time": "TIME",
    "timestamp": "TIMESTAMP",
    "timestamptz": "TIMESTAMP WITH TIME ZONE",
    "timestamp_ns": "TIMESTAMP_NS",
    "string": "VARCHAR",
    "uuid": "UUID",
    "binary": "BLOB",
}


def iceberg_type_to_duckdb_exact(itype: Any) -> Optional[str]:
    """The DuckDB type an Iceberg PRIMITIVE reads as, or None when there is no
    exact counterpart (nested types, ``timestamptz_ns``, v3 ``variant`` /
    ``geometry`` / ``unknown``).  None is "cannot say", never VARCHAR: the
    field-id read casts every file to these types, so a guess would be a
    wrong value, not a slow one."""
    if not isinstance(itype, str):
        return None
    t = itype.strip().lower()
    if t in _ICEBERG_PRIMITIVE_TO_DUCKDB:
        return _ICEBERG_PRIMITIVE_TO_DUCKDB[t]
    if t.startswith("decimal(") and t.endswith(")"):
        inner = t[len("decimal("):-1].split(",")
        try:
            p, s = int(inner[0]), int(inner[1])
        except (IndexError, ValueError):
            return None
        if 0 < p <= 38 and 0 <= s <= p:
            return f"DECIMAL({p}, {s})"
        return None
    if t.startswith("fixed[") and t.endswith("]"):
        return "BLOB"
    return None


def _null_projection(name: str, itype: Any) -> str:
    """``NULL`` typed when the Iceberg type maps simply, else untyped."""
    if isinstance(itype, str) and itype.strip():
        duck = iceberg_type_to_duckdb_exact(itype)
        if duck is None:
            try:
                from core.duckdb_views import _iceberg_type_to_duckdb
                duck = _iceberg_type_to_duckdb(itype)
            except Exception:
                duck = None
        if duck:
            return f"NULL::{duck} AS {_sql_ident(name)}"
    return f"NULL AS {_sql_ident(name)}"


def _rename_sources(inputs: Optional[Dict[str, Any]]) -> Dict[int, List[str]]:
    out: Dict[int, List[str]] = {}
    for k, v in ((inputs or {}).get("rename_sources") or {}).items():
        try:
            out[int(k)] = [str(n) for n in v or [] if n]
        except (TypeError, ValueError):
            continue
    return out


def _by_name_expr(f: Dict[str, Any], sources: Dict[int, List[str]]) -> Optional[str]:
    """``COALESCE("new", "old", ...) AS "new"`` for a renamed field whose older
    names no other field id ever carried (a file holds exactly one of them --
    the name it was written under); None when the field was not renamed."""
    olds = sources.get(f.get("id")) if isinstance(f.get("id"), int) else None
    if not olds:
        return None
    names = [f["name"]] + olds
    return (f"COALESCE({', '.join(_sql_ident(n) for n in names)}) "
            f"AS {_sql_ident(f['name'])}")


def _pad_select(schema: Optional[List[Dict[str, Any]]],
                inputs: Optional[Dict[str, Any]], *,
                skip_identity_sources: bool = False) -> str:
    """The zero-row typed relation UNION ALL BY NAME'd onto a by-NAME read so
    every current column binds whatever files the slice holds -- and, for a
    renamed field, every older name it may be stored under (the projection
    COALESCEs them).  Left out, because padding would turn a loud binder
    error into a silent wrong answer: a renamed field whose older name some
    other field id also used (or whose history is gone), and a current name
    an older schema gave to another field id."""
    if not isinstance(schema, list) or not schema:
        return ""
    if not ((inputs or {}).get("history_complete") or (inputs or {}).get("name_mapping")):
        # Old schemas expired and no name mapping: an added column and a
        # renamed one look the same, and a NULL pad would answer the renamed
        # one wrongly in silence.  Pad nothing -- a slice that lacks a column
        # fails loudly and the query falls back to the whole file set.
        return ""
    renamed = {int(x) for x in (inputs or {}).get("renamed_fids") or []
               if isinstance(x, int) or str(x).lstrip("-").isdigit()}
    reused = {str(x).lower() for x in (inputs or {}).get("reused_names") or []}
    sources = _rename_sources(inputs)
    # On the hive-path read an identity partition source column comes from the
    # PATH (typed by DuckDB's autocast); padding it would re-type that column.
    skip = set()
    if skip_identity_sources:
        for x in (inputs or {}).get("identity_source_fids") or []:
            try:
                skip.add(int(x))
            except (TypeError, ValueError):
                continue
    parts = []
    for f in schema:
        if not isinstance(f, dict) or not f.get("name"):
            continue
        fid = f.get("id")
        if isinstance(fid, int) and fid in skip:
            continue
        if str(f["name"]).lower() in reused:
            continue
        if isinstance(fid, int) and fid in renamed:
            if fid not in sources:
                continue
            for old in sources[fid]:
                parts.append(_null_projection(old, f.get("type")))
        parts.append(_null_projection(f["name"], f.get("type")))
    if not parts:
        return ""
    return f"SELECT {', '.join(parts)} WHERE FALSE"


def _star_replace(schema: Optional[List[Dict[str, Any]]],
                  inputs: Optional[Dict[str, Any]]) -> str:
    """`` REPLACE (COALESCE(...) AS "new", ...)`` for a ``SELECT *`` read by
    name (the hive-path view), or ""."""
    if not isinstance(schema, list):
        return ""
    sources = _rename_sources(inputs)
    exprs = [e for e in (_by_name_expr(f, sources) for f in schema
                         if isinstance(f, dict) and f.get("name")) if e]
    return f" REPLACE ({', '.join(exprs)})" if exprs else ""


def _force_union_for_evolution(ubn: bool, inputs: Optional[Dict[str, Any]],
                               n_files: int, table_name: str,
                               log_prefix: str) -> bool:
    """A by-NAME read of files that may differ in column set needs
    ``union_by_name`` or the FIRST file fixes the columns (the 2026-10-06
    rig failure).  Forced on when evolution is possible, unless a type
    conflict forbids it (DuckDB 1.5.3 segfault) -- then the read fails as it
    does today, loudly."""
    if ubn or not isinstance(inputs, dict) or not inputs.get("evolution_possible"):
        return ubn
    if inputs.get("type_conflict"):
        logger.warning(
            "%s '%s': schema evolution is possible but the schema has a "
            "cross-version TYPE conflict, so union_by_name stays OFF (DuckDB "
            "1.5.3 segfault) -- files that differ in column set will fail the "
            "by-name read, as they do today.", log_prefix, table_name)
        return False
    logger.info(
        "%s '%s': schema evolution is possible (history / schema-id / dropped "
        "column ids) -- union_by_name=true forced on for this by-name read of "
        "%d file(s), whatever the route decided.", log_prefix, table_name, n_files)
    return True


def _hive_path_plan(read_paths: List[str], union_by_name: bool, reason: str,
                    schema_names: Optional[List[str]], table_name: str,
                    log_prefix: str,
                    inputs: Optional[Dict[str, Any]] = None) -> IcebergReadPlan:
    """TODAY's read, unchanged: hive_partitioning=true through the
    partition-spec-evolution helper, ``SELECT *`` -- plus (2026-10-06) the
    typed pad, so a current column that no file in the slice carries is NULL
    rather than a binder error, and ``union_by_name`` when evolution is
    possible."""
    from core.duckdb_views import _build_iceberg_read_expr
    ubn = _force_union_for_evolution(union_by_name, inputs, len(read_paths),
                                     table_name, log_prefix)
    union_clause = ", union_by_name=true" if ubn else ""
    # 2026-10-06 -- the directory keys' types are DECLARED (identity partition
    # -> its source column's current type; anything else the literal string),
    # never DuckDB's per-read guess (a STRING ``code=51`` read as BIGINT).
    from core.hive_partition_types import (
        iceberg_identity_partition_types, common_hive_keys,
    )
    identity_types = iceberg_identity_partition_types(inputs)
    if read_paths and not identity_types:
        # 2026-10-26 -- UNKNOWN IS NOT SILENT.  With nothing declared every
        # directory key reads as the literal string (``hive_types_autocast=
        # false``): a DATE key then mis-binds (``strftime(VARCHAR, ...)``), a
        # numeric key compares as text.  Say so, naming the keys and why the
        # plan has no schema to type them from.
        undeclared = common_hive_keys(read_paths)
        if undeclared:
            logger.warning(
                "%s '%s': no identity partition types for the directory keys %s "
                "-- they read as VARCHAR on this read (%s)",
                log_prefix, table_name, list(undeclared), reason)
    from_expr = _build_iceberg_read_expr(
        list(read_paths), union_clause=union_clause,
        hive_types=identity_types)
    evolved = "UNION ALL BY NAME" in from_expr
    schema = (inputs or {}).get("schema") if isinstance(inputs, dict) else None
    pad = _pad_select(schema, inputs, skip_identity_sources=True) if read_paths else ""
    logger.info(
        "%s '%s': Iceberg read keeps partition values from the HIVE PATH "
        "(hive_partitioning=true, %d file(s)) -- %s",
        log_prefix, table_name, len(read_paths), reason,
    )
    return IcebergReadPlan(
        read_paths=list(read_paths), fidelity=FIDELITY_HIVE_PATH, reason=reason,
        hive_partitioning=True, union_by_name=ubn,
        from_expr=from_expr, select_list="*", projected=False,
        fallback_projection=(list(schema_names) if (schema_names and not evolved) else None),
        projection=PROJECTION_NONE,
        pad_select=pad,
        star_replace=_star_replace(schema, inputs) if pad else "",
    )


def _presence_counts(presence: Dict[str, Any]) -> Dict[int, int]:
    present: Dict[int, int] = {}
    for k, v in (presence.get("present") or {}).items():
        try:
            present[int(k)] = int(v)
        except (TypeError, ValueError):
            continue
    return present


def _hive_path_reason(inputs: Optional[Dict[str, Any]],
                      schema: Optional[List[Dict[str, Any]]]) -> Optional[str]:
    """Why the files cannot be PROVEN to store every identity partition
    column (the path is then the only safe source), or None when they can."""
    if not isinstance(inputs, dict) or not schema:
        return ("no read-plan metadata (cache entry from before the read plan, "
                "db-first read, or the reader could not export the current schema)")
    if inputs.get("files_substituted"):
        return ("the file list was substituted (mirror / materialized island) "
                "-- these are not the manifest's data files")
    if inputs.get("identity_unresolvable"):
        return ("an identity partition source is not a top-level column of the "
                "current schema (nested) -- cannot project it by name")
    presence = inputs.get("presence")
    if not isinstance(presence, dict):
        return "the reader exported no per-file column presence"
    n_files = int(presence.get("files") or 0)
    n_with = int(presence.get("files_with_metrics") or 0)
    if n_files <= 0 or n_with < n_files:
        return (f"{n_files - n_with} of {n_files} data file(s) carry no column "
                f"metrics in the manifest -- cannot prove the identity "
                f"partition columns are stored in the files")
    present = _presence_counts(presence)
    for fid in inputs.get("identity_source_fids") or []:
        try:
            fid_i = int(fid)
        except (TypeError, ValueError):
            return "identity partition source field-id unreadable"
        if present.get(fid_i, 0) != n_files:
            col = next((f.get("name") for f in schema
                        if isinstance(f, dict) and f.get("id") == fid_i), fid_i)
            return (f"identity partition column '{col}' is physically stored in "
                    f"{present.get(fid_i, 0)} of {n_files} data file(s) (migrated "
                    f"/ add_files table?) -- the path is the only source of its value")
    return None


def field_id_decline_reason(inputs: Dict[str, Any]) -> Optional[str]:
    """Why the current schema cannot be read BY FIELD ID, or None when it can.

    The field-id read is exact for every file that carries Parquet field ids
    -- and silently all-NULL for one that does not, so the table must not be
    one whose files were imported without ids (a name mapping is declared,
    or the inputs predate the property and cannot say)."""
    if "name_mapping" not in inputs:
        return "the read-plan inputs predate the name-mapping check"
    if inputs.get("name_mapping"):
        return (f"the table declares '{NAME_MAPPING_PROPERTY}' (files imported "
                f"without field ids) -- read by name")
    seen: set = set()
    for f in inputs.get("schema") or []:
        if not isinstance(f, dict) or not f.get("name"):
            return "a current-schema field has no name"
        if not isinstance(f.get("id"), int):
            return f"column '{f['name']}' has no field id"
        if iceberg_type_to_duckdb_exact(f.get("type")) is None:
            return (f"column '{f['name']}' type {f.get('type')!r} has no exact "
                    f"DuckDB counterpart for a field-id read")
        low = str(f["name"]).lower()
        if low in seen:
            return f"two current columns are named '{f['name']}' case-insensitively"
        seen.add(low)
    return None


def _field_id_schema_option(schema: List[Dict[str, Any]]) -> tuple:
    entries = []
    types: Dict[int, Any] = {}
    for f in schema:
        duck = iceberg_type_to_duckdb_exact(f.get("type"))
        fid = int(f["id"])
        types[fid] = (f["name"], duck)
        entries.append(
            f"{fid}: {{name: '{_esc(f['name'])}', type: '{duck}', default_value: NULL}}")
    return "schema=MAP {" + ", ".join(entries) + "}", types


def plan_iceberg_read(read_paths: List[str], *, meta: Optional[Dict[str, Any]],
                      union_by_name: bool, table_name: str = "",
                      log_prefix: str = "REG-VIEW") -> IcebergReadPlan:
    """Decide, ONCE, how ``read_paths`` (the paths DuckDB will actually read:
    presigned URLs, local pre-downloads or raw s3:// URIs -- parallel to the
    manifest's data files) are read and projected.

    ``meta`` is the reader's ``_out_meta`` (or the L1-cache restore of it);
    the decision is driven entirely by ``meta[META_KEY]``.  ``union_by_name``
    is the route's already-resolved decision (config flag, schema-evolution
    threshold, type-conflict guard) and is honoured; it is forced ON only when
    the manifest PROVES the files differ in column sets, or schema evolution
    is possible, and no type conflict forbids it -- without it that read
    fails or mis-binds.  A field-id read needs none of it.
    """
    read_paths = list(read_paths or [])
    inputs = (meta or {}).get(META_KEY) if isinstance(meta, dict) else None
    schema = (inputs or {}).get("schema") if isinstance(inputs, dict) else None
    schema_names = [f["name"] for f in schema if isinstance(f, dict) and f.get("name")] \
        if isinstance(schema, list) else None

    if not read_paths:
        return _hive_path_plan(read_paths, union_by_name, "no data files",
                               schema_names, table_name, log_prefix, inputs)
    keep_reason = _hive_path_reason(inputs, schema if schema_names else None)
    if keep_reason is not None:
        return _hive_path_plan(read_paths, union_by_name, keep_reason,
                               schema_names, table_name, log_prefix,
                               inputs if schema_names else None)

    presence = inputs["presence"]
    n_files = int(presence.get("files") or 0)
    present = _presence_counts(presence)
    reason = (f"identity partition columns are stored in every one of the "
              f"{n_files} data file(s) (manifest metrics)")
    columns = [f["name"] for f in schema if isinstance(f, dict) and f.get("name")]
    # ``null_columns`` is INFORMATIONAL: a field no file's metrics name.  A
    # writer omits metrics for columns in mode ``none`` (Iceberg's default
    # past the first 100), so this is "no evidence", not "absent" -- neither
    # projection below reads it as a NULL.
    null_columns = [f["name"] for f in schema if isinstance(f, dict) and f.get("name")
                    and present.get(f.get("id"), 0) == 0]
    paths_str = ", ".join(f"'{_esc(p)}'" for p in read_paths)

    # ── files mode, BY FIELD ID ───────────────────────────────────────────
    decline = field_id_decline_reason(inputs)
    if decline is None:
        schema_option, types = _field_id_schema_option(schema)
        from_expr = f"read_parquet([{paths_str}], hive_partitioning=false, {schema_option})"
        logger.info(
            "%s '%s': Iceberg read takes partition values from the DATA FILES "
            "(hive_partitioning=false) and projects the current schema (id %s) "
            "BY FIELD ID: %d column(s) -- renames follow the id, columns a file "
            "lacks read NULL -- %s",
            log_prefix, table_name, inputs.get("schema_id"), len(columns), reason,
        )
        return IcebergReadPlan(
            read_paths=read_paths, fidelity=FIDELITY_FILES, reason=reason,
            hive_partitioning=False, union_by_name=False,
            from_expr=from_expr, select_list=", ".join(_sql_ident(c) for c in columns),
            projected=True, columns=columns, null_columns=null_columns,
            projection=PROJECTION_FIELD_ID, schema_option=schema_option,
            field_types=types,
        )

    # ── files mode, BY NAME ───────────────────────────────────────────────
    parts: List[str] = []
    reused = {str(x).lower() for x in inputs.get("reused_names") or []}
    pad = _pad_select(schema, inputs)
    # COALESCE over a renamed field's older names only when the pad carries
    # them: without it a slice (or a whole set written after the rename)
    # holding no file with the old name could not bind the expression.
    sources = _rename_sources(inputs) if pad else {}
    for f in schema:
        if not isinstance(f, dict) or not f.get("name"):
            continue
        # A name an older schema gave to ANOTHER field id: by name the old
        # files would answer for it with that other column's values.  When
        # no file's metrics name this id, NULL is the only safe answer.
        if str(f["name"]).lower() in reused and present.get(f.get("id"), 0) == 0:
            parts.append(_null_projection(f["name"], f.get("type")))
        else:
            parts.append(_by_name_expr(f, sources) or _sql_ident(f["name"]))
    ubn = bool(union_by_name)
    needs_union = any(0 < c < n_files for c in present.values())
    if needs_union and not ubn:
        if inputs.get("type_conflict"):
            logger.warning(
                "%s '%s': the manifest shows the %d data file(s) differ in column "
                "sets but the schema has a cross-version TYPE conflict, so "
                "union_by_name stays OFF (DuckDB 1.5.3 segfault) -- a column "
                "missing from the first file will fail the read, as it does "
                "today.", log_prefix, table_name, n_files)
        else:
            ubn = True
            logger.info(
                "%s '%s': the manifest PROVES the %d data file(s) differ in column "
                "sets -- union_by_name=true forced on for this read (without it "
                "DuckDB fails or mis-binds the missing column).",
                log_prefix, table_name, n_files)
    ubn = _force_union_for_evolution(ubn, inputs, n_files, table_name, log_prefix)
    from_expr = (f"read_parquet([{paths_str}], hive_partitioning=false"
                 f"{', union_by_name=true' if ubn else ''})")
    logger.info(
        "%s '%s': Iceberg read takes partition values from the DATA FILES "
        "(hive_partitioning=false) and projects the current schema BY NAME "
        "(%s): %d column(s) -- %s",
        log_prefix, table_name, decline, len(columns), reason,
    )
    return IcebergReadPlan(
        read_paths=read_paths, fidelity=FIDELITY_FILES, reason=reason,
        hive_partitioning=False, union_by_name=ubn,
        from_expr=from_expr, select_list=", ".join(parts), projected=True,
        columns=columns, null_columns=null_columns,
        projection=PROJECTION_NAME, pad_select=pad,
    )


def padded_relation(plan: IcebergReadPlan, relation_sql: str) -> str:
    """``relation_sql`` (a SELECT) UNION ALL BY NAME the plan's typed pad, as
    a parenthesised relation; the bare relation when there is no pad."""
    if not plan.pad_select:
        return f"({relation_sql})"
    return f"(({relation_sql}) UNION ALL BY NAME ({plan.pad_select}))"


def iceberg_view_source(plan: IcebergReadPlan) -> str:
    """The FROM source a view builder selects from: the read itself, or (a
    by-name plan with a pad) the read UNION ALL BY NAME the typed pad, aliased
    -- so a builder's own projection / ``SELECT *`` / WHERE binds every
    current column in any slice of the files."""
    if plan.pad_select and plan.projection != PROJECTION_FIELD_ID:
        return padded_relation(plan, f"SELECT * FROM {plan.from_expr}") + " AS _qs_src"
    return plan.from_expr


def iceberg_view_select_sql(plan: IcebergReadPlan, where_clause: str = "") -> str:
    """The ``SELECT ...`` body of a plain (no-deletes) Iceberg view.

    ``where_clause`` is the JOIN-PRUNER's row-group predicate (already
    rendered, without the ``WHERE`` keyword).  In files mode it is applied
    OVER the projection so it binds against the current schema -- a
    partition column it names now sees the FILE value.
    """
    where = f" WHERE {where_clause}" if where_clause else ""
    if plan.projection == PROJECTION_FIELD_ID:
        inner = f"SELECT {plan.select_list} FROM {plan.from_expr}"
        if where:
            return f"SELECT * FROM ({inner}) AS _qs_ice{where}"
        return inner
    if plan.projected:
        inner = f"SELECT {plan.select_list} FROM {iceberg_view_source(plan)}"
        if where:
            return f"SELECT * FROM ({inner}) AS _qs_ice{where}"
        return inner
    if plan.star_replace and where:
        return (f"SELECT * FROM (SELECT *{plan.star_replace} FROM "
                f"{iceberg_view_source(plan)}) AS _qs_ice{where}")
    return f"SELECT *{plan.star_replace} FROM {iceberg_view_source(plan)}{where}"
