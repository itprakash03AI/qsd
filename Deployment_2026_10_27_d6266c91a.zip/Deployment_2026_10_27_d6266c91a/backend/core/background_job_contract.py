"""Every background job DECLARES its status reader and its run-now -- in ONE
table -- and both are answered by the process that RUNS the job.

THE DEFECT CLASS THIS CLOSES (2026-10-07)
-----------------------------------------
The owner asked for every background job to be proven LIVE on Docker,
firing by itself.  A read-only map found that impossible for a third of
them and dishonest for another third:

* Jobs with NO observable status -- the snapshot reactions and warm-on-
  commit, the file-arrival watcher, ``brain_cleanup_daemon``, the snapshot
  indexer, the fleet syncer: their only record was a process-local counter
  or nothing at all.  "Did it fire?" had no answer.
* Per-daemon "run now" routes (``POST /api/admin/iceberg-watcher/run``,
  ``/iceberg/prefetch/tick``, ``/brain/cleanup-tick``, ... ten of them) ran
  the tick on WHICHEVER pod answered.  In the split topology
  (``scheduler.mode == "external"``) that is the API pod: the tick landed in
  the API pod's memory, the owner's status route never showed it, and a
  tick that needs the daemon's listeners (refresh-table) skipped them.
* Status routes that had been moved to the owner (``core/daemon_snapshots``)
  covered eight names by hand; the other forty were still answered from
  whichever process took the request.

THE MECHANISM
-------------
``CONTRACTS``: name -> :class:`JobContract`.  A contract carries

* ``status(db)``  -- the module's own state (its ring, its counters, its
  config), always declared;
* ``tick(db)``    -- ONE pass, returning the module's raw result; or
  ``job_id``      -- the APScheduler id, so one pass is "run the registered
  job's function" (the retention sweeps, the S3 jobs in core/scheduler.py);
  or ``no_run_now`` -- WHY the job cannot be run on demand (a consumer loop,
  an event-driven listener, a supervisor over a client it builds at start);
* ``scope``       -- ``scheduler`` (runs where SCHEDULER_OWNED daemons run:
  the scheduler worker in external mode, this process otherwise) or
  ``per_process`` (listeners, the per-pod prewarmer, the executor-role
  syncer: every process has its own copy and answers for itself).

ONE ledger (``record_tick``) holds the last ticks per job in the OWNING
process: run-now writes it, and the APScheduler listener
(:func:`attach_scheduler_listener`, attached by ``core.scheduler.
init_scheduler``) writes every SCHEDULED fire of a declared ``job_id`` --
so "did it fire by itself" is answered by the same record run-now writes.
A tick's result is classified into one OUTCOME: ``ok`` (did work),
``no_input`` (ran, nothing to do -- a tick that did nothing must NOT read
ok), ``unreadable`` (could not read its input), ``skipped`` (did not run
its body: disabled, paused, not the lock holder, not registered -- with
the reason), ``error``, or ``unknown`` (the scheduled wrapper returned no
result; run-now reports the outcome).

``status(name)`` / ``run_now(name)`` resolve the OWNER the way
``core.daemon_snapshots`` does: in-process when this process runs the job,
else proxied to the scheduler worker's control API
(``/control/background-job/{name}/...``); every answer says
``answered_by``.  A run-now whose owner cannot be reached is REFUSED (503),
never run on the wrong pod.  The per-daemon admin routes delegate here, so
one answer exists, not two.

THE GUARD
---------
``tests/test_background_job_contract_2026_10_07.py`` enumerates
``daemon_registry.SCHEDULER_OWNED`` plus :data:`EXTRA_JOBS` and fails if any
name has no contract, no status reader, or neither a tick, a job_id nor a
declared reason; it proves run-now and status are PROXIED from an API pod
in external mode; and it fires a real APScheduler job into the ledger.
"""
from __future__ import annotations

import logging
import threading
import time
import traceback
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── outcomes ────────────────────────────────────────────────────────────

OUTCOME_OK = "ok"
OUTCOME_NO_INPUT = "no_input"
OUTCOME_UNREADABLE = "unreadable"
OUTCOME_SKIPPED = "skipped"
OUTCOME_ERROR = "error"
OUTCOME_UNKNOWN = "unknown"
OUTCOMES = frozenset({OUTCOME_OK, OUTCOME_NO_INPUT, OUTCOME_UNREADABLE,
                      OUTCOME_SKIPPED, OUTCOME_ERROR, OUTCOME_UNKNOWN})

TRIGGER_RUN_NOW = "run_now"
TRIGGER_SCHEDULED = "scheduled"
#: a tick the job ran BY ITSELF on an event or its own loop (a listener
#: firing, the fleet syncer's loop, the per-pod prewarmer's local task) --
#: recorded by the OWNING module, in the process the run happened in.
TRIGGER_EVENT = "event"

SCOPE_SCHEDULER = "scheduler"
SCOPE_PER_PROCESS = "per_process"

#: Durable rows kept per job (``background_job_ticks``), pruned on insert.
DURABLE_TICKS_PER_JOB = 50

#: How long the API pod waits for the scheduler worker to finish ONE tick
#: on run-now.  A prefetch tick can take minutes; the proxy's 10 s default
#: would report a running tick as a failure.
RUN_NOW_PROXY_TIMEOUT_S = 600.0

#: Ticks kept per job in the owning process.
LEDGER_DEPTH = 20

Verdict = Tuple[str, Optional[str]]


@dataclass(frozen=True)
class JobContract:
    """One background job's declaration.  Exactly one of ``tick`` /
    ``job_id`` / ``no_run_now`` makes it runnable-or-explained; a contract
    with none is refused by the guard."""
    name: str
    status: Callable[[Any], Dict[str, Any]]
    note: str
    tick: Optional[Callable[[Any], Any]] = None
    job_id: Optional[str] = None
    no_run_now: Optional[str] = None
    scope: str = SCOPE_SCHEDULER
    verdict: Optional[Callable[[Any], Verdict]] = None

    @property
    def runnable(self) -> bool:
        return self.tick is not None or self.job_id is not None


# ── the ledger: a per-process ring AND one durable table ───────────────
#
# 2026-10-08 (found live).  The ring alone could not answer for a
# ``per_process`` job: ``GET /api/admin/background-jobs/iceberg_warm_on_
# commit/status`` on the api pod said ``answered_by: this_process,
# last_tick: null`` while the warm had just run on the SCHEDULER pod (its
# metadata sync fired the listener in THAT process).  "Report every
# process" is not reachable in general -- api replicas and worker pods have
# no control API -- so the ledger is DURABLE instead: every tick, from
# every process, is a ``background_job_ticks`` row stamped with its
# ``pod_id``; ``last_tick`` / ``recent_ticks`` read the rows first (the same
# answer from any pod, surviving a restart) and fall back to this process's
# ring only when no DB is reachable.  The owning modules record their
# self-driven runs with ``TRIGGER_EVENT`` (the guard in
# tests/test_per_process_job_status_is_durable_2026_10_08.py requires a
# recorder per per_process job).

_LEDGER: Dict[str, deque] = {}
_LEDGER_LOCK = threading.Lock()
_INFLIGHT: Dict[str, float] = {}

LEDGER_DURABLE = "durable"
LEDGER_MEMORY = "this_process_memory"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ledger_db() -> Any:
    """The process-wide manager through THE accessor; None when there is
    none (a script, a misconfigured pod) -- never raises."""
    try:
        from core.database import resolve_db_manager
        return resolve_db_manager(None)
    except Exception:                                 # noqa: BLE001
        return None


def _persist_tick(name: str, rec: Dict[str, Any]) -> bool:
    """One ``background_job_ticks`` row for ``rec``; prune the job to
    :data:`DURABLE_TICKS_PER_JOB`.  Best-effort: a ledger write must never
    cost the tick that produced it."""
    dbm = _ledger_db()
    if dbm is None or not hasattr(dbm, "get_session"):
        return False
    try:
        from core.db.models import BackgroundJobTick
        at = datetime.fromisoformat(rec["at"])
        with dbm.get_session() as session:
            session.add(BackgroundJobTick(
                name=name, pod_id=rec.get("pod_id"), at=at,
                trigger=rec.get("trigger"), outcome=rec["outcome"],
                record=rec))
            session.flush()
            stale = [r.id for r in session.query(BackgroundJobTick.id)
                     .filter(BackgroundJobTick.name == name)
                     .order_by(BackgroundJobTick.at.desc(),
                               BackgroundJobTick.id.desc())
                     .offset(DURABLE_TICKS_PER_JOB).all()]
            if stale:
                session.query(BackgroundJobTick).filter(
                    BackgroundJobTick.id.in_(stale)).delete(
                        synchronize_session=False)
        return True
    except Exception as exc:                          # noqa: BLE001
        logger.debug("[job-contract] durable ledger write for %s failed: %s",
                     name, exc)
        return False


def durable_ticks(name: str, limit: int = 10) -> Optional[List[Dict[str, Any]]]:
    """The job's newest rows from ``background_job_ticks`` (every process),
    newest first; ``None`` when no DB is reachable (unknown != empty)."""
    dbm = _ledger_db()
    if dbm is None or not hasattr(dbm, "get_session"):
        return None
    try:
        from core.db.models import BackgroundJobTick
        with dbm.get_session(read_only=True) as session:
            rows = (session.query(BackgroundJobTick)
                    .filter(BackgroundJobTick.name == name)
                    .order_by(BackgroundJobTick.at.desc(),
                              BackgroundJobTick.id.desc())
                    .limit(max(1, int(limit))).all())
            return [r.to_dict() for r in rows]
    except Exception as exc:                          # noqa: BLE001
        logger.debug("[job-contract] durable ledger read for %s failed: %s",
                     name, exc)
        return None


def record_tick(name: str, *, trigger: str, outcome: str,
                reason: Optional[str] = None,
                counts: Optional[Dict[str, Any]] = None,
                duration_s: Optional[float] = None,
                error: Optional[str] = None,
                result: Any = None) -> Dict[str, Any]:
    """Append one tick to the job's ring (newest first), write its durable
    row, and return it."""
    assert outcome in OUTCOMES, outcome
    rec = {
        "at": _now_iso(),
        "trigger": trigger,
        "outcome": outcome,
        "reason": reason,
        "counts": dict(counts or {}),
        "duration_s": (round(duration_s, 3) if duration_s is not None
                       else None),
        "error": error,
        "pod_id": _pod_id(),
    }
    if result is not None:
        rec["result"] = _jsonable(result)
    with _LEDGER_LOCK:
        _LEDGER.setdefault(name, deque(maxlen=LEDGER_DEPTH)).appendleft(rec)
    _persist_tick(name, rec)
    return rec


def _ring(name: str, limit: int) -> List[Dict[str, Any]]:
    with _LEDGER_LOCK:
        ring = _LEDGER.get(name) or ()
        return [dict(r) for r in list(ring)[:max(1, int(limit))]]


def ticks_with_source(name: str, limit: int = 10
                      ) -> Tuple[List[Dict[str, Any]], str]:
    """``(ticks newest first, LEDGER_DURABLE | LEDGER_MEMORY)``.  The rows
    win whenever a DB answered; this process's ring is the fallback when
    there is no DB, or when a write failed and only memory holds the tick."""
    rows = durable_ticks(name, limit)
    ring = _ring(name, limit)
    if rows is None or (not rows and ring):
        return ring, LEDGER_MEMORY
    return rows, LEDGER_DURABLE


def last_tick(name: str) -> Optional[Dict[str, Any]]:
    ticks, _src = ticks_with_source(name, 1)
    return ticks[0] if ticks else None


def last_tick_for_job_id(job_id: str) -> Optional[Dict[str, Any]]:
    """TEST SEAM (declared 2026-10-07): the last tick of the contract that
    owns an APScheduler job id."""
    c = _by_job_id().get(job_id)
    return last_tick(c.name) if c is not None else None


def recent_ticks(name: str, limit: int = 10) -> List[Dict[str, Any]]:
    return ticks_with_source(name, limit)[0]


def reset_ledger_for_tests() -> None:
    """TEST SEAM (declared 2026-10-07) -- production must NOT call this.
    Clears this process's ring AND the durable rows (best-effort)."""
    with _LEDGER_LOCK:
        _LEDGER.clear()
        _INFLIGHT.clear()
    dbm = _ledger_db()
    if dbm is None or not hasattr(dbm, "get_session"):
        return
    try:
        from core.db.models import BackgroundJobTick
        with dbm.get_session() as session:
            session.query(BackgroundJobTick).delete(synchronize_session=False)
    except Exception:                                 # noqa: BLE001
        pass


def reset_ring_for_tests() -> None:
    """TEST SEAM (declared 2026-10-08) -- production must NOT call this.
    Clears ONLY this process's memory: "another process" / "after a
    restart", with the durable rows kept."""
    with _LEDGER_LOCK:
        _LEDGER.clear()
        _INFLIGHT.clear()


def _pod_id() -> str:
    try:
        from core.background_jobs import _this_pod_id
        return _this_pod_id()
    except Exception:
        return "unknown"


def _jsonable(value: Any, depth: int = 0) -> Any:
    if depth > 4:
        return str(value)[:200]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _jsonable(v, depth + 1) for k, v in list(value.items())[:60]}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v, depth + 1) for v in list(value)[:60]]
    if hasattr(value, "to_dict"):
        try:
            return _jsonable(value.to_dict(), depth + 1)
        except Exception:
            pass
    return str(value)[:200]


# ── classifying a tick's raw result ─────────────────────────────────────

#: Numeric fields that do not mean "work was done".
_NOT_WORK_KEYS = frozenset({
    "errors", "error_count", "failed", "failures", "elapsed_s", "duration_s",
    "elapsed", "duration", "seconds", "interval", "interval_seconds",
    "interval_hours", "limit", "max", "budget", "cap", "ttl",
    "input_rows", "rows_examined", "deferred_waits",
})


def _did_work(counts: Dict[str, Any]) -> bool:
    for k, v in counts.items():
        if k in _NOT_WORK_KEYS or k.startswith(("max_", "limit", "interval",
                                                  "budget", "elapsed",
                                                  "duration", "skipped")):
            continue
        if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
            return True
    return False


def _counts_of(raw: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in raw.items()
            if isinstance(v, (int, float)) and not isinstance(v, bool)}


_STATUS_WORDS = {
    OUTCOME_ERROR: {"error", "failed", "failure"},
    OUTCOME_UNREADABLE: {"unreadable"},
    OUTCOME_NO_INPUT: {"no_input", "nothing", "empty", "idle", "none"},
    OUTCOME_SKIPPED: {"disabled", "skipped", "paused", "deferred",
                      "not_leader", "not_due", "off", "not_armed"},
    OUTCOME_OK: {"ok", "ran", "completed", "done", "success", "synced"},
}


def classify(raw: Any) -> Tuple[str, Optional[str], Dict[str, Any]]:
    """``(outcome, reason, counts)`` for a tick's raw result.

    Dict results are read by their ``status`` / ``error`` / ``skipped`` /
    ``errors`` fields and their numeric counts; a tick whose counts are all
    zero ran with NOTHING TO DO and reads ``no_input``, never ``ok``.  A job
    whose result does not fit declares its own ``verdict``.
    """
    if raw is None:
        return OUTCOME_UNKNOWN, "the tick returned no result", {}
    if isinstance(raw, bool):
        return (OUTCOME_OK if raw else OUTCOME_NO_INPUT), None, {}
    if isinstance(raw, (int, float)):
        return ((OUTCOME_OK if raw > 0 else OUTCOME_NO_INPUT), None,
                {"n": raw})
    if isinstance(raw, dict):
        counts = _counts_of(raw)
        err = raw.get("error")
        if err:
            return OUTCOME_ERROR, str(err)[:300], counts
        errs = raw.get("errors")
        if isinstance(errs, (list, tuple)) and errs:
            return OUTCOME_ERROR, "; ".join(str(e) for e in errs)[:300], counts
        st = raw.get("status")
        if isinstance(st, str):
            s = st.strip().lower()
            for outcome, words in _STATUS_WORDS.items():
                if s in words:
                    reason = raw.get("reason") or raw.get("input_error")
                    if outcome == OUTCOME_OK:
                        return ((OUTCOME_OK if _did_work(counts)
                                 else OUTCOME_NO_INPUT), None, counts)
                    return outcome, (str(reason)[:300] if reason else st), counts
        # 2026-10-08 -- a tick that reports its failures under PER-TARGET
        # keys (brain_cleanup_daemon: ``memo_error`` / ``route_history_
        # error`` / ``br_grants_error``) used to read ``no_input``: the
        # keys are not numeric and not called ``error``.  A named failure
        # is an error whatever the key is called.  (``input_error`` is the
        # reason field of a ``status: unreadable`` tick, handled above.)
        named = [f"{k}: {str(v)[:120]}" for k, v in raw.items()
                 if k.endswith("_error") and k != "input_error" and v]
        if named:
            return OUTCOME_ERROR, "; ".join(named)[:300], counts
        # ...and a tick that says WHY it did nothing as a STRING under
        # ``skipped`` (pruning_alerts_daemon) or ``skipped_reason``
        # (output_gateway_cleanup, both mirror daemons, lake_formation_sync,
        # brain_coordinator_daemon) was recorded ``no_input`` -- "ran, found
        # nothing" -- over a tick that never looked.  The reason is the
        # record.
        for key in ("skipped", "skipped_reason"):
            why = raw.get(key)
            if isinstance(why, str) and why.strip() and not _did_work(counts):
                return OUTCOME_SKIPPED, why.strip()[:300], counts
        if raw.get("skipped") is True or raw.get("disabled") is True:
            return (OUTCOME_SKIPPED,
                    str(raw.get("reason") or "skipped")[:300], counts)
        if raw.get("ok") is False:
            return (OUTCOME_ERROR,
                    str(raw.get("reason") or raw.get("message")
                        or "ok=false")[:300], counts)
        if isinstance(errs, (int, float)) and errs > 0 and not _did_work(counts):
            return OUTCOME_ERROR, f"{errs} error(s), no work done", counts
        return ((OUTCOME_OK if _did_work(counts) else OUTCOME_NO_INPUT),
                None, counts)
    return OUTCOME_UNKNOWN, f"unrecognised result type {type(raw).__name__}", {}


def _verdict_for(c: JobContract, raw: Any) -> Tuple[str, Optional[str], Dict[str, Any]]:
    if c.verdict is not None:
        try:
            outcome, reason = c.verdict(raw)
            counts = _counts_of(raw) if isinstance(raw, dict) else {}
            return outcome, reason, counts
        except Exception as exc:                      # noqa: BLE001
            logger.debug("[job-contract] verdict for %s raised: %s", c.name, exc)
    return classify(raw)


# ── running one tick in THIS process ───────────────────────────────────

class TickRefused(RuntimeError):
    """Run-now could not run here; ``reason`` says why (the route maps it
    to 409 / 503)."""

    def __init__(self, reason: str, *, status_code: int = 409):
        super().__init__(reason)
        self.reason = reason
        self.status_code = status_code


def _run_apscheduler_job(job_id: str) -> Any:
    """Run the registered APScheduler job's function once, synchronously,
    in this process -- the generic run-now for closure-shaped jobs."""
    from core.scheduler import get_daemon_scheduler
    sched = get_daemon_scheduler()
    job = sched.get_job(job_id) if sched is not None else None
    if job is None:
        return {"status": "skipped",
                "reason": (f"APScheduler job {job_id!r} is not registered in "
                           f"this process (feature off, or this process does "
                           f"not hold the scheduler lock)")}
    return job.func(*(job.args or ()), **(job.kwargs or {}))


def local_run_now(name: str, db: Any) -> Dict[str, Any]:
    """ONE tick of ``name`` in THIS process, recorded in the ledger.
    Raises :class:`TickRefused` when the contract declares it cannot run
    on demand or a tick is already in flight; a tick that raises is
    RECORDED as ``error`` and returned, never re-raised."""
    c = CONTRACTS[name]
    if not c.runnable:
        raise TickRefused(c.no_run_now or "declared not runnable on demand")
    with _LEDGER_LOCK:
        started = _INFLIGHT.get(name)
        if started is not None:
            raise TickRefused(
                f"a tick of {name} is already running in this process "
                f"(started {time.monotonic() - started:.0f}s ago)")
        _INFLIGHT[name] = time.monotonic()
    t0 = time.monotonic()
    try:
        try:
            raw = c.tick(db) if c.tick is not None else _run_apscheduler_job(c.job_id)  # type: ignore[arg-type]
        except Exception as exc:                      # noqa: BLE001
            tb = traceback.format_exc().strip().splitlines()[-3:]
            rec = record_tick(name, trigger=TRIGGER_RUN_NOW,
                              outcome=OUTCOME_ERROR,
                              reason=f"{type(exc).__name__}: {exc}"[:300],
                              duration_s=time.monotonic() - t0,
                              error="\n".join(tb)[:1000])
            logger.warning("[job-contract] run-now %s raised: %s", name, exc)
            return rec
        outcome, reason, counts = _verdict_for(c, raw)
        return record_tick(name, trigger=TRIGGER_RUN_NOW, outcome=outcome,
                           reason=reason, counts=counts,
                           duration_s=time.monotonic() - t0, result=raw)
    finally:
        with _LEDGER_LOCK:
            _INFLIGHT.pop(name, None)


# ── the APScheduler listener: scheduled fires land in the SAME ledger ──

_LISTENER_FLAG = "_qs_job_contract_listener"


def _by_job_id() -> Dict[str, JobContract]:
    return {c.job_id: c for c in CONTRACTS.values() if c.job_id}


def _on_job_event(event: Any) -> None:
    try:
        c = _by_job_id().get(getattr(event, "job_id", None))
        if c is None:
            return
        exc = getattr(event, "exception", None)
        if exc is not None:
            record_tick(c.name, trigger=TRIGGER_SCHEDULED, outcome=OUTCOME_ERROR,
                        reason=f"{type(exc).__name__}: {exc}"[:300],
                        error=str(getattr(event, "traceback", "") or "")[-1000:])
            return
        if getattr(event, "code", None) is not None:
            try:
                from apscheduler.events import EVENT_JOB_MISSED
                if event.code == EVENT_JOB_MISSED:
                    record_tick(c.name, trigger=TRIGGER_SCHEDULED,
                                outcome=OUTCOME_SKIPPED,
                                reason="missed: the scheduled run time passed "
                                       "the misfire grace while the scheduler "
                                       "was paused or busy")
                    return
            except Exception:                         # noqa: BLE001
                pass
        raw = getattr(event, "retval", None)
        outcome, reason, counts = _verdict_for(c, raw)
        if raw is None:
            reason = ("fired; its scheduled wrapper returns no result -- "
                      "run-now reports the outcome")
        record_tick(c.name, trigger=TRIGGER_SCHEDULED, outcome=outcome,
                    reason=reason, counts=counts, result=raw)
    except Exception as exc:                          # noqa: BLE001 -- never cost the scheduler
        logger.debug("[job-contract] listener failed: %s", exc)


def attach_scheduler_listener(scheduler: Any) -> bool:
    """Attach the ledger listener ONCE per APScheduler instance.  Called by
    ``core.scheduler.init_scheduler`` right after ``start()`` -- the one
    seam both entry points (main.py and scheduler_worker.py) pass through.
    Returns True when attached now, False when already attached or when
    the object cannot take listeners (a test stub)."""
    if scheduler is None or getattr(scheduler, _LISTENER_FLAG, False):
        return False
    try:
        from apscheduler.events import (EVENT_JOB_ERROR, EVENT_JOB_EXECUTED,
                                        EVENT_JOB_MISSED)
        scheduler.add_listener(
            _on_job_event, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR | EVENT_JOB_MISSED)
        setattr(scheduler, _LISTENER_FLAG, True)
        return True
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[job-contract] could not attach the scheduler "
                       "listener (scheduled fires will not be ledgered): %s",
                       exc)
        return False


# ── status, in THIS process ────────────────────────────────────────────

def _scheduled_state(job_id: Optional[str]) -> Optional[Dict[str, Any]]:
    if not job_id:
        return None
    out: Dict[str, Any] = {"job_id": job_id, "registered": False,
                           "next_run_at": None, "paused": None}
    try:
        from core.scheduler import _scheduler as _sched
        job = _sched.get_job(job_id) if _sched is not None else None
        if job is not None:
            out["registered"] = True
            nr = getattr(job, "next_run_time", None)
            out["next_run_at"] = nr.isoformat() if nr else None
            out["paused"] = nr is None
    except Exception as exc:                          # noqa: BLE001
        out["error"] = str(exc)[:200]
    return out


def _owner_category(name: str) -> str:
    from core import daemon_registry as dr
    if name in dr.PER_POD_DAEMONS:
        return "per_pod_daemon"
    if name in dr.SCHEDULER_OWNED:
        return "scheduler_owned"
    return EXTRA_JOBS.get(name, ("undeclared", ""))[0]


def runs_here(c: JobContract) -> bool:
    """Does THIS process own the job?  Per-process jobs: always.
    Scheduler-scope jobs: the same answer ``daemon_snapshots`` gives."""
    if c.scope == SCOPE_PER_PROCESS:
        return True
    # 2026-10-10: the gate that STARTED the daemon answers (its recorded
    # decision for this name here, else the scheduler lock), never the
    # pod-role / scheduler.mode configuration -- see daemon_snapshots.
    from core.daemon_snapshots import daemon_runs_here
    return daemon_runs_here(c.name)


def _owner_reachable(proxy: Optional[Callable[..., Any]]) -> bool:
    """A scheduler worker's control API exists to ask (external mode, or an
    embedded pod pointed at one by scheduler.worker_host)."""
    from core.daemon_snapshots import scheduler_worker_configured
    return proxy is not None and scheduler_worker_configured()


def _no_owner_api_reason() -> str:
    from core.daemon_snapshots import no_owner_api_reason
    return no_owner_api_reason()


def local_status(name: str, db: Any, *, limit: int = 10) -> Dict[str, Any]:
    """This process's full view of one job."""
    c = CONTRACTS[name]
    ticks, ledger = ticks_with_source(name, limit)
    out: Dict[str, Any] = {
        "name": name,
        "note": c.note,
        "scope": c.scope,
        "owner": _owner_category(name),
        "runs_here": runs_here(c),
        "last_tick": ticks[0] if ticks else None,
        "recent_ticks": ticks,
        # 2026-10-08: ``durable`` = background_job_ticks rows written by
        # EVERY process that ran the job (pod_id on each tick), the same
        # answer from any pod; ``this_process_memory`` = no DB reachable.
        "ledger": ledger,
        "pods_seen": sorted({str(t.get("pod_id")) for t in ticks
                             if t.get("pod_id")}),
        "scheduled": _scheduled_state(c.job_id),
        "run_now": {"available": c.runnable, "reason": c.no_run_now},
    }
    try:
        from core.background_jobs import is_paused
        out["paused"] = bool(is_paused(name))
    except Exception:                                 # noqa: BLE001
        out["paused"] = None
    try:
        from core.daemon_registry import admin_disabled
        out["admin_disabled"] = bool(admin_disabled(name))
    except Exception:                                 # noqa: BLE001
        out["admin_disabled"] = None
    try:
        out["status"] = _jsonable(c.status(db))
    except Exception as exc:                          # noqa: BLE001
        out["status"] = {"status_error": f"{type(exc).__name__}: {exc}"[:300]}
    return out


def local_ticks(db: Any = None) -> Dict[str, Dict[str, Any]]:
    """The ledger summary for EVERY declared job, from this process: what
    the Background Jobs screen shows per row.  No module status is read
    here (cheap enough to poll)."""
    out: Dict[str, Dict[str, Any]] = {}
    for name, c in CONTRACTS.items():
        ticks, ledger = ticks_with_source(name, 1)
        out[name] = {
            "scope": c.scope,
            "runs_here": runs_here(c),
            "last_tick": ticks[0] if ticks else None,
            "ledger": ledger,
            "run_now": {"available": c.runnable, "reason": c.no_run_now},
            "scheduled": _scheduled_state(c.job_id),
        }
    return out


# ── owner resolution: this process, or the scheduler worker ───────────

def _scheduler_mode() -> Optional[str]:
    from core.daemon_snapshots import _scheduler_mode as _m
    return _m()


def _not_here_reason(c: JobContract) -> str:
    return (f"this pod does not run {c.name} (scope={c.scope}; scheduler-"
            f"owned daemons run on the scheduler pod)")


async def status(name: str, db: Any, *, limit: int = 10,
                 proxy: Optional[Callable[..., Any]] = None) -> Dict[str, Any]:
    """``local_status`` from the OWNING process, with ``answered_by``."""
    import asyncio
    c = CONTRACTS[name]
    if runs_here(c):
        out = await asyncio.to_thread(local_status, name, db, limit=limit)
        out["answered_by"] = "this_process"
        return out
    why = _not_here_reason(c) + "; "
    if _owner_reachable(proxy):
        try:
            remote = await proxy("GET", f"/control/background-job/{name}/status?limit={int(limit)}")
            if isinstance(remote, dict) and remote.get("name") == name:
                remote["answered_by"] = "scheduler_worker"
                return remote
            why += "the scheduler worker answered without a status; "
        except Exception as exc:                      # noqa: BLE001
            detail = getattr(exc, "detail", None) or str(exc)
            why += f"the scheduler worker could not be reached ({detail}); "
    else:
        why += _no_owner_api_reason() + "; "
    out = await asyncio.to_thread(local_status, name, db, limit=limit)
    out["answered_by"] = "this_process"
    if out.get("ledger") == LEDGER_DURABLE:
        out["warning"] = (why + "the ticks below are the DURABLE ledger "
                          "(written by every process, pod_id on each), but "
                          "``status`` is THIS process's copy of the module "
                          "state, which is empty when the job runs "
                          "elsewhere -- it is not evidence the job is idle.")
    else:
        out["warning"] = (why + "the data below is THIS process's copy, "
                          "which is empty when the job runs elsewhere -- it "
                          "is not evidence the job is idle.")
    return out


async def run_now(name: str, db: Any, *,
                  proxy: Optional[Callable[..., Any]] = None) -> Dict[str, Any]:
    """ONE tick in the OWNING process; the tick's record, with
    ``answered_by``.  Raises :class:`TickRefused` (409) when the job
    declares it cannot run on demand or is already running, and
    :class:`TickRefused` (503) when the owner cannot be reached -- a tick
    is NEVER run on a pod that does not own the job."""
    import asyncio
    c = CONTRACTS[name]
    if runs_here(c):
        rec = await asyncio.to_thread(local_run_now, name, db)
        rec["name"] = name
        rec["answered_by"] = "this_process"
        return rec
    if not c.runnable:
        raise TickRefused(c.no_run_now or "declared not runnable on demand")
    if not _owner_reachable(proxy):
        raise TickRefused(
            _not_here_reason(c) + " and " + _no_owner_api_reason(),
            status_code=503)
    try:
        remote = await proxy("POST", f"/control/background-job/{name}/run-now",
                             None, RUN_NOW_PROXY_TIMEOUT_S)
    except Exception as exc:                          # noqa: BLE001
        detail = getattr(exc, "detail", None) or str(exc)
        code = getattr(exc, "status_code", None)
        if code == 409:
            raise TickRefused(str(detail), status_code=409) from None
        raise TickRefused(
            _not_here_reason(c) + f"; the scheduler worker could not run it "
            f"({detail}) -- not run here", status_code=503) from None
    if not isinstance(remote, dict) or "outcome" not in remote:
        raise TickRefused("the scheduler worker answered without a tick record",
                          status_code=503)
    remote["name"] = name
    remote["answered_by"] = "scheduler_worker"
    return remote


async def all_ticks(db: Any, *, proxy: Optional[Callable[..., Any]] = None
                    ) -> Dict[str, Any]:
    """Every job's last tick: per-process jobs from here, scheduler-scope
    jobs from the owner (one proxy call)."""
    import asyncio
    local = await asyncio.to_thread(local_ticks, db)
    answered: Dict[str, str] = {n: "this_process" for n in local}
    warning = None
    need_remote = [n for n, c in CONTRACTS.items() if not runs_here(c)]
    if need_remote:
        why = ("this pod does not run the scheduler-owned jobs; ")
        if _owner_reachable(proxy):
            try:
                remote = await proxy("GET", "/control/background-job-ticks")
                jobs = (remote or {}).get("jobs") if isinstance(remote, dict) else None
                if isinstance(jobs, dict):
                    for n in need_remote:
                        if n in jobs:
                            local[n] = jobs[n]
                            answered[n] = "scheduler_worker"
                else:
                    warning = why + "the scheduler worker answered without ticks"
            except Exception as exc:                  # noqa: BLE001
                detail = getattr(exc, "detail", None) or str(exc)
                warning = why + f"the scheduler worker could not be reached ({detail})"
        else:
            warning = why + _no_owner_api_reason()
    for n in local:
        local[n]["answered_by"] = answered[n]
    out: Dict[str, Any] = {"jobs": local}
    if warning:
        out["warning"] = (warning + " -- the scheduler-owned rows are THIS "
                          "process's empty copy, not evidence the jobs are idle.")
    return out


# ── the declarations ───────────────────────────────────────────────────
#
# Every callable imports lazily: this module is imported by the admin
# routes and by core.scheduler, and must stay cheap.

def _no_module_state(_db: Any) -> Dict[str, Any]:
    return {"module_state": "none -- the ledger and the scheduled entry are "
                            "the record"}


def _retention(name: str, note: str) -> JobContract:
    def _tick(db: Any) -> Any:
        from core import retention_daemons as rd
        return getattr(rd, f"run_{name}")(db)
    _tick.__name__ = f"tick_{name}"
    return JobContract(name=name, status=_no_module_state, note=note,
                       tick=_tick, job_id=name)


def _published_api_rollup_status(db: Any) -> Dict[str, Any]:
    """The watermark per grain -- what the dashboard says about its own
    currency (core/published_api/rollup.py::watermark)."""
    from core.published_api.rollup import watermark
    try:
        return watermark(db)
    except Exception as exc:                            # noqa: BLE001
        return {"state": "unknown", "status_error": f"{type(exc).__name__}: {exc}"}


def _value_list_sync_status(db: Any) -> Dict[str, Any]:
    """Each daily list: its last sync, its status, whether it is due now."""
    from core import value_lists as vlm
    try:
        lists = db.list_value_lists()
        due = {v["id"] for v in vlm.due(lists)}
        return {"lists": [{"name": v["name"], "sync_mode": v["sync_mode"],
                           "last_synced_at": v["last_synced_at"], "last_status": v["last_status"],
                           "values": v["value_count"], "due": v["id"] in due} for v in lists]}
    except Exception as exc:                            # noqa: BLE001
        return {"state": "unknown", "status_error": f"{type(exc).__name__}: {exc}"}


def _value_list_sync_tick(db: Any) -> Any:
    from core.value_lists import tick
    return tick(db)


def _published_api_rollup_tick(db: Any) -> Any:
    from core.published_api.rollup import tick
    return tick(db)


def _file_watch_status(_db: Any) -> Dict[str, Any]:
    from core.feed.file_arrival_source import load_config
    cfg = load_config()
    return {"enabled": bool(cfg.get("enabled", True)),
            "interval_seconds": cfg.get("interval_seconds"),
            "lookback_days": cfg.get("lookback_days")}


def _file_watch_tick(db: Any) -> Any:
    from core.feed.file_arrival_source import watch_tick
    return watch_tick(db)


def _oracle_table_watch_status(db: Any) -> Dict[str, Any]:
    from core.feed.oracle_table_source import (
        load_config, producer_refusal, read_watermark, resolve_watched_tables,
    )
    cfg = load_config()
    out: Dict[str, Any] = {"enabled": bool(cfg.get("enabled", True)),
                           "interval_seconds": cfg.get("interval_seconds"),
                           "refusal": producer_refusal(cfg), "tables": []}
    try:
        res = resolve_watched_tables(db, cfg)
        out["problems"] = list(res.problems)
        for wt in res.tables:
            try:
                wm = read_watermark(db, wt)
            except Exception as exc:  # noqa: BLE001 -- status is a report, never a crash
                wm = f"unreadable: {exc}"
            out["tables"].append({"table": wt.table, "connection": wt.connection_name,
                                  "connection_id": wt.connection_id,
                                  "rules": len(wt.rules), "watermark": wm})
    except Exception as exc:  # noqa: BLE001
        out["problems"] = [f"could not resolve the watched tables: {exc}"]
    return out


def _oracle_table_watch_tick(db: Any) -> Any:
    from core.feed.oracle_table_source import watch_tick
    return watch_tick(db)


def _template_requests_status(db: Any) -> Dict[str, Any]:
    from core.feed.template_requests import FUNCTION_NAME, STATUS_VIEW, pending_count
    return {"function": f"{FUNCTION_NAME}()", "status_view": STATUS_VIEW,
            "waiting": pending_count(db)}


def _template_requests_tick(db: Any) -> Any:
    from core.feed.template_requests import tick
    return tick(db)


def _lake_formation_status(db: Any) -> Dict[str, Any]:
    from core.config import row_security as _rs
    from core.row_security.lake_formation_daemon import (
        connections_with_lake_formation_policies)
    return {"enabled": bool(getattr(_rs, "lake_formation_sync_enabled", False)),
            "interval_hours": getattr(_rs, "lake_formation_sync_interval_hours", None),
            "connections_with_policies": connections_with_lake_formation_policies(db)}


def _lake_formation_tick(db: Any) -> Any:
    from core.row_security.lake_formation_daemon import run_lake_formation_sync
    return run_lake_formation_sync(db)


def _iceberg_sync_status(_db: Any) -> Dict[str, Any]:
    from core.iceberg_metadata_sync import (get_last_summary, get_recent_runs,
                                            get_sync_progress)
    return {"summary": get_last_summary(), "progress": get_sync_progress(),
            "recent_runs": get_recent_runs()}


def _iceberg_sync_tick(db: Any) -> Any:
    import asyncio
    from core.iceberg_metadata_sync import sync_all_once
    return asyncio.run(sync_all_once(db))


def _watcher_status(db: Any) -> Dict[str, Any]:
    from core.iceberg_manifest_watcher import get_watcher_status
    return get_watcher_status(db)


def _watcher_tick(db: Any) -> Any:
    from core.iceberg_manifest_watcher import run_tick
    return run_tick(db)


def _duckdb_mirror_status(_db: Any) -> Dict[str, Any]:
    from core.brain_duckdb_mirror import (_config_enabled, _runtime_enabled_override,
                                          is_running)
    return {"enabled": bool(_config_enabled()),
            "runtime_override": _runtime_enabled_override(),
            "writer_running_here": bool(is_running())}


def _duckdb_mirror_tick(db: Any) -> Any:
    from core.brain_duckdb_mirror import get_mirror
    return get_mirror(db).tick_once()


def _kafka_cache_status(_db: Any) -> Dict[str, Any]:
    from core.kafka_cache_consumer import get_status
    return get_status()


def _custom_jobs_status(_db: Any) -> Dict[str, Any]:
    from core.custom_jobs import get_last_summary
    return {"last_summary": get_last_summary()}


def _custom_jobs_tick(_db: Any) -> Any:
    import asyncio
    from core.custom_jobs import _process_due_jobs
    return asyncio.run(_process_due_jobs())


def _prewarm_status(_db: Any) -> Dict[str, Any]:
    from core.prewarm_background_service import NOT_WIRED_REASON, is_wired
    return {"wired": bool(is_wired()), "reason": NOT_WIRED_REASON}


def _etl_status(_db: Any) -> Dict[str, Any]:
    from core.config import etl_pipelines as _cfg
    return {"enabled": bool(_cfg.enabled)}


def _etl_tick(_db: Any) -> Any:
    import asyncio
    from core.config import etl_pipelines as _cfg
    if not _cfg.enabled:
        return {"status": "skipped", "reason": "etl_pipelines.enabled is false"}
    from core.etl_engine import _scheduler_tick
    return {"triggered": int(asyncio.run(_scheduler_tick()) or 0)}


def _dq_status(_db: Any) -> Dict[str, Any]:
    from core.config import data_quality as _cfg
    return {"enabled": bool(_cfg.enabled),
            "schedule_interval_minutes": getattr(_cfg, "schedule_interval_minutes", None)}


def _sla_scanner_status(_db: Any) -> Dict[str, Any]:
    from core.dataflow.sla_scanner import get_sla_scanner
    return {"initialised_here": get_sla_scanner() is not None}


def _sla_scanner_tick(_db: Any) -> Any:
    from core.dataflow.sla_scanner import get_sla_scanner
    sc = get_sla_scanner()
    if sc is None:
        return {"status": "skipped",
                "reason": "the SLA scanner is not initialised in this process"}
    return {"flagged": int(sc._scan_once() or 0)}


def _dataflow_status(_db: Any) -> Dict[str, Any]:
    from core.config import get as _get
    return {"scheduler_autostart": bool(_get("dataflows", "scheduler_autostart", False)),
            "poll_seconds": _get("dataflows", "scheduler_poll_seconds", 30)}


def _feed_sla_status(_db: Any) -> Dict[str, Any]:
    from core.feed.sla_watcher import get_status
    return get_status()


def _feed_sla_tick(db: Any) -> Any:
    from core.daemon_registry import _deploy_env_name
    from core.feed.sla_watcher import evaluate_once
    return evaluate_once(db, env=_deploy_env_name(),
                         session_factory=getattr(db, "SessionLocal", None))


def _kafka_arrivals_status(_db: Any) -> Dict[str, Any]:
    from core.feed.kafka_arrivals import get_status
    return get_status()


def _netcool_status(db: Any) -> Dict[str, Any]:
    from core.feed.netcool_sender import get_status
    return get_status(getattr(db, "SessionLocal", None))


def _spark_reconciler_status(_db: Any) -> Dict[str, Any]:
    from core.config import spark_k8s as _sk
    from core.spark_k8s import reconciler as r
    t = getattr(r, "_thread", None)
    return {"enabled": bool(_sk.enabled),
            "loop_alive_here": bool(t is not None and t.is_alive())}


def _brain_daemon(name: str, mod: str, tick_fn: str, note: str,
                  status_fn: Optional[Callable[[Any], Dict[str, Any]]] = None,
                  job_id: Optional[str] = None,
                  scope: str = SCOPE_SCHEDULER,
                  verdict: Optional[Callable[[Any], Verdict]] = None) -> JobContract:
    def _tick(db: Any) -> Any:
        m = __import__(mod, fromlist=[tick_fn])
        return getattr(m, tick_fn)(db)
    _tick.__name__ = f"tick_{name}"
    return JobContract(name=name, status=status_fn or _no_module_state,
                       note=note, tick=_tick, job_id=job_id or name, scope=scope,
                       verdict=verdict)


def _prefetch_verdict(raw: Any) -> Verdict:
    """2026-10-08 -- the adaptive prefetch tick's own verdict.  Its
    ``status`` is already the input verdict (``ok`` ONLY when history rows
    were read; ``no_input``; ``unreadable``) and its ``reason`` says what
    became of the rows -- "built N", "covered: every ranked column covers
    every file", "idle: ...".  The generic classifier read the nested
    ``{plan, summary}`` as ``counts: {}`` and called every all-zero build
    ``no_input`` -- the 2026-09-26 "history is empty" verdict, for a tick
    that had read 40 rows and found every column covered."""
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    st = str(raw.get("status") or "").strip().lower()
    reason = raw.get("reason") or raw.get("input_error")
    reason_s = str(reason)[:300] if reason else None
    if st == OUTCOME_UNREADABLE:
        return OUTCOME_UNREADABLE, reason_s or "history unreadable"
    if st == OUTCOME_NO_INPUT:
        return OUTCOME_NO_INPUT, reason_s or "zero history rows read"
    # 2026-10-08 -- the tick's own ``error``: targets were attempted and NONE
    # was built because files failed (live: "built 7 ... over 10067 files"
    # over 0 scanned / 2,000 access_denied).  The tick decides it ONCE
    # (query_history_prefetcher._tick_status, read from the scanners'
    # summaries); this verdict carries it with its reason.
    if st == OUTCOME_ERROR:
        return OUTCOME_ERROR, reason_s or "targets failed; nothing built"
    if st == OUTCOME_OK:
        errs = raw.get("summary", {}).get("errors") if isinstance(raw.get("summary"), dict) else None
        if errs and not int(raw.get("built") or 0):
            return OUTCOME_ERROR, "; ".join(str(e) for e in errs)[:300]
        return OUTCOME_OK, reason_s
    return classify(raw)[:2]


def _nested(raw: Dict[str, Any], key: str) -> Dict[str, Any]:
    v = raw.get(key)
    return v if isinstance(v, dict) else {}


def _n(d: Dict[str, Any], key: str) -> int:
    try:
        return int(d.get(key) or 0)
    except (TypeError, ValueError):
        return 0


# 2026-10-08 -- verdicts for the ticks whose COUNTS live one level down.
# ``classify`` reads only top-level numbers, so output_gateway_cleanup
# (``summary.deleted``), both mirror daemons (``builds.built``) and the
# pruning alerts (``result.fired``) read ``no_input`` after deleting,
# building or sending; custom jobs read ``ok`` when every job ERRORED
# (``ran`` counts the failures); the writer advisor read ``ok`` for
# ``considered: 5, shadow_marked: 0``.  Found while designing the Docker
# proof that judges each job by its output (scripts/docker_proof/
# jobs_by_output_proof.py): the ledger and the output disagreed.

def _gateway_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error"):
        return OUTCOME_ERROR, str(raw["error"])[:300]
    if raw.get("skipped_reason"):
        return OUTCOME_SKIPPED, str(raw["skipped_reason"])[:300]
    s = _nested(raw, "summary")
    deleted, errors, scanned = _n(s, "deleted"), _n(s, "errors"), _n(s, "scanned")
    if deleted:
        return OUTCOME_OK, (f"{errors} entr(ies) failed" if errors else None)
    if errors:
        return OUTCOME_ERROR, f"{errors} of {scanned} entries failed, none deleted"
    return OUTCOME_NO_INPUT, f"scanned {scanned}, nothing expired"


def _mirror_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error"):
        return OUTCOME_ERROR, str(raw["error"])[:300]
    if raw.get("skipped_reason"):
        return OUTCOME_SKIPPED, str(raw["skipped_reason"])[:300]
    b = _nested(raw, "builds")
    cl = _nested(raw, "cleanup")
    built, errors, considered = _n(b, "built"), _n(b, "errors"), _n(b, "considered")
    swept = sum(_n(cl, k) for k in ("marked_stale", "swept_failed", "invalidated", "deleted"))
    if built or swept:
        return OUTCOME_OK, (f"{errors} build(s) failed" if errors else None)
    if errors:
        return OUTCOME_ERROR, f"{errors} of {considered} candidate build(s) failed, none built"
    return OUTCOME_NO_INPUT, f"considered {considered}, built 0"


def _alerts_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error"):
        return OUTCOME_ERROR, str(raw["error"])[:300]
    if isinstance(raw.get("skipped"), str) and raw["skipped"]:
        return OUTCOME_SKIPPED, raw["skipped"][:300]
    r = _nested(raw, "result")
    fired, errors = _n(r, "fired"), _n(r, "errors")
    if fired:
        return OUTCOME_OK, (f"{errors} delivery error(s)" if errors else None)
    if errors:
        return OUTCOME_ERROR, f"{errors} alert(s) could not be delivered, none fired"
    held = {k: _n(r, k) for k in ("suppressed", "skipped", "capped") if _n(r, k)}
    if held:
        return OUTCOME_NO_INPUT, "nothing fired: " + ", ".join(f"{v} {k}" for k, v in held.items())
    return OUTCOME_NO_INPUT, "no degradation to alert on"


def _custom_jobs_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error"):
        return OUTCOME_ERROR, str(raw["error"])[:300]
    if raw.get("skipped") is True:
        return OUTCOME_SKIPPED, str(raw.get("reason") or "skipped")[:300]
    ran, ok, errors = _n(raw, "ran"), _n(raw, "ok"), _n(raw, "errors")
    if ran == 0:
        return OUTCOME_NO_INPUT, "no custom job was due"
    if errors and not ok:
        return OUTCOME_ERROR, f"every due job failed ({errors} of {ran})"
    return OUTCOME_OK, (f"{errors} of {ran} job(s) failed" if errors else None)


def _advisor_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error"):
        return OUTCOME_ERROR, str(raw["error"])[:300]
    if raw.get("skipped_reason"):
        return OUTCOME_SKIPPED, str(raw["skipped_reason"])[:300]
    marked, considered = _n(raw, "shadow_marked"), _n(raw, "considered")
    if marked:
        return OUTCOME_OK, None
    return OUTCOME_NO_INPUT, (f"considered {considered}, none met the auto-apply bar"
                              if considered else "no recommendation to consider")


def _ring_status(mod: str, fn: str, key: str = "ticks"):
    def _status(_db: Any) -> Dict[str, Any]:
        m = __import__(mod, fromlist=[fn])
        return {key: getattr(m, fn)(limit=10)}
    return _status


def _prefetch_status(_db: Any) -> Dict[str, Any]:
    from core.query_history_prefetcher import get_prefetch_status
    return get_prefetch_status()


def _alerts_status(db: Any) -> Dict[str, Any]:
    from core.pruning_alerts import enabled, max_alerts_per_tick, recent_events
    return {"enabled": bool(enabled()), "max_alerts_per_tick": max_alerts_per_tick(),
            "recent_events": recent_events(db, limit=10)}


def _coordinator_status(_db: Any) -> Dict[str, Any]:
    from core.brain_coordinator import get_current_pressure_state, recent_reports
    return {"current": get_current_pressure_state(),
            "recent_reports": recent_reports(limit=10)}


def _prewarmer_status(_db: Any) -> Dict[str, Any]:
    from core.portal_cred_prewarmer import (cache_ttl_seconds, enabled,
                                            interval_minutes)
    from core.portal_cred_prewarmer import recent_ticks as _prewarmer_ticks
    return {"enabled": bool(enabled()), "interval_minutes": interval_minutes(),
            "cache_ttl_seconds": cache_ttl_seconds(),
            "recent_ticks": _prewarmer_ticks(limit=10)}


def _brain_cleanup_status(_db: Any) -> Dict[str, Any]:
    from core.brain_cleanup_daemon import cron_interval_hours
    return {"interval_hours": cron_interval_hours()}


def _writer_advisor_status(_db: Any) -> Dict[str, Any]:
    from core.writer_advisor import (_shadow_auto_apply_cron_minutes,
                                     auto_apply_enabled)
    return {"auto_apply_enabled": bool(auto_apply_enabled()),
            "cron_minutes": _shadow_auto_apply_cron_minutes()}


def _reactions_status(_db: Any) -> Dict[str, Any]:
    from core.iceberg_snapshot_reactions import stats
    return stats()


def _warm_status(_db: Any) -> Dict[str, Any]:
    from core.iceberg_warm_on_commit import _enabled, recent_warms
    return {"enabled": bool(_enabled()),
            # this PROCESS's ring; the ledger (last_tick / recent_ticks) is
            # durable and carries every process's warms with their records
            "recent_warms_this_process": recent_warms()[:10]}


def _warm_verdict(raw: Any) -> Verdict:
    """A warm record (``warm_for_snapshot``): ``status`` ok / skipped /
    error / partial, with the metadata step's file count as the work."""
    if not isinstance(raw, dict):
        return OUTCOME_UNKNOWN, "no warm record"
    st = str(raw.get("status") or "")
    if st == "skipped":
        return OUTCOME_SKIPPED, str(raw.get("reason") or "skipped")
    if st == "error":
        return OUTCOME_ERROR, str(raw.get("reason") or "error")
    steps = raw.get("steps") if isinstance(raw.get("steps"), dict) else {}
    if st == "partial":
        # 2026-10-08 -- the step's own error text travels with the verdict
        # ("bloom scan failed for 2,000 of 2,000 file(s): access_denied"),
        # not just the step's name.
        failed = [(k, v.get("error")) for k, v in steps.items()
                  if isinstance(v, dict) and v.get("error")]
        if not failed:
            return OUTCOME_ERROR, "partial: a step failed"
        return OUTCOME_ERROR, ("partial: " + "; ".join(
            f"{k} failed -- {str(e)[:200]}" for k, e in failed))[:300]
    meta = steps.get("metadata") if isinstance(steps.get("metadata"), dict) else {}
    if int(meta.get("files") or 0) > 0:
        return OUTCOME_OK, None
    return OUTCOME_NO_INPUT, "the snapshot has no data files"


def _indexer_status(_db: Any) -> Dict[str, Any]:
    from core.iceberg_snapshot_indexer import indexer_stats
    return indexer_stats()


def _pruning_history_writer_status(_db: Any) -> Dict[str, Any]:
    from core.query_diagnostic_store import pruning_history_writer_status
    return pruning_history_writer_status()


def _pruning_history_writer_tick(_db: Any) -> Dict[str, Any]:
    """Run-now = FLUSH: hand every queued row to the DB now (starting the
    writer thread if it is not alive) and report the ledger.  ``flushed``
    is the only count -- the totals ride under ``writer`` so a tick that
    had nothing queued reads ``no_input``, never ``ok``."""
    from core.query_diagnostic_store import (flush_pruning_history,
                                             pruning_history_writer_status)
    before = pruning_history_writer_status()
    queued = int(before["queue_depth"])
    drained = flush_pruning_history(timeout_s=30.0)
    after = pruning_history_writer_status()
    out: Dict[str, Any] = {
        "status": "ok" if drained else "error",
        "flushed": queued if drained else max(0, queued - int(after["queue_depth"])),
        "worker_alive": bool(after["worker_alive"]),
        "writer": after,
    }
    if not drained:
        out["reason"] = (f"queue not drained within 30s (depth "
                         f"{after['queue_depth']}, worker_alive="
                         f"{after['worker_alive']}, last_error="
                         f"{after['last_error']})")
    return out


def _indexer_tick(_db: Any) -> Any:
    from core.iceberg_snapshot_indexer import _drain_once, indexer_stats
    st = indexer_stats()
    if not st.get("armed"):
        return {"status": "skipped",
                "reason": ("the indexer is not armed in this process "
                           "(iceberg.snapshot_indexer_enabled=false, or arm() "
                           "was never called here)")}
    built = int(_drain_once() or 0)
    return {"builds_run": built, "queued_after": indexer_stats().get("queued", 0)}


def _fleet_syncer_status(_db: Any) -> Dict[str, Any]:
    from core.industrialization import fleet_syncer as fs
    t = (fs._started or {}).get("thread")
    return {"loop_alive_here": bool(t is not None and t.is_alive()),
            **fs.syncer_behind_stats()}


def _fleet_syncer_tick(db: Any) -> Any:
    from core.industrialization.fleet_syncer import FleetSyncer
    return FleetSyncer(db).run_tick()


def _fleet_syncer_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return OUTCOME_UNKNOWN, "no summary"
    if not raw.get("armed"):
        return OUTCOME_SKIPPED, "industrialization.fleet_syncer_enabled is not armed"
    if not raw.get("leader"):
        return OUTCOME_SKIPPED, "another process holds the fleet-syncer lock"
    if raw.get("errors"):
        return OUTCOME_ERROR, f"{raw['errors']} table(s) failed to sync"
    if raw.get("synced") or raw.get("skipped_complete"):
        return OUTCOME_OK, None
    return OUTCOME_NO_INPUT, "no watched tables"


def _apscheduler_status(_db: Any) -> Dict[str, Any]:
    from core.scheduler import get_scheduler_status
    st = get_scheduler_status()
    return {k: st.get(k) for k in ("running", "initialized", "paused", "job_count")}


def _sod_status(_db: Any) -> Dict[str, Any]:
    """The SOD generator's two BOOT-READ gates as this process reads them
    now, beside the scheduled entry ``local_status`` adds: an operator who
    set ``sod_enabled`` through the admin config route sees the overlay
    here and ``scheduled.registered`` says whether a restart has applied it
    (2026-10-11, the owner's "how will SOD be scheduled")."""
    from core.config import feed_generation as fg
    return {"sod_enabled": bool(fg.sod_enabled), "sod_cron": str(fg.sod_cron),
            "boot_read": True,
            "note": "both gates are read at init_scheduler; a change applies "
                    "at the scheduler-lock holder's next restart"}


def _sod_verdict(raw: Any) -> Verdict:
    """``SodResult.to_dict()`` by value: rows CREATED is work; a pass that
    created nothing is ``no_input`` NAMING why (already_existed /
    skipped_by_condition / skipped_window -- a month-end template on an
    ordinary day reads 'skipped_by_condition N', which is the right
    answer, not silence); a generator error is an error."""
    if not isinstance(raw, dict):
        return classify(raw)[:2]
    if raw.get("error") or raw.get("status") == "error":
        return OUTCOME_ERROR, str(raw.get("error") or raw.get("reason") or "error")[:300]
    if raw.get("status") in ("skipped", "disabled"):
        return OUTCOME_SKIPPED, str(raw.get("reason") or raw.get("status"))[:300]
    details = raw.get("error_details") or []
    if details or (isinstance(raw.get("errors"), int) and raw["errors"] > 0):
        return OUTCOME_ERROR, (f"{raw.get('errors')} feed(s) failed: "
                               + "; ".join(str(d) for d in details))[:300]
    created = int(raw.get("created") or 0)
    said = ", ".join(f"{k} {raw.get(k)}" for k in
                     ("already_existed", "skipped_by_condition", "skipped_window",
                      "skipped_inactive") if raw.get(k))
    bd = raw.get("business_date")
    if created > 0:
        return OUTCOME_OK, f"{bd}: created {created}" + (f" ({said})" if said else "")
    return OUTCOME_NO_INPUT, f"{bd}: created 0" + (f" ({said})" if said else " (no active feeds)")


_SNAPSHOT_LISTENER_REASON = (
    "event-driven: fires when THIS process detects an Iceberg snapshot roll "
    "(the metadata sync / manifest watcher on the scheduler pod, or an API "
    "pod serving POST /api/admin/iceberg-sync/refresh-table); there is no "
    "tick to run.  Provoke one with refresh-table on a watched table.")


#: Jobs that are NOT ``SCHEDULER_OWNED`` gate names but are still background
#: work the owner must see: name -> (category, why it is listed).
EXTRA_JOBS: Dict[str, Tuple[str, str]] = {
    "iceberg_snapshot_reactions": (
        "listener", "the commit-driven reactions (Iceberg-commit arrival source "
                    "+ warm-on-commit), armed per process"),
    "iceberg_warm_on_commit": (
        "listener", "warm-on-commit's own ring; one of the two reactions above"),
    "iceberg_snapshot_indexer": (
        "listener", "the snapshot-arrival indexer (partition-index backfill + "
                    "demand-ranked footer capture), armed per process"),
    "fleet_syncer": (
        "executor_loop", "industrialization fleet syncer: a leader-elected "
                         "thread loop in processes whose role is executor"),
    "iceberg_cache_lru": (
        "apscheduler_core", "core/scheduler.py init_scheduler job "
                            "__iceberg_cache_lru__"),
    "iceberg_meta_key_refresh": (
        "apscheduler_core", "core/scheduler.py init_scheduler job "
                            "__iceberg_meta_key_refresh__"),
    "partition_cache_refresh": (
        "apscheduler_core", "core/scheduler.py init_scheduler job "
                            "__partition_cache_refresh__"),
    "feed_etl_dep_poller": (
        "apscheduler_core", "core/scheduler.py init_scheduler job "
                            "__feed_etl_dep_poller__"),
    "feed_sod_generator": (
        "apscheduler_core", "core/scheduler.py init_scheduler job "
                            "__feed_sod_generator__ (feed_generation.sod_cron, "
                            "+ a boot fire 120 s after start; registered only "
                            "when feed_generation.sod_enabled was true at "
                            "init_scheduler) -- 2026-10-11"),
    "pruning_history_writer": (
        "writer_thread", "core/query_diagnostic_store.py: the daemon thread "
                         "that writes query_pruning_history (the brain's "
                         "input), started lazily in EVERY process that runs "
                         "a query; its ledger counts enqueued / written / "
                         "dropped / failed / skipped (2026-10-08)"),
    "component_health_reporter": (
        "per_pod_thread", "core/component_health/reporter.py: the thread that "
                          "writes THIS pod's component_health rows every "
                          "report_interval_seconds, in every server process "
                          "(2026-10-17)"),
}


def _component_health_reporter_status(db: Any) -> Dict[str, Any]:
    from core.component_health.reporter import status
    return status(db)


def _component_health_reporter_tick(db: Any) -> Any:
    from core.component_health.reporter import cycle_once
    return cycle_once(db)


def _component_health_reporter_verdict(raw: Any) -> Verdict:
    if not isinstance(raw, dict):
        return OUTCOME_ERROR, "the cycle returned nothing", {}
    if raw.get("status") == "skipped":
        return OUTCOME_SKIPPED, str(raw.get("reason")), {}
    if raw.get("status") == "unreadable":
        return OUTCOME_UNREADABLE, str(raw.get("input_error")), {"rows": raw.get("rows")}
    counts = {k: v for k, v in raw.items() if isinstance(v, (int, float)) and k != "ms"}
    if int(raw.get("rows") or 0) > 0:
        return OUTCOME_OK, None, counts
    return OUTCOME_NO_INPUT, "no check produced a row", counts


def _component_health_watcher_status(db: Any) -> Dict[str, Any]:
    from core.component_health.fleet_watcher import status
    return status(db)


def _component_health_watcher_verdict(raw: Any) -> Verdict:
    from core.component_health.fleet_watcher import watcher_verdict
    return watcher_verdict(raw)


_DECLARATIONS: List[JobContract] = [
    # ── scheduler core ──────────────────────────────────────────────────
    JobContract("apscheduler_embedded", _apscheduler_status,
                "APScheduler itself -- the process-wide job runner",
                no_run_now="APScheduler is the runner, not a job; the jobs it "
                           "hosts are the things to run"),
    # ── the retention group (core/retention_daemons.py) ─────────────────
    _retention("etl_cleanup", "reset stale ETL executions + delete old ones"),
    _retention("feed_cleanup", "reset stale feed executions + delete old ones"),
    _retention("dq_cleanup", "delete old data-quality results"),
    _retention("agent_log_cleanup", "delete old agent log rows"),
    _retention("pv_cleanup", "published-view access log + cache retention"),
    _retention("rls_audit_cleanup", "row-security audit retention"),
    _retention("delivery_history_cleanup", "delivery history retention"),
    _retention("query_log_cleanup", "query log retention"),
    _retention("feed_close_out_digest", "send the daily close-out digest when due"),
    _retention("feed_consumer_late_watch", "notice feed consumers whose delivery is late"),
    _retention("rate_limit_window_cleanup", "sweep finished rate-limit windows"),
    JobContract("feed_dependency_file_watch", _file_watch_status,
                "look for the files every waiting run's file dependency "
                "declares; record arrivals",
                tick=_file_watch_tick, job_id="feed_dependency_file_watch"),
    JobContract("feed_dependency_oracle_table_watch", _oracle_table_watch_status,
                "read each watched upstream Oracle table's new rows; resolve "
                "them through the resolver rules; record arrivals",
                tick=_oracle_table_watch_tick,
                job_id="feed_dependency_oracle_table_watch"),
    JobContract("feed_template_requests", _template_requests_status,
                "apply the feed template requests queued from SQL "
                "(qs_feed_template_apply) through the authoring rules",
                tick=_template_requests_tick, job_id="feed_template_requests"),
    JobContract("published_api_rollup", _published_api_rollup_status,
                "fold the published-API call rows since the lag window into "
                "hourly / daily buckets with a latency histogram; advance the "
                "watermark; sweep old buckets; then the alert pass: every "
                "threshold over every API in its scope, dependency-broken, "
                "sunsets due / reached",
                tick=_published_api_rollup_tick, job_id="published_api_rollup"),
    JobContract("value_list_sync", _value_list_sync_status,
                "re-sync every DAILY value list whose interval has passed (or "
                "whose last sync failed) from its own connection; a failed "
                "sync keeps the previous values and says so",
                tick=_value_list_sync_tick, job_id="value_list_sync"),
    JobContract("lake_formation_sync", _lake_formation_status,
                "re-import Lake Formation policies for connections that "
                "carry them", tick=_lake_formation_tick, job_id="lake_formation_sync"),
    # ── singleton services ──────────────────────────────────────────────
    JobContract("iceberg_metadata_sync", _iceberg_sync_status,
                "one pass over the watched-table registry (sync_all_once)",
                tick=_iceberg_sync_tick),
    JobContract("iceberg_manifest_watcher", _watcher_status,
                "poll every watched Iceberg table's metadata for a new "
                "snapshot (run_tick)", tick=_watcher_tick),
    JobContract("brain_duckdb_mirror", _duckdb_mirror_status,
                "one DuckDB-mirror writer pass (tick_once)",
                tick=_duckdb_mirror_tick),
    JobContract("kafka_cache_consumer", _kafka_cache_status,
                "Kafka cache-invalidation consumer",
                no_run_now="a Kafka consumer loop: messages drive it, there "
                           "is no tick"),
    JobContract("custom_jobs_scheduler", _custom_jobs_status,
                "run every admin custom job that is due (_process_due_jobs)",
                tick=_custom_jobs_tick, verdict=_custom_jobs_verdict),
    JobContract("prewarm_background", _prewarm_status,
                "DECLARED NOT WIRED (prewarm_background_service)",
                no_run_now="registered INERT -- see "
                           "prewarm_background_service.NOT_WIRED_REASON"),
    JobContract("etl_pipelines", _etl_status,
                "trigger every scheduled ETL pipeline that is due "
                "(etl_engine._scheduler_tick)", tick=_etl_tick),
    JobContract("dq_scheduled_loop", _dq_status,
                "execute every enabled data-quality rule", job_id="dq_scheduled_run"),
    JobContract("sla_scanner", _sla_scanner_status,
                "flag DataFlow runs past their SLA (_scan_once)",
                tick=_sla_scanner_tick, job_id="dataflow_sla_scan"),
    JobContract("dataflow_scheduler_autostart", _dataflow_status,
                "the native DataFlow schedule poll loop",
                no_run_now="a poll loop owned by init_workflow_subsystem, held "
                           "by the pod that started it; POST "
                           "/api/dataflows/scheduler/tick runs one pass there"),
    JobContract("feed_sla_watcher", _feed_sla_status,
                "evaluate acting time for every date holding a WAIT run "
                "(evaluate_once)", tick=_feed_sla_tick),
    JobContract("feed_kafka_arrivals", _kafka_arrivals_status,
                "the dependency-arrival Kafka consumer",
                no_run_now="a Kafka consumer: messages drive it; its resolver "
                           "pass runs per message"),
    JobContract("feed_netcool_sender", _netcool_status,
                "the Netcool store-and-forward drainer",
                no_run_now="a drainer thread that forwards continuously; "
                           "there is no tick (enqueue a test event through "
                           "the feed alerting routes)"),
    JobContract("spark_k8s_reconciler", _spark_reconciler_status,
                "supervise spark_k8s driver pods",
                no_run_now="a supervisor loop over a Kubernetes API client it "
                           "builds at start (availability ladder, leader "
                           "gate per iteration); one pass needs that client "
                           "-- declared not tickable on demand"),
    # ── brain daemons ───────────────────────────────────────────────────
    _brain_daemon("iceberg_mirror_daemon", "core.iceberg_mirror", "mirror_daemon_tick",
                  "build/refresh Iceberg mirrors for hot tables",
                  _ring_status("core.iceberg_mirror", "get_recent_ticks"),
                  verdict=_mirror_verdict),
    _brain_daemon("plain_parquet_mirror_daemon", "core.plain_parquet_mirror",
                  "mirror_daemon_tick", "build/refresh plain-parquet mirrors",
                  _ring_status("core.plain_parquet_mirror", "recent_ticks"),
                  verdict=_mirror_verdict),
    _brain_daemon("adaptive_prefetch", "core.query_history_prefetcher",
                  "prefetch_daemon_tick",
                  "rank hot (table, column) pairs from query history; enqueue "
                  "bloom + supplement scans", _prefetch_status,
                  job_id="__adaptive_prefetch__", verdict=_prefetch_verdict),
    _brain_daemon("pruning_alerts_daemon", "core.pruning_alerts", "alerts_daemon_tick",
                  "dispatch pruning alerts to the configured channels",
                  _alerts_status, verdict=_alerts_verdict),
    _brain_daemon("brain_coordinator_daemon", "core.brain_coordinator",
                  "coordinator_tick", "read pressure, steer the brain's components",
                  _coordinator_status),
    _brain_daemon("portal_cred_prewarmer", "core.portal_cred_prewarmer",
                  "prewarmer_tick", "keep the AWS-portal credential cache warm "
                  "(per pod)", _prewarmer_status, scope=SCOPE_PER_PROCESS),
    _brain_daemon("output_gateway_cleanup", "core.output_gateway",
                  "output_gateway_cleanup_tick", "expire output-gateway artifacts",
                  _ring_status("core.output_gateway", "get_recent_ticks"),
                  verdict=_gateway_verdict),
    _brain_daemon("plain_parquet_sync", "core.plain_parquet_metadata_sync",
                  "sync_tick", "scan plain-parquet tables' metadata into the brain",
                  _ring_status("core.plain_parquet_metadata_sync", "recent_ticks")),
    JobContract("reconciliation_scheduler", _no_module_state,
                "run every due reconciliation entity check",
                job_id="__reconciliation_check__"),
    _brain_daemon("brain_cleanup_daemon", "core.brain_cleanup_daemon", "cleanup_tick",
                  "evict stale brain_pruning_memo / brain_route_outcome rows, "
                  "expire time-bound report grants", _brain_cleanup_status),
    _brain_daemon("writer_advisor_shadow_auto_apply", "core.writer_advisor",
                  "shadow_auto_apply_daemon_tick",
                  "write SHADOW auto-apply ledger rows", _writer_advisor_status,
                  verdict=_advisor_verdict),
    _brain_daemon("clockwork_alert_notifier", "core.clockwork.notifier",
                  "run_notifier_once", "deliver pending Clockwork alerts"),
    # ── the extras (EXTRA_JOBS) ─────────────────────────────────────────
    JobContract("iceberg_snapshot_reactions", _reactions_status,
                "commit-driven reactions: Iceberg-commit arrivals + warm-on-commit",
                no_run_now=_SNAPSHOT_LISTENER_REASON, scope=SCOPE_PER_PROCESS),
    JobContract("iceberg_warm_on_commit", _warm_status,
                "warm the file list and bloom sidecars of a freshly committed "
                "snapshot", no_run_now=_SNAPSHOT_LISTENER_REASON,
                scope=SCOPE_PER_PROCESS, verdict=_warm_verdict),
    JobContract("iceberg_snapshot_indexer", _indexer_status,
                "drain queued snapshot builds: partition-index backfill + "
                "footer capture (_drain_once)", tick=_indexer_tick,
                scope=SCOPE_PER_PROCESS),
    JobContract("fleet_syncer", _fleet_syncer_status,
                "one leader-gated fleet sync pass (FleetSyncer.run_tick)",
                tick=_fleet_syncer_tick, scope=SCOPE_PER_PROCESS,
                verdict=_fleet_syncer_verdict),
    JobContract("iceberg_cache_lru", _no_module_state,
                "evict Iceberg snapshot/manifest cache rows past the LRU caps",
                job_id="__iceberg_cache_lru__"),
    JobContract("iceberg_meta_key_refresh", _no_module_state,
                "refresh every Iceberg metadata-key cache row (BF-512)",
                job_id="__iceberg_meta_key_refresh__"),
    JobContract("partition_cache_refresh", _no_module_state,
                "refresh partition caches for every registered Iceberg table",
                job_id="__partition_cache_refresh__"),
    JobContract("feed_etl_dep_poller", _no_module_state,
                "poll pending feed runs with ETL dependencies; flip WAIT/RUN",
                job_id="__feed_etl_dep_poller__"),
    JobContract("feed_sod_generator", _sod_status,
                "the start-of-day generator: one feed_runs row per active feed "
                "DUE on the business date (daily / month_end / workday N by "
                "its calendar; held WAIT on unmet dependencies); fires at "
                "feed_generation.sod_cron and 120 s after boot",
                job_id="__feed_sod_generator__", verdict=_sod_verdict),
    JobContract("pruning_history_writer", _pruning_history_writer_status,
                "flush the queued query_pruning_history rows to the DB and "
                "report the writer's ledger (enqueued / written / dropped / "
                "failed / skipped, last error, worker alive)",
                tick=_pruning_history_writer_tick, scope=SCOPE_PER_PROCESS),
    # ── component health, one place (2026-10-17) ────────────────────────
    JobContract("component_health_reporter", _component_health_reporter_status,
                "one reporter cycle: this pod's facts, every check it owns "
                "through the bounded pool, the intents addressed to it, one "
                "upsert of its component_health rows",
                tick=_component_health_reporter_tick, scope=SCOPE_PER_PROCESS,
                verdict=_component_health_reporter_verdict),
    _brain_daemon("component_health_fleet_watcher", "core.component_health.fleet_watcher",
                  "watcher_tick",
                  "probe the dependencies due this tick (bounded, round-robin), "
                  "write the fleet rows (dependencies, the scheduler election, "
                  "every singleton daemon's verdict), confirm transitions, raise "
                  "/ clear component alerts, expire intents, GC dead pods",
                  _component_health_watcher_status,
                  verdict=_component_health_watcher_verdict),
]

CONTRACTS: Dict[str, JobContract] = {c.name: c for c in _DECLARATIONS}
assert len(CONTRACTS) == len(_DECLARATIONS), "a job is declared twice"


def declared_names() -> List[str]:
    """TEST SEAM (declared 2026-10-07): every name the guard expects a
    contract for -- the registry's SCHEDULER_OWNED gate names plus
    EXTRA_JOBS."""
    from core.daemon_registry import SCHEDULER_OWNED
    return sorted(set(SCHEDULER_OWNED) | set(EXTRA_JOBS))


def record_event_tick(name: str, raw: Any, *, duration_s: Optional[float] = None,
                      error: Optional[str] = None) -> Dict[str, Any]:
    """A self-driven run (listener fired, own loop ticked) recorded by the
    OWNING module in the process it ran in: ``raw`` is classified by the
    job's own verdict exactly as run-now would classify it."""
    c = CONTRACTS.get(name)
    if error is not None:
        return record_tick(name, trigger=TRIGGER_EVENT, outcome=OUTCOME_ERROR,
                           reason=error[:300], duration_s=duration_s,
                           result=raw)
    if c is not None:
        outcome, reason, counts = _verdict_for(c, raw)
    else:
        outcome, reason, counts = classify(raw)
    return record_tick(name, trigger=TRIGGER_EVENT, outcome=outcome,
                       reason=reason, counts=counts, duration_s=duration_s,
                       result=raw)


__all__ = [
    "CONTRACTS", "DURABLE_TICKS_PER_JOB", "EXTRA_JOBS", "JobContract",
    "LEDGER_DURABLE", "LEDGER_MEMORY", "OUTCOMES", "TRIGGER_EVENT",
    "TickRefused",
    "all_ticks", "attach_scheduler_listener", "classify", "declared_names",
    "durable_ticks", "last_tick", "last_tick_for_job_id", "local_run_now",
    "local_status", "local_ticks",
    "record_event_tick", "record_tick", "recent_ticks",
    "reset_ledger_for_tests", "reset_ring_for_tests", "run_now",
    "runs_here", "status", "ticks_with_source",
]
