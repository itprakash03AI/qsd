"""Phase 139 audit-fix Gap 1 — Iceberg V2 Merge-on-Read (MoR) delete file support.

Iceberg V2 supports MoR tables where row deletions are recorded in separate
*delete files* rather than rewriting data files. There are two kinds:

1. **Position deletes** — parquet files with columns ``file_path`` (string)
   and ``pos`` (long). Each row identifies a (data_file, row_position) pair
   that should be EXCLUDED from query results.
2. **Equality deletes** — parquet files with the equality columns. Any data
   row matching ALL equality columns of any equality-delete row is EXCLUDED.

When delete files are present and ``iceberg_mor.enabled=true`` (default false
to preserve existing behaviour for append-only tables), this module:

- Collects delete-file metadata from DELETE manifests (skipped today)
- Returns helpers that the view-registration layer wraps around
  ``read_parquet([...])`` with DuckDB anti-joins / NOT EXISTS predicates

The current behaviour (skip delete files entirely) is preserved by default.
Users with MoR tables opt in via config — enabling produces CORRECT results
at the cost of additional S3 reads + DuckDB anti-join evaluation per query.

Reference: Iceberg V2 spec §"Row-level Deletes"
https://iceberg.apache.org/spec/#row-level-deletes
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class MorDeleteCollectionError(RuntimeError):
    """Raised when DELETE manifests exist but cannot be fully read.

    DATA-COMPLETENESS (F2, 2026-07-15): a partially-read delete set silently
    UNDER-applies deletes -> the row COUNT comes back too HIGH (the +726 class
    of bug).  When we KNOW a snapshot has delete manifests but any one of them
    fails to read, we can no longer guarantee a complete merge-on-read result,
    so we fail LOUD rather than serve a delete-blind / partially-deleted view.
    The caller (Step 4a) re-raises this instead of swallowing it.
    """


class MorDeletesUnresolvableError(RuntimeError):
    """Iceberg MoR fail-loud refusal -- delete files EXIST for the table but
    provably cannot be applied (resolution/download failure, no fid->name map
    for equality deletes, unmappable rewritten read paths for position
    deletes, or a road that served the data files without collecting the
    deletes the snapshot declares).  Serving the plain view would silently
    OVERCOUNT.

    Subclasses RuntimeError so every existing caller/test that catches (or
    pytest.raises) RuntimeError keeps working unchanged.  Declared HERE
    (2026-10-25; it lived in ``core.duckdb_views``, which re-exports it) so
    the federation engine and the cross-source road can raise the SAME type
    without importing the view engine, and ``api.connector_errors`` can map
    it to a 422 carrying the sentence.
    """


class MorDisabledWithDeletesError(ValueError):
    """The reader met DELETE manifests with ``iceberg_mor.enabled=false`` and
    no ``allow_stale_reads`` opt-in (2026-10-25).  A ValueError, as the bare
    one it replaces, so every ``except ValueError`` keeps its meaning -- and
    a TYPE, so a road that lists a table's files inside a fail-open handler
    (the federation engine's listing handler fell through to a whole-prefix
    glob, i.e. the deleted rows AND every orphan file) can re-raise exactly
    this refusal and nothing else."""


#: ``_out_meta`` keys the reader's Step 4a stamps when the snapshot's manifest
#: list carries DELETE manifests (and MoR is enabled).  ABSENT on an
#: append-only snapshot; PRESENT (possibly empty) once the deletes were
#: collected; restored by the brain memo and the L1 file-list cache.
DELETE_LIST_KEYS = ("pos_delete_files", "eq_delete_files")


def collected_deletes(meta: Optional[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """``(position_delete_files, equality_delete_files)`` the reader collected
    for this read -- ``([], [])`` when it collected none."""
    m = meta or {}
    return list(m.get("pos_delete_files") or []), list(m.get("eq_delete_files") or [])


def uncollected_deletes_reason(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    """THE rule for "this road was handed data files WITHOUT their deletes"
    (2026-10-25).

    The reader stamps the snapshot summary's ``total-delete-files`` on every
    road (``snapshot_total_delete_files``) BEFORE the route split, and its
    Step 4a stamps the collected lists (``DELETE_LIST_KEYS``) only on the
    roads that walk the delete manifests.  A snapshot that DECLARES delete
    files while the lists are ABSENT means the files came from a road that
    never collected them -- the pyiceberg route (which drops delete entries
    from its result), a caller that passed no ``_out_meta``, or a future
    short-cut.  Applying nothing there is the deleted rows served as data.

    Returns the sentence naming the count, or None when the lists are
    present (collected -- trust them, empty or not) or the summary declares
    none / is absent (an append-only snapshot; the walk would have stamped
    the lists had a delete manifest existed).  Unknown is NOT read as
    "deletes": a summary without the counter on a snapshot whose manifest
    list has no delete manifest is the common append-only case, and the
    manifest walk already stamps the lists for the other one.
    """
    m = meta or {}
    if any(k in m for k in DELETE_LIST_KEYS):
        return None
    raw = m.get("snapshot_total_delete_files")
    try:
        declared = int(raw) if raw is not None else 0
    except (TypeError, ValueError):
        declared = 0
    if declared <= 0:
        return None
    return (f"the snapshot declares {declared} delete file(s) (summary "
            f"total-delete-files) and this read collected none of them")


def _parse_s3_uri(uri: str, default_bucket: str) -> Tuple[str, str]:
    """Split an Iceberg-recorded manifest path into ``(bucket, key)``.

    F3 (2026-07-15): the previous code only stripped the ``s3://`` scheme, so a
    writer that records ``s3a://bucket/key`` (Hadoop ``S3AFileIO``) or ``s3n://``
    left the scheme glued to the S3 Key -> ``get_object`` failed -> the delete
    manifest was silently skipped -> overcount.  We now honour all three iceberg
    schemes and the manifest's OWN bucket (which may differ from the connection
    bucket in a multi-bucket / access-point layout).  A bare key falls back to
    the connection bucket, preserving the historical relative-path behaviour.
    """
    if not uri:
        return default_bucket, uri
    s = uri.strip()
    for _scheme in ("s3://", "s3a://", "s3n://"):
        if s.startswith(_scheme):
            rest = s[len(_scheme):]
            b, _, k = rest.partition("/")
            return (b or default_bucket), k
    return default_bucket, s


def _read_avro(data: bytes) -> List[dict]:
    """Lazy avro reader — fastavro if installed, else None."""
    try:
        import fastavro
        import io
        return list(fastavro.reader(io.BytesIO(data)))
    except Exception as exc:
        logger.debug("[iceberg_mor] avro read failed: %s", exc)
        return []


def _read_avro_strict(data: bytes) -> List[dict]:
    """Avro read that RAISES on failure instead of swallowing it.

    DATA-COMPLETENESS (F2 deep-dive fix, 2026-07-15): for DELETE manifests a
    silent ``[]`` from a DECODE failure (corrupt/truncated body, ``fastavro``
    missing from the image) is indistinguishable from "no deletes" and routes
    around the fail-loud gate -> delete-blind overcount (the +726 class).  The
    lenient ``_read_avro`` above is fine for best-effort reads; DELETE-manifest
    collection uses THIS one so the caller counts a raise as a read failure.  A
    legitimately empty-but-VALID manifest still decodes to ``[]`` without
    raising, so genuinely delete-free snapshots are unaffected.
    """
    import fastavro
    import io
    return list(fastavro.reader(io.BytesIO(data)))


def collect_delete_files(
    s3_client,
    bucket: str,
    manifests: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Walk DELETE manifests (content=1) and return position + equality delete files.

    Returns:
        (position_delete_files, equality_delete_files)

    Each element is a dict with at least:
        ``file_path``  — s3:// or relative path of the delete parquet
        ``partition``  — partition tuple (matches data files for join scope)
        ``record_count`` — how many delete entries are in this file
        ``equality_ids`` — for equality deletes only: list of field-ids
    """
    pos_files: List[Dict[str, Any]] = []
    eq_files: List[Dict[str, Any]] = []

    def _mc(x) -> int:  # content may be int (fastavro) or str -> coerce (F7)
        try:
            return int(x if x is not None else 0)
        except (TypeError, ValueError):
            return 0

    delete_manifests = [m for m in manifests if _mc(m.get("content", 0)) == 1]
    if not delete_manifests:
        return pos_files, eq_files

    # 2026-09-25 (FB-61, measured at the MinIO tap): these bodies were fetched
    # with a bare get_object on EVERY query -- the only manifests the reader
    # re-read -- while the app counters said "0 fetched".  A manifest file is
    # immutable, so it goes through the SAME per-manifest cache the data
    # manifests use (L1 -> L2 -> S3).  A read or decode failure RAISES out of
    # the fetch, so it is never cached and still fails this collection closed.
    try:
        from core import iceberg_snapshot_cache as _isc
    except Exception:                                   # pragma: no cover
        _isc = None
    fetched_from_s3: List[str] = []

    def _fetch_delete_manifest(_b: str, _k: str) -> List[Dict[str, Any]]:
        fetched_from_s3.append(_k)
        obj = s3_client.get_object(Bucket=_b, Key=_k)
        return _read_avro_strict(obj["Body"].read())

    logger.info("[iceberg_mor] reading %d DELETE manifests", len(delete_manifests))
    read_failures = 0
    for m in delete_manifests:
        manifest_path = m.get("manifest_path") or m.get("path", "")
        if not manifest_path:
            # A delete manifest entry with no path is itself an unresolved
            # delete manifest -> we cannot read it -> fail-closed (F2).
            read_failures += 1
            logger.warning("[iceberg_mor] DELETE manifest entry has no path: %r", m)
            continue
        # F3: honour s3://, s3a://, s3n:// and the manifest's own bucket.
        mbucket, key = _parse_s3_uri(manifest_path, bucket)
        # F2: a delete manifest we can't read -- or fetched but cannot DECODE
        # -- is deletes we can't apply.  Never continue silently (that
        # under-applies deletes -> overcount): count it, and the fail-loud
        # gate below refuses the whole collection.
        try:
            if _isc is not None:
                _entries = _isc.get_or_fetch_manifest_entries(
                    bucket=mbucket, manifest_path=key,
                    fetch_fn=_fetch_delete_manifest)
            else:
                _entries = _fetch_delete_manifest(mbucket, key)
        except Exception as exc:
            read_failures += 1
            logger.warning(
                "[iceberg_mor] could not read DELETE manifest s3://%s/%s "
                "(fail-closed -- refusing a delete-blind view): %s: %s",
                mbucket, key, type(exc).__name__, exc,
            )
            continue
        if not isinstance(_entries, list) or getattr(_entries, "qs_read_failed", False):
            read_failures += 1
            logger.warning(
                "[iceberg_mor] DELETE manifest s3://%s/%s came back unreadable "
                "(fail-closed)", mbucket, key)
            continue
        # 2026-08-03 (C6) — the manifest-list entry's own sequence number is
        # the inheritance source for ADDED (status=1) entries whose
        # ``sequence_number`` is null (Iceberg V2 spec §sequence-number
        # inheritance).  Without extracting sequence numbers AT ALL, the
        # seq-scoping arm of build_mor_view_sql was permanently inert and
        # every equality delete applied to every data file — including files
        # written AFTER the delete (a re-inserted CDC key was silently
        # suppressed).
        def _seq_of(x) -> Optional[int]:
            if x is None:
                return None
            try:
                return int(x)
            except (TypeError, ValueError):
                return None

        _manifest_seq = _seq_of(m.get("sequence_number"))
        for entry in _entries:
            if entry.get("status") == 2:  # DELETED entry — skip
                continue
            df = entry.get("data_file") or {}
            content = _mc(df.get("content", 0))
            _entry_seq = _seq_of(entry.get("sequence_number"))
            if _entry_seq is None:
                _entry_seq = _manifest_seq
            payload = {
                "file_path":    df.get("file_path") or df.get("path", ""),
                "partition":    df.get("partition") or {},
                "record_count": int(df.get("record_count", 0) or 0),
                # 2026-10-06 -- carried so sizing decisions (resource
                # admission) can charge a delete file its real bytes.
                # 0 = absent in the manifest = unknown, never "empty".
                "file_size_in_bytes": int(df.get("file_size_in_bytes", 0) or 0),
                "equality_ids": list(df.get("equality_ids") or []),
                # None when neither the entry nor its manifest carries one —
                # build_mor_view_sql then keeps the global (unscoped) apply.
                "sequence_number": _entry_seq,
            }
            if content == 1:  # POSITION_DELETES
                pos_files.append(payload)
            elif content == 2:  # EQUALITY_DELETES
                eq_files.append(payload)
    if read_failures:
        # F2 fail-closed: we could not read every DELETE manifest, so the
        # collected delete set is INCOMPLETE.  Building a view from it would
        # under-apply deletes and overcount rows silently.  Refuse instead.
        raise MorDeleteCollectionError(
            f"{read_failures} of {len(delete_manifests)} DELETE manifest(s) "
            f"could not be read; delete set is incomplete (would overcount). "
            f"Collected {len(pos_files)} position + {len(eq_files)} equality "
            f"delete file(s) before the failure."
        )
    logger.info("[iceberg_mor] collected pos_deletes=%d eq_deletes=%d · "
                "DELETE manifests fetched from S3=%d of %d (the rest from cache)",
                len(pos_files), len(eq_files), len(fetched_from_s3),
                len(delete_manifests))
    return pos_files, eq_files


def _normalize_iceberg_path(p: str) -> str:
    """Canonicalise an Iceberg-recorded file path for anti-join matching.

    Iceberg writers record data-file paths as ``s3://…`` / ``s3a://…`` /
    ``s3n://…``.  QueryStudio may hand DuckDB a presigned HTTPS URL or a local
    temp path to actually READ the file, so we can never compare the read path
    to the delete file's recorded path directly.  Both sides are normalised to
    a scheme-agnostic ``bucket/key`` form so the match survives scheme and
    read-path rewrites.
    """
    if not p:
        return ""
    s = p.strip()
    for _scheme in ("s3a://", "s3n://", "s3://"):
        if s.startswith(_scheme):
            return s[len(_scheme):]
    return s


def mor_view_ddl(view_name: str, select_body: str) -> str:
    """``CREATE OR REPLACE VIEW "<name>" AS <body>`` -- the one spelling of
    the MoR view's DDL over the body ``build_mor_select_sql`` returns."""
    view_name_esc = view_name.replace('"', '""')
    return f'CREATE OR REPLACE VIEW "{view_name_esc}" AS {select_body}'


def build_mor_view_sql(
    view_name: str,
    data_paths: List[str],
    pos_delete_paths: List[str],
    eq_delete_files: List[Dict[str, Any]],
    fid_to_name: Optional[Dict[int, str]] = None,
    *,
    data_orig_paths: Optional[List[str]] = None,
    data_seq_by_path: Optional[Dict[str, int]] = None,
    read_plan: Optional[Any] = None,
) -> str:
    """Build a DuckDB CREATE OR REPLACE VIEW SQL that applies MoR deletes.

    The DDL over ``build_mor_select_sql`` (2026-10-25: the body is its own
    builder so a caller that embeds the delete-aware read as a FROM
    expression -- the federation engine's ``_table_to_expression`` -- gets the
    SAME statement the view routes get, with no second MoR implementation).
    Every rule of the read is documented on ``build_mor_select_sql``.
    """
    return mor_view_ddl(view_name, build_mor_select_sql(
        data_paths, pos_delete_paths, eq_delete_files, fid_to_name,
        data_orig_paths=data_orig_paths, data_seq_by_path=data_seq_by_path,
        read_plan=read_plan))


def build_mor_select_sql(
    data_paths: List[str],
    pos_delete_paths: List[str],
    eq_delete_files: List[Dict[str, Any]],
    fid_to_name: Optional[Dict[int, str]] = None,
    *,
    data_orig_paths: Optional[List[str]] = None,
    data_seq_by_path: Optional[Dict[str, int]] = None,
    read_plan: Optional[Any] = None,
) -> str:
    """The SELECT that reads ``data_paths`` with the MoR deletes applied --
    what follows ``AS`` in the view DDL, and what ``(...)`` makes a FROM
    expression.  With no deletes it is the plain read (identical to the
    non-MoR builder); with no data paths ``SELECT 1 WHERE FALSE``.

    2026-09-25 -- ``read_plan`` (an ``iceberg_read_plan.IcebergReadPlan``)
    is THE decision on how the data files are read and projected: its
    ``read_options`` set ``hive_partitioning`` on the data scan (false when
    the manifest proves the identity partition columns are in the files, so
    ``region=MIDDLE+EAST`` in a path can no longer override ``'MIDDLE EAST'``
    in the file) and its projection is the final SELECT (the current Iceberg
    schema, in order, absent columns as NULL -- no hidden partition
    transforms).  Without a plan the historical shape is emitted.  In both
    cases the view's own helper columns (``filename`` / ``file_row_number``
    from the data scan, ``_rp`` / ``_row_idx`` / ...) never leak.

    Strategy:
      - Position deletes: anti-join the data scan against the union of position
        delete files on ``(original_data_file_path, physical_row_number)``.
      - Equality deletes: per delete file, a ``NOT EXISTS`` on its equality
        column set.

    ``data_paths`` are the paths DuckDB actually READS (presigned URLs / local
    temp paths / raw s3).  ``data_orig_paths`` (optional, parallel to
    ``data_paths``) are the ORIGINAL writer URIs that the delete files reference.
    When supplied, the position-delete anti-join matches on the original path via
    a read→original map — WITHOUT it, matching falls back to the read path, which
    is only correct when DuckDB reads the raw ``s3://`` URIs (AWS-httpfs direct).

    2026-07-15 CORRECTNESS FIXES (silent-overcount bug on MoR/V2 tables):
      1. Physical row position now comes from ``read_parquet(file_row_number=true)``
         — the prior ``ROW_NUMBER() OVER (… ORDER BY (SELECT NULL))`` is
         nondeterministic under DuckDB's parallel row-group scan and matched the
         WRONG rows.  Iceberg ``pos`` is the 0-based physical row index, which is
         exactly what ``file_row_number`` yields (0-based, per-file).
      2. The anti-join matches the delete file's recorded ``file_path`` against
         the data file's ORIGINAL uri (scheme-normalised), not the presigned/local
         READ path — the prior ``pd.file_path = filename`` compare never matched
         in presigned / pre-download / proxy modes, so every "delete-aware" view
         was a silent no-op that counted deleted rows.

    2026-07-15 CORRECTNESS DEPTH (same-day follow-up):
      3. Equality-delete NULL semantics — Iceberg matches NULL to NULL (a delete
         row with a NULL column deletes data rows where that column IS NULL).
         SQL ``=`` never matches NULL, so the prior builder silently KEPT such
         deleted rows (overcount).  Fixed with ``IS NOT DISTINCT FROM``.
      4. Equality-delete sequence-number scoping — per the Iceberg spec an
         equality delete applies only to data files whose data sequence number
         is STRICTLY LESS than the delete file's sequence number; a row
         re-inserted AFTER the delete (higher seq) must survive.  Scoping
         activates ONLY when the caller supplies ``data_seq_by_path`` (read
         path → data sequence number; original-uri keys also resolved via
         ``data_orig_paths``) AND the eq-delete entry carries a
         ``sequence_number``.  Without either, each eq-delete applies globally
         — EXACTLY today's behaviour, so existing callers are unaffected.  A
         data file MISSING from a supplied map also gets the global behaviour
         (unknown seq → delete applies, matching the pre-scoping baseline).
    """
    if not data_paths:
        return "SELECT 1 WHERE FALSE"

    def _esc(s: str) -> str:
        return s.replace("'", "''")

    data_list = ", ".join(f"'{_esc(p)}'" for p in data_paths)

    has_pos = bool(pos_delete_paths)
    has_eq = bool(eq_delete_files and fid_to_name)

    _plan_projected = bool(read_plan is not None and getattr(read_plan, "projected", False))
    _data_read_opts = (
        read_plan.read_options if read_plan is not None
        else "hive_partitioning=true, union_by_name=true"
    )

    # No deletes → plain view (identical to the non-MoR builder).
    if not has_pos and not has_eq:
        if read_plan is not None:
            from core.iceberg_read_plan import iceberg_view_select_sql
            return iceberg_view_select_sql(read_plan)
        return (
            f'SELECT * FROM read_parquet([{data_list}], hive_partitioning=true, '
            f'union_by_name=true)'
        )

    # read-path → original-writer-path map (normalised).  Used to translate the
    # DuckDB ``filename`` (a presigned/local read path) back to the original uri
    # the delete files reference.  Falls back to identity when the caller can't
    # supply originals (AWS-direct: read path already IS the s3 uri).
    use_map = (
        data_orig_paths is not None
        and len(data_orig_paths) == len(data_paths)
        and has_pos
    )
    pathmap_cte = ""
    if use_map:
        _pairs = []
        for _rp, _orig in zip(data_paths, data_orig_paths):
            _pairs.append(f"('{_esc(_rp)}', '{_esc(_normalize_iceberg_path(_orig))}')")
        pathmap_cte = f"_pm(_rp, _orig) AS (VALUES {', '.join(_pairs)}), "

    # Equality-delete sequence-number scoping (Iceberg spec §row-level-deletes):
    # an eq-delete applies only to data files with data-seq STRICTLY LESS than
    # the delete's seq.  One mechanism: a read-path → seq VALUES CTE (_sm)
    # LEFT-JOINed into the data CTE, and a per-delete `_seq < N` predicate.
    # Activates ONLY when the caller supplies seq info on BOTH sides; a data
    # file with unknown seq (NULL after the LEFT JOIN) keeps today's global
    # behaviour (delete applies).
    def _del_seq(ed: Dict[str, Any]) -> Optional[int]:
        v = ed.get("sequence_number")
        if v is None:
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    def _data_seq(idx: int, rp: str) -> Optional[int]:
        v = data_seq_by_path.get(rp)
        if v is None and data_orig_paths is not None \
                and len(data_orig_paths) == len(data_paths):
            _orig = data_orig_paths[idx]
            v = data_seq_by_path.get(_orig)
            if v is None:
                v = data_seq_by_path.get(_normalize_iceberg_path(_orig))
        if v is None:
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    use_seq = bool(
        has_eq
        and data_seq_by_path
        and any(_del_seq(ed) is not None for ed in eq_delete_files)
    )
    seqmap_cte = ""
    if use_seq:
        _spairs = [
            f"('{_esc(_rp)}', {_sv})"
            for _i, _rp in enumerate(data_paths)
            for _sv in (_data_seq(_i, _rp),) if _sv is not None
        ]
        if _spairs:
            seqmap_cte = f"_sm(_rp, _seq) AS (VALUES {', '.join(_spairs)}), "
        else:
            use_seq = False  # no resolvable seqs → today's behaviour

    # ── 2026-08-04 pos-delete anti-join RESTRUCTURE (40 GB spill fix) ──────
    # The previous shape LEFT-JOINed the (tiny) read-path→original-path map
    # onto the FULL data scan and computed
    # ``COALESCE(pm._orig, regexp_replace(rp._rp, …))`` per data row, then
    # anti-joined that DERIVED column against a raw scan of the delete files.
    # Two costs, both paid by the WIDE side:
    #   1. the LEFT JOIN + projection sat between the parquet scan and the
    #      anti-join, obstructing filter pushdown into the (up to 900-column)
    #      scan; and
    #   2. both anti-join inputs were derived subplans, so the optimizer's
    #      build/probe-side choice ran on garbage cardinality estimates —
    #      when it flipped, the hash table was built over the 17M-row ×
    #      900-column DATA side (tens of GB, spilled to .tmp, zero output
    #      until fully built) instead of the few-thousand-row delete side.
    # New shape: translate DELETE keys to read paths inside a small
    # MATERIALIZED CTE (delete rows ⋈ N-row VALUES map — thousands of rows,
    # computed once), and leave the data side a BARE parquet scan.  The
    # build side is now STRUCTURALLY the small side and the wide scan
    # streams through the probe.  Row-level semantics are unchanged: the
    # map covers every data path (built from the same zip), so
    # COALESCE(pm._orig, …) always resolved to pm._orig — matching on the
    # raw read path via the translated delete key is the identical
    # predicate, evaluated on the cheap side.
    pos_cte = ""
    if has_pos:
        pos_list = ", ".join(f"'{_esc(p)}'" for p in pos_delete_paths)
        if use_map:
            pos_cte = (
                "_pd AS MATERIALIZED ("
                "SELECT pm._rp AS _rp, pd.pos AS _pos "
                f"FROM read_parquet([{pos_list}], union_by_name=true) pd "
                "JOIN _pm pm ON regexp_replace(pd.file_path, "
                "'^s3[an]?://', '') = pm._orig"
                "), "
            )
        else:
            # No original-path map (AWS-direct: read path IS the s3 uri).
            # Normalise the delete key once, on the SMALL side.
            pos_cte = (
                "_pd AS MATERIALIZED ("
                "SELECT regexp_replace(pd.file_path, '^s3[an]?://', '') "
                "AS _orig, pd.pos AS _pos "
                f"FROM read_parquet([{pos_list}], union_by_name=true) pd"
                "), "
            )

    # Which helper columns must ride along on the data side:
    #   keep_rp        — raw read path, compared against the translated
    #                    delete keys (map available).
    #   need_orig_path — scheme-normalised read path (no map: delete files
    #                    reference the same uri DuckDB reads).
    keep_rp = has_pos and use_map
    need_orig_path = has_pos and not use_map

    seq_sel = ", sm._seq AS _seq " if use_seq else " "
    join_sm = " LEFT JOIN _sm sm ON rp._rp = sm._rp" if use_seq else ""

    sel_extra = ""
    if keep_rp:
        sel_extra += "    rp._rp AS _rp, "
    if need_orig_path:
        sel_extra += ("    regexp_replace(rp._rp, '^s3[an]?://', '') "
                      "AS _orig_path, ")

    # 2026-09-25 -- ``filename=true`` / ``file_row_number=true`` ADD those two
    # columns to the scan; the inner SELECT used to be ``SELECT *, filename AS
    # _rp, ...`` so both the originals AND the aliases rode along, and the
    # final ``EXCLUDE`` only knew the aliases: every MoR ``SELECT *`` served
    # ``filename`` and ``file_row_number`` as table columns (measured).  The
    # originals are excluded at the source now.
    data_cte = (
        "data AS ("
        "  SELECT rp.* EXCLUDE (_rp, _frn), "
        f"{sel_extra}"
        f"    rp._frn AS _row_idx{seq_sel}"
        "  FROM ("
        "    SELECT * EXCLUDE (filename, file_row_number), "
        "           filename AS _rp, file_row_number AS _frn "
        f"    FROM read_parquet([{data_list}], {_data_read_opts}, "
        "         filename=true, file_row_number=true)"
        f"  ) rp{join_sm}"
        ")"
    )

    # 2026-08-03 (C6) — equality-delete PARTITION scoping.  Per the Iceberg
    # spec, an equality delete stored with a partitioned spec applies only to
    # data files in the SAME partition; only an unpartitioned-spec delete is
    # global.  The partition tuple was collected (payload["partition"]) but
    # never used, so a partition-scoped eq delete removed matching keys in ALL
    # partitions (silent row loss).  We scope by adding the delete's partition
    # values as predicates INSIDE its NOT EXISTS subquery: rows outside the
    # partition make the subquery empty → the row is kept.
    #
    # Only IDENTITY partition fields can be scoped this way (the partition
    # value equals a real data column, and Iceberg data files physically
    # store identity-partitioned columns).  A partition key that is not a
    # schema column (bucket/truncate/days transforms — e.g. "ts_day") cannot
    # be compared against data, so that key is skipped: the delete stays as
    # broad as today's behaviour on that dimension, never broken narrower.
    _schema_cols = set(fid_to_name.values()) if fid_to_name else set()

    # 2026-10-06 -- with a FIELD-ID plan the data scan is projected by field
    # id, so an equality-delete file (also written with field ids) is read the
    # same way: its key columns come back under their CURRENT names whatever
    # they were called when the delete was written.  Any id the plan cannot
    # type keeps the by-name read (today's behaviour).
    _plan_types = ((getattr(read_plan, "field_types", None) or {})
                   if getattr(read_plan, "projection", "") == "field_id" else {})

    def _eq_delete_read(path_esc: str, eq_ids: List[Any]) -> str:
        entries = []
        for _fid in eq_ids:
            try:
                _fi = int(_fid)
            except (TypeError, ValueError):
                return f"read_parquet('{path_esc}')"
            _nt = _plan_types.get(_fi)
            if not _nt or not _nt[1]:
                return f"read_parquet('{path_esc}')"
            entries.append(
                f"{_fi}: {{name: '{_esc(_nt[0])}', type: '{_nt[1]}', "
                f"default_value: NULL}}")
        if not entries:
            return f"read_parquet('{path_esc}')"
        return (f"read_parquet('{path_esc}', schema=MAP {{"
                f"{', '.join(entries)}}})")

    def _sql_literal(v: Any) -> str:
        if v is None:
            return "NULL"
        if isinstance(v, bool):
            return "TRUE" if v else "FALSE"
        if isinstance(v, int):
            return str(v)
        if isinstance(v, float):
            return repr(v)
        try:
            from decimal import Decimal as _Dec
            if isinstance(v, _Dec):
                return str(v)
        except ImportError:  # pragma: no cover
            pass
        return "'" + str(v).replace("'", "''") + "'"

    def _partition_pred(ed: Dict[str, Any]) -> str:
        part = ed.get("partition")
        if not isinstance(part, dict) or not part:
            return ""   # unpartitioned spec → global delete (spec-correct)
        preds: List[str] = []
        for k, v in part.items():
            col = str(k)
            if col not in _schema_cols:
                logger.debug(
                    "[iceberg_mor] eq-delete partition key %r is not a schema "
                    "column (non-identity transform?) — cannot scope on it; "
                    "delete stays global on this dimension", col,
                )
                continue
            col_esc = col.replace('"', '""')
            preds.append(
                f'data."{col_esc}" IS NOT DISTINCT FROM {_sql_literal(v)}'
            )
        return (" AND " + " AND ".join(preds)) if preds else ""

    clauses: List[str] = []
    if has_pos:
        # Anti-join against the small MATERIALIZED delete-key CTE (see the
        # restructure note above) — the key comparison happens on whichever
        # column the data side carries raw (read path with a map, normalised
        # path without).  ``_pos`` is Iceberg's 0-based physical row index.
        if use_map:
            clauses.append(
                "NOT EXISTS (SELECT 1 FROM _pd WHERE _pd._rp = data._rp "
                "AND _pd._pos = data._row_idx)"
            )
        else:
            clauses.append(
                "NOT EXISTS (SELECT 1 FROM _pd "
                "WHERE _pd._orig = data._orig_path "
                "AND _pd._pos = data._row_idx)"
            )
    if has_eq:
        for ed in eq_delete_files:
            eq_path = ed.get("file_path", "")
            eq_ids = ed.get("equality_ids") or []
            if not eq_path or not eq_ids:
                continue
            eq_cols = [fid_to_name.get(int(fid)) for fid in eq_ids if fid_to_name.get(int(fid))]
            if not eq_cols:
                continue
            eq_path_e = _esc(eq_path)
            # Iceberg equality semantics: NULL equals NULL (a delete row with a
            # NULL column deletes rows where that column IS NULL) — SQL `=`
            # never matches NULL, which silently KEPT deleted rows (overcount).
            on_clause = " AND ".join(
                f'data."{c.replace(chr(34), chr(34)*2)}" IS NOT DISTINCT FROM '
                f'ed."{c.replace(chr(34), chr(34)*2)}"'
                for c in eq_cols
            )
            # Sequence scoping: only data files with seq < the delete's seq are
            # affected; unknown seq (NULL) → delete applies (today's baseline).
            _dseq = _del_seq(ed) if use_seq else None
            seq_pred = (
                f" AND (data._seq IS NULL OR data._seq < {_dseq})"
                if _dseq is not None else ""
            )
            part_pred = _partition_pred(ed)
            clauses.append(
                f"NOT EXISTS (SELECT 1 FROM {_eq_delete_read(eq_path_e, eq_ids)} ed "
                f"WHERE {on_clause}{seq_pred}{part_pred})"
            )

    full_where = " AND ".join(clauses) if clauses else "TRUE"
    _pad = getattr(read_plan, "pad_select", "") if read_plan is not None else ""
    _excl: List[str] = []
    if keep_rp:
        _excl.append("_rp")
    if need_orig_path:
        _excl.append("_orig_path")
    _excl.append("_row_idx")
    if use_seq:
        _excl.append("_seq")
    exclude_cols = ", ".join(_excl)
    # With a projecting read plan the final SELECT is the current Iceberg
    # schema itself (helper columns are simply not named); otherwise the
    # historical ``* EXCLUDE (helpers)``.
    #
    # 2026-10-06 -- a by-NAME plan carries a typed zero-row PAD (every current
    # column), UNION ALL BY NAME'd onto the rows that survive the deletes, so
    # a column no data file in this view (or in a worker's slice of it)
    # carries is NULL rather than a binder error.  Applied AFTER the delete
    # predicates on purpose: the anti-join keeps its bare-scan data side (the
    # 2026-08-04 restructure) and the pad never meets a delete.
    if _pad:
        _kept = (f"SELECT * FROM data WHERE {full_where}" if _plan_projected
                 else f"SELECT * EXCLUDE ({exclude_cols}) FROM data WHERE {full_where}")
        _sel = (read_plan.select_list if _plan_projected
                else "*" + (getattr(read_plan, "star_replace", "") or ""))
        return (
            f"WITH {pathmap_cte}{seqmap_cte}{pos_cte}{data_cte} "
            f"SELECT {_sel} FROM (({_kept}) UNION ALL BY NAME ({_pad})) AS _qs_mor"
        )
    final_select = (
        f"SELECT {read_plan.select_list} FROM data" if _plan_projected
        else f"SELECT * EXCLUDE ({exclude_cols}) FROM data"
    )
    return (
        f"WITH {pathmap_cte}{seqmap_cte}{pos_cte}{data_cte} "
        f"{final_select} "
        f"WHERE {full_where}"
    )


def is_mor_enabled() -> bool:
    """Read iceberg_mor.enabled from config. Default false for back-compat."""
    try:
        from core.config import get as _cfg_get
        # 2026-09-15: aligned to the declared default (True).
        return bool(_cfg_get("iceberg_mor", "enabled", True))
    except Exception:
        return False


def allow_stale_reads() -> bool:
    """When a V2 table has DELETE files but MoR is NOT enabled, should the
    reader return DATA-ONLY (deleted rows included) instead of FAILING LOUD?

    Default FALSE: refuse rather than silently return deleted/updated-away rows.
    An admin who knowingly accepts data-only reads (e.g. append-mostly tables
    where the occasional deleted row is tolerable) sets
    ``iceberg_mor.allow_stale_reads=true``."""
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("iceberg_mor", "allow_stale_reads", False))
    except Exception:
        return False
