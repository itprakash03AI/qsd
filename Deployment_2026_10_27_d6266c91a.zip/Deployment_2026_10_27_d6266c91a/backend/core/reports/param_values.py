"""Where a report parameter's choices come from -- ONE decision (2026-10-23).

The owner: "parameter selections...at least partition columns values should
be available in reports as we are [on] iceberg metadata.  Some generic way to
get whatever parameter list configured; it can have [a] static list to be
saved; as we already have iceberg metadata the unique values we can extract."

``report_parameters.values_source`` (NULL = ``auto``):

* ``auto``     -- a saved list when the parameter has one (the behaviour
                  since 2026-08-31); else, for a PARTITION column, the
                  table's partition values read from METADATA (no data scan:
                  Iceberg manifests, Hive folders, Trino ``$partitions``);
                  else the column's distinct values from the DATA.
* ``data``     -- always the column's distinct values (SELECT DISTINCT under
                  row security, narrowed by the cascade parent).
* ``metadata`` -- always the partition values; a column that is not a
                  partition column says so (never an empty list as if it
                  had none).
* ``static``   -- always the saved list.
* ``table``    -- (2026-10-24) another table's column -- a company master --
                  ``lov_source_connection_id`` / ``lov_source_table`` /
                  ``lov_source_column``, read through THE value cache under
                  row security (core/reports/param_choices.py).
* ``list``     -- (2026-10-24) a NAMED value list synced into our database
                  (``value_list_id``; core/value_lists.py): instant, the same
                  for every report that names it, key + label.

Metadata bypasses row security: a manifest lists EVERY partition value, and
a user entitled to one company would be shown all of them.  So metadata is
read only when no row policy can apply (``cache_scope.shared_slot_is_safe``
-- the SAME rule the caches use to decide whether one answer may serve
everyone; an unreadable policy store is not safe) or the caller is an admin
(admins bypass row security).  Otherwise the list comes from the data, under
row security, and the answer says why.  A cascade (a parent selection) also
reads the data: the metadata cannot be narrowed by another column.

Both LOV routes (the app's and the shared / embedded twin) call
:func:`plan` and :func:`partition_values`; neither decides on its own.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

VALUES_SOURCES = ("auto", "data", "metadata", "static", "table", "list")

#: The partition reader caps a SQL connector's list at this many values
#: (api/connections_api.py ``_values_max``); a list that long may be cut.
SQL_PARTITION_VALUES_MAX = 200

_DETECT_TTL_S = 300.0
_detect_memo: Dict[Tuple[int, str], Tuple[float, Any]] = {}


def normalise_source(value: Any) -> str:
    """The stored spelling (``None`` / blank = ``auto``); unknown raises."""
    v = str(value or "").strip().lower() or "auto"
    if v not in VALUES_SOURCES:
        raise ValueError(
            f"values_source must be one of {', '.join(VALUES_SOURCES)} (got {value!r})")
    return v


@dataclass(frozen=True)
class Plan:
    """What to read: ``static`` / ``metadata`` / ``data`` / ``nothing``."""
    read: str
    reason: Optional[str] = None


def plan(param: Dict[str, Any], *, override: Optional[str] = None) -> Plan:
    """The FIRST decision, before anything is read.  ``override`` is the
    editor's "show me the values from X" (capture); a viewer sends none."""
    src = normalise_source(override or param.get("values_source"))
    has_static = bool([v for v in (param.get("static_values") or []) if v not in (None, "")])
    if src == "static":
        return Plan("static") if has_static else Plan(
            "nothing", "This parameter takes its choices from a saved list, and the list is empty.")
    if src == "auto" and has_static:
        return Plan("static")
    if not param.get("lov_column_id"):
        return Plan("nothing", "This parameter has no Filter Column and no saved "
                               "value list, so there is nothing to choose from.")
    if src == "data":
        return Plan("data")
    if src == "list":
        return Plan("list") if param.get("value_list_id") else Plan(
            "nothing", "This parameter takes its choices from a value list, but no list is chosen.")
    if src == "table":
        missing = [f for f in ("lov_source_connection_id", "lov_source_table", "lov_source_column")
                   if not param.get(f)]
        if missing:
            return Plan("nothing", "This parameter takes its choices from another table, but "
                                   "the table is not fully chosen (connection, table and column).")
        return Plan("table")
    # auto (no saved list) or metadata: try the partition metadata first
    return Plan("metadata")


def metadata_allowed(db: Any, user_ctx: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
    """May THIS caller be shown values read from metadata?  See the module
    docstring.  Unknown = no."""
    role = str((user_ctx or {}).get("role") or "")
    if (user_ctx or {}).get("is_admin") or role in ("admin", "super_admin"):
        return True, None
    try:
        from core.row_security import cache_scope
        if cache_scope.shared_slot_is_safe(db):
            return True, None
    except Exception as exc:                                  # noqa: BLE001
        logger.info("[param-values] row-security state unreadable: %s", exc)
    return False, ("Row security applies to this data, so the choices are read "
                   "from the data and filtered for you, not from the table's metadata.")


@dataclass
class PartitionLookup:
    """``is_partition``: True / False / None (could not tell)."""
    is_partition: Optional[bool]
    values: Optional[List[Any]] = None
    truncated: bool = False
    reason: Optional[str] = None
    table: Optional[str] = None


def _ordered(values: List[Any], temporal: bool) -> List[Any]:
    clean = [v for v in values if v is not None and v != ""]
    seen, out = set(), []
    for v in clean:
        k = str(v)
        if k not in seen:
            seen.add(k)
            out.append(v)
    try:
        return sorted(out, key=lambda v: str(v), reverse=temporal)
    except Exception:                                        # noqa: BLE001
        return out


async def _detection(ds: Dict[str, Any], user: dict):
    from api.datasets_api import dataset_partition_detection
    key = (int(ds.get("id") or 0), str(ds.get("updated_at") or ""))
    now = time.monotonic()
    hit = _detect_memo.get(key)
    if hit and now - hit[0] < _DETECT_TTL_S:
        return hit[1]
    det = await dataset_partition_detection(ds, user)
    if det.detected:
        if len(_detect_memo) > 256:
            _detect_memo.clear()
        _detect_memo[key] = (now, det)
    return det


async def partition_values(db: Any, *, dataset_id: int, column_id: int,
                           user: dict, temporal: bool = False) -> PartitionLookup:
    """The column's partition values from METADATA, or why not."""
    import asyncio
    ds = await asyncio.to_thread(db.get_dataset_full, dataset_id)
    if not ds:
        return PartitionLookup(None, reason=f"Dataset {dataset_id} was not found.")
    col = next((c for c in (ds.get("columns") or []) if c.get("id") == column_id), None)
    if not col:
        return PartitionLookup(None, reason=f"Column {column_id} is not in dataset {dataset_id}.")
    phys = str(col.get("physical_name") or "")
    det = await _detection(ds, user)
    hit = det.tables_by_name.get(phys.lower())
    if hit is None:
        if not det.detected:
            return PartitionLookup(None, reason="; ".join(det.warnings)
                                   or "The table's partitions could not be determined.")
        return PartitionLookup(False, reason=f"'{phys}' is not a partition column of the "
                                             f"dataset's table, so it has no partition values.")
    table, conn_id = hit
    if not conn_id:
        return PartitionLookup(None, reason=f"The connection of table {table} is not known.",
                               table=table)
    from api.connections_api import registered_table_partition_values
    try:
        res = await registered_table_partition_values(int(conn_id), table)
    except Exception as exc:                                  # noqa: BLE001
        detail = getattr(exc, "detail", None) or str(exc)
        return PartitionLookup(None, reason=f"The partition values of {table} could not "
                                            f"be read: {detail}", table=table)
    if res.get("error"):
        return PartitionLookup(None, reason=f"The partition values of {table} could not "
                                            f"be read: {res['error']}", table=table)
    by_col = {str(k).lower(): v for k, v in (res.get("values") or {}).items()}
    raw = by_col.get(phys.lower())
    if raw is None:
        return PartitionLookup(None, reason=f"{table} lists no values for partition column "
                                            f"'{phys}'.", table=table)
    values = _ordered(list(raw), temporal)
    cut = bool(res.get("_source")) and len(raw) >= SQL_PARTITION_VALUES_MAX
    return PartitionLookup(True, values=values, truncated=cut, table=table)


def reset_for_tests() -> None:
    _detect_memo.clear()
