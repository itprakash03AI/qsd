"""The report canvas in an export (2026-10-26).

A canvas report's Excel / PDF carry every tile, computed from the SAME stored,
row-secured result the export itself was written from (the caller's own run),
through the same microcube drill the viewer's tiles use -- one answer on every
surface.  A tile that cannot be shown carries its sentence instead of numbers.

``canvas_tile_tables`` returns, per tile (the report's own table excluded --
the export already IS that table; its place on the page comes from
``report_tile_layout``), one entry::

    {"tile_id", "title", "kind", "header", "rows", "note", "layout",
     "formats", "labels", "cut"}

* ``header`` / ``rows`` -- the tile's table.  For a chart the first column
  is the category (scatter / bubble: the point label) and every other column
  is one series: the tile's measures, or the top ``MAX_SERIES`` values of its
  ``series`` field by total (as the viewer draws them).  Scatter rows are
  ``[label, x, y]``, bubble rows ``[label, x, y, size]``.
* ``formats`` -- one dataset ``format_pattern`` per header column ("" = none),
  so the Excel cells and the PDF labels carry the author's number format.
* ``layout`` -- the tile's ``{x, y, w, h}`` on the viewer's 12-column grid.
* ``cut`` -- ``{"shown", "total", "label", "largest_first"}`` when a chart
  draws its ``top_n`` of more categories (the viewer's "Showing 25 of N").

Chart categories are capped by the tile's ``top_n`` (the viewer's default of
25 when unset); tables and pivots list every row the cell budget allows.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

PAGE = 50_000
MAX_SHEET_ROWS = 1_048_575
#: a pivot spreads at most this many column values (the viewer's cap)
MAX_PIVOT_COLUMNS = 200
#: every tile of ONE export together holds at most this many cells --
#: a cap that cuts (and says so on the tile), never refuses the export
MAX_TILE_CELLS = 2_000_000
#: a chart split by a field draws its top this-many values (the viewer's rule)
MAX_SERIES = 8
#: a chart draws this many categories when the tile does not say (the viewer's default)
DEFAULT_TOP_N = 25

#: the chart kinds of the canvas contract (2026-10-26) and their shapes
CARTESIAN_KINDS = ("bar", "hbar", "stacked_bar", "line", "area", "stacked_area", "combo", "radar")
PART_KINDS = ("pie", "donut", "treemap", "funnel", "waterfall")
POINT_KINDS = ("scatter", "bubble")
CHART_KINDS = CARTESIAN_KINDS + PART_KINDS + POINT_KINDS
TABLE_KINDS = ("table", "pivot", "heatmap")

_AGG_WORDS = {"sum": "", "avg": "average", "count": "count", "min": "smallest", "max": "largest",
              "count_distinct": "different values"}
_BAD_SHEET_CHARS = re.compile(r"[\[\]:*?/\\]")


def _label(c: Optional[dict], cid: Any) -> str:
    if not c:
        return f"column #{cid}"
    return str(c.get("friendly_name") or c.get("physical_name") or f"column #{cid}")


def _fmt(c: Optional[dict]) -> str:
    return str((c or {}).get("format_pattern") or "")


def _title(t: dict, cols: Dict[int, dict]) -> str:
    title = str(t.get("title") or "").strip()
    if title:
        return title
    ms = t.get("measures") or []
    ds = t.get("dimensions") or []
    m = _label(cols.get(int(ms[0]["column_id"])), ms[0]["column_id"]) if ms else ""
    d = _label(cols.get(int(ds[0])), ds[0]) if ds else ""
    return f"{m} by {d}" if m and d else (m or d or str(t.get("kind")))


def sheet_names(titles: Sequence[str], taken: Sequence[str] = ()) -> List[str]:
    """Excel sheet names: <= 31 characters, none of []:*?/\\, unique
    (case-insensitive, as Excel compares them), never empty."""
    used = {t.lower() for t in taken}
    out = []
    for raw in titles:
        base = _BAD_SHEET_CHARS.sub(" ", str(raw or "")).strip().strip("'") or "Tile"
        base = base[:31]
        name, n = base, 2
        while name.lower() in used:
            suffix = f" ({n})"
            name = base[: 31 - len(suffix)] + suffix
            n += 1
        used.add(name.lower())
        out.append(name)
    return out


def _measure_header(m: dict, cols: Dict[int, dict]) -> str:
    c = cols.get(int(m["column_id"]))
    words = _AGG_WORDS.get(str(m.get("aggregation")), str(m.get("aggregation")))
    if m.get("aggregation") == "sum" and c and str(c.get("aggregation") or "").lower() in ("sum", "count"):
        words = ""
    return _label(c, m["column_id"]) + (f" ({words})" if words else "")


#: the deepest a canvas goes (grid rows); the save check refuses more and the
#: exports clamp to it, so a hand-edited y can never size an allocation
MAX_GRID_ROWS = 2000


def _layout(t: dict) -> Dict[str, int]:
    lay = t.get("layout") if isinstance(t.get("layout"), dict) else {}
    out = {}
    for k, d in (("x", 0), ("y", 0), ("w", 12), ("h", 4)):
        v = lay.get(k)
        out[k] = int(v) if isinstance(v, int) and not isinstance(v, bool) else d
    # bounded whatever was stored (security review 2026-10-26: the PDF bands
    # and the Excel grid allocate per grid row up to the lowest tile)
    out["x"] = min(max(out["x"], 0), 11)
    out["w"] = min(max(out["w"], 1), 12 - out["x"])
    out["h"] = min(max(out["h"], 1), 60)
    out["y"] = min(max(out["y"], 0), MAX_GRID_ROWS - out["h"])
    return out


def report_tile_layout(report: dict) -> Optional[Dict[str, int]]:
    """Where the report's own table sits on the canvas, or None when the
    canvas has no report tile."""
    canvas = (report.get("layout_config") or {}).get("canvas") if isinstance(report.get("layout_config"), dict) else None
    for t in (canvas or {}).get("tiles") or []:
        if isinstance(t, dict) and t.get("kind") == "report":
            return _layout(t)
    return None


def tile_placeholders(report: dict, dataset_columns: List[dict], note: str) -> List[Dict[str, Any]]:
    """Every tile beside the report's table, at its place, with ``note``
    instead of numbers -- for an export that has no stored result to read
    the tiles from.  A tile that cannot be computed is still SHOWN and says
    why; it never vanishes from the page."""
    canvas = (report.get("layout_config") or {}).get("canvas") if isinstance(report.get("layout_config"), dict) else None
    cols = {int(c["id"]): c for c in dataset_columns if c.get("id") is not None}
    out = []
    for t in (canvas or {}).get("tiles") or []:
        if isinstance(t, dict) and t.get("kind") != "report":
            out.append({"tile_id": t.get("id"), "title": _title(t, cols), "kind": str(t.get("kind") or ""),
                        "header": [], "rows": [], "note": note, "layout": _layout(t), "formats": [],
                        "labels": {}, "cut": None})
    return out


def _drill_all(artifact: Path, dims: List[str], measures: List[dict], *, sort_column: Optional[str],
               sort_direction: str, grain: str, group_cols: Optional[Sequence[str]],
               limit: Optional[int] = None, slicers: Optional[dict] = None) -> Dict[str, Any]:
    from core.reports import microcube as mc
    rows: List[dict] = []
    total = None
    page = 1
    while True:
        res = mc.read_artifact_drill(artifact, dimensions=dims, measures=measures, sort_column=sort_column,
                                     sort_direction=sort_direction, page=page, page_size=PAGE,
                                     artifact_grain=grain, artifact_group_columns=group_cols,
                                     **({"slicers": slicers} if slicers else {}))
        total = res.get("total_rows", total)
        rows.extend(res.get("rows") or [])
        if limit is not None and len(rows) >= limit:
            rows = rows[:limit]
            break
        if not res.get("rows") or len(res["rows"]) < PAGE or (total is not None and len(rows) >= total):
            break
        page += 1
    return {"rows": rows, "total": total if total is not None else len(rows)}


def _num(v: Any) -> Optional[float]:
    from decimal import Decimal
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float, Decimal)):
        return float(v)
    try:
        return float(str(v))
    except (TypeError, ValueError):
        return None


def canvas_tile_tables(artifact: str, report: dict, dataset_columns: List[dict], *,
                       grain: str, group_columns: Optional[Sequence[str]]) -> List[Dict[str, Any]]:
    from core.reports import microcube as mc
    canvas = (report.get("layout_config") or {}).get("canvas") if isinstance(report.get("layout_config"), dict) else None
    tiles = [t for t in (canvas or {}).get("tiles") or [] if isinstance(t, dict) and t.get("kind") != "report"]
    if not tiles or not artifact:
        return []
    cols = {int(c["id"]): c for c in dataset_columns if c.get("id") is not None}
    phys = lambda cid: (cols.get(int(cid)) or {}).get("physical_name") or ""   # noqa: E731
    path = Path(artifact)
    tiles = sorted(tiles, key=lambda t: ((t.get("layout") or {}).get("y", 0), (t.get("layout") or {}).get("x", 0)))
    out: List[Dict[str, Any]] = []
    budget = [MAX_TILE_CELLS]      # cells left for this export's tiles
    for t in tiles:
        title = _title(t, cols)
        kind = str(t.get("kind") or "")
        dims_ids = [int(d) for d in t.get("dimensions") or []]
        ms = [m for m in t.get("measures") or [] if isinstance(m, dict)]
        series = t.get("series")
        measures = [{"column": phys(m["column_id"]), "aggregation": m.get("aggregation"), "alias": f"v{i}__"}
                    for i, m in enumerate(ms)]
        entry: Dict[str, Any] = {"tile_id": t.get("id"), "title": title, "kind": kind, "header": [], "rows": [],
                                 "note": "", "layout": _layout(t), "formats": [], "cut": None,
                                 "labels": {"measures": [_measure_header(m, cols) for m in ms],
                                            "category": _label(cols.get(dims_ids[0]), dims_ids[0]) if dims_ids else "",
                                            "series": _label(cols.get(int(series)), series) if series is not None else ""}}
        try:
            if (kind in ("pivot", "heatmap")) and series is not None:
                _pivot_entry(entry, t, path, cols, phys, dims_ids, ms, measures, series, grain, group_columns, budget)
            elif kind in CHART_KINDS and dims_ids and ms:
                _chart_entry(entry, t, path, cols, phys, dims_ids, ms, measures, series, grain, group_columns, budget)
            else:
                _table_entry(entry, t, path, cols, phys, dims_ids, ms, measures, kind, grain, group_columns, budget)
        except mc.NonAdditiveMeasureError as exc:
            entry["note"] = "This tile cannot be shown at this level: " + "; ".join(
                f"{c}: {r}" for c, r in exc.refused.items())
        except mc.ArtifactNotReady as exc:
            entry["note"] = str(exc)
        except ValueError as exc:
            entry["note"] = ("This run does not have every field this tile uses (the report changed after it "
                             f"ran): {exc}")
        if budget[0] <= 0 and not entry["rows"] and not entry["note"]:
            entry["note"] = f"Not included: this export already holds {MAX_TILE_CELLS:,} tile cells."
        if not entry["formats"] and entry["header"]:
            entry["formats"] = [""] * len(entry["header"])
        out.append(entry)
    return out


def _sort_for(t: dict, dims: List[str], measures: List[dict], phys) -> tuple:
    sort = t.get("sort") if isinstance(t.get("sort"), dict) else None
    if sort and sort.get("by") == "measure" and measures:
        return "v0__", str(sort.get("dir") or "desc")
    if sort and sort.get("by") not in (None, "measure"):
        return phys(sort["by"]), str(sort.get("dir") or "asc")
    return (dims[0] if dims else None), "asc"


def _pivot_entry(entry, t, path, cols, phys, dims_ids, ms, measures, series, grain, group_columns, budget):
    row_dims = [phys(d) for d in dims_ids]
    ser = phys(series)
    res = _drill_all(path, row_dims + [ser], measures, sort_column=row_dims[0] if row_dims else None,
                     sort_direction="asc", grain=grain, group_cols=group_columns,
                     limit=max(1, budget[0] // max(1, len(ms))))
    ser_vals: List[Any] = []
    seen = set()
    for r in res["rows"]:
        k = repr(r.get(ser))
        if k not in seen:
            seen.add(k)
            ser_vals.append(r.get(ser))
    ser_vals.sort(key=lambda v: (v is None, str(v)))
    notes = []
    if len(ser_vals) > MAX_PIVOT_COLUMNS:
        notes.append(f"{MAX_PIVOT_COLUMNS} of {len(ser_vals):,} {_label(cols.get(int(series)), series)} "
                     f"values are spread across.")
        ser_vals = ser_vals[:MAX_PIVOT_COLUMNS]
    if res["total"] > len(res["rows"]):
        notes.append(f"{len(res['rows']):,} of {res['total']:,} combinations are included "
                     f"(an export holds {MAX_TILE_CELLS:,} tile cells).")
    entry["note"] = " ".join(notes)
    grid: Dict[tuple, Dict[str, Any]] = {}
    for r in res["rows"]:
        key = tuple(r.get(d) for d in row_dims)
        grid.setdefault(key, {})[repr(r.get(ser))] = r
    ser_label = _label(cols.get(int(series)), series)
    entry["header"] = [_label(cols.get(d), d) for d in dims_ids] + [
        f"{ser_label} = {'(no value)' if v is None else v}" + (f" · {_measure_header(m, cols)}" if len(ms) > 1 else "")
        for v in ser_vals for m in ms]
    entry["formats"] = [_fmt(cols.get(d)) for d in dims_ids] + [
        _fmt(cols.get(int(m["column_id"]))) for _v in ser_vals for m in ms]
    for key, cells in grid.items():
        row = list(key)
        for v in ser_vals:
            cell = cells.get(repr(v))
            row.extend([cell.get(f"v{i}__") if cell else None for i in range(len(ms))])
        entry["rows"].append(row)
    budget[0] -= len(entry["rows"]) * max(1, len(entry["header"]))


def _table_entry(entry, t, path, cols, phys, dims_ids, ms, measures, kind, grain, group_columns, budget):
    dims = [phys(d) for d in dims_ids]
    if kind == "number":
        dims, dims_ids = [], []
    sort_col, sort_dir = _sort_for(t, dims, measures, phys)
    width = max(1, len(dims) + len(ms))
    res = _drill_all(path, dims, measures, sort_column=sort_col, sort_direction=sort_dir, grain=grain,
                     group_cols=group_columns, limit=max(1, min(MAX_SHEET_ROWS, budget[0] // width)))
    entry["header"] = [_label(cols.get(d), d) for d in dims_ids] + [_measure_header(m, cols) for m in ms]
    entry["formats"] = [_fmt(cols.get(d)) for d in dims_ids] + [_fmt(cols.get(int(m["column_id"]))) for m in ms]
    for r in res["rows"]:
        entry["rows"].append([r.get(d) for d in dims] + [r.get(f"v{i}__") for i in range(len(ms))])
    budget[0] -= len(entry["rows"]) * width
    if res["total"] > len(entry["rows"]):
        entry["note"] = (f"{len(entry['rows']):,} of {res['total']:,} rows are included (an Excel sheet "
                         f"holds {MAX_SHEET_ROWS:,}; an export holds {MAX_TILE_CELLS:,} tile cells).")


def _chart_entry(entry, t, path, cols, phys, dims_ids, ms, measures, series, grain, group_columns, budget):
    kind = entry["kind"]
    cat = phys(dims_ids[0])
    cat_label = _label(cols.get(dims_ids[0]), dims_ids[0])
    top_n = t.get("top_n")
    top_n = int(top_n) if isinstance(top_n, int) and not isinstance(top_n, bool) and top_n > 0 else DEFAULT_TOP_N
    sort_col, sort_dir = _sort_for(t, [cat], measures, phys)
    sort = t.get("sort") if isinstance(t.get("sort"), dict) else None
    largest_first = bool(sort and sort.get("by") == "measure" and str(sort.get("dir") or "desc") == "desc")
    limit = max(1, min(top_n, budget[0] // max(1, 1 + len(ms))))
    cats = _drill_all(path, [cat], measures, sort_column=sort_col, sort_direction=sort_dir, grain=grain,
                      group_cols=group_columns, limit=limit)
    shown = [r.get(cat) for r in cats["rows"]]
    cut = cats["total"] > len(shown)
    notes = []
    if cut:
        entry["cut"] = {"shown": len(shown), "total": int(cats["total"]), "label": cat_label,
                        "largest_first": largest_first}
        notes.append(f"Showing {len(shown)} of {cats['total']:,} {cat_label}"
                     + (", largest first" if largest_first else (", smallest first" if sort and sort.get("by") == "measure" else ""))
                     + ".")
    if series is not None and kind in CARTESIAN_KINDS:
        ser = phys(series)
        ser_label = _label(cols.get(int(series)), series)
        tops = _drill_all(path, [ser], measures[:1], sort_column="v0__", sort_direction="desc", grain=grain,
                          group_cols=group_columns, limit=MAX_SERIES)
        ser_vals = [r.get(ser) for r in tops["rows"]]
        if tops["total"] > len(ser_vals):
            notes.append(f"{len(ser_vals)} of {tops['total']:,} {ser_label} shown (the largest).")
        pairs = _drill_all(path, [cat, ser], measures[:1], sort_column=cat, sort_direction="asc", grain=grain,
                           group_cols=group_columns, limit=max(1, budget[0]),
                           slicers={cat: [v for v in shown if v is not None],
                                    ser: [v for v in ser_vals if v is not None]})
        by: Dict[str, Dict[str, Any]] = {}
        for p in pairs["rows"]:
            by.setdefault(repr(p.get(cat)), {})[repr(p.get(ser))] = p.get("v0__")
        entry["header"] = [cat_label] + ["(no value)" if v is None else str(v) for v in ser_vals]
        entry["formats"] = [_fmt(cols.get(dims_ids[0]))] + [_fmt(cols.get(int(ms[0]["column_id"])))] * len(ser_vals)
        for c in shown:
            entry["rows"].append([c] + [by.get(repr(c), {}).get(repr(s)) for s in ser_vals])
    else:
        entry["header"] = [cat_label] + [_measure_header(m, cols) for m in ms]
        entry["formats"] = [_fmt(cols.get(dims_ids[0]))] + [_fmt(cols.get(int(m["column_id"]))) for m in ms]
        for r in cats["rows"]:
            entry["rows"].append([r.get(cat)] + [r.get(f"v{i}__") for i in range(len(ms))])
        if cut and kind in ("pie", "donut", "treemap"):       # a part of a whole: the rest is one part
            whole = _drill_all(path, [], measures[:1], sort_column=None, sort_direction="asc", grain=grain,
                               group_cols=group_columns, limit=1)
            total_v = _num(whole["rows"][0].get("v0__")) if whole["rows"] else None
            shown_sum = sum(_num(r[1]) or 0.0 for r in entry["rows"])
            if total_v is not None and total_v - shown_sum > 0:
                entry["rows"].append(["Everything else", total_v - shown_sum])
                notes.append('The rest are one part, "Everything else".')
    budget[0] -= len(entry["rows"]) * max(1, len(entry["header"]))
    entry["note"] = " ".join(notes)


_FORMULA_LEADS = ("=", "+", "-", "@", "\t", "\r")


def _cell(v: Any) -> Any:
    """A value as a safe cell: numbers exact, NULL in words, and a TEXT that a
    spreadsheet would run as a formula (=, +, -, @, tab, CR first) kept as
    text with a leading apostrophe -- a company called "=HYPERLINK(...)"
    must be shown, never executed."""
    from decimal import Decimal
    if isinstance(v, Decimal):
        return v            # openpyxl writes Decimal as a number, exactly
    if v is None:
        return "(no value)"
    if isinstance(v, str) and v.startswith(_FORMULA_LEADS):
        return "'" + v
    return v
