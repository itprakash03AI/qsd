"""Business-report PUBLISH lifecycle — one chokepoint (2026-08-17).

Before this module, "publish" was a boolean flip (``toggle_publish``:
``new_val = not existing["is_published"]``) and ``PUT
/api/business-reports/{id}`` mutated the ONLY copy of the definition — an
author's half-finished edit reached every consumer instantly.  There was no
state in which a consumer reads v3 while the author edits v4.

The model now:

* **Draft** — the live ``business_reports`` row.  Editors (owner / admin /
  explicit editor grant) always execute the draft, exactly as today.
* **Published version** — an immutable ``BusinessReportVersion`` snapshot of
  every field execution depends on (:data:`DEFINITION_FIELDS`) plus the
  ``report_parameters`` rows.  Consumers execute the CURRENT version's
  snapshot; the author's draft edits are invisible to them until republish.
* **Republish** mints the next ``version_no`` and moves ``is_current`` —
  unless the definition is byte-identical to the current version, in which
  case republish is idempotent (no noise row; unpublish→publish restores the
  same version).
* **Unpublish** is explicit and reversible: ``is_published=False`` +
  ``lifecycle_status='draft'``; version rows are kept.
* **Lifecycle**: ``draft | published | archived | deprecated``.  Archived /
  deprecated keep ``is_published`` untouched so a direct id stays resolvable
  for audit, but the listing chokepoints exclude them from the consumer
  (published) bucket.  Archived additionally REFUSES consumer execution
  (:class:`ReportArchivedError`); deprecated still executes (with the
  version disclosure) so existing links keep working.

DELIVERY DECISION (stated explicitly, like authorization.py's): a
subscription / scheduled delivery ships the CURRENT PUBLISHED VERSION when
one exists — that is what enterprise reporting tools do (a consumer's inbox
must not receive the author's half-edited draft).  A report that has never
been published (owner delivering their own draft) keeps delivering the
draft, byte-identical to today's behaviour.  Resolution is FAIL-OPEN to the
draft: a version-store hiccup must never turn a working delivery dark.

BACKWARDS COMPATIBILITY: a published report with NO version row (deploy
where alembic 017's backfill has not run yet) executes the draft for
AUTHENTICATED grantees and headless deliveries — exactly today's behaviour,
so no report ever goes dark on deploy.

TOKEN / ANONYMOUS CONSUMPTION (2026-09-15) is the exception to every draft
fallback above: share tokens, embed tokens, published views and API keys
receive the CURRENT PUBLISHED VERSION or a refusal
(:class:`ReportUnpublishedError` 410 / :class:`ReportVersionUnavailableError`
503) — never the draft.  Unpublish therefore REVOKES what every old link
serves, the same way archive does; an unauthenticated caller has no standing
to read a definition the author withdrew or never published.

AUTHORIZATION: never decided here.  ``can_view_business_report``
(core/reports/authorization.py) stays the ONE fail-closed view gate, always
evaluated against the LIVE row — access fields are deliberately not
snapshotted, so revoking access kills old versions too.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

LIFECYCLE_STATES = ("draft", "published", "archived", "deprecated")

#: Every BusinessReport field EXECUTION depends on — what a published
#: version snapshots.  Superset of ``instances._SEMANTIC_FIELDS`` (adds the
#: cross-connection overrides, name/description for presentation, and
#: refresh_on_open).  ACCESS fields (owner / role_whitelist / is_published /
#: owner_group_id / lifecycle_status) and execution STATS are deliberately
#: excluded: authorization and operational state always come from the LIVE
#: row.  ``raw_schedule_config`` is excluded too — scheduling is an
#: operational knob the author must be able to change without republishing.
DEFINITION_FIELDS = (
    "name", "description",
    "dataset_id", "merged_dataset_id", "merge_config",
    "merged_dataset_column_ids", "column_ids", "filter_specs",
    "condition_ids", "order_by", "row_limit", "section_definitions",
    "running_calculations", "slicer_column_ids", "drill_hierarchy_id",
    "layout_config", "data_source_type", "federation_view_id",
    "published_view_id", "raw_saved_query_id", "raw_sql_saved_query_id",
    "raw_sql_file_id", "raw_sql_override", "raw_parameters_schema",
    "raw_connection_override_id",
    "secondary_connection_id", "combine_mode", "join_config",
    "refresh_on_open",
)

#: Snapshot-parameter keys compared for the idempotent-republish check.
#: ``created_at`` is excluded (a re-saved identical parameter set must not
#: mint a new version); ids are INCLUDED — ``depends_on_param_id`` chains
#: reference them, so a recreated parameter set is a real change.
_PARAM_COMPARE_KEYS = (
    "id", "name", "label", "parameter_type", "lov_column_id",
    # 2026-08-31 — static_values MUST be compared.  It was added to the
    # parameter model the same day and not to this tuple, so an author who
    # changed ONLY the curated dropdown list and republished got no new
    # version: definitions_equal saw an identical projection, treated the
    # republish as idempotent, and consumers kept serving the previous
    # snapshot's values.  Exactly what this function's own docstring warns
    # against — "SKIPPING a real change would serve consumers stale bytes".
    # The value IS snapshotted (publish stores the full parameter rows); only
    # the change DETECTION was blind, which is the harder failure to notice.
    "static_values",
    # 2026-10-23 -- where the choices come from: changing it changes what a
    # consumer is offered, so a republish with only this change is a version.
    "values_source",
    # 2026-10-24 -- the other table a parameter's choices come from
    "lov_source_connection_id", "lov_source_table", "lov_source_column",
    # 2026-10-24 -- the named value list a parameter offers
    "value_list_id",
    "depends_on_param_id", "cascade_filter_column_id", "default_value",
    "description", "is_required", "sort_order",
)

#: Parameter columns deliberately NOT compared, with the reason.  Declared so
#: the completeness test below can tell "excluded on purpose" from "forgotten"
#: — the distinction that let static_values slip through.
_PARAM_COMPARE_EXCLUDED = {
    "report_id": "the version belongs to one report; it cannot differ",
    "created_at": "a re-saved identical parameter set must not mint a version",
}


class ReportNotServableError(Exception):
    """Base: a non-editor asked for a definition this report cannot serve
    them.  ``status_code`` is what the API layer answers — the resolver
    decides the VERDICT, the route only transcribes it."""
    status_code = 410


class ReportArchivedError(ReportNotServableError):
    """Raised when a consumer tries to execute an ARCHIVED report.  The API
    layer maps this to HTTP 410 (metadata stays readable for audit; only
    execution is refused).  Editors are exempt — they can still run the
    draft to decide whether to restore it."""
    status_code = 410


class ReportUnpublishedError(ReportNotServableError):
    """Raised when a TOKEN / anonymous consumer asks for a report that is
    not published — never published, or withdrawn by unpublish (2026-09-15).

    Before this, ``resolve_execution_report(consumer=True)`` fell back to
    the LIVE DRAFT: an anonymous holder of an old share/embed link read the
    author's unpublished edits after an explicit unpublish.  A withdrawn
    report REFUSES (410, like archive) — a correctness gate fails, it never
    serves something else."""
    status_code = 410


class ReportVersionUnavailableError(ReportNotServableError):
    """The version store could not be read for a TOKEN / anonymous consumer.
    Authenticated grantees fail open to the draft (a definition the owner
    saved for them); an anonymous caller has no standing to receive the
    draft, so "cannot tell" is a 503, not a leak."""
    status_code = 503


def effective_lifecycle_status(report: Dict[str, Any]) -> str:
    """The report's lifecycle state, deriving NULL from ``is_published`` so
    pre-migration rows read correctly (the compat rule — one place)."""
    status = (report or {}).get("lifecycle_status")
    if status in LIFECYCLE_STATES:
        return status
    return "published" if (report or {}).get("is_published") else "draft"


def can_edit_report(report: Dict[str, Any], user: Optional[dict], db) -> bool:
    """Editor-level check — SAME rule as the API's ``_br_can_edit`` (owner /
    admin / explicit editor grant via the Phase-157 chokepoint), importable
    without ``api.*`` so headless/core callers can use it too."""
    try:
        from core import business_report_permissions as _perm
        return bool(_perm.can_edit(report, user, db))
    except Exception:
        username = (user or {}).get("username", "")
        role = (user or {}).get("role", "viewer")
        try:
            from core.roles import ADMIN_TIER_ROLES
            admin = role in ADMIN_TIER_ROLES
        except Exception:
            admin = role in ("admin", "super_admin")
        return bool(username) and (report.get("owner") == username or admin)


# ── snapshotting ─────────────────────────────────────────────────────────────

def snapshot_definition(report: Dict[str, Any]) -> Dict[str, Any]:
    """The definition payload a version stores — DEFINITION_FIELDS only."""
    return {f: report.get(f) for f in DEFINITION_FIELDS}


def _canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def _params_projection(params: Optional[list]) -> list:
    return sorted(
        [{k: p.get(k) for k in _PARAM_COMPARE_KEYS}
         for p in (params or []) if isinstance(p, dict)],
        key=lambda p: (p.get("sort_order") or 0, str(p.get("name") or "")),
    )


def definitions_equal(version: Dict[str, Any], definition: Dict[str, Any],
                      parameters: Optional[list]) -> bool:
    """Is the draft byte-equivalent to an existing version?  Used for the
    idempotent republish (unpublish→publish restores, never duplicates).
    Uncertainty answers False — minting a possibly-redundant version is
    noise; SKIPPING a real change would serve consumers stale bytes."""
    try:
        if _canon(version.get("definition") or {}) != _canon(definition):
            return False
        return (_canon(_params_projection(version.get("parameters")))
                == _canon(_params_projection(parameters)))
    except Exception as exc:
        logger.debug("[br-publish] definition comparison failed — treating "
                     "as changed (mint): %s", exc)
        return False


# ── publish / unpublish / lifecycle ──────────────────────────────────────────

def publish_report(db, report: Dict[str, Any], published_by: str,
                   notes: Optional[str] = None
                   ) -> Tuple[Dict[str, Any], Dict[str, Any], bool]:
    """Publish (or republish) a report: snapshot the draft as the current
    published version and mark the report published.

    Returns ``(updated_report, version, minted)`` — ``minted=False`` means
    the draft was identical to the current version, which was re-marked
    current instead of duplicated (idempotent republish).

    ``semantic_version`` is stamped via the ONE existing notion of "what
    changed" (``instances.compute_semantic_version``) — fail-open to NULL
    (= unknown, disclosed): an unhashable snapshot must not block a publish.
    """
    report_id = int(report["id"])
    definition, parameters, sv = _snapshot_inputs(db, report)

    current = db.get_current_business_report_version(report_id)
    minted = True
    if current and definitions_equal(current, definition, parameters):
        version = current
        minted = False
    else:
        version = db.create_business_report_version(
            report_id=report_id, definition=definition,
            parameters=parameters, published_by=published_by,
            semantic_version=sv, notes=notes)
    updated = db.update_business_report(
        report_id, is_published=True, lifecycle_status="published")
    logger.info("[br-publish] report %s published as v%s by %s (minted=%s)",
                report_id, version.get("version_no"), published_by, minted)
    return updated, version, minted


def _snapshot_inputs(db, report: Dict[str, Any]
                     ) -> Tuple[Dict[str, Any], Optional[list], Optional[str]]:
    """What a version row stores, computed ONE way for the author publish
    and the lazy backfill: the DEFINITION_FIELDS projection, the parameter
    rows (fail-open to None when unreadable) and the semantic version
    (fail-open to NULL = unknown, disclosed)."""
    report_id = int(report["id"])
    definition = snapshot_definition(report)
    try:
        parameters = db.list_report_parameters(report_id) or []
    except Exception as exc:
        logger.warning("[br-publish] parameters unreadable for report %s — "
                       "snapshotting without them: %s", report_id, exc)
        parameters = None
    sv: Optional[str] = None
    try:
        from core.reports.instances import compute_semantic_version
        sv = compute_semantic_version(db, report)
    except Exception as exc:
        logger.info("[br-publish] semantic_version uncomputable for report "
                    "%s (stored NULL = unknown): %s", report_id, exc)
    return definition, parameters, sv


BACKFILL_PUBLISHER = "system:backfill"


def backfill_published_version(db, report: Dict[str, Any]) -> Dict[str, Any]:
    """A report flagged ``is_published`` with NO version row gets its LIVE
    row snapshotted as v1 (2026-09-15).

    How such a row exists: ``create_business_report(is_published=True)`` —
    the admin sample seed, direct DB writes, a deploy whose alembic-017
    backfill never ran (alembic is never invoked at runtime here).
    Pre-lifecycle, the row WAS the published definition, so snapshotting it
    is the SAME decision alembic 017 makes — applied lazily at the first
    consumer read instead of at migration time, so no existing link goes
    dark and no token ever receives the draft AS the draft: from this call
    on, the report has a version, author edits are invisible until
    republish, and ``served_version`` is disclosed.

    Idempotent (an existing current version is returned untouched) and a
    REPAIR, not an author action: ``is_published`` / ``lifecycle_status``
    are not touched, unlike :func:`publish_report`.
    """
    report_id = int(report["id"])
    current = db.get_current_business_report_version(report_id)
    if current:
        return current
    definition, parameters, sv = _snapshot_inputs(db, report)
    version = db.create_business_report_version(
        report_id=report_id, definition=definition, parameters=parameters,
        published_by=BACKFILL_PUBLISHER, semantic_version=sv,
        notes="v1 backfilled from the live row at first consumer read — "
              "the report was flagged published before the version model")
    logger.warning("[br-publish] report %s was is_published with NO version "
                   "row — backfilled v%s from the live row (%s)",
                   report_id, version.get("version_no"), BACKFILL_PUBLISHER)
    return version


def unpublish_report(db, report_id: int) -> Dict[str, Any]:
    """Explicit + reversible: consumers lose access (fail-closed via the
    authorization chokepoint reading is_published=False); version history is
    KEPT, so a later publish of an unchanged draft restores the same
    version_no."""
    updated = db.update_business_report(
        int(report_id), is_published=False, lifecycle_status="draft")
    logger.info("[br-publish] report %s unpublished (versions retained)",
                report_id)
    return updated


def set_lifecycle_status(db, report: Dict[str, Any], status: str,
                         acting_user: str) -> Dict[str, Any]:
    """One transition entry point.  ``published`` delegates to
    :func:`publish_report` (a lifecycle move to published IS a publish —
    never a flag flip that skips the snapshot); ``draft`` delegates to
    :func:`unpublish_report`.  ``archived`` / ``deprecated`` set the column
    only — ``is_published`` is untouched so a direct id stays resolvable
    for audit while the listing chokepoints hide the report."""
    if status not in LIFECYCLE_STATES:
        raise ValueError(
            f"invalid lifecycle status {status!r} — must be one of "
            f"{list(LIFECYCLE_STATES)}")
    if status == "published":
        updated, _version, _minted = publish_report(db, report, acting_user)
        return updated
    if status == "draft":
        return unpublish_report(db, report["id"])
    updated = db.update_business_report(
        int(report["id"]), lifecycle_status=status)
    logger.info("[br-publish] report %s lifecycle -> %s by %s",
                report.get("id"), status, acting_user)
    return updated


# ── execution resolution — THE draft/published fork ──────────────────────────

def apply_version(report: Dict[str, Any], version: Dict[str, Any]
                  ) -> Dict[str, Any]:
    """Overlay a version's snapshot onto the LIVE row → the effective
    report dict execution uses.

    Definition fields come from the SNAPSHOT; access fields (owner /
    role_whitelist / is_published / owner_group_id) and stats stay LIVE.
    ``_version_parameters`` carries the snapshotted ``report_parameters``
    rows — ``_build_report_filters`` / ``_map_report_params_to_pv`` /
    ``compute_semantic_version`` prefer it over the live table, so a draft
    parameter edit cannot leak into a consumer run either.  ``None`` (a
    backfilled/legacy version that never captured parameters) means
    UNKNOWN → live table (fail-open), never an empty override.
    """
    eff = dict(report)
    defn = version.get("definition") or {}
    for f in DEFINITION_FIELDS:
        if f in defn:
            eff[f] = defn[f]
    if version.get("parameters") is not None:
        eff["_version_parameters"] = version["parameters"]
    eff["_served_version_no"] = version.get("version_no")
    return eff


def version_meta(version: Dict[str, Any]) -> Dict[str, Any]:
    """The additive ``served_version`` disclosure execute responses carry."""
    return {
        "version_no": version.get("version_no"),
        "published_by": version.get("published_by"),
        "published_at": version.get("published_at"),
        "semantic_version": version.get("semantic_version"),
    }


def resolve_execution_report(db, report: Dict[str, Any],
                             user: Optional[dict] = None, *,
                             consumer: bool = False,
                             ) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    """THE fork: which definition does this execution run?

    Returns ``(effective_report, served_version_meta | None)`` — ``None``
    meta = the draft ran (editor, or an authenticated grantee of a report
    with no published version).

    * An editor → the draft (their edits are what they need to see).
    * ARCHIVED + non-editor → :class:`ReportArchivedError` (API maps to
      410).  Metadata endpoints are unaffected — audit stays possible.
    * ``consumer=True`` (share / embed tokens, published views, API keys —
      every caller with NO session) → the current published version's
      snapshot, or REFUSE (:class:`ReportUnpublishedError` 410 /
      :class:`ReportVersionUnavailableError` 503).  The draft is NEVER
      reachable from here (2026-09-15): before, an unpublished report fell
      back to the live draft, so an old link served the author's withdrawn
      edits to anyone holding it.  See :func:`resolve_published_snapshot`.
    * An authenticated caller WITHOUT edit rights (explicit grant /
      owner-group) → the published snapshot when one exists; otherwise the
      draft — the owner granted THEM access to a report whose only
      definition is the draft, and a published report with no version row
      (pre-backfill deploy) must not go dark.  FAIL-OPEN on version-store
      errors for this caller only: the draft is a definition the owner
      deliberately saved, never a wrong answer, only a possibly-newer one.
    """
    editor = False
    if not consumer and user is not None:
        try:
            editor = can_edit_report(report, user, db)
        except Exception as exc:
            logger.debug("[br-publish] edit-check failed — treating caller "
                         "as consumer: %s", exc)
    status = effective_lifecycle_status(report)
    if status == "archived" and not editor:
        raise ReportArchivedError(
            f"Report {report.get('id')} is archived — execution is disabled. "
            f"Its metadata and version history remain readable for audit; "
            f"an admin can restore it via the lifecycle endpoint.")
    if editor:
        return report, None
    if consumer:
        return resolve_published_snapshot(db, report)
    return _resolve_for_grantee(db, report)


def resolve_published_snapshot(db, report: Dict[str, Any]
                               ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """The ONLY definition a caller with no session may receive: the
    CURRENT PUBLISHED VERSION's snapshot.  There is no draft branch in this
    function by construction — every exit is a snapshot or a raise.

    * not ``is_published`` (never published, or withdrawn by unpublish) →
      :class:`ReportUnpublishedError` (410) — the same answer archive gives;
      a link to a withdrawn report is a dead link, not a preview of the
      author's edits.
    * ``is_published`` but no version row → :func:`backfill_published_version`
      mints v1 from the live row (alembic 017's decision, applied lazily)
      and THAT snapshot is served with its ``served_version`` disclosed.
      The draft is not served as the draft; a report published before the
      version model does not go dark either.
    * version store unreadable (lookup OR backfill) →
      :class:`ReportVersionUnavailableError` (503): "cannot tell" refuses,
      it does not fail open.
    """
    report_id = report.get("id")
    if not report.get("is_published"):
        raise ReportUnpublishedError(
            f"Report {report_id} is not published — this link no longer "
            f"serves a definition. The author can republish it.")
    try:
        current = db.get_current_business_report_version(int(report["id"]))
    except Exception as exc:
        logger.warning("[br-publish] version lookup failed for report %s on "
                       "a token/anonymous path — REFUSING (no draft fallback "
                       "for a caller with no session): %s", report_id, exc)
        raise ReportVersionUnavailableError(
            f"Report {report_id}: the published version could not be read; "
            f"retry later.") from exc
    if not current:
        try:
            current = backfill_published_version(db, report)
        except Exception as exc:
            logger.warning("[br-publish] report %s is_published with NO "
                           "version row and the v1 backfill FAILED — "
                           "refusing the token/anonymous caller: %s",
                           report_id, exc)
            raise ReportVersionUnavailableError(
                f"Report {report_id}: no published version snapshot exists "
                f"and one could not be created; retry later.") from exc
    return apply_version(report, current), version_meta(current)


def _resolve_for_grantee(db, report: Dict[str, Any]
                         ) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    """An AUTHENTICATED non-editor (explicit grant / owner-group) or a
    headless delivery the owner scheduled: the published snapshot when one
    exists, else the draft (fail-open — see :func:`resolve_execution_report`).
    Never called for a token / anonymous consumer."""
    if not report.get("is_published"):
        # Unpublished + viewable (explicit grant / owner-group): the draft
        # is the only definition that exists — unchanged behaviour.
        return report, None
    try:
        current = db.get_current_business_report_version(int(report["id"]))
    except Exception as exc:
        logger.warning("[br-publish] version lookup failed for report %s — "
                       "serving the draft to an authenticated grantee "
                       "(fail-open): %s", report.get("id"), exc)
        return report, None
    if not current:
        return report, None
    return apply_version(report, current), version_meta(current)


def resolve_headless_report(db, report: Dict[str, Any]
                            ) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    """Headless (scheduler / subscription delivery) resolution — the
    DELIVERY DECISION from the module docstring: deliveries ship the
    CURRENT PUBLISHED VERSION when one exists, else the draft.  Archived
    does NOT raise here: a delivery of an archived report is stopped by the
    send-time view re-check when access was withdrawn; an archived-but-
    still-authorized subscription keeps delivering the last published bytes
    rather than silently going dark."""
    if effective_lifecycle_status(report) == "archived":
        return _headless_archived(db, report)
    # A delivery is scheduled by an AUTHENTICATED owner/subscriber for a
    # report they can already view — a grantee, not an anonymous token.  It
    # keeps the documented published-else-draft fallback; the token path
    # (``consumer=True``) refuses instead (2026-09-15).
    return _resolve_for_grantee(db, dict(report))


def _headless_archived(db, report: Dict[str, Any]
                       ) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    try:
        current = db.get_current_business_report_version(int(report["id"]))
        if current and report.get("is_published"):
            return apply_version(report, current), version_meta(current)
    except Exception as exc:
        logger.warning("[br-publish] archived headless version lookup failed "
                       "for report %s — draft fallback: %s",
                       report.get("id"), exc)
    return dict(report), None
