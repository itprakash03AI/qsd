"""A report over the UNION ALL of two datasets -- each on its own connection,
lined up by column NAME (2026-10-24, the owner's plan item 2: "datasets ->
reports" on a cross-source query).

A dataset is ONE query on ONE connection (``datasets_api`` refuses a
cross-source source, rightly: it would run half of it).  The cross-source
report is therefore TWO datasets -- say ``fact_tetb`` on cloud S3 and the same
table on on-prem Hive -- and a ``merge_config`` of ``{"merge_type": "union"}``
on the report.  The run is the engine's ONE union
(``FederationEngine.execute_union_query``: every side through the dataset
door -- row security, role visibility, connection routing, truncation
disclosure -- then ``UNION ALL BY NAME``), with the report's FILTERS pushed
into EACH side's own source, so a 40M-row side is narrowed where it lives.

The rule here is the mapping: a column the report selects or filters on,
named by its id in the PRIMARY dataset, is the column of the SAME physical
name in the second dataset (the name the engine emits as the result column,
the name the union lines up on -- exact first, then case-insensitively, as a
Trino side folds unquoted names).  A name the second dataset lacks is
REFUSED, naming it and what the dataset does have -- never a NULL-padded
column passed off as data.  Refused too, with the reason: a dataset's saved
conditions (they are per dataset), calculated metrics and pivots (their
paths have no union), and a union without its second dataset.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

UNION = "union"


class UnionReportRefused(ValueError):
    """A union report that cannot run as configured -- the message says why."""


def is_union(merged_dataset_id: Any, merge_config: Optional[dict]) -> bool:
    return bool(merged_dataset_id) and str((merge_config or {}).get("merge_type") or "").lower() == UNION


def _columns(db, dataset_id: int) -> List[dict]:
    ds = db.get_dataset_full(int(dataset_id)) or {}
    cols = ds.get("columns")
    if cols is None:
        raise UnionReportRefused(f"Dataset {dataset_id} could not be read.")
    return list(cols)


def column_map(db, primary_dataset_id: int, secondary_dataset_id: int,
               primary_column_ids: List[int]) -> Dict[int, int]:
    """primary column id -> the second dataset's column id of the same name."""
    prim = {int(c["id"]): c for c in _columns(db, primary_dataset_id)}
    sec = _columns(db, secondary_dataset_id)
    exact = {str(c.get("physical_name")): int(c["id"]) for c in sec if c.get("physical_name")}
    folded = {str(c.get("physical_name")).lower(): int(c["id"]) for c in sec if c.get("physical_name")}
    out: Dict[int, int] = {}
    missing: List[str] = []
    for cid in primary_column_ids:
        col = prim.get(int(cid))
        if col is None:
            raise UnionReportRefused(
                f"Column id {cid} is not a column of dataset {primary_dataset_id}.")
        name = str(col.get("physical_name") or "")
        hit = exact.get(name, folded.get(name.lower()))
        if hit is None:
            missing.append(name)
        else:
            out[int(cid)] = hit
    if missing:
        have = ", ".join(sorted(exact)[:20]) + (" ..." if len(exact) > 20 else "")
        raise UnionReportRefused(
            f"The second dataset ({secondary_dataset_id}) has no column named "
            f"{', '.join(sorted(set(missing)))} -- a UNION ALL lines the two up BY NAME. "
            f"It has: {have or 'no columns'}.")
    return out


#: aggregates whose per-side partials combine EXACTLY (count -> sum of counts)
REGROUPABLE = {"SUM": "sum", "COUNT": "count", "MIN": "min", "MAX": "max"}


def _aggregate_of(col: dict) -> str:
    """The aggregate the engine emits for a selected column ('' = none) --
    the engine's own rule (a measure / kpi with a declared aggregation)."""
    agg = str(col.get("aggregation") or "").strip().upper()
    from core.federation_engine import VALID_AGGREGATIONS
    return agg if (col.get("column_type") in ("measure", "kpi") and agg in VALID_AGGREGATIONS) else ""


def regroup_plan(db, dataset_id: int, column_ids: List[int]) -> Optional[dict]:
    """When the report aggregates, each side returns its own GROUPED partial
    and the stacked rows must be grouped AGAIN (EMEA 15 + EMEA 100 is one
    EMEA 115, not two rows).  None when nothing is aggregated (detail rows
    stack as they are).  An aggregate whose partials cannot be combined
    exactly (AVG, COUNT_DISTINCT) is REFUSED, naming the column."""
    by_id = {int(c["id"]): c for c in _columns(db, dataset_id)}
    dims, measures, bad = [], [], []
    for cid in column_ids:
        col = by_id.get(int(cid)) or {}
        agg = _aggregate_of(col)
        name = str(col.get("physical_name") or "")
        if not agg:
            dims.append(name)
        elif agg in REGROUPABLE:
            measures.append({"name": name, "fn": REGROUPABLE[agg]})
        else:
            bad.append(f"{col.get('friendly_name') or name} ({agg})")
    if bad:
        raise UnionReportRefused(
            f"{', '.join(bad)} cannot be computed over a UNION ALL of two datasets: each side "
            f"answers its own part, and an average or a distinct count cannot be rebuilt from "
            f"the parts.  Use SUM / COUNT / MIN / MAX, or report the detail rows.")
    return {"group_by": dims, "measures": measures} if measures else None


def _filter_column_ids(filters: Optional[List[dict]]) -> List[int]:
    return [int(f["column_id"]) for f in (filters or []) if isinstance(f, dict) and f.get("column_id") is not None]


def refuse_if_unrunnable(db, *, dataset_id: Any, merged_dataset_id: Any, merge_config: Optional[dict],
                         column_ids: Optional[List[int]], filter_specs: Optional[List[dict]] = None,
                         condition_ids: Optional[List[int]] = None, layout_config: Optional[dict] = None,
                         metric_ids: Optional[List[int]] = None) -> None:
    """Save-time: the same checks the run makes, so a report that can never run
    is refused while its author is here."""
    if str((merge_config or {}).get("merge_type") or "").lower() != UNION:
        return
    if not merged_dataset_id:
        raise UnionReportRefused("A UNION ALL report needs its second dataset (merged_dataset_id).")
    if not dataset_id:
        raise UnionReportRefused("A UNION ALL report needs its first dataset (dataset_id).")
    if int(merged_dataset_id) == int(dataset_id):
        raise UnionReportRefused("A UNION ALL report needs two DIFFERENT datasets.")
    if condition_ids:
        raise UnionReportRefused(
            "Saved conditions belong to one dataset and cannot be applied to both sides of a "
            "UNION ALL -- use filters (they are applied to each side by column name).")
    if metric_ids:
        raise UnionReportRefused("Calculated metrics are not supported on a UNION ALL report.")
    if ((layout_config or {}).get("report_type")) == "pivot":
        raise UnionReportRefused("A pivot report cannot be a UNION ALL of two datasets yet.")
    ids = list(column_ids or []) + _filter_column_ids(filter_specs)
    column_map(db, int(dataset_id), int(merged_dataset_id), ids)
    regroup_plan(db, int(dataset_id), list(column_ids or []))


def union_specs(db, report: dict, column_ids: List[int], filters: Optional[List[dict]]) -> List[dict]:
    """The two sides ``execute_union_query`` runs: the report's columns and
    filters on the first dataset, the same NAMES' columns and filters on the
    second."""
    refuse_if_unrunnable(db, dataset_id=report.get("dataset_id"),
                         merged_dataset_id=report.get("merged_dataset_id"),
                         merge_config=report.get("merge_config"), column_ids=column_ids,
                         filter_specs=filters, condition_ids=report.get("condition_ids"),
                         layout_config=report.get("layout_config"))
    p, s = int(report["dataset_id"]), int(report["merged_dataset_id"])
    cmap = column_map(db, p, s, list(column_ids) + _filter_column_ids(filters))
    # the union stacks BY NAME, exactly: a second-side column spelled in
    # another case is stacked under the FIRST side's spelling
    pname = {int(c["id"]): str(c.get("physical_name")) for c in _columns(db, p)}
    sname = {int(c["id"]): str(c.get("physical_name")) for c in _columns(db, s)}
    rename = {sname[cmap[int(c)]]: pname[int(c)] for c in column_ids
              if sname[cmap[int(c)]] != pname[int(c)]}
    sec_filters = []
    for f in filters or []:
        g = dict(f)
        if g.get("column_id") is not None:
            g["column_id"] = cmap[int(g["column_id"])]
        sec_filters.append(g)
    return [
        {"dataset_id": p, "column_ids": list(column_ids), "filters": list(filters or []) or None},
        {"dataset_id": s, "column_ids": [cmap[int(c)] for c in column_ids], "filters": sec_filters or None,
         "rename": rename},
    ]
