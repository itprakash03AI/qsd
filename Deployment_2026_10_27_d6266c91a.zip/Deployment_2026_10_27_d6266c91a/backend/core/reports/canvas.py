"""The report canvas, checked on save (2026-10-26).

Owner-approved design: docs/REPORT_CANVAS_DESIGN_2026_10_25.html.  The
canvas lives in ``layout_config.canvas``; each tile is a view of the report's
ONE result (the stored, row-secured result of a run) computed through the
microcube (``core/reports/microcube.py``) -- never a second query.

``canvas_problems`` is the server's reading of what is wrong with a canvas,
the same rules as the builder's (frontend/src/components/reports/canvas/
canvasModel.ts::canvasProblems), plus what only the server can know:

* every field a tile uses is one of the report's selected columns (the query
  returns nothing else), and a column of its dataset;
* the way a tile adds values up is EXACT for this report's result.  A report
  whose dataset adds its measures up (or has a calculated metric) stores
  GROUPED rows: tiles may then re-add them (sum), take the smallest / largest,
  or count the different values of a column the rows are grouped by -- a
  count or an average over grouped rows would be a wrong number, so it is
  refused here by name (the microcube refuses the same at run time).

An empty list = the canvas may be saved.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

TILE_KINDS = ("report", "number", "table", "pivot", "heatmap",
              "bar", "hbar", "stacked_bar", "line", "area", "stacked_area", "combo", "radar",
              "pie", "donut", "treemap", "funnel", "waterfall", "scatter", "bubble")
#: one category, 1..8 values (each a series) OR one value split by a series field
SERIES_CHARTS = ("bar", "hbar", "stacked_bar", "line", "area", "stacked_area", "radar")
#: one category, one value
ONE_VALUE_CHARTS = ("pie", "donut", "treemap", "funnel", "waterfall")
#: parts of a whole / a running total: the value must be added up
SUM_ONLY = ("pie", "donut", "treemap", "waterfall")
CHART_KINDS = SERIES_CHARTS + ONE_VALUE_CHARTS + ("combo", "scatter", "bubble")
MAX_SERIES_VALUES = 8
#: the deepest a canvas goes (grid rows) -- the exports clamp to the same
MAX_GRID_ROWS = 2000
AGGREGATIONS = ("sum", "avg", "count", "min", "max", "count_distinct")
GRID_COLS = 12
MAX_TILES = 40
MAX_CHART_POINTS = 500
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_VALID_DATASET_AGGS = ("SUM", "AVG", "COUNT", "MIN", "MAX", "COUNT_DISTINCT")
_NUMERIC_RE = re.compile(r"int|decimal|numeric|double|float|real|number|money", re.I)


def _label(col: Optional[dict], cid: Any) -> str:
    if not col:
        return f"column #{cid}"
    return str(col.get("friendly_name") or col.get("display_name") or col.get("physical_name") or f"column #{cid}")


def _emits_aggregate(col: dict) -> bool:
    agg = str(col.get("aggregation") or "").strip().upper()
    return col.get("column_type") in ("measure", "kpi") and agg in _VALID_DATASET_AGGS


def _is_numeric(col: Optional[dict]) -> bool:
    return bool(col) and (bool(_NUMERIC_RE.search(str(col.get("data_type") or "")))
                          or col.get("column_type") in ("measure", "kpi"))


def dataset_rows_are_grouped(columns: Iterable[dict], has_metrics: bool) -> bool:
    """The microcube's fail-closed grain rule (``_derive_artifact_grain``):
    any dataset column that adds up, or any calculated metric, means the
    stored rows are grouped."""
    return has_metrics or any(_emits_aggregate(c) for c in columns)


def _tile_name(t: dict, cols: Dict[int, dict]) -> str:
    title = str(t.get("title") or "").strip()
    if title:
        return title
    if t.get("kind") == "report":
        return "Report"
    ms = t.get("measures") if isinstance(t.get("measures"), list) else []
    ds = t.get("dimensions") if isinstance(t.get("dimensions"), list) else []
    m = _label(cols.get(_int(ms[0].get("column_id"))), ms[0].get("column_id")) if ms and isinstance(ms[0], dict) else ""
    d = _label(cols.get(_int(ds[0])), ds[0]) if ds else ""
    if m and d:
        return f"{m} by {d}"
    return m or d or str(t.get("kind") or "tile")


def _int(v: Any) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def canvas_problems(canvas: Any, *, dataset_columns: List[dict], report_column_ids: List[int],
                    has_metrics: bool, has_dataset: bool = True) -> List[Dict[str, Optional[str]]]:
    out: List[Dict[str, Optional[str]]] = []
    if canvas is None:
        return out
    if not isinstance(canvas, dict) or not isinstance(canvas.get("tiles"), list):
        return [{"tile_id": None, "message": "The canvas must be an object with a list of tiles."}]
    tiles = canvas["tiles"]
    cols = {int(c["id"]): c for c in dataset_columns if _int(c.get("id")) is not None}
    selected = {int(i) for i in report_column_ids if _int(i) is not None}
    grouped = dataset_rows_are_grouped(dataset_columns, has_metrics)

    def say(t: Optional[dict], message: str) -> None:
        if t is None:
            out.append({"tile_id": None, "message": message})
        else:
            out.append({"tile_id": str(t.get("id") or ""), "message": f"{_tile_name(t, cols)}: {message}"})

    if not tiles:
        say(None, "The report has no tiles. Add at least one.")
    if len(tiles) > MAX_TILES:
        say(None, f"A report can hold {MAX_TILES} tiles; this one has {len(tiles)}.")
    if sum(1 for t in tiles if isinstance(t, dict) and t.get("kind") == "report") > 1:
        say(None, "The report's own table can be placed once.")
    seen: set = set()
    boxes = []
    for t in tiles:
        if not isinstance(t, dict):
            say(None, "Every tile must be an object.")
            continue
        tid = t.get("id")
        if not isinstance(tid, str) or not _ID_RE.match(tid) or tid in seen:
            say(t, "its id is missing or used twice.")
        seen.add(tid)
        kind = t.get("kind")
        if kind not in TILE_KINDS:
            say(t, f'"{kind}" is not a kind of tile.')
            continue
        if len(str(t.get("title") or "")) > 200:
            say(t, "its title is longer than 200 characters.")
        lay = t.get("layout") if isinstance(t.get("layout"), dict) else {}
        x, y, w, h = (lay.get(k) for k in ("x", "y", "w", "h"))
        if not all(isinstance(v, int) and not isinstance(v, bool) for v in (x, y, w, h)) \
                or x < 0 or y < 0 or w < 1 or h < 1 or x + w > GRID_COLS or h > 60 or y + h > MAX_GRID_ROWS:
            say(t, "its place on the page is outside the 12-column grid.")
        else:
            boxes.append((t, x, y, w, h))
        if kind != "report" and not has_dataset:
            say(t, "charts, pivots and number tiles need a report built on a dataset; "
                   "this report runs its own SQL, so it can show its table and its chart view.")
            continue
        dims = t.get("dimensions") or []
        measures = t.get("measures") or []
        series = t.get("series")
        if not isinstance(dims, list) or not isinstance(measures, list):
            say(t, "its fields must be lists.")
            continue
        dim_ids = [_int(d) for d in dims]
        fields = list(dim_ids) + [_int(m.get("column_id")) if isinstance(m, dict) else None for m in measures]
        if series is not None:
            fields.append(_int(series))
        for fid in fields:
            if fid is None or fid not in cols:
                say(t, f"it uses a field that is no longer in the data ({'column #' + str(fid) if fid is not None else 'an unreadable field'}). Remove it from the tile.")
            elif fid not in selected:
                say(t, f"{_label(cols[fid], fid)} is not one of the report's columns, so the report does not return it. Add it to the report.")
        if len(set(dim_ids)) != len(dim_ids):
            say(t, "the same field is used twice.")
        for m in measures:
            if not isinstance(m, dict):
                say(t, "every value must name a column and a way to add up.")
                continue
            agg = m.get("aggregation")
            col = cols.get(_int(m.get("column_id")))
            if agg not in AGGREGATIONS:
                say(t, f'"{agg}" is not a way to add up values.')
                continue
            name = _label(col, m.get("column_id"))
            if col and agg in ("sum", "avg") and not _is_numeric(col):
                say(t, f"{name} is not a number, so it cannot be {'added up' if agg == 'sum' else 'averaged'}. Use Count of different values instead.")
            if grouped and agg == "count":
                say(t, f"this report's rows are already added up, so counting them would count groups, not the "
                       f"underlying rows. Use a count measure of the data (shown as Sum), or Count of different values.")
            if grouped and agg == "avg":
                say(t, f"this report's rows are already added up, so an average of {name} here would be an average "
                       f"of averages -- a wrong number. Show the Sum, or an average measure at the report's own level.")
            if grouped and agg == "count_distinct" and col and _emits_aggregate(col):
                say(t, f"{name} is added up in this report's rows, so its different values cannot be counted.")
        top_n = t.get("top_n")
        if top_n is not None and (not isinstance(top_n, int) or isinstance(top_n, bool) or not 1 <= top_n <= MAX_CHART_POINTS):
            say(t, f"it can draw between 1 and {MAX_CHART_POINTS} values.")
        if kind == "table" and not dims and not measures:
            say(t, "add at least one field.")
        elif kind == "pivot":
            if not dims:
                say(t, "needs at least one row field.")
            if series is None:
                say(t, "needs a column field to spread across.")
            elif _int(series) in dim_ids:
                say(t, "the column field is also a row field.")
            if not measures:
                say(t, "needs a value to show.")
        elif kind == "heatmap":
            if len(dims) != 1:
                say(t, "needs one row field.")
            if series is None:
                say(t, "needs a column field to spread across.")
            elif _int(series) in dim_ids:
                say(t, "the column field is also the row field.")
            if len(measures) != 1:
                say(t, "needs exactly one value to colour the cells by.")
        elif kind in CHART_KINDS:
            if len(dims) != 1:
                say(t, "needs exactly one category field." if kind not in ("scatter", "bubble")
                    else "needs one field that names each point.")
            if kind in SERIES_CHARTS:
                if not 1 <= len(measures) <= MAX_SERIES_VALUES:
                    say(t, f"draws between 1 and {MAX_SERIES_VALUES} values.")
                if series is not None and len(measures) > 1:
                    say(t, "can be split by a series field OR show several values -- not both.")
            elif kind in ONE_VALUE_CHARTS:
                if len(measures) != 1:
                    say(t, "needs exactly one value to draw.")
                if series is not None:
                    say(t, "cannot be split into series.")
                if kind in SUM_ONLY and any(isinstance(m, dict) and m.get("aggregation") != "sum" for m in measures):
                    say(t, ("a waterfall adds its values up as it goes" if kind == "waterfall"
                            else "shows parts of a whole") + ", so its value must be added up (Sum).")
            elif kind == "combo":
                if not 2 <= len(measures) <= MAX_SERIES_VALUES:
                    say(t, f"needs 2 to {MAX_SERIES_VALUES} values: the first as bars, the rest as lines.")
                if series is not None:
                    say(t, "cannot be split into series.")
            elif kind == "scatter" and len(measures) != 2:
                say(t, "needs two values: across (x) and up (y).")
            elif kind == "bubble" and len(measures) != 3:
                say(t, "needs three values: across (x), up (y) and the bubble size.")
            if kind in ("scatter", "bubble") and series is not None:
                say(t, "cannot be split into series.")
            if series is not None and _int(series) in dim_ids:
                say(t, "the series field is also the category.")
        elif kind == "number" and (len(measures) != 1 or dims):
            say(t, "shows exactly one value and no fields.")
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            _, ax, ay, aw, ah = boxes[i]
            tb, bx, by, bw, bh = boxes[j]
            if ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah:
                say(tb, f"it sits on top of {_tile_name(boxes[i][0], cols)}.")
    return out
