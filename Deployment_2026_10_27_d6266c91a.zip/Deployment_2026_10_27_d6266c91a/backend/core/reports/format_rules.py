"""Top N / bottom N conditional formats RANK the column (2026-10-24).

The owner: "on reports conditional formatting does not work".  Two defects:
the viewer never applied the rules at all (only the authoring preview and
the exports did), and ``top_n`` / ``bottom_n`` matched EVERY numeric value
-- the evaluator sees one cell and cannot rank a column, so a "top 5 in
green" painted the whole column green.

A ranking rule now carries its CUT-OFF: the N-th largest (top) / smallest
(bottom) numeric value of the column over the WHOLE result, ties included
(``value >= cutoff`` / ``value <= cutoff``).  :func:`attach_cutoffs` stores it
on each ranking rule as ``_cutoff``, from the rows a document renders or
from the result's stored file; the ONE evaluator
(``api/pdf_export_api._apply_conditional_formats``) and its client mirror
(``reportAuthoringModel.evaluateRuleStyle``) compare against it.  A ranking
rule whose cut-off is not known matches NOTHING, never everything.

``n`` is ``condition_value.n`` (default 10).
"""
from __future__ import annotations

import logging
import math
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

RANKING = ("top_n", "bottom_n")
DEFAULT_N = 10


def rule_n(rule: Dict[str, Any]) -> int:
    try:
        n = int((rule.get("condition_value") or {}).get("n") or DEFAULT_N)
    except (TypeError, ValueError):
        n = DEFAULT_N
    return max(1, n)


def cutoff_key(rule: Dict[str, Any]) -> str:
    """How a cut-off is named on the wire: ``<column>#<rule_order>``."""
    return f"{rule.get('column_name')}#{rule.get('rule_order', 0)}"


def _numbers(values: Iterable[Any]) -> List[float]:
    out: List[float] = []
    for v in values:
        if v is None or v == "" or v == "None":
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if not math.isnan(f):
            out.append(f)
    return out


def cutoff_from_values(rule: Dict[str, Any], values: Iterable[Any]) -> Optional[float]:
    nums = _numbers(values)
    if not nums:
        return None
    n = min(rule_n(rule), len(nums))
    ordered = sorted(nums, reverse=rule.get("condition_type") == "top_n")
    return ordered[n - 1]


def attach_cutoffs(rules: Optional[List[Dict[str, Any]]], *, rows: Optional[List[Any]] = None,
                   columns: Optional[List[str]] = None,
                   artifact: Optional[str] = None) -> List[Dict[str, Any]]:
    """``rules`` with ``_cutoff`` on each ranking rule (copies; the input is
    not changed).  ``rows`` = dicts (or sequences aligned with ``columns``);
    ``artifact`` = the result's parquet file.  Never raises: a cut-off that
    cannot be computed is left off (the rule then matches nothing)."""
    rules = [dict(r) for r in (rules or [])]
    ranking = [r for r in rules if r.get("condition_type") in RANKING and r.get("is_enabled", True)]
    if not ranking:
        return rules
    try:
        if artifact:
            found = cutoffs_from_parquet(artifact, ranking)
        else:
            found = {}
            for r in ranking:
                col = r.get("column_name")
                if rows and isinstance(rows[0], dict):
                    vals = (row.get(col) for row in rows)
                elif rows and columns and col in columns:
                    i = columns.index(col)
                    vals = (row[i] for row in rows)
                else:
                    vals = ()
                found[cutoff_key(r)] = cutoff_from_values(r, vals)
        for r in ranking:
            c = found.get(cutoff_key(r))
            if c is not None:
                r["_cutoff"] = c
    except Exception as exc:                                  # noqa: BLE001
        logger.warning("[fmt-rules] ranking cut-offs could not be computed: %s", exc)
    return rules


def cutoffs_from_parquet(path: str, rules: List[Dict[str, Any]]) -> Dict[str, Optional[float]]:
    """The cut-offs over the WHOLE stored result, one ranked read per rule.
    A rule's column must be a column OF the file (never interpolated
    otherwise); the path is the server's own artifact path."""
    import duckdb
    import pyarrow.parquet as pq
    names = {f.name for f in pq.read_schema(path)}
    out: Dict[str, Optional[float]] = {}
    con = duckdb.connect()
    try:
        for r in rules:
            col = r.get("column_name")
            if col not in names:
                out[cutoff_key(r)] = None
                continue
            q = '"' + str(col).replace('"', '""') + '"'
            order = "DESC" if r.get("condition_type") == "top_n" else "ASC"
            row = con.execute(
                f"SELECT v FROM (SELECT TRY_CAST({q} AS DOUBLE) AS v FROM read_parquet(?)) "
                f"WHERE v IS NOT NULL AND NOT isnan(v) ORDER BY v {order} LIMIT 1 OFFSET ?",
                [path, rule_n(r) - 1]).fetchone()
            if row is None:       # fewer numbers than N: the last one is the cut-off
                row = con.execute(
                    f"SELECT {'MIN' if order == 'DESC' else 'MAX'}(v) FROM (SELECT TRY_CAST({q} AS DOUBLE) AS v "
                    f"FROM read_parquet(?)) WHERE v IS NOT NULL AND NOT isnan(v)", [path]).fetchone()
            out[cutoff_key(r)] = None if row is None or row[0] is None else float(row[0])
    finally:
        con.close()
    return out


def wire_cutoffs(rules: List[Dict[str, Any]]) -> Dict[str, float]:
    """``{<column>#<rule_order>: cutoff}`` for a page answer (the viewer)."""
    return {cutoff_key(r): r["_cutoff"] for r in rules if r.get("_cutoff") is not None}
