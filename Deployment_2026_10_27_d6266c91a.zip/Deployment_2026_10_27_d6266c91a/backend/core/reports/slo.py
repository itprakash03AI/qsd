"""Report SLOs -- "fresh and served by 07:00 London" (2026-09-28).

A report declares ONE promise (``report_slos``): a local time, an IANA
zone and, optionally, the business calendar whose business days the
promise is made on.  The promise is resolved per business date through THE
clocks function every feed SLA uses (``core.feed.acting_time.compute_
clocks`` -> ``sla_at``), so a report and a feed promising "07:00 London" on
the same date breach at the same instant, DST included.

THE RULE.  A report is MET for a business date when a run for that date
completed with readiness ``complete`` (core/reports/readiness.py, the same
gate the feeds wait on) at or before ``sla_at``.  A run whose readiness was
``partial`` or ``unknown`` satisfies nothing: unknown is never complete.

Live states, in the order the desk sorts them (worst first):

    breached            past the promise, not served complete -- an OPEN
                        ledger row and a Netcool problem event
    at_risk             before the promise, and the data is not complete
                        right now
    could_not_evaluate  the promise cannot be resolved (bad zone, an
                        unreadable calendar) -- named, never "met"
    served_late         breached, then a complete run landed -- the ledger
                        row is kept (it WAS missed) and the alert clears
    ready               before the promise, the data is complete and no run
                        has been served yet (a schedule or an open will)
    met                 served complete by the promise
    not_expected        not a business day on the promise's calendar

Every breach is a row in ``report_slo_breaches`` with its CAUSE --
``data_not_ready`` / ``could_not_tell`` / ``no_run`` /
``no_readiness_declared`` -- because "missed" without "why" is a number,
not a finding.  The Netcool Identifier is
``QS:<env>:REPORT_SLO_BREACHED:report-<id>:<date>`` (stable per report and
business date; the console tallies repeats) and the resolution reuses it.
Evaluated by the feed SLA watcher's pass (core/feed/sla_watcher.py) -- one
election, one interval, one environment -- never a second daemon.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from core.reports.readiness import (
    STATE_COMPLETE, STATE_PARTIAL, STATE_UNDECLARED, STATE_UNKNOWN,
    evaluate_readiness,
)

logger = logging.getLogger(__name__)

STATUS_BREACHED = "breached"
STATUS_AT_RISK = "at_risk"
STATUS_COULD_NOT_EVALUATE = "could_not_evaluate"
STATUS_SERVED_LATE = "served_late"
STATUS_READY = "ready"
STATUS_MET = "met"
STATUS_NOT_EXPECTED = "not_expected"

#: Worst first -- the order the desk shows and the ledger reasons about.
STATUS_ORDER = (STATUS_BREACHED, STATUS_AT_RISK, STATUS_COULD_NOT_EVALUATE,
                STATUS_SERVED_LATE, STATUS_READY, STATUS_MET, STATUS_NOT_EXPECTED)

CAUSE_DATA_NOT_READY = "data_not_ready"
CAUSE_COULD_NOT_TELL = "could_not_tell"
CAUSE_NO_RUN = "no_run"
CAUSE_NO_READINESS_DECLARED = "no_readiness_declared"

ALERT_TYPE = "REPORT_SLO_BREACHED"
CLEARS_WHEN = "a run for the business date completes with readiness Complete"

#: (report_id, business date ISO) -> the Netcool event last raised, so the
#: pass can send its resolution.  In-memory, like the feed watcher's: a
#: restart costs one un-cleared alert that ExpireTime reaps.
_raised: Dict[Any, Any] = {}
_lock = threading.Lock()


def report_object_key(report_id: int) -> str:
    """The Identifier's OBJECT part: stable per report, never the name (a
    rename must not open a second alert)."""
    return f"report-{int(report_id)}"


@dataclass
class SloStatus:
    report_id: int
    business_date: date
    status: str
    sla_at: Optional[datetime] = None
    served_at: Optional[datetime] = None
    cause: Optional[str] = None
    detail: Optional[str] = None
    readiness_state: Optional[str] = None
    readiness_summary: Optional[str] = None
    minutes_late: Optional[int] = None
    minutes_left: Optional[int] = None
    breach: Optional[dict] = None
    slo: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        iso = lambda d: d.isoformat() if d else None    # noqa: E731
        return {
            "report_id": self.report_id,
            "business_date": self.business_date.isoformat(),
            "status": self.status,
            "sla_at": iso(self.sla_at),
            "serve_by": self.slo.get("serve_by"),
            "timezone": self.slo.get("timezone"),
            "calendar_name": self.slo.get("calendar_name"),
            "served_at": iso(self.served_at),
            "cause": self.cause,
            "detail": self.detail,
            "readiness_state": self.readiness_state,
            "readiness_summary": self.readiness_summary,
            "minutes_late": self.minutes_late,
            "minutes_left": self.minutes_left,
            "breach": self.breach,
        }


def _minutes(earlier: Optional[datetime], later: Optional[datetime]) -> Optional[int]:
    if earlier is None or later is None:
        return None
    return max(0, int((later - earlier).total_seconds() // 60))


def _calendar_says_expected(db: Any, calendar_name: Optional[str],
                            business_date: date) -> tuple:
    """``(expected: bool | None, reason)`` -- None when the calendar could
    not be read (then the promise cannot be evaluated)."""
    if not calendar_name:
        return True, None
    try:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        spec = BusinessCalendarRepo(db).get(str(calendar_name))
        if spec is None:
            return None, (f"calendar {calendar_name!r} is not an active "
                          f"business calendar")
        return bool(BusinessCalendar(spec).is_business_day(business_date)), None
    except Exception as exc:                          # noqa: BLE001
        return None, f"calendar {calendar_name!r} could not be read: {exc}"


def _cause_from_readiness(state: Optional[str]) -> str:
    if state == STATE_PARTIAL:
        return CAUSE_DATA_NOT_READY
    if state == STATE_UNKNOWN:
        return CAUSE_COULD_NOT_TELL
    if state == STATE_UNDECLARED:
        return CAUSE_NO_READINESS_DECLARED
    return CAUSE_NO_RUN


def slo_status(db: Any, report: dict, slo: dict, business_date: date, *,
               now: Optional[datetime] = None,
               readiness: Any = None) -> SloStatus:
    """The live status of one promise on one business date -- THE rule.

    ``readiness`` (optional) is a pre-evaluated Readiness for the date; when
    absent it is evaluated only where the answer needs it (before the
    promise, or a breach with no run to blame).
    """
    from core.feed.acting_time import compute_clocks
    at_now = now or datetime.now(timezone.utc)
    report_id = int(report["id"])
    out = SloStatus(report_id=report_id, business_date=business_date,
                    status=STATUS_COULD_NOT_EVALUATE, slo=dict(slo))

    expected, cal_reason = _calendar_says_expected(
        db, slo.get("calendar_name"), business_date)
    if expected is None:
        out.detail = cal_reason
        return out
    if not expected:
        out.status = STATUS_NOT_EXPECTED
        out.detail = (f"{business_date.isoformat()} is not a business day on "
                      f"calendar {slo.get('calendar_name')!r}")
        return out

    clocks = compute_clocks(business_date=business_date,
                            sla_local_time=slo.get("serve_by"),
                            sla_timezone=slo.get("timezone"))
    if clocks.sla_at is None:
        out.detail = (f"the promise {slo.get('serve_by')!r} in zone "
                      f"{slo.get('timezone')!r} cannot be resolved to an instant")
        return out
    out.sla_at = clocks.sla_at

    try:
        runs = db.list_report_readiness_runs(report_id, business_date) or []
    except Exception as exc:                          # noqa: BLE001
        out.detail = f"the readiness run ledger could not be read: {exc}"
        return out
    complete_runs = [r for r in runs if r.get("state") == STATE_COMPLETE
                     and r.get("evaluated_at_dt") is not None]
    met_run = next((r for r in complete_runs
                    if r["evaluated_at_dt"] <= clocks.sla_at), None)
    late_run = next((r for r in complete_runs
                     if r["evaluated_at_dt"] > clocks.sla_at), None)
    latest = runs[-1] if runs else None
    try:
        out.breach = db.get_report_slo_breach(report_id, business_date)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[report_slo] breach row for report %s @ %s unreadable: %s",
                       report_id, business_date, exc)

    if met_run is not None:
        out.status = STATUS_MET
        out.served_at = met_run["evaluated_at_dt"]
        out.readiness_state = STATE_COMPLETE
        out.readiness_summary = met_run.get("summary")
        out.detail = (f"served {out.served_at.strftime('%H:%M')} UTC, promise "
                      f"{clocks.sla_at.strftime('%H:%M')} UTC")
        return out

    if at_now <= clocks.sla_at:
        rd = readiness if readiness is not None else evaluate_readiness(
            db, report, business_date, now=at_now)
        out.readiness_state = rd.state
        out.readiness_summary = rd.summary
        out.minutes_left = _minutes(at_now, clocks.sla_at)
        if rd.state == STATE_COMPLETE:
            out.status = STATUS_READY
            out.detail = (f"data complete; no run served yet -- "
                          f"{out.minutes_left} min to the promise")
        else:
            out.status = STATUS_AT_RISK
            out.cause = _cause_from_readiness(rd.state)
            out.detail = f"{rd.summary} -- {out.minutes_left} min to the promise"
        return out

    # ── past the promise ─────────────────────────────────────────────────
    if late_run is not None:
        out.status = STATUS_SERVED_LATE
        out.served_at = late_run["evaluated_at_dt"]
        out.readiness_state = STATE_COMPLETE
        out.readiness_summary = late_run.get("summary")
        out.minutes_late = _minutes(clocks.sla_at, out.served_at)
        out.cause = (out.breach or {}).get("cause") or _cause_from_readiness(
            (latest or {}).get("state") if latest is not late_run else None)
        out.detail = (f"served {out.served_at.strftime('%H:%M')} UTC, "
                      f"{out.minutes_late} min after the promise")
        return out

    out.status = STATUS_BREACHED
    out.minutes_late = _minutes(clocks.sla_at, at_now)
    if latest is not None:
        out.readiness_state = latest.get("state")
        out.readiness_summary = latest.get("summary")
        out.cause = _cause_from_readiness(latest.get("state"))
        out.detail = (f"last run at {latest.get('evaluated_at')}: "
                      f"{latest.get('summary')}")
    else:
        rd = readiness if readiness is not None else evaluate_readiness(
            db, report, business_date, now=at_now)
        out.readiness_state = rd.state
        out.readiness_summary = rd.summary
        if rd.state == STATE_COMPLETE:
            out.cause = CAUSE_NO_RUN
            out.detail = f"no run for {business_date.isoformat()}; {rd.summary}"
        else:
            out.cause = _cause_from_readiness(rd.state)
            out.detail = f"no run for {business_date.isoformat()}; {rd.summary}"
    return out


# ── the pass: ledger + Netcool ───────────────────────────────────────────

def breach_summary(report: dict, st: SloStatus) -> str:
    name = report.get("name") or f"report {report.get('id')}"
    when = (f"{st.slo.get('serve_by')} {st.slo.get('timezone')}")
    cause = {
        CAUSE_DATA_NOT_READY: "data not ready",
        CAUSE_COULD_NOT_TELL: "readiness could not be told",
        CAUSE_NO_RUN: "no run served",
        CAUSE_NO_READINESS_DECLARED: "no readiness dependencies declared",
    }.get(st.cause or "", st.cause or "missed")
    text = (f"Report {name} missed its {when} promise for "
            f"{st.business_date.isoformat()}: {cause}")
    if st.readiness_summary:
        text += f" ({st.readiness_summary})"
    return text


def build_breach_event(report: dict, st: SloStatus, *, env: str):
    from core.feed import netcool as _nc
    from core.feed.acting_time import STAGE_BREACHED, STAGE_SEVERITY
    slug = report.get("slug")
    return _nc.build_event(
        env=env, alert_type=ALERT_TYPE, obj=report_object_key(st.report_id),
        business_date=st.business_date, severity=STAGE_SEVERITY[STAGE_BREACHED],
        summary=breach_summary(report, st), alert_group=_nc.GROUP_REPORT_SLO,
        clears_when=CLEARS_WHEN,
        url=(f"/finance-reports/{slug}" if slug else None))


def _key(report_id: int, business_date: date) -> tuple:
    return (int(report_id), business_date.isoformat())


def _dates_for(slo: dict, now: datetime, lookback_days: int) -> List[date]:
    """Today in the promise's zone and ``lookback_days`` before it -- a
    07:00 Singapore promise is already breached at 23:30 UTC the day
    before, so the anchor is the ZONE's date, not UTC's."""
    from core.feed.acting_time import _resolve_zone
    tz = _resolve_zone(slo.get("timezone"))
    anchor = (now.astimezone(tz) if tz is not None else now).date()
    return [anchor - timedelta(days=i) for i in range(max(0, int(lookback_days)), -1, -1)]


def evaluate_once(db: Any, *, now: Optional[datetime] = None, env: str = "",
                  enqueue_fn=None, session_factory=None,
                  lookback_days: int = 3) -> dict:
    """One pass over every ACTIVE promise: record breaches, raise the Netcool
    event for each open breach, clear what was served late.  Counters,
    never adjectives.  Fail-open per promise: one report whose promise
    cannot be read must not silence the rest."""
    from core.feed import netcool as _nc
    at_now = now or datetime.now(timezone.utc)
    counters = {"slos": 0, "evaluated": 0, "breached": 0, "raised": 0,
                "refused": 0, "lost": 0, "cleared": 0, "served_late": 0,
                "unevaluable": 0, "errors": 0}
    try:
        slos = db.list_report_slos(active_only=True) or []
    except Exception as exc:                          # noqa: BLE001
        logger.error("[report_slo] could not list the promises: %s", exc)
        counters["errors"] += 1
        return counters
    counters["slos"] = len(slos)
    live: Dict[Any, Any] = {}
    for slo in slos:
        report_id = int(slo["report_id"])
        try:
            report = db.get_business_report(report_id)
        except Exception as exc:                      # noqa: BLE001
            logger.error("[report_slo] report %s unreadable: %s", report_id, exc)
            counters["errors"] += 1
            continue
        if not report:
            logger.warning("[report_slo] promise on report %s, which no longer "
                           "exists -- nothing evaluated", report_id)
            counters["errors"] += 1
            continue
        for bd in _dates_for(slo, at_now, lookback_days):
            try:
                st = slo_status(db, report, slo, bd, now=at_now)
            except Exception as exc:                  # noqa: BLE001
                logger.error("[report_slo] report %s @ %s could not be evaluated: %s",
                             report_id, bd, exc)
                counters["errors"] += 1
                continue
            counters["evaluated"] += 1
            if st.status == STATUS_COULD_NOT_EVALUATE:
                counters["unevaluable"] += 1
                logger.error("[report_slo] report %s @ %s: promise COULD NOT BE "
                             "EVALUATED -- %s (never read as met)", report_id, bd,
                             st.detail)
                continue
            if st.status == STATUS_BREACHED:
                counters["breached"] += 1
                try:
                    event = build_breach_event(report, st, env=env)
                except _nc.NetcoolContractError as exc:
                    counters["refused"] += 1
                    logger.error("[report_slo] refusing to raise the breach of "
                                 "report %s @ %s: %s", report_id, bd, exc)
                    _record_breach(db, st, counters, identifier=None)
                    continue
                _record_breach(db, st, counters, identifier=event.identifier)
                qid = _nc.enqueue_event(session_factory, event, enqueue_fn=enqueue_fn)
                if qid is None:
                    counters["lost"] += 1
                elif qid == _nc.SUPPRESSED:
                    # a netcool_rules row chose not to send it now: asked
                    # again next pass, nothing to clear (2026-10-25)
                    counters["suppressed"] = counters.get("suppressed", 0) + 1
                else:
                    counters["raised"] += 1
                    live[_key(report_id, bd)] = event
            elif st.status == STATUS_SERVED_LATE:
                if st.breach and st.breach.get("state") == "open":
                    try:
                        db.mark_report_slo_breach_served(report_id, bd, st.served_at)
                        counters["served_late"] += 1
                    except Exception as exc:          # noqa: BLE001
                        logger.error("[report_slo] could not mark report %s @ %s "
                                     "served late: %s", report_id, bd, exc)
                        counters["errors"] += 1
    counters["cleared"] = _clear_resolved(live, enqueue_fn=enqueue_fn,
                                          session_factory=session_factory)
    return counters


def _record_breach(db: Any, st: SloStatus, counters: dict, *,
                   identifier: Optional[str]) -> None:
    if st.breach is not None:
        return
    try:
        st.breach = db.record_report_slo_breach({
            "report_id": st.report_id, "business_date": st.business_date,
            "sla_at": st.sla_at, "detected_at": datetime.now(timezone.utc),
            "cause": st.cause or CAUSE_NO_RUN, "detail": (st.detail or "")[:2000],
            "state": "open", "netcool_identifier": identifier,
        })
    except Exception as exc:                          # noqa: BLE001
        logger.error("[report_slo] could not record the breach of report %s @ %s: %s",
                     st.report_id, st.business_date, exc)
        counters["errors"] += 1


def _clear_resolved(live: Dict[Any, Any], *, enqueue_fn=None,
                    session_factory=None) -> int:
    """Send a resolution (Type 2, the same Identifier) for every breach we
    raised that is no longer firing -- FR-ALT-01, an alert with no clear
    is how a console fills with stale rows."""
    from core.feed import netcool as _nc
    cleared = 0
    with _lock:
        gone = [key for key in _raised if key not in live]
        for key in gone:
            event = _raised.pop(key)
            try:
                _nc.enqueue_event(session_factory, _nc.resolution_for(event),
                                  enqueue_fn=enqueue_fn)
                cleared += 1
                logger.info("[report_slo] cleared %s", key)
            except Exception as exc:                  # noqa: BLE001
                logger.error("[report_slo] could not clear %s (%s) -- the console "
                             "holds a stale alert until its ExpireTime", key, exc)
        _raised.update(live)
    return cleared


def open_alerts() -> int:
    with _lock:
        return len(_raised)


def reset_state_for_tests() -> None:
    with _lock:
        _raised.clear()


def surface_rows(db: Any, business_date: date, *, now: Optional[datetime] = None,
                 report_visible=None) -> List[dict]:
    """The Support Desk's "Reports at risk" rows for ONE business date:
    every active promise the reader may see, worst first, ``not_expected``
    left out.  ``report_visible(report) -> bool`` is the reader's view
    rule; None = every report."""
    at_now = now or datetime.now(timezone.utc)
    rows: List[dict] = []
    for slo in db.list_report_slos(active_only=True) or []:
        report = db.get_business_report(int(slo["report_id"]))
        if not report:
            continue
        if report_visible is not None and not report_visible(report):
            continue
        st = slo_status(db, report, slo, business_date, now=at_now)
        if st.status == STATUS_NOT_EXPECTED:
            continue
        row = st.to_dict()
        row.update({"report_name": report.get("name"),
                    "report_slug": report.get("slug"),
                    "owner": report.get("owner")})
        rows.append(row)
    rows.sort(key=lambda r: (STATUS_ORDER.index(r["status"])
                             if r["status"] in STATUS_ORDER else len(STATUS_ORDER),
                             -int(r.get("minutes_late") or 0),
                             str(r.get("report_name") or "")))
    return rows


__all__ = [
    "STATUS_BREACHED", "STATUS_AT_RISK", "STATUS_COULD_NOT_EVALUATE",
    "STATUS_SERVED_LATE", "STATUS_READY", "STATUS_MET", "STATUS_NOT_EXPECTED",
    "STATUS_ORDER", "CAUSE_DATA_NOT_READY", "CAUSE_COULD_NOT_TELL",
    "CAUSE_NO_RUN", "CAUSE_NO_READINESS_DECLARED", "ALERT_TYPE", "CLEARS_WHEN",
    "SloStatus", "report_object_key", "slo_status", "breach_summary",
    "build_breach_event", "evaluate_once", "open_alerts",
    "reset_state_for_tests", "surface_rows",
]
