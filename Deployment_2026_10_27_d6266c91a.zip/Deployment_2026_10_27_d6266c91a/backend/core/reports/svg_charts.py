"""Charts as inline SVG, in pure Python (2026-10-26).

The PDF of a canvas report draws each chart tile at its place on the page.
WeasyPrint renders SVG, and nothing else is installed for charts (no
matplotlib, no plotly -- and none is to be added), so this module draws the
viewer's chart kinds itself: bar, hbar, stacked_bar, line, area,
stacked_area, combo, pie, donut, scatter, bubble, treemap, funnel, radar,
waterfall.  Axes carry readable tick labels (compact numbers 1.2K / 3.4M), a
legend names the series, and the colours are the viewer's dataviz palette
(frontend/src/components/ReportChartView.tsx CHART_SERIES_COLORS /
CHART_OTHER_COLOR).  Every text is escaped.

``render_chart(kind, header, rows, width=, height=)`` -> an ``<svg>`` string.
``header[0]`` is the category (scatter / bubble: the point label); every
other column is one series.  Scatter rows are ``[label, x, y]``, bubble rows
``[label, x, y, size]``.  Marks carry a class a test can count:
``bar`` (bars, funnel steps, waterfall steps), ``point`` (line vertices,
scatter / bubble points), ``slice`` (pie / donut), ``area``, ``cell``
(treemap), ``radar``.
"""
from __future__ import annotations

import html
import math
from decimal import Decimal
from typing import Any, List, Optional, Sequence

PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
OTHER_COLOR = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
INK = "#52514e"
INK_MUTED = "#898781"
FONT = "Arial, Helvetica, sans-serif"
_CHAR_W = 4.6          # average glyph width at 8px, for label budgets
_MAX_LABEL = 16


def esc(s: Any) -> str:
    return html.escape(str(s), quote=True)


def num(v: Any) -> Optional[float]:
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float, Decimal)):
        f = float(v)
        return f if math.isfinite(f) else None
    try:
        f = float(str(v).replace(",", ""))
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def compact(v: float) -> str:
    """1234 -> 1.2K, 3_400_000 -> 3.4M, 0.5 -> 0.5, -1200 -> -1.2K."""
    if v is None:
        return ""
    a = abs(v)
    sign = "-" if v < 0 else ""
    for cut, suffix in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if a >= cut:
            s = f"{a / cut:.1f}".rstrip("0").rstrip(".")
            return f"{sign}{s}{suffix}"
    if a == int(a):
        return f"{sign}{int(a):,}"
    return f"{sign}{a:,.2f}".rstrip("0").rstrip(".")


def nice_ticks(lo: float, hi: float, n: int = 5) -> List[float]:
    """Round tick values covering [lo, hi] -- the 'nice numbers' rule."""
    if lo == hi:
        hi = lo + 1 if lo >= 0 else 0
        lo = min(lo, 0)
    span = hi - lo
    raw = span / max(1, n)
    mag = 10 ** math.floor(math.log10(raw)) if raw > 0 else 1
    for m in (1, 2, 2.5, 5, 10):
        step = m * mag
        if span / step <= n + 1:
            break
    start = math.floor(lo / step) * step
    ticks = []
    t = start
    while True:                         # the last tick is never below the maximum
        ticks.append(round(t, 10))
        if t >= hi - step * 1e-9 or len(ticks) > 50:
            break
        t += step
    return ticks


def _label(s: Any, max_len: int = _MAX_LABEL) -> str:
    t = "(no value)" if s is None else str(s)
    return t if len(t) <= max_len else t[: max_len - 1] + "…"


def _color(i: int, name: Any = None) -> str:
    if name in ("Everything else", "Other"):
        return OTHER_COLOR
    return PALETTE[i % len(PALETTE)]


def _svg_open(w: float, h: float) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:g}pt" height="{h:g}pt" viewBox="0 0 {w:g} {h:g}" '
            f'font-family="{FONT}" font-size="8" role="img">')


def _text(x: float, y: float, s: str, *, anchor: str = "start", fill: str = INK, size: float = 8,
          extra: str = "") -> str:
    return (f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" fill="{fill}" font-size="{size:g}"{extra}>'
            f'{esc(s)}</text>')


def _legend(names: Sequence[str], w: float, y: float, colors: Optional[Sequence[str]] = None) -> str:
    out = []
    x = 4.0
    for i, n in enumerate(names):
        c = colors[i] if colors else _color(i, n)
        lab = _label(n, 22)
        width = 10 + len(lab) * _CHAR_W + 8
        if x + width > w and i:
            out.append(_text(x, y + 7, "…", fill=INK_MUTED))
            break
        out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="7" height="7" fill="{c}" rx="1"/>')
        out.append(_text(x + 10, y + 7, lab, fill=INK))
        x += width
    return "".join(out)


def _empty(w: float, h: float, words: str) -> str:
    return _svg_open(w, h) + _text(w / 2, h / 2, words, anchor="middle", fill=INK_MUTED) + "</svg>"


#: a value this many times smaller than the largest goes on its own scale on
#: the right -- the viewer's rule (CanvasTileView: ``top / peak(k) > 20``)
RIGHT_AXIS_RATIO = 20.0


def render_chart(kind: str, header: Sequence[str], rows: Sequence[Sequence[Any]], *,
                 width: float, height: float, split: bool = False) -> str:
    """``split``: the columns after the category are the values of ONE field
    split by a series field (they share one scale), not several values."""
    w, h = max(60.0, float(width)), max(40.0, float(height))
    rows = [list(r) for r in rows or []]
    if not rows or len(header) < 2:
        return _empty(w, h, "No rows.")
    if kind in ("pie", "donut"):
        return _pie(header, rows, w, h, donut=(kind == "donut"))
    if kind == "scatter":
        return _scatter(header, rows, w, h, bubble=False)
    if kind == "bubble":
        return _scatter(header, rows, w, h, bubble=True)
    if kind == "treemap":
        return _treemap(header, rows, w, h)
    if kind == "funnel":
        return _funnel(header, rows, w, h)
    if kind == "waterfall":
        return _waterfall(header, rows, w, h)
    if kind == "radar":
        return _radar(header, rows, w, h)
    if kind == "hbar":
        return _hbar(header, rows, w, h)
    return _cartesian(kind, header, rows, w, h, split=split)


def _on_right(kind: str, vals, n_s: int, split: bool) -> set:
    """The series drawn against the right-hand scale, by the viewer's rule:
    a combo's lines always; otherwise, for several VALUES (not a split, not
    stacked), each value more than ``RIGHT_AXIS_RATIO`` times smaller than
    the largest."""
    if kind == "combo":
        return set(range(1, n_s))
    if split or n_s < 2 or kind in ("stacked_bar", "stacked_area"):
        return set()
    peak = [max([abs(r[i]) for r in vals if r[i] is not None] or [0.0]) for i in range(n_s)]
    top = max(peak)
    return {i for i in range(n_s) if top > 0 and peak[i] > 0 and top / peak[i] > RIGHT_AXIS_RATIO}


# ── cartesian: bar / stacked_bar / line / area / stacked_area / combo ──────────

def _series_matrix(header, rows) -> tuple:
    names = [str(x) for x in header[1:]]
    cats = [r[0] if r else None for r in rows]
    vals = [[num(r[i + 1]) if i + 1 < len(r) else None for i in range(len(names))] for r in rows]
    return names, cats, vals


def _frame(w: float, h: float, names: Sequence[str], ticks: Sequence[float], *, legend: bool) -> dict:
    legend_h = 12.0 if legend else 0.0
    left = 6.0 + max(len(compact(t)) for t in ticks) * _CHAR_W + 4
    top = 6.0 + legend_h
    bottom = h - 18.0
    right = w - 6.0
    return {"left": left, "top": top, "bottom": bottom, "right": right, "legend_h": legend_h,
            "pw": max(10.0, right - left), "ph": max(10.0, bottom - top)}


def _y_axis(f: dict, ticks: Sequence[float], lo: float, hi: float) -> str:
    out = []
    span = (hi - lo) or 1.0
    for t in ticks:
        y = f["bottom"] - (t - lo) / span * f["ph"]
        out.append(f'<line x1="{f["left"]:.1f}" x2="{f["right"]:.1f}" y1="{y:.1f}" y2="{y:.1f}" stroke="{GRID}" stroke-width="0.5"/>')
        out.append(_text(f["left"] - 3, y + 3, compact(t), anchor="end", fill=INK_MUTED))
    return "".join(out)


def _x_labels(f: dict, cats: Sequence[Any], slot_w: float) -> str:
    out = []
    n = len(cats)
    max_labels = max(1, int(f["pw"] / 42))
    step = max(1, math.ceil(n / max_labels))
    for i, c in enumerate(cats):
        if i % step:
            continue
        x = f["left"] + (i + 0.5) * slot_w
        out.append(_text(x, f["bottom"] + 10, _label(c, max(4, int(slot_w * step / _CHAR_W))), anchor="middle", fill=INK))
    return "".join(out)


def _cartesian(kind: str, header, rows, w: float, h: float, *, split: bool = False) -> str:
    names, cats, vals = _series_matrix(header, rows)
    stacked = kind in ("stacked_bar", "stacked_area")
    n_s = len(names)
    right_set = _on_right(kind, vals, n_s, split)
    if len(right_set) == n_s:                 # nothing left on the left: one scale
        right_set = set()
    left_set = [i for i in range(n_s) if i not in right_set]
    if stacked:
        pos = [sum(v for v in r if v is not None and v > 0) for r in vals]
        neg = [sum(v for v in r if v is not None and v < 0) for r in vals]
        lo, hi = min(0.0, min(neg) if neg else 0.0), max(0.0, max(pos) if pos else 0.0)
    else:
        flat = [r[i] for r in vals for i in left_set if r[i] is not None]
        lo, hi = min(0.0, min(flat) if flat else 0.0), max(0.0, max(flat) if flat else 0.0)
    ticks = nice_ticks(lo, hi)
    lo, hi = min(lo, ticks[0]), max(hi, ticks[-1])
    span = (hi - lo) or 1.0
    f = _frame(w, h, names, ticks, legend=(n_s > 1 or kind == "combo"))
    r_ticks: List[float] = []
    r_lo, r_span = 0.0, 1.0
    if right_set:
        rflat = [r[i] for r in vals for i in right_set if r[i] is not None]
        r_lo, r_hi = min(0.0, min(rflat) if rflat else 0.0), max(0.0, max(rflat) if rflat else 0.0)
        r_ticks = nice_ticks(r_lo, r_hi)
        r_lo, r_hi = min(r_lo, r_ticks[0]), max(r_hi, r_ticks[-1])
        r_span = (r_hi - r_lo) or 1.0
        f["right"] -= max(len(compact(t)) for t in r_ticks) * _CHAR_W + 6
        f["pw"] = max(10.0, f["right"] - f["left"])
    yof_left = lambda v: f["bottom"] - (v - lo) / span * f["ph"]           # noqa: E731
    yof_right = lambda v: f["bottom"] - (v - r_lo) / r_span * f["ph"]      # noqa: E731
    scale_of = lambda si: yof_right if si in right_set else yof_left      # noqa: E731
    yof = yof_left
    out = [_svg_open(w, h)]
    if f["legend_h"]:
        out.append(_legend([f"{n} (right)" if i in right_set else n for i, n in enumerate(names)], w, 2,
                           [_color(i, n) for i, n in enumerate(names)]))
    out.append(_y_axis(f, ticks, lo, hi))
    for t in r_ticks:
        out.append(_text(f["right"] + 3, yof_right(t) + 3, compact(t), fill=INK_MUTED))
    n_c = len(cats)
    slot = f["pw"] / max(1, n_c)
    zero_y = yof(0.0)
    out.append(f'<line x1="{f["left"]:.1f}" x2="{f["right"]:.1f}" y1="{zero_y:.1f}" y2="{zero_y:.1f}" stroke="{AXIS}" stroke-width="0.8"/>')
    bar_series = list(range(n_s)) if kind in ("bar", "stacked_bar") else ([0] if kind == "combo" else [])
    line_series = list(range(n_s)) if kind == "line" else (list(range(1, n_s)) if kind == "combo" else [])
    area_series = list(range(n_s)) if kind in ("area", "stacked_area") else []
    if bar_series:
        if stacked:
            bw = slot * 0.7
            for ci in range(n_c):
                up, down = 0.0, 0.0
                for si in bar_series:
                    v = vals[ci][si]
                    if v is None or v == 0:
                        continue
                    if v > 0:
                        y0, y1 = yof(up + v), yof(up)
                        up += v
                    else:
                        y0, y1 = yof(down), yof(down + v)
                        down += v
                    x = f["left"] + ci * slot + (slot - bw) / 2
                    out.append(f'<rect class="bar" x="{x:.1f}" y="{y0:.1f}" width="{bw:.1f}" height="{max(0.0, y1 - y0):.1f}" fill="{_color(si, names[si])}"><title>{esc(_label(cats[ci], 60))} · {esc(names[si])}: {esc(compact(v))}</title></rect>')
        else:
            nb = max(1, len(bar_series))
            bw = slot * 0.8 / nb
            for ci in range(n_c):
                for k, si in enumerate(bar_series):
                    v = vals[ci][si]
                    if v is None:
                        continue
                    x = f["left"] + ci * slot + slot * 0.1 + k * bw
                    sy, z = scale_of(si), scale_of(si)(0.0)
                    y0, y1 = (sy(v), z) if v >= 0 else (z, sy(v))
                    out.append(f'<rect class="bar" x="{x:.1f}" y="{y0:.1f}" width="{max(0.5, bw - 0.5):.1f}" height="{max(0.0, y1 - y0):.1f}" fill="{_color(si, names[si])}"><title>{esc(_label(cats[ci], 60))} · {esc(names[si])}: {esc(compact(v))}</title></rect>')
    if area_series:
        base = [0.0] * n_c
        for si in area_series:
            pts_top = []
            new_base = []
            for ci in range(n_c):
                v = vals[ci][si] or 0.0
                top_v = (base[ci] + v) if stacked else v
                new_base.append(top_v)
                pts_top.append((f["left"] + (ci + 0.5) * slot, scale_of(si)(top_v)))
            pts_bottom = [(f["left"] + (ci + 0.5) * slot, scale_of(si)(base[ci] if stacked else 0.0)) for ci in range(n_c)]
            poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts_top + pts_bottom[::-1])
            out.append(f'<polygon class="area" points="{poly}" fill="{_color(si, names[si])}" fill-opacity="0.55" stroke="{_color(si, names[si])}" stroke-width="1"/>')
            if stacked:
                base = new_base
    for si in line_series:
        sy = scale_of(si)
        pts = [(f["left"] + (ci + 0.5) * slot, sy(vals[ci][si])) for ci in range(n_c) if vals[ci][si] is not None]
        if len(pts) > 1:
            out.append(f'<polyline class="line" points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in pts)}" fill="none" stroke="{_color(si, names[si])}" stroke-width="1.5"/>')
        for ci in range(n_c):
            v = vals[ci][si]
            if v is None:
                continue
            out.append(f'<circle class="point" cx="{f["left"] + (ci + 0.5) * slot:.1f}" cy="{sy(v):.1f}" r="2" fill="{_color(si, names[si])}"><title>{esc(_label(cats[ci], 60))} · {esc(names[si])}: {esc(compact(v))}</title></circle>')
    out.append(_x_labels(f, cats, slot))
    out.append("</svg>")
    return "".join(out)


def _hbar(header, rows, w: float, h: float) -> str:
    names, cats, vals = _series_matrix(header, rows)
    n_s, n_c = len(names), len(cats)
    flat = [v for r in vals for v in r if v is not None]
    lo, hi = min(0.0, min(flat) if flat else 0.0), max(0.0, max(flat) if flat else 0.0)
    ticks = nice_ticks(lo, hi)
    lo, hi = min(lo, ticks[0]), max(hi, ticks[-1])
    span = (hi - lo) or 1.0
    legend_h = 12.0 if n_s > 1 else 0.0
    max_cat = min(_MAX_LABEL, max(len(_label(c)) for c in cats))
    left = 6.0 + max_cat * _CHAR_W + 4
    top, bottom, right = 6.0 + legend_h, h - 14.0, w - 6.0
    pw, ph = max(10.0, right - left), max(10.0, bottom - top)
    xof = lambda v: left + (v - lo) / span * pw        # noqa: E731
    out = [_svg_open(w, h)]
    if legend_h:
        out.append(_legend(names, w, 2))
    for t in ticks:
        x = xof(t)
        out.append(f'<line y1="{top:.1f}" y2="{bottom:.1f}" x1="{x:.1f}" x2="{x:.1f}" stroke="{GRID}" stroke-width="0.5"/>')
        out.append(_text(x, bottom + 9, compact(t), anchor="middle", fill=INK_MUTED))
    slot = ph / max(1, n_c)
    bw = slot * 0.8 / max(1, n_s)
    zero_x = xof(0.0)
    max_labels = max(1, int(ph / 10))
    step = max(1, math.ceil(n_c / max_labels))
    for ci in range(n_c):
        if ci % step == 0:
            out.append(_text(left - 3, top + (ci + 0.5) * slot + 3, _label(cats[ci]), anchor="end", fill=INK))
        for si in range(n_s):
            v = vals[ci][si]
            if v is None:
                continue
            y = top + ci * slot + slot * 0.1 + si * bw
            x0, x1 = (zero_x, xof(v)) if v >= 0 else (xof(v), zero_x)
            out.append(f'<rect class="bar" x="{x0:.1f}" y="{y:.1f}" width="{max(0.0, x1 - x0):.1f}" height="{max(0.5, bw - 0.5):.1f}" fill="{_color(si, names[si])}"><title>{esc(_label(cats[ci], 60))} · {esc(names[si])}: {esc(compact(v))}</title></rect>')
    out.append(f'<line y1="{top:.1f}" y2="{bottom:.1f}" x1="{zero_x:.1f}" x2="{zero_x:.1f}" stroke="{AXIS}" stroke-width="0.8"/>')
    out.append("</svg>")
    return "".join(out)


# ── pie / donut ────────────────────────────────────────────────────────────────

def _pie(header, rows, w: float, h: float, *, donut: bool) -> str:
    items = [(r[0], num(r[1]) if len(r) > 1 else None) for r in rows]
    items = [(c, v) for c, v in items if v is not None and v > 0]
    total = sum(v for _, v in items)
    if not items or total <= 0:
        return _empty(w, h, "Nothing to draw (no value above zero).")
    legend_w = min(w * 0.45, 24 + 22 * _CHAR_W + 30)
    cx = (w - legend_w) / 2
    cy = h / 2
    r = max(10.0, min(cx - 6, cy - 6))
    r_in = r * 0.55 if donut else 0.0
    out = [_svg_open(w, h)]
    a0 = -math.pi / 2
    for i, (c, v) in enumerate(items):
        a1 = a0 + 2 * math.pi * v / total
        large = 1 if (a1 - a0) > math.pi else 0
        x0, y0 = cx + r * math.cos(a0), cy + r * math.sin(a0)
        x1, y1 = cx + r * math.cos(a1), cy + r * math.sin(a1)
        if len(items) == 1:
            d = (f"M {cx + r:.2f} {cy:.2f} A {r:.2f} {r:.2f} 0 1 1 {cx - r:.2f} {cy:.2f} A {r:.2f} {r:.2f} 0 1 1 {cx + r:.2f} {cy:.2f} Z")
        elif donut:
            xi0, yi0 = cx + r_in * math.cos(a1), cy + r_in * math.sin(a1)
            xi1, yi1 = cx + r_in * math.cos(a0), cy + r_in * math.sin(a0)
            d = (f"M {x0:.2f} {y0:.2f} A {r:.2f} {r:.2f} 0 {large} 1 {x1:.2f} {y1:.2f} "
                 f"L {xi0:.2f} {yi0:.2f} A {r_in:.2f} {r_in:.2f} 0 {large} 0 {xi1:.2f} {yi1:.2f} Z")
        else:
            d = f"M {cx:.2f} {cy:.2f} L {x0:.2f} {y0:.2f} A {r:.2f} {r:.2f} 0 {large} 1 {x1:.2f} {y1:.2f} Z"
        pct = 100.0 * v / total
        out.append(f'<path class="slice" d="{d}" fill="{_color(i, c)}" stroke="#fff" stroke-width="0.8">'
                   f'<title>{esc(_label(c, 60))}: {esc(compact(v))} ({pct:.1f}%)</title></path>')
        if len(items) == 1 and donut:
            out.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r_in:.1f}" fill="#fff"/>')
        a0 = a1
    # legend at the right, the largest first as drawn, at most what fits
    lx = w - legend_w + 6
    max_rows = max(1, int((h - 8) / 11))
    y = 8.0
    for i, (c, v) in enumerate(items):
        if i >= max_rows:
            out.append(_text(lx + 10, y + 7, f"… {len(items) - i} more", fill=INK_MUTED))
            break
        out.append(f'<rect x="{lx:.1f}" y="{y:.1f}" width="7" height="7" fill="{_color(i, c)}" rx="1"/>')
        out.append(_text(lx + 10, y + 7, f"{_label(c, 18)} {100.0 * v / total:.0f}%", fill=INK))
        y += 11
    out.append("</svg>")
    return "".join(out)


# ── scatter / bubble ───────────────────────────────────────────────────────────

def _scatter(header, rows, w: float, h: float, *, bubble: bool) -> str:
    pts = []
    for r in rows:
        x, y = (num(r[1]) if len(r) > 1 else None), (num(r[2]) if len(r) > 2 else None)
        z = num(r[3]) if (bubble and len(r) > 3) else None
        if x is None or y is None:
            continue
        pts.append((r[0], x, y, z))
    if not pts:
        return _empty(w, h, "Nothing to draw (no point has both values).")
    xs, ys = [p[1] for p in pts], [p[2] for p in pts]
    xt = nice_ticks(min(xs), max(xs))
    yt = nice_ticks(min(ys), max(ys))
    xlo, xhi, ylo, yhi = xt[0], xt[-1], yt[0], yt[-1]
    f = _frame(w, h, [], yt, legend=False)
    f["bottom"] = h - 22.0
    f["top"] += 10.0                          # room for the "up" axis title above the plot
    f["ph"] = max(10.0, f["bottom"] - f["top"])
    xs_, ys_ = (xhi - xlo) or 1.0, (yhi - ylo) or 1.0
    xof = lambda v: f["left"] + (v - xlo) / xs_ * f["pw"]      # noqa: E731
    yof = lambda v: f["bottom"] - (v - ylo) / ys_ * f["ph"]    # noqa: E731
    out = [_svg_open(w, h), _y_axis(f, yt, ylo, yhi)]
    for t in xt:
        x = xof(t)
        out.append(f'<line y1="{f["top"]:.1f}" y2="{f["bottom"]:.1f}" x1="{x:.1f}" x2="{x:.1f}" stroke="{GRID}" stroke-width="0.5"/>')
        out.append(_text(x, f["bottom"] + 9, compact(t), anchor="middle", fill=INK_MUTED))
    out.append(_text(f["left"] + f["pw"] / 2, h - 2, f"{_label(header[1], 30)} →", anchor="middle", fill=INK_MUTED, size=7))
    out.append(_text(4, f["top"] - 5, f"↑ {_label(header[2], 30)}", fill=INK_MUTED, size=7))
    zmax = max((p[3] for p in pts if p[3] is not None), default=None)
    rmax = max(4.0, min(f["pw"], f["ph"]) / 8)
    label_points = len(pts) <= 30
    for i, (lab, x, y, z) in enumerate(pts):
        r = 3.0
        if bubble and z is not None and zmax and zmax > 0:
            r = max(2.0, rmax * math.sqrt(max(0.0, z) / zmax))
        out.append(f'<circle class="point" cx="{xof(x):.1f}" cy="{yof(y):.1f}" r="{r:.1f}" fill="{PALETTE[0]}" fill-opacity="{0.55 if bubble else 0.9}" stroke="{PALETTE[0]}" stroke-width="0.6">'
                   f'<title>{esc(_label(lab, 60))}: {esc(compact(x))}, {esc(compact(y))}{(", " + esc(compact(z))) if z is not None else ""}</title></circle>')
        if label_points:
            out.append(_text(xof(x) + r + 2, yof(y) + 3, _label(lab, 12), fill=INK, size=7))
    out.append("</svg>")
    return "".join(out)


# ── treemap (squarified) ───────────────────────────────────────────────────────

def _squarify(values: List[float], x: float, y: float, w: float, h: float) -> List[tuple]:
    """Bruls / Huizing / van Wijk squarified layout: (x, y, w, h) per value,
    values in the given (descending) order."""
    out: List[tuple] = []
    total = sum(values)
    if total <= 0 or w <= 0 or h <= 0:
        return [(x, y, 0.0, 0.0) for _ in values]
    scale = (w * h) / total
    areas = [v * scale for v in values]
    i = 0

    def worst(row: List[float], side: float) -> float:
        s = sum(row)
        if s <= 0 or side <= 0:
            return float("inf")
        mx, mn = max(row), min(row)
        return max((side * side * mx) / (s * s), (s * s) / (side * side * mn))

    while i < len(areas):
        horizontal = w >= h           # lay the row along the shorter side
        side = h if horizontal else w
        row = [areas[i]]
        j = i + 1
        while j < len(areas) and worst(row + [areas[j]], side) <= worst(row, side):
            row.append(areas[j])
            j += 1
        s = sum(row)
        if horizontal:
            rw = s / side if side else 0.0
            yy = y
            for a in row:
                rh = a / rw if rw else 0.0
                out.append((x, yy, rw, rh))
                yy += rh
            x += rw
            w -= rw
        else:
            rh = s / side if side else 0.0
            xx = x
            for a in row:
                rw = a / rh if rh else 0.0
                out.append((xx, y, rw, rh))
                xx += rw
            y += rh
            h -= rh
        i = j
    return out


def _treemap(header, rows, w: float, h: float) -> str:
    items = [(r[0], num(r[1]) if len(r) > 1 else None) for r in rows]
    items = sorted([(c, v) for c, v in items if v is not None and v > 0], key=lambda cv: -cv[1])
    if not items:
        return _empty(w, h, "Nothing to draw (no value above zero).")
    boxes = _squarify([v for _, v in items], 2.0, 2.0, w - 4.0, h - 4.0)
    total = sum(v for _, v in items)
    out = [_svg_open(w, h)]
    for i, ((c, v), (x, y, bw, bh)) in enumerate(zip(items, boxes)):
        out.append(f'<rect class="cell" x="{x:.1f}" y="{y:.1f}" width="{max(0.0, bw):.1f}" height="{max(0.0, bh):.1f}" fill="{_color(i, c)}" stroke="#fff" stroke-width="1">'
                   f'<title>{esc(_label(c, 60))}: {esc(compact(v))} ({100.0 * v / total:.1f}%)</title></rect>')
        if bw > 28 and bh > 14:
            out.append(_text(x + 3, y + 10, _label(c, max(3, int((bw - 6) / _CHAR_W))), fill="#fff", size=7.5))
            if bh > 24:
                out.append(_text(x + 3, y + 19, compact(v), fill="#fff", size=7))
    out.append("</svg>")
    return "".join(out)


# ── funnel ─────────────────────────────────────────────────────────────────────

def _funnel(header, rows, w: float, h: float) -> str:
    items = [(r[0], num(r[1]) if len(r) > 1 else None) for r in rows]
    items = [(c, v if v is not None and v > 0 else 0.0) for c, v in items]
    if not items or max(v for _, v in items) <= 0:
        return _empty(w, h, "Nothing to draw (no value above zero).")
    vmax = max(v for _, v in items)
    label_w = min(w * 0.35, _MAX_LABEL * _CHAR_W + 8)
    left, right = label_w + 4, w - 40
    pw = max(10.0, right - left)
    slot = (h - 8) / len(items)
    bh = max(2.0, slot * 0.78)
    out = [_svg_open(w, h)]
    for i, (c, v) in enumerate(items):
        bw = pw * v / vmax
        x = left + (pw - bw) / 2
        y = 4 + i * slot + (slot - bh) / 2
        out.append(f'<rect class="bar" x="{x:.1f}" y="{y:.1f}" width="{bw:.1f}" height="{bh:.1f}" fill="{_color(i, c)}" rx="1">'
                   f'<title>{esc(_label(c, 60))}: {esc(compact(v))}</title></rect>')
        out.append(_text(label_w, y + bh / 2 + 3, _label(c), anchor="end", fill=INK))
        out.append(_text(right + 4, y + bh / 2 + 3, compact(v), fill=INK_MUTED))
    out.append("</svg>")
    return "".join(out)


# ── waterfall ──────────────────────────────────────────────────────────────────

def waterfall_steps(rows: Sequence[Sequence[Any]]) -> List[dict]:
    """The floating-bar arithmetic one place, for the SVG and the Excel chart:
    per category ``{"label", "value", "base", "size", "end"}`` and a final
    "Total" step."""
    out: List[dict] = []
    cum = 0.0
    for r in rows:
        v = num(r[1]) if len(r) > 1 else None
        v = v or 0.0
        start, end = cum, cum + v
        out.append({"label": r[0], "value": v, "base": min(start, end), "size": abs(v), "end": end})
        cum = end
    out.append({"label": "Total", "value": cum, "base": min(0.0, cum), "size": abs(cum), "end": cum, "total": True})
    return out


def _waterfall(header, rows, w: float, h: float) -> str:
    steps = waterfall_steps(rows)
    ends = [0.0] + [s["end"] for s in steps]
    lo, hi = min(ends), max(ends)
    ticks = nice_ticks(min(lo, 0.0), max(hi, 0.0))
    lo, hi = ticks[0], ticks[-1]
    span = (hi - lo) or 1.0
    f = _frame(w, h, [], ticks, legend=True)
    yof = lambda v: f["bottom"] - (v - lo) / span * f["ph"]      # noqa: E731
    out = [_svg_open(w, h), _legend(["Up", "Down", "Total"], w, 2, colors=[PALETTE[2], PALETTE[7], OTHER_COLOR]),
           _y_axis(f, ticks, lo, hi)]
    n = len(steps)
    slot = f["pw"] / max(1, n)
    bw = slot * 0.7
    prev_end = None
    for i, s in enumerate(steps):
        x = f["left"] + i * slot + (slot - bw) / 2
        y0, y1 = yof(s["base"] + s["size"]), yof(s["base"])
        color = OTHER_COLOR if s.get("total") else (PALETTE[2] if s["value"] >= 0 else PALETTE[7])
        out.append(f'<rect class="bar" x="{x:.1f}" y="{y0:.1f}" width="{bw:.1f}" height="{max(0.5, y1 - y0):.1f}" fill="{color}">'
                   f'<title>{esc(_label(s["label"], 60))}: {esc(compact(s["value"]))}</title></rect>')
        if prev_end is not None:
            out.append(f'<line x1="{x - (slot - bw):.1f}" x2="{x:.1f}" y1="{yof(prev_end):.1f}" y2="{yof(prev_end):.1f}" stroke="{AXIS}" stroke-width="0.6" stroke-dasharray="2,2"/>')
        prev_end = s["end"]
    out.append(_x_labels(f, [s["label"] for s in steps], slot))
    out.append("</svg>")
    return "".join(out)


# ── radar ──────────────────────────────────────────────────────────────────────

def _radar(header, rows, w: float, h: float) -> str:
    names, cats, vals = _series_matrix(header, rows)
    n_c = len(cats)
    if n_c < 3:
        return _cartesian("bar", header, rows, w, h)      # a radar needs three axes; fewer draws as bars
    flat = [v for r in vals for v in r if v is not None]
    hi = max(0.0, max(flat) if flat else 0.0)
    ticks = nice_ticks(0.0, hi, 4)
    hi = ticks[-1] or 1.0
    legend_h = 12.0 if len(names) > 1 else 0.0
    cx, cy = w / 2, (h + legend_h) / 2
    r = max(10.0, min(w / 2 - _MAX_LABEL * _CHAR_W - 4, (h - legend_h) / 2 - 12))
    out = [_svg_open(w, h)]
    if legend_h:
        out.append(_legend(names, w, 2))
    ang = lambda i: -math.pi / 2 + 2 * math.pi * i / n_c        # noqa: E731
    for t in ticks[1:]:
        rr = r * t / hi
        ring = " ".join(f"{cx + rr * math.cos(ang(i)):.1f},{cy + rr * math.sin(ang(i)):.1f}" for i in range(n_c))
        out.append(f'<polygon points="{ring}" fill="none" stroke="{GRID}" stroke-width="0.5"/>')
        out.append(_text(cx + 2, cy - rr - 1, compact(t), fill=INK_MUTED, size=6.5))
    for i in range(n_c):
        x, y = cx + r * math.cos(ang(i)), cy + r * math.sin(ang(i))
        out.append(f'<line x1="{cx:.1f}" y1="{cy:.1f}" x2="{x:.1f}" y2="{y:.1f}" stroke="{AXIS}" stroke-width="0.5"/>')
        lx, ly = cx + (r + 6) * math.cos(ang(i)), cy + (r + 6) * math.sin(ang(i)) + 3
        anchor = "middle" if abs(math.cos(ang(i))) < 0.2 else ("start" if math.cos(ang(i)) > 0 else "end")
        out.append(_text(lx, ly, _label(cats[i], 12), anchor=anchor, fill=INK, size=7))
    for si, name in enumerate(names):
        pts = []
        for ci in range(n_c):
            v = max(0.0, vals[ci][si] or 0.0)
            rr = r * v / hi
            pts.append(f"{cx + rr * math.cos(ang(ci)):.1f},{cy + rr * math.sin(ang(ci)):.1f}")
        out.append(f'<polygon class="radar" points="{" ".join(pts)}" fill="{_color(si, name)}" fill-opacity="0.25" stroke="{_color(si, name)}" stroke-width="1.2"><title>{esc(name)}</title></polygon>')
    out.append("</svg>")
    return "".join(out)
