"""A canvas report's PDF: the same layout as the viewer (2026-10-26).

The owner: "even pdf is not getting same format along with charts n all".
The PDF page holds the canvas as the viewer draws it: the 12 grid columns
over the printable width, grid rows scaled to it, every tile at its
``layout`` {x, y, w, h}.  Tiles are absolutely positioned inside BANDS --
runs of grid rows no tile crosses -- and a band never splits across pages
(``page-break-inside: avoid``), so a chart is never cut in two.  Nothing is
ever scaled to fit: a tile that would cross a page edge moves down to start
the next page, and what lies under it in its columns moves with it
(``_paginate``), so every band fits one page at the viewer's proportions.
The first page keeps room for the report's title and notices.  The report's own rows
(the ``report`` tile) flow as the existing table at the report tile's place
in the row order: the bands above it come first, the table, then the bands
below -- so a report without canvas tiles keeps its byte-identical document.

Charts are inline SVG from ``core.reports.svg_charts`` (pure Python);
number / table / pivot / heatmap tiles are styled HTML; every text is
escaped.  ``canvas_pdf_parts`` returns ``{"above", "below", "css"}`` for
``_render_pdf_bytes``.
"""
from __future__ import annotations

import html
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from core.reports.canvas_export import CHART_KINDS
from core.reports.svg_charts import num, render_chart

#: a grid row's height as a share of a grid column's width (the viewer: 56 px
#: rows over ~90 px columns on a 1,200 px page)
ROW_TO_COL = 0.62
_MM = 72 / 25.4
#: the @page margins of ``_render_pdf_bytes`` (15mm 12mm 18mm 12mm)
_MARGIN_TOP, _MARGIN_SIDE, _MARGIN_BOTTOM = 15 * _MM, 12 * _MM, 18 * _MM
_PAGE_SIZES = {"a4": (595.3, 841.9), "a3": (841.9, 1190.6), "a5": (419.5, 595.3),
               "letter": (612.0, 792.0), "legal": (612.0, 1008.0), "tabloid": (792.0, 1224.0)}
_TITLE_PT, _NOTE_PT, _PAD_PT = 13.0, 9.0, 5.0
_HEAD_PT, _ROW_PT = 13.0, 11.0
_HEAT_LOW, _HEAT_HIGH = (255, 255, 255), (42, 120, 214)     # white -> the palette's first blue
#: the first page's title line and the row-limit notice above the canvas
_FIRST_PAGE_HEAD_PT = 80.0


def page_geometry(page_size: str) -> Tuple[float, float]:
    """(printable width, printable height) in pt for a WeasyPrint @page size."""
    words = str(page_size or "A4 landscape").lower().split()
    w, h = _PAGE_SIZES.get(words[0] if words else "a4", _PAGE_SIZES["a4"])
    if "landscape" in words:
        w, h = h, w
    return w - 2 * _MARGIN_SIDE, h - _MARGIN_TOP - _MARGIN_BOTTOM


def _esc(s: Any) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def _bands(boxes: List[dict]) -> List[Tuple[int, int]]:
    """Maximal runs of grid rows that no tile crosses: (y0, y1) half-open."""
    if not boxes:
        return []
    n = max(b["y"] + b["h"] for b in boxes)
    crossed = [False] * (n + 1)        # crossed[k]: some tile spans rows k-1 and k
    for b in boxes:
        for k in range(b["y"] + 1, b["y"] + b["h"]):
            crossed[k] = True
    out, start = [], 0
    for k in range(1, n + 1):
        if k == n or not crossed[k]:
            out.append((start, k))
            start = k
    return out


def _paginate(boxes: List[dict], page_rows: int, first_rows: int) -> None:
    """Move tiles down (never resize, never reorder) so none crosses a page
    edge.  Page edges sit at ``first_rows``, then every ``page_rows``.  A tile
    keeps its columns; it moves down by the most any tile above it in its
    columns was moved, and below whatever already fills them.  A tile taller
    than a page gets one page.  Rewrites ``y`` / ``h`` in place."""
    page_rows = max(1, page_rows)
    first_rows = max(1, min(first_rows, page_rows))

    def edge_after(row: int) -> int:
        if row < first_rows:
            return first_rows
        return first_rows + ((row - first_rows) // page_rows + 1) * page_rows

    push = [0] * 12
    sky = [0] * 12
    for b in sorted(boxes, key=lambda b: (b["y"], b["x"])):
        cols = range(b["x"], min(12, b["x"] + b["w"]))
        b["h"] = min(b["h"], page_rows)
        y = max(b["y"] + max(push[c] for c in cols), max(sky[c] for c in cols))
        edge = edge_after(y)
        if y + b["h"] > edge:                   # would cross a page edge: start the next page
            y = edge                            # (every page after the first holds page_rows >= h)
        for c in cols:
            push[c] = y - b["y"]
            sky[c] = y + b["h"]
        b["y"] = y


def canvas_pdf_parts(tables: Sequence[dict], report_layout: Optional[dict], *, page_size: str,
                     header_bg: str, header_text: str,
                     fmt_value: Callable[[str, Any, dict], str]) -> Dict[str, str]:
    """The HTML above and below the report's own table, and the CSS.
    ``fmt_value(column, value, col_fmt_map)`` renders a table cell the way
    the report's own cells are rendered (format patterns, bracket negatives)."""
    width, height = page_geometry(page_size)
    col_pt = width / 12.0
    row_pt = col_pt * ROW_TO_COL
    boxes = []
    for t in tables:
        lay = t.get("layout") or {}
        boxes.append({"x": int(lay.get("x", 0)), "y": int(lay.get("y", 0)), "w": max(1, int(lay.get("w", 12))),
                      "h": max(1, int(lay.get("h", 4))), "tile": t})
    report_box = None
    if report_layout:
        report_box = {"x": int(report_layout.get("x", 0)), "y": int(report_layout.get("y", 0)),
                      "w": max(1, int(report_layout.get("w", 12))), "h": max(1, int(report_layout.get("h", 6))), "tile": None}
    # the report's own rows flow as a table at the report tile's place: tiles
    # that start above its bottom edge come before the table, the rest after
    cut = (report_box["y"] + report_box["h"]) if report_box else None
    groups = ([b for b in boxes if b["y"] < cut], [b for b in boxes if b["y"] >= cut]) if report_box else (boxes, [])
    page_rows = max(1, int(height // row_pt))
    first_rows = max(1, int((height - _FIRST_PAGE_HEAD_PT) // row_pt))
    above: List[str] = []
    below: List[str] = []
    for group, target, first in ((groups[0], above, first_rows), (groups[1], below, page_rows)):
        if not group:
            continue
        top = min(b["y"] for b in group)
        for b in group:
            b["y"] -= top
        _paginate(group, page_rows, first)
        for y0, y1 in _bands(group):
            members = [b for b in group if y0 <= b["y"] < y1]
            if not members:
                continue
            band_rows = max(b["y"] + b["h"] for b in members) - y0
            target.append(f'<div class="cv-band" style="height:{band_rows * row_pt:.1f}pt">')
            for b in sorted(members, key=lambda b: (b["y"], b["x"])):
                target.append(_tile_html(b, y0, col_pt, row_pt, fmt_value))
            target.append("</div>")
    css = f"""
.cv-band {{ position: relative; page-break-inside: avoid; break-inside: avoid; margin: 0; }}
.cv-tile {{ position: absolute; overflow: hidden; border: 0.75pt solid #d6d5cf; border-radius: 3pt;
           padding: {_PAD_PT:g}pt; box-sizing: border-box; background: #fff; }}
.cv-title {{ font-size: 9pt; font-weight: bold; color: #222; margin: 0 0 2pt 0; white-space: nowrap; overflow: hidden; }}
.cv-note {{ font-size: 6.5pt; color: #7A3E00; margin: 0 0 2pt 0; white-space: nowrap; overflow: hidden; }}
.cv-number {{ font-weight: bold; line-height: 1.1; }}
.cv-label {{ font-size: 7.5pt; color: #777; }}
.cv-table {{ border-collapse: collapse; font-size: 7.5pt; table-layout: fixed; }}
.cv-table thead tr {{ background: #{header_bg}; color: #{header_text}; }}
.cv-table th {{ padding: 2pt 3pt; text-align: left; font-weight: bold; white-space: nowrap; overflow: hidden; }}
.cv-table td {{ padding: 1.5pt 3pt; border-bottom: 0.5pt solid #e6e6e6; white-space: nowrap; overflow: hidden; }}
.cv-table td.num {{ text-align: right; }}
.cv-table tbody tr:nth-child(even) {{ background: #f7f8fa; }}
.cv-cut {{ font-size: 6.5pt; color: #898781; margin-top: 2pt; }}
.cv-chart svg {{ display: block; }}
.cv-empty {{ font-size: 7.5pt; color: #898781; }}"""
    return {"above": "\n".join(above), "below": "\n".join(below), "css": css}


def _tile_html(b: dict, band_y0: int, col_pt: float, row_pt: float, fmt_value) -> str:
    t = b["tile"]
    left, top = b["x"] * col_pt + 1.5, (b["y"] - band_y0) * row_pt + 1.5
    w, h = b["w"] * col_pt - 3.0, b["h"] * row_pt - 3.0
    note = str(t.get("note") or "")
    inner_w = w - 2 * _PAD_PT
    inner_h = h - 2 * _PAD_PT - _TITLE_PT - (_NOTE_PT if note else 0.0)
    kind = str(t.get("kind") or "")
    parts = [f'<div class="cv-tile" style="left:{left:.1f}pt;top:{top:.1f}pt;width:{w:.1f}pt;height:{h:.1f}pt">',
             f'<div class="cv-title">{_esc(t.get("title"))}</div>']
    if note:
        parts.append(f'<div class="cv-note">{_esc(note)}</div>')
    rows = t.get("rows") or []
    header = [str(x) for x in (t.get("header") or [])]
    if kind == "number":
        parts.append(_number_html(t, header, rows, inner_w, inner_h, fmt_value))
    elif kind in CHART_KINDS:
        if rows:
            parts.append(f'<div class="cv-chart">{render_chart(kind, header, rows, width=max(40.0, inner_w), height=max(30.0, inner_h), split=bool((t.get("labels") or {}).get("series")))}</div>')
        else:
            parts.append(f'<div class="cv-empty">{_esc(note) if note else "No rows."}</div>')
    elif header:
        parts.append(_table_html(t, header, rows, inner_w, inner_h, fmt_value, heat=(kind == "heatmap")))
    else:
        parts.append(f'<div class="cv-empty">{_esc(note) if note else "No fields."}</div>')
    parts.append("</div>")
    return "".join(parts)


def _number_html(t: dict, header: List[str], rows: list, inner_w: float, inner_h: float, fmt_value) -> str:
    size = max(8.0, min(30.0, inner_h * 0.55))
    if not rows:
        return f'<div class="cv-number" style="font-size:{size:.0f}pt;color:#898781">No rows</div>'
    v = rows[0][-1] if rows[0] else None
    if v is None:
        body = '<span style="color:#898781">No value</span>'
    else:
        fmts = t.get("formats") or [""]
        body = fmt_value(header[-1] if header else "v", _plain(v), {header[-1] if header else "v": fmts[-1] or ""})
    label = ((t.get("labels") or {}).get("measures") or [""])[0] if isinstance(t.get("labels"), dict) else ""
    # the value fits the tile's WIDTH too (a bold digit is about 0.6 em wide)
    shown = html.unescape(re.sub(r"<[^>]+>", "", str(body)))
    size = max(6.0, min(size, inner_w / (0.62 * max(1, len(shown)))))
    return (f'<div class="cv-number" style="font-size:{size:.0f}pt">{body}</div>'
            + (f'<div class="cv-label">{_esc(label)}</div>' if label else ""))


def _plain(v: Any) -> Any:
    """A Decimal as a float for the report's own cell formatter (it formats
    int / float; everything else is shown as text)."""
    from decimal import Decimal
    return float(v) if isinstance(v, Decimal) else v


#: the table font (7.5 pt): an average character's width, a cell's padding
_CELL_CHAR_PT, _CELL_PAD_PT = 4.3, 7.0


def _table_html(t: dict, header: List[str], rows: list, inner_w: float, inner_h: float, fmt_value,
                *, heat: bool) -> str:
    """Each column is as wide as its widest shown value (a number is never cut
    short); as many columns as fit the tile are shown, the rest are named in
    the note; a heading too long for its column ends in an ellipsis."""
    formats = list(t.get("formats") or []) + [""] * len(header)
    n_fit = max(1, int((inner_h - _HEAD_PT) / _ROW_PT))
    cut_words = []
    if len(rows) > n_fit:
        n_fit = max(1, n_fit - 1)
        cut_words.append(f"Showing {n_fit:,} of {len(rows):,} rows.")
    shown = rows[:n_fit]
    fmt_map = {header[i]: (formats[i] or "") for i in range(len(header))}
    cells: List[List[Tuple[str, bool]]] = []
    for r in shown:
        line = []
        for i in range(len(header)):
            v = r[i] if i < len(r) else None
            is_num = (isinstance(v, (int, float)) and not isinstance(v, bool)) or _is_decimal(v)
            line.append((fmt_value(header[i], _plain(v), fmt_map) if is_num else ("" if v is None else str(v)), is_num))
        cells.append(line)

    def need(i: int) -> float:
        longest = max([len(_strip(c[i][0])) for c in cells] or [0])
        return max(longest, min(len(header[i]), 8), 3) * _CELL_CHAR_PT + _CELL_PAD_PT

    cols, used = [], 0.0
    for i in range(len(header)):
        w_i = need(i)
        if cols and used + w_i > inner_w:
            break
        cols.append((i, w_i))
        used += w_i
    if len(cols) < len(header):
        cut_words.append(f"{len(cols)} of {len(header)} columns fit this tile.")
    spare = max(0.0, inner_w - used) / max(1, len(cols))
    lo = hi = None
    if heat and shown:
        vals = [num(r[i]) for r in shown for i, _ in cols[1:] if i < len(r)]
        vals = [v for v in vals if v is not None]
        if vals:
            lo, hi = min(vals), max(vals)
    colgroup = "".join(f'<col style="width:{w_i + spare:.1f}pt">' for _, w_i in cols)
    head = "".join(f'<th title="{_esc(header[i])}">{_esc(_fit(header[i], w_i + spare))}</th>' for i, w_i in cols)
    body = []
    for r, line in zip(shown, cells):
        tds = []
        for i, w_i in cols:
            text, is_num = line[i]
            style = ""
            n = num(r[i]) if i < len(r) else None
            if heat and i > 0 and n is not None and lo is not None:
                style = f' style="background:{_heat_color(n, lo, hi)}"'
            cls = ' class="num"' if is_num else ""
            tds.append(f"<td{cls}{style}>{text if is_num else _esc(_fit(text, w_i + spare))}</td>")
        body.append("<tr>" + "".join(tds) + "</tr>")
    out = [f'<table class="cv-table"><colgroup>{colgroup}</colgroup><thead><tr>{head}</tr></thead>'
           f'<tbody>{"".join(body)}</tbody></table>']
    if not rows:
        out.append('<div class="cv-empty">No rows.</div>')
    if cut_words:
        out.append(f'<div class="cv-cut">{_esc(" ".join(cut_words))}</div>')
    return "".join(out)


def _strip(s: str) -> str:
    """The visible text of a formatted cell (the formatter may add markup)."""
    return html.unescape(re.sub(r"<[^>]+>", "", str(s)))


def _fit(text: str, width_pt: float) -> str:
    """A heading or a text cell shortened to its column, ending in an ellipsis."""
    room = max(2, int((width_pt - _CELL_PAD_PT) / _CELL_CHAR_PT))
    return text if len(text) <= room else text[: room - 1] + "…"


def _is_decimal(v: Any) -> bool:
    from decimal import Decimal
    return isinstance(v, Decimal)


def _heat_color(v: float, lo: float, hi: float) -> str:
    f = 0.0 if hi == lo else max(0.0, min(1.0, (v - lo) / (hi - lo)))
    r, g, b = (round(a + (b_ - a) * f) for a, b_ in zip(_HEAT_LOW, _HEAT_HIGH))
    return f"#{r:02x}{g:02x}{b:02x}"
