"""
Spark Connect Session Manager — per-user session pooling with credential isolation.

Enterprise design:
- Each user gets their own Spark session built with THEIR resolved S3 credentials.
  Sessions are NEVER shared across users (credential isolation).
- Credential rotation: a SHA-256 hash of the resolved credentials is stored per user.
  When the hash changes (STS token refresh, portal rotation), the stale session is
  closed and a new one is created with fresh credentials.
- Idle eviction: sessions unused for ``session_idle_timeout_minutes`` are closed by
  a background asyncio task that runs every 5 minutes.
- Per-user quota: enforced by ``max_sessions_per_user`` — raises SessionQuotaError
  when the user already has that many sessions concurrently.
- On-prem S3: the session is configured with ``fs.s3a.endpoint`` and
  ``fs.s3a.path.style.access=true`` when ``conn_config`` indicates on-prem.
- Graceful shutdown: ``shutdown_all()`` closes every session when the pod restarts.
- DB tracking (fail-open): session records are written to SparkConnectSession table
  for admin monitoring and cost attribution. If the DB write fails, the session still
  works — we never block query execution on DB availability.

All pyspark imports are deferred to ``get_or_create()`` and only executed when
``spark_connect.enabled = true``. The module is safe to import regardless of
whether pyspark is installed.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Module-level singletons — populated by init_spark_connect_manager() ──────
_cfg = None          # spark_connect config section
_db_manager = None   # DatabaseManager for session tracking
_broadcast_fn = None # coroutine callable: broadcast_fn(username, payload)

# In-memory session registry.  Protected by _lock.
# username → {"session": SparkSession, "creds_hash": str, "last_used": float}
_sessions: Dict[str, Dict[str, Any]] = {}
_lock: Optional[asyncio.Lock] = None

# Background cleanup task handle
_cleanup_task: Optional[asyncio.Task] = None

# Global count of active queries (cross-user) — enforces max_concurrent_queries
_active_query_count: int = 0
_query_count_lock: Optional[asyncio.Lock] = None


# ── Custom exceptions ─────────────────────────────────────────────────────────

class SessionQuotaError(RuntimeError):
    """User has reached max_sessions_per_user."""


class SparkConnectUnavailableError(RuntimeError):
    """Spark Connect server is not reachable or pyspark is not installed."""


# ── Public API ────────────────────────────────────────────────────────────────

def init_spark_connect_manager(cfg, db_manager, broadcast_fn) -> None:
    """Called once from main.py ``_startup()`` when spark_connect.enabled is True.

    Args:
        cfg: the ``spark_connect`` config section object
        db_manager: DatabaseManager for session DB tracking
        broadcast_fn: async callable(username, payload) for WS broadcasts
    """
    global _cfg, _db_manager, _broadcast_fn, _lock, _query_count_lock

    _cfg = cfg
    _db_manager = db_manager
    _broadcast_fn = broadcast_fn
    _lock = asyncio.Lock()
    _query_count_lock = asyncio.Lock()

    logger.info(
        "[spark_connect] Session manager initialised — server=%s threshold=%d rows",
        cfg.server_url, cfg.row_threshold,
    )


async def start_cleanup_task() -> None:
    """Start the background idle-session reaper. Call from startup."""
    global _cleanup_task
    _cleanup_task = asyncio.create_task(_evict_idle_sessions_loop())
    logger.info("[spark_connect] Idle-session cleanup task started")


async def shutdown_all() -> None:
    """Close every open Spark session. Called from main.py _shutdown()."""
    if _cleanup_task and not _cleanup_task.done():
        _cleanup_task.cancel()
        try:
            await _cleanup_task
        except asyncio.CancelledError:
            pass

    if not _sessions:
        return

    async with _lock:
        for username in list(_sessions.keys()):
            await _close_session_locked(username, reason="pod_shutdown")

    logger.info("[spark_connect] All sessions closed on shutdown")


async def get_or_create_session(username: str, conn_config: dict):
    """Return a live Spark session for ``username``, creating one if needed.

    The session is configured with credentials resolved from ``conn_config``
    via ``credential_resolver.py``.  If credentials have rotated since the
    last call the stale session is replaced.

    Raises:
        SessionQuotaError: user already has max_sessions_per_user sessions
        SparkConnectUnavailableError: pyspark not installed or server unreachable
    """
    _require_init()
    _require_pyspark()

    resolved_creds = _resolve_credentials(username, conn_config)
    new_hash = _credential_hash(resolved_creds)

    async with _lock:
        existing = _sessions.get(username)

        if existing is not None:
            if existing["creds_hash"] == new_hash:
                existing["last_used"] = time.monotonic()
                return existing["session"]
            # Credentials rotated — replace the stale session
            logger.info("[spark_connect] Credentials rotated for %s — replacing session", username)
            await _close_session_locked(username, reason="creds_rotated")

        # Quota check (count active sessions for this user)
        user_count = sum(1 for u in _sessions if u == username)
        if user_count >= _cfg.max_sessions_per_user:
            raise SessionQuotaError(
                f"Spark session quota reached for {username} "
                f"(max {_cfg.max_sessions_per_user})"
            )

        session = _create_spark_session(username, conn_config, resolved_creds)
        _sessions[username] = {
            "session":     session,
            "creds_hash":  new_hash,
            "last_used":   time.monotonic(),
            "created_at":  datetime.now(timezone.utc),
        }

    _persist_session_async(username, conn_config)
    logger.info("[spark_connect] Session created for %s (server=%s)", username, _cfg.server_url)
    return _sessions[username]["session"]


async def close_session(username: str, reason: str = "explicit") -> None:
    """Close and remove a user's session."""
    async with _lock:
        await _close_session_locked(username, reason=reason)


def get_session_stats() -> dict:
    """Return current session pool stats for admin API."""
    return {
        "active_sessions": len(_sessions),
        "active_queries":  _active_query_count,
        "users": [
            {
                "username":   u,
                "idle_seconds": int(time.monotonic() - s["last_used"]),
                "created_at": s["created_at"].isoformat(),
            }
            for u, s in _sessions.items()
        ],
    }


# ── Internal helpers ──────────────────────────────────────────────────────────

def is_initialised() -> bool:
    """True when ``init_spark_connect_manager`` has run on this pod.

    2026-09-01 -- callers were asking for a ``get_spark_connect_manager``
    factory that does not exist (this module is the manager; there is no
    object to hand out), so every availability check raised ImportError and
    answered "unavailable".  One predicate, so the question has a single
    answer everywhere it is asked.
    """
    return _cfg is not None and _lock is not None


def _require_init() -> None:
    if _cfg is None or _lock is None:
        raise SparkConnectUnavailableError(
            "Spark Connect session manager is not initialised. "
            "Check that spark_connect.enabled=true and the server started cleanly."
        )


def _require_pyspark() -> None:
    try:
        import pyspark  # noqa: F401
    except ImportError as exc:
        raise SparkConnectUnavailableError(
            "pyspark is not installed. Add pyspark>=3.5.0 to requirements.txt."
        ) from exc


def _resolve_credentials(username: str, conn_config: dict) -> dict:
    """Resolve S3 credentials via the shared credential resolver (fail-open)."""
    try:
        # 2026-09-01 -- there is no ``CredentialResolver`` class in
        # core.credential_resolver; the module is function-shaped and the
        # entry point is ``resolve_s3_credentials``.  The import raised
        # ImportError on every call, so this function ALWAYS took the
        # fallback below and Spark Connect ran on the static credentials in
        # conn_config -- per-user resolution (portal creds, assume-role,
        # boto3 profile) never happened on this path.
        from core.credential_resolver import resolve_s3_credentials
        return resolve_s3_credentials(conn_config, username=username) or {}
    except Exception as exc:
        logger.warning(
            "[spark_connect] Credential resolution failed for %s (%s) — "
            "using static credentials from conn_config",
            username, exc,
        )
        return {
            "aws_access_key_id":     conn_config.get("access_key", ""),
            "aws_secret_access_key": conn_config.get("secret_key", ""),
            "aws_session_token":     conn_config.get("session_token", ""),
        }


def _credential_hash(creds: dict) -> str:
    """SHA-256 of the resolved credential dict. Used for rotation detection."""
    serialised = json.dumps(creds, sort_keys=True, default=str)
    return hashlib.sha256(serialised.encode()).hexdigest()


def _create_spark_session(username: str, conn_config: dict, creds: dict):
    """Build and return a new Spark Connect session.

    Credentials are injected as Hadoop fs.s3a.* configs so Spark reads S3
    files directly without any local file downloads.

    For on-prem S3 (Dell ECS / MinIO), ``fs.s3a.endpoint`` and path-style
    access are also injected.  AWS S3 gets neither (breaks SigV4).
    """
    from pyspark.sql import SparkSession  # type: ignore[import]

    # BF-267: resolve the effective server URL — append ;token=… when a
    # token is configured.  Two sources, in priority order:
    #   1. spark_connect.system_account → look up the System Account by
    #      name, read its decrypted `token` field (or `password`).  This
    #      is the production pattern (token encrypted at rest in DB).
    #   2. spark_connect.token → literal string (dev/test).
    # The URL itself can already carry ;token=… ; we only append when the
    # user hasn't included one and a token source is configured.
    _server_url = _cfg.server_url
    _token = ""
    try:
        _sa_name = getattr(_cfg, "system_account", "") or ""
        if _sa_name and _db_manager is not None:
            _sa = _db_manager.get_system_account_by_name_raw(_sa_name)
            if _sa:
                # Phase 156 deep-dive R2 -- vault-backed SAs have
                # blank token + password columns by design.  Route
                # through Phase 154 qs_credentials before falling
                # back to literal config token.
                if _sa.get("use_vault") and not (_sa.get("token") or _sa.get("password")):
                    try:
                        from core.qs_credentials import resolve_system_account
                        _resolved = resolve_system_account(_sa_name, db_manager=_db_manager)
                        _token = (
                            _resolved.get("token")
                            or _resolved.get("password")
                            or ""
                        ).strip()
                    except Exception as _sr_exc:
                        logger.warning(
                            "[spark_connect] SA '%s' use_vault=True but "
                            "qs_credentials failed (%s) -- falling back "
                            "to literal config token", _sa_name, _sr_exc,
                        )
                else:
                    _token = (
                        _sa.get("token") or _sa.get("password") or ""
                    ).strip()
    except Exception as _sa_err:
        logger.debug("[spark_connect] system_account lookup failed (%s) — "
                     "falling back to literal token", _sa_err)
    if not _token:
        _token = (getattr(_cfg, "token", "") or "").strip()
    if _token and ";token=" not in _server_url:
        # URL grammar: sc://host:port[/;k1=v1;k2=v2]
        # If no params block exists yet, start one with `/;`; otherwise
        # append with `;`.  Keep existing params (use_ssl, user_id, etc.)
        if "/;" in _server_url:
            _server_url = _server_url + ";token=" + _token
        else:
            _server_url = _server_url.rstrip("/") + "/;token=" + _token

    builder = (
        SparkSession.builder
        .remote(_server_url)
        .appName(f"querystudio-{username}")
        .config("spark.sql.execution.arrow.pyspark.enabled", "true")
        .config("spark.sql.shuffle.partitions", "200")
        # Parquet other engines wrote is read by the REFERENCE row reader:
        # Spark 3.5's vectorized reader returned Trino-written
        # DELTA_LENGTH_BYTE_ARRAY strings cut and shifted, no error raised
        # (2026-10-14; the Spark job sets the same,
        # spark/jobs/generic_feed.py _read_parquet_with_the_reference_reader).
        .config("spark.sql.parquet.enableVectorizedReader", "false")
    )

    # S3 credentials
    if creds.get("aws_access_key_id"):
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.access.key", creds["aws_access_key_id"])
            .config("spark.hadoop.fs.s3a.secret.key", creds.get("aws_secret_access_key", ""))
        )
        if creds.get("aws_session_token"):
            builder = builder.config(
                "spark.hadoop.fs.s3a.session.token", creds["aws_session_token"]
            )

    # Endpoint / region / addressing style from THE resolver (core.s3_access)
    # -- the answers DuckDB signs with.  2026-10-26: this site stripped the
    # scheme itself (never VPCE-normalised), set no region, and called
    # every endpoint path-style on its own.
    for _k, _v in s3a_session_conf(conn_config).items():
        builder = builder.config(_k, _v)

    return builder.getOrCreate()


def s3a_session_conf(conn_config: dict) -> dict:
    """The ``spark.hadoop.fs.s3a.*`` entries a Spark Connect session gets
    for its ONE connection's endpoint, region and addressing style --
    decided by ``core.s3_access.resolve_s3_access`` (keys are set by the
    caller from the resolved credentials)."""
    from core.s3_access import resolve_s3_access
    access = resolve_s3_access(conn_config or {}, proxy=False)
    out: dict = {}
    if access.endpoint_host:
        out["spark.hadoop.fs.s3a.endpoint"] = access.endpoint_host
        out["spark.hadoop.fs.s3a.impl"] = "org.apache.hadoop.fs.s3a.S3AFileSystem"
        if not access.use_ssl:
            out["spark.hadoop.fs.s3a.connection.ssl.enabled"] = "false"
    if access.region:
        out["spark.hadoop.fs.s3a.endpoint.region"] = access.region
    out["spark.hadoop.fs.s3a.path.style.access"] = (
        "true" if access.url_style == "path" else "false")
    return out


async def _close_session_locked(username: str, reason: str) -> None:
    """Close and remove a session. Caller must hold _lock."""
    entry = _sessions.pop(username, None)
    if entry is None:
        return

    session = entry["session"]
    try:
        session.stop()
    except Exception as exc:
        logger.warning("[spark_connect] Error closing session for %s: %s", username, exc)

    logger.info("[spark_connect] Session closed for %s (reason=%s)", username, reason)
    _mark_session_closed_async(username, reason)


async def _evict_idle_sessions_loop() -> None:
    """Background task: every 5 minutes evict sessions idle past the timeout."""
    while True:
        try:
            await asyncio.sleep(300)  # 5-minute check interval
            await _evict_idle_sessions_once()
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("[spark_connect] Idle eviction error (will retry): %s", exc)


async def _evict_idle_sessions_once() -> None:
    if _cfg is None:
        return
    cutoff = time.monotonic() - (_cfg.session_idle_timeout_minutes * 60)
    async with _lock:
        for username, entry in list(_sessions.items()):
            if entry["last_used"] < cutoff:
                logger.info(
                    "[spark_connect] Evicting idle session for %s (idle %.0fs)",
                    username, time.monotonic() - entry["last_used"],
                )
                await _close_session_locked(username, reason="idle_timeout")


def _persist_session_async(username: str, conn_config: dict) -> None:
    """Fire-and-forget: write session record to DB for admin tracking."""
    try:
        if _db_manager is None:
            return
        _db_manager.create_spark_connect_session(
            username=username,
            connection_id=conn_config.get("id"),
            server_url=_cfg.server_url if _cfg else "",
        )
    except Exception as exc:
        logger.debug("[spark_connect] DB session tracking failed (non-critical): %s", exc)


def _mark_session_closed_async(username: str, reason: str) -> None:
    """Fire-and-forget: mark session closed in DB."""
    try:
        if _db_manager is None:
            return
        _db_manager.close_spark_connect_session(username=username, reason=reason)
    except Exception as exc:
        logger.debug("[spark_connect] DB session close tracking failed (non-critical): %s", exc)
