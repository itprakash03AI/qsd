"""Phase 145.2 — Iceberg-manifest-driven feed row estimate.

Why this exists
---------------
``feed.backend_router.pick_backend`` decides native vs spark_connect vs
airflow based on ``estimated_rows``.  Today the only sources for that
estimate are:

  - ``FeedConfig.last_row_count`` (set after the FIRST successful run)
  - ``FeedConfig.estimated_row_count`` (admin override, often unset)

For a feed that has never run, both are ``None`` → router falls back
to ``"native"`` → user discovers it should have been Spark the hard way
(10-min hang while DuckDB pre-downloads 5,000 parquet files through
the corporate proxy).

This helper closes the gap by reading the *already-populated* Iceberg
manifest cache (BF-296 / ice_file_cache) and summing ``record_count``
across the tables the feed SQL actually references.  Per-file
record_counts are emitted by Iceberg writers and surface as Avro
manifest fields — no S3 work, just cache reads.

Contract
--------
* Returns ``int`` when a useful estimate is available.
* Returns ``None`` when the estimate would be misleading:
  - Connection isn't iceberg
  - No referenced_tables hint (would have to scan all tables)
  - All referenced tables miss cache (background sync hasn't warmed yet)
  - Connection_id is missing
* Never raises — defensive guards on every cache read.
"""
from __future__ import annotations

import logging
from typing import Iterable, Optional

logger = logging.getLogger(__name__)


def estimate_rows_from_iceberg_cache(
    connection_id: Optional[int],
    registered_tables: Optional[Iterable[dict]],
    referenced_tables: Optional[Iterable[str]],
    partition_filters: Optional[list] = None,
) -> Optional[int]:
    """Sum ``record_count`` from cached Iceberg manifests for the SQL's
    referenced tables.

    Parameters
    ----------
    connection_id
        Connection FK used as part of the cache key.  Required.
    registered_tables
        List of ``{name, s3_prefix, format}`` dicts from the connection.
        Used to identify which tables are iceberg-formatted.
    referenced_tables
        Set / list of table names referenced in the feed SQL.  When
        ``None``, returns ``None`` (we won't sum across an entire
        connection — too noisy).
    partition_filters
        Optional ``[{col, op, val}, ...]`` list.  Used as part of the
        cache key so we hit the same filter-pruned entry the executor
        will read.  Pass ``None`` to look up the full-table estimate.

    Returns
    -------
    int | None
        Estimated row count, or ``None`` when an estimate isn't useful
        (see module docstring).
    """
    if not connection_id or not referenced_tables:
        return None
    if not registered_tables:
        return None

    # Build a fast lookup of iceberg-format tables on this connection.
    # We deliberately exclude parquet / csv / json — for non-iceberg
    # tables, manifest record_count isn't available and a per-file
    # parquet footer scan would defeat the "no S3 work" guarantee.
    iceberg_table_names = {
        t["name"]
        for t in registered_tables
        if isinstance(t, dict)
        and t.get("name")
        and (t.get("format") == "iceberg")
    }
    if not iceberg_table_names:
        return None

    refs = {r.lower() for r in referenced_tables}
    iceberg_refs = [
        t for t in iceberg_table_names if t.lower() in refs
    ]
    if not iceberg_refs:
        return None

    try:
        from core.iceberg_cache import ice_cache_key, ice_cache_get
    except Exception as exc:
        logger.debug("[feed_row_estimator] iceberg_cache unavailable: %s", exc)
        return None

    total = 0
    hit_count = 0
    for tname in iceberg_refs:
        try:
            key = ice_cache_key(connection_id, tname, partition_filters)
            entry = ice_cache_get(key)
            if not entry:
                # Try the no-filter form as a fallback — the background
                # sync (BF-299) populates the cache with filters=None, so
                # an exact-filter miss might still have an unfiltered
                # entry we can use as an upper bound.
                if partition_filters:
                    key_no_filter = ice_cache_key(connection_id, tname, None)
                    entry = ice_cache_get(key_no_filter)
            if entry:
                rc = entry.get("record_count") or 0
                if rc > 0:
                    total += int(rc)
                    hit_count += 1
        except Exception as exc:
            logger.debug(
                "[feed_row_estimator] cache lookup failed for table=%s: %s",
                tname, exc,
            )

    if hit_count == 0:
        logger.debug(
            "[feed_row_estimator] no cache hits for tables=%s — "
            "skipping estimate (sync may not have run yet)",
            iceberg_refs,
        )
        return None

    logger.info(
        "[feed_row_estimator] iceberg manifest estimate: %d rows across %d "
        "cached table(s) (referenced=%s)",
        total, hit_count, sorted(iceberg_refs),
    )
    return total
