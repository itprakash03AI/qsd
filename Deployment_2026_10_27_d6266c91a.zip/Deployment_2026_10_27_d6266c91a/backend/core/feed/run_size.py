"""How big is THIS run -- the size the lane router decides on (2026-10-13).

The owner: "more than 500k should go by default to the new-pods lane ... we
can't keep the QS worker busy".  The router's size tiers were right
(``feed_generation.auto_route_threshold_rows`` = 500,000 -> the per-run
Spark pods); the SIZE it was given was a guess from the PAST: the feed's
previous run.  A month-end feed's 9-row re-send made its next million-row
month end look like 9 rows and run on the shared worker.

The size of THIS run, in order (ONE answer, recorded on the execution):

1. ``estimated_row_count`` on the feed -- an admin's explicit setting wins;
2. the UPSTREAM CONTRACT for this run's business date
   (``core/feed/upstream_contract.py``): every governed side's message
   carries ROW_COUNT, so their sum IS the size -- used only when EVERY side
   arrived and reported a count (a partial sum would under-route);
3. the previous run's row count (``last_row_count``);
4. None -- the caller's further estimators (the Iceberg manifest), then the
   router's "no estimate" rule.

The contract resolved here is kept on the feed config (``_upstream_contract``
with the business date it was read for), so the run's certification reads
the SAME resolution the router sized it by -- never a second read that a
message arriving in between could change.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, Dict, Mapping, Optional

logger = logging.getLogger(__name__)

CONTRACT_BD_KEY = "_upstream_contract_bd"


def run_business_date(feed_config: Mapping[str, Any], exec_record: Optional[Mapping[str, Any]] = None
                      ) -> Optional[date]:
    """The bound run's business date, else the execution row's; None."""
    raw = ((feed_config.get("_feed_run") or {}).get("business_date")
           or (exec_record or {}).get("business_date"))
    if not raw:
        return None
    try:
        return raw if isinstance(raw, date) and not isinstance(raw, datetime) \
            else date.fromisoformat(str(raw)[:10])
    except ValueError:
        return None


def contract_rows(contracts: Optional[Mapping[str, Any]]) -> Optional[int]:
    """The sum of every governed side's reported ROW_COUNT -- or None when
    the contract is unreadable, has no side, or ANY side has not arrived or
    reported no count."""
    if not contracts or "_unreadable" in contracts:
        return None
    sides = [c for c in contracts.values() if isinstance(c, Mapping)]
    if not sides:
        return None
    total = 0
    for c in sides:
        if c.get("status") != "arrived" or c.get("expected_rows") is None:
            return None
        total += int(c["expected_rows"])
    return total


def width_weighted_rows(rows: Optional[int], columns: Optional[int], base_columns: int) -> Optional[int]:
    """The rows the size tiers compare (2026-10-26): a run WIDER than
    ``base_columns`` (``feed_generation.auto_route_width_base_columns``, 100)
    weighs ``rows x columns / base_columns`` -- 2M rows x 600 columns is the
    work of 12M rows of 100, and the shared server writes it cell by cell.
    Never LESS than the rows (a narrow run keeps the owner's "more than
    500k rows goes to the pods" rule); unknown width = the rows as they are."""
    if rows is None or not columns or base_columns <= 0 or columns <= base_columns:
        return rows
    return int(rows * columns / base_columns)


def estimate(db, feed_config: dict) -> Dict[str, Any]:
    """``{"rows": int | None, "source": str | None}`` for this run (see the
    module docstring).  Resolves -- and keeps -- the upstream contract."""
    admin = feed_config.get("estimated_row_count")
    if admin:
        return {"rows": int(admin), "source": "admin estimate on the feed"}
    bd = run_business_date(feed_config)
    if bd is not None and getattr(db, "list_etl_dependency_mappings", None) is not None:
        try:
            from core.feed import upstream_contract
            contracts = upstream_contract.resolve(db, feed_config, bd)
        except Exception as exc:                       # noqa: BLE001 -- sized another way; certification says it
            logger.warning("[run_size] feed %s: upstream contract unreadable for sizing (%s)",
                           feed_config.get("id"), exc)
        else:
            feed_config["_upstream_contract"] = contracts
            feed_config[CONTRACT_BD_KEY] = bd.isoformat()
            rows = contract_rows(contracts)
            if rows is not None:
                return {"rows": rows, "source": f"upstream messages for {bd.isoformat()}"}
    last = feed_config.get("last_row_count")
    if last:
        return {"rows": int(last), "source": "previous run"}
    return {"rows": None, "source": None}
