"""ONE read plan per side, executed by any engine (2026-10-14).

Design record: ``docs/READ_PLAN_ALL_ENGINES_2026_10_14.html``.  The decision
of WHAT a side reads (which snapshot, which files, which partition types) is
made HERE, by QueryStudio's own planner calls, and serialised for the Spark
job as a ``"tables"`` side of THE existing plan (``core/feed/airflow_plan.py``,
plan 1.1).  The job registers each table as a view and runs the side's SQL --
converted from the dialect the connection DECLARES to Spark SQL -- over them.
It never decides on its own what to read.

Per table (a table the side's SQL reads, registered on its S3 connection):

* ``iceberg`` -- ``iceberg_reader.get_iceberg_data_files`` (the SAME planner
  call the native engine makes) pins the snapshot and names the metadata file
  it came from; the job loads THAT file at THAT snapshot through Iceberg's own
  reader, which applies position / equality deletes and evolves the schema by
  field id.  Proven on the rig's Spark image with no catalog: 400,036 rows x
  460 columns = Starburst.  The planned data/delete-file counts travel for
  the record.
* ``parquet`` (Hive-partitioned or plain) -- the table's files listed by
  Hive's rule (``s3_utilities.is_parquet_data_key``, the same rule Spark's
  reader applies); the job reads the table's base folder (a file list would
  blow the run Secret's 1 MiB at Hive scale) and FAILS when Spark's input
  file count differs from the planned count.  Partition column types are THE
  decision (``hive_partition_types.decide_partition_key_types``) over the
  complete listing, so Spark types them exactly as the native engine does.
  No data files at all is REFUSED (``scan_truncation.NoDataFilesRefusal``).

Credentials travel per BUCKET (``fs.s3a.bucket.<bucket>.*``, the artifact
store's proven shape) inside the run's Secret, so a cloud (AWS) and an
on-prem (MinIO) bucket are read in one session, each as its own connection.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

TABLES_KIND = "tables"


class ReadPlanRefused(ValueError):
    """The side cannot be planned for a detached engine: a table it reads is
    not registered on its connection, or a format no engine here reads."""


def _s3_client(conn_cfg: dict):
    from core.s3_storage import S3StorageHandler, build_s3_config
    return S3StorageHandler(build_s3_config(conn_cfg)).s3_client


def _identity(conn_cfg: dict) -> Dict[str, Any]:
    """The bucket's s3a identity: keys through THE credential chokepoint,
    endpoint / region / addressing style through THE access resolver
    (``core.s3_access``) -- the same answers DuckDB signs with.
    2026-10-26: this read ``region_name or region`` off the row (a saved
    Region that contradicts the endpoint reached the pod) and called every
    custom endpoint path-style on its own."""
    from core.credential_resolver import resolve_s3_for_consumer
    from core.s3_access import resolve_s3_access
    resolved = resolve_s3_for_consumer(dict(conn_cfg), "spark_read_plan",
                                       min_lifetime_seconds=600) or {}
    return resolve_s3_access(resolved or dict(conn_cfg), proxy=False).s3a_identity()


def tables_read(sql: str, dialect: str = "trino") -> List[str]:
    """The table names ``sql`` reads (lower case, as written: the registered
    names after the feed's table map)."""
    import sqlglot
    from sqlglot import exp
    tree = sqlglot.parse_one(sql.strip().rstrip(";"), dialect=dialect)
    ctes = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
    out: List[str] = []
    for t in tree.find_all(exp.Table):
        name = ".".join(p for p in (t.catalog, t.db, t.name) if p).lower()
        if name and name not in ctes and name not in out:
            out.append(name)
    return out


def _iceberg_columns(s3, bucket: str, key: str) -> Optional[int]:
    """The CURRENT schema's column count, from the exact metadata file the
    plan pins (one GET).  None = could not be read (said, never guessed)."""
    try:
        import gzip
        import json
        body = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
        if key.endswith(".gz.metadata.json") or body[:2] == bytes([0x1F, 0x8B]):
            body = gzip.decompress(body)
        meta = json.loads(body)
        sid = meta.get("current-schema-id")
        schemas = meta.get("schemas") or ([meta["schema"]] if meta.get("schema") else [])
        cur = next((s for s in schemas if s.get("schema-id") == sid), schemas[-1] if schemas else None)
        return len(cur.get("fields") or []) if cur else None
    except Exception as exc:                                  # noqa: BLE001
        logger.info("[read-plan] column count of s3://%s/%s not read: %s", bucket, key, exc)
        return None


def _parquet_columns(s3, uri: str) -> Optional[int]:
    """A data file's column count from its footer (two ranged GETs).  None =
    could not be read."""
    try:
        import io
        import struct
        import pyarrow.parquet as pq
        bucket, key = uri[len("s3://"):].split("/", 1) if uri.startswith("s3://") else ("", uri)
        tail = s3.get_object(Bucket=bucket, Key=key, Range="bytes=-8")["Body"].read()
        if len(tail) != 8 or tail[4:] != b"PAR1":
            return None
        n = struct.unpack("<I", tail[:4])[0]
        footer = s3.get_object(Bucket=bucket, Key=key, Range=f"bytes=-{n + 8}")["Body"].read()
        md = pq.read_metadata(io.BytesIO(b"PAR1" + footer))
        return int(md.num_columns)
    except Exception as exc:                                  # noqa: BLE001
        logger.info("[read-plan] column count of %s not read: %s", uri, exc)
        return None


def _plan_iceberg(s3, bucket: str, prefix: str, db) -> Dict[str, Any]:
    from core.iceberg_reader import get_iceberg_data_files
    meta: Dict[str, Any] = {}
    files = get_iceberg_data_files(s3, bucket, prefix, keys_only=True, _out_meta=meta,
                                   db_manager=db)
    key = meta.get("metadata_key")
    sid = meta.get("snapshot_id")
    if not key or not sid or str(sid) in ("None", ""):
        raise ReadPlanRefused(f"the Iceberg table at s3://{bucket}/{prefix} has no snapshot to "
                              f"pin (metadata {key!r}, snapshot {sid!r})")
    return {"layout": "iceberg",
            "location": f"s3a://{bucket}/{prefix.strip('/')}",
            "metadata_location": f"s3a://{bucket}/{key}",
            "snapshot_id": str(sid),
            "planned_data_files": len(files or []),
            "delete_files": len(meta.get("pos_delete_files") or []) + len(meta.get("eq_delete_files") or []),
            # the table's width: the pod is sized by it (core/spark_k8s/jdbc_queue_floor.py)
            "columns": _iceberg_columns(s3, bucket, key)}


def _plan_parquet(s3, bucket: str, prefix: str) -> Dict[str, Any]:
    from core.hive_partition_types import common_hive_keys, decide_partition_key_types
    from core.s3_utilities import list_s3_parquet_files
    from core.scan_truncation import NoDataFilesRefusal
    files = list(list_s3_parquet_files(s3, bucket, prefix) or [])
    if not files:
        raise NoDataFilesRefusal(f"no data files under s3://{bucket}/{prefix} -- the side is "
                                 f"refused rather than read as empty")
    keys = list(common_hive_keys(files))
    decided = decide_partition_key_types(keys, files, listing_complete=True) if keys else {}
    return {"layout": "parquet",
            "base_path": f"s3a://{bucket}/{prefix.strip('/')}",
            "planned_files": len(files),
            "partition_types": {k: v[0] for k, v in decided.items()},
            # data columns from one footer + the partition columns from the path
            "columns": (lambda n: n + len(decided) if n is not None else None)(
                _parquet_columns(s3, files[0]))}


def plan_tables_side(db, connection_id: int, sql: str, *, source_label: str = "",
                     feed_id: Any = None) -> Dict[str, Any]:
    """THE ``tables`` side for an S3 connection's SQL (module docstring)."""
    conn = db.get_connection_raw(int(connection_id)) or {}
    cfg = dict(conn.get("config") or {})
    bucket = cfg.get("bucket_name") or cfg.get("bucket") or ""
    if not bucket:
        raise ReadPlanRefused(f"connection {connection_id} names no bucket")
    from core.sql_dialect_translator import source_dialect_for, translate_for_engine
    read_as, _how = source_dialect_for(sql, cfg.get("sql_dialect"))
    registered = {str(t.get("name") or "").lower(): t
                  for t in (cfg.get("registered_tables") or []) if isinstance(t, dict)}
    s3 = _s3_client(cfg)
    tables: List[Dict[str, Any]] = []
    for name in tables_read(sql, read_as or "trino"):
        reg = registered.get(name)
        if reg is None:
            raise ReadPlanRefused(
                f"feed {feed_id}: the query reads '{name}', which is not a table registered on "
                f"connection {conn.get('name') or connection_id} -- register it, or map the "
                f"query's table to a registered one (query_params.table_map)")
        prefix = str(reg.get("s3_prefix") or "").strip("/") + "/"
        fmt = str(reg.get("format") or "parquet").lower()
        if fmt == "iceberg":
            entry = _plan_iceberg(s3, bucket, prefix, db)
        elif fmt == "parquet":
            entry = _plan_parquet(s3, bucket, prefix)
        else:
            raise ReadPlanRefused(f"table '{name}' is {fmt!r}; a detached engine reads "
                                  f"iceberg and parquet tables")
        entry["name"] = name
        tables.append(entry)
    spark_sql, tr = translate_for_engine(sql, cfg.get("sql_dialect"), "spark")
    logger.info("[read-plan] feed %s: %d table(s) on connection %s, SQL read as %s (%s) -> spark",
                feed_id, len(tables), connection_id, tr.get("from"), tr.get("how"))
    return {"kind": TABLES_KIND, "sql": spark_sql, "connection_id": int(connection_id),
            "source_label": source_label, "tables": tables,
            "storage": {bucket: _identity(cfg)},
            "sql_translation": dict(tr, to="spark")}


__all__ = ["TABLES_KIND", "ReadPlanRefused", "plan_tables_side", "tables_read"]
