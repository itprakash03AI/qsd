"""A run whose worker was killed is tried again a BOUNDED number of times
(2026-10-26).

The owner: "2 million rows, 600 columns -- restarted 10 times and never
completed".  Every road that frees a run its process never finished --
the pod's next process (``mixin_feeds.reap_runs_of_a_dead_process``) and the
heartbeat reaper (``reap_orphaned_feed_runs``) -- put it back on the queue,
and nothing counted: a run that kills its pod was claimed again by the next
process, killed it again, and was claimed again, for ever.  Each round cost
the pod's whole memory and every sibling run on it.

THE rule, in one place: ``feed_runs.retry_count`` counts the times a run was
put back after its worker was stopped; ``feed_generation.max_run_reclaims``
(1) is how many such second chances it gets.  A kill may be a sibling's
fault (the pod was over-full), so one retry is allowed; the next kill FAILS
the run for good, in plain words that say what to do.  A correctness gate
fails; it does not throttle.  A deliberate hand-back on a deploy
(``run_lifecycle.hand_back_on_exit``) is not a kill and is not counted.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

REQUEUED = "requeued"
FAILED = "failed"

#: the config key, on ``feed_generation``
LIMIT_KEY = "max_run_reclaims"
DEFAULT_LIMIT = 1


def reclaim_limit(cfg: Any = None) -> int:
    """How many times a run is put back on the queue after its worker was
    stopped before the next stop fails it (0 = never put back)."""
    if cfg is None:
        from core.config import feed_generation as cfg
    try:
        return max(0, int(getattr(cfg, LIMIT_KEY, DEFAULT_LIMIT)))
    except (TypeError, ValueError):
        return DEFAULT_LIMIT


def stopped_for_good_words(times: int) -> str:
    """What the run (and its last attempt) say when it is not tried again."""
    return (f"stopped for good: the worker running this feed was stopped {times} time(s) "
            "(restarted, or killed for memory) and nothing was delivered. It will not be "
            "tried again by itself. Run it on a Spark cluster (the feed's Execution engine), "
            "or make the query smaller, then run it again.")


def requeued_words(why: str, attempt: int, limit: int) -> str:
    return f"reclaimed: {why} -- it will run again (retry {attempt} of {limit})"


def apply_reclaim(run: Any, why: str, *, limit: Optional[int] = None,
                  now: Optional[datetime] = None) -> str:
    """Decide and WRITE what happens to a ``feed_runs`` row (an ORM row or
    anything with its attributes) whose worker was stopped: back on the queue
    (``REQUEUED``, ``retry_count`` + 1) while it has retries left, else
    ``FAILED`` for good with :func:`stopped_for_good_words`.  The caller
    commits."""
    limit = reclaim_limit() if limit is None else int(limit)
    now = now or datetime.now(timezone.utc)
    stopped = int(getattr(run, "retry_count", 0) or 0)
    if stopped >= limit:
        run.status = "failed"
        run.completed_at = now
        run.heartbeat_at = None
        run.claimed_by = None
        run.retry_count = stopped + 1
        run.error = stopped_for_good_words(stopped + 1)
        return FAILED
    run.status = "pending"
    run.started_at = None
    run.heartbeat_at = None
    run.claimed_by = None
    run.retry_count = stopped + 1
    run.error = requeued_words(why, stopped + 1, limit)
    return REQUEUED
