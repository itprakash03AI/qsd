"""A space at either end of a path, host or file name is refused at save
(2026-10-26, the owner: "I encounter file path issues ... a space appended at
the start").

``' /inbox'`` is not a folder anybody meant, and it fails hours later at the
delivery step with a message about a directory that "does not exist".  The
feed form trims these fields; this is the rule the server applies to every
road that saves a feed (the form, the API, templates, the SQL setup
function): the destination's text values, each delivery-chain hop's, and the
file / control-file name templates.  A SECRET value is never judged (a space
may be part of a password) -- the platform's one secret-key rule,
``secrets_at_rest.is_secret_key``.  Refused, never rewritten: the person sees
which field and fixes it.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional

#: The words a person reads for a field (anything else: the key itself).
LABELS = {
    "path": "Output folder", "remote_dir": "Remote folder", "host": "Host", "hostname": "Host",
    "username": "User", "user": "User", "bucket": "Bucket", "prefix": "Folder (prefix)",
    "table": "Table", "schema": "Schema", "region": "Region", "endpoint_url": "Endpoint",
    "output_filename_template": "File name", "control_file_template": "Control file name",
}


def _padded(v: Any) -> bool:
    return isinstance(v, str) and v != v.strip() and v.strip() != ""


def problems(feed: Mapping[str, Any], *, fields: Optional[Iterable[str]] = None) -> List[str]:
    """One plain sentence per padded value.  ``fields`` limits the check to
    the top-level fields a patch touches (an unrelated edit never fails on an
    old row)."""
    from core.secrets_at_rest import is_secret_key
    wanted = set(fields) if fields is not None else None
    out: List[str] = []

    def say(where: str, key: str, value: str) -> None:
        label = LABELS.get(key, key)
        side = "at the start" if value[:1].isspace() else "at the end"
        out.append(f"{where}{label} has a space {side} ({value!r}). Remove it.")

    def walk_config(where: str, cfg: Any) -> None:
        if not isinstance(cfg, Mapping):
            return
        for k, v in cfg.items():
            if is_secret_key(k):
                continue
            if _padded(v):
                say(where, str(k), v)

    if wanted is None or "destination_config" in wanted:
        walk_config("Where it goes: ", feed.get("destination_config"))
    if wanted is None or "delivery_chain" in wanted:
        for i, hop in enumerate(feed.get("delivery_chain") or [], start=1):
            if isinstance(hop, Mapping):
                walk_config(f"Delivery step {i}: ", hop.get("config") or hop.get("destination_config"))
    for key in ("output_filename_template", "control_file_template"):
        if (wanted is None or key in wanted) and _padded(feed.get(key)):
            say("The file: ", key, feed[key])
    return out


def refusal_detail(feed: Mapping[str, Any], *, fields: Optional[Iterable[str]] = None) -> Optional[Dict[str, Any]]:
    """The 422 detail, or None when nothing is padded."""
    found = problems(feed, fields=fields)
    if not found:
        return None
    return {"message": " ".join(found), "problems": found}
