"""Acting time — three clocks, kept apart (BRD §8).

The SLA is when the CONSUMER needs the file.  It is not when we need to act.
Acting time comes from knowing when each dependency normally arrives, and a
message that is late by its own standard is a signal HOURS before any SLA
arithmetic notices.

    expected arrival   "is this dependency late, by its own history?"
                       MEASURED — the arrival distribution per dependency,
                       per business-day type (core.feed.ledger)
    decision deadline  "is there still time for a skip to make the SLA?"
                       COMPUTED — sla_at - expected_runtime - safety
    SLA                "has the consumer been let down?"
                       DECLARED on the feed; a reporting fact, never an
                       action trigger

They fire in that order and are genuinely different events.  The first is
informational and often hours early.  The second is actionable and has a
countdown.  The third is a breach and is already too late.  Before this module
only the third existed (``sla_tracker`` marks ``sla_breached`` once ``sla_to``
has passed), which is why the system could only report what had already gone
wrong.

Worked example, and the reason the machinery earns its keep: a feed with a
06:00 SLA and a 40-minute runtime has a decision deadline around 05:20.  If
APAC_POSITIONS normally lands at 03:38 and it is 04:30 with nothing, something
is already wrong and there are FIFTY MINUTES of slack to use — time to call
the upstream team, who may fix it properly rather than the feed going out with
a skipped dependency.  Waiting for 05:20 converts a recoverable problem into a
forced choice; waiting for 06:00 converts it into an incident report.

Everything here is a PURE function over values.  The ledger read is the only
seam, and it is injected.
"""
from __future__ import annotations

import logging
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ── The ladder's rungs, in the order they fire ────────────────────────────

STAGE_OVERDUE = "overdue"                  # late by its OWN history
STAGE_DECISION_DUE = "decision_due"        # a skip can still make the SLA
STAGE_DEADLINE_PASSED = "deadline_passed"  # the feed WILL be late
STAGE_BREACHED = "breached"                # the consumer has been let down

#: Ordered worst-last, so a caller can compare severity without a lookup.
LADDER = (STAGE_OVERDUE, STAGE_DECISION_DUE, STAGE_DEADLINE_PASSED,
          STAGE_BREACHED)

#: Netcool severities (§12.3).  Declared here beside the stage that raises
#: them so the two can never drift apart in separate files.
STAGE_SEVERITY = {
    STAGE_OVERDUE:          2,   # warning
    STAGE_DECISION_DUE:     3,   # minor — a skip is still possible in time
    STAGE_DEADLINE_PASSED:  4,   # major — notify the consumer
    STAGE_BREACHED:         5,   # critical
}

#: Which percentile of the arrival distribution counts as "late".  p95 rather
#: than the max: one catastrophic 09:00 arrival must not move the expectation
#: for the next 90 days (FR-SLA-03).
DEFAULT_OVERDUE_PERCENTILE = "p95"

#: Lead time between "you must decide by" and "we tell you to decide".  An
#: alert that arrives AT the deadline is not actionable.
DEFAULT_DECISION_LEAD_SECONDS = 30 * 60

#: Safety margin between the last possible skip and the SLA, absorbing
#: dispatch, queueing and the gap between polls.
DEFAULT_SAFETY_SECONDS = 5 * 60


@dataclass(frozen=True)
class Clocks:
    """The three clocks for ONE feed on ONE business date.

    ``overdue_at`` is None when the dependency has no usable profile — that is
    a first-class answer, not a missing value: FR-SLA-04 requires falling back
    to the decision deadline alone rather than inventing a threshold from four
    data points and paging someone on the strength of it.
    """
    sla_at: datetime | None
    decision_deadline: datetime | None
    warn_at: datetime | None
    overdue_at: datetime | None
    expected_runtime_seconds: int | None
    runtime_source: str            # 'measured' | 'declared' | 'unknown'
    confidence: str                # 'high' | 'low' — of the arrival profile

    def to_dict(self) -> dict:
        iso = lambda d: d.isoformat() if d else None
        return {
            "sla_at": iso(self.sla_at),
            "decision_deadline": iso(self.decision_deadline),
            "warn_at": iso(self.warn_at),
            "overdue_at": iso(self.overdue_at),
            "expected_runtime_seconds": self.expected_runtime_seconds,
            "runtime_source": self.runtime_source,
            "confidence": self.confidence,
        }


@dataclass(frozen=True)
class Alert:
    """One rung of the ladder, ready to become a Netcool event (§12.2).

    ``blocked_feeds`` is the whole point of alerting on the DEPENDENCY rather
    than on each waiting feed: one overdue dependency blocking 34 feeds is ONE
    alert naming 34 feeds, not 34 alerts (FR-SLA-07, FR-DEP-19).  900 feeds on
    a bad morning is 900 alerts and the one that mattered is lost.
    """
    stage: str
    severity: int
    dependency_name: str
    business_date: date
    summary: str
    blocked_feeds: tuple = ()
    earliest_decision_deadline: datetime | None = None
    clears_when: str = ""

    def to_dict(self) -> dict:
        return {
            "stage": self.stage,
            "severity": self.severity,
            "dependency_name": self.dependency_name,
            "business_date": self.business_date.isoformat(),
            "summary": self.summary,
            "blocked_feeds": list(self.blocked_feeds),
            "earliest_decision_deadline": (
                self.earliest_decision_deadline.isoformat()
                if self.earliest_decision_deadline else None),
            "clears_when": self.clears_when,
        }


# ── Clock arithmetic ──────────────────────────────────────────────────────

def resolve_sla_at(business_date: date, sla_local_time: str | None,
                   tz_name: str | None) -> datetime | None:
    """Resolve a declared SLA to an absolute UTC instant.

    FR-SCH-06: an SLA is stored as a LOCAL TIME PLUS AN EXPLICIT ZONE and
    resolved per business date.  Never a bare hour — a feed serving APAC and
    EMEA has two answers, and DST moves one of them twice a year.

    Returns None when the feed declares no SLA; a feed without one still runs,
    it simply has no breach clock.
    """
    if not sla_local_time:
        return None
    parsed = _parse_local_time(sla_local_time)
    if parsed is None:
        logger.error(
            "[acting_time] SLA %r is not a HH:MM[:SS] local time — this feed "
            "has NO breach clock until it is fixed", sla_local_time)
        return None
    tz = _resolve_zone(tz_name)
    if tz is None:
        # Refuse to guess.  Assuming UTC for a feed whose consumer is in
        # Singapore silently moves the breach by eight hours.
        logger.error(
            "[acting_time] SLA %r declares no usable timezone (%r) — refusing "
            "to assume UTC, because assuming it silently moves the breach by "
            "the offset.  Declare the zone on the feed.",
            sla_local_time, tz_name)
        return None
    return datetime.combine(business_date, parsed, tzinfo=tz).astimezone(
        timezone.utc)


def validate_sla_declaration(sla_local_time: str | None,
                             tz_name: str | None) -> str | None:
    """Why a (local time, zone) pair could NOT become a breach clock, or
    None when it can (2026-09-28).  The authoring routes ask this BEFORE
    storing a promise: ``resolve_sla_at`` returns None for both faults and
    logs, which is right at evaluation time and wrong on a form -- an
    author who typed ``7am`` or ``London`` needs the fault named now, not
    a promise that never evaluates."""
    if not str(sla_local_time or "").strip():
        return "a local time is required, as HH:MM (e.g. 07:00)"
    if _parse_local_time(str(sla_local_time)) is None:
        return (f"{sla_local_time!r} is not a HH:MM[:SS] local time "
                f"(e.g. 07:00)")
    if not str(tz_name or "").strip():
        return ("a timezone is required (an IANA name such as Europe/London "
                "or Asia/Singapore); UTC is never assumed")
    if _resolve_zone(tz_name) is None:
        return (f"timezone {tz_name!r} is not an IANA zone name (e.g. "
                f"Europe/London, America/New_York, Asia/Singapore, UTC)")
    return None


#: The feed SLA fields the authoring routes validate, and what each means.
FEED_SLA_TIME_FIELDS = ("sla_from", "sla_to")


def feed_sla_field_problem(field_name: str, value: Any) -> str | None:
    """Why a FEED's ``sla_from`` / ``sla_to`` / ``sla_timezone`` value could
    not be evaluated by the SLA machinery, or None when it can (2026-10-03).

    A feed's SLA has TWO readers and both must be able to read what is
    stored: ``sla_tracker`` (the breach sweep -- its own regex on the legacy
    UTC path, ``resolve_sla_at`` when a zone is declared) and the alert
    ladder (``resolve_sla_at`` -> ``_parse_local_time``).  They disagree at
    the edges (``"05:7"`` parses in the ladder and is ``invalid_sla`` in the
    sweep), so a value is accepted only when BOTH read it.  Until this
    check the routes stored any string: ``"6pm"`` saved with 200 and the
    feed had no breach clock, said only in a log line at 04:19.

    ``None`` is "no SLA" (the column is nullable; a feed without one runs
    and simply has no clock) and ``sla_timezone=None`` is the legacy
    bare-UTC meaning both readers share.  An empty or blank string is NOT
    accepted as a spelling of "none": the sweep would read ``"  "`` as a
    declared, unparseable deadline.
    """
    if value is None:
        return None
    if field_name in FEED_SLA_TIME_FIELDS:
        return _feed_sla_time_problem(field_name, value)
    if field_name == "sla_timezone":
        return _feed_sla_zone_problem(value)
    raise ValueError(f"not a feed SLA field: {field_name!r}")


def _feed_sla_time_problem(field_name: str, value: Any) -> str | None:
    text = value.strip() if isinstance(value, str) else ""
    if not text:
        return (f"{field_name} must be a time of day as HH:MM (e.g. "
                f"06:00), or null for no SLA -- got {value!r}")
    from core.feed.sla_tracker import _SLA_TIME_RE
    if (_SLA_TIME_RE.match(text) is None
            or _parse_local_time(text.lstrip("+")) is None):
        return (f"{field_name}={value!r} is not a time of day the SLA "
                f"watcher can evaluate -- use HH:MM on the 24-hour "
                f"clock (00:00-23:59, e.g. 06:00), or null for no SLA")
    return None


def _feed_sla_zone_problem(value: Any) -> str | None:
    text = value.strip() if isinstance(value, str) else ""
    if not text:
        return ("sla_timezone must be an IANA zone name (e.g. "
                f"Europe/London), or null for UTC -- got {value!r}")
    try:
        from zoneinfo import ZoneInfo
        ZoneInfo(text)
    except Exception:
        return (f"sla_timezone={value!r} is not an IANA zone name the "
                f"SLA watcher can resolve (e.g. Europe/London, "
                f"America/New_York, Asia/Singapore, UTC)")
    return None


def compute_clocks(
    *,
    business_date: date,
    sla_local_time: str | None = None,
    sla_timezone: str | None = None,
    measured_runtime_seconds: int | None = None,
    declared_runtime_seconds: int | None = None,
    arrival_profile: Any = None,
    overdue_percentile: str = DEFAULT_OVERDUE_PERCENTILE,
    decision_lead_seconds: int = DEFAULT_DECISION_LEAD_SECONDS,
    safety_seconds: int = DEFAULT_SAFETY_SECONDS,
) -> Clocks:
    """Build the three clocks from measured history plus one declaration.

    ``measured_runtime_seconds`` wins over ``declared_runtime_seconds``
    (FR-SLA-01): the p95 of recent successful runs is derivable from run
    history, and a declared estimate goes stale silently.  Declared remains
    available as the override for a feed with no history yet.
    """
    runtime, source = _resolve_runtime(measured_runtime_seconds,
                                       declared_runtime_seconds)
    sla_at = resolve_sla_at(business_date, sla_local_time, sla_timezone)

    decision_deadline = None
    warn_at = None
    if sla_at is not None and runtime is not None:
        decision_deadline = sla_at - timedelta(
            seconds=int(runtime) + int(safety_seconds))
        warn_at = decision_deadline - timedelta(seconds=int(decision_lead_seconds))

    overdue_at, confidence = _overdue_from_profile(
        business_date, arrival_profile, overdue_percentile)

    return Clocks(
        sla_at=sla_at,
        decision_deadline=decision_deadline,
        warn_at=warn_at,
        overdue_at=overdue_at,
        expected_runtime_seconds=runtime,
        runtime_source=source,
        confidence=confidence,
    )


def _resolve_runtime(measured: int | None,
                     declared: int | None) -> tuple:
    for value, source in ((measured, "measured"), (declared, "declared")):
        if value is None:
            continue
        try:
            ivalue = int(value)
        except (TypeError, ValueError):
            logger.warning(
                "[acting_time] %s runtime %r is not an integer — ignoring",
                source, value)
            continue
        if ivalue > 0:
            return ivalue, source
        # 0 is not "instant"; it is "we do not know".  Treating it as a
        # runtime would put the decision deadline AT the SLA, which is the
        # one place it must never be.
        logger.warning(
            "[acting_time] %s runtime is %r — treating as unknown rather "
            "than as an instantaneous run", source, value)
    return None, "unknown"


def _overdue_from_profile(business_date: date, profile: Any,
                          percentile_key: str) -> tuple:
    """``(overdue_at, confidence)`` from an ArrivalProfile-shaped object.

    A low-confidence profile yields NO overdue clock.  That is FR-SLA-04 and
    it is deliberate: a new dependency with six observations has no usable
    expectation, and paging someone at 04:19 on the strength of four data
    points teaches them to ignore the alert.
    """
    if profile is None:
        return None, "low"
    confidence = str(getattr(profile, "confidence", "low") or "low")
    if confidence != "high":
        return None, confidence
    secs = getattr(profile, percentile_key, None)
    if secs is None:
        logger.warning(
            "[acting_time] arrival profile for %r has no %s — no overdue "
            "clock", getattr(profile, "dependency_name", "?"), percentile_key)
        return None, confidence
    return (datetime.combine(business_date, time(0, 0), tzinfo=timezone.utc)
            + timedelta(seconds=float(secs))), confidence


# ── The ladder ────────────────────────────────────────────────────────────

def evaluate_stage(now: datetime, clocks: Clocks, *, met: bool) -> str | None:
    """Which rung is live right now, or None.

    Worst-first, because the rungs overlap by construction: past the SLA a run
    is also past its decision deadline, and reporting the milder of the two
    would tell an operator to act when the time to act is gone.

    A met dependency raises nothing — every rung's clear condition is either
    "it arrived" or "the run completed", and FR-ALT-01 requires that every
    alert HAVE one.
    """
    if met:
        return None
    if clocks.sla_at is not None and now > clocks.sla_at:
        return STAGE_BREACHED
    if clocks.decision_deadline is not None and now > clocks.decision_deadline:
        return STAGE_DEADLINE_PASSED
    if clocks.warn_at is not None and now > clocks.warn_at:
        return STAGE_DECISION_DUE
    if clocks.overdue_at is not None and now > clocks.overdue_at:
        return STAGE_OVERDUE
    return None


def build_alert(stage: str, *, dependency_name: str, business_date: date,
                now: datetime, clocks: Clocks,
                blocked_feeds: Sequence[str] = (),
                earliest_deadline: datetime | None = None,
                skip_feed_hint: str = "") -> Alert:
    """Turn a live rung into the one line a human reads at 04:50.

    FR-SLA-06: the alert must NAME THE DECISION, not the condition.  Not "SLA
    at risk" but "APAC_POSITIONS not met; skip by 05:20 to still make 06:00".
    """
    feeds = tuple(blocked_feeds)
    deadline = earliest_deadline or clocks.decision_deadline
    if stage == STAGE_OVERDUE:
        late_by = _minutes_between(clocks.overdue_at, now)
        summary = (
            f"{dependency_name} is {late_by}m past its usual arrival "
            f"({DEFAULT_OVERDUE_PERCENTILE} "
            f"{_hhmm(clocks.overdue_at)}). {len(feeds)} feed(s) waiting."
            + (f" Earliest decision deadline {_hhmm(deadline)}." if deadline
               else " No decision deadline computed — no SLA or no runtime "
                    "history for the waiting feeds."))
        clears = "the dependency arrives"
    elif stage == STAGE_DECISION_DUE:
        target = skip_feed_hint or (feeds[0] if feeds else "the waiting feeds")
        summary = (
            f"Skip {dependency_name} by {_hhmm(deadline)} to still make the "
            f"{_hhmm(clocks.sla_at)} SLA for {target}.")
        clears = "the dependency arrives, or is skipped"
    elif stage == STAGE_DEADLINE_PASSED:
        # A DIFFERENT message to a different audience: past the deadline this
        # is no longer "act now", it is "tell the consumer".
        target = skip_feed_hint or (feeds[0] if feeds else "the waiting feeds")
        summary = (f"{target} will miss the {_hhmm(clocks.sla_at)} SLA "
                   f"({dependency_name} not met). Notify the consumer.")
        clears = "the run completes"
    else:
        target = skip_feed_hint or (feeds[0] if feeds else "the waiting feeds")
        summary = (f"{target} breached its {_hhmm(clocks.sla_at)} SLA "
                   f"({dependency_name} not met).")
        clears = "delivery completes"
    return Alert(
        stage=stage,
        severity=STAGE_SEVERITY[stage],
        dependency_name=dependency_name,
        business_date=business_date,
        summary=summary,
        blocked_feeds=feeds,
        earliest_decision_deadline=deadline,
        clears_when=clears,
    )


@dataclass
class BlockedDependency:
    """One unmet dependency and everything it is holding up."""
    dependency_name: str
    clocks: Clocks
    blocked_feeds: list = field(default_factory=list)
    earliest_deadline: datetime | None = None
    #: The feed to name in "skip X by 05:20 to still make 06:00".
    #: Added 2026-09-03: build_alert has always accepted it and this
    #: dataclass could not carry it, so the two ways of producing an
    #: alert differed — the watcher passed the hint and dropped
    #: earliest_deadline, this helper did the reverse.  Two drifted
    #: copies of one rule; now one rule with both facts.
    skip_feed_hint: str = ""
    # ── 2026-09-28: the PROFILE FACTS behind the clocks, for the screen ──
    # The alert only needs ``clocks``; a person needs to know WHY there is
    # no overdue clock -- six observations is a different answer from an
    # unreadable ledger, and neither is "not late".
    #: ``[{"feed_config_id", "feed_run_id", "feed_name"}, ...]`` -- the runs
    #: this dependency holds, with the names the screen shows.
    blocked_runs: list = field(default_factory=list)
    #: Observations in the arrival profile; None when the ledger could not
    #: be read (then ``profile_unavailable`` says why).
    observations: int | None = None
    #: The profile's p95, seconds of day, whatever its confidence -- the
    #: overdue CLOCK is only minted from a high-confidence profile, this is
    #: the raw fact.
    usual_by_seconds: float | None = None
    segmented: bool | None = None
    profile_unavailable: str | None = None


def alerts_for_dependencies(now: datetime, business_date: date,
                            blocked: Iterable[BlockedDependency]) -> list:
    """One alert PER DEPENDENCY, never per waiting feed.

    This is the anti-fatigue rule (FR-DEP-19) expressed as code rather than as
    guidance: on a bad morning the estate produces one alert per broken
    upstream, naming every feed it blocks, instead of hundreds that bury it.
    """
    out = []
    for item in blocked:
        # Per item, because one dependency whose clocks cannot be read
        # must not silence every other alert on the worst morning of the
        # year — the same reasoning as enqueue_alerts one layer down.
        try:
            stage = evaluate_stage(now, item.clocks, met=False)
        except Exception as exc:      # noqa: BLE001 — stated, never fatal
            logger.error("[acting_time] %s could not be evaluated: %s",
                         item.dependency_name, exc)
            continue
        if stage is None:
            continue
        out.append(build_alert(
            stage, dependency_name=item.dependency_name,
            business_date=business_date, now=now, clocks=item.clocks,
            blocked_feeds=item.blocked_feeds,
            earliest_deadline=item.earliest_deadline,
            skip_feed_hint=item.skip_feed_hint))
    # Worst first: an operator reads from the top.
    out.sort(key=lambda a: (-a.severity, a.dependency_name))
    return out


# ── small helpers ─────────────────────────────────────────────────────────

def _parse_local_time(value: str) -> time | None:
    parts = str(value).strip().split(":")
    if not (2 <= len(parts) <= 3):
        return None
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None
    while len(nums) < 3:
        nums.append(0)
    h, m, sec = nums
    if not (0 <= h <= 23 and 0 <= m <= 59 and 0 <= sec <= 59):
        return None
    return time(h, m, sec)


def _resolve_zone(tz_name: str | None):
    if not tz_name:
        return None
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(str(tz_name))
    except Exception as exc:
        logger.error("[acting_time] timezone %r is not resolvable (%s)",
                     tz_name, exc)
        return None


def _minutes_between(earlier: datetime | None,
                     later: datetime | None) -> int:
    if earlier is None or later is None:
        return 0
    return max(0, int((later - earlier).total_seconds() // 60))


def _hhmm(value: datetime | None) -> str:
    return value.strftime("%H:%M") if value else "?"


# ── The per-dependency computation, shared by the alert and the screen ────
#
# 2026-09-28.  ``sla_watcher.evaluate_once`` used to hold this loop inline
# -- profile read, config enrichment, tightest SLA, compute_clocks -- and
# hand the result ONLY to Netcool.  The Support Desk, the Today page's WAIT
# tooltip and the blocking route now read the same clocks.  A second copy
# of the loop would be a second answer to "when does this usually arrive",
# free to disagree with the alert an operator is reading on the console --
# so the loop lives here, ONCE, and the watcher applies its alert rule to
# what it returns.  ``tests/test_acting_time_on_the_desk_2026_09_28.py``
# pins that the alert path and the surface path see the SAME clocks.
#
# The DB reads (the blocking index, the feed configs, the runtime profile,
# the arrival ledger) are the seam; everything below them is still pure.

def _tightest_sla(feeds: list) -> tuple:
    """The earliest SLA among the feeds a dependency blocks, and its zone.

    The tightest one governs: alerting on the LOOSEST would tell an operator
    they have hours left while the strictest consumer is already at risk.

    The zone is ``feed_configs.sla_timezone`` (enriched by
    :func:`_enrich_with_config`) or UTC — the SAME rule ``sla_tracker``
    applies, ON PURPOSE (2026-09-03).  This lane used to fall back to the
    feed's SCHEDULE ``timezone`` while the tracker read the same ``sla_to``
    column as a bare UTC hour: two consumers, two meanings, wrong breach
    flags for every non-UTC feed.  The schedule zone is a different fact
    (when the cron fires) and never implies where the CONSUMER's deadline
    lives; only an explicit ``sla_timezone`` moves either consumer off UTC.
    """
    best = (None, None, None)
    for feed in feeds:
        sla = feed.get("sla_to") or feed.get("sla_at")
        if not sla:
            continue
        if best[0] is None or str(sla) < str(best[0]):
            best = (sla, feed.get("sla_timezone") or "UTC",
                    feed.get("name") or feed.get("feed_config_id"))
    return best


def _enrich_with_config(db, feeds: list, cache: dict, now: datetime) -> None:
    """Stamp each blocked run with its feed's SLA zone, declared runtime
    and MEASURED runtime (2026-09-03, FR-SLA-01/05/06).

    The run rows carry none of these: ``sla_timezone`` and
    ``expected_runtime_seconds`` live on ``feed_configs`` (real columns
    since 2026-09-03 — before that the declared fallback read a field on
    NO table, so the decision deadline was always None and only test
    doubles ever supplied it), and the measured runtime comes from the
    STORED profile (``core.feed.runtime_profile``), which
    ``ensure_fresh`` recomputes on its own schedule — never per tick
    (FR-SLA-05).

    Fail-soft per feed: an unreadable config or profile costs THAT
    feed's enrichment, never the pass.
    """
    from core.feed import runtime_profile as _rp
    for feed in feeds:
        try:
            fid = int(feed.get("feed_config_id"))
        except (TypeError, ValueError):
            continue
        if fid not in cache:
            try:
                cfg = db.get_feed_config(fid) or {}
            except Exception as exc:
                logger.debug("[acting_time] feed_config %s unreadable: %s",
                             fid, exc)
                cfg = {}
            measured = None
            profile = _rp.ensure_fresh(db, fid, now=now)   # never raises
            if profile:
                raw = profile.get("p95_seconds")
                try:
                    measured = int(raw) if raw is not None else None
                except (TypeError, ValueError):
                    measured = None
                if measured is not None and measured <= 0:
                    measured = None
            raw_tz = cfg.get("sla_timezone")
            cache[fid] = {
                # A plain non-empty string or nothing — anything else
                # falls back to UTC in _tightest_sla rather than feeding
                # garbage into the zone resolver.
                "sla_timezone": (raw_tz.strip()
                                 if isinstance(raw_tz, str)
                                 and raw_tz.strip() else None),
                "expected_runtime_seconds":
                    cfg.get("expected_runtime_seconds"),
                "measured_runtime_seconds": measured,
            }
        feed.update(cache[fid])


def _declared_runtime(feeds: list) -> int | None:
    """The LONGEST declared runtime among the blocked feeds.

    The decision deadline must leave room for the slowest of them: sizing it
    on the quickest would tell an operator a skip still makes the SLA when for
    one feed it no longer does.  Reads the value :func:`_enrich_with_config`
    stamped from the REAL ``feed_configs.expected_runtime_seconds`` column
    (2026-09-03) — run rows themselves never carried it.
    """
    values = [int(f["expected_runtime_seconds"]) for f in feeds
              if str(f.get("expected_runtime_seconds") or "").isdigit()]
    return max(values) if values else None


def _measured_runtime(feeds: list) -> int | None:
    """The LONGEST measured p95 runtime among the blocked feeds.

    Same longest-governs rule as :func:`_declared_runtime`, for the same
    reason.  The values come from the STORED runtime profile
    (:mod:`core.feed.runtime_profile`) via :func:`_enrich_with_config` —
    never recomputed here (FR-SLA-05).
    """
    values = [int(f["measured_runtime_seconds"]) for f in feeds
              if str(f.get("measured_runtime_seconds") or "").isdigit()]
    return max(values) if values else None


@dataclass
class BlockedClocks:
    """Everything one pass over the blocking index computed.

    ``index_error`` is set when the index itself could not be built -- then
    ``blocked`` is EMPTY FOR A REASON, and both consumers must say so (the
    watcher counts an error, the surface marks the section unavailable)
    rather than reading it as a quiet night.  ``failed`` lists the
    dependencies whose clocks could not be computed, with their runs, so a
    screen can show "could not tell" for exactly those instead of dropping
    them.
    """
    business_date: date
    now: datetime
    blocked: list = field(default_factory=list)
    failed: list = field(default_factory=list)
    waiting_runs: int = 0
    dependencies: int = 0
    errors: int = 0
    index_error: str | None = None


def _blocked_runs(runs: list) -> list:
    out = []
    for r in runs:
        try:
            fid = int(r.get("feed_config_id"))
        except (TypeError, ValueError):
            continue
        out.append({"feed_config_id": fid,
                    "feed_run_id": r.get("id"),
                    "feed_name": r.get("feed_name") or r.get("name")})
    return out


def clocks_for_blocked(db, business_date: date, now: datetime, *,
                       index: dict | None = None) -> BlockedClocks:
    """The three clocks for EVERY dependency blocking a run on ``business_date``.

    ONE function for the alert and the screen (2026-09-28).  ``index`` lets
    a caller that already built the blocking index (the blocking route)
    hand it in rather than building it twice; the watcher and the surface
    let it be built here.

    A dependency whose clocks cannot be computed lands in ``failed`` with
    the reason and its runs -- never silently dropped, because "not on the
    list" reads as "not late".  The blocking index failing altogether sets
    ``index_error`` and returns nothing else.
    """
    from core.feed.dependency_index import build_blocking_index

    result = BlockedClocks(business_date=business_date, now=now)
    if index is None:
        try:
            index = build_blocking_index(db, business_date=business_date)
        except Exception as exc:                      # noqa: BLE001
            result.index_error = f"{type(exc).__name__}: {exc}"
            return result
    if index.get("index_error"):
        # The index could not list the runs: nothing below is an answer.
        result.index_error = str(index["index_error"])
        result.errors += int(index.get("errors") or 0)
        return result
    result.waiting_runs = int(index.get("waiting_runs") or 0)
    result.errors += int(index.get("errors") or 0)
    by_dep = {name: entry["runs"]
              for name, entry in (index.get("by_dependency") or {}).items()}
    result.dependencies = len(by_dep)

    cfg_cache: dict = {}
    for dep_name, feeds in by_dep.items():
        try:
            profile = None
            profile_unavailable = None
            try:
                from core.feed.ledger import arrival_profile
                profile = arrival_profile(db, dep_name, None, now=now)
            except Exception as exc:                  # noqa: BLE001
                # No profile is a first-class answer (FR-SLA-04): the
                # decision deadline still works.  But "could not read the
                # ledger" and "six observations" are different answers, and
                # the screen must show which -- so the reason is KEPT.
                profile_unavailable = f"{type(exc).__name__}: {exc}"
                logger.warning("[acting_time] arrival profile for %s could "
                               "not be read: %s", dep_name, exc)
            _enrich_with_config(db, feeds, cfg_cache, now)
            sla_time, sla_tz, feed_name = _tightest_sla(feeds)
            clocks = compute_clocks(
                business_date=business_date, sla_local_time=sla_time,
                sla_timezone=sla_tz, arrival_profile=profile,
                measured_runtime_seconds=_measured_runtime(feeds),
                declared_runtime_seconds=_declared_runtime(feeds))
            result.blocked.append(BlockedDependency(
                dependency_name=dep_name,
                clocks=clocks,
                blocked_feeds=[str(f.get("feed_config_id")) for f in feeds],
                # None on purpose: these clocks were computed from the
                # TIGHTEST sla among the blocked feeds, so the decision
                # deadline already IS the earliest.  A separately derived
                # value would be a second way to compute the same number.
                earliest_deadline=None,
                skip_feed_hint=str(feed_name or ""),
                blocked_runs=_blocked_runs(feeds),
                observations=(int(profile.observations)
                              if profile is not None else None),
                usual_by_seconds=(getattr(profile, "p95", None)
                                  if profile is not None else None),
                segmented=(bool(profile.segmented)
                           if profile is not None else None),
                profile_unavailable=profile_unavailable))
        except Exception as exc:                      # noqa: BLE001
            logger.error("[acting_time] %s could not be evaluated: %s",
                         dep_name, exc)
            result.errors += 1
            result.failed.append({
                "dependency_name": dep_name,
                "error": f"{type(exc).__name__}: {exc}",
                "blocked_runs": _blocked_runs(feeds),
            })
    return result


# ── 2026-10-25: arrived / waiting / DELAYED, for a person ──────────────────
# The owner: "can be waiting, arrived or delayed (based on average time
# arrival) ... if no sla defined".  ONE rule, read by the dependency tracker,
# the board row and the task's cards (person_delays):
#   * the feed has an SLA -> expected by = its SLA deadline (THE SLA board's
#     answer, SlaTracker.deadline_for -- the same instant the SLA chip shows);
#   * no SLA -> expected by = the dependency's USUAL arrival time of day from
#     its own history (feed_generation.dependency_delay.usual_percentile; p50
#     = the typical arrival), on the RUN date (a business date's messages
#     arrive on its run date), once it has min_observations dates of history;
#   * neither -> no expectation: WAITING, never "delayed" by guess.
# Delayed = not arrived after expected by + grace_minutes.  The watcher's
# overdue ALERT (p95, high confidence, the ladder above) is a separate rule.

def delay_config() -> dict:
    try:
        from core.config import get as _get
        raw = _get("feed_generation", "dependency_delay", {}) or {}
    except Exception:                                 # noqa: BLE001 -- the declared defaults
        raw = {}
    pct = str(raw.get("usual_percentile") or "p50").lower()
    try:
        min_obs = max(1, int(raw.get("min_observations", 5)))
    except (TypeError, ValueError):
        min_obs = 5
    try:
        grace = max(0, int(raw.get("grace_minutes", 0)))
    except (TypeError, ValueError):
        grace = 0
    return {"usual_percentile": pct if pct in ("p50", "p90", "p95", "max") else "p50",
            "min_observations": min_obs, "grace_minutes": grace}


def _aware_dt(v: Any) -> datetime | None:
    if v is None or v == "":
        return None
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace("Z", "+00:00"))
        except ValueError:
            return None
    if not isinstance(v, datetime):
        return None
    return v if v.tzinfo else v.replace(tzinfo=timezone.utc)


def _as_day(v: Any) -> date | None:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v)[:10]) if v else None
    except ValueError:
        return None


def person_delays(db, wanted: dict, *, business_date: date, now: datetime | None = None,
                  cfg: dict | None = None) -> dict:
    """``{dependency: view}`` for dependencies NOT arrived yet.  ``wanted`` =
    ``{dependency: {"sla_deadline": <aware datetime | iso | None>, "run_date":
    <date | None>}}``.  The history is ONE read for all of them
    (``db.list_dependency_first_arrivals_bulk``).  A view: ``expected_by``
    (HH:MM UTC), ``expected_by_at``, ``expected_by_source`` (sla | usual |
    None), ``delayed``, ``minutes_delayed``.  Never raises: unreadable
    history = no usual time (waiting, never delayed by guess)."""
    from core.feed.ledger import compute_arrival_profile, seconds_of_day
    cfg = cfg or delay_config()
    now = now or datetime.now(timezone.utc)
    need_history = [n for n, w in wanted.items() if not _aware_dt((w or {}).get("sla_deadline"))]
    history: dict = {}
    if need_history:
        try:
            since = now.date() - timedelta(days=90)
            history = db.list_dependency_first_arrivals_bulk(need_history, since) or {}
        except Exception as exc:                      # noqa: BLE001 -- said in the log
            logger.warning("[acting_time] arrival history for %d dependencies unreadable: %s",
                           len(need_history), exc)
            history = {}
    out: dict = {}
    for name, w in wanted.items():
        w = w or {}
        expected, source = _aware_dt(w.get("sla_deadline")), None
        if expected is not None:
            source = "sla"
        else:
            rows = history.get(name) or []
            obs = [seconds_of_day(r["first_arrived_at"]) for r in rows]
            if len(obs) >= cfg["min_observations"]:
                prof = compute_arrival_profile(name, None, obs, segmented=False)
                secs = getattr(prof, cfg["usual_percentile"], None)
                day = _as_day(w.get("run_date")) or business_date
                if secs is not None:
                    expected = (datetime.combine(day, time(0, 0), tzinfo=timezone.utc)
                                + timedelta(seconds=float(secs)))
                    source = "usual"
        late_at = expected + timedelta(minutes=cfg["grace_minutes"]) if expected else None
        delayed = bool(late_at is not None and now > late_at)
        out[name] = {"expected_by": _hhmm(expected) if expected else None,
                     "expected_by_at": expected.isoformat() if expected else None,
                     "expected_by_source": source, "delayed": delayed,
                     "minutes_delayed": _minutes_between(late_at, now) if delayed else None}
    return out


def blocked_row(item: BlockedDependency, *, business_date: date,
                now: datetime) -> dict:
    """ONE dependency as the screen shows it -- the run surface's
    ``late_by_history`` section and the blocking route's ``clocks`` share
    this projection, so the two screens cannot word the same clock
    differently.

    Three honest states, told apart by the fields, never folded:

      * ``usual_by`` set -- a high-confidence profile minted an overdue
        clock; ``minutes_late`` is 0 or more;
      * ``usual_by`` null and ``observations`` a number -- no usable history
        yet (FR-SLA-04: the clock is not invented); ``minutes_late`` is
        null because unknown is not zero;
      * ``profile_unavailable`` set -- the ledger could not be read.

    ``stage`` is the ladder's own word (or null when no rung is live) and
    ``summary`` is the sentence the watcher sends to Netcool, from the same
    ``build_alert``.
    """
    c = item.clocks
    iso = lambda d: d.isoformat() if d else None    # noqa: E731
    stage_unavailable = None
    try:
        stage = evaluate_stage(now, c, met=False)
    except Exception as exc:                          # noqa: BLE001
        stage, stage_unavailable = None, f"{type(exc).__name__}: {exc}"
    summary = None
    if stage is not None:
        summary = build_alert(
            stage, dependency_name=item.dependency_name,
            business_date=business_date, now=now, clocks=c,
            blocked_feeds=item.blocked_feeds,
            earliest_deadline=item.earliest_deadline,
            skip_feed_hint=item.skip_feed_hint).summary
    blocked_ids = []
    for r in item.blocked_runs:
        try:
            blocked_ids.append(int(r["feed_config_id"]))
        except (KeyError, TypeError, ValueError):
            continue
    return {
        "dependency": item.dependency_name,
        "stage": stage,
        "severity": STAGE_SEVERITY.get(stage) if stage else None,
        "summary": summary,
        "stage_unavailable": stage_unavailable,
        "usual_by": _hhmm(c.overdue_at) if c.overdue_at else None,
        "usual_by_at": iso(c.overdue_at),
        "observations": item.observations,
        "confidence": c.confidence,
        "segmented": item.segmented,
        "profile_unavailable": item.profile_unavailable,
        # Unknown is not zero: only a minted clock can be late against.
        "minutes_late": (_minutes_between(c.overdue_at, now)
                         if c.overdue_at is not None else None),
        "decision_deadline": iso(c.decision_deadline),
        "warn_at": iso(c.warn_at),
        "sla_at": iso(c.sla_at),
        "sla_feed": item.skip_feed_hint or None,
        "expected_runtime_seconds": c.expected_runtime_seconds,
        "runtime_source": c.runtime_source,
        "blocked_feed_ids": blocked_ids,
        "blocked_feeds": list(item.blocked_runs),
        "blocked_count": len(blocked_ids),
        "clocks_unavailable": None,
    }


def failed_row(entry: dict) -> dict:
    """A dependency whose clocks could not be computed, kept ON the screen
    with the reason -- the same shape as :func:`blocked_row` so a renderer
    has one row type, every clock field null and ``clocks_unavailable``
    set."""
    runs = list(entry.get("blocked_runs") or [])
    ids = [int(r["feed_config_id"]) for r in runs
           if r.get("feed_config_id") is not None]
    return {
        "dependency": entry.get("dependency_name"),
        "stage": None, "severity": None, "summary": None,
        "stage_unavailable": None,
        "usual_by": None, "usual_by_at": None,
        "observations": None, "confidence": "low", "segmented": None,
        "profile_unavailable": None,
        "minutes_late": None,
        "decision_deadline": None, "warn_at": None, "sla_at": None,
        "sla_feed": None,
        "expected_runtime_seconds": None, "runtime_source": "unknown",
        "blocked_feed_ids": ids, "blocked_feeds": runs,
        "blocked_count": len(ids),
        "clocks_unavailable": str(entry.get("error") or "unknown error"),
    }


def worst_first_key(row: dict) -> tuple:
    """Sort key for the screen: the worst rung first, then the latest,
    then by name so the order is stable between polls."""
    return (-int(row.get("severity") or 0),
            -int(row.get("minutes_late") or 0),
            str(row.get("dependency") or ""))


def decision_deadline_for(db, business_date: date, dependency_name: str,
                          now: datetime) -> datetime | None:
    """The decision deadline this dependency is under RIGHT NOW, from the
    same computation the alert and the screen use -- stored with a skip so
    "was the skip made in time" is a fact in the ledger, not a
    reconstruction (2026-09-28).  None when the dependency is not blocking
    anything, or has no deadline (no SLA or no runtime among its feeds).
    Raises when the index could not be built; the caller decides how loud
    to be."""
    result = clocks_for_blocked(db, business_date, now)
    if result.index_error is not None:
        raise RuntimeError(result.index_error)
    for item in result.blocked:
        if item.dependency_name == dependency_name:
            return item.clocks.decision_deadline
    for entry in result.failed:
        if entry.get("dependency_name") == dependency_name:
            raise RuntimeError(str(entry.get("error")))
    return None
