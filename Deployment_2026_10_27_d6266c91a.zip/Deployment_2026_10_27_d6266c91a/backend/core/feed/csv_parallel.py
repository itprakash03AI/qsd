"""A large CSV written by several PROCESSES -- the same bytes one writes.

2026-10-13 (the owner, "very important"): the month-end feed read 1M x 460
cells straight from AWS S3 in 51 s and then spent 377 s writing the CSV on
ONE core.  The text of a CSV is per row, so the rows split cleanly: the
source's row groups are cut into ordered UNITS, each spawned worker renders
its unit with THE writer (``lane_output.render_block`` -- the writer every
lane uses) into a chunk file, and the parent writes the header and joins the
chunks in order.  Each cell takes the single-process path exactly: the parts
manifest's case renames and padding (``parts_manifest``), the integer-safe
frame (``renderers._batch_to_pandas``), ``itertuples``, ``render_block``.

Workers are fresh interpreters (``python -m core.feed.csv_parallel <job>``),
never forked and never a multiprocessing pool: the scheduler is a threaded
process with live database pools, and a spawned pool RE-IMPORTS the parent's
main module -- ``python -m querystudio scheduler`` runs ``main()`` at import,
so every worker would have started another scheduler.  How many: ``feed_generation.csv_parallel_workers``
(0 = the CPUs the pod may use, from its cgroup quota); below
``feed_generation.csv_parallel_min_rows`` one process writes, as before.
The cell budget (``feed_generation.max_cells_in_memory``) is SHARED by the
workers.  A worker that fails fails the render; no partial file is left.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Mapping, Optional

logger = logging.getLogger(__name__)

#: units per worker -- small enough to balance uneven row groups, few
#: enough that each start-up is paid once per many rows
UNITS_PER_WORKER = 4


def workers_for(rows: int) -> int:
    """How many processes write a file of ``rows`` rows (1 = one process)."""
    from core.config import feed_generation as _fg
    if rows < int(getattr(_fg, "csv_parallel_min_rows", 200_000)):
        return 1
    want = int(getattr(_fg, "csv_parallel_workers", 0))
    if want <= 0:
        from core.config import _usable_cpu_for_admission
        want = _usable_cpu_for_admission()
    return max(1, min(want, workers_memory_holds()))


def free_memory_bytes() -> Optional[int]:
    """The pod's memory not in use: cgroup limit - working set - margin
    (the margin the DuckDB headroom clamp keeps).  None = no cgroup limit
    to measure against (a dev box)."""
    from core.duckdb_resource_limits import (
        _HEADROOM_MARGIN_FRACTION, _HEADROOM_MARGIN_MIN_BYTES,
        _read_cgroup_memory_limit_bytes, _read_cgroup_working_set_bytes)
    limit = _read_cgroup_memory_limit_bytes()
    used = _read_cgroup_working_set_bytes()
    if not limit or limit <= 0 or used is None:
        return None
    margin = min(max(_HEADROOM_MARGIN_MIN_BYTES // 4, int(limit * _HEADROOM_MARGIN_FRACTION)),
                 _HEADROOM_MARGIN_MIN_BYTES)
    return max(0, int(limit) - int(used) - margin)


def workers_memory_holds() -> int:
    """How many worker processes the pod's FREE memory holds (2026-10-14).

    A throttle, never a gate: too little memory means one process (the
    caller writes the file itself, bounded by the batch budget) -- found
    live when four workers were started on a 2 GB scheduler already using
    1.7 GB and the kernel killed the pod, the run and its workers."""
    from core.config import feed_generation as _fg
    per = int(getattr(_fg, "csv_parallel_worker_mb", 512))
    if per <= 0:
        return 1 << 16
    try:
        free = free_memory_bytes()
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[csv-parallel] free memory unreadable (%s): one process", exc)
        return 1
    if free is None:
        return 1 << 16
    n = int(free // (per * 1024 * 1024))
    if n < 2:
        logger.info("[csv-parallel] one process: %.0f MB of the pod's memory is free, "
                    "a worker needs feed_generation.csv_parallel_worker_mb=%d",
                    free / 1024 ** 2, per)
    return max(1, n)


def _units(parquet_path: str, workers: int) -> Optional[List[Dict[str, Any]]]:
    """Ordered units ``{path, row_groups, renames, schema_b64}``, or None
    when the source cannot be split (one row group)."""
    import pyarrow.parquet as pq
    groups: List[tuple] = []          # (path, rg index, rows, renames, schema_b64)
    if os.path.isdir(parquet_path):
        from core.feed.parts_manifest import load_manifest
        manifest, _src = load_manifest(parquet_path)
        for part in manifest.parts:
            if part.location != "local":
                return None
            path = os.path.join(parquet_path, part.name)
            md = pq.read_metadata(path)
            for i in range(md.num_row_groups):
                groups.append((path, i, md.row_group(i).num_rows, part.renames, manifest.schema_b64))
    else:
        md = pq.read_metadata(parquet_path)
        for i in range(md.num_row_groups):
            groups.append((parquet_path, i, md.row_group(i).num_rows, None, None))
    if len(groups) < 2:
        return None
    total = sum(g[2] for g in groups)
    target = max(1, total // max(1, workers * UNITS_PER_WORKER))
    units: List[Dict[str, Any]] = []
    cur: Optional[Dict[str, Any]] = None
    for path, rg, n, ren, sch in groups:
        if cur is None or cur["path"] != path or cur["rows"] >= target:
            cur = {"path": path, "row_groups": [], "rows": 0, "renames": ren, "schema_b64": sch}
            units.append(cur)
        cur["row_groups"].append(rg)
        cur["rows"] += n
    return units


def _render_unit(unit: Dict[str, Any], dialect: Mapping[str, Any], batch_rows: int,
                 out_path: str, encoding: str) -> int:
    """A WORKER: one unit's rows, as CSV text, into ``out_path``."""
    import pyarrow.parquet as pq
    from core.feed.lane_output import render_block
    from core.feed.parts_manifest import _pad_batch_to_schema, _schema_from_b64
    from core.feed.renderers import _batch_to_pandas
    target = _schema_from_b64(unit["schema_b64"]) if unit.get("schema_b64") else None
    ren = unit.get("renames") or {}
    rows = 0
    pf = pq.ParquetFile(unit["path"])
    try:
        with open(out_path, "w", newline="", encoding=encoding) as fh:
            for batch in pf.iter_batches(batch_size=batch_rows, row_groups=unit["row_groups"]):
                if ren:
                    batch = batch.rename_columns([ren.get(c, c) for c in batch.schema.names])
                if target is not None:
                    batch = _pad_batch_to_schema(batch, target)
                if not batch.num_rows:
                    continue
                text, n = render_block(_batch_to_pandas(batch).itertuples(index=False, name=None),
                                       dialect)
                fh.write(text)
                rows += n
    finally:
        pf.close()
    return rows


def render_parallel(parquet_path: str, out_path: str, dialect: Mapping[str, Any],
                    chunk_size: int, columns: List[str]) -> Optional[int]:
    """Rows written, or None when this file is written by one process (the
    caller then does).  Raises when a worker fails."""
    from core.feed.lane_output import CsvRowWriter, open_csv, streamable_reason
    import pyarrow.parquet as pq
    why = streamable_reason(dialect)
    if why:
        logger.info("[csv-parallel] one process: %s", why)
        return None
    if os.path.isdir(parquet_path):
        from core.feed.parts_manifest import load_manifest
        total = int(load_manifest(parquet_path)[0].total_rows)
    else:
        total = int(pq.read_metadata(parquet_path).num_rows)
    workers = workers_for(total)
    if workers < 2:
        # said, every time: a silent "one process" hid a 1-CPU pod (2026-10-13)
        from core.config import feed_generation as _fg
        logger.info("[csv-parallel] one process for %d rows: %s", total,
                    "below csv_parallel_min_rows" if total < int(_fg.csv_parallel_min_rows)
                    else "the pod's CPU quota or its FREE memory allows one worker "
                         "(raise its CPU / memory limit, or set "
                         "feed_generation.csv_parallel_workers)")
        return None
    units = _units(parquet_path, workers)
    if not units:
        logger.info("[csv-parallel] one process: the source has a single row group")
        return None
    workers = min(workers, len(units))
    from core.feed.batch_budget import rows_within_budget
    batch_rows = rows_within_budget(chunk_size, len(columns) or None, batches_in_flight=workers)
    enc = str(dialect.get("encoding") or "utf-8").strip().lower()
    chunk_enc = "utf-8" if enc in ("utf-8-sig", "utf8") else enc
    chunks = [f"{out_path}.qs_chunk{i:05d}" for i in range(len(units))]
    jobs = [f"{out_path}.qs_job{w:03d}.json" for w in range(workers)]
    written = 0
    try:
        counts = _run_workers(units, chunks, jobs, dict(dialect), batch_rows, chunk_enc, workers)
        written = sum(counts)
        with open_csv(out_path, dialect) as f:          # the header (and a BOM) once
            CsvRowWriter(f, dialect).header(columns)
        # each chunk is removed the moment it is appended: the disk holds ONE
        # copy of the rows throughout (chunks shrinking, file growing)
        with open(out_path, "ab") as out:
            for c in chunks:
                with open(c, "rb") as part:
                    while True:
                        buf = part.read(8 << 20)
                        if not buf:
                            break
                        out.write(buf)
                os.remove(c)
    except BaseException:
        try:
            os.remove(out_path)
        except OSError:
            pass
        raise
    finally:
        for c in [*chunks, *jobs, *(j + ".out" for j in jobs), *(j + ".err" for j in jobs)]:
            try:
                os.remove(c)
            except OSError:
                pass
    logger.info("[csv-parallel] %d rows written by %d processes in %d ordered units",
                written, workers, len(units))
    return written


def worker_command(job: str) -> List[str]:
    """The interpreter command of one writer process (a seam: a test swaps it
    for a process that sleeps, to prove a cancel stops REAL children)."""
    import sys
    return [sys.executable, "-m", "core.feed.csv_parallel", job]


#: how often a waiting parent asks whether the run was cancelled
STOP_POLL_SECONDS = 0.5


def _wait_or_stop(p, procs) -> Optional[int]:
    """Wait for worker ``p``; while waiting, watch the run's cancel
    (core/cancel_scope.py).  When it lands every worker is terminated and
    None is returned -- a stopped worker is not a failed one.  The record
    says what was reached."""
    import subprocess
    from core.cancel_scope import stop_requested, current, note_cancel
    while True:
        try:
            return p.wait(timeout=STOP_POLL_SECONDS)
        except subprocess.TimeoutExpired:
            if not stop_requested():
                continue
            stopped = []
            for q, _err, _job in procs:
                if q.poll() is None:
                    try:
                        q.terminate()
                    except OSError:
                        pass
                    try:
                        q.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try:
                            q.kill()
                        except OSError:
                            pass
                stopped.append(q.pid)
            note_cancel(current(), "csv_workers", reached=True,
                        detail=f"{len(stopped)} writer process(es) stopped")
            logger.info("[csv-parallel] the run was cancelled: %d writer process(es) stopped",
                        len(stopped))
            return None


def _run_workers(units, chunks, jobs, dialect, batch_rows, encoding, workers) -> List[int]:
    """Start ``workers`` interpreters; worker w renders units w, w+W, ...
    Rows per unit, in unit order.  Raises naming the first worker that failed.
    A cancel of the run (the stop scope) terminates every worker and raises
    ``InterruptedError`` (2026-10-26)."""
    import json
    import subprocess
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    env = dict(os.environ)
    env.update({"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    env["PYTHONPATH"] = root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    procs = []
    for w, job in enumerate(jobs):
        mine = list(range(w, len(units), len(jobs)))
        with open(job, "w", encoding="utf-8") as fh:
            json.dump({"units": [units[i] for i in mine], "chunks": [chunks[i] for i in mine],
                       "index": mine, "dialect": dialect, "batch_rows": batch_rows,
                       "encoding": encoding, "out": job + ".out"}, fh)
        err = open(job + ".err", "wb")
        procs.append((subprocess.Popen(worker_command(job),
                                       cwd=root, env=env, stdout=subprocess.DEVNULL, stderr=err), err, job))
    counts = [0] * len(units)
    failed = []
    for p, err, job in procs:
        rc = _wait_or_stop(p, procs)
        err.close()
        if rc is None:
            # 2026-10-26 -- the run was cancelled: every worker is stopped,
            # the chunks written so far are removed by the caller's finally
            raise InterruptedError("the run was cancelled -- the CSV writer processes were stopped")
        if rc != 0:
            tail = open(job + ".err", "rb").read()[-600:].decode("utf-8", "replace")
            failed.append(f"worker {os.path.basename(job)} exit {rc}: {tail.strip()}")
            continue
        res = json.load(open(job + ".out", encoding="utf-8"))
        for i, n in zip(res["index"], res["rows"]):
            counts[i] = int(n)
    if failed:
        raise RuntimeError("the CSV was not written -- " + "; ".join(failed))
    return counts


def _worker_main(job_path: str) -> None:
    import json
    import pyarrow as pa
    # each worker IS one of the pod's CPUs: its own decode threads would
    # oversubscribe them (measured: 8 workers ran no faster than 4)
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    job = json.load(open(job_path, encoding="utf-8"))
    rows = [_render_unit(u, job["dialect"], int(job["batch_rows"]), c, job["encoding"])
            for u, c in zip(job["units"], job["chunks"])]
    with open(job["out"], "w", encoding="utf-8") as fh:
        json.dump({"index": job["index"], "rows": rows}, fh)


if __name__ == "__main__":      # a worker (see _run_workers)
    import sys as _sys
    _worker_main(_sys.argv[1])
