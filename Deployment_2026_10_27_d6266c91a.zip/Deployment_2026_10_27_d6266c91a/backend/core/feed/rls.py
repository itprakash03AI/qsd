"""Row-level security for feed generation (2026-08-17).

DESIGN DECISION -- the feed execution principal is the FEED OWNER
(``feed_configs.created_by``), not the trigger source.

Why:  feeds used to execute with NO principal at all.  ``triggered_by``
is a display/routing string ("scheduler", "queue_worker", "sod", or a
username on manual runs) and was never fed to ``secure_sql`` -- so a feed
sourced from an RLS-protected table exported the WHOLE table to
SFTP/email/S3.  The trigger source is also the wrong principal: the same
feed must produce the same rows whether the scheduler, the queue worker
or a colleague clicks Run -- the delivery destinations are fixed on the
feed, so the data contract belongs to the feed's AUTHOR, exactly like
scheduled Business Reports (``reports_api._run_sql_report`` uses
``{"username": report.owner, "role": "viewer"}`` when no interactive
user is present).

Semantics (deliberately restrictive-safe):

* ``username`` = ``feed_configs.created_by`` (falls back to
  ``_triggered_by_user`` and then ``"feed_engine"`` for legacy rows).
* ``role`` = ``"viewer"`` and ``is_admin`` = False -- there is no local
  user store carrying roles, and granting an implicit admin bypass here
  would recreate the leak for any feed whose author happened to be an
  admin.  A policy that SHOULD bypass feeds can bind accordingly.
* ``groups`` includes the feed's owner group name (``owner_group_id``)
  when resolvable, so group-scoped policies and ``${user.groups}``
  substitution behave sensibly for team-owned feeds.

Behaviour change matrix (the compatibility contract):

* RLS feature disabled            -> byte-identical SQL (secure_sql no-ops).
* No policy matches the source    -> byte-identical SQL.
* Policy matches                  -> the feed is FILTERED like any other
  consumer, or fails loudly if enforcement itself fails (unless
  ``row_security.fail_open`` says otherwise -- same knob as every other
  path).  This is the one case that changes, and it is the leak.

Paths that cannot rewrite SQL text (Spark Connect structured-builder
configs) go through :func:`assert_feed_tables_unrestricted` instead:
they REFUSE loudly when a referenced table is covered by an enabled
policy, rather than silently exporting unfiltered rows.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

# 2026-09-05 -- THE SECOND VOCABULARY, DELETED.
#
# This module used to carry ``RLS_DIALECT_MAP``, a copy of the shared
# connection-type -> dialect map whose own comment said it "mirrors
# api/reports_api._RS_DIALECT_MAP".  It did not mirror it for long.  The
# copy answered ``athena -> trino`` where the shared resolver in
# ``core.sql_filter_wrapper`` answers ``athena -> athena``, and it knew
# nothing of postgres / mysql / sqlserver / redshift / bigquery, so a feed
# on any of those was rewritten as DUCKDB while the report and the
# published view over the SAME saved query were rewritten as themselves.
# Two engines is fine; two answers to the same question is not.
#
# ``secure_feed_sql`` now resolves through ``dialect_for_connection_type``
# like every other surface.  Two deliberate behaviour changes follow:
#
#   * athena: ``trino`` -> ``athena``.  No emitted SQL changes -- sqlglot's
#     Athena dialect routes DML through Trino's parser and generator, and
#     the RLS rewriter only ever handles SELECTs -- but the name is now the
#     engine's own.  Justification in full at CONNECTION_TYPE_DIALECTS.
#   * postgres / mysql / sqlserver / redshift / bigquery: ``duckdb`` ->
#     the real dialect.  This DOES change the rewrite on those connections,
#     and it changes it towards correct: parsing Postgres or T-SQL as
#     duckdb can mangle syntax the rewriter then re-emits, which on this
#     path decides what rows a delivered file contains.
#
# Nothing may re-declare the map here.  A guard fails the build on a
# second copy: tests/test_query_dialect_contract_2026_09_05.py.


def feed_principal(db_manager: Any, feed_config: dict) -> Dict[str, Any]:
    """Build the user-ctx dict ``secure_sql`` consumes for this feed.

    Never raises -- principal construction failures degrade to an unknown
    viewer, never to a bypass.

    2026-08-19: that shape is NOT "the most restrictive", which this
    docstring used to claim.  Policies bind to principals and an unmatched
    table is left unfiltered, so a principal with no groups matches fewer
    RESTRICTIONS, not fewer rows.  The returned dict is therefore marked
    ``rls_unresolved`` and the rewriter refuses governed tables outright.
    """
    username = "feed_engine"
    groups: List[str] = []
    try:
        fc = feed_config or {}
        username = (
            (fc.get("created_by") or "").strip()
            or (fc.get("_triggered_by_user") or "").strip()
            or "feed_engine"
        )
        owner_gid = fc.get("owner_group_id")
        if owner_gid and db_manager is not None:
            try:
                group = db_manager.get_user_group(int(owner_gid))
                gname = (group or {}).get("name") if isinstance(group, dict) else None
                if gname:
                    groups.append(str(gname))
            except Exception as exc:
                logger.debug("[feed_rls] owner group lookup failed: %s", exc)
    except Exception as exc:
        logger.debug("[feed_rls] principal build degraded to default: %s", exc)
    return {
        "username": username,
        "role": "viewer",
        "groups": groups,
        "is_admin": False,
        # 2026-08-19 -- FABRICATED, and it must say so.  This principal never
        # resolves the user's real AD groups (only the feed's owner group is
        # added, when configured), so every group-bound policy stops matching
        # -- and in this GRANT-shaped engine an unmatched table is SKIPPED,
        # i.e. left UNFILTERED.  A feed then delivers the whole table to its
        # SFTP / email / S3 recipients as a successful run.
        #
        # The marker makes the rewriter refuse a GOVERNED table instead of
        # silently widening it.  Tables with no policies are unaffected, so
        # feeds on ungoverned data keep working exactly as before.
        "rls_unresolved": True,
        # 2026-10-24 -- data entitlement for this feed (the owner's decision 3:
        # per feed): "apply" = the OWNER GROUP's values; no owner group with
        # apply is refused (core/row_security/entitlement.py).
        "entitlement_scope": ("feed", _feed_mode(feed_config),
                              (feed_config or {}).get("owner_group_id")),
    }


def secure_feed_sql(
    db_manager: Any,
    sql: str,
    feed_config: dict,
    *,
    connection_id: Optional[int] = None,
    connection_type: Optional[str] = None,
    request_id: Optional[str] = None,
) -> str:
    """Apply row/column security policies to a feed's SQL.

    No-op (byte-identical return) when the RLS feature is disabled or no
    policy matches -- feeds that legitimately run today keep running.
    HARD-FAILS (ValueError) when enforcement itself errors, matching the
    reports/federation posture: a silent pass would defeat the purpose.
    (``secure_sql`` internally honours ``row_security.fail_open`` before
    its exception ever reaches us.)
    """
    def _call(**kw):
        # the PACKAGE seam (``core.row_security.secure_sql``) -- the one the
        # engine's tests patch to spy on / fail the run's securing
        from core.row_security import secure_sql as _rs_secure
        return _rs_secure(**kw), None
    return _secure(db_manager, sql, feed_config, _call,
                   connection_id=connection_id, connection_type=connection_type,
                   request_id=request_id)[0]


def secure_feed_sql_report(
    db_manager: Any,
    sql: str,
    feed_config: dict,
    *,
    connection_id: Optional[int] = None,
    connection_type: Optional[str] = None,
    request_id: Optional[str] = None,
):
    """:func:`secure_feed_sql` plus the rewriter's ``RewriteResult`` (``None``
    = no rewrite ran: the engine is off or not wired, or the SQL was passed
    through).  "Test as feed" (``core/feed/test_as_feed.py``, 2026-10-24)
    calls this to SHOW which entitlement dimensions and values the run would
    apply.  The DECISION -- the principal, the dialect, the failure framing
    -- is :func:`_secure`, shared with :func:`secure_feed_sql`; the engine
    function is the same one (``secure_sql`` IS ``secure_sql_report(...)[0]``),
    so the two cannot answer differently (a test pins it)."""
    def _call(**kw):
        from core.row_security.api import secure_sql_report as _rs_secure_report
        return _rs_secure_report(**kw)
    return _secure(db_manager, sql, feed_config, _call,
                   connection_id=connection_id, connection_type=connection_type,
                   request_id=request_id)


def _secure(db_manager: Any, sql: str, feed_config: dict, call, *,
            connection_id: Optional[int], connection_type: Optional[str],
            request_id: Optional[str]):
    """THE securing decision of a feed's SQL: the feed's principal, the
    connection's dialect through the ONE vocabulary, a failure framed as the
    run's ValueError.  ``call(**kw) -> (sql, RewriteResult | None)``."""
    if not sql:
        return sql, None
    ctx = feed_principal(db_manager, feed_config)
    # ONE vocabulary -- see the note where RLS_DIALECT_MAP used to live.
    from core.sql_filter_wrapper import dialect_for_connection_type
    dialect = dialect_for_connection_type(connection_type)
    try:
        return call(
            sql=sql,
            dialect=dialect,
            user_ctx=ctx,
            connection_id=connection_id,
            request_id=request_id,
        )
    except Exception as _rs_exc:
        raise ValueError(
            f"Row-security enforcement failed for feed "
            f"{(feed_config or {}).get('id')}: {_rs_exc}"
        ) from _rs_exc


def _rls_enabled() -> bool:
    """Delegates to ``core.row_security.api._is_enabled`` -- the one seam
    every row-security test pins (2026-09-26, F0).  This used to read the
    config directly, so a test that declared the engine OFF through the
    seam still saw this guard fire: two readers of one switch."""
    try:
        from core.row_security import api as _rs_api
        return bool(_rs_api._is_enabled())
    except Exception:
        return False


def _deployment_is_production() -> bool:
    """Delegates -- see :func:`_rls_fail_open`.  ONE implementation, in
    ``core.row_security.api``."""
    from core.row_security.api import deployment_is_production
    return deployment_is_production()


def _rls_fail_open() -> bool:
    """Is the row-security fail-open switch in force RIGHT NOW?

    2026-09-05 -- THE IMPLEMENTATION MOVED, and this is the point.

    FR-SEC-03 ("the RLS fail-open switch must be reviewed and, IN
    PRODUCTION, closed") was implemented HERE, and this function gates
    exactly one caller: ``assert_feed_tables_unrestricted`` below.  The
    gate that actually decides whether the SQL rewrite is skipped --
    ``core.row_security.api``'s ``PolicyRewriteError`` handler -- read the
    raw config and had NO production override.  So in production with
    ``fail_open=true`` declared, the two functions answered differently:

        core.feed.rls._rls_fail_open()      -> False   (FR-SEC-03 honoured)
        core.row_security.api._fail_open()  -> True    (the deciding gate)

    Two engines is fine; two answers to the same question is not.  The
    requirement now lives on the function that decides, and this one
    delegates -- so the feed surface's behaviour is unchanged and the SQL
    rewrite is finally covered by the same rule.
    """
    from core.row_security.api import fail_open_in_force
    return fail_open_in_force()


def assert_feed_tables_unrestricted(
    db_manager: Any,
    table_names: Iterable[str],
    feed_config: dict,
    path_label: str,
) -> None:
    """Fail-closed guard for execution paths that CANNOT rewrite SQL
    (e.g. Spark Connect structured-builder configs have no SQL text).

    Raises ``ValueError`` when an enabled row/column policy covers any
    referenced table -- exporting it unfiltered on this path would be a
    silent RLS bypass.  No-op when RLS is disabled, no tables are given
    or no policy matches (the overwhelmingly common case).
    """
    if not _rls_enabled() or db_manager is None:
        return
    tables = [str(t).strip() for t in (table_names or []) if str(t or "").strip()]
    if not tables:
        return
    # 2026-10-24 -- a feed under data entitlement ("apply"): a table a
    # dimension governs cannot be filtered on this path either.  Asked of the
    # ONE compiler with the feed's own principal; its refusal (no owner group,
    # unknown schema, unreadable store) is this path's refusal too.
    if _feed_mode(feed_config) == "apply":
        from core.row_security.api import build_user_ctx
        from core.row_security.entitlement import EntitlementRefused, compile_for
        ctx = build_user_ctx(feed_principal(db_manager, feed_config))
        conn_id = (feed_config or {}).get("connection_id")
        ent_covered = []
        for t in tables:
            try:
                if compile_for(ctx, conn_id, t, db_manager):
                    ent_covered.append(t)
            except EntitlementRefused as exc:
                raise ValueError(
                    f"Feed {(feed_config or {}).get('id')} ({path_label}): data entitlement "
                    f"cannot be certified for '{t}': {exc}") from exc
        if ent_covered:
            raise ValueError(
                f"Feed {(feed_config or {}).get('id')} ({path_label}) is under data entitlement "
                f"and reads table(s) a dimension governs: {sorted(ent_covered)}.  This path runs a "
                f"structured query config with no SQL text, so the entitlement filter cannot be "
                f"applied -- running it would export every row.  Fix: run this feed on the native "
                f"backend, or re-save the source query in SQL mode.")
    try:
        row_pols = db_manager.list_row_policies(enabled_only=True) or []
        col_pols = db_manager.list_column_policies(enabled_only=True) or []
    except Exception as exc:
        if _rls_fail_open():
            logger.warning(
                "[feed_rls] policy lookup failed on %s (%s) -- "
                "row_security.fail_open=true, continuing UNFILTERED",
                path_label, exc,
            )
            return
        raise ValueError(
            f"Row-security policy lookup failed on {path_label} for feed "
            f"{(feed_config or {}).get('id')}: {exc} -- refusing to run "
            f"unverified (row_security.fail_open=false)"
        ) from exc
    patterns = [p.get("table_pattern", "") for p in (list(row_pols) + list(col_pols))
                if isinstance(p, dict) and p.get("table_pattern")]
    if not patterns:
        return
    try:
        from core.row_security.resolver import table_matches_pattern
    except Exception:
        return
    covered = sorted({
        t for t in tables
        if any(table_matches_pattern(t, pat) for pat in patterns)
    })
    if not covered:
        return
    raise ValueError(
        f"Feed {(feed_config or {}).get('id')} ({path_label}) references "
        f"table(s) covered by enabled row/column security policies: "
        f"{covered}.  This execution path runs a structured query config "
        f"with no SQL text, so the policy rewrite cannot be applied -- "
        f"running it would export unfiltered rows.  Fix: run this feed on "
        f"the native backend, or re-save the source query in SQL mode so "
        f"the policy rewrite can apply."
    )


def _feed_mode(feed_config) -> str:
    """The feed's data-entitlement switch: its own, else the config default
    (core/row_security/entitlement.py::effective_mode)."""
    from core.row_security.entitlement import effective_mode
    return effective_mode((feed_config or {}).get("entitlement_mode"), "feed")
