"""FeedRunQueueWorker — Phase 130 hotfix-11.

The polling-based background worker for SOD-generated ``feed_runs``
rows.  Complements (does NOT replace) the existing per-feed
APScheduler cron mechanism:

  - Per-feed cron (existing): when a feed_config has its own
    ``cron_expression``, APScheduler fires ``run_scheduled_feed`` at
    that cron time -> ``execute_feed`` runs the feed.
  - Queue worker (this file): when SOD created a pending feed_run
    but the feed has NO cron, the worker picks it up, atomically
    claims it (pending -> running), and dispatches ``execute_feed``.

The two paths now share status sync via the ``feed_run_id`` parameter
to ``execute_feed`` (added in hotfix-8), so the dashboard reflects
progress regardless of who fired the execution.

Concurrency model — multiple jobs in parallel:
  - Worker polls every ``feed_generation.queue_poll_interval_seconds``
    (default 30s) via APScheduler.
  - Each tick pulls up to ``feed_generation.max_concurrent_native``
    pending rows; flips each from pending -> running with an atomic
    DB update; dispatches ``execute_feed`` as an asyncio task and
    moves on.
  - Atomic claim defends against double-trigger: parallel pods
    polling the same DB will each successfully claim DIFFERENT rows.
  - In-process ``_inflight`` set bounds total concurrent executions
    per pod.
  - REFILL ON COMPLETION (2026-10-10).  A finishing run frees a slot and,
    when the last poll saw a BACKLOG (claimable rows it had no slot for),
    wakes ONE refill thread that runs ``poll_once`` again at once.  Found
    live by the owner's month-end case: 50 one-second feeds released
    together took 514 s, because a slot freed between ticks sat idle until
    the next 30 s tick -- 50 / 3 slots = 17 rounds x 30 s.  At 4,000 feeds
    that was ~11 hours of a 3-wide pool ~97% idle.  See ``_request_refill``.

Activation: ``feed_generation.queue_worker_enabled`` (default false).
"""
from __future__ import annotations

import asyncio
import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


#: Who asked for a poll.  ``tick`` = the 30 s APScheduler job or the
#: standalone feed_worker loop; ``refill`` = a completed run freed a slot
#: while a backlog was known; ``poll_now`` = the admin route.
POLL_TRIGGER_TICK = "tick"
POLL_TRIGGER_REFILL = "refill"
POLL_TRIGGER_POLL_NOW = "poll_now"


@dataclass
class QueuePollResult:
    """Per-poll summary returned by ``poll_once``.

    ``trigger`` says who asked (see ``POLL_TRIGGER_*``).  ``backlog`` is the
    number of claimable candidates THIS pod could not take for want of a
    slot (pool full, or a connection budget denied) -- the evidence a
    completion-time refill is worth running.
    """
    candidates: int = 0
    claimed: int = 0
    skipped_already_running: int = 0
    skipped_pool_full: int = 0
    skipped_cron_owned: int = 0
    errors: int = 0
    error_details: List[str] = field(default_factory=list)
    trigger: str = POLL_TRIGGER_TICK
    backlog: int = 0
    #: runs left pending because their memory did not fit beside the runs
    #: this pod already holds (core/feed/run_memory.py) -- part of backlog
    held_for_memory: int = 0

    def to_dict(self) -> dict:
        return {
            "candidates": self.candidates,
            "claimed": self.claimed,
            "skipped_already_running": self.skipped_already_running,
            "skipped_pool_full": self.skipped_pool_full,
            "skipped_cron_owned": self.skipped_cron_owned,
            "errors": self.errors,
            "error_details": list(self.error_details),
            "trigger": self.trigger,
            "backlog": self.backlog,
            "held_for_memory": self.held_for_memory,
        }


# 2026-10-07 -- worker_health_state retention, decided HERE, once.
#
# Each poll upserts a row keyed ``hostname:pid``, so every restart (and every
# pid) adds a row.  The only age-out lived in the standalone ``feed_worker.py``
# loop; production runs this worker as an APScheduler job on the scheduler
# pod, which never called it -- ``/api/admin/feed-generation/health`` reported
# ``pod_count: 231``, one per restart since the table was created.  The GC now
# runs from ``poll_once`` itself (throttled), so every runtime shape ages out
# the same way.  1 h keeps dead-pod evidence well past the 180 s "native
# unhealthy" threshold.
WORKER_HEALTH_RETENTION_SECONDS = 3600
_WORKER_HEALTH_GC_EVERY_SECONDS = 600
_worker_health_gc_at = 0.0
_worker_health_gc_lock = threading.Lock()


def maybe_gc_worker_health(db, *, now: Optional[float] = None) -> Optional[int]:
    """Prune heartbeats older than the retention, at most once per
    ``_WORKER_HEALTH_GC_EVERY_SECONDS`` per process.  Returns the number of
    rows pruned, or ``None`` when throttled / unavailable.  Never raises."""
    global _worker_health_gc_at
    t = time.time() if now is None else now
    with _worker_health_gc_lock:
        if t - _worker_health_gc_at < _WORKER_HEALTH_GC_EVERY_SECONDS:
            return None
        _worker_health_gc_at = t
    try:
        n = db.cleanup_stale_worker_health(
            stale_after_seconds=WORKER_HEALTH_RETENTION_SECONDS)
        if n:
            logger.info("[queue-worker] pruned %d worker_health_state row(s) "
                        "older than %ds", n, WORKER_HEALTH_RETENTION_SECONDS)
        return int(n or 0)
    except Exception as exc:
        logger.debug("[queue-worker] worker_health_state GC failed: %s", exc)
        return None


class FeedRunQueueWorker:
    """Picks pending ``feed_runs`` and dispatches them.

    Constructor parameters are all DI-friendly so unit tests can pass
    a mocked db + mocked ``execute_feed_fn`` without booting the full
    feed engine.
    """

    def __init__(
        self,
        db,
        *,
        execute_feed_fn: Optional[Callable] = None,
        max_concurrent: int = 3,
        loop: Optional[asyncio.AbstractEventLoop] = None,
        shard: Optional[str] = None,
        heartbeat_interval_seconds: Optional[float] = None,
        refill_on_completion: Optional[bool] = None,
        memory_ledger=None,
    ) -> None:
        """Phase 130 hotfix-13: ``shard`` is an optional ``"i/N"`` string
        (e.g. ``"0/4"``) that gates which feed_runs this worker picks up.
        Workers with shard ``"0/4"`` only claim rows where
        ``feed_config_id %% 4 == 0``; ``"1/4"`` claims where ``%% 4 == 1``;
        etc.  Default ``None`` = single-shard mode (this worker owns
        all rows, same as pre-sharding behaviour).  Multi-shard
        deployments set the env var ``QUERYSTUDIO_FEED_SHARD=i/N`` on
        each pod and pass it here at construction."""
        if db is None:
            raise ValueError("FeedRunQueueWorker requires a db manager")
        self._db = db
        # 2026-08-20 — a worker must never CLAIM a run its executor cannot
        # run.  On a dedicated scheduler pod, init_feed_engine() was called
        # only in main.py's lifespan, so this worker claimed feed_runs and
        # execute_feed then crashed on feed_engine's None _db_manager.  The
        # chokepoint fix: wire the engine with the SAME db the claims come
        # from (broadcast_fn stays None — no websocket here).  No-op when
        # main.py already wired it, and skipped entirely when the caller
        # injects a custom execute_feed_fn (unit tests).
        if execute_feed_fn is None:
            try:
                from core import feed_engine as _fe
                if _fe._db_manager is None:
                    _fe.init_feed_engine(db, broadcast_fn=None)
                    logger.info(
                        "[queue_worker] feed_engine was unwired in this "
                        "process — initialised with the worker's own db")
            except Exception as _fe_exc:
                logger.warning("[queue_worker] feed_engine self-wire failed "
                               "(claims may not execute): %s", _fe_exc)
        self._max_concurrent = max(1, int(max_concurrent))
        # 2026-10-26 -- the pod's memory, reserved per run by its WIDTH
        # (core/feed/run_memory.py).  The count above alone admitted eight
        # 600-column runs into a 16 GiB scheduler.
        # None = no ledger (a worker built directly -- tests, tools); the
        # shared production worker passes the pod's (get_shared_queue_worker)
        from core.feed.run_memory import MemoryLedger
        self._memory = memory_ledger if memory_ledger is not None else MemoryLedger(None)
        # BF-591: split BF-590's combined set into two so ``inflight_count``
        # is accurate (was double-counting run_id + Task on the
        # create_task fallback branch, halving effective concurrency).
        self._inflight_run_ids: set = set()
        self._inflight_tasks: set = set()
        # FR-RUN-08 (2026-09-02) — runs that actually HOLD connection
        # claims.  The claim heartbeat must beat only for these: a
        # local-only feed (empty connection set) and a fail-open
        # unbudgeted admit hold nothing, and beating for them would log
        # a false "slots were reclaimed" warning every interval.
        self._runs_holding_claims: set = set()
        # Explicit override wins (tests, ops); None derives the cadence
        # from the reap threshold — see _heartbeat_interval_seconds.
        self._heartbeat_interval_override = heartbeat_interval_seconds
        # 2026-09-02 (D4) — drain mode.  While draining the worker claims
        # NOTHING new and lets what it holds finish, so a rolling deploy
        # stops abandoning runs mid-flight.  See ``drain``.
        self._draining = False
        self._loop = loop
        self._shard_id, self._shard_total = self._parse_shard(shard)
        self._shard_str = shard
        # 2026-10-10 -- REFILL ON COMPLETION.  Two locks and one thread:
        #   _poll_lock     serialises poll_once across every caller (the
        #                  APScheduler tick thread, the admin poll-now
        #                  thread, the refill thread) -- two polls at once
        #                  would both read the same free_slots and over-fill.
        #   _inflight_lock guards _inflight_run_ids, which poll_once ADDS to
        #                  on the polling thread and _run_one DISCARDS from
        #                  on the event-loop thread.
        #   the refill thread is woken by an Event: N completions while a
        #                  poll runs set it once, so at most ONE refill is
        #                  pending behind the poll in progress (coalesced).
        # ``refill_on_completion`` None = read the config key
        # ``feed_generation.queue_refill_on_completion`` on every request (the
        # DB overlay makes it a live kill switch); a bool pins it (tests).
        self._poll_lock = threading.Lock()
        self._inflight_lock = threading.Lock()
        self._refill_on_completion_override = refill_on_completion
        self._refill_lock = threading.Lock()
        self._refill_wake = threading.Event()
        self._refill_stop = threading.Event()
        self._refill_thread: Optional[threading.Thread] = None
        self._closed = False
        # The evidence: how many claimable rows the LAST poll left behind for
        # want of a slot on this pod.  0 = nothing is known to be waiting, so
        # a completion requests nothing and the tick keeps its normal duty.
        self._backlog_seen = 0
        self._refill_stats = {
            "requested": 0, "coalesced": 0, "skipped_no_backlog": 0,
            "skipped_disabled": 0, "skipped_draining": 0,
            "polls": 0, "claimed": 0, "errors": 0,
            "last_requested_at": None, "last_poll_at": None,
        }
        if execute_feed_fn is None:
            from core.feed_engine import execute_feed as _ef
            self._execute_feed_fn = _ef
            # 2026-08-20 — pass the worker's OWN db explicitly through the
            # execute_feed chokepoint (FeedEngineDeps).  The self-wire
            # above remains the module-global fallback; this makes the
            # dependency visible in the call, so a claimed run can never
            # execute against a db other than the one it was claimed from.
            from core.feed_engine import FeedEngineDeps as _FeedDeps
            self._feed_deps = _FeedDeps(db_manager=db)
        else:
            self._execute_feed_fn = execute_feed_fn
            # injected callable (unit tests): its signature is the test's
            # contract — do not force a deps kwarg on it.
            self._feed_deps = None

    @staticmethod
    def _parse_shard(shard: Optional[str]) -> tuple:
        """Parse ``'i/N'`` -> ``(i, N)``.  Returns ``(0, 1)`` (single-shard)
        for None / empty / malformed input.  Validates that 0 <= i < N
        and N >= 1; otherwise raises ValueError."""
        if not shard:
            return (0, 1)
        s = str(shard).strip()
        if "/" not in s:
            raise ValueError(
                f"shard must be 'i/N' format (e.g. '0/4'); got {shard!r}"
            )
        i_s, n_s = s.split("/", 1)
        try:
            i, n = int(i_s), int(n_s)
        except ValueError:
            raise ValueError(f"shard must be 'i/N' integers; got {shard!r}")
        if n < 1:
            raise ValueError(f"shard total must be >= 1; got {n}")
        if i < 0 or i >= n:
            raise ValueError(f"shard index must be 0 <= i < N; got {i}/{n}")
        return (i, n)

    # ── Public API ────────────────────────────────────────────────────

    @property
    def inflight_count(self) -> int:
        # BF-591: count run_ids only — that's the contract callers expect.
        return len(self._inflight_run_ids)

    @property
    def max_concurrent(self) -> int:
        return self._max_concurrent

    def poll_once(self, business_date: Optional[date] = None, *,
                  trigger: str = POLL_TRIGGER_TICK) -> QueuePollResult:
        """Synchronous poll tick.  Claims candidate rows + dispatches
        execute_feed as asyncio tasks.  Returns a typed summary.

        Safe to call repeatedly — atomic-claim semantics mean rows
        already being executed (anywhere) are skipped.  SERIALISED: the
        tick, the admin poll-now and the completion-time refill all take
        ``_poll_lock``, so two polls never read the same free slots.
        ``trigger`` is recorded on the result and in the worker's health
        row so an operator can see who polled.
        """
        self._reap_previous_process_once()
        # 2026-10-17 -- a DRAIN intent applied on this pod (component health):
        # claim nothing; the runs in flight finish.  The tick is still a tick
        # (recorded, with the reason) so a drained pod never reads as dead.
        try:
            from core.component_health.intents import is_draining as _is_draining
            draining = bool(_is_draining())
        except Exception:                                   # noqa: BLE001
            draining = False
        if draining:
            logger.info("[queue_worker] draining: not claiming (pod %s)", self.pod_id)
            return QueuePollResult(trigger=trigger,
                                   error_details=["draining: this pod claims no new run"])
        with self._poll_lock:
            result = self._poll_once_locked(business_date, trigger)
        maybe_gc_worker_health(self._db)     # 2026-10-07: bounded fleet table
        return result

    def _reap_previous_process_once(self) -> None:
        """Once per process, after one full beat interval (plus slack): free
        the runs a previous process on THIS pod left "running" -- it was
        killed (OOM) or restarted.  Without this the feed stayed blocked for
        the reaper's hour (found live 2026-10-14).  Waiting one interval is
        what makes it exact: a live process on this pod beats its runs at
        least that often (``mixin_feeds.reap_runs_of_a_dead_process``).

        2026-10-27: the SAME reap also runs from :func:`schedule_previous_
        process_reap` on every process, lease or no lease -- this method is
        kept for a worker built without it (tests, tools) and shares the
        once-per-process record."""
        if getattr(self, "_previous_process_reaped", False) or _PREVIOUS_PROCESS_REAP["done"]:
            self._previous_process_reaped = True
            return
        import time as _t
        born = getattr(self, "_process_born", None)
        if born is None:
            from datetime import datetime as _dt, timezone as _tz
            self._process_born = (_t.monotonic(),
                                  _dt.now(_tz.utc).replace(tzinfo=None))
            return
        if _t.monotonic() - born[0] < self._heartbeat_interval_seconds() * 1.5 + 30:
            return
        self._previous_process_reaped = True
        reap_previous_process_now(self._db, self.pod_id, born[1])

    def _reserve_memory(self, run_id: int, feed_id: int) -> bool:
        """Reserve the run's memory on this pod's ledger (run_memory.need_mb);
        False = it does not fit beside what this pod runs now."""
        from core.feed.run_memory import need_mb
        try:
            feed = self._db.get_feed_config(feed_id)
        except Exception:                                   # noqa: BLE001 -- unknown feed = the base
            feed = None
        mb = need_mb(self._db, feed, self._memory.budget_mb)
        if self._memory.try_reserve(run_id, mb):
            return True
        logger.info("[queue_worker] feed_run %s (feed %s) waits: it needs about %d MB and this pod "
                    "holds %d of %d MB for the runs it is executing", run_id, feed_id, mb,
                    self._memory.reserved_mb, self._memory.budget_mb or 0)
        return False

    def note_lane(self, run_id: int, backend: str) -> None:
        """The engine chose a lane whose work runs elsewhere: the run holds
        only run_memory.OFF_POD_MB here from now on."""
        from core.feed.run_memory import OFF_POD_BACKENDS, OFF_POD_MB
        if str(backend or "").lower() in OFF_POD_BACKENDS:
            self._memory.lower(run_id, OFF_POD_MB)
            self._request_refill(run_id)

    def _free_slots(self) -> int:
        with self._inflight_lock:
            return max(0, self._max_concurrent - len(self._inflight_run_ids))

    def _poll_once_locked(self, business_date: Optional[date],
                          trigger: str) -> QueuePollResult:
        result = QueuePollResult(trigger=trigger)
        today = business_date or datetime.now(timezone.utc).date()

        # 2026-09-02 (D4) — a draining worker claims NOTHING.  Checked before
        # the slot arithmetic so a drain is immediate rather than "as soon as a
        # slot frees", which is the opposite of what draining means.
        if self._draining:
            result.skipped_pool_full = 1
            return result

        free_slots = self._free_slots()
        if free_slots == 0:
            result.skipped_pool_full = 1
            return result

        # Phase 4 (2026-08-23) — bounded LOOKBACK.  Polling only today
        # silently ABANDONED any row still pending at midnight: a
        # dependency-WAIT row whose deps became ready at 00:01, a reclaim
        # that landed after 23:59, or worker downtime spanning midnight all
        # produced a row no poll would ever see again ("a job that silently
        # never runs").  The window is a cap on how far back we look, never
        # on whether a row inside it runs.
        lookback_days = 0
        if business_date is None:
            try:
                from core.config import feed_generation as _fg
                lookback_days = int(_fg.queue_lookback_days)
            except Exception:
                lookback_days = 0

        # Over-fetch so we have room to skip rows already claimed by
        # parallel pods.  Ordered by priority desc, scheduled_time asc
        # inside ``list_feed_runs``.  Multi-shard deployments over-fetch
        # by N more to account for the in-memory shard filter (we still
        # bound by free_slots after filtering).
        fetch_factor = 4 * max(1, self._shard_total)
        fetch_limit = free_slots * fetch_factor
        try:
            # include_pending_backfills (FR-OPS-06, 2026-09-02): a
            # backfill row's business_date is historical BY DEFINITION —
            # without this the date-window poll below could NEVER claim
            # one and every launched backfill would sit pending forever.
            if lookback_days > 0:
                candidates = self._db.list_feed_runs(
                    business_date_from=today - timedelta(days=lookback_days),
                    business_date_to=today, status="pending",
                    limit=fetch_limit, offset=0, exclude_wait=True,
                    include_pending_backfills=True,
                    decided_since=(datetime.now(timezone.utc).replace(tzinfo=None)
                                   - timedelta(days=lookback_days)),
                ) or []
            else:
                candidates = self._db.list_feed_runs(
                    business_date=today, status="pending",
                    limit=fetch_limit, offset=0, exclude_wait=True,
                    include_pending_backfills=True,
                ) or []
        except TypeError:
            # DB layer without the Phase-4 kwargs (older manager / test
            # double) — legacy today-only call; WAIT filtered in Python
            # below.
            candidates = self._db.list_feed_runs(
                business_date=today, status="pending",
                limit=fetch_limit, offset=0,
            ) or []
        # Apply shard predicate in-process.  Doing this in Python rather
        # than SQL keeps list_feed_runs portable across SQLite/Postgres
        # without a dialect-specific modulo operator.  At 10K pending
        # rows the post-fetch filter cost is negligible (μs).
        if self._shard_total > 1:
            sid, sn = self._shard_id, self._shard_total
            candidates = [
                r for r in candidates
                if (int(r.get("feed_config_id", 0)) % sn) == sid
            ]
        # Phase 131-A — ETL dependency gate.  A row whose deps are not
        # yet satisfied was flipped to action_decision='WAIT' by the
        # dependency poller; the queue worker must NOT claim it.  The
        # primary filter is SQL-side now (exclude_wait=True — a page of
        # WAIT rows used to starve runnable rows beyond the LIMIT); this
        # Python pass remains for the fallback branch above.
        candidates = [
            r for r in candidates
            if (r.get("action_decision") or "RUN") != "WAIT"
        ]
        # Phase 4 (2026-08-23) — CRON OWNERSHIP.  The docstring's contract
        # ("only rows whose feed has no cron") finally exists in code: a
        # cron-owned feed's row is claimable only AFTER its cron fire time
        # for the row's day has passed (+grace) — before that the cron path
        # owns it (running it at 00:00:30 was the wrong-time + double-
        # delivery defect); after it, this worker is the missed-fire safety
        # net.  The atomic claim keeps the hand-off race-safe either way.
        candidates = self._filter_cron_owned(candidates, result)
        # Foundation C (2026-09-02, FR-OPS-10/12) — priority is honoured
        # AT CLAIM TIME, not only at insert, and a waiting run ages so a
        # continuous stream of higher-priority work cannot starve it
        # forever.  Ordering here rather than in SQL keeps the ageing
        # rule in one testable place instead of a dialect-specific
        # expression.
        try:
            from core.feed import claims as _claims
            candidates = _claims.order_candidates(candidates)
        except Exception as _ord_exc:
            logger.warning(
                "[queue_worker] candidate ordering unavailable (%s) — "
                "falling back to the query order; priority still "
                "applies, ageing does not", _ord_exc)
        result.candidates = len(candidates)

        for idx, row in enumerate(candidates):
            if self._free_slots() == 0:
                # Every candidate from here on is claimable work this pod
                # has no slot for -- the BACKLOG a completion will refill.
                result.backlog += len(candidates) - idx
                break
            run_id = int(row["id"])
            if run_id in self._inflight_run_ids:
                result.skipped_already_running += 1
                continue
            feed_id = int(row["feed_config_id"])
            # 2026-10-26 -- the run's memory must fit beside what this pod
            # already runs (THROTTLE: it waits, in queue order, for a free
            # slot; with nothing running it is always admitted).
            if not self._reserve_memory(run_id, feed_id):
                result.held_for_memory += 1
                result.backlog += len(candidates) - idx
                break

            # Atomic claim — flip status pending -> running.  The DB's
            # update_feed_run does a SELECT-then-UPDATE; we tolerate
            # races by re-reading status after the update.  Better
            # primitive would be a conditional UPDATE WHERE status='pending'
            # returning rowcount; for now we accept a small race window
            # bounded by the in-process inflight set.
            # Foundation C (FR-RUN-06/07) — take a slot on EVERY
            # connection this run touches, or none at all, BEFORE
            # claiming the row.  A run claimed without its budget would
            # execute outside the source's allowance, which is exactly
            # what the per-process cap already gets wrong across
            # replicas.  A denial leaves the row PENDING for the next
            # tick; the decision names the blocking connection.
            if not self._acquire_slots(run_id, feed_id, row, result):
                # A budget denial is a slot this pod lacks too: a run on
                # that connection finishing is what frees it.
                self._memory.release(run_id)
                result.backlog += 1
                continue
            try:
                claimed = self._claim_row(run_id)
                if not claimed:
                    # Someone else owns the row — give the slots back
                    # immediately, or this pod holds budget for work it
                    # will never do.
                    self._release_slots(run_id)
                    self._memory.release(run_id)
                    result.skipped_already_running += 1
                    continue
            except Exception as exc:
                self._release_slots(run_id)
                self._memory.release(run_id)
                result.errors += 1
                result.error_details.append(f"feed_run {run_id} claim: {exc}"[:300])
                continue

            with self._inflight_lock:
                self._inflight_run_ids.add(run_id)
            # Fire-and-forget the async execution.  Either via the
            # caller-provided loop, or via asyncio.create_task on the
            # current running loop (when the worker is called from
            # within an async context).
            # BF-591: ANY dispatch failure must remove the run_id from
            # _inflight_run_ids AND flip the DB row back to pending so
            # the next tick can retry — otherwise the slot is
            # permanently consumed and the run is permanently stuck
            # on "running".
            try:
                self._dispatch_async(run_id, feed_id)
                result.claimed += 1
            except Exception as _disp_exc:
                with self._inflight_lock:
                    self._inflight_run_ids.discard(run_id)
                self._release_slots(run_id)
                self._memory.release(run_id)
                result.errors += 1
                result.error_details.append(
                    f"feed_run {run_id} dispatch: {_disp_exc}"[:300]
                )
                # BF-593: conditional reset — only flip to pending if WE
                # are still the claimed_by owner.  Without this, a
                # cross-pod claim that arrived between our atomic claim
                # and the dispatch failure would have its `running` flip
                # trampled back to `pending`, doubling-up the work.
                try:
                    _did_reset = self._db.reset_feed_run_to_pending_if_owned(
                        run_id,
                        owned_by="queue_worker",
                    )
                    if not _did_reset:
                        logger.info(
                            "BF-593: skip pending-reset for feed_run %s "
                            "— not owned by us anymore",
                            run_id,
                        )
                except AttributeError:
                    # DB layer doesn't have the conditional helper yet —
                    # fall back to the unconditional reset with a
                    # warning so the gap is visible in logs.  Migrating
                    # path: add ``reset_feed_run_to_pending_if_owned`` to
                    # the DB manager (UPDATE WHERE status='running' AND
                    # claimed_by='queue_worker').
                    logger.warning(
                        "BF-593: reset_feed_run_to_pending_if_owned not "
                        "available on DB manager — falling back to "
                        "unconditional reset of feed_run %s (cross-pod "
                        "trample risk).  Add the conditional helper.",
                        run_id,
                    )
                    try:
                        self._db.update_feed_run(run_id, {"status": "pending"})
                    except Exception as _flip_exc:
                        logger.warning(
                            "BF-591/593: could not reset feed_run %s to "
                            "pending after dispatch failure: %s",
                            run_id, _flip_exc,
                        )
                except Exception as _flip_exc:
                    logger.warning(
                        "BF-593: conditional pending-reset failed for "
                        "feed_run %s: %s",
                        run_id, _flip_exc,
                    )
        # The evidence for the NEXT completion: what this poll left behind.
        # Every trigger writes it -- a refill that found nothing clears it,
        # so the completions after it request nothing (no loop).
        with self._refill_lock:
            self._backlog_seen = int(result.backlog)
        # Phase 130 hotfix-13: record heartbeat for the health probe so
        # the failover agent can detect a wedged worker.  Recorded even
        # when nothing was claimed — a tick that ran successfully
        # without work is still proof of life.  The health copy carries the
        # refill counters beside the poll so an operator can see the
        # completion-time refills, not only the ticks.
        health_record = result.to_dict()
        health_record["refills"] = self.refill_stats()
        try:
            from core.feed.health import record_native_tick
            record_native_tick(health_record)
        except Exception:
            pass
        # Multi-pod fleet health — persist the heartbeat to the DB so
        # the failover agent on the scheduler pod can aggregate across
        # all worker pods.  Per-pod row keyed by hostname:pid.  Cheap
        # upsert — safe even at 1-second poll intervals.
        try:
            import os
            import socket as _sk
            pod_id = f"{_sk.gethostname()}:{os.getpid()}"
            shard = os.environ.get("QUERYSTUDIO_FEED_SHARD") or self._shard_str or None
            self._db.record_worker_health(
                pod_id,
                last_tick_result=health_record,
                inflight_count=len(self._inflight_run_ids),
                shard=shard,
            )
        except Exception:
            pass
        # Prometheus metrics for queue depth + claim rate.
        try:
            from core.metrics import record_feed_queue_tick
            record_feed_queue_tick(
                shard=self._shard_str or "0/1",
                claimed=result.claimed,
                errors=result.errors,
                skipped_running=result.skipped_already_running,
                inflight_count=len(self._inflight_run_ids),
            )
        except Exception:
            pass
        return result

    def _filter_cron_owned(self, candidates: list,
                           result: QueuePollResult) -> list:
        """Drop rows whose feed's OWN cron still owns the fire (Phase 4).

        See core/feed/run_ownership.py for the ownership vocabulary.  A
        config/DB hiccup fails OPEN per row (row stays claimable) — this
        filter exists to stop wrong-time duplicates, not to stop runs.
        """
        if not candidates:
            return candidates
        try:
            from core.feed.run_ownership import cron_owned, cron_fire_passed
        except Exception:  # pragma: no cover - import cycle safety
            return candidates
        try:
            from core.config import feed_generation as _fg
            grace = int(_fg.queue_cron_grace_seconds)
        except Exception:
            grace = 600
        out = []
        fc_cache: dict = {}
        for row in candidates:
            feed_id = row.get("feed_config_id")
            try:
                fc = fc_cache.get(feed_id)
                if fc is None:
                    fc = self._db.get_feed_config(int(feed_id)) or {}
                    fc_cache[feed_id] = fc
                if cron_owned(fc) and not cron_fire_passed(
                        fc, row, grace_seconds=grace):
                    result.skipped_cron_owned += 1
                    continue
            except Exception as exc:
                logger.debug("[queue_worker] cron-ownership check failed "
                             "for feed_run %s: %s — keeping it claimable",
                             row.get("id"), exc)
            out.append(row)
        return out

    # ── Internals ────────────────────────────────────────────────────

    def _claim_row(self, run_id: int) -> bool:
        """Atomic claim — delegates to the DB-level conditional update
        in ``claim_pending_feed_run``.  Returns False when another
        worker / pod beat us to the row.  Safe to call across pods
        (the UPDATE WHERE status='pending' returns rowcount=0 for
        already-claimed rows).
        """
        claimed = self._db.claim_pending_feed_run(run_id, claimed_by="queue_worker")
        return claimed is not None

    def _dispatch_async(self, run_id: int, feed_id: int) -> None:
        """Schedule the async execution as a non-blocking task.

        Priority order for the target loop:
          1. ``self._loop`` (caller-provided — e.g. FastAPI's main loop)
          2. The worker's dedicated background loop (lazy-initialized
             in a daemon thread the first time it's needed)
          3. ``asyncio.create_task`` if we happen to be on a running loop

        The transient ``run_until_complete`` fallback that was here
        before was a CORRECTNESS bug: when APScheduler invokes
        ``poll_once`` on a thread with no running loop, every claimed
        row was executed sequentially, blocking the scheduler thread
        for the duration of ``execute_feed``.  That defeated the
        ``max_concurrent`` contract and made the poll interval
        unreliable.  The dedicated-loop path below makes dispatch
        truly fire-and-forget regardless of caller context.
        """
        coro = self._run_one(run_id, feed_id)
        # BF-591: every scheduling path now guarded — if any raises, the
        # exception propagates to the caller (poll_once) which resets
        # the run_id back to pending so it isn't permanently stuck.
        if self._loop is not None:
            asyncio.run_coroutine_threadsafe(coro, self._loop)
            return
        try:
            # BF-590: must keep a strong reference to the task or the
            # event loop's WeakSet may collect it mid-await
            # (Python issue #88831).  Discard via done callback so the
            # set doesn't grow without bound.
            # BF-591: separate task set so inflight_count remains the
            # count of in-flight RUNS, not run_ids + tasks.
            _t = asyncio.create_task(coro)
            self._inflight_tasks.add(_t)
            _t.add_done_callback(self._inflight_tasks.discard)
            return
        except RuntimeError:
            pass
        loop = self._ensure_background_loop()
        asyncio.run_coroutine_threadsafe(coro, loop)

    # Dedicated background loop running in a daemon thread.  Per-instance
    # so each FeedRunQueueWorker has its own; the singletons in
    # scheduler.py / feed_api.py share one across ticks.
    _bg_loop: Optional[asyncio.AbstractEventLoop] = None
    _bg_thread: Optional[threading.Thread] = None
    _bg_lock = None  # threading.Lock created lazily to keep dataclass-free

    def _ensure_background_loop(self) -> asyncio.AbstractEventLoop:
        if self._bg_loop is not None and self._bg_loop.is_running():
            return self._bg_loop
        if self._bg_lock is None:
            self._bg_lock = threading.Lock()
        with self._bg_lock:
            if self._bg_loop is not None and self._bg_loop.is_running():
                return self._bg_loop
            loop = asyncio.new_event_loop()
            ready = threading.Event()

            def _runner():
                asyncio.set_event_loop(loop)
                ready.set()
                try:
                    loop.run_forever()
                finally:
                    try:
                        loop.close()
                    except Exception:
                        pass

            thread = threading.Thread(
                target=_runner,
                name="feed-queue-worker-loop",
                daemon=True,
            )
            thread.start()
            ready.wait(timeout=5.0)
            self._bg_loop = loop
            self._bg_thread = thread
            return loop

    # ── Foundation C: per-connection concurrency slots ────────────────

    @property
    def pod_id(self) -> str:
        """Who holds a claim.  A claim without an owner cannot be reclaimed
        when its holder dies, which is the whole point of the heartbeat."""
        import os
        import socket
        return (os.environ.get("HOSTNAME")
                or os.environ.get("POD_NAME")
                or f"{socket.gethostname()}:{os.getpid()}")

    def _acquire_slots(self, run_id: int, feed_id: int, row: dict,
                       result) -> bool:
        """Take a slot on every connection this run touches, or none.

        Returns True when the run may proceed.  FAILS OPEN on an internal
        error — an accounting failure must not become an outage — but never
        silently: an unbudgeted run is logged with the reason, because
        "the budget is not being enforced" and "the budget is fine" look
        identical from the outside.
        """
        try:
            from core.feed import claims as _claims
            from core.feed.connection_set import resolve_connection_set

            cfg = self._db.get_feed_config(feed_id) or {}
            cset = resolve_connection_set(cfg, dao=self._db)
            if not cset.connection_ids:
                # Nothing budgeted to take.  Not an error: a local-only feed
                # with no registered source genuinely touches no connection.
                return True
            decision = _claims.acquire(
                self._db, run_id=run_id,
                connection_ids=list(cset.connection_ids),
                pod_id=self.pod_id,
                priority=row.get("priority"),
                waiting_since=row.get("created_at"),
                feed_config_id=feed_id)
            if not getattr(decision, "granted", True):
                result.skipped_pool_full += 1
                logger.info(
                    "[queue_worker] feed_run %s waits — %s",
                    run_id, getattr(decision, "reason", "no free slot"))
                return False
            # Remember that this run holds real claims, so the in-flight
            # heartbeat (FR-RUN-08) knows to beat on them.
            self._runs_holding_claims.add(run_id)
            return True
        except Exception as exc:
            logger.error(
                "[queue_worker] could not budget feed_run %s (%s) — admitting "
                "it UNBUDGETED rather than stalling the queue.  Per-source "
                "concurrency is NOT being enforced for this run.",
                run_id, exc)
            return True

    def _release_slots(self, run_id: int) -> None:
        """Give the slots back.  Best-effort and never raises: a release
        failure must not mask the outcome of the run itself, and the
        heartbeat reaper is the backstop."""
        try:
            self._runs_holding_claims.discard(run_id)
            from core.feed import claims as _claims
            _claims.release(self._db, run_id=run_id, pod_id=self.pod_id)
        except Exception as exc:
            logger.warning(
                "[queue_worker] could not release slots for feed_run %s (%s) "
                "— the stale-claim reaper will reclaim them", run_id, exc)

    # ── 2026-10-10 — REFILL ON COMPLETION ─────────────────────────────
    #
    # Found live by scripts/docker_proof/monthly_kafka_merge_feeds_proof.py
    # (the owner's case: 4,000 Kafka-gated feeds released together at
    # month-end).  50 runs released at once, each ~1 s of work, took 514 s:
    # poll_once claimed up to the free slots only when the 30 s APScheduler
    # tick fired, a finishing run freed its slot and nothing asked for more
    # work, so 50 / 3 slots = 17 rounds x 30 s.  The configured concurrency
    # sat ~97% idle under a backlog -- at 4,000 feeds, ~11 hours.
    #
    # THE DECISION, once: a completion that freed a slot REQUESTS a refill;
    # the refill IS poll_once (same atomic claim, same drain / shard /
    # cron-ownership / WAIT / budget gates -- never a second claim path),
    # run on the worker's own refill thread (never on the event loop, which
    # is where the completion fires) and serialised with the tick and the
    # admin poll-now by _poll_lock.  It is requested only while the LAST
    # poll recorded a backlog (claimable rows this pod had no slot for):
    # that is what "while claimable rows exist" means here, and it is what
    # bounds the chain -- a refill that finds nothing records backlog 0 and
    # the completions after it request nothing.  The 30 s tick remains the
    # safety net for a backlog that appears between polls.
    # Kill switch: feed_generation.queue_refill_on_completion (default true).

    def _refill_enabled(self) -> bool:
        if self._refill_on_completion_override is not None:
            return bool(self._refill_on_completion_override)
        try:
            from core.config import feed_generation as _fg
            return bool(_fg.queue_refill_on_completion)
        except Exception as exc:
            # An unreadable config is a reason, not a silent "off": the
            # default ships on, so behave as the default and say why.
            logger.debug("[queue_worker] refill kill switch unreadable (%s) "
                         "-- defaulting to on", exc)
            return True

    def _request_refill(self, run_id: int) -> bool:
        """A run freed a slot: wake the refill thread if there is a reason
        to.  Returns True when a refill was requested or is already
        pending.  Never raises -- it runs in _run_one's finally."""
        try:
            with self._refill_lock:
                if self._closed:
                    return False
                if not self._refill_enabled():
                    self._refill_stats["skipped_disabled"] += 1
                    return False
                if self._draining:
                    self._refill_stats["skipped_draining"] += 1
                    return False
                if self._backlog_seen <= 0:
                    self._refill_stats["skipped_no_backlog"] += 1
                    return False
                self._refill_stats["requested"] += 1
                self._refill_stats["last_requested_at"] = (
                    datetime.now(timezone.utc).isoformat())
                if self._refill_wake.is_set():
                    # A refill is already pending behind the poll in
                    # progress -- this completion rides it (coalesced).
                    self._refill_stats["coalesced"] += 1
                    return True
                self._refill_wake.set()
                self._ensure_refill_thread()
                return True
        except Exception as exc:
            logger.warning("[queue_worker] could not request a refill after "
                           "feed_run %s (%s) -- the tick remains the safety "
                           "net", run_id, exc)
            return False

    def _ensure_refill_thread(self) -> None:
        """Called under _refill_lock."""
        t = self._refill_thread
        if t is not None and t.is_alive():
            return
        t = threading.Thread(target=self._refill_loop,
                             name="feed-queue-worker-refill", daemon=True)
        self._refill_thread = t
        t.start()

    def _refill_loop(self) -> None:
        """ONE thread per worker: wait for a wake, poll ONCE, wait again.
        Bounded by construction -- every pass is paid for by a completion
        that found a backlog, and a pass that finds nothing clears it."""
        wake, stop = self._refill_wake, self._refill_stop
        while not stop.is_set():
            if not wake.wait(timeout=1.0):
                continue
            if stop.is_set():
                return
            self._refill_once()

    def _refill_once(self) -> None:
        """One refill pass = ONE poll_once under the poll lock.

        The wake is cleared INSIDE the lock, just before the poll reads the
        queue: every completion that landed while this pass waited for a
        tick to finish is answered by this very poll (it will see their
        freed slots), so they are coalesced into it rather than earning a
        second pass.  A completion landing DURING the poll sets the wake
        again and earns exactly one more pass -- the one that will see the
        slot it freed."""
        try:
            with self._poll_lock:
                self._refill_wake.clear()
                if self._refill_stop.is_set():
                    return
                result = self._poll_once_locked(None, POLL_TRIGGER_REFILL)
            maybe_gc_worker_health(self._db)
            with self._refill_lock:
                self._refill_stats["polls"] += 1
                self._refill_stats["claimed"] += int(result.claimed)
                self._refill_stats["last_poll_at"] = (
                    datetime.now(timezone.utc).isoformat())
            if result.claimed > 0 or result.errors > 0:
                logger.info("[queue_worker] refill %s", result.to_dict())
        except Exception as exc:
            with self._refill_lock:
                self._refill_stats["errors"] += 1
            logger.warning("[queue_worker] refill poll failed: %s -- the "
                           "%s tick remains the safety net", exc,
                           "queue_poll_interval_seconds")

    def refill_stats(self) -> dict:
        """The refill counters, for the health row and the admin status."""
        with self._refill_lock:
            out = dict(self._refill_stats)
            out["backlog_seen"] = int(self._backlog_seen)
            out["enabled"] = self._refill_enabled()
            t = self._refill_thread
            out["thread_alive"] = bool(t is not None and t.is_alive())
            return out

    # ── FR-RUN-08 — beat while the run is alive ───────────────────────
    #
    # 2026-09-02.  Every heartbeat primitive (claims.heartbeat,
    # heartbeat_feed_run, heartbeat_feed_execution) existed, tested, with
    # ZERO production callers — while the scheduler's sweeper reset any
    # run older than ``stale_running_reclaim_seconds`` (1 h) on AGE
    # alone.  A healthy 90-minute extract was flipped back to pending
    # WHILE STILL RUNNING, a second worker claimed it, and the same feed
    # delivered TWICE — the exact failure this platform exists to
    # prevent.  These methods are the missing callers: the worker beats
    # on its in-flight runs on a cadence comfortably shorter than the
    # reap threshold, and the sweeper (core/scheduler.py) now reaps on
    # the HEARTBEAT, never age alone.

    def _heartbeat_interval_seconds(self) -> float:
        """Beat cadence.  Derived from the reap threshold (1/6 of it,
        clamped to [15, 300] s) so the two knobs cannot drift into
        "beats slower than the reaper".  A disabled sweeper
        (threshold <= 0) still beats at the default-threshold cadence —
        beating with no reaper is harmless; NOT beating and later
        re-enabling the reaper is a self-inflicted reap."""
        if self._heartbeat_interval_override is not None:
            return float(self._heartbeat_interval_override)
        return heartbeat_interval_seconds()

    def _beat_once(self, run_id: int, feed_id: int,
                   exec_id: Optional[int] = None) -> tuple:
        """One heartbeat pass for an in-flight run.

        Returns ``(alive, exec_id)``.  Two failures that must never look
        alike (they demand opposite responses):

        * a failed WRITE (db hiccup) — WARNING, ``alive=True``, retried
          next interval.  A beat that fails must not kill the run.
        * a LOST claim (the row is no longer running-and-ours — reaped,
          or claimed by another pod) — ERROR naming the finding,
          ``alive=False``, beating stops.  The in-flight execution is
          deliberately NOT cancelled here: aborting a delivery mid-put
          risks a partial file, and our failure-sync would trample the
          new owner's row.  The log line is the duplicate-run alarm.
        """
        # 1) Connection claims — only when this run actually holds any.
        self._beat_claims(run_id)
        # 2) The run row — the decider.
        try:
            landed = self._db.heartbeat_feed_run(run_id,
                                                 owned_by="queue_worker")
        except Exception as exc:
            logger.warning(
                "[queue_worker] run heartbeat WRITE failed for feed_run %s "
                "(%s) — retried next interval; the run continues",
                run_id, exc)
            return True, exec_id
        if not landed:
            # Not a write failure — the row is no longer running-and-ours.
            # Distinguish a normal completion race (execute_feed already
            # flipped the row terminal; the cancel in _run_one's finally
            # just hasn't fired yet) from a genuinely LOST claim.
            status = None
            try:
                status = (self._db.get_feed_run(run_id) or {}).get("status")
            except Exception:
                pass
            if status in ("completed", "failed", "skipped", "cancelled"):
                logger.debug(
                    "[queue_worker] heartbeat for feed_run %s raced its "
                    "completion (status=%r) — normal shutdown of the beat",
                    run_id, status)
                return False, exec_id
            logger.error(
                "[queue_worker] feed_run %s LOST its claim mid-run (row "
                "status=%r — reaped, or claimed by another pod).  This pod "
                "does NOT cancel the in-flight execution (aborting a "
                "delivery mid-put risks a partial file and our failure-sync "
                "would trample the new owner's row) but it has stopped "
                "beating; investigate for a concurrent duplicate.",
                run_id, status)
            return False, exec_id
        # 3) The execution row.
        return True, self._beat_execution(run_id, feed_id, exec_id)

    def _beat_claims(self, run_id: int) -> None:
        """Beat on the run's connection claims (step 1 of _beat_once)."""
        if run_id not in self._runs_holding_claims:
            return
        try:
            from core.feed import claims as _claims
            if not _claims.heartbeat(self._db, run_id=run_id,
                                     pod_id=self.pod_id):
                # Claims GONE (reaped/released elsewhere) — a finding,
                # already logged loudly by claims.heartbeat.  Stop beating
                # claims; the run-row beat is the decider for the run.
                self._runs_holding_claims.discard(run_id)
        except Exception as exc:
            logger.warning(
                "[queue_worker] claim heartbeat WRITE failed for feed_run "
                "%s (%s) — retried next interval; the run continues",
                run_id, exc)

    def _beat_execution(self, run_id: int, feed_id: int,
                        exec_id: Optional[int]) -> Optional[int]:
        """Beat on the feed's active execution row (step 3 of _beat_once).

        Created by execute_feed a moment after dispatch, so it is
        resolved lazily; at most one is active per feed (partial unique
        index).  Returns the exec_id to use next beat."""
        try:
            if exec_id is None:
                ex = self._db.get_active_feed_execution(feed_id)
                if ex:
                    exec_id = int(ex["id"])
            if exec_id is not None and not self._db.heartbeat_feed_execution(
                    exec_id):
                # Went terminal (normal near completion) — re-resolve on
                # the next beat rather than beating a dead row.
                exec_id = None
        except Exception as exc:
            logger.debug(
                "[queue_worker] execution heartbeat failed for feed_run %s "
                "(%s) — retried next interval", run_id, exc)
        return exec_id

    async def _heartbeat_loop(self, run_id: int, feed_id: int) -> None:
        """Beat until cancelled (run finished) or the claim is lost."""
        interval = self._heartbeat_interval_seconds()
        if interval <= 0:
            return
        exec_id: Optional[int] = None
        while True:
            await asyncio.sleep(interval)
            alive, exec_id = self._beat_once(run_id, feed_id, exec_id)
            if not alive:
                return

    def held_run_ids(self) -> set:
        """The runs this worker is executing right now (a copy)."""
        return set(self._inflight_run_ids)

    @property
    def draining(self) -> bool:
        """True once ``drain``/``begin_drain`` has been called."""
        return self._draining

    def begin_drain(self) -> None:
        """Stop claiming new work.  Idempotent, and safe to call from a signal
        handler: it sets one flag and logs."""
        if self._draining:
            return
        self._draining = True
        logger.warning(
            "[queue_worker] DRAINING — no new claims; %d run(s) still held: %s",
            len(self._inflight_run_ids), sorted(self._inflight_run_ids),
        )

    def resume(self) -> None:
        """Leave drain mode (an aborted deploy, or an operator changing their
        mind).  Without this, ``begin_drain`` would be a one-way door that
        needs a restart to undo."""
        if not self._draining:
            return
        self._draining = False
        logger.warning("[queue_worker] drain CANCELLED — claiming resumed")

    def drain(self, timeout_seconds: float = 60.0,
              poll_interval: float = 0.25) -> set:
        """Stop claiming, then wait for held runs to finish.

        2026-09-02 (D4).  ``shutdown`` used to stop the loop and join with a
        2-second timeout and no drain at all, so a rolling deployment at 22:00
        -- exactly when a platform team would choose to deploy -- abandoned
        every claimed run mid-flight.  They stayed 'running' with orphaned
        partial output until something swept them.

        Returns the run ids STILL held when the deadline passed (empty on a
        clean drain).  Those are deliberately NOT flipped back to pending
        here: this worker's tasks may still be mid-SFTP-put, and a run
        released while its delivery is in flight can be claimed by another pod
        and delivered TWICE -- the worst outcome this system has.  The
        existing stale-run reclaimer owns that case; it is keyed on the
        claiming pod having stopped, which is exactly the condition that makes
        a release safe.
        """
        self.begin_drain()
        deadline = time.monotonic() + max(0.0, float(timeout_seconds))
        while self._inflight_run_ids and time.monotonic() < deadline:
            time.sleep(poll_interval)
        held = set(self._inflight_run_ids)
        if held:
            logger.error(
                "[queue_worker] drain deadline (%.0fs) passed with %d run(s) "
                "still held: %s.  Left claimed on purpose -- releasing a run "
                "whose delivery may be in flight risks a DUPLICATE delivery; "
                "the stale-run reclaimer will recover them once this pod is "
                "gone.", float(timeout_seconds), len(held), sorted(held),
            )
        else:
            logger.info("[queue_worker] drained cleanly — nothing held")
        return held

    def shutdown(self, drain_timeout_seconds: float = 0.0) -> None:
        """Stop the background loop thread (test/admin teardown).

        ``drain_timeout_seconds > 0`` drains first (see ``drain``).  It
        defaults to 0 so existing callers -- test teardown, admin restart --
        keep today's immediate behaviour; the deployment path passes a real
        budget.
        """
        if drain_timeout_seconds > 0:
            self.drain(timeout_seconds=drain_timeout_seconds)
        # Refill first: a refill landing after the loop below is stopped
        # would start a NEW background loop for a worker being torn down.
        with self._refill_lock:
            self._closed = True
            self._refill_stop.set()
            self._refill_wake.set()
            rt = self._refill_thread
        if rt is not None and rt.is_alive() and rt is not threading.current_thread():
            rt.join(timeout=2.0)
        loop = self._bg_loop
        thread = self._bg_thread
        if loop is not None and loop.is_running():
            try:
                loop.call_soon_threadsafe(loop.stop)
            except Exception:
                pass
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)
        self._bg_loop = None
        self._bg_thread = None

    def _rerun_kwargs(self, run_id: int) -> dict:
        """2026-10-12 -- an operator's RE-RUN is re-queued, not executed in
        the API (api/feed_api.py::_requeue_for_rerun); THIS worker executes
        it, so it carries what the operator asked: the trigger and the
        person, the lane (``rerun_backend``) and the stored parameter
        overrides.  Any other run: nothing (the defaults stand)."""
        try:
            row = self._db.get_feed_run(int(run_id)) or {}
        except Exception as exc:                 # noqa: BLE001 -- the run still runs
            logger.warning("[queue_worker] feed_run %s unreadable for its re-run "
                           "choices (%s) -- run with the defaults", run_id, exc)
            return {}
        # a RESTATEMENT (core/feed/restatement.py) is a re-run the upstream
        # asked for: the same choices, its own trigger word on the record
        trig = str(row.get("triggered_by") or "")
        if trig not in ("rerun", "restatement"):
            return {}
        out: dict = {"trigger_type": trig,
                     "triggered_by": row.get("triggered_by_user") or trig}
        if row.get("rerun_backend"):
            out["backend_override"] = row["rerun_backend"]
        if row.get("consumer_overrides"):
            out["query_param_overrides"] = row["consumer_overrides"]
        if isinstance(row.get("rerun_reuse"), dict):
            out["reuse_side"] = row["rerun_reuse"]     # verified again by the engine
        return out

    async def _run_one(self, run_id: int, feed_id: int) -> None:
        """Execute one feed; sync feed_runs.status on success / failure.

        execute_feed (with feed_run_id passed) handles status sync
        for the running -> completed/failed transitions.  We only
        defend against execute_feed throwing before it gets to its
        own exception handler.
        """
        # FR-RUN-08 — beat while the run is alive, on the same loop the
        # execution runs on.  Without this, the sweeper's reap threshold
        # is a hard cap on run duration: at threshold+1s the row went
        # back to pending, a second worker claimed it, and the feed
        # delivered twice.  A beat-start failure must not stop the run —
        # the run merely re-enters the pre-heartbeat risk it always had.
        beat_task = None
        try:
            beat_task = asyncio.create_task(
                self._heartbeat_loop(run_id, feed_id))
        except Exception as _bt_exc:
            logger.warning(
                "[queue_worker] could not start the heartbeat for feed_run "
                "%s (%s) — the run proceeds UNBEATEN and risks the orphan "
                "reaper if it outlives the threshold", run_id, _bt_exc)
        try:
            _kwargs = dict(
                trigger_type="queue",
                triggered_by="queue_worker",
                feed_run_id=run_id,
            )
            _kwargs.update(self._rerun_kwargs(run_id))
            if self._feed_deps is not None:
                # real execute_feed: hand it this worker's db explicitly
                _kwargs["deps"] = self._feed_deps
            _res = await self._execute_feed_fn(feed_id, **_kwargs)
            # Phase 4 (2026-08-23): execute_feed can decline WITHOUT
            # raising — {"status": "skipped", "reason": "already_executing"}
            # when another execution (e.g. a manual UI run) holds the
            # feed's single active slot.  Before, the claim was simply
            # kept: the row sat 'running' with NO owner until the 1-hour
            # stale reclaim — a phantom run on the today page.  Release
            # the claim (conditionally — only if we still own it) so the
            # next tick retries.  Other skip reasons (backend_override=
            # halt) sync the row themselves inside execute_feed.
            if (isinstance(_res, dict)
                    and _res.get("status") == "skipped"
                    and _res.get("reason") == "already_executing"):
                try:
                    self._db.reset_feed_run_to_pending_if_owned(
                        run_id, owned_by="queue_worker")
                    logger.info(
                        "[queue_worker] feed_run %s released back to "
                        "pending — feed %s already has an active "
                        "execution elsewhere", run_id, feed_id)
                except Exception as _rel_exc:
                    logger.warning(
                        "[queue_worker] could not release feed_run %s "
                        "after already_executing skip: %s", run_id, _rel_exc)
        except Exception as exc:
            err = str(exc)[:1000]
            logger.warning(
                "[queue_worker] feed_run %s (feed=%s) crashed: %s",
                run_id, feed_id, err,
            )
            # execute_feed's own except branch should have already
            # marked the run failed; this is the last-resort sync.
            try:
                self._db.update_feed_run(run_id, {
                    "status": "failed",
                    "completed_at": datetime.now(timezone.utc),
                    "error": err,
                })
            except Exception:
                pass
        finally:
            # Stop beating FIRST — a beat landing after the release below
            # would resurrect heartbeat_at on a row we no longer own.
            if beat_task is not None:
                beat_task.cancel()
            # BF-591: split-set rename — was _inflight (combined).
            with self._inflight_lock:
                freed_slot = run_id in self._inflight_run_ids
                self._inflight_run_ids.discard(run_id)
            # Foundation C — release on EVERY exit path.  A slot held
            # by a finished run starves the source until the reaper
            # notices, and the reaper is a safety net, not the
            # mechanism.
            self._release_slots(run_id)
            self._memory.release(run_id)
            # 2026-10-10 — a freed slot asks for more work NOW (see
            # _request_refill); a run that held no slot here freed none.
            if freed_slot:
                self._request_refill(run_id)


# ── Process-wide singleton ────────────────────────────────────────────────
#
# Both the APScheduler-driven tick and the admin `/poll-now` endpoint
# share this instance so the ``_inflight`` set bounds concurrency across
# trigger sources.  Reconstructing the worker per tick (the original
# pattern) silently broke ``max_concurrent`` — the new tick started
# with an empty ``_inflight`` and could over-fill the pool.

_shared_worker: Optional[FeedRunQueueWorker] = None
_shared_worker_lock = threading.Lock()


#: The APScheduler job id for the queue worker, in ONE place.  The config
#: path and the admin route both register it, and two spellings would let a
#: pod run two workers polling the same rows.
QUEUE_WORKER_JOB_ID = "__feed_queue_worker__"


def queue_worker_tick(max_concurrent: int = 0) -> None:
    """One poll of the feed-run queue.  MODULE-LEVEL, and that is the point.

    2026-09-17 (FB-3) -- ``POST /api/admin/feeds/queue-worker/start`` passed a
    LOCAL CLOSURE to ``add_job``::

        ValueError: This Job cannot be serialized since the reference to its
        callable (<function queue_worker_start.<locals>._tick>) could not be
        determined. Consider giving a textual reference (module:function
        name) instead.

    APScheduler with a persistent jobstore has to serialize the callable, and
    a closure has no importable reference.  The route landed the job in the
    DEFAULT (Postgres) jobstore while the config path used the in-memory
    ``daemon`` store, so the same closure pattern worked in one place and 500'd
    in the other -- and the failure happened AT ``add_job``, so the
    ``_audit("feed_queue_worker_started")`` line below it never ran either.
    The attempt was not even recorded.

    It stayed hidden because ``poll-now`` works perfectly: it calls the worker
    DIRECTLY, with no scheduler involved, so every manual test passed and only
    the SCHEDULED worker was dead -- on a deployment that relies on the admin
    control, feed runs then sit pending for ever.  The consumer-presence probe
    reported exactly that state and told the operator to press the button that
    500s.

    ``max_concurrent`` of 0 means "read it from config", so the stored job
    carries no snapshot of a value an operator may since have changed.
    """
    db = None
    try:
        from core.database import get_db_manager
        db = get_db_manager()
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[queue_worker] no db manager: %s", exc)
        return
    if db is None:
        return
    try:
        if not max_concurrent:
            from core.config import feed_generation as _fg
            max_concurrent = int(_fg.max_concurrent_native)
    except Exception:                                       # noqa: BLE001
        max_concurrent = max_concurrent or 3
    try:
        worker = get_shared_queue_worker(db, max_concurrent=max_concurrent)
        result = worker.poll_once()
        if result.claimed > 0 or result.errors > 0:
            logger.info("[queue_worker] %s", result.to_dict())
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[queue_worker] tick failed: %s", exc)


def note_run_lane(run_id: Optional[int], backend: str) -> None:
    """For the engine: the run's lane is decided -- a lane whose work runs
    elsewhere frees this pod's memory reservation (never raises)."""
    if run_id is None:
        return
    try:
        w = peek_shared_queue_worker()
        if w is not None:
            w.note_lane(int(run_id), backend)
    except Exception as exc:                                # noqa: BLE001 -- advisory
        logger.debug("[queue_worker] note_run_lane(%s, %s) failed: %s", run_id, backend, exc)


def memory_bounded_slots(requested: int) -> int:
    """How many feed runs this pod may run at once: the configured number,
    THROTTLED by the pod's memory (2026-10-14).

    ``feed_generation.native_memory_per_run_mb`` is what one heavy run may
    need; a pod whose cgroup holds less than ``requested`` of them runs fewer
    (never fewer than one).  Found live: three 460-column feeds claimed
    together by a 2 GB scheduler, which the kernel then killed -- all three
    runs lost and left "running" until the stale-claim reclaim.  A cap
    THROTTLES: the runs it holds back stay pending and are claimed as slots
    free up.  No cgroup limit (a dev box) or 0 = the configured number."""
    try:
        requested = max(1, int(requested))
    except (TypeError, ValueError):
        requested = 1
    try:
        from core.config import feed_generation as _fg
        per_run_mb = int(_fg.native_memory_per_run_mb)
        if per_run_mb <= 0:
            return requested
        from core.duckdb_resource_limits import _read_cgroup_memory_limit_bytes
        budget = _read_cgroup_memory_limit_bytes()
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[queue_worker] memory bound not applied (%s); "
                       "running up to %d feed(s) at once", exc, requested)
        return requested
    if not budget or budget <= 0:
        return requested
    fits = max(1, int(budget // (per_run_mb * 1024 * 1024)))
    if fits < requested:
        logger.warning(
            "[queue_worker] this pod runs at most %d feed(s) at once, not %d: "
            "its memory (%.1f GB) holds %d run(s) of "
            "feed_generation.native_memory_per_run_mb=%d. Other ready runs wait "
            "for a free slot. Give the pod more memory to run more at once.",
            fits, requested, budget / 1024 ** 3, fits, per_run_mb)
        return fits
    return requested


def get_shared_queue_worker(
    db,
    *,
    max_concurrent: int = 3,
    execute_feed_fn: Optional[Callable] = None,
    shard: Optional[str] = None,
) -> FeedRunQueueWorker:
    """Return the process-wide ``FeedRunQueueWorker`` instance.

    On first call constructs the worker; subsequent calls return the
    same instance.  ``max_concurrent`` + ``shard`` are honoured only on
    the first call — a later caller cannot resize / re-shard an in-use
    worker (changing that would race with the live ``_inflight`` set).

    Default shard pulls from env ``QUERYSTUDIO_FEED_SHARD`` so the same
    code runs in single-shard dev and multi-pod prod without callers
    needing to know.
    """
    global _shared_worker
    if _shared_worker is not None:
        return _shared_worker
    with _shared_worker_lock:
        if _shared_worker is None:
            if shard is None:
                import os
                shard = os.environ.get("QUERYSTUDIO_FEED_SHARD") or None
            from core.feed.run_memory import MemoryLedger
            _shared_worker = FeedRunQueueWorker(
                db,
                max_concurrent=memory_bounded_slots(max_concurrent),
                execute_feed_fn=execute_feed_fn,
                shard=shard,
                memory_ledger=MemoryLedger.for_this_pod(),
            )
        return _shared_worker


def heartbeat_interval_seconds() -> float:
    """Beat cadence (1/6 of ``feed_generation.stale_running_reclaim_seconds``,
    clamped to [15, 300] s) -- see ``FeedRunQueueWorker._heartbeat_interval_seconds``."""
    try:
        from core.config import feed_generation as _fg
        threshold = int(_fg.stale_running_reclaim_seconds)
    except Exception:
        threshold = 3600
    if threshold <= 0:
        threshold = 3600
    return max(15.0, min(300.0, threshold / 6.0))


def this_pod_id() -> str:
    """The pod id a claim is held under (``FeedRunQueueWorker.pod_id``)."""
    import os
    import socket
    return (os.environ.get("HOSTNAME") or os.environ.get("POD_NAME")
            or f"{socket.gethostname()}:{os.getpid()}")


#: ONE reap of the previous process's runs per process (any road)
_PREVIOUS_PROCESS_REAP: Dict[str, Any] = {"scheduled": False, "done": False, "result": None}
_PREVIOUS_PROCESS_REAP_LOCK = threading.Lock()


def reap_previous_process_now(db, pod_id: str, born_utc,
                              record: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, int]]:
    """Free the runs a PREVIOUS process on ``pod_id`` left running (claimed
    before ``born_utc``, not beaten since) -- ``mixin_feeds.
    reap_runs_of_a_dead_process``.  Once per process; the result is kept.

    ``record``: the once-per-process record to use -- the one that was
    current when the reap was SCHEDULED (``schedule_previous_process_reap``
    hands it over), so a delayed reap writes the record it belongs to, never
    one installed after it (found in the CI replica: a test's delayed thread
    marked the NEXT test's fresh record done with its own fake result)."""
    rec = _PREVIOUS_PROCESS_REAP if record is None else record
    with _PREVIOUS_PROCESS_REAP_LOCK:
        if rec["done"]:
            return rec["result"]
        rec["done"] = True
    fn = getattr(db, "reap_runs_of_a_dead_process", None)
    if fn is None:
        return None
    try:
        out = fn(pod_id, born_utc)
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[queue_worker] could not free a previous process's runs "
                       "(%s) -- the heartbeat reaper frees them later", exc)
        return None
    rec["result"] = out
    if any(out.values()):
        logger.warning("[queue_worker] freed what a previous process on this pod "
                       "left running (it was restarted or killed): %s", out)
    return out


def schedule_previous_process_reap(db, *, delay_seconds: Optional[float] = None) -> bool:
    """Every backend process frees what ITS pod's previous process left
    running -- whether or not it ever polls the queue (2026-10-27).

    Found live: the rig's API container (a hybrid that had held the
    scheduler lock and run the feed) was killed and started again under
    the same hostname; the lock moved to the scheduler container, whose
    queue worker reaps only ITS OWN pod's claims, and the API's new process
    never polled -- so the killed run stayed "running" under a dead claim for
    the heartbeat reaper's hour, blocking its feed (the sibling SOD run was
    claimed every tick and released: "already has an active execution
    elsewhere").  The rule is the pod's, not the lease's: a thread started at
    process start waits one beat interval x 1.5 + 30 s (any live process on
    this pod beats at least that often) and reaps once.  Idempotent per
    process; True when scheduled by this call."""
    rec = _PREVIOUS_PROCESS_REAP
    with _PREVIOUS_PROCESS_REAP_LOCK:
        if rec["scheduled"]:
            return False
        rec["scheduled"] = True
    from datetime import datetime as _dt, timezone as _tz
    born = _dt.now(_tz.utc).replace(tzinfo=None)
    pod = this_pod_id()
    wait = (heartbeat_interval_seconds() * 1.5 + 30) if delay_seconds is None else float(delay_seconds)

    def _later():
        import time as _t
        _t.sleep(max(0.0, wait))
        reap_previous_process_now(db, pod, born, record=rec)

    threading.Thread(target=_later, name="feed-previous-process-reap", daemon=True).start()
    logger.info("[queue_worker] this process (pod %s) will free what a previous process "
                "left running in %.0f s, lease or no lease", pod, wait)
    return True


def peek_shared_queue_worker() -> Optional[FeedRunQueueWorker]:
    """The process-wide worker IF one exists, else None -- for a status
    route that must not construct a worker on a pod that runs none."""
    return _shared_worker


def reset_shared_queue_worker() -> None:
    """Drop the singleton (tests + admin reset).  Stops its background
    loop thread so the daemon doesn't outlive the process needlessly."""
    global _shared_worker
    with _shared_worker_lock:
        if _shared_worker is not None:
            try:
                _shared_worker.shutdown()
            except Exception:
                pass
            _shared_worker = None
