"""The DEPENDENCY + SLA TRACKER for one business date (2026-10-25, owner request).

The owner: "feed gen still doesnt show how many dependencies arrived or
pending ... we need a nice dashboard to track where the dependencies are ...
sla tracker ... on Feed Run Status only ... interactive ... each feed wise".

One answer for the date, three views of it:

* ``summary`` -- how many DISTINCT dependencies the date's feeds wait for and
  how many have ARRIVED / are WAITING / were SKIPPED / NOT EXPECTED / COULD
  NOT TELL; how many feeds have everything, how many still wait.
* ``dependencies`` -- one row per dependency: its state, when it arrived (or
  when it usually does and the decision deadline -- the SLA watcher's own
  clocks), the roads it arrives by, and the feeds waiting on it with the
  tightest SLA among them.  Waiting rows with the nearest deadline first.
* ``feeds`` -- one row per feed task: its dependencies arrived / total, what
  it still waits on, and its SLA verdict.

Nothing is decided twice here: a dependency's state is THE gate's verdict
(``etl_dependency.evaluate_gate_verdicts``, the answer the poller, the board
row and Run Now read), the SLA verdict is THE SLA board's
(``sla_board.build``), the clocks are THE watcher's (``acting_time
.clocks_for_blocked`` + ``blocked_row``).  The gate is read ONCE per
dependency key set (``effective_etl_id``) -- 4,000 feeds of one template
that share a key set are one read.

Unknown is not empty: a feed whose gate could not be read is counted in
``summary.feeds_unreadable`` and carries ``deps_unavailable``; a section that
fails names itself in ``unavailable``.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: dependency states, in the words the board's tiles use (``depBadge``)
ARRIVED, WAITING, SKIPPED, NOT_EXPECTED, UNKNOWN = (
    "arrived", "waiting", "skipped", "not_expected", "could_not_tell")
STATES = (ARRIVED, WAITING, SKIPPED, NOT_EXPECTED, UNKNOWN)
#: how many feed names a dependency row carries (the count is always exact)
FEEDS_PER_DEPENDENCY = 200

_SLA_ORDER = {"breached": 0, "late": 1, "at_risk": 2, "on_track": 3, "invalid_sla": 4,
              "met": 5, "no_sla": 6, "not_due": 7}


def state_of(verdict: Optional[str], action: Optional[str]) -> str:
    """THE gate's verdict as one state (the board tile's rule, ``depBadge``)."""
    if str(action or "").upper() == "SKIP":
        return SKIPPED
    v = str(verdict or "").lower()
    if v == "met":
        return ARRIVED
    if v == "not_expected":
        return NOT_EXPECTED
    if v == "not_met":
        return WAITING
    return UNKNOWN


def _iso(v: Any) -> Optional[str]:
    if v is None:
        return None
    return v.isoformat() if hasattr(v, "isoformat") else str(v)


class _GateReader:
    """THE gate and the declared roads, read ONCE per dependency key set."""

    def __init__(self, db, business_date: date):
        self.db, self.business_date = db, business_date
        self.gates: Dict[int, tuple] = {}
        self._roads: Dict[int, Dict[str, list]] = {}

    def gate(self, etl_id: int) -> tuple:
        from core.feed.etl_dependency import evaluate_gate_verdicts
        if etl_id not in self.gates:
            try:
                self.gates[etl_id] = ("ok", evaluate_gate_verdicts(self.db, etl_id, self.business_date))
            except Exception as exc:                    # noqa: BLE001 -- said per feed
                self.gates[etl_id] = ("error", f"{type(exc).__name__}: {exc}"[:300])
        return self.gates[etl_id]

    def roads(self, etl_id: int) -> Dict[str, list]:
        if etl_id not in self._roads:
            out: Dict[str, list] = {}
            try:
                # the gate's own (active) mapping rows carry the declared
                # roads -- prefetched for the whole date
                for m in self.db.list_etl_dependency_mappings_with_tracking(etl_id, self.business_date) or []:
                    out[str(m.get("dependency_key"))] = [
                        {"kind": s.get("kind"), "topic": s.get("topic"), "table": s.get("table")}
                        for s in (m.get("arrival_sources") or []) if isinstance(s, dict)]
            except Exception:                           # noqa: BLE001 -- a row then names no road
                out = {}
            self._roads[etl_id] = out
        return self._roads[etl_id]


def _search(sla_rows: List[dict], feeds: Dict[int, dict], groups: Dict[int, Any], search: str) -> List[dict]:
    """The board's search: a feed name or its group's name."""
    q = (search or "").strip().lower()
    if not q:
        return sla_rows

    def matches(r):
        gid = (feeds.get(int(r["feed_id"])) or {}).get("feed_group_id")
        group = str(groups.get(int(gid)) or "").lower() if gid is not None else ""
        return q in str(r.get("feed_name") or "").lower() or q in group
    return [r for r in sla_rows if matches(r)]


def _feed_row(r: dict, f: dict, groups: Dict[int, Any]) -> Dict[str, Any]:
    gid = f.get("feed_group_id")
    return {"feed_id": int(r["feed_id"]), "feed_name": r.get("feed_name"), "run_id": r.get("run_id"),
            "group_id": gid, "group_name": groups.get(int(gid)) if gid else None,
            "run_status": r.get("run_status"), "action_decision": r.get("action_decision"),
            "sla": {k: r.get(k) for k in ("verdict", "sla_to", "sla_timezone", "deadline_utc",
                                           "minutes_vs_deadline", "alerted", "delivered_at")},
            "deps_total": 0, **dict.fromkeys(STATES, 0), "pending": 0, "waiting_on": [],
            "deps_unavailable": None}


def _new_dependency(v, st: str, roads: list) -> Dict[str, Any]:
    from core.feed.dashboard import _side
    name = v.dependency_name
    return {"dependency": name, "side": _side(name or ""), "state": st,
            "verdict": v.verdict, "action": v.action, "reason": v.reason,
            "asserted": bool(getattr(v, "asserted", False)),
            "arrived_at": _iso(v.last_seen) if st == ARRIVED else None,
            "last_seen": _iso(v.last_seen),
            "expected_rows": v.expected_rows, "reported_rows": v.reported_rows,
            "roads": roads, "feeds_total": 0, "feeds_waiting": 0, "feeds": [],
            "tightest_deadline_utc": None, "tightest_sla_feed": None, "worst_sla": None, "clocks": None}


def _add_feed(d: Dict[str, Any], r: dict, st: str) -> None:
    """One feed waiting (or not) on a dependency: its count, its SLA."""
    d["feeds_total"] += 1
    if st in (WAITING, UNKNOWN):
        d["feeds_waiting"] += 1
    if len(d["feeds"]) < FEEDS_PER_DEPENDENCY:
        d["feeds"].append({"feed_id": int(r["feed_id"]), "feed_name": r.get("feed_name"),
                           "run_status": r.get("run_status"), "sla_verdict": r.get("verdict"),
                           "deadline_utc": r.get("deadline_utc")})
    dl, verdict = r.get("deadline_utc"), r.get("verdict")
    open_sla = dl and verdict not in ("met", "late", "not_due")
    if open_sla and (d["tightest_deadline_utc"] is None or dl < d["tightest_deadline_utc"]):
        d["tightest_deadline_utc"], d["tightest_sla_feed"] = dl, r.get("feed_name")
    if r.get("run_date") and (d.get("run_date") is None or str(r["run_date"]) < str(d["run_date"])):
        d["run_date"] = str(r["run_date"])
    if verdict and _SLA_ORDER.get(verdict, 99) < _SLA_ORDER.get(d["worst_sla"] or "", 99):
        d["worst_sla"] = verdict


def _fold_feed(r: dict, f: dict, groups, reader: _GateReader, deps: Dict[str, dict]) -> Dict[str, Any]:
    """One task: its dependencies by THE gate, folded into the dependency rows."""
    from core.feed.etl_dependency import effective_etl_id
    row = _feed_row(r, f, groups)
    etl_id = int(effective_etl_id(f))
    kind, val = reader.gate(etl_id)
    if kind == "error":
        row["deps_unavailable"] = val
        return row
    if val is None:
        row["deps_unavailable"] = "the four-verdict gate module is absent"
        return row
    for v in list(getattr(val, "verdicts", None) or []):
        st = state_of(v.verdict, v.action)
        row["deps_total"] += 1
        row[st] += 1
        if st in (WAITING, UNKNOWN):
            row["pending"] += 1
            row["waiting_on"].append(v.dependency_name)
        d = deps.get(v.dependency_name)
        if d is None:
            d = deps[v.dependency_name] = _new_dependency(
                v, st, reader.roads(etl_id).get(str(v.dependency_name)) or [])
        _add_feed(d, r, st)
    return row


#: the clock fields every caller may see: the DEPENDENCY's own history
_CLOCKS_ANY = ("usual_by", "usual_by_at", "minutes_late", "observations")
#: fields computed over EVERY feed waiting on the dependency (the tightest SLA,
#: its feed's name in the summary, the ladder stage those deadlines set) -- a caller scoped to some feeds would read
#: a feed it may not view; kept only for a caller who sees every feed
_CLOCKS_ALL_FEEDS = ("stage", "severity", "summary", "decision_deadline", "warn_at", "sla_at")


def _apply_clocks(db, business_date: date, now: datetime, deps: Dict[str, dict],
                  scoped: bool = False) -> Optional[str]:
    """THE watcher's clocks (usual arrival, decision deadline) for what still blocks."""
    try:
        from core.feed.acting_time import blocked_row, clocks_for_blocked
        for item in clocks_for_blocked(db, business_date, now).blocked:
            d = deps.get(item.dependency_name)
            if d is not None:
                b = blocked_row(item, business_date=business_date, now=now)
                keys = _CLOCKS_ANY if scoped else _CLOCKS_ANY + _CLOCKS_ALL_FEEDS
                d["clocks"] = {k: b.get(k) for k in keys}
    except Exception as exc:                            # noqa: BLE001 -- costs the clocks only
        logger.warning("[dependency_tracker] clocks unreadable for %s: %s", business_date, exc)
        return f"clocks: {type(exc).__name__}: {exc}"
    return None


def _apply_delays(db, business_date: date, now: datetime, deps: Dict[str, dict]) -> None:
    """THE person rule (acting_time.person_delays) for what has not arrived:
    the tightest SLA among the feeds waiting on it, else its usual arrival."""
    from core.feed.acting_time import person_delays
    wanted = {n: {"sla_deadline": d.get("tightest_deadline_utc"), "run_date": d.get("run_date")}
              for n, d in deps.items() if d["state"] in (WAITING, UNKNOWN)}
    views = person_delays(db, wanted, business_date=business_date, now=now) if wanted else {}
    for n, v in views.items():
        deps[n]["delay"] = v


def _minutes_until(iso: Optional[str], now: datetime) -> Optional[int]:
    if not iso:
        return None
    try:
        return int((datetime.fromisoformat(iso.replace("Z", "+00:00")) - now).total_seconds() // 60)
    except ValueError:
        return None


def person_state(state: str, delayed: bool) -> str:
    """What a PERSON reads (the owner, 2026-10-25: "can be waiting, arrived or
    delayed"): arrived | waiting | delayed | skipped | not_expected.  "Could
    not tell" is not a state of the dependency -- it is waiting (or delayed),
    with ``cant_check`` saying QueryStudio could not read it."""
    if state in (WAITING, UNKNOWN):
        return "delayed" if delayed else "waiting"
    return state


def _finish_dependency(d: Dict[str, Any], now: datetime) -> None:
    d["minutes_to_deadline"] = _minutes_until(d["tightest_deadline_utc"], now)
    # THE delay rule (acting_time.person_delays): the SLA when one is
    # defined, else the usual arrival from history -- set by _apply_delays
    d["overdue"] = bool(d["state"] in (WAITING, UNKNOWN) and (d.get("delay") or {}).get("delayed"))
    d["person_state"] = person_state(d["state"], d["overdue"])
    d["cant_check"] = d.get("reason") if d["state"] == UNKNOWN else None


def _summary(deps: Dict[str, dict], feed_rows: List[dict]) -> Dict[str, int]:
    counts = {s: sum(1 for d in deps.values() if d["state"] == s) for s in STATES}
    with_deps = [x for x in feed_rows if x["deps_total"]]
    return {
        "feeds": len(feed_rows),
        "feeds_with_dependencies": len(with_deps),
        "feeds_all_arrived": sum(1 for x in with_deps if not x["pending"]),
        "feeds_waiting": sum(1 for x in with_deps if x["pending"]),
        "feeds_unreadable": sum(1 for x in feed_rows if x["deps_unavailable"]),
        "dependencies": len(deps),
        **counts,
        # NOT ARRIVED = waiting + could not tell (a Kafka-only dependency
        # whose listener cannot confirm absence says "could not tell")
        "pending": counts[WAITING] + counts[UNKNOWN],
        "overdue": sum(1 for d in deps.values() if d["overdue"]),
        # 2026-10-25 -- what a PERSON reads: waiting (not yet expected) and
        # delayed (past its SLA, or its usual arrival time when no SLA); how
        # many of them QueryStudio could not check right now
        "waiting_on_time": sum(1 for d in deps.values() if d.get("person_state") == "waiting"),
        "delayed": sum(1 for d in deps.values() if d.get("person_state") == "delayed"),
        "cant_check": counts[UNKNOWN],
    }


def build(db, business_date: date, *, visible_feed_ids: Optional[set] = None,
          now: Optional[datetime] = None, search: str = "") -> Dict[str, Any]:
    from core.feed import sla_board
    from core.feed.gate_prefetch import DatePrefetch
    now = now or datetime.now(timezone.utc)
    unavailable: List[str] = []
    # the date's tasks and their SLA verdicts: THE SLA board's answer
    sla = sla_board.build(db, business_date, visible_feed_ids=visible_feed_ids, now=now)
    sla_rows = sla.get("rows") or []
    feeds = db.get_feed_configs_by_ids([r["feed_id"] for r in sla_rows]) or {}
    groups: Dict[int, Any] = {}
    try:
        groups = {int(g["id"]): g.get("name") for g in (db.list_feed_groups() or [])}
    except Exception as exc:                            # noqa: BLE001 -- named, not hidden
        unavailable.append(f"feed_groups: {type(exc).__name__}: {exc}")
    from core.feed.etl_dependency import effective_etl_id
    rows = _search(sla_rows, feeds, groups, search)
    try:
        db = DatePrefetch(db, business_date,
                           {int(effective_etl_id(feeds.get(int(r["feed_id"])) or {"id": int(r["feed_id"])}))
                            for r in rows}, feeds)
    except Exception as exc:                            # noqa: BLE001 -- per-feed reads instead
        logger.warning("[dependency_tracker] prefetch unavailable, reading per feed: %s", exc)
    reader = _GateReader(db, business_date)
    deps: Dict[str, Dict[str, Any]] = {}
    feed_rows = [_fold_feed(r, feeds.get(int(r["feed_id"])) or {"id": int(r["feed_id"])}, groups, reader, deps)
                 for r in rows]
    problem = _apply_clocks(db, business_date, now, deps, scoped=visible_feed_ids is not None)
    if problem:
        unavailable.append(problem)
    _apply_delays(db, business_date, now, deps)
    for d in deps.values():
        _finish_dependency(d, now)
    dep_list = sorted(deps.values(), key=lambda d: (
        0 if d["state"] in (WAITING, UNKNOWN) else 1, 0 if d["overdue"] else 1,
        d["tightest_deadline_utc"] or "~", str(d["dependency"])))
    feed_rows.sort(key=lambda x: (
        0 if (x["pending"] or x["deps_unavailable"]) else 1,
        _SLA_ORDER.get(x["sla"]["verdict"] or "", 99), x["sla"]["deadline_utc"] or "~",
        str(x["feed_name"] or "")))
    return {"business_date": business_date.isoformat(), "now": now.isoformat(),
            "at_risk_minutes": sla.get("at_risk_minutes"),
            "summary": _summary(deps, feed_rows), "sla_counts": sla.get("counts") or {},
            "dependencies": dep_list, "feeds": feed_rows,
            "gate_reads": len(reader.gates), "unavailable": unavailable}
