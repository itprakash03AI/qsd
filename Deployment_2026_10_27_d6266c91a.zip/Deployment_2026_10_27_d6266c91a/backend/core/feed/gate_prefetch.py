"""ONE read of a business date for THE dependency gate (2026-10-25).

The gate (``etl_dependency.evaluate_gate_verdicts``) reads, per feed, its
mapping rows and, per dependency, the date's arrivals -- ~6 statements a feed,
and a feed may declare 500+ Kafka dependencies (the owner).  ``DatePrefetch``
answers those reads for a whole date from TWO statements (every key set's
mapping rows; every arrival of the date), plus the configs the caller read
and a system setting the sources ask per dependency.  The gate's code is
unchanged -- only where its rows come from.  Everything else passes through;
a key that was not prefetched reads the real database.

Shared by the Dependencies & SLA tracker, the Feed Run Status board's rows
and a task's dependency cards.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Dict, Optional


class DatePrefetch:
    """The database, with the two reads THE gate makes per feed answered from
    ONE read each for the whole date (2026-10-25: 1,053 feeds = 8,765
    statements, 15 s, before).  Everything else passes through; a key that
    was not prefetched (another date, a feed outside the set) reads the real
    database -- the gate code is unchanged, only where its rows come from."""

    def __init__(self, db, business_date: date, etl_ids, feed_configs: Optional[Dict[int, dict]] = None):
        self._db, self._bd = db, business_date
        self._mappings = db.list_etl_dependency_mappings_with_tracking_bulk(list(etl_ids), business_date)
        self._events = db.list_dependency_events_on(business_date)
        # the date's feed configs, already read once by the caller (the
        # clocks read each one again per held run)
        self._configs = {int(k): v for k, v in (feed_configs or {}).items()}
        # a system setting read per declared SOURCE (the Kafka listener's
        # health: 1,675 reads for 1,053 feeds) -- constant for one answer
        self._settings: Dict[Any, Any] = {}

    def __getattr__(self, name):
        return getattr(self._db, name)

    def list_etl_dependency_mappings_with_tracking(self, etl_id, business_date):
        if business_date == self._bd and int(etl_id) in self._mappings:
            # a COPY: the gate resolves sources IN PLACE on its rows
            return [dict(r) for r in self._mappings[int(etl_id)]]
        return self._db.list_etl_dependency_mappings_with_tracking(etl_id, business_date)

    def get_feed_config(self, feed_id, *a, **k):
        if not a and not k and int(feed_id) in self._configs:
            return dict(self._configs[int(feed_id)])
        return self._db.get_feed_config(feed_id, *a, **k)

    def get_system_setting(self, *a, **k):
        key = (a, tuple(sorted(k.items())))
        if key not in self._settings:
            self._settings[key] = self._db.get_system_setting(*a, **k)
        return self._settings[key]

    def list_dependency_events(self, dependency_name, business_date):
        if business_date == self._bd:
            return [dict(e) for e in self._events.get(dependency_name, [])]
        return self._db.list_dependency_events(dependency_name, business_date)


