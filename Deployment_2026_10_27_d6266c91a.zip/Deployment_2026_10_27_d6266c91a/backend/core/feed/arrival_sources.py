"""Arrival sources — the DECLARED vocabulary of where a dependency's evidence
comes from, and the ONE resolver that turns a declaration into verdicts.

2026-09-27.  A feed dependency used to be satisfied by ANY evidence carrying
its name: a tracking row written by the ETL/OG side, or any arrival in the
ledger whatever wrote it.  That is still the rule for a dependency that
declares nothing.  A dependency may now DECLARE its sources — "this is met
when the Kafka message arrives AND the Iceberg table has committed data for
the date" — and the gate evaluates each declared source on its own and
combines them by the dependency's ``require_mode`` (``all``, the default, or
``any``).  Unknown under ALL is COULD NOT TELL, never met.

THIS MODULE IS THE EXTENSION POINT.  A new arrival source is one entry in
``SOURCE_KINDS`` -- naming its PRODUCER (2026-10-07: who writes the
evidence, and how its health is read) -- plus one evaluator in
``_EVALUATORS``; the gate, the
authoring route, the vocabulary route and the UI all read the registry and
need no change.  The readiness DECISION is not here — every verdict is
combined by ``core.feed.dependency_gate.combine_source_verdicts`` and every
caller (the boolean poller check, the four-verdict gate, the run surface,
the step) reaches it through ``resolve_arrival_sources``.  A decision made
twice is a bug.

Source kinds:

* ``kafka``          — an arrival in ``dependency_events`` with source
                       ``kafka`` (the resolver in core/feed/kafka_arrivals.py).
* ``etl``            — a ``COMPLETE`` row in ``etl_dependency_tracking``
                       (the OG/ETL status mirror; the admin tracking route).
* ``file``           — an arrival in ``dependency_events`` with source
                       ``file``, written by core/feed/file_arrival_source.py
                       when the declared location holds the files (and the
                       control file, when declared) for the business date.
                       Spec: ``connection_id`` (S3 or local), ``path`` (a
                       prefix template on the business date); optional
                       ``pattern``, ``control_file``, ``min_files``.
* ``iceberg_commit`` — an arrival with source ``iceberg_commit``, written by
                       core/feed/iceberg_commit_source.py when a registered
                       Iceberg table's new snapshot PROVES, from its own
                       manifests, that data for the business date exists.
                       Spec: ``connection_id``, ``table`` (the registered
                       name), ``date_column``.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from core.feed.dependency_gate import (
    ACTION_COMPLETE,
    ACTION_SKIP,
    MET,
    NOT_MET,
    UNKNOWN,
    REQUIRE_MODES,
    combine_source_verdicts,
    normalise_require_mode,
)

logger = logging.getLogger(__name__)

KIND_KAFKA = "kafka"
KIND_ETL = "etl"
KIND_FILE = "file"
KIND_ICEBERG_COMMIT = "iceberg_commit"
#: 2026-10-11 -- a row of an upstream's Oracle table (the OG QS_KAFKA_MESSAGE
#: landing table), read by core/feed/oracle_table_source.py and resolved
#: through the SAME resolver rules as a Kafka message.
KIND_ORACLE_TABLE = "oracle_table"

#: How a producer runs.  ``daemon``: a scheduler-owned daemon (its
#: heartbeat says whether it is running).  ``listener``: a callback armed by
#: the daemons that fire it.  ``external``: written from outside QueryStudio
#: (the OG/ETL side) -- nothing here can observe that writer.
PRODUCER_DAEMON = "daemon"
PRODUCER_LISTENER = "listener"
PRODUCER_EXTERNAL = "external"

#: A producer's health.  DOWN is a FACT (a refusal it states, or every
#: owning pod reporting it not running) and makes an unmet source "cannot be
#: satisfied"; UNKNOWN (nobody reported) never blocks anything on its own.
PRODUCER_UP = "up"
PRODUCER_DOWN = "down"
PRODUCER_UNKNOWN = "unknown"


@dataclass(frozen=True)
class ArrivalProducer:
    """WHO writes a kind's evidence (2026-10-07, owner requirement).

    The ``file`` kind sat in this vocabulary for ten days with NO producer:
    a declaration nothing could ever satisfy, discovered only when a feed
    failed at the 48 h escalation.  Every kind now names its producer here,
    and ``tests/test_arrival_source_producers_2026_10_07.py`` fails the build
    when one is missing, is not owned by any pod, or does not write the
    evidence this kind's evaluator reads.
    """
    #: what an operator reads ("feed_kafka_arrivals").
    name: str
    mechanism: str
    #: the module that WRITES the evidence, and the call it writes through
    #: (``record_dependency_arrival`` for ledger kinds, the tracking DAO for
    #: ``etl``) -- the guard reads the module's source for that call.
    module: str
    writer: str
    #: the dotted callable the daemon / listener / route starts.
    entry: str
    #: ``daemon_registry.SCHEDULER_OWNED`` names whose running makes it live
    #: (any one of them).
    daemons: Tuple[str, ...] = ()
    #: why it will NOT run on its own configuration / install, or None.
    refusal: Optional[Callable[[], Optional[str]]] = None
    #: why a producer that IS running cannot currently write (2026-10-08:
    #: the Kafka consumer's broker unreachable), read with the db so the
    #: answer crosses pods; None when healthy or when the kind has no such
    #: state.  Reached only after liveness said UP.
    fault: Optional[Callable[[Any], Optional[str]]] = None

    def describe(self) -> Dict[str, Any]:
        return {"name": self.name, "mechanism": self.mechanism,
                "daemons": list(self.daemons)}


@dataclass(frozen=True)
class ArrivalSourceKind:
    """One entry of the vocabulary — what the UI offers and what a
    declaration may name."""
    key: str
    label: str
    description: str
    #: the ``dependency_events.source`` value this kind's arrivals carry, or
    #: None when its evidence is not in the ledger (``etl`` reads the
    #: tracking table).
    ledger_source: Optional[str]
    #: parameters a declaration of this kind must carry, with the type each
    #: is validated as (``int`` / ``str``).
    params: Mapping[str, type]
    #: parameters it MAY carry (2026-10-07, the ``file`` kind's pattern /
    #: control file / minimum count).
    optional_params: Mapping[str, type] = field(default_factory=dict)
    #: the kind's own authoring check, after the generic parameter pass:
    #: ``fn(entry, norm, where) -> norm``, raising ValueError with the fault.
    #: Pure (no database); a check that needs the database lives in the
    #: authoring route.
    normalise: Optional[Callable[[Mapping[str, Any], Dict[str, Any], str],
                                 Dict[str, Any]]] = None
    #: WHO writes this kind's evidence (2026-10-07).  Required in spirit: the
    #: producer guard fails on a kind without one.
    producer: Optional[ArrivalProducer] = None

    def describe(self) -> Dict[str, Any]:
        return {
            "kind": self.key,
            "label": self.label,
            "description": self.description,
            "ledger_source": self.ledger_source,
            "params": ([{"name": n, "type": t.__name__, "required": True}
                        for n, t in self.params.items()]
                       + [{"name": n, "type": t.__name__, "required": False}
                          for n, t in self.optional_params.items()]),
            "producer": self.producer.describe() if self.producer else None,
        }


def _normalise_file(entry: Mapping[str, Any], norm: Dict[str, Any],
                    where: str) -> Dict[str, Any]:
    from core.feed.file_arrival_source import normalise_declaration
    return normalise_declaration(entry, norm, where)


def _kafka_refusal() -> Optional[str]:
    from core.feed.kafka_arrivals import consumer_refusal
    return consumer_refusal()


def _kafka_fault(db: Any) -> Optional[str]:
    from core.feed.kafka_arrivals import transport_fault
    return transport_fault(db)


def _normalise_kafka(entry: Mapping[str, Any], norm: Dict[str, Any],
                     where: str) -> Dict[str, Any]:
    """The optional ``topic`` (2026-10-08): which subscribed topic this
    source is met by.  Two Kafka sources on one dependency MUST name
    different topics -- without one there is nothing to tell them apart
    (and the duplicate check refuses the repeat)."""
    raw = entry.get("topic")
    if raw is None:
        return norm
    if not isinstance(raw, str):
        raise ValueError(f"{where} (kafka).topic={raw!r} is not a string")
    text = raw.strip()
    if text:
        norm["topic"] = text
    return norm


def _normalise_oracle_table(entry: Mapping[str, Any], norm: Dict[str, Any],
                            where: str) -> Dict[str, Any]:
    from core.feed.oracle_table_source import normalise_declaration
    return normalise_declaration(entry, norm, where)


def _oracle_table_refusal() -> Optional[str]:
    from core.feed.oracle_table_source import producer_refusal
    return producer_refusal()


_PARTITION_COLUMN_RE = __import__("re").compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _normalise_iceberg_commit(entry: Mapping[str, Any], norm: Dict[str, Any],
                              where: str) -> Dict[str, Any]:
    """The optional ``partition_values`` (2026-10-11): ``{column: value}``,
    the value a literal or a ``{TOKEN}`` the feed's query_params fill at
    evaluation time (``TETB_{SYSTEM_ENTITY}``: a template renders it at
    apply, a hand-authored feed at run time).  A commit then counts only
    when its files are OF THAT PARTITION -- 4,000 per-(entity, event) feeds
    on one table must not all release on the first entity's load.  Column
    names stored lower; a malformed map is refused at authoring."""
    raw = entry.get("partition_values")
    if raw is None:
        return norm
    if not isinstance(raw, Mapping) or not raw:
        raise ValueError(f"{where} (iceberg_commit).partition_values must be a non-empty "
                         f"object of {{column: value}}")
    out: Dict[str, str] = {}
    for col, value in raw.items():
        if not isinstance(col, str) or not _PARTITION_COLUMN_RE.match(col.strip()):
            raise ValueError(f"{where} (iceberg_commit).partition_values has a key "
                             f"{col!r} that is not a column name")
        if not isinstance(value, (str, int, float)) or isinstance(value, bool) or not str(value).strip():
            raise ValueError(f"{where} (iceberg_commit).partition_values[{col!r}]={value!r} "
                             f"is not a value (a literal or a {{TOKEN}})")
        text = str(value).strip()
        if any(ord(ch) < 32 for ch in text) or len(text) > 200:
            raise ValueError(f"{where} (iceberg_commit).partition_values[{col!r}] carries a "
                             f"control character or is over 200 characters")
        out[col.strip().lower()] = text
    norm["partition_values"] = out
    return norm


def _file_refusal() -> Optional[str]:
    from core.feed.file_arrival_source import load_config as _file_cfg
    if _file_cfg().get("enabled", True):
        return None
    return ("feed_generation.dependency_file.enabled is false -- the file "
            "watcher is switched off")


def _iceberg_commit_refusal() -> Optional[str]:
    from core.feed.iceberg_commit_source import load_config as _ice_cfg
    if _ice_cfg().get("enabled", True):
        return None
    return ("feed_generation.dependency_iceberg_commit.enabled is false -- "
            "commits are not inspected")


#: EXTENSION POINT — ordered as the UI lists them.  A new kind = one entry
#: here (with its PRODUCER) + one evaluator in ``_EVALUATORS``.
SOURCE_KINDS: Dict[str, ArrivalSourceKind] = {
    KIND_KAFKA: ArrivalSourceKind(
        KIND_KAFKA, "Kafka message",
        "A message on a subscribed topic, mapped to this dependency by a "
        "resolver rule (feed_generation.dependency_kafka.resolver_rules).",
        ledger_source="kafka", params={},
        # 2026-10-08 -- the topic the message is expected on, so ONE
        # dependency can wait for two messages (two topics, ALL).
        optional_params={"topic": str},
        normalise=_normalise_kafka,
        producer=ArrivalProducer(
            name="feed_kafka_arrivals", mechanism=PRODUCER_DAEMON,
            module="core.feed.kafka_arrivals",
            writer="record_dependency_arrival",
            entry="core.feed.kafka_arrivals.start_consumer",
            daemons=("feed_kafka_arrivals",), refusal=_kafka_refusal,
            fault=_kafka_fault)),
    KIND_ETL: ArrivalSourceKind(
        KIND_ETL, "ETL / OG status",
        "A COMPLETE status recorded for this dependency and business date "
        "(the ETL side's tracking row).",
        ledger_source=None, params={},
        producer=ArrivalProducer(
            name="the ETL/OG tracking writer", mechanism=PRODUCER_EXTERNAL,
            module="api.admin_api",
            writer="record_etl_dependency_tracking",
            entry="api.admin_api.record_etl_dep_tracking")),
    KIND_FILE: ArrivalSourceKind(
        KIND_FILE, "Control / landed file",
        "Files landed for the business date under a path on an S3 or "
        "local connection -- optionally matching a name pattern, at least "
        "min_files of them, and a control file (READY, *.ctl). The file "
        "watcher lists the path while a run waits on it.",
        ledger_source="file",
        params={"connection_id": int, "path": str},
        optional_params={"pattern": str, "control_file": str,
                         "min_files": int},
        normalise=_normalise_file,
        producer=ArrivalProducer(
            name="feed_dependency_file_watch", mechanism=PRODUCER_DAEMON,
            module="core.feed.file_arrival_source",
            writer="record_dependency_arrival",
            entry="core.retention_daemons.run_feed_dependency_file_watch",
            daemons=("feed_dependency_file_watch",), refusal=_file_refusal)),
    KIND_ICEBERG_COMMIT: ArrivalSourceKind(
        KIND_ICEBERG_COMMIT, "Iceberg table has data for the date",
        "A commit to a registered Iceberg table whose own metadata proves "
        "data for the business date exists in the declared date column -- "
        "optionally for ONE partition (partition_values: {column: value or "
        "{TOKEN}}), so a per-entity feed waits for its own island.",
        ledger_source="iceberg_commit",
        params={"connection_id": int, "table": str, "date_column": str},
        optional_params={"partition_values": dict},
        normalise=_normalise_iceberg_commit,
        producer=ArrivalProducer(
            name="the Iceberg snapshot-change listener",
            mechanism=PRODUCER_LISTENER,
            module="core.feed.iceberg_commit_source",
            writer="record_dependency_arrival",
            entry="core.iceberg_snapshot_reactions.arm",
            daemons=("iceberg_manifest_watcher", "iceberg_metadata_sync"),
            refusal=_iceberg_commit_refusal)),
    KIND_ORACLE_TABLE: ArrivalSourceKind(
        KIND_ORACLE_TABLE, "Row in an upstream Oracle table",
        "A new row of a watched Oracle table (the OG QS_KAFKA_MESSAGE landing "
        "table) that the table's resolver rules map to this dependency -- the "
        "same rules a Kafka message is resolved by (feed_generation."
        "dependency_oracle_table.tables[].resolver_rules). Spec: the Oracle "
        "connection and the table name.",
        ledger_source="oracle_table",
        params={"connection_id": int, "table": str},
        normalise=_normalise_oracle_table,
        producer=ArrivalProducer(
            name="feed_dependency_oracle_table_watch", mechanism=PRODUCER_DAEMON,
            module="core.feed.oracle_table_source",
            writer="record_dependency_arrival",
            entry="core.retention_daemons.run_feed_dependency_oracle_table_watch",
            daemons=("feed_dependency_oracle_table_watch",),
            refusal=_oracle_table_refusal)),
}


class ArrivalSourceRefused(ValueError):
    """A declaration that cannot be stored, with the reason."""


def describe_kinds() -> List[Dict[str, Any]]:
    """The vocabulary, for the authoring UI and the API."""
    return [k.describe() for k in SOURCE_KINDS.values()]


# ── Producer health (2026-10-07) ─────────────────────────────────────────

#: Heartbeat reads are cached this long per database: a gate pass evaluates
#: many rows, and the fleet's answer does not change faster than its own
#: 5 s heartbeat.
_HEALTH_TTL_S = 10.0
_heartbeat_cache: Dict[int, Tuple[float, Dict[str, list], Optional[str]]] = {}


def _heartbeats(db: Any) -> Tuple[Dict[str, list], Optional[str]]:
    import time as _time
    from core.effective_posture import _heartbeat_reports
    now = _time.monotonic()
    hit = _heartbeat_cache.get(id(db))
    if hit is not None and now - hit[0] < _HEALTH_TTL_S:
        return hit[1], hit[2]
    reports, error = _heartbeat_reports(db)
    _heartbeat_cache.clear()          # one database at a time; never grows
    _heartbeat_cache[id(db)] = (now, reports, error)
    return reports, error


def _daemon_liveness(db: Any, producer: ArrivalProducer) -> Tuple[str, str]:
    """(state, reason) from the fleet's first-hand heartbeats -- the SAME
    reading the Effective Posture card makes (``effective_posture.
    _heartbeat_verdict``), so the two can never disagree."""
    from core.effective_posture import OFF, ON, _heartbeat_verdict
    reports, error = _heartbeats(db)
    if error:
        return PRODUCER_UNKNOWN, f"daemon heartbeats unreadable ({error})"
    offs: List[str] = []
    for name in producer.daemons:
        found = _heartbeat_verdict(name, "", reports)
        if found is None:
            continue
        (state, runs_on, reason, _src), _warning = found
        if state == ON:
            return PRODUCER_UP, f"{name} running on {runs_on}"
        if state == OFF:
            offs.append(f"{name}: {reason}")
    if offs and len(offs) == len(producer.daemons):
        return PRODUCER_DOWN, "not running -- " + "; ".join(offs)
    return (PRODUCER_UNKNOWN,
            f"no pod has reported {' / '.join(producer.daemons)} recently")


def producer_health(db: Any, kind: str) -> Dict[str, Any]:
    """Is the producer of ``kind``'s evidence able to write it?

    DOWN when the producer states a refusal (switched off, its client not
    installed, nothing configured to consume) or when every pod that reports
    its daemon(s) reports it not running.  UP when a pod reports it running,
    or for an EXTERNAL writer (nothing here can observe it).  UNKNOWN
    otherwise -- unknown never makes a source unsatisfiable on its own.
    """
    spec = SOURCE_KINDS.get(kind)
    producer = spec.producer if spec else None
    if producer is None:
        return {"producer": None, "mechanism": None, "state": PRODUCER_DOWN,
                "reason": f"no producer is declared for {kind!r} -- nothing "
                          f"can ever write its evidence"}
    out = {"producer": producer.name, "mechanism": producer.mechanism}
    try:
        refusal = producer.refusal() if producer.refusal else None
    except Exception as exc:  # noqa: BLE001 -- a probe that fails is unknown, not down
        return {**out, "state": PRODUCER_UNKNOWN,
                "reason": f"the producer's own check failed: {exc}"}
    if refusal:
        return {**out, "state": PRODUCER_DOWN, "reason": refusal}
    if producer.mechanism == PRODUCER_EXTERNAL:
        return {**out, "state": PRODUCER_UP,
                "reason": "written from outside QueryStudio (the ETL/OG side, "
                          "or an operator through the tracking route) -- "
                          "that writer cannot be observed from here"}
    try:
        state, reason = _daemon_liveness(db, producer)
    except Exception as exc:  # noqa: BLE001
        state, reason = PRODUCER_UNKNOWN, f"heartbeats could not be read: {exc}"
    if state != PRODUCER_DOWN and producer.fault is not None:
        # 2026-10-08 -- running is not writing: a consumer whose broker is
        # unreachable is alive, heartbeats "running", and can satisfy
        # nothing.  The producer's own fault probe decides (cross-pod).
        try:
            fault = producer.fault(db)
        except Exception as exc:  # noqa: BLE001 -- a probe that fails is unknown, not down
            fault = None
            reason = f"{reason}; the producer's fault probe failed: {exc}"
        if fault:
            return {**out, "state": PRODUCER_DOWN,
                    "reason": f"{reason}, but it cannot receive: {fault}"}
    return {**out, "state": state, "reason": reason}


def _parse_one(i: int, entry: Any) -> Dict[str, Any]:
    """One declaration entry, validated and normalised (or refused)."""
    if not isinstance(entry, Mapping):
        raise ArrivalSourceRefused(
            f"arrival_sources[{i}] is not an object ({entry!r})")
    kind = str(entry.get("kind") or "").strip().lower()
    spec = SOURCE_KINDS.get(kind)
    if spec is None:
        raise ArrivalSourceRefused(
            f"arrival_sources[{i}].kind={entry.get('kind')!r} is not in "
            f"the vocabulary {sorted(SOURCE_KINDS)}")
    norm: Dict[str, Any] = {"kind": kind}
    for name, typ in spec.params.items():
        value = entry.get(name)
        if value is None or (isinstance(value, str) and not value.strip()):
            raise ArrivalSourceRefused(
                f"arrival_sources[{i}] ({kind}) is missing {name!r}")
        try:
            norm[name] = (int(value) if typ is int
                          else str(value).strip())
        except (TypeError, ValueError):
            raise ArrivalSourceRefused(
                f"arrival_sources[{i}] ({kind}).{name}={value!r} is not "
                f"a {typ.__name__}")
    if spec.normalise is not None:
        try:
            norm = spec.normalise(entry, norm, f"arrival_sources[{i}]")
        except ValueError as exc:
            raise ArrivalSourceRefused(str(exc)) from exc
    return norm


def parse_arrival_sources(raw: Any) -> List[Dict[str, Any]]:
    """Validate a declaration.  Returns the normalised list (``[]`` for no
    declaration); raises :class:`ArrivalSourceRefused` naming the fault.

    Refusing at authoring is the whole point: a kind outside the vocabulary
    or a missing parameter would otherwise be a dependency that reports
    COULD NOT TELL every night for ever.
    """
    if raw in (None, "", []):
        return []
    if not isinstance(raw, (list, tuple)):
        raise ArrivalSourceRefused(
            f"arrival_sources must be a list of source objects, got "
            f"{type(raw).__name__}")
    out: List[Dict[str, Any]] = []
    seen: set = set()
    for i, entry in enumerate(raw):
        norm = _parse_one(i, entry)
        # JSON-canonical: a declaration may carry a dict-valued parameter
        # (iceberg_commit.partition_values, 2026-10-11), which a tuple of
        # items cannot hash
        import json as _json
        key = _json.dumps(norm, sort_keys=True, default=str)
        if key in seen:
            raise ArrivalSourceRefused(
                f"arrival_sources[{i}] repeats an earlier declaration "
                f"({norm})")
        seen.add(key)
        out.append(norm)
    return out


def parse_require_mode(raw: Any) -> str:
    """``all`` / ``any``; anything else is refused rather than defaulted —
    a misspelt ``"al"`` must not silently become ANY or ALL."""
    if raw in (None, ""):
        return normalise_require_mode(None)
    text = str(raw).strip().lower()
    if text not in REQUIRE_MODES:
        raise ArrivalSourceRefused(
            f"require_mode={raw!r} is not one of {list(REQUIRE_MODES)}")
    return text


def declared_sources(row: Mapping[str, Any]) -> List[Dict[str, Any]]:
    """The row's declaration as a list, or ``[]`` (legacy rule applies)."""
    raw = row.get("arrival_sources")
    if isinstance(raw, list) and raw:
        return [dict(s) for s in raw if isinstance(s, Mapping)]
    return []


# ── Evaluators: one per kind, each answers (verdict, reason, evidence) ─────

@dataclass
class SourceContext:
    """What every evaluator may read.  Built ONCE per row so the ledger is
    read once, not once per declared source."""
    db: Any
    dependency_name: str
    business_date: date
    row: Mapping[str, Any]
    ledger_events: Optional[List[Dict[str, Any]]]   # None when unreadable
    ledger_error: Optional[str]


def _eval_kafka(ctx: SourceContext, spec: Mapping[str, Any]) -> tuple:
    """One ``kafka`` declaration (2026-10-08: per TOPIC).

    Order of evidence:
      1. the ledger unreadable                             -> COULD NOT TELL;
      2. a ``kafka`` arrival for D from this topic (or an untagged one)
                                                            -> MET;
      3. no resolver rule routes this topic (or, with no topic named, any
         topic) to this dependency                          -> COULD NOT TELL,
         "cannot be satisfied" -- nothing consumed will ever be recorded
         for it, and waiting 48 h for a message no rule maps is the
         defect this closes;
      4. otherwise NOT MET, naming the topic and the rule it waits on.
    """
    from core.feed.kafka_arrivals import (
        kafka_source_key, load_config as _kafka_cfg, rules_routing,
    )
    from core.feed.ledger import same_source_rows
    if ctx.ledger_events is None:
        return (UNKNOWN,
                f"the arrival ledger could not be read ({ctx.ledger_error})",
                None)
    topic = str(spec.get("topic") or "").strip() or None
    label = f"Kafka message on topic {topic!r}" if topic else "Kafka message"
    hits = same_source_rows(
        [e for e in ctx.ledger_events if str(e.get("source") or "") == "kafka"],
        kafka_source_key(topic))
    if hits:
        last = hits[-1]
        return (MET,
                f"{label} arrived at {last.get('arrived_at')} "
                f"({len(hits)} arrival(s), identity {last.get('message_identity')})",
                {"arrival_count": len(hits),
                 "last_arrived_at": last.get("arrived_at"),
                 "reported_rows": last.get("reported_rows"),
                 "topic": topic})
    try:
        rules = list(_kafka_cfg().get("resolver_rules") or [])
    except Exception as exc:  # noqa: BLE001 -- unreadable rules: say so, never "not met"
        return (UNKNOWN, f"the Kafka resolver rules could not be read: {exc}",
                {"topic": topic})
    routed = rules_routing(rules, ctx.dependency_name, topic)
    if not routed:
        where = (f"maps topic {topic!r} to" if topic
                 else "names dependency")
        return (UNKNOWN,
                f"cannot be satisfied: no resolver rule {where} "
                f"{ctx.dependency_name!r} (feed_generation.dependency_kafka."
                f"resolver_rules), so no message consumed from Kafka will "
                f"ever be recorded for it",
                {"topic": topic, "rules_for_dependency": 0})
    topics = sorted({r.topic for r in routed})
    return (NOT_MET,
            f"no {label} recorded for {ctx.business_date.isoformat()} "
            f"(waiting on topic{'s' if len(topics) > 1 else ''} "
            f"{', '.join(topics)})",
            {"topic": topic, "topics_routed": topics,
             "rules_for_dependency": len(routed)})


def _eval_etl(ctx: SourceContext, spec: Mapping[str, Any]) -> tuple:
    action = str(ctx.row.get("action") or "").strip().upper()
    comment = ctx.row.get("tracking_comments")
    if action == ACTION_COMPLETE:
        return (MET,
                "ETL status COMPLETE recorded"
                + (f" at {ctx.row.get('updated_at')}" if ctx.row.get("updated_at") else "")
                + (f" ({comment})" if comment else ""),
                {"updated_at": ctx.row.get("updated_at")})
    if action:
        return (NOT_MET, f"ETL status is {action}, not COMPLETE", None)
    return (NOT_MET,
            f"no ETL status recorded for {ctx.business_date.isoformat()}",
            None)


def _eval_file(ctx: SourceContext, spec: Mapping[str, Any]) -> tuple:
    # Aliased for the same reason as the Iceberg evaluator below.
    from core.feed.file_arrival_source import evaluate_source as _eval_file_source
    return _eval_file_source(
        ctx.db, dependency_name=ctx.dependency_name, spec=spec,
        business_date=ctx.business_date, ledger_events=ctx.ledger_events,
        ledger_error=ctx.ledger_error)


def _eval_iceberg_commit(ctx: SourceContext, spec: Mapping[str, Any]) -> tuple:
    # Aliased: this module defines its own ``evaluate_source``; a local name
    # that shadows it reads as the same function to people and to the
    # call-signature sweep (2026-09-27).
    from core.feed.iceberg_commit_source import evaluate_source as _eval_iceberg_commit
    return _eval_iceberg_commit(
        ctx.db, dependency_name=ctx.dependency_name, spec=spec,
        business_date=ctx.business_date, ledger_events=ctx.ledger_events,
        ledger_error=ctx.ledger_error,
        # 2026-10-11 -- the feed's key, so a declared partition's {TOKEN}s
        # render from its parameters (the gate row carries it since today)
        etl_id=ctx.row.get("etl_id"))


def _eval_oracle_table(ctx: SourceContext, spec: Mapping[str, Any]) -> tuple:
    # Aliased for the same reason as the Iceberg evaluator above.
    from core.feed.oracle_table_source import evaluate_source as _eval_oracle_table_source
    return _eval_oracle_table_source(
        ctx.db, dependency_name=ctx.dependency_name, spec=spec,
        business_date=ctx.business_date, ledger_events=ctx.ledger_events,
        ledger_error=ctx.ledger_error)


#: EXTENSION POINT — kind -> evaluator.  Every key of SOURCE_KINDS must be
#: here; a guard test fails the build when the two drift.
_EVALUATORS: Dict[str, Callable[[SourceContext, Mapping[str, Any]], tuple]] = {
    KIND_KAFKA: _eval_kafka,
    KIND_ETL: _eval_etl,
    KIND_FILE: _eval_file,
    KIND_ICEBERG_COMMIT: _eval_iceberg_commit,
    KIND_ORACLE_TABLE: _eval_oracle_table,
}


def evaluate_source(ctx: SourceContext, spec: Mapping[str, Any]) -> Dict[str, Any]:
    """One source's verdict.  An evaluator that RAISES yields UNKNOWN with
    the exception — "could not evaluate" must never read as "not met"."""
    kind = str(spec.get("kind") or "")
    fn = _EVALUATORS.get(kind)
    if fn is None:
        return {"kind": kind, "verdict": UNKNOWN,
                "reason": f"{kind!r} is not an installed arrival source",
                "evidence": None, "spec": dict(spec)}
    try:
        verdict, reason, evidence = fn(ctx, spec)
    except Exception as exc:  # noqa: BLE001 — a source that cannot be read is UNKNOWN, never a crash of the gate
        logger.error("[arrival_sources] %s evaluator for %r raised: %s",
                     kind, ctx.dependency_name, exc)
        verdict, reason, evidence = (
            UNKNOWN, f"{kind} could not be evaluated: {exc}", None)
    if verdict != MET:
        verdict, reason, evidence = _unless_producer_down(
            ctx.db, kind, verdict, reason, evidence)
    return {"kind": kind, "verdict": verdict, "reason": reason,
            "evidence": evidence, "spec": dict(spec)}


def _unless_producer_down(db: Any, kind: str, verdict: str, reason: str,
                          evidence: Any) -> tuple:
    """An unmet source whose producer is DOWN cannot be satisfied by waiting:
    say so (COULD NOT TELL, "cannot be satisfied: ..."), instead of "not
    met", which sends the operator chasing an upstream that may have
    delivered.  A source already MET keeps its arrival (never reached)."""
    health = producer_health(db, kind)
    ev = dict(evidence) if isinstance(evidence, Mapping) else {}
    ev["producer"] = health
    if health["state"] != PRODUCER_DOWN:
        return verdict, reason, ev
    return (UNKNOWN,
            f"cannot be satisfied: the {kind} producer "
            f"({health['producer']}) is not running ({health['reason']})"
            f" -- while it waits: {reason}", ev)


# ── The resolver: annotate the gate's rows in place ──────────────────────

def resolve_arrival_sources(db: Any, rows: Sequence[Dict[str, Any]],
                            business_date: date) -> int:
    """For every row that DECLARED sources: evaluate each, combine them, and
    project the result onto the row for BOTH readers.

    Sets, on such a row:
      * ``source_verdicts`` — the per-source answers (read by
        ``dependency_gate.evaluate_gate``, which re-combines them through
        the same ``combine_source_verdicts``);
      * ``require_mode``    — normalised;
      * ``combined_verdict`` / ``combined_reason`` — for callers that only
        want the answer;
      * ``action``          — the boolean projection the legacy
        ``check_dependencies`` reads: ``COMPLETE`` when the combination is
        MET, untouched when an operator wrote ``SKIP`` (an assertion always
        wins), otherwise ``None``.  This is what keeps the SOD/poller boolean
        and the four-verdict gate saying the same thing.

    Rows without a declaration are left exactly as they were.  Returns the
    number of rows resolved.  Mutates ``rows`` in place; never raises for a
    single row — a row whose ledger cannot be read gets UNKNOWN verdicts.
    """
    resolved = 0
    for row in rows:
        sources = declared_sources(row)
        if not sources:
            continue
        name = str(row.get("dependency_key") or row.get("dependency_name") or "")
        events: Optional[List[Dict[str, Any]]]
        error: Optional[str] = None
        try:
            events = list(db.list_dependency_events(name, business_date))
        except Exception as exc:  # noqa: BLE001 — the reason travels on the verdict
            logger.error("[arrival_sources] ledger unreadable for %r @ %s: %s",
                         name, business_date, exc)
            events, error = None, str(exc)
        ctx = SourceContext(db=db, dependency_name=name,
                            business_date=business_date, row=row,
                            ledger_events=events, ledger_error=error)
        verdicts = [evaluate_source(ctx, spec) for spec in sources]
        mode = normalise_require_mode(row.get("require_mode"))
        verdict, reason = combine_source_verdicts(verdicts, mode)
        row["source_verdicts"] = verdicts
        row["require_mode"] = mode
        row["combined_verdict"] = verdict
        row["combined_reason"] = reason
        current_action = str(row.get("action") or "").strip().upper()
        if current_action != ACTION_SKIP:
            if verdict == MET:
                row["action"] = ACTION_COMPLETE
                row["business_date"] = business_date
                latest = _latest_evidence_time(verdicts)
                if latest is not None:
                    row["updated_at"] = latest
                reported = _latest_reported_rows(verdicts)
                if reported is not None:
                    row["reported_rows"] = reported
            else:
                row["action"] = None
        resolved += 1
        _say_verdict(name, business_date, verdict, mode, reason)
    return resolved


#: the verdict last SAID at INFO per (dependency, business date).  The gate
#: re-resolves every row on every pass (the poller, the board, the tracker):
#: 80 waiting dependencies on the rig wrote ~1,360 INFO lines a minute, which
#: at the owner's 4,000 entities x 2 sides buries everything else.  A CHANGE
#: is said at INFO; the same verdict again is DEBUG.  Bounded: past
#: ``_SAID_MAX`` keys it starts over (the next pass says each verdict once more).
_said: Dict[tuple, str] = {}
_said_lock = threading.Lock()
_SAID_MAX = 50_000


def _say_verdict(name: str, business_date: date, verdict: str, mode: str, reason: str) -> None:
    key = (name, business_date)
    with _said_lock:
        changed = _said.get(key) != verdict
        if changed:
            if len(_said) >= _SAID_MAX:
                _said.clear()
            _said[key] = verdict
    (logger.info if changed else logger.debug)(
        "[arrival_sources] %r @ %s: %s (%s) -- %s", name, business_date.isoformat(), verdict, mode, reason)


def _latest_evidence_time(verdicts: Sequence[Mapping[str, Any]]) -> Any:
    times = []
    for v in verdicts:
        ev = v.get("evidence") or {}
        t = ev.get("last_arrived_at") or ev.get("updated_at")
        if t is not None:
            times.append(t)
    if not times:
        return None
    try:
        return max(times)
    except TypeError:
        return times[-1]


def _latest_reported_rows(verdicts: Sequence[Mapping[str, Any]]) -> Optional[int]:
    for v in reversed(list(verdicts)):
        ev = v.get("evidence") or {}
        raw = ev.get("reported_rows")
        if raw is not None:
            try:
                return int(raw)
            except (TypeError, ValueError):
                continue
    return None


__all__ = [
    "KIND_KAFKA", "KIND_ETL", "KIND_FILE", "KIND_ICEBERG_COMMIT", "KIND_ORACLE_TABLE",
    "SOURCE_KINDS", "ArrivalSourceKind", "ArrivalSourceRefused",
    "SourceContext", "describe_kinds", "parse_arrival_sources",
    "parse_require_mode", "declared_sources", "evaluate_source",
    "resolve_arrival_sources", "ArrivalProducer", "producer_health",
    "PRODUCER_DAEMON", "PRODUCER_LISTENER", "PRODUCER_EXTERNAL",
    "PRODUCER_UP", "PRODUCER_DOWN", "PRODUCER_UNKNOWN",
]
