"""The daemon that makes acting time actually act (BRD §8, §12).

``acting_time`` computes the three clocks and the alert ladder; ``netcool``
turns a rung into an event and hands it to the durable queue.  Neither runs
itself.  Without this pass they are two modules with passing tests and no
production caller — which behaves exactly like working code, because every
unit test agrees and nothing happens.

One pass:

  1. find the runs still waiting on a dependency for this business date;
  2. group them BY DEPENDENCY, because one overdue upstream blocking 34 feeds
     is ONE alert naming 34 feeds, not 34 alerts (FR-DEP-19 / FR-SLA-07) —
     900 feeds on a bad morning is 900 alerts and the one that mattered is
     lost;
  3. build each dependency's clocks from its MEASURED arrival profile and the
     tightest SLA among the feeds it blocks;
  4. evaluate the ladder and enqueue what fired;
  5. CLEAR what no longer applies.

Step 5 is not optional.  An alert raised at 04:19 and cleared by an arrival at
04:31 must send its resolution, or the console fills with stale alerts,
operators learn to ignore the AlertGroup, and the real one is missed
(FR-ALT-01).  So this pass tracks what it raised and resolves it — a raise
without a clear is the failure mode that makes a Netcool integration hated.

Fail-open throughout: alerting must never delay or fail a feed.
"""
from __future__ import annotations

import logging
import threading
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

DAEMON_NAME = "feed_sla_watcher"

#: (dependency name, business date ISO) -> the event we last raised for it,
#: so the pass can send a resolution when it stops firing.  Keyed by DATE as
#: well since 2026-09-28: the pass evaluates every date still holding a WAIT
#: run, and the Identifier already carries the date (BRD §12.2), so
#: yesterday's alert and today's for the same dependency are two problems
#: with two clears -- keyed by name alone, yesterday arriving would have
#: "cleared" today's.  In-memory: losing it on restart costs one un-cleared
#: alert that ExpireTime eventually reaps, which is a far smaller failure
#: than never clearing at all.
_raised: Dict[Any, Any] = {}

#: The declared default of ``feed_generation.sla_watcher.lookback_days``,
#: repeated here ONLY as the fallback for a config that cannot be read.
DEFAULT_LOOKBACK_DAYS = 3
_lock = threading.Lock()
_thread: Optional[threading.Thread] = None
_stop = threading.Event()

#: The counters from the most recent pass, and when it ran.  Kept because
#: ``evaluate_once`` returned them TO NOBODY: ``_loop`` logged them only
#: when something was raised or cleared, so a pass that detected 14 breaches
#: and refused all 14 printed nothing and left no state.  "0 alerts raised"
#: and "0 alerts raised, 14 refused because the environment is unset" are
#: completely different statements and the surface showed the first.
_last_pass: Dict[str, Any] = {}
_last_pass_at: Optional[str] = None
#: Cumulative since start — one bad pass is noise, a rising total is a
#: standing outage.
_refused_total: int = 0
_lost_total: int = 0
#: What ``start_background`` was actually given, and why it refused (None
#: when it did not).  A pod that believes it is UAT while sitting in PROD is
#: a plausible misconfiguration and was previously unobservable.
_env: str = ""
_env_source: str = "unset"
_refusal: Optional[str] = None


# 2026-09-28 -- the per-dependency body of this pass (tightest SLA, config
# enrichment, runtime resolution, the profile read, compute_clocks) moved to
# ``core.feed.acting_time.clocks_for_blocked`` so the Support Desk and the
# Today page read the SAME clocks this watcher alerts on.  The helpers are
# re-exported here because the tests that pin their edge cases were written
# against this module; the code lives in one place.
from core.feed.acting_time import (  # noqa: E402,F401 -- re-exported
    _declared_runtime, _enrich_with_config, _measured_runtime, _tightest_sla,
)


def evaluate_once(db, *, business_date: Optional[date] = None,
                  now: Optional[datetime] = None,
                  env: str = "", enqueue_fn=None,
                  session_factory=None,
                  lookback_days: Optional[int] = None) -> dict:
    """One pass.  Returns counters — numbers, not adjectives.

    2026-09-28 -- EVERY business date still holding a WAIT run inside
    ``[anchor - lookback_days, anchor]`` is evaluated (anchor = the given
    ``business_date`` or today, UTC), each against its OWN clocks.  The pass
    used to build the blocking index for the anchor alone, so a run for
    yesterday still held after midnight, past yesterday's SLA, raised
    nothing until the 48 h escalation failed it -- the consumer was let
    down and the console was quiet.  One dependency blocking runs on two
    dates is two problems: two Identifiers (the date is in the key, BRD
    §12.2), two alerts, two clears.  ``lookback_days`` defaults to the
    DECLARED ``feed_generation.sla_watcher.lookback_days``.
    """
    from core.feed import acting_time as _at
    from core.feed import netcool as _nc
    from core.feed.dependency_index import (build_blocking_index,
                                            wait_business_dates)

    at_now = now or datetime.now(timezone.utc)
    anchor = business_date or at_now.date()
    if lookback_days is None:
        lookback_days = load_config().get("lookback_days", DEFAULT_LOOKBACK_DAYS)
    lookback = max(0, _as_int(lookback_days, DEFAULT_LOOKBACK_DAYS))
    since = anchor - timedelta(days=lookback)
    # ``refused`` and ``lost`` are ALWAYS present, never conditionally
    # added.  A key that appears only when non-zero cannot be charted, and
    # a dashboard that renders a missing key as 0 cannot tell "none were
    # refused" from "this build does not count refusals".  ``dates`` names
    # every business date this pass evaluated; ``out_of_window_dates`` the
    # ones still holding a WAIT run that the look-back did NOT reach.
    counters = {"waiting_runs": 0, "dependencies": 0, "raised": 0,
                "cleared": 0, "errors": 0, "refused": 0, "lost": 0,
                "refusal_reasons": [], "dates": [],
                "out_of_window_dates": 0}

    # ── grouped by DEPENDENCY, never by feed — SHARED with the operator
    #    reverse-index API (core/feed/dependency_index), so the alert and
    #    the screen can never name different sets of feeds.  The old
    #    inline grouping here read ``run.get("etl_id")`` off
    #    ``list_feed_runs`` rows, which never carry etl_id — the map was
    #    ALWAYS empty and this watcher had never raised anything
    #    (found 2026-09-02 while factoring the grouping out).
    #    Listed ONCE for every date (the index reads the same rows).
    try:
        candidates = db.list_pending_runs_needing_dep_check() or []
    except Exception as exc:
        logger.error("[sla_watcher] could not list the runs waiting on a "
                     "dependency: %s", exc)
        counters["errors"] += 1
        _report_slo_pass(db, counters, at_now=at_now, env=env,
                         enqueue_fn=enqueue_fn, session_factory=session_factory,
                         lookback=lookback)
        _record_pass(counters, env)
        return counters
    dates = wait_business_dates(candidates, since=since, until=anchor)
    older = wait_business_dates(candidates, since=date.min,
                                until=since - timedelta(days=1))
    counters["out_of_window_dates"] = len(older)
    if older:
        logger.warning(
            "[sla_watcher] %d business date(s) still hold a WAIT run OLDER "
            "than the %d-day look-back and are NOT evaluated: %s. Nothing "
            "alerts on them; widen feed_generation.sla_watcher.lookback_days "
            "or resolve the runs.", len(older), lookback,
            ", ".join(d.isoformat() for d in older[:5]))
    counters["dates"] = [d.isoformat() for d in dates]

    live: Dict[Any, Any] = {}
    alerts: list = []
    for bd in dates:
        try:
            index = build_blocking_index(db, business_date=bd,
                                         candidates=candidates)
        except Exception as exc:
            logger.error("[sla_watcher] could not build the blocking index "
                         "for %s: %s", bd, exc)
            counters["errors"] += 1
            continue
        # The three clocks per dependency for THIS date, through the ONE
        # function the Support Desk and the blocking route read too
        # (acting_time.clocks_for_blocked, over the per-date index just
        # built from the shared candidate list).  What stays here is the
        # ALERT RULE; the per-dependency loop used to live inline and its
        # result reached only Netcool.
        result = _at.clocks_for_blocked(db, bd, at_now, index=index)
        counters["waiting_runs"] += result.waiting_runs
        counters["errors"] += result.errors
        counters["dependencies"] += result.dependencies
        # ONE rule, applied once per date: worst-first, one alert per
        # dependency naming every feed it blocks.
        alerts.extend(_at.alerts_for_dependencies(at_now, bd, result.blocked))

    # POSITIONAL outcomes, not the shorter queued-id list.  ``zip(alerts,
    # <the old enqueue_alerts>(...))`` paired alert 0 with alert 1's id as
    # anything was refused, which recorded the WRONG dependency as raised
    # and then rebuilt an event that had already been refused — raising the
    # NetcoolContractError out of this function, where nothing catches it.
    # ``enqueue_alerts_with_outcome`` isolates each alert — an operator
    # receiving nothing cannot tell a quiet night from a sender that died
    # on alert 3.
    reasons: list = []
    # 2026-10-25 (rig): an alert ALREADY RAISED with the same Identifier is
    # carried, not queued again.  Every pass (~30 s) used to enqueue every
    # open breach afresh: 36 breached dependencies were 4,060 Netcool events
    # in one hour on the rig -- at month end (~1,000 breaches) about 120,000
    # an hour into the gateway for problems the console already holds.  A
    # NEW stage (a new Identifier) is sent, and _clear_resolved still resolves
    # the previous one; after a restart the in-memory record is empty, so a
    # still-open problem is sent ONCE more (OMNIbus deduplicates it).
    to_send: list = []
    for alert in alerts:
        key = _raised_key(alert.dependency_name, alert.business_date)
        prior = _raised.get(key)
        if prior is not None:
            try:
                same = (_nc.event_from_alert(alert, env=env).identifier
                        == getattr(prior, "identifier", None))
            except Exception:                         # noqa: BLE001 -- the enqueue reports it
                same = False
            if same:
                live[key] = prior
                counters["unchanged"] = counters.get("unchanged", 0) + 1
                continue
        to_send.append(alert)
    for outcome in _nc.enqueue_alerts_with_outcome(
            session_factory, to_send, env=env, enqueue_fn=enqueue_fn, now=at_now):
        if outcome.queue_id == _nc.SUPPRESSED:
            # 2026-10-25 -- a netcool_rules row chose not to send it NOW (e.g.
            # outside its window).  NOT recorded as raised: the next pass asks
            # the rules again, so it is sent once the window opens -- and
            # nothing was sent, so nothing needs clearing.
            counters["suppressed"] = counters.get("suppressed", 0) + 1
        elif outcome.queue_id is not None:
            # The event the enqueue actually used — not a second build of
            # the same event, which is free to disagree with the first.
            live[_raised_key(outcome.alert.dependency_name,
                             outcome.alert.business_date)] = outcome.event
            counters["raised"] += 1
        elif outcome.refusal is not None:
            counters["refused"] += 1
            if outcome.refusal not in reasons:
                reasons.append(outcome.refusal)
        else:
            # Built, but the enqueue failed — already logged at ERROR as
            # "THIS ALERT IS LOST".  A transient queue fault, NOT a
            # misconfiguration, so it is counted apart from a refusal.
            counters["lost"] += 1
    counters["refusal_reasons"] = reasons[:5]

    counters["cleared"] = _clear_resolved(live, enqueue_fn=enqueue_fn,
                                          session_factory=session_factory)
    _report_slo_pass(db, counters, at_now=at_now, env=env, enqueue_fn=enqueue_fn,
                     session_factory=session_factory, lookback=lookback)
    _record_pass(counters, env)
    return counters


def _report_slo_pass(db, counters: dict, *, at_now: datetime, env: str,
                     enqueue_fn, session_factory, lookback: int) -> None:
    """2026-09-28: REPORT promises, in the SAME pass.

    core/reports/slo.py evaluates every active report SLO (fresh and served
    by HH:MM zone) against the readiness-run ledger, records breaches,
    raises REPORT_SLO events and clears them.  It rides this pass -- same
    singleton election, same interval, same environment, same queue --
    rather than a second daemon: one election, one place to look when
    nothing fires.  Its failure is contained both ways: a report promise
    that cannot be evaluated never silences a feed alert, and a feed
    listing that failed (the early return above) still lets the promises
    be evaluated.
    """
    try:
        from core.reports import slo as _report_slo
        counters["report_slo"] = _report_slo.evaluate_once(
            db, now=at_now, env=env, enqueue_fn=enqueue_fn,
            session_factory=session_factory, lookback_days=lookback)
    except Exception as exc:                          # noqa: BLE001
        logger.error("[sla_watcher] the report-SLO pass failed (feed alerts "
                     "were unaffected): %s", exc)
        counters["report_slo"] = {"errors": 1,
                                  "failed": f"{type(exc).__name__}: {exc}"}
        counters["errors"] += 1


def _raised_key(dependency_name: str, business_date: Any) -> tuple:
    """The key ``_raised`` and ``live`` share: (dependency, date ISO)."""
    bd = business_date
    if hasattr(bd, "isoformat"):
        bd = bd.isoformat()
    return (str(dependency_name), str(bd or "")[:10])


def _record_pass(counters: dict, env: str) -> None:
    """Publish the pass to the status surface.

    The whole point of the fix: the numbers ``evaluate_once`` computes are
    now READABLE without catching the one log line that may not be emitted.
    """
    global _last_pass, _last_pass_at, _refused_total, _lost_total
    with _lock:
        _last_pass = dict(counters)
        _last_pass["environment"] = str(env or "")
        _last_pass_at = datetime.now(timezone.utc).isoformat()
        _refused_total += int(counters.get("refused") or 0)
        _lost_total += int(counters.get("lost") or 0)


def _clear_resolved(live: Dict[str, Any], *, enqueue_fn=None,
                    session_factory=None) -> int:
    """Send a resolution for everything we raised that is no longer firing.

    FR-ALT-01.  Without this the console fills with stale alerts, operators
    learn to ignore the AlertGroup, and the real one is missed — which is the
    single most common way a Netcool integration becomes worthless.
    """
    from core.feed import netcool as _nc
    cleared = 0
    with _lock:
        gone = [key for key in _raised if key not in live]
        # 2026-10-10 -- ESCALATION.  The ladder's stages are different
        # alert types, so each is a different Identifier
        # (QS:<env>:DECISION_DUE:... then QS:<env>:DEADLINE_PASSED:... then
        # QS:<env>:BREACHED:...).  ``live`` carries the NEW stage under the
        # SAME (dependency, date) key, so the old test -- "key no longer in
        # live" -- never fired for it and ``_raised.update(live)`` silently
        # forgot the previous stage's event: its alert stayed OPEN on the
        # console at the old severity beside the new one, until ExpireTime
        # (found 2026-10-08 while building the Docker proof).  The previous
        # stage is cleared with its own Identifier before the new one is
        # remembered.
        escalated = [key for key in _raised
                     if key in live
                     and getattr(_raised[key], "identifier", None)
                     != getattr(live[key], "identifier", None)]
        for key in gone + escalated:
            event = _raised.pop(key)
            try:
                _nc.enqueue_event(session_factory, _nc.resolution_for(event),
                                  enqueue_fn=enqueue_fn)
                cleared += 1
                if key in live:
                    logger.info("[sla_watcher] cleared %s (%s) -- escalated to %s",
                                key, event.identifier, live[key].identifier)
                else:
                    logger.info("[sla_watcher] cleared %s", key)
            except Exception as exc:
                logger.error(
                    "[sla_watcher] could not clear %s (%s) — the console will "
                    "hold a stale alert until its ExpireTime", key, exc)
        _raised.update(live)
    return cleared


#: Interval floor.  A 0 (or negative) interval would busy-loop the pod —
#: the same "0 means unlimited" fold that has shipped 1M of 70M rows in
#: this codebase.  0 here means "as fast as possible", which is never
#: what anyone typing 0 into a config meant.
MIN_INTERVAL_SECONDS = 5


def load_config() -> dict:
    """The declared ``feed_generation.sla_watcher`` block, typed.

    Every key read here is DECLARED in core/config.py — a guard on an
    undeclared key is vacuous, and this cadence was a hardcoded 60 while
    every sibling daemon's was configurable.
    """
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "sla_watcher", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, dict):
        logger.error("[sla_watcher] feed_generation.sla_watcher is %s, not "
                     "an object — using defaults", type(raw).__name__)
        raw = {}
    return {
        "enabled": bool(raw.get("enabled", True)),
        # NOT floored here.  ``start_background`` floors every interval it
        # is given, from config or from an explicit argument, so a second
        # floor on this path could never fail -- and a guard that cannot
        # fail is worse than none: it reads as protection and proves
        # nothing.  One floor, in the one place the value is observable.
        "interval_seconds": _as_int(raw.get("interval_seconds"), 60),
        # Business dates before today that a pass also evaluates (0 = today
        # only).  Floored at 0 in evaluate_once, the one place it is used.
        "lookback_days": _as_int(raw.get("lookback_days"),
                                 DEFAULT_LOOKBACK_DAYS),
    }


def _as_int(value, fallback: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def safe_interval(seconds) -> int:
    """The interval the loop will actually use."""
    try:
        value = int(seconds)
    except (TypeError, ValueError):
        return MIN_INTERVAL_SECONDS
    return max(MIN_INTERVAL_SECONDS, value)


def _loop(db, interval_seconds: int, env: str, session_factory) -> None:
    while not _stop.wait(interval_seconds):
        try:
            counters = evaluate_once(db, env=env,
                                     session_factory=session_factory)
            # REFUSED and LOST join the log condition (2026-09-07).  The
            # old condition was ``raised or cleared``, so the one state
            # that most needed saying -- every alert detected and none
            # deliverable -- was the one state that printed nothing.
            if (counters["raised"] or counters["cleared"]
                    or counters["refused"] or counters["lost"]):
                logger.info("[sla_watcher] pass: %s", counters)
            if counters["refused"]:
                logger.error(
                    "[sla_watcher] %d of %d alert(s) were REFUSED and are "
                    "NOT on the console: %s",
                    counters["refused"],
                    counters["refused"] + counters["raised"]
                    + counters["lost"],
                    "; ".join(counters["refusal_reasons"]) or "no reason "
                    "recorded")
        except Exception as exc:      # pragma: no cover - loop guard
            logger.error("[sla_watcher] pass failed (continuing): %s", exc)
        # 2026-10-12 -- the feed alerts' e-mail RETRY rides this pass (one
        # election, one interval, no second daemon -- as the report SLOs do):
        # an alert whose e-mail did not complete is sent again
        # (core/feed/feed_alerts.py).
        try:
            from core.feed.feed_alerts import deliver_pending_email
            deliver_pending_email(db)
        except Exception as exc:      # pragma: no cover - loop guard
            logger.error("[sla_watcher] feed alert e-mail retry failed (continuing): %s", exc)


def start_background(db, *, interval_seconds: int | None = None,
                     env: str = "", session_factory=None) -> bool:
    """Start the pass.  Idempotent; returns whether a thread is running.

    ``interval_seconds`` defaults to the DECLARED cadence
    (``feed_generation.sla_watcher.interval_seconds``); an explicit value
    still wins, which is how the tests pin the floor without touching
    config.  A disabled watcher is a STATED refusal at INFO, never a
    silent no-op: "no alerts are firing" and "nothing is evaluating them"
    are opposite findings that look identical from outside.
    """
    global _thread, _env, _env_source, _refusal
    cfg = load_config()
    if interval_seconds is None:
        interval_seconds = cfg["interval_seconds"]
    if not cfg["enabled"]:
        _refusal = ("feed_generation.sla_watcher.enabled is false — an "
                    "operator turned this pass off. Nothing evaluates "
                    "acting time on this pod.")
        logger.info(
            "[sla_watcher] NOT running: feed_generation.sla_watcher.enabled "
            "is false. Nothing evaluates acting time on this pod, so no "
            "dependency will be alerted on however late it is.")
        return False

    # ── The environment must be known BEFORE the first breach ─────────
    #
    # ``netcool.build_identifier`` refuses a blank environment, so a
    # watcher started without one detects every breach, refuses every
    # alert and reports a quiet night.  It ran that way for weeks.
    #
    # Refusing HERE, at startup, is the whole difference: an operator
    # meets this line in the pod log at boot and on the status surface
    # immediately, instead of meeting silence at 04:50.  A watcher that
    # cannot alert has nothing to do -- it can raise nothing, and with
    # nothing raised there is nothing to clear either -- so starting it
    # would only manufacture the appearance of coverage.
    #
    # No value is invented.  The deployed environments are UAT and PROD:
    # guessing PROD labels a UAT alert as production, and guessing UAT
    # labels a real PROD breach as noise and gets it triaged away.  Both
    # are worse than this refusal, which is loud, named and fixable.
    env = str(env or "").strip()
    if not env:
        from core.config import deploy_environment_source as _des
        try:
            resolved, source = _des()
        except Exception:                          # noqa: BLE001
            resolved, source = "", "unset"
    else:
        resolved, source = env, "caller"
    _env, _env_source = resolved, source
    if not resolved:
        _refusal = (
            "the deployment environment is UNSET, so every alert this "
            "watcher raises would be refused by the Netcool Identifier "
            "contract and lost. Set app.environment (or the env var "
            "QUERYSTUDIO_APP_ENVIRONMENT) to this deployment's name, e.g. "
            "UAT or PROD. No default is applied: labelling a UAT alert "
            "PROD, or a PROD breach UAT, is worse than not alerting.")
        logger.error("[sla_watcher] NOT running: %s", _refusal)
        return False
    _refusal = None
    with _lock:
        if _thread is not None and _thread.is_alive():
            return True
        _stop.clear()
        _thread = threading.Thread(
            # ``resolved``, never the argument: an explicit env still wins,
            # but a caller that passed nothing gets the DECLARED config
            # value rather than the blank string it handed in.
            target=_loop, args=(db, safe_interval(interval_seconds), resolved,
                                session_factory),
            name=DAEMON_NAME, daemon=True)
        _thread.start()
    logger.info(
        "[sla_watcher] started — evaluating acting time every %ds as "
        "environment %r (from %s)", interval_seconds, resolved, source)
    return True


def get_status() -> dict:
    """For the operator surface: running or not, WHICH ENVIRONMENT it
    thinks it is, and what the last pass actually did.

    ``refused`` is the field this exists for.  It was computed and thrown
    away, so an unalertable watcher and a quiet night rendered identically
    — and the codebase has shipped that same shape (compute a value for a
    gate, then discard it) enough times to name it.
    """
    with _lock:
        thread = _thread
        running = bool(thread is not None and thread.is_alive())
        open_alerts = len(_raised)
        last_pass = dict(_last_pass)
        last_pass_at = _last_pass_at
        refused_total = _refused_total
        lost_total = _lost_total
        env, env_source, refusal = _env, _env_source, _refusal
    return {
        "running": running,
        # None when running.  When not running this is the STATED reason,
        # never an inferred one — the API's generic fallback would blame
        # pod role for a misconfiguration it cannot see.
        "refusal": refusal,
        # "which env does this pod think it is, and why" — answerable
        # without reading precedence rules off a wiki.
        "environment": env or None,
        "environment_source": env_source,
        "open_alerts": open_alerts,
        "last_pass": last_pass,
        "last_pass_at": last_pass_at,
        # Cumulative since process start: one refused pass is noise, a
        # rising total is a standing outage.
        "refused_total": refused_total,
        "lost_total": lost_total,
    }


def stop_background() -> None:
    _stop.set()
    with _lock:
        thread = _thread
    if thread is not None and thread.is_alive():
        thread.join(timeout=5.0)
    logger.info("[sla_watcher] stopped")


def reset_state_for_tests() -> None:
    """Return the module to its pre-start state.

    ``_thread`` is stopped and cleared here too (2026-09-02).  A reset that
    leaves a LIVE daemon thread behind leaks across test files: the daemon
    status surface reports this watcher as running, and an unrelated file's
    assertions fail or pass depending on which tests xdist happened to put
    in the same worker.  A reset that leaves the thread behind is not a
    reset.
    """
    global _thread, _last_pass, _last_pass_at, _refused_total, _lost_total
    global _env, _env_source, _refusal
    # Stop OUTSIDE the lock — stop_background takes it to read the thread.
    if _thread is not None and _thread.is_alive():
        stop_background()
    with _lock:
        _raised.clear()
        _thread = None
        # The status fields reset too. A leaked refusal count or a leaked
        # environment name is the same cross-file leak the thread handle
        # was: an unrelated file's assertions would pass or fail depending
        # on which tests xdist put in this worker.
        _last_pass = {}
        _last_pass_at = None
        _refused_total = 0
        _lost_total = 0
        _env = ""
        _env_source = "unset"
        _refusal = None
