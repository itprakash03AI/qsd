"""How much memory a feed run takes on THIS pod, and the pod's ledger of it
(2026-10-26).

The owner: "why is the scheduler taking more than 15 Gi of memory and
crashing every time".  Measured on the rig the same night: a native run of a
1,000-column table (40,320 rows in 2,016 files on AWS S3) held about 1.4 GB
and grew for its whole 15 minutes; the queue worker admitted runs by COUNT
(``memory_bounded_slots``: the pod's memory / 2 GB each), so a 16 GiB
scheduler took 8 wide runs together, the kernel killed it, its runs went back
on the queue and the next process took them again.

The rule (ONE place): a native run needs ``feed_generation.
native_memory_per_run_mb``; a LARGE run (its rows weighed by width -- the
router's ``run_size.width_weighted_rows`` -- over the row limit) or one whose
size is unknown needs that x columns / ``auto_route_width_base_columns`` above
that many -- never less than the base and never more than the whole pod (so
it can always run alone).  The size is THE size (``size_probe.size_this_run``
without the source count).  A run whose work is
not on this pod (pinned to a Spark / Airflow lane, or moved there by the
router once it starts: ``lower``) needs ``OFF_POD_MB``.

The ledger THROTTLES (a cap, never a refusal): a run that does not fit beside
the runs already reserved waits for the next free slot, in its queue order;
with nothing reserved the first run is always admitted.  No cgroup limit (a
dev box) or a base of 0 = no ledger.
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: what a run whose work runs elsewhere (a Spark pod, an Airflow DAG) holds
#: here while it waits for the job -- the engine's coroutine and its record
OFF_POD_MB = 256
OFF_POD_BACKENDS = frozenset({"spark_k8s", "spark_connect", "airflow"})


def _cfg():
    from core.config import feed_generation
    return feed_generation


def need_mb(db: Any, feed: Optional[Dict[str, Any]], budget_mb: Optional[int]) -> int:
    """The memory one run of ``feed`` needs on this pod (see the module)."""
    cfg = _cfg()
    base = int(getattr(cfg, "native_memory_per_run_mb", 2048) or 0)
    if base <= 0 or not feed:
        return max(base, 0)
    if str(feed.get("execution_backend") or "auto").lower() in OFF_POD_BACKENDS:
        return OFF_POD_MB
    width_base = int(getattr(cfg, "auto_route_width_base_columns", 100) or 100)
    # the size from what the PLATFORM measured or read (the upstream
    # ROW_COUNT, the previous run, table statistics, the catalog) -- never
    # the feed's own estimate or row limit, which its author sets: a tiny
    # estimate on a huge run would reserve the base and kill the pod
    # (security review 2026-10-26)
    trusted = {k: v for k, v in feed.items() if k not in ("estimated_row_count", "size_threshold_rows")}
    try:
        from core.feed.run_size import width_weighted_rows
        from core.feed.size_probe import size_this_run
        size = size_this_run(db, trusted, cfg, count_on_source=False)
    except Exception:                                     # noqa: BLE001 -- unknown size = weighed by width
        size = {"rows": None, "columns": None}
    cols, rows = size.get("columns"), size.get("rows")
    threshold = int(getattr(cfg, "auto_route_threshold_rows", 500_000))
    need = base
    # a SMALL run is small however wide it is (200 rows x 460 columns): only
    # a large run -- or one whose size nobody knows -- is weighed by width
    small = rows is not None and width_weighted_rows(rows, cols, width_base) <= threshold
    if cols and cols > width_base and not small:
        need = int(base * cols / width_base)
    if budget_mb:
        need = min(need, int(budget_mb))
    return need


class MemoryLedger:
    """The pod's reserved memory by run (thread-safe: claims happen on the
    polling thread, releases on the event loop)."""

    def __init__(self, budget_mb: Optional[int]):
        self.budget_mb = budget_mb if budget_mb and budget_mb > 0 else None
        self._held: Dict[int, int] = {}
        self._lock = threading.Lock()

    @classmethod
    def for_this_pod(cls) -> "MemoryLedger":
        try:
            if int(getattr(_cfg(), "native_memory_per_run_mb", 2048) or 0) <= 0:
                return cls(None)
            from core.duckdb_resource_limits import _read_cgroup_memory_limit_bytes
            b = _read_cgroup_memory_limit_bytes()
            return cls(int(b // (1024 * 1024)) if b else None)
        except Exception as exc:                          # noqa: BLE001 -- no ledger, said
            logger.warning("[run_memory] no memory ledger on this pod (%s): runs are admitted by count", exc)
            return cls(None)

    @property
    def reserved_mb(self) -> int:
        with self._lock:
            return sum(self._held.values())

    def try_reserve(self, run_id: int, mb: int) -> bool:
        """Reserve ``mb`` for ``run_id`` when it fits (or nothing is held)."""
        with self._lock:
            if self.budget_mb is None:
                self._held[run_id] = mb
                return True
            used = sum(v for k, v in self._held.items() if k != run_id)
            if self._held and used + mb > self.budget_mb:
                return False
            self._held[run_id] = mb
            return True

    def lower(self, run_id: int, mb: int) -> None:
        """The run's work moved off this pod: it holds ``mb`` now."""
        with self._lock:
            if run_id in self._held and self._held[run_id] > mb:
                self._held[run_id] = mb

    def release(self, run_id: int) -> None:
        with self._lock:
            self._held.pop(run_id, None)

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {"budget_mb": self.budget_mb, "reserved_mb": sum(self._held.values()),
                    "runs": dict(self._held)}
