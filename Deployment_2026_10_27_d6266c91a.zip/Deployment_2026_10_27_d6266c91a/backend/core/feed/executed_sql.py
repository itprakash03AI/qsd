"""The SQL a feed run produced, AS RENDERED, recorded where it is rendered
(2026-10-24).

The owner: "feed run status page does not show what has been executed by
resolving parameters -- [it] should show."  A feed's SQL carries calendar
tokens (``{BUSINESSDATE}``, ``{{business_date}}``), its ``query_params``
(``{SYSTEM_ENTITY}``) and a per-side table map; what reaches the source is
none of those -- it is the text after them.  Nothing kept that text.

Rule: the text is recorded BY the chokepoints that produce it, never
re-rendered for display (a second render is a second answer -- it would
disagree the day a calendar or a binding changes):

* ``core/feed/param_resolver.py::apply_to_query_config`` -- the native,
  union-pushdown and Spark Connect lanes;
* ``core/feed/airflow_plan.py::_resolve_serialized_side`` and
  ``core/spark_k8s/feed_conf.py::_apply_legacy_wrap_and_rls`` -- the Spark
  plan (lane ``spark``).

It is written the moment it exists, so a run that fails AFTER rendering
(the source refused the statement) still shows what it sent.  Recording is
OBSERVATION: a failure to record is logged and never fails the run.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: the longest text kept per row -- a generated 460-column statement is ~40 KB
MAX_SQL_CHARS = 200_000


def run_id_of(feed_config: Optional[dict], feed_run: Optional[dict] = None) -> Optional[int]:
    """The run a render belongs to: the explicit run, else the one the engine
    carries on the config (``feed_config["_feed_run"]``).  None = a render
    outside a run (a preview, a test) -- nothing is recorded."""
    for r in (feed_run, (feed_config or {}).get("_feed_run") if isinstance(feed_config, dict) else None):
        if isinstance(r, dict) and r.get("id") is not None:
            try:
                return int(r["id"])
            except (TypeError, ValueError):
                return None
    return None


def _scalar_params(params: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in (params or {}).items():
        if str(k).startswith("_"):
            continue
        if isinstance(v, (date, datetime)):
            out[str(k)] = v.isoformat()
        elif isinstance(v, (str, int, float, bool)) or v is None:
            out[str(k)] = v
    return out


def record(feed_config: Optional[dict], *, sql: Optional[str], params: Optional[Dict[str, Any]],
           side: str = "", field: str = "raw_sql", lane: str = "native",
           feed_run: Optional[dict] = None, db: Any = None) -> bool:
    """Append the rendered ``sql`` of one side of the run.  True when written."""
    run_id = run_id_of(feed_config, feed_run)
    if run_id is None or not isinstance(sql, str) or not sql.strip():
        return False
    try:
        if db is None:
            from core.database import get_db_manager
            db = get_db_manager()
        if db is None or not hasattr(db, "add_feed_run_sql"):
            return False
        db.add_feed_run_sql({
            "feed_run_id": run_id,
            "feed_config_id": (feed_config or {}).get("id") if isinstance(feed_config, dict) else None,
            "side": str(side or ""),
            "field": str(field or "raw_sql")[:40],
            "lane": str(lane or "native")[:20],
            "sql_text": sql[:MAX_SQL_CHARS],
            "params": _scalar_params(params),
        })
        return True
    except Exception as exc:   # observation: never fail the run for it
        logger.warning("[executed_sql] could not record run %s %s side: %s", run_id, side or "-", exc)
        return False


def for_run(db: Any, run_id: int) -> Dict[str, Any]:
    """What the run rendered: the LATEST text per (side, field) -- what the
    current attempt ran -- and every render in order (``history``).
    ``unavailable`` says the rows could not be READ (unknown != none)."""
    try:
        rows = db.list_feed_run_sql(int(run_id))
    except Exception as exc:
        return {"run_id": int(run_id), "statements": [], "history": [],
                "unavailable": f"the recorded SQL could not be read: {exc}"}
    latest: Dict[tuple, dict] = {}
    for r in rows:
        latest[(r["side"], r["field"])] = r
    order = {"primary": 0, "": 1, "secondary": 2}
    statements = sorted(latest.values(), key=lambda r: (order.get(r["side"], 3), r["field"]))
    return {"run_id": int(run_id), "statements": statements, "history": rows, "unavailable": None}
