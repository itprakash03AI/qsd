"""TEST AS FEED -- what this feed would deliver, under ITS OWN principal,
before it runs (2026-10-24; docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html §4
"test as consumer / feed", listed there as not in the first delivery).

The question an author or an admin asks of a feed whose
``entitlement_mode`` is ``apply``: "which rows will the OWNER GROUP's
entitlement let through, and which dimensions decide it?"  The answer must
come from the functions the RUN uses, or it is a second decision:

* the principal is ``core/feed/rls.py::feed_principal`` -- the dict every
  native side is secured with -- and the securing is
  ``rls.secure_feed_sql_report``, the ONE body ``secure_feed_sql`` returns the
  first element of;
* the business date / parameters are the engine's: the candidate dates come
  from ``SodTaskGenerator.current_business_date`` + ``restatement.next_task``
  (the board's and the summary's readers), the calendar from
  ``feed_engine._load_calendar_for_feed``, the tokens from
  ``param_resolver.apply_to_raw_sql`` -- the chokepoint that records nothing
  for a render with no run (``executed_sql.run_id_of`` -> None);
* each side's SQL text is ``feed_sql_resolver.resolve_feed_sql``'s (the
  "SQL as executed" preview's), the second side's config
  ``source_plan.secondary_side_config``'s;
* the read is ``cross_source_combine.run_side_to_parquet`` -- the one side
  runner the cross-source capability reads every connection type with,
  bounded (``row_cap`` fetches cap + 1 and SAYS when it cut).

What it never does: create a ``feed_runs`` / ``feed_executions`` row, write a
file under the feed's output dir, deliver, merge the two sides (they are
shown apart; the run merges them by column name), or take the Spark lane
(the preview reads natively whatever lane the run would take, and says so).

Unknown is never "not filtered": a store the compiler could not read, a table
whose columns are unknown, are ``could_not_be_determined`` (the run would be
REFUSED for the same reason); ``off`` / ``no_active_dimension`` /
``not_governed`` / ``engine_off`` each say why nothing was applied.
"""
from __future__ import annotations

import logging
import math
import os
import shutil
import tempfile
import threading
import time
import uuid
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: the most rows a caller may ask to SEE (``limit``); the deployment's default
#: is ``feed_generation.test_as_feed_max_rows``
ROW_CEILING = 500
DEFAULT_MAX_ROWS = 100
DEFAULT_TIMEOUT_SECONDS = 60

#: the entitlement verdict of a preview -- ONE word each, read by the UI
STATE_APPLIED = "applied"                       # a dimension filtered a side
STATE_OFF = "off"                               # entitlement_mode is off
STATE_ENGINE_OFF = "engine_off"                 # row security is not enforcing
STATE_NO_DIMENSION = "no_active_dimension"      # apply, but no dimension exists
STATE_NOT_GOVERNED = "not_governed"             # dimensions exist, no table carries one
STATE_REFUSED = "refused"                       # the run would be REFUSED (shape)
STATE_UNDETERMINED = "could_not_be_determined"  # the store / schema could not be read

PRINCIPAL_TYPE = "feed_owner_group"
LANE = "native preview"


def max_rows() -> int:
    try:
        from core.config import feed_generation as _fg
        n = int(_fg.test_as_feed_max_rows)
    except Exception:                                   # noqa: BLE001 -- undeclared config
        n = DEFAULT_MAX_ROWS
    return max(1, min(n, ROW_CEILING))


def timeout_seconds() -> float:
    try:
        from core.config import feed_generation as _fg
        return max(1.0, float(_fg.test_as_feed_timeout_seconds))
    except Exception:                                   # noqa: BLE001
        return float(DEFAULT_TIMEOUT_SECONDS)


class TestAsFeedRefused(ValueError):
    """A request this preview cannot take (a limit over the ceiling, a date
    that is not a date) -- the route's 422."""


# ── the business date: the run's own readers ─────────────────────────────────

def _today() -> date:
    return datetime.now(timezone.utc).date()


def business_date_choices(db: Any, feed: Dict[str, Any], today: Optional[date] = None) -> Dict[str, Any]:
    """The dates a preview may run for, each from THE reader the board / the
    summary use: ``current`` (the date a run TODAY is for --
    ``SodTaskGenerator.current_business_date``), ``next`` (the next task's
    run day and data date -- ``restatement.next_task``, i.e.
    ``schedule.business_date_for`` on the next due run day).  ``default`` is
    the next task's date when there is one (the owner: "default the next
    run's date"), else the current, else today; ``source`` says which."""
    from core.feed import restatement
    from core.feed.sod_generator import SodTaskGenerator
    today = today or _today()
    out: Dict[str, Any] = {"today": today.isoformat(), "current": None, "next": None,
                           "default": None, "source": None, "notes": []}
    cur: Optional[date] = None
    try:
        cur = SodTaskGenerator(db).current_business_date(feed, today)
    except Exception as exc:                            # noqa: BLE001 -- said, never guessed
        out["notes"].append(f"the current business date could not be derived: {exc}")
    if cur is not None:
        out["current"] = {"business_date": cur.isoformat(), "run_day": today.isoformat()}
        try:
            nt = restatement.next_task(db, feed, cur)
        except Exception as exc:                        # noqa: BLE001
            nt = None
            out["notes"].append(f"the next task could not be derived: {exc}")
        if nt:
            out["next"] = {"run_day": nt[0].isoformat(), "business_date": nt[1].isoformat()}
    else:
        out["notes"].append("this feed has no date rule (on demand / on completion of another feed): "
                            "a run is for the date it is started for")
    if out["next"]:
        out["default"], out["source"] = out["next"]["business_date"], "next_task"
    elif out["current"]:
        out["default"], out["source"] = out["current"]["business_date"], "current"
    else:
        out["default"], out["source"] = today.isoformat(), "today"
    return out


def _coerce_date(v: Any) -> Optional[date]:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v).strip()[:10])
    except ValueError:
        raise TestAsFeedRefused(f"business_date {v!r} is not a date (YYYY-MM-DD)") from None


def _synthetic_run(business_date: date, run_day: date) -> Dict[str, Any]:
    """The run the engine's resolver reads -- WITHOUT an id, so
    ``executed_sql.run_id_of`` answers None and the render records nothing."""
    return {"business_date": business_date, "run_date": run_day,
            "scheduled_time": datetime(run_day.year, run_day.month, run_day.day, tzinfo=timezone.utc)}


# ── the principal and what it holds ──────────────────────────────────────────

def _principal_block(db: Any, feed: Dict[str, Any]) -> Dict[str, Any]:
    from core.feed.rls import feed_principal
    p = feed_principal(db, feed)
    gid = feed.get("owner_group_id")
    group = None
    if gid:
        try:
            g = db.get_user_group(int(gid))
            group = {"id": int(gid), "name": (g or {}).get("name") if isinstance(g, dict) else None}
        except Exception as exc:                        # noqa: BLE001
            group = {"id": int(gid), "name": None, "unavailable": str(exc)}
    scope = p.get("entitlement_scope")
    return {
        "username": p.get("username"), "groups": list(p.get("groups") or []),
        "entitlement_scope": list(scope) if isinstance(scope, (tuple, list)) else scope,
        "principal_type": PRINCIPAL_TYPE, "owner_group": group,
        "resolved_by": "core/feed/rls.py::feed_principal",
        "_ctx": p,
    }


def _holds(db: Any, principal: Dict[str, Any]) -> Tuple[Optional[List[Dict[str, Any]]], Optional[str]]:
    """What the owner group HOLDS per active dimension (``explain_for`` -- the
    ``/api/me/entitlements`` reader) or why it could not be read."""
    try:
        from core.row_security.api import build_user_ctx
        from core.row_security.entitlement import explain_for
        return explain_for(build_user_ctx(principal), db), None
    except Exception as exc:                            # noqa: BLE001 -- said, never "none"
        return None, str(exc)


# ── one side ─────────────────────────────────────────────────────────────────

def _json_cell(v: Any) -> Any:
    if v is None or isinstance(v, (str, bool, int)):
        return v
    if isinstance(v, float):
        return None if (math.isnan(v) or math.isinf(v)) else v
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return str(v)


def _read_sample(path: str, limit: int) -> Tuple[List[Dict[str, str]], List[List[Any]]]:
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(path)
    cols = [{"name": f.name, "type": str(f.type)} for f in pf.schema_arrow]
    rows: List[List[Any]] = []
    for batch in pf.iter_batches(batch_size=min(limit, 1024)):
        for rec in batch.to_pylist():
            rows.append([_json_cell(rec.get(c["name"])) for c in cols])
            if len(rows) >= limit:
                return cols, rows
    return cols, rows


def _refusal_of(exc: BaseException) -> Dict[str, Any]:
    """Classify a securing failure by its CAUSE chain, never its text:
    an ``EntitlementRefused`` carries its ``kind``."""
    from core.row_security.entitlement import EntitlementRefused, UNDETERMINED_KINDS
    e: Optional[BaseException] = exc
    while e is not None:
        if isinstance(e, EntitlementRefused):
            kind = getattr(e, "kind", "refused")
            return {"entitlement": True, "kind": kind,
                    "state": STATE_UNDETERMINED if kind in UNDETERMINED_KINDS else STATE_REFUSED,
                    "message": str(e)}
        e = e.__cause__
    return {"entitlement": False, "kind": "row_security_refused", "state": STATE_REFUSED,
            "message": str(exc)}


def _disclose(result: Any) -> Dict[str, Any]:
    """The rewriter's record, projected: per table, the entitlement policies
    (dimension / columns / values / principals) and the stored policies by
    name; ``examined`` False when no rewrite ran at all."""
    if result is None:
        return {"examined": False, "tables": [], "skipped": [], "entitlements": []}
    tables, ents = [], []
    for entry in (getattr(result, "applied", None) or []):
        rp = entry.get("row_policies") or []
        ent_here = [p.get("entitlement") for p in rp
                    if isinstance(p, dict) and p.get("source") == "entitlement" and p.get("entitlement")]
        others = [p.get("name") for p in rp if isinstance(p, dict) and p.get("source") != "entitlement"]
        for e in ent_here:
            ents.append({"table": entry.get("table"), **e})
        tables.append({"table": entry.get("table"), "rewritten": bool(entry.get("rewritten")),
                       "entitlements": ent_here, "row_policies": others,
                       "column_policies": len(entry.get("column_policies") or [])})
    skipped = [s.get("table") if isinstance(s, dict) else str(s)
               for s in (getattr(result, "skipped", None) or [])]
    return {"examined": True, "tables": tables, "skipped": skipped, "entitlements": ents}


def _run_side(db: Any, label: str, side_cfg: Dict[str, Any], sql_text: str, conn_id: Any,
              *, feed_run: Dict[str, Any], calendar: Any, limit: int, cancel_event: Any,
              tmpdir: str, request_id: str) -> Dict[str, Any]:
    from core.feed.param_resolver import apply_to_raw_sql
    from core.feed.rls import secure_feed_sql_report
    from core.feed_engine import _TokenRefusal
    from core.connectors import SQL_CONNECTOR_TYPES
    from core.virtual_ref_rewriter import rewrite_virtual_refs

    t0 = time.monotonic()
    out: Dict[str, Any] = {"side": label, "connection_id": conn_id, "connection_name": None,
                           "connection_type": None, "sql_as_written": sql_text, "sql_as_executed": None,
                           "row_security": None, "columns": None, "rows": None, "rows_shown": 0,
                           "row_count": None, "row_count_exact": None, "truncated": None,
                           "error": None, "stage": None, "refusal": None, "notes": [], "elapsed_ms": None}
    try:
        conn = db.get_connection_raw(int(conn_id)) if conn_id is not None else None
    except Exception as exc:                            # noqa: BLE001
        conn = None
        out["notes"].append(f"connection read failed: {exc}")
    if not conn:
        out["error"] = f"connection {conn_id} not found -- the run would fail here"
        out["stage"] = "connection"
        return out
    conn_config = conn.get("config") or {}
    conn_type = str(conn.get("connection_type") or conn_config.get("type") or "")
    out["connection_name"], out["connection_type"] = conn.get("name"), conn_type

    # 1 -- the engine's render (the one chokepoint; a token refusal fails the run)
    try:
        rendered = apply_to_raw_sql(sql_text, side_cfg, feed_run=feed_run, calendar=calendar)
    except _TokenRefusal as exc:
        out["error"] = f"the run would FAIL rendering its parameters: {exc}"
        out["stage"] = "render"
        return out
    except Exception as exc:                            # noqa: BLE001 -- the engine runs the SQL as-is here
        rendered = sql_text
        out["notes"].append(f"parameter substitution failed ({exc}) -- the run would run the SQL as written")
    # 2 -- the DuckDB road's virtual refs (the engine rewrites them before securing)
    if conn_type not in SQL_CONNECTOR_TYPES:
        rendered = rewrite_virtual_refs(rendered) or rendered
    # 3 -- THE securing (core/feed/rls.py), the SAME call the run makes
    try:
        secured, result = secure_feed_sql_report(
            db, rendered, side_cfg, connection_id=conn.get("id"),
            connection_type=conn_type or "duckdb", request_id=request_id)
    except ValueError as exc:
        out["refusal"] = _refusal_of(exc)
        out["error"] = f"the run would be REFUSED by row security: {exc}"
        out["stage"] = "row_security"
        return out
    out["sql_as_executed"] = secured
    out["row_security"] = _disclose(result)
    if cancel_event is not None and cancel_event.is_set():
        out["error"], out["stage"] = "the preview was stopped before this side was read", "read"
        return out
    # 4 -- the bounded read through THE side runner
    from core.executors.cross_source_combine import SideSpec, run_side_to_parquet
    sample_path = os.path.join(tmpdir, f"{label}_{uuid.uuid4().hex[:8]}.parquet")
    try:
        outcome = run_side_to_parquet(
            SideSpec(label=label, connection=conn, sql=secured), sample_path,
            row_cap=limit, cancel_event=cancel_event, db_manager=db,
            execution_id=request_id)
    except Exception as exc:                            # noqa: BLE001 -- the source's verdict IS the answer
        from core.error_sanitizer import describe_exception
        try:
            msg = describe_exception(exc)
        except Exception:                               # noqa: BLE001
            msg = str(exc)
        out["error"] = f"the run would FAIL reading this side: {msg}"
        out["stage"] = "read"
        return out
    try:
        cols, rows = _read_sample(sample_path, limit)
    except Exception as exc:                            # noqa: BLE001
        out["error"], out["stage"] = f"the sample could not be read back: {exc}", "read"
        return out
    out["columns"], out["rows"], out["rows_shown"] = cols, rows, len(rows)
    out["truncated"] = bool(outcome.truncated)
    if not outcome.truncated:
        out["row_count"], out["row_count_exact"] = int(outcome.rows), True
    else:
        # more rows than shown: count them on the engine (never a guess)
        out["row_count"], out["row_count_exact"] = _count_rows(
            db, conn, secured, tmpdir, label, cancel_event, request_id, out["notes"])
    out["elapsed_ms"] = int((time.monotonic() - t0) * 1000)
    return out


def _count_rows(db: Any, conn: Dict[str, Any], secured_sql: str, tmpdir: str, label: str,
                cancel_event: Any, request_id: str, notes: List[str]) -> Tuple[Optional[int], Optional[bool]]:
    from core.executors.cross_source_combine import SideSpec, run_side_to_parquet, _strip_sql
    if cancel_event is not None and cancel_event.is_set():
        notes.append("row count skipped: the preview was stopped")
        return None, None
    count_sql = f"SELECT COUNT(*) AS qs_rows FROM ({_strip_sql(secured_sql)}) AS _qs_test_as_feed"
    path = os.path.join(tmpdir, f"{label}_count_{uuid.uuid4().hex[:8]}.parquet")
    try:
        run_side_to_parquet(SideSpec(label=f"{label}-count", connection=conn, sql=count_sql), path,
                            row_cap=None, cancel_event=cancel_event, db_manager=db,
                            execution_id=f"{request_id}-count")
        import pyarrow.parquet as pq
        tbl = pq.read_table(path)
        n = tbl.column(0)[0].as_py() if tbl.num_rows else None
        return (int(n) if n is not None else None), (n is not None)
    except Exception as exc:                            # noqa: BLE001 -- said; the sample stands
        notes.append(f"the row count could not be taken ({exc}); more rows exist than shown")
        return None, False


# ── the whole preview ────────────────────────────────────────────────────────

def _entitlement_block(db: Any, feed: Dict[str, Any], sides: List[Dict[str, Any]],
                       principal: Dict[str, Any]) -> Dict[str, Any]:
    """ONE verdict over every side, in the ``STATE_*`` vocabulary."""
    from core.row_security import api as rs
    from core.row_security import entitlement as ent
    from core.row_security.entitlement import effective_mode
    mode = effective_mode(feed.get("entitlement_mode"), "feed")
    block: Dict[str, Any] = {"mode": mode, "principal_type": PRINCIPAL_TYPE, "state": None,
                             "reason": None, "dimensions": [], "holds": None, "holds_unavailable": None}
    if mode != "apply":
        block["state"] = STATE_OFF
        block["reason"] = ("entitlement_mode is off: the feed reads every row its stored row "
                           "policies allow (an administrator switches it on)")
        return block
    # the SAME seam the engine short-circuits on (``secure_sql_report``:
    # ``_is_enabled()`` and a wired store / resolver) -- never a second reading
    # of the config, which a test pin or a runtime overlay would disagree with
    eng = rs.engine_state()
    try:
        enabled = bool(rs._is_enabled())
    except Exception:                                   # noqa: BLE001 -- unreadable = on, as the engine reads it
        enabled = True
    if not enabled or not eng.get("wired"):
        block["state"] = STATE_ENGINE_OFF
        why = eng.get("reason") or "row security is switched off (row_security.enabled / _is_enabled)"
        block["reason"] = (f"{why} -- entitlement_mode 'apply' has NO effect on this pod; "
                           f"the run would read every row")
        return block
    refusals = [s["refusal"] for s in sides if s.get("refusal") and s["refusal"].get("entitlement")]
    if refusals:
        block["state"] = refusals[0]["state"]
        block["reason"] = refusals[0]["message"]
        block["refusal_kind"] = refusals[0]["kind"]
    else:
        try:
            active = ent.any_active(db)
        except Exception as exc:                        # noqa: BLE001 -- unknown is not "none"
            block["state"] = STATE_UNDETERMINED
            block["reason"] = f"the entitlement dimensions could not be read: {exc}"
            return block
        applied = [e for s in sides for e in ((s.get("row_security") or {}).get("entitlements") or [])]
        unexamined = [s["side"] for s in sides
                      if s.get("error") or not (s.get("row_security") or {}).get("examined")]
        if not active:
            block["state"] = STATE_NO_DIMENSION
            block["reason"] = "no active entitlement dimension exists -- nothing to apply"
        elif applied:
            block["state"] = STATE_APPLIED
            block["dimensions"] = applied
            block["reason"] = (f"{len(applied)} entitlement filter(s) applied for owner group "
                               f"{(principal.get('owner_group') or {}).get('name') or principal.get('owner_group')}")
        elif unexamined:
            block["state"] = STATE_UNDETERMINED
            block["reason"] = ("a side could not be examined by row security: "
                               + "; ".join(f"{s['side']}: {s.get('error')}" for s in sides
                                           if s["side"] in unexamined))
        else:
            block["state"] = STATE_NOT_GOVERNED
            block["reason"] = ("dimensions are active but no table this feed reads carries an entitled "
                               "column -- the owner group's values do not narrow it")
    if feed.get("owner_group_id"):
        block["holds"], block["holds_unavailable"] = _holds(db, principal["_ctx"])
    return block


def preview(db: Any, feed: Dict[str, Any], *, business_date: Any = None, limit: Optional[int] = None,
            cancel_event: Any = None, requested_by: Optional[str] = None) -> Dict[str, Any]:
    """Run the feed's source query (both sides of a two-sided feed), bounded,
    as the FEED's principal, for a business date, and say what the run would
    deliver and why.  Writes nothing of the feed's: no run row, no file in its
    output dir, no delivery, no executed-SQL record."""
    from core.feed.source_plan import inherit_cross_source, secondary_side_config
    from core.feed_engine import _load_calendar_for_feed
    from core.feed.param_resolver import resolve_feed_params
    from core.feed_sql_resolver import resolve_feed_sql
    from core.feed.executed_sql import _scalar_params

    t0 = time.monotonic()
    cap = max_rows()
    lim = int(limit) if limit is not None else cap
    if lim < 1 or lim > ROW_CEILING:
        raise TestAsFeedRefused(f"limit must be between 1 and {ROW_CEILING} (asked {lim})")
    request_id = f"test-as-feed-{feed.get('id')}-{uuid.uuid4().hex[:8]}"
    feed = dict(feed)
    feed.pop("_feed_run", None)                         # a preview belongs to NO run

    # the date, by the run's own readers
    dates = business_date_choices(db, feed)
    asked = _coerce_date(business_date)
    if asked is not None:
        bd, run_day, src = asked, _today(), "requested"
    else:
        bd = date.fromisoformat(dates["default"])
        run_day = (date.fromisoformat(dates["next"]["run_day"]) if dates["source"] == "next_task"
                   else _today())
        src = dates["source"]
    feed_run = _synthetic_run(bd, run_day)
    calendar = _load_calendar_for_feed(feed, db=db)
    params = _scalar_params(resolve_feed_params(feed, feed_run, calendar))

    principal = _principal_block(db, feed)

    # the sides, as the SQL preview resolves them
    resolved = resolve_feed_sql(db, feed)
    probe = dict(feed)
    if not probe.get("secondary_connection_id"):
        try:
            inherit_cross_source(db, probe.get("source_type") or "", probe.get("source_id"), probe)
        except Exception as exc:                        # noqa: BLE001 -- resolve_feed_sql said "refused"
            logger.debug("[test_as_feed] cross-source inheritance probe: %s", exc)
    is_cross = bool(probe.get("secondary_connection_id"))
    plans: List[Tuple[str, Dict[str, Any], Optional[str], Any, Optional[str], Optional[str]]] = [
        ("primary", {**probe, "_cross_side": "primary"} if is_cross else dict(feed),
         resolved.get("sql"), resolved.get("connection_id"),
         resolved.get("source_status"), resolved.get("source_message")),
    ]
    if is_cross:
        plans.append(("secondary", secondary_side_config(probe), resolved.get("secondary_sql"),
                      resolved.get("secondary_connection_id"),
                      resolved.get("secondary_source_status"), resolved.get("secondary_source_message")))

    sides: List[Dict[str, Any]] = []
    tmpdir = tempfile.mkdtemp(prefix="qs_test_as_feed_")
    try:
        for label, side_cfg, sql_text, conn_id, status, message in plans:
            if status not in (None, "ok") or not sql_text:
                sides.append({"side": label, "connection_id": conn_id, "sql_as_written": sql_text,
                              "error": f"the source does not resolve ({status}): {message}",
                              "stage": "source", "rows": None, "row_count": None, "refusal": None,
                              "row_security": None, "notes": []})
                continue
            if cancel_event is not None and cancel_event.is_set():
                sides.append({"side": label, "connection_id": conn_id, "sql_as_written": sql_text,
                              "error": "the preview was stopped before this side ran", "stage": "read",
                              "rows": None, "row_count": None, "refusal": None, "row_security": None,
                              "notes": []})
                continue
            sides.append(_run_side(db, label, side_cfg, sql_text, conn_id, feed_run=feed_run,
                                   calendar=calendar, limit=lim, cancel_event=cancel_event,
                                   tmpdir=tmpdir, request_id=request_id))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    entitlement = _entitlement_block(db, feed, sides, principal)
    principal.pop("_ctx", None)
    out = {
        "feed_id": feed.get("id"), "feed_name": feed.get("name"),
        "entitlement_mode": _effective_feed_mode(feed),
        "business_date": {"value": bd.isoformat(), "run_day": run_day.isoformat(), "source": src,
                          "choices": dates, "calendar": feed.get("calendar_name")},
        "params": params,
        "principal": principal,
        "entitlement": entitlement,
        "sides": sides,
        "cross_source": is_cross,
        "combine_mode": resolved.get("combine_mode") if is_cross else None,
        "limit": lim, "lane": LANE,
        "delivered": False, "feed_run_created": False,
        "requested_by": requested_by,
        "elapsed_ms": int((time.monotonic() - t0) * 1000),
        "note": ("Nothing was delivered and no run was created.  Each side is shown as the run "
                 "would read it; a two-sided run merges them by column name."
                 + ("  The preview reads natively; the run's lane may be Spark." if feed.get("execution_backend")
                    not in (None, "", "native", "auto") else "")),
    }
    return out


def planned_sql(db: Any, feed: Dict[str, Any], business_date: date, run_day: Optional[date] = None
                ) -> List[Dict[str, Any]]:
    """What a run that has not started WILL send, per side: the feed's SQL
    with every parameter and {TOKEN} filled in for ``business_date`` by the
    engine's own render (``apply_to_raw_sql``).  Nothing is executed or
    secured (row security is applied when the run starts).  Never raises: a
    side that cannot be rendered says why (2026-10-25, the owner: "sql as
    executed doesn't show what query was executing")."""
    from core.feed.source_plan import inherit_cross_source, secondary_side_config
    from core.feed_engine import _TokenRefusal, _load_calendar_for_feed
    from core.feed.param_resolver import apply_to_raw_sql, resolve_feed_params
    from core.feed_sql_resolver import resolve_feed_sql
    from core.feed.executed_sql import _scalar_params
    feed = dict(feed)
    feed.pop("_feed_run", None)
    out: List[Dict[str, Any]] = []
    try:
        feed_run = _synthetic_run(business_date, run_day or _today())
        calendar = _load_calendar_for_feed(feed, db=db)
        params = _scalar_params(resolve_feed_params(feed, feed_run, calendar))
        resolved = resolve_feed_sql(db, feed)
        probe = dict(feed)
        if not probe.get("secondary_connection_id"):
            try:
                inherit_cross_source(db, probe.get("source_type") or "", probe.get("source_id"), probe)
            except Exception:                           # noqa: BLE001 -- resolve_feed_sql said "refused"
                pass
        is_cross = bool(probe.get("secondary_connection_id"))
        plans = [("primary", {**probe, "_cross_side": "primary"} if is_cross else dict(feed),
                  resolved.get("sql"), resolved.get("source_status"), resolved.get("source_message"))]
        if is_cross:
            plans.append(("secondary", secondary_side_config(probe), resolved.get("secondary_sql"),
                          resolved.get("secondary_source_status"), resolved.get("secondary_source_message")))
    except Exception as exc:                            # noqa: BLE001 -- said, never raised
        return [{"side": "primary", "sql": None, "params": {}, "error": f"the query could not be prepared: {exc}"}]
    for label, side_cfg, sql_text, status, message in plans:
        if status not in (None, "ok") or not sql_text:
            out.append({"side": label, "sql": None, "params": params,
                        "error": f"the feed's source cannot be read ({status}): {message}"})
            continue
        try:
            sql = apply_to_raw_sql(sql_text, side_cfg, feed_run=feed_run, calendar=calendar)
            out.append({"side": label, "sql": sql, "template": sql_text, "params": params, "error": None})
        except _TokenRefusal as exc:
            out.append({"side": label, "sql": None, "template": sql_text, "params": params,
                        "error": f"the run will FAIL filling in its values: {exc}"})
        except Exception as exc:                        # noqa: BLE001
            out.append({"side": label, "sql": sql_text, "template": sql_text, "params": params,
                        "error": f"values could not be filled in ({exc}); the SQL is shown as written"})
    return out


def new_cancel_event():
    return threading.Event()


def _effective_feed_mode(feed) -> str:
    from core.row_security.entitlement import effective_mode
    return effective_mode((feed or {}).get("entitlement_mode"), "feed")
