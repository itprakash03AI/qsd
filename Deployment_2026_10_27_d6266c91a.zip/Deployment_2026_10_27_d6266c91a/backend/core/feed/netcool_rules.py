"""WHEN an event goes to Netcool and WHAT it says -- rules as DATA (2026-10-25).

The owner: "we need config based netcool -- when to send and what events".

ONE decision, at THE chokepoint every producer calls
(``core/feed/netcool.py::enqueue_event`` -- the alert road, the SLA
watcher's dependency ladder, the report SLO, the published-API alerts,
component health):

    decide(event, now) -> Decision(action, rule, reason, event)

* the first ACTIVE ``netcool_rules`` row (lowest ``priority``, then id) whose
  MATCH fields all hold (AlertGroup, alert type, object glob, severity band)
  AND whose WHEN fields hold at ``now`` (week days, a business calendar's
  working days, a time window in a time zone -- the window may wrap past
  midnight) decides ``send`` or ``suppress``, and may override the severity
  and the AlertGroup of what is sent;
* no rule matches -> ``feed_generation.netcool.default_action`` (``send``).

Three rules that are NOT configurable, on purpose:
* the HEARTBEAT is always sent -- a suppressed liveness signal makes the
  console page "the sender is dead";
* a RESOLUTION is decided only by rules WITHOUT when-fields (a quiet-hours
  rule never holds back the clear of a problem sent in the day); a rule
  that never sends a type also never sends its clear (nothing to clear);
* a rule store that cannot be read SENDS (and says so once): an unreadable
  configuration must never silence the pager.
"""
from __future__ import annotations

import fnmatch
import logging
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

ACTIONS = ("send", "suppress")
_TTL_SECONDS = 30.0
_lock = threading.Lock()
_memo: Dict[str, Any] = {"at": 0.0, "rules": None}
_warned_unreadable = {"done": False}


@dataclass(frozen=True)
class Decision:
    action: str                       # send | suppress
    rule_id: Optional[int]
    rule_name: Optional[str]
    reason: str
    event: Any                        # the event to send (overrides applied)

    @property
    def send(self) -> bool:
        return self.action == "send"


def invalidate() -> None:
    with _lock:
        _memo.update({"at": 0.0, "rules": None})


def parse_identifier(identifier: str) -> Dict[str, str]:
    """``QS:<env>:<alert type>:<object>:<business date>`` -> its parts (the
    object may itself contain ':')."""
    parts = str(identifier or "").split(":")
    if len(parts) < 5:
        return {"env": "", "alert_type": "", "object": str(identifier or ""), "business_date": ""}
    return {"env": parts[1], "alert_type": parts[2], "object": ":".join(parts[3:-1]),
            "business_date": parts[-1]}


def _default_action() -> str:
    try:
        from core.config import get as _get
        v = str((_get("feed_generation", "netcool", {}) or {}).get("default_action") or "send").lower()
    except Exception:                                   # noqa: BLE001
        v = "send"
    return v if v in ACTIONS else "send"


def _db():
    try:
        from core.database import get_db_manager
        return get_db_manager()
    except Exception:                                   # noqa: BLE001
        return None


def load_rules(db=None) -> Optional[List[Dict[str, Any]]]:
    """The ACTIVE rules in decision order, memoised ``_TTL_SECONDS``; None =
    the store could not be read."""
    now = time.monotonic()
    with _lock:
        if _memo["rules"] is not None and now - _memo["at"] < _TTL_SECONDS:
            return _memo["rules"]
    db = db or _db()
    if db is None:
        return None
    try:
        from core.db.models import NetcoolRule
        with db.get_session(read_only=True) as s:
            rows = [r.to_dict() for r in s.query(NetcoolRule)
                    .filter(NetcoolRule.is_active == True)                  # noqa: E712
                    .order_by(NetcoolRule.priority.asc(), NetcoolRule.id.asc()).all()]
    except Exception as exc:                            # noqa: BLE001 -- said below, sends
        if not _warned_unreadable["done"]:
            logger.error("[netcool_rules] the rules could not be read (%s) -- every event is SENT "
                         "until they can (an unreadable configuration never silences the pager)", exc)
            _warned_unreadable["done"] = True
        return None
    _warned_unreadable["done"] = False
    with _lock:
        _memo.update({"at": now, "rules": rows})
    return rows


def _hhmm(text: Optional[str]) -> Optional[int]:
    if not text:
        return None
    h, m = str(text).split(":")
    return int(h) * 60 + int(m)


def _in_window(rule: Dict[str, Any], local: datetime) -> bool:
    lo, hi = _hhmm(rule.get("window_from")), _hhmm(rule.get("window_to"))
    if lo is None and hi is None:
        return True
    t = local.hour * 60 + local.minute
    lo = 0 if lo is None else lo
    hi = 24 * 60 if hi is None else hi
    return lo <= t < hi if lo <= hi else (t >= lo or t < hi)      # wraps past midnight


def _local(now: datetime, tz: Optional[str]) -> datetime:
    try:
        from zoneinfo import ZoneInfo
        return now.astimezone(ZoneInfo(tz or "UTC"))
    except Exception:                                   # noqa: BLE001 -- an unknown zone reads as UTC
        return now.astimezone(timezone.utc)


_cal_repo: Dict[str, Any] = {"repo": None, "db": None}


def _is_business_day(calendar_name: str, day, db=None) -> Optional[bool]:
    """The calendar's own answer (THE BusinessCalendar SOD uses); None when
    it cannot be read or speak for the date -- the rule then still applies
    (an unreadable calendar never silences the pager)."""
    try:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        db = db or _db()
        if _cal_repo["repo"] is None or _cal_repo["db"] is not db:
            _cal_repo.update({"repo": BusinessCalendarRepo(db), "db": db})
        spec = _cal_repo["repo"].get(str(calendar_name))
        if spec is None:
            return None
        return bool(BusinessCalendar(spec).is_business_day(day))
    except Exception:                                   # noqa: BLE001
        return None


def _what_matches(rule: Dict[str, Any], event: Any, parts: Dict[str, str]) -> bool:
    if rule.get("match_alert_group") and str(rule["match_alert_group"]).upper() != str(event.alert_group).upper():
        return False
    if rule.get("match_alert_type") and str(rule["match_alert_type"]).upper() != parts["alert_type"].upper():
        return False
    if rule.get("match_object") and not fnmatch.fnmatchcase(parts["object"].lower(),
                                                            str(rule["match_object"]).lower()):
        return False
    sev = int(event.severity)
    if rule.get("match_min_severity") is not None and sev < int(rule["match_min_severity"]):
        return False
    if rule.get("match_max_severity") is not None and sev > int(rule["match_max_severity"]):
        return False
    return True


def _when_matches(rule: Dict[str, Any], now: datetime, db=None) -> bool:
    local = _local(now, rule.get("timezone"))
    days = rule.get("days")
    if days and local.weekday() not in {int(d) for d in days}:
        return False
    if rule.get("business_days_calendar"):
        bd = _is_business_day(rule["business_days_calendar"], local.date(), db)
        if bd is False:
            return False
    return _in_window(rule, local)


def _has_when(rule: Dict[str, Any]) -> bool:
    return bool(rule.get("days") or rule.get("business_days_calendar")
                or rule.get("window_from") or rule.get("window_to"))


def _record_match(rule_id: int, db=None) -> None:
    try:
        from core.db.models import NetcoolRule
        db = db or _db()
        with db.get_session() as s:
            r = s.query(NetcoolRule).filter(NetcoolRule.id == int(rule_id)).first()
            if r is not None:
                r.match_count = int(r.match_count or 0) + 1
                r.last_matched_at = datetime.now(timezone.utc)
    except Exception as exc:                            # noqa: BLE001 -- a counter, never the decision
        logger.debug("[netcool_rules] match counter not written: %s", exc)


def decide(event: Any, now: Optional[datetime] = None, *, db=None, rules=None,
           record: bool = True) -> Decision:
    """THE decision for one event.  ``rules`` (tests, the dry run) replaces
    the store; ``record`` counts the match on the rule row."""
    from core.feed import netcool as nc
    now = now or datetime.now(timezone.utc)
    parts = parse_identifier(getattr(event, "identifier", ""))
    if parts["alert_type"].upper() == "HEARTBEAT":
        return Decision("send", None, None, "the heartbeat is always sent", event)
    resolution = int(getattr(event, "type", nc.TYPE_PROBLEM)) == nc.TYPE_RESOLUTION
    rules = load_rules(db) if rules is None else rules
    if rules is None:
        return Decision("send", None, None, "the rules could not be read -- sent", event)
    for rule in rules:
        if not rule.get("is_active", True) or not _what_matches(rule, event, parts):
            continue
        if resolution and _has_when(rule):
            continue          # a time-gated rule never holds back a CLEAR
        if not resolution and not _when_matches(rule, now, db):
            continue
        action = str(rule.get("action") or "send").lower()
        if action not in ACTIONS:
            action = "send"
        out = event
        if action == "send" and not resolution:
            if rule.get("severity_override") is not None:
                out = replace(out, severity=int(rule["severity_override"]))
            if rule.get("alert_group_override"):
                out = replace(out, alert_group=str(rule["alert_group_override"]))
        elif action == "send" and resolution and rule.get("alert_group_override"):
            # the clear must land on the group its problem was sent under
            out = replace(out, alert_group=str(rule["alert_group_override"]))
        if record and rule.get("id") is not None:
            _record_match(int(rule["id"]), db)
        return Decision(action, rule.get("id"), rule.get("name"),
                        f"rule '{rule.get('name')}' ({action})", out)
    act = _default_action()
    return Decision(act, None, None, f"no rule matched -- the default ({act})", event)


def validate(body: Dict[str, Any]) -> List[str]:
    """Every refusal of a rule, named (the route answers them in one 422)."""
    from core.feed.netcool import ALERT_GROUPS
    problems: List[str] = []
    if str(body.get("action") or "").lower() not in ACTIONS:
        problems.append(f"action must be one of {list(ACTIONS)}")
    for f in ("match_alert_group", "alert_group_override"):
        v = body.get(f)
        if v and str(v).upper() not in ALERT_GROUPS:
            problems.append(f"{f} must be one of {sorted(ALERT_GROUPS)}")
    for f in ("match_min_severity", "match_max_severity", "severity_override"):
        v = body.get(f)
        if v is not None and not (0 <= int(v) <= 5):
            problems.append(f"{f} must be 0..5 (Netcool severities)")
    for f in ("window_from", "window_to"):
        v = body.get(f)
        if v:
            try:
                h, m = str(v).split(":")
                if not (0 <= int(h) <= 23 and 0 <= int(m) <= 59):
                    raise ValueError
            except ValueError:
                problems.append(f"{f} must be HH:MM")
    days = body.get("days")
    if days is not None and (not isinstance(days, list) or any(int(d) not in range(7) for d in days)):
        problems.append("days must be a list of 0..6 (Monday = 0)")
    if body.get("timezone"):
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(str(body["timezone"]))
        except Exception:                               # noqa: BLE001
            problems.append(f"timezone '{body['timezone']}' is not a known time zone")
    return problems
