"""THE cancel of a feed run (2026-10-26) -- one body, every entry.

The owner: *"if any feed is running and we need to cancel, we should be able
to cancel in case something is wrong ... the same cancellation should be done
at the source also"*.

``cancel_execution`` is what both routes call (``POST /api/feed-executions/
{id}/cancel`` and ``POST /api/feed-runs/{id}/cancel`` on a running run) and
what a test drives.  In order:

1. the EXECUTION row is closed FIRST -- ``cancelled``, ``cancelled_by`` /
   ``cancelled_at``, the words -- so a pod that has not started the task, or
   runs it elsewhere, sees the cancel on its next look (the engine's run-wide
   DB watcher, ``feed_engine._watch_cancel_in_db``, every 2 s);
2. its RUN row is closed with it (found live 2026-10-11: a run left
   ``running`` was reset to ``pending`` by the orphan reaper and EXECUTED
   AGAIN after the operator cancelled it) -- a cancelled run is never claimed
   by the queue, the reaper or the completion-time refill;
3. the in-process event is REQUESTED (``signal_cancel``), which every lane of
   a run on THIS pod watches: the connector watchdogs cancel their statement
   at the source (Trino ``cur.cancel()``, Snowflake ``abort_query`` /
   ``SYSTEM$CANCEL_QUERY``, Oracle ``connection.cancel()``, Databricks
   ``cur.cancel()``), the DuckDB watchdog interrupts, the DuckDB child and
   the CSV writer processes are terminated, an upload in flight is
   abandoned, the Spark await deletes the pod, the Airflow await marks the
   DAG run failed;
4. a detached spark_k8s workload is deleted HERE as well, best-effort (this
   pod may lack cluster access; the reconciler's terminal-row sweep is the
   guarantee).

What the stop REACHED is written by the engine when it ends the run
(``files_metadata.cancel``, ``error_message`` in words -- "Stopped at the
source: ..." or "The query may still be running on ..."); this module writes
who asked and when.  Nothing here raises for a secondary failure: the
execution's cancel is the answer, and a run or a pod left behind is logged.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

__all__ = ["cancel_execution", "cancel_run_without_execution", "CANCELLABLE_EXECUTION_STATES"]

#: an execution in one of these can be cancelled; the rest are over
CANCELLABLE_EXECUTION_STATES = ("pending", "running")


def _who(user: Optional[Dict[str, Any]]) -> str:
    return str((user or {}).get("username") or "unknown")


def _words(by: str, at: datetime) -> str:
    return f"Cancelled by {by} at {at.strftime('%Y-%m-%d %H:%M:%S UTC')}."


def cancel_execution(db: Any, execution: Dict[str, Any], user: Optional[Dict[str, Any]],
                     *, now: Optional[datetime] = None,
                     spark_runner_factory: Any = None) -> Dict[str, Any]:
    """Cancel ``execution`` everywhere (see the module docstring).  Returns
    the answer the routes give: who, when, whether the in-process event was
    signalled on this pod, what happened to the run row and the Spark pod."""
    at = now or datetime.now(timezone.utc)
    by = _who(user)
    exec_db_id = int(execution["id"])
    exec_key = str(execution.get("execution_id") or "")
    words = _words(by, at)

    # 1. the execution row, FIRST
    db.update_feed_execution(exec_db_id, {
        "status": "cancelled",
        "completed_at": at,
        "cancelled_by": by,
        "cancelled_at": at,
        "error_message": words + " Stopping the query at the source...",
    })

    # 2. its run
    run_outcome = _cancel_run_of(db, execution, by, at)

    # 3. the in-process event
    signalled = False
    try:
        from core.feed_engine import signal_cancel
        signalled = bool(signal_cancel(exec_key, requested_by=by))
    except Exception as sig_exc:  # noqa: BLE001
        logger.debug("[feed_cancel] signal_cancel raised (non-fatal): %s", sig_exc)

    # 4. a detached Spark workload
    spark: Optional[Dict[str, Any]] = None
    if (execution.get("execution_backend") or "").lower() == "spark_k8s":
        spark = _delete_spark_workload(db, execution, spark_runner_factory)

    logger.info("[feed_cancel] execution %s (%s) cancelled by %s -- run %s, in-process "
                "signal %s%s", exec_db_id, exec_key, by, run_outcome.get("state"),
                "sent" if signalled else "not on this pod",
                f", spark {spark.get('state')}" if spark else "")
    return {
        "detail": "Execution cancelled",
        "id": exec_db_id,
        "execution_id": exec_key,
        "cancelled_by": by,
        "cancelled_at": at.isoformat(),
        "signalled_here": signalled,
        "run": run_outcome,
        "spark": spark,
        "words": words,
    }


def _cancel_run_of(db: Any, execution: Dict[str, Any], by: str, at: datetime) -> Dict[str, Any]:
    """Close the execution's bound feed_run when it is still active.
    Best-effort: a run left behind is logged, never a 500."""
    try:
        fr_for = getattr(db, "feed_run_for_execution", None)
        fr = fr_for(execution) if callable(fr_for) else None
        if not fr:
            return {"state": "no_run", "run_id": None}
        if (fr.get("status") or "") not in ("pending", "running"):
            return {"state": "already_over", "run_id": fr.get("id"), "status": fr.get("status")}
        db.update_feed_run(int(fr["id"]), {
            "status": "cancelled",
            "completed_at": at,
            "cancelled_by": by,
            "cancelled_at": at,
            "error": (f"{_words(by, at)} Cancelled with execution {execution.get('id')}."),
        })
        return {"state": "cancelled", "run_id": int(fr["id"])}
    except Exception as exc:  # noqa: BLE001
        from core.cancel_scope import describe as _describe
        logger.warning("cancel of execution %s: its feed_run was not cancelled with it "
                       "(%s) -- the orphan reaper may re-queue it", execution.get("id"), exc)
        return {"state": "not_cancelled", "run_id": None, "error": _describe(exc)[:300]}


def _delete_spark_workload(db: Any, execution: Dict[str, Any], factory: Any) -> Dict[str, Any]:
    """Delete the execution's SparkApplication / driver pod, best-effort."""
    try:
        if factory is None:
            from core.spark_k8s.runner import SparkK8sRunner
            runner = SparkK8sRunner(db)
        else:
            runner = factory(db)
        deleted = bool(runner.cancel(dict(execution)))
        return {"state": "deleted" if deleted else "not_on_cluster",
                "workload": execution.get("external_job_id")}
    except Exception as cr_exc:  # noqa: BLE001
        from core.cancel_scope import describe as _describe
        logger.warning("[feed_cancel] best-effort SparkApplication delete failed for %s "
                       "(the reconciler will finish the job): %s",
                       execution.get("execution_id"), cr_exc)
        return {"state": "delete_failed", "workload": execution.get("external_job_id"),
                "error": _describe(cr_exc)[:300],
                "note": "the reconciler deletes a live pod of a cancelled row within one interval"}


def cancel_run_without_execution(db: Any, run: Dict[str, Any], user: Optional[Dict[str, Any]],
                                 *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """A run that has no execution yet (pending / skipped, or claimed and
    not started): closed as cancelled with who and when.  The queue never
    claims a cancelled row."""
    at = now or datetime.now(timezone.utc)
    by = _who(user)
    updated = db.update_feed_run(int(run["id"]), {
        "status": "cancelled",
        "completed_at": at,
        "cancelled_by": by,
        "cancelled_at": at,
        "error": _words(by, at) + " No query had started.",
    })
    return updated or {}
