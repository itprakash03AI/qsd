"""The upstream MESSAGE TRACKER (2026-10-25, the owner: "group by code first
... then datasource ... show all messages with process flow ... 1 message
will have all steps like processing --> complete or processing --> failed ...
how many times the same message came ... per business close date").

Both roads -- the Kafka topic and the QS_KAFKA_MESSAGE watcher -- land every
message in ``kafka_messages``.  A PROCESSING message is filtered by the
resolver (the gate waits for COMPLETE) and never gets a ``business_date``, so
the tracker reads its own columns from the payload ONCE, at the one door both
roads land through (``track_columns`` in ``insert_kafka_message``):

* ``trk_business_date`` -- the payload's business close date;
* ``trk_code`` / ``trk_data_source`` -- the two levels of the tree
  (``group_fields``, CODE then DATA_SOURCE);
* ``trk_state`` -- the ``state_field`` (VERSION_STATE);
* ``trk_key`` -- WHICH message: a hash of the ``identity_fields``
  (DATA_SOURCE, CODE, BUSINESS_EVENT, CLOUD_COMPLIANT, SNAP_VERSION);
* ``trk_fields`` -- the identity + detail fields as JSON (what the screen shows).

``build`` answers one business close date from ONE indexed read of those
columns (never a payload): CODE -> DATA_SOURCE -> message, each message with
its FLOW (consecutive repeats collapsed and counted), its status (complete /
failed / processing / stuck), how many times it came, and what is wrong with
it (COMPLETE sent twice, a state after the end, failed then completed, one
environment silent while the other sent).  Every field name and state is
config (``feed_generation.message_tracker``).  Rows that landed before the
tracker are read by a bounded backfill and the answer says how many remain --
"not yet read" is never shown as "no messages".
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from datetime import date, datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional

logger = logging.getLogger(__name__)

#: bump when ``track_columns`` reads differently; rows stamped with an OLDER
#: version are re-read by the backfill (a config change alone applies to new rows)
TRACK_VERSION = 2          # 2 (2026-10-25): + trk_run_date

STATUSES = ("failed", "stuck", "processing", "complete", "unknown")
#: the order a code's messages are listed in: what needs a look first
_STATUS_ORDER = {s: i for i, s in enumerate(STATUSES)}

#: how long one request may spend reading old rows before it answers
BACKFILL_BUDGET_S = 2.0
BACKFILL_BATCH = 2000

DEFAULTS: Dict[str, Any] = {
    "business_date_field": "BUSINESS_DATE",
    "created_field": "CREATED_AT",
    "business_date_formats": ["%Y-%m-%d", "%d-%b-%y", "%d-%b-%Y", "%Y%m%d", "%d/%m/%Y"],
    "state_field": "VERSION_STATE",
    "complete_states": ["COMPLETE", "COMPLETED", "SUCCESS"],
    "failed_states": ["FAILED", "FAILURE", "ERROR"],
    "group_fields": ["CODE", "DATA_SOURCE"],
    "identity_fields": ["DATA_SOURCE", "CODE", "BUSINESS_EVENT", "CLOUD_COMPLIANT", "SNAP_VERSION"],
    "version_fields": ["SNAP_VERSION"],
    "detail_fields": ["ROW_COUNT", "VERSION_NUMBER", "DATA_STORE"],
    "stuck_after_minutes": 120,
    "page_size": 25,
}


def _names(v: Any) -> List[str]:
    if isinstance(v, str):
        v = [v]
    return [str(x).strip().upper() for x in (v or []) if str(x).strip()]


def config() -> Dict[str, Any]:
    """``feed_generation.message_tracker``, typed (every key declared in
    core/config.py)."""
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "message_tracker", {}) or {}
    except Exception:                                   # noqa: BLE001 -- the declared defaults
        raw = {}
    if not isinstance(raw, Mapping):
        raw = {}
    c = {**DEFAULTS, **raw}
    out: Dict[str, Any] = {k: _names(c[k]) for k in ("complete_states", "failed_states", "group_fields",
                                     "identity_fields", "version_fields", "detail_fields")}
    groups = out["group_fields"] + DEFAULTS["group_fields"][len(out["group_fields"]):]
    out["group_fields"] = groups[:2]
    out["business_date_field"] = str(c["business_date_field"] or "BUSINESS_DATE").strip().upper()
    out["created_field"] = str(c.get("created_field") or "CREATED_AT").strip().upper()
    out["state_field"] = str(c["state_field"] or "VERSION_STATE").strip().upper()
    fmts = c.get("business_date_formats") or DEFAULTS["business_date_formats"]
    out["business_date_formats"] = [str(f) for f in ([fmts] if isinstance(fmts, str) else fmts)]
    try:
        out["stuck_after_minutes"] = max(0, int(c.get("stuck_after_minutes") or 0))
    except (TypeError, ValueError):
        out["stuck_after_minutes"] = DEFAULTS["stuck_after_minutes"]
    try:
        out["page_size"] = max(1, int(c.get("page_size") or DEFAULTS["page_size"]))
    except (TypeError, ValueError):
        out["page_size"] = DEFAULTS["page_size"]
    return out


# ── Landing: the columns, read once ─────────────────────────────────────────

def _parse_date(raw: Any, formats: Iterable[str]) -> Optional[date]:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    text = str(raw).strip()
    if not text:
        return None
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    # an ISO timestamp where a date was meant
    if len(text) >= 10 and text[4:5] == "-" and text[7:8] == "-":
        try:
            return datetime.strptime(text[:10], "%Y-%m-%d").date()
        except ValueError:
            return None
    return None


def _text(v: Any, n: int) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip()
    return s[:n] if s else None


def track_columns(payload: Any, cfg: Optional[Mapping[str, Any]] = None,
                  landed_at: Any = None) -> Dict[str, Any]:
    """The tracker's columns for one landed payload (the raw text, or an
    already-parsed object).  Never raises: a payload that is not a JSON
    object is stamped read with every column NULL (its run date is the day
    it landed)."""
    out: Dict[str, Any] = {"trk_version": TRACK_VERSION, "trk_business_date": None,
                           "trk_run_date": _day_of(landed_at),
                           "trk_code": None, "trk_data_source": None, "trk_state": None,
                           "trk_key": None, "trk_fields": None}
    try:
        obj = json.loads(payload) if isinstance(payload, (str, bytes)) else payload
    except (TypeError, ValueError):
        return out
    if not isinstance(obj, Mapping):
        return out
    try:
        c = cfg or config()
        out.update(_read(obj, c))
        # the RUN DATE (the owner: "run date will be used with created date"):
        # the day the upstream CREATED the message, else the day it landed
        created = {str(k).strip().upper(): v for k, v in obj.items()}.get(c["created_field"])
        out["trk_run_date"] = _parse_date(created, ["%Y-%m-%d"]) or out["trk_run_date"]
    except Exception:                                   # noqa: BLE001 -- landing must never fail on the tracker
        logger.debug("[message_tracker] could not read a payload", exc_info=True)
    return out


def _day_of(v: Any) -> Optional[date]:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, str) and v:
        return _parse_date(v, ["%Y-%m-%d"])
    return None


def _read(obj: Mapping[str, Any], c: Mapping[str, Any]) -> Dict[str, Any]:
    up = {str(k).strip().upper(): v for k, v in obj.items()}
    state = _text(up.get(c["state_field"]), 60)
    ident = [_text(up.get(f), 500) or "" for f in c["identity_fields"]]
    shown: Dict[str, Any] = {}
    for f in list(c["identity_fields"]) + list(c["detail_fields"]):
        if up.get(f) is not None and f not in shown:
            shown[f] = up[f] if isinstance(up[f], (int, float, bool)) else str(up[f])[:200]
    return {
        "trk_business_date": _parse_date(up.get(c["business_date_field"]), c["business_date_formats"]),
        "trk_code": _text(up.get(c["group_fields"][0]), 200),
        "trk_data_source": _text(up.get(c["group_fields"][1]), 200),
        "trk_state": state.upper() if state else None,
        # an identity, not a secret: the hash only keys a GROUP BY
        "trk_key": (hashlib.sha256("\x1f".join(ident).encode("utf-8")).hexdigest()
                    if any(ident) else None),
        "trk_fields": json.dumps(shown, default=str) if shown else None,
    }


def backfill(db, *, budget_s: float = BACKFILL_BUDGET_S) -> int:
    """Read the columns of rows that landed before the tracker, for at most
    ``budget_s``.  Returns the rows still unread (0 = done)."""
    deadline = time.monotonic() + max(0.0, budget_s)
    try:
        while time.monotonic() < deadline:
            if not db.backfill_message_tracking(BACKFILL_BATCH):
                break
        return int(db.untracked_message_count())
    except Exception as exc:                            # noqa: BLE001 -- said in the answer
        logger.warning("[message_tracker] backfill failed: %s", exc)
        return -1


# ── The answer for one business close date ─────────────────────────────────

def _iso(v: Any) -> Optional[str]:
    if v is None:
        return None
    return v.isoformat() if hasattr(v, "isoformat") else str(v)


def _aware(v: Any) -> Optional[datetime]:
    if not isinstance(v, datetime):
        return None
    return v if v.tzinfo else v.replace(tzinfo=timezone.utc)


def _road(topic: Optional[str]) -> str:
    return "table" if str(topic or "").startswith("oracle_table:") else "kafka"


def _fields(raw: Any) -> Dict[str, Any]:
    if not raw:
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {}
    except (TypeError, ValueError):
        return {}


def _flow(arrivals: List[dict]) -> List[Dict[str, Any]]:
    """The states in arrival order, a consecutive repeat folded into one step
    with its count (PROCESSING x3 -> COMPLETE)."""
    steps: List[Dict[str, Any]] = []
    for a in arrivals:
        st = a["state"] or "?"
        if steps and steps[-1]["state"] == st:
            steps[-1]["count"] += 1
            steps[-1]["last_at"] = _iso(a["landed_at"])
        else:
            steps.append({"state": st, "count": 1, "first_at": _iso(a["landed_at"]),
                          "last_at": _iso(a["landed_at"])})
    return steps


def _flags(states: List[Optional[str]], status: str, done: set, failed: set) -> List[Dict[str, str]]:
    """What is wrong with one message's flow."""
    terminal = done | failed
    flags: List[Dict[str, str]] = []
    n_done = sum(1 for s in states if s in done)
    if n_done > 1:
        flags.append({"kind": "complete_repeated", "text": f"COMPLETE was sent {n_done} times"})
    ends = [i for i, s in enumerate(states) if s in terminal]
    late = next((s for s in states[ends[0] + 1:] if s and s not in terminal), None) if ends else None
    if late:
        flags.append({"kind": "after_terminal", "text": f"{late} came after it had already finished"})
    n_failed = sum(1 for s in states if s in failed)
    if status == "complete" and n_failed:
        flags.append({"kind": "recovered", "text": ("Failed once, then completed" if n_failed == 1
                                                     else f"Failed {n_failed} times, then completed")})
    return flags


def _status(final: Optional[str], last_at: Optional[datetime], done: set, failed: set,
            stuck_after: int, now: datetime) -> str:
    if final in done:
        return "complete"
    if final in failed:
        return "failed"
    if not final:
        return "unknown"
    if stuck_after and last_at and (now - last_at).total_seconds() > stuck_after * 60:
        return "stuck"
    return "processing"


def what_happened(resolution: Optional[str], dependency: Optional[str], state: Optional[str],
                  c: Mapping[str, Any]) -> str:
    """What QueryStudio did with one arriving message, in words a support
    person reads without the code (the owner, 2026-10-25)."""
    r = str(resolution or "").lower()
    if r == "resolved":
        return f"Used: released {dependency}" if dependency else "Used"
    if r == "filtered":
        done = " / ".join(c["complete_states"][:1]) or "COMPLETE"
        if state and state in c["complete_states"]:
            return "Not used by any feed rule"
        return f"Not used yet -- feeds wait for {done}"
    if r == "unmatched":
        return "No feed waits for this message"
    if r == "unresolvable":
        return "Could not be read -- see the full message"
    if r == "landed":
        return "Received, being checked"
    return r or "Received"


def _message(key: str, arrivals: List[dict], c: Mapping[str, Any], now: datetime) -> Dict[str, Any]:
    done, failed = set(c["complete_states"]), set(c["failed_states"])
    terminal = done | failed
    last = arrivals[-1]
    final = last["state"]
    first_at, last_at = _aware(arrivals[0]["landed_at"]), _aware(last["landed_at"])
    status = _status(final, last_at, done, failed, c["stuck_after_minutes"], now)
    flags = _flags([a["state"] for a in arrivals], status, done, failed)
    end_at = next((_aware(a["landed_at"]) for a in arrivals if a["state"] in terminal), None)
    flow = _flow(arrivals)
    fields = _fields(last["fields"])
    deps = sorted({a["dependency_name"] for a in arrivals if a["dependency_name"]})
    return {
        "key": key, "status": status, "final_state": final, "fields": fields,
        "flow": flow, "times_seen": len(arrivals),
        "repeats": sum(s["count"] - 1 for s in flow),
        "first_at": _iso(first_at), "last_at": _iso(last_at),
        "duration_seconds": (int((end_at - first_at).total_seconds())
                             if end_at and first_at else None),
        "age_minutes": int((now - last_at).total_seconds() // 60) if last_at else None,
        "flags": flags,
        "roads": sorted({_road(a["topic"]) for a in arrivals}),
        "dependency_names": deps,
        "resolution": last["resolution"],
        "reason": last["reason"],
        # 2026-10-25 (the owner: "version or row count may differ all the time"):
        # each arrival is its OWN message -- its own fields, and what
        # QueryStudio did with it in plain words; the full message is read
        # on demand (message_payloads)
        "arrivals": [{"id": a["id"], "at": _iso(a["landed_at"]), "state": a["state"],
                      "road": _road(a["topic"]), "resolution": a["resolution"],
                      "reason": a["reason"], "dependency_name": a["dependency_name"],
                      "fields": _fields(a["fields"]),
                      "what_happened": what_happened(a["resolution"], a["dependency_name"], a["state"], c)}
                     for a in arrivals],
    }


def _side_of(fields: Mapping[str, Any]) -> Optional[str]:
    from core.feed import environments
    return environments.side_of_message(fields)


def _logical(fields: Mapping[str, Any], c: Mapping[str, Any], side_fields: set) -> str:
    """The message without its environment and its version: the LOAD both
    sides (and every re-send) are about."""
    up = {str(k).upper(): v for k, v in fields.items()}
    skip = side_fields | set(c["version_fields"])
    return "\x1f".join("" if up.get(f) is None else str(up[f])
                       for f in c["identity_fields"] if f not in skip)


def _annotate_loads(messages: List[Dict[str, Any]], c: Mapping[str, Any]) -> None:
    """Per data source: an environment that sent nothing for a load the
    other environment sent (one side missing), and a load re-sent as more
    than one version."""
    from core.feed import environments
    envs = environments.environments()
    side_fields = {str(e.get("message_field") or "").upper() for e in envs} - {""}
    labels = {e["side"]: e["label"] for e in envs}
    loads: Dict[str, Dict[str, Any]] = {}
    for m in messages:
        m["side"] = _side_of(m["fields"])
        m["side_label"] = labels.get(m["side"]) if m["side"] else None
        L = loads.setdefault(_logical(m["fields"], c, side_fields), {"sides": set(), "versions": {}})
        if m["side"]:
            L["sides"].add(m["side"])
        ver = "\x1f".join(str(m["fields"].get(f) or m["fields"].get(f.lower()) or "")
                          for f in c["version_fields"])
        L["versions"].setdefault(m["side"], set()).add(ver)
    for m in messages:
        _flag_load(m, loads[_logical(m["fields"], c, side_fields)], envs, labels)


def _flag_load(m: Dict[str, Any], load: Mapping[str, Any], envs: List[dict], labels: Mapping[str, str]) -> None:
    missing = ([labels[e["side"]] for e in envs if e["side"] not in load["sides"]]
               if len(envs) > 1 and load["sides"] else [])
    if missing:
        m["flags"].append({"kind": "missing_side",
                           "text": f"No {' / '.join(missing)} message for this load"})
    nver = len(load["versions"].get(m["side"], ()))
    m["versions"] = nver
    if nver > 1:
        m["flags"].append({"kind": "resent", "text": f"Sent again: {nver} versions of this load"})


def _matches(m: Dict[str, Any], code: str, ds: str, q: str) -> bool:
    if not q:
        return True
    hay = [code, ds, *(str(v) for v in m["fields"].values()), *m["dependency_names"]]
    return any(q in str(h).lower() for h in hay if h)


def _wanted(m: Dict[str, Any], status: str) -> bool:
    if not status:
        return True
    if status == "attention":
        return m["status"] in ("failed", "stuck") or bool(m["flags"])
    if status in ("complete_repeated", "after_terminal", "missing_side", "resent", "recovered"):
        return any(f["kind"] == status for f in m["flags"])
    return m["status"] == status


def _counts(messages: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = dict.fromkeys(STATUSES, 0)
    out.update({"messages": 0, "arrivals": 0, "repeats": 0, "flagged": 0})
    flags: Dict[str, int] = {}
    for m in messages:
        out["messages"] += 1
        out[m["status"]] += 1
        out["arrivals"] += m["times_seen"]
        out["repeats"] += m["repeats"]
        if m["flags"]:
            out["flagged"] += 1
        for f in m["flags"]:
            flags[f["kind"]] = flags.get(f["kind"], 0) + 1
    out["flags"] = flags
    return out


def _worst(counts: Mapping[str, Any]) -> str:
    for s in STATUSES:
        if counts.get(s):
            return s
    return "unknown"


def _index(rows: List[dict], c: Mapping[str, Any], now: datetime):
    """The date's rows -> messages, grouped per (code, data source)."""
    by_key: Dict[str, List[dict]] = {}
    where: Dict[str, tuple] = {}
    no_key = 0
    for r in rows:
        if not r["key"]:
            no_key += 1
            continue
        by_key.setdefault(r["key"], []).append(r)
        where.setdefault(r["key"], (r["code"] or "", r["data_source"] or ""))
    per_ds: Dict[tuple, List[dict]] = {}
    for k, a in by_key.items():
        per_ds.setdefault(where[k], []).append(_message(k, a, c, now))
    # the loads are judged per (code, data source): a side missing is a
    # fact about the date, never about the page
    for ms in per_ds.values():
        _annotate_loads(ms, c)
    return per_ds, no_key


def _groups(per_ds: Dict[tuple, List[dict]], q: str, status: str) -> List[Dict[str, Any]]:
    tree: Dict[str, Dict[str, List[dict]]] = {}
    for (code, ds), ms in per_ds.items():
        keep = [m for m in ms if _matches(m, code, ds, q) and _wanted(m, status)]
        if keep:
            tree.setdefault(code, {})[ds] = keep
    groups = []
    for code, by_ds in tree.items():
        sources = []
        for ds in sorted(by_ds):
            ms = sorted(by_ds[ds], key=lambda m: (_STATUS_ORDER[m["status"]], m["first_at"] or ""))
            cnt = _counts(ms)
            sources.append({"data_source": ds, "counts": cnt, "worst": _worst(cnt), "messages": ms})
        cnt = _counts(m for s in sources for m in s["messages"])
        groups.append({"code": code, "counts": cnt, "worst": _worst(cnt), "data_sources": sources})
    # what needs a look first: a code with a failure before one that is all complete
    groups.sort(key=lambda g: (_STATUS_ORDER[g["worst"]], g["code"]))
    return groups


def _attach_feeds(db, shown: List[Dict[str, Any]], business_date: date) -> None:
    """Each shown message's feeds (the ones declaring its dependency) with
    their run for the date -- one read for the page."""
    msgs = [m for g in shown for s in g["data_sources"] for m in s["messages"]]
    names = sorted({n for m in msgs for n in m["dependency_names"]})
    released: Optional[Dict[str, list]] = {}
    if names:
        try:
            released = db.feeds_declaring_dependencies(names, business_date) or {}
        except Exception as exc:                        # noqa: BLE001 -- said on the message
            logger.warning("[message_tracker] feeds for %d dependencies unreadable: %s", len(names), exc)
            released = None
    for m in msgs:
        m["feeds"] = [] if released is None else [f for n in m["dependency_names"] for f in released.get(n, [])]
        if released is None:
            m["feeds_unreadable"] = True


#: the two ways to pick a day: the date the data is FOR (the payload's
#: BUSINESS_DATE), or the day the message was CREATED (its CREATED_AT, else the
#: day it landed) -- the owner's "run date"
BY = ("business", "run")


def build(db, business_date: date, *, q: str = "", status: str = "",
          page: int = 1, page_size: Optional[int] = None,
          now: Optional[datetime] = None, by: str = "business") -> Dict[str, Any]:
    """The tracker's answer for one day (see the module docstring): the
    messages whose business date is ``business_date`` (``by`` = "business"),
    or the messages CREATED that day (``by`` = "run").  Paged by CODE."""
    from core.feed import environments
    from core.feed.paging import block, paging
    c = config()
    now = now or datetime.now(timezone.utc)
    unread = backfill(db)
    by = by if by in BY else "business"
    per_ds, no_key = _index(db.list_tracked_messages(business_date, by=by), c, now)
    ql = (q or "").strip().lower()
    # the tiles count what the SEARCH shows (the owner searches a code and
    # reads its numbers); the state filter is what the tiles choose, so it
    # does not narrow them
    searched = {k: [m for m in ms if _matches(m, k[0], k[1], ql)] for k, ms in per_ds.items()}
    searched = {k: ms for k, ms in searched.items() if ms}
    summary = _counts(m for ms in searched.values() for m in ms)
    summary["codes"] = len({k[0] for k in searched})
    summary["data_sources"] = len({k[1] for k in searched})
    summary["unidentified"] = no_key
    summary["searched"] = bool(ql)
    groups = _groups(per_ds, ql, (status or "").strip().lower())
    p = paging(page, page_size or c["page_size"])
    shown = groups[p.offset:p.offset + p.page_size]
    _attach_feeds(db, shown, business_date)
    return {
        "business_date": business_date.isoformat(),
        "by": by,
        "generated_at": now.isoformat(),
        "q": q or "", "status": status or "",
        "summary": summary,
        "groups": shown,
        "paging": block(len(groups), p, len(shown)),
        "unread": unread,
        "config": {"state_field": c["state_field"], "group_fields": c["group_fields"],
                   "identity_fields": c["identity_fields"], "complete_states": c["complete_states"],
                   "failed_states": c["failed_states"], "stuck_after_minutes": c["stuck_after_minutes"]},
        "environments": environments.public(),
    }
