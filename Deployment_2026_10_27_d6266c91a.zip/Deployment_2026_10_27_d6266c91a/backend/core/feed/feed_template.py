"""A PARAMETERISED feed definition applied to a matrix -- the pure half
(2026-10-10, the owner's ~4,000 monthly (SYSTEM_ENTITY, EventCode) feeds).

Not 4,000 hand-authored configs: ONE template (a FeedConfigCreate-shaped
``feed`` body whose string fields carry ``{PARAM}`` tokens, the
``dependencies`` every member declares, the ordered ``parameters``) and a
``matrix`` of parameter rows.  :func:`render_member` turns one row into the
exact body and dependency list the ordinary authoring routes accept -- so
every rule those routes enforce (the name charset, the SLA, the filename
template, the cross-source preflight, the arrival-source vocabulary)
applies to a member exactly as to a hand-authored feed, and nothing here
writes to the database.  The routes in ``api/feed_template_api.py`` do the
applying (create / compare / update / retire) through THE create and update.

Decisions:

* **N feed rows, not one feed with a fan-out.**  Each (entity, event) is
  held on ITS OWN Kafka message, released, run, delivered, certified and
  receipted by itself -- the run model, the step model, the Today board,
  the SLA clocks and the consumer receipts are all per feed ("a feed run
  is a feed run", BRD section 2.2).  The fan-out (``core/feed/fanout.py``)
  is for ONE run producing N files from one release; here the releases are
  independent.
* **Membership is a column pair**, ``feed_configs.template_id`` +
  ``template_member_key`` (the parameter values joined by ``|`` in
  parameter order), never the name: a re-apply finds, compares and updates
  the same row; an unchanged member is reported ``unchanged``; a matrix row
  whose rendered name belongs to a NON-member feed is a ``conflict``
  (reported, nothing adopted silently).
* **A parameter value is validated ONCE** by
  ``core/feed/sql_tokens.py::validate_token_value`` -- the same rule the
  SQL renderer applies at run time -- so what the matrix accepts is what
  the WHERE clause will carry.  A quote in an entity code refuses the whole
  matrix, naming the row.
* **The rendered member carries its parameters in ``query_params``** so the
  SQL tokens ``{SYSTEM_ENTITY}`` / ``{EventCode}`` resolve at run time on
  every lane, and the ``name`` template must use EVERY parameter (two rows
  rendering one name is a collision at save time, not a surprise at 3am).
"""
from __future__ import annotations

import copy
import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from core.feed.sql_tokens import UnsafeTokenValue, validate_token_value

_PARAM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_TOKEN_RE = re.compile(r"(?<!\{)\{([A-Za-z_][A-Za-z0-9_]*)\}(?!\})")
MAX_MATRIX_ROWS = 20000
MEMBER_KEY_SEP = "|"

#: Fields of the ``feed`` body that are the template's business, never a
#: matrix row's: membership is stamped by the route, identity by the DAO.
_RESERVED_FEED_FIELDS = frozenset({"id", "template_id", "template_member_key",
                                   "created_by", "created_at", "updated_at",
                                   "etl_id", "apscheduler_job_id"})


#: 2026-10-12 (owner R1) -- the template's GROUP RULE: a Feed Group NAME
#: rendered per member like any string (``"{SYSTEM_ENTITY}"``).  The apply
#: resolves it to a DEFINED Feed Group (created on first use, an ordinary
#: editable group afterwards) and stores ``feed_group_id`` -- the dashboard
#: groups by Feed Groups, never by a hardcoded column.
FEED_GROUP_RULE_FIELD = "feed_group_name"


class FeedTemplateRefused(ValueError):
    """The template or its matrix cannot be applied; the message names what."""


@dataclass(frozen=True)
class RenderedMember:
    member_key: str
    values: Dict[str, str]
    feed: Dict[str, Any]
    dependencies: List[Dict[str, Any]]

    @property
    def name(self) -> str:
        return str(self.feed.get("name") or "")


@dataclass
class TemplateSpec:
    """A validated template: parameters, the feed body, the dependencies."""
    parameters: List[str]
    feed: Dict[str, Any]
    dependencies: List[Dict[str, Any]]

    def to_definition(self) -> Dict[str, Any]:
        return {"feed": copy.deepcopy(self.feed),
                "dependencies": copy.deepcopy(self.dependencies)}


def _walk_strings(node: Any, fn) -> Any:
    if isinstance(node, str):
        return fn(node)
    if isinstance(node, dict):
        return {k: _walk_strings(v, fn) for k, v in node.items()}
    if isinstance(node, list):
        return [_walk_strings(v, fn) for v in node]
    return node


def tokens_in(node: Any) -> List[str]:
    """Every ``{NAME}`` token in the template's strings, deduplicated."""
    seen: Dict[str, None] = {}

    def _collect(s: str) -> str:
        for m in _TOKEN_RE.finditer(s):
            seen.setdefault(m.group(1), None)
        return s
    _walk_strings(node, _collect)
    return list(seen)


def parse_template(parameters: Any, feed: Any, dependencies: Any) -> TemplateSpec:
    """Validate the template SHAPE (not a matrix).  Raises
    :class:`FeedTemplateRefused` naming the fault."""
    if not isinstance(parameters, (list, tuple)) or not parameters:
        raise FeedTemplateRefused(
            "parameters must be a non-empty list of names, e.g. "
            "[\"SYSTEM_ENTITY\", \"EventCode\"]")
    params: List[str] = []
    for p in parameters:
        if not isinstance(p, str) or not _PARAM_NAME_RE.match(p):
            raise FeedTemplateRefused(
                f"parameter {p!r} is not a name (letters, digits, underscore, "
                f"not starting with a digit)")
        if p in params:
            raise FeedTemplateRefused(f"parameter {p!r} is listed twice")
        params.append(p)
    if not isinstance(feed, dict) or not feed:
        raise FeedTemplateRefused("feed must be the feed body (an object) the "
                                  "members are rendered from")
    reserved = sorted(k for k in feed if k in _RESERVED_FEED_FIELDS)
    if reserved:
        raise FeedTemplateRefused(
            f"feed body must not carry {reserved}: membership and identity are "
            f"stamped by the apply, not authored")
    name = feed.get("name")
    if not isinstance(name, str) or not name.strip():
        raise FeedTemplateRefused("feed.name is required (a template with "
                                  "{PARAM} tokens, e.g. TETB_{SYSTEM_ENTITY}_{EventCode})")
    missing = [p for p in params if f"{{{p}}}" not in name]
    if missing:
        raise FeedTemplateRefused(
            f"feed.name {name!r} must use every parameter; it does not use "
            f"{missing} -- two matrix rows would render the same feed name")
    if not feed.get("source_type") or feed.get("source_id") is None:
        raise FeedTemplateRefused("feed.source_type and feed.source_id are required")
    if FEED_GROUP_RULE_FIELD in feed:
        rule = feed.get(FEED_GROUP_RULE_FIELD)
        if not isinstance(rule, str) or not rule.strip():
            raise FeedTemplateRefused(
                f"feed.{FEED_GROUP_RULE_FIELD} must be a Feed Group name, usually "
                f"with tokens (e.g. \"{{SYSTEM_ENTITY}}\"): every member joins the "
                f"group its values render")
        if feed.get("feed_group_id") is not None:
            raise FeedTemplateRefused(
                f"feed carries both feed_group_id and {FEED_GROUP_RULE_FIELD}: "
                f"one group rule, not two")
    from core.feed.filename_renderer import BRACE_TOKENS, LEGACY_TOKENS
    _run_time = {t.lower() for t in (*LEGACY_TOKENS, *BRACE_TOKENS)}
    unknown = [t for t in tokens_in(feed)
               if t not in params and t.upper() != t and t.lower() not in _run_time]
    # An UPPER-case unknown token may be an OG date token in SQL text
    # ({BUSINESSDATE}); a FILE-NAME token ({name}, {date}, {run_date} ...,
    # filename_renderer's vocabulary) is the run's -- the platform's own
    # default file name is "{name}_{date}.{ext}" (2026-10-26: a template using
    # it was refused); any other mixed-case one is almost certainly a typo'd
    # parameter.  Refuse the typo, let the vocabularies through.
    if unknown:
        raise FeedTemplateRefused(
            f"feed body carries token(s) {unknown} that are not declared "
            f"parameters {params}")
    deps_in: List[Dict[str, Any]] = []
    if dependencies is None:
        dependencies = []
    if not isinstance(dependencies, list):
        raise FeedTemplateRefused("dependencies must be a list")
    for i, d in enumerate(dependencies):
        if not isinstance(d, dict):
            raise FeedTemplateRefused(f"dependencies[{i}] is not an object")
        key = d.get("dependency_key")
        if not isinstance(key, str) or not key.strip():
            raise FeedTemplateRefused(f"dependencies[{i}].dependency_key is required")
        if d.get("dependency_type_id") is None and not str(d.get("dependency_type") or "").strip():
            raise FeedTemplateRefused(
                f"dependencies[{i}] needs dependency_type (a catalogue name such "
                f"as KAFKA) or dependency_type_id")
        deps_in.append(dict(d))
    qp = feed.get("query_params")
    if qp is not None and not isinstance(qp, dict):
        raise FeedTemplateRefused("feed.query_params must be an object")
    for p in params:
        if isinstance(qp, dict) and p in qp:
            raise FeedTemplateRefused(
                f"feed.query_params already carries {p!r}; the matrix supplies "
                f"every parameter value")
    return TemplateSpec(parameters=params, feed=copy.deepcopy(feed),
                        dependencies=deps_in)


def parse_matrix(spec: TemplateSpec, matrix: Any) -> List[Dict[str, str]]:
    """Validate the matrix against the template: every row carries every
    parameter with a value the SQL renderer will accept, no two rows share
    a key.  Raises :class:`FeedTemplateRefused` naming the row."""
    if not isinstance(matrix, list):
        raise FeedTemplateRefused("matrix must be a list of parameter rows")
    if len(matrix) > MAX_MATRIX_ROWS:
        raise FeedTemplateRefused(
            f"matrix has {len(matrix)} rows; the limit is {MAX_MATRIX_ROWS}")
    rows: List[Dict[str, str]] = []
    seen: Dict[str, int] = {}
    for i, row in enumerate(matrix):
        if not isinstance(row, dict):
            raise FeedTemplateRefused(f"matrix[{i}] is not an object")
        values: Dict[str, str] = {}
        for p in spec.parameters:
            if p not in row:
                raise FeedTemplateRefused(f"matrix[{i}] lacks parameter {p!r}")
            try:
                values[p] = validate_token_value(p, row[p])
            except UnsafeTokenValue as exc:
                raise FeedTemplateRefused(f"matrix[{i}]: {exc}") from exc
        extra = sorted(k for k in row if k not in spec.parameters)
        if extra:
            raise FeedTemplateRefused(
                f"matrix[{i}] carries {extra}, which are not declared parameters")
        key = member_key(spec.parameters, values)
        if key in seen:
            raise FeedTemplateRefused(
                f"matrix[{i}] repeats the row matrix[{seen[key]}] ({key})")
        seen[key] = i
        rows.append(values)
    return rows


def member_key(parameters: Sequence[str], values: Mapping[str, Any]) -> str:
    return MEMBER_KEY_SEP.join(str(values[p]) for p in parameters)


def render_member(spec: TemplateSpec, values: Mapping[str, str]) -> RenderedMember:
    """ONE matrix row -> the feed body + dependency rows the authoring
    routes accept.  Every ``{PARAM}`` in every string is substituted; the
    parameter values are added to ``query_params`` so the SQL tokens
    resolve at run time; ``{{...}}`` and undeclared tokens are untouched."""
    vals = {p: str(values[p]) for p in spec.parameters}

    def _sub(s: str) -> str:
        return _TOKEN_RE.sub(lambda m: vals.get(m.group(1), m.group(0)), s)

    # ``query_params`` is NOT rendered here: its SQL (a raw_sql feed's
    # ``sql``, a saved query's text reached through source_id) keeps its
    # ``{SYSTEM_ENTITY}`` / ``{EventCode}`` / ``{BUSINESSDATE}`` tokens and
    # the run-time renderer (core/feed/sql_tokens.py, every lane) fills them
    # from the parameter VALUES stored beside it -- one SQL text for 4,000
    # members, a template edit propagates, and the authoring surface shows
    # the query the author wrote.
    body = {k: v for k, v in spec.feed.items() if k != "query_params"}
    feed = _walk_strings(copy.deepcopy(body), _sub)
    # 2026-10-13 -- the NAME is derived, so it takes the feed form's rule
    # (an entity "SAP-2920-EMEA" -> FACT_TETB_SAP_2920_EMEA_EOD); dependency
    # keys and file names keep the value AS WRITTEN (they must match the
    # upstream's messages).
    if isinstance(feed.get("name"), str):
        from core.feed.identity import normalize_feed_name
        feed["name"] = normalize_feed_name(feed["name"])
    qp = copy.deepcopy(spec.feed.get("query_params") or {})
    qp.update(vals)
    feed["query_params"] = qp
    deps = _walk_strings(copy.deepcopy(spec.dependencies), _sub)
    return RenderedMember(member_key=member_key(spec.parameters, vals),
                          values=vals, feed=feed, dependencies=deps)


def _norm(v: Any) -> Any:
    """Compare-shape: JSON round trip so a tuple/list, int/float, or key
    order difference is not a change."""
    try:
        return json.loads(json.dumps(v, sort_keys=True, default=str))
    except (TypeError, ValueError):
        return v


def changed_fields(stored: Mapping[str, Any], rendered: Mapping[str, Any]) -> Dict[str, Any]:
    """The rendered fields whose stored value differs -- what an update
    must carry.  Only keys the template RENDERS are compared: a member's
    operator-set state (is_active, schedule_enabled after acceptance, run
    counters) is not the template's to overwrite."""
    out: Dict[str, Any] = {}
    for k, v in rendered.items():
        if k in ("schedule_enabled",):
            # authored on create; afterwards it is acceptance/operator state
            continue
        if _norm(stored.get(k)) != _norm(v):
            out[k] = v
    return out


def dependencies_differ(stored_rows: Iterable[Mapping[str, Any]],
                        rendered: Iterable[Mapping[str, Any]],
                        type_ids: Mapping[str, int]) -> bool:
    """Whether the member's declared dependency rows differ from the
    rendered ones (type, key, sources, mode, calendar, expected rows, the
    side the reported count certifies)."""
    def _shape(rows, resolve_type):
        out = []
        for r in rows:
            tid = r.get("dependency_type_id")
            if tid is None and resolve_type:
                tid = type_ids.get(str(r.get("dependency_type") or "").upper())
            out.append(_norm({
                "type": int(tid) if tid is not None else None,
                "key": str(r.get("dependency_key") or "").strip(),
                "sources": r.get("arrival_sources") or None,
                "mode": (r.get("require_mode") or None) if r.get("arrival_sources") else None,
                "calendar": r.get("calendar_name") or None,
                "expected_rows": r.get("expected_rows"),
                # 2026-10-11 -- which side the reported row count certifies
                "certifies_side": (str(r.get("certifies_side") or "").lower() or None),
                "description": r.get("description") or None,
                "active": bool(r.get("is_active", True)),
            }))
        return sorted(out, key=lambda d: (d["key"], str(d["type"])))
    return _shape(stored_rows, False) != _shape(rendered, True)


# ── The apply as a JOB (2026-10-10) ──────────────────────────────────────
#
# Per-member cost is O(1) amortised since the authoring index
# (core/feed/authoring_index.py), but 4,000 members are still 4,000 passes
# through THE create route -- ~25 ms each on the dev box's SQLite, more on
# the rig's Postgres -- i.e. minutes, which no HTTP request should hold.
# Above SYNC_APPLY_MAX_ROWS the route CLAIMS the template (one apply at a
# time, a compare-and-swap on ``feed_templates.apply_job_id``), answers 202
# with the job, and the apply runs as a task on the API process that took
# it; ``GET /api/feed-templates/{id}/apply-status`` reads the job from the
# row -- progress, heartbeat and, when done, the SAME ApplyReport the
# synchronous answer carries -- from ANY pod.  A dry run is always
# synchronous (it writes nothing); a small matrix keeps the inline report.

#: a matrix up to this many rows is applied inside the request
SYNC_APPLY_MAX_ROWS = 100
#: a queued/running job whose heartbeat is older than this belongs to a
#: process that ended (a pod restart): reported failed, never "running" forever
APPLY_STALE_SECONDS = 120.0
#: how often a running apply refreshes its row (progress + heartbeat)
APPLY_PROGRESS_EVERY_SECONDS = 2.0

JOB_QUEUED, JOB_RUNNING, JOB_COMPLETED, JOB_FAILED = ("queued", "running",
                                                     "completed", "failed")
JOB_LIVE_STATES = frozenset({JOB_QUEUED, JOB_RUNNING})
DEAD_OWNER_REASON = (
    "the process applying this template stopped (a pod restart or a worker "
    "exit) before it finished; the members it had already written are feeds "
    "like any other -- POST apply again, which finds them unchanged")


def _iso(dt) -> str:
    return dt.isoformat()


def new_apply_job(job_id: str, *, total: int, by: Optional[str], owner: str,
                  background: bool, now) -> Dict[str, Any]:
    """The job record as first written: queued, nothing done."""
    return {"job_id": job_id, "state": JOB_QUEUED, "background": bool(background),
            "total": int(total), "done": 0, "counts": None, "by": by,
            "owner": owner, "started_at": _iso(now), "heartbeat_at": _iso(now),
            "finished_at": None, "error": None, "report": None}


def apply_job_view(status: Any, *, now) -> Optional[Dict[str, Any]]:
    """What a poller is told.  A queued/running job whose heartbeat is older
    than :data:`APPLY_STALE_SECONDS` is a dead owner's: reported ``failed``
    with :data:`DEAD_OWNER_REASON` (and ``stale: true``), never in flight
    for ever.  Pure: the row is not rewritten here."""
    if not isinstance(status, dict) or not status.get("job_id"):
        return None
    view = dict(status)
    if view.get("state") in JOB_LIVE_STATES and job_is_stale(view, now=now):
        view["state"] = JOB_FAILED
        view["error"] = DEAD_OWNER_REASON
        view["stale"] = True
    return view


def job_is_stale(status: Mapping[str, Any], *, now) -> bool:
    hb = status.get("heartbeat_at") or status.get("started_at")
    if not hb:
        return True
    try:
        from datetime import datetime
        then = datetime.fromisoformat(str(hb))
    except ValueError:
        return True
    if then.tzinfo is None:
        then = then.replace(tzinfo=now.tzinfo)
    return (now - then).total_seconds() > APPLY_STALE_SECONDS


@dataclass
class ApplyReport:
    """What one apply did, per member -- never one aggregate 'done'."""
    template_id: Optional[int] = None
    dry_run: bool = False
    created: List[Dict[str, Any]] = field(default_factory=list)
    updated: List[Dict[str, Any]] = field(default_factory=list)
    unchanged: List[Dict[str, Any]] = field(default_factory=list)
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    refused: List[Dict[str, Any]] = field(default_factory=list)
    retired: List[Dict[str, Any]] = field(default_factory=list)
    orphaned: List[Dict[str, Any]] = field(default_factory=list)
    seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "template_id": self.template_id, "dry_run": self.dry_run,
            "matrix_rows": (len(self.created) + len(self.updated) + len(self.unchanged)
                            + len(self.conflicts) + len(self.refused)),
            "counts": {"created": len(self.created), "updated": len(self.updated),
                       "unchanged": len(self.unchanged), "conflicts": len(self.conflicts),
                       "refused": len(self.refused), "retired": len(self.retired),
                       "orphaned": len(self.orphaned)},
            "created": self.created, "updated": self.updated,
            "unchanged": self.unchanged, "conflicts": self.conflicts,
            "refused": self.refused, "retired": self.retired,
            "orphaned": self.orphaned, "seconds": round(self.seconds, 3),
        }
