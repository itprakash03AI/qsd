"""Phase 131-A — ETL dependency check.

Gates a feed_run on whether all its upstream dependencies (Kafka topic
arrivals, Oracle table partitions, …) have landed for the given
business_date.

The dependency identifier is ``etl_id`` — generic on purpose so the
same control covers feeds today and any other ETL artefact tomorrow
(report row hydration, S3 partition fill, API push).  Once integrated
with the OTG side, the same etl_id maps to OTG_REPORT_DEPENDENCY_MAPPING
rows; today QS reads from its own ``etl_dependency_*`` mirror tables
(populated by an external Kafka consumer or the OTG ETL).

Public API:
    check_dependencies(db, etl_id, business_date) -> DependencyCheckResult
    poll_pending_runs(db, broadcast_fn=None) -> dict  # for the scheduler

The poller is leader-gated by the caller via the existing
``scheduler_lease`` table — same pattern as the failover agent.

No Oracle access happens in this module; the caller's DB layer
encapsulates either the QS-side mirror tables or, post-integration,
the OTG Oracle cursor.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from core.feed.event_audience import address, feed_event_audience

logger = logging.getLogger(__name__)

# Action values that signal "dependency satisfied".  Matches OTG's
# OTG_DEPENDENCY_TRACKING.ACTION values (CHECK constraint in
# 01_tables.sql line 274).  Anything else = NOT ready.
READY_ACTIONS = {"COMPLETE", "SKIP"}


def effective_etl_id(feed_config: Any) -> int:
    """THE key a feed's dependency mappings live under (2026-09-27).

    A feed's ``etl_dependency_mappings`` rows are keyed by its explicit
    ``etl_id`` or, when that is NULL, by the feed's own id (the Phase 131
    default the authoring routes have written under since day one).  Until
    this function existed the WRITERS used that rule
    (``feed_api._resolve_etl_id_for_feed``) and the ENFORCERS did not: SOD's
    creation-time check ran only ``if etl_id is not None``, the poller's
    query selected only ``feed_configs.etl_id IS NOT NULL``, and every
    blocking surface skipped a feed with no explicit etl_id.  A feed whose
    dependencies were authored, stored and SHOWN was gated nowhere -- a
    backfilled date whose data never arrived simply ran (Docker rig, feed 2,
    2026-09-27).  One resolver, every reader and writer, so the key a
    mapping is written under is the key it is enforced under.

    ``feed_config`` is a feed_configs row (a dict, or anything with
    ``.get``) carrying ``id`` and optionally ``etl_id``.
    """
    raw = feed_config.get("etl_id")
    if raw is not None:
        return int(raw)
    return int(feed_config["id"])


def infer_certified_side(feed_config: Any, mapping: Any, n_active: int,
                         combined: Optional[bool] = None) -> Optional[str]:
    """The side a dependency vouches for when its author declared none
    (``resolve_reported_side_rows``).  None = it certifies nothing.
    ``combined``: whether the feed has a second side -- THE answer is
    ``source_plan.detect_cross_source`` (explicit, or inherited from its saved
    query / shared SQL file); the caller asks it once."""
    # the environment a dependency's NAME declares is configuration
    # (feed_generation.environments, core/feed/environments.py) -- never a
    # spelling written here
    from core.feed.environments import side_of_dependency
    if combined is None:
        combined = bool((feed_config or {}).get("secondary_connection_id"))
    if combined:
        return side_of_dependency((mapping or {}).get("dependency_key"))
    return "primary" if n_active == 1 else None


def resolve_reported_side_rows(db: Any, feed_config: Any,
                               business_date: Optional[date]) -> Dict[str, Any]:
    """What every side of the feed is EXPECTED to count -- a VIEW of the
    UPSTREAM CONTRACT (core/feed/upstream_contract.py, 2026-10-12): the same
    governing dependency (declared ``certifies_side``, else the configured
    environment of its name) and the same governing arrival (the latest that
    carried a count) the query's message tokens come from -- one answer.
    ``{}`` when no side is governed, ``{side: {dependency, status,
    reported_rows}}`` otherwise, ``{"_unreadable": why}`` when the mappings
    or the ledger could not be read (the judge then REFUSES)."""
    from core.feed import upstream_contract
    if getattr(db, "list_etl_dependency_mappings", None) is None:
        return {}
    return upstream_contract.as_reported_side_rows(
        upstream_contract.resolve(db, feed_config, business_date))


def hold_reason_at_creation(db: Any, feed_config: Any,
                            business_date: date) -> Optional[str]:
    """The creation-time dependency check every path that CREATES a run
    row applies -- SOD, the backfill launcher and the cron fire's
    create-when-absent branch -- so a row is born WAIT when its feed's
    dependencies are not ready.

    Returns the WAIT reason (``"waiting on A, B (+n more)"``) or None when
    the feed is admitted: no mappings under its effective etl_id (vacuously
    ready) or every one of them satisfied.

    Race-free by construction: the queue worker (30 s ticks) can claim a
    freshly created RUN row BEFORE the dependency poller (60 s ticks) has
    flipped it to WAIT, leaking a feed past its gate -- so the decision is
    made in the same call that writes the row.  The check is one SQL join
    per feed.

    Fail-OPEN, loudly: a broken dependency read must not stop the daily
    materialisation of the whole estate, so the row is written RUN with a
    WARNING and the poller's next tick re-asks.  That is the posture SOD
    has had since Phase 131-A; it is kept, not widened.
    """
    try:
        etl_id = effective_etl_id(feed_config)
        # 2026-10-25 -- the mapping rows are listed ONCE and the declared
        # sources resolved ONCE for both readers below.  The boolean check
        # and the four-verdict gate each listed the rows and re-ran every
        # source evaluator (a ledger read per declared source), so a HELD
        # feed paid the whole dependency read twice at creation -- at the
        # owner's month end that is every one of ~4,000 feeds, each with
        # CLOUD + ONPREM declared: measured 2 listings + 4 ledger reads per
        # feed, now 1 + 2 (tests/test_sod_creates_runs_in_few_statements_2026_10_25.py).
        # The decision is unchanged: the same rows, the same resolver, the
        # same gate -- read once instead of twice.  ``check_dependencies``
        # carries the rows it listed on ``result.rows``; a seam that
        # answers without them (a test's stand-in) falls back to the gate's
        # own listing below.
        result = check_dependencies(db, etl_id, business_date)
    except Exception as exc:
        logger.warning(
            "[etl_dependency] feed %s: dependency check failed at run "
            "creation for %s (%s) -- the row is written RUN and the poller "
            "re-checks on its next tick",
            (feed_config or {}).get("id") if hasattr(feed_config, "get")
            else feed_config, business_date, exc)
        return None
    if result.ready:
        return None
    # 2026-09-27 -- the SAME rule the poller applies (FR-DEP-08): the
    # four-verdict gate ADMITS a run whose only unmet dependencies are NOT
    # EXPECTED today (the upstream's own calendar says so), which the
    # boolean above cannot express.  Without this an upstream holiday
    # birthed the row WAIT and it sat there until the poller's next tick
    # re-asked -- a second readiness decision, taken a minute later.  The
    # gate can only ADMIT here, never block: a gate failure keeps the
    # boolean's answer.
    _rows = getattr(result, "rows", None)
    if (gate_admits_over_rows(db, _rows, business_date, etl_id=etl_id)
            if _rows is not None else gate_admits(db, etl_id, business_date)):
        logger.info(
            "[etl_dependency] feed %s @ %s admitted at creation: every unmet "
            "dependency is NOT EXPECTED today (the upstream's own calendar)",
            (feed_config or {}).get("id") if hasattr(feed_config, "get")
            else feed_config, business_date)
        return None
    pending_keys = [d.dependency_key for d in result.pending][:3]
    reason = "waiting on " + ", ".join(pending_keys)
    if len(result.pending) > 3:
        reason += f" (+{len(result.pending) - 3} more)"
    # 2026-09-27 -- a WAIT row is released ONLY by the dependency poller.
    # With the poller off (feed_generation.etl_dep_check_enabled, default
    # false) a held row would sit WAIT forever -- nothing flips it and the
    # 48 h escalation runs in the same poller.  So hold only when something
    # can release it; otherwise admit the run and say LOUDLY that its
    # declared dependencies are not being enforced.
    try:
        poller_on = bool(load_config().get("enabled"))
    except Exception:
        poller_on = False
    if not poller_on:
        logger.warning(
            "[etl_dependency] feed %s @ %s: %s -- NOT ENFORCED: the "
            "dependency poller is off, so a held run could never be "
            "released; the run proceeds. Set "
            "feed_generation.etl_dep_check_enabled=true to enforce "
            "dependencies.",
            (feed_config or {}).get("id") if hasattr(feed_config, "get")
            else feed_config, business_date, reason)
        return None
    return reason


def gate_admits(db: Any, etl_id: int, business_date: date) -> bool:
    """Does the FOUR-verdict gate admit this (etl_id, date)?  False on any
    failure -- the caller falls back to the boolean answer, so this can
    only ever ADMIT, never hold."""
    try:
        verdicts = evaluate_gate_verdicts(db, int(etl_id), business_date)
    except Exception as exc:
        logger.warning(
            "[etl_dependency] four-verdict gate failed for etl_id %s @ %s "
            "(%s) -- keeping the boolean answer", etl_id, business_date, exc)
        return False
    return bool(verdicts is not None and verdicts.admitted)


def gate_admits_over_rows(db: Any, rows: List[Dict[str, Any]],
                          business_date: date, *, etl_id: Any = None) -> bool:
    """:func:`gate_admits` over mapping rows ALREADY listed -- and already
    run through the declared-source resolver by :func:`check_dependencies_over_rows`
    (2026-10-25), so the gate does not list or resolve a second time.  The
    same posture: False on any failure, never a hold."""
    try:
        verdicts = evaluate_gate_over_rows(db, rows, business_date,
                                           sources_resolved=True)
    except Exception as exc:
        logger.warning(
            "[etl_dependency] four-verdict gate failed for etl_id %s @ %s "
            "(%s) -- keeping the boolean answer", etl_id, business_date, exc)
        return False
    return bool(verdicts is not None and verdicts.admitted)


def run_preflight(db: Any, feed_config: Any, business_date: date) -> dict:
    """What a Run Now for ``business_date`` would find at the gate
    (2026-09-27).  ONE answer, from the same ``evaluate_gate_verdicts``
    the poller, the blocking index and the skip routes read -- the Run Now
    dialog shows it and the execute route requires a reason on it.

    Never raises: an unreadable gate is reported as ``unavailable`` with
    the reason and ``admitted`` False -- and ``override_required`` stays
    False, because unreadable is not "not met": the execute route fails
    OPEN on it (loudly), exactly as the deployment-window read beside it
    and ``hold_reason_at_creation`` do.  A reason is required only for a
    dependency the gate could read and found NOT MET / COULD NOT TELL.
    """
    etl_id = effective_etl_id(feed_config)
    out: Dict[str, Any] = {
        "feed_id": (feed_config or {}).get("id") if hasattr(feed_config, "get") else None,
        "etl_id": int(etl_id),
        "business_date": business_date.isoformat(),
        "has_dependencies": False,
        "admitted": True,
        "asserted": False,
        "verdicts": [],
        "blocking": [],
        "unavailable": None,
        "override_required": False,
    }
    try:
        verdicts = evaluate_gate_verdicts(db, int(etl_id), business_date)
    except Exception as exc:
        logger.error("[etl_dependency] preflight for etl_id %s @ %s could "
                     "not read the gate: %s", etl_id, business_date, exc)
        out["unavailable"] = f"{type(exc).__name__}: {exc}"[:500]
        out["admitted"] = False
        return out
    if verdicts is None:
        out["unavailable"] = "the four-verdict gate module is absent"
        out["admitted"] = False
        return out
    out["has_dependencies"] = bool(verdicts.verdicts)
    out["admitted"] = bool(verdicts.admitted)
    out["asserted"] = bool(verdicts.asserted)
    out["verdicts"] = [v.to_dict() for v in verdicts.verdicts]
    out["blocking"] = [v.dependency_name for v in verdicts.blocking]
    out["override_required"] = not verdicts.admitted
    return out


@dataclass
class DepStatus:
    """One dependency's current state for a given business_date."""
    mapping_id:     int
    type_id:        int
    type_name:      str          # e.g. KAFKA, ORACLE_TABLE
    dependency_key: str
    action:         Optional[str]  # COMPLETE | SKIP | PENDING | RESET | None
    updated_at:     Optional[datetime] = None

    @property
    def ready(self) -> bool:
        return (self.action or "").upper() in READY_ACTIONS

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mapping_id":     self.mapping_id,
            "type_id":        self.type_id,
            "type_name":      self.type_name,
            "dependency_key": self.dependency_key,
            "action":         self.action,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
            "ready":          self.ready,
        }


@dataclass
class DependencyCheckResult:
    """Aggregate outcome for an etl_id @ business_date."""
    etl_id:        int
    business_date: date
    deps:          List[DepStatus] = field(default_factory=list)
    checked_at:    datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    #: The mapping rows this result was decided over, the declared sources
    #: already resolved onto them (2026-10-25) -- so the four-verdict gate
    #: can read the SAME rows without listing or resolving again.  None
    #: when the result was built without them.
    rows:          Optional[List[Dict[str, Any]]] = field(default=None, repr=False, compare=False)

    @property
    def ready(self) -> bool:
        # Vacuously ready when there are no dependencies mapped.
        return all(d.ready for d in self.deps)

    @property
    def pending(self) -> List[DepStatus]:
        return [d for d in self.deps if not d.ready]

    @property
    def complete(self) -> List[DepStatus]:
        return [d for d in self.deps if d.ready]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "etl_id":        self.etl_id,
            "business_date": self.business_date.isoformat(),
            "ready":         self.ready,
            "total_deps":    len(self.deps),
            "complete":      [d.to_dict() for d in self.complete],
            "pending":       [d.to_dict() for d in self.pending],
            "checked_at":    self.checked_at.isoformat(),
        }


# ── Core check (DB-agnostic; takes a fetcher) ───────────────────────


def check_dependencies(
    db: Any,
    etl_id: int,
    business_date: date,
) -> DependencyCheckResult:
    """Look up the dependency mappings for ``etl_id`` and merge with the
    tracking rows for ``business_date``.

    Requires the caller's ``db`` object to expose
    ``list_etl_dependency_mappings_with_tracking(etl_id, business_date)``
    returning a list of dicts with keys::

        mapping_id, type_id, type_name, dependency_key, action, updated_at
    """
    rows = db.list_etl_dependency_mappings_with_tracking(etl_id, business_date)
    return check_dependencies_over_rows(db, rows, etl_id, business_date)


def check_dependencies_over_rows(
    db: Any,
    rows: List[Dict[str, Any]],
    etl_id: int,
    business_date: date,
) -> DependencyCheckResult:
    """:func:`check_dependencies` over mapping rows ALREADY listed (2026-10-25):
    the declared-source resolver is applied to ``rows`` IN PLACE, so a caller
    that hands the same rows to :func:`evaluate_gate_over_rows` afterwards
    passes ``sources_resolved=True`` and the sources are read once."""
    # 2026-09-27 — a dependency that DECLARED its arrival sources is
    # decided by them, here as in the four-verdict gate: the resolver
    # projects the combined verdict onto ``action`` so this boolean and
    # evaluate_gate_verdicts cannot disagree.  Rows without a declaration
    # are untouched.
    _resolve_declared_sources(db, rows, business_date)
    deps = [
        DepStatus(
            mapping_id=int(r["mapping_id"]),
            type_id=int(r["type_id"]),
            type_name=str(r.get("type_name") or ""),
            dependency_key=str(r.get("dependency_key") or ""),
            action=(r.get("action") or None),
            updated_at=r.get("updated_at"),
        )
        for r in rows
    ]
    return DependencyCheckResult(
        etl_id=etl_id,
        business_date=business_date,
        deps=deps,
        rows=rows,
    )


# ── Poller (run by the scheduler under a leader lease) ──────────────


def _created_at_utc(raw: Any) -> Optional[datetime]:
    """A run row's ``created_at`` as an AWARE UTC datetime, or None.

    2026-09-27 — ``FeedRun.created_at`` is a plain ``DateTime`` column
    written from ``datetime.now(timezone.utc)``: SQLite and PostgreSQL
    both hand back a NAIVE value, and ``to_dict`` renders it as an ISO
    string with no offset.  The poller subtracted that from an aware
    ``now`` -- a ``TypeError`` raised OUTSIDE the per-row try, so the
    first held row past the SLA grace killed the whole pass (every row
    after it went unpolled) and the escalation sweep compared the same
    naive value against an aware cutoff.  The existing tests fed aware
    datetimes, which production never produces.  Naive means UTC here,
    because that is what the model writes.
    """
    if raw is None:
        return None
    if isinstance(raw, str):
        try:
            raw = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            return None
    if not isinstance(raw, datetime):
        return None
    if raw.tzinfo is None:
        return raw.replace(tzinfo=timezone.utc)
    return raw.astimezone(timezone.utc)


def _resolve_declared_sources(db: Any, rows: List[Dict[str, Any]],
                              business_date: date) -> int:
    """The ONE resolver for declared arrival sources
    (core/feed/arrival_sources.py), applied to the gate's rows in place.

    Called by BOTH readers of the rows -- ``check_dependencies`` (boolean)
    and ``evaluate_gate_verdicts`` (four verdicts) -- so a dependency with a
    declaration is decided once.  A resolver failure marks every declared
    row's evidence unreadable (COULD NOT TELL, and not ready), never met.
    """
    try:
        from core.feed.arrival_sources import (
            declared_sources, resolve_arrival_sources,
        )
    except ImportError:
        return 0
    try:
        return resolve_arrival_sources(db, rows, business_date)
    except Exception as exc:
        logger.error(
            "[etl_dependency] arrival-source resolution failed for business "
            "date %s (%s) -- every dependency with a declaration reports "
            "COULD NOT TELL this pass", business_date, exc)
        for row in rows:
            if declared_sources(row):
                row["evidence_readable"] = False
                if str(row.get("action") or "").upper() != "SKIP":
                    row["action"] = None
        return 0


def _apply_ledger_arrivals(db: Any, rows: List[Dict[str, Any]],
                           business_date: date) -> None:
    """Bridge the ARRIVAL LEDGER into the rows the gate reads.

    2026-09-02 — the seam that was missing.  The Kafka resolver records an
    arrival in ``dependency_events`` (append-only, replay-detecting), while the
    gate has always read the ``etl_dependency_tracking`` mirror.  Nothing
    connected the two, so a message could land, resolve, and be recorded — and
    the feed waiting on it would still sit at NOT MET all night.  The BRD's
    §7.1 diagram says "the gate re-evaluates" and names no owner for that
    conversion; this is it.

    ADMIT-ONLY, and mutates ``rows`` in place.  An arrival in the ledger can
    mark a dependency MET; nothing here can un-meet one the tracking table
    already satisfied.  A bridge that could also take satisfaction away would
    let a ledger read failure hold up a feed that was genuinely ready.

    Fail-open per dependency, and audible: if the ledger cannot be read for one
    name, that dependency simply keeps whatever the tracking table said —
    logged, because "the ledger says nothing" and "the ledger could not be
    read" are opposite findings.
    """
    try:
        from core.feed.ledger import derive_dependency_state
    except ImportError:
        return
    for row in rows:
        if row.get("action"):
            continue                    # already satisfied; admit-only
        if row.get("source_verdicts") is not None:
            # 2026-09-27 — a DECLARED dependency was decided by its
            # sources; the any-evidence bridge must not re-admit it on an
            # arrival from a source it did not declare.
            continue
        name = str(row.get("dependency_key") or "")
        if not name:
            continue
        try:
            state = derive_dependency_state(db, name, business_date)
        except Exception as exc:
            logger.error(
                "[etl_dependency] arrival ledger could not be read for %r "
                "(%s) — that dependency keeps its tracking-table state; a "
                "Kafka arrival for it will NOT be seen this pass",
                name, exc)
            continue
        if state.met:
            row["action"] = "COMPLETE"
            # FR-DEP-24 — what the upstream SAID it loaded, so the gate's
            # partial-load check ("says COMPLETE but loaded 60% of its
            # rows") has a producer on the reported side.  Only set when a
            # count actually arrived: writing None over a value the
            # tracking mirror already carried would erase evidence, and
            # writing 0 would fire the alarm on every upstream that
            # publishes no counts at all.
            if state.reported_rows is not None:
                row["reported_rows"] = state.reported_rows
            # The ledger is keyed by business date, so an arrival it returns
            # IS for this date — carried so the gate's stale-satisfaction
            # guard (FR-DEP-17) sees a date rather than a None it would have
            # to interpret.
            row["business_date"] = business_date
            # 2026-09-28 -- the DAO row always CARRIES ``updated_at`` (None
            # without a tracking row), so ``setdefault`` never wrote the
            # ledger's arrival time and every ledger-satisfied dependency
            # reported ``last_seen: None`` -- "arrived" with no "when" on
            # the Today page, and no time for a report's readiness sentence.
            if row.get("updated_at") is None:
                row["updated_at"] = state.last_arrived_at
            logger.info(
                "[etl_dependency] %r satisfied from the arrival ledger "
                "(%d arrival(s), %d distinct identity(ies)%s)",
                name, state.arrival_count, state.distinct_identities,
                ", REPLAY SEEN" if state.replay_seen else "")


def evaluate_gate_verdicts(db: Any, etl_id: int, business_date: date):
    """The FOUR-verdict gate (BRD §7) over the same rows ``check_dependencies``
    reads: met / not met / NOT EXPECTED / could not tell.

    ``check_dependencies`` above answers a BOOLEAN — ready or not — and that
    is what the poller has always acted on.  It cannot express the case the
    whole section exists for: the tenth message never comes because the
    UPSTREAM has a holiday we do not.  Reported as not-met, that pages someone
    at 04:19 to chase a message nobody was ever going to send; reported as
    not-expected it is not an incident at all.

    Returns a :class:`core.feed.dependency_gate.GateResult`, or None when the
    gate module is absent (an older build keeps the boolean behaviour).
    Loading each governing calendar is best-effort: a calendar that cannot be
    read yields COULD-NOT-TELL for that dependency, never a silent
    not-expected — excusing a dependency on a calendar we failed to read is
    how a broken upstream goes unnoticed.
    """
    try:
        from core.feed.dependency_gate import evaluate_gate  # noqa: F401 -- presence probe
    except ImportError:
        return None
    rows = db.list_etl_dependency_mappings_with_tracking(etl_id, business_date)
    return evaluate_gate_over_rows(db, rows, business_date)


def evaluate_gate_over_rows(db: Any, rows: List[Dict[str, Any]],
                            business_date: date, *,
                            sources_resolved: bool = False):
    """THE readiness decision over ALREADY-LISTED mapping rows (2026-09-28).

    ``evaluate_gate_verdicts`` lists a FEED's rows by etl_id and hands them
    here; ``core.reports.readiness`` lists a REPORT's rows
    (``report_dependency_mappings``, the same row shape) and hands them
    here too.  Everything that decides -- the declared-source resolver,
    the arrival-ledger bridge, the upstream calendars, the four verdicts --
    runs in this one function, so a report and a feed naming the same
    dependency can never be told two different things about the same
    business date.  Returns a ``GateResult``; None when the gate module is
    absent (an older build keeps the boolean behaviour).

    ``sources_resolved`` (2026-10-25): the caller already ran
    :func:`_resolve_declared_sources` over THESE rows (through
    :func:`check_dependencies_over_rows`) -- the projection is in place, so
    it is not read again.  The resolver is idempotent on the same rows at
    the same instant; this only saves the second read.
    """
    try:
        from core.feed.dependency_gate import evaluate_gate
    except ImportError:
        return None
    if not sources_resolved:
        _resolve_declared_sources(db, rows, business_date)
    _apply_ledger_arrivals(db, rows, business_date)
    calendars: Dict[str, Any] = {}
    for row in rows:
        cal_name = row.get("calendar_name")
        if not cal_name:
            continue
        try:
            from core.feed.calendar import (
                BusinessCalendar, BusinessCalendarRepo,
            )
            spec = BusinessCalendarRepo(db).get(str(cal_name))
            if spec is None:
                # A NAMED calendar that does not exist is a
                # misconfiguration, not an excuse: reporting
                # not-expected here would silence the dependency for
                # ever on the strength of a typo.
                logger.error(
                    "[etl_dependency] dependency %r names calendar %r, "
                    "which does not exist — reporting COULD NOT TELL "
                    "rather than excusing it",
                    row.get("dependency_key"), cal_name)
                row["evidence_readable"] = False
                continue
            cal = BusinessCalendar(spec)
        except Exception as exc:
            logger.error(
                "[etl_dependency] governing calendar %r for dependency %r "
                "could not be loaded (%s) — that dependency reports COULD NOT "
                "TELL rather than being excused on a calendar we never read",
                cal_name, row.get("dependency_key"), exc)
            row["evidence_readable"] = False
            continue
        if cal is not None:
            calendars[str(row.get("dependency_key") or "")] = cal
    return evaluate_gate(rows, business_date=business_date,
                         calendars=calendars)


#: What the last paged listing did (pages walked, ceiling hit) -- read by
#: ``poll_pending_runs`` into its counters right after the listing.
_LAST_PAGING: Dict[str, Any] = {}


def _governed_runs_paged(db: Any):
    """Every pending run the gate governs, walked in keyset pages.

    A db double without the ``after_id`` parameter (an older seam) gets
    the single legacy call -- the rows it returns are the rows it returns.
    """
    cfg = load_config()
    page = max(1, int(cfg.get("poll_page_size") or 500))
    ceiling = max(page, int(cfg.get("poll_max_rows") or 20000))
    _LAST_PAGING.clear()
    _LAST_PAGING.update({"pages": 0, "truncated": False})
    out: list = []
    after = 0
    while True:
        try:
            rows = db.list_pending_runs_needing_dep_check(limit=page, after_id=after)
        except TypeError as exc:
            if "after_id" not in str(exc) and "limit" not in str(exc):
                raise
            rows = db.list_pending_runs_needing_dep_check()
            _LAST_PAGING["pages"] = 1
            return list(rows or [])
        rows = list(rows or [])
        _LAST_PAGING["pages"] += 1
        out.extend(rows)
        if len(rows) < page:
            return out
        if len(out) >= ceiling:
            _LAST_PAGING["truncated"] = True
            logger.warning(
                "[etl_dependency] the dependency poller reached its ceiling of "
                "%d governed runs in one tick (feed_generation."
                "etl_dep_poll_max_rows) -- the rest are evaluated next tick",
                ceiling)
            return out
        after = max(int(r.get("id") or 0) for r in rows)


def poll_pending_runs(
    db: Any,
    *,
    broadcast_fn: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    sla_grace_hours: int = 2,
    now: Optional[datetime] = None,
) -> Dict[str, Any]:
    """One pass over the pending feed_runs the dependency gate governs:
    ``db.list_pending_runs_needing_dep_check()`` -- runs of feeds with
    active mappings under their EFFECTIVE etl_id (``effective_etl_id``:
    explicit etl_id, else the feed's own id), runs of feeds with an
    explicit etl_id, and any run already held at WAIT.  Each row carries
    ``etl_id`` = the effective key, so this poller and the authoring
    routes read the same mapping rows.

    For each: re-check dependency state, flip action_decision to RUN or
    WAIT, and (optionally) broadcast a WS event when a WAIT slides past
    the SLA grace period.

    Returns aggregate counters for the admin dashboard:
        {
          "scanned": int, "flipped_to_run": int, "still_waiting": int,
          "sla_breached": int, "errors": int
        }
    """
    counters = {
        "scanned": 0,
        "flipped_to_run": 0,
        "still_waiting": 0,
        "sla_breached": 0,
        "errors": 0,
        "pages": 0,
        "truncated": False,
    }
    now = now or datetime.now(timezone.utc)
    grace = timedelta(hours=int(sla_grace_hours) if sla_grace_hours else 0)

    # 2026-10-10 -- EVERY governed run, in pages (keyset on id).  The one
    # listing capped at 500 by priority: 4,000 month-end feeds released by
    # one message had rows 501+ held at WAIT until the first 500 were
    # CLAIMED, because a RUN-decided pending row stays in the set.  The
    # ceiling is logged when hit -- a silent cap is the defect this closes.
    try:
        candidates = list(_governed_runs_paged(db))
    except Exception as e:
        logger.error("[etl_dependency] could not list pending runs: %s", e)
        counters["errors"] += 1
        return counters
    counters["pages"] = int(_LAST_PAGING.get("pages") or 0)
    counters["truncated"] = bool(_LAST_PAGING.get("truncated"))

    for run in candidates:
        counters["scanned"] += 1
        etl_id = run.get("etl_id")
        biz_date = run.get("business_date")
        run_id = run.get("id")
        if not etl_id or not biz_date or not run_id:
            continue
        if isinstance(biz_date, str):
            try:
                biz_date = date.fromisoformat(biz_date)
            except ValueError:
                counters["errors"] += 1
                continue
        # FR-DEP-08 (2026-09-02) — consult the FOUR-verdict gate first.
        # It admits a run whose only unmet dependency is NOT EXPECTED
        # (the upstream's own calendar says today is not a business day
        # for them), which the boolean check below cannot express: it
        # would hold the feed all night waiting for a message nobody was
        # ever going to send, and page someone about it.
        #
        # It can only ADMIT, never block: anything the four-verdict gate
        # refuses falls through to the existing check, so this cannot
        # make a currently-runnable feed wait.  A gate failure is not
        # fatal either — the boolean answer is still there.
        _verdicts = None
        try:
            _verdicts = evaluate_gate_verdicts(db, int(etl_id), biz_date)
        except Exception as _gv_exc:
            logger.warning(
                "[etl_dependency] four-verdict gate failed for run %s "
                "(%s) — falling back to the boolean check; a not-expected "
                "dependency will block this run", run_id, _gv_exc)
        if _verdicts is not None and _verdicts.blocking:
            logger.info("[etl_dependency] run %s blocked by: %s",
                        run_id, "; ".join(
                            f"{v.dependency_name} ({v.reason})"
                            for v in _verdicts.blocking))
        try:
            result = check_dependencies(db, int(etl_id), biz_date)
            if (_verdicts is not None and _verdicts.admitted
                    and not result.ready):
                logger.info(
                    "[etl_dependency] run %s admitted by the four-verdict "
                    "gate: every unmet dependency is NOT EXPECTED today "
                    "(the upstream's own calendar), so nothing is late",
                    run_id)
                result = DependencyCheckResult(
                    etl_id=int(etl_id), business_date=biz_date, deps=[])
        except Exception as e:
            logger.warning(
                "[etl_dependency] check failed for run %s (etl_id=%s): %s",
                run_id, etl_id, e,
            )
            counters["errors"] += 1
            continue

        if result.ready:
            # Track whether this was a genuine state transition (WAIT→RUN)
            # vs. a no-op re-affirmation, so we only broadcast on actual
            # transitions and don't spam the UI.
            was_waiting = (run.get("action_decision") or "RUN") == "WAIT"
            try:
                _rel = {
                    "action_decision": "RUN",
                    "action_reason":   f"deps ready ({len(result.complete)} complete)",
                }
                if was_waiting:
                    # the decision to run is NOW, whatever the business date
                    # (2026-10-11): the queue worker's lookback reads it
                    _rel["released_at"] = datetime.now(timezone.utc).replace(tzinfo=None)
                db.update_feed_run(int(run_id), _rel)
                counters["flipped_to_run"] += 1
                if was_waiting and broadcast_fn is not None:
                    try:
                        # 2026-10-07: THE audience (core/feed/event_audience)
                        broadcast_fn("feed_dep_ready", address({
                            "feed_run_id":    int(run_id),
                            "feed_config_id": run.get("feed_config_id"),
                            "etl_id":         int(etl_id),
                            "complete_count": len(result.complete),
                        }, feed_event_audience(
                            db, run.get("feed_config_id"), None, run=run)))
                    except Exception:
                        pass
            except Exception as e:
                logger.warning(
                    "[etl_dependency] could not flip run %s to RUN: %s",
                    run_id, e,
                )
                counters["errors"] += 1
        else:
            pending_names = [d.dependency_key for d in result.pending][:5]
            reason = "waiting on " + ", ".join(pending_names)
            if len(result.pending) > 5:
                reason += f" (+{len(result.pending) - 5} more)"
            # 2026-09-27 — say WHICH SOURCE is blocking, in the gate's own
            # words, so the Today page's WAIT chip reads "waiting on
            # TRADES_LOADED: waiting on iceberg_commit: no commit of
            # ice_trades containing dt=... has been observed" rather than a
            # bare name.  The gate's verdicts are the same rows the boolean
            # was computed from, so the two cannot name different things.
            if _verdicts is not None and _verdicts.blocking:
                _detail = "; ".join(
                    f"{v.dependency_name}: {v.reason}"
                    for v in _verdicts.blocking[:5])
                if len(_verdicts.blocking) > 5:
                    _detail += f" (+{len(_verdicts.blocking) - 5} more)"
                reason = f"waiting on {_detail}"[:2000]
            try:
                db.update_feed_run(int(run_id), {
                    "action_decision": "WAIT",
                    "action_reason":   reason,
                })
                counters["still_waiting"] += 1
            except Exception as e:
                logger.warning(
                    "[etl_dependency] could not mark run %s as WAIT: %s",
                    run_id, e,
                )
                counters["errors"] += 1

            # SLA-breach broadcast -- ONCE per breach (2026-10-25, rig).  The
            # comment said "the caller is expected to dedupe" and no caller
            # did: every poller pass re-broadcast every held run past its
            # grace -- 16,153 queue rows in 3 hours on the rig (WebSocket
            # fan-out rows are never marked delivered), which also pushed the
            # Netcool sender hours behind.  Again only when WHAT it waits on
            # changes; a restart broadcasts a still-open breach once more.
            created = _created_at_utc(run.get("created_at"))
            if created and (now - created) > grace:
                counters["sla_breached"] += 1
                if broadcast_fn is not None and _first_breach_broadcast(int(run_id), pending_names):
                    try:
                        broadcast_fn("feed_dep_sla_breach", address({
                            "feed_run_id":   int(run_id),
                            "feed_config_id": run.get("feed_config_id"),
                            "etl_id":        int(etl_id),
                            "pending":       pending_names,
                            "waiting_hours": round(
                                (now - created).total_seconds() / 3600.0, 2,
                            ),
                        }, feed_event_audience(
                            db, run.get("feed_config_id"), None, run=run)))
                    except Exception:
                        pass

    return counters


#: run id -> the pending names its last breach broadcast carried (bounded)
_BREACH_BROADCAST_MAX = 50000
_breach_broadcast: "Dict[int, tuple]" = {}


def _first_breach_broadcast(run_id: int, pending: List[str]) -> bool:
    """True when this run's breach has not been broadcast with this pending
    set by this process; records it.  Bounded: the oldest half is forgotten
    past the cap (a forgotten run is broadcast once more, never silenced)."""
    key = tuple(sorted(str(p) for p in pending or ()))
    if _breach_broadcast.get(run_id) == key:
        return False
    if len(_breach_broadcast) >= _BREACH_BROADCAST_MAX:
        for k in list(_breach_broadcast)[: _BREACH_BROADCAST_MAX // 2]:
            _breach_broadcast.pop(k, None)
    _breach_broadcast[run_id] = key
    return True


# ── Config helpers ──────────────────────────────────────────────────


def load_config() -> Dict[str, Any]:
    try:
        from core.config import _db_setting_or
    except ImportError:
        _db_setting_or = None  # type: ignore

    def _resolve(key: str, default: Any) -> Any:
        # DB setting (admin App Config) first; else the DECLARED config
        # value (config.json / QUERYSTUDIO_* env); else the literal.
        try:
            from core.config import get as _cfg_get
            section, _, name = key.partition(".")
            declared = _cfg_get(section, name, default)
        except Exception:
            declared = default
        if _db_setting_or is None:
            return declared
        return _db_setting_or(key, declared)

    return {
        # 2026-09-27 -- ON by default (matches core/config.py _DEFAULTS
        # verbatim): a WAIT row is released by this poller and nothing else.
        "enabled":             bool(_resolve("feed_generation.etl_dep_check_enabled", True)),
        "interval_seconds":    int(_resolve("feed_generation.etl_dep_check_interval_seconds", 60)),
        "sla_grace_hours":     float(_resolve("feed_generation.etl_dep_sla_hours", 2)),
        "leader_only":         bool(_resolve("feed_generation.etl_dep_check_leader_only", True)),
        # Phase 131 deep-dive #12 — escalation timeout.  Feed runs stuck
        # in WAIT longer than this are flipped to failed so they don't
        # hang silently forever (e.g. when the dep poller is off OR
        # when an upstream is genuinely broken).  Default 48h.  Set to
        # 0 to disable escalation.
        "wait_escalation_hours": float(_resolve("feed_generation.etl_dep_wait_escalation_hours", 48)),
        # 2026-10-10 -- paging of the per-tick scan (see poll_pending_runs).
        "poll_page_size":      int(_resolve("feed_generation.etl_dep_poll_page_size", 500)),
        "poll_max_rows":       int(_resolve("feed_generation.etl_dep_poll_max_rows", 20000)),
    }


def escalate_stale_wait_runs(
    db: Any,
    *,
    escalation_hours: float = 48.0,
    broadcast_fn: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    now: Optional[datetime] = None,
) -> Dict[str, Any]:
    """Phase 131 deep-dive #12 — escalation sweep for feed_runs stuck in
    WAIT longer than ``escalation_hours``.  Flips them to status='failed'
    with action_reason explaining the timeout so ops can triage.

    Called from the same scheduler tick as poll_pending_runs.  Cheap
    DB scan; only fires when there are actually stuck rows.

    2026-09-27 -- the escalation REACHES A PERSON.  Until then it flipped
    the row and broadcast ``feed_dep_wait_escalated`` over a function that
    nothing consumed (and whose signature did not even match, so the call
    raised inside its own try).  Each escalated run now goes through the
    run-outcome notification path (``feed_engine._send_notifications`` --
    the feed's ``notify_emails`` plus its owner group's
    ``notification_email``, THE mailer), lands as a bell notification for
    the feed's owner, and is recorded as a ``dependency_wait_escalated``
    run event carrying the ORIGINAL WAIT reason and the notification
    verdict, so the timeline says who was told and how.

    Returns counters: {scanned, escalated, notified, errors}.
    """
    counters = {"scanned": 0, "escalated": 0, "notified": 0, "errors": 0}
    if escalation_hours <= 0:
        return counters
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=float(escalation_hours))

    try:
        candidates = db.list_pending_runs_needing_dep_check()
    except Exception as e:
        logger.warning("[etl_dependency] escalation: list failed: %s", e)
        counters["errors"] += 1
        return counters

    for run in candidates:
        counters["scanned"] += 1
        if (run.get("action_decision") or "") != "WAIT":
            continue
        raw_created = run.get("created_at")
        created = _created_at_utc(raw_created)
        if created is None:
            if raw_created is not None:
                counters["errors"] += 1     # present but unreadable
            continue
        if created > cutoff:
            continue
        # Stuck longer than threshold → escalate.
        run_id = run.get("id")
        prior_reason = run.get("action_reason") or "waiting on deps"
        msg = (
            f"{ESCALATION_PREFIX} {escalation_hours}h in WAIT.  Original: {prior_reason}.  "
            f"Verify upstream dependencies + tracking table; consider system_account "
            f"fallback if portal auth was expected to land."
        )
        hours_waiting = round((now - created).total_seconds() / 3600.0, 2)
        try:
            db.update_feed_run(int(run_id), {
                "status": "failed",
                "action_decision": "SKIP",
                "action_reason": msg,
                "completed_at": now,
                "error": msg,
            })
            counters["escalated"] += 1
        except Exception as e:
            logger.warning(
                "[etl_dependency] escalation: could not mark run %s failed: %s",
                run_id, e,
            )
            counters["errors"] += 1
            continue
        verdict = notify_wait_escalation(
            db, run, message=msg, wait_reason=str(prior_reason),
            hours_waiting=hours_waiting, now=now)
        if verdict.get("reached"):
            counters["notified"] += 1
        if broadcast_fn is not None:
            try:
                broadcast_fn("feed_dep_wait_escalated", address({
                    "feed_run_id":   int(run_id),
                    "feed_config_id": run.get("feed_config_id"),
                    "feed_name": verdict.get("feed_name"),
                    "business_date": str(run.get("business_date") or ""),
                    "hours_waiting": hours_waiting,
                    "wait_reason": str(prior_reason),
                    "reason": msg,
                }, feed_event_audience(db, run.get("feed_config_id"), None,
                                       run=run)))
            except Exception as exc:
                logger.warning("[etl_dependency] escalation broadcast for "
                               "run %s failed: %s", run_id, exc)
    return counters


#: The prefix every escalated run's action_reason / error carries.  The
#: Today page recognises an escalated run by it (one spelling, both sides).
ESCALATION_PREFIX = "Escalated after"


def notify_wait_escalation(db: Any, run: Dict[str, Any], *, message: str,
                           wait_reason: str, hours_waiting: float,
                           now: Optional[datetime] = None) -> Dict[str, Any]:
    """Tell a person that a run gave up waiting (2026-09-27).

    Three channels, each fail-soft and each RECORDED:

    * e-mail through the run-outcome path (``feed_engine._send_
      notifications`` with outcome ``failure`` -- the feed's
      ``notify_on_failure`` / ``notify_emails`` and its owner group's
      ``notification_email`` decide the recipients, exactly as for a run
      that failed in the engine);
    * a bell notification for the feed's owner (``created_by``), the same
      ``NotificationLog`` rows the notification bell polls;
    * a ``dependency_wait_escalated`` run event carrying the ORIGINAL WAIT
      reason and the verdict of the two channels above.

    Returns ``{reached, feed_name, owner, email, bell, event}``;
    ``reached`` is True when at least one channel delivered to someone.
    """
    now = now or datetime.now(timezone.utc)
    out: Dict[str, Any] = {"reached": False, "feed_name": None, "owner": None,
                           "email": {"state": "none"}, "bell": {"state": "none"},
                           "event": {"state": "none"}}
    feed_id = run.get("feed_config_id")
    try:
        feed = db.get_feed_config(int(feed_id)) if feed_id is not None else None
    except Exception as exc:
        logger.error("[etl_dependency] escalation: feed %s unreadable (%s) -- "
                     "nobody can be told", feed_id, exc)
        feed = None
    if not feed:
        out["email"] = {"state": "failed", "reason": "feed config unreadable"}
        return out
    feed_name = feed.get("name") or f"feed {feed_id}"
    owner = str(feed.get("created_by") or "").strip() or None
    out["feed_name"], out["owner"] = feed_name, owner
    bd = str(run.get("business_date") or "")

    # 1. e-mail, through THE run-outcome path.
    try:
        from core.feed_engine import _send_notifications
        verdict = _send_notifications(feed, "failure", {
            "feed_name": feed_name,
            "error": message,
            "wait_reason": wait_reason,
            "business_date": bd,
            "feed_run_id": run.get("id"),
            "hours_waiting": hours_waiting,
            "escalation": True,
            "duration": None,
        }, db=db)
        out["email"] = dict((verdict or {}).get("email") or {"state": "none"})
        if out["email"].get("state") == "none" and not feed.get("notify_on_failure"):
            out["email"]["reason"] = ("the feed has notify_on_failure off -- "
                                      "no e-mail is configured for its failures")
    except Exception as exc:
        logger.error("[etl_dependency] escalation e-mail for run %s failed: %s",
                     run.get("id"), exc)
        out["email"] = {"state": "failed", "reason": str(exc)[:300]}
    if out["email"].get("state") == "sent":
        out["reached"] = True

    # 2. the bell, for the owner.
    title = f"Feed {feed_name} gave up waiting on its dependencies"
    body = (f"Run for {bd} escalated after {hours_waiting}h in WAIT and was "
            f"marked failed. Waiting on: {wait_reason}. Skip the dependency "
            f"with a reason, or re-run once the upstream lands.")
    if owner:
        try:
            db.log_notification(
                event_type="feed_dep_wait_escalated", channel="websocket",
                recipient=owner, status="sent", title=title, message=body,
                payload={"feed_run_id": run.get("id"), "feed_config_id": feed_id,
                         "business_date": bd, "wait_reason": wait_reason,
                         "hours_waiting": hours_waiting,
                         "href": "/feeds/today"})
            out["bell"] = {"state": "sent", "recipient": owner}
            out["reached"] = True
        except Exception as exc:
            logger.error("[etl_dependency] escalation bell row for %s failed: %s",
                         owner, exc)
            out["bell"] = {"state": "failed", "recipient": owner,
                           "reason": str(exc)[:300]}
    else:
        out["bell"] = {"state": "none", "reason": "the feed has no owner"}

    # 3. the record.
    try:
        db.insert_run_event({
            "feed_config_id": int(feed_id),
            "business_date": _as_date(run.get("business_date")) or now.date(),
            "build_id": run.get("build_id"),
            "event_type": "dependency_wait_escalated",
            "subject": wait_reason[:500],
            "actor": "system",
            "payload": {
                "feed_run_id": run.get("id"),
                "reason": message,
                "wait_reason": wait_reason,
                "hours_waiting": hours_waiting,
                "notification": {"email": out["email"], "bell": out["bell"]},
                "source": "wait_escalation",
            },
        })
        out["event"] = {"state": "recorded"}
    except Exception as exc:
        logger.error("[etl_dependency] escalation run event for run %s could "
                     "not be written: %s", run.get("id"), exc)
        out["event"] = {"state": "failed", "reason": str(exc)[:300]}
    if not out["reached"]:
        logger.error(
            "[etl_dependency] run %s (%s @ %s) escalated and NOBODY WAS "
            "REACHED: email=%s bell=%s.  Set notify_on_failure + "
            "notify_emails on the feed (or its group's notification_email) "
            "and give the feed an owner.",
            run.get("id"), feed_name, bd, out["email"], out["bell"])
    return out


def _as_date(raw: Any) -> Optional[date]:
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    if isinstance(raw, str):
        try:
            return date.fromisoformat(raw[:10])
        except ValueError:
            return None
    return None
