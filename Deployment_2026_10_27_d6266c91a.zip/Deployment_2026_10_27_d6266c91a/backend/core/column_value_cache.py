"""THE cache of a column's distinct values (2026-10-24).

One cache for every "what values does this column have?" question: the
query builder's value picker (``/api/sql/distinct-values``) and a report
parameter's choices (``core/reports/param_choices.py``).  It was the CQB's
private ``_DISTINCT_CACHE``; the owner: "CQB is already caching all values --
use it".  So a list the query builder read for ``fact_tetb.region`` also
serves a report whose parameter traces to ``fact_tetb.region``.

The key is (connection, table, column, search text, the reader's scope).
The scope is ``query_cache.rls_user_scope`` plus the policy-set marker, so a
filtered reader's list is never served to, or taken from, anyone else.  An
entry records how many values were ASKED for: it serves any later request
for no more than that, or any request at all once it is ``complete`` (it
held fewer values than were asked for, so it is the whole list).

Values are stored as read (a date stays a date); a caller that needs
strings converts them.  Entries live ``ttl_seconds()``
(``business_reports.lov_cache_seconds``, default 300 -- the CQB's 5 minutes).
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, List, Optional, Tuple

_MAX_ENTRIES = 2000
_lock = threading.Lock()
_entries: "dict[Tuple, _Entry]" = {}


@dataclass
class _Entry:
    at: float
    values: List[Any]
    asked: int          # how many values the read asked for (0 = no cap)
    complete: bool      # fewer came back than were asked for: the whole list


def ttl_seconds() -> float:
    try:
        from core.config import business_reports as _br
        return float(max(0, int(_br.lov_cache_seconds)))
    except Exception:                                        # noqa: BLE001
        return 300.0


def scope_for(user: Any) -> str:
    """The reader's cache scope: '' when one answer may serve everyone."""
    try:
        from core.query_cache import rls_user_scope
        scope = rls_user_scope(user) or ""
    except Exception:                                        # noqa: BLE001
        return "unverified"
    if scope:
        from core.row_security.cache_scope import policy_set_marker
        scope = f"{scope}:{policy_set_marker()}"
    return scope


def key(connection_id: Any, table: str, column: str, *, search: str = "",
        scope: str = "", qualifier: str = "") -> Tuple:
    """``qualifier`` separates reads of the same table whose scope differs in
    another way (a report's cascade parent)."""
    bare = str(column).rsplit(".", 1)[-1].lower()
    return (str(connection_id), str(table).strip().lower(), bare,
            str(search or "").strip().lower(), scope, qualifier)


def get(k: Tuple, want: int) -> Optional[List[Any]]:
    """The cached list for a request of ``want`` values (0 = all), or None."""
    with _lock:
        e = _entries.get(k)
        if e is None:
            return None
        if time.monotonic() - e.at >= ttl_seconds():
            _entries.pop(k, None)
            return None
        if e.complete or (want and e.asked and want <= e.asked):
            return list(e.values if not want else e.values[:want])
        return None


def put(k: Tuple, values: List[Any], asked: int) -> None:
    complete = (not asked) or len(values) < asked
    with _lock:
        if len(_entries) >= _MAX_ENTRIES:
            oldest = sorted(_entries.items(), key=lambda kv: kv[1].at)[: _MAX_ENTRIES // 4]
            for kk, _ in oldest:
                _entries.pop(kk, None)
        _entries[k] = _Entry(time.monotonic(), list(values), int(asked or 0), complete)


def clear() -> None:
    with _lock:
        _entries.clear()
