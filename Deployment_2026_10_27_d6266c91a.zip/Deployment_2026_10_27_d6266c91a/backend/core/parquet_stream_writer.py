"""ParquetStreamWriter -- bounded-queue, background-thread parquet writer
for interactive SQL connector queries (Trino / Starburst / Snowflake /
Databricks / Oracle / Athena).

Strategic shape (per ``ETL/steps/file/starburst_file_base.ChunkWriter``,
operator directive 2026-06-24: "may be we have to do same as how we do
starburst to file etl workflow"):

  cursor.fetchmany(batch_size) ──► main thread ──► bounded Queue ──►
    background thread ──► pyarrow.parquet.ParquetWriter ──► output file

Memory bound: queue holds at most ``maxsize`` batches.  At
``batch_size=10_000`` and ~150 bytes/row that's ~1.5 MB per batch;
maxsize=4 caps peak resident at ~6 MB regardless of total result
size.  For 170M-row results this is the difference between
``OOMKill at 50-100M rows`` and ``ships the file``.

Differs from ETL ChunkWriter in:
  * writes PARQUET (not CSV) via pyarrow.ParquetWriter so the
    Download Center can serve a single compressed columnar file
    that BQB / CQB previews can read efficiently.
  * single output file per query (ETL splits into chunks for
    parallel writers + downstream reconcile).
  * no per-column SUM accumulator (ETL needs it for reconcile;
    interactive queries don't).
  * preserves the SAME bounded-queue + background-thread shape
    so per-batch memory cost is the same.

Why pyarrow.ParquetWriter (not pandas.DataFrame.to_parquet on each
batch): ParquetWriter keeps ONE open file handle, writes row-group
metadata incrementally, and only finalises the parquet footer on
``close()``.  Per-batch pandas would either:
  * write one parquet PER BATCH (caller has to concat -- defeats
    the memory bound), OR
  * keep a growing DataFrame -- same OOM as today.

Fail-safe semantics:
  * Cursor exception in producer => background thread sees
    ``signal_end()``; ``finalise()`` raises so caller marks failed.
  * Background thread exception => stored on ``self.error``; next
    ``put_batch()`` raises (back-pressure surfaces the failure).
  * Cancel mid-stream => caller raises InterruptedError; finalise()
    closes the writer + deletes the partial file so no orphan
    parquet ships to Download Center.
"""
from __future__ import annotations

import logging
from collections.abc import Mapping
import os
import threading
from queue import Empty, Queue
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# Sentinel used to signal "no more batches" to the background thread.
_SENTINEL_END = object()

#: 2026-10-26 -- cells (rows x columns) a parquet ROW GROUP holds before it is
#: written.  Every ``put_batch`` used to become one row group: the cell budget
#: (core/feed/batch_budget.py) sizes a 600-column fetch at 277 rows, so a
#: 2M-row feed wrote ~7,200 row groups x 600 column chunks -- measured on
#: 20,000 x 600: 73 row groups took 12.7 s and 34.7 MB against 4 row groups in
#: 9.2 s and 23.2 MB, and every reader parses the footer whole.  A batch is
#: still converted to Arrow as it arrives (its Python objects are freed); the
#: Arrow batches stay COLUMNAR until this many cells are pending, then go out
#: as ONE row group.  4M cells of Arrow is tens of MB, never Python objects.
ROW_GROUP_CELLS = 4_000_000


#: decimal128 tops out at 38 digits; decimal256 at 76.
_DEC128_MAX_PRECISION = 38
_DEC256_MAX_PRECISION = 76


#: Source type name -> arrow type, for columns pyarrow could not infer because
#: the first batch held nothing but NULLs.  Deliberately coarse: it only has to
#: be WIDE ENOUGH to hold the values that arrive later.
def _arrow_type_for_declared(decl, pa):
    d = (decl or "").strip().lower()
    if not d:
        return None
    if d.startswith("decimal") or d.startswith("numeric"):
        # 2026-08-21 — NEVER INVENT A SCALE.  This returned
        # decimal128(38, 9) for every decimal, so a source column of
        # decimal(38,12) would have been written at scale 9 and SILENTLY LOST
        # THREE DECIMAL PLACES.  On money columns that is the worst possible
        # outcome — worse than the crash it was meant to prevent.
        #
        # SCALE is the number of digits after the point: changing it changes
        # the VALUE.  PRECISION is only a declared ceiling, so widening that is
        # free.  So: take the scale the source declared, widen only precision,
        # and if the scale cannot be read with certainty return None — falling
        # back to pyarrow's inference from the actual values, which is correct
        # by construction.
        import re as _re
        m = _re.search(r"\(\s*(\d+)\s*(?:,\s*(\d+)\s*)?\)", d)
        if not m or m.group(2) is None:
            return None            # no explicit scale -> do not guess
        _scale = int(m.group(2))
        if _scale > _DEC128_MAX_PRECISION:
            return None
        return pa.decimal128(_DEC128_MAX_PRECISION, _scale)
    if any(k in d for k in ("timestamp", "datetime")):
        return pa.timestamp("us")
    if d.startswith("date"):
        return pa.date32()
    if d.startswith("bool"):
        return pa.bool_()
    if any(k in d for k in ("bigint", "long", "int8")):
        return pa.int64()
    if any(k in d for k in ("int", "smallint", "tinyint")):
        return pa.int64()
    if any(k in d for k in ("double", "float", "real")):
        return pa.float64()
    if any(k in d for k in ("varchar", "char", "string", "text", "uuid",
                            "json", "varbinary")):
        return pa.string()
    return None


def _schema_from_declared(schema, declared, pa):
    """Fix the two things first-batch inference cannot get right.

    2026-08-21.  The file schema is inferred from the FIRST batch and pinned for
    the whole file.  That is right for most columns — the DATA is the best
    authority once there is any — but it is wrong in exactly two places, and
    both caused production failures:

    1. A column that arrived entirely NULL infers as ``pa.null()``, which is not
       a type, it is "could not tell".  The first later row carrying a value
       dies with ``Invalid null value``.  The source declared the type; use it.

    2. A DECIMAL's SCALE.  A SQL decimal column has ONE fixed scale —
       ``decimal(38,2)`` means every value carries two decimal places.  But the
       driver returns Decimal objects with their own exponents, so a first batch
       of ``Decimal("1.5")`` pins scale 1 and the next value ``Decimal("2.25")``
       cannot be represented:

           ArrowInvalid: Rescaling Decimal value would cause data loss

       Inference is sampling one batch to guess a property the source states
       exactly.  The declared scale holds every value in the column by
       definition.

    SCALE IS NEVER INVENTED.  An earlier cut of this returned
    ``decimal128(38, 9)`` for every decimal, which would have silently truncated
    a ``decimal(38,12)`` column by three digits — on money columns, far worse
    than the crash it replaced.  When the declared type carries no scale (a bare
    ``decimal``), the inferred scale stands.

    Everything else keeps the inferred type untouched.
    """
    try:
        changed = False
        fields = []
        for f in schema:
            want = _arrow_type_for_declared(declared.get(f.name), pa)
            if pa.types.is_null(f.type):
                # No information from the data at all.
                if want is None:
                    want = pa.string()      # holds anything that arrives later
                    logger.info(
                        "[parquet-stream] column %r was NULL in the first batch "
                        "and its source type %r is unmapped — writing it as "
                        "string so later values are not lost",
                        f.name, declared.get(f.name))
                fields.append(f.with_type(want))
                changed = True
            elif (pa.types.is_decimal(f.type) and want is not None
                  and pa.types.is_decimal(want) and not want.equals(f.type)):
                # Declared scale wins for decimals — see (2) above.
                fields.append(f.with_type(want))
                changed = True
            elif (pa.types.is_integer(f.type) and want is not None
                  and pa.types.is_floating(want)):
                # 3. INTEGER INFERRED, FLOATING DECLARED.
                #
                # A first batch of whole numbers (1, 2, 3) infers int64 for a
                # column the source declares DOUBLE.  The next value with a
                # fractional part is then silently TRUNCATED by the cast:
                #
                #     put 1, then 2.5  ->  written as [1, 2]
                #
                # No error, no warning, wrong number in a financial column.
                # Widening int -> float is lossless for every value the column
                # can hold, and the source already said the column is floating.
                # Deliberately ONE direction: float -> int would be the very
                # truncation this prevents.
                fields.append(f.with_type(want))
                changed = True
            else:
                fields.append(f)
        return pa.schema(fields) if changed else schema
    except Exception:
        logger.debug("declared-schema build skipped", exc_info=True)
        return schema


def _resolve_null_fields(schema, declared, pa):
    """Give a real type to any field pyarrow inferred as NULL.

    2026-08-21 — the schema is inferred from the FIRST batch and pinned for the
    file.  A column that happens to be entirely NULL in that batch is inferred
    as ``pa.null()`` — which is not a type, it is "could not tell" — and the
    first later row carrying a real value dies:

        ArrowInvalid: Invalid null value

    which killed a Starburst query that had already run at the source.  On a
    wide result set with nullable columns this is close to inevitable: it only
    takes one column whose first thousand rows are NULL.

    The SOURCE already told us the type, so use it.  When it cannot be mapped,
    fall back to string: it holds anything that arrives, and a value displayed
    as text beats a query that dies.
    """
    try:
        changed = False
        fields = []
        for f in schema:
            if pa.types.is_null(f.type):
                t = _arrow_type_for_declared(declared.get(f.name), pa)
                if t is None:
                    t = pa.string()
                    logger.info(
                        "[parquet-stream] column %r was NULL in the first "
                        "batch and its source type %r is unmapped — writing it "
                        "as string so later values are not lost",
                        f.name, declared.get(f.name))
                fields.append(f.with_type(t))
                changed = True
            else:
                fields.append(f)
        return pa.schema(fields) if changed else schema
    except Exception:
        logger.debug("null-field resolution skipped", exc_info=True)
        return schema


def _widen_decimals(schema, pa):
    """Widen every DECIMAL field to its maximum precision, keeping the scale.

    2026-08-21 — the schema is inferred from the FIRST batch, then pinned for
    the whole file.  pyarrow derives a decimal's precision from the DIGITS IT
    ACTUALLY SEES, so a first batch whose largest value needs 28 digits pins
    decimal128(28, s) — and the first later row needing 29 blows up:

        ArrowInvalid: Decimal type with precision 29 does not fit into
        precision inferred from first array element: 28

    which killed a Starburst query that had already SUCCEEDED at the source.
    The failure is about MAGNITUDE, not about the column: the same column is
    fine for thousands of rows and then is not.

    Precision is only a declared upper bound — widening it to the maximum
    stores the identical values and cannot lose or change a digit.  The SCALE
    is what determines the decimal point, so it is preserved exactly.

    Returns the original schema object when there is nothing to widen, so the
    caller can skip a needless rebuild.
    """
    try:
        changed = False
        fields = []
        for f in schema:
            t = f.type
            if pa.types.is_decimal128(t) and t.precision < _DEC128_MAX_PRECISION:
                fields.append(f.with_type(
                    pa.decimal128(_DEC128_MAX_PRECISION, t.scale)))
                changed = True
            elif (hasattr(pa.types, "is_decimal256")
                  and pa.types.is_decimal256(t)
                  and t.precision < _DEC256_MAX_PRECISION):
                fields.append(f.with_type(
                    pa.decimal256(_DEC256_MAX_PRECISION, t.scale)))
                changed = True
            else:
                fields.append(f)
        return pa.schema(fields) if changed else schema
    except Exception:
        # Never block a write over this — the un-widened schema is exactly
        # today's behaviour.
        logger.debug("decimal widening skipped", exc_info=True)
        return schema


class ParquetStreamWriter:
    """Streaming parquet writer with bounded-queue back-pressure.

    Usage:

        writer = ParquetStreamWriter(
            output_path="/.../result.parquet",
            columns=[{"name": "id", "type": "BIGINT"}, ...],
        )
        writer.start()
        try:
            for batch in cursor.fetchmany_batches(batch_size=10_000):
                writer.put_batch(batch)        # blocks if queue full
            writer.signal_end()
            writer.finalise()                  # waits for drain
        except Exception:
            writer.cancel()
            raise
        finally:
            writer.close()

    ``columns`` is a list of dicts with ``name`` keys (and optional
    pyarrow type info).  The first batch establishes the schema by
    inference from the row data; subsequent batches MUST match.

    ``output_path`` parent dir must exist (caller creates it).
    """

    def __init__(
        self,
        output_path: str,
        columns: List[Dict[str, Any]],
        *,
        queue_maxsize: int = 4,
        compression: str = "snappy",
        idle_timeout_seconds: int = 600,
        row_group_cells: int = ROW_GROUP_CELLS,
    ):
        self.output_path = output_path
        self.columns = columns
        self._row_group_cells = max(1, int(row_group_cells or 1))
        self._pending: List[Any] = []      # Arrow batches of the open row group
        self._pending_cells = 0
        self.column_names: List[str] = [c.get("name", "") for c in columns]
        #: name -> the SOURCE's declared type string, used only to resolve
        #: a column pyarrow could not infer (see _resolve_null_fields).
        self._declared_types = {
            str(c.get("name", "")): str(c.get("type") or "").lower()
            for c in (columns or [])
        }
        self.compression = compression
        self.idle_timeout = max(60, int(idle_timeout_seconds))
        self._queue: Queue = Queue(maxsize=max(1, int(queue_maxsize)))
        self._thread: Optional[threading.Thread] = None
        self._writer = None
        self._schema = None
        self.records_written: int = 0
        self.error: Optional[BaseException] = None
        self._error_reported = False
        self._cancelled = False

    # ── Public API ─────────────────────────────────────────────

    def start(self) -> None:
        """Start the background writer thread.  Idempotent."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._run,
            name=f"parquet-stream-{os.path.basename(self.output_path)}",
            daemon=False,
        )
        self._thread.start()

    def put_batch(
        self, batch: List[Tuple], timeout: float = 120.0,
    ) -> None:
        """Push a batch onto the queue.  Blocks when full (back
        pressure).  Surfaces any prior background-thread error so
        callers fail fast.
        """
        if self.error is not None:
            raise self.error
        if self._cancelled:
            raise RuntimeError("ParquetStreamWriter: cancelled")
        self._queue.put(batch, timeout=timeout)

    def signal_end(self, timeout: float = 60.0) -> None:
        """Tell the background thread no more batches are coming."""
        self._queue.put(_SENTINEL_END, timeout=timeout)

    def cancel(self) -> None:
        """Mid-stream cancel.  Drops the partial output file.  Safe
        to call from a different thread than the producer."""
        self._cancelled = True
        try:
            # Drain any in-flight batches so the bg thread can exit.
            self._queue.put_nowait(_SENTINEL_END)
        except Exception:
            pass

    def finalise(self, timeout: Optional[float] = None) -> int:
        """Wait for the background thread to drain + close the writer.

        Returns the row count written.  Raises any error the bg
        thread captured (including cancel-related ones).

        Caller MUST call after signal_end (the bg thread won't exit
        until it sees the sentinel).
        """
        if self._thread is None:
            return self.records_written
        self._thread.join(timeout=timeout)
        if self._thread.is_alive():
            # Hard timeout -- caller should treat this as failure.
            self.error = TimeoutError(
                f"ParquetStreamWriter finalise timed out after "
                f"{timeout}s; bg thread still running"
            )
        if self._cancelled:
            self._cleanup_partial_file()
            raise InterruptedError("Cancelled by user")
        if self.error is not None:
            self._cleanup_partial_file()
            raise self.error
        return self.records_written

    def close(self) -> None:
        """Defensive close + thread join with short timeout.  Safe
        to call multiple times.

        2026-08-21 — close() never looked at ``self.error``.  ``put_batch`` and
        ``finalise`` raise it, but a failure in the LAST batch is only ever seen
        by close() — so a writer thread that died on the final chunk produced a
        file that was short, and the caller saw success.  Silent row loss.
        close() cannot raise (it runs in ``finally``, where raising would mask
        the original exception), so it makes noise instead: an unreported write
        failure now leaves an ERROR in the log rather than nothing at all.
        """
        if self.error is not None and not self._error_reported:
            self._error_reported = True
            logger.error(
                "[parquet-stream] %s: the writer thread FAILED and nothing "
                "raised it — the output file is INCOMPLETE (%d row(s) written "
                "before the failure): %s",
                self.output_path, self.records_written, self.error,
                exc_info=self.error,
            )
        # 2026-08-31 -- ORDER MATTERS, and it used to be the wrong way round.
        # This closed self._writer FIRST and stopped the producer thread
        # afterwards, so the writer thread could be inside pyarrow's
        # write_table() while this thread closed the very same ParquetWriter.
        # pyarrow's writer is not thread-safe and the overlap faults in C++:
        # it is a PROCESS ABORT, not an exception -- no traceback, nothing in
        # the log, and any other request in flight dies with it.  (It killed a
        # whole test worker outright.)  The thread already closes the writer
        # itself when it sees the sentinel, so it was always a second,
        # concurrent closer.  A close() from a finally after a cancel or an
        # error is exactly the moment a batch is still in flight.
        if self._thread is not None and self._thread.is_alive():
            try:
                self._queue.put_nowait(_SENTINEL_END)
            except Exception:
                pass
            self._thread.join(timeout=5.0)
        if self._writer is not None:
            if self._thread is not None and self._thread.is_alive():
                # Still writing after the join timed out.  Closing now would
                # race pyarrow and take the process down; leaking the handle
                # to interpreter shutdown is strictly the lesser harm, and a
                # later close() call retries because _writer stays set.
                logger.error(
                    "[parquet-stream] %s: the writer thread is STILL running "
                    "after close() waited 5s -- not closing the pyarrow "
                    "writer, because doing so would race it and abort the "
                    "process. The file may be incomplete.",
                    self.output_path,
                )
            else:
                try:
                    self._writer.close()
                except Exception:
                    pass
                self._writer = None

    # ── Internal ───────────────────────────────────────────────

    def _cleanup_partial_file(self) -> None:
        """Drop a partial / corrupt parquet so Download Center never
        serves it."""
        try:
            if os.path.exists(self.output_path):
                os.unlink(self.output_path)
        except Exception:
            pass

    def _run(self) -> None:
        """Background-thread loop: drain queue, write batches to
        parquet, exit on sentinel / cancel / error."""
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError as exc:
            self.error = exc
            return

        while True:
            try:
                item = self._queue.get(timeout=self.idle_timeout)
            except Empty:
                self.error = TimeoutError(
                    f"ParquetStreamWriter idle for "
                    f"{self.idle_timeout}s -- producer stalled "
                    f"or connection dropped"
                )
                return

            if item is _SENTINEL_END:
                break

            if self._cancelled:
                continue   # drain queue silently

            try:
                self._write_batch(item, pa, pq)
            except BaseException as exc:
                self.error = exc
                logger.warning(
                    "[parquet-stream] %s write_batch error: %s",
                    os.path.basename(self.output_path), exc,
                    exc_info=True,
                )
                return

        # Close writer cleanly on sentinel -- the open row group first.
        try:
            if not self._cancelled:
                self._flush_row_group()
            if self._writer is not None:
                self._writer.close()
                self._writer = None
        except Exception as exc:
            self.error = exc

    def _stage(self, data: Any) -> None:
        """Keep an Arrow batch (or table) for the open row group; write the
        row group once it holds ``row_group_cells`` cells."""
        batches = data.to_batches() if hasattr(data, "to_batches") else [data]
        for rb in batches:
            self._pending.append(rb)
            self._pending_cells += rb.num_rows * rb.num_columns
        if self._pending_cells >= self._row_group_cells:
            self._flush_row_group()

    def _flush_row_group(self) -> None:
        """Write what is pending as ONE row group."""
        if not self._pending or self._writer is None:
            self._pending, self._pending_cells = [], 0
            return
        import pyarrow as pa
        tbl = pa.Table.from_batches(self._pending, schema=self._schema)
        self._pending, self._pending_cells = [], 0
        self._writer.write_table(tbl, row_group_size=max(1, tbl.num_rows))

    @staticmethod
    def _is_nan(value: Any) -> bool:
        """True only for a float NaN.  ``v != v`` is the NaN identity — using
        ``math.isnan`` would raise on the non-floats that share this column."""
        return isinstance(value, float) and value != value

    def _nan_to_none_in_text_columns(self, cols_data: Dict[str, List[Any]], pa) -> None:
        """Replace float NaN with None in NON-NUMERIC columns, in place.

        2026-08-10.  A report grouped by any nullable text dimension could not
        write its artifact at all::

            pyarrow.lib.ArrowTypeError: Expected bytes, got a 'float' object

        ``pandas.DataFrame.itertuples`` — which ``df_to_parquet_streaming``
        uses to slice the result into batches — yields ``float('nan')``, not
        ``None``, for a SQL NULL in a string column.  pyarrow infers ``string``
        from the first real value and then refuses the NaN, so the whole write
        fails.  Reproduced directly: a DuckDB ``GROUP BY`` over a text column
        containing NULLs returns ``[('East', 1.0), (nan, 2.0), ('', 3.0)]``.

        This is the shared artifact-write path for the federation/business-report
        engine (``federation_engine.execute_dataset_query``), so it broke the
        same way for EVERY source type, not just files.

        NUMERIC columns are deliberately left alone: NaN in a float column is a
        real float value with its own meaning, and rewriting it to NULL would
        change what the report says.  The distinction is made from the pinned
        schema once one exists, and from the presence of text values in the
        batch before that — which is the only information available while the
        schema is still being inferred.
        """
        pinned = {}
        if self._schema is not None:
            try:
                for field in self._schema:
                    pinned[field.name] = field.type
            except Exception:  # noqa: BLE001 - a mocked pyarrow may not iterate
                pinned = {}

        for name, values in cols_data.items():
            ftype = pinned.get(name)
            if ftype is not None:
                try:
                    numeric = pa.types.is_floating(ftype) or pa.types.is_decimal(ftype)
                except Exception:  # noqa: BLE001 - partial pyarrow mock
                    numeric = False
                if numeric:
                    continue
            else:
                # Schema not pinned yet: only touch a column that actually
                # carries text, so a pure float column keeps its NaNs.
                if not any(isinstance(v, (str, bytes)) for v in values):
                    continue
            if any(self._is_nan(v) for v in values):
                cols_data[name] = [None if self._is_nan(v) else v for v in values]

    def _write_batch(self, batch: List[Tuple], pa, pq) -> None:
        """Convert tuple rows -> pyarrow RecordBatch -> write."""
        if not batch:
            return
        # Convert list of tuples into a dict-of-columns so pyarrow
        # can build a RecordBatch.  None / NaN values pass through;
        # pyarrow infers the schema from the first non-null per col.
        n_cols = len(self.column_names)
        cols_data: Dict[str, List[Any]] = {
            name: [] for name in self.column_names
        }
        # 2026-08-20 -- ROWS ARRIVE KEYED BY NAME, NOT BY POSITION.
        #
        # Every SQL connector yields
        #     [dict(zip(col_names, row)) for row in batch]
        # -- trino/starburst, snowflake, databricks, oracle and athena, all
        # five.  This loop indexed rows POSITIONALLY (``row[i]``), which on a
        # dict is a KEY lookup, so the first column of the first row raised:
        #
        #     File "core/parquet_stream_writer.py", line 326, in _write_batch
        #         cols_data[name].append(row[i])
        #     KeyError: 0
        #
        # surfacing to the user as "SQL connector query failed: 0" -- a message
        # in which the entire diagnosis is the digit zero.  The query had
        # already SUCCEEDED at Starburst; the rows were in hand and it was the
        # write that failed.
        #
        # Both shapes are accepted rather than one being declared correct: the
        # connectors clearly agree on mappings, but this writer is also fed
        # positional rows elsewhere, and a writer that only accepts what its
        # current callers happen to send is how this broke in the first place.
        # PER ROW, not once per batch.  Deciding from the first row alone meant
        # a batch that mixed shapes hit `'tuple' object has no attribute 'get'`
        # and lost the WHOLE batch — the same all-or-nothing failure as the bug
        # this replaced.  The check is an isinstance on a value already in hand.
        for row in batch:
            if isinstance(row, Mapping):
                # Keyed by column name.  A column the row omits is NULL --
                # never a KeyError, because a partial row must not lose the
                # whole batch.
                for name in self.column_names:
                    cols_data[name].append(row.get(name))
                continue
            # Positional.  Tolerate short / long rows -- pad / truncate
            # against the declared column count.
            if len(row) < n_cols:
                row = tuple(row) + (None,) * (n_cols - len(row))
            elif len(row) > n_cols:
                row = tuple(row[:n_cols])
            for i, name in enumerate(self.column_names):
                cols_data[name].append(row[i])

        self._nan_to_none_in_text_columns(cols_data, pa)

        # Phase 154 defensive shim: ``pa.RecordBatch`` is the standard
        # entry point but pre-existing tests (test_s3_readers_phase_b)
        # monkeypatch ``sys.modules["pyarrow"]`` with a partial mock
        # that strips RecordBatch.  Fall back to ``Table.from_pydict``
        # when the attribute is missing -- functionally equivalent for
        # write_table + survives mock pollution AND real pyarrow.
        _has_rb = hasattr(pa, "RecordBatch")
        if self._writer is None:
            # First batch -- infer schema from this batch's data.
            if _has_rb:
                rb = pa.RecordBatch.from_pydict(cols_data)
                self._schema = _schema_from_declared(
                    _widen_decimals(rb.schema, pa),
                    self._declared_types, pa)
                if self._schema is not rb.schema:
                    rb = pa.RecordBatch.from_pydict(cols_data,
                                                    schema=self._schema)
                self._writer = pq.ParquetWriter(
                    self.output_path, self._schema,
                    compression=self.compression,
                )
                self._stage(rb)
            else:
                tbl = pa.Table.from_pydict(cols_data)
                self._schema = _schema_from_declared(
                    _widen_decimals(tbl.schema, pa),
                    self._declared_types, pa)
                if self._schema is not tbl.schema:
                    tbl = pa.Table.from_pydict(cols_data, schema=self._schema)
                self._writer = pq.ParquetWriter(
                    self.output_path, self._schema,
                    compression=self.compression,
                )
                self._stage(tbl)
        else:
            if _has_rb:
                rb = pa.RecordBatch.from_pydict(cols_data, schema=self._schema)
                self._stage(rb)
            else:
                tbl = pa.Table.from_pydict(cols_data, schema=self._schema)
                self._stage(tbl)

        self.records_written += len(batch)


__all__ = ["ParquetStreamWriter"]
