"""The service review for ALL of QueryStudio -- 2026-10-26.

The owner: "Service Review ?? whats this doesnt make sense... i thought its
for all query studio components".  The page answered four FEED questions
(``core/feed/service_review.py``).  These sections answer the same kind of
question for the rest of the platform, over the same period:

  reports         which reports failed most, how long they took
                  (``business_report_async_jobs`` -- the rows behind each
                  report's Execution History);
  queries         query runs by the engine that answered
                  (``query_executions``);
  published APIs  calls, errors, refusals and speed per API
                  (``published_api_call_rollups``, day grain);
  platform        which component went down or could not be checked
                  (``component_health_events``) and which alerts were
                  raised, per area (``feed_alerts``, every subject kind).

Same honesty contract as the feed sections: each section degrades on its
own, and one that could not be read SAYS so (``unavailable``) -- an empty
section because a query failed must never read as "nothing to report".
Read-only: every number is derived from rows something else writes.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, Dict, List

from core.feed.run_surface import SurfaceSection, _section

logger = logging.getLogger(__name__)

#: the areas of the review, in the order the page shows them -- ONE list the
#: route returns, so the page never guesses which section belongs where
AREAS: Dict[str, List[str]] = {
    "feeds": ["success_rate_by_group", "trending_slower",
              "dependency_late_most_often", "skips"],
    "reports": ["report_runs", "query_runs_by_engine"],
    "published_apis": ["api_calls"],
    "platform": ["component_downtime", "alerts_raised"],
}

#: the statuses that count as a failed run
_FAILED = ("failed", "error")


def _start_of(since: date) -> datetime:
    # the tables store naive UTC timestamps
    return datetime(since.year, since.month, since.day)


def _seconds(start: Any, end: Any):
    if start is None or end is None:
        return None
    try:
        s = (end.replace(tzinfo=None) - start.replace(tzinfo=None)).total_seconds()
    except Exception:                                        # noqa: BLE001
        return None
    return s if s >= 0 else None


def _iso(v: Any):
    return v.isoformat() if hasattr(v, "isoformat") else v


def _rate(bad: int, total: int):
    return round(bad / total, 4) if total else None


def report_runs(db: Any, *, since: date) -> SurfaceSection:
    """Per report: runs, failures, the failure rate, average and longest
    time, and the last failure's reason.  Worst first."""
    def _fn():
        from core.db.models import BusinessReport, BusinessReportAsyncJob as J
        agg: Dict[int, dict] = {}
        with db.get_session(read_only=True) as session:
            q = (session.query(J.report_id, J.status, J.created_at,
                               J.completed_at, J.error)
                 .filter(J.created_at >= _start_of(since))
                 .order_by(J.created_at.asc()))
            for rid, status, created, completed, error in q.yield_per(2000):
                a = agg.setdefault(int(rid), {"runs": 0, "failed": 0, "secs": [],
                                              "last_failure": None,
                                              "last_failure_at": None})
                a["runs"] += 1
                st = (status or "").lower()
                if st in _FAILED:
                    a["failed"] += 1
                    a["last_failure"] = (error or "").strip()[:300] or None
                    a["last_failure_at"] = _iso(created)
                elif st == "completed":
                    s = _seconds(created, completed)
                    if s is not None:
                        a["secs"].append(s)
            names = dict(session.query(BusinessReport.id, BusinessReport.name)
                         .filter(BusinessReport.id.in_(list(agg) or [0])).all())
        out = []
        for rid, a in agg.items():
            secs = a.pop("secs")
            out.append({
                "report_id": rid,
                "report": names.get(rid) or f"report #{rid} (deleted)",
                "runs": a["runs"], "failed": a["failed"],
                "failure_rate": _rate(a["failed"], a["runs"]),
                "avg_seconds": round(sum(secs) / len(secs), 1) if secs else None,
                "max_seconds": round(max(secs), 1) if secs else None,
                "last_failure": a["last_failure"],
                "last_failure_at": a["last_failure_at"],
            })
        out.sort(key=lambda r: (-r["failed"], -r["runs"], r["report"]))
        return out
    return _section("report_runs", _fn)


def query_runs_by_engine(db: Any, *, since: date) -> SurfaceSection:
    """Query runs (reports, the query builder, previews) by the engine that
    answered them.  A run that recorded no engine is 'not recorded', never a
    guess."""
    def _fn():
        from core.db.models import QueryExecution as Q
        agg: Dict[str, dict] = {}
        with db.get_session(read_only=True) as session:
            q = (session.query(Q.engine, Q.status, Q.started_at, Q.completed_at)
                 .filter(Q.started_at >= _start_of(since)))
            for engine, status, started, completed in q.yield_per(5000):
                a = agg.setdefault(engine or "not recorded",
                                   {"runs": 0, "failed": 0, "cancelled": 0, "secs": []})
                a["runs"] += 1
                st = (status or "").lower()
                if st in _FAILED:
                    a["failed"] += 1
                elif st == "cancelled":
                    a["cancelled"] += 1
                elif st == "completed":
                    s = _seconds(started, completed)
                    if s is not None:
                        a["secs"].append(s)
        out = []
        for engine, a in agg.items():
            secs = sorted(a.pop("secs"))
            out.append({
                "engine": engine, "runs": a["runs"], "failed": a["failed"],
                "cancelled": a["cancelled"],
                "failure_rate": _rate(a["failed"], a["runs"]),
                "avg_seconds": round(sum(secs) / len(secs), 2) if secs else None,
                "p95_seconds": (round(secs[min(len(secs) - 1, int(len(secs) * 0.95))], 2)
                                if secs else None),
            })
        out.sort(key=lambda r: -r["runs"])
        return out
    return _section("query_runs_by_engine", _fn)


def api_calls(db: Any, *, since: date) -> SurfaceSection:
    """Per published API: calls, errors (4xx / 5xx), refusals, average and
    slowest answer, last call -- from the day rollups, the numbers the API
    dashboard shows."""
    def _fn():
        from core.db.models import PublishedApiCallRollup as R
        agg: Dict[tuple, dict] = {}
        with db.get_session(read_only=True) as session:
            q = (session.query(R.api_kind, R.api_id, R.api_slug, R.calls,
                               R.client_4xx, R.server_5xx, R.refused,
                               R.latency_ms_sum, R.latency_ms_max, R.last_call_at)
                 .filter(R.grain == "day", R.bucket_start >= _start_of(since)))
            for kind, aid, slug, calls, c4, c5, refused, lat_sum, lat_max, last in q.yield_per(5000):
                a = agg.setdefault((kind or "", int(aid or 0)), {
                    "slug": None, "calls": 0, "c4": 0, "c5": 0, "refused": 0,
                    "lat_sum": 0, "lat_max": None, "last": None})
                a["slug"] = a["slug"] or slug
                a["calls"] += int(calls or 0)
                a["c4"] += int(c4 or 0)
                a["c5"] += int(c5 or 0)
                a["refused"] += sum(int(v or 0) for v in (refused or {}).values())
                a["lat_sum"] += int(lat_sum or 0)
                if lat_max is not None:
                    a["lat_max"] = max(a["lat_max"] or 0, int(lat_max))
                if last is not None and (a["last"] is None or last > a["last"]):
                    a["last"] = last
        out = []
        for (kind, aid), a in agg.items():
            errors = a["c4"] + a["c5"]
            out.append({
                "api_kind": kind, "api_id": aid,
                "api": a["slug"] or ("an unknown API" if not aid else f"{kind} #{aid}"),
                "calls": a["calls"], "client_errors": a["c4"], "server_errors": a["c5"],
                "error_rate": _rate(errors, a["calls"]), "refused": a["refused"],
                "avg_ms": round(a["lat_sum"] / a["calls"]) if a["calls"] else None,
                "max_ms": a["lat_max"], "last_call": _iso(a["last"]),
            })
        out.sort(key=lambda r: (-(r["server_errors"] + r["client_errors"]), -r["calls"], r["api"]))
        return out
    return _section("api_calls", _fn)


def component_downtime(db: Any, *, since: date) -> SurfaceSection:
    """Per component: how often it went DOWN, how often it could not be
    checked, and the last time with the reason it gave."""
    def _fn():
        from core.component_health.vocabulary import DOWN, UNKNOWN
        from core.db.models import ComponentHealthEvent as E
        agg: Dict[str, dict] = {}
        with db.get_session(read_only=True) as session:
            q = (session.query(E.component_id, E.to_state, E.at, E.reason, E.pod_id)
                 .filter(E.at >= _start_of(since), E.to_state.in_((DOWN, UNKNOWN)))
                 .order_by(E.at.asc()))
            for comp, state, at, reason, pod in q.yield_per(5000):
                a = agg.setdefault(comp, {"down": 0, "unknown": 0, "pods": set(),
                                          "last_at": None, "last_state": None,
                                          "last_reason": None})
                a["down" if state == DOWN else "unknown"] += 1
                if pod:
                    a["pods"].add(pod)
                a["last_at"], a["last_state"] = _iso(at), state
                a["last_reason"] = (reason or "").strip()[:300] or None
        out = [{
            "component": comp, "times_down": a["down"],
            "times_not_checkable": a["unknown"], "pods": len(a["pods"]),
            "last_at": a["last_at"], "last_state": a["last_state"],
            "last_reason": a["last_reason"],
        } for comp, a in agg.items()]
        out.sort(key=lambda r: (-r["times_down"], -r["times_not_checkable"], r["component"]))
        return out
    return _section("component_downtime", _fn)


#: the area an alert belongs to, by its subject kind (NULL = a feed alert,
#: written before subjects existed)
_ALERT_AREA = {None: "feeds", "": "feeds", "feed": "feeds", "published_api": "published APIs",
               "component": "platform", "report": "reports"}


def alerts_raised(db: Any, *, since: date) -> SurfaceSection:
    """Alerts raised in the period, per area and kind: how many, how many
    are still open, the highest severity."""
    def _fn():
        from sqlalchemy import func
        from core.db.models import FeedAlert as A
        with db.get_session(read_only=True) as session:
            rows = (session.query(A.subject_kind, A.kind, A.status,
                                  func.count(A.id), func.max(A.severity),
                                  func.max(A.raised_at))
                    .filter(A.raised_at >= _start_of(since))
                    .group_by(A.subject_kind, A.kind, A.status)
                    .all())
        agg: Dict[tuple, dict] = {}
        for subject, kind, status, n, sev, last in rows:
            area = _ALERT_AREA.get(subject, subject)
            a = agg.setdefault((area, kind), {"raised": 0, "open": 0, "severity": 0,
                                              "last": None})
            a["raised"] += int(n)
            if (status or "") == "open":
                a["open"] += int(n)
            a["severity"] = max(a["severity"], int(sev or 0))
            if last is not None and (a["last"] is None or last > a["last"]):
                a["last"] = last
        out = [{"area": area, "kind": kind, "raised": a["raised"], "still_open": a["open"],
                "highest_severity": a["severity"], "last_raised": _iso(a["last"])}
               for (area, kind), a in agg.items()]
        out.sort(key=lambda r: (-r["still_open"], -r["raised"], r["area"], r["kind"]))
        return out
    return _section("alerts_raised", _fn)


def platform_sections(db: Any, *, since: date) -> List[SurfaceSection]:
    """Every non-feed section, in ``AREAS`` order."""
    return [report_runs(db, since=since), query_runs_by_engine(db, since=since),
            api_calls(db, since=since), component_downtime(db, since=since),
            alerts_raised(db, since=since)]
