"""THE cross-source capability -- how two sources are combined, for EVERY
surface and ANY source on either side (2026-10-04).

The bottom half of this module (``combine_spec`` / ``run_side_to_parquet`` /
``combine_sides`` / ``execute_cross_source``) is the one answer the query
builder, the SQL page, federation views, merged-dataset reports, feeds and
the raw-SQL report runner all route through; read the block comment above
``CrossSourceRefusal`` first.  The top half is the pure SQL assembly it uses:

Phase 139 honest-fix #3 — extracted cross-source COMBINE SQL builder.

Pure SQL string assembly for the UNION / JOIN branch of cross-source
queries. Extracted from api/execute_api.execute_cross_query_background so
the combine logic can be tested in isolation (no DB / async / WS deps).

Validation rules retained from the original:
  - JOIN type must be one of {INNER, LEFT, RIGHT, FULL, CROSS}
  - Non-CROSS JOIN must have left_on + right_on of equal length
  - Suffixes for column conflict disambiguation must be alphanumeric (BF-102)
  - UNION uses UNION ALL BY NAME with __empty__ EXCLUDE for empty sides
  - Overlap columns get suffixed (right_on keys are NOT included in result)

Public API:
  build_union_combine_sql(p_path, s_path, out_path, p_cols, s_cols)
  build_join_combine_sql(p_path, s_path, out_path, join_config, p_cols, s_cols)
  build_pandas_merge_select_sql(...)  — pandas-``merge``-SHAPED DuckDB join
  describe_columns(con, parquet_path)  — small helper for the inline DESCRIBE
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

# Valid JOIN types pinned by the existing engine
VALID_JOIN_TYPES = {"INNER", "LEFT", "RIGHT", "FULL", "CROSS"}

# Suffix validation: alphanumeric + underscore only (BF-102)
_SUFFIX_RE = re.compile(r"[A-Za-z0-9_]+")


def _esc_path(p: str) -> str:
    """Escape single quotes for inclusion in a SQL string literal."""
    return str(p).replace("'", "''")


def _esc_ident(c: str) -> str:
    """Escape double quotes for use inside a quoted SQL identifier."""
    return str(c).replace('"', '""')


def _on_clause(left_on: Sequence[str], right_on: Sequence[str],
               key_cast_varchar: Optional[Sequence[bool]] = None) -> str:
    """``a."k" = b."k" AND ...`` -- the ONE ON-clause renderer for both
    join shapes.  A pair flagged in ``key_cast_varchar`` compares as text
    on both sides (see :func:`join_key_casts`)."""
    casts = list(key_cast_varchar or [])
    parts = []
    for i, (lk, rk) in enumerate(zip(left_on, right_on)):
        a = f'a."{_esc_ident(lk)}"'
        b = f'b."{_esc_ident(rk)}"'
        if i < len(casts) and casts[i]:
            a, b = f"CAST({a} AS VARCHAR)", f"CAST({b} AS VARCHAR)"
        parts.append(f"{a} = {b}")
    return " AND ".join(parts)


def describe_columns(con, parquet_path: str) -> List[Tuple[str, Any]]:
    """Return [(col_name, type_str), ...] for a parquet file via DuckDB DESCRIBE.

    Used to:
      - detect type mismatches across UNION sides (warn user)
      - resolve column overlap for JOIN suffix disambiguation
      - check for the BF-121 __empty__ placeholder column
    """
    try:
        desc = con.execute(
            f"SELECT * FROM read_parquet('{_esc_path(parquet_path)}') LIMIT 0"
        ).description
        if not desc:
            return []
        return [(d[0], d[1]) for d in desc]
    except Exception as exc:
        logger.debug("describe_columns failed for %s: %s", parquet_path, exc)
        return []


def detect_union_type_mismatches(
    primary_cols: List[Tuple[str, Any]],
    secondary_cols: List[Tuple[str, Any]],
) -> List[str]:
    """Return list of "col_name: primary_type→secondary_type" for shared
    columns whose types differ. DuckDB will auto-promote so this is a
    warning, not an error."""
    p_types = dict(primary_cols)
    s_types = dict(secondary_cols)
    return [
        f"{c}: {p_types[c]}→{s_types[c]}"
        for c in p_types
        if c in s_types and p_types[c] != s_types[c]
    ]


def build_union_combine_sql(
    primary_parquet:   str,
    secondary_parquet: str,
    output_parquet:    str,
    primary_cols:      List[Tuple[str, Any]],
    secondary_cols:    List[Tuple[str, Any]],
    limit:             Optional[int] = None,
    select_only:       bool = False,
) -> str:
    """Build the COPY-style UNION ALL by-name SQL (``select_only``: just the
    SELECT, for a caller that pages / counts / projects it itself).

    The output goes to ``output_parquet`` as ZSTD-compressed parquet via
    DuckDB's COPY ... TO.

    2026-10-10 -- the alignment is THE merge plan
    (``core.feed.merge_by_name.plan_merge``, mirrored into the Spark job):
    columns matched by name case-insensitively, output in the PRIMARY's
    order and spelling, a side's missing column a typed NULL, and a
    same-named column of incompatible types REFUSES (``MergeRefused``, a
    ValueError) instead of DuckDB's silent promotion to text.  Until then
    this emitted ``UNION ALL BY NAME``, which promoted a DECIMAL under a
    VARCHAR to VARCHAR with a warning nobody reading the file could see.

    BF-121: the __empty__ placeholder column is dropped by the plan.
    """
    from core.feed.merge_by_name import plan_merge, sql_select_list
    p_esc = _esc_path(primary_parquet)
    s_esc = _esc_path(secondary_parquet)
    o_esc = _esc_path(output_parquet)

    plan = plan_merge(list(primary_cols), list(secondary_cols))

    # ``limit`` (2026-08-11) — a bound on the COMBINED result, applied here so
    # a caller never has to bound the SIDES instead.  Truncating an input to a
    # combine silently changes the output; truncating the output is a visible,
    # disclosable cut.  None = no LIMIT clause at all.
    limit_clause = (f" LIMIT {int(limit)}"
                    if limit is not None and int(limit) > 0 else "")

    select = (
        f"SELECT * FROM ("
        f"SELECT {sql_select_list(plan, 'primary')} FROM read_parquet('{p_esc}')"
        f" UNION ALL "
        f"SELECT {sql_select_list(plan, 'secondary')} FROM read_parquet('{s_esc}')"
        f")"
        f"{limit_clause}"
    )
    if select_only:
        return select
    return f"COPY ({select}) TO '{o_esc}' (FORMAT PARQUET, COMPRESSION ZSTD)"


def normalise_join_config(join_config: Dict[str, Any]) -> Tuple[
    str, List[str], List[str], List[str]
]:
    """Validate + normalise a JOIN config dict.

    Returns (how, left_on, right_on, suffixes).

    Raises ValueError on invalid join type, missing keys, or mismatched
    left_on/right_on lengths.

    - how: uppercased + validated against VALID_JOIN_TYPES
    - left_on / right_on: coerced to lists; required for non-CROSS joins;
      must be same length
    - suffixes: validated alphanumeric (BF-102); falls back to defaults
    """
    if not join_config:
        raise ValueError("join_config required for join mode")

    # 2026-10-04 -- ONE join vocabulary.  ``outer`` / ``full outer`` /
    # ``full_outer`` all mean FULL; the query builder's own JOIN-type menu
    # sends ``outer``, and this gate refused it, so FULL OUTER was offered in
    # the UI and could never run.  ``normalise_join_how`` is the only reader.
    how = normalise_join_how(join_config.get("how", "inner")).upper()
    if how not in VALID_JOIN_TYPES:
        raise ValueError(f"Invalid join type '{how}' — must be one of {VALID_JOIN_TYPES}")

    left_on = join_config.get("left_on")
    right_on = join_config.get("right_on")
    if isinstance(left_on, str):
        left_on = [left_on]
    if isinstance(right_on, str):
        right_on = [right_on]
    left_on = list(left_on or [])
    right_on = list(right_on or [])

    if how != "CROSS":
        if not left_on or not right_on:
            raise ValueError("join_config must specify left_on and right_on")
        if len(left_on) != len(right_on):
            raise ValueError(
                f"left_on ({len(left_on)}) and right_on ({len(right_on)}) "
                f"must have same length"
            )

    raw_suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
    suffixes = [s for s in (raw_suffixes or [])[:2]
                if isinstance(s, str) and _SUFFIX_RE.fullmatch(s)]
    if len(suffixes) < 2:
        suffixes = ["_primary", "_secondary"]

    return how, left_on, right_on, suffixes


def semi_join_pushdown_allowed(
    join_config: Optional[Dict[str, Any]],
    primary_filter_logic: str = "AND",
    primary_has_filters: bool = False,
    primary_is_raw_sql: bool = False,
) -> Tuple[bool, str]:
    """THE correctness gate for cross-source semi-join pushdown, stated once.

    Pushdown filters the PRIMARY (left, ``a``) side down to the key set
    observed on the secondary side.  That is only sound when the join would
    drop non-matching primary rows anyway:

    * INNER / RIGHT  → safe (non-matching left rows never survive the join)
    * LEFT / FULL    → UNSAFE: those joins exist precisely to KEEP unmatched
      primary rows; pushdown deleted them (verified: 3 rows → 1).  The old
      gate excluded only CROSS.
    * config-injection path with ``filter_logic=OR`` → UNSAFE: the injected
      IN filter joins the OR group and WIDENS the primary result instead of
      narrowing it (raw_sql primary is fine — the IN is ANDed onto a wrapper
      ``SELECT * FROM (raw) WHERE ...``).

    Returns (allowed, reason) — the reason is logged so a skipped pushdown
    is observable, never silent.
    """
    how = ((join_config or {}).get("how", "inner") or "inner").upper()
    if how not in ("INNER", "RIGHT"):
        return False, (
            f"{how} JOIN keeps unmatched primary rows — filtering the "
            f"primary by the secondary's key set would delete exactly the "
            f"rows this join type exists to keep"
        )
    if (not primary_is_raw_sql and primary_has_filters
            and str(primary_filter_logic or "AND").upper() == "OR"):
        return False, (
            "primary filter_logic=OR — appending the semi-join IN filter to "
            "an OR group would WIDEN the primary result instead of narrowing it"
        )
    return True, "ok"


def build_join_combine_sql(
    primary_parquet:   str,
    secondary_parquet: str,
    output_parquet:    str,
    join_config:       Dict[str, Any],
    primary_col_names:  List[str],
    secondary_col_names: List[str],
    limit:              Optional[int] = None,
    key_cast_varchar:   Optional[Sequence[bool]] = None,
    select_only:        bool = False,
) -> str:
    """Build the COPY-style JOIN SQL (``select_only``: just the SELECT).

    ``key_cast_varchar`` (2026-10-04) -- one flag per key pair; a True pair
    is compared as ``CAST(.. AS VARCHAR)`` on both sides.  Set by
    :func:`join_key_casts` when one side's key is text and the other's is
    not (a Snowflake NUMBER beside a Trino VARCHAR, or an empty side that
    the connector chokepoint typed as text): DuckDB refuses to compare a
    VARCHAR column with a non-VARCHAR one, so without it the join failed.

    Args:
        primary_parquet:    path to primary side temp parquet
        secondary_parquet:  path to secondary side temp parquet
        output_parquet:     path to combined result parquet
        join_config:        {how, left_on, right_on, suffixes}
        primary_col_names:  result of [c[0] for c in describe_columns(primary)]
        secondary_col_names: ditto for secondary

    Behaviour:
        - Right_on key columns are DROPPED from the result (they're equal to
          left_on values after the join)
        - Columns appearing in BOTH sides (and not part of right_on) get
          suffixed with suffixes[0] / suffixes[1] for disambiguation
        - CROSS JOIN has no ON clause
    """
    how, left_on, right_on, suffixes = normalise_join_config(join_config)

    # 2026-08-20 — an EMPTY column list here can only mean describe_columns
    # FAILED (its ``except -> return []``): every parquet file has at least
    # one column (empty results carry the BF-121 ``__empty__`` placeholder).
    # Emitting the join anyway silently projected ONLY the surviving side —
    # the user asked for columns from both sides and got one, with a success
    # status.  Refuse instead; the caller's error path is the honest outcome.
    if not primary_col_names or not secondary_col_names:
        _missing = ("primary" if not primary_col_names else "secondary")
        raise ValueError(
            f"build_join_combine_sql: {_missing} side has no column list — "
            f"describe_columns failed for its parquet "
            f"({primary_parquet if _missing == 'primary' else secondary_parquet!r}). "
            f"Refusing to emit a JOIN that would silently drop every "
            f"{_missing}-side column from the result."
        )

    p_esc = _esc_path(primary_parquet)
    s_esc = _esc_path(secondary_parquet)
    o_esc = _esc_path(output_parquet)

    # ON clause (skip for CROSS)
    on_clause = ""
    if how != "CROSS" and left_on and right_on:
        on_clause = _on_clause(left_on, right_on, key_cast_varchar)

    # Column overlap → suffix disambiguation
    a_cols = list(primary_col_names)
    b_cols = list(secondary_col_names)
    a_set = set(a_cols)
    right_key_set = set(right_on) if right_on else set()
    overlap = (a_set & set(b_cols)) - right_key_set

    # 2026-10-04 -- the right key is DROPPED, so on a RIGHT / FULL join the
    # surviving left key column must carry the value of a row that exists
    # only on the right: ``b.key`` for RIGHT, ``COALESCE(a.key, b.key)`` for
    # FULL.  Before this an unmatched right row came back with a NULL key --
    # the one column a join result is read by.
    key_fill: Dict[str, str] = {}
    if how in ("RIGHT", "FULL"):
        _casts = list(key_cast_varchar or [])
        for i, (lk, rk) in enumerate(zip(left_on, right_on)):
            a_ref = f'a."{_esc_ident(lk)}"'
            b_ref = f'b."{_esc_ident(rk)}"'
            if i < len(_casts) and _casts[i]:
                a_ref = f"CAST({a_ref} AS VARCHAR)"
                b_ref = f"CAST({b_ref} AS VARCHAR)"
            key_fill[lk] = (b_ref if how == "RIGHT"
                            else f"COALESCE({a_ref}, {b_ref})")

    select_parts: List[str] = []
    for col in a_cols:
        c_esc = _esc_ident(col)
        if col in key_fill:
            alias = f"{c_esc}{suffixes[0]}" if col in overlap else c_esc
            select_parts.append(f'{key_fill[col]} AS "{alias}"')
        elif col in overlap:
            select_parts.append(f'a."{c_esc}" AS "{c_esc}{suffixes[0]}"')
        else:
            select_parts.append(f'a."{c_esc}"')
    for col in b_cols:
        c_esc = _esc_ident(col)
        if col in right_key_set:
            continue   # right key dropped — equals left
        if col in overlap:
            select_parts.append(f'b."{c_esc}" AS "{c_esc}{suffixes[1]}"')
        else:
            select_parts.append(f'b."{c_esc}"')

    select_clause = ", ".join(select_parts) if select_parts else "*"
    on_part = f" ON {on_clause}" if on_clause else ""
    # See build_union_combine_sql: bound the OUTPUT, never the inputs.
    limit_clause = (f" LIMIT {int(limit)}"
                    if limit is not None and int(limit) > 0 else "")

    select = (
        f"SELECT {select_clause} "
        f"FROM read_parquet('{p_esc}') a "
        f"{how} JOIN read_parquet('{s_esc}') b"
        f"{on_part}{limit_clause}"
    )
    if select_only:
        return select
    return f"COPY ({select}) TO '{o_esc}' (FORMAT PARQUET, COMPRESSION ZSTD)"


# ═══════════════════════════════════════════════════════════════════════════
# pandas-``merge``-SHAPED join  (2026-08-11 — federation row-cap removal)
# ═══════════════════════════════════════════════════════════════════════════
#
# WHY A SECOND JOIN BUILDER RATHER THAN REUSING build_join_combine_sql
# --------------------------------------------------------------------
# ``FederationEngine.execute_merged_query`` merged its two sides with
# ``pd.merge(df_p, df_s, how=…, left_on=…, right_on=…, suffixes=("", "_merged"))``.
# pandas cannot spill, so the merged frame had to fit in the API pod — which
# is what made ``federation.max_result_rows`` a memory ceiling.  Routing the
# merge through DuckDB removes the ceiling (DuckDB spills to
# ``temp_directory``; see core/duckdb_factory.py).
#
# But ``build_join_combine_sql`` produces a DIFFERENT RESULT SHAPE from
# pandas, and the shape is load-bearing — the report viewer, the microcube
# and every saved layout address columns BY NAME:
#
#     build_join_combine_sql   DROPS right_on columns, suffixes overlaps
#                              ``_primary`` / ``_secondary``
#     pd.merge(suffixes=…)     KEEPS right_on columns, suffixes overlaps
#                              ``""`` (left unchanged) / ``"_merged"``
#
# Swapping one for the other would silently rename and delete columns in
# every existing merged report.  So this builder reproduces pandas' shape
# EXACTLY and only the execution engine changes.
_ROW_ORDINAL = "file_row_number"

# pandas ``how`` -> SQL join keyword.
_PANDAS_HOW_TO_SQL = {
    "inner": "INNER",
    "left":  "LEFT",
    "right": "RIGHT",
    "full":  "FULL OUTER",
    "cross": "CROSS",
}


def pandas_merge_output_columns(
    primary_col_names:   Sequence[str],
    secondary_col_names: Sequence[str],
    suffixes: Tuple[str, str] = ("", "_merged"),
) -> List[str]:
    """The column names ``pd.merge`` would produce, in pandas' order.

    Left columns first (in their own order), then right columns.  A name
    present on BOTH sides is suffixed on both sides — with the default
    ``("", "_merged")`` that means the left keeps its name and the right
    becomes ``<name>_merged``.  ``right_on`` columns are KEPT (pandas keeps
    them); that is the difference from :func:`build_join_combine_sql`.
    """
    overlap = set(primary_col_names) & set(secondary_col_names)
    out = [f"{c}{suffixes[0]}" if c in overlap else c for c in primary_col_names]
    out += [f"{c}{suffixes[1]}" if c in overlap else c for c in secondary_col_names]
    return out


def build_pandas_merge_select_sql(
    primary_parquet:   str,
    secondary_parquet: str,
    *,
    how: str,
    left_on:  Sequence[str],
    right_on: Sequence[str],
    primary_col_names:   Sequence[str],
    secondary_col_names: Sequence[str],
    suffixes: Tuple[str, str] = ("", "_merged"),
    limit: Optional[int] = None,
    preserve_order: Optional[bool] = None,
    key_cast_varchar: Optional[Sequence[bool]] = None,
    coalesce_equal_keys: bool = False,
) -> str:
    """A DuckDB SELECT that returns exactly what ``pd.merge`` would return.

    ``coalesce_equal_keys`` (2026-10-04) -- pandas emits ONE column for a
    key pair whose two names are equal (``left_on=["id"], right_on=["id"]``
    gives ``id``, not ``id`` + ``id_merged``), filled from whichever side
    the join keeps (COALESCE for an outer join).  The SQL-page cross-source
    join was a ``pd.merge`` and its saved results address that single
    column, so its DuckDB replacement asks for it.  The merged-dataset
    report keeps the default (False): its shape since 2026-08-11 has been
    the un-coalesced one and saved layouts address it.

    ``key_cast_varchar`` -- see :func:`build_join_combine_sql`.

    Returns a SELECT (not a ``COPY``) so the caller can stream the result
    through ``core.federation_stream.duckdb_result_to_parquet`` at O(one
    batch) and read ``total_rows`` / ``columns`` straight back.

    ROW ORDER — and why it is tied to ``limit``.  ``pd.merge`` preserves the
    order of the side the join preserves (left for inner/left/cross, right
    for right).  DuckDB does not: ``core/duckdb_factory`` even pins
    ``preserve_insertion_order=false``.  Each side can be read with
    ``file_row_number=true`` — its position inside its own single-file
    parquet IS the pandas row index — and the result ordered by that ordinal
    (never projected).  But ORDER BY is a BLOCKING operator, and a blocking
    operator feeding an Arrow *streaming* reader pins the whole sorted result:

        MEASURED, 2.4M x 2.4M inner join, memory_limit=256MB, spill enabled
          no ORDER BY ................ 2,400,000 rows, 282.9 MB peak RSS
          ORDER BY, no LIMIT ......... FAILS: "Out of Memory Error: failed to
                                       pin block of size 256.0 KiB"
          ORDER BY + LIMIT 1000 ...... 1,000 rows, 281.0 MB peak RSS
                                       (DuckDB turns it into a bounded Top-N)
          pandas equivalent .......... 2,400,000 rows, 792.9 MB peak RSS

    So ``preserve_order`` DEFAULTS TO AUTO (``None``): order iff a positive
    ``limit`` is set.  That is exactly when order is a correctness property —
    an unordered LIMIT changes WHICH rows survive.  When the whole result is
    delivered, the multiset is complete either way and sequence is not part
    of the contract (the engine has no ORDER BY of its own to honour), so the
    result streams unordered and stays bounded.  Forcing ``True`` without a
    limit is legal but will hold the result in memory — do not do it on a
    path that must scale.

    ``outer`` is the one join type whose order is NOT reproduced even when
    ordering: pandas sorts an outer merge by the join KEY, which is not
    expressible here without also reproducing pandas' cross-type collation.
    Outer gets a deterministic left-then-right ordinal order instead — same
    rows, same columns, different sequence.  Callers that apply a LIMIT to an
    ``outer`` merge must disclose unstable truncation (the federation engine
    does).

    A source that already has a ``file_row_number`` column also drops the
    ORDER BY: the multiset of rows is unchanged, only the sequence becomes
    arbitrary, and that beats clobbering the user's own column.
    """
    # ONE vocabulary (2026-10-04): ``outer`` and ``full`` are the same join.
    # DatasetMergeRequest validates ``full`` while this map only knew
    # ``outer``, so a FULL merge was accepted by the route and refused here.
    how_l = normalise_join_how(how)
    sql_how = _PANDAS_HOW_TO_SQL[how_l]

    left_on = list(left_on or [])
    right_on = list(right_on or [])
    if how_l != "cross":
        if not left_on or not right_on:
            raise ValueError(
                f"merge_type '{how_l}' needs merge keys on both sides "
                f"(left_on={left_on!r}, right_on={right_on!r})")
        if len(left_on) != len(right_on):
            raise ValueError(
                f"left_on ({len(left_on)}) and right_on ({len(right_on)}) "
                f"must have the same length")

    p_names = list(primary_col_names)
    s_names = list(secondary_col_names)

    # 2026-08-20 — same refusal as build_join_combine_sql: an empty column
    # list means schema introspection failed on that side (parquet always
    # has ≥1 column).  Emitting the merge would silently drop that side's
    # columns from every saved report addressing them by name.
    if not p_names or not s_names:
        _missing = "primary" if not p_names else "secondary"
        raise ValueError(
            f"build_pandas_merge_select_sql: {_missing} side has no column "
            f"list (schema introspection failed). Refusing to emit a merge "
            f"that would silently drop every {_missing}-side column."
        )

    has_limit = limit is not None and int(limit) > 0
    want_order = has_limit if preserve_order is None else bool(preserve_order)
    # A source that already carries a column called ``file_row_number``
    # would collide with the reader-injected ordinal.  Rather than guess a
    # free name, drop the ordering: fewer guarantees, never a wrong result.
    can_order = want_order and (
        _ROW_ORDINAL not in p_names and _ROW_ORDINAL not in s_names)

    _fr = ", file_row_number=true" if can_order else ""
    a_src = f"read_parquet('{_esc_path(primary_parquet)}'{_fr})"
    b_src = f"read_parquet('{_esc_path(secondary_parquet)}'{_fr})"

    # Same-named key pairs pandas folds into ONE column (see the docstring).
    casts = list(key_cast_varchar or [])
    coalesced: Dict[str, int] = {}
    if coalesce_equal_keys and how_l != "cross":
        for i, (lk, rk) in enumerate(zip(left_on, right_on)):
            if lk == rk:
                coalesced[lk] = i
    overlap = (set(p_names) & set(s_names)) - set(coalesced)
    select_parts: List[str] = []
    for col in p_names:
        c = _esc_ident(col)
        if col in coalesced:
            cast = (coalesced[col] < len(casts) and casts[coalesced[col]])
            a_ref, b_ref = f'a."{c}"', f'b."{c}"'
            if cast:
                a_ref = f"CAST({a_ref} AS VARCHAR)"
                b_ref = f"CAST({b_ref} AS VARCHAR)"
            expr = {"right": b_ref, "full": f"COALESCE({a_ref}, {b_ref})"
                    }.get(how_l, a_ref)
            select_parts.append(f'{expr} AS "{c}"')
            continue
        alias = f"{col}{suffixes[0]}" if col in overlap else col
        if alias != col:
            select_parts.append(f'a."{c}" AS "{_esc_ident(alias)}"')
        else:
            select_parts.append(f'a."{c}"')
    for col in s_names:
        if col in coalesced:
            continue
        c = _esc_ident(col)
        alias = f"{col}{suffixes[1]}" if col in overlap else col
        if alias != col:
            select_parts.append(f'b."{c}" AS "{_esc_ident(alias)}"')
        else:
            select_parts.append(f'b."{c}"')
    select_clause = ", ".join(select_parts) if select_parts else "*"

    on_part = ""
    if how_l != "cross":
        on_part = " ON " + _on_clause(left_on, right_on, casts)

    order_part = ""
    if can_order:
        if how_l == "right":
            order_part = (f' ORDER BY b."{_ROW_ORDINAL}" NULLS LAST, '
                          f'a."{_ROW_ORDINAL}" NULLS LAST')
        else:
            order_part = (f' ORDER BY a."{_ROW_ORDINAL}" NULLS LAST, '
                          f'b."{_ROW_ORDINAL}" NULLS LAST')

    limit_part = f" LIMIT {int(limit)}" if has_limit else ""

    return (
        f"SELECT {select_clause} "
        f"FROM {a_src} a "
        f"{sql_how} JOIN {b_src} b"
        f"{on_part}{order_part}{limit_part}"
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Zero-copy UNION combine (2026-08-22, design_starburst_140m §4.3 step 3)
# ═══════════════════════════════════════════════════════════════════════════════


class UnionSchemaError(ValueError):
    """The two sides' schemas cannot be unified for a zero-copy manifest
    union.  The caller falls back to the DuckDB combine — DECLARED, never
    silent."""


def _side_entries(path: str):
    """[(abs_file, rows, bytes, columns_or_None)] + side schema for a
    single parquet file OR a parts directory.

    Everything is read/validated HERE, before any file is moved — the
    move phase below must be the only mutating step, so a refusal leaves
    both sides exactly where they were.
    """
    import os
    import pyarrow.parquet as pq
    from core.feed.parts_manifest import (
        load_manifest, is_parts_dir, verify_local_parts,
    )

    if os.path.isfile(path):
        pf = pq.ParquetFile(path)
        try:
            rows = pf.metadata.num_rows
            schema = pf.schema_arrow
        finally:
            pf.close()
        return [(path, rows, os.path.getsize(path), None)], schema

    if not is_parts_dir(path):
        raise UnionSchemaError(f"{path} is neither a parquet file nor a "
                               f"parts directory")
    manifest, _src = load_manifest(path)          # COMPLETE manifests only
    verify_local_parts(path, manifest)            # truth check before reuse
    schema = manifest.arrow_schema()
    entries = []
    for p in manifest.parts:
        entries.append((os.path.join(path, p.name), p.rows, p.bytes,
                        p.columns))
    return entries, schema


def build_union_parts_manifest(primary_path: str, secondary_path: str,
                               out_dir: str):
    """Combine a UNION's two materialised sides into ONE parts manifest
    WITHOUT copying a byte of data: the side files become the parts, the
    unified by-name schema lives in the manifest, and readers pad/cast
    each batch at read time (core.feed.parts_manifest reader).

    Semantics mirror ``build_union_combine_sql``: alignment BY NAME,
    ``__empty__`` placeholder columns excluded (unless nothing else
    exists).  Type promotion follows ``pa.unify_schemas`` permissive
    promotion; an impossible promotion raises :class:`UnionSchemaError`
    and the caller falls back to the DuckDB combine.

    All validation happens BEFORE the first move; moves are same-
    filesystem ``os.replace`` and are rolled back if one fails.
    Returns the written :class:`~core.feed.parts_manifest.PartsManifest`.
    """
    import os
    import uuid as _uuid
    import base64 as _b64
    import pyarrow as pa
    from core.feed.parts_manifest import PartInfo, PartsManifest

    a_entries, a_schema = _side_entries(primary_path)
    b_entries, b_schema = _side_entries(secondary_path)

    # 2026-10-10 -- THE merge plan gates this path too.  An incompatible
    # same-named column REFUSES (MergeRefused propagates: the DuckDB fallback
    # would refuse the same way, and a refusal must not be retried as a
    # fallback).  A plan that needs a PROJECTION -- a case-only rename
    # (Trino's ``tran_currency_name`` under Oracle's ``TRAN_CURRENCY_NAME``:
    # pyarrow unifies names case-SENSITIVELY and would produce two columns),
    # a within-family promotion, a dropped placeholder -- is not zero-copy
    # material: the manifest reader pads by exact name, so the DuckDB
    # combine (which renders the plan's SELECT lists) runs instead.  Only a
    # column set that is identical, or differs by MISSING columns alone, is
    # stacked without a copy.
    #
    # 2026-10-13 -- a CASE-ONLY rename is stacked too: the secondary's
    # parts carry ``renames`` ({its spelling: the primary's}) and the
    # manifest reader renames each batch before it pads.  Found live: the
    # owner's 1M-row month end (the S3 engine spells ``snap_version``,
    # Starburst ``SNAP_VERSION``) fell back to the DuckDB combine, whose
    # parquet writer holds ~256 KB per column per thread -- 460 columns
    # did not fit the scheduler's 488 MB and the run failed.
    from core.feed.merge_by_name import MergeRefused, plan_merge as _plan_merge
    try:
        _plan = _plan_merge([(f.name, str(f.type)) for f in a_schema],
                            [(f.name, str(f.type)) for f in b_schema])
    except MergeRefused as exc:
        # The engine's pre-combine gate has already refused this; reached
        # directly, the refusal keeps this function's contract (a
        # UnionSchemaError leaves both sides where they were) and the
        # DuckDB combine refuses with the same words.
        raise UnionSchemaError(str(exc)) from exc
    b_renames = {sname: pname for pname, sname in _plan.renames}
    if b_renames:
        b_schema = pa.schema([f.with_name(b_renames.get(f.name, f.name))
                              for f in b_schema])

    try:
        try:
            unified = pa.unify_schemas([a_schema, b_schema],
                                       promote_options="permissive")
        except TypeError:
            unified = pa.unify_schemas([a_schema, b_schema])
    except Exception as exc:
        raise UnionSchemaError(
            f"schemas do not unify by name ({exc}) — e.g. the same column "
            f"with unpromotable types on the two sides") from exc

    # BF-121 __empty__ exclusion, at manifest level.
    real_fields = [f for f in unified if f.name != "__empty__"]
    if real_fields:
        unified = pa.schema(real_fields)
    unified_cols = [f.name for f in unified]

    def _part_columns(entry_cols, side_schema):
        cols = entry_cols if entry_cols is not None else \
            [f.name for f in side_schema]
        cols = [c for c in cols if c in set(unified_cols)]
        return None if cols == unified_cols else cols

    os.makedirs(out_dir, exist_ok=True)
    moved = []            # [(src, dst)] for rollback
    parts = []
    idx = 0
    try:
        for entries, side_schema, ren in ((a_entries, a_schema, None),
                                          (b_entries, b_schema, b_renames or None)):
            for src, rows, size, entry_cols in entries:
                if ren and entry_cols is not None:
                    entry_cols = [ren.get(c, c) for c in entry_cols]
                dst_name = f"part-{idx:05d}.parquet"
                dst = os.path.join(out_dir, dst_name)
                os.replace(src, dst)
                moved.append((src, dst))
                parts.append(PartInfo(
                    index=idx, name=dst_name, rows=int(rows),
                    bytes=int(size), location="local",
                    columns=_part_columns(entry_cols, side_schema),
                    renames=dict(ren) if ren else None,
                ))
                idx += 1
    except OSError:
        # Roll back so the DuckDB fallback still has both sides intact.
        for src, dst in reversed(moved):
            try:
                os.replace(dst, src)
            except OSError as rb_exc:
                logger.error(
                    "[cross-union] ROLLBACK FAILED moving %s back to %s: %s "
                    "— side files may be split across two directories",
                    dst, src, rb_exc)
        raise

    manifest = PartsManifest(
        parts=parts,
        schema_b64=_b64.b64encode(unified.serialize().to_pybytes())
                       .decode("ascii"),
        total_rows=sum(p.rows for p in parts),
        total_bytes=sum(p.bytes for p in parts),
        status="complete",
        sql_sha256="",
        build_id=f"union:{_uuid.uuid4().hex[:12]}",
        source={"rung": "cross_union_zero_copy",
                "primary": os.path.basename(primary_path),
                "secondary": os.path.basename(secondary_path)},
    )
    manifest.completed_at = manifest.created_at
    manifest.write(out_dir, partial=False)

    # The side PARTS DIRS (if any) are now empty shells — remove them.
    import shutil as _sh
    for side in (primary_path, secondary_path):
        if os.path.isdir(side):
            _sh.rmtree(side, ignore_errors=True)
    return manifest


# ═══════════════════════════════════════════════════════════════════════════════
# THE ONE CROSS-SOURCE CAPABILITY (2026-10-04)
# ═══════════════════════════════════════════════════════════════════════════════
#
# Measured live: the query builder dropped a secondary whenever the PRIMARY was
# a SQL connector (X1/X2: 200, primary-only rows); a federation view refused
# every connection but s3/local (X4); the SQL page joined in pandas and had no
# UNION at all (X3); a merged-dataset report capped each SIDE at the report
# limit, so the join ran over a sample (X5); a feed was right (X6).  Four
# engines, four answers to "how are two sources combined", each with its own
# gaps.  This section is the one answer; every surface routes through it:
#
#   combine_spec()          ONE vocabulary: mode join|union, how inner|left|
#                           right|full|cross ("outer" == "full"), multi-key,
#                           suffixes, result shape.  Refuses, naming why.
#   run_side_to_parquet()   ONE side runner: a SQL connector side streams
#                           through ITS connector (pooled; Trino, Starburst,
#                           Snowflake, Oracle, Databricks, Athena), a storage
#                           side through the registered-tables-as-DuckDB-views
#                           road custom-SQL datasets run, a local side through
#                           DuckDB views over the base path.  Bounded memory:
#                           cursor -> parquet, never a frame.
#   combine_sides()         ONE combine: DuckDB over the two parquet sides,
#                           spilling; the result cap uses an overflow SENTINEL
#                           (fetch limit+1) so ``truncated`` means "there was
#                           more", never "the count happened to equal the cap".
#   execute_cross_source()  the orchestration: refuse unsupported sides before
#                           any work, semi-join key pushdown when it is sound,
#                           both sides in parallel otherwise, never a one-sided
#                           answer (either side failing fails the whole).
#
# ROW SECURITY is the CALLER's: a side's SQL arrives FINAL and SECURED in that
# side's own dialect (each surface already owns that rewrite and its
# principal).  This module never runs a side's SQL anywhere but on that side's
# own engine, so a policy applied by the caller is the policy that runs.
#
# ROW LIMITS, one rule for every surface:
#   * ``row_limit`` bounds the COMBINED result.  None / 0 / negative =
#     UNLIMITED.  A cut is DISCLOSED (``truncated=True``) only when a row past
#     the cap existed.
#   * ``side_row_cap`` (optional, default unlimited) bounds each SIDE.  A side
#     cut changes the combine's answer invisibly, so a side that hit it is
#     DISCLOSED per side (``primary_truncated`` / ``secondary_truncated``) with
#     the same sentinel rule, and the result is marked truncated too.

import os as _os
import threading as _threading
from dataclasses import dataclass, field
from typing import Callable


class CrossSourceRefusal(ValueError):
    """A cross-source request that cannot be executed WHOLE.

    A ``ValueError`` so every route's refusal branch answers it as a 4xx
    naming the reason -- an unsupported side type, an unknown join type, a
    join with no keys.  Distinct so callers can tell "this request is wrong"
    from "a source was down".
    """


COMBINE_MODES = ("join", "union")

#: Result shapes.  ``combine`` -- right join keys DROPPED, overlapping names
#: suffixed ``_primary`` / ``_secondary`` (the query builder, feeds, federation
#: views, .sql-file reports).  ``merge`` -- pandas ``merge`` shape: right keys
#: KEPT, overlaps suffixed with the caller's suffixes (merged-dataset reports,
#: the SQL page).  Both are declared by the caller; neither is inferred.
SHAPE_COMBINE = "combine"
SHAPE_MERGE = "merge"

_HOW_ALIASES = {
    "inner": "inner", "inner join": "inner",
    "left": "left", "left outer": "left", "left join": "left",
    "left outer join": "left",
    "right": "right", "right outer": "right", "right join": "right",
    "right outer join": "right",
    "full": "full", "outer": "full", "full outer": "full",
    "fullouter": "full", "full join": "full", "full outer join": "full",
    "outer join": "full",
    "cross": "cross", "cross join": "cross",
}


def normalise_join_how(how: Any) -> str:
    """THE join-type vocabulary: ``inner|left|right|full|cross``.

    ``outer``, ``FULL OUTER``, ``full_outer`` and ``full outer join`` are all
    ``full``.  Before this one reader existed the query builder's menu sent
    ``outer`` (refused by the combine gate), a dataset merge validated
    ``full`` (refused by the merge builder), and a federation view accepted
    only ``full`` -- one join, three spellings, three different refusals.
    """
    key = re.sub(r"[\s_\-]+", " ", str(how if how is not None else "inner")
                 ).strip().lower() or "inner"
    out = _HOW_ALIASES.get(key)
    if out is None:
        raise CrossSourceRefusal(
            f"Invalid join type {how!r} -- one of inner, left, right, "
            f"full (also spelled 'outer'), cross")
    return out


def _as_key_list(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, str):
        return [v] if v.strip() else []
    return [str(x) for x in v if x is not None and str(x).strip()]


@dataclass(frozen=True)
class CombineSpec:
    """How two sides combine, in the one vocabulary (see :func:`combine_spec`)."""
    mode: str
    how: str = "inner"
    left_on: Tuple[str, ...] = ()
    right_on: Tuple[str, ...] = ()
    suffixes: Tuple[str, str] = ("_primary", "_secondary")
    shape: str = SHAPE_COMBINE
    coalesce_equal_keys: bool = False

    def to_join_config(self) -> Dict[str, Any]:
        return {"how": self.how, "left_on": list(self.left_on),
                "right_on": list(self.right_on),
                "suffixes": list(self.suffixes)}


def combine_spec(
    combine_mode: Optional[str] = None,
    join_config: Optional[Dict[str, Any]] = None,
    *,
    join_on: Optional[Sequence[Dict[str, Any]]] = None,
    join_how: Optional[str] = None,
    default_mode: Optional[str] = None,
    shape: str = SHAPE_COMBINE,
    default_suffixes: Optional[Tuple[str, str]] = None,
    coalesce_equal_keys: bool = False,
) -> CombineSpec:
    """Build the ONE combine description from any surface's spelling.

    * ``combine_mode`` -- ``join`` / ``union``.  Blank uses ``default_mode``
      (each surface states its own historical default: the SQL page joins,
      a feed unions); with neither, a request carrying join keys is a join
      and one without is a union.
    * keys -- ``join_config.left_on/right_on`` (str or list, the query
      builder / feed / SQL page spelling) or ``join_on=[{"left","right"}]``
      (federation views and dataset merges).
    * ``how`` -- ``join_config.how`` or ``join_how``, through
      :func:`normalise_join_how`.

    Raises :class:`CrossSourceRefusal` naming the problem; a join without
    keys (other than CROSS) is refused here, before either side runs.
    """
    jc = dict(join_config or {})
    mode = (combine_mode or "").strip().lower()
    if not mode:
        mode = (default_mode or "").strip().lower()
    left_on = _as_key_list(jc.get("left_on"))
    right_on = _as_key_list(jc.get("right_on"))
    for pair in (join_on or []):
        if not isinstance(pair, dict):
            continue
        left_on.append(str(pair.get("left") or "").strip())
        right_on.append(str(pair.get("right") or "").strip())
    if not mode:
        mode = "join" if (left_on or right_on) else "union"
    if mode not in COMBINE_MODES:
        raise CrossSourceRefusal(
            f"Invalid combine_mode {combine_mode!r} -- one of "
            f"{list(COMBINE_MODES)}")
    if shape not in (SHAPE_COMBINE, SHAPE_MERGE):
        raise CrossSourceRefusal(f"Unknown result shape {shape!r}")

    if default_suffixes is None:
        default_suffixes = (("_primary", "_secondary") if shape == SHAPE_COMBINE
                            else ("", "_merged"))
    if mode == "union":
        return CombineSpec(mode="union", shape=shape,
                           suffixes=tuple(default_suffixes))

    how = normalise_join_how(jc.get("how") or join_how or "inner")
    if how != "cross":
        if not left_on or not right_on or "" in left_on or "" in right_on:
            raise CrossSourceRefusal(
                "A cross-source JOIN needs key columns on both sides "
                "(join_config left_on/right_on, or join_on "
                "[{left, right}]); none were given.")
        if len(left_on) != len(right_on):
            raise CrossSourceRefusal(
                f"left_on ({len(left_on)}) and right_on ({len(right_on)}) "
                f"must name the same number of key columns")
    else:
        left_on, right_on = [], []

    raw_sfx = jc.get("suffixes")
    sfx: Tuple[str, str] = tuple(default_suffixes)  # type: ignore[assignment]
    if isinstance(raw_sfx, (list, tuple)) and len(raw_sfx) >= 2:
        cand = [str(x if x is not None else "") for x in raw_sfx[:2]]
        ok = all(c == "" or _SUFFIX_RE.fullmatch(c) for c in cand)
        # The combine shape suffixes BOTH sides of an overlap, so an empty
        # suffix there would emit two columns with one name.
        if shape == SHAPE_COMBINE and ("" in cand):
            ok = False
        if ok and cand[0] != cand[1]:
            sfx = (cand[0], cand[1])
    return CombineSpec(mode="join", how=how, left_on=tuple(left_on),
                       right_on=tuple(right_on), suffixes=sfx, shape=shape,
                       coalesce_equal_keys=bool(coalesce_equal_keys))


def saved_sql_query_spec(combine_mode: Optional[str],
                         join_config: Optional[Dict[str, Any]], *,
                         hybrid: bool = False) -> CombineSpec:
    """The spec of a SQL-page saved query (``sql_saved_queries``), decided
    ONCE for the three places that run one: the SQL page, a scheduled
    ``sql_query`` job and a raw-SQL business report.

    Blank ``combine_mode`` is a JOIN (the only mode the page had), in the
    pandas ``merge`` shape those runs always produced -- ``_a`` / ``_b``
    suffixes (``_sql`` / ``_parquet`` for a report's SQL-x-file hybrid),
    same-named keys folded into one column -- so every saved query keeps
    its columns.  ``combine_mode="union"`` stacks the two sides by name.
    """
    return combine_spec(
        combine_mode, join_config or {}, default_mode="join",
        shape=SHAPE_MERGE,
        default_suffixes=(("_sql", "_parquet") if hybrid else ("_a", "_b")),
        coalesce_equal_keys=True)


def resolve_row_limit(limit: Any) -> Optional[int]:
    """THE row-limit rule: None, 0 or negative = UNLIMITED (``None``)."""
    if limit is None:
        return None
    try:
        n = int(limit)
    except (TypeError, ValueError):
        raise CrossSourceRefusal(f"row limit {limit!r} is not an integer")
    return n if n > 0 else None


# ── key-type harmonisation ────────────────────────────────────────────────

_STRING_TYPE_PREFIXES = ("VARCHAR", "STRING", "TEXT", "CHAR", "BPCHAR", "UUID",
                         "NVARCHAR", "ENUM")


def _type_family(t: Any) -> str:
    s = str(t or "").strip().upper()
    if not s:
        return "unknown"
    if s.startswith(_STRING_TYPE_PREFIXES):
        return "string"
    if s.startswith(("TINYINT", "SMALLINT", "INT", "BIGINT", "HUGEINT",
                     "UTINYINT", "USMALLINT", "UINT", "UBIGINT", "UHUGEINT",
                     "DECIMAL", "NUMERIC", "DOUBLE", "FLOAT", "REAL")):
        return "number"
    if s.startswith(("DATE", "TIME", "TIMESTAMP", "INTERVAL")):
        return "temporal"
    if s.startswith("BOOL"):
        return "bool"
    return "other"


def join_key_casts(primary_cols: Sequence[Tuple[str, Any]],
                   secondary_cols: Sequence[Tuple[str, Any]],
                   left_on: Sequence[str], right_on: Sequence[str]
                   ) -> Tuple[List[bool], List[str]]:
    """Per key pair: compare as text?  And a disclosure line for each that is.

    DuckDB will not compare a VARCHAR column with a non-VARCHAR one, and two
    engines routinely disagree on a key's type (Snowflake NUMBER vs a Trino
    VARCHAR code; an EMPTY side the connector chokepoint typed as text).
    When exactly one side is text the pair is compared as text on both sides
    and the decision is disclosed -- never applied silently.  Numeric vs
    numeric (DECIMAL(38,0) vs BIGINT) already compares and is left alone.
    """
    pt = {str(n).lower(): t for n, t in primary_cols}
    st = {str(n).lower(): t for n, t in secondary_cols}
    flags: List[bool] = []
    notes: List[str] = []
    for lk, rk in zip(left_on, right_on):
        fa = _type_family(pt.get(str(lk).lower()))
        fb = _type_family(st.get(str(rk).lower()))
        cast = (fa != fb and "unknown" not in (fa, fb)
                and "string" in (fa, fb))
        flags.append(cast)
        if cast:
            notes.append(f"{lk} ({pt.get(str(lk).lower())}) = {rk} "
                         f"({st.get(str(rk).lower())}): compared as text")
    return flags, notes


# ── results ────────────────────────────────────────────────────────────────

@dataclass
class SideOutcome:
    label: str
    path: str
    rows: int
    truncated: bool = False
    row_cap: Optional[int] = None
    connection_type: str = ""


@dataclass
class CombineOutcome:
    """The combined artifact and EVERYTHING a caller must disclose about it."""
    output_path: str
    total_rows: int
    columns: List[str]
    mode: str
    how: Optional[str] = None
    row_limit: Optional[int] = None
    truncated: bool = False
    type_mismatches: List[str] = field(default_factory=list)
    key_casts: List[str] = field(default_factory=list)
    join_health: str = "ok"
    join_health_detail: Optional[str] = None
    primary_rows: int = 0
    secondary_rows: int = 0
    primary_truncated: bool = False
    secondary_truncated: bool = False
    side_row_cap: Optional[int] = None
    semi_join_pushdown: Optional[str] = None
    primary_type: str = ""
    secondary_type: str = ""
    #: 2026-10-25 -- unaliased expressions renamed to their own text before
    #: the by-name union: ``"<side>: <engine name> -> <tag>"``
    expression_tags: List[str] = field(default_factory=list)

    @property
    def any_truncation(self) -> bool:
        return bool(self.truncated or self.primary_truncated
                    or self.secondary_truncated)

    def disclosure(self) -> Dict[str, Any]:
        """The keys every surface puts on its response / execution record."""
        d: Dict[str, Any] = {
            "combine_mode": self.mode,
            "primary_rows": self.primary_rows,
            "secondary_rows": self.secondary_rows,
            "row_limit": self.row_limit or 0,
            "truncated": self.any_truncation,
            "result_truncated": bool(self.truncated),
            "primary_truncated": bool(self.primary_truncated),
            "secondary_truncated": bool(self.secondary_truncated),
            "side_row_cap": self.side_row_cap or 0,
        }
        if self.how:
            d["join_how"] = self.how
        if self.type_mismatches:
            d["type_mismatches"] = list(self.type_mismatches)
        if self.key_casts:
            d["key_casts"] = list(self.key_casts)
        if self.join_health != "ok":
            d["join_health"] = self.join_health
            if self.join_health_detail:
                d["join_health_detail"] = self.join_health_detail
        if self.semi_join_pushdown:
            d["semi_join_pushdown"] = self.semi_join_pushdown
        if self.primary_type or self.secondary_type:
            d["sources"] = {"primary": self.primary_type,
                            "secondary": self.secondary_type}
        return d


# ── the combine ────────────────────────────────────────────────────────────

def _duck_source(p: str) -> str:
    """A parts DIRECTORY (feed write ladder) reads through a local glob."""
    return p if _os.path.isfile(p) else _os.path.join(p, "part-*.parquet")


def _parquet_rows(path: str) -> int:
    import pyarrow.parquet as _pq
    return int(_pq.read_metadata(path).num_rows)


def _keep_first_rows(src: str, dst: str, n: int) -> None:
    """Copy the first ``n`` rows of ``src`` to ``dst``, in file order,
    streaming batch by batch (bounded memory, row order preserved)."""
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    pf = _pq.ParquetFile(src)
    writer = None
    left = int(n)
    try:
        writer = _pq.ParquetWriter(dst, pf.schema_arrow, compression="zstd")
        if left > 0:
            for batch in pf.iter_batches(batch_size=65_536):
                if left <= 0:
                    break
                if batch.num_rows > left:
                    batch = batch.slice(0, left)
                writer.write_table(_pa.Table.from_batches(
                    [batch], schema=pf.schema_arrow))
                left -= batch.num_rows
    finally:
        if writer is not None:
            writer.close()
        pf.close()


def combine_select_sql(primary_src: str, secondary_src: str, spec: CombineSpec,
                       primary_cols: Sequence[Tuple[str, Any]],
                       secondary_cols: Sequence[Tuple[str, Any]], *,
                       limit: Optional[int] = None
                       ) -> Tuple[str, List[str], List[str]]:
    """THE combine as a DuckDB SELECT -- ``(sql, key_casts, type_mismatches)``.

    :func:`combine_sides` COPYs it to a file; a caller that pages, counts or
    projects the combined result itself (the federation view's preview /
    published-API page) wraps it instead.  Either way it is the same SQL
    from the same builders, so the two cannot disagree about what a combine
    of two sides is.
    """
    for label, cols, src in (("primary", primary_cols, primary_src),
                             ("secondary", secondary_cols, secondary_src)):
        if not cols:
            raise CrossSourceRefusal(
                f"the {label} side's result could not be read "
                f"({src}) -- refusing to combine, because a combine "
                f"with one unreadable side returns the other side "
                f"and calls it the answer")
    if spec.mode == "union":
        # 2026-10-10 -- THE merge plan decides the alignment (and refuses
        # an incompatible same-named column); the SQL builder reads the
        # same plan.  The disclosed "mismatches" are the plan's within-
        # family PROMOTIONS -- everything else was refused.
        from core.feed.merge_by_name import MergeRefused, plan_merge
        try:
            plan = plan_merge(list(primary_cols), list(secondary_cols))
        except MergeRefused as exc:
            raise CrossSourceRefusal(str(exc)) from exc
        return (build_union_combine_sql(
                    primary_src, secondary_src, "", list(primary_cols),
                    list(secondary_cols), limit=limit, select_only=True),
                [], [f"{n}: {p}→{s}" for n, p, s in plan.promotions])
    casts, key_notes = join_key_casts(primary_cols, secondary_cols,
                                      spec.left_on, spec.right_on)
    p_names = [c[0] for c in primary_cols]
    s_names = [c[0] for c in secondary_cols]
    if spec.shape == SHAPE_MERGE:
        sel = build_pandas_merge_select_sql(
            primary_src, secondary_src, how=spec.how,
            left_on=list(spec.left_on), right_on=list(spec.right_on),
            primary_col_names=p_names, secondary_col_names=s_names,
            suffixes=tuple(spec.suffixes), limit=limit,
            key_cast_varchar=casts,
            coalesce_equal_keys=spec.coalesce_equal_keys)
    else:
        sel = build_join_combine_sql(
            primary_src, secondary_src, "", spec.to_join_config(),
            p_names, s_names, limit=limit, key_cast_varchar=casts,
            select_only=True)
    return sel, key_notes, []


def _tag_side(con, src: str, sql: Optional[str], dialect: Optional[str], label: str,
              staging_dir: str, notes: List[str]) -> str:
    """A side whose statement has UNALIASED expressions, renamed to each
    expression's own text (``core/executors/expression_tags.py``) in a staged
    copy; the side as it is otherwise."""
    if not sql:
        return src
    from core.executors.expression_tags import rename_map
    cols = [c for c, _t in describe_columns(con, src)]
    ren = rename_map(sql, dialect, cols)
    if not ren:
        return src
    def _q(name: str) -> str:                       # always quoted: "count(*)" is a name here
        return '"' + str(name).replace('"', '""') + '"'
    sel = ", ".join(f"{_q(c)} AS {_q(ren[c])}" if c in ren else _q(c) for c in cols)
    dst = _os.path.join(staging_dir, f".qs_tagged_{label}_{_os.getpid()}_{id(notes)}.parquet")
    con.execute(f"COPY (SELECT {sel} FROM read_parquet('{_esc_path(src)}')) TO "
                f"'{_esc_path(dst)}' (FORMAT PARQUET, COMPRESSION ZSTD)")
    notes.extend(f"{label}: {c} -> {t}" for c, t in ren.items())
    logger.info("[cross-source] %s side: %d unaliased column(s) named by their expression: %s",
                label, len(ren), ren)
    return dst


def combine_sides(primary_path: str, secondary_path: str, output_path: str,
                  spec: CombineSpec, *, row_limit: Any = None,
                  side_sql: Tuple[Optional[str], Optional[str]] = (None, None),
                  side_dialects: Tuple[Optional[str], Optional[str]] = (None, None),
                  ) -> CombineOutcome:
    """Combine two materialised sides into ``output_path`` in DuckDB.

    THE combine for every surface.  Spills (``core/duckdb_factory`` sets the
    memory limit and temp directory), never loads a side into this process.
    ``row_limit`` bounds the RESULT with an overflow sentinel: DuckDB is asked
    for ``limit + 1`` rows and only a result that produced the extra row is
    cut and marked ``truncated`` -- a result of exactly ``limit`` rows is
    complete and says so.
    """
    from core.duckdb_factory import duckdb_connection

    limit = resolve_row_limit(row_limit)
    p_src, s_src = _duck_source(primary_path), _duck_source(secondary_path)
    staging = (output_path + ".qs_sentinel.parquet") if limit else output_path
    _os.makedirs(_os.path.dirname(_os.path.abspath(output_path)) or ".",
                 exist_ok=True)
    key_notes: List[str] = []
    mismatches: List[str] = []
    tag_notes: List[str] = []
    tagged: List[str] = []
    try:
        with duckdb_connection() as con:
            # 2026-10-25 -- a UNION of statements whose expressions carry no
            # alias: each engine names them its own way (DuckDB count_star(),
            # Trino _col0) and BY-NAME alignment kept both, half of every row
            # empty.  Each side's unaliased column is renamed to its own
            # expression's text, read from that side's statement.
            if spec.mode == "union" and any(side_sql):
                stage_dir = _os.path.dirname(_os.path.abspath(output_path)) or "."
                for i, (label, src) in enumerate((("primary", p_src), ("secondary", s_src))):
                    new = _tag_side(con, src, side_sql[i], side_dialects[i], label, stage_dir, tag_notes)
                    if new != src:
                        tagged.append(new)
                        if i == 0:
                            p_src = new
                        else:
                            s_src = new
            p_cols = describe_columns(con, p_src)
            s_cols = describe_columns(con, s_src)
            q_limit = (limit + 1) if limit else None
            sel, key_notes, mismatches = combine_select_sql(
                p_src, s_src, spec, p_cols, s_cols, limit=q_limit)
            sql = (f"COPY ({sel}) TO '{_esc_path(staging)}' "
                   f"(FORMAT PARQUET, COMPRESSION ZSTD)")
            logger.debug("[cross-source] combine SQL: %s", sql[:600])
            con.execute(sql)

            join_health, jh_detail = "ok", None
            total = _parquet_rows(staging)
            if spec.mode == "join" and total == 0 and spec.how != "cross":
                try:
                    pn = con.execute(
                        f"SELECT COUNT(*) FROM read_parquet('{_esc_path(p_src)}')"
                    ).fetchone()[0]
                    sn = con.execute(
                        f"SELECT COUNT(*) FROM read_parquet('{_esc_path(s_src)}')"
                    ).fetchone()[0]
                    if pn and sn:
                        join_health = "suspicious_empty"
                        # BF-517 -- name the likely causes, so "0 rows" is
                        # an investigation path, not a shrug.
                        jh_detail = (
                            f"JOIN produced 0 rows but primary had {pn:,} and "
                            f"secondary had {sn:,}.  Likely causes: (1) the "
                            f"join column {list(spec.left_on)} / "
                            f"{list(spec.right_on)} does not hold the same "
                            f"values on both sides (case, padding), (2) a "
                            f"type mismatch between the two keys, (3) the "
                            f"WHERE filters on either side narrowed the key "
                            f"sets to disjoint ranges.")
                except Exception as _jh_exc:   # diagnostic only
                    logger.debug("[cross-source] join-health probe skipped: %s",
                                 _jh_exc)

        truncated = False
        if limit and staging != output_path:
            if total > limit:
                _keep_first_rows(staging, output_path, limit)
                truncated, total = True, limit
            else:
                _os.replace(staging, output_path)
        import pyarrow.parquet as _pq
        columns = list(_pq.read_schema(output_path).names)
        return CombineOutcome(
            output_path=output_path, total_rows=int(total), columns=columns,
            mode=spec.mode, how=(spec.how if spec.mode == "join" else None),
            row_limit=limit, truncated=truncated,
            type_mismatches=mismatches, key_casts=key_notes,
            join_health=join_health, join_health_detail=jh_detail,
            expression_tags=tag_notes)
    except BaseException:
        # A partial artifact that later reads as a short result is the silent
        # data loss this codebase keeps paying for.
        for p in {output_path, staging}:
            try:
                _os.unlink(p)
            except OSError:
                pass
        raise
    finally:
        for p in ([staging] if staging != output_path else []) + tagged:
            try:
                _os.unlink(p)
            except OSError:
                pass


# ── sides ──────────────────────────────────────────────────────────────────

STORAGE_SIDE_TYPES = frozenset({"s3"})
LOCAL_SIDE_TYPES = frozenset({"local"})


def connector_side_types() -> frozenset:
    """The SQL-connector types a side can be (the connector registry)."""
    from core.connectors import SQL_CONNECTOR_TYPES
    return frozenset(str(t).lower() for t in SQL_CONNECTOR_TYPES) - {"rest_api"}


def supported_side_types() -> frozenset:
    """Every connection type a cross-source side can read."""
    return connector_side_types() | STORAGE_SIDE_TYPES | LOCAL_SIDE_TYPES


def side_kind(connection_type: Any) -> Optional[str]:
    t = str(connection_type or "").strip().lower()
    if t in connector_side_types():
        return "connector"
    if t in STORAGE_SIDE_TYPES:
        return "storage"
    if t in LOCAL_SIDE_TYPES:
        return "local"
    return None


def refuse_unsupported_side(connection_type: Any, label: str) -> str:
    """The side's kind, or a refusal naming the type and what IS supported."""
    kind = side_kind(connection_type)
    if kind is None:
        raise CrossSourceRefusal(
            f"The {label} side is a {connection_type!r} connection, which a "
            f"cross-source query cannot read. Supported: "
            f"{sorted(supported_side_types())}.")
    return kind


@dataclass
class SideSpec:
    """One side of a cross-source request.

    Exactly one source of rows:
      * ``connection`` + ``sql`` -- the side's FINAL, SECURED statement in its
        own dialect, run on its own engine (:func:`run_side_to_parquet`);
      * ``producer(out_path, fetch_limit, cancel_event) -> rows`` -- a surface
        with richer machinery for that side (the query builder's S3 pruning
        road, a dataset's semantic layer) writes the parquet itself;
      * ``path`` -- an already-materialised parquet (or parts directory).
    """
    label: str
    connection: Optional[Dict[str, Any]] = None
    sql: Optional[str] = None
    producer: Optional[Callable[..., Any]] = None
    path: Optional[str] = None

    @property
    def connection_type(self) -> str:
        return str((self.connection or {}).get("connection_type") or "").lower()


class AnyEvent:
    """``is_set()`` / ``wait()`` true when ANY of the events is set -- the
    caller's cancel plus the peer side's failure."""

    def __init__(self, *events):
        self._events = [e for e in events if e is not None]

    def is_set(self) -> bool:
        return any(e.is_set() for e in self._events)

    def wait(self, timeout: Optional[float] = None) -> bool:
        import time as _t
        deadline = None if timeout is None else _t.monotonic() + timeout
        while True:
            if self.is_set():
                return True
            if deadline is not None and _t.monotonic() >= deadline:
                return False
            _t.sleep(0.05)


def _write_empty_placeholder(path: str) -> None:
    """BF-121: a side with no columns at all becomes the ``__empty__``
    placeholder the union excludes (a zero-column parquet cannot be read)."""
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    _pq.write_table(_pa.table({"__empty__": _pa.array([], type=_pa.int32())}),
                    path, compression="zstd")


def _ensure_readable_side(path: str) -> None:
    import pyarrow.parquet as _pq
    if _os.path.isdir(path):
        return
    if len(_pq.read_schema(path).names) == 0:
        _write_empty_placeholder(path)


def _apply_side_cap(path: str, rows: int, cap: Optional[int]) -> Tuple[int, bool]:
    """Sentinel rule for a side: it was fetched with ``cap + 1``; a side
    holding more than ``cap`` rows is cut back to ``cap`` and DISCLOSED."""
    if not cap or rows <= cap:
        return rows, False
    tmp = path + ".qs_cap.parquet"
    _keep_first_rows(path, tmp, cap)
    _os.replace(tmp, path)
    return cap, True


def _strip_sql(sql: Optional[str]) -> str:
    return str(sql or "").strip().rstrip(";").strip()


def _run_connector_side(conn: Dict[str, Any], sql: str, out_path: str,
                        fetch_limit: Optional[int], cancel_event) -> int:
    from core.connector_to_parquet import execute_sql_to_parquet
    ctype = str(conn.get("connection_type") or "").lower()
    cid = conn.get("id")
    if cid is not None:
        from core.connection_pool import get_pooled_connector
        cm = get_pooled_connector(int(cid), ctype, conn.get("config") or {},
                                  conn.get("name") or "")
    else:
        import contextlib
        from core.connectors import get_connector

        @contextlib.contextmanager
        def _unpooled():
            c = get_connector(ctype, conn.get("config") or {})
            try:
                yield c
            finally:
                try:
                    c.close()
                except Exception as exc:
                    logger.debug("[cross-source] connector close: %s", exc)
        cm = _unpooled()
    connector = cm.__enter__()
    exc_info: Tuple[Any, Any, Any] = (None, None, None)
    try:
        stats = execute_sql_to_parquet(connector, sql, out_path,
                                       row_limit=fetch_limit,
                                       cancel_event=cancel_event)
        return int(stats.get("total_rows", 0))
    except BaseException as exc:
        # Recorded, not sniffed: only an exception escaping THIS call makes
        # the connector suspect, so only then is it discarded, not pooled.
        exc_info = (type(exc), exc, exc.__traceback__)
        raise
    finally:
        try:
            cm.__exit__(*exc_info)
        except Exception as rel_exc:
            logger.debug("[cross-source] connector release: %s", rel_exc)


def _run_storage_side(conn: Dict[str, Any], sql: str, out_path: str,
                      fetch_limit: Optional[int], db_manager,
                      execution_id: str) -> int:
    """An S3 connection's SQL, on the road a custom-SQL dataset over that
    connection runs: registered tables bound as DuckDB views by
    ``FederationEngine._registered_table_views_for_sql`` (manifest
    resolution, presigned URLs, the statement's own WHERE pruning files),
    streamed into ``out_path``."""
    if db_manager is None:
        raise CrossSourceRefusal(
            "a storage (s3) side needs the metadata database to resolve its "
            "registered tables; none was supplied")
    from core.federation_engine import FederationEngine
    fe = FederationEngine(db_manager, output_dir=_os.path.dirname(out_path))
    cid = int(conn["id"])
    connections = {cid: conn}
    body = _strip_sql(sql)
    views = fe._registered_table_views_for_sql(
        body, connections, [], base_query=body) or None
    run_sql = (f"SELECT * FROM ({body}) AS qs_side LIMIT {int(fetch_limit)}"
               if fetch_limit else body)
    stats = fe._execute_duckdb_s3(run_sql, connections,
                                  execution_id or "cross-source-side",
                                  sink_path=out_path, table_views=views)
    if isinstance(stats, dict) and "total_rows" in stats:
        return int(stats.get("total_rows") or 0)
    return _parquet_rows(out_path)


def _run_local_side(conn: Dict[str, Any], sql: str, out_path: str,
                    fetch_limit: Optional[int]) -> int:
    """A local connection's SQL: every parquet file / parquet directory
    directly under its base path is a view named by its stem."""
    from core.duckdb_factory import duckdb_connection
    base = str((conn.get("config") or {}).get("base_path") or "")
    if not base or not _os.path.isdir(base):
        raise CrossSourceRefusal(
            f"local connection {conn.get('id')} has no readable base_path "
            f"({base!r})")
    body = _strip_sql(sql)
    run_sql = (f"SELECT * FROM ({body}) AS qs_side LIMIT {int(fetch_limit)}"
               if fetch_limit else body)
    with duckdb_connection() as con:
        for entry in sorted(_os.listdir(base)):
            full = _os.path.join(base, entry)
            stem = _os.path.splitext(entry)[0]
            if not stem or stem.startswith("."):
                continue
            if _os.path.isfile(full) and entry.lower().endswith(".parquet"):
                src = full.replace("\\", "/")
            elif _os.path.isdir(full):
                src = _os.path.join(full, "**", "*.parquet").replace("\\", "/")
            else:
                continue
            con.execute(
                f'CREATE OR REPLACE VIEW "{_esc_ident(stem)}" AS SELECT * FROM '
                f"read_parquet('{_esc_path(src)}', hive_partitioning=true, "
                f"union_by_name=true)")
        con.execute(f"COPY ({run_sql}) TO '{_esc_path(out_path)}' "
                    f"(FORMAT PARQUET, COMPRESSION ZSTD)")
    return _parquet_rows(out_path)


def run_side_to_parquet(side: SideSpec, out_path: str, *,
                        row_cap: Any = None, cancel_event=None,
                        db_manager=None, execution_id: str = "") -> SideOutcome:
    """Materialise ONE side into ``out_path`` through ITS engine.

    ``row_cap`` -- None/0 = the whole side.  A positive cap fetches
    ``cap + 1`` and a side that produced the extra row is cut and DISCLOSED
    (``truncated=True``); never a silent short side.
    """
    cap = resolve_row_limit(row_cap)
    fetch = (cap + 1) if cap else None
    ctype = side.connection_type
    if side.path:
        if not _os.path.exists(side.path):
            raise CrossSourceRefusal(
                f"the {side.label} side's artifact {side.path} does not exist")
        rows = (_parquet_rows(side.path) if _os.path.isfile(side.path)
                else _parquet_rows_dir(side.path))
        return SideOutcome(side.label, side.path, rows, False, cap, ctype)
    if side.producer is not None:
        produced = side.producer(out_path, fetch, cancel_event)
        if isinstance(produced, str) and produced != out_path:
            out_path = produced
        if not _os.path.exists(out_path):
            raise CrossSourceRefusal(
                f"the {side.label} side produced no artifact at {out_path} -- "
                f"refusing to combine the other side alone")
        _ensure_readable_side(out_path)
        rows = (int(produced) if isinstance(produced, int)
                and not isinstance(produced, bool) else _parquet_rows(out_path))
        rows, cut = _apply_side_cap(out_path, rows, cap)
        return SideOutcome(side.label, out_path, rows, cut, cap, ctype)

    kind = refuse_unsupported_side(ctype, side.label)
    if not _strip_sql(side.sql):
        raise CrossSourceRefusal(
            f"the {side.label} side has no SQL -- a cross-source request "
            f"with nothing on one side would return only the other side's "
            f"rows")
    if kind == "connector":
        rows = _run_connector_side(side.connection or {}, _strip_sql(side.sql),
                                   out_path, fetch, cancel_event)
    elif kind == "storage":
        rows = _run_storage_side(side.connection or {}, side.sql or "",
                                 out_path, fetch, db_manager, execution_id)
    else:
        rows = _run_local_side(side.connection or {}, side.sql or "",
                               out_path, fetch)
    if not _os.path.exists(out_path):
        raise CrossSourceRefusal(
            f"the {side.label} side ({ctype}) produced no artifact -- "
            f"refusing to combine the other side alone")
    _ensure_readable_side(out_path)
    rows, cut = _apply_side_cap(out_path, rows, cap)
    logger.info("[cross-source] %s side (%s): %d rows%s -> %s", side.label,
                ctype, rows, " (CAPPED)" if cut else "", out_path)
    return SideOutcome(side.label, out_path, rows, cut, cap, ctype)


def _parquet_rows_dir(path: str) -> int:
    import glob as _glob
    return sum(_parquet_rows(p)
               for p in _glob.glob(_os.path.join(path, "part-*.parquet")))


def parquet_config_producer(qc: Dict[str, Any], data_dir: str, *,
                            where: str, db=None, request_id: str = ""):
    """A SIDE that is a stored query CONFIG over a local parquet directory
    (a .sql report whose file side is JSON) -- the ``SideSpec.producer``.

    Runs on ``core.local_parquet_road`` (the optimized engine for the plain
    shape, DuckDB beyond it) and STREAMS its chunks into the side parquet;
    a leg that matched nothing keeps its schema (the 2026-08-20 rule), so a
    UNION does not drop its columns and a JOIN still finds its key.  No row
    security on these legs, as before: ``secure=None`` says so.
    """
    def _produce(out_path: str, fetch_limit: Optional[int], cancel_event) -> int:
        from core.local_parquet_road import run_local_parquet, leg_to_dataframe
        from core.connector_to_parquet import df_chunks_to_parquet_streaming
        run = run_local_parquet(dict(qc or {}), data_dir=data_dir, where=where,
                                secure=None, request_id=request_id, db=db)
        n = int(df_chunks_to_parquet_streaming(run.chunks, out_path)
                .get("total_rows", 0))
        if n == 0:
            import pyarrow as _pa
            import pyarrow.parquet as _pq
            empty = leg_to_dataframe(run, data_dir)
            if len(empty.columns):
                _pq.write_table(_pa.Table.from_pandas(empty, preserve_index=False),
                                out_path, compression="zstd")
            else:
                _write_empty_placeholder(out_path)
        return n
    return _produce


# ── semi-join key pushdown ────────────────────────────────────────────────

SEMI_JOIN_MAX_DISTINCT = 10_000
SEMI_JOIN_MAX_KEYS = 8


def _pushdown_literal(v: Any) -> Optional[str]:
    """A key value as a portable SQL literal, or None (= do not push down).

    Only integers and plain strings: a DATE / TIMESTAMP / DECIMAL value's
    literal spelling differs per engine, and a wrong one is a type error at
    best and a constant-false predicate (zero rows) at worst."""
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return str(v)
    if isinstance(v, str):
        if "\\" in v:
            return None
        return "'" + v.replace("'", "''") + "'"
    return None


def semi_join_wrap_sql(sql: str, connection_type: str,
                       key_values: Sequence[Tuple[str, Sequence[Any]]]
                       ) -> Optional[str]:
    """The primary's statement filtered to the secondary's key set, in the
    primary engine's own identifier grammar -- or None when the key set is
    not portably expressible (see :func:`_pushdown_literal`)."""
    from core.sql_filter_wrapper import (
        dialect_for_connection_type, quote_identifier_for_dialect)
    dialect = (dialect_for_connection_type(connection_type)
               if side_kind(connection_type) == "connector" else "duckdb")
    preds = []
    for col, vals in key_values:
        vals = list(vals)
        lits = [_pushdown_literal(v) for v in vals]
        if not lits or any(x is None for x in lits):
            return None
        if len({type(v) for v in vals}) != 1:
            return None
        try:
            ident = quote_identifier_for_dialect(col, dialect)
        except Exception:
            return None
        preds.append(f"{ident} IN ({', '.join(lits)})")
    if not preds:
        return None
    # Alias ``qs_sj``: letter-first (Oracle refuses a leading underscore), no
    # ``AS`` (Oracle refuses AS before a table alias).
    return (f"SELECT * FROM (\n{_strip_sql(sql)}\n) qs_sj\nWHERE "
            + " AND ".join(preds))


def _distinct_keys(path: str, right_on: Sequence[str]
                   ) -> Optional[List[List[Any]]]:
    from core.duckdb_factory import duckdb_connection
    out: List[List[Any]] = []
    with duckdb_connection() as con:
        for rk in right_on:
            rows = con.execute(
                f'SELECT DISTINCT "{_esc_ident(rk)}" FROM '
                f"read_parquet('{_esc_path(_duck_source(path))}') "
                f'WHERE "{_esc_ident(rk)}" IS NOT NULL '
                f"LIMIT {SEMI_JOIN_MAX_DISTINCT + 1}").fetchall()
            if not (0 < len(rows) <= SEMI_JOIN_MAX_DISTINCT):
                return None
            out.append([r[0] for r in rows])
    return out


# ── the orchestration ─────────────────────────────────────────────────────

def execute_cross_source(
    primary: SideSpec,
    secondary: SideSpec,
    spec: CombineSpec,
    output_path: str,
    *,
    row_limit: Any = None,
    side_row_cap: Any = None,
    cancel_event=None,
    progress: Optional[Callable[[Dict[str, Any]], None]] = None,
    db_manager=None,
    execution_id: str = "",
    work_dir: Optional[str] = None,
    semi_join_pushdown: bool = True,
) -> CombineOutcome:
    """Run both sides and combine them -- THE cross-source execution.

    Never returns a one-sided answer: either side failing (or producing no
    artifact) fails the whole call and removes any partial output.  An
    unsupported side type is refused before either side runs.

    Semi-join pushdown (kept from the query builder, BF-536): for an INNER
    or RIGHT join whose primary is a SQL side, the secondary runs first and,
    when its key set is small (<= 10,000 distinct per key) and portable
    (integers / plain strings), the primary statement is filtered to it on
    the primary's own engine.  LEFT / FULL joins never push down (they exist
    to keep unmatched primary rows).  A primary engine that rejects the
    filtered statement runs it unfiltered -- the pushdown is an optimisation,
    never a correctness dependency.
    """
    import shutil
    import tempfile
    import uuid as _uuid
    from concurrent.futures import ThreadPoolExecutor, wait, FIRST_EXCEPTION

    def _emit(step: str, **kw):
        if progress is None:
            return
        try:
            progress({"step": step, "execution_id": execution_id, **kw})
        except Exception as exc:
            logger.debug("[cross-source] progress callback failed: %s", exc)

    for s in (primary, secondary):
        if s.path is None and s.producer is None:
            refuse_unsupported_side(s.connection_type, s.label)

    cap = resolve_row_limit(side_row_cap)
    base = work_dir or _os.path.dirname(_os.path.abspath(output_path)) or None
    if base:
        _os.makedirs(base, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="qs_cross_", dir=base)
    tag = _uuid.uuid4().hex[:8]
    p_out = _os.path.join(tmp, f"primary_{tag}.parquet")
    s_out = _os.path.join(tmp, f"secondary_{tag}.parquet")
    peer = _threading.Event()
    side_cancel = AnyEvent(cancel_event, peer)
    pushdown_note: Optional[str] = None
    ok = False

    def _side(s: SideSpec, out: str) -> SideOutcome:
        try:
            if side_cancel.is_set():
                raise InterruptedError("cross-source execution cancelled")
            return run_side_to_parquet(s, out, row_cap=cap,
                                       cancel_event=side_cancel,
                                       db_manager=db_manager,
                                       execution_id=execution_id)
        except (InterruptedError, CrossSourceRefusal):
            peer.set()
            raise
        except Exception as exc:
            peer.set()
            raise RuntimeError(
                f"Cross-source {s.label} side "
                f"({s.connection_type or 'producer'}) failed "
                f"({type(exc).__name__}): {exc}") from exc

    try:
        _emit("executing", message="Executing both source queries")
        p_res: Optional[SideOutcome] = None
        s_res: Optional[SideOutcome] = None
        can_push = bool(semi_join_pushdown and spec.mode == "join"
                        and spec.how != "cross"
                        and _strip_sql(primary.sql)
                        and primary.connection is not None
                        and primary.producer is None and primary.path is None
                        and 0 < len(spec.left_on) <= SEMI_JOIN_MAX_KEYS)
        if can_push:
            allowed, reason = semi_join_pushdown_allowed(
                spec.to_join_config(), primary_is_raw_sql=True)
            if not allowed:
                pushdown_note = f"skipped: {reason}"
                can_push = False
        if can_push:
            s_res = _side(secondary, s_out)
            wrapped = None
            try:
                keys = _distinct_keys(s_res.path, spec.right_on)
                if keys is not None:
                    wrapped = semi_join_wrap_sql(
                        primary.sql or "", primary.connection_type,
                        list(zip(spec.left_on, keys)))
            except Exception as exc:
                logger.info("[cross-source] semi-join key probe failed: %s", exc)
            if wrapped:
                pushed = SideSpec(primary.label, primary.connection, wrapped)
                try:
                    p_res = _side(pushed, p_out)
                    pushdown_note = (f"applied: primary filtered to the "
                                     f"secondary's {list(spec.right_on)} keys")
                except (InterruptedError, CrossSourceRefusal):
                    raise
                except Exception as exc:
                    logger.warning(
                        "[cross-source] semi-join pushdown rejected by the "
                        "primary engine (%s) -- running it unfiltered", exc)
                    if cancel_event is not None and cancel_event.is_set():
                        raise
                    peer.clear()
                    pushdown_note = "declined by the primary engine"
                    try:
                        _os.unlink(p_out)
                    except OSError:
                        pass
            else:
                pushdown_note = (pushdown_note
                                 or "skipped: key set too large or not portable")
            if p_res is None:
                p_res = _side(primary, p_out)
        else:
            pool = ThreadPoolExecutor(max_workers=2,
                                      thread_name_prefix="qs-cross-side")
            failed = False
            try:
                fp = pool.submit(_side, primary, p_out)
                fs = pool.submit(_side, secondary, s_out)
                done, not_done = wait([fp, fs], return_when=FIRST_EXCEPTION)
                first_err: Optional[BaseException] = None
                for f in (fp, fs):
                    if f in done and f.exception() is not None:
                        e = f.exception()
                        if first_err is None or (
                                isinstance(first_err, InterruptedError)
                                and not isinstance(e, InterruptedError)):
                            first_err = e
                if first_err is not None:
                    failed = True
                    for nd in not_done:
                        try:
                            nd.result(timeout=30)
                        except BaseException:
                            pass
                    raise first_err
                p_res, s_res = fp.result(), fs.result()
            finally:
                pool.shutdown(wait=not failed, cancel_futures=failed)

        if cancel_event is not None and cancel_event.is_set():
            raise InterruptedError("cross-source execution cancelled")
        assert p_res is not None and s_res is not None
        _emit("combining", message=f"Combining via {spec.mode.upper()}",
              primary_rows=p_res.rows, secondary_rows=s_res.rows)
        out = combine_sides(p_res.path, s_res.path, output_path, spec,
                            row_limit=row_limit,
                            side_sql=(primary.sql, secondary.sql))
        out.primary_rows, out.secondary_rows = p_res.rows, s_res.rows
        out.primary_truncated = bool(p_res.truncated)
        out.secondary_truncated = bool(s_res.truncated)
        out.side_row_cap = cap
        out.semi_join_pushdown = pushdown_note
        out.primary_type = primary.connection_type
        out.secondary_type = secondary.connection_type
        ok = True
        _emit("completed", message=f"Combined: {out.total_rows} rows",
              total_rows=out.total_rows, primary_rows=out.primary_rows,
              secondary_rows=out.secondary_rows)
        logger.info(
            "[cross-source] %s %s+%s -> %d rows (primary=%d%s, secondary=%d%s, "
            "result%s)", spec.mode, primary.connection_type or "producer",
            secondary.connection_type or "producer", out.total_rows,
            out.primary_rows, " CAPPED" if out.primary_truncated else "",
            out.secondary_rows, " CAPPED" if out.secondary_truncated else "",
            " CAPPED" if out.truncated else " whole")
        return out
    finally:
        if not ok:
            try:
                _os.unlink(output_path)
            except OSError:
                pass
        shutil.rmtree(tmp, ignore_errors=True)
