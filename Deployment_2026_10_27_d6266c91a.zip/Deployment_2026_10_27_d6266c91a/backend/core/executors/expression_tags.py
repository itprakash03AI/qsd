"""An unaliased expression is named by ITS OWN TEXT on every side (2026-10-25).

The owner ran a UNION ALL of two statements with the same SELECT list and no
aliases:

    SELECT count(*), round(sum(transactional_currency_amount), 2) FROM ...   -- AWS S3
    SELECT count(*), round(sum(transactional_currency_amount), 2) FROM ...   -- Starburst

and got 4 columns, half of every row empty: each engine names an unaliased
column its own way (DuckDB ``count_star()``, Trino ``_col0``), and the combine
aligns BY NAME.  "Positional mapping can create errors -- the same column
expression should tag" (the owner): so a side's result column is renamed to
the canonical text of the expression that produced it, read from THAT side's
own statement -- within one statement, result column *i* IS projection *i*,
exact.  Then the two sides meet by name: the same expression on both sides
is one column; a different expression stays its own column; nothing is ever
paired by position across sides.

Never guesses: a statement that cannot be parsed, that selects ``*``, or
whose projection count differs from the result's columns is left exactly as
it is (by-name alignment as before).  An aliased expression and a bare
column keep their names.
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

_WS = re.compile(r"\s+")


def canonical_text(expr) -> str:
    """The expression as ONE spelling for every engine: sqlglot's generic
    rendering, identifiers unquoted, lower case, single spaces."""
    from sqlglot import exp
    e = expr.copy()
    for ident in e.find_all(exp.Identifier):
        ident.set("quoted", False)
    text = e.sql()
    return _WS.sub(" ", text).strip().lower()


def output_tags(sql: str, dialect: Optional[str]) -> Optional[List[Optional[str]]]:
    """Per output column of ``sql``: the tag for an unaliased expression,
    None for a column that already has a name (alias / bare column).  None
    overall when the statement cannot be read for this (parse failure, ``*``)."""
    if not (sql or "").strip():
        return None
    import sqlglot
    from sqlglot import exp
    tree = None
    # the tag is engine-NEUTRAL text, so any grammar that reads the statement
    # gives the same answer; the caller's dialect first when it knows it
    for d in ([dialect] if dialect else []) + [None, "trino", "duckdb", "snowflake"]:
        try:
            tree = sqlglot.parse_one(sql.strip().rstrip(";"), read=d)
            break
        except Exception as exc:                        # noqa: BLE001 -- the next grammar
            logger.debug("[expression-tags] not parsed as %s: %s", d, exc)
    if tree is None:
        return None
    sel = tree
    while isinstance(sel, (exp.Union, exp.Except, exp.Intersect)):
        sel = sel.left                                  # the first branch names the columns
    if isinstance(sel, exp.Subquery):
        sel = sel.this
    if not isinstance(sel, exp.Select):
        return None
    out: List[Optional[str]] = []
    for proj in sel.expressions:
        if isinstance(proj, exp.Star) or (isinstance(proj, exp.Column) and isinstance(proj.this, exp.Star)):
            return None
        if isinstance(proj, (exp.Alias, exp.Column)):
            out.append(None)
            continue
        out.append(canonical_text(proj))
    return out


def rename_map(sql: Optional[str], dialect: Optional[str],
               result_columns: Sequence[str]) -> Dict[str, str]:
    """``{result column -> tag}`` for one side, or {} when nothing can be
    said with certainty (counts differ, a tag would collide with a name the
    side already has, two projections share one tag)."""
    tags = output_tags(sql or "", dialect)
    cols = list(result_columns)
    if not tags or len(tags) != len(cols):
        return {}
    named = {c.lower() for c, t in zip(cols, tags) if t is None}
    wanted = [t for t in tags if t]
    out: Dict[str, str] = {}
    for col, tag in zip(cols, tags):
        if not tag or tag == col:
            continue
        if tag in named or wanted.count(tag) > 1:
            continue                                    # never two columns under one name
        out[col] = tag
    return out
