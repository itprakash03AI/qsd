"""
QueryStudio CLI — Airflow-style unified entry point.

Usage:
    python -m querystudio standalone        Run webserver + scheduler in one process
    python -m querystudio webserver         Run HTTP/WebSocket server only
    python -m querystudio scheduler         Run scheduler worker only
    python -m querystudio executor          Run executor worker only
    python -m querystudio published-api     Run Published Views API only (consumer-facing)
    python -m querystudio reports           Run Reports API only (business-reports serving pod)
    python -m querystudio etl-worker        Run ETL pipeline worker
    python -m querystudio feed-worker       Run feed run queue worker (claims feed_runs)
    python -m querystudio db init           Initialize database and directories
    python -m querystudio db migrate        Apply pending schema migrations
    python -m querystudio db check          Verify database connectivity
    python -m querystudio version           Show version information
    python -m querystudio info              System and environment info
    python -m querystudio config show       Print resolved configuration
    python -m querystudio config validate   Validate config.json
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from pathlib import Path

# Ensure the backend directory is on sys.path so core.* imports work
_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


def _print_banner():
    from querystudio import __version__
    v = __version__
    py = platform.python_version()
    osname = platform.system()
    d = "\033[2m"   # dim
    r = "\033[0m"   # reset
    b = "\033[1m"   # bold
    c = "\033[36m"  # cyan
    print(f"""{c}
   ___                       ___ _           _ _
  / _ \\ _  _ ___ _ _ _  _  / __| |_ _  _ __| (_)___
 | (_) | || / -_) '_| || | \\__ \\  _| || / _` | / _ \\
  \\__\\_\\\\_,_\\___|_|  \\_, | |___/\\__|\\_,_\\__,_|_\\___/
                     |__/{r}
  {d}v{v}  |  Python {py}  |  {osname}{r}
""")


# ── Subcommands ──────────────────────────────────────────────────────────────

def cmd_standalone(args):
    """Run webserver + scheduler in one process (embedded mode)."""
    _print_banner()
    print("[standalone] Starting webserver + scheduler in one process")

    # Force embedded mode so APScheduler runs in-process
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "embedded"

    # glibc fixes its arena limit when the 9th arena is made -- importing
    # main starts thread pools, so the cap must come FIRST (_cap_allocator)
    _cap_allocator()
    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


def cmd_webserver(args):
    """Run FastAPI HTTP server only (external scheduler mode)."""
    _print_banner()
    print("[webserver] Starting HTTP server (scheduler.mode=external)")
    print("[webserver] Make sure scheduler worker is running separately\n")

    # Force external mode so APScheduler does NOT start here
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "external"

    # glibc fixes its arena limit when the 9th arena is made -- importing
    # main starts thread pools, so the cap must come FIRST (_cap_allocator)
    _cap_allocator()
    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


def _cap_allocator():
    """Cap glibc's malloc arenas for a long-running WORKER process.

    2026-10-11: ``core/process_memory.configure_allocator`` was applied only
    by ``main.run_server`` -- the uvicorn processes.  The workers below run
    no uvicorn, so the scheduler (where the in-process queue worker runs
    every native feed) kept glibc's default of 8 x cores arenas: live on the
    rig (20 cores) its anonymous memory went 202 MiB at start to 1,935 MiB
    after a day of concurrent feed runs, in a 2 GiB container, while one
    10M-row run alone added ~90 MiB.  Every worker subcommand calls this
    BEFORE importing its worker module, so the cap is in force before any
    thread mallocs.

    2026-10-25: the SERVER subcommands too (standalone, webserver, reports,
    published-api).  ``main.run_server`` applied the cap only after ``from
    main import run_server`` had imported the world, and glibc fixes its
    arena limit (8 x cores) the moment a 9th arena is made: the rig's
    standalone API held 49 arenas and 2.3 GiB idle, and the published-API
    memory guard refused every uncached /data page above 2,304 MiB."""
    from core.process_memory import configure_allocator
    n = configure_allocator()
    # print, like the banner: logging is configured later by the worker
    # module, so configure_allocator's own INFO line is lost on these pods.
    print(f"[allocator] glibc malloc arenas capped at {n}" if n
          else "[allocator] glibc malloc arenas NOT capped "
               "(server.malloc_arena_max=0, or not glibc)")


def cmd_scheduler(args):
    """Run scheduler worker only."""
    _print_banner()
    print("[scheduler] Starting scheduler worker\n")
    _cap_allocator()

    # Override port if provided
    if args.port:
        os.environ["QUERYSTUDIO_SCHEDULER_WORKER_PORT"] = str(args.port)

    from scheduler_worker import main as scheduler_main
    scheduler_main()


def cmd_executor(args):
    """Run executor worker only (heavy query execution)."""
    _print_banner()
    print("[executor] Starting executor worker\n")
    _cap_allocator()

    # Override port if provided
    if args.port:
        os.environ["QUERYSTUDIO_EXECUTOR_WORKER_PORT"] = str(args.port)

    from executor_worker import main as executor_main
    executor_main()


def cmd_etl_worker(args):
    """Run ETL pipeline worker (Airflow/Spark/DuckDB execution)."""
    _print_banner()
    print("[etl-worker] Starting ETL pipeline worker\n")
    _cap_allocator()

    # Override port if provided
    if args.port:
        os.environ["QUERYSTUDIO_ETL_WORKER_PORT"] = str(args.port)

    from etl_worker import main as etl_main
    etl_main()


def cmd_feed_worker(args):
    """Run the feed run queue worker only (backend/feed_worker.py).

    W3 (2026-09-26): the ``feed-worker`` Helm chart ran ``etl-worker`` --
    the ETL PIPELINE poller -- because this subcommand did not exist and a
    chart comment called ``feed_worker`` "a typo".  This is the process
    that claims ``feed_runs`` rows (an atomic conditional UPDATE, so N pods
    and the scheduler's in-process copy never double-run a row) and
    executes feeds; it is not the ETL worker and not the scheduler.
    """
    _print_banner()
    print("[feed-worker] Starting feed run queue worker\n")
    _cap_allocator()

    # Control-app port for the probes, mirroring the other workers.
    if args.port:
        os.environ["QUERYSTUDIO_FEED_WORKER_PORT"] = str(args.port)

    # feed_worker.main parses its OWN options; hand it exactly the ones
    # given here.  Passing nothing would make it read sys.argv, whose first
    # entry is this subcommand's name -- an "unrecognized arguments" exit.
    argv = []
    if args.shard:
        argv += ["--shard", str(args.shard)]
    if args.poll_interval:
        argv += ["--poll-interval", str(args.poll_interval)]
    if args.max_concurrent:
        argv += ["--max-concurrent", str(args.max_concurrent)]
    if args.log_level:
        argv += ["--log-level", str(args.log_level)]

    from feed_worker import main as feed_main
    feed_main(argv)


def cmd_published_api(args):
    """Run Published Views API server only (lightweight, consumer-facing)."""
    _print_banner()
    print("[published-api] Starting Published Views API server")
    print("[published-api] Only /api/v1/* and /health endpoints are active\n")

    # Force Published API mode — only PV + health routes registered
    os.environ["QUERYSTUDIO_PUBLISHED_API_MODE"] = "true"
    # No scheduler needed in consumer-facing pod
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "external"

    # glibc fixes its arena limit when the 9th arena is made -- importing
    # main starts thread pools, so the cap must come FIRST (_cap_allocator)
    _cap_allocator()
    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


def cmd_reports(args):
    """Run Reports API server only (business-reports serving pod).

    2026-08-09 (reporting rewire Phase 4) — sibling of cmd_published_api
    above.  Sets QUERYSTUDIO_REPORTS_MODE so main.py registers only the
    reports surface (business-reports + datasets + subscriptions + comments
    + health/metrics); scheduler is external — scheduled report runs happen
    on the scheduler pod, this pod serves execute/retrieve/drill/export.
    """
    _print_banner()
    print("[reports] Starting Reports API server")
    print("[reports] Only /api/business-reports/*, /api/datasets/*, "
          "/api/subscriptions/*, and /health endpoints are active\n")

    # Force Reports mode — only report-serving + health routes registered
    os.environ["QUERYSTUDIO_REPORTS_MODE"] = "true"
    # No scheduler in the serving pod — schedules run on the scheduler pod
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "external"

    # glibc fixes its arena limit when the 9th arena is made -- importing
    # main starts thread pools, so the cap must come FIRST (_cap_allocator)
    _cap_allocator()
    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


# 2026-06-04 — CLI commands historically hardcoded sqlite:///{db_file}
# regardless of database.type config.  After a Postgres cutover, running
# `python -m querystudio db init/migrate/check` silently operated against
# SQLite, applying migrations to the wrong DB and reporting health from
# the wrong DB.  This helper reads database.type from config and returns
# the appropriate (db_url, label, file_path) tuple so the CLI matches
# what the running backend actually uses.  file_path is None when the
# backend is Postgres (no on-disk file to inspect).
def _resolve_cli_db_target():
    from core.config import paths as _paths, database as _db_cfg

    db_type = (_db_cfg.type or "sqlite").lower()
    if db_type == "postgresql":
        # Use db_url (honours BF-409 env ladder: QUERYSTUDIO_DATABASE_URL /
        # _CMD / _SECRET → config.postgresql_url → composed parts) instead
        # of postgresql_url directly, which reads config.json only and
        # blanks out env-driven K8s deploys.
        try:
            url = (_db_cfg.db_url or "").strip()
        except ValueError as _e:
            print(f"FAIL: database.type=postgresql but no URL resolved: {_e}")
            sys.exit(1)
        if not url:
            print("FAIL: database.type=postgresql but no URL resolved.")
            print("  Set one of:")
            print("    env QUERYSTUDIO_DATABASE_URL=postgresql://user:pass@host:5432/db")
            print("    env QUERYSTUDIO_DATABASE_URL_SECRET=/path/to/secret/file")
            print("    env QUERYSTUDIO_DATABASE_POSTGRESQL_{USER,PASSWORD,HOST,PORT,DB}")
            print("    config.json database.postgresql_url='postgresql://...'")
            sys.exit(1)
        # Mask the password for display.
        try:
            from urllib.parse import urlparse
            _p = urlparse(url)
            _label = f"postgresql://{_p.username or 'user'}:***@{_p.hostname}:{_p.port or 5432}{_p.path}"
        except Exception:
            _label = "postgresql:///<configured>"
        return url, _label, None
    if db_type == "oracle":
        url = _db_cfg.db_url
        return url, "oracle://<configured>", None
    # SQLite (default)
    db_file = Path(_paths.db_file).resolve()
    return f"sqlite:///{db_file.as_posix()}", str(db_file), db_file


def cmd_db_init(args):
    """Create database, tables, and data directories."""
    os.chdir(str(_backend_dir))
    from core.config import paths as _paths

    # Create all data directories
    dirs = [
        Path(_paths.data_dir),
        Path(_paths.parquet_dir),
        Path(_paths.downloads_dir),
        Path(_paths.data_dir) / "cache",
        Path(_paths.data_dir) / "uploads",
    ]
    created = []
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        created.append(d)

    # 2026-06-04 — honour database.type from config so Postgres deployments
    # don't silently apply migrations to a SQLite file nobody uses.
    db_url, db_label, _db_file = _resolve_cli_db_target()

    from core.database import DatabaseManager
    db_manager = DatabaseManager(db_url=db_url)

    # Count tables
    from sqlalchemy import inspect
    inspector = inspect(db_manager.engine)
    tables = inspector.get_table_names()

    print("Database initialized successfully")
    print(f"  Backend:  {db_label}")
    print(f"  Tables:   {len(tables)}")
    print(f"  Dirs:     {len(created)} data directories ready")
    for d in created:
        print(f"            {d}")


def cmd_db_migrate(args):
    """Apply pending schema migrations."""
    os.chdir(str(_backend_dir))
    # 2026-06-04 — honour database.type from config.
    db_url, db_label, _db_file = _resolve_cli_db_target()

    from core.database import DatabaseManager
    db_manager = DatabaseManager(db_url=db_url)

    print("Schema migrations applied successfully")
    print(f"  Backend: {db_label}")


def cmd_db_check(args):
    """Verify database connectivity and schema."""
    os.chdir(str(_backend_dir))
    # 2026-06-04 — honour database.type from config.  For SQLite we
    # still pre-check the file exists; for Postgres/Oracle we just
    # attempt the connection (the existence check doesn't apply).
    db_url, db_label, db_file = _resolve_cli_db_target()

    if db_file is not None and not db_file.exists():
        print(f"FAIL: Database file not found: {db_file}")
        print("  Run: python -m querystudio db init")
        sys.exit(1)

    try:
        from core.database import DatabaseManager
        db_manager = DatabaseManager(db_url=db_url)
    except Exception as exc:
        print(f"FAIL: Cannot connect to database: {exc}")
        sys.exit(1)

    from sqlalchemy import inspect, text
    inspector = inspect(db_manager.engine)
    tables = inspector.get_table_names()

    expected = [
        "saved_queries", "query_executions", "download_files",
        "connections", "schedules", "pending_notifications",
    ]
    missing = [t for t in expected if t not in tables]

    # Get on-disk size only for SQLite — Postgres has no single file.
    size_label = ""
    if db_file is not None and db_file.exists():
        size_mb = db_file.stat().st_size / (1024 * 1024)
        size_label = f" ({size_mb:.1f} MB)"

    # Count key records
    session = db_manager.SessionLocal()
    try:
        counts = {}
        for t in ["saved_queries", "connections", "schedules"]:
            if t in tables:
                result = session.execute(text(f"SELECT COUNT(*) FROM {t}"))
                counts[t] = result.scalar()
    finally:
        session.close()

    print("Database health check")
    print(f"  Backend:  {db_label}{size_label}")
    print(f"  Tables:   {len(tables)}")
    if missing:
        print(f"  Missing:  {', '.join(missing)}")
    else:
        print("  Schema:   OK (all expected tables present)")
    for t, c in counts.items():
        print(f"  {t}: {c} rows")

    if missing:
        print("\nWARNING: Some tables are missing. Run: python -m querystudio db init")
        sys.exit(1)
    else:
        print("\nAll checks passed")


# ── Phase 107-E: Super admin (break-glass) management ──────────────────────

def _get_db_for_cli():
    """Build a DatabaseManager from config — used by super-admin subcommands.

    2026-06-04 — honours database.type so Postgres deployments don't
    silently operate against a stale SQLite file."""
    os.chdir(str(_backend_dir))
    db_url, _label, _file = _resolve_cli_db_target()
    from core.database import DatabaseManager
    return DatabaseManager(db_url=db_url)


def _prompt_password(confirm: bool = True) -> str:
    """Securely prompt for a password (twice for confirmation if requested)."""
    import getpass
    while True:
        pw1 = getpass.getpass("Password: ")
        if len(pw1) < 12:
            print("ERROR: password must be at least 12 characters long")
            continue
        if not confirm:
            return pw1
        pw2 = getpass.getpass("Confirm:  ")
        if pw1 != pw2:
            print("ERROR: passwords do not match — try again")
            continue
        return pw1


def cmd_super_admin_create(args):
    """Create a new break-glass super admin account."""
    from core.ad_auth import hash_password
    db = _get_db_for_cli()

    username = args.username
    password = args.password or _prompt_password(confirm=True)
    if len(password) < 12:
        print("ERROR: password must be at least 12 characters long")
        sys.exit(1)

    try:
        row = db.create_super_admin(
            username=username,
            password_hash=hash_password(password),
            created_by="cli",
            notes=args.notes,
        )
    except ValueError as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)

    db.audit(
        username="cli",
        action="super_admin_create",
        resource_type="super_admin",
        resource_id=username,
        details={"source": "cli"},
    )

    print(f"Super admin created: {row['username']} (id={row['id']})")


def cmd_super_admin_reset(args):
    """Reset the password for an existing super admin."""
    from core.ad_auth import hash_password
    db = _get_db_for_cli()

    sa = db.get_super_admin_by_username(args.username)
    if sa is None:
        print(f"ERROR: super admin not found: {args.username}")
        sys.exit(1)

    password = args.password or _prompt_password(confirm=True)
    if len(password) < 12:
        print("ERROR: password must be at least 12 characters long")
        sys.exit(1)

    if not db.update_super_admin_password(args.username, hash_password(password)):
        print(f"ERROR: failed to update password for: {args.username}")
        sys.exit(1)

    db.audit(
        username="cli",
        action="super_admin_reset_password",
        resource_type="super_admin",
        resource_id=args.username,
        details={"source": "cli"},
    )

    print(f"Password reset for super admin: {args.username}")


def cmd_super_admin_list(args):
    """List all super admins (no password hashes)."""
    db = _get_db_for_cli()
    rows = db.list_super_admins()
    if not rows:
        print("No super admins configured")
        return

    print(f"{'USERNAME':<24}{'ACTIVE':<10}{'CREATED':<22}{'LAST LOGIN':<22}NOTES")
    print("-" * 100)
    for r in rows:
        print(
            f"{r['username']:<24}"
            f"{('yes' if r['is_active'] else 'no'):<10}"
            f"{(r.get('created_at') or '')[:19]:<22}"
            f"{(r.get('last_login_at') or '')[:19]:<22}"
            f"{r.get('notes') or ''}"
        )


def cmd_super_admin_disable(args):
    """Disable a super admin without deleting it."""
    db = _get_db_for_cli()

    if not db.get_super_admin_by_username(args.username):
        print(f"ERROR: super admin not found: {args.username}")
        sys.exit(1)

    # Last-active lockout protection
    sa = db.get_super_admin_by_username(args.username)
    if sa and sa.get("is_active") and db.count_active_super_admins() <= 1:
        print("ERROR: cannot disable the last active super admin (lockout protection)")
        sys.exit(1)

    if not db.set_super_admin_active(args.username, False):
        print(f"ERROR: failed to disable: {args.username}")
        sys.exit(1)

    db.audit(
        username="cli",
        action="super_admin_disable",
        resource_type="super_admin",
        resource_id=args.username,
        details={"source": "cli"},
    )

    print(f"Disabled super admin: {args.username}")


def cmd_super_admin_enable(args):
    """Re-enable a previously disabled super admin."""
    db = _get_db_for_cli()
    if not db.get_super_admin_by_username(args.username):
        print(f"ERROR: super admin not found: {args.username}")
        sys.exit(1)

    if not db.set_super_admin_active(args.username, True):
        print(f"ERROR: failed to enable: {args.username}")
        sys.exit(1)

    db.audit(
        username="cli",
        action="super_admin_enable",
        resource_type="super_admin",
        resource_id=args.username,
        details={"source": "cli"},
    )

    print(f"Enabled super admin: {args.username}")


def cmd_version(args):
    """Print version + key dependency versions."""
    from querystudio import __version__

    print(f"QueryStudio v{__version__}")
    print(f"Python {platform.python_version()}")

    deps = {
        "fastapi": "fastapi",
        "uvicorn": "uvicorn",
        "duckdb": "duckdb",
        "APScheduler": "apscheduler",
        "SQLAlchemy": "sqlalchemy",
        "PyArrow": "pyarrow",
        "Pandas": "pandas",
        "Boto3": "boto3",
        "Pydantic": "pydantic",
    }
    parts = []
    for label, pkg in deps.items():
        try:
            mod = __import__(pkg)
            ver = getattr(mod, "__version__", getattr(mod, "version", "?"))
            parts.append(f"{label} {ver}")
        except ImportError:
            parts.append(f"{label} (not installed)")

    # Print in rows of 3
    for i in range(0, len(parts), 3):
        print("  " + " | ".join(parts[i:i + 3]))


def cmd_info(args):
    """Print full system info."""
    from querystudio import __version__
    os.chdir(str(_backend_dir))

    print(f"QueryStudio v{__version__}")
    print("-" * 40)
    print(f"  Platform:    {platform.system()} {platform.release()} ({sys.platform})")
    print(f"  Python:      {platform.python_version()}")
    print(f"  Backend dir: {_backend_dir}")

    try:
        from core.config import paths as _paths, scheduler as _sched_cfg, auth as _auth_cfg, executor as _exec_cfg

        config_file = _backend_dir / "config.json"
        print(f"  Config file: {config_file} ({'exists' if config_file.exists() else 'NOT FOUND'})")

        # 2026-06-04 — print the actual configured backend so a Postgres
        # deployment doesn't mislead operators with "SQLite not created".
        try:
            _info_db_url, _info_db_label, _info_db_file = _resolve_cli_db_target()
        except Exception:
            _info_db_url, _info_db_label, _info_db_file = None, "<unresolved>", None
        if _info_db_file is not None:
            db_file = _info_db_file
            if db_file.exists():
                size_mb = db_file.stat().st_size / (1024 * 1024)
                print(f"  Database:    {db_file} ({size_mb:.1f} MB)")
            else:
                print(f"  Database:    {db_file} (not created)")
        else:
            db_file = None
            print(f"  Database:    {_info_db_label}")

        data_dir = Path(_paths.data_dir).resolve()
        if data_dir.exists():
            total = sum(f.stat().st_size for f in data_dir.rglob("*") if f.is_file())
            print(f"  Data dir:    {data_dir} ({total / (1024 * 1024):.0f} MB)")
        else:
            print(f"  Data dir:    {data_dir} (not created)")

        print(f"  Auth mode:   {_auth_cfg.type}")
        print(f"  Scheduler:   {_sched_cfg.mode}")
        print(f"  Executor:    {_exec_cfg.mode}")

        # Queue backend info
        try:
            from core.config import queue as _queue_cfg
            backend = _queue_cfg.backend
            print(f"  Queue:       {backend}", end="")
            if backend == "redis":
                print(f" ({_queue_cfg.redis_url})", end="")
                # Test Redis connectivity
                try:
                    import redis
                    r = redis.from_url(_queue_cfg.redis_url, socket_connect_timeout=2)
                    r.ping()
                    print(" [connected]")
                except Exception:
                    print(" [NOT reachable]")
            else:
                print()
        except Exception:
            print("  Queue:       sqlite (default)")

        # 2026-06-04 — count records via the actual configured backend.
        # SQLite needs the file to exist; Postgres/Oracle just need a URL.
        _can_count = (db_file is not None and db_file.exists()) or \
                     (db_file is None and _info_db_url)
        if _can_count:
            try:
                from core.database import DatabaseManager
                db_manager = DatabaseManager(db_url=_info_db_url)
                from sqlalchemy import text
                session = db_manager.SessionLocal()
                try:
                    for table, label in [
                        ("connections", "Connections"),
                        ("saved_queries", "Saved queries"),
                        ("schedules", "Schedules"),
                    ]:
                        try:
                            count = session.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                            print(f"  {label}:{' ' * (13 - len(label))}{count}")
                        except Exception:
                            pass
                finally:
                    session.close()
            except Exception:
                pass

    except Exception as exc:
        print(f"  Config load error: {exc}")


_CONFIG_SECRET_KEYS = {"password", "secret", "key", "token", "credential", "local_users"}
#: A key that names WHERE a secret lives is a path, not the secret
#: (server.ssl_keyfile, paths.secret_key_file, secrets.token_path): masking
#: it hid the TLS key path from `config show`, so scripts/verify_prod_config.py
#: could never confirm the pod loaded the cert it mounts (2026-09-29).
_CONFIG_LOCATION_SUFFIXES = ("file", "path", "dir")


def _looks_secret(key: str) -> bool:
    k = key.lower()
    if k.endswith(_CONFIG_LOCATION_SUFFIXES):
        return False
    return any(s in k for s in _CONFIG_SECRET_KEYS)


def _mask_config(d, parent_key=""):
    """Mask secret-looking string values in place (dicts and lists)."""
    if isinstance(d, dict):
        for k, v in d.items():
            if _looks_secret(k) and isinstance(v, str) and v:
                d[k] = "***masked***"
            else:
                _mask_config(v, k)
    elif isinstance(d, list):
        for item in d:
            _mask_config(item)


def _config_file_in_force():
    """The file the loader reads: ``$QUERYSTUDIO_CONFIG`` when set, else
    ``backend/config.json`` -- the same rule as ``core.config._load_file``."""
    from core import config as _cfg_mod
    env_override = os.environ.get("QUERYSTUDIO_CONFIG")
    return Path(env_override) if env_override else _cfg_mod._CONFIG_FILE


def _config_db_overlay():
    """``(rows_or_None, error_or_None)`` -- the cross-pod overlay rows
    (system_settings ``config.<section>.<key>``) from the configured
    database.  ``None`` rows with an error means UNKNOWN, never "none".
    The DB target resolver prints and exits on a bad target; both are
    captured so this prints one JSON document either way."""
    import contextlib
    import io
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            db_url, _label, _file = _resolve_cli_db_target()
        from core import config as _cfg_mod
        from core.database import DatabaseManager
        rows = DatabaseManager(db_url=db_url).list_system_settings(
            prefix=_cfg_mod._RUNTIME_OVERRIDE_PREFIX)
        return rows, None
    except SystemExit:
        return None, (buf.getvalue().strip() or "database target could not be resolved")
    except Exception as exc:  # noqa: BLE001 -- reported, never hidden
        return None, f"{type(exc).__name__}: {exc}"


def cmd_config_show(args):
    """Print the EFFECTIVE configuration of this process, secrets masked.

    2026-09-27: the sections printed are file + env + the cross-pod DB
    overlay (``system_settings`` rows an admin wrote through
    ``config.set()``), which is what ``config.get()`` serves on a pod.  It
    used to print ``_cfg`` alone -- the file+env layer -- so a value an
    admin had changed fleet-wide was invisible to the operator reading the
    dump.  Two labelled keys say where things came from: ``_source`` (the
    config file in force, whether it loaded, the overlay's row count or the
    error that made it UNKNOWN) and ``_db_overlay`` (the overlay rows
    themselves, ``null`` when unreadable).  ``--no-db`` skips the database.
    The docs/PROD_CONFIG_DEPLOYMENT_PLAN checker consumes this shape.
    """
    os.chdir(str(_backend_dir))

    import copy
    from core import config as _cfg_mod

    cfg = copy.deepcopy(_cfg_mod._cfg)
    # 2026-09-27: ONE resolver for "which file did this process load" --
    # core.config.config_source() -- shared with the startup line and
    # /health, so the three cannot disagree.
    source = dict(_cfg_mod.config_source())
    source.update({
        "env_overrides_refused": [
            {"env": ev, "key": f"{sec}.{fld}", "reason": why}
            for ev, sec, fld, why in _cfg_mod._env_rejections],
        "db_overlay_rows": None,
        "db_overlay_error": None,
    })
    overlay = None
    overlay_diff = None
    if getattr(args, "no_db", False):
        source["db_overlay_error"] = "skipped (--no-db)"
    else:
        rows, err = _config_db_overlay()
        if err is not None:
            source["db_overlay_error"] = err
        else:
            overlay = {}
            # Rows that DIFFER from the file+env layer: the ones a release
            # must reconcile (they win over the reviewed file on every pod).
            overlay_diff = _overlay_diff_rows(rows or [], _cfg_mod._cfg,
                                              _cfg_mod._RUNTIME_OVERRIDE_PREFIX)
            prefix = _cfg_mod._RUNTIME_OVERRIDE_PREFIX
            for r in rows or []:
                k = (r.get("key") or "")[len(prefix):]
                sec, _, kk = k.partition(".")
                if not (sec and kk) or r.get("value") is None:
                    continue
                overlay[f"{sec}.{kk}"] = r.get("value")
                cfg.setdefault(sec, {})
                if isinstance(cfg[sec], dict):
                    cfg[sec][kk] = r.get("value")
            source["db_overlay_rows"] = len(overlay)

    _mask_config(cfg)
    if overlay is not None:
        masked_overlay = {}
        for dotted, v in overlay.items():
            sec, kk = dotted.split(".", 1)
            holder = {kk: copy.deepcopy(v)}
            _mask_config(holder)
            masked_overlay[dotted] = holder[kk]
        overlay = masked_overlay
    if overlay_diff is not None:
        overlay_diff = _mask_overlay_diff(overlay_diff)
    out = {"_source": source, "_db_overlay": overlay,
           "_db_overlay_diff": overlay_diff}
    out.update(cfg)
    print(json.dumps(out, indent=2, default=str))


def _overlay_diff_rows(rows, file_env_cfg, prefix):
    """The DB overlay rows whose value differs from the file+env layer.

    ``[{"key": "section.key", "overlay": v, "file_env": v_or_None,
    "declared": bool}]`` -- a row for a key the file+env layer does not
    even have is listed with ``file_env: None`` and ``declared: False``
    (it still wins at read time through ``config.get``)."""
    out = []
    for r in rows:
        k = (r.get("key") or "")
        if not k.startswith(prefix):
            continue
        dotted = k[len(prefix):]
        sec, _, kk = dotted.partition(".")
        if not (sec and kk) or r.get("value") is None:
            continue
        section = file_env_cfg.get(sec) if isinstance(file_env_cfg, dict) else None
        declared = isinstance(section, dict) and kk in section
        current = section.get(kk) if declared else None
        if not declared or current != r.get("value"):
            out.append({"key": dotted, "overlay": r.get("value"),
                        "file_env": current, "declared": declared})
    return out


def _mask_overlay_diff(diff):
    import copy as _copy
    masked = []
    for d in diff:
        sec, kk = d["key"].split(".", 1)
        holder = {kk: _copy.deepcopy(d["overlay"])}
        _mask_config(holder)
        secret = holder[kk] == "***masked***"
        masked.append({**d, "overlay": holder[kk],
                       "file_env": "***masked***" if (secret and d["file_env"]) else d["file_env"]})
    return masked


def cmd_config_overlay_diff(args):
    """List the DB overlay rows (``system_settings`` ``config.<section>.<key>``,
    written by admin screens through ``config.set()``) that DIFFER from the
    file+env layer of THIS process -- "reconcile before release" as one
    command (2026-09-27; docs/PROD_CONFIG_DEPLOYMENT_PLAN_2026_09_27.html
    section 3.4).

    Exit 0: every overlay row equals the reviewed file+env value (or there
    are none).  Exit 1: at least one row differs -- each is named with both
    values; put it in the environment overlay or delete the row.  Exit 2:
    the overlay could not be READ -- UNKNOWN, never "no rows" (CLAUDE.md
    section 4: unknown is not empty).
    """
    os.chdir(str(_backend_dir))
    from core import config as _cfg_mod

    rows, err = _config_db_overlay()
    if err is not None:
        print(json.dumps({"status": "UNKNOWN", "error": err, "rows_total": None,
                          "differs": None}, indent=2, default=str))
        sys.exit(2)
    diff = _mask_overlay_diff(_overlay_diff_rows(
        rows or [], _cfg_mod._cfg, _cfg_mod._RUNTIME_OVERRIDE_PREFIX))
    status = "DIFFERS" if diff else "RECONCILED"
    print(json.dumps({"status": status, "config_file": _cfg_mod.config_source()["config_file"],
                      "rows_total": len(rows or []), "differs_count": len(diff),
                      "differs": diff}, indent=2, default=str))
    sys.exit(1 if diff else 0)


def cmd_config_diff_defaults(args):
    """List every leaf of the config FILE in force that differs from the
    declared ``_DEFAULTS`` (2026-09-27), secrets masked.

    Why: a file generated by ``init_config`` writes every default as an
    explicit value, and an explicit value beats ``_DEFAULTS`` -- so each later
    default change is silently FROZEN at whatever the file said the day it
    was generated.  Found live on the Docker rig: ``row_security.enabled`` was
    still false a day after the owner turned it on.  Before a release every
    line this prints should be a deliberate environment difference someone
    can name (docs/PROD_CONFIG_DEPLOYMENT_PLAN_2026_09_27.html section 3).

    Reads the FILE only (not env, not the DB overlay -- ``config show`` is the
    effective view).  ``--fail-on-diff`` exits 1 when anything differs, for
    a pipeline that keeps the file partial.
    """
    os.chdir(str(_backend_dir))
    import copy
    from core import config as _cfg_mod

    cfg_file = _config_file_in_force()
    if not cfg_file.exists():
        print(json.dumps({"config_file": str(cfg_file), "error": "not found"}))
        sys.exit(2)
    try:
        data = json.loads(cfg_file.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 -- reported, never hidden
        print(json.dumps({"config_file": str(cfg_file),
                          "error": f"{type(exc).__name__}: {exc}"}))
        sys.exit(2)

    differs, undeclared = [], []

    def _walk(node, declared, prefix):
        for k, v in node.items():
            if str(k).startswith("_comment"):
                continue
            dotted = f"{prefix}.{k}" if prefix else str(k)
            if not isinstance(declared, dict) or k not in declared:
                undeclared.append(dotted)
                continue
            d = declared[k]
            if isinstance(v, dict) and isinstance(d, dict):
                _walk(v, d, dotted)
            elif v != d:
                holder = {k: copy.deepcopy(v), "__default__": copy.deepcopy(d)}
                _mask_config(holder)
                differs.append({"key": dotted, "file": holder[k],
                                "default": d if holder[k] != "***masked***" else "***masked***"})

    _walk(data, _cfg_mod._DEFAULTS, "")
    print(json.dumps({"config_file": str(cfg_file), "differs_count": len(differs),
                      "differs": differs, "undeclared": undeclared},
                     indent=2, default=str))
    if getattr(args, "fail_on_diff", False) and differs:
        sys.exit(1)


def cmd_config_validate(args):
    """Validate the config file in force (syntax, shapes) and report what
    ``core.config.validate_config`` says about the EFFECTIVE config.

    2026-09-27: honours ``$QUERYSTUDIO_CONFIG`` (it read ``backend/config.json``
    only, so on a pod whose loader was pointed elsewhere it validated a file
    nobody reads) and prints ``validate_config()``'s findings -- unknown or
    removed keys, refused env overrides, out-of-range values -- which are the
    checks the product itself runs at startup.
    """
    os.chdir(str(_backend_dir))

    config_file = _config_file_in_force()
    if not config_file.exists():
        print(f"Config file not found: {config_file}")
        if os.environ.get("QUERYSTUDIO_CONFIG"):
            print("FAIL: QUERYSTUDIO_CONFIG names a file that does not exist -- "
                  "the loader runs on DEFAULTS and auth fails CLOSED")
            sys.exit(1)
        print("Using built-in defaults (this is OK for development)")
        sys.exit(0)

    # Parse JSON
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except json.JSONDecodeError as exc:
        print(f"FAIL: Invalid JSON in {config_file}")
        print(f"  {exc}")
        sys.exit(1)

    print(f"Config file: {config_file}")
    print("  JSON syntax: OK")

    # 2026-09-27: the LOADER's verdict on this very file.  A file that parses
    # but was REFUSED (a surviving __SET_PER_ENV__ placeholder) leaves the
    # process on DEFAULTS with auth failing closed -- that is a FAIL here,
    # naming the keys, not a validation of the defaults it fell back to.
    from core import config as _cfg_mod
    _src = _cfg_mod.config_source()
    if _src.get("config_file_load_failed") and str(_src.get("config_file")) == str(config_file):
        print(f"FAIL: the loader REFUSED this file -- {_src.get('config_file_error')}")
        if _src.get("config_file_placeholders"):
            print("  placeholders: " + ", ".join(_src["config_file_placeholders"]))
        print("  The pod would run on DEFAULTS with auth failing CLOSED.")
        sys.exit(1)

    warnings = []
    errors = []

    # Validate server section
    server = cfg.get("server", {})
    port = server.get("port")
    if port is not None and not isinstance(port, int):
        errors.append(f"server.port must be integer, got {type(port).__name__}")
    workers = server.get("workers")
    if workers is not None and not isinstance(workers, int):
        errors.append(f"server.workers must be integer, got {type(workers).__name__}")

    # Validate scheduler section
    sched = cfg.get("scheduler", {})
    mode = sched.get("mode")
    if mode and mode not in ("embedded", "external"):
        errors.append(f"scheduler.mode must be 'embedded' or 'external', got '{mode}'")

    # Validate executor section
    executor = cfg.get("executor", {})
    exec_mode = executor.get("mode")
    if exec_mode and exec_mode not in ("embedded", "external"):
        errors.append(f"executor.mode must be 'embedded' or 'external', got '{exec_mode}'")

    # Validate auth section
    auth = cfg.get("auth", {})
    auth_type = auth.get("type")
    if auth_type and auth_type not in ("none", "local", "ad"):
        errors.append(f"auth.type must be 'none', 'local', or 'ad', got '{auth_type}'")
    if auth_type == "none":
        warnings.append("auth.type is 'none' — no authentication (fine for development)")

    # Validate queue section
    queue = cfg.get("queue", {})
    q_backend = queue.get("backend")
    if q_backend and q_backend not in ("sqlite", "redis"):
        errors.append(f"queue.backend must be 'sqlite' or 'redis', got '{q_backend}'")
    if q_backend == "redis":
        redis_url = queue.get("redis_url", "")
        if not redis_url:
            errors.append("queue.redis_url is required when queue.backend = 'redis'")
        elif not redis_url.startswith(("redis://", "rediss://")):
            errors.append(f"queue.redis_url must start with 'redis://' or 'rediss://', got '{redis_url}'")
        ttl = queue.get("task_ttl_hours")
        if ttl is not None and (not isinstance(ttl, (int, float)) or ttl < 1):
            errors.append(f"queue.task_ttl_hours must be a positive number, got {ttl}")

    # Validate database section
    db = cfg.get("database", {})
    db_type = db.get("type")
    if db_type and db_type not in ("sqlite", "postgresql", "oracle"):
        errors.append(f"database.type must be 'sqlite', 'postgresql', or 'oracle', got '{db_type}'")

    # Report
    sections = [k for k in cfg.keys()]
    print(f"  Sections:    {', '.join(sections)}")

    if errors:
        print(f"\n  ERRORS ({len(errors)}):")
        for e in errors:
            print(f"    - {e}")

    if warnings:
        print(f"\n  WARNINGS ({len(warnings)}):")
        for w in warnings:
            print(f"    - {w}")

    if not errors and not warnings:
        print("  Validation:  OK")

    # 2026-09-27: what the PRODUCT checks at startup, against the effective
    # config (this file + env): unknown / removed keys, refused env
    # overrides, enum and range violations.  These are warnings the pod
    # would log at boot; here the operator sees them BEFORE the roll.
    try:
        from core.config import validate_config as _validate_cfg
        issues = _validate_cfg()
    except Exception as exc:  # noqa: BLE001 -- reported, never hidden
        issues = [f"validate_config() could not run: {exc}"]
    if issues:
        print(f"\n  STARTUP VALIDATION ({len(issues)} finding(s), as the pod would log them):")
        for i in issues:
            print(f"    - {i}")
    else:
        print("  Startup validation: OK")

    if errors:
        sys.exit(1)


# ── Main CLI dispatcher ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="querystudio",
        description="QueryStudio — Enterprise Parquet Query Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  standalone      Run webserver + scheduler in one process (default)
  webserver       Run HTTP/WebSocket server only
  scheduler       Run scheduler worker only
  executor        Run executor worker only (heavy queries)
  published-api   Run Published Views API only (consumer-facing)
  reports         Run Reports API only (business-reports serving pod)
  etl-worker      Run ETL pipeline worker
  db              Database management (init, migrate, check)
  version         Show version info
  info            System and environment info
  config          Configuration management (show, validate)
""",
    )
    subparsers = parser.add_subparsers(dest="command")

    # standalone
    p = subparsers.add_parser("standalone", help="Run all components in one process")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=1, help="Number of workers (default: 1)")
    p.set_defaults(func=cmd_standalone)

    # webserver
    p = subparsers.add_parser("webserver", help="Run HTTP server only (external scheduler)")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=1, help="Number of workers (default: 1)")
    p.set_defaults(func=cmd_webserver)

    # scheduler
    p = subparsers.add_parser("scheduler", help="Run scheduler worker only")
    p.add_argument("--port", type=int, default=None, help="Control API port (default: 8001)")
    p.set_defaults(func=cmd_scheduler)

    # executor
    p = subparsers.add_parser("executor", help="Run executor worker only")
    p.add_argument("--port", type=int, default=None, help="Control API port (default: 8002)")
    p.set_defaults(func=cmd_executor)

    # etl-worker (Phase 127)
    p = subparsers.add_parser("etl-worker", help="Run ETL pipeline worker")
    p.add_argument("--port", type=int, default=None, help="Control API port (default: 8004)")
    p.set_defaults(func=cmd_etl_worker)

    # feed-worker (W3, 2026-09-26) -- the feed run queue worker, feed_worker.py
    p = subparsers.add_parser("feed-worker", help="Run feed run queue worker (claims and executes feed_runs)")
    p.add_argument("--port", type=int, default=None, help="Control API port for probes (default: 8005)")
    p.add_argument("--shard", default=None, help="Shard 'i/N' (default: env QUERYSTUDIO_FEED_SHARD)")
    p.add_argument("--poll-interval", type=int, default=None, help="Override feed_generation.queue_poll_interval_seconds")
    p.add_argument("--max-concurrent", type=int, default=None, help="Override feed_generation.max_concurrent_native")
    p.add_argument("--log-level", default=None, help="Log level (default: INFO)")
    p.set_defaults(func=cmd_feed_worker)

    # published-api
    p = subparsers.add_parser("published-api", help="Run Published Views API only (consumer-facing)")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=2, help="Number of workers (default: 2)")
    p.set_defaults(func=cmd_published_api)

    # reports (reporting rewire Phase 4, 2026-08-09)
    p = subparsers.add_parser("reports", help="Run Reports API only (business-reports serving pod)")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=2, help="Number of workers (default: 2)")
    p.set_defaults(func=cmd_reports)

    # db
    db_parser = subparsers.add_parser("db", help="Database management")
    db_sub = db_parser.add_subparsers(dest="db_command")
    p_init = db_sub.add_parser("init", help="Initialize database and directories")
    p_init.set_defaults(func=cmd_db_init)
    p_migrate = db_sub.add_parser("migrate", help="Apply schema migrations")
    p_migrate.set_defaults(func=cmd_db_migrate)
    p_check = db_sub.add_parser("check", help="Verify database health")
    p_check.set_defaults(func=cmd_db_check)

    # super-admin (Phase 107-E)
    sa_parser = subparsers.add_parser(
        "super-admin",
        help="Manage break-glass super admin accounts",
    )
    sa_sub = sa_parser.add_subparsers(dest="super_admin_command")

    p_sa_create = sa_sub.add_parser("create", help="Create a new super admin")
    p_sa_create.add_argument("--username", required=True, help="Login name")
    p_sa_create.add_argument("--password", default=None, help="Password (prompts if omitted)")
    p_sa_create.add_argument("--notes", default=None, help="Optional notes")
    p_sa_create.set_defaults(func=cmd_super_admin_create)

    p_sa_reset = sa_sub.add_parser("reset", help="Reset a super admin password")
    p_sa_reset.add_argument("--username", required=True)
    p_sa_reset.add_argument("--password", default=None, help="Password (prompts if omitted)")
    p_sa_reset.set_defaults(func=cmd_super_admin_reset)

    p_sa_list = sa_sub.add_parser("list", help="List all super admins")
    p_sa_list.set_defaults(func=cmd_super_admin_list)

    p_sa_dis = sa_sub.add_parser("disable", help="Disable a super admin (lockout-protected)")
    p_sa_dis.add_argument("--username", required=True)
    p_sa_dis.set_defaults(func=cmd_super_admin_disable)

    p_sa_en = sa_sub.add_parser("enable", help="Re-enable a disabled super admin")
    p_sa_en.add_argument("--username", required=True)
    p_sa_en.set_defaults(func=cmd_super_admin_enable)

    # version
    p = subparsers.add_parser("version", help="Show version info")
    p.set_defaults(func=cmd_version)

    # info
    p = subparsers.add_parser("info", help="System and environment info")
    p.set_defaults(func=cmd_info)

    # release -- configuration releases UAT -> PROD (2026-10-17, querystudio/release_cli.py)
    from querystudio.release_cli import add_release_parser
    rel_parser = add_release_parser(subparsers)

    # config
    cfg_parser = subparsers.add_parser("config", help="Configuration management")
    cfg_sub = cfg_parser.add_subparsers(dest="config_command")
    p_show = cfg_sub.add_parser(
        "show", help="Print the effective config: file + env + the cross-pod DB overlay")
    p_show.add_argument("--no-db", action="store_true", dest="no_db",
                        help="do not read the system_settings overlay (file + env only)")
    p_show.set_defaults(func=cmd_config_show)
    p_diff = cfg_sub.add_parser(
        "diff-defaults",
        help="List every value in the config FILE that differs from the declared defaults")
    p_diff.add_argument("--fail-on-diff", action="store_true", dest="fail_on_diff",
                        help="exit 1 when any value differs")
    p_diff.set_defaults(func=cmd_config_diff_defaults)
    p_validate = cfg_sub.add_parser(
        "validate", help="Validate the config file in force ($QUERYSTUDIO_CONFIG or backend/config.json)")
    p_validate.set_defaults(func=cmd_config_validate)
    p_ovl = cfg_sub.add_parser(
        "overlay-diff",
        help="List DB overlay rows (system_settings config.*) that differ from the file+env layer; "
             "exit 1 if any, 2 if the overlay cannot be read")
    p_ovl.set_defaults(func=cmd_config_overlay_diff)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # 2026-10-17 -- a SERVER process encrypts with the data keys held in the
    # database (envelope encryption, core/crypto.py); the first
    # DatabaseManager of the process binds the store.  Children (uvicorn
    # workers, subprocesses) inherit it.  One-off commands (db, config, info,
    # super-admin) keep the direct key and never create data keys.
    if args.command in ("standalone", "webserver", "scheduler", "executor", "etl-worker",
                        "feed-worker", "published-api", "reports"):
        os.environ.setdefault("QS_DATA_KEYS_IN_DB", "1")

    if args.command == "db" and not getattr(args, "db_command", None):
        db_parser.print_help()
        sys.exit(0)

    if args.command == "config" and not getattr(args, "config_command", None):
        cfg_parser.print_help()
        sys.exit(0)

    if args.command == "release":
        if not getattr(args, "release_command", None):
            rel_parser.print_help()
            sys.exit(0)
        from querystudio.release_cli import run as _run_release
        os.chdir(str(_backend_dir))
        _run_release(args)          # exits with the command's code

    if args.command == "super-admin" and not getattr(args, "super_admin_command", None):
        sa_parser.print_help()
        sys.exit(0)

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    # cd to backend dir for all commands
    os.chdir(str(_backend_dir))
    args.func(args)
