"""Value lists -- routes (2026-10-24; the rules are core/value_lists.py).

  GET    /api/value-lists                       every list (authors)
  POST   /api/value-lists                       create (the author must SEE the connection)
  POST   /api/value-lists/preview               run a query, see its columns + first rows (nothing saved)
  GET    /api/value-lists/{id}                  one list + the reports that use it
  PUT    /api/value-lists/{id}                  edit (owner or admin)
  DELETE /api/value-lists/{id}                  409 while a report parameter uses it
  POST   /api/value-lists/{id}/sync             sync now
  PUT    /api/value-lists/{id}/items            a STATIC list's values
  GET    /api/value-lists/{id}/items            the values THIS caller may choose (serve)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_role
from core import value_lists as vlm
from core.audit import audit_event

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/value-lists", tags=["value-lists"])
_AUTHOR = require_role("admin", "analyst")

_db_manager = None


def set_value_lists_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


async def _adb(fn, *a, **k):
    return await asyncio.to_thread(fn, *a, **k)


class ValueListIn(BaseModel):
    name: Optional[str] = Field(default=None, max_length=200)
    description: Optional[str] = None
    source_type: Optional[str] = None
    connection_id: Optional[int] = None
    source_sql: Optional[str] = None
    key_column: Optional[str] = Field(default=None, max_length=255)
    label_column: Optional[str] = Field(default=None, max_length=255)
    sync_mode: Optional[str] = None
    sync_every_hours: Optional[int] = None


class ItemIn(BaseModel):
    key: str = Field(..., min_length=1, max_length=500)
    label: Optional[str] = Field(default=None, max_length=1000)


class ItemsIn(BaseModel):
    items: List[ItemIn]


class PreviewIn(BaseModel):
    connection_id: int
    source_sql: str
    key_column: Optional[str] = None
    label_column: Optional[str] = None


def _is_admin(user: dict) -> bool:
    from core.roles import is_admin_like
    return is_admin_like(user)


async def _require_connection(cid: Optional[int], user: dict) -> None:
    """The author must SEE the connection the list reads (THE connections'
    rule) -- otherwise a list would be a way to read a source they cannot."""
    from api.connections_api import _connection_visible_to
    conn = await _adb(_db().get_connection, int(cid)) if cid else None
    if not conn or not await _connection_visible_to(conn, user):
        raise HTTPException(status_code=404, detail=f"Connection {cid} not found")


def _require_editable(vl: dict, user: dict) -> None:
    if not _is_admin(user) and vl.get("created_by") != user.get("username"):
        raise HTTPException(status_code=403, detail="Only the list's author or an admin may change it")


def _used_by(list_id: int) -> List[Dict[str, Any]]:
    from core.db.models import BusinessReport, ReportParameter
    with _db().get_session(read_only=True) as s:
        rows = (s.query(ReportParameter.report_id, ReportParameter.name, BusinessReport.name)
                .join(BusinessReport, BusinessReport.id == ReportParameter.report_id)
                .filter(ReportParameter.value_list_id == int(list_id)).all())
    return [{"report_id": r[0], "parameter": r[1], "report": r[2]} for r in rows]


@router.get("")
async def list_value_lists(user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    return {"items": await _adb(_db().list_value_lists)}


@router.post("/preview")
async def preview(body: PreviewIn, user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    """Run the query, NOTHING saved: its columns, the first rows, and -- when
    the key column is named -- how many distinct keys it would hold."""
    await _require_connection(body.connection_id, user)
    try:
        cols, rows = await _adb(vlm.run_query, _db(), body.connection_id, body.source_sql, user)
    except Exception as exc:                                  # noqa: BLE001
        raise HTTPException(status_code=422, detail=f"the query could not run: {exc}") from None
    out: Dict[str, Any] = {"columns": cols, "rows": [{k: vlm._jsonable(v) for k, v in r.items()}
                                                     for r in rows[:20]],
                           "row_count": len(rows)}
    if body.key_column:
        try:
            out["distinct_keys"] = len(vlm.items_from_rows(cols, rows, body.key_column, body.label_column))
        except vlm.ValueListError as exc:
            out["problem"] = str(exc)
    return out


@router.post("")
async def create_value_list(body: ValueListIn, request: Request,
                            user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    data = body.model_dump(exclude_none=True)
    data.setdefault("source_type", "query")
    data.setdefault("sync_mode", "manual")
    bad = vlm.problems(data, creating=True)
    if bad:
        raise HTTPException(status_code=422, detail="; ".join(bad))
    if await _adb(_db().get_value_list_by_name, data["name"].strip()):
        raise HTTPException(status_code=409, detail=f"A value list named {data['name']!r} already exists")
    if data["source_type"] == "query":
        await _require_connection(data.get("connection_id"), user)
    data["name"] = data["name"].strip()
    created = await _adb(_db().create_value_list, data, user.get("username") or "")
    audit_event(_db(), user, request, "value_list_created", resource_type="value_list",
                resource_id=created["id"], details={"name": created["name"]})
    return created


@router.get("/{list_id}")
async def get_value_list(list_id: int, user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    return {**vl, "used_by": await _adb(_used_by, list_id)}


@router.put("/{list_id}")
async def update_value_list(list_id: int, body: ValueListIn, request: Request,
                            user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    _require_editable(vl, user)
    data = body.model_dump(exclude_unset=True)
    # SECURITY (review): a list's source never changes -- a query list turned
    # static would keep the synced snapshot of its connection and serve it
    # WITHOUT the row-security rules a query list is served under.  A
    # different source is a new list.
    if data.get("source_type") not in (None, vl["source_type"]):
        raise HTTPException(status_code=422, detail="A list's source cannot change (query / typed) -- "
                                                    "create a new list instead")
    merged = {**vl, **data}
    bad = vlm.problems(merged, creating=False)
    if bad:
        raise HTTPException(status_code=422, detail="; ".join(bad))
    # SECURITY (review): any change to WHAT a query list reads re-checks
    # that the editor may see its connection -- not only a new connection id
    if merged["source_type"] == "query" and {"connection_id", "source_sql", "source_type"} & set(data):
        await _require_connection(merged.get("connection_id"), user)
    if merged["source_type"] == "static":
        data["connection_id"] = None
    updated = await _adb(_db().update_value_list, list_id, data, user.get("username") or "")
    audit_event(_db(), user, request, "value_list_updated", resource_type="value_list",
                resource_id=list_id, details={"changed": sorted(data)})
    return updated


@router.delete("/{list_id}")
async def delete_value_list(list_id: int, request: Request,
                            user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    _require_editable(vl, user)
    users = await _adb(_used_by, list_id)
    if users:
        names = ", ".join(f"{u['report']} ({u['parameter']})" for u in users[:10])
        raise HTTPException(status_code=409, detail=f"{len(users)} report parameter(s) use this list: {names}")
    await _adb(_db().delete_value_list, list_id)
    audit_event(_db(), user, request, "value_list_deleted", resource_type="value_list",
                resource_id=list_id, details={"name": vl["name"]})
    return {"deleted": True}


@router.post("/{list_id}/sync")
async def sync_value_list(list_id: int, request: Request, user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    _require_editable(vl, user)
    if vl["source_type"] == "query":            # the syncer must still see it
        await _require_connection(vl.get("connection_id"), user)
    try:
        out = await _adb(vlm.sync, _db(), list_id, by=user.get("username") or "")
    except vlm.ValueListError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from None
    audit_event(_db(), user, request, "value_list_synced", resource_type="value_list",
                resource_id=list_id, details=out.get("last_sync_summary") or {})
    return out


@router.put("/{list_id}/items")
async def set_static_items(list_id: int, body: ItemsIn, request: Request,
                           user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    _require_editable(vl, user)
    if vl["source_type"] != "static":
        raise HTTPException(status_code=422, detail="a query list's values come from its sync")
    seen, items = set(), []
    for i, it in enumerate(body.items):
        k = it.key.strip()
        if k and k not in seen:
            seen.add(k)
            items.append({"key": k, "label": it.label, "sort_order": i, "attrs": None})
    out = await _adb(_db().replace_value_list_items, list_id, items, by=user.get("username") or "")
    audit_event(_db(), user, request, "value_list_items_set", resource_type="value_list",
                resource_id=list_id, details=out.get("last_sync_summary") or {})
    return out


@router.get("/{list_id}/items")
async def list_items(list_id: int, search: Optional[str] = Query(default=None, max_length=200),
                     limit: int = Query(500, ge=1, le=5000),
                     user: dict = Depends(_AUTHOR)) -> Dict[str, Any]:
    """The values THIS caller may choose (row security / entitlement applied).
    SECURITY (review): read directly only by an author who may see a query
    list's connection; a report's viewer reads a list THROUGH the report's
    parameter (the report's own view rule)."""
    vl = await _adb(_db().get_value_list, list_id)
    if vl is None:
        raise HTTPException(status_code=404, detail="Value list not found")
    if vl["source_type"] == "query" and not _is_admin(user):
        await _require_connection(vl.get("connection_id"), user)
    try:
        return await _adb(vlm.serve, _db(), list_id, user, search=search, limit=limit)
    except vlm.ValueListError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from None
