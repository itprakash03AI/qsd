"""Phase 139 honest-fix — SQL tooling endpoints.

Three small endpoints powered by sqlglot:
  POST /api/sql/format        — pretty-print raw SQL
  POST /api/sql/split         — split a multi-statement script into a list
  POST /api/sql/to-visual     — reverse-engineer raw SQL into a QueryConfig dict

All endpoints fail-OPEN: if sqlglot is missing OR the SQL doesn't parse,
return the input unchanged with a clear message rather than erroring.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.deps import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["SQL Tools"])


# ── Request models ────────────────────────────────────────────────────────

class FormatRequest(BaseModel):
    sql:        str
    dialect:    Optional[str] = "duckdb"


class SplitRequest(BaseModel):
    sql:        str
    dialect:    Optional[str] = "duckdb"


class ToVisualRequest(BaseModel):
    sql:        str
    dialect:    Optional[str] = "duckdb"


# ── /api/sql/format ───────────────────────────────────────────────────────

def _module_db():
    """THE database for this module — one seam, module level.

    2026-08-23.  This module resolved "the database" THREE separate ways, each
    a FUNCTION-LOCAL import.  Two of them were `from main import _db_manager`,
    a name `main` never exposes, so they raised ImportError on every call and
    two features were dead for as long as they had existed:
    columns_by_table enrichment always returned {}, and distinct-values 500'd.

    Three private copies of one fact is why nobody noticed: there was no single
    place to read, and a fix applied to one site left the others rotting.  It
    also left tests with no seam — a fixture had to reach into whichever module
    a given route happened to import from, and broke whenever that changed.

    One accessor. Every route in this module uses it.  Returns None when the
    manager is not wired; callers decide whether that is fatal.
    """
    try:
        from core.database import get_db_manager
        return get_db_manager()
    except Exception:          # not wired yet / import cycle during boot
        return None


@router.post("/api/sql/format")
async def sql_format(req: FormatRequest, _user: dict = Depends(get_current_user)):
    """Pretty-print raw SQL. Returns input unchanged if sqlglot missing or parse fails."""
    try:
        import sqlglot
    except ImportError:
        return {"sql": req.sql, "formatted": False, "reason": "sqlglot not installed"}
    try:
        formatted = sqlglot.transpile(req.sql, read=req.dialect or "duckdb",
                                      write=req.dialect or "duckdb",
                                      pretty=True)
        if not formatted:
            return {"sql": req.sql, "formatted": False, "reason": "no statements parsed"}
        return {"sql": ";\n\n".join(formatted), "formatted": True}
    except Exception as exc:
        return {"sql": req.sql, "formatted": False, "reason": str(exc)[:200]}


# ── /api/sql/split — multi-statement helper ───────────────────────────────

@router.post("/api/sql/split")
async def sql_split(req: SplitRequest, _user: dict = Depends(get_current_user)):
    """Split a multi-statement script into individual statements.

    Returns a list of trimmed SQL strings. Empty input → empty list.
    Fails OPEN: when sqlglot can't parse, falls back to naive ``;`` split.
    """
    if not req.sql or not req.sql.strip():
        return {"statements": [], "method": "empty"}
    try:
        import sqlglot
        parsed = sqlglot.parse(req.sql, read=req.dialect or "duckdb")
        out = [p.sql(dialect=req.dialect or "duckdb").strip() for p in parsed if p]
        return {"statements": [s for s in out if s], "method": "sqlglot"}
    except Exception as exc:
        # Fallback: naive split that handles trivial cases
        parts = [p.strip() for p in req.sql.split(";") if p.strip()]
        return {"statements": parts, "method": "naive_fallback",
                "warning": f"sqlglot parse failed: {str(exc)[:150]}"}


# ── /api/sql/to-visual — reverse-engineer SQL → QueryConfig ───────────────

@router.post("/api/sql/to-visual")
async def sql_to_visual(req: ToVisualRequest, _user: dict = Depends(get_current_user)):
    """Extract a partial QueryConfig dict from raw SQL via sqlglot AST walk.

    Returns:
        {
          "files":       [<table_name>, ...],
          "columns":     [<col>, ...] or None for SELECT *,
          "filters":     [{col, op, val}, ...],
          "group_by":    [<col>, ...],
          "order_by":    [{column, direction}, ...],
          "aggregations": [{function, column, alias}, ...],
          "limit":       int or None,
          "joins":       [{left, right, on}, ...],
          "warnings":    [<str>, ...],
        }

    Best-effort: complex expressions / window funcs / sub-queries fall under
    "warnings" but the rest of the structure is still returned.
    """
    if not req.sql or not req.sql.strip():
        raise HTTPException(status_code=400, detail="sql is required")
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        raise HTTPException(status_code=400, detail="sqlglot not installed in runtime")

    warnings: List[str] = []
    try:
        tree = sqlglot.parse_one(req.sql, read=req.dialect or "duckdb")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"SQL parse failed: {exc}")

    if not isinstance(tree, exp.Select):
        raise HTTPException(status_code=400, detail="Only SELECT statements are supported")

    # ── Tables (FROM + JOINs) ────────────────────────────────────────────
    files: List[str] = []
    joins: List[Dict[str, Any]] = []
    from_clause = tree.args.get("from")
    if from_clause:
        for tbl in from_clause.find_all(exp.Table):
            name = tbl.name
            if name and name not in files:
                files.append(name)
    for j in tree.args.get("joins") or []:
        if not isinstance(j, exp.Join):
            continue
        side_tbl = j.this
        if isinstance(side_tbl, exp.Table) and side_tbl.name:
            if side_tbl.name not in files:
                files.append(side_tbl.name)
        on_expr = j.args.get("on")
        joins.append({
            "kind": (j.args.get("kind") or "inner").lower(),
            "table": side_tbl.name if isinstance(side_tbl, exp.Table) else None,
            "on":   on_expr.sql() if on_expr else None,
        })

    # ── SELECT clause ────────────────────────────────────────────────────
    columns: Optional[List[str]] = []
    aggregations: List[Dict[str, Any]] = []
    is_star = False
    for sel in tree.expressions or []:
        # Strip alias wrapper
        body = sel.this if isinstance(sel, exp.Alias) else sel
        alias = sel.alias if isinstance(sel, exp.Alias) else None
        # SELECT *
        if isinstance(body, exp.Star):
            is_star = True
            continue
        # Aggregate function
        if isinstance(body, (exp.Sum, exp.Count, exp.Avg, exp.Min, exp.Max)):
            fn_name = body.__class__.__name__.upper()
            args = body.this
            col_ref = args.sql() if args else "*"
            aggregations.append({
                "function": fn_name,
                "column":   col_ref,
                "alias":    alias or f"{fn_name.lower()}_{col_ref.replace('*', 'all')}",
            })
            continue
        # Plain column reference
        if isinstance(body, exp.Column):
            columns.append(body.name)
            continue
        # Anything else (CASE, computed, function call) — note as warning
        warnings.append(f"Complex SELECT expression not mapped: {body.sql()[:60]}")

    if is_star:
        columns = None  # SELECT *

    # ── WHERE clause → filters list ──────────────────────────────────────
    filters: List[Dict[str, Any]] = []
    where = tree.args.get("where")
    if where:
        from sqlglot import expressions as _exp_alias
        # Decompose AND tree into individual predicates
        def _decompose(node):
            if isinstance(node, _exp_alias.And):
                return _decompose(node.left) + _decompose(node.right)
            return [node]
        for pred in _decompose(where.this):
            f = _predicate_to_filter(pred, exp)
            if f:
                filters.append(f)
            else:
                warnings.append(f"Could not map WHERE predicate: {pred.sql()[:60]}")

    # ── GROUP BY ─────────────────────────────────────────────────────────
    group_by: List[str] = []
    grp = tree.args.get("group")
    if grp:
        for g in grp.expressions or []:
            if isinstance(g, exp.Column):
                group_by.append(g.name)
            else:
                group_by.append(g.sql())

    # ── ORDER BY ─────────────────────────────────────────────────────────
    order_by: List[Dict[str, str]] = []
    orderclause = tree.args.get("order")
    if orderclause:
        for o in orderclause.expressions or []:
            col = o.this.name if isinstance(o.this, exp.Column) else o.this.sql()
            direction = "desc" if o.args.get("desc") else "asc"
            order_by.append({"column": col, "direction": direction})

    # ── LIMIT ────────────────────────────────────────────────────────────
    limit = None
    lim = tree.args.get("limit")
    if lim and isinstance(lim.expression, exp.Literal):
        try:
            limit = int(lim.expression.this)
        except (ValueError, TypeError):
            pass

    # HAVING / WINDOW / CTEs → warnings
    if tree.args.get("having"):
        warnings.append("HAVING clause not mapped (use raw_sql mode)")
    if tree.args.get("with_") or tree.args.get("with"):   # sqlglot >= 30 stores it as with_
        warnings.append("CTE / WITH clause not mapped (use raw_sql mode)")
    if any(isinstance(s, exp.Window) for s in tree.find_all(exp.Window)):
        warnings.append("Window function not mapped (use raw_sql mode)")

    return {
        "files":        files,
        "columns":      columns if columns else (None if is_star else []),
        "filters":      filters,
        "group_by":     group_by,
        "order_by":     order_by,
        "aggregations": aggregations,
        "limit":        limit,
        "joins":        joins,
        "warnings":     warnings,
    }


def _predicate_to_filter(node, exp) -> Optional[Dict[str, Any]]:
    """Map a sqlglot predicate node to a {col, op, val} filter dict."""
    op_map = {
        exp.EQ:  "eq",  exp.NEQ: "ne",
        exp.GT:  "gt",  exp.GTE: "gte",
        exp.LT:  "lt",  exp.LTE: "lte",
    }
    for cls, op_str in op_map.items():
        if isinstance(node, cls):
            left, right = node.this, node.expression
            if isinstance(left, exp.Column) and isinstance(right, exp.Literal):
                return {"col": left.name, "op": op_str, "val": _lit_value(right)}
            if isinstance(right, exp.Column) and isinstance(left, exp.Literal):
                # Reverse: 5 < col → col > 5
                rev = {"gt": "lt", "lt": "gt", "gte": "lte", "lte": "gte",
                       "eq": "eq", "ne": "ne"}
                return {"col": right.name, "op": rev.get(op_str, op_str),
                        "val": _lit_value(left)}
            return None
    if isinstance(node, exp.In):
        col = node.this
        if not isinstance(col, exp.Column):
            return None
        vals = [_lit_value(e) for e in node.expressions if isinstance(e, exp.Literal)]
        return {"col": col.name, "op": "in", "val": vals}
    if isinstance(node, exp.Between):
        col = node.this
        if not isinstance(col, exp.Column):
            return None
        lo, hi = node.args.get("low"), node.args.get("high")
        if isinstance(lo, exp.Literal) and isinstance(hi, exp.Literal):
            return {"col": col.name, "op": "between",
                    "val": [_lit_value(lo), _lit_value(hi)]}
    return None


def _lit_value(lit):
    """Extract Python value from a sqlglot Literal."""
    raw = lit.this if hasattr(lit, "this") else lit.name
    if hasattr(lit, "is_number") and lit.is_number:
        try:
            return int(raw) if "." not in str(raw) else float(raw)
        except (ValueError, TypeError):
            return raw
    return str(raw).strip("'\"")


# ── /api/sql/explain-plain — human-readable plan summary ──────────────────

class ExplainPlainRequest(BaseModel):
    explain_text:   str           # raw output of EXPLAIN / EXPLAIN ANALYZE
    sql:            Optional[str] = None   # optional original SQL for context


@router.post("/api/sql/explain-plain")
async def sql_explain_plain(req: ExplainPlainRequest,
                            _user: dict = Depends(get_current_user)):
    """Produce a one-paragraph human-readable summary of an EXPLAIN plan.

    Tries the agent LLM engine first (if enabled). Falls back to a rule-based
    summary that walks the operator tree text and counts the common nodes.
    Always returns SOME summary — never errors.
    """
    text = (req.explain_text or "").strip()
    if not text:
        return {"summary": "No EXPLAIN output provided.", "source": "none"}

    # ── Try LLM engine ────────────────────────────────────────────────────
    try:
        from core.agents.llm_engine import LLMEngine
        engine = LLMEngine()
        if engine.is_configured():
            prompt = (
                "You are a SQL query plan explainer. Given a DuckDB EXPLAIN plan, "
                "produce ONE short paragraph (2-3 sentences) describing what the "
                "query does in plain English. Mention: scan strategy (index, parquet "
                "files), join type if present, aggregation, expected row count if "
                "shown. No bullet points; conversational tone. Avoid the words "
                "'plan' or 'EXPLAIN'.\n\nQuery:\n"
                + (req.sql or "(not provided)")
                + "\n\nPlan:\n"
                + text[:4000]  # cap input
            )
            try:
                summary = engine.generate(prompt, max_tokens=200, temperature=0.2)
                if summary and isinstance(summary, str):
                    return {"summary": summary.strip(), "source": "llm"}
            except Exception as exc:
                logger.debug("LLM EXPLAIN summary failed (%s) — falling back", exc)
    except Exception:
        pass  # LLM engine not available

    # ── Rule-based fallback ───────────────────────────────────────────────
    return {"summary": _rule_based_explain_summary(text), "source": "rules"}


def _rule_based_explain_summary(plan: str) -> str:
    """Walk the EXPLAIN text and produce a short summary from the operators present."""
    upper = plan.upper()
    pieces: List[str] = []

    # Detect scans
    parquet_scans = upper.count("PARQUET_SCAN")
    seq_scans = upper.count("SEQ_SCAN")
    if parquet_scans:
        pieces.append(f"reads {parquet_scans} parquet file{'s' if parquet_scans != 1 else ''}")
    elif seq_scans:
        pieces.append(f"performs {seq_scans} table scan{'s' if seq_scans != 1 else ''}")

    # Joins
    if "HASH_JOIN" in upper or "HASH JOIN" in upper:
        pieces.append("does a hash join")
    elif "MERGE_JOIN" in upper:
        pieces.append("does a merge join")
    elif "NESTED_LOOP" in upper:
        pieces.append("does a nested-loop join (potentially slow)")

    # Aggregation
    if "HASH_GROUP_BY" in upper or "HASH GROUP BY" in upper:
        pieces.append("aggregates with a hash group-by")
    elif "PERFECT_HASH" in upper:
        pieces.append("aggregates via perfect-hash group-by")

    # Filter
    if "FILTER" in upper:
        pieces.append("applies a WHERE filter")

    # Limit
    if "LIMIT" in upper:
        pieces.append("caps the output via LIMIT")

    # Order
    if "ORDER_BY" in upper or "ORDER BY" in upper:
        pieces.append("sorts the results")

    if not pieces:
        return "Operator tree analyzed; no recognised major operators."

    if len(pieces) == 1:
        body = pieces[0].capitalize() + "."
    else:
        body = "; ".join(pieces[:-1]).capitalize() + ", then " + pieces[-1] + "."
    return f"This query {body}"


# ── /api/sql/preview-columns — sqlglot column extraction ──────────────────


class PreviewColumnsRequest(BaseModel):
    sql:     str
    dialect: Optional[str] = "duckdb"
    # Phase 133-H round 6 — when set, the endpoint ALSO fetches the
    # full column list (with types) from every table the SQL
    # references on this connection.  Same path
    # ``published_views/detect_partitions`` uses, lifted out so
    # FeedConfigs / DataFlow / Reconciliation editors can show every
    # column — not just the ones named in the SQL.
    connection_id: Optional[int] = None


@router.post("/api/sql/preview-columns")
async def preview_columns(
    req: PreviewColumnsRequest,
    _user: dict = Depends(get_current_user),
):
    """Extract column names from raw SQL via sqlglot.

    Used by the shared WhereClausesEditor (Recon / Feed / DataFlow) so
    publishers get a real autocomplete dropdown sourced from a proper
    parser rather than the browser-side regex.  Handles CTEs, sub-
    queries, joins, and column aliases.

    Returns ``{columns: [{name, is_alias}], projection: [str],
    tables: [str], warnings: [str]}``.

    ``columns`` is every column the statement REFERENCES (SELECT, WHERE,
    GROUP BY, ORDER BY, JOIN ON) — what a filter editor needs.
    ``projection`` is only what the statement RETURNS — what a dataset's
    output shape needs.  Asking one question and getting the other is how
    a dataset acquired three WHERE-only columns and every report on it
    failed at the source with COLUMN_NOT_FOUND.
    Failure modes:
      - SQL doesn't parse → returns ``{columns: [], tables: [], warnings: ["parse failed: ..."]}``
        (200 status — caller falls back to regex).
      - sqlglot missing → 200 with warning, same shape.

    Best-effort by design.  The endpoint never returns 5xx for malformed
    SQL — the publisher is editing live and a parse failure on every
    keystroke would spam the UI with toasts.
    """
    if not req.sql or not req.sql.strip():
        return {"columns": [], "tables": [], "warnings": []}

    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        return {"columns": [], "tables": [],
                "warnings": ["sqlglot not installed; falling back to regex"]}

    try:
        tree = sqlglot.parse_one(req.sql, read=req.dialect or "duckdb")
    except Exception as e:
        return {"columns": [], "tables": [],
                "warnings": [f"parse failed: {e}"]}

    seen_cols: Dict[str, bool] = {}   # name (lower) → is_alias
    tables: List[str] = []
    table_aliases: Dict[str, str] = {}  # alias → real table name
    warnings: List[str] = []

    def _add(name: Optional[str], is_alias: bool = False):
        if not name or not isinstance(name, str):
            return
        # Normalise: strip table prefix + quotes.
        n = name.replace('"', '').replace('`', '').replace('[', '').replace(']', '')
        if '.' in n:
            n = n.rsplit('.', 1)[-1]
        n = n.strip()
        if not n or n == '*':
            return
        key = n.lower()
        if key not in seen_cols:
            seen_cols[key] = is_alias
        elif is_alias:
            # Promote earlier reference to alias if the canonical form is an alias.
            seen_cols[key] = True

    try:
        # SELECT-list aliases / direct column refs.
        for sel in tree.find_all(exp.Select):
            for expression in (sel.expressions or []):
                if isinstance(expression, exp.Alias):
                    _add(expression.alias_or_name, is_alias=True)
                elif isinstance(expression, exp.Column):
                    _add(expression.alias_or_name, is_alias=False)
                elif isinstance(expression, exp.Star):
                    warnings.append("SELECT * — column list not enumerable")
                else:
                    # Function call / expression — pull the alias if any,
                    # otherwise the first column reference inside it.
                    alias = expression.alias if hasattr(expression, 'alias') else None
                    if alias:
                        _add(alias, is_alias=True)
                    else:
                        cols_inside = list(expression.find_all(exp.Column))
                        if cols_inside:
                            _add(cols_inside[0].alias_or_name, is_alias=False)

        # WHERE / GROUP BY / ORDER BY / JOIN ON — every Column reference.
        # Anything not already captured from the SELECT list shows up here.
        for col in tree.find_all(exp.Column):
            _add(col.alias_or_name, is_alias=False)

        # Tables referenced (handy for the caller's partition lookup).
        # Phase 133-H round 14 — also capture ``FROM trades a`` /
        # ``JOIN positions b`` aliases so the publish dialog can offer
        # alias-qualified column entries (``a.code``, ``b.code``) in
        # addition to the bare + table-qualified forms it already
        # builds.  table_aliases maps ``alias → table_name`` for every
        # explicit AS-alias the publisher wrote.  An alias that's the
        # same as the table name (no actual AS) is omitted.
        for tbl in tree.find_all(exp.Table):
            name = tbl.name
            if name and name not in tables:
                tables.append(name)
            alias_name = tbl.alias_or_name
            if alias_name and alias_name != name:
                # Last-write-wins is fine: the SAME alias can't bind to
                # two tables in valid SQL.
                table_aliases[alias_name] = name
    except Exception as e:
        warnings.append(f"AST walk error: {e}")

    columns = [{"name": k, "is_alias": is_alias}
               for k, is_alias in seen_cols.items()]

    # Phase 133-H round 6 — when caller supplied a connection_id,
    # ALSO return the full column list per table by reading the
    # ``schema_cache`` table the platform populates on every
    # CQB / BQB / register-table call.  Falls back to
    # ``connector.list_columns()`` on cache miss for SQL warehouses
    # so first-time use still works.  Gives the editor a dropdown of
    # EVERY column, not just the ones named in the SQL — which was
    # the user's core complaint ("show all columns to decide
    # static or dynamic").
    columns_by_table: Dict[str, List[Dict[str, Any]]] = {}
    partition_columns_by_table: Dict[str, List[str]] = {}
    table_connection_ids: Dict[str, int] = {}
    # SECURITY 2026-08-23 (Phase 2A): the enrichment block below reads the
    # connection's schema by id AND, on a cache miss, drives an OUTBOUND
    # connector.list_columns / S3 read with the connection's stored
    # credentials.  A caller not entitled to the connection must reach none
    # of that.  This endpoint is fail-open editor autocomplete, so it
    # DEGRADES: drop an unentitled id, keep the SQL-parsed column list.  The
    # decision is the shared entitlement rule (denied_connection_ids).
    if req.connection_id:
        try:
            from core.entitlements import denied_connection_ids as _dci
            _db_ent = _module_db()
            if _db_ent is not None and _dci(_user, [req.connection_id], db=_db_ent):
                req.connection_id = None
                warnings.append("column enrichment skipped: connection not "
                                "accessible to you")
        except Exception:
            # Fail CLOSED on an entitlement-check error: no enrichment rather
            # than a possible cross-user schema read.
            req.connection_id = None
    if req.connection_id and tables:
        # 2026-08-23: was ``from main import _db_manager`` — main exposes
        # ``db_manager``, never ``_db_manager``, so this ALWAYS raised
        # ImportError and the entire columns_by_table enrichment below was
        # dead (every response returned columns_by_table={}).  The sanctioned
        # process-wide accessor returns the wired manager.
        try:
            _db = _module_db()
        except Exception:
            _db = None
        if _db is not None:
            try:
                conn_raw = _db.get_connection_raw(req.connection_id)
            except Exception:
                conn_raw = None
            conn_type = (conn_raw or {}).get("connection_type", "")
            for tbl_name in tables:
                if not tbl_name:
                    continue
                # Cache hit?  schema_data is the dict
                # ``read_parquet_schema`` / ``list_columns`` returned.
                cached = None
                try:
                    cached = _db.get_schema_cache(req.connection_id, tbl_name)
                except Exception:
                    cached = None
                if cached and cached.get("schema_data"):
                    sd = cached["schema_data"] or {}
                    cols = sd.get("columns") or []
                    if cols:
                        columns_by_table[tbl_name] = [
                            {
                                "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                                "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                            }
                            for c in cols
                            if (c.get("name") if isinstance(c, dict) else c)
                        ]
                        table_connection_ids[tbl_name] = req.connection_id
                    pcols = sd.get("partition_columns") or []
                    if pcols:
                        partition_columns_by_table[tbl_name] = [str(p) for p in pcols if p]
                    continue  # cache hit — done with this table
                # Cache miss: try partition_cache too — it's keyed
                # separately and gets populated by every CQB query.
                try:
                    pc_entries = _db.get_connection_partitions(req.connection_id, tbl_name)
                    if pc_entries:
                        partition_columns_by_table[tbl_name] = [
                            p.get("column") for p in pc_entries if p.get("column")
                        ]
                except Exception:
                    pass
                # Last resort for SQL warehouses — ask the connector.
                # Skipped for non-SQL (S3 / file) connections; the
                # schema_cache should be primed for those by the
                # register-table flow.
                if not conn_raw:
                    continue
                try:
                    from core.connectors import (
                        SQL_CONNECTOR_TYPES as _SCT, get_connector as _gc,
                    )
                except Exception:
                    _SCT, _gc = set(), None
                # Phase 133-I round 27 — S3/iceberg/registered fallback.
                # For S3-backed connections (parquet/iceberg/registered
                # tables) connector.list_columns doesn't apply.  Try
                # ``read_parquet_schema_for_conn`` against the table's
                # registered prefix instead.  This is the same fallback
                # ``detect_partitions`` uses for file_refs.
                if conn_type in ("s3", "local") and not columns_by_table.get(tbl_name):
                    try:
                        _cfg = conn_raw.get("config", {})
                        _reg = _cfg.get("registered_tables") or []
                        _tdef = next((t for t in _reg if t.get("name") == tbl_name), None)
                        if _tdef:
                            from core.s3_utilities import make_s3_client_for_conn
                            from core.schema_reader import read_parquet_schema_for_conn
                            _bucket = _cfg.get("bucket_name", "")
                            _prefix = _tdef.get("prefix") or _tdef.get("s3_prefix") or ""
                            _s3c = make_s3_client_for_conn(conn_raw)
                            _si = read_parquet_schema_for_conn(
                                conn_raw, _bucket, _prefix, s3_client=_s3c,
                            )
                            _all_cols_s3 = _si.get("columns") or []
                            if _all_cols_s3:
                                columns_by_table[tbl_name] = [
                                    {
                                        "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                                        "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                                    }
                                    for c in _all_cols_s3
                                    if (c.get("name") if isinstance(c, dict) else c)
                                ]
                                table_connection_ids[tbl_name] = req.connection_id
                            _pcols_s3 = _si.get("partition_columns") or []
                            # iceberg uses partition_spec; fall back to it
                            if not _pcols_s3:
                                _ps = _si.get("partition_spec") or []
                                if isinstance(_ps, list):
                                    _pcols_s3 = [
                                        (p.get("source_column") or p.get("name") or "")
                                        for p in _ps
                                        if isinstance(p, dict) and (p.get("source_column") or p.get("name"))
                                    ]
                            if _pcols_s3:
                                partition_columns_by_table[tbl_name] = _pcols_s3
                    except Exception as _se:
                        warnings.append(
                            f"S3 schema read failed for {tbl_name}: {str(_se)[:200]}"
                        )
                if _gc and conn_type in _SCT:
                    _co = None
                    try:
                        try:
                            _co = _gc(conn_type, conn_raw.get("config", {}),
                                      req.connection_id, conn_raw.get("name", ""))
                        except TypeError:
                            _co = _gc(conn_type, conn_raw.get("config", {}))
                    except Exception:
                        _co = None
                    if _co is not None:
                        try:
                            # tbl_name may be ``cat.sch.tbl`` or
                            # ``sch.tbl`` or just ``tbl``.  Split and
                            # fill the catalog from connection config.
                            _parts = tbl_name.split(".")
                            _default_cat = (
                                conn_raw.get("config", {}).get("catalog")
                                or conn_raw.get("config", {}).get("database")
                                or ""
                            )
                            if len(_parts) >= 3:
                                _cat, _sch, _tbl = _parts[-3], _parts[-2], _parts[-1]
                            elif len(_parts) == 2:
                                _cat, _sch, _tbl = _default_cat, _parts[0], _parts[1]
                            else:
                                _cat, _sch, _tbl = _default_cat, "", _parts[0]
                            _all_cols = _co.list_columns(_cat, _sch, _tbl) or []
                            if _all_cols:
                                columns_by_table[tbl_name] = [
                                    {
                                        "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                                        "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                                    }
                                    for c in _all_cols
                                    if (c.get("name") if isinstance(c, dict) else c)
                                ]
                                table_connection_ids[tbl_name] = req.connection_id
                        except Exception as _le:
                            warnings.append(
                                f"list_columns({tbl_name}) failed: {str(_le)[:200]}"
                            )
                        finally:
                            try:
                                _co.close()
                            except Exception:
                                pass

    # ── projection: what the statement RETURNS ────────────────────────
    #
    # 2026-09-04.  ``columns`` above is deliberately EVERY column the
    # statement references — SELECT list, WHERE, GROUP BY, ORDER BY, JOIN
    # ON — because its original consumers (the WHERE-clause editor, the
    # publish dialog) need the columns you can FILTER ON.  That is right
    # for them and wrong for anyone asking "what does this query return".
    #
    # DatasetCreationWizard was using it as a saved query's OUTPUT SHAPE.
    # For a reported Starburst query that projected 23 columns and named
    # three more only in its WHERE, the dataset was created with 26.  The
    # report then selected all 26, the engine wrapped the query as
    # ``WITH _base AS (...) SELECT "system_id" ... FROM _base``, and
    # Starburst answered COLUMN_NOT_FOUND — naming one column and
    # explaining nothing.
    #
    # A column a query FILTERS ON is not a column it RETURNS.  Both
    # answers are useful; they are different questions, so they are
    # different fields.  ``columns`` is unchanged for its five existing
    # consumers.
    #
    # Derived by the SAME parser dataset detection and saved-query column
    # capture already use (core.sql_output_columns), so "what does this
    # return" has ONE implementation rather than a second opinion here.
    projection: List[str] = []
    try:
        from core.sql_output_columns import derive_columns_from_sql_text
        projection = [c["physical_name"]
                      for c in (derive_columns_from_sql_text(req.sql) or [])
                      if c.get("physical_name")]
    except Exception as _proj_exc:      # noqa: BLE001
        # Best-effort like the rest of this endpoint: an unreadable
        # projection is an EMPTY list plus a warning, never a 5xx and
        # never a silent [] that a caller could read as "returns nothing".
        warnings.append(f"projection unavailable: {_proj_exc}")

    return {
        "columns": columns,
        "projection": projection,
        "tables": tables,
        "table_aliases": table_aliases,
        "columns_by_table": columns_by_table,
        "partition_columns_by_table": partition_columns_by_table,
        "table_connection_ids": table_connection_ids,
        "warnings": warnings,
    }


# ── /api/sql/distinct-values — distinct-value picker for the editor ──────


class DistinctValuesRequest(BaseModel):
    connection_id: int
    column:         str
    table:          Optional[str] = None
    limit:          Optional[int] = 200
    # Phase 133-H round 8 — optional SQL context for alias resolution.
    # When the user picks a SELECT-list alias (e.g. ``region_pretty``
    # in ``SELECT UPPER(region) AS region_pretty FROM trades``), the
    # bare alias doesn't exist on ``trades``.  Pass the originating SQL
    # so the endpoint can resolve the alias to its underlying column
    # via sqlglot AST walk.
    sql:            Optional[str] = None
    dialect:        Optional[str] = "duckdb"


# 2026-10-24 -- the cache is core/column_value_cache.py, SHARED with report
# parameters (a list read here for fact_tetb.region serves a report whose
# parameter traces to fact_tetb.region, and the other way round).
_DISTINCT_HARD_CAP = 1000                   # ceiling regardless of limit


@router.post("/api/sql/distinct-values")
async def distinct_values(
    req: DistinctValuesRequest,
    _user: dict = Depends(get_current_user),
):
    """Return up to ``limit`` distinct values for ``column`` on the given
    connection's ``table`` — used by the WhereClausesEditor's per-row
    value picker on non-partition-cached sources (Snowflake / Oracle /
    Trino / Databricks).

    Caches results for 5 minutes per (connection, table, column) so
    repeated dropdown opens don't hammer the warehouse.  Capped at
    ``_DISTINCT_HARD_CAP`` regardless of the caller's request.

    Returns ``{values: [str], cached: bool, warnings: [str]}``.

    Safe-by-default:
      - Returns 200 + empty list when the connection / table is
        unreachable, the column doesn't exist, or the connector can't
        run the query.
      - Caps the result count to keep payloads small.
      - All identifiers passed through ``sqlglot.exp.quote_identifier``
        (when available) — no string concatenation into SQL.

    SECURITY 2026-08-20:
      - Connection ACL: the caller must be able to SEE the connection
        (``_connection_visible_to`` — the same visibility rule
        connections_api applies).  Before this fix any authenticated user
        could read column values from any registered warehouse by
        connection id.
      - Row security: the DISTINCT query is rewritten through
        ``secure_sql`` in the TARGET dialect, so values an RLS predicate
        hides never reach the caller (they used to — the raw column
        domain was read straight from the warehouse).
      - The cache key carries the caller's RLS scope
        (``rls_user_scope``): a filtered user's value list is never
        served to — or taken from — another principal.  The ACL check
        runs BEFORE the cache lookup, so a user with no grant can't
        read another user's cached domain either.
    """

    # 2026-08-23: was ``from main import _db_manager`` — that name does not
    # exist on main (only ``db_manager``), so this import raised ImportError
    # and 500'd every distinct-values call.  Use the sanctioned accessor.
    _db = _module_db()
    if _db is None:
        raise HTTPException(503, "Database not initialised")

    if not req.column or not req.column.strip():
        raise HTTPException(400, "column is required")
    if not req.table or not req.table.strip():
        return {"values": [], "cached": False,
                "warnings": ["table required for distinct-values lookup"]}

    # Connection ACL — BEFORE the cache lookup (a denied caller must not
    # even learn whether a cached domain exists).  The record is fetched
    # from THIS module's db (main._db_manager, same as always) and the
    # decision is the shared visibility rule from connections_api — owner /
    # is_shared / legacy-unowned / explicit ACL grant / admin.  404 (not
    # 403) so the route is not an existence oracle, matching connections_api.
    import asyncio as _aio
    try:
        conn = await _aio.to_thread(_db.get_connection, req.connection_id)
    except Exception as e:
        return {"values": [], "cached": False,
                "warnings": [f"connection lookup failed: {e}"]}
    if not conn:
        raise HTTPException(404, f"Connection {req.connection_id} not found")
    from api.connections_api import _connection_visible_to
    if not await _connection_visible_to(conn, _user):
        raise HTTPException(404, f"Connection {req.connection_id} not found")

    table = req.table.strip()
    column = req.column.strip()
    # 0 means unlimited -- resolve to the hard cap rather than the 200
    # default, which would return fewer values than the caller asked for.
    _req_limit = int(req.limit or 0)
    limit = (min(_req_limit, _DISTINCT_HARD_CAP) if _req_limit > 0
             else _DISTINCT_HARD_CAP)
    # Phase 133-H round 5 — normalize cache key on the BARE column so
    # ``trades.region`` and ``region`` hit the same cache entry (the
    # qualifier is stripped before quoting anyway).
    _bare_col_key = column.rsplit(".", 1)[-1].lower() if "." in column else column.lower()

    # SECURITY 2026-08-20 — principal scope in the key.  When row security
    # is enabled each non-admin user gets their own entry (their DISTINCT
    # result is policy-filtered); when it's off the scope is empty and the
    # entry stays shared — correct, because the ACL above already gated
    # access and the unfiltered domain is then identical for every caller.
    # 2026-09-26 (F0) -- a scoped entry folds the policy SET too
    # (column_value_cache.scope_for: rls_user_scope + the policy marker).
    from core import column_value_cache as _cvc
    _scope = _cvc.scope_for(_user)
    cache_key = _cvc.key(req.connection_id, table, _bare_col_key, scope=_scope)
    _hit = _cvc.get(cache_key, limit)
    if _hit is not None:
        return {"values": [str(v) for v in _hit if v is not None], "cached": True, "warnings": []}

    # Build a safe SQL string.  Identifiers are quoted via sqlglot when
    # available; otherwise plain double-quoting.  WE NEVER INLINE the
    # value side — distinct values are read FROM the source, never
    # supplied by the user as part of this query.
    #
    # Phase 133-H deep-dive — when ``table`` is a qualified reference
    # (e.g. ``catalog.schema.table`` on Trino / ``database.table`` on
    # Snowflake), each part must be quoted INDIVIDUALLY and joined with
    # dots — otherwise we end up emitting ``"catalog.schema.table"``
    # which the warehouse treats as a single identifier and rejects.
    def _quote_qualified(name: str) -> str:
        parts = [p for p in str(name).split(".") if p.strip()]
        try:
            import sqlglot
            return ".".join(
                sqlglot.exp.to_identifier(p, quoted=True).sql() for p in parts
            )
        except Exception:
            return ".".join('"' + p.replace('"', '""') + '"' for p in parts)

    # Phase 133-H round 4 — strip leading table-qualifier from the
    # column name.  WhereClausesEditor passes the dropdown's display
    # value, which can be ``schema.table.col`` when the catalog grouped
    # by source table.  Quoting that whole thing produced
    # ``"schema.table.col"`` which the warehouse treated as a single
    # identifier and rejected.  Take only the trailing part.
    bare_column = column.rsplit(".", 1)[-1] if "." in column else column

    # Phase 133-H round 8 — when the bare_column is a SELECT-list
    # alias defined in ``req.sql``, resolve it to the underlying
    # column expression.  Otherwise the warehouse rejects
    # ``SELECT DISTINCT <alias> FROM <table>`` (the alias lives in
    # the OUTER query only).  Conservative: when the alias's body is
    # a single Column reference, swap to that.  Anything more
    # complex (function call, expression) falls back to the bare
    # alias and lets the warehouse error gracefully — the editor's
    # Autocomplete still works in free-text mode.
    if req.sql:
        try:
            import sqlglot
            from sqlglot import exp as _exp
            _tree = sqlglot.parse_one(req.sql, read=req.dialect or "duckdb")
            _alias_target: Optional[str] = None
            for sel in _tree.find_all(_exp.Select):
                for projection in (sel.expressions or []):
                    if isinstance(projection, _exp.Alias):
                        if projection.alias_or_name.lower() == bare_column.lower():
                            inner = projection.this
                            if isinstance(inner, _exp.Column):
                                _alias_target = inner.name
                                break
                if _alias_target:
                    break
            if _alias_target:
                logger.debug(
                    "distinct-values: resolved alias %r → %r",
                    bare_column, _alias_target,
                )
                bare_column = _alias_target
        except Exception:
            logger.debug("distinct-values alias resolution failed", exc_info=True)
    try:
        import sqlglot
        col_q = sqlglot.exp.to_identifier(bare_column, quoted=True).sql()
    except Exception:
        col_q = '"' + bare_column.replace('"', '""') + '"'
    tbl_q = _quote_qualified(table)

    # Phase 133-H deep-dive (round 3) — don't inline LIMIT.  Oracle
    # rejects ``LIMIT n`` (uses ``FETCH FIRST n ROWS ONLY`` / ``ROWNUM``);
    # the connector's ``execute_query(sql, limit)`` applies the right
    # dialect-specific syntax.  Snowflake / Trino / Databricks / Athena
    # all support the connector-level limit arg too — same code path.
    sql = f"SELECT DISTINCT {col_q} AS v FROM {tbl_q} ORDER BY 1"

    # SECURITY 2026-08-20 — row-security rewrite in the TARGET dialect
    # (same pattern as the structured connector path in execute_api).
    # Without it the cached distinct set was the UNRESTRICTED column
    # domain: a user whose RLS predicate hides certain region/account
    # values still saw the full list.  Fail-closed: if policy resolution
    # itself breaks we return NO values, never the unfiltered domain.
    from core.row_security import secure_sql as _rs_sec
    from core.row_security.api import PolicyResolutionError as _RsErr
    from core.sql_filter_wrapper import dialect_for_connection_type as _rs_dial
    import asyncio as _aio
    try:
        _secured_sql = await _aio.to_thread(
            _rs_sec,
            sql,
            dialect=_rs_dial(conn.get("connection_type")),
            user_ctx=_user,
            connection_id=req.connection_id,
        )
        if _secured_sql:
            sql = _secured_sql
    except _RsErr as _rs_exc:
        logger.error("distinct-values: row-security rewrite failed for "
                     "connection %s: %s", req.connection_id, _rs_exc)
        return {"values": [], "cached": False,
                "warnings": ["row-security policy could not be resolved — "
                             "no values returned"]}

    try:
        # 2026-09-16 POOLED — distinct-value lookups back the filter
        # pickers, so this fires repeatedly while a user builds a report.
        from core.connection_pool import get_pooled_connector
        with get_pooled_connector(
                conn.get("id"),
                conn.get("connection_type", ""),
                conn.get("config", {}),
                conn.get("name", ""),
        ) as connector:
            result = connector.execute_query(sql, limit)
    except Exception as e:
        return {"values": [], "cached": False,
                "warnings": [f"query failed: {e}"]}

    # Normalise rows to a flat string list.  Different connectors return
    # different shapes — we handle the two we know.
    values: List[str] = []
    rows = (result or {}).get("rows") or []
    for r in rows:
        if isinstance(r, dict):
            v = next(iter(r.values()), None)
        elif isinstance(r, (list, tuple)) and r:
            v = r[0]
        else:
            v = r
        if v is None:
            continue
        s = str(v)
        if s and s not in values:
            values.append(s)
        if len(values) >= limit:
            break

    _cvc.put(cache_key, values, limit)
    return {"values": values, "cached": False, "warnings": []}
